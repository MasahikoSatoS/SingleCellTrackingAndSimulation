//
//  Communication.m
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2/15/2014.
//
//

#import "CommXYMap.h"

NSString *notificationToCommXYMap = @"notificationExecuteCommXYMap";

@implementation CommXYMap

-(id)init{
    self = [super init];
    
    if (self != nil){
        progressMonitor = 0;
        mapATemptCount = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToCommXYMap object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    commXYMapTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(processControl) userInfo:nil repeats:YES];
}

-(void)processControl{
    if (runStatusXYMap != 0) [self xyMapMonitor];
}

-(void)xyMapMonitor{
    if (runStatusXYMap == 2){
        mapATemptCount++;
        
        NSString *activeProcess;
        
        for (NSRunningApplication *currApp in [[NSWorkspace sharedWorkspace] runningApplications]){
            activeProcess = [currApp localizedName];
            
            if ([activeProcess isEqualToString:@"XY_Map"]){
                runStatusXYMap = 3;
                mapDisplayFlag = 1;
                progressMonitor = 0;
                mapATemptCount = 0;
                break;
            }
        }
        
        if (mapATemptCount == 1000){
            mapDisplayFlag = 2;
            runStatusXYMap = 0;
            mapATemptCount = 0;
        }
    }
    
    if (runStatusXYMap == 3){
        string bodyNameSend;
        string autoStatusXYSend;
        string batchStatusXYSend;
        string initialStatusXYSend;
        
        if (autoProcessCommit == "1") autoStatusXYSend = "1";
        else if (autoProcessCommit == "nil" && initialRunStatus == "nil" && processingIFStatus == 1) autoStatusXYSend = "0";
        else if (autoProcessCommit == "nil" && processingIFStatus == 2) autoStatusXYSend = "0";
        else autoStatusXYSend = "0";
        
        if (batchBackupOperationCommit == "1" || batchImageOperationCommit == "1") batchStatusXYSend = "1";
        else batchStatusXYSend = "0";
        
        if (initialRunStatus != "nil") initialStatusXYSend = "1";
        else initialStatusXYSend = "0";
        
        if (bodyNameHold != "nil") bodyNameSend = "~~"+bodyNameHold;
        else bodyNameSend = "~~nil";
        
        if (bodyNameSend != bodyNameSendMap || autoStatusXYSend != autoStatusXYSendMap || batchStatusXYSend != batchStatusXYSendMap || initialStatusXYSend != initialStatusXYSendMap){
            bodyNameSendMap = bodyNameSend;
            autoStatusXYSendMap = autoStatusXYSend;
            batchStatusXYSendMap = batchStatusXYSend;
            initialStatusXYSendMap = initialStatusXYSend;
            
            fstream oin;
            
            for (int counter1 = 0; counter1 < 10; counter1++){
                oin.open(instructionMapPath.c_str(), ios::out);
                
                if (oin.is_open()){
                    oin<<bodyNameSend<<endl;
                    oin<<autoStatusXYSend<<endl;
                    oin<<batchStatusXYSend<<endl;
                    oin<<initialStatusXYSend<<endl;
                    oin.close();
                    progressMonitor = 4;
                    break;
                }
            }
        }
    }
    
    if (runStatusXYMap == 3 && progressMonitor == 4){
        progressMonitor = 1;
    }
    
    if (runStatusXYMap == 3 && progressMonitor == 1){
        string receivedData = "nil";
        string getString = "nil";
        
        int instructionMapFlag = 0;
        
        ifstream fin;
        fin.open(instructionMapPath2.c_str(),ios::in);
        if (fin.is_open()){
            instructionMapFlag = 1;
            fin.close();
        }
        
        if (instructionMapFlag != 0){
            fin.open(instructionMapPath2.c_str(),ios::in);
            
            getline(fin, getString);
            
            if ((int)getString.find("~~N") != -1){
                receivedData = getString;
                remove (instructionMapPath2.c_str());
            }
            
            fin.close();
        }
        
        if (receivedData != "nil"){
            string returnMessage = receivedData;
            
            if ((int)returnMessage.find("~~N") != -1){
                int totalFOVTemp = 0;
                
                returnMessage = returnMessage.substr(returnMessage.find("/")+1);
                string fovNoTemp;
                
                for (int counter1 = 0; counter1 < 16; counter1++){
                    fovNoTemp = returnMessage.substr(0, returnMessage.find("/"));
                    returnMessage = returnMessage.substr(returnMessage.find("/")+1);
                    arrayFOVNumberList [counter1] = atoi(fovNoTemp.c_str());
                    
                    totalFOVTemp = totalFOVTemp+atoi(fovNoTemp.c_str());
                }
                
                objectiveType = returnMessage.substr(0, returnMessage.find("/"));
                
                if (objectiveType == "1") arraySummaryList [31] = "x10";
                else if (objectiveType == "2") arraySummaryList [31] = "x20";
                else if (objectiveType == "3") arraySummaryList [31] = "x40";
                
                string fovNumberString;
                string treatmentString;
                
                for (int counter1 = 7; counter1 < 23; counter1++){
                    treatmentString = arrayNameList [counter1-7];
                    fovNumberString = to_string(arrayFOVNumberList [counter1-7]);
                    
                    if (treatmentString == "nil" && fovNumberString == "0") arraySummaryList [counter1] = "nil";
                    else if (treatmentString != "nil" && fovNumberString == "0") arraySummaryList [counter1] = treatmentString+" (nil)";
                    else if (treatmentString == "nil" && fovNumberString != "0") arraySummaryList [counter1] = "nil ("+fovNumberString+")";
                    else arraySummaryList [counter1] = treatmentString+" ("+fovNumberString+")";
                }
                
                totalFOVNoHold = to_string(totalFOVTemp);
                
                arraySummaryList [4] = totalFOVNoHold;
                
                ofstream oin;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses parameterSave];
                
                oin.open(summaryDataPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < summaryListCount; counter1++) oin<<arraySummaryList [counter1]<<endl;
                
                oin.close();
                
                oin.open(nameListDataPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < 16; counter1++) oin<<arrayNameList [counter1]<<endl;
                for (int counter1 = 0; counter1 < 16; counter1++) oin<<arrayFOVNumberList [counter1]<<endl;
                
                oin<<fluorescent1<<endl;
                oin<<fluorescent2<<endl;
                oin<<fluorescent3<<endl;
                oin<<fluorescent4<<endl;
                oin<<fluorescent5<<endl;
                oin<<fluorescent6<<endl;
                oin<<fluorescentNew1<<endl;
                oin<<fluorescentNew2<<endl;
                oin<<fluorescentNew3<<endl;
                oin<<fluorescentNew4<<endl;
                oin<<fluorescentNew5<<endl;
                oin<<fluorescentNew6<<endl;
                
                string colorNoString = to_string(fluorescentColor1);
                oin<<colorNoString<<endl;
                colorNoString = to_string(fluorescentColor2);
                oin<<colorNoString<<endl;
                colorNoString = to_string(fluorescentColor3);
                oin<<colorNoString<<endl;
                colorNoString = to_string(fluorescentColor4);
                oin<<colorNoString<<endl;
                colorNoString = to_string(fluorescentColor5);
                oin<<colorNoString<<endl;
                colorNoString = to_string(fluorescentColor6);
                oin<<colorNoString<<endl;
                
                oin.close();
                
                fovNoDisplayFlag = 1;
                summarySetCall = 2;
                tableViewPage = 0;
                mapSetPerform = "1";
            }
        }
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToCommXYMap object:nil];
    if (commXYMapTimer) [commXYMapTimer invalidate];
}

@end
