//
//  BatchImageProcess.m
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2014-05-21.
//
//

#import "BatchImageProcess.h"

NSString *notificationToBatchImage = @"notificationExecuteBatchImage";

@implementation BatchImageProcess

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToBatchImage object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    batchImageTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(processControl) userInfo:nil repeats:YES];
}

-(void)processControl{
    if (autoBatchMode == 3) [self batchImageMain];
}

-(void)batchImageMain{
    DIR *dir;
    struct dirent *dent;
    DIR *dir2;
    struct dirent *dent2;
    DIR *dir3;
    struct dirent *dent3;
    
    ofstream oin;
    
    if (autoStepCount == 200) [batchImageTimer invalidate];
    
    if (autoStepCount == 0 && launchCheck == 0){
        NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @"/" error:nil];
        unsigned long freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
        
        if (autoTimerInvalidate == 1 && autoStepCount == 0){
            for (int counter1 = 0; counter1 < 10; counter1++){
                oin.open(instructionCSPath.c_str(), ios::out);
                
                if (oin.is_open()){
                    oin<<"Exit"<<endl;
                    oin.close();
                    break;
                }
            }
            
            autoTimerInvalidate = 0;
            autoStepCount = 4;
            contrastSetFlag = 2;
            
            [batchImageTimer invalidate];
        }
        else if (autoStepCount == -1 && 2097152000 > freeSize){
            if (consoleWarningCount+5 > consoleWarningLimit) [self warningUpDate];
            arrayConsoleWarning [consoleWarningCount] = "[BI] Low Disk Space: Processing Holding", consoleWarningCount++;
            
            for (int counter1 = 0; counter1 < 10; counter1++){
                oin.open(instructionCSPath.c_str(), ios::out);
                
                if (oin.is_open()){
                    oin<<"Exit"<<endl;
                    oin.close();
                    break;
                }
            }
            
            autoStepCount = 4;
            contrastSetFlag = 2;
            consolePage = 0;
            consoleDisplayCall = 1;
            
            [batchImageTimer invalidate];
        }
        else{
            
            filePickUpCount++;
            batchImageIFCount++;
            
            string stringExtract = to_string(filePickUpCount);
            
            if (stringExtract.length() == 1) stringExtract = "000"+stringExtract;
            else if (stringExtract.length() == 2) stringExtract = "00"+stringExtract;
            else if (stringExtract.length() == 3) stringExtract = "0"+stringExtract;
            
            string imageNoIF = to_string(batchImageIFCount);
            
            if (imageNoIF.length() == 1) imageNoIF = "000"+imageNoIF;
            else if (imageNoIF.length() == 2) imageNoIF = "00"+imageNoIF;
            else if (imageNoIF.length() == 3) imageNoIF = "0"+imageNoIF;
            
            productsFilesImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Source_Images";
            
            int processEnd = 0;
            
            string processingIFCountString = to_string(processingIFCount);
            
            if (processingIFCountString.length() == 1) processingIFCountString = "0"+processingIFCountString;
            
            string processingIFCountString2 = to_string(processingIFCount+1);
            
            if (processingIFCountString2.length() == 1) processingIFCountString2 = "0"+processingIFCountString2;
            
            long sizeForCopy = 0;
            
            struct stat sizeOfFile;
            
            if (processingIFStatus == 0){
                dir = opendir(productsFilesImagePath.c_str());
                
                if (dir != NULL){
                    string entry;
                    string entry2;
                    string entry3;
                    string productDataPath1;
                    string productDataPath2;
                    string productDataPath3;
                    string productDataPath4;
                    string productDataPath5;
                    string productDataPath6;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            productDataPath1 = productsFilesImagePath+"/"+entry;
                            productDataPath2 = productsFocalTempPath+"/"+entry;
                            
                            dir2 = opendir(productDataPath1.c_str());
                            
                            if (dir2 != NULL){
                                while ((dent2 = readdir(dir2))){
                                    entry2 = dent2 -> d_name;
                                    
                                    if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                        productDataPath3 = productDataPath1+"/"+entry2;
                                        productDataPath4 = productDataPath2+"/"+entry2;
                                        
                                        dir3 = opendir(productDataPath3.c_str());
                                        
                                        if (dir3 != NULL){
                                            while ((dent3 = readdir(dir3))){
                                                entry3 = dent3 -> d_name;
                                                
                                                if ((int)entry3.find("_"+stringExtract+"-") != -1 && ((int)entry3.find("BMP") == -1 || (int)entry3.find("TIF") == -1)){
                                                    productDataPath5 = productDataPath3+"/"+entry3;
                                                    productDataPath6 = productDataPath4+"/"+entry3;
                                                    
                                                    if (stat(productDataPath5.c_str(), &sizeOfFile) == 0){
                                                        sizeForCopy = sizeOfFile.st_size;
                                                        
                                                        ifstream infile (productDataPath5.c_str(), ifstream::binary);
                                                        ofstream outfile (productDataPath6.c_str(), ofstream::binary);
                                                        
                                                        char *buffer = new char[sizeForCopy];
                                                        infile.read (buffer, sizeForCopy);
                                                        outfile.write (buffer, sizeForCopy);
                                                        delete [] buffer;
                                                        
                                                        outfile.close();
                                                        infile.close();
                                                    }
                                                    
                                                    processEnd = 1;
                                                }
                                                else if ((int)entry3.find("_"+stringExtract+"-") != -1 && ((int)entry3.find("BMP") != -1 || (int)entry3.find("TIF") != -1)){
                                                    processEnd = 2;
                                                    break;
                                                }
                                            }
                                            
                                            closedir(dir3);
                                        }
                                    }
                                    
                                    if (processEnd == 2){
                                        break;
                                    }
                                }
                                
                                closedir(dir2);
                            }
                        }
                        
                        if (processEnd == 2){
                            break;
                        }
                    }
                    
                    closedir(dir);
                }
            }
            else if (processingIFStatus == 1){
                dir = opendir(productsFilesImagePath.c_str());
                
                if (dir != NULL){
                    string entry;
                    string entry2;
                    string entry3;
                    string productDataPath1;
                    string productDataPath2;
                    string productDataPath3;
                    string productDataPath4;
                    string productDataPath5;
                    string productDataPath6;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            productDataPath1 = productsFilesImagePath+"/"+entry;
                            productDataPath2 = productsFocalTempPath+"/"+entry;
                            
                            dir2 = opendir(productDataPath1.c_str());
                            
                            if (dir2 != NULL){
                                while ((dent2 = readdir(dir2))){
                                    entry2 = dent2 -> d_name;
                                    
                                    if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                        productDataPath3 = productDataPath1+"/"+entry2;
                                        productDataPath4 = productDataPath2+"/"+entry2;
                                        
                                        dir3 = opendir(productDataPath3.c_str());
                                        
                                        if (dir3 != NULL){
                                            while ((dent3 = readdir(dir3))){
                                                entry3 = dent3 -> d_name;
                                                
                                                if ((int)entry3.find("_"+imageNoIF+"-") != -1){
                                                    productDataPath5 = productDataPath3+"/"+entry3;
                                                    productDataPath6 = productDataPath4+"/"+entry3;
                                                    
                                                    if (stat(productDataPath5.c_str(), &sizeOfFile) == 0){
                                                        sizeForCopy = sizeOfFile.st_size;
                                                        
                                                        ifstream infile (productDataPath5.c_str(), ifstream::binary);
                                                        ofstream outfile (productDataPath6.c_str(), ofstream::binary);
                                                        
                                                        char *buffer = new char[sizeForCopy];
                                                        infile.read (buffer, sizeForCopy);
                                                        outfile.write (buffer, sizeForCopy);
                                                        delete [] buffer;
                                                        
                                                        outfile.close();
                                                        infile.close();
                                                        
                                                        processEnd = 1;
                                                    }
                                                }
                                            }
                                            
                                            closedir(dir3);
                                        }
                                    }
                                }
                                
                                closedir(dir2);
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                
                if (processEnd == 0){
                    string sourceImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+batchImageBodyName+"_Products"+"/"+"Source_Images";
                    
                    dir = opendir(sourceImagePath.c_str());
                    
                    if (dir != NULL){
                        string entry;
                        string entry2;
                        string entry3;
                        string productDataPath1;
                        string productDataPath3;
                        
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                productDataPath1 = sourceImagePath+"/"+entry;
                                
                                dir2 = opendir(productDataPath1.c_str());
                                
                                if (dir2 != NULL){
                                    while ((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                            productDataPath3 = productDataPath1+"/"+entry2;
                                            
                                            dir3 = opendir(productDataPath3.c_str());
                                            
                                            if (dir3 != NULL){
                                                while ((dent3 = readdir(dir3))){
                                                    entry3 = dent3 -> d_name;
                                                    
                                                    if ((int)entry3.find("BMP"+processingIFCountString2) != -1 || (int)entry3.find("TIF"+processingIFCountString2) != -1) processEnd = 3;
                                                }
                                                
                                                closedir(dir3);
                                            }
                                        }
                                        
                                        if (processEnd == 3){
                                            break;
                                        }
                                    }
                                    
                                    closedir(dir2);
                                }
                            }
                            
                            if (processEnd == 3){
                                break;
                            }
                        }
                        
                        closedir(dir);
                    }
                }
            }
            
            if (processEnd == 0 || processEnd == 2 || processEnd == 3){
                if (largestFileNoBatch < filePickUpCount || processEnd == 2 || processEnd == 3){
                    filePickUpCount--;
                    
                    if (consoleWarningCount+5 > consoleWarningLimit) [self warningUpDate];
                    
                    if (processEnd == 0){
                        arrayConsoleWarning [consoleWarningCount] = "[BI] Processing completed.", consoleWarningCount++;
                    }
                    else if (processEnd == 2){
                        arrayConsoleWarning [consoleWarningCount] = "[BI] Processing completed. IF Detected.", consoleWarningCount++;
                    }
                    else if (processEnd == 3){
                        arrayConsoleWarning [consoleWarningCount] = "[BI] Processing completed. IF Detected. Perform IF Merge. Then, Start IF Again.", consoleWarningCount++;
                    }
                    
                    for (int counter1 = 0; counter1 < 10; counter1++){
                        oin.open(instructionCSPath.c_str(), ios::out);
                        
                        if (oin.is_open()){
                            oin<<"Exit"<<endl;
                            oin.close();
                            break;
                        }
                    }
                    
                    oin.open(batchProcessImagePath.c_str(), ios::out);
                    oin<<batchImageBodyName<<endl;
                    oin<<batchImagePathNameHold<<endl;
                    oin<<batchImagePathInfo<<endl;
                    oin<<filePickUpCount<<endl;
                    oin<<largestFileNoBatch<<endl;
                    oin.close();
                    
                    autoStepCount = 4;
                    contrastSetFlag = 2;
                    consolePage = 0;
                    consoleDisplayCall = 1;
                    
                    [batchImageTimer invalidate];
                }
            }
            else{
                
                autoStepCount = -1;
                
                oin.open(batchProcessImagePath.c_str(), ios::out);
                oin<<batchImageBodyName<<endl;
                oin<<batchImagePathNameHold<<endl;
                oin<<batchImagePathInfo<<endl;
                oin<<filePickUpCount<<endl;
                oin<<largestFileNoBatch<<endl;
                oin.close();
            }
        }
    }
    
    if (autoStepCount == -1){
        autoStepCount = 2;
        
        for (int counter1 = 0; counter1 < 10; counter1++){
            oin.open(instructionCSPath.c_str(), ios::out);
            
            if (oin.is_open()){
                oin<<"Next"<<endl;
                oin.close();
                break;
            }
        }
        
        string copyPath1 = productsFilesInfoPath+"/"+"CT-FOVPosition";
        string copyPath2 = productsFocalTempPath+"/"+"CT-FOVPosition";
        
        struct stat sizeOfFile;
        
        long sizeForCopy = 0;
        
        if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile3 (copyPath1.c_str(), ifstream::binary);
            ofstream outfile3 (copyPath2.c_str(), ofstream::binary);
            
            char *buffer3 = new char[sizeForCopy];
            infile3.read (buffer3, sizeForCopy);
            outfile3.write (buffer3, sizeForCopy);
            delete [] buffer3;
            
            outfile3.close();
            infile3.close();
        }
        
        copyPath1 = productsFilesInfoPath+"/"+"CT-ContrastData";
        copyPath2 = productsFocalTempPath+"/"+"CT-ContrastData";
        
        if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile4 (copyPath1.c_str(), ifstream::binary);
            ofstream outfile4 (copyPath2.c_str(), ofstream::binary);
            
            char *buffer4 = new char[sizeForCopy];
            infile4.read (buffer4, sizeForCopy);
            outfile4.write (buffer4, sizeForCopy);
            delete [] buffer4;
            
            outfile4.close();
            infile4.close();
        }
        
        copyPath1 = productsFilesInfoPath+"/"+"CT-ContrastDataG";
        copyPath2 = productsFocalTempPath+"/"+"CT-ContrastDataG";
        
        if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile4 (copyPath1.c_str(), ifstream::binary);
            ofstream outfile4 (copyPath2.c_str(), ofstream::binary);
            
            char *buffer4 = new char[sizeForCopy];
            infile4.read (buffer4, sizeForCopy);
            outfile4.write (buffer4, sizeForCopy);
            delete [] buffer4;
            
            outfile4.close();
            infile4.close();
        }
        
        copyPath1 = productsFilesInfoPath+"/"+"CT-ContrastDataB";
        copyPath2 = productsFocalTempPath+"/"+"CT-ContrastDataB";
        
        if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile4 (copyPath1.c_str(), ifstream::binary);
            ofstream outfile4 (copyPath2.c_str(), ofstream::binary);
            
            char *buffer4 = new char[sizeForCopy];
            infile4.read (buffer4, sizeForCopy);
            outfile4.write (buffer4, sizeForCopy);
            delete [] buffer4;
            
            outfile4.close();
            infile4.close();
        }
        
        copyPath1 = productsFilesInfoPath+"/"+"CT-BasicSetting";
        copyPath2 = productsFocalTempPath+"/"+"CT-BasicSetting";
        
        if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile5 (copyPath1.c_str(), ifstream::binary);
            ofstream outfile5 (copyPath2.c_str(), ofstream::binary);
            
            char *buffer5 = new char[sizeForCopy];
            infile5.read (buffer5, sizeForCopy);
            outfile5.write (buffer5, sizeForCopy);
            delete [] buffer5;
            
            outfile5.close();
            infile5.close();
        }
        
        for (int counter1 = 0; counter1 < 16; counter1++) arrayForConsoleCheck2 [counter1] = 0;
    }
    else if (autoStepCount == 2){
        int instructionAPFlag = 0;
        
        string getString;
        string instructionAP;
        
        ifstream fin;
        fin.open(instructionAPPath.c_str(),ios::in);
        if (fin.is_open()){
            instructionAPFlag = 1;
            fin.close();
        }
        
        if (instructionAPFlag != 0){
            fin.open(instructionAPPath.c_str(),ios::in);
            
            getline(fin, getString), instructionAP = getString;
            
            if (instructionAP == "Done") autoStepCount = 3;
            
            fin.close();
        }
    }
    else if (autoStepCount == 3) autoStepCount = 100;
    else if (autoStepCount >= 100 && autoStepCount < 110) autoStepCount++;
    else if (autoStepCount == 110){
        string copyPath2 = productsFilesInfoPath+"/"+"CT-FOVPosition";
        string copyPath1 = productsFocalTempPath+"/"+"CT-FOVPosition";
        
        struct stat sizeOfFile;
        
        long sizeForCopy = 0;
        
        if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile3 (copyPath1.c_str(), ifstream::binary);
            ofstream outfile3 (copyPath2.c_str(), ofstream::binary);
            
            char *buffer3 = new char[sizeForCopy];
            infile3.read (buffer3, sizeForCopy);
            outfile3.write (buffer3, sizeForCopy);
            delete [] buffer3;
            
            outfile3.close();
            infile3.close();
        }
        
        copyPath2 = productsFilesInfoPath+"/"+"CT-ContrastData";
        copyPath1 = productsFocalTempPath+"/"+"CT-ContrastData";
        
        if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile4 (copyPath1.c_str(), ifstream::binary);
            ofstream outfile4 (copyPath2.c_str(), ofstream::binary);
            
            char *buffer4 = new char[sizeForCopy];
            infile4.read (buffer4, sizeForCopy);
            outfile4.write (buffer4, sizeForCopy);
            delete [] buffer4;
            
            outfile4.close();
            infile4.close();
        }
        
        copyPath2 = productsFilesInfoPath+"/"+"CT-ContrastDataG";
        copyPath1 = productsFocalTempPath+"/"+"CT-ContrastDataG";
        
        if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile4 (copyPath1.c_str(), ifstream::binary);
            ofstream outfile4 (copyPath2.c_str(), ofstream::binary);
            
            char *buffer4 = new char[sizeForCopy];
            infile4.read (buffer4, sizeForCopy);
            outfile4.write (buffer4, sizeForCopy);
            delete [] buffer4;
            
            outfile4.close();
            infile4.close();
        }
        
        copyPath2 = productsFilesInfoPath+"/"+"CT-ContrastDataB";
        copyPath1 = productsFocalTempPath+"/"+"CT-ContrastDataB";
        
        if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile4 (copyPath1.c_str(), ifstream::binary);
            ofstream outfile4 (copyPath2.c_str(), ofstream::binary);
            
            char *buffer4 = new char[sizeForCopy];
            infile4.read (buffer4, sizeForCopy);
            outfile4.write (buffer4, sizeForCopy);
            delete [] buffer4;
            
            outfile4.close();
            infile4.close();
        }
        
        copyPath2 = productsFilesInfoPath+"/"+"CT-BasicSetting";
        copyPath1 = productsFocalTempPath+"/"+"CT-BasicSetting";
        
        if (stat(copyPath1.c_str(), &sizeOfFile) != 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile5 (copyPath1.c_str(), ifstream::binary);
            ofstream outfile5 (copyPath2.c_str(), ofstream::binary);
            
            char *buffer5 = new char[sizeForCopy];
            infile5.read (buffer5, sizeForCopy);
            outfile5.write (buffer5, sizeForCopy);
            delete [] buffer5;
            
            outfile5.close();
            infile5.close();
        }
        
        int directoryRmv = 0;
        pathToDelete = productsStitchTempPath;
        pathToDelete2 = stitchedFolderPath;
        
        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
        [controllerSubProcesses fileRenameLayerTwo:directoryRmv];
        
        directoryRmv = 0;
        pathToDelete = productsFocalTempPath;
        
        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
        [controllerSubProcesses fileDeleteLayerThree:directoryRmv];
        
        autoTotalCount++;
        autoTotalCountDisplayCall = 1;
        
        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
        [controllerSubProcesses parameterSave];
        
        remove (instructionAPPath.c_str());
        
        if (autoTimerInvalidate == 1){
            autoTimerInvalidate = 0;
            autoStepCount = 4;
            focalImageFlag = 2;
            contrastSetFlag = 2;
            
            for (int counter1 = 0; counter1 < 10; counter1++){
                oin.open(instructionFIPath2.c_str(), ios::out);
                
                if (oin.is_open()){
                    oin<<"Exit"<<endl;
                    oin.close();
                    break;
                }
            }
            
            for (int counter1 = 0; counter1 < 10; counter1++){
                oin.open(instructionCSPath.c_str(), ios::out);
                
                if (oin.is_open()){
                    oin<<"Exit"<<endl;
                    oin.close();
                    break;
                }
            }
            
            [batchImageTimer invalidate];
        }
        else if (autoTimerInvalidate == 0) autoStepCount = 0;
    }
    else if (autoStepCount == 52){
        [self stepReset];
    }
    
    if (autoStepCount >= 2 && autoStepCount < 110){
        string entry;
        string productDataPath1;
        string timeString;
        
        int findFlag = 0;
        
        for (int counter1 = 0; counter1 < 16; counter1++){
            if (arrayNameList [counter1] != "nil"){
                productDataPath1 = productsStitchTempPath+"/"+arrayNameList [counter1]+"_Stitch";
                
                dir = opendir(productDataPath1.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find(".tif") != -1) timeString = entry.substr(0, entry.find(".tif"));
                            else if ((int)entry.find(".bmp") != -1) timeString = entry.substr(0, entry.find(".bmp"));
                            
                            if (arrayForConsoleCheck2 [counter1] == 0){
                                if (consoleContrastCount+5 > consoleContrastLimit) [self consoleContrastUpDate];
                                arrayConsoleContrast [consoleContrastCount] = timeString+"/ "+arrayNameList [counter1], consoleContrastCount++;
                                
                                arrayForConsoleCheck2 [counter1] = 1;
                                consolePage = 3;
                                consoleDisplayCall = 1;
                                findFlag = 1;
                                
                                break;
                            }
                        }
                    }
                    
                    closedir(dir);
                    
                    if (findFlag == 1){
                        break;
                    }
                }
            }
        }
    }
}

-(void)stepReset{
    int directoryRmv = 0;
    pathToDelete = productsStitchTempPath;
    
    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
    [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
    
    autoTimerInvalidate = 0;
    autoStepCount = 4;
    contrastSetFlag = 2;
    
    [batchImageTimer invalidate];
    
    autoStepCount = 0;
}

-(void) warningUpDate{
    string *arrayUpDate = new string [consoleWarningCount+10];
    
    for (int counter1 = 0; counter1 < consoleWarningCount; counter1++) arrayUpDate [counter1] = arrayConsoleWarning [counter1];
    
    delete [] arrayConsoleWarning;
    arrayConsoleWarning = new string [consoleWarningLimit+500];
    consoleWarningLimit = consoleWarningLimit+500;
    
    for (int counter1 = 0; counter1 < consoleWarningCount; counter1++) arrayConsoleWarning [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)consoleContrastUpDate{
    string *arrayUpDate = new string [consoleContrastCount+10];
    
    for (int counter1 = 0; counter1 < consoleContrastCount; counter1++) arrayUpDate [counter1] = arrayConsoleContrast [counter1];
    
    delete [] arrayConsoleContrast;
    arrayConsoleContrast = new string [consoleContrastLimit+500];
    consoleContrastLimit = consoleContrastLimit+500;
    
    for (int counter1 = 0; counter1 < consoleContrastCount; counter1++) arrayConsoleContrast [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)fileDeleteUpDate2{
    string *arrayUpDate = new string [fileDeleteCount2+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++) arrayUpDate [counter1] = arrayFileDelete2 [counter1];
    
    delete [] arrayFileDelete2;
    arrayFileDelete2 = new string [fileDeleteLimit2+500];
    fileDeleteLimit2 = fileDeleteLimit2+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++) arrayFileDelete2 [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToBatchImage object:nil];
    if (batchImageTimer) [batchImageTimer invalidate];
}

@end
