//
//  AutoProcess.h
//  Imaging_Controller
//
//  Created by Masahiko Sato on 3/16/2014.
//  Copyright Masahiko Sato 2014 All rights reserved.
//
//

#ifndef AUTOPROCESS_H
#define AUTOPROCESS_H
#import "Controller.h"
#endif

@interface AutoProcess : NSObject {
    int smallestFolderNumber; //Smallest folder number
    
    NSTimer *autoProcessTimer;
    
    id controllerSubProcesses;
}

-(id)init;
-(void)dealloc;
-(void)autoProcessMain;
-(void)consoleFocalImageUpDate;
-(void)consoleContrastUpDate;
-(void)warningUpDate;
-(void)stepReset;
-(void)processControl;
-(void)fileDeleteUpDate;
-(void)fileDeleteUpDate2;

@end
