//
//  CommOutlineDraw.h
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2/15/2014.
//  Copyright Masahiko Sato 2014 All rights reserved.
//

#ifndef COMMOUTLUNEDRAW_H
#define COMMOUTLINEDRAW_H
#import "Controller.h"
#endif

@interface CommOutlineDraw : NSObject {
    NSTimer *commOutlineDrawTimer;
}

-(id)init;
-(void)dealloc;
-(void)outlineDraw;
-(void)processControl;

@end
