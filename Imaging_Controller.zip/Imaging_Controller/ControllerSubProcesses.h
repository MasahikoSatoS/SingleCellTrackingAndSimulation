//
//  ControllerSubProcesses.h
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2021-08-04.
//  Copyright Masahiko Sato 2021 All rights reserved.
//

#ifndef CONTROLLERSUBPROCESSES_H
#define CONTROLLERSUBPROCESSES_H
#import "Controller.h"
#endif

@interface ControllerSubProcesses : NSObject{
}

-(int)nameCheck;
-(void)parameterSave;
-(void)fileDeleteLayerOne:(int)directoryRemove;
-(void)fileDeleteLayerTwo:(int)directoryRemove;
-(int)fileDeleteLayerTwoStitch:(int)modeA :(int)modeB;
-(void)fileRenameLayerTwo:(int)directoryRemove;
-(void)fileDeleteLayerThree:(int)directoryRemove;
-(void)fileRenameLayerThreeBmp:(int)directoryRemove;
-(void)fileDeleteLayerFour:(int)directoryRemove;
-(void)fileDeleteUpDate;
-(void)fileDeleteUpDate2;

@end
