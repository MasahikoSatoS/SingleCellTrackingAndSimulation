//
//  BatchImageProcess.h
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2014-05-21.
//  Copyright Masahiko Sato 2014 All rights reserved.
//
//

#ifndef BATCHIMAGEPROCESS_H
#define BATCHIMAGEPROCESS_H
#import "Controller.h"
#endif

@interface BatchImageProcess : NSObject {
    NSTimer *batchImageTimer;
    
    id controllerSubProcesses;
}

-(id)init;
-(void)dealloc;
-(void)batchImageMain;
-(void)consoleContrastUpDate;
-(void)warningUpDate;
-(void)stepReset;
-(void)processControl;
-(void)fileDeleteUpDate;
-(void)fileDeleteUpDate2;

@end
