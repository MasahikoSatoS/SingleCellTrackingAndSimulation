//
//  ASCIIconversion.h
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2014-05-29.
//  Copyright Masahiko Sato 2014 All rights reserved.
//
//

#ifndef ASCIICONVERSION_H
#define ASCIICONVERSION_H
#import "CommFile.h"
#endif

@interface ASCIIconversion : NSObject {
}

-(void)ascIIConversion2 :(int)ascIIint;
-(int)ascIICode;

@end
