//
//  Controller.h
//  Imaging_Controller
//
//  Created by Masahiko Sato on 09/05/10.
//  Copyright Masahiko Sato 2010 All rights reserved.
//

#ifndef CONTROLLER_H
#define CONTROLLER_H
#import <Cocoa/Cocoa.h>
#import "Controller2.h"
#import "ControllerSubProcesses.h"
#import "AutoProcess.h"
#import "ActiveProcessMonitor.h"
#import "NetSettingController.h"
#import "BatchBackUpController.h"
#import "BatchBackUpProcess.h"
#import "BatchImageController.h"
#import "BatchImageProcess.h"
#import "CommXYMap.h"
#import "CommOutlineDraw.h"
#import "CommContrast.h"
#import "CommFile.h"
#import "CommName.h"
#import "CommFocal.h"
#import "DataSaveLoad.h"
#import "SummaryPrint.h"
#import "SummaryWindow.h"
#import "SingleTiffSave.h"
#import "TiffFileRead.h"
#include <iostream>
#include <string>
#include <cstdio>
#include <dirent.h>
#include <sys/stat.h>
#include <fstream>
#include <sstream>
#endif

using namespace std;

extern NSString *notificationToCommXYMap;
extern NSString *notificationToCommFile;
extern NSString *notificationToCommContrast;
extern NSString *notificationToCommOutlineDraw;
extern NSString *notificationToCommName;
extern NSString *notificationToCommFocal;
extern NSString *notificationToAutoProcess;
extern NSString *notificationToBatchBackUp;
extern NSString *notificationToBatchImage;
extern NSString *notificationToActiveProcess;
extern NSString *notificationToSaveLoad;
extern NSString *notificationToSummary;
extern NSString *notificationToSummaryWindow;
extern NSString *notificationToNetCheckController;

//----Basic Info----
extern string pathNameString; //Path name
extern string bodyNameHold; //Analysis body name hold
extern string computerNameHold; //Computer name hold
extern string userIDHold; //User ID name hold
extern string totalFOVNoHold; //Total Fov number hold, it will be up dated if Map program set different number

//----Basic Operation----
extern string nameCheckString; //Use for the Name Check
extern string initialRunStatus; //Initial run status hold
extern string mapSetPerform; //Map set status hold
extern int fovNoDisplayFlag; //Fov no Display Set
extern int imageTimePointAccumulationCounter; //Hold latest time point, T point created by Initial Setting is "1" (folder: body name-10001)
extern string *arrayFileDelete; //Hold names of files that will be deleted
extern int fileDeleteCount;
extern int fileDeleteLimit;
extern string *arrayFileDelete2; //Hold names of files that will be deleted, second array
extern int fileDeleteCount2;
extern int fileDeleteLimit2;
extern int progressTiming; //Hold Progress indicator timing
extern string bodyNameSendMap; //Body name send to XY map
extern string autoStatusXYSendMap; //Auto run status send to XY map
extern string batchStatusXYSendMap; //Batch status send to XY map
extern string initialStatusXYSendMap; //Initial status send to XY map
extern string pathToDelete; //Hold directory path for file delete;
extern string pathToDelete2; //Hold second directory path for file delete;
extern int launchCheck; //Set 1 when a thread is launched, skip to check active processes till launching is completed.
extern int monitorTimerControlOutline; //Count skip timing
extern int monitorTimerControlCellTracking; //Count skip timing
extern int monitorTimerControlDataAnalysis; //Count skip timing
extern int monitorTimerControlBackUp; //Count skip timing
extern int monitorTimerControlXYMap; //Count skip timing
extern int monitorTimerControlFileUpload; //Count skip timing
extern int monitorTimerControlNameSet; //Count skip timing
extern int monitorTimerControlFocal; //Count skip timing
extern int monitorTimerControlContrast; //Count skip timing
extern int monitorTimerControlAutoFileUpload; //Count skip timing
extern int monitorTimerControlAutoFocalContrast; //Count skip timing
extern int monitorTimerControlBatchBack; //Count skip timing
extern int monitorTimerControlBatchImage; //Count skip timing
extern int monitorTimerControlAutoBackFocalHold; //Count skip timing
extern int monitorTimerControlAutoBackContrastHold; //Count skip timing
extern int monitorTimerControlBackImageContrastHold; //Count skip timing
extern int monitorTimerControlLastPurge; //Count skip timing

//----Auto/Batch-Back/Batch Image----
extern string autoProcessCommit; //Set when Auto run is set
extern string batchBackupOperationCommit; //Set when Batch backup is set
extern string batchImageOperationCommit; //Set when Batch Image is set
extern string smallestFolderName; //Smallest folder name hold, for auto/batch backup
extern string smallestFolderSourceName; //Smallest folder name hold (original), for batch backup
extern int autoBatchMode; //Mode status Hold 1. Auto, 2. Batch (back), 3. Batch (image) status
extern int autoRunOnOff; //Auto run status
extern int batchBackupOnOff; //Batch beck up folder process status
extern int batchImageOnOff; //Batch Image folder process status
extern int processLoopMonitor; //Monitor progress of Auto or batch process
extern int autoTimerInvalidate; //Auto timer invalidate flag
extern int autoStepCount; //Monitor auto/batch process/Check error
extern int autoTotalCount; //Time point count of auto/batch processing
extern int autoTotalCountDisplayCall; //Time point count of auto/batch processing, display call
extern int *arrayForConsoleCheck; //Console display for data scan, auto/batch
extern int *arrayForConsoleCheck2; //Console display for data scan, auto/batch
extern int backupBatchWait1; //Wait for file copy for batch backup
extern int backupBatchWait2; //Wait for file copy for batch backup

//----Batch (back-up)----
extern string batchBackUpNameHold; //Batch process name (eq to body name), process from backUp folders
extern string *arrayBatchPathName; //Array for batch path list
extern int batchPathNameCount;
extern string batchBodyName; //Hold batch body name
extern string *batchProcessInfo; //Hold batch directory, folder name and status
extern int batchProcessInfoCount;
extern int batchProcessInfoLimit;
extern string backupBatchWaitPathName; //Batch backup current path name hold

//----Batch (Image)----
extern string batchImagePathNameHold; //Batch process name, process from Image files
extern string batchImageBodyName; //Hold batch body name for Image
extern string batchImagePathInfo; //Hold Path name for Batch Image hold
extern string *arrayImageFolderList; //Hold folder name in the Image folder (05)
extern int imageFolderListCount;
extern int filePickUpCount; //For Image batch, count file position
extern int batchImageIFCount; //Count for image no of IF (batch image)
extern int largestFileNoBatch; //For batch image

//----Fluorescent info----
extern string fluorescent1; //Fluorescent name info
extern string fluorescent2; //Fluorescent name info
extern string fluorescent3; //Fluorescent name info
extern string fluorescent4; //Fluorescent name info
extern string fluorescent5; //Fluorescent name info
extern string fluorescent6; //Fluorescent name info
extern string fluorescentNew1; //Fluorescent new name info
extern string fluorescentNew2; //Fluorescent new name info
extern string fluorescentNew3; //Fluorescent new name info
extern string fluorescentNew4; //Fluorescent new name info
extern string fluorescentNew5; //Fluorescent new name info
extern string fluorescentNew6; //Fluorescent new name info
extern int fluorescentColor1; //Fluorecent color info
extern int fluorescentColor2; //Fluorecent color info
extern int fluorescentColor3; //Fluorecent color info
extern int fluorescentColor4; //Fluorecent color info
extern int fluorescentColor5; //Fluorecent color info
extern int fluorescentColor6; //Fluorecent color info
extern int fluorescentCount; //Active fluorescent channel no.
extern int dicFluorescentMode; //Hold DIC/FLUO mode

//----Summary----
extern string *arrayNameList; //Array for the Treatment Name list (1-16, if nothing is set "nil")
extern int *arrayFOVNumberList; //Array for the No of FOV list, (1-16, if nothing is set "nil"
extern string *arraySummaryList; //Array for the Summary List (for Table display)
extern int summaryListCount;
extern int summarySetCall; //Call Summary Set

//----Console----
extern string *arrayConsoleWarning; //Array for Warning (for Console Display)
extern int consoleWarningCount;
extern int consoleWarningLimit;
extern string *arrayConsoleTreatName; //Array for Console TreatName (for Console Display)
extern int consoleTreatNameCount;
extern int consoleTreatNameLimit;
extern string *arrayConsoleFocalImage; //Array for Console Focal image (for Console Display)
extern int consoleFocalImageCount;
extern int consoleFocalImageLimit;
extern string *arrayConsoleContrast; //Array for Console Contrast (for Console Display)
extern int consoleContrastCount;
extern int consoleContrastLimit;
extern int consolePage; //Console display Page number
extern int consoleDisplayCall; //Control console display

//----Table control----
extern int tableViewPage; //Table view page
extern int tableViewCall; //Call Table view
extern int tableCallCount; //Table "key board type shift" block
extern int tableCurrentRowHold; //Table processing control
extern int rowIndexHold; //Table processing control
extern int rowNumberHold; //Table processing control

//----Backup----
extern string *arrayBackUpDisplayList; //Array for backup list foe display and backUp results (for summary print)
extern int backUpDisplayListCount;
extern string backUpNameHold; //Back up folder name

//----Launch status----
extern int runStatusXYMap; //XY map run status
extern int runStatusFileUpLoad; //FileUpload run status
extern int runStatusTreatmentNameSet; //Treatment name run status
extern int runStatusFocalImage; //Focal image run status
extern int runStatusContrast; //Contrast run status
extern int runStatusOutlineDraw; //Outline draw run status
extern int runStatusCellTracking; //Cell tracking run status
extern int runStatusDataAnalysis; //Analysis run status
extern int runStatusBackUp; //Backup run status
extern int runStatusMovie; //Movie run status
extern int runStatusMovie2; //Movie2 run status
extern int runStatusMovie3; //Movie3 run status
extern int runStatusMovie4; //Movie4 run status
extern int runStatusMovie5; //Movie5 run status
extern int runStatusMovie6; //Movie6 run status
extern int runStatusMovieQuant; //Movie Quant run status
extern int runStatusWatson; //Watson run status
extern int runStatusFileConverter; //File converter run status
extern int runStatusCell3D; //Cell 3D run status

//----Sub process control----
extern int fileUpLoadFlag; //FileUpload status hold
extern int nameAssignFlag; //Name assign status hold
extern int focalImageFlag; //Focal Image status hold
extern int contrastSetFlag; //Contrast Set status hold
extern int outlineDrawDisplayFlag; //Outline draw Display status hold
extern int cellTrackingDisplayFlag; //Cell Tracking Display status hold
extern int analysisDisplayFlag; //Data analysis Display status hold
extern int backUpDisplayFlag; //Backup flag
extern int mapDisplayFlag; //MAP Display status hold
extern int cellMovieDisplayFlag; //Movie status hold
extern int cellMovieDisplayFlag2; //Movie2 status hold
extern int cellMovieDisplayFlag3; //Movie3 status hold
extern int cellMovieDisplayFlag4; //Movie4 status hold
extern int cellMovieDisplayFlag5; //Movie5 status hold
extern int cellMovieDisplayFlag6; //Movie6 status hold
extern int cellMovieQuantFlag; //Movie Quant status hold
extern int watsonFlag; //Watson status hold
extern int fileConverterFlag; //File converter status hold
extern int cell3DFlag; //Cell 3D status hold

//----File up-load----
extern string folderNameForNamed; //Folder name, file transfer to name ass.
extern string roundTimeString; //Latest time for folder number hold
extern string *arrayFileName; //Upload file name array
extern string ascIIstring; //AscII
extern int fileTransferProgress; //File transfer progress count
extern string *arraySelectFiles; //Names of files to be uploaded
extern int selectFileCount;
extern int selectFileLimit;

//----File split----
extern string fileSavePathHold; //Path for Tiff file save
extern int **arrayImageFileSave; //Image array for tif save
extern uint8_t *fileReadArray; //array holding image data
extern int fileSplitOption; //0; Split if H:W = 1:2, 1: Not split

//----Save load operation----
extern string *arraySaveLoadList; //SaveLoad List hold
extern int saveLoadListCount;
extern int saveLoadListLimit;
extern int summaryOperation; //For summary window
extern int saveLoadOperation; //For saveLoad window
extern int summaryType; //Summary type hold
extern string saveFolderName; //Hold save folder name
extern string sizeCheckPath; //Size check path
extern string directoryPath; //Directory path
extern string directoryPath2; //Directory path2
extern int saveLoadProgress; //Save progress status
extern string separatePath; //Separate path
extern string bodyNameSeparate; //Body name for separate

//----Objective type----
extern string objectiveType; //ObjectiveType

//----Last purge----
extern int lastPurgeFlag; //Last Purge progress
extern int purgeCount; //Last purge count

//----IF mode----
extern int processingIFCount; //Count IF processing
extern int processingIFStatus; //IF Status
extern int newIFFoundFlag; //Set when new IF is found

//----Net check----
extern int netCheckWindowOperation; //Net check window
extern string netAddressHold; //Net address
extern string netUsernameHold; //Net user name
extern string netPasswordHold; //net password

//----Path Info----
extern string dataImportFolderPath; //Data import path
extern string dataFilesPath; //Data file path
extern string namedFilesPath; //Named file path
extern string productsFilesPath; //Products file path
extern string cellTrackingImageFolderPath; //Cell tracking image path
extern string cellTrackingDataPath; //Cell tracking data path
extern string cellTrackingLibraryPath; //Cell tracking library path
extern string cellTrackingSystemDataPath; //Cell tracking system path
extern string cellTrackingAnalysisPath; //Cell tracking analysis path
extern string analysisDataPath; //Analysis data path
extern string nameListDataPath; //Named list path
extern string backUpDirectoryPath; //Backup directory path
extern string batchProcessImagePath; //Batch process image path
extern string consoleWarningPath; //Console warning path
extern string summaryDataPath; //Summary path
extern string launchProgramPath; //Launch program path
extern string productsFilesImagePath; //Products file image path
extern string productsFilesInfoPath; //Products file info path
extern string productsFocalTempPath; //Products focal temp path
extern string backUpDataPath; //Back up data path
extern string stitchedFolderPath; //Stitched folder path
extern string productsStitchTempPath; //Products stitch temp path
extern string warningFLPath; //Warning path
extern string instructionFIPath; //Instruction path
extern string instructionAPPath; //Instruction path
extern string instructionCSPath; //Instruction path
extern string instructionFLPath; //Instruction path
extern string instructionMapPath; //Instruction path
extern string instructionMapPath2; //Instruction path
extern string instructionNamePath; //Instruction path
extern string instructionFIPath2; //Instruction path
extern string loadingCompletePath; //Loading completion path
extern string loadingCompleteFLPath; //Loading completion path
extern string loadingCompleteCSPath; //Loading completion path
extern string batchProcessBackUpPath; //Batch process path
extern string assignNamePath; //Name assign path
extern string batchProcessFolderPath; //Batch process folder path
extern string backupResultsPath; //Backup results path
extern string dataSaveFolderPath; //Data save folder path
extern string directoryPathForPC; //Directory PC path
extern string backUpResultsPath; //Backup results path

@interface Controller : NSObject <NSTableViewDataSource> {
    string extensionInfoDisplay; //Display extended info, detailed name of directory etc
    int totalFOVDisplayCall; //Call Total FOV display
    int extensionInfoDisplayCall; //Display Call for extended info
    
    string *arrayForBackUpNames; //Back up file name hold
    int forbackUpNamesCount;
    int forBackUpNamesStatus;
    int forBackUpNamesCountIncrement;
    
    int focalContrastRestartFlag; //Focal contrast auto restart flag
    int focalContrastRetryCount; //Focal contrast auto restart count
    int fileUploadStartCount; //File upload auto start count
    
    string *arrayBackUpDriveName; //Array for backup drive list
    int backUpDriveNameCount;
    
    int lastPurgeSetFlag; //On when last purge is set, will not release until refresh
    
    int netCheckStatus; //Check net status
    int netConnectionStatus; //Net connection status
    int connectionCheckCount; //Net check count
    string infoDirectoryPC; //Net info
    string dataDirName; //Data directory name
    string infoDirName; //Info directory name
    
    int monitorTimerControlOutline; //Count skip timing
    int monitorTimerControlCellTracking; //Count skip timing
    int monitorTimerControlDataAnalysis; //Count skip timing
    int monitorTimerControlBackUp; //Count skip timing
    int monitorTimerControlXYMap; //Count skip timing
    int monitorTimerControlFileUpload; //Count skip timing
    int monitorTimerControlNameSet; //Count skip timing
    int monitorTimerControlFocal; //Count skip timing
    int monitorTimerControlContrast; //Count skip timing
    int monitorTimerControlAutoFileUpload; //Count skip timing
    int monitorTimerControlAutoFocalContrast; //Count skip timing
    int monitorTimerControlBatchBack; //Count skip timing
    int monitorTimerControlBatchImage; //Count skip timing
    int monitorTimerControlAutoBackFocalHold; //Count skip timing
    int monitorTimerControlAutoBackContrastHold; //Count skip timing
    int monitorTimerControlBackImageContrastHold; //Count skip timing
    int monitorTimerControlLastPurge; //Count skip timing
    
    IBOutlet NSWindow *controller;
    IBOutlet NSTableView *tableViewList;
    IBOutlet NSTextView *textViewcontroller;
    
    NSTimer *controllerTimer;
    NSString *processInfo;
    
    //----Basic information----
    IBOutlet NSTextField *analysisName;
    IBOutlet NSTextField *computerName;
    IBOutlet NSTextField *totalFOV;
    IBOutlet NSTextField *userID;
    IBOutlet NSTextField *processModeDisplay;
    IBOutlet NSTextField *currentTimePoint;
    IBOutlet NSTextField *runStatusDisplay;
    
    //----Setting information----
    IBOutlet NSTextField *refreshStatus;
    IBOutlet NSTextField *mapStatus;
    IBOutlet NSTextField *backUpStatus;
    IBOutlet NSTextField *backUpName;
    IBOutlet NSTextField *initialRun;
    IBOutlet NSTextField *initialRunOn;
    
    //----Auto process----
    IBOutlet NSTextField *autoText;
    IBOutlet NSTextField *autoStatus;
    
    //----Operation status----
    IBOutlet NSTextField *fileUpLoadStatus;
    IBOutlet NSTextField *treatNameSetStatus;
    IBOutlet NSTextField *focalImageStatus;
    IBOutlet NSTextField *contrastSetStatus;
    
    //----Operation text----
    IBOutlet NSTextField *fileUpLoadStatusOn;
    IBOutlet NSTextField *focalImageStatusOn;
    IBOutlet NSTextField *contrastSetStatusOn;
    
    //----Association process status----
    IBOutlet NSTextField *outlineDrawStatus;
    IBOutlet NSTextField *cellTrackingStatus;
    IBOutlet NSTextField *dataAnalysisStatus;
    IBOutlet NSTextField *backUpProgramStatus;
    
    //----Batch backup process----
    IBOutlet NSTextField *batchText1;
    IBOutlet NSTextField *batchSetStatus1;
    IBOutlet NSTextField *batchStartStatus1;
    IBOutlet NSTextField *batchAnalysisName1;
    IBOutlet NSTextField *batchSaveName1;
    IBOutlet NSTextField *batchRedoNo1;
    
    //----Batch Image process----
    IBOutlet NSTextField *batchText2;
    IBOutlet NSTextField *batchSetStatus2;
    IBOutlet NSTextField *batchStartStatus2;
    IBOutlet NSTextField *batchAnalysisName2;
    IBOutlet NSTextField *batchSaveName2;
    IBOutlet NSTextField *batchRedoNo2;
    
    //----Console and Table----
    IBOutlet NSTextField *consoleName;
    IBOutlet NSTextField *tableName;
    
    //----Others----
    IBOutlet NSTextField *inputDataSet;
    IBOutlet NSTextField *extendedInfo;
    IBOutlet NSTextField *objectiveSet;
    IBOutlet NSTextField *lastPurgeDisplay;
    IBOutlet NSTextField *netAutoCheckDisplay;
    
    IBOutlet NSProgressIndicator *backSave;
    
    id controllerSubProcesses;
}

/*
 //[NSApp setActivationPolicy: NSApplicationActivationPolicyProhibited];
 //AppNap Inactivate: Command line > defaults write NSGlobalDomain NSAppSleepDisabled -bool YES
 */

-(id)init;
-(void)dealloc;

-(void)processControl;
-(void)consoleDisplay;
-(void)summarySet;
-(void)refreshMain:(int)callType;
-(void)settingRedo;

-(void)fileDeleteUpDate;
-(void)fileDeleteUpDate2;
-(void)warningUpDate;
-(void)batchInfoUpDate;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

-(IBAction)initialRunSet:(id)sender;
-(IBAction)initialSetCancel:(id)sender;
-(IBAction)refresh:(id)sender;
-(IBAction)processTerminate:(id)sender;
-(IBAction)redoFocalSet:(id)sender;
-(IBAction)lastPurgeStart:(id)sender;
-(IBAction)processIFStart:(id)sender;
-(IBAction)processIFMerge:(id)sender;
-(IBAction)backUpSet:(id)sender;
-(IBAction)backUpNameSet:(id)sender;
-(IBAction)autoProcessStart:(id)sender;
-(IBAction)autoProcessRedo:(id)sender;
-(IBAction)toolConsoleSwitch:(id)sender;
-(IBAction)toolTableSwitch:(id)sender;
-(IBAction)toolConsoleClear:(id)sender;
-(IBAction)toolListDelete:(id)sender;
-(IBAction)toolModeSelect:(id)sender;
-(IBAction)toolSaveLoad:(id)sender;
-(IBAction)printSummary:(id)sender;
-(IBAction)directoryData:(id)sender;
-(IBAction)directoryInfo:(id)sender;
-(IBAction)userPassSet:(id)sender;
-(IBAction)netAutoCheckSet:(id)sender;

@end
