//
//  ActiveProcessMonitor.h
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2014-05-14.
//  Copyright Masahiko Sato 2014 All rights reserved.
//
//

#ifndef ACTIVEPROCESSMONITOR_H
#define ACTIVEPROCESSMONITOR_H
#import "Controller.h"
#endif

@interface ActiveProcessMonitor : NSObject {
    NSTimer *activeProcessTimer;
}

-(id)init;
-(void)dealloc;
-(void)processControl;

@end
