//
//  ControllerSubProcesses.m
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2021-08-04.
//  Copyright Masahiko Sato 2021 All rights reserved.
//

#import "ControllerSubProcesses.h"

@implementation ControllerSubProcesses

-(int)nameCheck{
    int errorFlag = 0;
    string newAnalysisID = nameCheckString;
    
    if ((int)newAnalysisID.find(" ") >= 0) errorFlag = 2;
    if ((int)newAnalysisID.find(",") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(".") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("/") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(",") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(":") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("<") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(">") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("'") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("[") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("]") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("=") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("+") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("{") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("}") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(")") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("(") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("*") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("&") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("^") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("%") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("$") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("#") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("@") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("!") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("`") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("~") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("|") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("-") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("_") >= 0) errorFlag = 1;
    
    return errorFlag;
}

-(void)parameterSave{
    ofstream oin;
    oin.open(analysisDataPath.c_str(), ios::out);
    oin<<bodyNameHold<<endl;
    oin<<computerNameHold<<endl;
    oin<<totalFOVNoHold<<endl;
    oin<<userIDHold<<endl;
    oin<<initialRunStatus<<endl;
    oin<<autoProcessCommit<<endl;
    oin<<batchBackupOperationCommit<<endl;
    oin<<batchImageOperationCommit<<endl;
    oin<<autoBatchMode<<endl;
    oin<<mapSetPerform<<endl;
    oin<<imageTimePointAccumulationCounter<<endl;
    oin<<objectiveType<<endl;
    oin<<processingIFCount<<endl;
    oin<<processingIFStatus<<endl;
    oin<<newIFFoundFlag<<endl;
    oin<<batchImageIFCount<<endl;
    oin<<fileSplitOption<<endl;
    oin.close();
}

-(void)fileDeleteLayerOne:(int)directoryRemove{
    //directoryRemove == 0; delete files except "." etc
    //directoryRemove == 1; delete files except "." etc, and delete folder
    //directoryRemove == 2; delete files and delete folder
    
    DIR *dir;
    struct dirent *dent;
    
    string entry;
    
    dir = opendir(pathToDelete.c_str());
    fileDeleteCount = 0;
    
    if (dir != NULL){
        while ((dent = readdir(dir))){
            entry = dent -> d_name;
            
            if (directoryRemove == 0 || directoryRemove == 1){
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                    arrayFileDelete [fileDeleteCount] = pathToDelete+"/"+entry, fileDeleteCount++;
                }
            }
            else if (directoryRemove == 2){
                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                arrayFileDelete [fileDeleteCount] = pathToDelete+"/"+entry, fileDeleteCount++;
            }
        }
        
        closedir(dir);
        
        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
            remove (arrayFileDelete [counter1].c_str());
            
            if (directoryRemove == 1 || directoryRemove == 2) rmdir (arrayFileDelete [counter1].c_str());
        }
    }
}

-(void)fileDeleteLayerTwo:(int)directoryRemove{
    //directoryRemove == 0; delete files
    //directoryRemove == 1; delete files and delete folder
    
    DIR *dir;
    struct dirent *dent;
    DIR *dir2;
    struct dirent *dent2;
    
    string entry;
    string entry2;
    string filePath;
    
    dir = opendir(pathToDelete.c_str());
    fileDeleteCount = 0;
    
    if (dir != NULL){
        while ((dent = readdir(dir))){
            entry = dent -> d_name;
            filePath = pathToDelete+"/"+entry;
            
            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                dir2 = opendir(filePath.c_str());
                
                if (dir2 != NULL){
                    while ((dent2 = readdir(dir2))){
                        entry2 = dent2 -> d_name;
                        
                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                        arrayFileDelete [fileDeleteCount] = filePath+"/"+entry2, fileDeleteCount++;
                    }
                    
                    closedir(dir2);
                }
            }
        }
        
        closedir(dir);
        
        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
            remove (arrayFileDelete [counter1].c_str());
            
            if (directoryRemove == 1) rmdir (arrayFileDelete [counter1].c_str());
        }
    }
}

-(int)fileDeleteLayerTwoStitch:(int)modeA :(int)modeB{
    DIR *dir;
    struct dirent *dent;
    DIR *dir2;
    struct dirent *dent2;
    
    string entry;
    string entry2;
    string stringExtract;
    string filePath;
    string fileExtension;
    
    int lastRoundNumber = 0;
    
    dir = opendir(pathToDelete.c_str());
    fileDeleteCount = 0;
    
    if (dir != NULL){
        while ((dent = readdir(dir))){
            entry = dent -> d_name;
            
            if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("_Stitch") != -1){
                filePath = pathToDelete+"/"+entry;
                
                dir2 = opendir(filePath.c_str());
                
                if (dir2 != NULL){
                    while ((dent2 = readdir(dir2))){
                        entry2 = dent2 -> d_name;
                        
                        if (modeB == 0){
                            if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && ((int)entry2.find("BMP") != -1 || (int)entry2.find("TIF") != -1)){
                                if ((int)entry2.find("BMP") != -1) stringExtract = entry2.substr(entry2.find("BMP")+3);
                                else if ((int)entry2.find("TIF") != -1) stringExtract = entry2.substr(entry2.find("TIF")+3);
                                
                                if (processingIFCount <= atoi(stringExtract.c_str())){
                                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                    arrayFileDelete [fileDeleteCount] = filePath+"/"+entry2, fileDeleteCount++;
                                }
                            }
                        }
                        else if (modeB == 1){
                            if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && ((int)entry2.find("BMP") != -1 || (int)entry2.find("TIF") != -1)){
                                if ((int)entry2.find("BMP") != -1) stringExtract = entry2.substr(entry2.find("BMP")+3);
                                else if ((int)entry2.find("TIF") != -1) stringExtract = entry2.substr(entry2.find("TIF")+3);
                                
                                if (processingIFCount <= atoi(stringExtract.c_str())) lastRoundNumber = 1;
                            }
                        }
                        else if (modeB == 2){
                            if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && (int)entry2.find("STimage") != -1){
                                stringExtract = entry2.substr(8, 4);
                                
                                if (lastRoundNumber < atoi(stringExtract.c_str())) lastRoundNumber = atoi(stringExtract.c_str());
                            }
                        }
                        else if (modeB == 3){
                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                            arrayFileDelete [fileDeleteCount] = filePath+"/"+entry2, fileDeleteCount++;
                        }
                    }
                }
                
                closedir(dir2);
            }
        }
    }
    
    closedir(dir);
    
    if (modeB == 0 || modeB == 3){
        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
            remove (arrayFileDelete [counter1].c_str());
        }
    }
    
    return lastRoundNumber;
}

-(void)fileRenameLayerTwo:(int)directoryRemove{
    //pathToDelete: Source
    //pathToDelete2: destination
    
    DIR *dir;
    struct dirent *dent;
    DIR *dir2;
    struct dirent *dent2;
    
    string entry;
    string entry2;
    string filePath;
    string filePath2;
    
    if (directoryRemove == 0){
        dir = opendir(pathToDelete.c_str());
        fileDeleteCount = 0;
        fileDeleteCount2 = 0;
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    filePath = pathToDelete2+"/"+entry;
                    filePath2 = pathToDelete+"/"+entry;
                    
                    dir2 = opendir(filePath2.c_str());
                    
                    if (dir2 != NULL){
                        while ((dent2 = readdir(dir2))){
                            entry2 = dent2 -> d_name;
                            
                            if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                arrayFileDelete [fileDeleteCount] = filePath+"/"+entry2, fileDeleteCount++;
                                
                                if (fileDeleteCount2+5 > fileDeleteLimit2) [self fileDeleteUpDate2];
                                arrayFileDelete2 [fileDeleteCount2] = filePath2+"/"+entry2, fileDeleteCount2++;
                            }
                        }
                        
                        closedir(dir2);
                    }
                }
            }
            
            closedir(dir);
            
            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                rename (arrayFileDelete2 [counter1].c_str(), arrayFileDelete [counter1].c_str());
            }
        }
    }
    else{
        
        dir = opendir(pathToDelete.c_str());
        fileDeleteCount = 0;
        fileDeleteCount2 = 0;
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                    arrayFileDelete [fileDeleteCount] = pathToDelete2+"/"+entry, fileDeleteCount++;
                    
                    if (fileDeleteCount2+5 > fileDeleteLimit2) [self fileDeleteUpDate2];
                    arrayFileDelete2 [fileDeleteCount2] = pathToDelete+"/"+entry, fileDeleteCount2++;
                }
            }
            
            closedir(dir);
            
            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                if (arrayFileDelete2 [counter1] != "." && arrayFileDelete2 [counter1] != ".." && arrayFileDelete2 [counter1] != ".DS_Store"){
                    rename (arrayFileDelete2 [counter1].c_str(), arrayFileDelete [counter1].c_str());
                }
                else remove (arrayFileDelete2 [counter1].c_str());
            }
        }
    }
}

-(void)fileDeleteLayerThree:(int)directoryRemove{
    //directoryRemove == 0; delete files except "." etc
    //directoryRemove == 2; delete files and delete folder
    
    DIR *dir;
    struct dirent *dent;
    DIR *dir2;
    struct dirent *dent2;
    DIR *dir3;
    struct dirent *dent3;
    
    string entry;
    string entry2;
    string entry3;
    string filePath;
    string filePath2;
    
    dir = opendir(pathToDelete.c_str());
    fileDeleteCount = 0;
    
    if (dir != NULL){
        while ((dent = readdir(dir))){
            entry = dent -> d_name;
            filePath = pathToDelete+"/"+entry;
            
            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                dir2 = opendir(filePath.c_str());
                
                if (dir2 != NULL){
                    while ((dent2 = readdir(dir2))){
                        entry2 = dent2 -> d_name;
                        filePath2 = filePath+"/"+entry2;
                        
                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                            dir3 = opendir(filePath2.c_str());
                            
                            if (dir3 != NULL){
                                while ((dent3 = readdir(dir3))){
                                    entry3 = dent3 -> d_name;
                                    
                                    if (directoryRemove == 0){
                                        if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store"){
                                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                            arrayFileDelete [fileDeleteCount] = filePath2+"/"+entry3, fileDeleteCount++;
                                        }
                                    }
                                    else if (directoryRemove == 2){
                                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                        arrayFileDelete [fileDeleteCount] = filePath2+"/"+entry3, fileDeleteCount++;
                                    }
                                }
                                
                                closedir(dir3);
                            }
                        }
                    }
                    
                    closedir(dir2);
                }
            }
        }
        
        closedir(dir);
        
        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
            remove (arrayFileDelete [counter1].c_str());
            
            if (directoryRemove == 2) rmdir (arrayFileDelete [counter1].c_str());
        }
    }
}

-(void)fileRenameLayerThreeBmp:(int)directoryRemove{
    //pathToDelete: Source
    //pathToDelete2: destination
    
    DIR *dir;
    struct dirent *dent;
    DIR *dir2;
    struct dirent *dent2;
    DIR *dir3;
    struct dirent *dent3;
    
    string entry;
    string entry2;
    string entry3;
    string filePath;
    string filePath2;
    string filePath3;
    string filePath4;
    
    dir = opendir(pathToDelete.c_str());
    fileDeleteCount = 0;
    fileDeleteCount2 = 0;
    
    if (dir != NULL){
        while ((dent = readdir(dir))){
            entry = dent -> d_name;
            
            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                filePath = pathToDelete2+"/"+entry; //Destination
                filePath2 = pathToDelete+"/"+entry; //Source
                
                dir2 = opendir(filePath2.c_str());
                
                if (dir2 != NULL){
                    while ((dent2 = readdir(dir2))){
                        entry2 = dent2 -> d_name;
                        
                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                            filePath3 = filePath+"/"+entry2; //Destination
                            filePath4 = filePath2+"/"+entry2; //Source
                            
                            dir3 = opendir(filePath4.c_str());
                            
                            if (dir3 != NULL){
                                while ((dent3 = readdir(dir3))){
                                    entry3 = dent3 -> d_name;
                                    
                                    if ((int)entry3.find(".bmp") != -1 || (int)entry3.find(".tif") != -1){
                                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                        arrayFileDelete [fileDeleteCount] = filePath3+"/"+entry3, fileDeleteCount++; //Destination
                                        
                                        if (fileDeleteCount2+5 > fileDeleteLimit2) [self fileDeleteUpDate2];
                                        arrayFileDelete2 [fileDeleteCount2] = filePath4+"/"+entry3, fileDeleteCount2++; //Source
                                    }
                                }
                                
                                closedir(dir3);
                            }
                        }
                    }
                    
                    closedir(dir2);
                }
            }
        }
        
        closedir(dir);
        
        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
            rename (arrayFileDelete2 [counter1].c_str(), arrayFileDelete [counter1].c_str());
        }
    }
}

-(void)fileDeleteLayerFour:(int)directoryRemove{
    //directoryRemove == 0; delete files except "." etc
    //directoryRemove == 2; delete files and delete folder
    
    DIR *dir;
    struct dirent *dent;
    DIR *dir2;
    struct dirent *dent2;
    DIR *dir3;
    struct dirent *dent3;
    DIR *dir4;
    struct dirent *dent4;
    
    string entry;
    string entry2;
    string entry3;
    string entry4;
    string filePath;
    string filePath2;
    string filePath3;
    
    dir = opendir(pathToDelete.c_str());
    fileDeleteCount = 0;
    
    if (dir != NULL){
        while ((dent = readdir(dir))){
            entry = dent -> d_name;
            filePath = pathToDelete+"/"+entry;
            
            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                dir2 = opendir(filePath.c_str());
                
                if (dir2 != NULL){
                    while ((dent2 = readdir(dir2))){
                        entry2 = dent2 -> d_name;
                        filePath2 = filePath+"/"+entry2;
                        
                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                            dir3 = opendir(filePath2.c_str());
                            
                            if (dir3 != NULL){
                                while ((dent3 = readdir(dir3))){
                                    entry3 = dent3 -> d_name;
                                    filePath3 = filePath2+"/"+entry3;
                                    
                                    if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store"){
                                        dir4 = opendir(filePath3.c_str());
                                        
                                        if (dir4 != NULL){
                                            while ((dent4 = readdir(dir4))){
                                                entry4 = dent4 -> d_name;
                                                
                                                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                                arrayFileDelete [fileDeleteCount] = filePath3+"/"+entry4, fileDeleteCount++;
                                            }
                                            
                                            closedir(dir4);
                                        }
                                    }
                                }
                                
                                closedir(dir3);
                            }
                        }
                    }
                    
                    closedir(dir2);
                }
            }
        }
        
        closedir(dir);
        
        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
            remove (arrayFileDelete [counter1].c_str());
            
            if (directoryRemove == 2) rmdir (arrayFileDelete [counter1].c_str());
        }
    }
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)fileDeleteUpDate2{
    string *arrayUpDate = new string [fileDeleteCount2+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++) arrayUpDate [counter1] = arrayFileDelete2 [counter1];
    
    delete [] arrayFileDelete2;
    arrayFileDelete2 = new string [fileDeleteLimit2+500];
    fileDeleteLimit2 = fileDeleteLimit2+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++) arrayFileDelete2 [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

@end
