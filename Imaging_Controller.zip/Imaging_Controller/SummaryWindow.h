//
//  SummaryWindow.h
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2014-05-23.
//  Copyright Masahiko Sato 2014 All rights reserved.
//
//

#ifndef SUMMARYWINDOW_H
#define SUMMARYWINDOW_H
#import "Controller.h"
#endif

@interface SummaryWindow : NSView {
    IBOutlet NSWindow *summaryWindow;
}

-(IBAction)pdfPrint:(id)sender;
-(void)dealloc;

@end
