//
//  SummaryWindow.m
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2014-05-23.
//
//

#import "SummaryWindow.h"

NSString *notificationToSummaryWindow = @"notificationExecuteSummaryWindow";

@implementation SummaryWindow

-(id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    
    if (self){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToSummaryWindow object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [self setNeedsDisplay:YES];
}

-(IBAction)pdfPrint:(id)sender{
    string saveFileName;
    
    if (summaryType == 1) saveFileName = bodyNameHold+"-Summary.pdf";
    else saveFileName = bodyNameHold+"-BackUpInfo.pdf";
    
    NSSavePanel *save = [NSSavePanel savePanel];
    [save setNameFieldStringValue:@(saveFileName.c_str())];
    
    int result2 = (int)[save runModal];
    
    if (result2 == NSModalResponseOK){
        NSURL *files = [save URL];
        NSString *selectedFile = files.path;
        
        string extractedID = [selectedFile UTF8String];
        string directoryPath3 = [selectedFile UTF8String];
        
        int terminationFlag = 0;
        
        do{
            
            terminationFlag = 1;
            
            if ((int)extractedID.find("/") != -1) extractedID = extractedID.substr(extractedID.find("/")+1);
            else terminationFlag = 0;
            
        } while (terminationFlag == 1);
        
        NSRect sizeReset = NSMakeRect(0, 0, 792, 612);
        NSData *data;
        data = [summaryWindow dataWithPDFInsideRect:sizeReset];
        [data writeToFile:@(directoryPath3.c_str()) atomically:YES];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(void)drawRect:(NSRect)rect {
    NSBezierPath *thePathA;
    thePathA = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 792, 612)];
    [[NSColor colorWithCalibratedRed:0.9 green:0.9 blue:0.9 alpha:0.2] set];
    [thePathA fill];
    
    [thePathA setLineWidth:1.5];
    thePathA = [NSBezierPath bezierPathWithRect: NSMakeRect(10, 62, 772, 500)];
    [[NSColor blackColor] set];
    [thePathA stroke];
    
    NSPoint positionAA, positionBB;
    
    if (summaryType == 1){
        [[NSColor lightGrayColor] set];
        [thePathA setLineWidth:0.5];
        
        for (int counter1 = 1; counter1 < 26; counter1++){
            positionAA.x = 10;
            positionAA.y = 562-counter1*20;
            positionBB.x = 782;
            positionBB.y = 562-counter1*20;
            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
        }
        
        positionAA.x = 150;
        positionAA.y = 562;
        positionBB.x = 150;
        positionBB.y = 62;
        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
        
        positionAA.x = 300;
        positionAA.y = 562;
        positionBB.x = 300;
        positionBB.y = 62;
        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
        
        positionAA.x = 305;
        positionAA.y = 562;
        positionBB.x = 305;
        positionBB.y = 62;
        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
        
        positionAA.x = 405;
        positionAA.y = 562;
        positionBB.x = 405;
        positionBB.y = 62;
        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
        
        positionAA.x = 555;
        positionAA.y = 562;
        positionBB.x = 555;
        positionBB.y = 62;
        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
        
        positionAA.x = 705;
        positionAA.y = 562;
        positionBB.x = 705;
        positionBB.y = 62;
        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
        
        [thePathA setLineWidth:0];
        thePathA = [NSBezierPath bezierPathWithRect: NSMakeRect(10, 542, 772, 20)];
        [[NSColor colorWithCalibratedRed:0.49 green:0.85 blue:0.85 alpha:0.3] set];
        [thePathA fill];
        
        [thePathA setLineWidth:0];
        thePathA = [NSBezierPath bezierPathWithRect: NSMakeRect(10, 182, 772, 20)];
        [[NSColor colorWithCalibratedRed:0.85 green:0.49 blue:0.49 alpha:0.3] set];
        [thePathA fill];
        
        NSPoint pointA;
        NSAttributedString *attrStrA;
        NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
        
        [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        
        [attributesA setObject:[NSFont systemFontOfSize:15] forKey:NSFontAttributeName];
        
        string infoDisplayString = "Summary";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 350;
        pointA.y = 580;
        [attrStrA drawAtPoint:pointA];
        
        [attributesA setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
        
        infoDisplayString = "Topics";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 13;
        pointA.y = 545;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = "Information";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 153;
        pointA.y = 545;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = "Well No.";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 310;
        pointA.y = 545;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = "Treat Name";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 410;
        pointA.y = 545;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = "No of FOV";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 560;
        pointA.y = 545;
        [attrStrA drawAtPoint:pointA];
        
        [attributesA setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
        
        infoDisplayString = "Date";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 13;
        pointA.y = 525;
        [attrStrA drawAtPoint:pointA];
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"dd-MM-yyyy"];
        NSString *strDate = [dateFormatter stringFromDate:[NSDate date]];
        
        attrStrA = [[NSAttributedString alloc] initWithString:strDate attributes:attributesA];
        pointA.x = 153;
        pointA.y = 525;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = "Analysis";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 13;
        pointA.y = 505;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = arraySummaryList [1];
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 153;
        pointA.y = 505;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = "Computer";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 13;
        pointA.y = 485;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = arraySummaryList [2];
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 153;
        pointA.y = 485;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = "User ID";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 13;
        pointA.y = 465;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = arraySummaryList [3];
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 153;
        pointA.y = 465;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = "Total No.of FOV";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 13;
        pointA.y = 445;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = arraySummaryList [4];
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 153;
        pointA.y = 445;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = "Last Time Point";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 13;
        pointA.y = 425;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = arraySummaryList [5];
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 153;
        pointA.y = 425;
        [attrStrA drawAtPoint:pointA];
        
        string extension;
        
        for (int counter1 = 1; counter1 <= 16; counter1++){
            extension = to_string(counter1);
            
            infoDisplayString = "Well "+extension;
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
            pointA.x = 310;
            pointA.y = 525-(counter1-1)*20;
            [attrStrA drawAtPoint:pointA];
            
            infoDisplayString = arrayNameList [counter1-1];
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
            pointA.x = 410;
            pointA.y = 525-(counter1-1)*20;
            [attrStrA drawAtPoint:pointA];
            
            extension = to_string(arrayFOVNumberList [counter1-1]);
            
            infoDisplayString = extension;
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
            pointA.x = 560;
            pointA.y = 525-(counter1-1)*20;
            [attrStrA drawAtPoint:pointA];
        }
        
        [attributesA setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
        
        infoDisplayString = "Fluorescent Ch.";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 310;
        pointA.y = 185;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = "Name";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 410;
        pointA.y = 185;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = "Color No";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 560;
        pointA.y = 185;
        [attrStrA drawAtPoint:pointA];
        
        [attributesA setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
        
        infoDisplayString = "Fluorescent 1";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 310;
        pointA.y = 165;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = fluorescent1;
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 410;
        pointA.y = 165;
        [attrStrA drawAtPoint:pointA];
        
        extension = to_string(fluorescentColor1);
        
        infoDisplayString = extension;
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 560;
        pointA.y = 165;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = "Fluorescent 2";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 310;
        pointA.y = 145;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = fluorescent2;
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 410;
        pointA.y = 145;
        [attrStrA drawAtPoint:pointA];
        
        extension = to_string(fluorescentColor2);
        
        infoDisplayString = extension;
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 560;
        pointA.y = 145;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = "Fluorescent 3";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 310;
        pointA.y = 125;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = fluorescent3;
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 410;
        pointA.y = 125;
        [attrStrA drawAtPoint:pointA];
        
        extension = to_string(fluorescentColor3);
        
        infoDisplayString = extension;
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 560;
        pointA.y = 125;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = "Fluorescent 4";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 310;
        pointA.y = 105;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = fluorescent4;
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 410;
        pointA.y = 105;
        [attrStrA drawAtPoint:pointA];
        
        extension = to_string(fluorescentColor4);
        
        infoDisplayString = extension;
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 560;
        pointA.y = 105;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = "Fluorescent 5";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 310;
        pointA.y = 85;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = fluorescent5;
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 410;
        pointA.y = 85;
        [attrStrA drawAtPoint:pointA];
        
        extension = to_string(fluorescentColor5);
        
        infoDisplayString = extension;
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 560;
        pointA.y = 85;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = "Fluorescent 6";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 310;
        pointA.y = 65;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = fluorescent6;
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 410;
        pointA.y = 65;
        [attrStrA drawAtPoint:pointA];
        
        extension = to_string(fluorescentColor6);
        
        infoDisplayString = extension;
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 560;
        pointA.y = 65;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = "Objective";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 13;
        pointA.y = 405;
        [attrStrA drawAtPoint:pointA];
        
        if (objectiveType == "1") infoDisplayString = "x10";
        else if (objectiveType == "2") infoDisplayString = "x20";
        else if (objectiveType == "3") infoDisplayString = "x40";
        else infoDisplayString = "nil";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 153;
        pointA.y = 405;
        [attrStrA drawAtPoint:pointA];
    }
    
    if (summaryType == 2){
        [[NSColor lightGrayColor] set];
        [thePathA setLineWidth:0.5];
        
        for (int counter1 = 1; counter1 < 26; counter1++){
            positionAA.x = 10;
            positionAA.y = 562-counter1*20;
            positionBB.x = 782;
            positionBB.y = 562-counter1*20;
            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
        }
        
        for (int counter1 = 1; counter1 < 24; counter1 = counter1+2){
            [thePathA setLineWidth:0];
            thePathA = [NSBezierPath bezierPathWithRect: NSMakeRect(10, 542-counter1*20, 772, 20)];
            [[NSColor colorWithCalibratedRed:0.49 green:0.85 blue:0.85 alpha:0.3] set];
            [thePathA fill];
        }
        
        NSPoint pointA;
        NSAttributedString *attrStrA;
        NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
        
        [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        [attributesA setObject:[NSFont systemFontOfSize:15] forKey:NSFontAttributeName];
        
        string infoDisplayString = "Backup folder information";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 305;
        pointA.y = 580;
        [attrStrA drawAtPoint:pointA];
        
        string dataTemp;
        string dataTemp2;
        string folderNo;
        string startNo;
        string endNo;
        
        for (int counter1 = 1; counter1 < backUpDisplayListCount/2; counter1++){
            dataTemp = arrayBackUpDisplayList [counter1*2];
            dataTemp2 = arrayBackUpDisplayList [counter1*2+1];
            
            folderNo = dataTemp2.substr(dataTemp2.find("N: ")+3, dataTemp2.find("F: ")-dataTemp2.find("N: ")-5);
            startNo = dataTemp2.substr(dataTemp2.find("F: ")+3, dataTemp2.find("L: ")-dataTemp2.find("F: ")-5);
            endNo = dataTemp2.substr(dataTemp2.find("L: ")+3, dataTemp2.find("S: ")-dataTemp2.find("L: ")-5);
            
            if (startNo != "0" && startNo != "nil"){
                [attributesA setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                
                infoDisplayString = dataTemp;
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 13;
                pointA.y = 545-(counter1-1)*40;
                [attrStrA drawAtPoint:pointA];
                
                if (startNo.length() == 1) startNo = bodyNameHold+"-1000"+startNo;
                else if (startNo.length() == 2) startNo = bodyNameHold+"-100"+startNo;
                else if (startNo.length() == 3) startNo = bodyNameHold+"-10"+startNo;
                else startNo = bodyNameHold+"-1"+startNo;
                
                if (endNo.length() == 1) endNo = bodyNameHold+"-1000"+endNo;
                else if (endNo.length() == 2) endNo = bodyNameHold+"-100"+endNo;
                else if (endNo.length() == 3) endNo = bodyNameHold+"-10"+endNo;
                else endNo = bodyNameHold+"-1"+endNo;
                
                [attributesA setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
                
                if (folderNo == "nil") folderNo = "#";
                
                infoDisplayString = "FolderName:  "+backUpNameHold+"_"+userIDHold+folderNo+",    Start:  "+startNo+",    End:  "+endNo;
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 30;
                pointA.y = 525-(counter1-1)*40;
                [attrStrA drawAtPoint:pointA];
            }
        }
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToSummaryWindow object:nil];
}

@end
