//
//  AutoProcess.m
//  Imaging_Controller
//
//  Created by Masahiko Sato on 3/16/2014.
//
//

#import "AutoProcess.h"

NSString *notificationToAutoProcess = @"notificationExecuteAutoProcess";

@implementation AutoProcess

-(id)init{
    self = [super init];
    
    if (self != nil){
        smallestFolderNumber = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToAutoProcess object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    autoProcessTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(processControl) userInfo:nil repeats:YES];
}

-(void)processControl{
    if (autoBatchMode == 1) [self autoProcessMain];
}

-(void)autoProcessMain{
    if (autoStepCount == 0 && launchCheck == 0){
        smallestFolderNumber = 10000;
        smallestFolderName = "";
        
        string entry;
        string bodyNameExtract;
        
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(namedFilesPath.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    if ((int)entry.find(bodyNameHold) != -1){
                        bodyNameExtract = entry.substr(entry.find("-")+2);
                        
                        if (atoi(bodyNameExtract.c_str()) < smallestFolderNumber){
                            smallestFolderNumber = atoi(bodyNameExtract.c_str());
                            smallestFolderName = entry;
                        }
                        
                        autoStepCount = -1;
                        break;
                    }
                }
            }
            
            closedir(dir);
        }
        
        if (autoTimerInvalidate == 1 && autoStepCount == 0){
            ofstream oin;
            
            for (int counter1 = 0; counter1 < 10; counter1++){
                oin.open(instructionFIPath2.c_str(), ios::out);
                
                if (oin.is_open()){
                    oin<<"Exit"<<endl;
                    oin.close();
                    break;
                }
            }
            
            for (int counter1 = 0; counter1 < 10; counter1++){
                oin.open(instructionCSPath.c_str(), ios::out);
                
                if (oin.is_open()){
                    oin<<"Exit"<<endl;
                    oin.close();
                    break;
                }
            }
            
            autoTimerInvalidate = 0;
            autoStepCount = 4;
            focalImageFlag = 2;
            contrastSetFlag = 2;
            
            if (purgeCount == 3) purgeCount = 0;
            
            [autoProcessTimer invalidate];
        }
        
        NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @"/" error:nil];
        unsigned long freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
        //----1073741824, 1Gb limit----
        
        if (autoStepCount == -1 && 2097152000 > freeSize){ //=========2Gb=========
            if (consoleWarningCount+5 > consoleWarningLimit) [self warningUpDate];
            arrayConsoleWarning [consoleWarningCount] = "[AU] Low Disk Space: Processing Holding", consoleWarningCount++;
            
            ofstream oin;
            
            for (int counter1 = 0; counter1 < 10; counter1++){
                oin.open(instructionFIPath2.c_str(), ios::out);
                
                if (oin.is_open()){
                    oin<<"Exit"<<endl;
                    oin.close();
                    break;
                }
            }
            
            for (int counter1 = 0; counter1 < 10; counter1++){
                oin.open(instructionCSPath.c_str(), ios::out);
                
                if (oin.is_open()){
                    oin<<"Exit"<<endl;
                    oin.close();
                    break;
                }
            }
            
            autoStepCount = 4;
            focalImageFlag = 2;
            contrastSetFlag = 2;
            consolePage = 0;
            consoleDisplayCall = 1;
            
            if (purgeCount == 3) purgeCount = 0;
            
            [autoProcessTimer invalidate];
        }
    }
    
    if (autoStepCount == -1){
        autoStepCount = 2;
        
        ofstream oin;
        
        for (int counter1 = 0; counter1 < 10; counter1++){
            oin.open(instructionFIPath2.c_str(), ios::out);
            
            if (oin.is_open()){
                oin<<smallestFolderName<<endl;
                oin.close();
                break;
            }
        }
        
        struct stat sizeOfFile;
        
        string copyPath1 = productsFilesInfoPath+"/"+"FI-FocalPlaneData";
        string copyPath2 = productsFocalTempPath+"/"+"FI-FocalPlaneData";
        
        long sizeForCopy = 0;
        
        if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile (copyPath1.c_str(), ifstream::binary);
            ofstream outfile (copyPath2.c_str(), ofstream::binary);
            
            char *buffer = new char[sizeForCopy];
            infile.read (buffer, sizeForCopy);
            outfile.write (buffer, sizeForCopy);
            delete [] buffer;
            
            outfile.close();
            infile.close();
        }
        
        copyPath1 = productsFilesInfoPath+"/"+"FI-BasicSetting";
        copyPath2 = productsFocalTempPath+"/"+"FI-BasicSetting";
        
        if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile2 (copyPath1.c_str(), ifstream::binary);
            ofstream outfile2 (copyPath2.c_str(), ofstream::binary);
            
            char *buffer2 = new char[sizeForCopy];
            infile2.read (buffer2, sizeForCopy);
            outfile2.write (buffer2, sizeForCopy);
            delete [] buffer2;
            
            outfile2.close();
            infile2.close();
        }
        
        copyPath1 = productsFilesInfoPath+"/"+"CT-FOVPosition";
        copyPath2 = productsFocalTempPath+"/"+"CT-FOVPosition";
        
        if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile3 (copyPath1.c_str(), ifstream::binary);
            ofstream outfile3 (copyPath2.c_str(), ofstream::binary);
            
            char *buffer3 = new char[sizeForCopy];
            infile3.read (buffer3, sizeForCopy);
            outfile3.write (buffer3, sizeForCopy);
            delete [] buffer3;
            
            outfile3.close();
            infile3.close();
        }
        
        copyPath1 = productsFilesInfoPath+"/"+"CT-ContrastData";
        copyPath2 = productsFocalTempPath+"/"+"CT-ContrastData";
        
        if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile4 (copyPath1.c_str(), ifstream::binary);
            ofstream outfile4 (copyPath2.c_str(), ofstream::binary);
            
            char *buffer4 = new char[sizeForCopy];
            infile4.read (buffer4, sizeForCopy);
            outfile4.write (buffer4, sizeForCopy);
            delete [] buffer4;
            
            outfile4.close();
            infile4.close();
        }
        
        copyPath1 = productsFilesInfoPath+"/"+"CT-ContrastDataG";
        copyPath2 = productsFocalTempPath+"/"+"CT-ContrastDataG";
        
        if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile4 (copyPath1.c_str(), ifstream::binary);
            ofstream outfile4 (copyPath2.c_str(), ofstream::binary);
            
            char *buffer4 = new char[sizeForCopy];
            infile4.read (buffer4, sizeForCopy);
            outfile4.write (buffer4, sizeForCopy);
            delete [] buffer4;
            
            outfile4.close();
            infile4.close();
        }
        
        copyPath1 = productsFilesInfoPath+"/"+"CT-ContrastDataB";
        copyPath2 = productsFocalTempPath+"/"+"CT-ContrastDataB";
        
        if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile4 (copyPath1.c_str(), ifstream::binary);
            ofstream outfile4 (copyPath2.c_str(), ofstream::binary);
            
            char *buffer4 = new char[sizeForCopy];
            infile4.read (buffer4, sizeForCopy);
            outfile4.write (buffer4, sizeForCopy);
            delete [] buffer4;
            
            outfile4.close();
            infile4.close();
        }
        
        copyPath1 = productsFilesInfoPath+"/"+"CT-BasicSetting";
        copyPath2 = productsFocalTempPath+"/"+"CT-BasicSetting";
        
        if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile5 (copyPath1.c_str(), ifstream::binary);
            ofstream outfile5 (copyPath2.c_str(), ofstream::binary);
            
            char *buffer5 = new char[sizeForCopy];
            infile5.read (buffer5, sizeForCopy);
            outfile5.write (buffer5, sizeForCopy);
            delete [] buffer5;
            
            outfile5.close();
            infile5.close();
        }
        
        for (int counter1 = 0; counter1 < 16; counter1++){
            arrayForConsoleCheck [counter1] = 0;
            arrayForConsoleCheck2 [counter1] = 0;
        }
    }
    else if (autoStepCount == 2){
        int instructionAPFlag = 0;
        
        string getString;
        string instructionAP;
        
        ifstream fin;
        fin.open(instructionAPPath.c_str(),ios::in);
        if (fin.is_open()){
            instructionAPFlag = 1;
            fin.close();
        }
        
        if (instructionAPFlag != 0){
            fin.open(instructionAPPath.c_str(),ios::in);
            
            getline(fin, getString);
            instructionAP = getString;
            
            if (instructionAP == "Done") autoStepCount = 3;
            
            fin.close();
        }
    }
    else if (autoStepCount == 3) autoStepCount = 60;
    else if (autoStepCount >= 60 && autoStepCount < 95) autoStepCount++;
    else if (autoStepCount == 95){
        autoStepCount = 100;
        
        if (purgeCount >= 1 && purgeCount <= 100) purgeCount++;
    }
    else if (autoStepCount >= 100 && autoStepCount < 110) autoStepCount++;
    else if (autoStepCount == 110){
        string copyPath2 = productsFilesInfoPath+"/"+"FI-FocalPlaneData";
        string copyPath1 = productsFocalTempPath+"/"+"FI-FocalPlaneData";
        
        struct stat sizeOfFile;
        
        long sizeForCopy = 0;
        
        if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile (copyPath1.c_str(), ifstream::binary);
            ofstream outfile (copyPath2.c_str(), ofstream::binary);
            
            char *buffer = new char[sizeForCopy];
            infile.read (buffer, sizeForCopy);
            outfile.write (buffer, sizeForCopy);
            delete [] buffer;
            
            outfile.close();
            infile.close();
        }
        
        copyPath2 = productsFilesInfoPath+"/"+"FI-BasicSetting";
        copyPath1 = productsFocalTempPath+"/"+"FI-BasicSetting";
        
        if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile2 (copyPath1.c_str(), ifstream::binary);
            ofstream outfile2 (copyPath2.c_str(), ofstream::binary);
            
            char *buffer2 = new char[sizeForCopy];
            infile2.read (buffer2, sizeForCopy);
            outfile2.write (buffer2, sizeForCopy);
            delete [] buffer2;
            
            outfile2.close();
            infile2.close();
        }
        
        copyPath2 = productsFilesInfoPath+"/"+"CT-FOVPosition";
        copyPath1 = productsFocalTempPath+"/"+"CT-FOVPosition";
        
        if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile3 (copyPath1.c_str(), ifstream::binary);
            ofstream outfile3 (copyPath2.c_str(), ofstream::binary);
            
            char *buffer3 = new char[sizeForCopy];
            infile3.read (buffer3, sizeForCopy);
            outfile3.write (buffer3, sizeForCopy);
            delete [] buffer3;
            
            outfile3.close();
            infile3.close();
        }
        
        copyPath2 = productsFilesInfoPath+"/"+"CT-ContrastData";
        copyPath1 = productsFocalTempPath+"/"+"CT-ContrastData";
        
        if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile4 (copyPath1.c_str(), ifstream::binary);
            ofstream outfile4 (copyPath2.c_str(), ofstream::binary);
            
            char *buffer4 = new char[sizeForCopy];
            infile4.read (buffer4, sizeForCopy);
            outfile4.write (buffer4, sizeForCopy);
            delete [] buffer4;
            
            outfile4.close();
            infile4.close();
        }
        
        copyPath2 = productsFilesInfoPath+"/"+"CT-ContrastDataG";
        copyPath1 = productsFocalTempPath+"/"+"CT-ContrastDataG";
        
        if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile4 (copyPath1.c_str(), ifstream::binary);
            ofstream outfile4 (copyPath2.c_str(), ofstream::binary);
            
            char *buffer4 = new char[sizeForCopy];
            infile4.read (buffer4, sizeForCopy);
            outfile4.write (buffer4, sizeForCopy);
            delete [] buffer4;
            
            outfile4.close();
            infile4.close();
        }
        
        copyPath2 = productsFilesInfoPath+"/"+"CT-ContrastDataB";
        copyPath1 = productsFocalTempPath+"/"+"CT-ContrastDataB";
        
        if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile4 (copyPath1.c_str(), ifstream::binary);
            ofstream outfile4 (copyPath2.c_str(), ofstream::binary);
            
            char *buffer4 = new char[sizeForCopy];
            infile4.read (buffer4, sizeForCopy);
            outfile4.write (buffer4, sizeForCopy);
            delete [] buffer4;
            
            outfile4.close();
            infile4.close();
        }
        
        copyPath2 = productsFilesInfoPath+"/"+"CT-BasicSetting";
        copyPath1 = productsFocalTempPath+"/"+"CT-BasicSetting";
        
        if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream infile5 (copyPath1.c_str(), ifstream::binary);
            ofstream outfile5 (copyPath2.c_str(), ofstream::binary);
            
            char *buffer5 = new char[sizeForCopy];
            infile5.read (buffer5, sizeForCopy);
            outfile5.write (buffer5, sizeForCopy);
            delete [] buffer5;
            
            outfile5.close();
            infile5.close();
        }
        
        int directoryRmv = 0;
        pathToDelete = productsFocalTempPath;
        pathToDelete2 = productsFilesImagePath;
        
        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
        [controllerSubProcesses fileRenameLayerThreeBmp:directoryRmv];
        
        directoryRmv = 0;
        pathToDelete = productsStitchTempPath;
        pathToDelete2 = stitchedFolderPath;
        
        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
        [controllerSubProcesses fileRenameLayerTwo:directoryRmv];
        
        autoTotalCount++;
        autoTotalCountDisplayCall = 1;
        
        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
        [controllerSubProcesses parameterSave];
        
        ofstream oin;
        
        string backUpFolderSavePath = backUpDataPath+"/"+smallestFolderName;
        mkdir(backUpFolderSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string processFilePath = namedFilesPath+"/"+smallestFolderName;
        
        directoryRmv = 1;
        pathToDelete = processFilePath;
        pathToDelete2 = backUpFolderSavePath;
        
        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
        [controllerSubProcesses fileRenameLayerTwo:directoryRmv];
        
        rmdir(processFilePath.c_str());
        
        remove (instructionAPPath.c_str());
        
        if (autoTimerInvalidate == 1){
            autoTimerInvalidate = 0;
            autoStepCount = 4;
            focalImageFlag = 2;
            contrastSetFlag = 2;
            
            for (int counter1 = 0; counter1 < 10; counter1++){
                oin.open(instructionFIPath2.c_str(), ios::out);
                
                if (oin.is_open()){
                    oin<<"Exit"<<endl;
                    oin.close();
                    break;
                }
            }
            
            for (int counter1 = 0; counter1 < 10; counter1++){
                oin.open(instructionCSPath.c_str(), ios::out);
                
                if (oin.is_open()){
                    oin<<"Exit"<<endl;
                    oin.close();
                    break;
                }
            }
            
            [autoProcessTimer invalidate];
        }
        else if (autoTimerInvalidate == 0) autoStepCount = 0;
        
        if (purgeCount == 3) purgeCount = 4;
    }
    else if (autoStepCount == 52){
        [self stepReset];
    }
    
    if (autoStepCount >= 2 && autoStepCount < 110){
        string entry;
        string productDataPath1;
        string timeString;
        
        DIR *dir;
        struct dirent *dent;
        
        int findFlag = 0;
        
        for (int counter1 = 0; counter1 < 16; counter1++){
            if (arrayNameList [counter1] != "nil"){
                productDataPath1 = productsFocalTempPath+"/"+arrayNameList [counter1]+"~Sorted/FOV001";
                
                dir = opendir(productDataPath1.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if (arrayForConsoleCheck [counter1] == 0){
                                if (consoleFocalImageCount+5 > consoleFocalImageLimit) [self consoleFocalImageUpDate];
                                arrayConsoleFocalImage [consoleFocalImageCount] = smallestFolderName+"/ "+arrayNameList [counter1], consoleFocalImageCount++;
                                arrayForConsoleCheck [counter1] = 1;
                                consolePage = 2;
                                consoleDisplayCall = 1;
                                findFlag = 1;
                                
                                break;
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                
                productDataPath1 = productsStitchTempPath+"/"+arrayNameList [counter1]+"_Stitch";
                
                dir = opendir(productDataPath1.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find(".tif") != -1) timeString = entry.substr(0, entry.find(".tif"));
                            else if ((int)entry.find(".bmp") != -1) timeString = entry.substr(0, entry.find(".bmp"));
                            
                            if (arrayForConsoleCheck2 [counter1] == 0){
                                if (consoleContrastCount+5 > consoleContrastLimit) [self consoleContrastUpDate];
                                
                                if (purgeCount < 2) arrayConsoleContrast [consoleContrastCount] = timeString+"/ "+arrayNameList [counter1], consoleContrastCount++;
                                else arrayConsoleContrast [consoleContrastCount] = timeString+"/ "+arrayNameList [counter1]+"/Purge Done", consoleContrastCount++;
                                
                                arrayForConsoleCheck2 [counter1] = 1;
                                consolePage = 3;
                                consoleDisplayCall = 1;
                                findFlag = 1;
                                
                                break;
                            }
                        }
                    }
                    
                    closedir(dir);
                    
                    if (findFlag == 1){
                        break;
                    }
                }
            }
        }
    }
}

-(void)stepReset{
    int directoryRmv = 0;
    pathToDelete = productsFocalTempPath;
    
    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
    [controllerSubProcesses fileDeleteLayerThree:directoryRmv];
    
    directoryRmv = 0;
    pathToDelete = productsStitchTempPath;
    
    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
    [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
    
    autoTimerInvalidate = 0;
    autoStepCount = 4;
    focalImageFlag = 2;
    contrastSetFlag = 2;
    
    [autoProcessTimer invalidate];
    
    autoStepCount = 0;
}

-(void) warningUpDate{
    string *arrayUpDate = new string [consoleWarningCount+10];
    
    for (int counter1 = 0; counter1 < consoleWarningCount; counter1++) arrayUpDate [counter1] = arrayConsoleWarning [counter1];
    
    delete [] arrayConsoleWarning;
    arrayConsoleWarning = new string [consoleWarningLimit+500];
    consoleWarningLimit = consoleWarningLimit+500;
    
    for (int counter1 = 0; counter1 < consoleWarningCount; counter1++) arrayConsoleWarning [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)consoleFocalImageUpDate{
    string *arrayUpDate = new string [consoleFocalImageCount+10];
    
    for (int counter1 = 0; counter1 < consoleFocalImageCount; counter1++) arrayUpDate [counter1] = arrayConsoleFocalImage [counter1];
    
    delete [] arrayConsoleFocalImage;
    arrayConsoleFocalImage = new string [consoleFocalImageLimit+500];
    consoleFocalImageLimit = consoleFocalImageLimit+500;
    
    for (int counter1 = 0; counter1 < consoleFocalImageCount; counter1++) arrayConsoleFocalImage [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)consoleContrastUpDate{
    string *arrayUpDate = new string [consoleContrastCount+10];
    
    for (int counter1 = 0; counter1 < consoleContrastCount; counter1++) arrayUpDate [counter1] = arrayConsoleContrast [counter1];
    
    delete [] arrayConsoleContrast;
    arrayConsoleContrast = new string [consoleContrastLimit+500];
    consoleContrastLimit = consoleContrastLimit+500;
    
    for (int counter1 = 0; counter1 < consoleContrastCount; counter1++) arrayConsoleContrast [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)fileDeleteUpDate2{
    string *arrayUpDate = new string [fileDeleteCount2+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++) arrayUpDate [counter1] = arrayFileDelete2 [counter1];
    
    delete [] arrayFileDelete2;
    arrayFileDelete2 = new string [fileDeleteLimit2+500];
    fileDeleteLimit2 = fileDeleteLimit2+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++) arrayFileDelete2 [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToAutoProcess object:nil];
    if (autoProcessTimer) [autoProcessTimer invalidate];
}

@end
