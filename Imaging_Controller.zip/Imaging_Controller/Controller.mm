//
//  Controller.mm
//  Imaging_Controller
//
//  Created by Masahiko Sato on 09/05/10.
//  Copyright Masahiko Sato 2010 All rights reserved.
//

#import "Controller.h"

//----Basic Info----
string pathNameString;
string bodyNameHold;
string computerNameHold;
string userIDHold;
string totalFOVNoHold;

//----Basic Operation----
string nameCheckString;
string initialRunStatus;
string mapSetPerform;
int fovNoDisplayFlag;
int imageTimePointAccumulationCounter;
string *arrayFileDelete;
int fileDeleteCount;
int fileDeleteLimit;
string *arrayFileDelete2;
int fileDeleteCount2;
int fileDeleteLimit2;
int progressTiming;
string bodyNameSendMap;
string autoStatusXYSendMap;
string batchStatusXYSendMap;
string initialStatusXYSendMap;
string pathToDelete;
string pathToDelete2;
int launchCheck;

//----Auto/Batch-Back/Batch Image----
string autoProcessCommit;
string batchBackupOperationCommit;
string batchImageOperationCommit;
string smallestFolderName;
string smallestFolderSourceName;
int autoBatchMode;
int autoRunOnOff;
int batchBackupOnOff;
int batchImageOnOff;
int processLoopMonitor;
int autoTimerInvalidate;
int autoStepCount;
int autoTotalCount;
int autoTotalCountDisplayCall;
int *arrayForConsoleCheck;
int *arrayForConsoleCheck2;
int backupBatchWait1;
int backupBatchWait2;

//----Batch (back-up)----
string batchBackUpNameHold;
string *arrayBatchPathName;
int batchPathNameCount;
string batchBodyName;
string *batchProcessInfo;
int batchProcessInfoCount;
int batchProcessInfoLimit;
string backupBatchWaitPathName;

//----Batch (Image)----
string batchImagePathNameHold;
string batchImageBodyName;
string batchImagePathInfo;
string *arrayImageFolderList;
int imageFolderListCount;
int filePickUpCount;
int batchImageIFCount;
int largestFileNoBatch;

//----Fluorescent info----
string fluorescent1;
string fluorescent2;
string fluorescent3;
string fluorescent4;
string fluorescent5;
string fluorescent6;
string fluorescentNew1;
string fluorescentNew2;
string fluorescentNew3;
string fluorescentNew4;
string fluorescentNew5;
string fluorescentNew6;
int fluorescentColor1;
int fluorescentColor2;
int fluorescentColor3;
int fluorescentColor4;
int fluorescentColor5;
int fluorescentColor6;
int fluorescentCount;
int dicFluorescentMode;

//----Summary----
string *arrayNameList;
int *arrayFOVNumberList;
string *arraySummaryList;
int summaryListCount;
int summarySetCall;

//----Console----
string *arrayConsoleWarning;
int consoleWarningCount;
int consoleWarningLimit;
string *arrayConsoleTreatName;
int consoleTreatNameCount;
int consoleTreatNameLimit;
string *arrayConsoleFocalImage;
int consoleFocalImageCount;
int consoleFocalImageLimit;
string *arrayConsoleContrast;
int consoleContrastCount;
int consoleContrastLimit;
int consolePage;
int consoleDisplayCall;

//----Table control----
int tableViewPage;
int tableViewCall;
int tableCallCount;
int tableCurrentRowHold;
int rowIndexHold;
int rowNumberHold;

//----Backup----
string *arrayBackUpDisplayList;
int backUpDisplayListCount;
string backUpNameHold;

//----Launch status----
int runStatusXYMap;
int runStatusFileUpLoad;
int runStatusTreatmentNameSet;
int runStatusFocalImage;
int runStatusContrast;
int runStatusOutlineDraw;
int runStatusCellTracking;
int runStatusDataAnalysis;
int runStatusBackUp;
int runStatusMovie;
int runStatusMovie2;
int runStatusMovie3;
int runStatusMovie4;
int runStatusMovie5;
int runStatusMovie6;
int runStatusMovieQuant;
int runStatusWatson;
int runStatusFileConverter;
int runStatusCell3D;

//----Sub process control----
int fileUpLoadFlag;
int nameAssignFlag;
int focalImageFlag;
int contrastSetFlag;
int outlineDrawDisplayFlag;
int cellTrackingDisplayFlag;
int analysisDisplayFlag;
int backUpDisplayFlag;
int mapDisplayFlag;
int cellMovieDisplayFlag;
int cellMovieDisplayFlag2;
int cellMovieDisplayFlag3;
int cellMovieDisplayFlag4;
int cellMovieDisplayFlag5;
int cellMovieDisplayFlag6;
int cellMovieQuantFlag;
int watsonFlag;
int fileConverterFlag;
int cell3DFlag;

//----File up-load----
string folderNameForNamed;
string roundTimeString;
string *arrayFileName;
string ascIIstring;
int fileTransferProgress;
string *arraySelectFiles;
int selectFileCount;
int selectFileLimit;

//----File split----
string fileSavePathHold;
int **arrayImageFileSave;
uint8_t *fileReadArray;
int fileSplitOption;

//----Save load operation----
string *arraySaveLoadList;
int saveLoadListCount;
int saveLoadListLimit;
int summaryOperation;
int saveLoadOperation;
int summaryType;
string saveFolderName;
string sizeCheckPath;
string directoryPath;
string directoryPath2;
int saveLoadProgress;
string separatePath;
string bodyNameSeparate;

//----Objective type----
string objectiveType;

//----Last purge----
int lastPurgeFlag;
int purgeCount;

//----IF mode----
int processingIFCount;
int processingIFStatus;
int newIFFoundFlag;

//----Net check----
int netCheckWindowOperation;
string netAddressHold;
string netUsernameHold;
string netPasswordHold;

//----Path Info----
string dataImportFolderPath;
string dataFilesPath;
string namedFilesPath;
string productsFilesPath;
string cellTrackingImageFolderPath;
string cellTrackingDataPath;
string cellTrackingLibraryPath;
string cellTrackingSystemDataPath;
string cellTrackingAnalysisPath;
string analysisDataPath;
string nameListDataPath;
string backUpDirectoryPath;
string batchProcessImagePath;
string consoleWarningPath;
string summaryDataPath;
string launchProgramPath;
string productsFilesImagePath;
string productsFilesInfoPath;
string productsFocalTempPath;
string backUpDataPath;
string stitchedFolderPath;
string productsStitchTempPath;
string warningFLPath;
string instructionFIPath;
string instructionAPPath;
string instructionCSPath;
string instructionFLPath;
string instructionMapPath;
string instructionMapPath2;
string instructionNamePath;
string instructionFIPath2;
string loadingCompletePath;
string loadingCompleteFLPath;
string loadingCompleteCSPath;
string batchProcessBackUpPath;
string assignNamePath;
string batchProcessFolderPath;
string backupResultsPath;
string dataSaveFolderPath;
string directoryPathForPC;
string backUpResultsPath;

@implementation Controller

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSString *currentDirectoryPathNSString = [[NSBundle mainBundle] bundlePath];
        string userPathNameString = [currentDirectoryPathNSString cStringUsingEncoding:NSUTF8StringEncoding];
        
        if (userPathNameString.length() == 0) exit (0);
        else if ((int)userPathNameString.find("/Users/") == -1) exit (0);
        else{
            
            string pathName2 = userPathNameString.substr((unsigned long)userPathNameString.find("/Users/")+7);
            pathNameString = pathName2.substr(0, (unsigned long)pathName2.find("/"));
        }
        
        bodyNameHold = "nil";
        computerNameHold = "nil";
        userIDHold = "nil";
        totalFOVNoHold = "nil";
        
        initialRunStatus = "nil";
        mapSetPerform = "0";
        fovNoDisplayFlag = 0;
        imageTimePointAccumulationCounter = 0;
        progressTiming = 0;
        bodyNameSendMap = "nil";
        autoStatusXYSendMap = "nil";
        batchStatusXYSendMap = "nil";
        initialStatusXYSendMap = "nil";
        launchCheck = 0;
        
        autoProcessCommit = "nil";
        batchBackupOperationCommit = "nil";
        batchImageOperationCommit = "nil";
        autoBatchMode = 0;
        autoRunOnOff = 0;
        batchBackupOnOff = 0;
        batchImageOnOff = 0;
        processLoopMonitor = 0;
        autoTimerInvalidate = 0;
        autoStepCount = 0;
        autoTotalCount = 0;
        autoTotalCountDisplayCall = 0;
        backupBatchWait1 = 0;
        backupBatchWait2 = 0;
        
        filePickUpCount = 0;
        batchImageIFCount = 1;
        largestFileNoBatch = 0;
        
        fluorescent1 = "nil";
        fluorescent2 = "nil";
        fluorescent3 = "nil";
        fluorescent4 = "nil";
        fluorescent5 = "nil";
        fluorescent6 = "nil";
        fluorescentNew1 = "nil";
        fluorescentNew2 = "nil";
        fluorescentNew3 = "nil";
        fluorescentNew4 = "nil";
        fluorescentNew5 = "nil";
        fluorescentNew6 = "nil";
        fluorescentColor1 = 0;
        fluorescentColor2 = 0;
        fluorescentColor3 = 0;
        fluorescentColor4 = 0;
        fluorescentColor5 = 0;
        fluorescentColor6 = 0;
        fluorescentCount = 0;
        dicFluorescentMode = 1;
        
        summarySetCall = 0;
        
        consolePage = 0;
        consoleDisplayCall = 0;
        
        tableViewPage = 0;
        tableViewCall = 0;
        tableCallCount = 0;
        tableCurrentRowHold = 0;
        rowIndexHold = 0;
        rowNumberHold = 0;
        
        runStatusXYMap = 0;
        runStatusFileUpLoad = 0;
        runStatusTreatmentNameSet = 0;
        runStatusFocalImage = 0;
        runStatusContrast = 0;
        runStatusOutlineDraw = 0;
        runStatusCellTracking = 0;
        runStatusDataAnalysis = 0;
        runStatusBackUp = 0;
        runStatusMovie = 0;
        runStatusMovie2 = 0;
        runStatusMovie3 = 0;
        runStatusMovie4 = 0;
        runStatusMovie5 = 0;
        runStatusMovie6 = 0;
        runStatusMovieQuant = 0;
        runStatusWatson = 0;
        runStatusFileConverter = 0;
        runStatusCell3D = 0;
        
        fileUpLoadFlag = 0;
        nameAssignFlag = 0;
        focalImageFlag = 0;
        contrastSetFlag = 0;
        outlineDrawDisplayFlag = 0;
        cellTrackingDisplayFlag = 0;
        analysisDisplayFlag = 0;
        backUpDisplayFlag = 0;
        mapDisplayFlag = 0;
        cellMovieDisplayFlag = 0;
        cellMovieDisplayFlag2 = 0;
        cellMovieDisplayFlag3 = 0;
        cellMovieDisplayFlag4 = 0;
        cellMovieDisplayFlag5 = 0;
        cellMovieDisplayFlag6 = 0;
        cellMovieQuantFlag = 0;
        watsonFlag = 0;
        fileConverterFlag = 0;
        cell3DFlag = 0;
        
        fileTransferProgress  = 0;
        
        summaryOperation = 0;
        saveLoadOperation = 0;
        summaryType = 1;
        saveLoadProgress = 0;
        separatePath = "";
        bodyNameSeparate = "";
        
        objectiveType = "1";
        
        lastPurgeFlag = 0;
        purgeCount = 0;
        
        processingIFCount = 0;
        processingIFStatus = 0;
        newIFFoundFlag = 0;
        
        netCheckWindowOperation = 0;
        netAddressHold = "nil";
        netUsernameHold = "nil";
        netPasswordHold = "nil";
        
        extensionInfoDisplay = "nil";
        totalFOVDisplayCall = 0;
        extensionInfoDisplayCall = 0;
        
        forBackUpNamesStatus = 0;
        
        focalContrastRestartFlag = 0;
        focalContrastRetryCount = 0;
        fileUploadStartCount = 0;
        
        lastPurgeSetFlag = 0;
        
        netCheckStatus = 0;
        netConnectionStatus = 0;
        
        monitorTimerControlOutline = 0;
        monitorTimerControlCellTracking = 0;
        monitorTimerControlDataAnalysis = 0;
        monitorTimerControlBackUp = 0;
        monitorTimerControlXYMap = 0;
        monitorTimerControlFileUpload = 0;
        monitorTimerControlNameSet = 0;
        monitorTimerControlFocal = 0;
        monitorTimerControlContrast = 0;
        monitorTimerControlAutoFileUpload = 0;
        monitorTimerControlAutoFocalContrast = 0;
        monitorTimerControlBatchBack = 0;
        monitorTimerControlBatchImage = 0;
        monitorTimerControlAutoBackFocalHold = 0;
        monitorTimerControlAutoBackContrastHold = 0;
        monitorTimerControlBackImageContrastHold = 0;
        monitorTimerControlLastPurge = 0;
    }
    
    return self;
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [controller frame];
    CGFloat windowHeight = windowSize.size.height;
    CGFloat displayX = 80;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [controller setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [tableViewList setDataSource:self];
}

-(void)applicationDidFinishLaunching:(NSNotification*)notification{
    //[NSApp setActivationPolicy: NSApplicationActivationPolicyProhibited];
    //AppNap Inactivate: Command line > defaults write NSGlobalDomain NSAppSleepDisabled -bool YES
    
    //----Directory Paths----
    dataImportFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"01_Data_Import";
    dataFilesPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"02_Data_Files";
    namedFilesPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"03_Named_Files";
    productsFilesPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files";
    cellTrackingImageFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images";
    cellTrackingDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"07_Cell_Tracking_Data";
    cellTrackingAnalysisPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"08_Cell_Tracking_Analysis_Data";
    cellTrackingLibraryPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library";
    cellTrackingSystemDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data";
    backUpDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"04_BackUp_Folder";
    
    analysisDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/AnalysisSetting";
    nameListDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/NameListSetting";
    backUpDirectoryPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/BackUpList";
    backUpResultsPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/BackUpResults";
    batchProcessBackUpPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/BatchBackUpNameList";
    batchProcessImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/BatchImageList";
    consoleWarningPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ConsoleWarning";
    summaryDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/Summary";
    launchProgramPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"Cell_Imaging_processing_programs";
    warningFLPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"FL_Warning";
    instructionFIPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"FI_Instruction1";
    instructionFIPath2 = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"FI_Instruction2";
    instructionAPPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"AP_Instruction1";
    instructionCSPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"CS_Instruction1";
    instructionFLPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"FL_Instruction1";
    instructionMapPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"Map_Instruction1";
    instructionMapPath2 = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"Map_Instruction2";
    instructionNamePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"Name_Instruction1";
    assignNamePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/NAAssignedName";
    backupResultsPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/BKData";
    batchProcessFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/BTInfo";
    loadingCompletePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/FLComplete1";
    loadingCompleteFLPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/FSComplete1";
    loadingCompleteCSPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CSComplete1";
    
    //----array initialization----
    arraySummaryList = new string [100];
    summaryListCount = 0;
    batchProcessInfo = new string [3000];
    batchProcessInfoCount = 0;
    batchProcessInfoLimit = 3000;
    arrayForConsoleCheck = new int [100];
    arrayForConsoleCheck2 = new int [100];
    arraySaveLoadList = new string [500];
    saveLoadListCount = 0;
    saveLoadListLimit = 500;
    
    arrayConsoleTreatName = new string [1000];
    consoleTreatNameCount = 0;
    consoleTreatNameLimit = 1000;
    arrayConsoleFocalImage = new string [1000];
    consoleFocalImageCount = 0;
    consoleFocalImageLimit = 1000;
    arrayConsoleContrast = new string [1000];
    consoleContrastCount = 0;
    consoleContrastLimit = 1000;
    arrayImageFolderList = new string [1000];
    imageFolderListCount = 0;
    arraySelectFiles = new string [1000];
    selectFileCount = 0;
    selectFileLimit = 1000;
    
    //----Basic Setting----
    string getString;
    
    ifstream fin;
    fin.open(analysisDataPath.c_str(),ios::in);
    
    if (fin.is_open()){
        getline(fin, getString), bodyNameHold = getString;
        getline(fin, getString), computerNameHold = getString;
        getline(fin, getString), totalFOVNoHold = getString;
        getline(fin, getString), userIDHold = getString;
        getline(fin, getString), initialRunStatus = getString;
        getline(fin, getString), autoProcessCommit = getString;
        getline(fin, getString), batchBackupOperationCommit = getString;
        getline(fin, getString), batchImageOperationCommit = getString;
        getline(fin, getString), autoBatchMode = atoi(getString.c_str());
        getline(fin, getString), mapSetPerform = getString;
        getline(fin, getString), imageTimePointAccumulationCounter = atoi(getString.c_str());
        getline(fin, getString), objectiveType = getString;
        getline(fin, getString), processingIFCount = atoi(getString.c_str());
        getline(fin, getString), processingIFStatus = atoi(getString.c_str());
        getline(fin, getString), newIFFoundFlag = atoi(getString.c_str());
        getline(fin, getString), batchImageIFCount = atoi(getString.c_str());
        getline(fin, getString), fileSplitOption = atoi(getString.c_str());
        
        fin.close();
    }
    
    productsFilesImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Source_Images";
    productsFilesInfoPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Analysis_Information";
    productsFocalTempPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Temp_Images";
    productsStitchTempPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images"+"/"+"Temp_Image";
    
    directoryPathForPC = "nil";
    infoDirectoryPC = "nil";
    
    string directoryDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/DirectoryData";
    
    fin.open(directoryDataPath.c_str(),ios::in);
    
    if (fin.is_open()){
        getline(fin, getString), directoryPathForPC = getString;
        getline(fin, getString), infoDirectoryPC = getString;
        
        fin.close();
    }
    
    string netInformationPath = cellTrackingSystemDataPath+"/NetData";
    
    fin.open(netInformationPath.c_str(),ios::in);
    
    if (fin.is_open()){
        getline(fin, getString), netAddressHold = getString;
        getline(fin, getString), netUsernameHold = getString;
        getline(fin, getString), netPasswordHold = getString;
        
        fin.close();
    }
    
    if (autoBatchMode == 0) autoBatchMode = 1;
    
    if (bodyNameHold != "nil") [analysisName setStringValue:@(bodyNameHold.c_str())];
    else [analysisName setStringValue:@"nil"];
    
    if (computerNameHold != "nil") [computerName setStringValue:@(computerNameHold.c_str())];
    else [computerName setStringValue:@"nil"];
    
    if (totalFOVNoHold != "nil") [totalFOV setStringValue:@(totalFOVNoHold.c_str())];
    else [totalFOV setStringValue:@"nil"];
    
    if (userIDHold != "nil") [userID setStringValue:@(userIDHold.c_str())];
    else [userID setStringValue:@"nil"];
    
    [refreshStatus setStringValue:@"Ready"];
    
    if (objectiveType == "1") [objectiveSet setStringValue:@"x10"];
    else if (objectiveType == "2") [objectiveSet setStringValue:@"x20"];
    else if (objectiveType == "3") [objectiveSet setStringValue:@"x40"];
    
    if (autoBatchMode == 1){
        if (processingIFStatus == 0){
            [autoText setTextColor:[NSColor purpleColor]];
            [autoText setStringValue:@"Auto Processing"];
            [processModeDisplay setStringValue:@"Auto."];
            
            if (initialRunStatus == "nil") [runStatusDisplay setStringValue:@"None"];
            else if (autoProcessCommit == "nil" && initialRunStatus != "nil") [runStatusDisplay setStringValue:@"Init."];
            else if (autoProcessCommit == "1") [runStatusDisplay setStringValue:@"Proc."];
        }
        else if (processingIFStatus == 1){
            [autoText setTextColor:[NSColor purpleColor]];
            [autoText setStringValue:@"Auto Processing IF On"];
            [processModeDisplay setStringValue:@"Auto."];
            [runStatusDisplay setStringValue:@"IF Mode On"];
        }
        else if (processingIFStatus == 2){
            [autoText setTextColor:[NSColor purpleColor]];
            [autoText setStringValue:@"Auto Processing IF R-To-S"];
            [processModeDisplay setStringValue:@"Auto."];
            [runStatusDisplay setStringValue:@"IF Ready"];
        }
    }
    else if (autoBatchMode == 2){
        if (processingIFStatus == 0){
            [batchText1 setTextColor:[NSColor purpleColor]];
            [batchText1 setStringValue:@"Batch (Backup)"];
            [processModeDisplay setStringValue:@"Batch (Back.)"];
            
            if (initialRunStatus == "nil") [runStatusDisplay setStringValue:@"None"];
            else if (batchBackupOperationCommit == "nil" && initialRunStatus != "nil") [runStatusDisplay setStringValue:@"Init."];
            else if (batchBackupOperationCommit == "1") [runStatusDisplay setStringValue:@"Proc."];
        }
        else if (processingIFStatus == 1){
            [batchText1 setTextColor:[NSColor purpleColor]];
            [batchText1 setStringValue:@"Batch (Backup) IF On"];
            [processModeDisplay setStringValue:@"Batch (Back.)"];
            [runStatusDisplay setStringValue:@"IF Mode On"];
        }
        else if (processingIFStatus == 2){
            [batchText1 setTextColor:[NSColor purpleColor]];
            [batchText1 setStringValue:@"Batch (Backup) IF R-To-S"];
            [processModeDisplay setStringValue:@"Batch (Back.)"];
            [runStatusDisplay setStringValue:@"IF Ready"];
        }
    }
    else if (autoBatchMode == 3){
        if (processingIFStatus == 0){
            [batchText2 setTextColor:[NSColor purpleColor]];
            [batchText2 setStringValue:@"Batch (Image)"];
            [processModeDisplay setStringValue:@"Batch (Image)"];
            
            if (initialRunStatus == "nil") [runStatusDisplay setStringValue:@"None"];
            else if (batchImageOperationCommit == "nil" && initialRunStatus != "nil") [runStatusDisplay setStringValue:@"Init."];
            else if (batchImageOperationCommit == "1") [runStatusDisplay setStringValue:@"Proc."];
        }
        else if (processingIFStatus == 1){
            [batchText2 setTextColor:[NSColor purpleColor]];
            [batchText2 setStringValue:@"Batch (Image) IF On"];
            [processModeDisplay setStringValue:@"Batch (Image)"];
            [runStatusDisplay setStringValue:@"IF Mode On"];
        }
        else if (processingIFStatus == 2){
            [batchText2 setTextColor:[NSColor purpleColor]];
            [batchText2 setStringValue:@"Batch (Image) IF R-To-S"];
            [processModeDisplay setStringValue:@"Batch (Image)"];
            [runStatusDisplay setStringValue:@"IF Ready"];
        }
    }
    
    if (autoProcessCommit == "1") [autoStatus setStringValue:@"Hold"];
    else [autoStatus setStringValue:@"nil"];
    
    if (initialRunStatus == "nil"){
        [initialRun setTextColor:[NSColor blackColor]];
        [initialRun setStringValue:@"nil"];
        [initialRunOn setTextColor:[NSColor blackColor]];
        [initialRunOn setStringValue:@"Initial Set"];
    }
    else if (atoi(initialRunStatus.c_str()) == 0){
        [initialRun setTextColor:[NSColor blueColor]];
        [initialRun setStringValue:@"FUP"];
        [initialRunOn setTextColor:[NSColor blueColor]];
        [initialRunOn setStringValue:@"Initial Set"];
    }
    else if (atoi(initialRunStatus.c_str()) == 1){
        [initialRun setTextColor:[NSColor blueColor]];
        [initialRun setStringValue:@"FUP/NAS"];
        [initialRunOn setTextColor:[NSColor blueColor]];
        [initialRunOn setStringValue:@"Initial Set"];
    }
    else if (atoi(initialRunStatus.c_str()) == 2){
        [initialRun setTextColor:[NSColor blueColor]];
        [initialRun setStringValue:@"NAS"];
        [initialRunOn setTextColor:[NSColor blueColor]];
        [initialRunOn setStringValue:@"Initial Set"];
    }
    else if (atoi(initialRunStatus.c_str()) == 3){
        [initialRun setTextColor:[NSColor blueColor]];
        [initialRun setStringValue:@"NAS/FIS"];
        [initialRunOn setTextColor:[NSColor blueColor]];
        [initialRunOn setStringValue:@"Initial Set"];
    }
    else if (atoi(initialRunStatus.c_str()) == 4){
        [initialRun setTextColor:[NSColor blueColor]];
        [initialRun setStringValue:@"FIS"];
        [initialRunOn setTextColor:[NSColor blueColor]];
        [initialRunOn setStringValue:@"Initial Set"];
    }
    else if (atoi(initialRunStatus.c_str()) == 5){
        [initialRun setTextColor:[NSColor blueColor]];
        [initialRun setStringValue:@"FIS/CTS"];
        [initialRunOn setTextColor:[NSColor blueColor]];
        [initialRunOn setStringValue:@"Initial Set"];
    }
    else if (atoi(initialRunStatus.c_str()) == 6){
        [initialRun setTextColor:[NSColor blueColor]];
        [initialRun setStringValue:@"CTS"];
        [initialRunOn setTextColor:[NSColor blueColor]];
        [initialRunOn setStringValue:@"Initial Set"];
    }
    else if (atoi(initialRunStatus.c_str()) == 7){
        [initialRun setTextColor:[NSColor blueColor]];
        [initialRun setStringValue:@"CTS/Done"];
        [initialRunOn setTextColor:[NSColor blueColor]];
        [initialRunOn setStringValue:@"Initial Set"];
    }
    else if (atoi(initialRunStatus.c_str()) == 8){
        [initialRun setTextColor:[NSColor blueColor]];
        [initialRun setStringValue:@"Done"];
        [initialRunOn setTextColor:[NSColor blueColor]];
        [initialRunOn setStringValue:@"Initial Set"];
    }
    
    //----Name list and FOV no upload----
    arrayNameList = new string [100];
    arrayFOVNumberList = new int [100];
    
    for (int counter1 = 0; counter1 < 16; counter1++){
        arrayNameList [counter1] = "nil";
        arrayFOVNumberList [counter1] = 0;
    }
    
    fin.open(nameListDataPath.c_str(),ios::in);
    
    if (fin.is_open()){
        for (int counter1 = 0; counter1 < 16; counter1++){
            getline(fin, getString), arrayNameList [counter1] = getString;
        }
        
        for (int counter1 = 0; counter1 < 16; counter1++){
            getline(fin, getString);
            
            if (getString != "nil") arrayFOVNumberList [counter1] = atoi(getString.c_str());
            else arrayFOVNumberList [counter1] = 0;
        }
        
        getline(fin, getString), fluorescent1 = getString;
        getline(fin, getString), fluorescent2 = getString;
        getline(fin, getString), fluorescent3 = getString;
        getline(fin, getString), fluorescent4 = getString;
        getline(fin, getString), fluorescent5 = getString;
        getline(fin, getString), fluorescent6 = getString;
        getline(fin, getString), fluorescentNew1 = getString;
        getline(fin, getString), fluorescentNew2 = getString;
        getline(fin, getString), fluorescentNew3 = getString;
        getline(fin, getString), fluorescentNew4 = getString;
        getline(fin, getString), fluorescentNew5 = getString;
        getline(fin, getString), fluorescentNew6 = getString;
        getline(fin, getString), fluorescentColor1 = atoi(getString.c_str());
        
        if (getString != "0") fluorescentCount++;
        
        getline(fin, getString), fluorescentColor2 = atoi(getString.c_str());
        
        if (getString != "0") fluorescentCount++;
        
        getline(fin, getString), fluorescentColor3 = atoi(getString.c_str());
        
        if (getString != "0") fluorescentCount++;
        
        getline(fin, getString), fluorescentColor4 = atoi(getString.c_str());
        
        if (getString != "0") fluorescentCount++;
        
        getline(fin, getString), fluorescentColor5 = atoi(getString.c_str());
        
        if (getString != "0") fluorescentCount++;
        
        getline(fin, getString), fluorescentColor6 = atoi(getString.c_str());
        
        if (getString != "0") fluorescentCount++;
        
        fin.close();
    }
    
    if (fluorescentCount == 0) dicFluorescentMode = 1;
    else dicFluorescentMode = 2;
    
    string treatNameCheck = "";
    
    //----Last processed time point----
    for (int counter1 = 0; counter1 < 16; counter1++){
        if (arrayNameList [counter1] != "nil"){
            treatNameCheck = arrayNameList [counter1];
            break;
        }
    }
    
    //----BackUp folder name up load----
    if (processingIFStatus == 0) backUpNameHold = bodyNameHold;
    else{
        
        int stringLength = (int)bodyNameHold.length();
        string bodyNameHoldTemp = bodyNameHold.substr(0, (unsigned long)stringLength-2);
        backUpNameHold = bodyNameHoldTemp;
    }
    
    arrayBackUpDriveName = new string [101];
    backUpDriveNameCount = 0;
    
    fin.open(backUpDirectoryPath.c_str(),ios::in);
    
    if (fin.is_open()){
        getline(fin, getString), backUpNameHold = getString;
        
        do{
            
            getline(fin, getString);
            
            if (getString != "") arrayBackUpDriveName [backUpDriveNameCount] = getString, backUpDriveNameCount++;
            
        } while (getString != "");
        
        fin.close();
    }
    
    if (backUpNameHold != "nil" && backUpDriveNameCount != 0) [backUpStatus setIntegerValue:backUpDriveNameCount];
    else [backUpStatus setStringValue:@"nil"];
    
    if (backUpNameHold != "nil" && autoBatchMode == 1) [backUpName setStringValue:@( backUpNameHold.c_str())];
    else [backUpName setStringValue:@"nil"];
    
    arrayBackUpDisplayList = new string [201];
    backUpDisplayListCount = 0;
    
    fin.open(backUpResultsPath.c_str(),ios::in);
    
    if (fin.is_open()){
        do{
            
            getline(fin, getString);
            
            if (getString != "") arrayBackUpDisplayList [backUpDisplayListCount] = getString, backUpDisplayListCount++;
            
        } while (getString != "");
        
        fin.close();
    }
    
    //----Display set----
    [mapStatus setStringValue:@"Off"];
    [fileUpLoadStatus setStringValue:@"Off"];
    [treatNameSetStatus setStringValue:@"Off"];
    [focalImageStatus setStringValue:@"Off"];
    [contrastSetStatus setStringValue:@"Off"];
    [outlineDrawStatus setStringValue:@"Off"];
    [cellTrackingStatus setStringValue:@"Off"];
    [dataAnalysisStatus setStringValue:@"Off"];
    
    //----Batch information (from backUp folder) up load----
    batchBackUpNameHold = "nil";
    batchBodyName = "nil";
    
    arrayBatchPathName = new string [300];
    batchPathNameCount = 0;
    
    fin.open(batchProcessBackUpPath.c_str(),ios::in);
    
    if (fin.is_open()){
        arrayBatchPathName [batchPathNameCount] = "BL", batchPathNameCount++;
        
        getline(fin, getString);
        
        batchBodyName = getString;
        arrayBatchPathName [batchPathNameCount] = getString, batchPathNameCount++;
        
        getline(fin, getString);
        
        batchBackUpNameHold = getString;
        arrayBatchPathName [batchPathNameCount] = getString, batchPathNameCount++;
        
        do{
            
            getline(fin, getString);
            
            if (getString != "") arrayBatchPathName [batchPathNameCount] = getString, batchPathNameCount++;
            
        } while (getString != "");
        
        fin.close();
    }
    
    fin.open(batchProcessFolderPath.c_str(),ios::in);
    
    if (fin.is_open()){
        do{
            
            getline(fin, getString);
            
            if (getString != ""){
                if (batchProcessInfoCount+10 > batchProcessInfoLimit) [self batchInfoUpDate];
                
                batchProcessInfo [batchProcessInfoCount] = getString, batchProcessInfoCount++;
            }
            
        } while (getString != "");
        
        fin.close();
    }
    
    if (batchBackUpNameHold != "nil") [batchSetStatus1 setIntegerValue:batchPathNameCount-3];
    else [batchSetStatus1 setStringValue:@"nil"];
    
    if (batchBackupOperationCommit == "nil") [batchStartStatus1 setStringValue:@"nil"];
    else [batchStartStatus1 setStringValue:@"Hold"];
    
    if (batchBackUpNameHold != "nil") [batchAnalysisName1 setStringValue:@(batchBodyName.c_str())];
    else [batchAnalysisName1 setStringValue:@"nil"];
    
    if (batchBackUpNameHold != "nil") [batchSaveName1 setStringValue:@(batchBackUpNameHold.c_str())];
    else [batchSaveName1 setStringValue:@"nil"];
    
    //----Batch information (from image folder) up load----
    batchImageBodyName = "nil";
    batchImagePathNameHold = "nil";
    batchImagePathInfo = "nil";
    
    fin.open(batchProcessImagePath.c_str(),ios::in);
    
    if (fin.is_open()){
        getline(fin, getString), batchImageBodyName = getString;
        getline(fin, getString), batchImagePathNameHold = getString;
        getline(fin, getString), batchImagePathInfo = getString;
        getline(fin, getString), filePickUpCount = atoi(getString.c_str());
        getline(fin, getString), largestFileNoBatch = atoi(getString.c_str());
        fin.close();
    }
    
    if (batchImagePathNameHold != "nil") [batchSetStatus2 setStringValue:@"Set"];
    else [batchSetStatus2 setStringValue:@"nil"];
    
    if (batchImageOperationCommit == "nil") [batchStartStatus2 setStringValue:@"nil"];
    else [batchStartStatus2 setStringValue:@"Hold"];
    
    if (batchImagePathNameHold != "nil") [batchAnalysisName2 setStringValue:@( batchImageBodyName.c_str())];
    else [batchAnalysisName2 setStringValue:@"nil"];
    
    if (batchImagePathNameHold != "nil") [batchSaveName2 setStringValue:@(batchImagePathNameHold.c_str())];
    else [batchSaveName2 setStringValue:@"nil"];
    
    if (batchImagePathNameHold == "nil") stitchedFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images"+"/"+bodyNameHold+"_Image";
    else stitchedFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images"+"/"+batchImagePathNameHold+"_Image";
    
    string fileNoCheckPath;
    
    if (batchImageBodyName == "nil") fileNoCheckPath = stitchedFolderPath+"/"+treatNameCheck+"_Stitch";
    else fileNoCheckPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images"+"/"+batchImagePathNameHold+"_Image/"+treatNameCheck+"_Stitch";
    
    string entry;
    string fileNoCheck;
    
    DIR *dir;
    struct dirent *dent;
    
    dir = opendir(fileNoCheckPath.c_str());
    
    if (dir != NULL){
        while ((dent = readdir(dir))){
            entry = dent -> d_name;
            
            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                fileNoCheck = entry.substr(entry.find("STimage ")+8, 4);
                
                if (atoi(fileNoCheck.c_str()) > autoTotalCount) autoTotalCount = atoi(fileNoCheck.c_str());
            }
        }
        
        closedir(dir);
    }
    
    if (autoTotalCount == 0) [currentTimePoint setStringValue:@"nil"];
    else [currentTimePoint setIntegerValue:autoTotalCount];
    
    //----Console Warning up load----
    arrayConsoleWarning = new string [500];
    consoleWarningCount = 0;
    consoleWarningLimit = 500;
    
    fin.open(consoleWarningPath.c_str(),ios::in);
    
    if (fin.is_open()){
        do{
            
            getline(fin, getString);
            
            if (getString != ""){
                if (consoleWarningCount+5 > consoleWarningLimit){
                    string *arrayUpDate = new string [consoleWarningCount+10];
                    
                    for (int counter1 = 0; counter1 < consoleWarningCount; counter1++) arrayUpDate [counter1] = arrayConsoleWarning [counter1];
                    
                    delete [] arrayConsoleWarning;
                    arrayConsoleWarning = new string [consoleWarningLimit+500];
                    consoleWarningLimit = consoleWarningLimit+500;
                    
                    for (int counter1 = 0; counter1 < consoleWarningCount; counter1++) arrayConsoleWarning [counter1] = arrayUpDate [counter1];
                    delete [] arrayUpDate;
                }
                
                arrayConsoleWarning [consoleWarningCount] = getString, consoleWarningCount++;
            }
            
        } while (getString != "");
        
        fin.close();
    }
    
    arrayFileDelete = new string [100];
    fileDeleteCount = 0;
    fileDeleteLimit = 100;
    
    arrayFileDelete2 = new string [100];
    fileDeleteCount2 = 0;
    fileDeleteLimit2 = 100;
    
    [consoleName setStringValue:@"Console"];
    [tableName setStringValue:@"Summary"];
    [inputDataSet setStringValue:@""];
    
    consoleDisplayCall = 1;
    summarySetCall = 1;
    tableViewPage = 0;
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToActiveProcess object:self];
    controllerTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(processControl) userInfo:nil repeats:YES];
}

-(void)processControl{
    //----Console display call----
    if (consoleDisplayCall == 1){
        consoleDisplayCall = 2;
        [self consoleDisplay];
    }
    
    //----Table display call----
    if (tableViewCall == 1){
        tableViewCall = 0;
        [tableViewList reloadData];
    }
    
    //----Summary display call----
    if (summarySetCall >= 1){
        if (summarySetCall == 1) summarySetCall = 3;
        if (summarySetCall == 2) summarySetCall = 4;
        [self summarySet];
    }
    
    //----Total fov display call----
    if (totalFOVDisplayCall == 1){
        if ([totalFOV intValue] == atoi(totalFOVNoHold.c_str())){
            totalFOVDisplayCall = 0;
            [totalFOV setStringValue:@(totalFOVNoHold.c_str())];
        }
    }
    
    //----Extension display call----
    if (extensionInfoDisplayCall == 1){
        extensionInfoDisplayCall = 0;
        [extendedInfo setStringValue:@(extensionInfoDisplay.c_str())];
    }
    
    //----Outline draw----
    if (runStatusOutlineDraw == 1){
        runStatusOutlineDraw = 2;
        monitorTimerControlOutline = 1;
    }
    else if (monitorTimerControlOutline >= 1 && monitorTimerControlOutline <= 10){
        monitorTimerControlOutline++;
    }
    else if (monitorTimerControlOutline == 11){
        monitorTimerControlOutline = 0;
        launchCheck = 0;
    }
    else if (outlineDrawDisplayFlag == 1){
        outlineDrawDisplayFlag = 0;
        [outlineDrawStatus setStringValue:@"On"];
    }
    else if (outlineDrawDisplayFlag == 2){
        runStatusOutlineDraw = 0;
        outlineDrawDisplayFlag = 0;
        [outlineDrawStatus setStringValue:@"Off"];
    }
    
    //----Cell tracking----
    if (runStatusCellTracking == 1){
        runStatusCellTracking = 2;
        monitorTimerControlCellTracking = 1;
        [cellTrackingStatus setStringValue:@"On"];
    }
    else if (monitorTimerControlCellTracking >= 1 && monitorTimerControlCellTracking <= 10){
        monitorTimerControlCellTracking++;
    }
    else if (monitorTimerControlCellTracking == 11){
        monitorTimerControlCellTracking = 0;
        launchCheck = 0;
    }
    else if (cellTrackingDisplayFlag == 2){
        runStatusCellTracking = 0;
        cellTrackingDisplayFlag = 0;
        [cellTrackingStatus setStringValue:@"Off"];
    }
    
    //----Cell Movie----
    if (runStatusMovie == 1) runStatusMovie = 2;
    else if (cellMovieDisplayFlag == 2){
        runStatusMovie = 0;
        cellMovieDisplayFlag = 0;
    }
    
    //----Cell Movie2----
    if (runStatusMovie2 == 1) runStatusMovie2 = 2;
    else if (cellMovieDisplayFlag2 == 2){
        runStatusMovie2 = 0;
        cellMovieDisplayFlag2 = 0;
    }
    
    //----Cell Movie3----
    if (runStatusMovie3 == 1) runStatusMovie3 = 2;
    else if (cellMovieDisplayFlag3 == 2){
        runStatusMovie3 = 0;
        cellMovieDisplayFlag3 = 0;
    }
    
    //----Cell Movie4----
    if (runStatusMovie4 == 1) runStatusMovie4 = 2;
    else if (cellMovieDisplayFlag4 == 2){
        runStatusMovie4 = 0;
        cellMovieDisplayFlag4 = 0;
    }
    
    //----Cell Movie5----
    if (runStatusMovie5 == 1) runStatusMovie5 = 2;
    else if (cellMovieDisplayFlag5 == 2){
        runStatusMovie5 = 0;
        cellMovieDisplayFlag5 = 0;
    }
    
    //----Cell Movie6----
    if (runStatusMovie6 == 1) runStatusMovie6 = 2;
    else if (cellMovieDisplayFlag6 == 2){
        runStatusMovie6 = 0;
        cellMovieDisplayFlag6 = 0;
    }
    
    //----Cell MovieQuant----
    if (runStatusMovieQuant == 1) runStatusMovieQuant = 2;
    else if (cellMovieQuantFlag == 2){
        runStatusMovieQuant = 0;
        cellMovieQuantFlag = 0;
    }
    
    //----Watson----
    if (runStatusWatson == 1) runStatusWatson = 2;
    else if (watsonFlag == 2){
        runStatusWatson = 0;
        watsonFlag = 0;
    }
    
    //----File Converter----
    if (runStatusFileConverter == 1) runStatusFileConverter = 2;
    else if (fileConverterFlag == 2){
        runStatusFileConverter = 0;
        fileConverterFlag = 0;
    }
    
    //----Cell 3D----
    if (runStatusCell3D == 1) runStatusCell3D = 2;
    else if (cell3DFlag == 2){
        runStatusCell3D = 0;
        cell3DFlag = 0;
    }
    
    //----Data analysis----
    if (runStatusDataAnalysis == 1){
        runStatusDataAnalysis = 2;
        monitorTimerControlDataAnalysis = 1;
        [dataAnalysisStatus setStringValue:@"On"];
    }
    else if (monitorTimerControlDataAnalysis >= 1 && monitorTimerControlDataAnalysis <= 10){
        monitorTimerControlDataAnalysis++;
    }
    else if (monitorTimerControlDataAnalysis == 11){
        monitorTimerControlDataAnalysis = 0;
        launchCheck = 0;
    }
    else if (analysisDisplayFlag == 2){
        runStatusDataAnalysis = 0;
        analysisDisplayFlag = 0;
        [dataAnalysisStatus setStringValue:@"Off"];
    }
    
    //----Backup----
    if (runStatusBackUp == 1){
        runStatusBackUp = 2;
        monitorTimerControlBackUp = 1;
        [backUpProgramStatus setStringValue:@"On"];
    }
    else if (monitorTimerControlBackUp >= 1 && monitorTimerControlBackUp <= 10){
        monitorTimerControlBackUp++;
    }
    else if (monitorTimerControlBackUp == 11){
        monitorTimerControlBackUp = 0;
        launchCheck = 0;
    }
    else if (backUpDisplayFlag == 2){
        string getString;
        string directoryNameBk;
        
        runStatusBackUp = 0;
        backUpDisplayFlag = 0;
        [backUpProgramStatus setStringValue:@"Off"];
        
        ifstream fin;
        fin.open(backupResultsPath.c_str(),ios::in);
        
        if (fin.is_open()){
            getline(fin, getString), directoryNameBk = getString;
            fin.close();
            
            if (directoryNameBk == "NAD"){
                if (consoleWarningCount+5 > consoleWarningLimit) [self warningUpDate];
                arrayConsoleWarning [consoleWarningCount] = "[BK] No Available Hard Drives", consoleWarningCount++;
                
                consolePage = 0;
                consoleDisplayCall = 1;
            }
            
            remove (backupResultsPath.c_str());
        }
    }
    else if (runStatusBackUp == 2){
        ifstream fin;
        fin.open(backupResultsPath.c_str(),ios::in);
        
        if (fin.is_open()){
            string getString;
            string directoryNameBk;
            string backupFolderNo;
            string backupStartNo;
            string backupEndNo;
            string backupStatus;
            
            getline(fin, getString), directoryNameBk = getString;
            getline(fin, getString), backupFolderNo = getString;
            getline(fin, getString), backupStartNo = getString;
            getline(fin, getString), backupEndNo = getString;
            getline(fin, getString), backupStatus = getString;
            fin.close();
            
            //cout<<directoryNameBk<<" "<<backupFolderNo<<" "<<backupStartNo<<" "<<backupEndNo<<" "<<backupStatus<<" Info"<<endl;
            
            if (directoryNameBk != "NAD"){
                ofstream oin;
                
                for (int counter1 = 0; counter1 < backUpDisplayListCount/2; counter1++){
                    if (arrayBackUpDisplayList [counter1*2] == directoryNameBk){
                        arrayBackUpDisplayList [counter1*2+1] = "N: "+backupFolderNo+", F: "+backupStartNo+", L: "+backupEndNo+", S: "+backupStatus;
                        
                        oin.open(backUpResultsPath.c_str(), ios::out);
                        
                        for (int counter2 = 0; counter2 < backUpDisplayListCount; counter2++) oin<<arrayBackUpDisplayList [counter2]<<endl;
                        
                        oin.close();
                        
                        tableViewPage = 1;
                        [tableViewList reloadData];
                        break;
                    }
                }
            }
            else if (directoryNameBk == "NAD"){
                if (consoleWarningCount+5 > consoleWarningLimit) [self warningUpDate];
                arrayConsoleWarning [consoleWarningCount] = "[BK] No Available Hard Drives", consoleWarningCount++;
                
                consolePage = 0;
                consoleDisplayCall = 1;
            }
            
            remove (backupResultsPath.c_str());
        }
    }
    
    //----XY map----
    if (runStatusXYMap == 1){
        runStatusXYMap = 2;
        monitorTimerControlXYMap = 1;
    }
    else if (monitorTimerControlXYMap >= 1 && monitorTimerControlXYMap <= 10){
        monitorTimerControlXYMap++;
    }
    else if (monitorTimerControlXYMap == 11){
        monitorTimerControlXYMap = 0;
        launchCheck = 0;
    }
    else if (mapDisplayFlag == 1){
        mapDisplayFlag = 0;
        [mapStatus setStringValue:@"On"];
    }
    else if (mapDisplayFlag == 2){
        runStatusXYMap = 0;
        mapDisplayFlag = 0;
        [mapStatus setStringValue:@"Off"];
    }
    
    //==========Initial run==========
    if (autoProcessCommit == "nil" && initialRunStatus != "8"){
        
        //----File upLoad----
        if (runStatusFileUpLoad == 1){
            runStatusFileUpLoad = 2;
            monitorTimerControlFileUpload = 1;
        }
        else if (monitorTimerControlFileUpload >= 1 && monitorTimerControlFileUpload <= 10){
            monitorTimerControlFileUpload++;
        }
        else if (monitorTimerControlFileUpload == 11){
            monitorTimerControlFileUpload = 0;
            launchCheck = 0;
        }
        else if (fileUpLoadFlag == 1){
            fileUpLoadFlag = 0;
            [fileUpLoadStatus setStringValue:@"On"];
            
            int directoryRmv = 0;
            pathToDelete = dataImportFolderPath;
            
            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
            [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
            
            directoryRmv = 0;
            pathToDelete = dataFilesPath;
            
            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
            [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
            
            directoryRmv = 1;
            pathToDelete = dataFilesPath;
            
            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
            [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
        }
        else if (fileUpLoadFlag == 2 && initialRunStatus == "1"){
            fileUpLoadFlag = 0;
            initialRunStatus = "1A";
            [fileUpLoadStatus setStringValue:@"Off"];
            
            remove(instructionFLPath.c_str());
        }
        else if (fileUpLoadFlag == 2 && initialRunStatus == "0"){
            fileUpLoadFlag = 0;
            runStatusFileUpLoad = 0;
            fileTransferProgress  = 0;
            
            [fileUpLoadStatus setStringValue:@"Off"];
            
            if (consoleWarningCount+5 > consoleWarningLimit) [self warningUpDate];
            arrayConsoleWarning [consoleWarningCount] = "[FL] Crash: Redo Initial Setting", consoleWarningCount++;
            
            consolePage = 0;
            consoleDisplayCall = 1;
            
            remove(instructionFLPath.c_str());
        }
        else if (fileUpLoadFlag == 4 && processLoopMonitor == 0){
            [backSave startAnimation:self];
            
            fileTransferProgress  = 1;
            processLoopMonitor = 1;
        }
        else if (fileUpLoadFlag == 4 && processLoopMonitor == 3){
            [backSave stopAnimation:self];
            
            fileUpLoadFlag = 0;
            processLoopMonitor = 0;
            
            [initialRun setStringValue:@"FUP/NAS"];
            initialRunStatus = "1";
            
            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
            [controllerSubProcesses parameterSave];
            
            remove(loadingCompletePath.c_str());
            remove(instructionFLPath.c_str());
        }
        else if (initialRunStatus == "1A" && runStatusFileUpLoad == 4){
            runStatusFileUpLoad = 0;
            initialRunStatus = "2";
            
            [initialRun setStringValue:@"NAS"];
            
            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
            [controllerSubProcesses parameterSave];
        }
        
        //----Name set----
        if (runStatusTreatmentNameSet == 1){
            runStatusTreatmentNameSet = 2;
            monitorTimerControlNameSet = 1;
        }
        else if (monitorTimerControlNameSet >= 1 && monitorTimerControlNameSet <= 10){
            monitorTimerControlNameSet++;
        }
        else if (monitorTimerControlNameSet == 11){
            monitorTimerControlNameSet = 0;
            launchCheck = 0;
        }
        else if (nameAssignFlag == 1){
            nameAssignFlag = 0;
            [treatNameSetStatus setStringValue:@"On"];
        }
        else if (nameAssignFlag == 2 && initialRunStatus == "3"){
            nameAssignFlag = 0;
            initialRunStatus = "3A";
            [treatNameSetStatus setStringValue:@"Off"];
        }
        else if (nameAssignFlag == 2 && initialRunStatus == "2"){
            nameAssignFlag = 0;
            runStatusTreatmentNameSet = 0;
            
            [treatNameSetStatus setStringValue:@"Off"];
            
            if (consoleWarningCount+5 > consoleWarningLimit) [self warningUpDate];
            arrayConsoleWarning [consoleWarningCount] = "[NA] Crash/Quit: Redo Initial Setting/NAS", consoleWarningCount++;
            
            consolePage = 0;
            consoleDisplayCall = 1;
        }
        else if (nameAssignFlag == 3){
            consolePage = 1;
            [self consoleDisplay];
            
            nameAssignFlag = 0;
            initialRunStatus = "3";
            
            [initialRun setStringValue:@"NAS/FIS"];
            
            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
            [controllerSubProcesses parameterSave];
            
            remove (instructionNamePath.c_str());
        }
        else if (initialRunStatus == "3A" && runStatusTreatmentNameSet == 4){
            runStatusTreatmentNameSet = 0;
            initialRunStatus = "4";
            
            [initialRun setStringValue:@"FIS"];
            
            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
            [controllerSubProcesses parameterSave];
        }
        
        //----Focal----
        if (runStatusFocalImage == 1){
            runStatusFocalImage = 2;
            monitorTimerControlFocal = 1;
        }
        else if (monitorTimerControlFocal >= 1 && monitorTimerControlFocal <= 10){
            monitorTimerControlFocal++;
        }
        else if (monitorTimerControlFocal == 11){
            monitorTimerControlFocal = 0;
            launchCheck = 0;
        }
        else if (focalImageFlag == 1){
            focalImageFlag = 0;
            [focalImageStatus setStringValue:@"On"];
        }
        else if (focalImageFlag == 2 && initialRunStatus == "5"){
            focalImageFlag = 0;
            initialRunStatus = "5A";
            [focalImageStatus setStringValue:@"Off"];
        }
        else if (focalImageFlag == 2 && initialRunStatus == "4"){
            focalImageFlag = 0;
            runStatusFocalImage = 0;
            
            [focalImageStatus setStringValue:@"Off"];
            
            if (consoleWarningCount+5 > consoleWarningLimit) [self warningUpDate];
            arrayConsoleWarning [consoleWarningCount] = "[FI] Crash/Quit: Redo Initial Setting/FIS", consoleWarningCount++;
            
            consolePage = 0;
            consoleDisplayCall = 1;
        }
        else if (focalImageFlag == 3){
            consolePage = 2;
            [self consoleDisplay];
            
            focalImageFlag = 0;
            initialRunStatus = "5";
            
            [initialRun setStringValue:@"FIS/CTS"];
            
            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
            [controllerSubProcesses parameterSave];
            
            remove(loadingCompleteFLPath.c_str());
            remove (instructionFIPath.c_str());
            remove (instructionFIPath2.c_str());
        }
        else if (initialRunStatus == "5A" && runStatusFocalImage == 4){
            runStatusFocalImage = 0;
            initialRunStatus = "6";
            
            [initialRun setStringValue:@"CTS"];
            
            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
            [controllerSubProcesses parameterSave];
        }
        
        //----Contrast----
        if (runStatusContrast == 1){
            runStatusContrast = 2;
            monitorTimerControlContrast = 1;
        }
        else if (monitorTimerControlContrast >= 1 && monitorTimerControlContrast <= 10){
            monitorTimerControlContrast++;
        }
        else if (monitorTimerControlContrast == 11){
            monitorTimerControlContrast = 0;
            launchCheck = 0;
        }
        else if (contrastSetFlag == 1){
            contrastSetFlag = 0;
            [contrastSetStatus setStringValue:@"On"];
        }
        else if (contrastSetFlag == 2 && initialRunStatus == "7"){
            contrastSetFlag = 0;
            initialRunStatus = "7A";
            [contrastSetStatus setStringValue:@"Off"];
        }
        else if (contrastSetFlag == 2 && initialRunStatus == "6"){
            contrastSetFlag = 0;
            runStatusContrast = 0;
            
            [contrastSetStatus setStringValue:@"Off"];
            
            if (consoleWarningCount+5 > consoleWarningLimit) [self warningUpDate];
            arrayConsoleWarning [consoleWarningCount] = "[CS] Crash/Quit: Redo Initial Setting/CIS", consoleWarningCount++;
            
            consolePage = 0;
            consoleDisplayCall = 1;
        }
        else if (contrastSetFlag == 3){
            consolePage = 3;
            [self consoleDisplay];
            
            contrastSetFlag = 0;
            initialRunStatus = "7";
            
            [initialRun setStringValue:@"CTS/Done"];
            
            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
            [controllerSubProcesses parameterSave];
            
            remove(loadingCompleteCSPath.c_str());
            remove (instructionAPPath.c_str());
        }
        else if (initialRunStatus == "7A" && runStatusContrast == 4){
            string backUpFolderSavePath;
            string processFilePath;
            
            runStatusContrast = 0;
            initialRunStatus = "8";
            
            [initialRun setStringValue:@"Done"];
            autoTotalCount = 1;
            
            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
            [controllerSubProcesses parameterSave];
            
            if (autoBatchMode != 3){
                int directoryRmv = 0;
                pathToDelete = productsFocalTempPath;
                pathToDelete2 = productsFilesImagePath;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses fileRenameLayerThreeBmp:directoryRmv];
            }
            
            int directoryRmv = 0;
            pathToDelete = productsStitchTempPath;
            pathToDelete2 = stitchedFolderPath;
            
            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
            [controllerSubProcesses fileRenameLayerTwo:directoryRmv];
            
            ofstream oin;
            
            if (autoBatchMode == 1){
                backUpFolderSavePath = backUpDataPath+"/"+bodyNameHold+"-10001";
                mkdir(backUpFolderSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                processFilePath = namedFilesPath+"/"+bodyNameHold+"-10001";
                
                directoryRmv = 1;
                pathToDelete = processFilePath;
                pathToDelete2 = backUpFolderSavePath;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses fileRenameLayerTwo:directoryRmv];
                
                rmdir(processFilePath.c_str());
            }
            else if (autoBatchMode == 2){
                backUpFolderSavePath = namedFilesPath+"/"+bodyNameHold+"-10001";
                
                directoryRmv = 2;
                pathToDelete = backUpFolderSavePath;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                
                rmdir (backUpFolderSavePath.c_str());
                
                if (processingIFStatus == 0){
                    for (int counter1 = 0; counter1 < batchProcessInfoCount/3; counter1++){
                        if (batchProcessInfo [counter1*3+1] == batchBodyName+"-10001"){
                            batchProcessInfo [counter1*3+2] = "1";
                            break;
                        }
                    }
                    
                    oin.open(batchProcessFolderPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < batchProcessInfoCount; counter1++) oin<<batchProcessInfo [counter1]<<endl;
                    
                    oin.close();
                }
            }
            else if (autoBatchMode == 3){
                directoryRmv = 0;
                pathToDelete = productsFocalTempPath;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses fileDeleteLayerThree:directoryRmv];
            }
            
            [currentTimePoint setStringValue:@"1"];
        }
    }
    
    //==========Auto run==========
    //----For file upload----
    if (autoBatchMode == 1 && initialRunStatus == "8" && lastPurgeFlag == 0){
        if (runStatusFileUpLoad == 1){
            runStatusFileUpLoad = 2;
            monitorTimerControlAutoFileUpload = 1;
        }
        else if (monitorTimerControlAutoFileUpload >= 1 && monitorTimerControlAutoFileUpload <= 10){
            monitorTimerControlAutoFileUpload++;
        }
        else if (monitorTimerControlAutoFileUpload == 11){
            monitorTimerControlAutoFileUpload = 0;
            launchCheck = 0;
        }
        else if (fileUpLoadFlag == 1 && runStatusFileUpLoad > 0){
            fileUpLoadFlag = 0;
            
            [fileUpLoadStatusOn setTextColor:[NSColor magentaColor]];
            [fileUpLoadStatusOn setStringValue:@"File up-loading"];
            [fileUpLoadStatus setTextColor:[NSColor magentaColor]];
            [fileUpLoadStatus setStringValue:@"On"];
        }
        else if (fileUpLoadFlag == 2 && runStatusFileUpLoad == 4){
            string getString;
            
            ifstream fin;
            fin.open(warningFLPath.c_str(),ios::in);
            
            if (fin.is_open()){
                getline(fin, getString);
                
                if (consoleWarningCount+5 > consoleWarningLimit) [self warningUpDate];
                arrayConsoleWarning [consoleWarningCount] = getString, consoleWarningCount++;
                
                if (getString == "[FL] New IF is Found: Perform IF Merge and Start New IF") newIFFoundFlag = 1;
                
                fin.close();
                
                remove (warningFLPath.c_str());
                
                consolePage = 0;
                consoleDisplayCall = 1;
            }
            
            if (newIFFoundFlag == 1){
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses parameterSave];
            }
            
            runStatusFileUpLoad = 0;
            fileUpLoadFlag = 0;
            fileTransferProgress  = 0;
            
            [fileUpLoadStatusOn setTextColor:[NSColor blueColor]];
            [fileUpLoadStatusOn setStringValue:@"File up-loading"];
            [fileUpLoadStatus setTextColor:[NSColor blueColor]];
            [fileUpLoadStatus setStringValue:@"Off"];
        }
    }
    
    if (autoBatchMode == 1 && initialRunStatus == "8"){
        if (processLoopMonitor == 0 && runStatusFileUpLoad > 0){
            fileTransferProgress  = 1;
            processLoopMonitor = 1;
        }
        else if (processLoopMonitor == 3 && runStatusFileUpLoad > 0) processLoopMonitor = 4;
        else if (processLoopMonitor == 5 && runStatusFileUpLoad > 0) processLoopMonitor = 0;
    }
    
    //----For file Focal and Contrast----
    if (autoRunOnOff == 1 && autoProcessCommit == "1"){
        if (runStatusFocalImage == 1){
            runStatusFocalImage = 2;
            
            if (monitorTimerControlAutoFocalContrast == 1) monitorTimerControlAutoFocalContrast = 2;
            else monitorTimerControlAutoFocalContrast = 1;
        }
        
        if (runStatusContrast == 1){
            runStatusContrast = 2;
            
            if (monitorTimerControlAutoFocalContrast == 1) monitorTimerControlAutoFocalContrast = 2;
            else monitorTimerControlAutoFocalContrast = 1;
        }
        
        if (monitorTimerControlAutoFocalContrast == 1 || monitorTimerControlAutoFocalContrast == 2){
            if (monitorTimerControlAutoFocalContrast == 2) monitorTimerControlAutoFocalContrast = 3;
        }
        else if (monitorTimerControlAutoFocalContrast >= 3 && monitorTimerControlAutoFocalContrast <= 10){
            monitorTimerControlAutoFocalContrast++;
        }
        else if (monitorTimerControlAutoFocalContrast == 11){
            monitorTimerControlAutoFocalContrast = 0;
            launchCheck = 0;
        }
        else if (contrastSetFlag == 1 || focalImageFlag == 1){
            contrastSetFlag = 0;
            focalImageFlag = 0;
            
            [focalImageStatusOn setTextColor:[NSColor magentaColor]];
            [focalImageStatusOn setStringValue:@"Focal Image Sel."];
            [focalImageStatus setTextColor:[NSColor magentaColor]];
            [focalImageStatus setStringValue:@"On"];
            
            [contrastSetStatusOn setTextColor:[NSColor magentaColor]];
            [contrastSetStatusOn setStringValue:@"Contrast Set"];
            [contrastSetStatus setTextColor:[NSColor magentaColor]];
            [contrastSetStatus setStringValue:@"On"];
        }
        else if ((focalImageFlag == 2 && autoStepCount != 4) || (contrastSetFlag == 2 && autoStepCount != 4)){
            runStatusFocalImage = 0;
            runStatusContrast = 0;
            autoStepCount = 0;
            
            [focalImageStatusOn setTextColor:[NSColor blueColor]];
            [focalImageStatusOn setStringValue:@"Focal Image Sel."];
            [focalImageStatus setTextColor:[NSColor blueColor]];
            [focalImageStatus setStringValue:@"Off"];
            
            [contrastSetStatusOn setTextColor:[NSColor blueColor]];
            [contrastSetStatusOn setStringValue:@"Contrast Set"];
            [contrastSetStatus setTextColor:[NSColor blueColor]];
            [contrastSetStatus setStringValue:@"Off"];
            
            if (focalImageFlag == 2){
                if (consoleWarningCount+5 > consoleWarningLimit) [self warningUpDate];
                arrayConsoleWarning [consoleWarningCount] = "[AU] Focal Sel. Crash", consoleWarningCount++;
                
                consolePage = 0;
                consoleDisplayCall = 1;
                
                ofstream oin;
                
                for (int counter1 = 0; counter1 < 10; counter1++){
                    oin.open(instructionCSPath.c_str(), ios::out);
                    
                    if (oin.is_open()){
                        oin<<"Exit"<<endl;
                        oin.close();
                        break;
                    }
                }
            }
            if (contrastSetFlag == 2){
                if (consoleWarningCount+5 > consoleWarningLimit) [self warningUpDate];
                arrayConsoleWarning [consoleWarningCount] = "[AU] Contrast Set Crash", consoleWarningCount++;
                
                consolePage = 0;
                consoleDisplayCall = 1;
                
                ofstream oin;
                
                for (int counter1 = 0; counter1 < 10; counter1++){
                    oin.open(instructionFIPath2.c_str(), ios::out);
                    
                    if (oin.is_open()){
                        oin<<"Exit"<<endl;
                        oin.close();
                        break;
                    }
                }
            }
            
            focalContrastRetryCount++;
            
            if (focalContrastRetryCount <= 2) focalContrastRestartFlag = 1;
            else focalContrastRetryCount = 0;
            
            focalImageFlag = 0;
            contrastSetFlag = 0;
            autoRunOnOff = 0;
            
            [autoStatus setStringValue:@"Hold"];
        }
        else if ((focalImageFlag == 2 && autoStepCount == 4) || (contrastSetFlag == 2 && autoStepCount == 4)){
            runStatusFocalImage = 0;
            focalImageFlag = 0;
            
            [focalImageStatusOn setTextColor:[NSColor blueColor]];
            [focalImageStatusOn setStringValue:@"Focal Image Sel."];
            [focalImageStatus setTextColor:[NSColor blueColor]];
            [focalImageStatus setStringValue:@"Off"];
            
            runStatusContrast = 0;
            contrastSetFlag = 0;
            
            [contrastSetStatusOn setTextColor:[NSColor blueColor]];
            [contrastSetStatusOn setStringValue:@"Contrast Set"];
            [contrastSetStatus setTextColor:[NSColor blueColor]];
            [contrastSetStatus setStringValue:@"Off"];
            
            autoStepCount = 0;
            autoRunOnOff = 0;
            
            [autoStatus setStringValue:@"Hold"];
            
            //cout<<focalImageFlag<<" "<<focalImageFlag<<" "<<autoStepCount<<" "<<autoRunOnOff<<"  "<<runStatusContrast<<" "<<contrastSetFlag<<" status1"<<endl;
        }
    }
    
    //==========BatchBackup auto start==========
    if (batchBackupOnOff == 1 && batchBackupOperationCommit == "1"){
        if (runStatusFocalImage == 1){
            runStatusFocalImage = 2;
            
            if (monitorTimerControlBatchBack == 1) monitorTimerControlBatchBack = 2;
            else monitorTimerControlBatchBack = 1;
        }
        
        if (runStatusContrast == 1){
            runStatusContrast = 2;
            
            if (monitorTimerControlBatchBack == 1) monitorTimerControlBatchBack = 2;
            else monitorTimerControlBatchBack = 1;
        }
        
        if (monitorTimerControlBatchBack == 1 || monitorTimerControlBatchBack == 2){
            if (monitorTimerControlBatchBack == 2) monitorTimerControlBatchBack = 3;
        }
        else if (monitorTimerControlBatchBack >= 3 && monitorTimerControlBatchBack <= 10){
            monitorTimerControlBatchBack++;
        }
        else if (monitorTimerControlBatchBack == 11){
            monitorTimerControlBatchBack = 0;
            launchCheck = 0;
        }
        else if (contrastSetFlag == 1 || focalImageFlag == 1){
            contrastSetFlag = 0;
            focalImageFlag = 0;
            
            [focalImageStatusOn setTextColor:[NSColor magentaColor]];
            [focalImageStatusOn setStringValue:@"Focal Image Sel."];
            [focalImageStatus setTextColor:[NSColor magentaColor]];
            [focalImageStatus setStringValue:@"On"];
            
            [contrastSetStatusOn setTextColor:[NSColor magentaColor]];
            [contrastSetStatusOn setStringValue:@"Contrast Set"];
            [contrastSetStatus setTextColor:[NSColor magentaColor]];
            [contrastSetStatus setStringValue:@"On"];
        }
        else if ((focalImageFlag == 2 && autoStepCount != 4) || (contrastSetFlag == 2 && autoStepCount != 4)){
            runStatusFocalImage = 0;
            runStatusContrast = 0;
            autoStepCount = 0;
            
            [focalImageStatusOn setTextColor:[NSColor blueColor]];
            [focalImageStatusOn setStringValue:@"Focal Image Sel."];
            [focalImageStatus setTextColor:[NSColor blueColor]];
            [focalImageStatus setStringValue:@"Off"];
            
            [contrastSetStatusOn setTextColor:[NSColor blueColor]];
            [contrastSetStatusOn setStringValue:@"Contrast Set"];
            [contrastSetStatus setTextColor:[NSColor blueColor]];
            [contrastSetStatus setStringValue:@"Off"];
            
            if (focalImageFlag == 2){
                if (consoleWarningCount+5 > consoleWarningLimit) [self warningUpDate];
                arrayConsoleWarning [consoleWarningCount] = "[BB] Focal Sel. Crash", consoleWarningCount++;
                
                consolePage = 0;
                consoleDisplayCall = 1;
                
                ofstream oin;
                
                for (int counter1 = 0; counter1 < 10; counter1++){
                    oin.open(instructionCSPath.c_str(), ios::out);
                    
                    if (oin.is_open()){
                        oin<<"Exit"<<endl;
                        oin.close();
                        break;
                    }
                }
            }
            
            if (contrastSetFlag == 2){
                if (consoleWarningCount+5 > consoleWarningLimit) [self warningUpDate];
                arrayConsoleWarning [consoleWarningCount] = "[BB] Contrast Set Crash", consoleWarningCount++;
                
                consolePage = 0;
                consoleDisplayCall = 1;
                
                ofstream oin;
                
                for (int counter1 = 0; counter1 < 10; counter1++){
                    oin.open(instructionFIPath2.c_str(), ios::out);
                    
                    if (oin.is_open()){
                        oin<<"Exit"<<endl;
                        oin.close();
                        break;
                    }
                }
            }
            
            if (backupBatchWait2 == 91) backupBatchWait2 = 93;
            
            focalImageFlag = 0;
            contrastSetFlag = 0;
            batchBackupOnOff = 0;
            autoStepCount = 200;
            
            [batchStartStatus1 setStringValue:@"Hold"];
        }
        else if ((focalImageFlag == 2 && autoStepCount == 4) || (contrastSetFlag == 2 && autoStepCount == 4)){
            runStatusFocalImage = 0;
            focalImageFlag = 0;
            
            [focalImageStatusOn setTextColor:[NSColor blueColor]];
            [focalImageStatusOn setStringValue:@"Focal Image Sel."];
            [focalImageStatus setTextColor:[NSColor blueColor]];
            [focalImageStatus setStringValue:@"Off"];
            
            runStatusContrast = 0;
            contrastSetFlag = 0;
            
            [contrastSetStatusOn setTextColor:[NSColor blueColor]];
            [contrastSetStatusOn setStringValue:@"Contrast Set"];
            [contrastSetStatus setTextColor:[NSColor blueColor]];
            [contrastSetStatus setStringValue:@"Off"];
            
            autoStepCount = 0;
            batchBackupOnOff = 0;
            
            [batchStartStatus1 setStringValue:@"Hold"];
            
            //cout<<focalImageFlag<<" "<<focalImageFlag<<" "<<autoStepCount<<" "<<autoRunOnOff<<"  "<<runStatusContrast<<" "<<contrastSetFlag<<" status2"<<endl;
        }
    }
    
    //==========BatchImage auto start==========
    if (batchImageOnOff == 1 && batchImageOperationCommit == "1"){
        if (runStatusContrast == 1){
            runStatusContrast = 2;
            monitorTimerControlBatchImage = 1;
        }
        else if (monitorTimerControlBatchImage >= 1 && monitorTimerControlBatchImage <= 10){
            monitorTimerControlBatchImage++;
        }
        else if (monitorTimerControlBatchImage == 11){
            monitorTimerControlBatchImage = 0;
            launchCheck = 0;
        }
        else if (contrastSetFlag == 1){
            contrastSetFlag = 0;
            
            [contrastSetStatusOn setTextColor:[NSColor magentaColor]];
            [contrastSetStatusOn setStringValue:@"Contrast Set"];
            [contrastSetStatus setTextColor:[NSColor magentaColor]];
            [contrastSetStatus setStringValue:@"On"];
        }
        else if (contrastSetFlag == 2 && autoStepCount != 4){
            runStatusContrast = 0;
            autoStepCount = 0;
            
            [contrastSetStatusOn setTextColor:[NSColor blueColor]];
            [contrastSetStatusOn setStringValue:@"Contrast Set"];
            [contrastSetStatus setTextColor:[NSColor blueColor]];
            [contrastSetStatus setStringValue:@"Off"];
            
            if (contrastSetFlag == 2){
                if (consoleWarningCount+5 > consoleWarningLimit) [self warningUpDate];
                arrayConsoleWarning [consoleWarningCount] = "[BI] Contrast Set Crash", consoleWarningCount++;
                
                consolePage = 0;
                consoleDisplayCall = 1;
            }
            
            contrastSetFlag = 0;
            batchImageOnOff = 0;
            autoStepCount = 200;
            
            [batchStartStatus2 setStringValue:@"Hold"];
        }
        else if (contrastSetFlag == 2 && autoStepCount == 4){
            focalImageFlag = 0;
            runStatusContrast = 0;
            contrastSetFlag = 0;
            
            [contrastSetStatusOn setTextColor:[NSColor blueColor]];
            [contrastSetStatusOn setStringValue:@"Contrast Set"];
            [contrastSetStatus setTextColor:[NSColor blueColor]];
            [contrastSetStatus setStringValue:@"Off"];
            
            autoStepCount = 0;
            batchImageOnOff = 0;
            
            [batchStartStatus2 setStringValue:@"Hold"];
            
            //cout<<focalImageFlag<<" "<<focalImageFlag<<" "<<autoStepCount<<" "<<autoRunOnOff<<"  "<<runStatusContrast<<" "<<contrastSetFlag<<" status3"<<endl;
        }
    }
    
    //==========Auto/Batch backup Focal/Contrast during the holding==========
    if ((autoRunOnOff == 0 && autoProcessCommit == "1") || (batchBackupOnOff == 0 && batchBackupOperationCommit == "1")){
        if (runStatusFocalImage == 1){
            runStatusFocalImage = 2;
            monitorTimerControlAutoBackFocalHold = 1;
        }
        
        if (runStatusContrast == 1){
            runStatusContrast = 2;
            monitorTimerControlAutoBackFocalHold = 1;
        }
        
        if (monitorTimerControlAutoBackFocalHold == 1 && monitorTimerControlAutoBackFocalHold == 1){
            monitorTimerControlAutoBackFocalHold = 3;
        }
        else if (monitorTimerControlAutoBackFocalHold >= 3 && monitorTimerControlAutoBackFocalHold <= 10){
            monitorTimerControlAutoBackFocalHold++;
        }
        else if (monitorTimerControlAutoBackFocalHold == 11){
            monitorTimerControlAutoBackFocalHold = 0;
            launchCheck = 0;
        }
        else if (focalImageFlag == 1){
            focalImageFlag = 0;
            
            [focalImageStatus setStringValue:@"On"];
        }
        else if (focalImageFlag == 2){
            focalImageFlag = 0;
            runStatusFocalImage = 0;
            
            [focalImageStatus setStringValue:@"Off"];
        }
        else if (focalImageFlag == 3){
            remove (instructionFIPath.c_str());
            remove (instructionFIPath2.c_str());
            
            consolePage = 2;
            [self consoleDisplay];
            
            focalImageFlag = 0;
        }
        
        if (monitorTimerControlAutoBackContrastHold == 1 && contrastSetFlag == 1){
            monitorTimerControlAutoBackContrastHold = 3;
        }
        else if (monitorTimerControlAutoBackContrastHold >= 3 && monitorTimerControlAutoBackContrastHold <= 10){
            monitorTimerControlAutoBackContrastHold++;
        }
        else if (monitorTimerControlAutoBackContrastHold == 11){
            monitorTimerControlAutoBackContrastHold = 0;
            launchCheck = 0;
        }
        else if (contrastSetFlag == 1){
            contrastSetFlag = 0;
            
            [contrastSetStatus setStringValue:@"On"];
        }
        else if (contrastSetFlag == 2){
            runStatusContrast = 0;
            contrastSetFlag = 0;
            
            [contrastSetStatus setStringValue:@"Off"];
        }
        else if (contrastSetFlag == 3){
            remove (instructionAPPath.c_str());
            
            consolePage = 3;
            [self consoleDisplay];
            
            contrastSetFlag = 0;
        }
    }
    
    //==========Batch Image Contrast during the holding==========
    if (batchImageOnOff == 0 && batchImageOperationCommit == "1"){
        if (runStatusContrast == 1){
            runStatusContrast = 2;
            monitorTimerControlBackImageContrastHold = 1;
        }
        else if (monitorTimerControlBackImageContrastHold >= 1 && monitorTimerControlBackImageContrastHold <= 10){
            monitorTimerControlBackImageContrastHold++;
        }
        else if (monitorTimerControlBackImageContrastHold == 11){
            monitorTimerControlBackImageContrastHold = 0;
            launchCheck = 0;
        }
        else if (contrastSetFlag == 1){
            contrastSetFlag = 0;
            
            [contrastSetStatus setStringValue:@"On"];
        }
        else if (contrastSetFlag == 2){
            runStatusContrast = 0;
            contrastSetFlag = 0;
            
            [contrastSetStatus setStringValue:@"Off"];
        }
        else if (contrastSetFlag == 3){
            remove (instructionAPPath.c_str());
            
            consolePage = 3;
            [self consoleDisplay];
            
            contrastSetFlag = 0;
        }
    }
    
    //==========BatchBackup Initial upload==========
    if (backupBatchWait1 == 1){
        backupBatchWait1 = 2;
        [initialRun setStringValue:@"Copying"];
    }
    else if (backupBatchWait1 < 4 && backupBatchWait1 >= 2) backupBatchWait1++;
    else if (backupBatchWait1 == 4){
        backupBatchWait1 = 8;
        
        int fileNoCount = 0;
        string entry;
        
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(backupBatchWaitPathName.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store") fileNoCount++;
            }
            
            closedir(dir);
        }
        
        if (forBackUpNamesStatus == 1) delete [] arrayForBackUpNames;
        arrayForBackUpNames = new string [fileNoCount+10];
        
        forbackUpNamesCount = 0;
        forBackUpNamesCountIncrement = 0;
        
        dir = opendir(backupBatchWaitPathName.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store") arrayForBackUpNames [forbackUpNamesCount] = entry, forbackUpNamesCount++;
            }
            
            closedir(dir);
        }
    }
    else if (backupBatchWait1 == 8){
        string backUpFolderSavePath = namedFilesPath+"/"+bodyNameHold+"-10001";
        mkdir(backUpFolderSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        [backSave startAnimation:self];
        
        if (forbackUpNamesCount != forBackUpNamesCountIncrement){
            string entry = arrayForBackUpNames [forBackUpNamesCountIncrement];
            
            //----Old format adapt----
            string extractString = entry.substr(entry.find("_")+1, entry.find("-")-entry.find("_")-1);
            string extractString2 = entry.substr(0, entry.find("_"));
            string extractString3 = entry.substr(entry.find("-")+1);
            extractString = to_string(atoi(extractString.c_str()));
            
            if (extractString.length() == 1) extractString = "000"+extractString;
            else if (extractString.length() == 2) extractString = "00"+extractString;
            else if (extractString.length() == 3) extractString = "0"+extractString;
            //-------------
            
            string copyPath1 = backupBatchWaitPathName+"/"+entry;
            string copyPath2;
            
            if (processingIFStatus == 0) copyPath2 = backUpFolderSavePath+"/"+extractString2+"_"+extractString+"-"+extractString3;
            else if (processingIFStatus == 1){
                extractString3 = extractString3.substr(0, extractString3.find(".TIF"));
                copyPath2 = backUpFolderSavePath+"/"+extractString2+"_"+extractString+"-"+extractString3+".tif";
            }
            
            struct stat sizeOfFile;
            
            long sizeForCopy = 0;
            
            if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                ifstream infile (copyPath1.c_str(), ifstream::binary);
                ofstream outfile (copyPath2.c_str(), ofstream::binary);
                
                char *buffer = new char[sizeForCopy];
                infile.read (buffer, sizeForCopy);
                outfile.write (buffer, sizeForCopy);
                delete [] buffer;
                
                outfile.close();
                infile.close();
                
                forBackUpNamesCountIncrement++;
            }
        }
        else{
            
            backupBatchWait1 = 9;
            delete [] arrayForBackUpNames;
            
            forBackUpNamesStatus = 0;
            
            [backSave stopAnimation:self];
        }
    }
    else if (backupBatchWait1 == 9){
        [initialRun setTextColor:[NSColor blueColor]];
        [initialRun setStringValue:@"FIS"];
        initialRunStatus = "4";
        
        [initialRunOn setTextColor:[NSColor blueColor]];
        [initialRunOn setStringValue:@"Initial Run"];
        
        backupBatchWait1 = 0;
    }
    
    //==========BatchBackup Auto file upload==========
    if (backupBatchWait2 == 1){
        backupBatchWait2 = 2;
        [batchStartStatus1 setStringValue:@"On"];
    }
    else if (backupBatchWait2 < 4 && backupBatchWait2 >= 2) backupBatchWait2++;
    else if (backupBatchWait2 == 4 && runStatusFocalImage == 3){
        backupBatchWait2 = 91;
        
        int fileNoCount = 0;
        string entry;
        
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(backupBatchWaitPathName.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store") fileNoCount++;
            }
            
            closedir(dir);
        }
        
        if (forBackUpNamesStatus == 1) delete [] arrayForBackUpNames;
        arrayForBackUpNames = new string [fileNoCount+10];
        
        forbackUpNamesCount = 0;
        forBackUpNamesCountIncrement = 0;
        
        dir = opendir(backupBatchWaitPathName.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store") arrayForBackUpNames [forbackUpNamesCount] = entry, forbackUpNamesCount++;
            }
            
            closedir(dir);
        }
    }
    else if (backupBatchWait2 == 91 && runStatusFocalImage == 3){
        string backUpFolderSavePath = namedFilesPath+"/"+smallestFolderName;
        mkdir(backUpFolderSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        [backSave startAnimation:self];
        
        if (forbackUpNamesCount != forBackUpNamesCountIncrement){
            string entry = arrayForBackUpNames [forBackUpNamesCountIncrement];
            
            //----Old format adapt----
            string extractString = entry.substr(entry.find("_")+1, entry.find("-")-entry.find("_")-1);
            string extractString2 = entry.substr(0, entry.find("_"));
            string extractString3 = entry.substr(entry.find("-")+1);
            extractString = to_string(atoi(extractString.c_str()));
            
            if (extractString.length() == 1) extractString = "000"+extractString;
            else if (extractString.length() == 2) extractString = "00"+extractString;
            else if (extractString.length() == 3) extractString = "0"+extractString;
            //-------------
            
            string copyPath1 = backupBatchWaitPathName+"/"+entry;
            string copyPath2;
            
            if (processingIFStatus == 0) copyPath2 = backUpFolderSavePath+"/"+extractString2+"_"+extractString+"-"+extractString3;
            else if (processingIFStatus == 1){
                extractString3 = extractString3.substr(0, extractString3.find(".TIF"));
                copyPath2 = backUpFolderSavePath+"/"+extractString2+"_"+extractString+"-"+extractString3+".tif";
            }
            
            struct stat sizeOfFile;
            
            long sizeForCopy = 0;
            
            if (stat(copyPath1.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                ifstream infile (copyPath1.c_str(), ifstream::binary);
                ofstream outfile (copyPath2.c_str(), ofstream::binary);
                
                char *buffer = new char[sizeForCopy];
                infile.read (buffer, sizeForCopy);
                outfile.write (buffer, sizeForCopy);
                delete [] buffer;
                
                outfile.close();
                infile.close();
                
                forBackUpNamesCountIncrement++;
            }
        }
        else{
            
            backupBatchWait2 = 92;
            delete [] arrayForBackUpNames;
            
            forBackUpNamesStatus = 0;
            
            [backSave stopAnimation:self];
        }
    }
    else if (backupBatchWait2 == 92){
        autoStepCount = -1;
        backupBatchWait2 = 0;
    }
    else if (backupBatchWait2 == 93){
        delete [] arrayForBackUpNames;
        
        forBackUpNamesStatus = 0;
        
        [backSave stopAnimation:self];
        autoStepCount = -1;
        backupBatchWait2 = 0;
    }
    
    //==========Last Purge==========
    if (autoBatchMode == 1 && initialRunStatus == "8" && lastPurgeFlag >= 1){
        if (runStatusFileUpLoad == 1 && lastPurgeFlag == 1){
            lastPurgeFlag = 3;
            monitorTimerControlLastPurge = 1;
            purgeCount = 1;
        }
        else if (monitorTimerControlLastPurge >= 1 && monitorTimerControlLastPurge <= 10){
            monitorTimerControlLastPurge++;
        }
        else if (monitorTimerControlLastPurge == 11){
            monitorTimerControlLastPurge = 12;
        }
        else if (runStatusFileUpLoad == 1 && lastPurgeFlag == 3){
            runStatusFileUpLoad = 2;
            monitorTimerControlLastPurge = 13;
        }
        else if (monitorTimerControlLastPurge >= 13 && monitorTimerControlLastPurge <= 22){
            monitorTimerControlLastPurge++;
        }
        else if (monitorTimerControlLastPurge == 23){
            monitorTimerControlLastPurge = 0;
            launchCheck = 0;
        }
        else if (fileUpLoadFlag == 1 && runStatusFileUpLoad > 0 && lastPurgeFlag == 4){
            fileUpLoadFlag = 0;
            
            [fileUpLoadStatusOn setTextColor:[NSColor magentaColor]];
            [fileUpLoadStatusOn setStringValue:@"File up-loading"];
            [fileUpLoadStatus setTextColor:[NSColor magentaColor]];
            [fileUpLoadStatus setStringValue:@"On"];
            
            [lastPurgeDisplay setTextColor:[NSColor blackColor]];
            [lastPurgeDisplay setStringValue:@"Last Purge"];
        }
        else if (fileUpLoadFlag == 2 && runStatusFileUpLoad == 4){
            runStatusFileUpLoad = 0;
            fileUpLoadFlag = 0;
            lastPurgeFlag = 0;
            purgeCount = 0;
            
            remove(loadingCompletePath.c_str());
            
            [fileUpLoadStatusOn setTextColor:[NSColor blueColor]];
            [fileUpLoadStatusOn setStringValue:@"File up-loading"];
            [fileUpLoadStatus setTextColor:[NSColor blueColor]];
            [fileUpLoadStatus setStringValue:@"Off"];
            [lastPurgeDisplay setTextColor:[NSColor blackColor]];
            [lastPurgeDisplay setStringValue:@"Last Purge"];
        }
        
        if (purgeCount == 4){
            lastPurgeFlag = 0;
            purgeCount = 0;
            processLoopMonitor = 0;
            remove(loadingCompletePath.c_str());
        }
    }
    
    //==========Focal Contrast relaunch==========
    if (focalContrastRestartFlag == 1 && focalImageFlag == 0 && contrastSetFlag == 0){
        focalContrastRestartFlag = 2;
    }
    else if (focalContrastRestartFlag >= 2 && focalContrastRestartFlag < 30 && focalImageFlag == 0 && contrastSetFlag == 0){
        focalContrastRestartFlag++;
    }
    else if (focalContrastRestartFlag == 30 && focalImageFlag == 0 && contrastSetFlag == 0){
        focalContrastRestartFlag = 61;
        
        if (consoleWarningCount+5 > consoleWarningLimit) [self warningUpDate];
        arrayConsoleWarning [consoleWarningCount] = "[AU] Focal Image Selection Restart", consoleWarningCount++;
        arrayConsoleWarning [consoleWarningCount] = "[AU] Contrast Set Restart", consoleWarningCount++;
        
        consolePage = 0;
        consoleDisplayCall = 1;
        
        autoRunOnOff = 1;
        [autoStatus setStringValue:@"On"];
        
        remove (instructionFIPath.c_str());
        remove (instructionFIPath2.c_str());
        remove (instructionAPPath.c_str());
        remove (instructionCSPath.c_str());
        remove (instructionNamePath.c_str());
        
        fileUploadStartCount = 0;
        focalContrastRetryCount = 0;
        runStatusFocalImage = 1;
        runStatusContrast = 1;
        autoStepCount = 0;
        
        string launchProgramFocal = launchProgramPath+"/"+"Focal_Image_Selection.app";
        string launchProgramContrast = launchProgramPath+"/"+"Contrast_Set.app";
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToAutoProcess object:self];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCommFocal object:self];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCommContrast object:self];
        
        NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
        [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramFocal.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
        [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramContrast.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
        
        launchCheck = 1;
        focalContrastRestartFlag = 62;
    }
    else if (focalContrastRestartFlag == 62) focalContrastRestartFlag = 0;
    
    //cout<< autoBatchMode<<" "<<initialRunStatus<<" "<<runStatusFocalImage<<" "<<runStatusContrast<<" "<<runStatusFileUpLoad<<endl;
    
    //==========File upload relaunch==========
    if (autoBatchMode == 1 && initialRunStatus == "8" && lastPurgeFlag == 0 && processingIFStatus == 0 && runStatusFocalImage >= 2 && runStatusContrast >= 2 && runStatusFileUpLoad == 0 && fileUploadStartCount < 300 && lastPurgeSetFlag == 0){
        fileUploadStartCount++;
    }
    else if (autoBatchMode == 1 && initialRunStatus == "8" && lastPurgeFlag == 0 && processingIFStatus == 0 && runStatusFocalImage >= 2 && runStatusContrast >= 2 && runStatusFileUpLoad == 0 && fileUploadStartCount == 300 && lastPurgeSetFlag == 0){
        runStatusFileUpLoad = 1;
        
        arrayConsoleWarning [consoleWarningCount] = "[AU] FileUpload Auto Start", consoleWarningCount++;
        
        consolePage = 0;
        consoleDisplayCall = 1;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCommFile object:self];
        
        string launchProgramFileUpLoad = launchProgramPath+"/"+"FileUpLoad.app";
        
        NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
        [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramFileUpLoad.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
        
        launchCheck = 1;
    }
    else if (autoBatchMode == 1 && initialRunStatus == "8" && lastPurgeFlag == 0 && processingIFStatus == 0 && runStatusFocalImage >= 2 && runStatusContrast >= 2 && runStatusFileUpLoad != 0 && lastPurgeSetFlag == 0){
        fileUploadStartCount = 0;
    }
    
    //==========Net Connection check==========
    if (netCheckStatus == 1){
        int connectionCheck = 0;
        DIR *dir;
        
        dir = opendir(directoryPathForPC.c_str());
        
        if (dir != NULL){
            closedir(dir);
        }
        else connectionCheck = 1;
        
        dir = opendir(infoDirectoryPC.c_str());
        
        if (dir != NULL){
            closedir(dir);
        }
        else{
            
            if (connectionCheck == 1) connectionCheck = 3;
            else connectionCheck = 2;
        }
        
        if (connectionCheck != 0) connectionCheckCount++;
        else connectionCheckCount = 0;
        
        if (connectionCheckCount == 20){ //=======change to 200
            netCheckStatus = 2;
            netConnectionStatus = 1;
            connectionCheckCount = 0;
        }
    }
    
    //==========Net Reconnection==========
    if (netConnectionStatus == 1){
        netConnectionStatus = 2;
        string directoryDirectoryName = "nil";
        string infoDirectoryName = "nil";
        string extractedID;
        
        if ((int)directoryPathForPC.find("/Volumes/") != -1){
            directoryDirectoryName = directoryPathForPC.substr(directoryPathForPC.find("/Volumes/")+9);
            
            if ((int)directoryPathForPC.find("/") != -1) directoryDirectoryName = directoryDirectoryName.substr(0, directoryDirectoryName.find("/"));
            
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                
                if ((int)directoryDirectoryName.find(" ") != -1){
                    extractedID = directoryDirectoryName.substr(0, directoryDirectoryName.find(" "));
                    directoryDirectoryName = directoryDirectoryName.substr(directoryDirectoryName.find(" ")+1);
                    directoryDirectoryName = extractedID+"%20"+directoryDirectoryName;
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
        }
        
        if ((int)infoDirectoryPC.find("/Volumes/") != -1){
            infoDirectoryName = infoDirectoryPC.substr(infoDirectoryPC.find("/Volumes/")+9);
            
            if ((int)infoDirectoryPC.find("/") != -1) infoDirectoryName = infoDirectoryName.substr(0, infoDirectoryName.find("/"));
            
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                
                if ((int)infoDirectoryName.find(" ") != -1){
                    extractedID = infoDirectoryName.substr(0, infoDirectoryName.find(" "));
                    infoDirectoryName = infoDirectoryName.substr(infoDirectoryName.find(" ")+1);
                    infoDirectoryName = extractedID+"%20"+infoDirectoryName;
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
        }
        
        if (directoryDirectoryName != "nil" && infoDirectoryName != "nil" && directoryDirectoryName == infoDirectoryName){
            dataDirName = directoryDirectoryName;
            infoDirName = infoDirectoryName;
            
            netConnectionStatus = 3;
        }
        else if (directoryDirectoryName != "nil" && infoDirectoryName != "nil" && directoryDirectoryName != infoDirectoryName){
            dataDirName = directoryDirectoryName;
            infoDirName = infoDirectoryName;
            
            netConnectionStatus = 4;
        }
        else{
            
            netCheckStatus = 0;
            netConnectionStatus = 0;
            [netAutoCheckDisplay setStringValue:@"Directory Error"];
        }
    }
    else if (netConnectionStatus == 3){
        netConnectionStatus = 30;
        
        NSString *command1 = @"tell application \"Finder\" to open location \"smb://";
        NSString *command2 = @(netUsernameHold.c_str());
        NSString *command3 = @":";
        NSString *command4 = @(netPasswordHold.c_str());
        NSString *command5 = @"@";
        NSString *command6 = @(netAddressHold.c_str());
        NSString *command7 = @"/";
        NSString *command8 = @(dataDirName.c_str());
        NSString *command9 = @"\"";
        
        NSString *cmd = [NSString stringWithFormat:@"%@%@%@%@%@%@%@%@%@", command1, command2, command3, command4, command5, command6, command7, command8, command9];
        
        NSAppleScript* theScript = [[NSAppleScript alloc] initWithSource:cmd];
        [theScript executeAndReturnError:nil];
        
        netConnectionStatus = 40;
    }
    else if (netConnectionStatus >= 40 && netConnectionStatus < 500){
        netConnectionStatus++;
    }
    else if (netConnectionStatus == 500){
        netCheckStatus = 1;
        netConnectionStatus = 0;
    }
    else if (netConnectionStatus == 4){
        netConnectionStatus = 630;
        
        NSString *command1 = @"tell application \"Finder\" to open location \"smb://";
        NSString *command2 = @(netUsernameHold.c_str());
        NSString *command3 = @":";
        NSString *command4 = @(netPasswordHold.c_str());
        NSString *command5 = @"@";
        NSString *command6 = @(netAddressHold.c_str());
        NSString *command7 = @"/";
        NSString *command8 = @(dataDirName.c_str());
        NSString *command9 = @"\"";
        
        NSString *cmd = [NSString stringWithFormat:@"%@%@%@%@%@%@%@%@%@", command1, command2, command3, command4, command5, command6, command7, command8, command9];
        
        //NSLog (@"%@", cmd);
        
        NSAppleScript* theScript = [[NSAppleScript alloc] initWithSource:cmd];
        [theScript executeAndReturnError:nil];
        
        netConnectionStatus = 640;
    }
    else if (netConnectionStatus >= 640 && netConnectionStatus < 1000){
        netConnectionStatus++;
    }
    else if (netConnectionStatus == 1000){
        netConnectionStatus = 1630;
        
        NSString *command1 = @"tell application \"Finder\" to open location \"smb://";
        NSString *command2 = @(netUsernameHold.c_str());
        NSString *command3 = @":";
        NSString *command4 = @(netPasswordHold.c_str());
        NSString *command5 = @"@";
        NSString *command6 = @(netAddressHold.c_str());
        NSString *command7 = @"/";
        NSString *command8 = @(infoDirName.c_str());
        NSString *command9 = @"\"";
        
        NSString *cmd = [NSString stringWithFormat:@"%@%@%@%@%@%@%@%@%@", command1, command2, command3, command4, command5, command6, command7, command8, command9];
        
        NSAppleScript* theScript = [[NSAppleScript alloc] initWithSource:cmd];
        [theScript executeAndReturnError:nil];
        
        netConnectionStatus = 1640;
    }
    else if (netConnectionStatus >= 1640 && netConnectionStatus < 2000){
        netConnectionStatus++;
    }
    else if (netConnectionStatus == 2000){
        netCheckStatus = 1;
        netConnectionStatus = 0;
    }
    
    //==========FOV display==========
    if (fovNoDisplayFlag == 1){
        if ([totalFOV intValue] == atoi(totalFOVNoHold.c_str())){
            fovNoDisplayFlag = 0;
            [totalFOV setIntegerValue:atoi(totalFOVNoHold.c_str())];
            
            if (objectiveType == "1") [objectiveSet setStringValue:@"x10"];
            else if (objectiveType == "2") [objectiveSet setStringValue:@"x20"];
            else if (objectiveType == "3") [objectiveSet setStringValue:@"x40"];
        }
    }
    
    //==========Time Point display==========
    if (autoTotalCountDisplayCall == 1){
        autoTotalCountDisplayCall = 0;
        [currentTimePoint setIntegerValue:autoTotalCount];
    }
    
    //==========Table control==========
    if (tableCallCount == 1){
        tableCallCount = 0;
        rowIndexHold = tableCurrentRowHold;
    }
    
    if (tableCallCount > 1) tableCallCount = 0;
    
    //==========Monitor=========
    if (progressTiming == 6){
        progressTiming = 7;
        [backSave startAnimation:self];
    }
    else if (progressTiming == 8){
        progressTiming = 0;
        [backSave stopAnimation:self];
    }
}

-(void)summarySet{
    //----Summary----
    //1. BL, 2. Analysis name, 3. Computer name, 4. UserID, 5. Total FOV, 6. Last time point, 7. BL
    //8. Well 1 (name + fov), 9. Well 2 (name + fov), 10. Well 3 (name + fov), 11. Well 4 (name + fov), 12. Well 5 (name + fov)
    //13. Well 6 (name + fov), 14. Well 7 (name + fov), 15. Well 8 (name + fov), 16. Well 9 (name + fov), 17. Well 10 (name + fov)
    //18. Well 11 (name + fov), 19. Well 12 (name + fov), 20. Well 13 (name + fov), 21. Well 14 (name + fov), 22. Well 15 (name + fov)
    //23. Well 16 (name + fov), 24. BL, 25. Fluorescent1 (name + color), 26. Fluorescent2 (name + color), 27. Fluorescent3 (name + color)
    //28. Fluorescent4 (name + color), 29. Fluorescent3 (name + color), 30. Fluorescent6 (name + color), 31 Object
    
    if (summarySetCall == 3 || summarySetCall == 4){
        string getString;
        string treatmentString;
        string colorString;
        string fovNumberString;
        
        if (summarySetCall == 3){
            ifstream fin;
            fin.open(summaryDataPath.c_str(),ios::in);
            
            if (fin.is_open()){
                summaryListCount = 0;
                
                do{
                    
                    getline(fin, getString);
                    
                    if (getString != "") arraySummaryList [summaryListCount] = getString, summaryListCount++;
                    
                } while (getString != "");
                
                fin.close();
            }
            else{
                
                summaryListCount = 0;
                
                arraySummaryList [summaryListCount] = "BL", summaryListCount++;
                arraySummaryList [summaryListCount] = bodyNameHold, summaryListCount++;
                arraySummaryList [summaryListCount] = computerNameHold, summaryListCount++;
                arraySummaryList [summaryListCount] = userIDHold, summaryListCount++;
                arraySummaryList [summaryListCount] = totalFOVNoHold, summaryListCount++;
                arraySummaryList [summaryListCount] = "nil", summaryListCount++;
                arraySummaryList [summaryListCount] = "BL", summaryListCount++;
                
                for (int counter1 = 0; counter1 < 16; counter1++){
                    treatmentString = arrayNameList [counter1];
                    fovNumberString = to_string(arrayFOVNumberList [counter1]);
                    
                    if (treatmentString == "nil" && fovNumberString == "0") arraySummaryList [summaryListCount] = "nil", summaryListCount++;
                    else if (treatmentString != "nil" && fovNumberString == "0") arraySummaryList [summaryListCount] = treatmentString+" (nil)", summaryListCount++;
                    else if (treatmentString == "nil" && fovNumberString != "0") arraySummaryList [summaryListCount] = "nil ("+fovNumberString+")", summaryListCount++;
                    else arraySummaryList [summaryListCount] = treatmentString+" ("+fovNumberString+")", summaryListCount++;
                }
                
                arraySummaryList [summaryListCount] = "BL", summaryListCount++;
                
                int colorNo = fluorescentColor1;
                
                if (colorNo == 1) colorString = "Blue";
                else if (colorNo == 2) colorString = "Green";
                else if (colorNo == 3) colorString = "Yellow";
                else if (colorNo == 4) colorString = "Red";
                else if (colorNo == 5) colorString = "Magenta";
                else if (colorNo == 6) colorString = "Cyan";
                else if (colorNo == 7) colorString = "Orange";
                else if (colorNo == 8) colorString = "Purple";
                else if (colorNo == 9) colorString = "Sky";
                
                if (colorNo != 0) arraySummaryList [summaryListCount] = fluorescent1+" ("+colorString+")", summaryListCount++;
                else arraySummaryList [summaryListCount] = "nil", summaryListCount++;
                
                colorNo = fluorescentColor2;
                
                if (colorNo == 1) colorString = "Blue";
                else if (colorNo == 2) colorString = "Green";
                else if (colorNo == 3) colorString = "Yellow";
                else if (colorNo == 4) colorString = "Red";
                else if (colorNo == 5) colorString = "Magenta";
                else if (colorNo == 6) colorString = "Cyan";
                else if (colorNo == 7) colorString = "Orange";
                else if (colorNo == 8) colorString = "Purple";
                else if (colorNo == 9) colorString = "Sky";
                
                if (colorNo != 0) arraySummaryList [summaryListCount] = fluorescent2+" ("+colorString+")", summaryListCount++;
                else arraySummaryList [summaryListCount] = "nil", summaryListCount++;
                
                colorNo = fluorescentColor3;
                
                if (colorNo == 1) colorString = "Blue";
                else if (colorNo == 2) colorString = "Green";
                else if (colorNo == 3) colorString = "Yellow";
                else if (colorNo == 4) colorString = "Red";
                else if (colorNo == 5) colorString = "Magenta";
                else if (colorNo == 6) colorString = "Cyan";
                else if (colorNo == 7) colorString = "Orange";
                else if (colorNo == 8) colorString = "Purple";
                else if (colorNo == 9) colorString = "Sky";
                
                if (colorNo != 0) arraySummaryList [summaryListCount] = fluorescent3+" ("+colorString+")", summaryListCount++;
                else arraySummaryList [summaryListCount] = "nil", summaryListCount++;
                
                colorNo = fluorescentColor4;
                
                if (colorNo == 1) colorString = "Blue";
                else if (colorNo == 2) colorString = "Green";
                else if (colorNo == 3) colorString = "Yellow";
                else if (colorNo == 4) colorString = "Red";
                else if (colorNo == 5) colorString = "Magenta";
                else if (colorNo == 6) colorString = "Cyan";
                else if (colorNo == 7) colorString = "Orange";
                else if (colorNo == 8) colorString = "Purple";
                else if (colorNo == 9) colorString = "Sky";
                
                if (colorNo != 0) arraySummaryList [summaryListCount] = fluorescent4+" ("+colorString+")", summaryListCount++;
                else arraySummaryList [summaryListCount] = "nil", summaryListCount++;
                
                colorNo = fluorescentColor5;
                
                if (colorNo == 1) colorString = "Blue";
                else if (colorNo == 2) colorString = "Green";
                else if (colorNo == 3) colorString = "Yellow";
                else if (colorNo == 4) colorString = "Red";
                else if (colorNo == 5) colorString = "Magenta";
                else if (colorNo == 6) colorString = "Cyan";
                else if (colorNo == 7) colorString = "Orange";
                else if (colorNo == 8) colorString = "Purple";
                else if (colorNo == 9) colorString = "Sky";
                
                if (colorNo != 0) arraySummaryList [summaryListCount] = fluorescent5+" ("+colorString+")", summaryListCount++;
                else arraySummaryList [summaryListCount] = "nil", summaryListCount++;
                
                colorNo = fluorescentColor6;
                
                if (colorNo == 1) colorString = "Blue";
                else if (colorNo == 2) colorString = "Green";
                else if (colorNo == 3) colorString = "Yellow";
                else if (colorNo == 4) colorString = "Red";
                else if (colorNo == 5) colorString = "Magenta";
                else if (colorNo == 6) colorString = "Cyan";
                else if (colorNo == 7) colorString = "Orange";
                else if (colorNo == 8) colorString = "Purple";
                else if (colorNo == 9) colorString = "Sky";
                
                if (colorNo != 0) arraySummaryList [summaryListCount] = fluorescent6+" ("+colorString+")", summaryListCount++;
                else arraySummaryList [summaryListCount] = "nil", summaryListCount++;
                
                arraySummaryList [summaryListCount] = "BL", summaryListCount++;
                
                if (objectiveType == "1") arraySummaryList [summaryListCount] = "x10", summaryListCount++;
                else if (objectiveType == "2") arraySummaryList [summaryListCount] = "x20", summaryListCount++;
                else if (objectiveType == "3") arraySummaryList [summaryListCount] = "x40", summaryListCount++;
                else arraySummaryList [summaryListCount] = "nil", summaryListCount++;
            }
        }
        
        //for (int counterA = 0; counterA < summaryListCount; counterA++) cout<< arraySummaryList [counterA]<<"  Summary"<<endl;
        
        //----For Call 1 and 2, save summary----
        ofstream oin;
        oin.open(summaryDataPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 < summaryListCount; counter1++) oin<<arraySummaryList [counter1]<<endl;
        
        oin.close();
        
        summarySetCall = 0;
        tableViewCall = 1;
        tableViewPage = 0;
    }
}

-(IBAction)refresh:(id)sender{
    int callType = 1;
    
    [backSave startAnimation:self];
    [self refreshMain:callType];
    [backSave stopAnimation:self];
}

-(void)refreshMain:(int)callType{
    if (autoRunOnOff == 0 && batchBackupOnOff == 0 && batchImageOnOff == 0){
        if (runStatusXYMap >= 1 || runStatusFileUpLoad >= 1 || runStatusTreatmentNameSet >= 1 || runStatusFocalImage >= 1 || runStatusContrast >= 1){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Stop Sub Processes"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            string messageString = "";
            
            if (processingIFStatus != 1) messageString = "On going processing will be terminated";
            else messageString = "On going processing will be terminated. IF merge is not performed. OK?";
            
            NSString *message = @(messageString.c_str());
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert addButtonWithTitle:@"Cancel"];
            [alert setMessageText:message];
            [alert setAlertStyle:NSAlertStyleCritical];
            
            if ([alert runModal] == NSAlertFirstButtonReturn){
                if (callType == 2){
                    if (autoBatchMode == 1){
                        autoBatchMode = 2;
                        
                        [autoText setTextColor:[NSColor blackColor]];
                        [autoText setStringValue:@"Auto Processing"];
                        [processModeDisplay setStringValue:@"Auto."];
                        [batchText1 setTextColor:[NSColor purpleColor]];
                        [batchText1 setStringValue:@"Batch (Backup)"];
                        [processModeDisplay setStringValue:@"Batch (Back.)"];
                    }
                    else if (autoBatchMode == 2){
                        autoBatchMode = 3;
                        
                        [batchText1 setTextColor:[NSColor blackColor]];
                        [batchText1 setStringValue:@"Batch (Backup)"];
                        [processModeDisplay setStringValue:@"Batch (Back.)"];
                        [batchText2 setTextColor:[NSColor purpleColor]];
                        [batchText2 setStringValue:@"Batch (Image)"];
                        [processModeDisplay setStringValue:@"Batch (Image)"];
                    }
                    else if (autoBatchMode == 3){
                        autoBatchMode = 1;
                        
                        [batchText2 setTextColor:[NSColor blackColor]];
                        [batchText2 setStringValue:@"Batch Operation (Image)"];
                        [processModeDisplay setStringValue:@"Batch (Image)"];
                        [autoText setTextColor:[NSColor purpleColor]];
                        [autoText setStringValue:@"Auto Processing"];
                        [processModeDisplay setStringValue:@"Auto."];
                    }
                }
                
                runStatusXYMap = 0;
                runStatusFileUpLoad = 0;
                runStatusTreatmentNameSet = 0;
                runStatusFocalImage = 0;
                runStatusContrast = 0;
                fluorescentColor1 = 0;
                fluorescentColor2 = 0;
                fluorescentColor3 = 0;
                fluorescentColor4 = 0;
                fluorescentColor5 = 0;
                fluorescentColor6 = 0;
                backUpDriveNameCount = 0;
                batchPathNameCount = 0;
                backUpDisplayListCount = 0;
                filePickUpCount = 0;
                fluorescentCount = 0;
                
                bodyNameHold = "nil";
                totalFOVNoHold = "nil";
                userIDHold = "nil";
                fluorescent1 = "nil";
                fluorescent2 = "nil";
                fluorescent3 = "nil";
                fluorescent4 = "nil";
                fluorescent5 = "nil";
                fluorescent6 = "nil";
                batchBackUpNameHold = "nil";
                batchImagePathNameHold = "nil";
                batchImageBodyName = "nil";
                batchBodyName = "nil";
                extensionInfoDisplay = "nil";
                batchImagePathInfo = "nil";
                mapSetPerform = "0";
                fluorescentNew1 = "nil";
                fluorescentNew2 = "nil";
                fluorescentNew3 = "nil";
                fluorescentNew4 = "nil";
                fluorescentNew5 = "nil";
                fluorescentNew6 = "nil";
                bodyNameSendMap = "nil";
                autoStatusXYSendMap = "nil";
                batchStatusXYSendMap = "nil";
                initialStatusXYSendMap = "nil";
                
                if (processingIFStatus == 0) backUpNameHold = bodyNameHold;
                else{
                    
                    string bodyNameHoldTemp = bodyNameHold.substr(0, bodyNameHold.length()-2);
                    backUpNameHold = bodyNameHoldTemp;
                }
                
                initialRunStatus = "nil";
                autoProcessCommit = "nil";
                batchBackupOperationCommit = "nil";
                batchImageOperationCommit = "nil";
                
                [analysisName setStringValue:@"nil"];
                [totalFOV setStringValue:@"nil"];
                [userID setStringValue:@"nil"];
                [refreshStatus setStringValue:@"Ready"];
                [mapStatus setStringValue:@"Off"];
                [backUpName setStringValue:@"nil"];
                [backUpStatus setStringValue:@"nil"];
                
                [autoText setStringValue:@"Auto Processing"];
                [autoStatus setStringValue:@"nil"];
                [currentTimePoint setStringValue:@"nil"];
                
                [fileUpLoadStatus setTextColor:[NSColor blueColor]];
                [fileUpLoadStatus setStringValue:@"Off"];
                [treatNameSetStatus setTextColor:[NSColor blueColor]];
                [treatNameSetStatus setStringValue:@"Off"];
                [focalImageStatus setTextColor:[NSColor blueColor]];
                [focalImageStatus setStringValue:@"Off"];
                [contrastSetStatus setTextColor:[NSColor blueColor]];
                [contrastSetStatus setStringValue:@"Off"];
                
                [fileUpLoadStatusOn setTextColor:[NSColor blueColor]];
                [fileUpLoadStatusOn setStringValue:@"File up-loading"];
                [focalImageStatusOn setTextColor:[NSColor blueColor]];
                [focalImageStatusOn setStringValue:@"Focal Image Sel."];
                [contrastSetStatusOn setTextColor:[NSColor blueColor]];
                [contrastSetStatusOn setStringValue:@"Contrast Set"];
                
                [batchSetStatus1 setStringValue:@"nil"];
                [batchStartStatus1 setStringValue:@"nil"];
                [batchAnalysisName1 setStringValue:@"nil"];
                [batchSaveName1 setStringValue:@"nil"];
                [batchText1 setStringValue:@"Batch (Backup)"];
                
                [batchSetStatus2 setStringValue:@"nil"];
                [batchStartStatus2 setStringValue:@"nil"];
                [batchAnalysisName2 setStringValue:@"nil"];
                [batchSaveName2 setStringValue:@"nil"];
                [batchText2 setStringValue:@"Batch (Image)"];
                
                [consoleName setStringValue:@"Console"];
                [tableName setStringValue:@"Summary"];
                [inputDataSet setStringValue:@""];
                
                [initialRun setTextColor:[NSColor blackColor]];
                [initialRun setStringValue:@"nil"];
                [initialRunOn setTextColor:[NSColor blackColor]];
                [initialRunOn setStringValue:@"Initial Run"];
                
                [lastPurgeDisplay setTextColor:[NSColor blackColor]];
                [lastPurgeDisplay setStringValue:@"Last Purge"];
                
                [batchRedoNo1 setStringValue:@"nil"];
                [batchRedoNo2 setStringValue:@"nil"];
                
                [runStatusDisplay setStringValue:@"None"];
                
                netCheckStatus = 0;
                [netAutoCheckDisplay setStringValue:@"Off"];
                
                summaryListCount = 0;
                consoleWarningCount = 0;
                consoleTreatNameCount = 0;
                consoleFocalImageCount = 0;
                consoleContrastCount = 0;
                imageFolderListCount = 0;
                extensionInfoDisplayCall = 1;
                lastPurgeFlag = 0;
                lastPurgeSetFlag = 0;
                
                autoTotalCount = 0;
                imageTimePointAccumulationCounter = 0;
                processingIFCount = 0;
                processingIFStatus = 0;
                newIFFoundFlag = 0;
                purgeCount = 0;
                batchImageIFCount = 1;
                
                remove (analysisDataPath.c_str());
                remove (nameListDataPath.c_str());
                remove (backUpDirectoryPath.c_str());
                remove (batchProcessBackUpPath.c_str());
                remove (batchProcessImagePath.c_str());
                remove (consoleWarningPath.c_str());
                remove (summaryDataPath.c_str());
                remove (backUpResultsPath.c_str());
                remove (backupResultsPath.c_str());
                remove (instructionFIPath.c_str());
                remove (instructionFIPath2.c_str());
                remove (instructionAPPath.c_str());
                remove (instructionCSPath.c_str());
                remove (loadingCompletePath.c_str());
                remove (loadingCompleteFLPath.c_str());
                remove (loadingCompleteCSPath.c_str());
                remove (instructionFLPath.c_str());
                remove (instructionMapPath.c_str());
                remove (instructionNamePath.c_str());
                remove (assignNamePath.c_str());
                
                string basicInfoPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/BKBasic";
                string messagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/BKData";
                
                remove (basicInfoPath.c_str());
                remove (messagePath.c_str());
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses parameterSave];
                
                int directoryRmv = 1;
                pathToDelete = dataImportFolderPath;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                
                directoryRmv = 0;
                pathToDelete = dataFilesPath;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                
                directoryRmv = 1;
                pathToDelete = dataFilesPath;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                
                directoryRmv = 0;
                pathToDelete = namedFilesPath;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                
                directoryRmv = 1;
                pathToDelete = namedFilesPath;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                
                directoryRmv = 0;
                pathToDelete = productsStitchTempPath;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                
                directoryRmv = 2;
                pathToDelete = productsStitchTempPath;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                
                rmdir (productsStitchTempPath.c_str());
                
                tableViewPage = 0;
                summarySetCall = 1;
                consoleDisplayCall = 1;
                
                for (int counter1 = 0; counter1 < 16; counter1++) arrayNameList [counter1] = "nil";
                for (int counter1 = 0; counter1 < 16; counter1++) arrayFOVNumberList [counter1] = 0;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Stop Auto/Batch Processing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)consoleDisplay{
    string displayForConsole;
    
    consoleDisplayCall = 0;
    int consoleDisplayFlag = 0;
    
    string *consoleDisplay;
    int consoleDisplayCount = 0;
    
    NSAttributedString *documentString1 = [[NSAttributedString alloc] initWithString:@""];
    [[textViewcontroller textStorage] setAttributedString: documentString1];
    
    if (consolePage == 0){
        [consoleName setStringValue:@"Warnings"];
        consoleDisplay = new string [consoleWarningCount+10];
        consoleDisplayCount = 0;
        consoleDisplayFlag = 1;
        
        for (int counter1 = 0; counter1 < consoleWarningCount; counter1++){
            consoleDisplay [consoleDisplayCount] = arrayConsoleWarning [counter1], consoleDisplayCount++;
        }
    }
    else if (consolePage == 1){
        [consoleName setStringValue:@"Name Assign."];
        consoleDisplay = new string [consoleTreatNameCount+10];
        consoleDisplayCount = 0;
        consoleDisplayFlag = 1;
        
        for (int counter1 = 0; counter1 < consoleTreatNameCount; counter1++){
            consoleDisplay [consoleDisplayCount] = arrayConsoleTreatName [counter1], consoleDisplayCount++;
        }
    }
    else if (consolePage == 2){
        [consoleName setStringValue:@"Focal Image Sel."];
        consoleDisplay = new string [consoleFocalImageCount+10];
        consoleDisplayCount = 0;
        consoleDisplayFlag = 1;
        
        for (int counter1 = 0; counter1 < consoleFocalImageCount; counter1++){
            consoleDisplay [consoleDisplayCount] = arrayConsoleFocalImage [counter1], consoleDisplayCount++;
        }
    }
    else if (consolePage == 3){
        [consoleName setStringValue:@"Contrast Set"];
        consoleDisplay = new string [consoleContrastCount+10];
        consoleDisplayCount = 0;
        consoleDisplayFlag = 1;
        
        for (int counter1 = 0; counter1 < consoleContrastCount; counter1++){
            consoleDisplay [consoleDisplayCount] = arrayConsoleContrast [counter1], consoleDisplayCount++;
        }
    }
    
    NSRange endRange;
    
    if (consoleDisplayCount != 0){
        for (int counter1 = 0; counter1 < consoleDisplayCount; counter1++){
            endRange.location = [[textViewcontroller textStorage] length];
            endRange.length = 0;
            displayForConsole = consoleDisplay [counter1];
            
            NSString *stringProcessMessage = @(displayForConsole.c_str());
            [textViewcontroller replaceCharactersInRange:endRange withString:stringProcessMessage];
            endRange.length = [stringProcessMessage length];
            [textViewcontroller scrollRangeToVisible:endRange];
            
            endRange.location = [[textViewcontroller textStorage] length];
            endRange.length = 0;
            [textViewcontroller replaceCharactersInRange:endRange withString:@"\r"];
            endRange.length = [@"\r" length];
            [textViewcontroller scrollRangeToVisible:endRange];
            
            endRange.location = [[textViewcontroller textStorage] length];
            endRange.length = 0;
            [textViewcontroller replaceCharactersInRange:endRange withString:@" "];
            endRange.length = [@" " length];
            [textViewcontroller scrollRangeToVisible:endRange];
            
            endRange.location = [[textViewcontroller textStorage] length];
            endRange.length = 0;
            [textViewcontroller replaceCharactersInRange:endRange withString:@"\r"];
            endRange.length = [@"\r" length];
            [textViewcontroller scrollRangeToVisible:endRange];
        }
    }
    
    if (consoleDisplayFlag != 0) delete [] consoleDisplay;
}

-(IBAction)toolConsoleSwitch:(id)sender{
    if (consolePage == 0) consolePage = 1;
    else if (consolePage == 1) consolePage = 2;
    else if (consolePage == 2) consolePage = 3;
    else if (consolePage == 3) consolePage = 0;
    
    consoleDisplayCall = 1;
}

-(IBAction)toolConsoleClear:(id)sender{
    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"OK"];
    [alert addButtonWithTitle:@"Cancel"];
    [alert setMessageText:@"Console Cleaning?"];
    [alert setAlertStyle:NSAlertStyleWarning];
    
    if ([alert runModal] == NSAlertFirstButtonReturn){
        if (consolePage == 0) consoleWarningCount = 0;
        else if (consolePage == 1) consoleTreatNameCount = 0;
        else if (consolePage == 2) consoleFocalImageCount = 0;
        else if (consolePage == 3) consoleContrastCount = 0;
        
        consoleDisplayCall = 1;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = 0;
    
    if (tableViewPage == 0) tableViewContent = summaryListCount, [tableName setStringValue:@"Summary"];
    if (tableViewPage == 1) tableViewContent = backUpDisplayListCount, [tableName setStringValue:@"BackUp Drive List"];
    if (tableViewPage == 2) tableViewContent = batchPathNameCount, [tableName setStringValue:@"Batch Folder List"];
    if (tableViewPage == 3) tableViewContent = imageFolderListCount, [tableName setStringValue:@"Image Folder List"];
    
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    string displayData1;
    string displayData2;
    string backDisplayNo;
    string displayTemp;
    
    NSAttributedString *attrStr;
    
    if (tableViewPage == 0){
        displayData1 = "";
        displayData2 = "";
        
        if (rowIndex == 0) displayData1 = "BS", displayData2 = "Basic Info.";
        else if (rowIndex == 1) displayData1 = "Analysis", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 2) displayData1 = "Computer", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 3) displayData1 = "User ID", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 4) displayData1 = "FOV", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 5) displayData1 = "Last T.", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 6) displayData1 = " ", displayData2 = " ";
        else if (rowIndex == 7) displayData1 = "Well 1", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 8) displayData1 = "Well 2", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 9) displayData1 = "Well 3", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 10) displayData1 = "Well 4", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 11) displayData1 = "Well 5", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 12) displayData1 = "Well 6", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 13) displayData1 = "Well 7", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 14) displayData1 = "Well 8", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 15) displayData1 = "Well 9", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 16) displayData1 = "Well 10", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 17) displayData1 = "Well 11", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 18) displayData1 = "Well 12", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 19) displayData1 = "Well 13", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 20) displayData1 = "Well 14", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 21) displayData1 = "Well 15", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 22) displayData1 = "Well 16", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 23) displayData1 = " ", displayData2 = " ";
        else if (rowIndex == 24) displayData1 = "Fluorescent1", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 25) displayData1 = "Fluorescent2", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 26) displayData1 = "Fluorescent3", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 27) displayData1 = "Fluorescent4", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 28) displayData1 = "Fluorescent5", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 29) displayData1 = "Fluorescent6", displayData2 = arraySummaryList [rowIndex];
        else if (rowIndex == 30) displayData1 = " ", displayData2 = " ";
        else if (rowIndex == 31) displayData1 = "Objective", displayData2 = arraySummaryList [rowIndex];
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"] && rowIndex <= 31){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && rowIndex > 31){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && rowIndex <= 31){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && rowIndex > 31){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else if (tableViewPage == 1){
        //======1. BL, 2. Folder Name, 3. Directory, 4. Status....======
        
        displayData1 = "";
        displayData2 = "";
        int writingFlag = 0;
        
        backDisplayNo = to_string((rowIndex-2)/2+1);
        
        if (rowIndex == 0){
            displayData1 = "BU";
            displayData2 = "BackUp Info";
        }
        else if (rowIndex == 1){
            displayData1 = "S.Name";
            displayData2 = arrayBackUpDisplayList [rowIndex];
        }
        else if (rowIndex >= 2 && (rowIndex-2)%2 == 0){
            displayData1 = "Back "+backDisplayNo;
            displayTemp = arrayBackUpDisplayList [rowIndex];
            
            if ((int)displayTemp.find("/Users/") != -1){
                displayTemp = displayTemp.substr(displayTemp.find("/Desktop"));
            }
            else if ((int)displayTemp.find("/Volumes") == -1) displayTemp = displayTemp.substr(8);
            
            displayData2 = displayTemp;
        }
        else if (rowIndex >= 2 && (rowIndex-2)%2 != 0){
            displayData1 = " ";
            displayData2 = arrayBackUpDisplayList [rowIndex];
        }
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"] && rowIndex <= 1){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && rowIndex > 1 && writingFlag == 0){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && rowIndex <= 1){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && rowIndex > 1 && writingFlag == 0){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else if (tableViewPage == 2){
        displayData1 = "";
        displayData2 = "";
        int writingFlag = 0;
        
        if (rowIndex == 0){
            displayData1 = "BT";
            displayData2 = "Batch Info";
        }
        else if (rowIndex == 1){
            displayData1 = "Analysis";
            displayData2 = arrayBatchPathName [rowIndex];
        }
        else if (rowIndex == 2){
            displayData1 = "S.Name";
            displayData2 = arrayBatchPathName [rowIndex];
        }
        else if (rowIndex > 2){
            displayTemp = arrayBatchPathName [rowIndex];
            
            if ((int)displayTemp.find("/Users/") != -1){
                displayTemp = displayTemp.substr(displayTemp.find("/Desktop/"));
            }
            else if ((int)displayTemp.find("/Volumes/") == -1) displayTemp = displayTemp.substr(8);
            
            backDisplayNo = to_string(rowIndex-2);
            
            displayData1 = "Batch "+backDisplayNo;
            displayData2 = displayTemp;
        }
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"] && rowIndex <= 2){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && rowIndex > 2 && writingFlag == 0){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && rowIndex <= 2){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && rowIndex > 2 && writingFlag == 0){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else if (tableViewPage == 3){
        displayData1 = "";
        displayData2 = "";
        
        backDisplayNo = to_string(rowIndex+1);
        
        displayData1 = backDisplayNo;
        displayData2 = arrayImageFolderList [rowIndex];
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else{
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    tableCallCount++;
    
    if (tableCallCount == 2){
        if (tableViewPage == 0){
            extensionInfoDisplay = "nil";
            extensionInfoDisplayCall = 1;
        }
        else if (tableViewPage == 1){
            if (rowIndexHold >= 2 && (rowIndexHold-2)%2 == 0){
                int indexTemp = (rowIndexHold-2)/2;
                extensionInfoDisplay = arrayBackUpDriveName [indexTemp];
                rowNumberHold = rowIndexHold;
                extensionInfoDisplayCall = 1;
            }
            else{
                
                rowNumberHold = 0;
                extensionInfoDisplay = "nil";
                extensionInfoDisplayCall = 1;
            }
        }
        else if (tableViewPage == 2){
            if (rowIndexHold >= 3){
                extensionInfoDisplay = arrayBatchPathName [rowIndexHold];
                rowNumberHold = rowIndexHold;
                extensionInfoDisplayCall = 1;
            }
            else{
                
                rowNumberHold = 0;
                extensionInfoDisplay = "nil";
                extensionInfoDisplayCall = 1;
            }
        }
        else if (tableViewPage == 3){
            rowNumberHold = rowIndexHold;
            extensionInfoDisplay = "nil";
            extensionInfoDisplayCall = 1;
        }
    }
    else if (tableCallCount == 1){
        tableCurrentRowHold = rowIndex;
        
        if (tableViewPage == 0){
            extensionInfoDisplay = "nil";
            extensionInfoDisplayCall = 1;
        }
        else if (tableViewPage == 1){
            if (rowIndex >= 2 && (rowIndex-2)%2 == 0){
                int indexTemp = (rowIndex-2)/2;
                extensionInfoDisplay = arrayBackUpDriveName [indexTemp];
                rowNumberHold = rowIndex;
                extensionInfoDisplayCall = 1;
            }
            else{
                
                rowNumberHold = 0;
                extensionInfoDisplay = "nil";
                extensionInfoDisplayCall = 1;
            }
        }
        else if (tableViewPage == 2){
            if (rowIndex >= 3){
                extensionInfoDisplay = arrayBatchPathName [rowIndex];
                rowNumberHold = rowIndex;
                extensionInfoDisplayCall = 1;
            }
            else{
                
                rowNumberHold = 0;
                extensionInfoDisplay = "nil";
                extensionInfoDisplayCall = 1;
            }
        }
        else if (tableViewPage == 3){
            rowNumberHold = rowIndex;
            extensionInfoDisplay = "nil";
            extensionInfoDisplayCall = 1;
        }
    }
    
    return YES;
}

-(IBAction)toolTableSwitch:(id)sender{
    if (tableViewPage == 0) tableViewPage = 1;
    else if (tableViewPage == 1) tableViewPage = 2;
    else if (tableViewPage == 2) tableViewPage= 3;
    else if (tableViewPage == 3) tableViewPage= 0;
    
    tableViewCall = 1;
}

-(IBAction)toolModeSelect:(id)sender{
    int callType = 2;
    [self refreshMain:callType];
}

-(IBAction)toolListDelete:(id)sender{
    if (tableViewPage == 1){
        if (rowNumberHold >= 2 && (rowNumberHold-2)%2 == 0){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert addButtonWithTitle:@"Cancel"];
            [alert setMessageText:@"Delete The Path"];
            [alert setInformativeText:@"Folder Save information will be removed"];
            [alert setAlertStyle:NSAlertStyleWarning];
            
            if ([alert runModal] == NSAlertFirstButtonReturn){
                string *backUpTemp = new string [backUpDisplayListCount+50];
                int backUpTempCount = 0;
                
                for (int counter1 = 0; counter1 < backUpDisplayListCount; counter1++){
                    if (counter1 != rowNumberHold && counter1 != rowNumberHold+1){
                        backUpTemp [backUpTempCount] = arrayBackUpDisplayList [counter1], backUpTempCount++;
                    }
                }
                
                backUpDisplayListCount = 0;
                
                for (int counter1 = 0; counter1 < backUpTempCount; counter1++){
                    arrayBackUpDisplayList [backUpDisplayListCount] = backUpTemp [counter1], backUpDisplayListCount++;
                }
                
                delete [] backUpTemp;
                
                backUpTemp = new string [backUpDriveNameCount+50];
                backUpTempCount = 0;
                
                for (int counter1 = 0; counter1 < backUpDriveNameCount; counter1++){
                    if (counter1 != (rowNumberHold-2)/2){
                        backUpTemp [backUpTempCount] = arrayBackUpDriveName [counter1], backUpTempCount++;
                    }
                }
                
                backUpDriveNameCount = 0;
                
                for (int counter1 = 0; counter1 < backUpTempCount; counter1++){
                    arrayBackUpDriveName [backUpDriveNameCount] = backUpTemp [counter1], backUpDriveNameCount++;
                }
                
                delete [] backUpTemp;
                
                if (backUpDriveNameCount == 0){
                    backUpDisplayListCount = 0;
                    
                    ifstream fin;
                    fin.open(backUpDirectoryPath.c_str(),ios::in);
                    if (fin.is_open()) fin.close(), remove (backUpDirectoryPath.c_str());
                    
                    fin.open(backUpResultsPath.c_str(),ios::in);
                    if (fin.is_open()) fin.close(), remove (backUpResultsPath.c_str());
                    
                    [backUpStatus setStringValue:@"nil"];
                    [tableViewList reloadData];
                }
                else{
                    
                    ofstream oin;
                    oin.open(backUpResultsPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < backUpDisplayListCount; counter1++) oin<<arrayBackUpDisplayList [counter1]<<endl;
                    
                    oin.close();
                    
                    oin.open(backUpDirectoryPath.c_str(), ios::out);
                    oin<<backUpNameHold<<endl;
                    
                    for (int counter1 = 0; counter1 < backUpDriveNameCount; counter1++) oin<<arrayBackUpDriveName [counter1]<<endl;
                    
                    oin.close();
                    
                    [backUpStatus setIntegerValue:backUpDriveNameCount];
                    [tableViewList reloadData];
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else if (tableViewPage == 2){
        if (rowNumberHold >= 3){
            string *backUpTemp = new string [batchPathNameCount+50];
            int backUpTempCount = 0;
            
            for (int counter1 = 0; counter1 < batchPathNameCount; counter1++){
                if (counter1 != rowNumberHold) backUpTemp [backUpTempCount] = arrayBatchPathName [counter1], backUpTempCount++;
            }
            
            batchPathNameCount = 0;
            
            for (int counter1 = 0; counter1 < backUpTempCount; counter1++){
                arrayBatchPathName [batchPathNameCount] = backUpTemp [counter1], batchPathNameCount++;
            }
            
            delete [] backUpTemp;
            
            if (batchPathNameCount == 3){
                batchPathNameCount = 0;
                
                ifstream fin;
                fin.open(batchProcessBackUpPath.c_str(),ios::in);
                
                if (fin.is_open()) fin.close(), remove (batchProcessBackUpPath.c_str());
                
                [batchSetStatus1 setStringValue:@"nil"];
                [tableViewList reloadData];
            }
            else{
                
                ofstream oin;
                oin.open(batchProcessBackUpPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < batchPathNameCount; counter1++) oin<<arrayBatchPathName [counter1]<<endl;
                
                oin.close();
                
                [batchSetStatus1 setIntegerValue:batchPathNameCount-3];
                [tableViewList reloadData];
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)toolSaveLoad:(id)sender{
    if (saveLoadOperation == 0){
        saveLoadOperation = 1;
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSaveLoad object:self];
    }
    
    if (saveLoadOperation == 2) saveLoadOperation = 3;
}

-(IBAction)printSummary:(id)sender{
    if (summaryOperation == 0){
        summaryOperation = 1;
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSummary object:self];
    }
    
    if (summaryOperation == 2) summaryOperation = 3;
}

-(IBAction)processTerminate:(id)sender{
    delete [] arraySummaryList;
    delete [] batchProcessInfo;
    delete [] arrayForConsoleCheck;
    delete [] arrayForConsoleCheck2;
    delete [] arrayNameList;
    delete [] arrayFOVNumberList;
    delete [] arrayBackUpDriveName;
    delete [] arrayBatchPathName;
    delete [] arrayConsoleWarning;
    delete [] arrayConsoleTreatName;
    delete [] arrayConsoleFocalImage;
    delete [] arrayConsoleContrast;
    delete [] arrayBackUpDisplayList;
    delete [] arrayImageFolderList;
    delete [] arraySaveLoadList;
    delete [] arraySelectFiles;
    delete [] arrayFileDelete;
    delete [] arrayFileDelete2;
    
    exit(0);
}

//----Running operation commands----
-(IBAction)initialRunSet:(id)sender{
    if (initialRunStatus == "nil" && saveLoadProgress == 0){
        int directoryPathCheck = 0;
        
        [backSave startAnimation:self];
        
        if (autoBatchMode == 1){
            string directoryDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/DirectoryData";
            
            string getString;
            string dataPathInfo = "nil";
            string infoPathInfo = "nil";
            
            ifstream fin;
            
            fin.open(directoryDataPath.c_str(),ios::in);
            
            if (fin.is_open()){
                getline(fin, getString), dataPathInfo = getString;
                getline(fin, getString), infoPathInfo = getString;
                
                fin.close();
            }
            
            if (dataPathInfo != "nil" && infoPathInfo != "nil") directoryPathCheck = 1;
        }
        
        if ((autoBatchMode == 1 && mapSetPerform == "1" && directoryPathCheck == 1) || autoBatchMode == 2 || autoBatchMode == 3){
            if ((autoBatchMode == 1 && bodyNameHold != "nil" && computerNameHold != "nil" && totalFOVNoHold != "nil" && userIDHold != "nil" && initialRunStatus == "nil" ) || (autoBatchMode == 2 && batchBodyName != "nil" && batchBackUpNameHold != "nil" && initialRunStatus == "nil") || (autoBatchMode == 3 && batchImageBodyName != "nil" && batchImagePathNameHold != "nil" && initialRunStatus == "nil")){
                if (autoRunOnOff == 0 && batchBackupOnOff == 0 && batchImageOnOff == 0){
                    if (autoBatchMode == 1){
                        [initialRun setTextColor:[NSColor blueColor]];
                        [initialRun setStringValue:@"FUP"];
                        initialRunStatus = "0";
                        
                        [initialRunOn setTextColor:[NSColor blueColor]];
                        [initialRunOn setStringValue:@"Initial Run"];
                        
                        if (processingIFStatus == 0) [runStatusDisplay setStringValue:@"Init."];
                        
                        productsFilesImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Source_Images";
                        productsFilesInfoPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Analysis_Information";
                        productsFocalTempPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Temp_Images";
                        stitchedFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images"+"/"+bodyNameHold+"_Image";
                        
                        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                        [controllerSubProcesses parameterSave];
                        
                        remove(instructionFLPath.c_str());
                        remove(instructionFIPath.c_str());
                        remove (instructionFIPath2.c_str());
                    }
                    else if (autoBatchMode == 2){
                        string pathName;
                        string entry;
                        string entry2;
                        string folderNumberCheck;
                        
                        DIR *dir;
                        struct dirent *dent;
                        DIR *dir2;
                        struct dirent *dent2;
                        
                        batchProcessInfoCount = 0;
                        int largestFolderNo = 0;
                        
                        string checkPath;
                        string processingIFCountString;
                        
                        processingIFCountString = to_string(processingIFCount);
                        
                        if (processingIFCountString.length() == 1) processingIFCountString = "0"+processingIFCountString;
                        
                        if (processingIFStatus == 0){
                            for (int counter1 = 3; counter1 < batchPathNameCount; counter1++){
                                pathName = arrayBatchPathName [counter1];
                                
                                dir = opendir(pathName.c_str());
                                
                                if (dir != NULL){
                                    while ((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        
                                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                            if ((int)entry.find(batchBodyName+"-") != -1){
                                                if (batchProcessInfoCount+10 > batchProcessInfoLimit) [self batchInfoUpDate];
                                                
                                                batchProcessInfo [batchProcessInfoCount] = pathName, batchProcessInfoCount++;
                                                batchProcessInfo [batchProcessInfoCount] = entry, batchProcessInfoCount++;
                                                batchProcessInfo [batchProcessInfoCount] = "nil", batchProcessInfoCount++;
                                                
                                                folderNumberCheck = entry.substr(entry.find("-1")+2);
                                                
                                                if (largestFolderNo < atoi(folderNumberCheck.c_str())) largestFolderNo = atoi(folderNumberCheck.c_str());
                                            }
                                        }
                                    }
                                    
                                    closedir(dir);
                                }
                            }
                            
                            if (processingIFStatus == 0) [runStatusDisplay setStringValue:@"Init."];
                        }
                        else if (processingIFStatus == 1){
                            int targetIFFind = 0;
                            
                            for (int counter1 = 3; counter1 < batchPathNameCount; counter1++){
                                pathName = arrayBatchPathName [counter1];
                                
                                dir = opendir(pathName.c_str());
                                
                                if (dir != NULL){
                                    while ((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        
                                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                            checkPath = pathName+"/"+entry;
                                            
                                            targetIFFind = 0;
                                            
                                            dir2 = opendir(checkPath.c_str());
                                            
                                            if (dir2 != NULL){
                                                while ((dent2 = readdir(dir2))){
                                                    entry2 = dent2 -> d_name;
                                                    
                                                    if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                                        if ((int)entry2.find(".TIF"+processingIFCountString) != -1) targetIFFind = 1;
                                                    }
                                                }
                                                
                                                closedir(dir2);
                                            }
                                            
                                            if (targetIFFind == 1){
                                                if (batchProcessInfoCount+10 > batchProcessInfoLimit) [self batchInfoUpDate];
                                                
                                                batchProcessInfo [batchProcessInfoCount] = pathName, batchProcessInfoCount++;
                                                batchProcessInfo [batchProcessInfoCount] = entry, batchProcessInfoCount++;
                                                batchProcessInfo [batchProcessInfoCount] = "nil", batchProcessInfoCount++;
                                                
                                                folderNumberCheck = entry.substr(entry.find("-1")+2);
                                                
                                                if (largestFolderNo < atoi(folderNumberCheck.c_str())) largestFolderNo = atoi(folderNumberCheck.c_str());
                                            }
                                        }
                                    }
                                    
                                    closedir(dir);
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < batchProcessInfoCount/3; counterA++){
                        //    cout<<batchProcessInfo [counterA*3]<<" "<<batchProcessInfo [counterA*3+1]<<" "<<batchProcessInfo [counterA*3+2]<<" Batch"<<endl;
                        //}
                        
                        ofstream oin;
                        
                        oin.open(batchProcessFolderPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < batchProcessInfoCount; counter1++) oin<<batchProcessInfo [counter1]<<endl;
                        
                        oin.close();
                        
                        if (batchProcessInfoCount != 0){
                            int batchSeqCount = 1;
                            
                            //----Sorting----
                            string *batchProcessInfoTemp = new string [batchProcessInfoCount+50];
                            int batchProcessInfoTempCount = 0;
                            
                            for (int counter1 = 1; counter1 <= largestFolderNo; counter1++){
                                for (int counter2 = 0; counter2 < batchProcessInfoCount/3; counter2++){
                                    folderNumberCheck = batchProcessInfo [counter2*3+1];
                                    folderNumberCheck = folderNumberCheck.substr(folderNumberCheck.find("-1")+2);
                                    
                                    if (atoi(folderNumberCheck.c_str()) == batchSeqCount){
                                        batchProcessInfoTemp [batchProcessInfoTempCount] = batchProcessInfo [counter2*3], batchProcessInfoTempCount++;
                                        batchProcessInfoTemp [batchProcessInfoTempCount] = batchProcessInfo [counter2*3+1], batchProcessInfoTempCount++;
                                        batchProcessInfoTemp [batchProcessInfoTempCount] = batchProcessInfo [counter2*3+2], batchProcessInfoTempCount++;
                                        break;
                                    }
                                }
                                
                                batchSeqCount++;
                            }
                            
                            batchProcessInfoCount = 0;
                            
                            for (int counter1 = 0; counter1 < batchProcessInfoTempCount; counter1++){
                                batchProcessInfo [batchProcessInfoCount] = batchProcessInfoTemp [counter1], batchProcessInfoCount++;
                            }
                            
                            delete [] batchProcessInfoTemp;
                            
                            string firstPathName = batchProcessInfo [0];
                            string firstFolderNo = batchProcessInfo [1];
                            batchProcessInfo [2] = "1";
                            
                            oin.open(batchProcessFolderPath.c_str(), ios::out);
                            for (int counter1 = 0; counter1 < batchProcessInfoCount; counter1++)  oin<<batchProcessInfo [counter1]<<endl;
                            oin.close();
                            
                            string treatNameCheck;
                            
                            for (int counter1 = 0; counter1 < 16; counter1++){
                                arrayNameList [counter1] = "nil";
                                arrayFOVNumberList [counter1] = 0;
                            }
                            
                            backupBatchWaitPathName = firstPathName+"/"+firstFolderNo;
                            int nameListEntry = 0;
                            int matchFlag = 0;
                            
                            string *nameListTemp = new string [50];
                            int nameListTempCount = 0;
                            
                            dir = opendir(backupBatchWaitPathName.c_str());
                            
                            if (dir != NULL){
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                        treatNameCheck = entry.substr(0, entry.find("_"));
                                        
                                        matchFlag = 0;
                                        
                                        for (int counter1 = 0; counter1 < 16; counter1++){
                                            if (treatNameCheck == nameListTemp [counter1]){
                                                matchFlag = 1;
                                                break;
                                            }
                                        }
                                        
                                        if (matchFlag == 0) nameListTemp [nameListTempCount] = treatNameCheck, nameListTempCount++;
                                    }
                                }
                                
                                closedir(dir);
                                
                                //----Directory Sort----
                                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                                
                                for (int counter1 = 0; counter1 < nameListTempCount; counter1++){
                                    [unsortedArray addObject:@(nameListTemp [counter1].c_str())];
                                }
                                
                                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                                
                                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                                    arrayNameList [nameListEntry] = [unsortedArray [counter1] UTF8String], nameListEntry++;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < 16; counterA++) cout<<arrayNameList [counterA]<<" Name"<<endl;
                            
                            fluorescentCount = 0;
                            fluorescent1 = "nil";
                            fluorescent2 = "nil";
                            fluorescent3 = "nil";
                            fluorescent4 = "nil";
                            fluorescent5 = "nil";
                            fluorescent6 = "nil";
                            fluorescentColor1 = 0;
                            fluorescentColor2 = 0;
                            fluorescentColor3 = 0;
                            fluorescentColor4 = 0;
                            fluorescentColor5 = 0;
                            fluorescentColor6 = 0;
                            string extractString;
                            string fovNoCheck;
                            string colorNoCheck;
                            string colorNameCheck;
                            
                            int largestFovNo = 0;
                            int findString2 = 0;
                            
                            for (int counter1 = 0; counter1 < 16; counter1++){
                                if (arrayNameList [counter1] != "nil"){
                                    treatNameCheck = arrayNameList [counter1];
                                    largestFovNo = 0;
                                    fileDeleteCount = 0;
                                    
                                    dir = opendir(backupBatchWaitPathName.c_str());
                                    
                                    if (dir != NULL){
                                        largestFovNo = 0;
                                        
                                        while ((dent = readdir(dir))){
                                            entry = dent -> d_name;
                                            
                                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                                extractString = entry.substr(entry.find("_")+1);
                                                findString2 = 0;
                                                
                                                if (processingIFStatus == 0) findString2 = (int)extractString.find(".tif");
                                                else if (processingIFStatus == 1) findString2 = (int)extractString.find(".TIF"+processingIFCountString);
                                                
                                                if ((int)entry.find(treatNameCheck) != -1 && (int)extractString.find("_") == -1){
                                                    fovNoCheck = extractString.substr(extractString.find("-")+1, (unsigned long)findString2-extractString.find("-")-1);
                                                    
                                                    if (atoi(fovNoCheck.c_str()) > largestFovNo) largestFovNo = atoi(fovNoCheck.c_str());
                                                }
                                                
                                                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                                            }
                                        }
                                        
                                        closedir(dir);
                                    }
                                    
                                    //----Directory Sort----
                                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                                    
                                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                                        [unsortedArray addObject:@(arrayFileDelete [counter2].c_str())];
                                    }
                                    
                                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                                    
                                    for (NSUInteger counter2 = 0; counter2 < [unsortedArray count]; counter2++){
                                        arrayFileDelete [counter2] = [unsortedArray [counter2] UTF8String];
                                    }
                                    
                                    colorNoCheck = "";
                                    colorNameCheck = "";
                                    
                                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                                        entry = arrayFileDelete [counter2];
                                        
                                        extractString = entry.substr(entry.find("_")+1);
                                        findString2 = 0;
                                        
                                        if (processingIFStatus == 0) findString2 = (int)extractString.find(".tif");
                                        else if (processingIFStatus == 1) findString2 = (int)extractString.find(".TIF"+processingIFCountString);
                                        
                                        if ((int)entry.find(treatNameCheck) != -1 && (int)extractString.find("_") != -1){
                                            colorNoCheck = extractString.substr(extractString.find("_")+1, 1);
                                            colorNameCheck = extractString.substr(extractString.find("_")+3, (unsigned long)findString2-extractString.find("_")-3);
                                            
                                            if (fluorescent1 == "nil"){
                                                fluorescent1 = colorNameCheck;
                                                fluorescentColor1 = atoi(colorNoCheck.c_str());
                                                fluorescentCount++;
                                            }
                                            else if (fluorescent1 != "nil" && fluorescent1 != colorNameCheck && fluorescent2 == "nil"){
                                                fluorescent2 = colorNameCheck;
                                                fluorescentColor2 = atoi(colorNoCheck.c_str());
                                                fluorescentCount++;
                                            }
                                            else if (fluorescent1 != "nil" && fluorescent1 != colorNameCheck && fluorescent2 != "nil" && fluorescent2 != colorNameCheck && fluorescent3 == "nil"){
                                                fluorescent3 = colorNameCheck;
                                                fluorescentColor3 = atoi(colorNoCheck.c_str());
                                                fluorescentCount++;
                                            }
                                            else if (fluorescent1 != "nil" && fluorescent1 != colorNameCheck && fluorescent2 != "nil" && fluorescent2 != colorNameCheck && fluorescent3 != "nil" && fluorescent3 != colorNameCheck && fluorescent4 == "nil"){
                                                fluorescent4 = colorNameCheck;
                                                fluorescentColor4 = atoi(colorNoCheck.c_str());
                                                fluorescentCount++;
                                            }
                                            else if (fluorescent1 != "nil" && fluorescent1 != colorNameCheck && fluorescent2 != "nil" && fluorescent2 != colorNameCheck && fluorescent3 != "nil" && fluorescent3 != colorNameCheck && fluorescent4 != "nil" && fluorescent4 != colorNameCheck && fluorescent5 == "nil"){
                                                fluorescent5 = colorNameCheck;
                                                fluorescentColor5 = atoi(colorNoCheck.c_str());
                                                fluorescentCount++;
                                            }
                                            else if (fluorescent1 != "nil" && fluorescent1 != colorNameCheck && fluorescent2 != "nil" && fluorescent2 != colorNameCheck && fluorescent3 != "nil" && fluorescent3 != colorNameCheck && fluorescent4 != "nil" && fluorescent4 != colorNameCheck && fluorescent5 != "nil" && fluorescent5 != colorNameCheck && fluorescent6 == "nil"){
                                                fluorescent6 = colorNameCheck;
                                                fluorescentColor6 = atoi(colorNoCheck.c_str());
                                                fluorescentCount++;
                                            }
                                        }
                                    }
                                    
                                    arrayFOVNumberList [counter1] = largestFovNo;
                                }
                            }
                            
                            totalFOVNoHold = "0";
                            int fovNoInt = 0;
                            
                            for (int counter1 = 0; counter1 < 16; counter1++){
                                if (arrayFOVNumberList [counter1] != 0) fovNoInt = fovNoInt+arrayFOVNumberList [counter1];
                            }
                            
                            //cout<<fluorescent1<<" "<<fluorescent2<<" "<<fluorescent3<<" "<<fluorescentColor1<<" "<<fluorescentColor2<<" "<<fluorescentColor3<<" "<<fluorescentColor4<<" "<<fluorescentColor5<<" "<<fluorescentColor6<<" "<<fluorescentCount<<" Color"<<endl;
                            
                            oin.open(nameListDataPath.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < 16; counter1++) oin<<arrayNameList [counter1]<<endl;
                            for (int counter1 = 0; counter1 < 16; counter1++) oin<<arrayFOVNumberList [counter1]<<endl;
                            
                            oin<<fluorescent1<<endl;
                            oin<<fluorescent2<<endl;
                            oin<<fluorescent3<<endl;
                            oin<<fluorescent4<<endl;
                            oin<<fluorescent5<<endl;
                            oin<<fluorescent6<<endl;
                            oin<<fluorescent1<<endl;
                            oin<<fluorescent2<<endl;
                            oin<<fluorescent3<<endl;
                            oin<<fluorescent4<<endl;
                            oin<<fluorescent5<<endl;
                            oin<<fluorescent6<<endl;
                            
                            string colorNoString = to_string(fluorescentColor1);
                            oin<<colorNoString<<endl;
                            
                            colorNoString = to_string(fluorescentColor2);
                            oin<<colorNoString<<endl;
                            
                            colorNoString = to_string(fluorescentColor3);
                            oin<<colorNoString<<endl;
                            
                            colorNoString = to_string(fluorescentColor4);
                            oin<<colorNoString<<endl;
                            
                            colorNoString = to_string(fluorescentColor5);
                            oin<<colorNoString<<endl;
                            
                            colorNoString = to_string(fluorescentColor6);
                            oin<<colorNoString<<endl;
                            
                            oin.close();
                            
                            arraySummaryList [1] = batchBackUpNameHold;
                            arraySummaryList [3] = "Batch";
                            
                            totalFOVNoHold = to_string(fovNoInt);
                            
                            arraySummaryList [4] = totalFOVNoHold;
                            
                            for (int counter1 = 7; counter1 < 23; counter1++){
                                treatNameCheck = arrayNameList [counter1-7];
                                fovNoInt = arrayFOVNumberList [counter1-7];
                                
                                extractString = to_string(fovNoInt);
                                
                                if (treatNameCheck == "nil" && extractString == "0") arraySummaryList [counter1] = "nil";
                                else if (treatNameCheck != "nil" && extractString == "0") arraySummaryList [counter1] = treatNameCheck+" (nil)";
                                else if (treatNameCheck == "nil" && extractString != "0") arraySummaryList [counter1] = "nil ("+extractString+")";
                                else arraySummaryList [counter1] = treatNameCheck+" ("+extractString+")";
                            }
                            
                            string colorName1;
                            string colorName2;
                            string colorName3;
                            string colorName4;
                            string colorName5;
                            string colorName6;
                            
                            if (fluorescentColor1 == 1) colorName1 = "Blue";
                            else if (fluorescentColor1 == 2) colorName1 = "Green";
                            else if (fluorescentColor1 == 3) colorName1 = "Yellow";
                            else if (fluorescentColor1 == 4) colorName1 = "Red";
                            else if (fluorescentColor1 == 5) colorName1 = "Magenta";
                            else if (fluorescentColor1 == 6) colorName1 = "Cyan";
                            else if (fluorescentColor1 == 7) colorName1 = "Orange";
                            else if (fluorescentColor1 == 8) colorName1 = "Purple";
                            else if (fluorescentColor1 == 9) colorName1 = "Sky";
                            
                            if (fluorescentColor2 == 1) colorName2 = "Blue";
                            else if (fluorescentColor2 == 2) colorName2 = "Green";
                            else if (fluorescentColor2 == 3) colorName2 = "Yellow";
                            else if (fluorescentColor2 == 4) colorName2 = "Red";
                            else if (fluorescentColor2 == 5) colorName2 = "Magenta";
                            else if (fluorescentColor2 == 6) colorName2 = "Cyan";
                            else if (fluorescentColor2 == 7) colorName2 = "Orange";
                            else if (fluorescentColor2 == 8) colorName2 = "Purple";
                            else if (fluorescentColor2 == 9) colorName2 = "Sky";
                            
                            if (fluorescentColor3 == 1) colorName3 = "Blue";
                            else if (fluorescentColor3 == 2) colorName3 = "Green";
                            else if (fluorescentColor3 == 3) colorName3 = "Yellow";
                            else if (fluorescentColor3 == 4) colorName3 = "Red";
                            else if (fluorescentColor3 == 5) colorName3 = "Magenta";
                            else if (fluorescentColor3 == 6) colorName3 = "Cyan";
                            else if (fluorescentColor3 == 7) colorName3 = "Orange";
                            else if (fluorescentColor3 == 8) colorName3 = "Purple";
                            else if (fluorescentColor3 == 9) colorName3 = "Sky";
                            
                            if (fluorescentColor4 == 1) colorName4 = "Blue";
                            else if (fluorescentColor4 == 2) colorName4 = "Green";
                            else if (fluorescentColor4 == 3) colorName4 = "Yellow";
                            else if (fluorescentColor4 == 4) colorName4 = "Red";
                            else if (fluorescentColor4 == 5) colorName4 = "Magenta";
                            else if (fluorescentColor4 == 6) colorName4 = "Cyan";
                            else if (fluorescentColor4 == 7) colorName4 = "Orange";
                            else if (fluorescentColor4 == 8) colorName4 = "Purple";
                            else if (fluorescentColor4 == 9) colorName4 = "Sky";
                            
                            if (fluorescentColor5 == 1) colorName5 = "Blue";
                            else if (fluorescentColor5 == 2) colorName5 = "Green";
                            else if (fluorescentColor5 == 3) colorName5 = "Yellow";
                            else if (fluorescentColor5 == 4) colorName5 = "Red";
                            else if (fluorescentColor5 == 5) colorName5 = "Magenta";
                            else if (fluorescentColor5 == 6) colorName5 = "Cyan";
                            else if (fluorescentColor5 == 7) colorName5 = "Orange";
                            else if (fluorescentColor5 == 8) colorName5 = "Purple";
                            else if (fluorescentColor5 == 9) colorName5 = "Sky";
                            
                            if (fluorescentColor6 == 1) colorName6 = "Blue";
                            else if (fluorescentColor6 == 2) colorName6 = "Green";
                            else if (fluorescentColor6 == 3) colorName6 = "Yellow";
                            else if (fluorescentColor6 == 4) colorName6 = "Red";
                            else if (fluorescentColor6 == 5) colorName6 = "Magenta";
                            else if (fluorescentColor6 == 6) colorName6 = "Cyan";
                            else if (fluorescentColor6 == 7) colorName6 = "Orange";
                            else if (fluorescentColor6 == 8) colorName6 = "Purple";
                            else if (fluorescentColor6 == 9) colorName6 = "Sky";
                            
                            if (fluorescent1 != "nil" && fluorescentColor1 != 0) arraySummaryList [24] = fluorescent1+" ("+colorName1+")";
                            else arraySummaryList [24] = "nil";
                            
                            if (fluorescent2 != "nil" && fluorescentColor2 != 0) arraySummaryList [25] = fluorescent2+" ("+colorName2+")";
                            else arraySummaryList [25] = "nil";
                            
                            if (fluorescent3 != "nil" && fluorescentColor3 != 0) arraySummaryList [26] = fluorescent3+" ("+colorName3+")";
                            else arraySummaryList [26] = "nil";
                            
                            if (fluorescent4 != "nil" && fluorescentColor4 != 0) arraySummaryList [27] = fluorescent4+" ("+colorName4+")";
                            else arraySummaryList [27] = "nil";
                            
                            if (fluorescent5 != "nil" && fluorescentColor5 != 0) arraySummaryList [28] = fluorescent5+" ("+colorName5+")";
                            else arraySummaryList [28] = "nil";
                            
                            if (fluorescent6 != "nil" && fluorescentColor6 != 0) arraySummaryList [29] = fluorescent6+" ("+colorName6+")";
                            else arraySummaryList [29] = "nil";
                            
                            oin.open(summaryDataPath.c_str(), ios::out);
                            for (int counter1 = 0; counter1 < summaryListCount; counter1++) oin<<arraySummaryList [counter1]<<endl;
                            oin.close();
                            
                            summarySetCall = 2;
                            tableViewPage = 0;
                            
                            //for (int counterA = 0; counterA < summaryListCount; counterA++) cout<< arraySummaryList [counterA]<<"  Summary"<<endl;
                            
                            oin.open(assignNamePath.c_str(), ios::out);
                            oin<<"Well No"<<endl;
                            oin<<"Treat. Name"<<endl;
                            oin<<"No of FOV"<<endl;
                            
                            for (int counter1 = 0; counter1 < 16; counter1++){
                                if (arrayNameList [counter1] != "nil"){
                                    oin<<"Well"<<endl;
                                    oin<<arrayNameList [counter1]<<endl;
                                    oin<<arrayFOVNumberList [counter1]<<endl;
                                }
                                else{
                                    
                                    oin<<"Well"<<endl;
                                    oin<<"nil"<<endl;
                                    oin<<"0"<<endl;
                                }
                            }
                            
                            oin<<"BF"<<endl;
                            oin<<"BF"<<endl;
                            oin<<"BF"<<endl;
                            oin<<"Fluo: Org Name"<<endl;
                            oin<<"Fluo: New Name"<<endl;
                            oin<<"Color No"<<endl;
                            
                            oin<<fluorescent1<<endl;
                            oin<<fluorescent1<<endl;
                            oin<<fluorescentColor1<<endl;
                            oin<<fluorescent2<<endl;
                            oin<<fluorescent2<<endl;
                            oin<<fluorescentColor2<<endl;
                            oin<<fluorescent3<<endl;
                            oin<<fluorescent3<<endl;
                            oin<<fluorescentColor3<<endl;
                            oin<<fluorescent4<<endl;
                            oin<<fluorescent4<<endl;
                            oin<<fluorescentColor4<<endl;
                            oin<<fluorescent5<<endl;
                            oin<<fluorescent5<<endl;
                            oin<<fluorescentColor5<<endl;
                            oin<<fluorescent6<<endl;
                            oin<<fluorescent6<<endl;
                            oin<<fluorescentColor6<<endl;
                            
                            oin.close();
                            
                            bodyNameHold = batchBackUpNameHold;
                            userIDHold = "Batch";
                            
                            [analysisName setStringValue:@(bodyNameHold.c_str())];
                            [totalFOV setStringValue:@(totalFOVNoHold.c_str())];
                            [userID setStringValue:@"Batch"];
                            
                            productsFilesImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Source_Images";
                            productsFilesInfoPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Analysis_Information";
                            productsFocalTempPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Temp_Images";
                            stitchedFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images"+"/"+bodyNameHold+"_Image";
                            
                            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                            [controllerSubProcesses parameterSave];
                            
                            remove(instructionFIPath.c_str());
                            remove (instructionFIPath2.c_str());
                            
                            backupBatchWait1 = 1;
                            
                            //for (int counterA = 0; counterA < batchProcessInfoCount/3; counterA++){
                            //    cout<<batchProcessInfo [counterA*3]<<" "<<batchProcessInfo [counterA*3+1]<<" "<<batchProcessInfo [counterA*3+2]<<" Batch"<<endl;
                            //}
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Folder Missing: Redo Setting"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else if (autoBatchMode == 3){
                        string productFolderPath = productsFilesPath+"/"+batchImageBodyName+"_Products";
                        string productFolderNewPath = productsFilesPath+"/"+batchImagePathNameHold+"_Products";
                        
                        string *arrayNameListTemp = new string [100];
                        int nameListTempCount = 0;
                        int *arrayFOVNumberListTemp = new int [100];
                        int fovNumberListTemp = 0;
                        
                        for (int counter1 = 0; counter1 < 16; counter1++){
                            arrayNameListTemp [counter1] = "nil";
                            arrayFOVNumberListTemp [counter1] = 0;
                        }
                        
                        int fiFilesCheck1 = 0;
                        int fiFilesCheck2 = 0;
                        int fiFilesCheck3 = 0;
                        int fiFilesCheck4 = 0;
                        int analysisFolderCheck = 0;
                        int sourceFolderCheck = 0;
                        int mainFolderFind = 0;
                        int lowestFileNo = 10000;
                        largestFileNoBatch = 0;
                        
                        string entry;
                        string entry2;
                        string entry3;
                        string entry4;
                        string extractString;
                        string productFolderPath2;
                        string productFolderPath3;
                        string productFolderPath4;
                        
                        DIR *dir;
                        struct dirent *dent;
                        DIR *dir2;
                        struct dirent *dent2;
                        DIR *dir3;
                        struct dirent *dent3;
                        DIR *dir4;
                        struct dirent *dent4;
                        
                        if (processingIFStatus == 0){
                            dir = opendir(productFolderPath.c_str());
                            
                            if (dir != NULL){
                                mainFolderFind = 1;
                                
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (entry == "Analysis_Information"){
                                        analysisFolderCheck = 1;
                                        
                                        productFolderPath2 = productFolderPath+"/"+entry;
                                        dir2 = opendir(productFolderPath2.c_str());
                                        
                                        if (dir2 != NULL){
                                            while ((dent2 = readdir(dir2))){
                                                entry2 = dent2 -> d_name;
                                                
                                                if (entry2 == "FI-BasicSetting") fiFilesCheck1 = 1;
                                                if (entry2 == "FI-FocalPlaneData") fiFilesCheck2 = 1;
                                                if (entry2 == "FI-FOVData") fiFilesCheck3 = 1;
                                                if (entry2 == "FI-TreatmentNameData") fiFilesCheck4 = 1;
                                            }
                                            
                                            closedir(dir2);
                                        }
                                    }
                                    
                                    if (entry == "Source_Images"){
                                        sourceFolderCheck = 1;
                                        
                                        productFolderPath2 = productFolderPath+"/"+entry;
                                        dir2 = opendir(productFolderPath2.c_str());
                                        
                                        if (dir2 != NULL){
                                            while ((dent2 = readdir(dir2))){
                                                entry2 = dent2 -> d_name;
                                                int findString = (int)entry2.find("~Sorted");
                                                
                                                if (findString != -1){
                                                    extractString = entry2.substr(0, (unsigned long)findString);
                                                    arrayNameListTemp [nameListTempCount] = extractString, nameListTempCount++;
                                                }
                                            }
                                            
                                            closedir(dir2);
                                            
                                            //----Directory Sort----
                                            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                                            
                                            for (int counter1 = 0; counter1 < nameListTempCount; counter1++){
                                                [unsortedArray addObject:@(arrayNameListTemp [counter1].c_str())];
                                            }
                                            
                                            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                                            
                                            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                                                arrayNameListTemp [counter1] = [unsortedArray [counter1] UTF8String];
                                            }
                                        }
                                        
                                        int fovNoCount = 0;
                                        int fileNoCount = 0;
                                        
                                        for (int counter1 = 0; counter1 < nameListTempCount; counter1++){
                                            productFolderPath3 = productFolderPath2+"/"+arrayNameListTemp [counter1]+"~Sorted";
                                            dir3 = opendir(productFolderPath3.c_str());
                                            
                                            if (dir3 != NULL){
                                                fovNoCount = 0;
                                                
                                                while ((dent3 = readdir(dir3))){
                                                    entry3 = dent3 -> d_name;
                                                    
                                                    if ((int)entry3.find("FOV") != -1){
                                                        productFolderPath4 = productFolderPath3+"/"+entry3;
                                                        fovNoCount++;
                                                        
                                                        dir4 = opendir(productFolderPath4.c_str());
                                                        
                                                        if (dir4 != NULL){
                                                            fileNoCount = 0;
                                                            
                                                            while ((dent4 = readdir(dir4))){
                                                                entry4 = dent4 -> d_name;
                                                                extractString = entry4.substr(entry4.find("_")+1, 4);
                                                                
                                                                if ((int)entry4.find(entry3+".bmp") != -1 || (int)entry4.find(entry3+".tif") != -1) fileNoCount++;
                                                                if (atoi(extractString.c_str()) > largestFileNoBatch) largestFileNoBatch = atoi(extractString.c_str());
                                                            }
                                                            
                                                            if (lowestFileNo > fileNoCount) lowestFileNo = fileNoCount;
                                                            
                                                            closedir(dir4);
                                                        }
                                                    }
                                                }
                                                
                                                closedir(dir3);
                                                
                                                arrayFOVNumberListTemp [fovNumberListTemp] = fovNoCount, fovNumberListTemp++;
                                            }
                                        }
                                    }
                                }
                                
                                closedir(dir);
                            }
                            
                            if (processingIFStatus == 0) [runStatusDisplay setStringValue:@"Init."];
                        }
                        else if (processingIFStatus == 1){
                            mkdir(productFolderNewPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                            
                            string productFolderNoIFPath;
                            string processingIFCountString;
                            string newAnalysisFolderPath;
                            string sourceFolderPath2;
                            string mergeProductPath2;
                            string sourceFolderPath3;
                            string mergeProductPath3;
                            string sourceFolderPath4;
                            string mergeProductPath4;
                            string sourceFolderPath5;
                            string mergeProductPath5;
                            string stringExtract;
                            string stringExtract2;
                            string sourceTimeExtract;
                            string newEntryNoString;
                            string fileExtension;
                            
                            struct stat sizeOfFile;
                            
                            processingIFCountString = to_string(processingIFCount);
                            
                            if (processingIFCountString.length() == 1) processingIFCountString = "0"+processingIFCountString;
                            
                            //----Copy IF**_Analysis_Information data, except CT-FOVPosition----
                            dir = opendir(productFolderPath.c_str());
                            
                            if (dir != NULL){
                                long sizeForCopy = 0;
                                
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    sourceFolderPath2 = productFolderPath+"/"+entry;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                        if ((int)entry.find("IF"+processingIFCountString+"_Analysis_") != -1){
                                            newAnalysisFolderPath = productFolderNewPath+"/"+"Analysis_Information";
                                            mkdir(newAnalysisFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                            
                                            dir2 = opendir(sourceFolderPath2.c_str());
                                            
                                            if (dir2 != NULL){
                                                while ((dent2 = readdir(dir2))){
                                                    entry2 = dent2 -> d_name;
                                                    
                                                    sourceFolderPath3 = sourceFolderPath2+"/"+entry2;
                                                    mergeProductPath3 = newAnalysisFolderPath+"/"+entry2;
                                                    
                                                    if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && (int)entry2.find("CT-FOVPosition") == -1){
                                                        if (stat(sourceFolderPath3.c_str(), &sizeOfFile) == 0){
                                                            sizeForCopy = sizeOfFile.st_size;
                                                            
                                                            ifstream infile (sourceFolderPath3.c_str(), ifstream::binary);
                                                            ofstream outfile (mergeProductPath3.c_str(), ofstream::binary);
                                                            
                                                            char *buffer = new char[sizeForCopy];
                                                            infile.read (buffer, sizeForCopy);
                                                            outfile.write (buffer, sizeForCopy);
                                                            delete [] buffer;
                                                            
                                                            outfile.close();
                                                            infile.close();
                                                        }
                                                    }
                                                }
                                                
                                                closedir(dir2);
                                            }
                                        }
                                    }
                                }
                                
                                closedir(dir);
                            }
                            
                            //----Copy Analysis_Information, CT-FOVPosition----
                            dir = opendir(productFolderPath.c_str());
                            
                            if (dir != NULL){
                                long sizeForCopy = 0;
                                
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    sourceFolderPath2 = productFolderPath+"/"+entry;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                        if ((int)entry.find("Analysis_Information") != -1){
                                            dir2 = opendir(sourceFolderPath2.c_str());
                                            
                                            if (dir2 != NULL){
                                                while ((dent2 = readdir(dir2))){
                                                    entry2 = dent2 -> d_name;
                                                    
                                                    sourceFolderPath3 = sourceFolderPath2+"/"+entry2;
                                                    mergeProductPath3 = newAnalysisFolderPath+"/"+entry2;
                                                    
                                                    if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && (int)entry2.find("CT-FOVPosition") != -1){
                                                        if (stat(sourceFolderPath3.c_str(), &sizeOfFile) == 0){
                                                            sizeForCopy = sizeOfFile.st_size;
                                                            
                                                            ifstream infile (sourceFolderPath3.c_str(), ifstream::binary);
                                                            ofstream outfile (mergeProductPath3.c_str(), ofstream::binary);
                                                            
                                                            char *buffer = new char[sizeForCopy];
                                                            infile.read (buffer, sizeForCopy);
                                                            outfile.write (buffer, sizeForCopy);
                                                            delete [] buffer;
                                                            
                                                            outfile.close();
                                                            infile.close();
                                                        }
                                                    }
                                                }
                                                
                                                closedir(dir2);
                                            }
                                        }
                                    }
                                }
                                
                                closedir(dir);
                            }
                            
                            sourceFolderPath4 = productFolderPath+"/"+"Source_Images";
                            mergeProductPath4 = productFolderNewPath+"/"+"Source_Images";
                            mkdir(mergeProductPath4.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                            
                            dir = opendir(sourceFolderPath4.c_str());
                            
                            if (dir != NULL){
                                long sizeForCopy = 0;
                                
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    sourceFolderPath2 = sourceFolderPath4+"/"+entry;
                                    mergeProductPath2 = mergeProductPath4+"/"+entry;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("~Sorted") != -1){
                                        mkdir(mergeProductPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                        
                                        dir2 = opendir(sourceFolderPath2.c_str());
                                        
                                        if (dir2 != NULL){
                                            while ((dent2 = readdir(dir2))){
                                                entry2 = dent2 -> d_name;
                                                
                                                sourceFolderPath3 = sourceFolderPath2+"/"+entry2;
                                                mergeProductPath3 = mergeProductPath2+"/"+entry2;
                                                
                                                if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && (int)entry2.find("FOV") != -1){
                                                    mkdir(mergeProductPath3.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                                    
                                                    dir3 = opendir(sourceFolderPath3.c_str());
                                                    
                                                    if (dir3 != NULL){
                                                        while ((dent3 = readdir(dir3))){
                                                            entry3 = dent3 -> d_name;
                                                            
                                                            sourceFolderPath5 = sourceFolderPath3+"/"+entry3;
                                                            
                                                            if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store" && ((int)entry3.find("BMP"+processingIFCountString) != -1 || (int)entry3.find("TIF"+processingIFCountString) != -1)){
                                                                if ((int)entry3.find("BMP") != -1) fileExtension = ".BMP";
                                                                else if ((int)entry3.find("TIF") != -1) fileExtension = ".TIF";
                                                                
                                                                stringExtract = entry3.substr(0, entry3.find("_"));
                                                                stringExtract2 = entry3.substr(entry3.find("_"));
                                                                sourceTimeExtract = stringExtract2.substr(1, 4);
                                                                stringExtract2 = stringExtract2.substr(0, stringExtract2.find(fileExtension));
                                                                stringExtract2 = stringExtract2.substr(5);
                                                                newEntryNoString = to_string(atoi(sourceTimeExtract.c_str())-filePickUpCount);
                                                                
                                                                if (newEntryNoString.length() == 1) newEntryNoString = "000"+newEntryNoString;
                                                                else if (newEntryNoString.length() == 2) newEntryNoString = "00"+newEntryNoString;
                                                                else if (newEntryNoString.length() == 3) newEntryNoString = "0"+newEntryNoString;
                                                                
                                                                if (fileExtension == ".TIF") mergeProductPath5 = mergeProductPath3+"/"+stringExtract+"_"+newEntryNoString+stringExtract2+".tif";
                                                                else if (fileExtension == ".BMP") mergeProductPath5 = mergeProductPath3+"/"+stringExtract+"_"+newEntryNoString+stringExtract2+".bmp";
                                                                
                                                                if (stat(sourceFolderPath5.c_str(), &sizeOfFile) == 0){
                                                                    sizeForCopy = sizeOfFile.st_size;
                                                                    
                                                                    ifstream infile (sourceFolderPath5.c_str(), ifstream::binary);
                                                                    ofstream outfile (mergeProductPath5.c_str(), ofstream::binary);
                                                                    
                                                                    char *buffer = new char[sizeForCopy];
                                                                    infile.read (buffer, sizeForCopy);
                                                                    outfile.write (buffer, sizeForCopy);
                                                                    delete [] buffer;
                                                                    
                                                                    outfile.close();
                                                                    infile.close();
                                                                }
                                                            }
                                                        }
                                                        
                                                        closedir(dir3);
                                                    }
                                                }
                                            }
                                            
                                            closedir(dir2);
                                        }
                                    }
                                }
                                
                                closedir(dir);
                            }
                            
                            sourceFolderPath4 = productFolderPath+"/"+"Temp_Images";
                            mergeProductPath4 = productFolderNewPath+"/"+"Temp_Images";
                            mkdir(mergeProductPath4.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                            
                            dir = opendir(sourceFolderPath4.c_str());
                            
                            if (dir != NULL){
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    sourceFolderPath2 = sourceFolderPath4+"/"+entry;
                                    mergeProductPath2 = mergeProductPath4+"/"+entry;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("~Sorted") != -1){
                                        mkdir(mergeProductPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                        
                                        dir2 = opendir(sourceFolderPath2.c_str());
                                        
                                        if (dir2 != NULL){
                                            while ((dent2 = readdir(dir2))){
                                                entry2 = dent2 -> d_name;
                                                sourceFolderPath3 = sourceFolderPath2+"/"+entry2;
                                                mergeProductPath3 = mergeProductPath2+"/"+entry2;
                                                
                                                if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && (int)entry2.find("FOV") != -1){
                                                    mkdir(mergeProductPath3.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                                }
                                            }
                                            
                                            closedir(dir2);
                                        }
                                    }
                                }
                                
                                closedir(dir);
                            }
                            
                            dir = opendir(productFolderNewPath.c_str());
                            
                            if (dir != NULL){
                                mainFolderFind = 1;
                                
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (entry == "Analysis_Information"){
                                        analysisFolderCheck = 1;
                                        
                                        productFolderPath2 = productFolderNewPath+"/"+entry;
                                        dir2 = opendir(productFolderPath2.c_str());
                                        
                                        if (dir2 != NULL){
                                            while ((dent2 = readdir(dir2))){
                                                entry2 = dent2 -> d_name;
                                                
                                                if (entry2 == "FI-BasicSetting") fiFilesCheck1 = 1;
                                                if (entry2 == "FI-FocalPlaneData") fiFilesCheck2 = 1;
                                                if (entry2 == "FI-FOVData") fiFilesCheck3 = 1;
                                                if (entry2 == "FI-TreatmentNameData") fiFilesCheck4 = 1;
                                            }
                                            
                                            closedir(dir2);
                                        }
                                    }
                                    
                                    if (entry == "Source_Images"){
                                        sourceFolderCheck = 1;
                                        
                                        productFolderPath2 = productFolderNewPath+"/"+entry;
                                        dir2 = opendir(productFolderPath2.c_str());
                                        
                                        if (dir2 != NULL){
                                            while ((dent2 = readdir(dir2))){
                                                entry2 = dent2 -> d_name;
                                                
                                                if ((int)entry2.find("~Sorted") != -1){
                                                    extractString = entry2.substr(0, entry2.find("~Sorted"));
                                                    arrayNameListTemp [nameListTempCount] = extractString, nameListTempCount++;
                                                }
                                            }
                                            
                                            closedir(dir2);
                                            
                                            //----Directory Sort----
                                            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                                            
                                            for (int counter1 = 0; counter1 < nameListTempCount; counter1++){
                                                [unsortedArray addObject:@(arrayNameListTemp [counter1].c_str())];
                                            }
                                            
                                            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                                            
                                            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                                                arrayNameListTemp [counter1] = [unsortedArray [counter1] UTF8String];
                                            }
                                        }
                                        
                                        int fovNoCount = 0;
                                        int fileNoCount = 0;
                                        
                                        for (int counter1 = 0; counter1 < nameListTempCount; counter1++){
                                            productFolderPath3 = productFolderPath2+"/"+arrayNameListTemp [counter1]+"~Sorted";
                                            dir3 = opendir(productFolderPath3.c_str());
                                            
                                            if (dir3 != NULL){
                                                fovNoCount = 0;
                                                
                                                while ((dent3 = readdir(dir3))){
                                                    entry3 = dent3 -> d_name;
                                                    
                                                    if ((int)entry3.find("FOV") != -1){
                                                        productFolderPath4 = productFolderPath3+"/"+entry3;
                                                        fovNoCount++;
                                                        
                                                        dir4 = opendir(productFolderPath4.c_str());
                                                        
                                                        if (dir4 != NULL){
                                                            fileNoCount = 0;
                                                            
                                                            while ((dent4 = readdir(dir4))){
                                                                entry4 = dent4 -> d_name;
                                                                extractString = entry4.substr(entry4.find("_")+1, 4);
                                                                
                                                                if ((int)entry4.find(entry3+".bmp") != -1 || (int)entry4.find(entry3+".tif") != -1) fileNoCount++;
                                                                if (atoi(extractString.c_str()) > largestFileNoBatch) largestFileNoBatch = atoi(extractString.c_str());
                                                            }
                                                            
                                                            if (lowestFileNo > atoi(extractString.c_str())) lowestFileNo = atoi(extractString.c_str());
                                                            
                                                            closedir(dir4);
                                                        }
                                                    }
                                                }
                                                
                                                closedir(dir3);
                                                
                                                arrayFOVNumberListTemp [fovNumberListTemp] = fovNoCount, fovNumberListTemp++;
                                            }
                                        }
                                    }
                                }
                                
                                closedir(dir);
                            }
                        }
                        
                        //cout<<fiFilesCheck1<<" "<<fiFilesCheck2<<" "<<fiFilesCheck3<<" "<<fiFilesCheck4<<" "<<analysisFolderCheck<<" "<<sourceFolderCheck<<" "<<mainFolderFind<<" "<<lowestFileNo<<" Check"<<endl;
                        
                        if (fiFilesCheck1 == 1 && fiFilesCheck2 == 1 && fiFilesCheck3 == 1 && fiFilesCheck4 == 1 && analysisFolderCheck == 1 && sourceFolderCheck == 1 &&
                            mainFolderFind == 1 && lowestFileNo >= 1 && lowestFileNo != 10000){
                            [initialRun setTextColor:[NSColor blueColor]];
                            [initialRun setStringValue:@"CTS"];
                            initialRunStatus = "6";
                            
                            [initialRunOn setTextColor:[NSColor blueColor]];
                            [initialRunOn setStringValue:@"Initial Run"];
                            
                            for (int counter1 = 0; counter1 < 16; counter1++){
                                arrayNameList [counter1] = "nil";
                                arrayFOVNumberList [counter1] = 0;
                            }
                            for (int counter1 = 0; counter1 < 16; counter1++){
                                arrayNameList [counter1] = arrayNameListTemp [counter1];
                                arrayFOVNumberList [counter1] = arrayFOVNumberListTemp [counter1];
                            }
                            
                            //for (int counterA = 0; counterA < 16; counterA++) cout<<arrayNameList [counterA]<<" "<<arrayFOVNumberList [counterA]<<" Name"<<endl;
                            
                            fluorescentCount = 0;
                            fluorescent1 = "nil";
                            fluorescent2 = "nil";
                            fluorescent3 = "nil";
                            fluorescent4 = "nil";
                            fluorescent5 = "nil";
                            fluorescent6 = "nil";
                            fluorescentColor1 = 0;
                            fluorescentColor2 = 0;
                            fluorescentColor3 = 0;
                            fluorescentColor4 = 0;
                            fluorescentColor5 = 0;
                            fluorescentColor6 = 0;
                            
                            string pathName;
                            
                            if (processingIFStatus == 0) pathName = productFolderPath+"/source_Images/"+arrayNameList [0]+"~Sorted/FOV001";
                            else if (processingIFStatus == 1) pathName = productFolderNewPath+"/source_Images/"+arrayNameList [0]+"~Sorted/FOV001";
                            
                            string treatNameCheck;
                            string colorNoCheck;
                            string colorNameCheck;
                            
                            for (int counter1 = 0; counter1 < 16; counter1++){
                                if (arrayNameList [counter1] != "nil"){
                                    treatNameCheck = arrayNameList [counter1];
                                    
                                    dir = opendir(pathName.c_str());
                                    
                                    if (dir != NULL){
                                        while ((dent = readdir(dir))){
                                            entry = dent -> d_name;
                                            
                                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                                if ((int)entry.find("_0001-") != -1){
                                                    extractString = entry.substr(entry.find("_0001-")+13);
                                                    
                                                    colorNoCheck = "";
                                                    colorNameCheck = "";
                                                    
                                                    if (((int)extractString.find(".bmp") != -1 || (int)extractString.find(".tif") != -1) && (int)extractString.find("_") != -1){
                                                        colorNoCheck = extractString.substr(0, 1);
                                                        
                                                        if ((int)extractString.find(".tif") != -1) colorNameCheck = extractString.substr(2, extractString.find(".tif")-extractString.find("_")-1);
                                                        else if ((int)extractString.find(".bmp") != -1) colorNameCheck = extractString.substr(2, extractString.find(".bmp")-extractString.find("_")-1);
                                                        
                                                        if (fluorescent1 == "nil"){
                                                            fluorescent1 = colorNameCheck;
                                                            fluorescentColor1 = atoi(colorNoCheck.c_str());
                                                            fluorescentCount++;
                                                        }
                                                        else if (fluorescent1 != "nil" && fluorescent1 != colorNameCheck && fluorescent2 == "nil"){
                                                            fluorescent2 = colorNameCheck;
                                                            fluorescentColor2 = atoi(colorNoCheck.c_str());
                                                            fluorescentCount++;
                                                        }
                                                        else if (fluorescent1 != "nil" && fluorescent1 != colorNameCheck && fluorescent2 != "nil" && fluorescent2 != colorNameCheck && fluorescent3 == "nil"){
                                                            fluorescent3 = colorNameCheck;
                                                            fluorescentColor3 = atoi(colorNoCheck.c_str());
                                                            fluorescentCount++;
                                                        }
                                                        else if (fluorescent1 != "nil" && fluorescent1 != colorNameCheck && fluorescent2 != "nil" && fluorescent2 != colorNameCheck && fluorescent3 != "nil" && fluorescent3 != colorNameCheck && fluorescent4 == "nil"){
                                                            fluorescent4 = colorNameCheck;
                                                            fluorescentColor4 = atoi(colorNoCheck.c_str());
                                                            fluorescentCount++;
                                                        }
                                                        else if (fluorescent1 != "nil" && fluorescent1 != colorNameCheck && fluorescent2 != "nil" && fluorescent2 != colorNameCheck && fluorescent3 != "nil" && fluorescent3 != colorNameCheck && fluorescent4 != "nil" && fluorescent4 != colorNameCheck && fluorescent5 == "nil"){
                                                            fluorescent5 = colorNameCheck;
                                                            fluorescentColor5 = atoi(colorNoCheck.c_str());
                                                            fluorescentCount++;
                                                        }
                                                        else if (fluorescent1 != "nil" && fluorescent1 != colorNameCheck && fluorescent2 != "nil" && fluorescent2 != colorNameCheck && fluorescent3 != "nil" && fluorescent3 != colorNameCheck && fluorescent4 != "nil" && fluorescent4 != colorNameCheck && fluorescent5 != "nil" && fluorescent5 != colorNameCheck && fluorescent6 == "nil"){
                                                            fluorescent6 = colorNameCheck;
                                                            fluorescentColor6 = atoi(colorNoCheck.c_str());
                                                            fluorescentCount++;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        
                                        closedir(dir);
                                    }
                                }
                            }
                            
                            totalFOVNoHold = "0";
                            int fovNoInt = 0;
                            
                            for (int counter1 = 0; counter1 < 16; counter1++){
                                if (arrayFOVNumberList [counter1] != 0) fovNoInt = fovNoInt+arrayFOVNumberList [counter1];
                            }
                            
                            //cout<<fluorescent1<<" "<<fluorescent2<<" "<<fluorescent3<<" "<<fluorescentColor1<<" "<<fluorescentColor2<<" "<<fluorescentColor3<<" "<<fluorescentCount<<" Color"<<endl;
                            
                            ofstream oin;
                            
                            oin.open(nameListDataPath.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < 16; counter1++) oin<<arrayNameList [counter1]<<endl;
                            for (int counter1 = 0; counter1 < 16; counter1++) oin<<arrayFOVNumberList [counter1]<<endl;
                            
                            oin<<fluorescent1<<endl;
                            oin<<fluorescent2<<endl;
                            oin<<fluorescent3<<endl;
                            oin<<fluorescent4<<endl;
                            oin<<fluorescent5<<endl;
                            oin<<fluorescent6<<endl;
                            oin<<fluorescent1<<endl;
                            oin<<fluorescent2<<endl;
                            oin<<fluorescent3<<endl;
                            oin<<fluorescent4<<endl;
                            oin<<fluorescent5<<endl;
                            oin<<fluorescent6<<endl;
                            
                            string colorNoString = to_string(fluorescentColor1);
                            oin<<colorNoString<<endl;
                            
                            colorNoString = to_string(fluorescentColor2);
                            oin<<colorNoString<<endl;
                            
                            colorNoString = to_string(fluorescentColor3);
                            oin<<colorNoString<<endl;
                            
                            colorNoString = to_string(fluorescentColor4);
                            oin<<colorNoString<<endl;
                            
                            colorNoString = to_string(fluorescentColor5);
                            oin<<colorNoString<<endl;
                            
                            colorNoString = to_string(fluorescentColor6);
                            oin<<colorNoString<<endl;
                            
                            oin.close();
                            
                            arraySummaryList [1] = batchImagePathNameHold;
                            arraySummaryList [3] = "Image";
                            
                            totalFOVNoHold = to_string(fovNoInt);
                            
                            arraySummaryList [4] = totalFOVNoHold;
                            
                            for (int counter1 = 7; counter1 < 23; counter1++){
                                treatNameCheck = arrayNameList [counter1-7];
                                fovNoInt = arrayFOVNumberList [counter1-7];
                                
                                extractString = to_string(fovNoInt);
                                
                                if (treatNameCheck == "nil" && extractString == "0") arraySummaryList [counter1] = "nil";
                                else if (treatNameCheck != "nil" && extractString == "0") arraySummaryList [counter1] = treatNameCheck+" (nil)";
                                else if (treatNameCheck == "nil" && extractString != "0") arraySummaryList [counter1] = "nil ("+extractString+")";
                                else arraySummaryList [counter1] = treatNameCheck+" ("+extractString+")";
                            }
                            
                            string colorName1;
                            string colorName2;
                            string colorName3;
                            string colorName4;
                            string colorName5;
                            string colorName6;
                            
                            if (fluorescentColor1 == 1) colorName1 = "Blue";
                            else if (fluorescentColor1 == 2) colorName1 = "Green";
                            else if (fluorescentColor1 == 3) colorName1 = "Yellow";
                            else if (fluorescentColor1 == 4) colorName1 = "Red";
                            else if (fluorescentColor1 == 5) colorName1 = "Magenta";
                            else if (fluorescentColor1 == 6) colorName1 = "Cyan";
                            else if (fluorescentColor1 == 7) colorName1 = "Orange";
                            else if (fluorescentColor1 == 8) colorName1 = "Purple";
                            else if (fluorescentColor1 == 9) colorName1 = "Sky";
                            
                            if (fluorescentColor2 == 1) colorName2 = "Blue";
                            else if (fluorescentColor2 == 2) colorName2 = "Green";
                            else if (fluorescentColor2 == 3) colorName2 = "Yellow";
                            else if (fluorescentColor2 == 4) colorName2 = "Red";
                            else if (fluorescentColor2 == 5) colorName2 = "Magenta";
                            else if (fluorescentColor2 == 6) colorName2 = "Cyan";
                            else if (fluorescentColor2 == 7) colorName2 = "Orange";
                            else if (fluorescentColor2 == 8) colorName2 = "Purple";
                            else if (fluorescentColor2 == 9) colorName2 = "Sky";
                            
                            if (fluorescentColor3 == 1) colorName3 = "Blue";
                            else if (fluorescentColor3 == 2) colorName3 = "Green";
                            else if (fluorescentColor3 == 3) colorName3 = "Yellow";
                            else if (fluorescentColor3 == 4) colorName3 = "Red";
                            else if (fluorescentColor3 == 5) colorName3 = "Magenta";
                            else if (fluorescentColor3 == 6) colorName3 = "Cyan";
                            else if (fluorescentColor3 == 7) colorName3 = "Orange";
                            else if (fluorescentColor3 == 8) colorName3 = "Purple";
                            else if (fluorescentColor3 == 9) colorName3 = "Sky";
                            
                            if (fluorescentColor4 == 1) colorName4 = "Blue";
                            else if (fluorescentColor4 == 2) colorName4 = "Green";
                            else if (fluorescentColor4 == 3) colorName4 = "Yellow";
                            else if (fluorescentColor4 == 4) colorName4 = "Red";
                            else if (fluorescentColor4 == 5) colorName4 = "Magenta";
                            else if (fluorescentColor4 == 6) colorName4 = "Cyan";
                            else if (fluorescentColor4 == 7) colorName4 = "Orange";
                            else if (fluorescentColor4 == 8) colorName4 = "Purple";
                            else if (fluorescentColor4 == 9) colorName4 = "Sky";
                            
                            if (fluorescentColor5 == 1) colorName5 = "Blue";
                            else if (fluorescentColor5 == 2) colorName5 = "Green";
                            else if (fluorescentColor5 == 3) colorName5 = "Yellow";
                            else if (fluorescentColor5 == 4) colorName5 = "Red";
                            else if (fluorescentColor5 == 5) colorName5 = "Magenta";
                            else if (fluorescentColor5 == 6) colorName5 = "Cyan";
                            else if (fluorescentColor5 == 7) colorName5 = "Orange";
                            else if (fluorescentColor5 == 8) colorName5 = "Purple";
                            else if (fluorescentColor5 == 9) colorName5 = "Sky";
                            
                            if (fluorescentColor6 == 1) colorName6 = "Blue";
                            else if (fluorescentColor6 == 2) colorName6 = "Green";
                            else if (fluorescentColor6 == 3) colorName6 = "Yellow";
                            else if (fluorescentColor6 == 4) colorName6 = "Red";
                            else if (fluorescentColor6 == 5) colorName6 = "Magenta";
                            else if (fluorescentColor6 == 6) colorName6 = "Cyan";
                            else if (fluorescentColor6 == 7) colorName6 = "Orange";
                            else if (fluorescentColor6 == 8) colorName6 = "Purple";
                            else if (fluorescentColor6 == 9) colorName6 = "Sky";
                            
                            if (fluorescent1 != "nil" && fluorescentColor1 != 0) arraySummaryList [24] = fluorescent1+" ("+colorName1+")";
                            else arraySummaryList [24] = "nil";
                            
                            if (fluorescent2 != "nil" && fluorescentColor2 != 0) arraySummaryList [25] = fluorescent2+" ("+colorName2+")";
                            else arraySummaryList [25] = "nil";
                            
                            if (fluorescent3 != "nil" && fluorescentColor3 != 0) arraySummaryList [26] = fluorescent3+" ("+colorName3+")";
                            else arraySummaryList [26] = "nil";
                            
                            if (fluorescent4 != "nil" && fluorescentColor4 != 0) arraySummaryList [27] = fluorescent4+" ("+colorName4+")";
                            else arraySummaryList [27] = "nil";
                            
                            if (fluorescent5 != "nil" && fluorescentColor5 != 0) arraySummaryList [28] = fluorescent5+" ("+colorName5+")";
                            else arraySummaryList [28] = "nil";
                            
                            if (fluorescent6 != "nil" && fluorescentColor6 != 0) arraySummaryList [29] = fluorescent6+" ("+colorName6+")";
                            else arraySummaryList [29] = "nil";
                            
                            oin.open(summaryDataPath.c_str(), ios::out);
                            for (int counter1 = 0; counter1 < summaryListCount; counter1++) oin<<arraySummaryList [counter1]<<endl;
                            oin.close();
                            
                            summarySetCall = 2;
                            tableViewPage = 0;
                            
                            //for (int counterA = 0; counterA < summaryListCount; counterA++) cout<< arraySummaryList [counterA]<<"  Summary"<<endl;
                            
                            oin.open(assignNamePath.c_str(), ios::out);
                            oin<<"Well No"<<endl;
                            oin<<"Treat. Name"<<endl;
                            oin<<"No of FOV"<<endl;
                            
                            for (int counter1 = 0; counter1 < 16; counter1++){
                                if (arrayNameList [counter1] != "nil"){
                                    oin<<"Well"<<endl;
                                    oin<<arrayNameList [counter1]<<endl;
                                    oin<<arrayFOVNumberList [counter1]<<endl;
                                }
                                else{
                                    
                                    oin<<"Well"<<endl;
                                    oin<<"nil"<<endl;
                                    oin<<"0"<<endl;
                                }
                            }
                            
                            oin<<"BF"<<endl;
                            oin<<"BF"<<endl;
                            oin<<"BF"<<endl;
                            oin<<"Fluo: Org Name"<<endl;
                            oin<<"Fluo: New Name"<<endl;
                            oin<<"Color No"<<endl;
                            
                            oin<<fluorescent1<<endl;
                            oin<<fluorescent1<<endl;
                            oin<<fluorescentColor1<<endl;
                            oin<<fluorescent2<<endl;
                            oin<<fluorescent2<<endl;
                            oin<<fluorescentColor2<<endl;
                            oin<<fluorescent3<<endl;
                            oin<<fluorescent3<<endl;
                            oin<<fluorescentColor3<<endl;
                            oin<<fluorescent4<<endl;
                            oin<<fluorescent4<<endl;
                            oin<<fluorescentColor4<<endl;
                            oin<<fluorescent5<<endl;
                            oin<<fluorescent5<<endl;
                            oin<<fluorescentColor5<<endl;
                            oin<<fluorescent6<<endl;
                            oin<<fluorescent6<<endl;
                            oin<<fluorescentColor6<<endl;
                            
                            oin.close();
                            
                            if (processingIFStatus == 0) bodyNameHold = batchImageBodyName;
                            userIDHold = "Image";
                            
                            [analysisName setStringValue:@(bodyNameHold.c_str())];
                            [totalFOV setStringValue:@(totalFOVNoHold.c_str())];
                            [userID setStringValue:@"Image"];
                            
                            productsFilesImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Source_Images";
                            productsFilesInfoPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Analysis_Information";
                            productsFocalTempPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Temp_Images";
                            stitchedFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images"+"/"+batchImagePathNameHold+"_Image";
                            
                            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                            [controllerSubProcesses parameterSave];
                            
                            int directoryRmv = 2;
                            pathToDelete = productsFocalTempPath;
                            
                            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                            [controllerSubProcesses fileDeleteLayerThree:directoryRmv];
                            
                            directoryRmv = 1;
                            pathToDelete = productsFocalTempPath;
                            
                            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                            [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                            
                            directoryRmv = 1;
                            pathToDelete = productsFocalTempPath;
                            
                            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                            [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                            
                            for (int counter1 = 0; counter1 < 16; counter1++){
                                if (arrayNameList [counter1] != "nil"){
                                    productFolderPath = productsFocalTempPath+"/"+arrayNameList [counter1]+"~Sorted";
                                    fovNoInt = arrayFOVNumberList [counter1];
                                    
                                    mkdir(productFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                    
                                    for (int counter2 = 1; counter2 <= fovNoInt; counter2++){
                                        extractString = to_string(counter2);
                                        
                                        if (extractString.length() == 1) extractString = "FOV00"+extractString;
                                        else if (extractString.length() == 2) extractString = "FOV0"+extractString;
                                        else if (extractString.length() == 3) extractString = "FOV"+extractString;
                                        
                                        productFolderPath2 = productFolderPath+"/"+extractString;
                                        mkdir(productFolderPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                    }
                                }
                            }
                            
                            if (processingIFStatus == 0) filePickUpCount = 1;
                            else filePickUpCount++;
                            
                            if (processingIFStatus == 0) productsFilesImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+batchImageBodyName+"_Products"+"/"+"Source_Images";
                            else if (processingIFStatus == 1) productsFilesImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+batchImagePathNameHold+"_Products"+"/"+"Source_Images";
                            
                            string productFolderPath5;
                            string productFolderPath6;
                            
                            dir = opendir(productsFilesImagePath.c_str());
                            
                            if (dir != NULL){
                                long sizeForCopy = 0;
                                
                                struct stat sizeOfFile;
                                
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                        productFolderPath = productsFilesImagePath+"/"+entry;
                                        productFolderPath2 = productsFocalTempPath+"/"+entry;
                                        
                                        dir2 = opendir(productFolderPath.c_str());
                                        
                                        if (dir2 != NULL){
                                            while ((dent2 = readdir(dir2))){
                                                entry2 = dent2 -> d_name;
                                                
                                                if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                                    productFolderPath3 = productFolderPath+"/"+entry2;
                                                    productFolderPath4 = productFolderPath2+"/"+entry2;
                                                    
                                                    dir3 = opendir(productFolderPath3.c_str());
                                                    
                                                    if (dir3 != NULL){
                                                        while ((dent3 = readdir(dir3))){
                                                            entry3 = dent3 -> d_name;
                                                            
                                                            int findString = (int)entry3.find("_0001-");
                                                            
                                                            if (findString != -1){
                                                                productFolderPath5 = productFolderPath3+"/"+entry3;
                                                                productFolderPath6 = productFolderPath4+"/"+entry3;
                                                                
                                                                if (stat(productFolderPath5.c_str(), &sizeOfFile) == 0){
                                                                    sizeForCopy = sizeOfFile.st_size;
                                                                    
                                                                    ifstream infile (productFolderPath5.c_str(), ifstream::binary);
                                                                    ofstream outfile (productFolderPath6.c_str(), ofstream::binary);
                                                                    
                                                                    char *buffer = new char[sizeForCopy];
                                                                    infile.read (buffer, sizeForCopy);
                                                                    outfile.write (buffer, sizeForCopy);
                                                                    delete [] buffer;
                                                                    
                                                                    outfile.close();
                                                                    infile.close();
                                                                }
                                                            }
                                                        }
                                                        
                                                        closedir(dir3);
                                                    }
                                                }
                                            }
                                            
                                            closedir(dir2);
                                        }
                                    }
                                }
                                
                                closedir(dir);
                            }
                            
                            oin.open(batchProcessImagePath.c_str(), ios::out);
                            oin<<batchImageBodyName<<endl;
                            oin<<batchImagePathNameHold<<endl;
                            oin<<batchImagePathInfo<<endl;
                            oin<<filePickUpCount<<endl;
                            oin<<largestFileNoBatch<<endl;
                            oin.close();
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Folders In Incorrect Format Or Files Missing"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                        
                        delete [] arrayNameListTemp;
                        delete [] arrayFOVNumberListTemp;
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Stop Auto/Batch Processing"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Complete Basic Settings"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            if (directoryPathCheck == 0){
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Set A Directory Path"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            else if (mapSetPerform != "1"){
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Perform Map Set"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        [backSave stopAnimation:self];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Process Running Or Save-Load In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)initialSetCancel:(id)sender{
    if (runStatusFileUpLoad == 0 && runStatusTreatmentNameSet == 0 && runStatusFocalImage == 0 && runStatusContrast == 0){
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"BackUp Folder Will Be Cleared"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            [backSave startAnimation:self];
            [self settingRedo];
            [backSave stopAnimation:self];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Quit Running Applications"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)redoFocalSet:(id)sender{
    if (autoBatchMode == 1 || autoBatchMode == 2){
        if ((initialRunStatus == "6" || initialRunStatus == "7")){
            if (runStatusContrast == 0){
                [backSave startAnimation:self];
                
                int nameFolderFind1 = 0;
                int nameFolderFind2 = 0;
                
                string processFilePath = namedFilesPath+"/"+bodyNameHold+"-10001";
                
                ifstream fin;
                fin.open(processFilePath.c_str(),ios::in);
                if (fin.is_open()){
                    nameFolderFind1 = 1;
                    fin.close();
                }
                
                string backUpFolderSavePath = backUpDataPath+"/"+bodyNameHold+"-10001";
                
                fin.open(backUpFolderSavePath.c_str(),ios::in);
                if (fin.is_open()){
                    nameFolderFind2 = 1;
                    fin.close();
                }
                
                if (nameFolderFind1 == 1 || nameFolderFind2 == 1){
                    if (nameFolderFind1 == 0 && nameFolderFind2 == 1){
                        mkdir(processFilePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                        
                        int directoryRmv = 1;
                        pathToDelete = backUpFolderSavePath;
                        pathToDelete2 = processFilePath;
                        
                        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                        [controllerSubProcesses fileRenameLayerTwo:directoryRmv];
                        
                        rmdir(backUpFolderSavePath.c_str());
                    }
                    
                    int directoryRmv = 0;
                    pathToDelete = stitchedFolderPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                    
                    directoryRmv = 1;
                    pathToDelete = stitchedFolderPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                    
                    string removePath = productsFilesInfoPath+"/"+"FI-FocalPlaneData";
                    remove (removePath.c_str());
                    removePath = productsFilesInfoPath+"/"+"FI-BasicSetting";
                    remove (removePath.c_str());
                    removePath = productsFilesInfoPath+"/"+"FI-FOVData";
                    remove (removePath.c_str());
                    removePath = productsFilesInfoPath+"/"+"FI-TreatmentNameData";
                    remove (removePath.c_str());
                    removePath = productsFilesInfoPath+"/"+"CT-FOVPosition";
                    remove (removePath.c_str());
                    removePath = productsFilesInfoPath+"/"+"CT-ContrastData";
                    remove (removePath.c_str());
                    removePath = productsFilesInfoPath+"/"+"CT-ContrastDataG";
                    remove (removePath.c_str());
                    removePath = productsFilesInfoPath+"/"+"CT-ContrastDataB";
                    remove (removePath.c_str());
                    removePath = productsFilesInfoPath+"/"+"CT-BasicSetting";
                    remove (removePath.c_str());
                    remove (instructionCSPath.c_str());
                    
                    focalImageFlag = 0;
                    initialRunStatus = "4";
                    [initialRun setStringValue:@"FIS"];
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses parameterSave];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Named Folder Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                
                [backSave stopAnimation:self];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Quit Contrast Setting"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            if (initialRunStatus == "8"){
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Contrast Settings Complete: Use Initial Cancel To Redo Setting"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Contrast Set Step"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Auto/Batch BackUp Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lastPurgeStart:(id)sender{
    if (autoBatchMode == 1 && processingIFStatus == 0){
        if (lastPurgeFlag == 0){
            [backSave startAnimation:self];
            
            //----Imaging computer check----
            string firstTimePoint = "";
            string entry;
            
            int timeMismatchFind = 0;
            int bodyExtensionMismatchFind = 0;
            int fileNameTableCount = 0;
            int directpryInfoHoldCount = 0;
            int directpryInfoHoldLimit = 10000;
            
            DIR *dir;
            struct dirent *dent;
            
            dir = opendir(directoryPathForPC.c_str());
            
            if (dir != NULL){
                string *arrayDirectpryInfoHold = new string [10000];
                
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if (directpryInfoHoldCount+10 > directpryInfoHoldLimit){
                            string *arrayUpDate = new string [directpryInfoHoldCount+10];
                            
                            for (int counter1 = 0; counter1 < directpryInfoHoldCount; counter1++) arrayUpDate [counter1] = arrayDirectpryInfoHold [counter1];
                            
                            delete [] arrayDirectpryInfoHold;
                            arrayDirectpryInfoHold = new string [directpryInfoHoldLimit+50000];
                            directpryInfoHoldLimit = directpryInfoHoldLimit+50000;
                            
                            for (int counter1 = 0; counter1 < directpryInfoHoldCount; counter1++) arrayDirectpryInfoHold [counter1] = arrayUpDate [counter1];
                            delete [] arrayUpDate;
                        }
                        
                        arrayDirectpryInfoHold [directpryInfoHoldCount] = entry, directpryInfoHoldCount++;
                    }
                }
                
                closedir(dir);
                
                if (directpryInfoHoldCount != 0){
                    int bodyNameExtension = -1;
                    int bodyNameLength = (int)bodyNameHold.length();
                    int findString1 = 0;
                    int terminationFlag = 0;
                    
                    string tempName;
                    string bodyNameExtract;
                    string lastString;
                    string extractStringTemp;
                    
                    for (int counter1 = 0; counter1 < directpryInfoHoldCount; counter1++){
                        entry = arrayDirectpryInfoHold [counter1];
                        findString1 = (int)entry.find(bodyNameHold);
                        
                        if (findString1 > 0){
                            if (entry.substr((unsigned long)findString1-1, 1) != "_") findString1 = -1;
                        }
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" && findString1 != -1){
                            tempName = entry.substr((unsigned long)findString1);
                            bodyNameExtract = tempName.substr(0, tempName.find("_"));
                            
                            do{
                                
                                terminationFlag = 1;
                                
                                lastString = bodyNameExtract.substr(bodyNameExtract.length()-1, 1);
                                
                                if (lastString == "0" || lastString == "1" || lastString == "2" || lastString == "3" || lastString == "4" || lastString == "5" || lastString == "6" || lastString == "7" || lastString == "8" || lastString == "9"){
                                    bodyNameExtract = bodyNameExtract.substr(0, bodyNameExtract.length()-1);
                                }
                                else terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                            
                            if (bodyNameExtract == bodyNameHold && (int)entry.find("_s") != -1){
                                
                                if (firstTimePoint == "") firstTimePoint = entry.substr(entry.find("_t")+2, entry.find(".TIF")-entry.find("_t")-2);
                                else if (firstTimePoint != entry.substr(entry.find("_t")+2, entry.find(".TIF")-entry.find("_t")-2)) timeMismatchFind = 1;
                                
                                tempName = entry.substr(entry.find(bodyNameHold));
                                
                                extractStringTemp = tempName.substr((unsigned long)bodyNameLength, tempName.find("_")-(unsigned long)bodyNameLength);
                                
                                if (bodyNameExtension == -1) bodyNameExtension = atoi(extractStringTemp.c_str());
                                else if (bodyNameExtension != atoi(extractStringTemp.c_str())) bodyExtensionMismatchFind = 1;
                                
                                fileNameTableCount++;
                            }
                        }
                    }
                }
                
                delete [] arrayDirectpryInfoHold;
                
                //----Data import folder check----
                int dataImportFolderCount = 0;
                
                dir = opendir(dataImportFolderPath.c_str());
                
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store") dataImportFolderCount++;
                }
                
                closedir(dir);
                
                if (fileNameTableCount != 0 || dataImportFolderCount != 0){
                    if (timeMismatchFind == 0 && bodyExtensionMismatchFind == 0){
                        if (runStatusFileUpLoad == 0){
                            lastPurgeFlag = 1;
                            purgeCount = 0;
                            lastPurgeSetFlag = 1;
                            
                            [lastPurgeDisplay setTextColor:[NSColor redColor]];
                            [lastPurgeDisplay setStringValue:@"Last Purge"];
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Ready To Start File UpLoading"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Quit File UpLoadinging"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Wait until Processing Of Time End-1 Files Is Complete"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"File Missing"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Check Imaging Computer"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            
            [backSave stopAnimation:self];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Last Purge On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Auto Mode Off Or IF Mode On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)processIFStart:(id)sender{
    if (processingIFStatus == 0 || processingIFStatus == 2){
        if (initialRunStatus == "8" && autoBatchMode == 1){
            if (runStatusFileUpLoad == 0){
                if (runStatusFocalImage == 0){
                    if (runStatusContrast == 0){
                        if (runStatusBackUp == 0){
                            //----Imaging computer check----
                            string firstTimePoint = "";
                            string entry;
                            
                            DIR *dir;
                            struct dirent *dent;
                            
                            dir = opendir(directoryPathForPC.c_str());
                            
                            if (dir != NULL){
                                closedir(dir);
                                
                                //----Data import folder check----
                                int dataImportFolderCount = 0;
                                
                                dir = opendir(dataImportFolderPath.c_str());
                                
                                if (dir != NULL){
                                    while ((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        
                                        if (entry != "." && entry != ".." && entry != ".DS_Store") dataImportFolderCount++;
                                    }
                                    
                                    closedir(dir);
                                }
                                
                                if ((dataImportFolderCount == 0 && processingIFStatus == 0) || processingIFStatus == 2 || newIFFoundFlag == 1){
                                    int namedFolderCount = 0;
                                    
                                    dir = opendir(namedFilesPath.c_str());
                                    
                                    if (dir != NULL){
                                        while ((dent = readdir(dir))){
                                            entry = dent -> d_name;
                                            
                                            if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(bodyNameHold) != -1) namedFolderCount++;
                                        }
                                        
                                        closedir(dir);
                                    }
                                    
                                    if (namedFolderCount == 0){
                                        NSAlert *alert = [[NSAlert alloc] init];
                                        [alert addButtonWithTitle:@"OK"];
                                        [alert addButtonWithTitle:@"Cancel"];
                                        [alert setMessageText:@"IF Mode Will Commence: Add IF AT THE END OF BODYNAME (METAMORPH)"];
                                        [alert setInformativeText:@"**PRINT SUMMARY? CURRENT SUMMARY WILL BE CLEARED**"];
                                        [alert setAlertStyle:NSAlertStyleWarning];
                                        
                                        if ([alert runModal] == NSAlertFirstButtonReturn){
                                            if (processingIFStatus == 0) bodyNameHold = bodyNameHold+"IF";
                                            
                                            [analysisName setStringValue:@(bodyNameHold.c_str())];
                                            
                                            processingIFStatus = 1;
                                            processingIFCount++;
                                            
                                            productsFilesImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Source_Images";
                                            productsFilesInfoPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Analysis_Information";
                                            productsFocalTempPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Temp_Images";
                                            stitchedFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images"+"/"+bodyNameHold+"_Image";
                                            
                                            runStatusFileUpLoad = 0;
                                            runStatusTreatmentNameSet = 0;
                                            runStatusFocalImage = 0;
                                            runStatusContrast = 0;
                                            fluorescentColor1 = 0;
                                            fluorescentColor2 = 0;
                                            fluorescentColor3 = 0;
                                            fluorescentColor4 = 0;
                                            fluorescentColor5 = 0;
                                            fluorescentColor6 = 0;
                                            fluorescent1 = "nil";
                                            fluorescent2 = "nil";
                                            fluorescent3 = "nil";
                                            fluorescent4 = "nil";
                                            fluorescent5 = "nil";
                                            fluorescent6 = "nil";
                                            fluorescentNew1 = "nil";
                                            fluorescentNew2 = "nil";
                                            fluorescentNew3 = "nil";
                                            fluorescentNew4 = "nil";
                                            fluorescentNew5 = "nil";
                                            fluorescentNew6 = "nil";
                                            extensionInfoDisplay = "nil";
                                            initialRunStatus = "nil";
                                            autoProcessCommit = "nil";
                                            
                                            [autoText setTextColor:[NSColor purpleColor]];
                                            [autoText setStringValue:@"Auto Processing IF On"];
                                            [currentTimePoint setStringValue:@"nil"];
                                            
                                            [fileUpLoadStatus setTextColor:[NSColor blueColor]];
                                            [fileUpLoadStatus setStringValue:@"Off"];
                                            [treatNameSetStatus setTextColor:[NSColor blueColor]];
                                            [treatNameSetStatus setStringValue:@"Off"];
                                            [focalImageStatus setTextColor:[NSColor blueColor]];
                                            [focalImageStatus setStringValue:@"Off"];
                                            [contrastSetStatus setTextColor:[NSColor blueColor]];
                                            [contrastSetStatus setStringValue:@"Off"];
                                            
                                            [fileUpLoadStatusOn setTextColor:[NSColor blueColor]];
                                            [fileUpLoadStatusOn setStringValue:@"File up-loading"];
                                            [focalImageStatusOn setTextColor:[NSColor blueColor]];
                                            [focalImageStatusOn setStringValue:@"Focal Image Sel."];
                                            [contrastSetStatusOn setTextColor:[NSColor blueColor]];
                                            [contrastSetStatusOn setStringValue:@"Contrast Set"];
                                            
                                            [initialRun setTextColor:[NSColor blackColor]];
                                            [initialRun setStringValue:@"nil"];
                                            [initialRunOn setTextColor:[NSColor blackColor]];
                                            [initialRunOn setStringValue:@"Initial Run"];
                                            [runStatusDisplay setStringValue:@"IF Mode On"];
                                            
                                            summaryListCount = 0;
                                            lastPurgeFlag = 0;
                                            lastPurgeSetFlag = 1;
                                            autoTotalCount = 0;
                                            imageTimePointAccumulationCounter = 0;
                                            
                                            remove (instructionFIPath.c_str());
                                            remove (instructionFIPath2.c_str());
                                            remove (instructionAPPath.c_str());
                                            remove (instructionCSPath.c_str());
                                            remove (loadingCompletePath.c_str());
                                            remove (loadingCompleteFLPath.c_str());
                                            remove (loadingCompleteCSPath.c_str());
                                            remove (summaryDataPath.c_str());
                                            remove (instructionFLPath.c_str());
                                            remove (instructionNamePath.c_str());
                                            
                                            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                            [controllerSubProcesses parameterSave];
                                            
                                            int directoryRmv = 0;
                                            pathToDelete = dataImportFolderPath;
                                            
                                            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                            [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                                            
                                            directoryRmv = 1;
                                            pathToDelete = dataFilesPath;
                                            
                                            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                            [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                                            
                                            directoryRmv = 0;
                                            pathToDelete = namedFilesPath;
                                            
                                            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                            [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                                            
                                            directoryRmv = 1;
                                            pathToDelete = namedFilesPath;
                                            
                                            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                            [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                                            
                                            directoryRmv = 0;
                                            pathToDelete = productsStitchTempPath;
                                            
                                            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                            [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                                            
                                            directoryRmv = 2;
                                            pathToDelete = productsStitchTempPath;
                                            
                                            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                            [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                                            
                                            rmdir (productsStitchTempPath.c_str());
                                            
                                            for (int counter1 = 0; counter1 < 16; counter1++) arrayNameList [counter1] = "nil";
                                            for (int counter1 = 0; counter1 < 16; counter1++) arrayFOVNumberList [counter1] = 0;
                                            
                                            string getString;
                                            
                                            ifstream fin;
                                            
                                            fin.open(nameListDataPath.c_str(),ios::in);
                                            
                                            if (fin.is_open()){
                                                for (int counter1 = 0; counter1 < 16; counter1++){
                                                    getline(fin, getString), arrayNameList [counter1] = getString;
                                                }
                                                
                                                for (int counter1 = 0; counter1 < 16; counter1++){
                                                    getline(fin, getString);
                                                    
                                                    if (getString != "nil") arrayFOVNumberList [counter1] = atoi(getString.c_str());
                                                    else arrayFOVNumberList [counter1] = 0;
                                                }
                                                
                                                fin.close();
                                            }
                                            
                                            ofstream oin;
                                            
                                            oin.open(nameListDataPath.c_str(), ios::out);
                                            
                                            for (int counter1 = 0; counter1 < 16; counter1++) oin<<arrayNameList [counter1]<<endl;
                                            for (int counter1 = 0; counter1 < 16; counter1++) oin<<arrayFOVNumberList [counter1]<<endl;
                                            
                                            oin<<fluorescent1<<endl;
                                            oin<<fluorescent2<<endl;
                                            oin<<fluorescent3<<endl;
                                            oin<<fluorescent4<<endl;
                                            oin<<fluorescent5<<endl;
                                            oin<<fluorescent6<<endl;
                                            oin<<fluorescentNew1<<endl;
                                            oin<<fluorescentNew2<<endl;
                                            oin<<fluorescentNew3<<endl;
                                            oin<<fluorescentNew4<<endl;
                                            oin<<fluorescentNew5<<endl;
                                            oin<<fluorescentNew6<<endl;
                                            
                                            string colorNoString = to_string(fluorescentColor1);
                                            oin<<colorNoString<<endl;
                                            
                                            colorNoString = to_string(fluorescentColor2);
                                            oin<<colorNoString<<endl;
                                            
                                            colorNoString = to_string(fluorescentColor3);
                                            oin<<colorNoString<<endl;
                                            
                                            colorNoString = to_string(fluorescentColor4);
                                            oin<<colorNoString<<endl;
                                            
                                            colorNoString = to_string(fluorescentColor5);
                                            oin<<colorNoString<<endl;
                                            
                                            colorNoString = to_string(fluorescentColor6);
                                            oin<<colorNoString<<endl;
                                            
                                            oin.close();
                                            
                                            tableViewPage = 0;
                                            summarySetCall = 1;
                                            consoleDisplayCall = 1;
                                        }
                                    }
                                    else{
                                        
                                        NSAlert *alert = [[NSAlert alloc] init];
                                        [alert addButtonWithTitle:@"OK"];
                                        [alert setMessageText:@"Complete Focal Image Sel And Contrast Set"];
                                        [alert setAlertStyle:NSAlertStyleWarning];
                                        [alert runModal];
                                        
                                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                                        [sound play];
                                    }
                                }
                                else{
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"Wait: Processing Files/Perform Last Purge"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                            }
                            else{
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"Check Imaging Computer"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Quit BackUp"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Quit Contrast Setting"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Quit Focal Image Sel."];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Quit File UpLoadinging"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else if (initialRunStatus == "8" && autoBatchMode == 2){
            if (runStatusFocalImage == 0){
                if (runStatusContrast == 0){
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert addButtonWithTitle:@"Cancel"];
                    [alert setMessageText:@"IF Mode Will Commence"];
                    [alert setInformativeText:@"**PRINT SUMMARY? CURRENT SUMMARY WILL BE CLEARED**"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    
                    if ([alert runModal] == NSAlertFirstButtonReturn){
                        if (processingIFStatus == 0){
                            bodyNameHold = bodyNameHold+"IF";
                            batchBackUpNameHold = batchBackUpNameHold+"IF";
                        }
                        
                        processingIFStatus = 1;
                        processingIFCount++;
                        
                        productsFilesImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Source_Images";
                        productsFilesInfoPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Analysis_Information";
                        stitchedFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images"+"/"+bodyNameHold+"_Image";
                        
                        runStatusFocalImage = 0;
                        runStatusContrast = 0;
                        fluorescentColor1 = 0;
                        fluorescentColor2 = 0;
                        fluorescentColor3 = 0;
                        fluorescentColor4 = 0;
                        fluorescentColor5 = 0;
                        fluorescentColor6 = 0;
                        fluorescentCount = 0;
                        fluorescent1 = "nil";
                        fluorescent2 = "nil";
                        fluorescent3 = "nil";
                        fluorescent4 = "nil";
                        fluorescent5 = "nil";
                        fluorescent6 = "nil";
                        fluorescentNew1 = "nil";
                        fluorescentNew2 = "nil";
                        fluorescentNew3 = "nil";
                        fluorescentNew4 = "nil";
                        fluorescentNew5 = "nil";
                        fluorescentNew6 = "nil";
                        
                        extensionInfoDisplay = "nil";
                        initialRunStatus = "nil";
                        batchBackupOperationCommit = "nil";
                        
                        [batchText1 setTextColor:[NSColor purpleColor]];
                        [batchText1 setStringValue:@"Batch (Backup) IF On"];
                        [currentTimePoint setStringValue:@"nil"];
                        
                        [focalImageStatus setTextColor:[NSColor blueColor]];
                        [focalImageStatus setStringValue:@"Off"];
                        [contrastSetStatus setTextColor:[NSColor blueColor]];
                        [contrastSetStatus setStringValue:@"Off"];
                        
                        [focalImageStatusOn setTextColor:[NSColor blueColor]];
                        [focalImageStatusOn setStringValue:@"Focal Image Sel."];
                        [contrastSetStatusOn setTextColor:[NSColor blueColor]];
                        [contrastSetStatusOn setStringValue:@"Contrast Set"];
                        
                        [initialRun setTextColor:[NSColor blackColor]];
                        [initialRun setStringValue:@"nil"];
                        [initialRunOn setTextColor:[NSColor blackColor]];
                        [initialRunOn setStringValue:@"Initial Run"];
                        [runStatusDisplay setStringValue:@"IF Mode On"];
                        
                        summaryListCount = 0;
                        lastPurgeFlag = 0;
                        lastPurgeSetFlag = 1;
                        imageTimePointAccumulationCounter = 0;
                        
                        remove (instructionFIPath.c_str());
                        remove (instructionFIPath2.c_str());
                        remove (instructionAPPath.c_str());
                        remove (instructionCSPath.c_str());
                        remove (loadingCompletePath.c_str());
                        remove (loadingCompleteFLPath.c_str());
                        remove (loadingCompleteCSPath.c_str());
                        remove (instructionFLPath.c_str());
                        remove (instructionNamePath.c_str());
                        
                        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                        [controllerSubProcesses parameterSave];
                        
                        int directoryRmv = 0;
                        pathToDelete = namedFilesPath;
                        
                        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                        [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                        
                        directoryRmv = 1;
                        pathToDelete = namedFilesPath;
                        
                        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                        [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                        
                        for (int counter1 = 0; counter1 < 16; counter1++) arrayNameList [counter1] = "nil";
                        for (int counter1 = 0; counter1 < 16; counter1++) arrayFOVNumberList [counter1] = 0;
                        
                        string getString;
                        
                        ifstream fin;
                        
                        fin.open(nameListDataPath.c_str(),ios::in);
                        
                        if (fin.is_open()){
                            for (int counter1 = 0; counter1 < 16; counter1++){
                                getline(fin, getString), arrayNameList [counter1] = getString;
                            }
                            
                            for (int counter1 = 0; counter1 < 16; counter1++){
                                getline(fin, getString);
                                
                                if (getString != "nil") arrayFOVNumberList [counter1] = atoi(getString.c_str());
                                else arrayFOVNumberList [counter1] = 0;
                            }
                            
                            fin.close();
                        }
                        
                        ofstream oin;
                        
                        oin.open(nameListDataPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < 16; counter1++) oin<<arrayNameList [counter1]<<endl;
                        for (int counter1 = 0; counter1 < 16; counter1++) oin<<arrayFOVNumberList [counter1]<<endl;
                        
                        oin<<fluorescent1<<endl;
                        oin<<fluorescent2<<endl;
                        oin<<fluorescent3<<endl;
                        oin<<fluorescent4<<endl;
                        oin<<fluorescent5<<endl;
                        oin<<fluorescent6<<endl;
                        oin<<fluorescentNew1<<endl;
                        oin<<fluorescentNew2<<endl;
                        oin<<fluorescentNew3<<endl;
                        oin<<fluorescentNew4<<endl;
                        oin<<fluorescentNew5<<endl;
                        oin<<fluorescentNew6<<endl;
                        
                        string colorNoString = to_string(fluorescentColor1);
                        oin<<colorNoString<<endl;
                        
                        colorNoString = to_string(fluorescentColor2);
                        oin<<colorNoString<<endl;
                        
                        colorNoString = to_string(fluorescentColor3);
                        oin<<colorNoString<<endl;
                        
                        colorNoString = to_string(fluorescentColor4);
                        oin<<colorNoString<<endl;
                        
                        colorNoString = to_string(fluorescentColor5);
                        oin<<colorNoString<<endl;
                        
                        colorNoString = to_string(fluorescentColor6);
                        oin<<colorNoString<<endl;
                        
                        oin.close();
                        
                        arrayBatchPathName [2] = batchBackUpNameHold;
                        
                        oin.open(batchProcessBackUpPath.c_str(), ios::out);
                        for (int counter1 = 1; counter1 < batchPathNameCount; counter1++) oin<<arrayBatchPathName [counter1]<<endl;
                        oin.close();
                        
                        [batchSaveName1 setStringValue:@(batchBackUpNameHold.c_str())];
                        
                        tableViewPage = 0;
                        summarySetCall = 1;
                        consoleDisplayCall = 1;
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Quit Contrast Setting"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Quit Focal Image Sel."];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else if (initialRunStatus == "8" && autoBatchMode == 3){
            if (runStatusContrast == 0){
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert addButtonWithTitle:@"Cancel"];
                [alert setMessageText:@"IF Mode Will Commence"];
                [alert setInformativeText:@"**PRINT SUMMARY? CURRENT SUMMARY WILL BE CLEARED**"];
                [alert setAlertStyle:NSAlertStyleWarning];
                
                if ([alert runModal] == NSAlertFirstButtonReturn){
                    if (processingIFStatus == 0){
                        bodyNameHold = batchImagePathNameHold+"IF";
                        batchImagePathNameHold = batchImagePathNameHold+"IF";
                    }
                    
                    processingIFStatus = 1;
                    processingIFCount++;
                    newIFFoundFlag = 0;
                    
                    productsFilesImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Source_Images";
                    productsFilesInfoPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Analysis_Information";
                    productsFocalTempPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Temp_Images";
                    stitchedFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images"+"/"+bodyNameHold+"_Image";
                    
                    batchImageIFCount = 1;
                    runStatusContrast = 0;
                    fluorescentColor1 = 0;
                    fluorescentColor2 = 0;
                    fluorescentColor3 = 0;
                    fluorescentColor4 = 0;
                    fluorescentColor5 = 0;
                    fluorescentColor6 = 0;
                    fluorescentCount = 0;
                    fluorescent1 = "nil";
                    fluorescent2 = "nil";
                    fluorescent3 = "nil";
                    fluorescent4 = "nil";
                    fluorescent5 = "nil";
                    fluorescent6 = "nil";
                    fluorescentNew1 = "nil";
                    fluorescentNew2 = "nil";
                    fluorescentNew3 = "nil";
                    fluorescentNew4 = "nil";
                    fluorescentNew5 = "nil";
                    fluorescentNew6 = "nil";
                    
                    extensionInfoDisplay = "nil";
                    initialRunStatus = "nil";
                    batchImageOperationCommit = "nil";
                    
                    [batchText2 setTextColor:[NSColor purpleColor]];
                    [batchText2 setStringValue:@"Batch (Image) IF On"];
                    [currentTimePoint setStringValue:@"nil"];
                    
                    [contrastSetStatus setTextColor:[NSColor blueColor]];
                    [contrastSetStatus setStringValue:@"Off"];
                    [contrastSetStatusOn setTextColor:[NSColor blueColor]];
                    [contrastSetStatusOn setStringValue:@"Contrast Set"];
                    
                    [initialRun setTextColor:[NSColor blackColor]];
                    [initialRun setStringValue:@"nil"];
                    [initialRunOn setTextColor:[NSColor blackColor]];
                    [initialRunOn setStringValue:@"Initial Run"];
                    [runStatusDisplay setStringValue:@"IF Mode On"];
                    
                    summaryListCount = 0;
                    imageFolderListCount = 0;
                    lastPurgeFlag = 0;
                    lastPurgeSetFlag = 1;
                    
                    remove (instructionFIPath.c_str());
                    remove (instructionFIPath2.c_str());
                    remove (instructionAPPath.c_str());
                    remove (instructionCSPath.c_str());
                    remove (loadingCompletePath.c_str());
                    remove (loadingCompleteFLPath.c_str());
                    remove (loadingCompleteCSPath.c_str());
                    remove (instructionFLPath.c_str());
                    remove (instructionNamePath.c_str());
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses parameterSave];
                    
                    tableViewPage = 0;
                    summarySetCall = 1;
                    consoleDisplayCall = 1;
                    
                    for (int counter1 = 0; counter1 < 16; counter1++) arrayNameList [counter1] = "nil";
                    for (int counter1 = 0; counter1 < 16; counter1++) arrayFOVNumberList [counter1] = 0;
                    
                    string getString;
                    
                    ifstream fin;
                    
                    fin.open(nameListDataPath.c_str(),ios::in);
                    
                    if (fin.is_open()){
                        for (int counter1 = 0; counter1 < 16; counter1++){
                            getline(fin, getString), arrayNameList [counter1] = getString;
                        }
                        
                        for (int counter1 = 0; counter1 < 16; counter1++){
                            getline(fin, getString);
                            
                            if (getString != "nil") arrayFOVNumberList [counter1] = atoi(getString.c_str());
                            else arrayFOVNumberList [counter1] = 0;
                        }
                        
                        fin.close();
                    }
                    
                    ofstream oin;
                    
                    oin.open(nameListDataPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < 16; counter1++) oin<<arrayNameList [counter1]<<endl;
                    for (int counter1 = 0; counter1 < 16; counter1++) oin<<arrayFOVNumberList [counter1]<<endl;
                    
                    oin<<fluorescent1<<endl;
                    oin<<fluorescent2<<endl;
                    oin<<fluorescent3<<endl;
                    oin<<fluorescent4<<endl;
                    oin<<fluorescent5<<endl;
                    oin<<fluorescent6<<endl;
                    oin<<fluorescentNew1<<endl;
                    oin<<fluorescentNew2<<endl;
                    oin<<fluorescentNew3<<endl;
                    oin<<fluorescentNew4<<endl;
                    oin<<fluorescentNew5<<endl;
                    oin<<fluorescentNew6<<endl;
                    
                    string colorNoString = to_string(fluorescentColor1);
                    oin<<colorNoString<<endl;
                    
                    colorNoString = to_string(fluorescentColor2);
                    oin<<colorNoString<<endl;
                    
                    colorNoString = to_string(fluorescentColor3);
                    oin<<colorNoString<<endl;
                    
                    colorNoString = to_string(fluorescentColor4);
                    oin<<colorNoString<<endl;
                    
                    colorNoString = to_string(fluorescentColor5);
                    oin<<colorNoString<<endl;
                    
                    colorNoString = to_string(fluorescentColor6);
                    oin<<colorNoString<<endl;
                    
                    oin.close();
                    
                    oin.open(batchProcessImagePath.c_str(), ios::out);
                    oin<<batchImageBodyName<<endl;
                    oin<<batchImagePathNameHold<<endl;
                    oin<<batchImagePathInfo<<endl;
                    oin<<filePickUpCount<<endl;
                    oin<<largestFileNoBatch<<endl;
                    oin.close();
                    
                    [batchSaveName2 setStringValue:@(batchImagePathNameHold.c_str())];
                    
                    tableViewPage = 0;
                    summarySetCall = 1;
                    consoleDisplayCall = 1;
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Quit Contrast Setting"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"IF Processing On: Perform IF Data Merge"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)processIFMerge:(id)sender{
    if (processingIFStatus == 1){
        if (initialRunStatus == "8" && autoBatchMode == 1){
            if (runStatusFileUpLoad == 0){
                if (runStatusFocalImage == 0){
                    if (runStatusContrast == 0){
                        [backSave startAnimation:self];
                        
                        //----Imaging computer check----
                        string firstTimePoint = "";
                        int fileNameTableCount = 0;
                        
                        string entry;
                        
                        DIR *dir;
                        struct dirent *dent;
                        DIR *dir2;
                        struct dirent *dent2;
                        
                        dir = opendir(directoryPathForPC.c_str());
                        
                        if (dir != NULL){
                            closedir(dir);
                            
                            //----Data import folder check----
                            int dataImportFolderCount = 0;
                            
                            dir = opendir(dataImportFolderPath.c_str());
                            
                            if (dir != NULL){
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store") dataImportFolderCount++;
                                }
                                
                                closedir(dir);
                            }
                            
                            if (newIFFoundFlag == 1) fileNameTableCount = 0;
                            
                            if (fileNameTableCount == 0 && dataImportFolderCount == 0){
                                int namedFolderCount = 0;
                                
                                dir = opendir(namedFilesPath.c_str());
                                
                                if (dir != NULL){
                                    while ((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        
                                        if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(bodyNameHold) != -1) namedFolderCount++;
                                    }
                                    
                                    closedir(dir);
                                }
                                
                                if (namedFolderCount == 0){
                                    int stringLength = (int)bodyNameHold.length();
                                    
                                    string processingIFCountString = to_string(processingIFCount);
                                    
                                    if (processingIFCountString.length() == 1) processingIFCountString = "0"+processingIFCountString;
                                    
                                    string noIFBodyName = bodyNameHold.substr(0, (unsigned long)stringLength-2);
                                    string mergeImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images"+"/"+noIFBodyName+"_Image";
                                    
                                    string stitchedFolderPath2;
                                    string stitchedFolderPath3;
                                    string mergeImagePath2;
                                    string mergeImagePath3;
                                    string mergeBackupPath;
                                    string sourceBackupPath;
                                    string sourceBackupPath2;
                                    string entry2;
                                    string stringExtract;
                                    string stringExtract2;
                                    string newEntryNoString;
                                    
                                    int modeA = 0;
                                    int modeB = 1;
                                    pathToDelete = mergeImagePath;
                                    
                                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                    int lastRoundNumber = [controllerSubProcesses fileDeleteLayerTwoStitch:modeA:modeB];
                                    
                                    if (lastRoundNumber == 1){
                                        NSAlert *alert = [[NSAlert alloc] init];
                                        [alert addButtonWithTitle:@"OK"];
                                        [alert setMessageText:@"Previously Created Images Found And Will Be Deleted"];
                                        [alert setAlertStyle:NSAlertStyleWarning];
                                        [alert runModal];
                                        
                                        modeA = 0;
                                        modeB = 0;
                                        pathToDelete = mergeImagePath;
                                        
                                        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                        [controllerSubProcesses fileDeleteLayerTwoStitch:modeA:modeB];
                                    }
                                    
                                    int lastBackUpNo = 0;
                                    
                                    dir = opendir(backUpDataPath.c_str());
                                    
                                    if (dir != NULL){
                                        int timePointNumber = 0;
                                        
                                        while ((dent = readdir(dir))){
                                            entry = dent -> d_name;
                                            sourceBackupPath2 = backUpDataPath+"/"+entry;
                                            
                                            if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(bodyNameHold) == -1 && (int)entry.find(noIFBodyName) != -1){
                                                stringExtract = entry.substr(entry.find("-")+1);
                                                timePointNumber = atoi(stringExtract.c_str());
                                                timePointNumber = timePointNumber-10000;
                                                
                                                if (lastBackUpNo < timePointNumber) lastBackUpNo = timePointNumber;
                                            }
                                        }
                                        
                                        closedir(dir);
                                    }
                                    
                                    if (lastBackUpNo != 0){
                                        DIR *dir3;
                                        struct dirent *dent3;
                                        DIR *dir4;
                                        struct dirent *dent4;
                                        
                                        modeA = 0;
                                        modeB = 2;
                                        pathToDelete = mergeImagePath;
                                        
                                        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                        int lastCount = [controllerSubProcesses fileDeleteLayerTwoStitch:modeA:modeB];
                                        
                                        dir = opendir(stitchedFolderPath.c_str());
                                        fileDeleteCount = 0;
                                        fileDeleteCount2 = 0;
                                        
                                        if (dir != NULL){
                                            while ((dent = readdir(dir))){
                                                entry = dent -> d_name;
                                                
                                                if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("_Stitch") != -1){
                                                    stitchedFolderPath2 = stitchedFolderPath+"/"+entry;
                                                    mergeImagePath2 = mergeImagePath+"/"+entry;
                                                    
                                                    dir2 = opendir(stitchedFolderPath2.c_str());
                                                    
                                                    if (dir2 != NULL){
                                                        while ((dent2 = readdir(dir2))){
                                                            entry2 = dent2 -> d_name;
                                                            
                                                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                                            arrayFileDelete [fileDeleteCount] = stitchedFolderPath2+"/@"+entry2, fileDeleteCount++; //----Add"~" as a marker----
                                                            
                                                            if (fileDeleteCount2+5 > fileDeleteLimit2) [self fileDeleteUpDate2];
                                                            arrayFileDelete2 [fileDeleteCount2] = mergeImagePath2, fileDeleteCount2++;
                                                        }
                                                        
                                                        closedir(dir2);
                                                    }
                                                }
                                            }
                                            
                                            closedir(dir);
                                            
                                            string imageNameExtract;
                                            string imageNameExtract2;
                                            string fileExtension;
                                            
                                            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                                imageNameExtract = arrayFileDelete [counter1].substr(arrayFileDelete [counter1].find("@")+1);
                                                imageNameExtract2 = arrayFileDelete [counter1].substr(0, arrayFileDelete [counter1].find("@"));
                                                
                                                stitchedFolderPath3 = imageNameExtract2+imageNameExtract;
                                                mergeImagePath3 = arrayFileDelete2 [counter1]+"/"+imageNameExtract;
                                                
                                                if ((int)imageNameExtract.find("STimage") != -1){
                                                    if ((int)imageNameExtract.find(".tif") != -1) fileExtension = ".tif";
                                                    else if ((int)imageNameExtract.find(".bmp") != -1) fileExtension = ".bmp";
                                                    
                                                    stringExtract = imageNameExtract.substr(8, 4);
                                                    stringExtract2 = imageNameExtract.substr(12);
                                                    
                                                    if (stringExtract2.find(fileExtension) == 0) stringExtract2 = "";
                                                    else stringExtract2 = stringExtract2.substr(0, stringExtract2.find(fileExtension));
                                                    
                                                    newEntryNoString = to_string(lastCount+atoi(stringExtract.c_str()));
                                                    
                                                    if (newEntryNoString.length() == 1) newEntryNoString = "000"+newEntryNoString;
                                                    else if (newEntryNoString.length() == 2) newEntryNoString = "00"+newEntryNoString;
                                                    else if (newEntryNoString.length() == 3) newEntryNoString = "0"+newEntryNoString;
                                                    
                                                    if (fileExtension == ".tif") mergeImagePath3 = arrayFileDelete2 [counter1]+"/STimage "+newEntryNoString+stringExtract2+".TIF"+processingIFCountString;
                                                    else if (fileExtension == ".bmp") mergeImagePath3 = arrayFileDelete2 [counter1]+"/STimage "+newEntryNoString+stringExtract2+".BMP"+processingIFCountString;
                                                    
                                                    rename (stitchedFolderPath3.c_str(), mergeImagePath3.c_str());
                                                }
                                                else remove (stitchedFolderPath3.c_str());
                                            }
                                        }
                                        
                                        int directoryRmv = 2;
                                        pathToDelete = stitchedFolderPath;
                                        
                                        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                        [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                                        
                                        remove (stitchedFolderPath.c_str());
                                        
                                        string mergeProductPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+noIFBodyName+"_Products";
                                        string sourceProductPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products";
                                        
                                        string newAnalysisFolderPath;
                                        string sourceFolderPath2;
                                        string sourceFolderPath3;
                                        string sourceFolderPath4;
                                        string sourceFolderPath5;
                                        string mergeProductPath2;
                                        string mergeProductPath3;
                                        string mergeProductPath4;
                                        string mergeProductPath5;
                                        string entry3;
                                        string entry4;
                                        string sourceTimeExtract;
                                        
                                        dir = opendir(sourceProductPath.c_str());
                                        
                                        if (dir != NULL){
                                            while ((dent = readdir(dir))){
                                                entry = dent -> d_name;
                                                sourceFolderPath2 = sourceProductPath+"/"+entry;
                                                mergeProductPath2 = mergeProductPath+"/"+entry;
                                                
                                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                                    if ((int)entry.find("Analysis_") != -1){
                                                        newAnalysisFolderPath = mergeProductPath+"/"+"IF"+processingIFCountString+"_Analysis_Information";
                                                        mkdir(newAnalysisFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                                        
                                                        dir2 = opendir(sourceFolderPath2.c_str());
                                                        
                                                        if (dir2 != NULL){
                                                            while ((dent2 = readdir(dir2))){
                                                                entry2 = dent2 -> d_name;
                                                                sourceFolderPath3 = sourceFolderPath2+"/"+entry2;
                                                                mergeProductPath3 = newAnalysisFolderPath+"/"+entry2;
                                                                
                                                                if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                                                    rename (sourceFolderPath3.c_str(), mergeProductPath3.c_str());
                                                                }
                                                                else remove (sourceFolderPath3.c_str());
                                                            }
                                                            
                                                            closedir(dir2);
                                                            
                                                            rmdir (sourceFolderPath2.c_str());
                                                        }
                                                    }
                                                    
                                                    if ((int)entry.find("Source_") != -1){
                                                        dir2 = opendir(sourceFolderPath2.c_str());
                                                        fileDeleteCount = 0;
                                                        fileDeleteCount2 = 0;
                                                        
                                                        if (dir2 != NULL){
                                                            while ((dent2 = readdir(dir2))){
                                                                entry2 = dent2 -> d_name;
                                                                sourceFolderPath3 = sourceFolderPath2+"/"+entry2;
                                                                mergeProductPath3 = mergeProductPath2+"/"+entry2;
                                                                
                                                                if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && (int)entry2.find("~Sorted") != -1){
                                                                    dir3 = opendir(sourceFolderPath3.c_str());
                                                                    
                                                                    if (dir3 != NULL){
                                                                        while ((dent3 = readdir(dir3))){
                                                                            entry3 = dent3 -> d_name;
                                                                            sourceFolderPath4 = sourceFolderPath3+"/"+entry3;
                                                                            mergeProductPath4 = mergeProductPath3+"/"+entry3;
                                                                            
                                                                            if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store" && (int)entry3.find("FOV") != -1){
                                                                                dir4 = opendir(sourceFolderPath4.c_str());
                                                                                
                                                                                if (dir4 != NULL){
                                                                                    while ((dent4 = readdir(dir4))){
                                                                                        entry4 = dent4 -> d_name;
                                                                                        
                                                                                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                                                                        arrayFileDelete [fileDeleteCount] = sourceFolderPath4+"/@"+entry4, fileDeleteCount++; //=======Add "~" as a marker======
                                                                                        
                                                                                        if (fileDeleteCount2+5 > fileDeleteLimit2) [self fileDeleteUpDate2];
                                                                                        arrayFileDelete2 [fileDeleteCount2] = mergeProductPath4, fileDeleteCount2++; //=======Add "~" as a marker======
                                                                                    }
                                                                                    
                                                                                    closedir(dir4);
                                                                                }
                                                                            }
                                                                        }
                                                                        
                                                                        closedir(dir3);
                                                                    }
                                                                }
                                                            }
                                                            
                                                            closedir(dir2);
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            closedir(dir);
                                            
                                            string imageNameExtract;
                                            string imageNameExtract2;
                                            string fileExtension;
                                            
                                            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                                imageNameExtract = arrayFileDelete [counter1].substr(arrayFileDelete [counter1].find("@")+1);
                                                imageNameExtract2 = arrayFileDelete [counter1].substr(0, arrayFileDelete [counter1].find("@"));
                                                sourceFolderPath5 = imageNameExtract2+imageNameExtract;
                                                
                                                if (imageNameExtract != "." && imageNameExtract != ".." && imageNameExtract != ".DS_Store" && ((int)imageNameExtract.find(".tif") != -1 || (int)imageNameExtract.find(".bmp") != -1)){
                                                    if ((int)imageNameExtract.find("BMP") != -1) fileExtension = ".bmp";
                                                    else if ((int)imageNameExtract.find("TIF") != -1) fileExtension = ".tif";
                                                    
                                                    stringExtract = imageNameExtract.substr(0, imageNameExtract.find("_"));
                                                    stringExtract2 = imageNameExtract.substr(imageNameExtract.find("_")+1);
                                                    sourceTimeExtract = stringExtract2.substr(0, 4);
                                                    stringExtract2 = stringExtract2.substr(4);
                                                    stringExtract2 = stringExtract2.substr(0, stringExtract2.find(fileExtension));
                                                    
                                                    newEntryNoString = to_string(lastCount+atoi(sourceTimeExtract.c_str()));
                                                    
                                                    if (newEntryNoString.length() == 1) newEntryNoString = "000"+newEntryNoString;
                                                    else if (newEntryNoString.length() == 2) newEntryNoString = "00"+newEntryNoString;
                                                    else if (newEntryNoString.length() == 3) newEntryNoString = "0"+newEntryNoString;
                                                    
                                                    if (fileExtension == ".tif") mergeProductPath5 = arrayFileDelete2 [counter1]+"/"+stringExtract+"_"+newEntryNoString+stringExtract2+".TIF"+processingIFCountString;
                                                    else if (fileExtension == ".bmp") mergeProductPath5 = arrayFileDelete2 [counter1]+"/"+stringExtract+"_"+newEntryNoString+stringExtract2+".BMP"+processingIFCountString;
                                                    
                                                    rename (sourceFolderPath5.c_str(), mergeProductPath5.c_str());
                                                }
                                            }
                                        }
                                        
                                        directoryRmv = 2;
                                        pathToDelete = sourceProductPath;
                                        
                                        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                        [controllerSubProcesses fileDeleteLayerFour:directoryRmv];
                                        
                                        directoryRmv = 2;
                                        pathToDelete = sourceProductPath;
                                        
                                        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                        [controllerSubProcesses fileDeleteLayerThree:directoryRmv];
                                        
                                        directoryRmv = 1;
                                        pathToDelete = sourceProductPath;
                                        
                                        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                        [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                                        
                                        directoryRmv = 2;
                                        pathToDelete = sourceProductPath;
                                        
                                        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                        [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                                        
                                        remove (sourceProductPath.c_str());
                                        
                                        string treatNameString;
                                        string newEntryNoFile;
                                        
                                        dir = opendir(backUpDataPath.c_str());
                                        fileDeleteCount = 0;
                                        fileDeleteCount2 = 0;
                                        
                                        if (dir != NULL){
                                            int timePointNumber = 0;
                                            
                                            while ((dent = readdir(dir))){
                                                entry = dent -> d_name;
                                                sourceBackupPath = backUpDataPath+"/"+entry;
                                                
                                                if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(bodyNameHold) != -1){
                                                    stringExtract = entry.substr(entry.find("-")+1);
                                                    timePointNumber = atoi(stringExtract.c_str());
                                                    timePointNumber = timePointNumber-10000;
                                                    
                                                    newEntryNoString = to_string(lastBackUpNo+timePointNumber);
                                                    newEntryNoFile = to_string(lastBackUpNo+timePointNumber);
                                                    
                                                    if (newEntryNoString.length() == 1) newEntryNoString = "1000"+newEntryNoString;
                                                    else if (newEntryNoString.length() == 2) newEntryNoString = "100"+newEntryNoString;
                                                    else if (newEntryNoString.length() == 3) newEntryNoString = "10"+newEntryNoString;
                                                    else if (newEntryNoString.length() == 4) newEntryNoString = "1"+newEntryNoString;
                                                    
                                                    if (newEntryNoFile.length() == 1) newEntryNoFile = "000"+newEntryNoFile;
                                                    else if (newEntryNoFile.length() == 2) newEntryNoFile = "00"+newEntryNoFile;
                                                    else if (newEntryNoFile.length() == 3) newEntryNoFile = "0"+newEntryNoFile;
                                                    
                                                    newAnalysisFolderPath = backUpDataPath+"/"+noIFBodyName+"-"+newEntryNoString;
                                                    mkdir(newAnalysisFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                                    
                                                    dir2 = opendir(sourceBackupPath.c_str());
                                                    
                                                    if (dir2 != NULL){
                                                        while ((dent2 = readdir(dir2))){
                                                            entry2 = dent2 -> d_name;
                                                            
                                                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                                            arrayFileDelete [fileDeleteCount] = sourceBackupPath+"/@"+entry2, fileDeleteCount++;
                                                            
                                                            if (fileDeleteCount2+5 > fileDeleteLimit2) [self fileDeleteUpDate2];
                                                            arrayFileDelete2 [fileDeleteCount2] = newAnalysisFolderPath, fileDeleteCount2++;
                                                        }
                                                        
                                                        closedir(dir2);
                                                    }
                                                }
                                            }
                                            
                                            closedir(dir);
                                            
                                            string imageNameExtract;
                                            string imageNameExtract2;
                                            
                                            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                                imageNameExtract = arrayFileDelete [counter1].substr(arrayFileDelete [counter1].find("@")+1);
                                                imageNameExtract2 = arrayFileDelete [counter1].substr(0, arrayFileDelete [counter1].find("@"));
                                                
                                                sourceBackupPath2 = imageNameExtract2+imageNameExtract;
                                                
                                                if (imageNameExtract != "." && imageNameExtract != ".." && imageNameExtract != ".DS_Store"){
                                                    treatNameString = imageNameExtract.substr(0, imageNameExtract.find("_"));
                                                    stringExtract = imageNameExtract.substr(imageNameExtract.find("-"));
                                                    stringExtract = stringExtract.substr(0, stringExtract.find(".tif"));
                                                    
                                                    mergeBackupPath = arrayFileDelete2 [counter1]+"/"+treatNameString+"_"+newEntryNoFile+stringExtract+".TIF"+processingIFCountString;
                                                    
                                                    rename (sourceBackupPath2.c_str(), mergeBackupPath.c_str());
                                                }
                                            }
                                        }
                                        
                                        dir = opendir(backUpDataPath.c_str());
                                        fileDeleteCount = 0;
                                        
                                        if (dir != NULL){
                                            while ((dent = readdir(dir))){
                                                entry = dent -> d_name;
                                                sourceBackupPath = backUpDataPath+"/"+entry;
                                                
                                                if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(bodyNameHold) != -1){
                                                    dir2 = opendir(sourceBackupPath.c_str());
                                                    
                                                    if (dir2 != NULL){
                                                        while ((dent2 = readdir(dir2))){
                                                            entry2 = dent2 -> d_name;
                                                            
                                                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                                            arrayFileDelete [fileDeleteCount] = sourceBackupPath+"/"+entry2, fileDeleteCount++;
                                                        }
                                                        
                                                        closedir(dir2);
                                                    }
                                                }
                                            }
                                            
                                            closedir(dir);
                                            
                                            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                                remove (arrayFileDelete [counter1].c_str());
                                            }
                                        }
                                        
                                        fileDeleteCount = 0;
                                        
                                        dir = opendir(backUpDataPath.c_str());
                                        
                                        if (dir != NULL){
                                            while ((dent = readdir(dir))){
                                                entry = dent -> d_name;
                                                
                                                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                                            }
                                            
                                            closedir(dir);
                                            
                                            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                                sourceBackupPath = backUpDataPath+"/"+arrayFileDelete [counter1];
                                                entry = arrayFileDelete [counter1];
                                                
                                                if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(bodyNameHold) != -1){
                                                    rmdir (sourceBackupPath.c_str());
                                                }
                                            }
                                        }
                                        
                                        processingIFStatus = 2;
                                        
                                        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                        [controllerSubProcesses parameterSave];
                                        
                                        [autoText setTextColor:[NSColor purpleColor]];
                                        [autoText setStringValue:@"Auto Processing IF R-To-S"];
                                        [runStatusDisplay setStringValue:@"IF Ready"];
                                        
                                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                                        [sound play];
                                    }
                                    else{
                                        
                                        NSAlert *alert = [[NSAlert alloc] init];
                                        [alert addButtonWithTitle:@"OK"];
                                        [alert setMessageText:@"No Last BackUp Folder Found: Unable To Start IF Mode"];
                                        [alert setAlertStyle:NSAlertStyleWarning];
                                        [alert runModal];
                                        
                                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                                        [sound play];
                                    }
                                }
                                else{
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"Complete Focal Image Sel And Contrast Set"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                            }
                            else{
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"Wait: Processing Files"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Check Imaging Computer"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                        
                        [backSave stopAnimation:self];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Quit Contrast Setting"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Quit Focal Image Sel."];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Quit File UpLoadinging"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else if (initialRunStatus == "8" && autoBatchMode == 2){
            if (runStatusFocalImage == 0){
                if (runStatusContrast == 0){
                    int stringLength = (int)bodyNameHold.length();
                    
                    string processingIFCountString = to_string(processingIFCount);
                    
                    if (processingIFCountString.length() == 1) processingIFCountString = "0"+processingIFCountString;
                    
                    string noIFBodyName = bodyNameHold.substr(0, (unsigned long)stringLength-2);
                    string mergeImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images"+"/"+noIFBodyName+"_Image";
                    
                    string stitchedFolderPath2;
                    string stitchedFolderPath3;
                    string mergeImagePath2;
                    string mergeImagePath3;
                    string entry;
                    string entry2;
                    string stringExtract;
                    string stringExtract2;
                    string newEntryNoString;
                    
                    DIR *dir;
                    struct dirent *dent;
                    DIR *dir2;
                    struct dirent *dent2;
                    DIR *dir3;
                    struct dirent *dent3;
                    DIR *dir4;
                    struct dirent *dent4;
                    
                    int modeA = 0;
                    int modeB = 1;
                    pathToDelete = mergeImagePath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    int lastRoundNumber = [controllerSubProcesses fileDeleteLayerTwoStitch:modeA:modeB];
                    
                    if (lastRoundNumber == 1){
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Previously Created Images Found And Will Be Deleted"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        string sourceFolderPath5;
                        
                        modeA = 0;
                        modeB = 0;
                        pathToDelete = mergeImagePath;
                        
                        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                        [controllerSubProcesses fileDeleteLayerTwoStitch:modeA:modeB];
                    }
                    
                    [backSave startAnimation:self];
                    
                    modeA = 0;
                    modeB = 2;
                    pathToDelete = mergeImagePath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    int lastCount = [controllerSubProcesses fileDeleteLayerTwoStitch:modeA:modeB];
                    
                    dir = opendir(stitchedFolderPath.c_str());
                    fileDeleteCount = 0;
                    fileDeleteCount2 = 0;
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("_Stitch") != -1){
                                stitchedFolderPath2 = stitchedFolderPath+"/"+entry;
                                mergeImagePath2 = mergeImagePath+"/"+entry;
                                
                                dir2 = opendir(stitchedFolderPath2.c_str());
                                
                                if (dir2 != NULL){
                                    while ((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                        arrayFileDelete [fileDeleteCount] = stitchedFolderPath2+"/@"+entry2, fileDeleteCount++;
                                        
                                        if (fileDeleteCount2+5 > fileDeleteLimit2) [self fileDeleteUpDate2];
                                        arrayFileDelete2 [fileDeleteCount2] = mergeImagePath2, fileDeleteCount2++;
                                    }
                                    
                                    closedir(dir2);
                                }
                            }
                        }
                        
                        closedir(dir);
                        
                        string imageNameExtract;
                        string imageNameExtract2;
                        string fileExtension;
                        
                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            imageNameExtract = arrayFileDelete [counter1].substr(arrayFileDelete [counter1].find("@")+1);
                            imageNameExtract2 = arrayFileDelete [counter1].substr(0, arrayFileDelete [counter1].find("@"));
                            
                            stitchedFolderPath3 = imageNameExtract2+imageNameExtract;
                            mergeImagePath3 = arrayFileDelete2 [counter1]+"/"+imageNameExtract;
                            
                            if ((int)imageNameExtract.find("STimage") != -1){
                                if ((int)imageNameExtract.find(".tif") != -1) fileExtension = ".tif";
                                else if ((int)imageNameExtract.find(".bmp") != -1) fileExtension = ".bmp";
                                
                                stringExtract = imageNameExtract.substr(8, 4);
                                stringExtract2 = imageNameExtract.substr(12);
                                
                                if (stringExtract2.find(fileExtension) == 0) stringExtract2 = "";
                                else stringExtract2 = stringExtract2.substr(0, stringExtract2.find(fileExtension));
                                
                                newEntryNoString = to_string(lastCount+atoi(stringExtract.c_str()));
                                
                                if (newEntryNoString.length() == 1) newEntryNoString = "000"+newEntryNoString;
                                else if (newEntryNoString.length() == 2) newEntryNoString = "00"+newEntryNoString;
                                else if (newEntryNoString.length() == 3) newEntryNoString = "0"+newEntryNoString;
                                
                                if (fileExtension == ".tif") mergeImagePath3 = arrayFileDelete2 [counter1]+"/STimage "+newEntryNoString+stringExtract2+".TIF"+processingIFCountString;
                                else if (fileExtension == ".bmp") mergeImagePath3 = arrayFileDelete2 [counter1]+"/STimage "+newEntryNoString+stringExtract2+".BMP"+processingIFCountString;
                                
                                rename (stitchedFolderPath3.c_str(), mergeImagePath3.c_str());
                            }
                        }
                    }
                    
                    modeA = 0;
                    modeB = 3;
                    pathToDelete = stitchedFolderPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerTwoStitch:modeA:modeB];
                    
                    int directoryRmv = 2;
                    pathToDelete = stitchedFolderPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                    
                    remove (stitchedFolderPath.c_str());
                    
                    string mergeProductPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+noIFBodyName+"_Products";
                    string sourceProductPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products";
                    
                    string newAnalysisFolderPath;
                    string sourceFolderPath2;
                    string sourceFolderPath3;
                    string sourceFolderPath4;
                    string sourceFolderPath5;
                    string mergeProductPath2;
                    string mergeProductPath3;
                    string mergeProductPath4;
                    string mergeProductPath5;
                    string entry3;
                    string entry4;
                    string sourceTimeExtract;
                    
                    dir = opendir(sourceProductPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            sourceFolderPath2 = sourceProductPath+"/"+entry;
                            mergeProductPath2 = mergeProductPath+"/"+entry;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if ((int)entry.find("Analysis_") != -1){
                                    newAnalysisFolderPath = mergeProductPath+"/"+"IF"+processingIFCountString+"_Analysis_Information";
                                    mkdir(newAnalysisFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                    
                                    dir2 = opendir(sourceFolderPath2.c_str());
                                    
                                    if (dir2 != NULL){
                                        while ((dent2 = readdir(dir2))){
                                            entry2 = dent2 -> d_name;
                                            sourceFolderPath3 = sourceFolderPath2+"/"+entry2;
                                            mergeProductPath3 = newAnalysisFolderPath+"/"+entry2;
                                            
                                            if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                                rename (sourceFolderPath3.c_str(), mergeProductPath3.c_str());
                                            }
                                            else remove (sourceFolderPath3.c_str());
                                        }
                                        
                                        closedir(dir2);
                                        
                                        rmdir (sourceFolderPath2.c_str());
                                    }
                                }
                                
                                if ((int)entry.find("Source_") != -1){
                                    dir2 = opendir(sourceFolderPath2.c_str());
                                    fileDeleteCount = 0;
                                    fileDeleteCount2 = 0;
                                    
                                    if (dir2 != NULL){
                                        while ((dent2 = readdir(dir2))){
                                            entry2 = dent2 -> d_name;
                                            sourceFolderPath3 = sourceFolderPath2+"/"+entry2;
                                            mergeProductPath3 = mergeProductPath2+"/"+entry2;
                                            
                                            if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && (int)entry2.find("~Sorted") != -1){
                                                dir3 = opendir(sourceFolderPath3.c_str());
                                                
                                                if (dir3 != NULL){
                                                    while ((dent3 = readdir(dir3))){
                                                        entry3 = dent3 -> d_name;
                                                        sourceFolderPath4 = sourceFolderPath3+"/"+entry3;
                                                        mergeProductPath4 = mergeProductPath3+"/"+entry3;
                                                        
                                                        if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store" && (int)entry3.find("FOV") != -1){
                                                            dir4 = opendir(sourceFolderPath4.c_str());
                                                            
                                                            if (dir4 != NULL){
                                                                while ((dent4 = readdir(dir4))){
                                                                    entry4 = dent4 -> d_name;
                                                                    
                                                                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                                                    arrayFileDelete [fileDeleteCount] = sourceFolderPath4+"/@"+entry4, fileDeleteCount++;
                                                                    
                                                                    if (fileDeleteCount2+5 > fileDeleteLimit2) [self fileDeleteUpDate2];
                                                                    arrayFileDelete2 [fileDeleteCount2] = mergeProductPath4, fileDeleteCount2++;
                                                                }
                                                                
                                                                closedir(dir4);
                                                            }
                                                        }
                                                    }
                                                    
                                                    closedir(dir3);
                                                }
                                            }
                                        }
                                        
                                        closedir(dir2);
                                    }
                                }
                            }
                        }
                        
                        closedir(dir);
                        
                        string imageNameExtract;
                        string imageNameExtract2;
                        string fileExtension;
                        
                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            imageNameExtract = arrayFileDelete [counter1].substr(arrayFileDelete [counter1].find("@")+1);
                            imageNameExtract2 = arrayFileDelete [counter1].substr(0, arrayFileDelete [counter1].find("@"));
                            
                            sourceFolderPath5 = imageNameExtract2+imageNameExtract;
                            
                            if (imageNameExtract != "." && imageNameExtract != ".." && imageNameExtract != ".DS_Store" && ((int)imageNameExtract.find(".tif") != -1 || (int)imageNameExtract.find(".bmp") != -1)){
                                if ((int)imageNameExtract.find("bmp") != -1) fileExtension = ".bmp";
                                else if ((int)imageNameExtract.find("tif") != -1) fileExtension = ".tif";
                                
                                stringExtract = imageNameExtract.substr(0, imageNameExtract.find("_"));
                                stringExtract2 = imageNameExtract.substr(imageNameExtract.find("_")+1);
                                sourceTimeExtract = stringExtract2.substr(0, 4);
                                stringExtract2 = stringExtract2.substr(4);
                                stringExtract2 = stringExtract2.substr(0, stringExtract2.find(fileExtension));
                                
                                newEntryNoString = to_string(lastCount+atoi(sourceTimeExtract.c_str()));
                                
                                if (newEntryNoString.length() == 1) newEntryNoString = "000"+newEntryNoString;
                                else if (newEntryNoString.length() == 2) newEntryNoString = "00"+newEntryNoString;
                                else if (newEntryNoString.length() == 3) newEntryNoString = "0"+newEntryNoString;
                                
                                if (fileExtension == ".tif") mergeProductPath5 = arrayFileDelete2 [counter1]+"/"+stringExtract+"_"+newEntryNoString+stringExtract2+".tif"+processingIFCountString;
                                else if (fileExtension == ".bmp") mergeProductPath5 = arrayFileDelete2 [counter1]+"/"+stringExtract+"_"+newEntryNoString+stringExtract2+".bmp"+processingIFCountString;
                                
                                rename (sourceFolderPath5.c_str(), mergeProductPath5.c_str());
                            }
                        }
                    }
                    
                    directoryRmv = 2;
                    pathToDelete = sourceProductPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerFour:directoryRmv];
                    
                    directoryRmv = 2;
                    pathToDelete = sourceProductPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerThree:directoryRmv];
                    
                    directoryRmv = 1;
                    pathToDelete = sourceProductPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                    
                    directoryRmv = 2;
                    pathToDelete = sourceProductPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                    
                    remove (sourceProductPath.c_str());
                    
                    processingIFStatus = 2;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses parameterSave];
                    
                    [batchText1 setTextColor:[NSColor purpleColor]];
                    [batchText1 setStringValue:@"Batch (Backup) IF R-To-S"];
                    [runStatusDisplay setStringValue:@"IF Done"];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    [backSave stopAnimation:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Quit Contrast Setting"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Quit Focal Image Sel."];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else if (initialRunStatus == "8" && autoBatchMode == 3){
            if (runStatusContrast == 0){
                if (processingIFStatus == 1 && largestFileNoBatch < batchImageIFCount){
                    int stringLength = (int)batchImagePathNameHold.length();
                    
                    string processingIFCountString = to_string(processingIFCount);
                    
                    if (processingIFCountString.length() == 1) processingIFCountString = "0"+processingIFCountString;
                    
                    string noIFBodyName = batchImagePathNameHold.substr(0, (unsigned long)stringLength-2);
                    string mergeImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images"+"/"+noIFBodyName+"_Image";
                    
                    string entry;
                    string entry2;
                    string stringExtract;
                    string stringExtract2;
                    string stitchedFolderPath2;
                    string stitchedFolderPath3;
                    string mergeImagePath2;
                    string mergeImagePath3;
                    string newEntryNoString;
                    
                    DIR *dir;
                    struct dirent *dent;
                    DIR *dir2;
                    struct dirent *dent2;
                    
                    int modeA = 0;
                    int modeB = 1;
                    pathToDelete = mergeImagePath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    int lastRoundNumber = [controllerSubProcesses fileDeleteLayerTwoStitch:modeA:modeB];
                    
                    if (lastRoundNumber == 1){
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Previously Created Images Found And Will Be Deleted"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        modeA = 0;
                        modeB = 0;
                        pathToDelete = mergeImagePath;
                        
                        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                        [controllerSubProcesses fileDeleteLayerTwoStitch:modeA:modeB];
                    }
                    
                    [backSave startAnimation:self];
                    
                    modeA = 0;
                    modeB = 2;
                    pathToDelete = mergeImagePath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    int lastCount = [controllerSubProcesses fileDeleteLayerTwoStitch:modeA:modeB];
                    
                    dir = opendir(stitchedFolderPath.c_str());
                    fileDeleteCount = 0;
                    fileDeleteCount2 = 0;
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("_Stitch") != -1){
                                stitchedFolderPath2 = stitchedFolderPath+"/"+entry;
                                mergeImagePath2 = mergeImagePath+"/"+entry;
                                
                                dir2 = opendir(stitchedFolderPath2.c_str());
                                
                                if (dir2 != NULL){
                                    while ((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                        arrayFileDelete [fileDeleteCount] = stitchedFolderPath2+"/@"+entry2, fileDeleteCount++;
                                        
                                        if (fileDeleteCount2+5 > fileDeleteLimit2) [self fileDeleteUpDate2];
                                        arrayFileDelete2 [fileDeleteCount2] = mergeImagePath2, fileDeleteCount2++;
                                    }
                                    
                                    closedir(dir2);
                                }
                            }
                        }
                        
                        closedir(dir);
                        
                        string imageNameExtract;
                        string imageNameExtract2;
                        string fileExtension;
                        
                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            imageNameExtract = arrayFileDelete [counter1].substr(arrayFileDelete [counter1].find("@")+1);
                            imageNameExtract2 = arrayFileDelete [counter1].substr(0, arrayFileDelete [counter1].find("@"));
                            
                            stitchedFolderPath3 = imageNameExtract2+imageNameExtract;
                            mergeImagePath3 = arrayFileDelete2 [counter1]+"/"+imageNameExtract;
                            
                            if ((int)imageNameExtract.find("STimage") != -1){
                                if ((int)imageNameExtract.find(".tif") != -1) fileExtension = ".tif";
                                else if ((int)imageNameExtract.find(".bmp") != -1) fileExtension = ".bmp";
                                
                                stringExtract = imageNameExtract.substr(8, 4);
                                stringExtract2 = imageNameExtract.substr(12);
                                
                                if (stringExtract2.find(fileExtension) == 0) stringExtract2 = "";
                                else stringExtract2 = stringExtract2.substr(0, stringExtract2.find(fileExtension));
                                
                                newEntryNoString = to_string(lastCount+atoi(stringExtract.c_str()));
                                
                                if (newEntryNoString.length() == 1) newEntryNoString = "000"+newEntryNoString;
                                else if (newEntryNoString.length() == 2) newEntryNoString = "00"+newEntryNoString;
                                else if (newEntryNoString.length() == 3) newEntryNoString = "0"+newEntryNoString;
                                
                                if (fileExtension == ".tif") mergeImagePath3 = arrayFileDelete2 [counter1]+"/STimage "+newEntryNoString+stringExtract2+".TIF"+processingIFCountString;
                                else if (fileExtension == ".bmp") mergeImagePath3 = arrayFileDelete2 [counter1]+"/STimage "+newEntryNoString+stringExtract2+".BMP"+processingIFCountString;
                                
                                rename (stitchedFolderPath3.c_str(), mergeImagePath3.c_str());
                            }
                        }
                    }
                    
                    modeA = 0;
                    modeB = 3;
                    pathToDelete = stitchedFolderPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerTwoStitch:modeA:modeB];
                    
                    int directoryRmv = 2;
                    pathToDelete = stitchedFolderPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                    
                    remove (stitchedFolderPath.c_str());
                    
                    string sourceProductPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+batchImagePathNameHold+"_Products";
                    
                    directoryRmv = 2;
                    pathToDelete = sourceProductPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerFour:directoryRmv];
                    
                    directoryRmv = 2;
                    pathToDelete = sourceProductPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerThree:directoryRmv];
                    
                    directoryRmv = 1;
                    pathToDelete = sourceProductPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                    
                    directoryRmv = 2;
                    pathToDelete = sourceProductPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                    
                    remove (sourceProductPath.c_str());
                    
                    processingIFStatus = 2;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses parameterSave];
                    
                    [batchText2 setTextColor:[NSColor purpleColor]];
                    [batchText2 setStringValue:@"Batch (Backup) IF R-To-S"];
                    [runStatusDisplay setStringValue:@"IF Ready"];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    [backSave stopAnimation:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Process Remaining Images"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Quit Contrast Setting"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"IF Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

//----BackUp set----
-(IBAction)backUpNameSet:(id)sender{
    if (initialRunStatus == "nil" && autoBatchMode == 1 && processingIFStatus == 0){
        string analysisNameSetTemp = [[inputDataSet stringValue] UTF8String];
        
        if (autoRunOnOff == 0 && batchBackupOnOff == 0 && batchImageOnOff == 0){
            nameCheckString = analysisNameSetTemp;
            
            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
            int checkResults = [controllerSubProcesses nameCheck];
            
            if (checkResults == 0){
                if (nameCheckString.length() < 4 || nameCheckString.length() > 15) checkResults = 1;
            }
            
            if (checkResults == 0){
                backUpNameHold = nameCheckString;
                [inputDataSet setStringValue:@""];
                [backUpName setStringValue:@(backUpNameHold.c_str())];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                [inputDataSet setStringValue:@""];
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Stop Auto/Batch Processing Or IF Mode On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            [inputDataSet setStringValue:@""];
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)backUpSet:(id)sender{
    if (backUpNameHold != "nil" && autoBatchMode == 1){
        if (autoRunOnOff == 0 && batchBackupOnOff == 0 && batchImageOnOff == 0){
            NSOpenPanel *openDlg = [NSOpenPanel openPanel];
            [openDlg setCanChooseFiles:NO];
            [openDlg setCanChooseDirectories:YES];
            [openDlg setCanCreateDirectories:YES];
            
            if ([openDlg runModal] == NSModalResponseOK){
                NSArray *files = [openDlg URLs];
                NSString *fileName = [[files objectAtIndex:0] absoluteString];
                
                string directoryPathExtract = [fileName UTF8String];
                
                int findString1 = (int)directoryPathExtract.find("/Users/");
                if (findString1 == -1) findString1 = (int)directoryPathExtract.find("/Volumes/");
                
                unsigned long directoryLength = directoryPathExtract.length();
                string extractedID = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
                string extractedID2;
                
                int terminationFlag = 0;
                
                do{
                    
                    terminationFlag = 1;
                    
                    if ((int)extractedID.find("%20") != -1){
                        extractedID2 = extractedID.substr(0, extractedID.find("%20"));
                        extractedID = extractedID.substr(extractedID.find("%20")+3);
                        extractedID = extractedID2+" "+extractedID;
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                int matchFlag = 0;
                
                for (int counter1 = 0; counter1 < backUpDriveNameCount; counter1++){
                    if (arrayBackUpDriveName [counter1] == extractedID){
                        matchFlag = 1;
                        break;
                    }
                }
                
                if (matchFlag == 0){
                    if (backUpDriveNameCount+1 < 101){
                        arrayBackUpDriveName [backUpDriveNameCount] = extractedID, backUpDriveNameCount++;
                        
                        [backUpStatus setIntegerValue:backUpDriveNameCount];
                        
                        ofstream oin;
                        oin.open(backUpDirectoryPath.c_str(), ios::out);
                        oin<<backUpNameHold<<endl;
                        
                        for (int counter1 = 0; counter1 < backUpDriveNameCount; counter1++) oin<<arrayBackUpDriveName [counter1]<<endl;
                        
                        oin.close();
                        
                        if (backUpDisplayListCount == 0){
                            arrayBackUpDisplayList [backUpDisplayListCount] = "BL", backUpDisplayListCount++;
                            arrayBackUpDisplayList [backUpDisplayListCount] = backUpNameHold, backUpDisplayListCount++;
                        }
                        
                        arrayBackUpDisplayList [backUpDisplayListCount] = extractedID, backUpDisplayListCount++;
                        arrayBackUpDisplayList [backUpDisplayListCount] = "N: nil, F: nil, L: nil, S: O", backUpDisplayListCount++;
                        
                        oin.open(backUpResultsPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < backUpDisplayListCount; counter1++) oin<<arrayBackUpDisplayList [counter1]<<endl;
                        
                        oin.close();
                        
                        tableViewPage = 1;
                        [tableViewList reloadData];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Exceed Entry Limit (100)"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                    }
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Stop Auto/Batch Processing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

//----Automate mode----
-(IBAction)autoProcessStart:(id)sender{
    if (initialRunStatus == "8" && autoBatchMode == 1){
        if (autoProcessCommit == "nil"){
            autoProcessCommit = "1";
            purgeCount = 0;
            
            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
            [controllerSubProcesses parameterSave];
            
            [autoStatus setStringValue:@"Hold"];
            
            if (processingIFStatus == 0) [runStatusDisplay setStringValue:@"Proc."];
        }
        
        if (autoRunOnOff == 0){
            if (processingIFStatus != 2){
                if (runStatusFocalImage == 0 && runStatusContrast == 0){
                    autoRunOnOff = 1;
                    [autoStatus setStringValue:@"On"];
                    
                    remove (instructionFIPath.c_str());
                    remove (instructionFIPath2.c_str());
                    remove (instructionAPPath.c_str());
                    remove (instructionCSPath.c_str());
                    remove (instructionFLPath.c_str());
                    remove (instructionNamePath.c_str());
                    
                    fileUploadStartCount = 0;
                    focalContrastRetryCount = 0;
                    runStatusFocalImage = 1;
                    runStatusContrast = 1;
                    autoStepCount = 0;
                    
                    string launchProgramFocal = launchProgramPath+"/"+"Focal_Image_Selection.app";
                    string launchProgramContrast = launchProgramPath+"/"+"Contrast_Set.app";
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToAutoProcess object:self];
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCommFocal object:self];
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCommContrast object:self];
                    
                    NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
                    [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramFocal.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
                    [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramContrast.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
                    
                    launchCheck = 1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Auto Processing On"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Start IF Mode"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else if (autoRunOnOff == 1){
            autoTimerInvalidate = 1;
            [autoStatus setStringValue:@"Wait"];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)autoProcessRedo:(id)sender{
    if (autoBatchMode == 1 && initialRunStatus == "8" && autoProcessCommit == "1" && processingIFStatus == 0){
        if (autoRunOnOff == 0){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert addButtonWithTitle:@"Cancel"];
            [alert setMessageText:@"Perform Initial Setting Again?"];
            [alert setAlertStyle:NSAlertStyleWarning];
            
            if ([alert runModal] == NSAlertFirstButtonReturn){
                autoProcessCommit = "nil";
                
                [backSave startAnimation:self];
                [self settingRedo];
                [backSave stopAnimation:self];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Auto Processng On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Auto Mode Off Or IF Mode On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)settingRedo{
    if (initialRunStatus != "nil"){
        if ((autoBatchMode == 1 && autoProcessCommit == "nil") || (autoBatchMode == 2 && batchBackupOperationCommit == "nil") || (autoBatchMode == 3 && batchImageOperationCommit == "nil")){
            
            if (processingIFStatus == 0){
                initialRunStatus = "nil";
                [initialRun setTextColor:[NSColor blackColor]];
                [initialRun setStringValue:@"nil"];
                [initialRunOn setTextColor:[NSColor blackColor]];
                [initialRunOn setStringValue:@"Initial Run"];
                [runStatusDisplay setStringValue:@"None"];
                
                imageTimePointAccumulationCounter = 0;
                autoTotalCount = 0;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses parameterSave];
                
                if (autoBatchMode == 1){
                    string treatmentString;
                    string fovNumberString;
                    
                    for (int counter1 = 0; counter1 < 16; counter1++) arrayNameList [counter1] = "nil";
                    
                    for (int counter1 = 7; counter1 < 23; counter1++){
                        treatmentString = arrayNameList [counter1-7];
                        fovNumberString = to_string(arrayFOVNumberList [counter1-7]);
                        
                        if (treatmentString == "nil" && fovNumberString == "0") arraySummaryList [counter1] = "nil";
                        else if (treatmentString != "nil" && fovNumberString == "0") arraySummaryList [counter1] = treatmentString+" (nil)";
                        else if (treatmentString == "nil" && fovNumberString != "0") arraySummaryList [counter1] = "nil ("+fovNumberString+")";
                        else arraySummaryList [counter1] = treatmentString+" ("+fovNumberString+")";
                    }
                    
                    arraySummaryList [5] = "nil";
                    arraySummaryList [24] = "nil";
                    arraySummaryList [25] = "nil";
                    arraySummaryList [26] = "nil";
                    arraySummaryList [27] = "nil";
                    arraySummaryList [28] = "nil";
                    arraySummaryList [29] = "nil";
                    
                    remove (backupResultsPath.c_str());
                    
                    for (int counter1 = 1; counter1 < backUpDisplayListCount/2; counter1++){
                        arrayBackUpDisplayList [counter1*2+1] = "N: nil, F: nil, L: nil, S: O";
                    }
                }
                
                ofstream oin;
                
                oin.open(summaryDataPath.c_str(), ios::out);
                for (int counter1 = 0; counter1 < summaryListCount; counter1++) oin<<arraySummaryList [counter1]<<endl;
                oin.close();
                
                oin.open(nameListDataPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < 16; counter1++) oin<<arrayNameList [counter1]<<endl;
                for (int counter1 = 0; counter1 < 16; counter1++) oin<<arrayFOVNumberList [counter1]<<endl;
                
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"0"<<endl;
                oin<<"0"<<endl;
                oin<<"0"<<endl;
                
                oin.close();
                
                if (autoBatchMode == 1 || autoBatchMode == 2){
                    string clearFilePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products";
                    
                    //----Products clear---------
                    int directoryRmv = 2;
                    pathToDelete = clearFilePath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerFour:directoryRmv];
                    
                    directoryRmv = 2;
                    pathToDelete = clearFilePath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerThree:directoryRmv];
                    
                    directoryRmv = 1;
                    pathToDelete = clearFilePath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                    
                    directoryRmv = 1;
                    pathToDelete = clearFilePath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                    
                    //----Stitch clear---------
                    directoryRmv = 0;
                    pathToDelete = stitchedFolderPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                    
                    directoryRmv = 1;
                    pathToDelete = stitchedFolderPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                    
                    //----Stitch Temp clear---------
                    directoryRmv = 0;
                    pathToDelete = productsStitchTempPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                    
                    directoryRmv = 1;
                    pathToDelete = productsStitchTempPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                    
                    //----Data Image folder clear---------
                    directoryRmv = 1;
                    pathToDelete = dataImportFolderPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                    
                    //----Data File clear---------
                    directoryRmv = 0;
                    pathToDelete = dataFilesPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                    
                    directoryRmv = 1;
                    pathToDelete = dataFilesPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                    
                    //----Named clear---------
                    directoryRmv = 0;
                    pathToDelete = namedFilesPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                    
                    directoryRmv = 1;
                    pathToDelete = namedFilesPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                    
                    //----BackUp clear---------
                    directoryRmv = 0;
                    pathToDelete = backUpDataPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                    
                    directoryRmv = 1;
                    pathToDelete = backUpDataPath;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                }
                
                [currentTimePoint setStringValue:@"nil"];
                
                remove (instructionFIPath.c_str());
                remove (instructionFIPath2.c_str());
                remove (instructionAPPath.c_str());
                remove (instructionCSPath.c_str());
                remove (loadingCompletePath.c_str());
                remove (loadingCompleteFLPath.c_str());
                remove (loadingCompleteCSPath.c_str());
                remove (instructionFLPath.c_str());
                remove (instructionNamePath.c_str());
                
                summarySetCall = 2;
                tableViewPage = 0;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else if (processingIFStatus == 1 && autoBatchMode == 1){
                if (processingIFStatus == 0) bodyNameHold = bodyNameHold+"IF";
                
                [analysisName setStringValue:@(bodyNameHold.c_str())];
                
                processingIFStatus = 1;
                
                productsFilesImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Source_Images";
                productsFilesInfoPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Analysis_Information";
                productsFocalTempPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Temp_Images";
                stitchedFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images"+"/"+bodyNameHold+"_Image";
                
                runStatusFileUpLoad = 0;
                runStatusTreatmentNameSet = 0;
                runStatusFocalImage = 0;
                runStatusContrast = 0;
                fluorescentColor1 = 0;
                fluorescentColor2 = 0;
                fluorescentColor3 = 0;
                fluorescentColor4 = 0;
                fluorescentColor5 = 0;
                fluorescentColor6 = 0;
                fluorescent1 = "nil";
                fluorescent2 = "nil";
                fluorescent3 = "nil";
                fluorescent4 = "nil";
                fluorescent5 = "nil";
                fluorescent6 = "nil";
                fluorescentNew1 = "nil";
                fluorescentNew2 = "nil";
                fluorescentNew3 = "nil";
                fluorescentNew4 = "nil";
                fluorescentNew5 = "nil";
                fluorescentNew6 = "nil";
                extensionInfoDisplay = "nil";
                initialRunStatus = "nil";
                autoProcessCommit = "nil";
                
                [autoText setTextColor:[NSColor purpleColor]];
                [autoText setStringValue:@"Auto Processing IF On"];
                [currentTimePoint setStringValue:@"nil"];
                
                [fileUpLoadStatus setTextColor:[NSColor blueColor]];
                [fileUpLoadStatus setStringValue:@"Off"];
                [treatNameSetStatus setTextColor:[NSColor blueColor]];
                [treatNameSetStatus setStringValue:@"Off"];
                [focalImageStatus setTextColor:[NSColor blueColor]];
                [focalImageStatus setStringValue:@"Off"];
                [contrastSetStatus setTextColor:[NSColor blueColor]];
                [contrastSetStatus setStringValue:@"Off"];
                
                [fileUpLoadStatusOn setTextColor:[NSColor blueColor]];
                [fileUpLoadStatusOn setStringValue:@"File up-loading"];
                [focalImageStatusOn setTextColor:[NSColor blueColor]];
                [focalImageStatusOn setStringValue:@"Focal Image Sel."];
                [contrastSetStatusOn setTextColor:[NSColor blueColor]];
                [contrastSetStatusOn setStringValue:@"Contrast Set"];
                
                [initialRun setTextColor:[NSColor blackColor]];
                [initialRun setStringValue:@"nil"];
                [initialRunOn setTextColor:[NSColor blackColor]];
                [initialRunOn setStringValue:@"Initial Run"];
                
                summaryListCount = 0;
                lastPurgeFlag = 0;
                lastPurgeSetFlag = 0;
                autoTotalCount = 0;
                imageTimePointAccumulationCounter = 0;
                
                remove (instructionFIPath.c_str());
                remove (instructionFIPath2.c_str());
                remove (instructionAPPath.c_str());
                remove (instructionCSPath.c_str());
                remove (loadingCompletePath.c_str());
                remove (loadingCompleteFLPath.c_str());
                remove (loadingCompleteCSPath.c_str());
                remove (summaryDataPath.c_str());
                remove (instructionFLPath.c_str());
                remove (instructionNamePath.c_str());
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses parameterSave];
                
                int directoryRmv = 1;
                pathToDelete = dataImportFolderPath;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                
                directoryRmv = 0;
                pathToDelete = dataFilesPath;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                
                directoryRmv = 1;
                pathToDelete = dataFilesPath;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                
                directoryRmv = 0;
                pathToDelete = namedFilesPath;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                
                directoryRmv = 1;
                pathToDelete = namedFilesPath;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                
                directoryRmv = 0;
                pathToDelete = productsStitchTempPath;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                
                directoryRmv = 2;
                pathToDelete = productsStitchTempPath;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                
                rmdir (productsStitchTempPath.c_str());
                
                for (int counter1 = 0; counter1 < 16; counter1++) arrayNameList [counter1] = "nil";
                for (int counter1 = 0; counter1 < 16; counter1++) arrayFOVNumberList [counter1] = 0;
                
                string getString;
                
                ifstream fin;
                
                fin.open(nameListDataPath.c_str(),ios::in);
                
                if (fin.is_open()){
                    for (int counter1 = 0; counter1 < 16; counter1++){
                        getline(fin, getString), arrayNameList [counter1] = getString;
                    }
                    
                    for (int counter1 = 0; counter1 < 16; counter1++){
                        getline(fin, getString);
                        
                        if (getString != "nil") arrayFOVNumberList [counter1] = atoi(getString.c_str());
                        else arrayFOVNumberList [counter1] = 0;
                    }
                    
                    fin.close();
                }
                
                ofstream oin;
                
                oin.open(nameListDataPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < 16; counter1++) oin<<arrayNameList [counter1]<<endl;
                for (int counter1 = 0; counter1 < 16; counter1++) oin<<arrayFOVNumberList [counter1]<<endl;
                
                oin<<fluorescent1<<endl;
                oin<<fluorescent2<<endl;
                oin<<fluorescent3<<endl;
                oin<<fluorescent4<<endl;
                oin<<fluorescent5<<endl;
                oin<<fluorescent6<<endl;
                oin<<fluorescentNew1<<endl;
                oin<<fluorescentNew2<<endl;
                oin<<fluorescentNew3<<endl;
                oin<<fluorescentNew4<<endl;
                oin<<fluorescentNew5<<endl;
                oin<<fluorescentNew6<<endl;
                
                string colorNoString = to_string(fluorescentColor1);
                oin<<colorNoString<<endl;
                
                colorNoString = to_string(fluorescentColor2);
                oin<<colorNoString<<endl;
                
                colorNoString = to_string(fluorescentColor3);
                oin<<colorNoString<<endl;
                
                colorNoString = to_string(fluorescentColor4);
                oin<<colorNoString<<endl;
                
                colorNoString = to_string(fluorescentColor5);
                oin<<colorNoString<<endl;
                
                colorNoString = to_string(fluorescentColor6);
                oin<<colorNoString<<endl;
                
                oin.close();
                
                tableViewPage = 0;
                summarySetCall = 1;
                consoleDisplayCall = 1;
            }
            else if (processingIFStatus == 1 && autoBatchMode == 2){
                if (processingIFStatus == 0){
                    bodyNameHold = bodyNameHold+"IF";
                    batchBackUpNameHold = batchBackUpNameHold+"IF";
                }
                
                processingIFStatus = 1;
                
                productsFilesImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Source_Images";
                productsFilesInfoPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Analysis_Information";
                stitchedFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images"+"/"+bodyNameHold+"_Image";
                
                runStatusFocalImage = 0;
                runStatusContrast = 0;
                fluorescentColor1 = 0;
                fluorescentColor2 = 0;
                fluorescentColor3 = 0;
                fluorescentColor4 = 0;
                fluorescentColor5 = 0;
                fluorescentColor6 = 0;
                fluorescentCount = 0;
                fluorescent1 = "nil";
                fluorescent2 = "nil";
                fluorescent3 = "nil";
                fluorescent4 = "nil";
                fluorescent5 = "nil";
                fluorescent6 = "nil";
                fluorescentNew1 = "nil";
                fluorescentNew2 = "nil";
                fluorescentNew3 = "nil";
                fluorescentNew4 = "nil";
                fluorescentNew5 = "nil";
                fluorescentNew6 = "nil";
                
                extensionInfoDisplay = "nil";
                initialRunStatus = "nil";
                batchBackupOperationCommit = "nil";
                
                [batchText1 setTextColor:[NSColor purpleColor]];
                [batchText1 setStringValue:@"Batch (Backup) IF On"];
                [currentTimePoint setStringValue:@"nil"];
                
                [focalImageStatus setTextColor:[NSColor blueColor]];
                [focalImageStatus setStringValue:@"Off"];
                [contrastSetStatus setTextColor:[NSColor blueColor]];
                [contrastSetStatus setStringValue:@"Off"];
                
                [focalImageStatusOn setTextColor:[NSColor blueColor]];
                [focalImageStatusOn setStringValue:@"Focal Image Sel."];
                [contrastSetStatusOn setTextColor:[NSColor blueColor]];
                [contrastSetStatusOn setStringValue:@"Contrast Set"];
                
                [initialRun setTextColor:[NSColor blackColor]];
                [initialRun setStringValue:@"nil"];
                [initialRunOn setTextColor:[NSColor blackColor]];
                [initialRunOn setStringValue:@"Initial Run"];
                
                summaryListCount = 0;
                lastPurgeFlag = 0;
                lastPurgeSetFlag = 0;
                imageTimePointAccumulationCounter = 0;
                
                remove (instructionFIPath.c_str());
                remove (instructionFIPath2.c_str());
                remove (instructionAPPath.c_str());
                remove (instructionCSPath.c_str());
                remove (loadingCompletePath.c_str());
                remove (loadingCompleteFLPath.c_str());
                remove (loadingCompleteCSPath.c_str());
                remove (instructionFLPath.c_str());
                remove (instructionNamePath.c_str());
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses parameterSave];
                
                int directoryRmv = 0;
                pathToDelete = namedFilesPath;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                
                directoryRmv = 1;
                pathToDelete = namedFilesPath;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                
                for (int counter1 = 0; counter1 < 16; counter1++) arrayNameList [counter1] = "nil";
                for (int counter1 = 0; counter1 < 16; counter1++) arrayFOVNumberList [counter1] = 0;
                
                string getString;
                
                ifstream fin;
                
                fin.open(nameListDataPath.c_str(),ios::in);
                
                if (fin.is_open()){
                    for (int counter1 = 0; counter1 < 16; counter1++){
                        getline(fin, getString), arrayNameList [counter1] = getString;
                    }
                    
                    for (int counter1 = 0; counter1 < 16; counter1++){
                        getline(fin, getString);
                        
                        if (getString != "nil") arrayFOVNumberList [counter1] = atoi(getString.c_str());
                        else arrayFOVNumberList [counter1] = 0;
                    }
                    
                    fin.close();
                }
                
                ofstream oin;
                
                oin.open(nameListDataPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < 16; counter1++) oin<<arrayNameList [counter1]<<endl;
                for (int counter1 = 0; counter1 < 16; counter1++) oin<<arrayFOVNumberList [counter1]<<endl;
                
                oin<<fluorescent1<<endl;
                oin<<fluorescent2<<endl;
                oin<<fluorescent3<<endl;
                oin<<fluorescent4<<endl;
                oin<<fluorescent5<<endl;
                oin<<fluorescent6<<endl;
                oin<<fluorescentNew1<<endl;
                oin<<fluorescentNew2<<endl;
                oin<<fluorescentNew3<<endl;
                oin<<fluorescentNew4<<endl;
                oin<<fluorescentNew5<<endl;
                oin<<fluorescentNew6<<endl;
                
                string colorNoString = to_string(fluorescentColor1);
                oin<<colorNoString<<endl;
                
                colorNoString = to_string(fluorescentColor2);
                oin<<colorNoString<<endl;
                
                colorNoString = to_string(fluorescentColor3);
                oin<<colorNoString<<endl;
                
                colorNoString = to_string(fluorescentColor4);
                oin<<colorNoString<<endl;
                
                colorNoString = to_string(fluorescentColor5);
                oin<<colorNoString<<endl;
                
                colorNoString = to_string(fluorescentColor6);
                oin<<colorNoString<<endl;
                
                oin.close();
                
                arrayBatchPathName [2] = batchBackUpNameHold;
                
                oin.open(batchProcessBackUpPath.c_str(), ios::out);
                for (int counter1 = 1; counter1 < batchPathNameCount; counter1++) oin<<arrayBatchPathName [counter1]<<endl;
                oin.close();
                
                [batchSaveName1 setStringValue:@(batchBackUpNameHold.c_str())];
                
                tableViewPage = 0;
                summarySetCall = 1;
                consoleDisplayCall = 1;
            }
            else if (processingIFStatus == 1 && autoBatchMode == 3){
                if (processingIFStatus == 0){
                    bodyNameHold = batchImagePathNameHold+"IF";
                    batchImagePathNameHold = batchImagePathNameHold+"IF";
                }
                
                processingIFStatus = 1;
                newIFFoundFlag = 0;
                
                productsFilesImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Source_Images";
                productsFilesInfoPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Analysis_Information";
                productsFocalTempPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameHold+"_Products"+"/"+"Temp_Images";
                stitchedFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images"+"/"+bodyNameHold+"_Image";
                
                batchImageIFCount = 1;
                runStatusContrast = 0;
                fluorescentColor1 = 0;
                fluorescentColor2 = 0;
                fluorescentColor3 = 0;
                fluorescentColor4 = 0;
                fluorescentColor5 = 0;
                fluorescentColor6 = 0;
                fluorescentCount = 0;
                fluorescent1 = "nil";
                fluorescent2 = "nil";
                fluorescent3 = "nil";
                fluorescent4 = "nil";
                fluorescent5 = "nil";
                fluorescent6 = "nil";
                fluorescentNew1 = "nil";
                fluorescentNew2 = "nil";
                fluorescentNew3 = "nil";
                fluorescentNew4 = "nil";
                fluorescentNew5 = "nil";
                fluorescentNew6 = "nil";
                
                extensionInfoDisplay = "nil";
                initialRunStatus = "nil";
                batchImageOperationCommit = "nil";
                
                [batchText2 setTextColor:[NSColor purpleColor]];
                [batchText2 setStringValue:@"Batch (Image) IF On"];
                [currentTimePoint setStringValue:@"nil"];
                
                [contrastSetStatus setTextColor:[NSColor blueColor]];
                [contrastSetStatus setStringValue:@"Off"];
                [contrastSetStatusOn setTextColor:[NSColor blueColor]];
                [contrastSetStatusOn setStringValue:@"Contrast Set"];
                
                [initialRun setTextColor:[NSColor blackColor]];
                [initialRun setStringValue:@"nil"];
                [initialRunOn setTextColor:[NSColor blackColor]];
                [initialRunOn setStringValue:@"Initial Run"];
                
                summaryListCount = 0;
                imageFolderListCount = 0;
                lastPurgeFlag = 0;
                lastPurgeSetFlag = 0;
                
                remove (instructionFIPath.c_str());
                remove (instructionFIPath2.c_str());
                remove (instructionAPPath.c_str());
                remove (instructionCSPath.c_str());
                remove (loadingCompletePath.c_str());
                remove (loadingCompleteFLPath.c_str());
                remove (loadingCompleteCSPath.c_str());
                remove (instructionFLPath.c_str());
                remove (instructionNamePath.c_str());
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses parameterSave];
                
                tableViewPage = 0;
                summarySetCall = 1;
                consoleDisplayCall = 1;
                
                for (int counter1 = 0; counter1 < 16; counter1++) arrayNameList [counter1] = "nil";
                for (int counter1 = 0; counter1 < 16; counter1++) arrayFOVNumberList [counter1] = 0;
                
                string getString;
                
                ifstream fin;
                
                fin.open(nameListDataPath.c_str(),ios::in);
                
                if (fin.is_open()){
                    for (int counter1 = 0; counter1 < 16; counter1++){
                        getline(fin, getString), arrayNameList [counter1] = getString;
                    }
                    
                    for (int counter1 = 0; counter1 < 16; counter1++){
                        getline(fin, getString);
                        
                        if (getString != "nil") arrayFOVNumberList [counter1] = atoi(getString.c_str());
                        else arrayFOVNumberList [counter1] = 0;
                    }
                    
                    fin.close();
                }
                
                ofstream oin;
                
                oin.open(nameListDataPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < 16; counter1++) oin<<arrayNameList [counter1]<<endl;
                for (int counter1 = 0; counter1 < 16; counter1++) oin<<arrayFOVNumberList [counter1]<<endl;
                
                oin<<fluorescent1<<endl;
                oin<<fluorescent2<<endl;
                oin<<fluorescent3<<endl;
                oin<<fluorescent4<<endl;
                oin<<fluorescent5<<endl;
                oin<<fluorescent6<<endl;
                oin<<fluorescentNew1<<endl;
                oin<<fluorescentNew2<<endl;
                oin<<fluorescentNew3<<endl;
                oin<<fluorescentNew4<<endl;
                oin<<fluorescentNew5<<endl;
                oin<<fluorescentNew6<<endl;
                
                string colorNoString = to_string(fluorescentColor1);
                oin<<colorNoString<<endl;
                
                colorNoString = to_string(fluorescentColor2);
                oin<<colorNoString<<endl;
                
                colorNoString = to_string(fluorescentColor3);
                oin<<colorNoString<<endl;
                
                colorNoString = to_string(fluorescentColor4);
                oin<<colorNoString<<endl;
                
                colorNoString = to_string(fluorescentColor5);
                oin<<colorNoString<<endl;
                
                colorNoString = to_string(fluorescentColor6);
                oin<<colorNoString<<endl;
                
                oin.close();
                
                oin.open(batchProcessImagePath.c_str(), ios::out);
                oin<<batchImageBodyName<<endl;
                oin<<batchImagePathNameHold<<endl;
                oin<<batchImagePathInfo<<endl;
                oin<<filePickUpCount<<endl;
                oin<<largestFileNoBatch<<endl;
                oin.close();
                
                [batchSaveName2 setStringValue:@(batchImagePathNameHold.c_str())];
                
                tableViewPage = 0;
                summarySetCall = 1;
                consoleDisplayCall = 1;
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Auto/Batch Processing On: Use Refresh"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Initial Run Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

//----Net connection set----
-(IBAction)directoryData:(id)sender{
    if (initialRunStatus == "nil" && autoBatchMode == 1 && runStatusXYMap == 0){
        NSOpenPanel *openDlg = [NSOpenPanel openPanel];
        [openDlg setCanChooseFiles:NO];
        [openDlg setCanChooseDirectories:YES];
        [openDlg setCanCreateDirectories:YES];
        
        if ([openDlg runModal] == NSModalResponseOK){
            NSArray *files = [openDlg URLs];
            NSString *fileName = [[files objectAtIndex:0] absoluteString];
            
            string directoryPathExtract = [fileName UTF8String];
            
            if ((int)directoryPathExtract.find("/Volumes/") != -1){
                unsigned long directoryLength = directoryPathExtract.length();
                string extractedID = directoryPathExtract.substr(directoryPathExtract.find("/Volumes/"), directoryLength-directoryPathExtract.find("/Volumes/")-1);
                string extractedID2;
                
                int terminationFlag = 0;
                
                do{
                    
                    terminationFlag = 1;
                    
                    if ((int)extractedID.find("%20") != -1){
                        extractedID2 = extractedID.substr(0, extractedID.find("%20"));
                        extractedID = extractedID.substr(extractedID.find("%20")+3);
                        extractedID = extractedID2+" "+extractedID;
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                string directoryDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/DirectoryData";
                string getString;
                string dataPathInfo;
                string infoPathInfo;
                
                ifstream fin;
                ofstream oin;
                
                fin.open(directoryDataPath.c_str(),ios::in);
                
                if (fin.is_open()){
                    getline(fin, getString), dataPathInfo = getString;
                    getline(fin, getString), infoPathInfo = getString;
                    
                    fin.close();
                    
                    oin.open(directoryDataPath.c_str(), ios::out);
                    oin<<extractedID<<endl;
                    oin<<infoPathInfo<<endl;
                    oin.close();
                }
                else{
                    
                    oin.open(directoryDataPath.c_str(), ios::out);
                    oin<<extractedID<<endl;
                    oin<<"nil"<<endl;
                    oin.close();
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Select An Imaging Computer"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        if (initialRunStatus != "nil"){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Stop Initial Setting And Do Refresh"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (autoBatchMode != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Set Auto Processing And Refresh"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (runStatusXYMap != 0){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Quit Map"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)directoryInfo:(id)sender{
    if (initialRunStatus == "nil" && autoBatchMode == 1 && runStatusXYMap == 0){
        NSOpenPanel *openDlg = [NSOpenPanel openPanel];
        [openDlg setCanChooseFiles:NO];
        [openDlg setCanChooseDirectories:YES];
        [openDlg setCanCreateDirectories:YES];
        
        if ([openDlg runModal] == NSModalResponseOK){
            NSArray *files = [openDlg URLs];
            NSString *fileName = [[files objectAtIndex:0] absoluteString];
            
            string directoryPathExtract = [fileName UTF8String];
            
            if ((int)directoryPathExtract.find("/Volumes/") != -1){
                unsigned long directoryLength = directoryPathExtract.length();
                string extractedID = directoryPathExtract.substr(directoryPathExtract.find("/Volumes/"), directoryLength-directoryPathExtract.find("/Volumes/")-1);
                string extractedID2;
                
                int terminationFlag = 0;
                
                do{
                    
                    terminationFlag = 1;
                    
                    if ((int)extractedID.find("%20") != -1){
                        extractedID2 = extractedID.substr(0, extractedID.find("%20"));
                        extractedID = extractedID.substr(extractedID.find("%20")+3);
                        extractedID = extractedID2+" "+extractedID;
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                string directoryDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/DirectoryData";
                string getString;
                string dataPathInfo;
                string infoPathInfo;
                
                ifstream fin;
                ofstream oin;
                
                fin.open(directoryDataPath.c_str(),ios::in);
                
                if (fin.is_open()){
                    getline(fin, getString), dataPathInfo = getString;
                    getline(fin, getString), infoPathInfo = getString;
                    fin.close();
                    
                    oin.open(directoryDataPath.c_str(), ios::out);
                    oin<<dataPathInfo<<endl;
                    oin<<extractedID<<endl;
                    oin.close();
                }
                else{
                    
                    oin.open(directoryDataPath.c_str(), ios::out);
                    oin<<"nil"<<endl;
                    oin<<extractedID<<endl;
                    oin.close();
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Select an Imaging computer"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        if (initialRunStatus != "nil"){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Stop Initial Setting And Do Refresh"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (autoBatchMode != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Set Auto Processing And Refresh"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (runStatusXYMap != 0){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Quit Map"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)userPassSet:(id)sender{
    if (initialRunStatus == "nil" && autoBatchMode == 1 && runStatusXYMap == 0){
        if (netCheckWindowOperation == 0){
            netCheckWindowOperation = 1;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNetCheckController object:self];
        }
        
        if (netCheckWindowOperation == 2) netCheckWindowOperation = 3;
    }
    else{
        
        if (initialRunStatus != "nil"){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Stop Initial Setting And Do Refresh"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (autoBatchMode != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Set Auto Processing And Refresh"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (runStatusXYMap != 0){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Quit Map"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)netAutoCheckSet:(id)sender{
    if (autoBatchMode == 1){
        if (netAddressHold != "nil" && netUsernameHold != "nil" && netPasswordHold != "nil"){
            if (directoryPathForPC != "nil" && infoDirectoryPC != "nil"){
                if (netCheckStatus == 0){
                    netCheckStatus = 1;
                    connectionCheckCount = 0;
                    [netAutoCheckDisplay setStringValue:@"On"];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    netCheckStatus = 0;
                    [netAutoCheckDisplay setStringValue:@"Off"];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Imaging Computer Directory Infomation Not Set"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Set Address/User name/Password"];
            [alert setAlertStyle:NSAlertStyleWarning];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Auto Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)fileDeleteUpDate2{
    string *arrayUpDate = new string [fileDeleteCount2+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++) arrayUpDate [counter1] = arrayFileDelete2 [counter1];
    
    delete [] arrayFileDelete2;
    arrayFileDelete2 = new string [fileDeleteLimit2+500];
    fileDeleteLimit2 = fileDeleteLimit2+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++) arrayFileDelete2 [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)warningUpDate{
    string *arrayUpDate = new string [consoleWarningCount+10];
    
    for (int counter1 = 0; counter1 < consoleWarningCount; counter1++) arrayUpDate [counter1] = arrayConsoleWarning [counter1];
    
    delete [] arrayConsoleWarning;
    arrayConsoleWarning = new string [consoleWarningLimit+500];
    consoleWarningLimit = consoleWarningLimit+500;
    
    for (int counter1 = 0; counter1 < consoleWarningCount; counter1++) arrayConsoleWarning [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)batchInfoUpDate{
    string *arrayUpDate = new string [batchProcessInfoCount+10];
    
    for (int counter1 = 0; counter1 < batchProcessInfoCount; counter1++) arrayUpDate [counter1] = batchProcessInfo [counter1];
    
    delete [] batchProcessInfo;
    batchProcessInfo = new string [batchProcessInfoLimit+500];
    batchProcessInfoLimit = batchProcessInfoLimit+500;
    
    for (int counter1 = 0; counter1 < batchProcessInfoCount; counter1++) batchProcessInfo [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    if (controllerTimer) [controllerTimer invalidate];
}

@end
