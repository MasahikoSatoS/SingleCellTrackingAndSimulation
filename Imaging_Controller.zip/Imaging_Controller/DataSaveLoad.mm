//
//  DataSaveLoad.m
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2014-05-22.
//
//

#import "DataSaveLoad.h"

NSString *notificationToSaveLoad = @"notificationExecuteSaveLoad";

@implementation DataSaveLoad

-(id)init{
    self = [super init];
    
    if (self != nil){
        saveLoadType = -1;
        timerFirst = 0;
        processEndFlag = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToSaveLoad object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [separateNameDisplay setStringValue:@"nil"];
    
    saveLoadWindController = [[NSWindowController alloc] initWithWindowNibName:@"SaveLoad"];
    [saveLoadWindController showWindow:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [saveLoadWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [saveLoadWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [saveLoadList setDataSource:self];
}

-(void)processMonitor{
    if (processEndFlag == 1){
        processEndFlag = 0;
        [saveLoadList reloadData];
    }
}

-(IBAction)typeSwitch:(id)sender{
    /*
     saveLoadType == 0: 06_Image folder save/load
     saveLoadType == 1: 05_Products folder save/load
     saveLoadType == 2: 10_Cell_Tracking_Library folder save/load
     */
    
    if (saveLoadProgress == 0){
        if (timerFirst == 0){
            saveLoadTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(processMonitor) userInfo:nil repeats:YES];
            timerFirst = 1;
        }
        
        if (saveLoadType == 0 || saveLoadType == -1){
            saveLoadType = 1;
            saveLoadListCount = 0;
            [saveTypeDisplay setStringValue:@"Stitched Image"]; //----Image----
            
            DIR *dir;
            struct dirent *dent;
            
            dir = opendir(cellTrackingImageFolderPath.c_str());
            
            if (dir != NULL){
                string entry;
                string fileNameCheck;
                
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        fileNameCheck = entry.substr(0, entry.find("_Image"));
                        
                        if (fileNameCheck != "Temp"){
                            if (saveLoadListCount+5 > saveLoadListLimit) [self dataSaveUpDate];
                            arraySaveLoadList [saveLoadListCount] = fileNameCheck, saveLoadListCount++;
                        }
                    }
                }
                
                closedir(dir);
                
                //----Directory Sort----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < saveLoadListCount; counter1++){
                    [unsortedArray addObject:@(arraySaveLoadList [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arraySaveLoadList [counter1] = [unsortedArray [counter1] UTF8String];
                }
            }
            
            [saveLoadList reloadData];
        }
        else if (saveLoadType == 1){
            saveLoadType = 2;
            saveLoadListCount = 0;
            [saveTypeDisplay setStringValue:@"Pattern Data"]; //----Pattern----
            [saveLoadList reloadData];
        }
        else if (saveLoadType == 2){
            saveLoadType = 3;
            saveLoadListCount = 0;
            [saveTypeDisplay setStringValue:@"Remove Specific Treatment From BackUp Folder"]; //----Products----
        }
        else if (saveLoadType == 3){
            saveLoadType = 0;
            saveLoadListCount = 0;
            [saveTypeDisplay setStringValue:@"Products"]; //----Products----
            
            DIR *dir;
            struct dirent *dent;
            
            dir = opendir(productsFilesPath.c_str());
            
            if (dir != NULL){
                string entry;
                string fileNameCheck;
                
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        fileNameCheck = entry.substr(0, entry.find("_Products"));
                        
                        if (fileNameCheck != "Temp"){
                            if (saveLoadListCount+5 > saveLoadListLimit) [self dataSaveUpDate];
                            arraySaveLoadList [saveLoadListCount] = fileNameCheck, saveLoadListCount++;
                        }
                    }
                }
                
                closedir(dir);
                
                //----Directory Sort----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < saveLoadListCount; counter1++){
                    [unsortedArray addObject:@(arraySaveLoadList [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arraySaveLoadList [counter1] = [unsortedArray [counter1] UTF8String];
                }
            }
            
            [saveLoadList reloadData];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processings In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)productSave:(id)sender{
    if (saveLoadProgress == 0){
        if (saveLoadType != -1 && saveLoadType != 3){
            if (saveLoadType == 0 || saveLoadType == 1) saveFolderName = arraySaveLoadList [rowNumberHold];
            else saveFolderName = bodyNameHold;
            
            NSSavePanel *save = [NSSavePanel savePanel];
            [save setNameFieldStringValue:@(saveFolderName.c_str())];
            
            int result2 = (int)[save runModal];
            
            if (result2 == NSModalResponseOK){
                NSURL *files = [save URL];
                NSString *selectedFile = files.path;
                
                string extractedID = [selectedFile UTF8String];
                directoryPath = [selectedFile UTF8String];
                
                string directoryPath3 = "";
                string sizeCheckPathTemp = "";
                string stringExtract;
                
                int entryCount = 0;
                int terminationFlag = 0;
                
                do{
                    
                    terminationFlag = 1;
                    
                    if ((int)extractedID.find("/") != -1){
                        stringExtract = extractedID.substr(0, extractedID.find("/"));
                        extractedID = extractedID.substr(extractedID.find("/")+1);
                        directoryPath3 = directoryPath3+stringExtract+"/";
                        
                        if (entryCount != 3) sizeCheckPathTemp = sizeCheckPathTemp+stringExtract+"/", entryCount++;
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                nameCheckString = extractedID;
                
                if ((int)sizeCheckPathTemp.find("Volumes") != -1) sizeCheckPath = sizeCheckPathTemp;
                else sizeCheckPath = "/";
                
                if (nameCheckString.length() >= 4 || nameCheckString.length() <= 15){
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    int checkResults = [controllerSubProcesses nameCheck];
                    
                    if (checkResults == 0){
                        string checkName;
                        
                        int matchFind = 0;
                        
                        DIR *dir;
                        struct dirent *dent;
                        
                        if (saveLoadType == 0) checkName = extractedID+"_Products";
                        else if (saveLoadType == 1) checkName = extractedID+"_Image";
                        else if (saveLoadType == 2) checkName = extractedID+"_Pattern";
                        
                        string entry;
                        
                        dir = opendir(directoryPath3.c_str());
                        
                        if (dir != NULL){
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                    if (checkName == entry){
                                        matchFind = 1;
                                        break;
                                    }
                                }
                            }
                            
                            closedir(dir);
                        }
                        
                        if (matchFind == 0){
                            [self save1];
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Folder With The Same Name Exists"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Check Character Restrictions"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Check Name Length"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select/Check Data Type"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processings In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)save1{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        saveLoadProgress = 1;
        progressTiming = 6;
        
        long sizeForCopy = 0;
        
        struct stat sizeOfFile;
        
        DIR *dir;
        struct dirent *dent;
        DIR *dir2;
        struct dirent *dent2;
        DIR *dir3;
        struct dirent *dent3;
        DIR *dir4;
        struct dirent *dent4;
        
        string entry;
        
        if (self->saveLoadType == 0){
            NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(sizeCheckPath.c_str()) error:nil];
            unsigned long freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
            
            string productsName = "_Products";
            
            dir = opendir(productsFilesPath.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if ((int)entry.find(saveFolderName) != -1){
                        if ((int)entry.find("_ProductsH") != -1) productsName = "_ProductsH";
                        else if ((int)entry.find("_ProductsF") != -1) productsName = "_ProductsF";
                    }
                }
                
                closedir(dir);
            }
            
            string sourcePathName = productsFilesPath+"/"+saveFolderName+productsName;
            unsigned long totalFileSize = 0;
            
            dir = opendir(sourcePathName.c_str());
            
            if (dir != NULL){
                string entry2;
                string entry3;
                string entry4;
                string pathName2;
                string pathName3;
                string pathName4;
                string pathName5;
                
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        pathName2 = sourcePathName+"/"+entry;
                        
                        dir2 = opendir(pathName2.c_str());
                        
                        if (dir2 != NULL){
                            while ((dent2 = readdir(dir2))){
                                entry2 = dent2 -> d_name;
                                
                                if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                    pathName3 = pathName2+"/"+entry2;
                                    
                                    dir3 = opendir(pathName3.c_str());
                                    
                                    if(dir3 != NULL){
                                        while ((dent3 = readdir(dir3))){
                                            entry3 = dent3 -> d_name;
                                            
                                            if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store"){
                                                pathName4 = pathName3+"/"+entry3;
                                                
                                                dir4 = opendir(pathName4.c_str());
                                                
                                                if (dir4 != NULL){
                                                    while ((dent4 = readdir(dir4))){
                                                        entry4 = dent4 -> d_name;
                                                        
                                                        if (entry4 != "." && entry4 != ".." && entry4 != ".DS_Store"){
                                                            pathName5 = pathName4+"/"+entry4;
                                                            
                                                            if (stat(pathName5.c_str(), &sizeOfFile) == 0){
                                                                sizeForCopy = sizeOfFile.st_size;
                                                                
                                                                totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                                                            }
                                                        }
                                                    }
                                                    
                                                    closedir(dir4);
                                                }
                                                else{
                                                    
                                                    if (stat(pathName3.c_str(), &sizeOfFile) == 0){
                                                        sizeForCopy = sizeOfFile.st_size;
                                                        
                                                        totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        closedir(dir3);
                                    }
                                    else{
                                        
                                        if (stat(pathName3.c_str(), &sizeOfFile) == 0){
                                            sizeForCopy = sizeOfFile.st_size;
                                            
                                            totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                                        }
                                    }
                                }
                            }
                            
                            closedir(dir2);
                        }
                        else{
                            
                            if (stat(pathName2.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                            }
                        }
                    }
                }
                
                closedir(dir);
            }
            
            unsigned long refSize = (unsigned long)totalFileSize+2097152000;
            
            if (freeSize > refSize){
                string saveFolderPath = directoryPath+productsName;
                mkdir(saveFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                dir = opendir(sourcePathName.c_str());
                
                if (dir != NULL){
                    string entry2;
                    string entry3;
                    string entry4;
                    string pathName2;
                    string pathNameB2;
                    string pathName3;
                    string pathNameB3;
                    string pathName4;
                    string pathNameB4;
                    string pathName5;
                    string pathNameB5;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            pathName2 = sourcePathName+"/"+entry;
                            pathNameB2 = saveFolderPath+"/"+entry;
                            
                            dir2 = opendir(pathName2.c_str());
                            
                            if (dir2 != NULL){
                                mkdir(pathNameB2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                
                                while ((dent2 = readdir(dir2))){
                                    entry2 = dent2 -> d_name;
                                    
                                    if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                        pathName3 = pathName2+"/"+entry2;
                                        pathNameB3 = pathNameB2+"/"+entry2;
                                        
                                        dir3 = opendir(pathName3.c_str());
                                        
                                        if (dir3 != NULL){
                                            mkdir(pathNameB3.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                            
                                            while ((dent3 = readdir(dir3))){
                                                entry3 = dent3 -> d_name;
                                                
                                                if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store"){
                                                    pathName4 = pathName3+"/"+entry3;
                                                    pathNameB4 = pathNameB3+"/"+entry3;
                                                    
                                                    dir4 = opendir(pathName4.c_str());
                                                    
                                                    if (dir4 != NULL){
                                                        mkdir(pathNameB4.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                                        
                                                        while ((dent4 = readdir(dir4))){
                                                            entry4 = dent4 -> d_name;
                                                            
                                                            if (entry4 != "." && entry4 != ".." && entry4 != ".DS_Store"){
                                                                pathName5 = pathName4+"/"+entry4;
                                                                pathNameB5 = pathNameB4+"/"+entry4;
                                                                
                                                                if (stat(pathName5.c_str(), &sizeOfFile) == 0){
                                                                    sizeForCopy = sizeOfFile.st_size;
                                                                    
                                                                    ifstream infile (pathName5.c_str(), ifstream::binary);
                                                                    ofstream outfile (pathNameB5.c_str(), ofstream::binary);
                                                                    
                                                                    char *buffer = new char[sizeForCopy];
                                                                    infile.read (buffer, sizeForCopy);
                                                                    outfile.write (buffer, sizeForCopy);
                                                                    delete [] buffer;
                                                                    
                                                                    outfile.close();
                                                                    infile.close();
                                                                }
                                                            }
                                                        }
                                                        
                                                        closedir(dir4);
                                                    }
                                                    else{
                                                        
                                                        if (stat(pathName4.c_str(), &sizeOfFile) == 0){
                                                            sizeForCopy = sizeOfFile.st_size;
                                                            
                                                            ifstream infile (pathName4.c_str(), ifstream::binary);
                                                            ofstream outfile (pathNameB4.c_str(), ofstream::binary);
                                                            
                                                            char *buffer = new char[sizeForCopy];
                                                            infile.read (buffer, sizeForCopy);
                                                            outfile.write (buffer, sizeForCopy);
                                                            delete [] buffer;
                                                            
                                                            outfile.close();
                                                            infile.close();
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            closedir(dir3);
                                        }
                                        else{
                                            
                                            if (stat(pathName3.c_str(), &sizeOfFile) == 0){
                                                sizeForCopy = sizeOfFile.st_size;
                                                
                                                ifstream infile (pathName3.c_str(), ifstream::binary);
                                                ofstream outfile (pathNameB3.c_str(), ofstream::binary);
                                                
                                                char *buffer = new char[sizeForCopy];
                                                infile.read (buffer, sizeForCopy);
                                                outfile.write (buffer, sizeForCopy);
                                                delete [] buffer;
                                                
                                                outfile.close();
                                                infile.close();
                                            }
                                        }
                                    }
                                }
                                
                                closedir(dir2);
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Low Disk Space"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        if (self->saveLoadType == 1){
            NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(sizeCheckPath.c_str()) error:nil];
            unsigned long freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
            
            string sourcePathName = cellTrackingImageFolderPath+"/"+saveFolderName+"_Image";
            unsigned long totalFileSize = 0;
            
            dir = opendir(sourcePathName.c_str());
            
            if (dir != NULL){
                string entry2;
                string pathName2;
                string pathName3;
                
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        pathName2 = sourcePathName+"/"+entry;
                        
                        dir2 = opendir(pathName2.c_str());
                        
                        if (dir2 != NULL){
                            while ((dent2 = readdir(dir2))){
                                entry2 = dent2 -> d_name;
                                
                                if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                    pathName3 = pathName2+"/"+entry2;
                                    
                                    if (stat(pathName3.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                        
                                        totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                                    }
                                }
                            }
                            
                            closedir(dir2);
                        }
                    }
                }
                
                closedir(dir);
            }
            
            unsigned long refSize = (unsigned long)totalFileSize+2097152000;
            
            if (freeSize > refSize){
                string saveFolderPath = directoryPath+"_Image";
                mkdir(saveFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                dir = opendir(sourcePathName.c_str());
                
                if (dir != NULL){
                    string entry2;
                    string pathName2;
                    string pathNameB2;
                    string pathName3;
                    string pathNameB3;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            pathName2 = sourcePathName+"/"+entry;
                            pathNameB2 = saveFolderPath+"/"+entry;
                            
                            dir2 = opendir(pathName2.c_str());
                            
                            if (dir2 != NULL){
                                mkdir(pathNameB2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                
                                while ((dent2 = readdir(dir2))){
                                    entry2 = dent2 -> d_name;
                                    
                                    if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                        pathName3 = pathName2+"/"+entry2;
                                        pathNameB3 = pathNameB2+"/"+entry2;
                                        
                                        if (stat(pathName3.c_str(), &sizeOfFile) == 0){
                                            sizeForCopy = sizeOfFile.st_size;
                                            
                                            ifstream infile (pathName3.c_str(), ifstream::binary);
                                            ofstream outfile (pathNameB3.c_str(), ofstream::binary);
                                            
                                            char *buffer = new char[sizeForCopy];
                                            infile.read (buffer, sizeForCopy);
                                            outfile.write (buffer, sizeForCopy);
                                            delete [] buffer;
                                            
                                            outfile.close();
                                            infile.close();
                                        }
                                    }
                                }
                                
                                closedir(dir2);
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Low Disk Space"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        if (self->saveLoadType == 2){
            NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(sizeCheckPath.c_str()) error:nil];
            unsigned long freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
            
            string sourcePathName = cellTrackingLibraryPath;
            unsigned long totalFileSize = 0;
            
            dir = opendir(sourcePathName.c_str());
            
            if (dir != NULL){
                string pathName2;
                
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        pathName2 = sourcePathName+"/"+entry;
                        
                        if (stat(pathName2.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                        }
                    }
                }
                
                closedir(dir);
            }
            
            unsigned long refSize = (unsigned long)totalFileSize+2097152000;
            
            if (freeSize > refSize){
                string saveFolderPath = directoryPath+"_Pattern";
                mkdir(saveFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                dir = opendir(sourcePathName.c_str());
                
                if (dir != NULL){
                    string pathName2;
                    string pathNameB2;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            pathName2 = sourcePathName+"/"+entry;
                            pathNameB2 = saveFolderPath+"/"+entry;
                            
                            if (stat(pathName2.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                ifstream infile (pathName2.c_str(), ifstream::binary);
                                ofstream outfile (pathNameB2.c_str(), ofstream::binary);
                                
                                char *buffer = new char[sizeForCopy];
                                infile.read (buffer, sizeForCopy);
                                outfile.write (buffer, sizeForCopy);
                                delete [] buffer;
                                
                                outfile.close();
                                infile.close();
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Low Disk Space"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        progressTiming = 8;
        self->processEndFlag = 1;
        saveLoadProgress = 0;
    });
}

-(IBAction)productLoad:(id)sender{
    /*
     Load selected folders to a corresponding CLIA folders.
     */
    
    if (saveLoadProgress == 0){
        if (saveLoadType != -1 && saveLoadType != 3){
            NSOpenPanel *openDlg = [NSOpenPanel openPanel];
            [openDlg setCanChooseFiles:NO];
            [openDlg setCanChooseDirectories:YES];
            
            if ([openDlg runModal] == NSModalResponseOK){
                NSArray *files = [openDlg URLs];
                NSString *fileName = [[files objectAtIndex:0] absoluteString];
                
                string directoryPathExtract = [fileName UTF8String];
                
                int findString1 = (int)directoryPathExtract.find("/Users/");
                if (findString1 == -1) findString1 = (int)directoryPathExtract.find("/Volumes/");
                
                unsigned long directoryLength = directoryPathExtract.length();
                directoryPath = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
                string extractedID;
                string extractedID2;
                
                int terminationFlag = 0;
                
                do{
                    
                    terminationFlag = 1;
                    
                    findString1 = (int)directoryPath.find("%20");
                    if (findString1 != -1){
                        extractedID2 = directoryPath.substr(0, (unsigned long)findString1);
                        directoryPath = directoryPath.substr((unsigned long)findString1+3);
                        directoryPath = extractedID2+" "+directoryPath;
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                extractedID = directoryPath;
                
                string sizeCheckPathTemp = "";
                string stringExtract;
                int entryCount = 0;
                
                do{
                    
                    terminationFlag = 1;
                    findString1 = (int)extractedID.find("/");
                    
                    if (findString1 != -1){
                        stringExtract = extractedID.substr(0, (unsigned long)findString1);
                        extractedID = extractedID.substr((unsigned long)findString1+1);
                        
                        if (entryCount != 3) sizeCheckPathTemp = sizeCheckPathTemp+stringExtract+"/", entryCount++;
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                nameCheckString = extractedID.substr(0, extractedID.find("_"));
                findString1 = (int)sizeCheckPathTemp.find("Volumes");
                
                if (findString1 != -1) sizeCheckPath = sizeCheckPathTemp;
                else sizeCheckPath = "/";
                
                saveFolderName = extractedID;
                
                if (nameCheckString.length() >= 4 || nameCheckString.length() <= 15){
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    int checkResults = [controllerSubProcesses nameCheck];
                    
                    if (checkResults == 0){
                        if (saveLoadType == 0) findString1 = (int)extractedID.find("_Products");
                        else if (saveLoadType == 1) findString1 = (int)extractedID.find("_Image");
                        else findString1 = (int)extractedID.find("_Pattern");
                        
                        if (findString1 != -1){
                            int matchFind = 0;
                            string checkName;
                            
                            DIR *dir;
                            struct dirent *dent;
                            
                            if (saveLoadType == 0){
                                checkName = extractedID;
                                directoryPath2 = productsFilesPath;
                            }
                            else if (saveLoadType == 1){
                                checkName = extractedID;
                                directoryPath2 = cellTrackingImageFolderPath;
                            }
                            else{
                                
                                checkName = extractedID;
                                directoryPath2 = cellTrackingLibraryPath;
                            }
                            
                            if (saveLoadType == 0 || saveLoadType == 1){
                                dir = opendir(directoryPath2.c_str());
                                
                                if(dir != NULL){
                                    string entry;
                                    
                                    while ((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        
                                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                            if (extractedID == entry){
                                                matchFind = 1;
                                                break;
                                            }
                                        }
                                    }
                                    
                                    closedir(dir);
                                }
                            }
                            
                            if (matchFind == 0){
                                [self load1];
                            }
                            else{
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"Folder With The Same Name Exists"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Folder Type Mismatch"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Check Character Restrictions"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Check Name Length"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select/Check Data Type"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processings In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)load1{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        saveLoadProgress = 1;
        
        long sizeForCopy = 0;
        
        struct stat sizeOfFile;
        
        DIR *dir;
        struct dirent *dent;
        DIR *dir2;
        struct dirent *dent2;
        DIR *dir3;
        struct dirent *dent3;
        DIR *dir4;
        struct dirent *dent4;
        
        progressTiming = 6;
        
        if (self->saveLoadType == 0){
            NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(sizeCheckPath.c_str()) error:nil];
            unsigned long freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
            unsigned long totalFileSize = 0;
            
            dir = opendir(directoryPath.c_str());
            
            if (dir != NULL){
                string entry;
                string entry2;
                string entry3;
                string entry4;
                string pathName2;
                string pathName3;
                string pathName4;
                string pathName5;
                
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        pathName2 = directoryPath+entry;
                        
                        dir2 = opendir(pathName2.c_str());
                        
                        if (dir2 != NULL){
                            while ((dent2 = readdir(dir2))){
                                entry2 = dent2 -> d_name;
                                
                                if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                    pathName3 = pathName2+"/"+entry2;
                                    
                                    dir3 = opendir(pathName3.c_str());
                                    
                                    if(dir3 != NULL){
                                        while ((dent3 = readdir(dir3))){
                                            entry3 = dent3 -> d_name;
                                            
                                            if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store"){
                                                pathName4 = pathName3+"/"+entry3;
                                                
                                                dir4 = opendir(pathName4.c_str());
                                                
                                                if (dir4 != NULL){
                                                    while ((dent4 = readdir(dir4))){
                                                        entry4 = dent4 -> d_name;
                                                        
                                                        if (entry4 != "." && entry4 != ".." && entry4 != ".DS_Store"){
                                                            pathName5 = pathName4+"/"+entry4;
                                                            
                                                            if (stat(pathName5.c_str(), &sizeOfFile) == 0){
                                                                sizeForCopy = sizeOfFile.st_size;
                                                                
                                                                totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                                                            }
                                                        }
                                                    }
                                                    
                                                    closedir(dir4);
                                                }
                                                else{
                                                    
                                                    if (stat(pathName3.c_str(), &sizeOfFile) == 0){
                                                        sizeForCopy = sizeOfFile.st_size;
                                                        
                                                        totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        closedir(dir3);
                                    }
                                    else{
                                        
                                        if (stat(pathName3.c_str(), &sizeOfFile) == 0){
                                            sizeForCopy = sizeOfFile.st_size;
                                            
                                            totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                                        }
                                    }
                                }
                            }
                            
                            closedir(dir2);
                        }
                        else{
                            
                            if (stat(pathName2.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                            }
                        }
                    }
                }
                
                closedir(dir);
            }
            
            unsigned long refSize = (unsigned long)totalFileSize+2097152000;
            
            if (freeSize > refSize){
                string saveFolderPath = directoryPath2+"/"+saveFolderName;
                mkdir(saveFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                dir = opendir(directoryPath.c_str());
                
                if (dir != NULL){
                    string entry;
                    string entry2;
                    string entry3;
                    string entry4;
                    string pathName2;
                    string pathNameB2;
                    string pathName3;
                    string pathNameB3;
                    string pathName4;
                    string pathNameB4;
                    string pathName5;
                    string pathNameB5;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            pathName2 = directoryPath+"/"+entry;
                            pathNameB2 = saveFolderPath+"/"+entry;
                            
                            dir2 = opendir(pathName2.c_str());
                            
                            if (dir2 != NULL){
                                mkdir(pathNameB2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                
                                while ((dent2 = readdir(dir2))){
                                    entry2 = dent2 -> d_name;
                                    
                                    if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                        pathName3 = pathName2+"/"+entry2;
                                        pathNameB3 = pathNameB2+"/"+entry2;
                                        
                                        dir3 = opendir(pathName3.c_str());
                                        
                                        if (dir3 != NULL){
                                            mkdir(pathNameB3.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                            
                                            while ((dent3 = readdir(dir3))){
                                                entry3 = dent3 -> d_name;
                                                
                                                if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store"){
                                                    pathName4 = pathName3+"/"+entry3;
                                                    pathNameB4 = pathNameB3+"/"+entry3;
                                                    
                                                    dir4 = opendir(pathName4.c_str());
                                                    
                                                    if (dir4 != NULL){
                                                        mkdir(pathNameB4.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                                        
                                                        while ((dent4 = readdir(dir4))){
                                                            entry4 = dent4 -> d_name;
                                                            
                                                            if (entry4 != "." && entry4 != ".." && entry4 != ".DS_Store"){
                                                                pathName5 = pathName4+"/"+entry4;
                                                                pathNameB5 = pathNameB4+"/"+entry4;
                                                                
                                                                if (stat(pathName5.c_str(), &sizeOfFile) == 0){
                                                                    sizeForCopy = sizeOfFile.st_size;
                                                                    
                                                                    ifstream infile (pathName5.c_str(), ifstream::binary);
                                                                    ofstream outfile (pathNameB5.c_str(), ofstream::binary);
                                                                    
                                                                    char *buffer = new char[sizeForCopy];
                                                                    infile.read (buffer, sizeForCopy);
                                                                    outfile.write (buffer, sizeForCopy);
                                                                    delete [] buffer;
                                                                    
                                                                    outfile.close();
                                                                    infile.close();
                                                                }
                                                            }
                                                        }
                                                        
                                                        closedir(dir4);
                                                    }
                                                    else{
                                                        
                                                        if (stat(pathName4.c_str(), &sizeOfFile) == 0){
                                                            sizeForCopy = sizeOfFile.st_size;
                                                            
                                                            ifstream infile (pathName4.c_str(), ifstream::binary);
                                                            ofstream outfile (pathNameB4.c_str(), ofstream::binary);
                                                            
                                                            char *buffer = new char[sizeForCopy];
                                                            infile.read (buffer, sizeForCopy);
                                                            outfile.write (buffer, sizeForCopy);
                                                            delete [] buffer;
                                                            
                                                            outfile.close();
                                                            infile.close();
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            closedir(dir3);
                                        }
                                        else{
                                            
                                            if (stat(pathName3.c_str(), &sizeOfFile) == 0){
                                                sizeForCopy = sizeOfFile.st_size;
                                                
                                                ifstream infile (pathName3.c_str(), ifstream::binary);
                                                ofstream outfile (pathNameB3.c_str(), ofstream::binary);
                                                
                                                char *buffer = new char[sizeForCopy];
                                                infile.read (buffer, sizeForCopy);
                                                outfile.write (buffer, sizeForCopy);
                                                delete [] buffer;
                                                
                                                outfile.close();
                                                infile.close();
                                            }
                                        }
                                    }
                                }
                                
                                closedir(dir2);
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                
                saveLoadListCount = 0;
                
                dir = opendir(productsFilesPath.c_str());
                
                if (dir != NULL){
                    string entry;
                    string fileNameCheck;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            fileNameCheck = entry.substr(0, entry.find("_Products"));
                            
                            if (fileNameCheck != "Temp"){
                                if (saveLoadListCount+5 > saveLoadListLimit) [self dataSaveUpDate];
                                arraySaveLoadList [saveLoadListCount] = fileNameCheck, saveLoadListCount++;
                            }
                        }
                    }
                    
                    closedir(dir);
                    
                    //----Directory Sort----
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < saveLoadListCount; counter1++){
                        [unsortedArray addObject:@(arraySaveLoadList [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        arraySaveLoadList [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Low Disk Space"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        if (self->saveLoadType == 1){
            NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(sizeCheckPath.c_str()) error:nil];
            unsigned long freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
            unsigned long totalFileSize = 0;
            
            dir = opendir(directoryPath.c_str());
            
            if (dir != NULL){
                string entry;
                string entry2;
                string pathName2;
                string pathName3;
                
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        pathName2 = directoryPath+"/"+entry;
                        
                        dir2 = opendir(pathName2.c_str());
                        
                        if (dir2 != NULL){
                            while ((dent2 = readdir(dir2))){
                                entry2 = dent2 -> d_name;
                                
                                if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                    pathName3 = pathName2+"/"+entry2;
                                    
                                    if (stat(pathName3.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                        
                                        totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                                    }
                                }
                            }
                            
                            closedir(dir2);
                        }
                    }
                }
                
                closedir(dir);
            }
            
            unsigned long refSize = (unsigned long)totalFileSize+2097152000;
            
            if (freeSize > refSize){
                string saveFolderPath = directoryPath2+"/"+saveFolderName;
                mkdir(saveFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                dir = opendir(directoryPath.c_str());
                
                if (dir != NULL){
                    string entry;
                    string entry2;
                    string pathName2;
                    string pathNameB2;
                    string pathName3;
                    string pathNameB3;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            pathName2 = directoryPath+"/"+entry;
                            pathNameB2 = saveFolderPath+"/"+entry;
                            
                            dir2 = opendir(pathName2.c_str());
                            
                            if (dir2 != NULL){
                                mkdir(pathNameB2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                
                                while ((dent2 = readdir(dir2))){
                                    entry2 = dent2 -> d_name;
                                    
                                    if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                        pathName3 = pathName2+"/"+entry2;
                                        pathNameB3 = pathNameB2+"/"+entry2;
                                        
                                        if (stat(pathName3.c_str(), &sizeOfFile) == 0){
                                            sizeForCopy = sizeOfFile.st_size;
                                            
                                            ifstream infile (pathName3.c_str(), ifstream::binary);
                                            ofstream outfile (pathNameB3.c_str(), ofstream::binary);
                                            
                                            char *buffer = new char[sizeForCopy];
                                            infile.read (buffer, sizeForCopy);
                                            outfile.write (buffer, sizeForCopy);
                                            delete [] buffer;
                                            
                                            outfile.close();
                                            infile.close();
                                        }
                                    }
                                }
                                
                                closedir(dir2);
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                
                saveLoadListCount = 0;
                
                dir = opendir(cellTrackingImageFolderPath.c_str());
                
                if (dir != NULL){
                    string entry;
                    string fileNameCheck;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            fileNameCheck = entry.substr(0, entry.find("_Image"));
                            
                            if (fileNameCheck != "Temp"){
                                if (saveLoadListCount+5 > saveLoadListLimit) [self dataSaveUpDate];
                                arraySaveLoadList [saveLoadListCount] = fileNameCheck, saveLoadListCount++;
                            }
                        }
                    }
                    
                    closedir(dir);
                    
                    //----Directory Sort----
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < saveLoadListCount; counter1++){
                        [unsortedArray addObject:@(arraySaveLoadList [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        arraySaveLoadList [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Low Disk Space"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        if (self->saveLoadType == 2){
            NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(sizeCheckPath.c_str()) error:nil];
            unsigned long freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
            unsigned long totalFileSize = 0;
            
            dir = opendir(directoryPath.c_str());
            
            if (dir != NULL){
                string entry;
                string pathName2;
                
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        pathName2 = directoryPath+"/"+entry;
                        
                        if (stat(pathName2.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                        }
                    }
                }
                
                closedir(dir);
            }
            
            unsigned long refSize = (unsigned long)totalFileSize+2097152000;
            
            if (freeSize > refSize){
                string saveFolderPath = cellTrackingLibraryPath;
                
                dir = opendir(directoryPath.c_str());
                
                if (dir != NULL){
                    string entry;
                    string pathName2;
                    string pathNameB2;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            pathName2 = directoryPath+"/"+entry;
                            pathNameB2 = saveFolderPath+"/"+entry;
                            
                            if (stat(pathName2.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                ifstream infile (pathName2.c_str(), ifstream::binary);
                                ofstream outfile (pathNameB2.c_str(), ofstream::binary);
                                
                                char *buffer = new char[sizeForCopy];
                                infile.read (buffer, sizeForCopy);
                                outfile.write (buffer, sizeForCopy);
                                delete [] buffer;
                                
                                outfile.close();
                                infile.close();
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Low Disk Space"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        progressTiming = 8;
        self->processEndFlag = 1;
        saveLoadProgress = 0;
    });
}

-(IBAction)deleteFolder:(id)sender{
    /*
     Delete Products or Image folder from CLIA folders.
     */
    
    if (initialRunStatus == "nil"){
        if (saveLoadProgress == 0){
            if (saveLoadType != -1){
                if (saveLoadType == 0 || saveLoadType == 1 || saveLoadType == 3){
                    if (saveLoadType == 0 || saveLoadType == 1){
                        string deleteFolderName = arraySaveLoadList [rowNumberHold];
                        string delFolderString = "Folder "+deleteFolderName+" will be deleted. Deleted data cannot be restored.";
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert addButtonWithTitle:@"Cancel"];
                        [alert setMessageText:@"Delete Data"];
                        [alert setInformativeText:@(delFolderString.c_str())];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        
                        if ([alert runModal] == NSAlertFirstButtonReturn){
                            progressTiming = 6;
                            saveLoadProgress = 1;
                            
                            if (saveLoadType == 0){
                                DIR *dir;
                                struct dirent *dent;
                                
                                string productsName = "_Products";
                                string entry;
                                
                                dir = opendir(productsFilesPath.c_str());
                                
                                if (dir != NULL){
                                    while ((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        
                                        if ((int)entry.find(saveFolderName) != -1){
                                            if ((int)entry.find("_ProductsH") != -1) productsName = "_ProductsH";
                                            else if ((int)entry.find("_ProductsF") != -1) productsName = "_ProductsF";
                                        }
                                    }
                                    
                                    closedir(dir);
                                }
                                
                                string deleteFolderPath = productsFilesPath+"/"+deleteFolderName+productsName;
                                
                                int directoryRmv = 2;
                                pathToDelete = deleteFolderPath;
                                
                                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                [controllerSubProcesses fileDeleteLayerFour:directoryRmv];
                                
                                directoryRmv = 2;
                                pathToDelete = deleteFolderPath;
                                
                                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                [controllerSubProcesses fileDeleteLayerThree:directoryRmv];
                                
                                directoryRmv = 1;
                                pathToDelete = deleteFolderPath;
                                
                                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                                
                                directoryRmv = 2;
                                pathToDelete = deleteFolderPath;
                                
                                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                                
                                rmdir (deleteFolderPath.c_str());
                                
                                saveLoadListCount = 0;
                                
                                dir = opendir(productsFilesPath.c_str());
                                
                                if (dir != NULL){
                                    string fileNameCheck;
                                    
                                    while ((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        
                                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                            fileNameCheck = entry.substr(0, entry.find("_Products"));
                                            
                                            if (fileNameCheck != "Temp"){
                                                if (saveLoadListCount+5 > saveLoadListLimit) [self dataSaveUpDate];
                                                arraySaveLoadList [saveLoadListCount] = fileNameCheck, saveLoadListCount++;
                                            }
                                        }
                                    }
                                    
                                    closedir(dir);
                                    
                                    //----Directory Sort----
                                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                                    
                                    for (int counter1 = 0; counter1 < saveLoadListCount; counter1++){
                                        [unsortedArray addObject:@(arraySaveLoadList [counter1].c_str())];
                                    }
                                    
                                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                                    
                                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                                        arraySaveLoadList [counter1] = [unsortedArray [counter1] UTF8String];
                                    }
                                }
                                
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                                
                                [saveLoadList reloadData];
                            }
                            
                            if (saveLoadType == 1){
                                string deleteFolderPath = cellTrackingImageFolderPath+"/"+deleteFolderName+"_Image";
                                
                                DIR *dir;
                                struct dirent *dent;
                                
                                int directoryRmv = 0;
                                pathToDelete = deleteFolderPath;
                                
                                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                                
                                directoryRmv = 2;
                                pathToDelete = deleteFolderPath;
                                
                                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                                
                                rmdir (deleteFolderPath.c_str());
                                
                                saveLoadListCount = 0;
                                
                                dir = opendir(cellTrackingImageFolderPath.c_str());
                                
                                if (dir != NULL){
                                    string entry;
                                    string fileNameCheck;
                                    
                                    while ((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        
                                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                            fileNameCheck = entry.substr(0, entry.find("_Image"));
                                            
                                            if (fileNameCheck != "Temp"){
                                                if (saveLoadListCount+5 > saveLoadListLimit) [self dataSaveUpDate];
                                                arraySaveLoadList [saveLoadListCount] = fileNameCheck, saveLoadListCount++;
                                            }
                                        }
                                    }
                                    
                                    closedir(dir);
                                    
                                    //----Directory Sort----
                                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                                    
                                    for (int counter1 = 0; counter1 < saveLoadListCount; counter1++){
                                        [unsortedArray addObject:@(arraySaveLoadList [counter1].c_str())];
                                    }
                                    
                                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                                    
                                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                                        arraySaveLoadList [counter1] = [unsortedArray [counter1] UTF8String];
                                    }
                                }
                                
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                                
                                [saveLoadList reloadData];
                            }
                            
                            progressTiming = 8;
                            saveLoadProgress = 0;
                        }
                    }
                    
                    if (saveLoadType == 3){
                        if (saveLoadListCount != 0){
                            string deleteFolderName = arraySaveLoadList [rowNumberHold];
                            
                            if (rowNumberHold != saveLoadListCount-1){
                                string delFolderString = "Files "+deleteFolderName+" will be deleted. Deleted data cannot be restored.";
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                
                                [alert addButtonWithTitle:@"OK"];
                                [alert addButtonWithTitle:@"Cancel"];
                                [alert setMessageText:@"Delete Data"];
                                [alert setInformativeText:@(delFolderString.c_str())];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                
                                if ([alert runModal] == NSAlertFirstButtonReturn){
                                    progressTiming = 6;
                                    saveLoadProgress = 1;
                                    
                                    string deleteFolderPath = arraySaveLoadList [saveLoadListCount-1];
                                    
                                    DIR *dir;
                                    struct dirent *dent;
                                    
                                    int folderCount = 0;
                                    
                                    dir = opendir(deleteFolderPath.c_str());
                                    
                                    if (dir != NULL){
                                        string entry;
                                        string productFolderPath2;
                                        
                                        while ((dent = readdir(dir))){
                                            entry = dent -> d_name;
                                            
                                            productFolderPath2 = deleteFolderPath+"/"+entry;
                                            
                                            if (entry != "." && entry != ".." && entry != ".DS_Store") folderCount++;
                                        }
                                        
                                        closedir(dir);
                                    }
                                    
                                    int directoryRmv = 0;
                                    pathToDelete = deleteFolderPath;
                                    
                                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                    [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                                    
                                    string *saveListTemp = new string [saveLoadListCount+5];
                                    int saveListTempCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < saveLoadListCount; counter1++){
                                        if (arraySaveLoadList [counter1] != deleteFolderName){
                                            saveListTemp [saveListTempCount] = arraySaveLoadList [counter1], saveListTempCount++;
                                        }
                                    }
                                    
                                    saveLoadListCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < saveListTempCount; counter1++) arraySaveLoadList [counter1] = saveListTemp [counter1], saveLoadListCount++;
                                    
                                    delete [] saveListTemp;
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                    
                                    [saveLoadList reloadData];
                                    
                                    progressTiming = 8;
                                    saveLoadProgress = 0;
                                }
                            }
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Perform Set"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Data Type Missmatch"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Select Data Type"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Other Processings In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Perform Before Initial Run Starts"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)backUpClean:(id)sender{
    if (saveLoadProgress == 0){
        if (initialRunStatus == "nil"){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert addButtonWithTitle:@"Cancel"];
            [alert setMessageText:@"Delete Folders In The Backup Folder?"];
            [alert setAlertStyle:NSAlertStyleWarning];
            
            if ([alert runModal] == NSAlertFirstButtonReturn){
                progressTiming = 6;
                saveLoadProgress = 1;
                
                int folderNoCount = 0;
                
                DIR *dir;
                struct dirent *dent;
                DIR *dir2;
                struct dirent *dent2;
                
                dir = opendir(backUpDataPath.c_str());
                
                if (dir != NULL){
                    string entry;
                    string entry2;
                    string productDataPath1;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        productDataPath1 = backUpDataPath+"/"+entry;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            dir2 = opendir(productDataPath1.c_str());
                            
                            if (dir2 != NULL){
                                while ((dent2 = readdir(dir2))){
                                    entry2 = dent2 -> d_name;
                                    folderNoCount++;
                                }
                                
                                closedir(dir2);
                            }
                        }
                    }
                    
                    closedir(dir);
                    
                    string *folderNameList = new string [folderNoCount+50];
                    int folderNameListCount = 0;
                    
                    dir = opendir(backUpDataPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            productDataPath1 = backUpDataPath+"/"+entry;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                folderNameList [folderNameListCount] = entry, folderNameListCount++;
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    string productDataPath2;
                    
                    for (int counter1 = 0; counter1 < folderNameListCount; counter1++){
                        entry = folderNameList [counter1];
                        productDataPath1 = backUpDataPath+"/"+entry;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            dir2 = opendir(productDataPath1.c_str());
                            fileDeleteCount = 0;
                            
                            if (dir2 != NULL){
                                while ((dent2 = readdir(dir2))){
                                    entry2 = dent2 -> d_name;
                                    
                                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                    arrayFileDelete [fileDeleteCount] = productDataPath1+"/"+entry2, fileDeleteCount++;
                                }
                                
                                closedir(dir2);
                                
                                for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                                    remove (arrayFileDelete [counter2].c_str());
                                }
                            }
                            else remove (productDataPath1.c_str());
                            
                            rmdir (productDataPath1.c_str());
                        }
                    }
                    
                    delete [] folderNameList;
                }
                
                progressTiming = 8;
                saveLoadProgress = 0;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Perform Before Initial Run Starts"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processings In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)setList:(id)sender{
    if (saveLoadType != -1){
        if (saveLoadType == 3){
            NSOpenPanel *openDlg = [NSOpenPanel openPanel];
            [openDlg setCanChooseFiles:NO];
            [openDlg setCanChooseDirectories:YES];
            
            if ([openDlg runModal] == NSModalResponseOK){
                NSArray *files = [openDlg URLs];
                NSString *fileName = [[files objectAtIndex:0] absoluteString];
                
                string directoryPathExtract = [fileName UTF8String];
                
                int findString1 = (int)directoryPathExtract.find("/Users/");
                if (findString1 == -1) findString1 = (int)directoryPathExtract.find("/Volumes/");
                
                unsigned long directoryLength = directoryPathExtract.length();
                string directoryPath3 = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
                string extractedID;
                string extractedID2;
                
                int terminationFlag = 0;
                
                do{
                    
                    terminationFlag = 1;
                    
                    if ((int)directoryPath3.find("%20") != -1){
                        extractedID2 = directoryPath3.substr(0, directoryPath3.find("%20"));
                        directoryPath3 = directoryPath3.substr(directoryPath3.find("%20")+3);
                        directoryPath3 = extractedID2+" "+directoryPath3;
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                extractedID = directoryPath3;
                
                string stringExtract;
                
                do{
                    
                    terminationFlag = 1;
                    
                    if ((int)extractedID.find("/") != -1){
                        stringExtract = extractedID.substr(0, extractedID.find("/"));
                        extractedID = extractedID.substr(extractedID.find("/")+1);
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                if ((int)extractedID.find("-1") != -1){
                    saveLoadListCount = 0;
                    
                    string fileNameCheck;
                    string entry;
                    int findFlag = 0;
                    
                    DIR *dir;
                    struct dirent *dent;
                    
                    dir = opendir(directoryPath3.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                findFlag = 0;
                                
                                if ((int)entry.find("_") != -1 && (int)entry.find("-") != -1 && ((int)entry.find(".tif") != -1 || (int)entry.find(".TIF") != -1)){
                                    fileNameCheck = entry.substr(0, entry.find("_"));
                                    
                                    for (int counter1 = 0; counter1 < saveLoadListCount; counter1++){
                                        if (arraySaveLoadList [counter1] == fileNameCheck){
                                            findFlag = 1;
                                            break;
                                        }
                                    }
                                    
                                    if (findFlag == 0){
                                        if (saveLoadListCount+5 > saveLoadListLimit) [self dataSaveUpDate];
                                        arraySaveLoadList [saveLoadListCount] = fileNameCheck, saveLoadListCount++;
                                    }
                                }
                            }
                        }
                        
                        closedir(dir);
                        
                        //----Directory Sort----
                        NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                        
                        for (int counter1 = 0; counter1 < saveLoadListCount; counter1++){
                            [unsortedArray addObject:@(arraySaveLoadList [counter1].c_str())];
                        }
                        
                        [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                        
                        for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                            arraySaveLoadList [counter1] = [unsortedArray [counter1] UTF8String];
                        }
                    }
                    
                    if (saveLoadListCount != 0){
                        string newDirectory = directoryPath3.substr(0, directoryPath3.find(extractedID)-1);
                        
                        if (saveLoadListCount+5 > saveLoadListLimit) [self dataSaveUpDate];
                        arraySaveLoadList [saveLoadListCount] = newDirectory, saveLoadListCount++;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        [saveLoadList reloadData];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"File Missing"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"BackUp Folder Missing"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Data Type Missmatch"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Select Data Type"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)selectBKFolderForSeparate:(id)sender{
    if (initialRunStatus == "nil"){
        if (saveLoadProgress == 0){
            NSOpenPanel *openDlg = [NSOpenPanel openPanel];
            [openDlg setCanChooseFiles:NO];
            [openDlg setCanChooseDirectories:YES];
            
            if ([openDlg runModal] == NSModalResponseOK){
                NSArray *files = [openDlg URLs];
                NSString *fileName = [[files objectAtIndex:0] absoluteString];
                
                string directoryPathExtract = [fileName UTF8String];
                
                int findString1 = (int)directoryPathExtract.find("/Users/");
                if (findString1 == -1) findString1 = (int)directoryPathExtract.find("/Volumes/");
                
                unsigned long directoryLength = directoryPathExtract.length();
                directoryPath = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
                string extractedID;
                string extractedID2;
                
                int terminationFlag = 0;
                
                do{
                    
                    terminationFlag = 1;
                    
                    findString1 = (int)directoryPath.find("%20");
                    if (findString1 != -1){
                        extractedID2 = directoryPath.substr(0, (unsigned long)findString1);
                        directoryPath = directoryPath.substr((unsigned long)findString1+3);
                        directoryPath = extractedID2+" "+directoryPath;
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                string entry;
                string entry2;
                string bodyname = "";
                string folderPath;
                
                int findIFData = 0;
                separatePath = "";
                bodyNameSeparate = "";
                
                DIR *dir;
                struct dirent *dent;
                DIR *dir2;
                struct dirent *dent2;
                
                dir = opendir(directoryPath.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find("-") >= 4 && (int)entry.length()-(int)entry.find("-")-1 == 5){
                                folderPath = directoryPath+"/"+entry;
                                
                                dir2 = opendir(folderPath.c_str());
                                
                                if (dir2 != NULL){
                                    while ((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                            if ((int)entry2.find("_") != -1 && (int)entry2.find("-") != -1 && (int)entry2.find(".TIF") != -1 && (int)entry2.length()-(int)entry2.find(".TIF")-4 == 2){
                                                findIFData++;
                                                bodyname = entry.substr(0, entry.find("-"));
                                                break;
                                            }
                                        }
                                    }
                                    
                                    closedir(dir2);
                                }
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                
                if (bodyname != ""){
                    if (findIFData > 0){
                        separatePath = directoryPath;
                        bodyNameSeparate = bodyname;
                        
                        [separateNameDisplay setStringValue:@(bodyNameSeparate.c_str())];
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        separatePath = "";
                        bodyNameSeparate = "";
                        
                        [separateNameDisplay setStringValue:@"nil"];
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"IF Folder Missing"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    separatePath = "";
                    bodyNameSeparate = "";
                    
                    [separateNameDisplay setStringValue:@"nil"];
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"BackUp Folder Missing"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            separatePath = "";
            bodyNameSeparate = "";
            
            [separateNameDisplay setStringValue:@"nil"];
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Other Processings In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        separatePath = "";
        bodyNameSeparate = "";
        
        [separateNameDisplay setStringValue:@"nil"];
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Perform Before Initial Run Starts"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)selectBKDestination:(id)sender{
    if (initialRunStatus == "nil"){
        if (saveLoadProgress == 0){
            if (separatePath != "" && bodyNameSeparate != ""){
                NSOpenPanel *openDlg = [NSOpenPanel openPanel];
                [openDlg setCanChooseFiles:NO];
                [openDlg setCanChooseDirectories:YES];
                
                if ([openDlg runModal] == NSModalResponseOK){
                    NSArray *files = [openDlg URLs];
                    NSString *fileName = [[files objectAtIndex:0] absoluteString];
                    
                    string directoryPathExtract = [fileName UTF8String];
                    
                    int findString1 = (int)directoryPathExtract.find("/Users/");
                    if (findString1 == -1) findString1 = (int)directoryPathExtract.find("/Volumes/");
                    
                    unsigned long directoryLength = directoryPathExtract.length();
                    directoryPath = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
                    string extractedID;
                    string extractedID2;
                    
                    int terminationFlag = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        findString1 = (int)directoryPath.find("%20");
                        if (findString1 != -1){
                            extractedID2 = directoryPath.substr(0, (unsigned long)findString1);
                            directoryPath = directoryPath.substr((unsigned long)findString1+3);
                            directoryPath = extractedID2+" "+directoryPath;
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    extractedID = directoryPath;
                    
                    string sizeCheckPathTemp = "";
                    string stringExtract;
                    int entryCount = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        findString1 = (int)extractedID.find("/");
                        
                        if (findString1 != -1){
                            stringExtract = extractedID.substr(0, (unsigned long)findString1);
                            extractedID = extractedID.substr((unsigned long)findString1+1);
                            
                            if (entryCount != 3) sizeCheckPathTemp = sizeCheckPathTemp+stringExtract+"/", entryCount++;
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    nameCheckString = extractedID.substr(0, extractedID.find("_"));
                    findString1 = (int)sizeCheckPathTemp.find("Volumes");
                    
                    if (findString1 != -1) sizeCheckPath = sizeCheckPathTemp;
                    else sizeCheckPath = "/";
                    
                    NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(sizeCheckPath.c_str()) error:nil];
                    unsigned long freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
                    unsigned long totalFileSize = 0;
                    
                    long sizeForCopy = 0;
                    
                    struct stat sizeOfFile;
                    
                    string entry;
                    string entry2;
                    string folderPath;
                    string folderPath2;
                    
                    DIR *dir;
                    struct dirent *dent;
                    DIR *dir2;
                    struct dirent *dent2;
                    
                    dir = opendir(separatePath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if ((int)entry.find("-") >= 4 && (int)entry.length()-(int)entry.find("-")-1 == 5){
                                    folderPath = separatePath+"/"+entry;
                                    
                                    dir2 = opendir(folderPath.c_str());
                                    
                                    if (dir2 != NULL){
                                        while ((dent2 = readdir(dir2))){
                                            entry2 = dent2 -> d_name;
                                            
                                            if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                                if ((int)entry2.find("_") != -1 && (int)entry2.find("-") != -1 && (int)entry2.find(".TIF") != -1 && (int)entry2.length()-(int)entry2.find(".TIF")-4 == 2){
                                                    folderPath2 = folderPath+"/"+entry2;
                                                    
                                                    if (stat(folderPath2.c_str(), &sizeOfFile) == 0){
                                                        sizeForCopy = sizeOfFile.st_size;
                                                        
                                                        totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        closedir(dir2);
                                    }
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    unsigned long refSize = (unsigned long)totalFileSize+2097152000;
                    
                    if (freeSize > refSize){
                        [self separateIf1];
                    }
                    else{
                        
                        separatePath = "";
                        bodyNameSeparate = "";
                        
                        [separateNameDisplay setStringValue:@"nil"];
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Low Disk Space"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
            }
            else{
                
                separatePath = "";
                bodyNameSeparate = "";
                
                [separateNameDisplay setStringValue:@"nil"];
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Folder Selected"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            separatePath = "";
            bodyNameSeparate = "";
            
            [separateNameDisplay setStringValue:@"nil"];
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Other Processings In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        separatePath = "";
        bodyNameSeparate = "";
        
        [separateNameDisplay setStringValue:@"nil"];
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Perform Before Initial Run Starts"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)separateIf1{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        saveLoadProgress = 1;
        progressTiming = 6;
        
        int terminationFlag = 0;
        long sizeForCopy = 0;
        
        struct stat sizeOfFile;
        
        string extractedID = separatePath;
        string entry;
        string entry2;
        string folderPath;
        string folderPath2;
        
        DIR *dir;
        struct dirent *dent;
        DIR *dir2;
        struct dirent *dent2;
        
        do{
            
            terminationFlag = 1;
            
            if ((int)extractedID.find("/") != -1){
                extractedID = extractedID.substr(extractedID.find("/")+1);
            }
            else terminationFlag = 0;
            
        } while (terminationFlag == 1);
        
        string newDirectoryPath = directoryPath+"/"+extractedID+"-IFSeparate";
        string newDirectoryPath2;
        string newDirectoryPath3;
        string pathName1;
        string pathNameB1;
        
        int findIFData = 0;
        
        dir = opendir(separatePath.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    if ((int)entry.find("-") >= 4 && (int)entry.length()-(int)entry.find("-")-1 == 5 && (int)entry.find(bodyNameSeparate) != -1){
                        folderPath = separatePath+"/"+entry;
                        
                        dir2 = opendir(folderPath.c_str());
                        
                        if (dir2 != NULL){
                            while ((dent2 = readdir(dir2))){
                                entry2 = dent2 -> d_name;
                                
                                if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                    if ((int)entry2.find("_") != -1 && (int)entry2.find("-") != -1 && (int)entry2.find(".TIF") != -1 && (int)entry2.length()-(int)entry2.find(".TIF")-4 == 2){
                                        findIFData++;
                                        break;
                                    }
                                }
                            }
                            
                            closedir(dir2);
                        }
                        
                        if (findIFData > 0){
                            dir2 = opendir(folderPath.c_str());
                            fileDeleteCount = 0;
                            
                            if (dir2 != NULL){
                                while ((dent2 = readdir(dir2))){
                                    entry2 = dent2 -> d_name;
                                    
                                    if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                        arrayFileDelete [fileDeleteCount] = entry2, fileDeleteCount++;
                                    }
                                }
                                
                                closedir(dir2);
                                
                                newDirectoryPath3 = directoryPath+"/"+extractedID+"-IFSeparate"+to_string(findIFData);
                                mkdir(newDirectoryPath3.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                
                                newDirectoryPath2 = newDirectoryPath3+"/"+entry;
                                
                                mkdir(newDirectoryPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                
                                for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                                    pathName1 = folderPath+"/"+arrayFileDelete [counter2];
                                    pathNameB1 = newDirectoryPath3+"/"+entry+"/"+arrayFileDelete [counter2].substr(0, arrayFileDelete [counter2].find(".TIF"))+".tif";
                                    
                                    if (stat(pathName1.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                        
                                        ifstream infile (pathName1.c_str(), ifstream::binary);
                                        ofstream outfile (pathNameB1.c_str(), ofstream::binary);
                                        
                                        char *buffer = new char[sizeForCopy];
                                        infile.read (buffer, sizeForCopy);
                                        outfile.write (buffer, sizeForCopy);
                                        delete [] buffer;
                                        
                                        outfile.close();
                                        infile.close();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            closedir(dir);
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        progressTiming = 8;
        saveLoadProgress = 0;
    });
}

-(IBAction)selectImageFolderForMerge:(id)sender{
    if (saveLoadProgress == 0){
        NSOpenPanel *openDlg = [NSOpenPanel openPanel];
        [openDlg setCanChooseFiles:NO];
        [openDlg setCanChooseDirectories:YES];
        
        if ([openDlg runModal] == NSModalResponseOK){
            NSArray *files = [openDlg URLs];
            NSString *fileName = [[files objectAtIndex:0] absoluteString];
            
            string directoryPathExtract = [fileName UTF8String];
            
            int findString1 = (int)directoryPathExtract.find("/Users/");
            if (findString1 == -1) findString1 = (int)directoryPathExtract.find("/Volumes/");
            
            unsigned long directoryLength = directoryPathExtract.length();
            directoryPath = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
            string extractedID;
            string extractedID2;
            
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                
                findString1 = (int)directoryPath.find("%20");
                if (findString1 != -1){
                    extractedID2 = directoryPath.substr(0, (unsigned long)findString1);
                    directoryPath = directoryPath.substr((unsigned long)findString1+3);
                    directoryPath = extractedID2+" "+directoryPath;
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            extractedID = directoryPath;
            
            do{
                
                terminationFlag = 1;
                findString1 = (int)extractedID.find("/");
                
                if (findString1 != -1){
                    extractedID = extractedID.substr((unsigned long)findString1+1);
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            if ((int)extractedID.find("_Image") != -1 && initialRunStatus == "8"){
                //----Destination check----
                string entry;
                int entryCountDes = 0;
                
                DIR *dir;
                struct dirent *dent;
                
                dir = opendir(directoryPath.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find("_Stitch") != -1){
                                entryCountDes++;
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                
                string *treatNameMerge = new string [entryCountDes+10];
                int treatNameMergeCount = 0;
                
                dir = opendir(directoryPath.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find("_Stitch") != -1){
                                treatNameMerge [treatNameMergeCount] = entry, treatNameMergeCount++;
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                
                //----Source check----
                string sourcePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images"+"/"+batchImagePathNameHold+"_Image";
                
                int entryCountSou = 0;
                
                dir = opendir(sourcePath.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find("_Stitch") != -1) entryCountSou++;
                        }
                    }
                    
                    closedir(dir);
                }
                
                string *treatNameMergeSource = new string [entryCountSou+10];
                int treatNameMergeSourceCount = 0;
                string *treatNameMergeSourceFile = new string [entryCountSou*4+40];
                int treatNameMergeSourceFileCount = 0;
                int *treatNameMergeEntryNo = new int [entryCountSou+10];
                int treatNameMergeEntryNoCount = 0;
                
                string folderPath;
                string entry2;
                int mergeEntryCount = 0;
                
                DIR *dir2;
                struct dirent *dent2;
                
                dir = opendir(sourcePath.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find("_Stitch") != -1){
                                treatNameMergeSource [treatNameMergeSourceCount] = entry, treatNameMergeSourceCount++;
                                
                                folderPath = sourcePath+"/"+entry;
                                mergeEntryCount = 0;
                                
                                dir2 = opendir(folderPath.c_str());
                                
                                if (dir2 != NULL){
                                    while ((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && ((int)entry2.find("bmp") != -1 || (int)entry2.find("tif") != -1)){
                                            treatNameMergeSourceFile [treatNameMergeSourceFileCount] = entry2, treatNameMergeSourceFileCount++;
                                            mergeEntryCount++;
                                        }
                                    }
                                    
                                    closedir(dir2);
                                    
                                    treatNameMergeEntryNo [treatNameMergeEntryNoCount] = mergeEntryCount, treatNameMergeEntryNoCount++;
                                }
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                
                if (entryCountDes == entryCountSou){
                    ifstream fin;
                    
                    int matchFind = 0;
                    int imageSizeCheck = 0;
                    int noMatchFind = 0;
                    int horizontalBit [4];
                    int verticalBit [4];
                    int bitData = 0;
                    int imageWidthSource = 0;
                    int imageHeightSource = 0;
                    int imageWidthDestination = 0;
                    int imageHeightDestination = 0;
                    
                    unsigned long  bitPosition = 0;
                    
                    string sourceSizeCheck;
                    string sourceSizeCheckFile;
                    string destinationSizeCheck;
                    string destinationSizeCheckFile;
                    
                    for (int counter1 = 0; counter1 < treatNameMergeSourceCount; counter1++){
                        matchFind = 0;
                        
                        for (int counter2 = 0; counter2 < treatNameMergeCount; counter2++){
                            if (treatNameMerge [counter2] == treatNameMergeSource [counter1]){
                                matchFind = 1;
                                
                                sourceSizeCheck = sourcePath+"/"+treatNameMergeSource [counter1];
                                sourceSizeCheckFile = "";
                                
                                dir = opendir(sourceSizeCheck.c_str());
                                
                                if (dir != NULL){
                                    while ((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        
                                        if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("STimage ") != -1){
                                            sourceSizeCheckFile = entry;
                                            break;
                                        }
                                    }
                                    
                                    closedir(dir);
                                }
                                
                                sourceSizeCheck = sourceSizeCheck+"/"+sourceSizeCheckFile;
                                
                                fin.open(sourceSizeCheck.c_str(),ios::in | ios::binary);
                                imageWidthSource = 0;
                                imageHeightSource = 0;
                                
                                if (fin.is_open()){
                                    bitPosition = 0;
                                    
                                    while((bitData = fin.get()) != EOF){
                                        if (bitPosition == 18) horizontalBit [0] = bitData;
                                        if (bitPosition == 19) horizontalBit [1] = bitData;
                                        if (bitPosition == 20) horizontalBit [2] = bitData;
                                        if (bitPosition == 21) horizontalBit [3] = bitData;
                                        if (bitPosition == 22) verticalBit [0] = bitData;
                                        if (bitPosition == 23) verticalBit [1] = bitData;
                                        if (bitPosition == 24) verticalBit [2] = bitData;
                                        if (bitPosition == 25){
                                            verticalBit [3] = bitData;
                                            
                                            imageWidthSource = horizontalBit [3]*16777216+horizontalBit [2]*65536+horizontalBit [1]*256+horizontalBit [0];
                                            imageHeightSource = verticalBit [3]*16777216+verticalBit [2]*65536+verticalBit [1]*256+verticalBit [0];
                                            break;
                                        }
                                        
                                        bitPosition++;
                                    }
                                    
                                    fin.close();
                                }
                                
                                destinationSizeCheck = directoryPath+"/"+treatNameMerge [counter2];
                                destinationSizeCheckFile = "";
                                
                                dir = opendir(destinationSizeCheck.c_str());
                                
                                if (dir != NULL){
                                    while ((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        
                                        if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("STimage ") != -1){
                                            destinationSizeCheckFile = entry;
                                            break;
                                        }
                                    }
                                    
                                    closedir(dir);
                                }
                                
                                destinationSizeCheck = destinationSizeCheck+"/"+destinationSizeCheckFile;
                                
                                fin.open(destinationSizeCheck.c_str(),ios::in | ios::binary);
                                
                                imageWidthDestination = 0;
                                imageHeightDestination = 0;
                                
                                if (fin.is_open()){
                                    bitPosition = 0;
                                    
                                    while((bitData = fin.get()) != EOF){
                                        if (bitPosition == 18) horizontalBit [0] = bitData;
                                        if (bitPosition == 19) horizontalBit [1] = bitData;
                                        if (bitPosition == 20) horizontalBit [2] = bitData;
                                        if (bitPosition == 21) horizontalBit [3] = bitData;
                                        if (bitPosition == 22) verticalBit [0] = bitData;
                                        if (bitPosition == 23) verticalBit [1] = bitData;
                                        if (bitPosition == 24) verticalBit [2] = bitData;
                                        if (bitPosition == 25){
                                            verticalBit [3] = bitData;
                                            
                                            imageWidthDestination = horizontalBit [3]*16777216+horizontalBit [2]*65536+horizontalBit [1]*256+horizontalBit [0];
                                            imageHeightDestination = verticalBit [3]*16777216+verticalBit [2]*65536+verticalBit [1]*256+verticalBit [0];
                                            break;
                                        }
                                        
                                        bitPosition++;
                                    }
                                    
                                    fin.close();
                                }
                                
                                if (imageWidthDestination != imageWidthSource || imageHeightDestination != imageHeightSource) imageSizeCheck = 1;
                                
                                break;
                            }
                        }
                        
                        if (matchFind == 0) noMatchFind = 1;
                    }
                    
                    if (noMatchFind == 0 && imageSizeCheck == 0){
                        string mergeProcessPath;
                        string mergeProcessSourcePath1;
                        string mergeProcessDestinationPath1;
                        string timeExtension;
                        string roundExtension;
                        string colorInfo;
                        int maxTimeNo = 0;
                        int maxRoundNo = 0;
                        int readCount = 0;
                        
                        long sizeForCopy = 0;
                        
                        struct stat sizeOfFile;
                        
                        for (int counter1 = 0; counter1 < treatNameMergeSourceCount; counter1++){
                            mergeProcessPath = directoryPath+"/"+treatNameMergeSource [counter1];
                            
                            maxTimeNo = 0;
                            maxRoundNo = 0;
                            
                            dir = opendir(mergeProcessPath.c_str());
                            
                            if (dir != NULL){
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("STimage ") != -1){
                                        if (maxTimeNo < atoi(entry.substr(entry.find("STimage ")+8, 4).c_str())) maxTimeNo = atoi(entry.substr(entry.find("STimage ")+8, 4).c_str());
                                        
                                        if ((int)entry.find("BMP") != -1 || (int)entry.find("TIF") != -1){
                                            if ((int)entry.find("TIF") != -1){
                                                if (maxRoundNo < atoi(entry.substr(entry.find("TIF")+3, 2).c_str())) maxRoundNo = atoi(entry.substr(entry.find("TIF")+3, 2).c_str());
                                            }
                                            else if ((int)entry.find("BMP") != -1){
                                                if (maxRoundNo < atoi(entry.substr(entry.find("BMP")+3, 2).c_str())) maxRoundNo = atoi(entry.substr(entry.find("BMP")+3, 2).c_str());
                                            }
                                        }
                                    }
                                }
                                
                                closedir(dir);
                            }
                            
                            for (int counter2 = 0; counter2 < treatNameMergeEntryNo [counter1]; counter2++){
                                mergeProcessSourcePath1 = sourcePath+"/"+treatNameMergeSource [counter1]+"/"+treatNameMergeSourceFile [readCount];
                                
                                timeExtension = to_string(maxTimeNo+1);
                                
                                if (timeExtension.length() == 1) timeExtension = "000"+timeExtension;
                                else if (timeExtension.length() == 2) timeExtension = "00"+timeExtension;
                                else if (timeExtension.length() == 3) timeExtension = "0"+timeExtension;
                                
                                roundExtension = to_string(maxRoundNo+1);
                                
                                if (roundExtension.length() == 1) roundExtension = "0"+roundExtension;
                                
                                if ((int)treatNameMergeSourceFile [readCount].find(".tif") != -1){
                                    if ((int)treatNameMergeSourceFile [readCount].find("_") != -1){
                                        colorInfo = treatNameMergeSourceFile [readCount].substr(12, treatNameMergeSourceFile [readCount].find(".tif")-12);
                                        mergeProcessDestinationPath1 = directoryPath+"/"+treatNameMergeSource [counter1]+"/STimage "+timeExtension+colorInfo+".TIF"+roundExtension;
                                    }
                                    else mergeProcessDestinationPath1 = directoryPath+"/"+treatNameMergeSource [counter1]+"/STimage "+timeExtension+".TIF"+roundExtension;
                                }
                                else if ((int)treatNameMergeSourceFile [readCount].find(".bmp") != -1){
                                    if ((int)treatNameMergeSourceFile [readCount].find("_") != -1){
                                        colorInfo = treatNameMergeSourceFile [readCount].substr(12, treatNameMergeSourceFile [readCount].find(".bmp")-12);
                                        mergeProcessDestinationPath1 = directoryPath+"/"+treatNameMergeSource [counter1]+"/STimage "+timeExtension+colorInfo+".BMP"+roundExtension;
                                    }
                                    else mergeProcessDestinationPath1 = directoryPath+"/"+treatNameMergeSource [counter1]+"/STimage "+timeExtension+".BMP"+roundExtension;
                                }
                                
                                if (stat(mergeProcessSourcePath1.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    ifstream infile (mergeProcessSourcePath1.c_str(), ifstream::binary);
                                    ofstream outfile (mergeProcessDestinationPath1.c_str(), ofstream::binary);
                                    
                                    char *buffer = new char[sizeForCopy];
                                    infile.read (buffer, sizeForCopy);
                                    outfile.write (buffer, sizeForCopy);
                                    delete [] buffer;
                                    
                                    outfile.close();
                                    infile.close();
                                }
                                
                                readCount++;
                            }
                        }
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        if (imageSizeCheck != 0){
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Image Size Mismatch: Remake Stitched Images Without Using Fluorescent Position Adjustment"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                        else if (noMatchFind != 0){
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Data Format Mismatch"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Sub-folder Number Mismatch"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                
                delete [] treatNameMerge;
                delete [] treatNameMergeSource;
                delete [] treatNameMergeSourceFile;
                delete [] treatNameMergeEntryNo;
            }
            else{
                
                if ((int)extractedID.find("_Image") == -1){
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"No Image folder"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Complete Initial setting"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processings In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)tableReload:(id)sender{
    [saveLoadList reloadData];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = saveLoadListCount;
    
    if (saveLoadType == 3) tableViewContent--;
    
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    string displayData1;
    
    NSAttributedString *attrStr;
    displayData1 = arraySaveLoadList [rowIndex];
    
    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
    [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
    
    if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
    }
    else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    tableCallCount++;
    
    if (tableCallCount == 2) rowNumberHold = rowIndexHold;
    else if (tableCallCount == 1){
        tableCurrentRowHold = rowIndex;
        rowNumberHold = rowIndex;
    }
    
    return YES;
}

-(IBAction)closeWindow:(id)sender{
    [saveLoadWindow orderOut:self];
    saveLoadOperation = 2;
    saveLoadTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (saveLoadOperation == 3){
        [saveLoadWindow makeKeyAndOrderFront:self];
        saveLoadOperation = 1;
        [saveLoadTimer invalidate];
        saveLoadTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(processMonitor) userInfo:nil repeats:YES];
    }
}

-(void)dataSaveUpDate{
    string *arrayUpDate = new string [saveLoadListCount+10];
    
    for (int counter1 = 0; counter1 < saveLoadListCount; counter1++) arrayUpDate [counter1] = arraySaveLoadList [counter1];
    
    delete [] arraySaveLoadList;
    arraySaveLoadList = new string [saveLoadListLimit+500];
    saveLoadListLimit = saveLoadListLimit+500;
    
    for (int counter1 = 0; counter1 < saveLoadListCount; counter1++) arraySaveLoadList [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToSaveLoad object:nil];
    if (saveLoadTimer) [saveLoadTimer invalidate];
    if (saveLoadTimer2) [saveLoadTimer2 invalidate];
}

@end
