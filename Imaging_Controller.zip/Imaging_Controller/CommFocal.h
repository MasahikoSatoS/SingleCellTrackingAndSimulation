//
//  CommFocal.h
//  Imaging_Controller
//
//  Created by Masahiko Sato on 3/9/2014.
//  Copyright Masahiko Sato 2014 All rights reserved.
//
//

#ifndef COMMFOCAL_H
#define COMMFOCAL_H
#import "Controller.h"
#endif

@interface CommFocal : NSObject {
    int focalImageProgress1; //Focal progress
    int focalImageProgress2; //Focal progress
    int focalImageATemptCount; //Focal image A temp count
    
    NSTimer *commFocalTimer;
}

-(id)init;
-(void)dealloc;
-(void)processControl;
-(void)focalImageSel;
-(void)consoleFocalImageUpDate;

@end
