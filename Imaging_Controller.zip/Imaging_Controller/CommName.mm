//
//  CommName.m
//  Imaging_Controller
//
//  Created by Masahiko Sato on 3/9/2014.
//
//

#import "CommName.h"

NSString *notificationToCommName = @"notificationExecuteCommName";

@implementation CommName

-(id)init{
    self = [super init];
    
    if (self != nil){
        nameAssignProgress1 = 0;
        nameAssignProgress2 = 0;
        nameATempCount = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToCommName object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    commNameTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(processControl) userInfo:nil repeats:YES];
}

-(void)processControl{
    if (runStatusTreatmentNameSet != 0) [self nameAssign];
}

-(void)nameAssign{
    //----Initial communication establishment----
    if (runStatusTreatmentNameSet == 2){
        nameATempCount++;
        
        NSString *activeProcess;
        
        for (NSRunningApplication *currApp in [[NSWorkspace sharedWorkspace] runningApplications]){
            activeProcess = [currApp localizedName];
            
            if ([activeProcess isEqualToString:@"FileName_Assignment"]){
                runStatusTreatmentNameSet = 3;
                nameAssignFlag = 1;
                nameAssignProgress1 = 1;
                nameAssignProgress2 = 1;
                break;
            }
        }
        
        if (nameATempCount == 1000){
            nameAssignFlag = 2;
            nameATempCount = 0;
            runStatusTreatmentNameSet = 0;
        }
    }
    
    //----Basic info send----
    if (runStatusTreatmentNameSet == 3 && nameAssignProgress1 == 1){
        nameAssignProgress1 = 2;
    }
    
    if (runStatusTreatmentNameSet == 3 && nameAssignProgress1 == 2){
        string runStatusTemp = "2";
        
        if (initialRunStatus == "2" && processingIFStatus == 0) runStatusTemp = "2";
        else if (initialRunStatus == "3" && processingIFStatus == 0) runStatusTemp = "3";
        else if (initialRunStatus == "2" && processingIFStatus == 1) runStatusTemp = "4";
        else if (initialRunStatus == "3" && processingIFStatus == 1) runStatusTemp = "5";
        
        //runStatusTemp = "2";
        
        fstream oin;
        
        for (int counter1 = 0; counter1 < 10; counter1++){
            oin.open(instructionNamePath.c_str(), ios::out);
            
            if (oin.is_open()){
                oin<<runStatusTemp<<endl;
                oin<<bodyNameHold<<endl;
                oin.close();
                nameAssignProgress1 = 3;
                break;
            }
        }
    }
    
    if (runStatusTreatmentNameSet == 3 && nameAssignProgress1 == 3){
        nameAssignProgress1 = 4;
    }
    
    //----Info receive----
    if (runStatusTreatmentNameSet == 3 && nameAssignProgress2 == 1){
        nameAssignProgress2 = 2;
    }
    
    if (runStatusTreatmentNameSet == 3 && nameAssignProgress2 == 2){
        string receivedData = "nil";
        string getString = "nil";
        
        int instructionNameFlag = 0;
        
        ifstream fin;
        fin.open(instructionNamePath.c_str(),ios::in);
        if (fin.is_open()){
            instructionNameFlag = 1;
            fin.close();
        }
        
        if (instructionNameFlag != 0){
            fin.open(instructionNamePath.c_str(),ios::in);
            
            getline(fin, getString);
            
            if ((int)getString.find("~~N") != -1){
                receivedData = getString;
                remove (instructionNamePath.c_str());
            }
            
            fin.close();
        }
        
        if (receivedData != "nil"){
            string receivedMessage = receivedData;
            
            //cout<<receivedMessage<<" Receive "<<endl;
            
            if ((int)receivedMessage.find("~~N/") != -1){
                receivedMessage = receivedMessage.substr(receivedMessage.find("/")+1);
                string treatmentString;
                
                for (int counter1 = 0; counter1 < 16; counter1++){
                    treatmentString = receivedMessage.substr(0, receivedMessage.find("/"));
                    receivedMessage = receivedMessage.substr(receivedMessage.find("/")+1);
                    arrayNameList [counter1] = treatmentString;
                }
                
                fluorescentNew1 = receivedMessage.substr(0, receivedMessage.find("/"));
                receivedMessage = receivedMessage.substr(receivedMessage.find("/")+1);
                
                string fluorescentCount1 = receivedMessage.substr(0, receivedMessage.find("/"));
                fluorescentColor1 = atoi(fluorescentCount1.c_str());
                receivedMessage = receivedMessage.substr(receivedMessage.find("/")+1);
                
                fluorescentNew2 = receivedMessage.substr(0, receivedMessage.find("/"));
                receivedMessage = receivedMessage.substr(receivedMessage.find("/")+1);
                
                string fluorescentCount2 = receivedMessage.substr(0, receivedMessage.find("/"));
                fluorescentColor2 = atoi(fluorescentCount2.c_str());
                receivedMessage = receivedMessage.substr(receivedMessage.find("/")+1);
                
                fluorescentNew3 = receivedMessage.substr(0, receivedMessage.find("/"));
                receivedMessage = receivedMessage.substr(receivedMessage.find("/")+1);
                
                string fluorescentCount3 = receivedMessage.substr(0, receivedMessage.find("/"));
                fluorescentColor3 = atoi(fluorescentCount3.c_str());
                receivedMessage = receivedMessage.substr(receivedMessage.find("/")+1);
                
                fluorescentNew4 = receivedMessage.substr(0, receivedMessage.find("/"));
                receivedMessage = receivedMessage.substr(receivedMessage.find("/")+1);
                
                string fluorescentCount4 = receivedMessage.substr(0, receivedMessage.find("/"));
                fluorescentColor4 = atoi(fluorescentCount4.c_str());
                receivedMessage = receivedMessage.substr(receivedMessage.find("/")+1);
                
                fluorescentNew5 = receivedMessage.substr(0, receivedMessage.find("/"));
                receivedMessage = receivedMessage.substr(receivedMessage.find("/")+1);
                
                string fluorescentCount5 = receivedMessage.substr(0, receivedMessage.find("/"));
                fluorescentColor5 = atoi(fluorescentCount5.c_str());
                receivedMessage = receivedMessage.substr(receivedMessage.find("/")+1);
                
                fluorescentNew6 = receivedMessage.substr(0, receivedMessage.find("/"));
                receivedMessage = receivedMessage.substr(receivedMessage.find("/")+1);
                
                string fluorescentCount6 = receivedMessage.substr(0, receivedMessage.find("/"));
                fluorescentColor6 = atoi(fluorescentCount6.c_str());
                receivedMessage = receivedMessage.substr(receivedMessage.find("/")+1);
                
                string consoleData = receivedMessage.substr(0, receivedMessage.find("/"));
                receivedMessage = receivedMessage.substr(receivedMessage.find("/")+1);
                
                //cout<<fluorescent1<<" "<<fluorescent2<<" "<<fluorescent3<<" "<<fluorescentColor1<<" "<<fluorescentColor2<<" "<<fluorescentColor3<<" "<<consoleData <<" Receive Data"<<endl;
                //cout<<fluorescent4<<" "<<fluorescent5<<" "<<fluorescent6<<" "<<fluorescentColor4<<" "<<fluorescentColor5<<" "<<fluorescentColor6<<" "<<consoleData <<" Receive Data2"<<endl;
                
                string fovNumberString;
                
                for (int counter1 = 7; counter1 < 23; counter1++){
                    treatmentString = arrayNameList [counter1-7];
                    fovNumberString = to_string(arrayFOVNumberList [counter1-7]);
                    
                    if (treatmentString == "nil" && fovNumberString == "0") arraySummaryList [counter1] = "nil";
                    else if (treatmentString != "nil" && fovNumberString == "0") arraySummaryList [counter1] = treatmentString+" (nil)";
                    else if (treatmentString == "nil" && fovNumberString != "0") arraySummaryList [counter1] = "nil ("+fovNumberString+")";
                    else arraySummaryList [counter1] = treatmentString+" ("+fovNumberString+")";
                }
                
                string colorName1;
                string colorName2;
                string colorName3;
                string colorName4;
                string colorName5;
                string colorName6;
                
                if (fluorescentColor1 == 1) colorName1 = "Blue";
                else if (fluorescentColor1 == 2) colorName1 = "Green";
                else if (fluorescentColor1 == 3) colorName1 = "Yellow";
                else if (fluorescentColor1 == 4) colorName1 = "Red";
                else if (fluorescentColor1 == 5) colorName1 = "Magenta";
                else if (fluorescentColor1 == 6) colorName1 = "Cyan";
                else if (fluorescentColor1 == 7) colorName1 = "Orange";
                else if (fluorescentColor1 == 8) colorName1 = "Purple";
                else if (fluorescentColor1 == 9) colorName1 = "Sky";
                
                if (fluorescentColor2 == 1) colorName2 = "Blue";
                else if (fluorescentColor2 == 2) colorName2 = "Green";
                else if (fluorescentColor2 == 3) colorName2 = "Yellow";
                else if (fluorescentColor2 == 4) colorName2 = "Red";
                else if (fluorescentColor2 == 5) colorName2 = "Magenta";
                else if (fluorescentColor2 == 6) colorName2 = "Cyan";
                else if (fluorescentColor2 == 7) colorName2 = "Orange";
                else if (fluorescentColor2 == 8) colorName2 = "Purple";
                else if (fluorescentColor2 == 9) colorName2 = "Sky";
                
                if (fluorescentColor3 == 1) colorName3 = "Blue";
                else if (fluorescentColor3 == 2) colorName3 = "Green";
                else if (fluorescentColor3 == 3) colorName3 = "Yellow";
                else if (fluorescentColor3 == 4) colorName3 = "Red";
                else if (fluorescentColor3 == 5) colorName3 = "Magenta";
                else if (fluorescentColor3 == 6) colorName3 = "Cyan";
                else if (fluorescentColor3 == 7) colorName3 = "Orange";
                else if (fluorescentColor3 == 8) colorName3 = "Purple";
                else if (fluorescentColor3 == 9) colorName3 = "Sky";
                
                if (fluorescentColor4 == 1) colorName4 = "Blue";
                else if (fluorescentColor4 == 2) colorName4 = "Green";
                else if (fluorescentColor4 == 3) colorName4 = "Yellow";
                else if (fluorescentColor4 == 4) colorName4 = "Red";
                else if (fluorescentColor4 == 5) colorName4 = "Magenta";
                else if (fluorescentColor4 == 6) colorName4 = "Cyan";
                else if (fluorescentColor4 == 7) colorName4 = "Orange";
                else if (fluorescentColor4 == 8) colorName4 = "Purple";
                else if (fluorescentColor4 == 9) colorName4 = "Sky";
                
                if (fluorescentColor5 == 1) colorName5 = "Blue";
                else if (fluorescentColor5 == 2) colorName5 = "Green";
                else if (fluorescentColor5 == 3) colorName5 = "Yellow";
                else if (fluorescentColor5 == 4) colorName5 = "Red";
                else if (fluorescentColor5 == 5) colorName5 = "Magenta";
                else if (fluorescentColor5 == 6) colorName5 = "Cyan";
                else if (fluorescentColor5 == 7) colorName5 = "Orange";
                else if (fluorescentColor5 == 8) colorName5 = "Purple";
                else if (fluorescentColor5 == 9) colorName5 = "Sky";
                
                if (fluorescentColor6 == 1) colorName6 = "Blue";
                else if (fluorescentColor6 == 2) colorName6 = "Green";
                else if (fluorescentColor6 == 3) colorName6 = "Yellow";
                else if (fluorescentColor6 == 4) colorName6 = "Red";
                else if (fluorescentColor6 == 5) colorName6 = "Magenta";
                else if (fluorescentColor6 == 6) colorName6 = "Cyan";
                else if (fluorescentColor6 == 7) colorName6 = "Orange";
                else if (fluorescentColor6 == 8) colorName6 = "Purple";
                else if (fluorescentColor6 == 9) colorName6 = "Sky";
                
                if (fluorescentNew1 != "nil" && fluorescentColor1 != 0) arraySummaryList [24] = fluorescentNew1+" ("+colorName1+")";
                if (fluorescentNew2 != "nil" && fluorescentColor2 != 0) arraySummaryList [25] = fluorescentNew2+" ("+colorName2+")";
                if (fluorescentNew3 != "nil" && fluorescentColor3 != 0) arraySummaryList [26] = fluorescentNew3+" ("+colorName3+")";
                if (fluorescentNew4 != "nil" && fluorescentColor4 != 0) arraySummaryList [27] = fluorescentNew4+" ("+colorName4+")";
                if (fluorescentNew5 != "nil" && fluorescentColor5 != 0) arraySummaryList [28] = fluorescentNew5+" ("+colorName5+")";
                if (fluorescentNew6 != "nil" && fluorescentColor6 != 0) arraySummaryList [29] = fluorescentNew6+" ("+colorName6+")";
                
                ofstream oin;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses parameterSave];
                
                oin.open(summaryDataPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < summaryListCount; counter1++) oin<<arraySummaryList [counter1]<<endl;
                
                oin.close();
                
                oin.open(nameListDataPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < 16; counter1++) oin<<arrayNameList [counter1]<<endl;
                for (int counter1 = 0; counter1 < 16; counter1++) oin<<arrayFOVNumberList [counter1]<<endl;
                
                oin<<fluorescent1<<endl;
                oin<<fluorescent2<<endl;
                oin<<fluorescent3<<endl;
                oin<<fluorescent4<<endl;
                oin<<fluorescent5<<endl;
                oin<<fluorescent6<<endl;
                oin<<fluorescentNew1<<endl;
                oin<<fluorescentNew2<<endl;
                oin<<fluorescentNew3<<endl;
                oin<<fluorescentNew4<<endl;
                oin<<fluorescentNew5<<endl;
                oin<<fluorescentNew6<<endl;
                
                string colorNoString = to_string(fluorescentColor1);
                oin<<colorNoString<<endl;
                
                colorNoString = to_string(fluorescentColor2);
                oin<<colorNoString<<endl;
                
                colorNoString = to_string(fluorescentColor3);
                oin<<colorNoString<<endl;
                
                colorNoString = to_string(fluorescentColor4);
                oin<<colorNoString<<endl;
                
                colorNoString = to_string(fluorescentColor5);
                oin<<colorNoString<<endl;
                
                colorNoString = to_string(fluorescentColor6);
                oin<<colorNoString<<endl;
                
                oin.close();
                
                if (consoleTreatNameCount+5 > consoleTreatNameLimit) [self consoleTreatNameUpDate];
                arrayConsoleTreatName [consoleTreatNameCount] = consoleData, consoleTreatNameCount++;
                
                nameAssignFlag = 3;
                summarySetCall = 2;
                tableViewPage = 0;
                nameAssignProgress2 = 3;
                consolePage = 1;
                consoleDisplayCall = 1;
            }
        }
    }
    
    if (runStatusTreatmentNameSet == 3 && nameAssignProgress2 == 3){
        nameAssignProgress2 = 1;
    }
}

-(void)consoleTreatNameUpDate{
    string *arrayUpDate = new string [consoleTreatNameCount+10];
    
    for (int counter1 = 0; counter1 < consoleTreatNameCount; counter1++) arrayUpDate [counter1] = arrayConsoleTreatName [counter1];
    
    delete [] arrayConsoleTreatName;
    arrayConsoleTreatName = new string [consoleTreatNameLimit+500];
    consoleTreatNameLimit = consoleTreatNameLimit+500;
    
    for (int counter1 = 0; counter1 < consoleTreatNameCount; counter1++) arrayConsoleTreatName [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToCommName object:nil];
    if (commNameTimer) [commNameTimer invalidate];
}

@end
