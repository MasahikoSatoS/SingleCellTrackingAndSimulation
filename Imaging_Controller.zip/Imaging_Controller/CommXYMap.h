//
//  CommXYMap.h
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2/15/2014.
//  Copyright Masahiko Sato 2014 All rights reserved.
//

#ifndef COMMXYMAP_H
#define COMMXYMAP_H
#import "Controller.h"
#endif

@interface CommXYMap : NSObject {
    int progressMonitor; //Progress monitor
    int mapATemptCount; //Map A temp count
    
    NSTimer *commXYMapTimer;
    
    id controllerSubProcesses;
}

-(id)init;
-(void)dealloc;
-(void)xyMapMonitor;
-(void)processControl;

@end
