//
//  SummaryPrint.m
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2014-05-23.
//
//

#import "SummaryPrint.h"

NSString *notificationToSummary = @"notificationExecuteSummary";

@implementation SummaryPrint

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToSummary object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    summaryWindController = [[NSWindowController alloc] initWithWindowNibName:@"SummaryWindow"];
    [summaryWindController showWindow:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [summaryWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [summaryWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
}

-(IBAction)switchSummary:(id)sender{
    if (summaryType == 1){
        summaryType = 2;
        [summaryDisplay setStringValue:@"BackUp List"];
    }
    else if (summaryType == 2){
        summaryType = 1;
        [summaryDisplay setStringValue:@"Summary"];
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSummaryWindow object:self];
}

-(IBAction)closeWindow:(id)sender{
    [summaryWindow orderOut:self];
    summaryOperation = 2;
    summaryTimerTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (summaryOperation == 3){
        [summaryWindow makeKeyAndOrderFront:self];
        summaryOperation = 1;
        [summaryTimerTimer invalidate];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToSummary object:nil];
    if (summaryTimerTimer) [summaryTimerTimer invalidate];
}

@end
