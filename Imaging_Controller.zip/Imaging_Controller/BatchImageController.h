//
//  BatchImageController.h
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2021-08-04.
//  Copyright Masahiko Sato 2021 All rights reserved.
//

#ifndef BATCHIMAGECONTROLLER_H
#define BATCHIMAGECONTROLLER_H
#import "Controller.h"
#endif

@interface BatchImageController : NSObject{
    IBOutlet NSTextField *inputDataSet;
    IBOutlet NSTextField *batchText2;
    IBOutlet NSTextField *batchSetStatus2;
    IBOutlet NSTextField *batchStartStatus2;
    IBOutlet NSTextField *batchAnalysisName2;
    IBOutlet NSTextField *batchSaveName2;
    IBOutlet NSTextField *batchRedoNo2;
    
    IBOutlet NSTextField *runStatusDisplay;
    
    id controllerSubProcesses;
}

-(void)fileDeleteUpDate;

-(IBAction)batchImageSet:(id)sender;
-(IBAction)batchImageStart:(id)sender;
-(IBAction)batchSeriesImageAnalysisNameSet:(id)sender;
-(IBAction)batchSeriesImageNameSet:(id)sender;
-(IBAction)batchSeriesImageNameRedo:(id)sender;

@end
