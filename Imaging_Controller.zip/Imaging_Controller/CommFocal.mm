//
//  CommFocal.m
//  Imaging_Controller
//
//  Created by Masahiko Sato on 3/9/2014.
//
//

#import "CommFocal.h"

NSString *notificationToCommFocal = @"notificationExecuteCommFocal";

@implementation CommFocal

-(id)init{
    self = [super init];
    
    if (self != nil){
        focalImageProgress1 = 0;
        focalImageProgress2 = 0;
        focalImageATemptCount = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToCommFocal object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    commFocalTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(processControl) userInfo:nil repeats:YES];
}

-(void)processControl{
    if (runStatusFocalImage != 0) [self focalImageSel];
}

-(void)focalImageSel{
    //----Initial communication establishment----
    if (runStatusFocalImage == 2){
        focalImageATemptCount++;
        
        NSString *activeProcess;
        
        for (NSRunningApplication *currApp in [[NSWorkspace sharedWorkspace] runningApplications]){
            activeProcess = [currApp localizedName];
            
            if ([activeProcess isEqualToString:@"Focal_Image_Selection"]){
                runStatusFocalImage = 3;
                focalImageFlag = 1;
                focalImageProgress1 = 1;
                focalImageProgress2 = 1;
                focalImageATemptCount = 0;
                break;
            }
        }
        
        if (focalImageATemptCount == 1000){
            focalImageFlag = 2;
            focalImageATemptCount = 0;
            runStatusFocalImage = 0;
        }
    }
    
    //----Basic info send----
    if (runStatusFocalImage == 3 && focalImageProgress1 == 1){
        focalImageProgress1 = 2;
    }
    
    if (runStatusFocalImage == 3 && focalImageProgress1 == 2){
        string runStatusTemp = "2";
        
        if (initialRunStatus == "4" && autoBatchMode == 1) runStatusTemp = "2";
        else if (initialRunStatus == "5" && autoBatchMode == 1) runStatusTemp = "3";
        else if (batchBackupOperationCommit == "1" && batchBackupOnOff == 0) runStatusTemp = "4";
        else if (batchBackupOperationCommit == "1" && batchBackupOnOff == 1) runStatusTemp = "5";
        else if (autoProcessCommit == "1" && autoRunOnOff == 0) runStatusTemp = "6";
        else if (autoProcessCommit == "1" && autoRunOnOff == 1) runStatusTemp = "7";
        else if (initialRunStatus == "4" && autoBatchMode == 2) runStatusTemp = "8";
        else if (initialRunStatus == "5" && autoBatchMode == 2) runStatusTemp = "9";
        
        //runStatusTemp = "8";
        
        fstream oin;
        
        for (int counter1 = 0; counter1 < 10; counter1++){
            oin.open(instructionFIPath.c_str(), ios::out);
            
            if (oin.is_open()){
                oin<<runStatusTemp<<endl;
                oin.close();
                focalImageProgress1 = 3;
                break;
            }
        }
    }
    
    if (runStatusFocalImage == 3 && focalImageProgress1 == 3){
        focalImageProgress1 = 4;
        
        for (int counter1 = 0; counter1 < 16; counter1++) arrayForConsoleCheck [counter1] = 0;
        
        if ((batchBackupOperationCommit == "1" && batchBackupOnOff == 1) || (autoProcessCommit == "1" && autoRunOnOff == 1)){
            [commFocalTimer invalidate];
        }
    }
    
    //----File created by Focal Select check----
    if (runStatusFocalImage == 3 && focalImageProgress2 == 1 && autoProcessCommit == "nil" && batchBackupOperationCommit == "nil"){
        int instructionCSPathFlag = 0;
        
        ifstream fin;
        
        fin.open(instructionCSPath.c_str(),ios::in);
        if (fin.is_open()){
            instructionCSPathFlag = 1;
            fin.close();
        }
        
        string getString = "";
        
        if (instructionCSPathFlag != 0){
            fin.open(instructionCSPath.c_str(),ios::in);
            
            getline(fin, getString);
            
            if (getString == "Next"){
                focalImageFlag = 3;
                focalImageProgress2 = 3;
            }
            
            fin.close();
        }
    }
    
    //----Console display----
    if (runStatusFocalImage == 3 && focalImageProgress1 == 4){
        string productDataPath1;
        
        ifstream fin;
        
        for (int counter1 = 0; counter1 < 16; counter1++){
            if (arrayNameList [counter1] != "nil"){
                productDataPath1 = productsFocalTempPath+"/"+arrayNameList [counter1]+"~Sorted/FOV001/"+arrayNameList [counter1]+"_0001"+"-FOV001.tif";
                
                fin.open(productDataPath1.c_str(),ios::in);
                
                if (fin.is_open()){
                    fin.close();
                    
                    if (arrayForConsoleCheck [counter1] == 0){
                        if (consoleFocalImageCount+5 > consoleFocalImageLimit) [self consoleFocalImageUpDate];
                        arrayConsoleFocalImage [consoleFocalImageCount] = bodyNameHold+"-10001"+"/ "+arrayNameList [counter1], consoleFocalImageCount++;
                        
                        arrayForConsoleCheck [counter1] = 1;
                        consolePage = 2;
                        consoleDisplayCall = 1;
                        break;
                    }
                }
                else{
                    
                    productDataPath1 = productsFocalTempPath+"/"+arrayNameList [counter1]+"~Sorted/FOV001/"+arrayNameList [counter1]+"_0001"+"-FOV001.bmp";
                    
                    fin.open(productDataPath1.c_str(),ios::in);
                    
                    if (fin.is_open()){
                        fin.close();
                        
                        if (arrayForConsoleCheck [counter1] == 0){
                            if (consoleFocalImageCount+5 > consoleFocalImageLimit) [self consoleFocalImageUpDate];
                            arrayConsoleFocalImage [consoleFocalImageCount] = bodyNameHold+"-10001"+"/ "+arrayNameList [counter1], consoleFocalImageCount++;
                            
                            arrayForConsoleCheck [counter1] = 1;
                            consolePage = 2;
                            consoleDisplayCall = 1;
                            break;
                        }
                    }
                }
            }
        }
    }
}

-(void)consoleFocalImageUpDate{
    string *arrayUpDate = new string [consoleFocalImageCount+10];
    
    for (int counter1 = 0; counter1 < consoleFocalImageCount; counter1++) arrayUpDate [counter1] = arrayConsoleFocalImage [counter1];
    
    delete [] arrayConsoleFocalImage;
    arrayConsoleFocalImage = new string [consoleFocalImageLimit+500];
    consoleFocalImageLimit = consoleFocalImageLimit+500;
    
    for (int counter1 = 0; counter1 < consoleFocalImageCount; counter1++) arrayConsoleFocalImage [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToCommFocal object:nil];
    if (commFocalTimer) [commFocalTimer invalidate];
}

@end
