//
//  BatchImageController.m
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2021-08-04.
//  Copyright Masahiko Sato 2021 All rights reserved.
//

#import "BatchImageController.h"

@implementation BatchImageController

-(IBAction)batchSeriesImageAnalysisNameSet:(id)sender{
    if (autoBatchMode == 3){
        if (imageFolderListCount != 0){
            if (batchImagePathNameHold != "nil"){
                if (autoRunOnOff == 0 && batchBackupOnOff == 0 && batchImageOnOff == 0 && initialRunStatus == "nil"){
                    if (processingIFStatus == 0){
                        batchImageBodyName = arrayImageFolderList [rowNumberHold];
                        batchImagePathInfo = productsFilesPath+"/"+batchImageBodyName+"_Products";
                        
                        [batchSetStatus2 setStringValue:@"Set"];
                        [batchAnalysisName2 setStringValue:@(batchImageBodyName.c_str())];
                        
                        ofstream oin;
                        oin.open(batchProcessImagePath.c_str(), ios::out);
                        oin<<batchImageBodyName<<endl;
                        oin<<batchImagePathNameHold<<endl;
                        oin<<batchImagePathInfo<<endl;
                        oin<<filePickUpCount<<endl;
                        oin<<largestFileNoBatch<<endl;
                        oin.close();
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"IF Mode On"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        [inputDataSet setStringValue:@""];
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Stop Auto/Batch Processing"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    [inputDataSet setStringValue:@""];
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Perform Folder Find"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            [inputDataSet setStringValue:@""];
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Batch Image Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        [inputDataSet setStringValue:@""];
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)batchSeriesImageNameSet:(id)sender{
    if (autoBatchMode == 3){
        if (autoRunOnOff == 0 && batchBackupOnOff == 0 && batchImageOnOff == 0 && initialRunStatus == "nil"){
            if (processingIFStatus == 0){
                nameCheckString = [[inputDataSet stringValue] UTF8String];
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                int checkResults = [controllerSubProcesses nameCheck];
                
                if (checkResults == 0){
                    if (nameCheckString.length() < 4 || nameCheckString.length() > 15) checkResults = 1;
                }
                
                if (checkResults == 0){
                    string entry;
                    
                    DIR *dir;
                    struct dirent *dent;
                    
                    dir = opendir(productsFilesPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if ((int)entry.find(nameCheckString+"_") != -1){
                                    checkResults = 2;
                                    break;
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    dir = opendir(cellTrackingImageFolderPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if ((int)entry.find(nameCheckString+"_") != -1){
                                    checkResults = 2;
                                    break;
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    dir = opendir(cellTrackingDataPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if ((int)entry.find(nameCheckString+"_") != -1){
                                    checkResults = 2;
                                    break;
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    dir = opendir(cellTrackingAnalysisPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if ((int)entry.find(nameCheckString+"_") != -1){
                                    checkResults = 2;
                                    break;
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                }
                
                if (checkResults == 0){
                    batchImagePathNameHold = nameCheckString;
                    
                    ofstream oin;
                    oin.open(batchProcessImagePath.c_str(), ios::out);
                    oin<<batchImageBodyName<<endl;
                    oin<<batchImagePathNameHold<<endl;
                    oin<<batchImagePathInfo<<endl;
                    oin.close();
                    
                    [inputDataSet setStringValue:@""];
                    [batchSaveName2 setStringValue:@(batchImagePathNameHold.c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Identical Name was found"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    [inputDataSet setStringValue:@""];
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"IF Mode On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                [inputDataSet setStringValue:@""];
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Stop Auto/Batch Processing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            [inputDataSet setStringValue:@""];
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Batch Image Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        [inputDataSet setStringValue:@""];
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)batchImageSet:(id)sender{
    if (autoBatchMode == 3){
        if (batchImagePathNameHold != "nil"){
            if (autoRunOnOff == 0 && batchBackupOnOff == 0 && batchImageOnOff == 0){
                if (processingIFStatus == 0){
                    imageFolderListCount = 0;
                    
                    string entry;
                    string extractedID;
                    
                    DIR *dir;
                    struct dirent *dent;
                    
                    dir = opendir(productsFilesPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if ((int)entry.find("_Products") != -1){
                                    extractedID = entry.substr(0, entry.find("_Products"));
                                    
                                    if (imageFolderListCount < 500) arrayImageFolderList [imageFolderListCount] = extractedID, imageFolderListCount++;
                                }
                            }
                        }
                        
                        closedir(dir);
                        
                        //----Directory Sort----
                        NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                        
                        for (int counter1 = 0; counter1 < imageFolderListCount; counter1++){
                            [unsortedArray addObject:@(arrayImageFolderList [counter1].c_str())];
                        }
                        
                        [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                        
                        for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                            arrayImageFolderList [counter1] = [unsortedArray [counter1] UTF8String];
                        }
                    }
                    
                    tableViewPage = 3;
                    tableViewCall = 1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"IF Mode On"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Stop Auto/Batch Processing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Set A Series Name"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Batch Image Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)batchImageStart:(id)sender{
    if (initialRunStatus == "8"){
        if (autoBatchMode == 3){
            if (batchImageOperationCommit == "nil"){
                batchImageOperationCommit = "1";
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses parameterSave];
                
                [batchStartStatus2 setStringValue:@"Hold"];
                
                if (processingIFStatus == 0) [runStatusDisplay setStringValue:@"Proc."];
            }
            
            if (batchImageOnOff == 0 && (largestFileNoBatch >= filePickUpCount || (processingIFStatus == 1 && largestFileNoBatch >= batchImageIFCount))){
                if (runStatusContrast == 0){
                    remove (instructionFIPath.c_str());
                    remove (instructionFIPath2.c_str());
                    remove (instructionAPPath.c_str());
                    remove (instructionCSPath.c_str());
                    
                    batchImageOnOff = 1;
                    [batchStartStatus2 setStringValue:@"On"];
                    
                    runStatusContrast = 1;
                    autoStepCount = 0;
                    
                    string launchProgramContrast = launchProgramPath+"/"+"Contrast_Set.app";
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBatchImage object:self];
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCommContrast object:self];
                    
                    NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
                    [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramContrast.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
                    
                    launchCheck = 1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Batch Image On"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else if (batchImageOnOff == 1){
                autoTimerInvalidate = 1;
                [batchStartStatus2 setStringValue:@"Wait"];
            }
            else{
                
                if (largestFileNoBatch < filePickUpCount || largestFileNoBatch < batchImageIFCount){
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Processing Complete"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Perform Initial Run"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)batchSeriesImageNameRedo:(id)sender{
    if (autoBatchMode == 3){
        if (batchImageOperationCommit != "nil"){
            if (batchImagePathNameHold != "nil"){
                if (batchImageOnOff == 0){
                    if (runStatusContrast == 0){
                        if (processingIFStatus == 0){
                            if ([inputDataSet integerValue] <= largestFileNoBatch && [inputDataSet integerValue] < filePickUpCount){
                                if ([inputDataSet integerValue] > 0){
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert addButtonWithTitle:@"Cancel"];
                                    [alert setMessageText:@"Delete Data And Re-do Processing?"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    
                                    if ([alert runModal] == NSAlertFirstButtonReturn){
                                        filePickUpCount = (int)[inputDataSet integerValue];
                                        
                                        string stitchedFolderBatchPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images"+"/"+batchImagePathNameHold+"_Image";
                                        string entry;
                                        string entry2;
                                        string entry3;
                                        string productDataPath1;
                                        string productDataPath2;
                                        string productDataPath3;
                                        string fileNoST;
                                        
                                        DIR *dir;
                                        struct dirent *dent;
                                        DIR *dir2;
                                        struct dirent *dent2;
                                        
                                        dir = opendir(stitchedFolderBatchPath.c_str());
                                        fileDeleteCount = 0;
                                        
                                        if (dir != NULL){
                                            while ((dent = readdir(dir))){
                                                entry = dent -> d_name;
                                                
                                                if ((int)entry.find("_Stitch") != -1){
                                                    productDataPath1 = stitchedFolderBatchPath+"/"+entry;
                                                    
                                                    dir2 = opendir(productDataPath1.c_str());
                                                    
                                                    if (dir2 != NULL){
                                                        while ((dent2 = readdir(dir2))){
                                                            entry2 = dent2 -> d_name;
                                                            
                                                            if ((int)entry2.find("STimage ") != -1){
                                                                fileNoST = entry2.substr(entry2.find("STimage ")+8, 4);
                                                                
                                                                if (atoi(fileNoST.c_str()) >= filePickUpCount){
                                                                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                                                    arrayFileDelete [fileDeleteCount] = productDataPath1+"/"+entry2, fileDeleteCount++;
                                                                }
                                                            }
                                                        }
                                                        
                                                        closedir(dir2);
                                                    }
                                                }
                                            }
                                            
                                            closedir(dir);
                                            
                                            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                                remove (arrayFileDelete [counter1].c_str());
                                            }
                                        }
                                        
                                        filePickUpCount--;
                                        autoTotalCount = filePickUpCount-1;
                                        
                                        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                        [controllerSubProcesses parameterSave];
                                        
                                        [batchRedoNo2 setIntegerValue:filePickUpCount];
                                        
                                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                                        [sound play];
                                    }
                                    
                                    [inputDataSet setStringValue:@""];
                                }
                                else{
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"Set Point: Out Of Range: Out of range"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                                
                                [inputDataSet setStringValue:@""];
                            }
                            else{
                                
                                [inputDataSet setStringValue:@""];
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"Set Point: Out Of Range: Out of range"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Redo Not Allow In IF Mode"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        [inputDataSet setStringValue:@""];
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Quit Contrast Setting"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    [inputDataSet setStringValue:@""];
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Hold Batch Processing"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                [inputDataSet setStringValue:@""];
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Need to set a series name"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            [inputDataSet setStringValue:@""];
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Start Batch (Image)"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        [inputDataSet setStringValue:@""];
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Batch (Image) Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

@end
