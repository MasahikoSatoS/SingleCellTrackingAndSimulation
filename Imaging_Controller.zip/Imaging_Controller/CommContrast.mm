//
//  CommContrast.m
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2014-04-09.
//
//

#import "CommContrast.h"

NSString *notificationToCommContrast = @"notificationExecuteCommContrast";

@implementation CommContrast

-(id)init{
    self = [super init];
    
    if (self != nil){
        contrastSetProgress1 = 0;
        contrastSetProgress2 = 0;
        contrastImageATempCount = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToCommContrast object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    commContrastTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(processControl) userInfo:nil repeats:YES];
}

-(void)processControl{
    if (runStatusContrast != 0) [self contrastSet];
}

-(void)contrastSet{
    //----Initial communication establishment----
    if (runStatusContrast == 2){
        contrastImageATempCount++;
        
        NSString *activeProcess;
        
        for (NSRunningApplication *currApp in [[NSWorkspace sharedWorkspace] runningApplications]){
            activeProcess = [currApp localizedName];
            
            if ([activeProcess isEqualToString:@"Contrast_Set"]){
                runStatusContrast = 3;
                contrastSetFlag = 1;
                contrastSetProgress1 = 1;
                contrastSetProgress2 = 1;
                contrastImageATempCount = 0;
                break;
            }
        }
        
        if (contrastImageATempCount == 1000){
            contrastSetFlag = 2;
            contrastImageATempCount = 0;
            runStatusContrast = 0;
        }
    }
    
    //----Basic info send----
    if (runStatusContrast == 3 && contrastSetProgress1 == 1){
        contrastSetProgress1 = 2;
    }
    
    if (runStatusContrast == 3 && contrastSetProgress1 == 2){
        string runStatusTemp = "2";
        string statusIF = "0";
        
        if (initialRunStatus == "6" && autoBatchMode == 1) runStatusTemp = "2"; //----Initial Auto----
        else if (initialRunStatus == "7" && autoBatchMode == 1) runStatusTemp = "3"; //----Initial Auto After set----
        else if (batchBackupOperationCommit == "1" && batchBackupOnOff == 0) runStatusTemp = "4"; //----Batch BK, process during the holding----
        else if (batchBackupOperationCommit == "1" && batchBackupOnOff == 1) runStatusTemp = "5"; //----Batch BK----
        else if (autoProcessCommit == "1" && autoRunOnOff == 0) runStatusTemp = "6"; //----Auto, process during the holding----
        else if (autoProcessCommit == "1" && autoRunOnOff == 1) runStatusTemp = "7"; //----Auto----
        else if (initialRunStatus == "6" && autoBatchMode == 2) runStatusTemp = "8"; //----Initial Batch BK----
        else if (initialRunStatus == "7" && autoBatchMode == 2) runStatusTemp = "9"; //----Initial Batch BK, after set----
        else if (initialRunStatus == "6" && autoBatchMode == 3) runStatusTemp = "10"; //----Initial Batch IG----
        else if (initialRunStatus == "7" && autoBatchMode == 3) runStatusTemp = "11"; //----Initial Batch IG, after set----
        else if (batchImageOperationCommit == "1" && batchImageOnOff == 0) runStatusTemp = "12"; //----Batch IG, process during the holding----
        else if (batchImageOperationCommit == "1" && batchImageOnOff == 1) runStatusTemp = "13"; //----Batch IG----
        
        if (processingIFStatus == 1 && autoBatchMode == 2) statusIF = "1";
        else if (processingIFStatus == 1 && autoBatchMode == 3) statusIF = "2";
        else if (processingIFStatus == 1 && autoBatchMode == 1) statusIF = "3";
        
        fstream oin;
        
        for (int counter1 = 0; counter1 < 10; counter1++){
            oin.open(instructionCSPath.c_str(), ios::out);
            
            if (oin.is_open()){
                oin<<runStatusTemp<<endl;
                oin<<statusIF<<endl;
                oin.close();
                contrastSetProgress1 = 3;
                break;
            }
        }
    }
    
    if (runStatusContrast == 3 && contrastSetProgress1 == 3){
        contrastSetProgress1 = 4;
        
        for (int counter1 = 0; counter1 < 16; counter1++) arrayForConsoleCheck2 [counter1] = 0;
        
        if ((batchBackupOperationCommit == "1" && batchBackupOnOff == 1) || (autoProcessCommit == "1" && autoRunOnOff == 1) || (batchImageOperationCommit == "1" && batchImageOnOff == 1)){
            [commContrastTimer invalidate];
        }
    }
    
    if (runStatusContrast == 3 && contrastSetProgress2 == 1 && autoProcessCommit == "nil" && batchBackupOperationCommit == "nil" && batchImageOperationCommit == "nil"){
        int instructionAPFlag = 0;
        
        ifstream fin;
        fin.open(instructionAPPath.c_str(),ios::in);
        if (fin.is_open()){
            instructionAPFlag = 1;
            fin.close();
        }
        
        string getString = "";
        
        if (instructionAPFlag != 0){
            fin.open(instructionAPPath.c_str(),ios::in);
            
            getline(fin, getString);
            
            if (getString == "Done"){
                contrastSetFlag = 3;
                contrastSetProgress2 = 3;
            }
            
            fin.close();
        }
    }
    
    //----Console display----
    if (runStatusContrast == 3 && contrastSetProgress1 == 4){
        string productDataPath1;
        
        ifstream fin;
        
        for (int counter1 = 0; counter1 < 16; counter1++){
            if (arrayNameList [counter1] != "nil"){
                productDataPath1 = productsStitchTempPath+"/"+arrayNameList [counter1]+"_Stitch/"+"STimage "+"0001.tif";
                
                fin.open(productDataPath1.c_str(),ios::in);
                
                if (fin.is_open()){
                    fin.close();
                    
                    if (arrayForConsoleCheck2 [counter1] == 0){
                        if (consoleContrastCount+5 > consoleContrastLimit) [self consoleContrastUpDate];
                        arrayConsoleContrast [consoleContrastCount] = "STimage 0001/ "+arrayNameList [counter1], consoleContrastCount++;
                        
                        arrayForConsoleCheck2 [counter1] = 1;
                        consolePage = 3;
                        consoleDisplayCall = 1;
                        break;
                    }
                }
                else {
                    
                    productDataPath1 = productsStitchTempPath+"/"+arrayNameList [counter1]+"_Stitch/"+"STimage "+"0001.bmp";
                    
                    fin.open(productDataPath1.c_str(),ios::in);
                    
                    if (fin.is_open()){
                        fin.close();
                        
                        if (arrayForConsoleCheck2 [counter1] == 0){
                            if (consoleContrastCount+5 > consoleContrastLimit) [self consoleContrastUpDate];
                            arrayConsoleContrast [consoleContrastCount] = "STimage 0001/ "+arrayNameList [counter1], consoleContrastCount++;
                            
                            arrayForConsoleCheck2 [counter1] = 1;
                            consolePage = 3;
                            consoleDisplayCall = 1;
                            break;
                        }
                    }
                }
            }
        }
    }
}

-(void)consoleContrastUpDate{
    string *arrayUpDate = new string [consoleContrastCount+10];
    
    for (int counter1 = 0; counter1 < consoleContrastCount; counter1++) arrayUpDate [counter1] = arrayConsoleContrast [counter1];
    
    delete [] arrayConsoleContrast;
    arrayConsoleContrast = new string [consoleContrastLimit+500];
    consoleContrastLimit = consoleContrastLimit+500;
    
    for (int counter1 = 0; counter1 < consoleContrastCount; counter1++) arrayConsoleContrast [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToCommContrast object:nil];
    if (commContrastTimer) [commContrastTimer invalidate];
}

@end
