//
//  CommOutlineDraw.m
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2/15/2014.
//
//

#import "CommOutlineDraw.h"

NSString *notificationToCommOutlineDraw = @"notificationExecuteCommOutlineDraw";

@implementation CommOutlineDraw

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToCommOutlineDraw object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    commOutlineDrawTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(processControl) userInfo:nil repeats:YES];
}

-(void)processControl{
    if (runStatusOutlineDraw != 0) [self outlineDraw];
}

-(void)outlineDraw{
    if (runStatusOutlineDraw == 2){
        NSString *activeProcess;
        
        for (NSRunningApplication *currApp in [[NSWorkspace sharedWorkspace] runningApplications]){
            activeProcess = [currApp localizedName];
            
            if ([activeProcess isEqualToString:@"Cell_Outline_Draw"]){
                runStatusOutlineDraw = 3;
                outlineDrawDisplayFlag = 1;
                [commOutlineDrawTimer invalidate];
                break;
            }
        }
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToCommOutlineDraw object:nil];
    if (commOutlineDrawTimer) [commOutlineDrawTimer invalidate];
}

@end
