//
//  ActiveProcessMonitor.m
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2014-05-14.
//
//

#import "ActiveProcessMonitor.h"

NSString *notificationToActiveProcess = @"notificationExecuteActiveProcess";

@implementation ActiveProcessMonitor

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToActiveProcess object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    activeProcessTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(processControl) userInfo:nil repeats:YES];
}

-(void)processControl{
    if (launchCheck == 0){
        NSString *activeProcess;
        
        int xyMapActive = 0;
        int fileUploadActive = 0;
        int nameActive = 0;
        int focalActive = 0;
        int contrastActive = 0;
        int outlineActive = 0;
        int cellTrackingActive = 0;
        int dataAnalysisActive = 0;
        int backUpActive = 0;
        int cellMovieActive = 0;
        int cellMovieActive2 = 0;
        int cellMovieActive3 = 0;
        int cellMovieActive4 = 0;
        int cellMovieActive5 = 0;
        int cellMovieActive6 = 0;
        int cellMovieQuant = 0;
        int watsonActive = 0;
        int fileConverterActive = 0;
        int cell3DActive = 0;
        
        if (runStatusXYMap > 0) xyMapActive = 1;
        if (runStatusFileUpLoad > 0) fileUploadActive = 1;
        if (runStatusTreatmentNameSet > 0) nameActive = 1;
        if (runStatusFocalImage > 0) focalActive = 1;
        if (runStatusContrast > 0) contrastActive = 1;
        if (runStatusOutlineDraw > 0) outlineActive = 1;
        if (runStatusCellTracking > 0) cellTrackingActive = 1;
        if (runStatusDataAnalysis > 0) dataAnalysisActive = 1;
        if (runStatusBackUp > 0) backUpActive = 1;
        if (runStatusMovie > 0) cellMovieActive = 1;
        if (runStatusMovie2 > 0) cellMovieActive2 = 1;
        if (runStatusMovie3 > 0) cellMovieActive3 = 1;
        if (runStatusMovie4 > 0) cellMovieActive4 = 1;
        if (runStatusMovie5 > 0) cellMovieActive5 = 1;
        if (runStatusMovie6 > 0) cellMovieActive6 = 1;
        if (runStatusMovieQuant > 0) cellMovieQuant = 1;
        if (runStatusWatson > 0) watsonActive = 1;
        if (runStatusFileConverter > 0) fileConverterActive = 1;
        if (runStatusCell3D > 0) cell3DActive = 1;
        
        for (NSRunningApplication *currApp in [[NSWorkspace sharedWorkspace] runningApplications]){
            activeProcess = [currApp localizedName];
            
            //NSLog (@"%@", activeProcess);
            
            if ([activeProcess isEqualToString:@"XY_Map"]) xyMapActive = 2;
            if ([activeProcess isEqualToString:@"FileUpLoad"]) fileUploadActive = 2;
            if ([activeProcess isEqualToString:@"FileName_Assignment"]) nameActive = 2;
            if ([activeProcess isEqualToString:@"Focal_Image_Selection"]) focalActive = 2;
            if ([activeProcess isEqualToString:@"Contrast_Set"]) contrastActive = 2;
            if ([activeProcess isEqualToString:@"Cell_Outline_Draw"]) outlineActive = 2;
            if ([activeProcess isEqualToString:@"Cell_Tracking"]) cellTrackingActive = 2;
            if ([activeProcess isEqualToString:@"Lineage_Analysis"]) dataAnalysisActive = 2;
            if ([activeProcess isEqualToString:@"Data_BackUp"]) backUpActive = 2;
            if ([activeProcess isEqualToString:@"CellMovie"]) cellMovieActive = 2;
            if ([activeProcess isEqualToString:@"CellMovie2"]) cellMovieActive2 = 2;
            if ([activeProcess isEqualToString:@"CellMovie3"]) cellMovieActive3 = 2;
            if ([activeProcess isEqualToString:@"CellMovie4"]) cellMovieActive4 = 2;
            if ([activeProcess isEqualToString:@"CellMovie5"]) cellMovieActive5 = 2;
            if ([activeProcess isEqualToString:@"CellMovie6"]) cellMovieActive6 = 2;
            if ([activeProcess isEqualToString:@"CellMovieQuant"]) cellMovieQuant = 2;
            if ([activeProcess isEqualToString:@"Watson"]) watsonActive = 2;
            if ([activeProcess isEqualToString:@"FileConverter"]) fileConverterActive = 2;
            if ([activeProcess isEqualToString:@"Cell3D"]) cell3DActive = 2;
        }
        
        //----To make subprocess debug, slash out relevant ones----
        if (xyMapActive == 1) mapDisplayFlag = 2;
        if (fileUploadActive == 1) fileUpLoadFlag = 2, processLoopMonitor = 0, runStatusFileUpLoad = 4;
        if (nameActive == 1) nameAssignFlag = 2, runStatusTreatmentNameSet = 4;
        if (focalActive == 1) focalImageFlag = 2, runStatusFocalImage = 4;
        if (contrastActive == 1) contrastSetFlag = 2, runStatusContrast = 4;
        if (outlineActive == 1) outlineDrawDisplayFlag = 2;
        if (cellTrackingActive == 1) cellTrackingDisplayFlag = 2;
        if (dataAnalysisActive == 1) analysisDisplayFlag = 2;
        if (backUpActive == 1) backUpDisplayFlag = 2;
        if (cellMovieActive == 1) cellMovieDisplayFlag = 2;
        if (cellMovieActive2 == 1) cellMovieDisplayFlag2 = 2;
        if (cellMovieActive3 == 1) cellMovieDisplayFlag3 = 2;
        if (cellMovieActive4 == 1) cellMovieDisplayFlag4 = 2;
        if (cellMovieActive5 == 1) cellMovieDisplayFlag5 = 2;
        if (cellMovieActive6 == 1) cellMovieDisplayFlag6 = 2;
        if (cellMovieQuant == 1) cellMovieQuantFlag = 2;
        if (watsonActive == 1) watsonFlag = 2;
        if (fileConverterActive == 1) fileConverterFlag = 2;
        if (cell3DActive == 1) cell3DFlag = 2;
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToActiveProcess object:nil];
    if (activeProcessTimer) [activeProcessTimer invalidate];
}

@end
