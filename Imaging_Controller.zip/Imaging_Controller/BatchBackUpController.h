//
//  BatchBackUpController.h
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2021-08-04.
//  Copyright Masahiko Sato 2021 All rights reserved.
//

#ifndef BATCHBACKUPCONTROLLER_H
#define BATCHBACKUPCONTROLLER_H
#import "Controller.h"
#endif

@interface BatchBackUpController : NSObject{
    IBOutlet NSTextField *inputDataSet;
    IBOutlet NSTextField *batchText1;
    IBOutlet NSTextField *batchSetStatus1;
    IBOutlet NSTextField *batchStartStatus1;
    IBOutlet NSTextField *batchAnalysisName1;
    IBOutlet NSTextField *batchSaveName1;
    IBOutlet NSTextField *batchRedoNo1;
    IBOutlet NSTextField *runStatusDisplay;
    
    IBOutlet NSProgressIndicator *backSave;
    
    id controllerSubProcesses;
}

-(void)fileDeleteUpDate;
-(void)batchInfoUpDate;

-(IBAction)batchSet:(id)sender;
-(IBAction)batchStart:(id)sender;
-(IBAction)batchSeriesNameSet:(id)sender;
-(IBAction)batchAnalysisNameSet:(id)sender;
-(IBAction)batchImageRedo:(id)sender;

@end
