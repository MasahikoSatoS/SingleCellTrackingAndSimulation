//
//  CommContrast.h
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2014-04-09.
//  Copyright Masahiko Sato 2014 All rights reserved.
//
//

#ifndef COMMCONTRAST_H
#define COMMCONTRAST_H
#import "Controller.h"
#endif

@interface CommContrast : NSObject {
    int contrastSetProgress1; //Contrast progress
    int contrastSetProgress2; //Contrast progress
    int contrastImageATempCount; //Contrast image A Temp count
    
    NSTimer *commContrastTimer;
}

-(id)init;
-(void)dealloc;
-(void)processControl;
-(void)contrastSet;
-(void)consoleContrastUpDate;

@end
