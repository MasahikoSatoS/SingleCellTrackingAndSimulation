//
//  SummaryPrint.h
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2014-05-23.
//  Copyright Masahiko Sato 2014 All rights reserved.
//
//

#ifndef SUMMARYPRINT_H
#define SUMMARYPRINT_H
#import "Controller.h"
#endif

@interface SummaryPrint : NSObject {
    IBOutlet NSTextField *summaryDisplay;
    IBOutlet NSWindow *summaryWindow;
    
    NSTimer *summaryTimerTimer;
    
    NSWindowController *summaryWindController;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;

-(IBAction)closeWindow:(id)sender;
-(IBAction)switchSummary:(id)sender;

@end
