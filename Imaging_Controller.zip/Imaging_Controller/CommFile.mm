//
//  CommFile.mm
//  Imaging_Controller
//
//  Created by Masahiko Sato on 3/9/2014.
//
//

#import "CommFile.h"

NSString *notificationToCommFile = @"notificationExecuteCommFile";

@implementation CommFile

-(id)init{
    self = [super init];
    
    if (self != nil){
        incrementCountTransfer = 0;
        fileNameCount = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToCommFile object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    commFileTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(processControl) userInfo:nil repeats:YES];
}

-(void)processControl{
    if (runStatusFileUpLoad != 0) [self fileUpLoad];
    if (processLoopMonitor == 1) [self fileTransfer];
    if (processLoopMonitor == 4) [self nameSetAuto];
}

-(void)fileUpLoad{
    //----Initial communication establishment----
    if (runStatusFileUpLoad == 2){
        runStatusFileUpLoad = 3;
        fileUpLoadFlag = 1;
        fileUpLoadProgress1 = 1;
        fileUpLoadInitialSet = 1;
    }
    else if (runStatusFileUpLoad == 3 && fileUpLoadProgress1 == 1){
        fileUpLoadProgress1 = 2;
    }
    else if (runStatusFileUpLoad == 3 && fileUpLoadProgress1 == 2){
        if (fileUpLoadInitialSet == 1){
            fileUpLoadInitialSet = 0;
            
            string instructionFLTempPath2 = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/FL_InstructionTemp2";
            string instructionFLPath2 = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/FL_Instruction2";
            
            string runStatusTemp = "2";
            
            if ((initialRunStatus == "0" || initialRunStatus == "1") && processingIFStatus == 0) runStatusTemp = "2";
            if (initialRunStatus == "8" && lastPurgeFlag == 0 && processingIFStatus == 0) runStatusTemp = "1";
            if (initialRunStatus == "8" && lastPurgeFlag == 3){
                runStatusTemp = "9";
                lastPurgeFlag = 4;
            }
            if ((initialRunStatus == "0" || initialRunStatus == "1") && processingIFStatus == 1) runStatusTemp = "3";
            if (initialRunStatus == "8" && lastPurgeFlag == 0 && processingIFStatus == 1) runStatusTemp = "4";
            
            ofstream oin;
            
            for (int counter1 = 0; counter1 < 10; counter1++){
                oin.open(instructionFLTempPath2.c_str(), ios::out);
                
                if (oin.is_open()){
                    oin<<computerNameHold<<endl;
                    oin<<userIDHold<<endl;
                    oin<<bodyNameHold<<endl;
                    oin<<totalFOVNoHold<<endl;
                    oin<<runStatusTemp<<endl;
                    
                    oin.close();
                    
                    ifstream fin;
                    
                    fin.open(instructionFLTempPath2.c_str(),ios::in);
                    
                    if (fin.is_open()){
                        fin.close();
                        
                        rename(instructionFLTempPath2.c_str(), instructionFLPath2.c_str());
                        
                        fileUpLoadProgress2 = 1;
                        fileUpLoadProgress1 = 3;
                        
                        break;
                    }
                }
            }
        }
    }
    
    //----Info receive----
    if (runStatusFileUpLoad == 3 && fileUpLoadProgress2 == 1 && (initialRunStatus == "0" || initialRunStatus == "1" || (initialRunStatus == "8" && lastPurgeFlag == 4))){
        int instructionFIFlag = 0;
        
        ifstream fin;
        fin.open(instructionFLPath.c_str(),ios::in);
        if (fin.is_open()){
            instructionFIFlag = 1;
            fin.close();
        }
        
        string getString = "";
        
        if (instructionFIFlag != 0){
            fin.open(instructionFLPath.c_str(),ios::in);
            
            getline(fin, getString);
            
            if (getString == "IF"){
                fileUpLoadFlag = 4;
                fileUpLoadProgress2 = 3;
            }
            else if (getString == "DIC"){
                getline(fin, getString);
                fluorescent1 = getString;
                fluorescentNew1 = getString;
                
                getline(fin, getString);
                fluorescent2 = getString;
                fluorescentNew2 = getString;
                
                getline(fin, getString);
                fluorescent3 = getString;
                fluorescentNew3 = getString;
                
                getline(fin, getString);
                fluorescent4 = getString;
                fluorescentNew4 = getString;
                
                getline(fin, getString);
                fluorescent5 = getString;
                fluorescentNew5 = getString;
                
                getline(fin, getString);
                fluorescent6 = getString;
                fluorescentNew6 = getString;
                
                getline(fin, getString);
                fluorescentCount = atoi(getString.c_str());
                
                getline(fin, getString);
                dicFluorescentMode = atoi(getString.c_str());
                
                if (fluorescent1 != "nil") arraySummaryList [24] = fluorescent1+" (nil)";
                if (fluorescent2 != "nil") arraySummaryList [25] = fluorescent2+" (nil)";
                if (fluorescent3 != "nil") arraySummaryList [26] = fluorescent3+" (nil)";
                if (fluorescent4 != "nil") arraySummaryList [27] = fluorescent4+" (nil)";
                if (fluorescent5 != "nil") arraySummaryList [28] = fluorescent5+" (nil)";
                if (fluorescent6 != "nil") arraySummaryList [29] = fluorescent6+" (nil)";
                
                ofstream oin;
                oin.open(summaryDataPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < summaryListCount; counter1++) oin<<arraySummaryList [counter1]<<endl;
                
                oin.close();
                
                int directoryRmv = 0;
                pathToDelete = dataFilesPath;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses fileDeleteLayerTwo:directoryRmv];
                
                directoryRmv = 1;
                pathToDelete = dataFilesPath;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
                
                fileUpLoadFlag = 4;
                summarySetCall = 2;
                tableViewPage = 0;
                consolePage = 0;
                consoleDisplayCall = 1;
                processLoopMonitor = 0;
                imageTimePointAccumulationCounter = 0;
                fileUpLoadProgress2 = 3;
            }
            
            fin.close();
        }
    }
}

-(void)fileTransfer{
    if (fileTransferProgress  == 1){
        int bodyNameLength = (int)bodyNameHold.length();
        lowestTime = 100000;
        lowestBodyNumber = 100000;
        int nextBodyNumber = 0;
        int nextTimePoint = 0;
        int fileNumberCount = 0;
        
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(dataImportFolderPath.c_str());
        
        if (dir != NULL){
            string entry;
            
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                if ((int)entry.find(bodyNameHold) != -1) fileNumberCount++;
            }
            
            closedir(dir);
        }
        
        arrayFileName = new string [fileNumberCount+50];
        fileNameCount = 0;
        arrayTimeNumber = new int [fileNumberCount+50];
        timeNumberCount = 0;
        arrayBodyNumber = new int [fileNumberCount+50];
        bodyNumberCount = 0;
        
        dir = opendir(dataImportFolderPath.c_str());
        
        if (dir != NULL){
            string entry;
            string bodyNumber;
            string timePoint;
            
            int findMatch1 = 0;
            
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                findMatch1 = (int)entry.find(bodyNameHold);
                
                if (findMatch1 > 0){
                    if (entry.substr((unsigned long)findMatch1-1, 1) != "_") findMatch1 = -1;
                }
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && findMatch1 != -1){
                    if ((int)entry.find("_s") != -1){
                        bodyNumber = entry.substr((unsigned long)bodyNameLength, 3);
                        timePoint = entry.substr(entry.find("_t")+2, 4);
                        
                        arrayBodyNumber [bodyNumberCount] = atoi(bodyNumber.c_str()), bodyNumberCount++;
                        arrayFileName [fileNameCount] = entry, fileNameCount++;
                        arrayTimeNumber [timeNumberCount] = atoi(timePoint.c_str()), timeNumberCount++;
                        
                        //cout<< bodyNumber<<" "<<timePoint<<" "<<entry<<" BodyName"<<endl;
                    }
                }
            }
            
            closedir(dir);
        }
        
        //cout<<fileNameCount<<" fileNoCount"<<endl;
        
        if (fileNameCount != 0){
            for (int counter1 = 0; counter1 < fileNameCount; counter1++){
                if (arrayBodyNumber [counter1] < lowestBodyNumber) lowestBodyNumber = arrayBodyNumber [counter1];
                if (arrayBodyNumber [counter1] > nextBodyNumber) nextBodyNumber = arrayBodyNumber [counter1];
            }
            
            if (lowestBodyNumber != 100000){
                for (int counter1 = 0; counter1 < fileNameCount; counter1++){
                    if (arrayTimeNumber [counter1] < lowestTime && arrayBodyNumber [counter1] == lowestBodyNumber) lowestTime = arrayTimeNumber [counter1];
                    if (arrayTimeNumber [counter1] > nextTimePoint && arrayBodyNumber [counter1] == nextBodyNumber) nextTimePoint = arrayTimeNumber [counter1];
                }
                
                //cout<<lowestBodyNumber<<" "<<nextBodyNumber<<" "<<lowestTime<<" "<<nextTimePoint<<" LowInfo"<<endl;
                
                if (lowestTime != 100000){
                    int findFlag = 0;
                    
                    if (nextBodyNumber > lowestBodyNumber || (nextBodyNumber == lowestBodyNumber && nextTimePoint > lowestTime)) findFlag = 1;
                    
                    if ((findFlag == 1 && initialRunStatus == "8" && autoProcessCommit == "1") || initialRunStatus != "8" || lastPurgeFlag != 0 || processingIFStatus == 1){
                        string timePointString = to_string(lowestTime);
                        string timePointAdjust;
                        
                        if (timePointString.length() == 1) timePointAdjust = "000"+timePointString;
                        else if (timePointString.length() == 2) timePointAdjust = "00"+timePointString;
                        else if (timePointString.length() == 3) timePointAdjust = "0"+timePointString;
                        else timePointAdjust = timePointString;
                        
                        string bodyNumberString = to_string(lowestBodyNumber);
                        string bodyNumberAdjust;
                        
                        if (bodyNumberString.length() == 1) bodyNumberAdjust = "00"+bodyNumberString;
                        else if (bodyNumberString.length() == 2) bodyNumberAdjust = "0"+bodyNumberString;
                        else bodyNumberAdjust = bodyNumberString;
                        
                        int fileNumberCount2 = 0;
                        string bodyNameTemp = bodyNameHold+bodyNumberAdjust;
                        
                        int wholeNameLength = (int)bodyNameTemp.length()+16;
                        int fluorescentDetectFlag = 0;
                        
                        int fluorescentCase = 0;
                        selectFileCount = 0;
                        string fileNameTemp;
                        
                        int wholeNameLengthFile = 0;
                        
                        //cout<<bodyNumberAdjust<<" "<<bodyNameTemp<<" "<<timePointAdjust<<" BodyAdjust "<<wholeNameLength<<endl;
                        
                        for (int counter1 = 0; counter1 < fileNameCount; counter1++){
                            fileNameTemp = arrayFileName [counter1];
                            
                            if ((int)fileNameTemp.find("t"+timePointAdjust) != -1 && (int)fileNameTemp.find(bodyNameTemp) != -1){
                                fileNumberCount2++;
                                
                                if (selectFileCount+50 > selectFileLimit) [self selectFileUpDate];
                                
                                wholeNameLengthFile = (int)arrayFileName [counter1].length();
                                arraySelectFiles [selectFileCount] = arrayFileName [counter1], selectFileCount++;
                                
                                if (wholeNameLength < wholeNameLengthFile) fluorescentDetectFlag = 1;
                            }
                        }
                        
                        int cutOffNumber = 0;
                        
                        if (fluorescentDetectFlag == 1){
                            cutOffNumber = atoi(totalFOVNoHold.c_str())+atoi(totalFOVNoHold.c_str())*fluorescentCount;
                            fluorescentCase = 2;
                        }
                        else if (nextTimePoint != 0){
                            cutOffNumber = atoi(totalFOVNoHold.c_str());
                            fluorescentCase = 1;
                        }
                        
                        //cout<<initialRunStatus<<" "<<atoi(totalFOVNoHold.c_str())<<" "<<fluorescentCount<<" "<<fileNumberCount2<<"  InfoA"<<endl;
                        //cout<<atoi(totalFOVNoHold.c_str())+fluorescentCount*atoi(totalFOVNoHold.c_str())<<" "<<cutOffNumber<<" "<<fluorescentCase<<" check"<<endl;
                        //cout<<processingIFStatus<<" "<<fluorescentCase<<" "<<cutOffNumber<<" "<<atoi(totalFOVNoHold.c_str())+atoi(totalFOVNoHold.c_str())*fluorescentCount<<endl;
                        
                        if ((initialRunStatus == "8" && fluorescentCase == 1 && fileNumberCount2 == cutOffNumber) || (initialRunStatus == "8" && fluorescentCase == 2 && fileNumberCount2 <= cutOffNumber && processingIFStatus == 0) || ((initialRunStatus == "0" || initialRunStatus == "1") && fileNumberCount2 == atoi(totalFOVNoHold.c_str())+atoi(totalFOVNoHold.c_str())*fluorescentCount) || lastPurgeFlag == 5 || (processingIFStatus == 1 && fluorescentCase == 2 && fileNumberCount2 == cutOffNumber)){
                            fileTransferProgress  = 2;
                        }
                        else if (nextBodyNumber > lowestBodyNumber || (nextBodyNumber == lowestBodyNumber && nextTimePoint > lowestTime)){
                            string entry;
                            string removeFilePath;
                            
                            for (int counter1 = 0; counter1 < fileNameCount; counter1++){
                                if (arrayBodyNumber [counter1] == lowestBodyNumber && arrayTimeNumber [counter1] == lowestTime){
                                    entry = arrayFileName [counter1];
                                    removeFilePath = dataImportFolderPath+"/"+entry;
                                    remove (removeFilePath.c_str());
                                }
                            }
                            
                            delete [] arrayFileName;
                            delete [] arrayTimeNumber;
                            delete [] arrayBodyNumber;
                            
                            fileTransferProgress  = 0;
                        }
                    }
                    else{
                        
                        delete [] arrayFileName;
                        delete [] arrayTimeNumber;
                        delete [] arrayBodyNumber;
                    }
                }
                else{
                    
                    delete [] arrayFileName;
                    delete [] arrayTimeNumber;
                    delete [] arrayBodyNumber;
                    
                    fileTransferProgress  = 0;
                }
            }
            else{
                
                delete [] arrayFileName;
                delete [] arrayTimeNumber;
                delete [] arrayBodyNumber;
                
                fileTransferProgress  = 0;
            }
        }
        else{
            
            delete [] arrayFileName;
            delete [] arrayTimeNumber;
            delete [] arrayBodyNumber;
        }
    }
    
    if (fileTransferProgress  == 2){
        imageTimePointAccumulationCounter++;
        
        roundTimeString = to_string(imageTimePointAccumulationCounter);
        
        if (roundTimeString.length() == 1) folderNameForNamed = bodyNameHold+"-1000"+roundTimeString;
        else if (roundTimeString.length() == 2) folderNameForNamed = bodyNameHold+"-100"+roundTimeString;
        else if (roundTimeString.length() == 3) folderNameForNamed = bodyNameHold+"-10"+roundTimeString;
        else folderNameForNamed = bodyNameHold+"-1"+roundTimeString;
        
        dataSaveFolderPath = dataFilesPath+"/"+folderNameForNamed;
        mkdir(dataSaveFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        incrementCountTransfer = 0;
        fileTransferProgress  = 3;
    }
    
    if (fileTransferProgress  == 3){
        int bodyNameLength = (int)bodyNameHold.length();
        string removeFilePath;
        
        if (selectFileCount != incrementCountTransfer){
            string entry = arraySelectFiles [incrementCountTransfer];
            string fluorescentAddition = "";
            
            if (dicFluorescentMode == 2){
                if ((int)entry.find(fluorescent1) != -1) fluorescentAddition = fluorescent1;
                if ((int)entry.find(fluorescent2) != -1) fluorescentAddition = fluorescent2;
                if ((int)entry.find(fluorescent3) != -1) fluorescentAddition = fluorescent3;
                if ((int)entry.find(fluorescent4) != -1) fluorescentAddition = fluorescent4;
                if ((int)entry.find(fluorescent5) != -1) fluorescentAddition = fluorescent5;
                if ((int)entry.find(fluorescent6) != -1) fluorescentAddition = fluorescent6;
            }
            
            string fileNamePath = dataImportFolderPath+"/"+entry;
            string bodyNumber = entry.substr((unsigned long)bodyNameLength, 3);
            string stagePosition = entry.substr(entry.find("_s")+1, 5);
            string timePoint = entry.substr(entry.find("_t")+1, 5);
            string destinationNamePath;
            
            if (dicFluorescentMode == 1) destinationNamePath = dataSaveFolderPath+"/"+bodyNameHold+bodyNumber+"_"+stagePosition+"_"+timePoint+".tif";
            else if (dicFluorescentMode == 2 && fluorescentAddition != "") destinationNamePath = dataSaveFolderPath+"/"+bodyNameHold+bodyNumber+"_"+fluorescentAddition+"_"+stagePosition+"_"+timePoint+".tif";
            else if (dicFluorescentMode == 2 && fluorescentAddition == "") destinationNamePath = dataSaveFolderPath+"/"+bodyNameHold+bodyNumber+"_"+stagePosition+"_"+timePoint+".tif";
            
            //----Tiff reading----
            unsigned long stripFirstAddress = 0;
            unsigned long stripByteCountAddress = 0;
            unsigned long nextAddress = 0;
            unsigned long headPosition = 0;
            unsigned long stripEntry = 0;
            unsigned long ifDPreviousHold = 0;
            long sizeForCopy = 0;
            
            double xPosition = 0;
            double yPosition = 0;
            
            int imageWidth = 0;
            int imageHeight = 0;
            int imageBit = 0; //Check 8, 16
            int imageCompression = 0; //Check 1
            int photoMetric = 0; //Check 0, 1, 2
            int imageDimension = 0;
            int verticalBmp = 0;
            int horizontalBmp = 0;
            int horizontalBmpEntry = 0;
            int endianType = 0;
            int samplePerPix = 0;
            int loopCount = 0;
            int dataConversion [4];
            int mode = 1;
            int processType = 3;
            int numberOfLayers = 0;
            int terminationFlag = 0;
            int singleDoubleCheck = 0;
            
            struct stat sizeOfFile;
            
            //----File Read----
            if (stat(fileNamePath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                ifstream fin2;
                
                fileReadArray = new uint8_t [(int)sizeForCopy+4];
                fin2.open(fileNamePath.c_str(), ios::in | ios::binary);
                fin2.read((char*)fileReadArray, sizeForCopy+1);
                fin2.close();
                
                dataConversion [0] = fileReadArray [0];
                dataConversion [1] = fileReadArray [1];
                
                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                else endianType = 0;
                
                int *arrayExtractedImage3 = new int [100];
                
                headPosition = 0;
                
                if (endianType == 1){
                    dataConversion [0] = fileReadArray [7];
                    dataConversion [1] = fileReadArray [6];
                    dataConversion [2] = fileReadArray [5];
                    dataConversion [3] = fileReadArray [4];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                else if (endianType == 0){
                    dataConversion [0] = fileReadArray [4];
                    dataConversion [1] = fileReadArray [5];
                    dataConversion [2] = fileReadArray [6];
                    dataConversion [3] = fileReadArray [7];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                
                loopCount = 0;
                
                fileSavePathHold = destinationNamePath;
                
                do{
                    
                    terminationFlag = 1;
                    imageDimension = 0;
                    
                    if (endianType == 1){
                        tiffFileRead = [[TiffFileRead alloc] init];
                        [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                        
                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                            if (imageWidth > imageHeight) imageDimension = imageWidth;
                            else imageDimension = imageHeight;
                            
                            tiffFileRead = [[TiffFileRead alloc] init];
                            delete [] arrayExtractedImage3;
                            
                            arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                        }
                    }
                    else if (endianType == 0){
                        tiffFileRead = [[TiffFileRead alloc] init];
                        [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                        
                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                            if (imageWidth > imageHeight) imageDimension = imageWidth;
                            else imageDimension = imageHeight;
                            
                            tiffFileRead = [[TiffFileRead alloc] init];
                            delete [] arrayExtractedImage3;
                            
                            arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                        }
                    }
                    
                    if (imageWidth == imageHeight || fileSplitOption == 1){
                        singleDoubleCheck = 1;
                        break;
                    }
                    
                    if (imageDimension != 0){
                        int **arrayImageFileSaveTemp = new int *[imageDimension+1];
                        arrayImageFileSave = new int *[imageDimension+1];
                        
                        for (int counter3 = 0; counter3 < imageDimension+1; counter3++){
                            arrayImageFileSaveTemp [counter3] = new int [imageDimension*3+1];
                            arrayImageFileSave [counter3] = new int [imageDimension*3+1];
                        }
                        
                        for (int counter3 = 0; counter3 < imageDimension; counter3++){
                            for (int counter4 = 0; counter4 < imageDimension*3; counter4++){
                                arrayImageFileSaveTemp [counter3][counter4] = 0;
                                arrayImageFileSave [counter3][counter4] = 0;
                            }
                        }
                        
                        verticalBmp = 0;
                        horizontalBmp = 0;
                        
                        if (photoMetric == 1){
                            for (int counter2 = 0; counter2 < imageWidth*imageHeight; counter2++){
                                if (horizontalBmp < imageWidth){
                                    arrayImageFileSaveTemp [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2]);
                                    horizontalBmpEntry++;
                                }
                                
                                if (horizontalBmpEntry == imageWidth){
                                    horizontalBmpEntry = 0;
                                    verticalBmp++;
                                }
                            }
                        }
                        else if (photoMetric == 2){
                            for (int counter2 = 0; counter2 < imageWidth*imageHeight; counter2++){
                                if (horizontalBmp < imageWidth){
                                    arrayImageFileSaveTemp [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2*3]), horizontalBmpEntry++;
                                    arrayImageFileSaveTemp [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2*3+1]), horizontalBmpEntry++;
                                    arrayImageFileSaveTemp [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2*3+2]), horizontalBmpEntry++;
                                    horizontalBmpEntry++;
                                }
                                
                                if (horizontalBmp == imageWidth){
                                    horizontalBmpEntry = 0;
                                    verticalBmp++;
                                }
                            }
                        }
                        
                        if (imageWidth == imageHeight*2){
                            if ((dicFluorescentMode == 2 && fluorescentAddition == "") || dicFluorescentMode == 1){
                                if (photoMetric == 1){
                                    for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                        for (int counter3 = imageWidth/2; counter3 < imageWidth; counter3++){
                                            arrayImageFileSave [counter2][counter3-imageWidth/2] = arrayImageFileSaveTemp [counter2][counter3];
                                        }
                                    }
                                }
                                else if (photoMetric == 2){
                                    for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                        for (int counter3 = imageWidth/2; counter3 < imageWidth; counter3++){
                                            arrayImageFileSave [counter2][(counter3-imageWidth/2)*3] = arrayImageFileSaveTemp [counter2][counter3*3];
                                            arrayImageFileSave [counter2][(counter3-imageWidth/2)*3+1] = arrayImageFileSaveTemp [counter2][counter3*3+1];
                                            arrayImageFileSave [counter2][(counter3-imageWidth/2)*3+1] = arrayImageFileSaveTemp [counter2][counter3*3+1];
                                        }
                                    }
                                }
                            }
                            else if (dicFluorescentMode == 2 && fluorescentAddition != ""){
                                if (photoMetric == 1){
                                    for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                        for (int counter3 = 0; counter3 < imageWidth/2; counter3++){
                                            arrayImageFileSave [counter2][counter3] = arrayImageFileSaveTemp [counter2][counter3];
                                        }
                                    }
                                }
                                else if (photoMetric == 2){
                                    for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                        for (int counter3 = 0; counter3 < imageWidth/2; counter3++){
                                            arrayImageFileSave [counter2][counter3*3] = arrayImageFileSaveTemp [counter2][counter3*3];
                                            arrayImageFileSave [counter2][counter3*3+1] = arrayImageFileSaveTemp [counter2][counter3*3+1];
                                            arrayImageFileSave [counter2][counter3*3+2] = arrayImageFileSaveTemp [counter2][counter3*3+2];
                                        }
                                    }
                                }
                            }
                            
                            imageWidth = imageWidth/2;
                        }
                        else{
                            
                            if (photoMetric == 1){
                                for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                    for (int counter3 = 0; counter3 < imageWidth; counter3++){
                                        arrayImageFileSave [counter2][counter3] = arrayImageFileSaveTemp [counter2][counter3];
                                    }
                                }
                            }
                            else if (photoMetric == 2){
                                for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                    for (int counter3 = 0; counter3 < imageWidth; counter3++){
                                        arrayImageFileSave [counter2][counter3*3] = arrayImageFileSaveTemp [counter2][counter3*3];
                                        arrayImageFileSave [counter2][counter3*3+1] = arrayImageFileSaveTemp [counter2][counter3*3+1];
                                        arrayImageFileSave [counter2][counter3*3+2] = arrayImageFileSaveTemp [counter2][counter3*3+2];
                                    }
                                }
                            }
                        }
                        
                        if (loopCount == 0 && nextAddress == 0) mode = 0;
                        
                        if (xPosition == -1) xPosition = 100;
                        if (yPosition == -1) yPosition = 100;
                        
                        singleTiffSave = [[SingleTiffSave alloc] init];
                        ifDPreviousHold = [singleTiffSave singleTiffLayerSave:imageWidth:imageHeight:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:ifDPreviousHold];
                        
                        for (int counter3 = 0; counter3 < imageDimension+1; counter3++){
                            delete [] arrayImageFileSaveTemp [counter3];
                            delete [] arrayImageFileSave [counter3];
                        }
                        
                        delete [] arrayImageFileSaveTemp;
                        delete [] arrayImageFileSave;
                    }
                    
                    if (nextAddress != 0){
                        headPosition = nextAddress;
                        loopCount++;
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                delete [] arrayExtractedImage3;
                delete [] fileReadArray;
            }
            
            if (singleDoubleCheck == 0) remove (fileNamePath.c_str());
            else rename (fileNamePath.c_str(), destinationNamePath.c_str());
            
            incrementCountTransfer++;
        }
        else{
            
            if (initialRunStatus == "0" || initialRunStatus == "1"){
                int directoryRmv = 1;
                pathToDelete = dataImportFolderPath;
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
            }
            
            processLoopMonitor = 3;
            fileTransferProgress  = 0;
            
            arraySummaryList [5] = roundTimeString;
            
            ofstream oin;
            oin.open(summaryDataPath.c_str(), ios::out);
            
            for (int counter1 = 0; counter1 < summaryListCount; counter1++) oin<<arraySummaryList [counter1]<<endl;
            
            oin.close();
            
            controllerSubProcesses = [[ControllerSubProcesses alloc] init];
            [controllerSubProcesses parameterSave];
            
            summarySetCall = 2;
            tableViewPage = 0;
            
            delete [] arrayFileName;
            delete [] arrayTimeNumber;
            delete [] arrayBodyNumber;
        }
    }
}

-(void)nameSetAuto{
    int totalFovNameInt = atoi(totalFOVNoHold.c_str());
    
    string *arrayTransferNameList = new string [totalFovNameInt+10];
    int transferNameListCount = 1;
    
    int *arrayTransferNumberList = new int [totalFovNameInt*2+10];
    int transferNumberListCount = 2; //----No entry to 0 and 1----
    
    int sequentialNo = 1;
    int listNumberCount = 0;
    
    for (int counter1 = 0; counter1 < 16; counter1++){
        if (arrayNameList [counter1] != "nil"){
            listNumberCount = 1;
            
            for (int counter2 = 0; counter2 < arrayFOVNumberList [counter1]; counter2++){
                arrayTransferNameList [transferNameListCount] = arrayNameList [counter1], transferNameListCount++;
                arrayTransferNumberList [transferNumberListCount] = listNumberCount, transferNumberListCount++, listNumberCount++;
                arrayTransferNumberList [transferNumberListCount] = sequentialNo, transferNumberListCount++, sequentialNo++;
            }
        }
    }
    
    //for (int counterA = 1; counterA <= totalFovNameInt; counterA++){
    //    cout<<" "<<arrayTransferNameList [counterA]<<" "<<arrayTransferNumberList [counterA*2]<<" "<<arrayTransferNumberList [counterA*2+1]<<" arrayData"<<counterA<<endl;
    //}
    
    dataSaveFolderPath = namedFilesPath+"/"+folderNameForNamed;
    mkdir(dataSaveFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    
    string sourceFolderPath = dataFilesPath+"/"+folderNameForNamed;
    string timePoint = folderNameForNamed.substr(folderNameForNamed.find("-")+1);
    
    timePoint = to_string(atoi(timePoint.c_str())-10000);
    
    if (timePoint.length() == 1) timePoint = "000"+timePoint;
    else if (timePoint.length() == 2) timePoint = "00"+timePoint;
    else if (timePoint.length() == 3) timePoint = "0"+timePoint;
    
    string entry;
    
    DIR *dir;
    struct dirent *dent;
    
    for (int counter1 = 1; counter1 <= totalFovNameInt; counter1++){
        fileDeleteCount = 0;
        
        dir = opendir(sourceFolderPath.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
            }
            
            closedir(dir);
            
            int findString1 = 0;
            int stagePositionTemp = 0;
            
            string stagePosition;
            string newTreatmentName;
            string fluorescentColor;
            string newFluorescentColor;
            string fluorescentColorNo;
            string sourceFilePath;
            string destinationFilePath;
            
            for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                entry = arrayFileDelete [counter2];
                
                findString1 = (int)entry.find(bodyNameHold);
                
                if (findString1 > 0){
                    if (entry.substr((unsigned long)findString1-1, 1) != "_") findString1 = -1;
                }
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && findString1 != -1){
                    stagePosition = entry.substr(entry.find("_s")+2, 4);
                    stagePositionTemp = 1;
                    
                    for (int counter3 = 1; counter3 <= totalFovNameInt; counter3++){
                        if (atoi(stagePosition.c_str()) == arrayTransferNumberList [counter3*2+1]){
                            stagePositionTemp = counter3;
                            break;
                        }
                    }
                    
                    //for (int counterA = 1; counterA <= totalFovNameInt; counterA++){
                    //    cout<<" "<<arrayTransferNameList [counterA]<<" "<<arrayTransferNumberList [counterA*2]<<" "<<arrayTransferNumberList [counterA*2+1]<<" arrayData"<<counterA<<endl;
                    //}
                    
                    newTreatmentName = arrayTransferNameList [stagePositionTemp];
                    stagePosition = to_string(arrayTransferNumberList [stagePositionTemp*2]);
                    
                    if (bodyNameHold.length()+19 != entry.length()) fluorescentColor = entry.substr(bodyNameHold.length()+4, entry.find("_s")-bodyNameHold.length()-4);
                    else fluorescentColor = "";
                    
                    if (fluorescentColor != ""){
                        if (fluorescentColor == fluorescent1){
                            newFluorescentColor = fluorescentNew1;
                            fluorescentColorNo = to_string(fluorescentColor1);
                        }
                        else if (fluorescentColor == fluorescent2){
                            newFluorescentColor = fluorescentNew2;
                            fluorescentColorNo = to_string(fluorescentColor2);
                        }
                        else if (fluorescentColor == fluorescent3){
                            newFluorescentColor = fluorescentNew3;
                            fluorescentColorNo = to_string(fluorescentColor3);
                        }
                        else if (fluorescentColor == fluorescent4){
                            newFluorescentColor = fluorescentNew4;
                            fluorescentColorNo = to_string(fluorescentColor4);
                        }
                        else if (fluorescentColor == fluorescent5){
                            newFluorescentColor = fluorescentNew5;
                            fluorescentColorNo = to_string(fluorescentColor5);
                        }
                        else if (fluorescentColor == fluorescent6){
                            newFluorescentColor = fluorescentNew6;
                            fluorescentColorNo = to_string(fluorescentColor6);
                        }
                    }
                    else newFluorescentColor = "";
                    
                    sourceFilePath = sourceFolderPath+"/"+entry;
                    
                    if (newFluorescentColor == "") destinationFilePath = dataSaveFolderPath+"/"+newTreatmentName+"_"+timePoint+"-"+stagePosition+".tif";
                    else destinationFilePath = dataSaveFolderPath+"/"+newTreatmentName+"_"+timePoint+"-"+stagePosition+"_"+fluorescentColorNo+"_"+newFluorescentColor+".tif";
                    
                    rename (sourceFilePath.c_str(), destinationFilePath.c_str());
                }
            }
        }
    }
    
    int directoryRmv = 2;
    pathToDelete = sourceFolderPath;
    
    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
    [controllerSubProcesses fileDeleteLayerOne:directoryRmv];
    
    rmdir (sourceFolderPath.c_str());
    
    if (consoleTreatNameCount+5 > consoleTreatNameLimit) [self consoleTreatNameUpDate];
    arrayConsoleTreatName [consoleTreatNameCount] = folderNameForNamed, consoleTreatNameCount++;
    
    delete [] arrayTransferNumberList;
    delete [] arrayTransferNameList;
    
    processLoopMonitor = 5;
    consolePage = 1;
    consoleDisplayCall = 1;
}

-(void)consoleTreatNameUpDate{
    string *arrayUpDate = new string [consoleTreatNameCount+10];
    
    for (int counter1 = 0; counter1 < consoleTreatNameCount; counter1++) arrayUpDate [counter1] = arrayConsoleTreatName [counter1];
    
    delete [] arrayConsoleTreatName;
    arrayConsoleTreatName = new string [consoleTreatNameLimit+500];
    consoleTreatNameLimit = consoleTreatNameLimit+500;
    
    for (int counter1 = 0; counter1 < consoleTreatNameCount; counter1++) arrayConsoleTreatName [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)selectFileUpDate{
    string *arrayUpDate = new string [selectFileCount+10];
    
    for (int counter1 = 0; counter1 < selectFileCount; counter1++) arrayUpDate [counter1] = arraySelectFiles [counter1];
    
    delete [] arraySelectFiles;
    arraySelectFiles = new string [selectFileLimit+500];
    selectFileLimit = selectFileLimit+500;
    
    for (int counter1 = 0; counter1 < selectFileCount; counter1++) arraySelectFiles [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToCommFile object:nil];
    if (commFileTimer) [commFileTimer invalidate];
}

@end
