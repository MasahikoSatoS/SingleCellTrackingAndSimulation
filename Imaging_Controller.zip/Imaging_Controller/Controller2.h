//
//  Controller2.h
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2021-08-03.
//  Copyright Masahiko Sato 2021 All rights reserved.
//

#ifndef CONTROLLER2_H
#define CONTROLLER2_H
#import "Controller.h"
#endif

@interface Controller2 : NSObject{
    IBOutlet NSTextField *analysisName;
    IBOutlet NSTextField *computerName;
    IBOutlet NSTextField *totalFOV;
    IBOutlet NSTextField *userID;
    
    IBOutlet NSTextField *backUpName;
    IBOutlet NSTextField *inputDataSet;
    IBOutlet NSTextField *objectiveSet;
    IBOutlet NSTextField *fileSplitSet;
    
    id controllerSubProcesses;
}

-(IBAction)analysisNameSet:(id)sender;
-(IBAction)computerNameSet:(id)sender;
-(IBAction)totalFOVSet:(id)sender;
-(IBAction)userIDSet:(id)sender;

-(IBAction)xyMapStart:(id)sender;
-(IBAction)outlineStartStart:(id)sender;
-(IBAction)dataBackUpStart:(id)sender;
-(IBAction)cellTrackingStart:(id)sender;
-(IBAction)movieRunStart:(id)sender;
-(IBAction)movieRunStart2:(id)sender;
-(IBAction)movieRunStart3:(id)sender;
-(IBAction)movieRunStart4:(id)sender;
-(IBAction)movieRunStart5:(id)sender;
-(IBAction)movieRunStart6:(id)sender;
-(IBAction)movieRunStartQuant:(id)sender;
-(IBAction)watsonStart:(id)sender;
-(IBAction)dataAnalysisStart:(id)sender;
-(IBAction)fileUpLoadStart:(id)sender;
-(IBAction)treatNameStart:(id)sender;
-(IBAction)focalStart:(id)sender;
-(IBAction)contrastSetStart:(id)sender;
-(IBAction)fileConverterStart:(id)sender;
-(IBAction)cell3DStart:(id)sender;

-(IBAction)objective10:(id)sender;
-(IBAction)objective20:(id)sender;
-(IBAction)objective40:(id)sender;

-(IBAction)fileSplitSetNo:(id)sender;
-(IBAction)fileSplitSetYES:(id)sender;

@end
