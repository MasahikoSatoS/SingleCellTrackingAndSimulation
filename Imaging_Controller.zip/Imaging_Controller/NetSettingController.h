//
//  NetSettingController.h
//  Imaging_Controller
//
//  Created by Masahiko Sato on 1/24/17.
//  Copyright Masahiko Sato 2017 All rights reserved.
//
//

#ifndef NETSETTINGCONTROLLER_H
#define NETSETTINGCONTROLLER_H
#import "Controller.h"
#endif

@interface NetSettingController : NSObject {
    IBOutlet NSTextField *addressDisplay;
    IBOutlet NSTextField *addressInput;
    IBOutlet NSTextField *usernameDisplay;
    IBOutlet NSTextField *usernameInput;
    IBOutlet NSTextField *passwordDisplay;
    IBOutlet NSTextField *passwordInput;
    
    IBOutlet NSWindow *netCheckWindow;
    NSTimer *netCheckTimer;
    
    NSWindowController *netCheckWindowController;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;

-(IBAction)addressSet:(id)sender;
-(IBAction)usernameSet:(id)sender;
-(IBAction)passwordSet:(id)sender;
-(IBAction)closeWindow:(id)sender;

@end
