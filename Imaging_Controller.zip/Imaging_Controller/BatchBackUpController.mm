//
//  BatchBackUpController.m
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2021-08-04.
//  Copyright Masahiko Sato 2021 All rights reserved.
//

#import "BatchBackUpController.h"

@implementation BatchBackUpController

-(IBAction)batchAnalysisNameSet:(id)sender{
    if (autoBatchMode == 2){
        if (autoRunOnOff == 0 && batchBackupOnOff == 0 && batchImageOnOff == 0 && initialRunStatus == "nil"){
            if (processingIFStatus == 0){
                nameCheckString = [[inputDataSet stringValue] UTF8String];
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                int checkResults = [controllerSubProcesses nameCheck];
                
                if (checkResults == 0){
                    if (nameCheckString.length() < 4 || nameCheckString.length() > 15) checkResults = 1;
                }
                
                if (checkResults == 0){
                    batchBodyName = nameCheckString;
                    [inputDataSet setStringValue:@""];
                    
                    [batchAnalysisName1 setStringValue:@(batchBodyName.c_str())];
                    [batchSaveName1 setStringValue:@(batchBackUpNameHold.c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    [inputDataSet setStringValue:@""];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"IF Mode On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                [inputDataSet setStringValue:@""];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Stop Auto/Batch Processing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            [inputDataSet setStringValue:@""];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Batch Backup Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        [inputDataSet setStringValue:@""];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)batchSeriesNameSet:(id)sender{
    if (autoBatchMode == 2){
        if (autoRunOnOff == 0 && batchBackupOnOff == 0 && batchImageOnOff == 0 && initialRunStatus == "nil"){
            if (processingIFStatus == 0){
                nameCheckString = [[inputDataSet stringValue] UTF8String];
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                int checkResults = [controllerSubProcesses nameCheck];
                
                if (checkResults == 0){
                    if (nameCheckString.length() < 4 || nameCheckString.length() > 15) checkResults = 1;
                }
                
                if (checkResults == 0){
                    string entry;
                    
                    DIR *dir;
                    struct dirent *dent;
                    
                    dir = opendir(productsFilesPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if ((int)entry.find(nameCheckString+"_") != -1){
                                    checkResults = 2;
                                    break;
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    dir = opendir(cellTrackingImageFolderPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if ((int)entry.find(nameCheckString+"_") != -1){
                                    checkResults = 2;
                                    break;
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    dir = opendir(cellTrackingDataPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if ((int)entry.find(nameCheckString+"_") != -1){
                                    checkResults = 2;
                                    break;
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    dir = opendir(cellTrackingAnalysisPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if ((int)entry.find(nameCheckString+"_") != -1){
                                    checkResults = 2;
                                    break;
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                }
                
                if (checkResults == 0){
                    batchBackUpNameHold = nameCheckString;
                    [inputDataSet setStringValue:@""];
                    [batchSaveName1 setStringValue:@(batchBackUpNameHold.c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (checkResults == 1){
                    [inputDataSet setStringValue:@""];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Duplicate name Found"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    [inputDataSet setStringValue:@""];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"IF Mode On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                [inputDataSet setStringValue:@""];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Stop Auto/Batch Processing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            [inputDataSet setStringValue:@""];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Batch Backup Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        [inputDataSet setStringValue:@""];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)batchSet:(id)sender{
    if (autoBatchMode == 2){
        if (batchBackUpNameHold != "nil"){
            if (autoRunOnOff == 0 && batchBackupOnOff == 0 && batchImageOnOff == 0){
                if (processingIFStatus == 0){
                    NSOpenPanel *openDlg = [NSOpenPanel openPanel];
                    [openDlg setCanChooseFiles:NO];
                    [openDlg setCanChooseDirectories:YES];
                    [openDlg setCanCreateDirectories:YES];
                    
                    if ([openDlg runModal] == NSModalResponseOK){
                        NSArray *files = [openDlg URLs];
                        NSString *fileName = [[files objectAtIndex:0] absoluteString];
                        
                        string directoryPathExtract = [fileName UTF8String];
                        
                        int findString1 = (int)directoryPathExtract.find("/Users/");
                        if (findString1 == -1) findString1 = (int)directoryPathExtract.find("/Volumes/");
                        
                        unsigned long directoryLength = directoryPathExtract.length();
                        string extractedID = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
                        string extractedID2;
                        
                        int terminationFlag = 0;
                        
                        do{
                            
                            terminationFlag = 1;
                            
                            if ((int)extractedID.find("%20") != -1){
                                extractedID2 = extractedID.substr(0, extractedID.find("%20"));
                                extractedID = extractedID.substr(extractedID.find("%20")+3);
                                extractedID = extractedID2+" "+extractedID;
                            }
                            else terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                        
                        int matchFlag = 0;
                        
                        for (int counter1 = 0; counter1 < batchPathNameCount; counter1++){
                            if (arrayBatchPathName [counter1] == extractedID){
                                matchFlag = 1;
                                break;
                            }
                        }
                        
                        if (matchFlag == 0){
                            if (batchPathNameCount+1 < 101){
                                int matchFlag2 = 0;
                                string entry;
                                string stringExtract;
                                
                                DIR *dir;
                                struct dirent *dent;
                                
                                dir = opendir(extractedID.c_str());
                                
                                if (dir != NULL){
                                    while ((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        
                                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                            findString1 = (int)entry.find(batchBodyName+"-1");
                                            
                                            if (findString1 == -1){
                                                matchFlag = 1;
                                                break;
                                            }
                                            
                                            if (findString1 != -1){
                                                stringExtract = entry.substr(entry.find("-1")+1);
                                                
                                                if (stringExtract.length () == 5 && atoi(stringExtract.c_str()) > 10000) matchFlag2 = 1;
                                            }
                                        }
                                    }
                                    
                                    closedir(dir);
                                }
                                
                                if (matchFlag == 0 && matchFlag2 == 1){
                                    if (batchPathNameCount == 0){
                                        arrayBatchPathName [batchPathNameCount] = "BL", batchPathNameCount++;
                                        arrayBatchPathName [batchPathNameCount] = batchBodyName, batchPathNameCount++;
                                        arrayBatchPathName [batchPathNameCount] = batchBackUpNameHold, batchPathNameCount++;
                                    }
                                    
                                    arrayBatchPathName [batchPathNameCount] = extractedID, batchPathNameCount++;
                                    
                                    [batchSetStatus1 setIntegerValue:batchPathNameCount-3];
                                    
                                    ofstream oin;
                                    oin.open(batchProcessBackUpPath.c_str(), ios::out);
                                    
                                    for (int counter1 = 1; counter1 < batchPathNameCount; counter1++) oin<<arrayBatchPathName [counter1]<<endl;
                                    
                                    oin.close();
                                    
                                    tableViewPage = 2;
                                    tableViewCall = 1;
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                }
                                else{
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"No Matching Analysis Name Found: Check Folder Content"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                }
                            }
                            else{
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"Exceed Entry Limit (100)"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                            }
                        }
                        else{
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Stop Auto/Batch Processing"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"IF Mode On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Batch Backup Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)batchStart:(id)sender{
    if (initialRunStatus == "8"){
        if (autoBatchMode == 2 && batchPathNameCount > 0){
            if (batchBackupOperationCommit == "nil"){
                batchBackupOperationCommit = "1";
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                [controllerSubProcesses parameterSave];
                
                [batchStartStatus1 setStringValue:@"Hold"];
                
                if (processingIFStatus == 0) [runStatusDisplay setStringValue:@"Proc."];
            }
            
            if (batchBackupOnOff == 0){
                if (runStatusFocalImage == 0 && runStatusContrast == 0){
                    string *batchProcessInfoTemp = new string [batchProcessInfoCount+50];
                    int batchProcessInfoTempCount = 0;
                    
                    //for (int counterA = 0; counterA < batchProcessInfoCount/3; counterA++){
                    //    cout<<batchProcessInfo [counterA*3]<<" "<<batchProcessInfo [counterA*3+1]<<" "<<batchProcessInfo [counterA*3+2]<<"  Batchinfo"<<endl;
                    //}
                    
                    for (int counter1 = 0; counter1 < batchProcessInfoCount/3; counter1++){
                        if (batchProcessInfo [counter1*3+2] == "1"){
                            batchProcessInfoTemp [batchProcessInfoTempCount] = batchProcessInfo [counter1*3], batchProcessInfoTempCount++;
                            batchProcessInfoTemp [batchProcessInfoTempCount] = batchProcessInfo [counter1*3+1], batchProcessInfoTempCount++;
                            batchProcessInfoTemp [batchProcessInfoTempCount] = batchProcessInfo [counter1*3+2], batchProcessInfoTempCount++;
                        }
                    }
                    
                    string pathName;
                    string entry;
                    string folderNumberCheck;
                    string checkPath;
                    string entry2;
                    string processingIFCountString;
                    
                    processingIFCountString = to_string(processingIFCount);
                    
                    if (processingIFCountString.length() == 1) processingIFCountString = "0"+processingIFCountString;
                    
                    DIR *dir;
                    struct dirent *dent;
                    DIR *dir2;
                    struct dirent *dent2;
                    
                    batchProcessInfoCount = 0;
                    int largestFolderNo = 0;
                    
                    for (int counter1 = 0; counter1 < batchPathNameCount; counter1++){
                        pathName = arrayBatchPathName [counter1];
                        
                        if ((int)pathName.find("BackupDummy") != -1){
                            dir = opendir(pathName.c_str());
                            
                            if (dir != NULL){
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                        if (processingIFStatus == 0){
                                            if ((int)entry.find(batchBodyName+"-") != -1){
                                                if (batchProcessInfoCount+10 > batchProcessInfoLimit) [self batchInfoUpDate];
                                                
                                                batchProcessInfo [batchProcessInfoCount] = pathName, batchProcessInfoCount++;
                                                batchProcessInfo [batchProcessInfoCount] = entry, batchProcessInfoCount++;
                                                batchProcessInfo [batchProcessInfoCount] = "nil2", batchProcessInfoCount++;
                                                
                                                folderNumberCheck = entry.substr(entry.find("-1")+2);
                                                
                                                if (largestFolderNo < atoi(folderNumberCheck.c_str())) largestFolderNo = atoi(folderNumberCheck.c_str());
                                            }
                                        }
                                    }
                                }
                                
                                closedir(dir);
                            }
                        }
                        else{
                            
                            dir = opendir(pathName.c_str());
                            
                            if (dir != NULL){
                                int targetIFFind = 0;
                                
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                        if (processingIFStatus == 0){
                                            if ((int)entry.find(batchBodyName+"-") != -1){
                                                if (batchProcessInfoCount+10 > batchProcessInfoLimit) [self batchInfoUpDate];
                                                
                                                batchProcessInfo [batchProcessInfoCount] = pathName, batchProcessInfoCount++;
                                                batchProcessInfo [batchProcessInfoCount] = entry, batchProcessInfoCount++;
                                                batchProcessInfo [batchProcessInfoCount] = "nil", batchProcessInfoCount++;
                                                
                                                folderNumberCheck = entry.substr(entry.find("-1")+2);
                                                
                                                if (largestFolderNo < atoi(folderNumberCheck.c_str())) largestFolderNo = atoi(folderNumberCheck.c_str());
                                            }
                                        }
                                        else{
                                            
                                            if ((int)entry.find(batchBodyName+"-") != -1){
                                                checkPath = pathName+"/"+entry;
                                                
                                                targetIFFind = 0;
                                                
                                                dir2 = opendir(checkPath.c_str());
                                                
                                                if (dir2 != NULL){
                                                    while ((dent2 = readdir(dir2))){
                                                        entry2 = dent2 -> d_name;
                                                        
                                                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                                            if ((int)entry2.find(".TIF"+processingIFCountString) != -1) targetIFFind = 1;
                                                        }
                                                    }
                                                    
                                                    closedir(dir2);
                                                }
                                                
                                                if (targetIFFind == 1){
                                                    if (batchProcessInfoCount+10 > batchProcessInfoLimit) [self batchInfoUpDate];
                                                    
                                                    batchProcessInfo [batchProcessInfoCount] = pathName, batchProcessInfoCount++;
                                                    batchProcessInfo [batchProcessInfoCount] = entry, batchProcessInfoCount++;
                                                    batchProcessInfo [batchProcessInfoCount] = "nil", batchProcessInfoCount++;
                                                    
                                                    folderNumberCheck = entry.substr(entry.find("-1")+2);
                                                    
                                                    if (largestFolderNo < atoi(folderNumberCheck.c_str())) largestFolderNo = atoi(folderNumberCheck.c_str());
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                closedir(dir);
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < batchProcessInfoCount/3; counterA++){
                    //    cout<<batchProcessInfo [counterA*3]<<" "<<batchProcessInfo [counterA*3+1]<<" "<<batchProcessInfo [counterA*3+2]<<"  Batch2"<<endl;
                    //}
                    
                    string statusName;
                    string statusTemp;
                    
                    for (int counter1 = 0; counter1 < batchProcessInfoTempCount/3; counter1++){
                        statusName = batchProcessInfoTemp [counter1*3+1];
                        statusTemp = batchProcessInfoTemp [counter1*3+2];
                        
                        for (int counter2 = 0; counter2 < batchProcessInfoCount/3; counter2++){
                            if (batchProcessInfo [counter2*3+1] == statusName && statusTemp == "1"){
                                batchProcessInfo [counter2*3+2] = "1";
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < batchProcessInfoCount/3; counterA++){
                    //    cout<<batchProcessInfo [counterA*3]<<" "<<batchProcessInfo [counterA*3+1]<<" "<<batchProcessInfo [counterA*3+2]<<"  Batch3"<<endl;
                    //}
                    
                    for (int counter1 = 0; counter1 < batchProcessInfoCount/3; counter1++){
                        if (batchProcessInfo [counter1*3+2] == "nil2"){
                            for (int counter2 = 0; counter2 < batchProcessInfoCount/3; counter2++){
                                if (batchProcessInfo [counter2*3+1] == batchProcessInfo [counter1*3+2] && batchProcessInfo [counter2*3+1] != "nil2"){
                                    batchProcessInfo [counter2*3+2] = "1";
                                    break;
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < batchProcessInfoCount/3; counterA++){
                    //    cout<<batchProcessInfo [counterA*3]<<" "<<batchProcessInfo [counterA*3+1]<<" "<<batchProcessInfo [counterA*3+2]<<"  Batch3"<<endl;
                    //}
                    
                    string focalSettingPathBatch = productsFilesInfoPath+"/"+"FI-BasicSetting";
                    string getString;
                    
                    ifstream fin;
                    
                    fin.open(focalSettingPathBatch.c_str(),ios::in);
                    
                    int copySetStatus = 0;
                    
                    if (fin.is_open()){
                        getline(fin, getString); //----Time point----
                        getline(fin, getString); //----Import end point----
                        getline(fin, getString); //----DIC range hold----
                        getline(fin, getString);
                        getline(fin, getString), copySetStatus = atoi(getString.c_str());
                        getline(fin, getString);
                        
                        fin.close();
                    }
                    
                    if (copySetStatus == 0){
                        for (int counter1 = 0; counter1 < batchProcessInfoCount/3; counter1++){
                            if (batchProcessInfo [counter1*3+2] == "nil2"){
                                batchProcessInfo [counter1*3+2] = "1";
                            }
                        }
                    }
                    else{
                        
                        for (int counter1 = 0; counter1 < batchProcessInfoCount/3; counter1++){
                            if (batchProcessInfo [counter1*3+2] == "nil2"){
                                batchProcessInfo [counter1*3+2] = "nil";
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < batchProcessInfoCount/3; counterA++){
                    //    cout<<batchProcessInfo [counterA*3]<<" "<<batchProcessInfo [counterA*3+1]<<" "<<batchProcessInfo [counterA*3+2]<<"  Batch4"<<endl;
                    //}
                    
                    delete [] batchProcessInfoTemp;
                    
                    string *batchProcessInfoTemp2 = new string [batchProcessInfoCount+50];
                    int batchProcessInfoTempCount2 = 0;
                    
                    int batchSeqCount = 1;
                    
                    for (int counter1 = 1; counter1 <= largestFolderNo; counter1++){
                        for (int counter2 = 0; counter2 < batchProcessInfoCount/3; counter2++){
                            folderNumberCheck = batchProcessInfo [counter2*3+1];
                            folderNumberCheck = folderNumberCheck.substr(folderNumberCheck.find("-1")+2);
                            
                            if (atoi(folderNumberCheck.c_str()) == batchSeqCount){
                                batchProcessInfoTemp2 [batchProcessInfoTempCount2] = batchProcessInfo [counter2*3], batchProcessInfoTempCount2++;
                                batchProcessInfoTemp2 [batchProcessInfoTempCount2] = batchProcessInfo [counter2*3+1], batchProcessInfoTempCount2++;
                                batchProcessInfoTemp2 [batchProcessInfoTempCount2] = batchProcessInfo [counter2*3+2], batchProcessInfoTempCount2++;
                                break;
                            }
                        }
                        
                        batchSeqCount++;
                    }
                    
                    //for (int counterA = 0; counterA < batchProcessInfoTempCount2/3; counterA++){
                    //    cout<<batchProcessInfoTemp2 [counterA*3]<<" "<<batchProcessInfoTemp2 [counterA*3+1]<<" "<<batchProcessInfoTemp2 [counterA*3+2]<<"  Batch"<<endl;
                    //}
                    
                    batchProcessInfoCount = 0;
                    
                    for (int counter1 = 0; counter1 < batchProcessInfoTempCount2; counter1++) batchProcessInfo [batchProcessInfoCount] = batchProcessInfoTemp2 [counter1], batchProcessInfoCount++;
                    
                    ofstream oin;
                    oin.open(batchProcessFolderPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < batchProcessInfoCount; counter1++)  oin<<batchProcessInfo [counter1]<<endl;
                    
                    oin.close();
                    
                    delete [] batchProcessInfoTemp2;
                    
                    //for (int counterA = 0; counterA < batchProcessInfoCount/3; counterA++){
                    //    cout<<batchProcessInfo [counterA*3]<<" "<<batchProcessInfo [counterA*3+1]<<" "<<batchProcessInfo [counterA*3+2]<<"  Batch"<<endl;
                    //}
                    
                    remove (instructionFIPath.c_str());
                    remove (instructionFIPath2.c_str());
                    remove (instructionAPPath.c_str());
                    remove (instructionCSPath.c_str());
                    remove (instructionNamePath.c_str());
                    
                    batchBackupOnOff = 1;
                    [batchStartStatus1 setStringValue:@"On"];
                    
                    runStatusFocalImage = 1;
                    runStatusContrast = 1;
                    autoStepCount = 0;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBatchBackUp object:self];
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCommFocal object:self];
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCommContrast object:self];
                    
                    string launchProgramFocal = launchProgramPath+"/"+"Focal_Image_Selection.app";
                    string launchProgramContrast = launchProgramPath+"/"+"Contrast_Set.app";
                    
                    NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
                    [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramFocal.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
                    [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramContrast.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
                    
                    launchCheck = 1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Batch BackUp On"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else if (batchBackupOnOff == 1){
                autoTimerInvalidate = 1;
                [batchStartStatus1 setStringValue:@"Wait"];
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Perform Initial Run"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)batchImageRedo:(id)sender{
    if (autoBatchMode == 2){
        if (batchBackupOperationCommit != "nil"){
            if (batchBackUpNameHold != "nil"){
                if (batchBackupOnOff == 0){
                    if (processingIFStatus == 0){
                        if (runStatusFocalImage == 0){
                            int inputDataSetCount = (int)[inputDataSet integerValue];
                            [inputDataSet setStringValue:@""];
                            
                            if (inputDataSetCount > 0){
                                NSAlert *alert = [[NSAlert alloc] init];
                                
                                [alert addButtonWithTitle:@"OK"];
                                [alert addButtonWithTitle:@"Cancel"];
                                [alert setMessageText:@"Delete Data And Re-do Processing?"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                
                                if ([alert runModal] == NSAlertFirstButtonReturn){
                                    [backSave startAnimation:self];
                                    
                                    string stringExtract;
                                    int redoFlag = 0;
                                    
                                    if (inputDataSetCount < batchProcessInfoCount/3){
                                        if (batchProcessInfo [(inputDataSetCount-1)*3+2] == "1") redoFlag = 1;
                                    }
                                    
                                    //for (int counterA = 0; counterA < batchProcessInfoCount/3; counterA++){
                                    //    cout<<batchProcessInfo [counterA*3]<<" "<<batchProcessInfo [counterA*3+1]<<" "<<batchProcessInfo [counterA*3+2]<<" Batch"<<endl;
                                    //}
                                    
                                    if (redoFlag == 1){
                                        for (int counter1 = 0; counter1 < batchProcessInfoCount/3; counter1++){
                                            if (counter1 >= inputDataSetCount-1 && batchProcessInfo [counter1*3+2] == "1"){
                                                batchProcessInfo [counter1*3+2] = "nil";
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < batchProcessInfoCount/3; counterA++){
                                        //    cout<<batchProcessInfo [counterA*3]<<" "<<batchProcessInfo [counterA*3+1]<<" "<<batchProcessInfo [counterA*3+2]<<" Batch"<<endl;
                                        //}
                                        
                                        string focalModify = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+batchBackUpNameHold+"_Products"+"/"+"Analysis_Information"+"/"+"FI-BasicSetting";
                                        
                                        int currentPoint = 0;
                                        int importTableEnd = 0;
                                        int dicRangeSet = 0;
                                        int firstImageExclude = 0;
                                        int copySetStatus = 0;
                                        string copyDirectoryInfo;
                                        string getString;
                                        
                                        ifstream fin;
                                        fin.open(focalModify.c_str(),ios::in);
                                        
                                        if (fin.is_open()){
                                            getline(fin, getString), currentPoint = atoi(getString.c_str());
                                            getline(fin, getString), importTableEnd = atoi(getString.c_str());
                                            getline(fin, getString), dicRangeSet = atoi(getString.c_str());
                                            getline(fin, getString), firstImageExclude = atoi(getString.c_str());
                                            getline(fin, getString), copySetStatus = atoi(getString.c_str());
                                            getline(fin, getString), copyDirectoryInfo = getString.c_str();
                                            
                                            fin.close();
                                        }
                                        
                                        ofstream oin;
                                        oin.open(focalModify.c_str(),ios::out);
                                        
                                        oin<<inputDataSetCount<<endl;
                                        oin<<importTableEnd<<endl;
                                        oin<<dicRangeSet<<endl;
                                        oin<<firstImageExclude<<endl;
                                        oin<<copySetStatus<<endl;
                                        oin<<copyDirectoryInfo<<endl;
                                        
                                        oin.close();
                                        
                                        int fluorescentCountFocal = 0;
                                        
                                        if (fluorescentColor1 != 0) fluorescentCountFocal++;
                                        if (fluorescentColor2 != 0) fluorescentCountFocal++;
                                        if (fluorescentColor3 != 0) fluorescentCountFocal++;
                                        if (fluorescentColor4 != 0) fluorescentCountFocal++;
                                        if (fluorescentColor5 != 0) fluorescentCountFocal++;
                                        if (fluorescentColor6 != 0) fluorescentCountFocal++;
                                        
                                        int totalFOVNoHoldFocal = atoi(totalFOVNoHold.c_str());
                                        
                                        string focalPlaneModify = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+batchBackUpNameHold+"_Products"+"/"+"Analysis_Information"+"/"+"FI-FocalPlaneData";
                                        
                                        int **arrayFocalPlaineData = new int *[totalFOVNoHoldFocal+totalFOVNoHoldFocal*fluorescentCountFocal+100];
                                        
                                        for (int counter1 = 0; counter1 < totalFOVNoHoldFocal+totalFOVNoHoldFocal*fluorescentCountFocal+100; counter1++) arrayFocalPlaineData [counter1] = new int [currentPoint+500];
                                        
                                        if (importTableEnd == -1){
                                            int lineCount = 0;
                                            
                                            fin.open(focalPlaneModify.c_str(),ios::in);
                                            
                                            if (fin.is_open()){
                                                do{
                                                    
                                                    getline(fin, getString);
                                                    
                                                    if (getString != ""){
                                                        arrayFocalPlaineData [lineCount][0] = 0;
                                                        
                                                        getline(fin, getString);
                                                        arrayFocalPlaineData [lineCount][1] = 0;
                                                        
                                                        if (lineCount == 0){
                                                            for (int counter1 = 1; counter1 <= currentPoint; counter1++){
                                                                getline(fin, getString), arrayFocalPlaineData [lineCount][counter1+1] = 0;
                                                            }
                                                        }
                                                        else{
                                                            
                                                            for (int counter1 = 1; counter1 < currentPoint; counter1++){
                                                                getline(fin, getString), arrayFocalPlaineData [lineCount][counter1+1] = atoi(getString.c_str());
                                                            }
                                                            
                                                            getline(fin, getString);
                                                            arrayFocalPlaineData [lineCount][currentPoint+1] = atoi(getString.c_str());
                                                        }
                                                        
                                                        lineCount++;
                                                    }
                                                    
                                                } while (getString != "");
                                                
                                                fin.close();
                                            }
                                            
                                            string treatmentModify = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+batchBackUpNameHold+"_Products"+"/"+"Analysis_Information"+"/"+"FI-TreatmentNameData";
                                            
                                            int treatmentCount = 0;
                                            
                                            fin.open(treatmentModify.c_str(),ios::in);
                                            
                                            if (fin.is_open()){
                                                do{
                                                    
                                                    getline(fin, getString);
                                                    
                                                    if (getString != "") treatmentCount++;
                                                    
                                                } while (getString != "");
                                                
                                                fin.close();
                                            }
                                            
                                            oin.open(focalPlaneModify.c_str(), ios::out);
                                            
                                            for (int counter1 = 0; counter1 < treatmentCount; counter1++){
                                                for (int counter2 = 0; counter2 < inputDataSetCount+2; counter2++){
                                                    oin<<arrayFocalPlaineData [counter1][counter2]<<endl;
                                                }
                                            }
                                            
                                            oin.close();
                                        }
                                        
                                        for (int counter1 = 0; counter1 < totalFOVNoHoldFocal+totalFOVNoHoldFocal*fluorescentCountFocal+100; counter1++) delete [] arrayFocalPlaineData [counter1];
                                        
                                        delete [] arrayFocalPlaineData;
                                        
                                        string sourceModify = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+batchBackUpNameHold+"_Products"+"/"+"Source_Images";
                                        string entry;
                                        string entry2;
                                        string entry3;
                                        string productFolderPath2;
                                        string productFolderPath3;
                                        string productFolderPath4;
                                        string extractString;
                                        
                                        DIR *dir;
                                        struct dirent *dent;
                                        DIR *dir2;
                                        struct dirent *dent2;
                                        DIR *dir3;
                                        struct dirent *dent3;
                                        
                                        dir = opendir(sourceModify.c_str());
                                        fileDeleteCount = 0;
                                        
                                        if (dir != NULL){
                                            while ((dent = readdir(dir))){
                                                entry = dent -> d_name;
                                                productFolderPath2 = sourceModify+"/"+entry;
                                                
                                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                                    dir2 = opendir(productFolderPath2.c_str());
                                                    
                                                    if (dir2 != NULL){
                                                        while ((dent2 = readdir(dir2))){
                                                            entry2 = dent2 -> d_name;
                                                            productFolderPath3 = productFolderPath2+"/"+entry2;
                                                            
                                                            if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                                                dir3 = opendir(productFolderPath3.c_str());
                                                                
                                                                if (dir3 != NULL){
                                                                    while ((dent3 = readdir(dir3))){
                                                                        entry3 = dent3 -> d_name;
                                                                        
                                                                        if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store"){
                                                                            if ((int)entry3.find("FOV") != -1){
                                                                                extractString = entry3.substr(entry3.find("_")+1, 4);
                                                                                
                                                                                if (atoi(extractString.c_str()) >= inputDataSetCount){
                                                                                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                                                                    arrayFileDelete [fileDeleteCount] = productFolderPath3+"/"+entry3, fileDeleteCount++;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                    
                                                                    closedir(dir3);
                                                                }
                                                            }
                                                        }
                                                        
                                                        closedir(dir2);
                                                    }
                                                }
                                            }
                                            
                                            closedir(dir);
                                            
                                            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                                remove (arrayFileDelete [counter1].c_str());
                                            }
                                        }
                                        
                                        string stitchedFolderBatchPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images"+"/"+batchBackUpNameHold+"_Image";
                                        string productFolderPath1;
                                        string fileNoST;
                                        
                                        dir = opendir(stitchedFolderBatchPath.c_str());
                                        fileDeleteCount = 0;
                                        
                                        if (dir != NULL){
                                            while ((dent = readdir(dir))){
                                                entry = dent -> d_name;
                                                
                                                if ((int)entry.find("_Stitch") != -1){
                                                    productFolderPath1 = stitchedFolderBatchPath+"/"+entry;
                                                    
                                                    dir2 = opendir(productFolderPath1.c_str());
                                                    
                                                    if (dir2 != NULL){
                                                        while ((dent2 = readdir(dir2))){
                                                            entry2 = dent2 -> d_name;
                                                            
                                                            if ((int)entry2.find("STimage ") != -1){
                                                                fileNoST = entry2.substr(entry2.find("STimage ")+8, 4);
                                                                
                                                                if (atoi(fileNoST.c_str()) >= inputDataSetCount){
                                                                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                                                    arrayFileDelete [fileDeleteCount] = productFolderPath1+"/"+entry2, fileDeleteCount++;
                                                                }
                                                            }
                                                        }
                                                        
                                                        closedir(dir2);
                                                    }
                                                }
                                            }
                                            
                                            closedir(dir);
                                            
                                            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                                remove (arrayFileDelete [counter1].c_str());
                                            }
                                        }
                                        
                                        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                                        [controllerSubProcesses parameterSave];
                                        
                                        oin.open(batchProcessFolderPath.c_str(), ios::out);
                                        
                                        for (int counter1 = 0; counter1 < batchProcessInfoCount; counter1++)  oin<<batchProcessInfo [counter1]<<endl;
                                        
                                        oin.close();
                                        
                                        [batchRedoNo1 setIntegerValue:inputDataSetCount];
                                        
                                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                                        [sound play];
                                    }
                                    else{
                                        
                                        NSAlert *alert2 = [[NSAlert alloc] init];
                                        [alert2 addButtonWithTitle:@"OK"];
                                        [alert2 setMessageText:@"Set Point: Out of Range"];
                                        [alert2 setAlertStyle:NSAlertStyleWarning];
                                        [alert2 runModal];
                                        
                                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                                        [sound play];
                                    }
                                    
                                    [backSave stopAnimation:self];
                                }
                            }
                            else{
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"Set Point: Out Of Range: Out of range"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                        else{
                            
                            [inputDataSet setStringValue:@""];
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Stop Focal Image Sel."];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Redo dose not allow in the IF mode"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    [inputDataSet setStringValue:@""];
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Hold Batch Processing"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                [inputDataSet setStringValue:@""];
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Set A Series Name"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            [inputDataSet setStringValue:@""];
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Batch (Back-Up) Has Not Been Started"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        [inputDataSet setStringValue:@""];
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Batch (Back-Up) Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)batchInfoUpDate{
    string *arrayUpDate = new string [batchProcessInfoCount+10];
    
    for (int counter1 = 0; counter1 < batchProcessInfoCount; counter1++) arrayUpDate [counter1] = batchProcessInfo [counter1];
    
    delete [] batchProcessInfo;
    batchProcessInfo = new string [batchProcessInfoLimit+500];
    batchProcessInfoLimit = batchProcessInfoLimit+500;
    
    for (int counter1 = 0; counter1 < batchProcessInfoCount; counter1++) batchProcessInfo [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

@end
