//
//  DataSaveLoad.h
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2014-05-22.
//  Copyright Masahiko Sato 2014 All rights reserved.
//
//

#ifndef DATASAVELOAD_H
#define DATASAVELOAD_H
#import "Controller.h"
#endif

@interface DataSaveLoad : NSObject <NSTableViewDataSource> {
    int saveLoadType; //SaveLoad Type
    int timerFirst; //Timer set
    int processEndFlag; //Process end
    
    IBOutlet NSWindow *saveLoadWindow;
    IBOutlet NSTableView *saveLoadList;
    IBOutlet NSTextField *saveTypeDisplay;
    IBOutlet NSTextField *separateNameDisplay;
    
    IBOutlet NSProgressIndicator *backSave2;
    
    NSTimer *saveLoadTimer;
    NSTimer *saveLoadTimer2;
    
    NSWindowController *saveLoadWindController;
    
    id controllerSubProcesses;
}

-(id)init;
-(void)dealloc;
-(void)dataSaveUpDate;
-(void)fileDeleteUpDate;
-(void)save1;
-(void)load1;
-(void)separateIf1;
-(void)processMonitor;

-(IBAction)productSave:(id)sender;
-(IBAction)productLoad:(id)sender;
-(IBAction)deleteFolder:(id)sender;
-(IBAction)typeSwitch:(id)sender;
-(IBAction)closeWindow:(id)sender;
-(IBAction)backUpClean:(id)sender;
-(IBAction)setList:(id)sender;
-(IBAction)tableReload:(id)sender;
-(IBAction)selectBKFolderForSeparate:(id)sender;
-(IBAction)selectBKDestination:(id)sender;
-(IBAction)selectImageFolderForMerge:(id)sender;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

@end
