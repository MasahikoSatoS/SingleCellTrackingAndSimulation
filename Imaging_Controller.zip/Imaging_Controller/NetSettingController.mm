//
//  NetSettingController.m
//  Imaging_Controller
//
//  Created by Masahiko Sato on 1/24/17.
//
//

#import "NetSettingController.h"

NSString *notificationToNetCheckController = @"notificationExecuteNetCheckController";

@implementation NetSettingController

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToNetCheckController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    netCheckWindowController = [[NSWindowController alloc] initWithWindowNibName:@"NetCheckSet"];
    [netCheckWindowController showWindow:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [netCheckWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [netCheckWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [addressDisplay setStringValue:@(netAddressHold.c_str())];
    [usernameDisplay setStringValue:@(netUsernameHold.c_str())];
    
    string passwordSetTemp2 = "";
    
    for (int counter1 = 0; counter1 < (int)netPasswordHold.length(); counter1++){
        passwordSetTemp2 = passwordSetTemp2+"*";
    }
    
    [passwordDisplay setStringValue:@(passwordSetTemp2.c_str())];
}

-(IBAction)addressSet:(id)sender{
    if (initialRunStatus == "nil" && autoBatchMode == 1 && runStatusXYMap == 0){
        string addressNameSetTemp = [[addressInput stringValue] UTF8String];
        
        if (addressNameSetTemp.length() >= 4 && addressNameSetTemp.length() <= 50){
            netAddressHold = addressNameSetTemp;
            
            string netInformationPath = cellTrackingSystemDataPath+"/NetData";
            string getString;
            
            ifstream fin;
            ofstream oin;
            
            fin.open(netInformationPath.c_str(),ios::in);
            
            if (fin.is_open()){
                getline(fin, getString);
                getline(fin, getString), netUsernameHold = getString;
                getline(fin, getString), netPasswordHold = getString;
                
                fin.close();
                
                oin.open(netInformationPath.c_str(), ios::out);
                
                oin<<netAddressHold<<endl;
                oin<<netUsernameHold<<endl;
                oin<<netPasswordHold<<endl;
                oin.close();
            }
            else{
                
                oin.open(netInformationPath.c_str(), ios::out);
                
                oin<<netAddressHold<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin.close();
            }
            
            [addressInput setStringValue:@""];
            [addressDisplay setStringValue:@(netAddressHold.c_str())];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            [addressInput setStringValue:@""];
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Length: 4-50 Characters"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        [addressInput setStringValue:@""];
        
        if (initialRunStatus != "nil"){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Stop Initial Setting And Do Refresh"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (autoBatchMode != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Set Auto Processing And Refresh"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (runStatusXYMap != 0){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Quit Map"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)usernameSet:(id)sender{
    if (initialRunStatus == "nil" && autoBatchMode == 1 && runStatusXYMap == 0){
        string netUsernameSetTemp = [[usernameInput stringValue] UTF8String];
        
        if (netUsernameSetTemp.length() >= 4 && netUsernameSetTemp.length() <= 50){
            netUsernameHold = netUsernameSetTemp;
            
            string netInformationPath = cellTrackingSystemDataPath+"/NetData";
            string getString;
            
            ifstream fin;
            ofstream oin;
            
            fin.open(netInformationPath.c_str(),ios::in);
            
            if (fin.is_open()){
                getline(fin, getString), netAddressHold = getString;
                getline(fin, getString);
                getline(fin, getString), netPasswordHold = getString;
                
                fin.close();
                
                oin.open(netInformationPath.c_str(), ios::out);
                
                oin<<netAddressHold<<endl;
                oin<<netUsernameHold<<endl;
                oin<<netPasswordHold<<endl;
                oin.close();
            }
            else{
                
                oin.open(netInformationPath.c_str(), ios::out);
                
                oin<<"nil"<<endl;
                oin<<netUsernameHold<<endl;
                oin<<"nil"<<endl;
                oin.close();
            }
            
            [usernameInput setStringValue:@""];
            [usernameDisplay setStringValue:@(netUsernameHold.c_str())];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            [usernameInput setStringValue:@""];
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Length: 4-50 Characters"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        [usernameInput setStringValue:@""];
        
        if (initialRunStatus != "nil"){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Stop Initial Setting And Do Refresh"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (autoBatchMode != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Set Auto Processing And Refresh"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (runStatusXYMap != 0){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Quit Map"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)passwordSet:(id)sender{
    if (initialRunStatus == "nil" && autoBatchMode == 1 && runStatusXYMap == 0){
        string passwordSetTemp = [[passwordInput stringValue] UTF8String];
        
        if (passwordSetTemp.length() >= 4 && passwordSetTemp.length() <= 50){
            netPasswordHold = passwordSetTemp;
            
            string netInformationPath = cellTrackingSystemDataPath+"/NetData";
            string getString;
            
            ifstream fin;
            ofstream oin;
            
            fin.open(netInformationPath.c_str(),ios::in);
            
            if (fin.is_open()){
                getline(fin, getString), netAddressHold = getString;
                getline(fin, getString), netUsernameHold = getString;
                getline(fin, getString);
                
                fin.close();
                
                oin.open(netInformationPath.c_str(), ios::out);
                
                oin<<netAddressHold<<endl;
                oin<<netUsernameHold<<endl;
                oin<<netPasswordHold<<endl;
                oin.close();
            }
            else{
                
                oin.open(netInformationPath.c_str(), ios::out);
                
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<netPasswordHold<<endl;
                oin.close();
            }
            
            string passwordSetTemp2 = "";
            
            for (int counter1 = 0; counter1 < (int)passwordSetTemp.length(); counter1++){
                passwordSetTemp2 = passwordSetTemp2+"*";
            }
            
            [passwordInput setStringValue:@""];
            [passwordDisplay setStringValue:@(passwordSetTemp2.c_str())];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            [passwordInput setStringValue:@""];
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Length: 4-50 Characters"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        [passwordInput setStringValue:@""];
        
        if (initialRunStatus != "nil"){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Stop Initial Setting And Do Refresh"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (autoBatchMode != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Set Auto Processing And Refresh"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (runStatusXYMap != 0){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Quit Map"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(void)reDisplayWindow{
    if (netCheckWindowOperation == 3){
        [netCheckWindow makeKeyAndOrderFront:self];
        netCheckWindowOperation = 1;
        [netCheckTimer invalidate];
    }
}

-(IBAction)closeWindow:(id)sender{
    [netCheckWindow orderOut:self];
    netCheckWindowOperation = 2;
    netCheckTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToNetCheckController object:nil];
}

@end
