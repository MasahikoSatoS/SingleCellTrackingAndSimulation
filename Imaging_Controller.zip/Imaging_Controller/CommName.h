//
//  CommName.h
//  Imaging_Controller
//
//  Created by Masahiko Sato on 3/9/2014.
//  Copyright Masahiko Sato 2014 All rights reserved.
//
//

#ifndef COMMNAME_H
#define COMMNAME_H
#import "Controller.h"
#endif

@interface CommName : NSObject {
    int nameAssignProgress1; //Name progress
    int nameAssignProgress2; //Name progress
    int nameATempCount; //Name A temp count
    
    NSTimer *commNameTimer;
    
    id controllerSubProcesses;
}

-(id)init;
-(void)dealloc;
-(void)nameAssign;
-(void)processControl;
-(void)consoleTreatNameUpDate;

@end
