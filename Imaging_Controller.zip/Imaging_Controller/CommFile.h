//
//  CommFile.h
//  Imaging_Controller
//
//  Created by Masahiko Sato on 3/9/2014.
//  Copyright Masahiko Sato 2014 All rights reserved.
//
//

#ifndef COMMFILE_H
#define COMMFILE_H
#import "Controller.h"
#import "ASCIIconversion.h"
#endif

@interface CommFile : NSObject {
    int fileUpLoadProgress1; //File upload progress
    int fileUpLoadProgress2; //File upload progress
    int fileUpLoadInitialSet; //File upload initial set
    int incrementCountTransfer; //Increment
    int fileNameCount; //File name count
    int *arrayBodyNumber; //Body name array
    int *arrayTimeNumber; //Time number array
    int timeNumberCount; //Time number count
    int bodyNumberCount; //Body name count
    int lowestBodyNumber; //Lowest body name
    int lowestTime; //Lowest time
    
    id ascIIconversion;
    id controllerSubProcesses;
    id singleTiffSave;
    id tiffFileRead;
    
    NSTimer *commFileTimer;
}

-(id)init;
-(void)dealloc;
-(void)fileUpLoad;
-(void)fileTransfer;
-(void)nameSetAuto;
-(void)processControl;
-(void)consoleTreatNameUpDate;
-(void)selectFileUpDate;
-(void)fileDeleteUpDate;

@end
