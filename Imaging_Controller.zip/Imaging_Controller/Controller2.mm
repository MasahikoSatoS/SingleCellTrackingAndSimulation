//
//  Controller2.m
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2021-08-03.
//  Copyright Masahiko Sato 2021 All rights reserved.
//

#import "Controller2.h"

@implementation Controller2

-(IBAction)analysisNameSet:(id)sender{
    if (initialRunStatus == "nil"){
        if (autoRunOnOff == 0 && batchBackupOnOff == 0 && batchImageOnOff == 0){
            if (processingIFStatus == 0){
                nameCheckString = [[inputDataSet stringValue] UTF8String];
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                int checkResults = [controllerSubProcesses nameCheck];
                
                if (checkResults == 0){
                    if (nameCheckString.length() < 4 || nameCheckString.length() > 15) checkResults = 1;
                }
                
                string entry;
                
                if (checkResults == 0){
                    DIR *dir;
                    struct dirent *dent;
                    
                    dir = opendir(productsFilesPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if (entry.find(nameCheckString+"_") == 0){
                                    checkResults = 2;
                                    break;
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    dir = opendir(cellTrackingImageFolderPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if (entry.find(nameCheckString+"_") == 0){
                                    checkResults = 2;
                                    break;
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    dir = opendir(cellTrackingDataPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if (entry.find(nameCheckString+"_") == 0){
                                    checkResults = 2;
                                    break;
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    dir = opendir(cellTrackingAnalysisPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if (entry.find(nameCheckString+"_") == 0){
                                    checkResults = 2;
                                    break;
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                }
                
                int checkResults2 = 0;
                
                if (checkResults == 0){
                    entry = nameCheckString.substr(nameCheckString.length()-1, 1);
                    
                    if (entry == "0" || entry == "1" || entry == "2" || entry == "3" || entry == "4" || entry == "5" || entry == "6" || entry == "7" || entry == "8" || entry == "9"){
                        checkResults2 = 1;
                    }
                    
                    string stringExtract = nameCheckString.substr(nameCheckString.length()-2);
                    
                    if (stringExtract == "IF") checkResults2 = 1;
                }
                
                if (checkResults2 == 0){
                    if (checkResults == 0){
                        bodyNameHold = nameCheckString;
                        [inputDataSet setStringValue:@""];
                        [analysisName setStringValue:@(bodyNameHold.c_str())];
                        
                        arraySummaryList [1] = bodyNameHold;
                        backUpNameHold = bodyNameHold;
                        
                        [backUpName setStringValue:@(backUpNameHold.c_str())];
                        
                        summarySetCall = 2;
                        tableViewPage = 0;
                        
                        controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                        [controllerSubProcesses parameterSave];
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else if (checkResults == 1){
                        [inputDataSet setStringValue:@""];
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Duplicate name Found"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        [inputDataSet setStringValue:@""];
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Remove Numerical Number Or IF From The Last Character"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    [inputDataSet setStringValue:@""];
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"IF Mode On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                [inputDataSet setStringValue:@""];
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Stop Auto/Batch Processing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            [inputDataSet setStringValue:@""];
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        [inputDataSet setStringValue:@""];
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)computerNameSet:(id)sender{
    if (initialRunStatus == "nil"){
        if (autoRunOnOff == 0 && batchBackupOnOff == 0 && batchImageOnOff == 0){
            if (processingIFStatus == 0){
                nameCheckString = [[inputDataSet stringValue] UTF8String];
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                int checkResults = [controllerSubProcesses nameCheck];
                
                if (checkResults == 2){
                    if (nameCheckString.find(" ") != 0) checkResults = 0;
                }
                
                if (checkResults == 0){
                    if (nameCheckString.length() < 4 || nameCheckString.length() > 15) checkResults = 1;
                }
                
                if (checkResults == 0){
                    computerNameHold = nameCheckString;
                    [inputDataSet setStringValue:@""];
                    [computerName setStringValue:@(computerNameHold.c_str())];
                    
                    arraySummaryList [2] = computerNameHold;
                    summarySetCall = 2;
                    tableViewPage = 0;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses parameterSave];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    [inputDataSet setStringValue:@""];
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"IF Mode On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                [inputDataSet setStringValue:@""];
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Stop Auto/Batch Processing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            [inputDataSet setStringValue:@""];
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        [inputDataSet setStringValue:@""];
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)totalFOVSet:(id)sender{
    string totalFOVSetStringTemp = [[inputDataSet stringValue] UTF8String];
    int totalFOVSetTemp = atoi(totalFOVSetStringTemp.c_str());
    
    if (initialRunStatus == "nil"){
        if (autoRunOnOff == 0 && batchBackupOnOff == 0 && batchImageOnOff == 0){
            if (processingIFStatus == 0){
                if (totalFOVSetTemp > 0 && totalFOVSetTemp < 1000){
                    totalFOVNoHold = totalFOVSetStringTemp;
                    [inputDataSet setStringValue:@""];
                    [totalFOV setStringValue:@(totalFOVNoHold.c_str())];
                    
                    arraySummaryList [4] = totalFOVSetStringTemp;
                    summarySetCall = 2;
                    tableViewPage = 0;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses parameterSave];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    [inputDataSet setStringValue:@""];
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"IF Mode On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                [inputDataSet setStringValue:@""];
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Stop Auto/Batch Processing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            [inputDataSet setStringValue:@""];
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        [inputDataSet setStringValue:@""];
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)userIDSet:(id)sender{
    if (initialRunStatus == "nil"){
        if (autoRunOnOff == 0 && batchBackupOnOff == 0 && batchImageOnOff == 0){
            if (processingIFStatus == 0){
                nameCheckString = [[inputDataSet stringValue] UTF8String];
                
                controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                int checkResults = [controllerSubProcesses nameCheck];
                
                if (checkResults == 0){
                    if (nameCheckString.length() < 3 || nameCheckString.length() > 15) checkResults = 1;
                }
                
                if (checkResults == 0){
                    userIDHold = nameCheckString;
                    [inputDataSet setStringValue:@""];
                    [userID setStringValue:@(userIDHold.c_str())];
                    
                    arraySummaryList [3] = userIDHold;
                    summarySetCall = 2;
                    tableViewPage = 0;
                    
                    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
                    [controllerSubProcesses parameterSave];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    [inputDataSet setStringValue:@""];
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"IF Mode On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                [inputDataSet setStringValue:@""];
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Stop Auto/Batch Processing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            [inputDataSet setStringValue:@""];
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        [inputDataSet setStringValue:@""];
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)xyMapStart:(id)sender{
    if (runStatusXYMap == 0){
        remove (instructionMapPath.c_str());
        runStatusXYMap = 1;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCommXYMap object:self];
        
        string launchProgramMap = launchProgramPath+"/"+"XY_Map.app";
        
        NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
        [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramMap .c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
        
        launchCheck = 1;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"XY Map On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)outlineStartStart:(id)sender{
    if (runStatusOutlineDraw == 0){
        runStatusOutlineDraw = 1;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCommOutlineDraw object:self];
        
        string launchProgramOutlineDraw = launchProgramPath+"/"+"Cell_Outline_Draw.app";
        
        NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
        [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramOutlineDraw.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
        
        launchCheck = 1;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Outline Draw On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dataBackUpStart:(id)sender{
    if (autoBatchMode == 1){
        if (initialRunStatus == "8"){
            if (runStatusBackUp == 0){
                runStatusBackUp = 1;
                
                string launchProgramBackup = launchProgramPath+"/"+"Data_BackUp.app";
                
                NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
                [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramBackup.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
                
                launchCheck = 1;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Backup On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Complete Initial Setting"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Auto Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cellTrackingStart:(id)sender{
    if (runStatusCellTracking == 0){
        runStatusCellTracking = 1;
        launchCheck = 1;
        
        string launchProgramCellTracking = launchProgramPath+"/"+"Cell_Tracking.app";
        
        NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
        [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramCellTracking.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Cell Tracking On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)movieRunStart:(id)sender{
    if (runStatusMovie == 0){
        runStatusMovie = 1;
        
        string launchProgramMovie = launchProgramPath+"/"+"CellMovie.app";
        
        NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
        [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramMovie.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Cell Movie1 On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)movieRunStart2:(id)sender{
    if (runStatusMovie2 == 0){
        runStatusMovie2 = 1;
        
        string launchProgramMovie = launchProgramPath+"/"+"CellMovie2.app";
        
        NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
        [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramMovie.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Cell Movie2 On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)movieRunStart3:(id)sender{
    if (runStatusMovie3 == 0){
        runStatusMovie3 = 1;
        
        string launchProgramMovie = launchProgramPath+"/"+"CellMovie3.app";
        
        NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
        [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramMovie.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Cell Movie3 On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)movieRunStart4:(id)sender{
    if (runStatusMovie4 == 0){
        runStatusMovie4 = 1;
        
        string launchProgramMovie = launchProgramPath+"/"+"CellMovie4.app";
        
        NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
        [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramMovie.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Cell Movie4 On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)movieRunStart5:(id)sender{
    if (runStatusMovie5 == 0){
        runStatusMovie5 = 1;
        
        string launchProgramMovie = launchProgramPath+"/"+"CellMovie5.app";
        
        NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
        [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramMovie.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Cell Movie5 On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)movieRunStart6:(id)sender{
    if (runStatusMovie6 == 0){
        runStatusMovie6 = 1;
        
        string launchProgramMovie = launchProgramPath+"/"+"CellMovie6.app";
        
        NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
        [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramMovie.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Cell Movie6 On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)movieRunStartQuant:(id)sender{
    if (runStatusMovieQuant == 0){
        runStatusMovieQuant = 1;
        
        string launchProgramMovie = launchProgramPath+"/"+"CellMovieQuant.app";
        
        NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
        [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramMovie.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Cell Movie Quant On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)watsonStart:(id)sender{
    if (runStatusWatson == 0){
        runStatusWatson = 1;
        
        string launchProgramMovie = launchProgramPath+"/"+"Watson.app";
        
        NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
        [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramMovie.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Watson On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dataAnalysisStart:(id)sender{
    if (runStatusDataAnalysis == 0){
        runStatusDataAnalysis = 1;
        
        string launchProgramAnalysis = launchProgramPath+"/"+"Lineage_Analysis.app";
        
        NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
        [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramAnalysis.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
        
        launchCheck = 1;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Data Analysis On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)fileUpLoadStart:(id)sender{
    if (autoBatchMode == 1){
        if (processingIFStatus != 2){
            if (runStatusFileUpLoad == 0 && (lastPurgeFlag == 0 || lastPurgeFlag == 1)){
                if (initialRunStatus == "0" || initialRunStatus == "1" || (initialRunStatus == "8" && autoProcessCommit != "nil")){
                    runStatusFileUpLoad = 1;
                    
                    if (initialRunStatus == "0") imageTimePointAccumulationCounter = 0;
                    
                    string instructionFLPath2 = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/FL_Instruction2";
                    
                    int upLoadLaunchCheck = 0;
                    
                    if (lastPurgeFlag == 1){
                        remove (instructionFLPath2.c_str());
                        
                        int fileRemoveCheck = 0;
                        
                        ifstream fin;
                        
                        do{
                            
                            fileRemoveCheck = 1;
                            fin.open(instructionFLPath2.c_str(),ios::in);
                            
                            if (!fin.is_open()){
                                fileRemoveCheck = 0;
                            }
                            else{
                                
                                fin.close();
                            }
                            
                        } while (fileRemoveCheck == 1);
                        
                        upLoadLaunchCheck = 1;
                    }
                    else upLoadLaunchCheck = 1;
                    
                    if (upLoadLaunchCheck == 1){
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCommFile object:self];
                        
                        string launchProgramFileUpLoad = launchProgramPath+"/"+"FileUpLoad.app";
                        
                        NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
                        [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramFileUpLoad.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
                        
                        launchCheck = 1;
                    }
                }
                else{
                    
                    if (initialRunStatus != "0" && initialRunStatus != "1" && initialRunStatus != "nil"){
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"File UpLoad Complete"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    else if (initialRunStatus == "nil"){
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Initial Run Off"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"File UpLoad On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"IF Mode Not started"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Auto Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)treatNameStart:(id)sender{
    if (runStatusFileUpLoad == 0 && autoBatchMode == 1 && autoProcessCommit == "nil"){
        if (runStatusTreatmentNameSet == 0){
            initialRunStatus = "2";
            
            if ((initialRunStatus == "2" || initialRunStatus == "3") && autoRunOnOff == 0){
                remove (instructionNamePath.c_str());
                runStatusTreatmentNameSet = 1;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCommName object:self];
                
                string launchProgramNameAss = launchProgramPath+"/"+"FileName_Assignment.app";
                
                NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
                [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramNameAss.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
                
                launchCheck = 1;
            }
            else{
                
                if (autoRunOnOff != 0){
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Auto Run On"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                else if (initialRunStatus != "2" && initialRunStatus != "3" && initialRunStatus != "nil"){
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Name Assignment Complete"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                else if (initialRunStatus == "nil"){
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Initial Run Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Name Assignment On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (runStatusFileUpLoad > 0 && autoBatchMode == 1){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Quit File UpLoading"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (autoProcessCommit == "1" && autoBatchMode == 1){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Auto On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (autoBatchMode != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Auto Mode Off"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)focalStart:(id)sender{
    if (runStatusTreatmentNameSet == 0 && (autoBatchMode == 1 || autoBatchMode == 2)){
        if (processingIFStatus != 2){
            if (runStatusFocalImage == 0){
                if ((initialRunStatus == "4" || initialRunStatus == "5" || initialRunStatus == "8") && batchBackupOnOff == 0 && autoRunOnOff == 0){
                    if ((autoBatchMode == 1 && initialRunStatus == "8" && autoProcessCommit == "nil") || (autoBatchMode == 2 && initialRunStatus == "8" && batchBackupOperationCommit == "nil")){
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Start Batch/Auto"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    else{
                        
                        remove (instructionFIPath.c_str());
                        remove (instructionFIPath2.c_str());
                        runStatusFocalImage = 1;
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCommFocal object:self];
                        
                        string launchProgramFocal = launchProgramPath+"/"+"Focal_Image_Selection.app";
                        
                        NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
                        [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramFocal.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
                        
                        launchCheck = 1;
                    }
                }
                else{
                    
                    if (batchBackupOnOff != 0){
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Batch On"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    else if (autoRunOnOff != 0){
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Auto Run On"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    else if (initialRunStatus != "4" && initialRunStatus != "5" && initialRunStatus != "nil"){
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Focal Image Sel. Complete"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    else if (initialRunStatus == "nil"){
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Initial Run Off"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Focal Image Sel. On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"IF Mode Not started"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (autoBatchMode == 1 && runStatusTreatmentNameSet > 0){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Quit File Name Assignment"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (autoBatchMode == 3){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Auto/Batch BackUp Mode Off"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)contrastSetStart:(id)sender{
    if (runStatusFocalImage == 0 && (autoBatchMode == 1 || autoBatchMode == 2 || autoBatchMode == 3)){
        if (processingIFStatus != 2){
            if (runStatusContrast == 0){
                if ((initialRunStatus == "6" || initialRunStatus == "7" || initialRunStatus == "8") && batchBackupOnOff == 0 && batchImageOnOff == 0 && autoRunOnOff == 0){
                    if ((autoBatchMode == 1 && initialRunStatus == "8" && autoProcessCommit == "nil") || (autoBatchMode == 2 && initialRunStatus == "8" && batchBackupOperationCommit == "nil") || (autoBatchMode == 3 && initialRunStatus == "8" && batchImageOperationCommit == "nil")){
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Start Batch/Auto"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    else{
                        
                        remove (instructionCSPath.c_str());
                        runStatusContrast = 1;
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCommContrast object:self];
                        
                        string launchProgramContrast = launchProgramPath+"/"+"Contrast_Set.app";
                        
                        NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
                        [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramContrast.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
                        
                        launchCheck = 1;
                    }
                }
                else{
                    
                    if (batchBackupOnOff != 0 || batchImageOnOff != 0){
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Batch On"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    else if (autoRunOnOff != 0){
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Auto Run On"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    else if (initialRunStatus != "4" && initialRunStatus != "5" && initialRunStatus != "nil"){
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Contrast Set Complete"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    else if (initialRunStatus == "nil"){
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Initial Run Off"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Contrast Set On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"IF Mode Not started"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (runStatusFocalImage > 0 && (autoBatchMode == 1 || autoBatchMode == 2 || autoBatchMode == 3)){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Quit Focal Image Sel."];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)fileConverterStart:(id)sender{
    if (runStatusFileConverter == 0){
        runStatusFileConverter = 1;
        
        string launchProgramMovie = launchProgramPath+"/"+"FileConverter.app";
        
        NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
        [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramMovie.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"File Converter On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cell3DStart:(id)sender{
    if (runStatusCell3D == 0){
        runStatusCell3D = 1;
        
        string launchProgramMovie = launchProgramPath+"/"+"Cell3DDisplay.app";
        
        NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
        [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(launchProgramMovie.c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Cell 3D Display On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)objective10:(id)sender{
    objectiveType = "1";
    [objectiveSet setStringValue:@"x10"];
    arraySummaryList [31] = "x10";
    summarySetCall = 2;
    
    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
    [controllerSubProcesses parameterSave];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)objective20:(id)sender{
    objectiveType = "2";
    [objectiveSet setStringValue:@"x20"];
    arraySummaryList [31] = "x20";
    summarySetCall = 2;
    
    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
    [controllerSubProcesses parameterSave];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)objective40:(id)sender{
    objectiveType = "3";
    [objectiveSet setStringValue:@"x40"];
    arraySummaryList [31] = "x40";
    summarySetCall = 2;
    
    controllerSubProcesses = [[ControllerSubProcesses alloc] init];
    [controllerSubProcesses parameterSave];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)fileSplitSetNo:(id)sender{
    fileSplitOption = 1;
    [fileSplitSet setStringValue:@"   No   "];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)fileSplitSetYES:(id)sender{
    fileSplitOption = 0;
    [fileSplitSet setStringValue:@"H:W = 1:2"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

@end
