//
//  BatchBackUpProcess.h
//  Imaging_Controller
//
//  Created by Masahiko Sato on 2014-05-19.
//  Copyright Masahiko Sato 2014 All rights reserved.
//
//

#ifndef BATCHBACKUPPROCESS_H
#define BATCHBACKUPPROCESS_H
#import "Controller.h"
#endif

@interface BatchBackUpProcess : NSObject {
    NSTimer *batchBackUpTimer;
    
    id controllerSubProcesses;
}

-(id)init;
-(void)dealloc;
-(void)batchBackUpMain;
-(void)consoleFocalImageUpDate;
-(void)consoleContrastUpDate;
-(void)warningUpDate;
-(void)stepReset;
-(void)processControl;
-(void)fileDeleteUpDate;
-(void)fileDeleteUpDate2;

@end
