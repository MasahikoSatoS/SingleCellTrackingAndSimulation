//
//  HistogramWindow.m
//  FileConverter
//
//  Created by Masahiko Sato on 2018-06-15.
//
//

#import "HistogramWindow.h"
NSString *notificationToHistogram = @"notificationExecuteHistogram";

@implementation HistogramWindow

- (id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    
    if (self) {
        dragFlag = 0;
        verticalMagnification = 1;
        verticalMagnificationStep = 1;
        
        histogramImage = [[NSImage alloc] initWithContentsOfFile:@""];
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToHistogram object:nil];
    }
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [self setNeedsDisplay:YES];
}

-(void)mouseDown:(NSEvent *)event{
    NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
    
    xPointDownHisto = clickPoint.x;
    yPointDownHisto = clickPoint.y;
    selectProcessLine = 0;
    
    if (bitNumberNumberHold == 8){
        if ((double)(lowerHistHold/(double)256)*368 > xPointDownHisto-10 && (double)(lowerHistHold/(double)256)*368 < xPointDownHisto+10 && yPointDownHisto < 140){
            selectProcessLine = 1;
            dragFlag = 1;
        }
        else if ((double)(higherHistHold/(double)256)*368 > xPointDownHisto-10 && (double)(higherHistHold/(double)256)*368 < xPointDownHisto+10 && yPointDownHisto < 140){
            selectProcessLine = 2;
            dragFlag = 1;
        }
    }
    else if (bitNumberNumberHold == 16){
        if ((double)(lowerHistHold/(double)65535)*368 > xPointDownHisto-10 && (double)(lowerHistHold/(double)65535)*368 < xPointDownHisto+10 && yPointDownHisto < 140){
            selectProcessLine = 1;
            dragFlag = 1;
        }
        else if ((double)(higherHistHold/(double)65535)*368 > xPointDownHisto-10 && (double)(higherHistHold/(double)65535)*368 < xPointDownHisto+10 && yPointDownHisto < 140){
            selectProcessLine = 2;
            dragFlag = 1;
        }
    }
    
    [self setNeedsDisplay:YES];
}

-(void)mouseUp:(NSEvent *)event{
    NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
    
    dragFlag = 0;
    
    xPointDragHisto = clickPoint.x;
    
    if (bitNumberNumberHold == 8){
        if (selectProcessLine == 1){
            if (lowerHistHold >= 0){
                lowerHistHold = (int)(((xPointDragHisto-2)/(double)368)*(double)256);
                
                if (lowerHistHold < 0) lowerHistHold = 0;
                if (lowerHistHold >= 256) lowerHistHold = 256;
            }
        }
        else if (selectProcessLine == 2){
            if (higherHistHold < 256){
                higherHistHold = (int)(((xPointDragHisto-2)/(double)368)*(double)256);
                
                if (higherHistHold < 0) higherHistHold = 0;
                if (higherHistHold >= 256) higherHistHold = 255;
            }
        }
    }
    else if (bitNumberNumberHold == 16){
        if (selectProcessLine == 1){
            if (lowerHistHold >= 0){
                lowerHistHold = (int)(((xPointDragHisto-2)/(double)368)*(double)65535);
                
                if (lowerHistHold < 0) lowerHistHold = 0;
                if (lowerHistHold >= 65536) lowerHistHold = 65536;
            }
        }
        else if (selectProcessLine == 2){
            if (higherHistHold < 65536){
                higherHistHold = (int)(((xPointDragHisto-2)/(double)368)*(double)65535);
                
                if (higherHistHold < 0) higherHistHold = 0;
                if (higherHistHold >= 65536) higherHistHold = 65535;
            }
        }
    }
    
    [self setNeedsDisplay:YES];
}

-(void)mouseDragged:(NSEvent *)event{
    NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
    
    dragFlag = 1;
    
    xPointDragHisto = clickPoint.x;
    
    if (bitNumberNumberHold == 8){
        if (selectProcessLine == 1){
            if (lowerHistHold >= 0){
                lowerHistHold = (int)(((xPointDragHisto-2)/(double)368)*(double)256);
                
                if (lowerHistHold < 0) lowerHistHold = 0;
                if (lowerHistHold >= 256) lowerHistHold = 256;
            }
        }
        else if (selectProcessLine == 2){
            if (higherHistHold < 256){
                higherHistHold = (int)(((xPointDragHisto-2)/(double)368)*(double)256);
                
                if (higherHistHold < 0) higherHistHold = 0;
                if (higherHistHold >= 256) higherHistHold = 255;
            }
        }
    }
    else if (bitNumberNumberHold == 16){
        if (selectProcessLine == 1){
            if (lowerHistHold >= 0){
                lowerHistHold = (int)(((xPointDragHisto-2)/(double)368)*(double)65535);
                
                if (lowerHistHold < 0) lowerHistHold = 0;
                if (lowerHistHold >= 65536) lowerHistHold = 65536;
            }
        }
        else if (selectProcessLine == 2){
            if (higherHistHold < 65536){
                higherHistHold = (int)(((xPointDragHisto-2)/(double)368)*(double)65535);
                
                if (higherHistHold < 0) higherHistHold = 0;
                if (higherHistHold >= 65536) higherHistHold = 65535;
            }
        }
    }
    
    [self setNeedsDisplay:YES];
}

-(void)keyDown:(NSEvent *)event{
    int keyCode = [event keyCode];
    
    if (keyCode == 126){
        if (verticalMagnificationStep <= 20){
            verticalMagnificationStep++;
            
            if (verticalMagnificationStep > 20) verticalMagnificationStep = 20;
            
            verticalMagnification = verticalMagnificationStep;
            
            [self setNeedsDisplay:YES];
        }
    }
    
    if (keyCode == 125){
        if (verticalMagnificationStep > 0){
            verticalMagnificationStep--;
            
            if (verticalMagnificationStep < 1) verticalMagnificationStep = 1;
            
            verticalMagnification = verticalMagnificationStep;
            
            [self setNeedsDisplay:YES];
        }
    }
    
    if (keyCode == 123 ||  keyCode == 124){
        if (folderChangeHold == 0){
            int nextFilePositionCheck = 0;
            
            if (keyCode == 123){
                if (nextValueHold == 0) nextFilePositionCheck = currentFile-1;
                else if (nextValueHold == 1) nextFilePositionCheck = currentFile-10;
                else if (nextValueHold == 2) nextFilePositionCheck = currentFile-100;
                else if (nextValueHold == 3) nextFilePositionCheck = currentFile-1000;
                
                if (nextFilePositionCheck < 1) nextFilePositionCheck = 0;
            }
            
            if (keyCode == 124){
                if (nextValueHold == 0) nextFilePositionCheck = currentFile+1;
                else if (nextValueHold == 1) nextFilePositionCheck = currentFile+10;
                else if (nextValueHold == 2) nextFilePositionCheck = currentFile+100;
                else if (nextValueHold == 3) nextFilePositionCheck = currentFile+1000;
                
                if (nextFilePositionCheck > fileDeleteCount) nextFilePositionCheck = 0;
            }
            
            if (nextFilePositionCheck != 0){
                string entry;
                string sourceFileName;
                string tiffExtensionHold;
                
                unsigned long nextAddress = 0;
                unsigned long stripFirstAddress = 0;
                unsigned long stripByteCountAddress = 0;
                unsigned long headPosition = 0;
                unsigned long totalImageCount = 0;
                unsigned long stripEntry = 0;
                long sizeForCopy = 0;
                
                double xPosition = 0;
                double yPosition = 0;
                
                int numberOfImagePoint = 0;
                int meanValueTemp = 0;
                int terminationFlag = 0;
                int pixNo90 = 0;
                
                int imageWidth = 0;
                int imageHeight = 0;
                int imageBit = 0; // Check 8, 16
                int imageCompression = 0; // Check 1
                int photoMetric = 0; //Check 0, 1, 2
                int imageDimension = 0;
                int dimensionAddition = 0;
                int verticalBmp = 0;
                int horizontalBmp = 0;
                int horizontalBmpEntry = 0;
                int newImageDimension = 0;
                int endianType = 0;
                int samplePerPix = 0;
                int dataConversion [4];
                int processType = 2;
                int numberOfLayers = 0;
                int layerTotalCount = 0;
                
                struct stat sizeOfFile;
                
                ifstream fin;
                
                if (fileDeleteCount != 0){
                    currentFile = nextFilePositionCheck;
                    fileNameHist = arrayFileDelete [currentFile-1];
                    
                    tiffExtensionHold = "";
                    
                    if ((int)arrayFileDelete [currentFile-1].find(".TIFF") != -1) tiffExtensionHold = ".TIFF";
                    else if ((int)arrayFileDelete [currentFile-1].find(".Tiff") != -1) tiffExtensionHold = ".Tiff";
                    else if ((int)arrayFileDelete [currentFile-1].find(".tiff") != -1) tiffExtensionHold = ".tiff";
                    else if ((int)arrayFileDelete [currentFile-1].find(".TIF") != -1 ) tiffExtensionHold = ".TIF";
                    else if ((int)arrayFileDelete [currentFile-1].find(".Tif") != -1) tiffExtensionHold = ".Tif";
                    else if ((int)arrayFileDelete [currentFile-1].find(".tif") != -1) tiffExtensionHold = ".tif";
                    
                    sourceFileName = sourcePathNameHold+"/"+arrayFileDelete [currentFile-1];
                    
                    //----File Read----
                    if (stat(sourceFileName.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        fileReadArray = new uint8_t [sizeForCopy+4];
                        fin.open(sourceFileName.c_str(), ios::in | ios::binary);
                        
                        fin.read((char*)fileReadArray, sizeForCopy+1);
                        fin.close();
                        
                        headPosition = 0;
                        
                        dataConversion [0] = fileReadArray [0];
                        dataConversion [1] = fileReadArray [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = fileReadArray [7];
                            dataConversion [1] = fileReadArray [6];
                            dataConversion [2] = fileReadArray [5];
                            dataConversion [3] = fileReadArray [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = fileReadArray [4];
                            dataConversion [1] = fileReadArray [5];
                            dataConversion [2] = fileReadArray [6];
                            dataConversion [3] = fileReadArray [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        if (endianType == 1){ //----Big endian----
                            layerTotalCount = 1;
                            
                            do{
                                
                                terminationFlag = 1;
                                
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (nextAddress == 0) terminationFlag = 0;
                                else{
                                    
                                    headPosition = nextAddress;
                                    layerTotalCount++;
                                }
                                
                            } while (terminationFlag == 1);
                        }
                        else if (endianType == 0){
                            layerTotalCount = 1;
                            
                            do{
                                
                                terminationFlag = 1;
                                
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (nextAddress == 0) terminationFlag = 0;
                                else{
                                    
                                    headPosition = nextAddress;
                                    layerTotalCount++;
                                }
                                
                            } while (terminationFlag == 1);
                        }
                        
                        zPlaneNumberHold = layerTotalCount;
                        bitNumberNumberHold = imageBit;
                        colorStatusHold = photoMetric;
                        
                        histDisplayCall = 1;
                        
                        //cout<<imageCompression<<" "<<imageBit<<" "<<layerTotalCount<<" EntryInfo"<<endl;
                        
                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                            zPositionHold = 1;
                            
                            int *arrayExtractedImage3 = new int [100];
                            
                            if (endianType == 1){
                                if (imageWidth > imageHeight) imageDimension = imageWidth;
                                else imageDimension = imageHeight;
                                
                                tiffFileRead = [[TiffFileRead alloc] init];
                                delete [] arrayExtractedImage3;
                                
                                arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                            }
                            else if (endianType == 0){
                                if (imageWidth > imageHeight) imageDimension = imageWidth;
                                else imageDimension = imageHeight;
                                
                                tiffFileRead = [[TiffFileRead alloc] init];
                                delete [] arrayExtractedImage3;
                                
                                arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                            }
                            
                            dimensionAddition = imageDimension%4;
                            
                            if (dimensionAddition == 1) dimensionAddition = 3;
                            else if (dimensionAddition == 2) dimensionAddition = 2;
                            else if (dimensionAddition == 3) dimensionAddition = 1;
                            
                            newImageDimension = imageDimension+dimensionAddition;
                            
                            int **arrayExtractedImage = new int *[newImageDimension+1];
                            
                            for (int counter3 = 0; counter3 < newImageDimension+1; counter3++){
                                arrayExtractedImage [counter3] = new int [newImageDimension+1];
                            }
                            
                            for (int counter3 = 0; counter3 < newImageDimension; counter3++){
                                for (int counter4 = 0; counter4 < newImageDimension; counter4++){
                                    arrayExtractedImage [counter3][counter4] = 0;
                                }
                            }
                            
                            verticalBmp = 0;
                            horizontalBmp = 0;
                            horizontalBmpEntry = 0;
                            
                            for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                if (verticalBmp < imageHeight){
                                    if (horizontalBmp < imageWidth){
                                        arrayExtractedImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3]);
                                        horizontalBmp++;
                                        horizontalBmpEntry++;
                                    }
                                    
                                    if (horizontalBmp == imageWidth && imageWidth < newImageDimension){
                                        for (int counter4 = 0; counter4 < newImageDimension-imageWidth; counter4++){
                                            arrayExtractedImage [verticalBmp][horizontalBmpEntry] = 0;
                                            horizontalBmpEntry++;
                                        }
                                    }
                                    
                                    if (horizontalBmp == imageWidth){
                                        horizontalBmp = 0;
                                        horizontalBmpEntry = 0;
                                        verticalBmp++;
                                    }
                                }
                            }
                            
                            if (imageBit == 8){
                                for (int counter3 = 0; counter3 <= 255; counter3++) histogramHold [counter3] = 0;
                                
                                for (int counter3 = 0; counter3 < newImageDimension; counter3++){
                                    for (int counter4 = 0; counter4 < newImageDimension; counter4++){
                                        if (arrayExtractedImage [counter3][counter4] >= 255) histogramHold [255]++;
                                        else if (arrayExtractedImage [counter3][counter4] < 0) histogramHold [0]++;
                                        else histogramHold [arrayExtractedImage [counter3][counter4]]++;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA <= 255; counterA++){
                                //    cout<<counterA<<" "<<histogramHold [counterA]<<" Histogram"<<endl;
                                //}
                                
                                lowerHistHold = 0;
                                higherHistHold = 0;
                                meanValueTemp = 0;
                                
                                numberOfImagePoint = 0;
                                totalImageCount = 0;
                                
                                for (int counter3 = 1; counter3 <= 255; counter3++){
                                    numberOfImagePoint = numberOfImagePoint+histogramHold [counter3];
                                    totalImageCount = totalImageCount+(unsigned long)counter3*(unsigned long)histogramHold [counter3];
                                }
                                
                                if (numberOfImagePoint != 0) meanValueTemp = (int)(totalImageCount/(double)numberOfImagePoint);
                                pixNo90 = histogramHold [meanValueTemp];
                                
                                for (int counter3 = 1; counter3 <= 255; counter3++){
                                    if (meanValueTemp-counter3 >= 0){
                                        pixNo90 = pixNo90+histogramHold [meanValueTemp-counter3];
                                        lowerHistHold = meanValueTemp-counter3;
                                    }
                                    if (meanValueTemp+counter3 <= 255){
                                        pixNo90 = pixNo90+histogramHold [meanValueTemp+counter3];
                                        higherHistHold = meanValueTemp+counter3;
                                    }
                                    if (pixNo90/(double)numberOfImagePoint > 0.8){
                                        break;
                                    }
                                }
                                
                                //cout<< lowerHistHold<<" "<<higherHistHold<<" "<<meanValueTemp <<" Value"endl;
                            }
                            else if (imageBit == 16){
                                for (int counter3 = 0; counter3 <= 65535; counter3++) histogramHold [counter3] = 0;
                                
                                for (int counter3 = 0; counter3 < newImageDimension; counter3++){
                                    for (int counter4 = 0; counter4 < newImageDimension; counter4++){
                                        if (arrayExtractedImage [counter3][counter4] >= 65535) histogramHold [65535]++;
                                        else if (arrayExtractedImage [counter3][counter4] < 0) histogramHold [0]++;
                                        else histogramHold [arrayExtractedImage [counter3][counter4]]++;
                                    }
                                }
                                
                                lowerHistHold = 0;
                                higherHistHold = 0;
                                meanValueTemp = 0;
                                
                                numberOfImagePoint = 0;
                                totalImageCount = 0;
                                
                                for (int counter3 = 0; counter3 <= 65535; counter3++){
                                    numberOfImagePoint = numberOfImagePoint+histogramHold [counter3];
                                    totalImageCount = totalImageCount+(unsigned long)counter3*(unsigned long)histogramHold [counter3];
                                }
                                
                                if (numberOfImagePoint != 0) meanValueTemp = (int)(totalImageCount/(double)numberOfImagePoint);
                                pixNo90 = histogramHold [meanValueTemp];
                                
                                for (int counter3 = 0; counter3 <= 65535; counter3++){
                                    if (meanValueTemp-counter3 >= 0){
                                        pixNo90 = pixNo90+histogramHold [meanValueTemp-counter3];
                                        lowerHistHold = meanValueTemp-counter3;
                                    }
                                    if (meanValueTemp+counter3 <= 65535){
                                        pixNo90 = pixNo90+histogramHold [meanValueTemp+counter3];
                                        higherHistHold = meanValueTemp+counter3;
                                    }
                                    if (pixNo90/(double)numberOfImagePoint > 0.8){
                                        break;
                                    }
                                }
                                
                                //cout<< lowerHistHold<<" "<<higherHistHold<<" "<<meanValueTemp <<" Value"endl;
                            }
                            
                            for (int counter3 = 0; counter3 < newImageDimension+1; counter3++){
                                delete [] arrayExtractedImage [counter3];
                            }
                            
                            delete [] arrayExtractedImage;
                            
                            delete [] arrayExtractedImage3;
                            
                            [self setNeedsDisplay:YES];
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Image Format Mismatch"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                        
                        delete [] fileReadArray;
                    }
                }
            }
        }
    }
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)drawRect:(NSRect)rect{
    [[NSColor lightGrayColor] set];
    
    NSBezierPath *path;
    path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 375, 152)];
    [path fill];
    
    if (firstRead == 1 && folderChangeHold == 0){
        [[NSColor blackColor] set];
        [NSBezierPath setDefaultLineWidth:0.8];
        
        NSPoint positionAA, positionBB;
        positionAA.x = 2;
        positionAA.y = 2;
        positionBB.x = 370;
        positionBB.y = 2;
        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
        
        [[NSColor redColor] set];
        [NSBezierPath setDefaultLineWidth:1.0];
        
        if (bitNumberNumberHold == 8){
            positionAA.x = (CGFloat)((lowerHistHold/(double)255)*368+2);
            positionAA.y = 2;
            positionBB.x = (CGFloat)((lowerHistHold/(double)255)*368+2);
            positionBB.y = 140;
            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            
            [[NSColor blueColor] set];
            [NSBezierPath setDefaultLineWidth:1.0];
            
            positionAA.x = (CGFloat)((higherHistHold/(double)255)*368+2);
            positionAA.y = 2;
            positionBB.x = (CGFloat)((higherHistHold/(double)255)*368+2);
            positionBB.y = 140;
            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
        }
        
        else if (bitNumberNumberHold == 16){
            positionAA.x = (CGFloat)((lowerHistHold/(double)65535)*368+2);
            positionAA.y = 2;
            positionBB.x = (CGFloat)((lowerHistHold/(double)65535)*368+2);
            positionBB.y = 140;
            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            
            [[NSColor blueColor] set];
            [NSBezierPath setDefaultLineWidth:1.0];
            
            positionAA.x = (CGFloat)((higherHistHold/(double)65535)*368+2);
            positionAA.y = 2;
            positionBB.x = (CGFloat)((higherHistHold/(double)65535)*368+2);
            positionBB.y = 140;
            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
        }
        
        [[NSColor blackColor] set];
        [NSBezierPath setDefaultLineWidth:1];
        
        int maxCount = 0;
        CGFloat maxValue = 0;
        
        if (bitNumberNumberHold == 8){
            for (int counter1 = 0; counter1 <= 255; counter1++){
                if (histogramHold [counter1] > maxCount){
                    maxCount = histogramHold [counter1];
                }
            }
            
            for (int counter1 = 0; counter1 <= 255; counter1++){
                maxValue = ((histogramHold [counter1]/(double)maxCount)*145)*verticalMagnification;
                
                if (maxValue > 145) maxValue = 145;
                
                positionAA.x = (CGFloat)((counter1/(double)255)*368+2);
                positionAA.y = 2;
                positionBB.x = (CGFloat)((counter1/(double)255)*368+2);
                positionBB.y = maxValue+2;
                
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            }
        }
        else if (bitNumberNumberHold == 16){
            for (int counter1 = 0; counter1 <= 65535; counter1++){
                if (histogramHold [counter1] > maxCount){
                    maxCount = histogramHold [counter1];
                }
            }
            
            if (dragFlag == 1){
                for (int counter1 = 0; counter1 <= 65535; counter1 = counter1+50){
                    maxValue = ((CGFloat)((histogramHold [counter1]/(double)maxCount)*145))*verticalMagnification;
                    
                    if (maxValue > 145) maxValue = 145;
                    
                    positionAA.x = (CGFloat)((counter1/(double)65535)*368+2);
                    positionAA.y = 2;
                    positionBB.x = (CGFloat)((counter1/(double)65535)*368+2);
                    positionBB.y = maxValue+2;
                    
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
            }
            else{
                
                for (int counter1 = 0; counter1 <= 65535; counter1++){
                    maxValue = ((CGFloat)((histogramHold [counter1]/(double)maxCount)*145))*verticalMagnification;
                    
                    if (maxValue > 145) maxValue = 145;
                    
                    positionAA.x = (CGFloat)((counter1/(double)65535)*368+2);
                    positionAA.y = 2;
                    positionBB.x = (CGFloat)((counter1/(double)65535)*368+2);
                    positionBB.y = maxValue+2;
                    
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
            }
        }
        
        NSAttributedString *attrStrA;
        NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
        
        string extension = to_string(lowerHistHold);
        
        [attributesA setObject:[NSFont systemFontOfSize:12] forKey:NSFontAttributeName];
        [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
        
        attrStrA = [[NSAttributedString alloc] initWithString:@"L:" attributes:attributesA];
        positionAA.x = 5;
        positionAA.y = 135;
        [attrStrA drawAtPoint:positionAA];
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributesA];
        positionAA.x = 17;
        positionAA.y = 135;
        [attrStrA drawAtPoint:positionAA];
        
        extension = to_string(higherHistHold);
        
        [attributesA setObject:[NSFont systemFontOfSize:12] forKey:NSFontAttributeName];
        [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        
        attrStrA = [[NSAttributedString alloc] initWithString:@"H:" attributes:attributesA];
        positionAA.x = 80;
        positionAA.y = 135;
        [attrStrA drawAtPoint:positionAA];
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributesA];
        positionAA.x = 92;
        positionAA.y = 135;
        [attrStrA drawAtPoint:positionAA];
        
        [attributesA setObject:[NSFont systemFontOfSize:12] forKey:NSFontAttributeName];
        [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
        
        if ((int)fileNameHist.length() > 25){
            fileNameHist = fileNameHist.substr(0, 25)+"...";
        }
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(fileNameHist.c_str()) attributes:attributesA];
        positionAA.x = 200;
        positionAA.y = 135;
        [attrStrA drawAtPoint:positionAA];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToHistogram object:nil];
}

@end
