//
//  Controller.h
//  FileConverter
//
//  Created by Masahiko Sato on 11/07/17.
//  Copyright 2011 Masahiko Sato All rights reserved.
//

#ifndef CONTROLLER_H
#define CONTROLLER_H
#import <Cocoa/Cocoa.h>
#import "ASCIIconversion.h"
#import "Processing.h"
#import "Processing2.h"
#import "SizeReduction.h"
#import "SingleTiffSave.h"
#import "TiffFileRead.h"
#import "ProcessingOptions.h"
#include <iostream>
#include <dirent.h>
#include <sys/stat.h>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <ctime>
#endif

using namespace std;

extern NSString *notificationToHistogram;

extern string pathNameString; //Path name
extern string sourcePathNameHold; //Source directory path
extern string destinationPathNameHold; //Destination directory path
extern string fileSavePathHold; //Path for Tiff file save
extern int **arrayImageFileSave; //Image array for tif save
extern uint8_t *fileReadArray; //Array holding image data

extern string *arrayFileDelete; //Directory file name hold
extern int fileDeleteCount; //Directory file name hold; count
extern int fileDeleteLimit; //Directory file name hold; limit
extern string ascIIstring; //To ascII string for int conversion
extern string fileNameHist; //File name display; draw rect

extern int fovStatusHold; //FOV set status hold
extern int tiffReductionHold; //Tiff reduction status hold
extern int contrastMeanHold; //Contrast mean hold
extern int belowCutHold; //Below cut off hold
extern int aboveCutHold; //Above cut hold
extern int valueBelowHold; //Value below hold
extern double meanAboveFoldHold; //Mean above hold
extern double meanBelowFoldHold; //Mean below hold
extern double valueFoldHold; //Value fold hold
extern int rangeFromHold; //Range from hold
extern int rangeToHold; //Range to hold
extern int tiff16To8Hold; //Tiff 16 to 8 (range) status hold
extern int contrastActivateHold; //contrast adjust status hold
extern int backStartHold; //Backup create start
extern int to16SetHold; // 8 to 16 bit conversion status hold
extern int zPositionHold; //z position hold
extern int nextValueHold; //Next value hold
extern int folderChangeHold; //Check source folder change. If changed, block hist display
extern int zPlaneNumberHold; //zStack number for display (histogram)
extern int bitNumberNumberHold; //Bit number for display (histogram)
extern int colorStatusHold; //Color status hold (histogram)
extern int lowerHistHold; //Histogram lower bar
extern int higherHistHold; //Histogram higher bar
extern int currentFile; //Current file number (histogram)
extern int firstRead; //Image loading check (histogram)
extern int backSaveOn; //Progress indicator on
extern int otherProcessOn; //Background process on
extern int histDisplayCall; //Histogram data display call
extern int loadImageSizeDisplayCall; //Display call for loaded image
extern string loadSizeDataString; //Original image size
extern string loadSizeDataString2; //Square image size

extern int *wellFov1; //Well information
extern int *wellFov2; //Well information
extern int *wellFov3; //Well information
extern int *wellFov4; //Well information
extern int *wellFov5; //Well information
extern int *wellFov6; //Well information
extern int *wellFov7; //Well information
extern int *wellFov8; //Well information
extern string *wellNoTreatList; //Well list
extern int wellNoTreatListCount;

extern int *fovPosition; //FOV position
extern int *histogramHold; //Histogram data hold

//char 1byte, -128-+127
//unsigned char 255, in the event that "char" is defined, it will be processed as "unsigned char"
//unsigned int, 4 bytes, max 4294967295; int +-4294967295/2
//unsigned long, unsigned long long, 8 bytes, max 9223372036854775807, use unsigned long; long, long long, +- 9223372036854775807/2
//double 8 bytes, floating, max 9223372036854775807

@interface Controller : NSObject <NSTextFieldDelegate>{
    int fluorescentSetHold; //Fluorescent live dic status hold
    int sizeDisplayCall; //Image size display call
    int dimensionSelect; //For dimension (square or original) multi-single layer operation
    int colorGraySelect; //For Color Gray multi-single layer operation
    string sizeDataString; //Source image size for display
    string sizeDataString2; //New image size for display
    int loadImageSizeDisplayCall; //Display call for loaded image
    string loadSizeDataString; //Original image size
    string loadSizeDataString2; //Square image size
    
    IBOutlet NSTextField *sourcePathNameHoldDisplay;
    IBOutlet NSTextField *destinationPathNameHoldDisplay;
    IBOutlet NSTextField *layerNoDisplay;
    IBOutlet NSTextField *layerNoDisplay2;
    IBOutlet NSTextField *sourceImageSizeDisplay;
    IBOutlet NSTextField *newImageSizeDisplay;
    IBOutlet NSTextField *fileNameFromDisplay;
    IBOutlet NSTextField *fileNameToDisplay;
    IBOutlet NSTextField *renumberStartDisplay;
    IBOutlet NSTextField *renumberEveryDisplay;
    IBOutlet NSTextField *renumberGapDisplay;
    IBOutlet NSTextField *pickUpStartDisplay;
    IBOutlet NSTextField *pickUpEveryDisplay;
    IBOutlet NSTextField *pickKeyDisplay;
    IBOutlet NSTextField *dimensionDisplay;
    IBOutlet NSTextField *colorGrayDisplay;
    
    IBOutlet NSTextField *fovStatusDisplay;
    IBOutlet NSTextField *tifReductionDisplay;
    IBOutlet NSTextField *contrastMeanDisplay;
    IBOutlet NSTextField *belowCutDisplay;
    IBOutlet NSTextField *aboveCutDisplay;
    IBOutlet NSTextField *valueBelowDisplay;
    IBOutlet NSTextField *valueMeanAboveDisplay;
    IBOutlet NSTextField *valueMeanBelowDisplay;
    IBOutlet NSTextField *valueFoldDisplay;
    IBOutlet NSTextField *fileBitDisplay;
    IBOutlet NSTextField *rangeFromDisplay;
    IBOutlet NSTextField *rangeToDisplay;
    IBOutlet NSTextField *tiff16To8Display;
    IBOutlet NSTextField *contrastActivateDisplay;
    IBOutlet NSTextField *backStartDisplay;
    IBOutlet NSTextField *to16HoldDisplay;
    
    IBOutlet NSTextField *xyAssign11;
    IBOutlet NSTextField *xyAssign21;
    IBOutlet NSTextField *xyAssign31;
    IBOutlet NSTextField *xyAssign41;
    IBOutlet NSTextField *xyAssign51;
    IBOutlet NSTextField *xyAssign61;
    IBOutlet NSTextField *xyAssign71;
    
    IBOutlet NSTextField *xyAssign12;
    IBOutlet NSTextField *xyAssign22;
    IBOutlet NSTextField *xyAssign32;
    IBOutlet NSTextField *xyAssign42;
    IBOutlet NSTextField *xyAssign52;
    IBOutlet NSTextField *xyAssign62;
    IBOutlet NSTextField *xyAssign72;
    
    IBOutlet NSTextField *xyAssign13;
    IBOutlet NSTextField *xyAssign23;
    IBOutlet NSTextField *xyAssign33;
    IBOutlet NSTextField *xyAssign43;
    IBOutlet NSTextField *xyAssign53;
    IBOutlet NSTextField *xyAssign63;
    IBOutlet NSTextField *xyAssign73;
    
    IBOutlet NSTextField *xyAssign14;
    IBOutlet NSTextField *xyAssign24;
    IBOutlet NSTextField *xyAssign34;
    IBOutlet NSTextField *xyAssign44;
    IBOutlet NSTextField *xyAssign54;
    IBOutlet NSTextField *xyAssign64;
    IBOutlet NSTextField *xyAssign74;
    
    IBOutlet NSTextField *xyAssign15;
    IBOutlet NSTextField *xyAssign25;
    IBOutlet NSTextField *xyAssign35;
    IBOutlet NSTextField *xyAssign45;
    IBOutlet NSTextField *xyAssign55;
    IBOutlet NSTextField *xyAssign65;
    IBOutlet NSTextField *xyAssign75;
    
    IBOutlet NSTextField *xyAssign16;
    IBOutlet NSTextField *xyAssign26;
    IBOutlet NSTextField *xyAssign36;
    IBOutlet NSTextField *xyAssign46;
    IBOutlet NSTextField *xyAssign56;
    IBOutlet NSTextField *xyAssign66;
    IBOutlet NSTextField *xyAssign76;
    
    IBOutlet NSTextField *xyAssign17;
    IBOutlet NSTextField *xyAssign27;
    IBOutlet NSTextField *xyAssign37;
    IBOutlet NSTextField *xyAssign47;
    IBOutlet NSTextField *xyAssign57;
    IBOutlet NSTextField *xyAssign67;
    IBOutlet NSTextField *xyAssign77;
    
    IBOutlet NSTextField *dimension1;
    IBOutlet NSTextField *dimension2;
    IBOutlet NSTextField *dimension3;
    IBOutlet NSTextField *dimension4;
    IBOutlet NSTextField *dimension5;
    IBOutlet NSTextField *dimension6;
    IBOutlet NSTextField *dimension7;
    IBOutlet NSTextField *dimension8;
    
    IBOutlet NSTextField *body1;
    IBOutlet NSTextField *body2;
    IBOutlet NSTextField *body3;
    IBOutlet NSTextField *body4;
    IBOutlet NSTextField *body5;
    IBOutlet NSTextField *body6;
    IBOutlet NSTextField *body7;
    IBOutlet NSTextField *body8;
    
    IBOutlet NSTextField *zPositionDisplay;
    IBOutlet NSTextField *zNumberDisplay;
    IBOutlet NSTextField *bitNoDisplay;
    IBOutlet NSTextField *colorStatusDisplay;
    IBOutlet NSTextField *stepperNextDisplay;
    IBOutlet NSTextField *imageSizeDisplay;
    IBOutlet NSTextField *loadImageSizeDisplay;
    IBOutlet NSTextField *squareImageSizeDisplay;
    
    IBOutlet NSStepper *stepperNext;
    IBOutlet NSStepper *stepperSlice;
    
    IBOutlet NSProgressIndicator *backSave;
    
    IBOutlet NSWindow *controllerWindow;
    
    NSTimer *controllerTimer;
    
    id ascIIconversion;
    id singleTiffSave;
    id tiffFileRead;
    id fileUpDates;
}

-(id)init;
-(void)dealloc;

-(void)displayData;
-(void)fileDeleteUpDate;

-(IBAction)selectFolderDirectory:(id)sender;
-(IBAction)selectDestinationFolderDirectory:(id)sender;
-(IBAction)multiToSingleTiff:(id)sender;
-(IBAction)multiToMultiTiff:(id)sender;
-(IBAction)singleToMultiTiff:(id)sender;
-(IBAction)fileNameReplace:(id)sender;
-(IBAction)fileNameRemove:(id)sender;
-(IBAction)fileNameInsert:(id)sender;
-(IBAction)fileReNumbering:(id)sender;
-(IBAction)invertNo:(id)sender;
-(IBAction)folderCombine:(id)sender;
-(IBAction)filePickUp:(id)sender;
-(IBAction)keyPickUp:(id)sender;

-(IBAction)conversionBmpToTif:(id)sender;

-(IBAction)processQuit:(id)sender;
-(IBAction)setWell1:(id)sender;
-(IBAction)setWell2:(id)sender;
-(IBAction)setWell3:(id)sender;
-(IBAction)setWell4:(id)sender;
-(IBAction)setWell5:(id)sender;
-(IBAction)setWell6:(id)sender;
-(IBAction)setWell7:(id)sender;
-(IBAction)setWell8:(id)sender;
-(IBAction)clearDimension:(id)sender;
-(IBAction)clearAll:(id)sender;
-(IBAction)fovPositionSet:(id)sender;
-(IBAction)tifReductionSet:(id)sender;
-(IBAction)activateContrast:(id)sender;
-(IBAction)tif16To8Set:(id)sender;
-(IBAction)to16Set:(id)sender;
-(IBAction)imageLoad:(id)sender;
-(IBAction)stepperActionNext:(id)sender;
-(IBAction)stepperSlice:(id)sender;
-(IBAction)dimensionSelect:(id)sender;
-(IBAction)colorGraySelect:(id)sender;

@end
