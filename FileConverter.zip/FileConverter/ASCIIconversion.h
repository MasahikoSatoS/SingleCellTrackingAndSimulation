//
//  ASCIIconversion.h
//  FileConverter
//
//  Created by Masahiko Sato on 2018-05-22.
//
//

#ifndef ASCIICONVERSION_H
#define ASCIICONVERSION_H
#import "Controller.h"
#endif

@interface ASCIIconversion : NSObject {
}

-(void)ascIIConversion2 :(int)ascIIint;
-(int)ascIICode;
-(int)nameCheck:(NSString*)nameCheckString;

@end
