//
//  Processing2.m
//  FileConverter
//
//  Created by Masahiko Sato on 2018-06-14.
//
//

#import "Processing2.h"

@implementation Processing2

-(IBAction)tiffToTiff:(id)sender{
    /*
     //----Input format Folder/name.tif
     //----Convert single or multi layer Tiff to Tiff file
     //----Option, Mean: Move mean to the set value: e.g. average 100, Mean: 90, 90 to be 100//if < fold set, after mean shift, (pix value-mean)*fold//if > fold set, after mean shift, (mean-pix value)*fold
     //----Option, Below cut: value below the cut will be replaced with the set value----
     //----Option, Above cut: value above cut will be multiplied by fold, e.g Cut: 100, pix value: 120, fold: 1.5, new value = (120-100)*1.5
     //----Option, Extract Tif range: Average: convert 16 bit to 8 bit, Range From-To: Extract range of 16 bit image and convert to 8 bit image
     //----Option Tiff reduction, reduce Tiff size to 1/2, before the reduction
     //----If Original is ON, image bit of original image will be kept. If it is Off, out put image will be 8 bit
     */
    
    if (otherProcessOn == 0){
        if (sourcePathNameHold != "nil" && destinationPathNameHold != "nil"){
            if (contrastActivateHold == 1){
                if (contrastMeanHold <= 0 || contrastMeanHold > 255){
                    contrastMeanHold = -1;
                    [contrastMeanDisplay setStringValue:@""];
                    [valueMeanAboveDisplay setStringValue:@""];
                    [valueMeanBelowDisplay setStringValue:@""];
                }
                else{
                    
                    if (meanAboveFoldHold <= 0 || meanAboveFoldHold > 255) meanAboveFoldHold = -1;
                    if (meanBelowFoldHold <= 0 || meanBelowFoldHold > 255) meanBelowFoldHold = -1;
                }
                
                if (belowCutHold <= 0 || belowCutHold > 255){
                    belowCutHold = -1;
                    valueBelowHold = -1;
                    [belowCutDisplay setStringValue:@""];
                    [valueBelowDisplay setStringValue:@""];
                }
                else{
                    
                    if (valueBelowHold <= 0 || valueBelowHold > 255){
                        belowCutHold = -1;
                        valueBelowHold = -1;
                        [belowCutDisplay setStringValue:@""];
                        [valueBelowDisplay setStringValue:@""];
                    }
                }
                
                if (aboveCutHold <= 0 || aboveCutHold > 255){
                    aboveCutHold = -1;
                    valueFoldHold = -1;
                    [aboveCutDisplay setStringValue:@""];
                    [valueFoldDisplay setStringValue:@""];
                }
                else{
                    
                    if (valueFoldHold <= 0 || valueFoldHold > 255){
                        aboveCutHold = -1;
                        valueFoldHold = -1;
                        [aboveCutDisplay setStringValue:@""];
                        [valueFoldDisplay setStringValue:@""];
                    }
                }
                
                if (tiff16To8Hold == 1){
                    if (rangeFromHold == -1 || rangeToHold == -1){
                        rangeFromHold = -1;
                        rangeToHold = -1;
                        tiff16To8Hold = 0;
                        [rangeFromDisplay setStringValue:@""];
                        [rangeToDisplay setStringValue:@""];
                        [tiff16To8Display setStringValue:@"Average"];
                    }
                    else if (rangeFromHold >= rangeToHold){
                        rangeFromHold = -1;
                        rangeToHold = -1;
                        tiff16To8Hold = 0;
                        [rangeFromDisplay setStringValue:@""];
                        [rangeToDisplay setStringValue:@""];
                        [tiff16To8Display setStringValue:@"Average"];
                    }
                }
                else{
                    
                    if (rangeFromHold != -1 && rangeToHold != -1){
                        if (rangeFromHold >= rangeToHold){
                            rangeFromHold = -1;
                            rangeToHold = -1;
                            [rangeFromDisplay setStringValue:@""];
                            [rangeToDisplay setStringValue:@""];
                        }
                    }
                    else{
                        
                        rangeFromHold = -1;
                        rangeToHold = -1;
                        [rangeFromDisplay setStringValue:@""];
                        [rangeToDisplay setStringValue:@""];
                    }
                }
            }
            
            string extractedID = sourcePathNameHold;
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                
                if ((int)extractedID.find("/") != -1) extractedID = extractedID.substr(extractedID.find("/")+1);
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            string newFolderPath = destinationPathNameHold+"/"+extractedID+"-New";
            
            int folderCreationCheck = 0;
            
            folderCreationCheck = mkdir(newFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            if (folderCreationCheck == 0){
                DIR *dir;
                struct dirent *dent;
                
                string entry;
                string cellFovPath4;
                
                unsigned long totalFileSize = 0;
                unsigned long freeSize = 0;
                unsigned long refSize = 0;
                long sizeForCopy = 0;
                
                ofstream oin;
                ifstream fin;
                
                fileDeleteCount = 0;
                
                dir = opendir(sourcePathNameHold.c_str());
                
                if (dir != NULL){
                    struct stat sizeOfFile;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        cellFovPath4 = sourcePathNameHold+"/"+entry;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" &&  ((int)entry.find(".TIFF") != -1 || (int)entry.find(".Tiff") != -1 || (int)entry.find(".tiff") != -1 || (int)entry.find(".TIF") != -1 || (int)entry.find(".Tif") != -1 || (int)entry.find(".tif") != -1)){
                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                            arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                            
                            if (stat(cellFovPath4.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                            }
                        }
                    }
                    
                    closedir(dir);
                    
                    //----Directory Sort----
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                        [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                }
                
                NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(destinationPathNameHold.c_str()) error:nil];
                freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
                refSize = totalFileSize+1048576000; //----1Gb----
                
                if (freeSize > refSize){
                    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
                        otherProcessOn = 1;
                        backSaveOn = 1;
                        
                        string sourceFileName;
                        string tiffExtensionHold;
                        
                        unsigned long nextAddress = 0;
                        unsigned long stripFirstAddress = 0;
                        unsigned long stripByteCountAddress = 0;
                        unsigned long headPosition = 0;
                        unsigned long stripEntry = 0;
                        unsigned long ifDPreviousHold = 0;
                        long sizeForCopy2 = 0;
                        
                        int dimensionAddition = 0;
                        int newImageDimension = 0;
                        int imageDimension = 0;
                        int verticalBmp = 0;
                        int horizontalBmp = 0;
                        int horizontalBmpEntry = 0;
                        int terminationFlag2 = 0;
                        int loopCount = 0;
                        
                        double xPosition = 0;
                        double yPosition = 0;
                        
                        int imageWidth = 0;
                        int imageHeight = 0;
                        int imageBit = 0; // Check 8, 16
                        int imageCompression = 0; // Check 1
                        int photoMetric = 0; //Check 0, 1, 2
                        int endianType = 0;
                        int samplePerPix = 0;
                        int dataConversion [4];
                        int mode = 0;
                        int processType = 2;
                        int numberOfLayers = 0;
                        int numberOfLayers2 = 0;
                        
                        struct stat sizeOfFile;
                        
                        ifstream fin2;
                        
                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            tiffExtensionHold = "";
                            
                            if ((int)arrayFileDelete [counter1].find(".TIFF") != -1) tiffExtensionHold = ".TIFF";
                            else if ((int)arrayFileDelete [counter1].find(".Tiff") != -1) tiffExtensionHold = ".Tiff";
                            else if ((int)arrayFileDelete [counter1].find(".tiff") != -1) tiffExtensionHold = ".tiff";
                            else if ((int)arrayFileDelete [counter1].find(".TIF") != -1 ) tiffExtensionHold = ".TIF";
                            else if ((int)arrayFileDelete [counter1].find(".Tif") != -1) tiffExtensionHold = ".Tif";
                            else if ((int)arrayFileDelete [counter1].find(".tif") != -1) tiffExtensionHold = ".tif";
                            
                            sourceFileName = sourcePathNameHold+"/"+arrayFileDelete [counter1];
                            
                            //----File Read----
                            if (stat(sourceFileName.c_str(), &sizeOfFile) == 0){
                                sizeForCopy2 = sizeOfFile.st_size;
                                
                                fileReadArray = new uint8_t [sizeForCopy2+4];
                                fin2.open(sourceFileName.c_str(), ios::in | ios::binary);
                                
                                fin2.read((char*)fileReadArray, sizeForCopy2+1);
                                fin2.close();
                                
                                headPosition = 0;
                                
                                dataConversion [0] = fileReadArray [0];
                                dataConversion [1] = fileReadArray [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = fileReadArray [7];
                                    dataConversion [1] = fileReadArray [6];
                                    dataConversion [2] = fileReadArray [5];
                                    dataConversion [3] = fileReadArray [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = fileReadArray [4];
                                    dataConversion [1] = fileReadArray [5];
                                    dataConversion [2] = fileReadArray [6];
                                    dataConversion [3] = fileReadArray [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                if (endianType == 1){ //----Big endian----
                                    self->tiffFileRead = [[TiffFileRead alloc] init];
                                    [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                }
                                else if (endianType == 0){
                                    self->tiffFileRead = [[TiffFileRead alloc] init];
                                    [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                }
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16)){
                                    imageDimension = 0;
                                    
                                    int *arrayExtractedImage3 = new int [100];
                                    
                                    loopCount = 0;
                                    
                                    do{
                                        
                                        terminationFlag2 = 1;
                                        
                                        if (loopCount == 0){
                                            fileSavePathHold = newFolderPath+"/"+arrayFileDelete [counter1];
                                            
                                            loopCount++;
                                            ifDPreviousHold = 0;
                                        }
                                        else loopCount++;
                                        
                                        if (endianType == 1){
                                            self->tiffFileRead = [[TiffFileRead alloc] init];
                                            [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers2];
                                            
                                            if (imageWidth > imageHeight) imageDimension = imageWidth;
                                            else imageDimension = imageHeight;
                                            
                                            self->tiffFileRead = [[TiffFileRead alloc] init];
                                            delete [] arrayExtractedImage3;
                                            
                                            arrayExtractedImage3 = [self->tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                        }
                                        else if (endianType == 0){
                                            self->tiffFileRead = [[TiffFileRead alloc] init];
                                            [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers2];
                                            
                                            if (imageWidth > imageHeight) imageDimension = imageWidth;
                                            else imageDimension = imageHeight;
                                            
                                            self->tiffFileRead = [[TiffFileRead alloc] init];
                                            delete [] arrayExtractedImage3;
                                            
                                            arrayExtractedImage3 = [self->tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                        }
                                        
                                        if (imageDimension != 0){
                                            dimensionAddition = imageDimension%4;
                                            
                                            if (dimensionAddition == 1) dimensionAddition = 3;
                                            else if (dimensionAddition == 2) dimensionAddition = 2;
                                            else if (dimensionAddition == 3) dimensionAddition = 1;
                                            
                                            newImageDimension = imageDimension+dimensionAddition;
                                            
                                            arrayImageFileSave = new int *[newImageDimension+1];
                                            
                                            for (int counter3 = 0; counter3 < newImageDimension+1; counter3++){
                                                arrayImageFileSave [counter3] = new int [newImageDimension+1];
                                            }
                                            
                                            for (int counter3 = 0; counter3 < newImageDimension; counter3++){
                                                for (int counter4 = 0; counter4 < newImageDimension; counter4++){
                                                    arrayImageFileSave [counter3][counter4] = 0;
                                                }
                                            }
                                            
                                            verticalBmp = 0;
                                            horizontalBmp = 0;
                                            horizontalBmpEntry = 0;
                                            
                                            for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                                if (verticalBmp < imageHeight){
                                                    if (horizontalBmp < imageWidth){
                                                        arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3]);
                                                        horizontalBmp++;
                                                        horizontalBmpEntry++;
                                                    }
                                                    
                                                    if (horizontalBmp == imageWidth && imageWidth < newImageDimension){
                                                        for (int counter4 = 0; counter4 < newImageDimension-imageWidth; counter4++){
                                                            arrayImageFileSave [verticalBmp][horizontalBmpEntry] = -1;
                                                            horizontalBmpEntry++;
                                                        }
                                                    }
                                                    
                                                    if (horizontalBmp == imageWidth){
                                                        horizontalBmp = 0;
                                                        horizontalBmpEntry = 0;
                                                        verticalBmp++;
                                                    }
                                                }
                                            }
                                            
                                            if (imageHeight < newImageDimension){
                                                for (int counter3 = imageHeight; counter3 < newImageDimension; counter3++){
                                                    for (int counter4 = 0; counter4 < newImageDimension; counter4++){
                                                        arrayImageFileSave [counter3][counter4] = -1;
                                                    }
                                                }
                                            }
                                            
                                            self->processingOptions = [[ProcessingOptions alloc] init];
                                            newImageDimension = [self->processingOptions imageProcessingOptions:imageBit:newImageDimension];
                                            
                                            if (imageBit == 16 && to16SetHold == 1){
                                                for (int counter3 = 0; counter3 < newImageDimension; counter3++){
                                                    for (int counter4 = 0; counter4 < newImageDimension; counter4++){
                                                        arrayImageFileSave [counter3][counter4] = arrayImageFileSave [counter3][counter4]*256;
                                                    }
                                                }
                                            }
                                            else imageBit = 8;
                                            
                                            if (xPosition == -1) xPosition = 100;
                                            if (yPosition == -1) yPosition = 100;
                                            
                                            photoMetric = 1;
                                            
                                            //cout<<imageBit<<" "<<photoMetric<<" "<<numberOfLayers<<" "<<ifDPreviousHold<<" "<<headPosition<<" "<<nextAddress<<" Info"<<endl;
                                            
                                            if (numberOfLayers == 1) mode = 0;
                                            else mode = 1;
                                            
                                            self->singleTiffSave = [[SingleTiffSave alloc] init];
                                            ifDPreviousHold = [self->singleTiffSave singleTiffLayerSave:newImageDimension:newImageDimension:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:ifDPreviousHold];
                                            
                                            for (int counter4 = 0; counter4 < newImageDimension+1; counter4++){
                                                delete [] arrayImageFileSave [counter4];
                                            }
                                            
                                            delete [] arrayImageFileSave;
                                        }
                                        
                                        if (nextAddress != 0) headPosition = nextAddress;
                                        else terminationFlag2 = 0;
                                        
                                    } while (terminationFlag2 == 1);
                                    
                                    delete [] arrayExtractedImage3;
                                }
                                
                                delete [] fileReadArray;
                            }
                        }
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        backSaveOn = 3;
                        otherProcessOn = 0;
                    });
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Disk Space Low"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Folder Creation Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select Source/Destination Folder"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageSizeAdjust:(id)sender{
    /*
     //----Input format: Folder
     //----Adjust image size to the largest one
     */
    
    if (sourcePathNameHold != "nil"){
        int terminationFlag = 0;
        string extractedID = sourcePathNameHold;
        
        do{
            
            terminationFlag = 1;
            
            if ((int)extractedID.find("/") != -1) extractedID = extractedID.substr(extractedID.find("/")+1);
            else terminationFlag = 0;
            
        } while (terminationFlag == 1);
        
        string newFolderPath = destinationPathNameHold+"/"+extractedID+"-"+"new";
        
        mkdir(newFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        DIR *dir;
        struct dirent *dent;
        
        string entry;
        string cellFovPath4;
        
        unsigned long totalFileSize = 0;
        unsigned long freeSize = 0;
        unsigned long refSize = 0;
        long sizeForCopy = 0;
        
        fileDeleteCount = 0;
        totalFileSize = 0;
        
        dir = opendir(sourcePathNameHold.c_str());
        
        if (dir != NULL){
            struct stat sizeOfFile;
            
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                cellFovPath4 = sourcePathNameHold+"/"+entry;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" &&  ((int)entry.find(".TIFF") != -1 || (int)entry.find(".Tiff") != -1 || (int)entry.find(".tiff") != -1 || (int)entry.find(".TIF") != -1 || (int)entry.find(".Tif") != -1 || (int)entry.find(".tif") != -1)){
                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                    arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                    
                    sizeForCopy = 0;
                    
                    if (stat(cellFovPath4.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                    }
                }
            }
            
            closedir(dir);
        }
        
        if (fileDeleteCount != 0){
            NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(destinationPathNameHold.c_str()) error:nil];
            freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
            refSize = totalFileSize+1048576000; //----1Gb----
            
            if (freeSize > refSize){
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
                    otherProcessOn = 1;
                    backSaveOn = 1;
                    
                    string sourceFileName;
                    string tiffExtensionHold;
                    string fileSaveName;
                    
                    unsigned long nextAddress = 0;
                    unsigned long stripFirstAddress = 0;
                    unsigned long stripByteCountAddress = 0;
                    unsigned long headPosition = 0;
                    unsigned long stripEntry = 0;
                    long sizeForCopy2 = 0;
                    
                    double xPosition = 0;
                    double yPosition = 0;
                    
                    int newImageDimensionW = 0;
                    int newImageDimensionH = 0;
                    
                    int imageWidth = 0;
                    int imageHeight = 0;
                    int imageBit = 0; // Check 8, 16
                    int imageCompression = 0; // Check 1
                    int photoMetric = 0; //Check 0, 1, 2
                    int imageDimension = 0;
                    int dimensionAddition = 0;
                    int verticalBmp = 0;
                    int horizontalBmp = 0;
                    int horizontalBmpEntry = 0;
                    int endianType = 0;
                    int samplePerPix = 0;
                    int dataConversion [4];
                    int mode = 0;
                    int processType = 3;
                    int numberOfLayers = 0;
                    
                    int maxImageSizeWidth = 0;
                    int maxImageSizeHight = 0;
                    
                    struct stat sizeOfFile;
                    
                    ifstream fin;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                        tiffExtensionHold = "";
                        
                        if ((int)arrayFileDelete [counter2].find(".TIFF") != -1) tiffExtensionHold = ".TIFF";
                        else if ((int)arrayFileDelete [counter2].find(".Tiff") != -1) tiffExtensionHold = ".Tiff";
                        else if ((int)arrayFileDelete [counter2].find(".tiff") != -1) tiffExtensionHold = ".tiff";
                        else if ((int)arrayFileDelete [counter2].find(".TIF") != -1 ) tiffExtensionHold = ".TIF";
                        else if ((int)arrayFileDelete [counter2].find(".Tif") != -1) tiffExtensionHold = ".Tif";
                        else if ((int)arrayFileDelete [counter2].find(".tif") != -1) tiffExtensionHold = ".tif";
                        
                        sourceFileName = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                        
                        //----File Read----
                        if (stat(sourceFileName.c_str(), &sizeOfFile) == 0){
                            sizeForCopy2 = sizeOfFile.st_size;
                            
                            fileReadArray = new uint8_t [sizeForCopy2+4];
                            fin.open(sourceFileName.c_str(), ios::in | ios::binary);
                            
                            fin.read((char*)fileReadArray, sizeForCopy2+1);
                            fin.close();
                            
                            dataConversion [0] = fileReadArray [0];
                            dataConversion [1] = fileReadArray [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = fileReadArray [7];
                                dataConversion [1] = fileReadArray [6];
                                dataConversion [2] = fileReadArray [5];
                                dataConversion [3] = fileReadArray [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = fileReadArray [4];
                                dataConversion [1] = fileReadArray [5];
                                dataConversion [2] = fileReadArray [6];
                                dataConversion [3] = fileReadArray [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            if (endianType == 1){ //----Big endian----
                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            }
                            else if (endianType == 0){
                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            }
                            
                            if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && numberOfLayers == 1 && samplePerPix <= 4 && photoMetric < 3){
                                if (maxImageSizeWidth < imageWidth) maxImageSizeWidth = imageWidth;
                                if (maxImageSizeHight < imageHeight) maxImageSizeHight = imageHeight;
                            }
                            else arrayFileDelete [counter2] = "";
                            
                            delete [] fileReadArray;
                        }
                    }
                    
                    if (maxImageSizeWidth > maxImageSizeHight) imageDimension = maxImageSizeWidth;
                    else imageDimension = maxImageSizeHight;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                        if (arrayFileDelete [counter2] != ""){
                            tiffExtensionHold = "";
                            
                            if ((int)arrayFileDelete [counter2].find(".TIFF") != -1) tiffExtensionHold = ".TIFF";
                            else if ((int)arrayFileDelete [counter2].find(".Tiff") != -1) tiffExtensionHold = ".Tiff";
                            else if ((int)arrayFileDelete [counter2].find(".tiff") != -1) tiffExtensionHold = ".tiff";
                            else if ((int)arrayFileDelete [counter2].find(".TIF") != -1 ) tiffExtensionHold = ".TIF";
                            else if ((int)arrayFileDelete [counter2].find(".Tif") != -1) tiffExtensionHold = ".Tif";
                            else if ((int)arrayFileDelete [counter2].find(".tif") != -1) tiffExtensionHold = ".tif";
                            
                            sourceFileName = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                            fileSaveName = arrayFileDelete [counter2].substr(0, arrayFileDelete [counter2].find(tiffExtensionHold));
                            
                            fileSavePathHold = newFolderPath+"/"+fileSaveName+".tif";
                            
                            if (stat(sourceFileName.c_str(), &sizeOfFile) == 0){
                                sizeForCopy2 = sizeOfFile.st_size;
                                
                                fileReadArray = new uint8_t [sizeForCopy2+4];
                                fin.open(sourceFileName.c_str(), ios::in | ios::binary);
                                
                                fin.read((char*)fileReadArray, sizeForCopy+1);
                                fin.close();
                                
                                headPosition = 0;
                                
                                dataConversion [0] = fileReadArray [0];
                                dataConversion [1] = fileReadArray [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = fileReadArray [7];
                                    dataConversion [1] = fileReadArray [6];
                                    dataConversion [2] = fileReadArray [5];
                                    dataConversion [3] = fileReadArray [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = fileReadArray [4];
                                    dataConversion [1] = fileReadArray [5];
                                    dataConversion [2] = fileReadArray [6];
                                    dataConversion [3] = fileReadArray [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                int *arrayExtractedImage3 = new int [100];
                                
                                if (endianType == 1){ //----Big endian----
                                    self->tiffFileRead = [[TiffFileRead alloc] init];
                                    [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                    
                                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && numberOfLayers == 1 && samplePerPix <= 4 && photoMetric < 3){
                                        if (imageWidth > imageHeight) imageDimension = imageWidth;
                                        else imageDimension = imageHeight;
                                        
                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [self->tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                    }
                                }
                                else if (endianType == 0){
                                    self->tiffFileRead = [[TiffFileRead alloc] init];
                                    [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                    
                                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && numberOfLayers == 1 && samplePerPix <= 4 && photoMetric < 3){
                                        if (imageWidth > imageHeight) imageDimension = imageWidth;
                                        else imageDimension = imageHeight;
                                        
                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [self->tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                    }
                                }
                                
                                if (imageDimension != 0){
                                    dimensionAddition = imageDimension%4;
                                    
                                    if (dimensionAddition == 1) dimensionAddition = 3;
                                    else if (dimensionAddition == 2) dimensionAddition = 2;
                                    else if (dimensionAddition == 3) dimensionAddition = 1;
                                    
                                    newImageDimensionW = imageDimension+dimensionAddition;
                                    newImageDimensionH = imageDimension+dimensionAddition;
                                    
                                    arrayImageFileSave = new int *[newImageDimensionH+1];
                                    
                                    for (int counter3 = 0; counter3 < newImageDimensionH+1; counter3++){
                                        arrayImageFileSave [counter3] = new int [newImageDimensionW*3+1];
                                    }
                                    
                                    for (int counter3 = 0; counter3 < newImageDimensionH+1; counter3++){
                                        for (int counter4 = 0; counter4 < newImageDimensionW*3+1; counter4++){
                                            arrayImageFileSave [counter3][counter4] = 0;
                                        }
                                    }
                                    
                                    verticalBmp = 0;
                                    horizontalBmp = 0;
                                    horizontalBmpEntry = 0;
                                    
                                    for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                        if (verticalBmp < imageHeight){
                                            if (horizontalBmp < imageWidth){
                                                if (photoMetric <= 1){
                                                    arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3]), horizontalBmpEntry++;
                                                }
                                                else if (photoMetric == 2){
                                                    arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3]), horizontalBmpEntry++;
                                                    arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+1]), horizontalBmpEntry++;
                                                    arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+2]), horizontalBmpEntry++;
                                                }
                                                
                                                horizontalBmp++;
                                            }
                                            
                                            if (horizontalBmp == imageWidth && imageWidth < newImageDimensionW){
                                                for (int counter4 = 0; counter4 < newImageDimensionW-imageWidth; counter4++){
                                                    if (photoMetric <= 1){
                                                        arrayImageFileSave [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                    }
                                                    else if (photoMetric == 2){
                                                        arrayImageFileSave [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                        arrayImageFileSave [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                        arrayImageFileSave [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                    }
                                                }
                                            }
                                            
                                            if (horizontalBmp == imageWidth){
                                                horizontalBmp = 0;
                                                horizontalBmpEntry = 0;
                                                verticalBmp++;
                                            }
                                        }
                                    }
                                    
                                    if (imageHeight < newImageDimensionH){
                                        for (int counter3 = imageHeight; counter3 < newImageDimensionH; counter3++){
                                            for (int counter4 = 0; counter4 < newImageDimensionW; counter4++){
                                                if (photoMetric <= 1){
                                                    arrayImageFileSave [counter3][counter4] = 0;
                                                }
                                                else if (photoMetric == 2){
                                                    arrayImageFileSave [counter3][counter4] = 0;
                                                    arrayImageFileSave [counter3][counter4] = 0;
                                                    arrayImageFileSave [counter3][counter4] = 0;
                                                }
                                            }
                                        }
                                    }
                                    
                                    if (photoMetric == 0) photoMetric = 1;
                                    if (samplePerPix == 4) samplePerPix = 3;
                                    
                                    if (xPosition == -1) xPosition = 100;
                                    if (yPosition == -1) yPosition = 100;
                                    
                                    self->singleTiffSave = [[SingleTiffSave alloc] init];
                                    [self->singleTiffSave singleTiffLayerSave:newImageDimensionW:newImageDimensionH:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:(unsigned long)mode];
                                    
                                    for (int counter3 = 0; counter3 < newImageDimensionH+1; counter3++){
                                        delete [] arrayImageFileSave [counter3];
                                    }
                                    
                                    delete [] arrayImageFileSave;
                                }
                                
                                delete [] arrayExtractedImage3;
                                
                                delete [] fileReadArray;
                            }
                        }
                    }
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    backSaveOn = 3;
                    otherProcessOn = 0;
                });
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Disk Space Low"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tif File Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Select Source Folder"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)fileDuplicate:(id)sender{
    /*
     //----Input format: Folder
     //----Create duplicate tif files in a selected folder
     */
    
    if (sourcePathNameHold != "nil"){
        int terminationFlag = 0;
        string extractedID = sourcePathNameHold;
        
        do{
            
            terminationFlag = 1;
            
            if ((int)extractedID.find("/") != -1) extractedID = extractedID.substr(extractedID.find("/")+1);
            else terminationFlag = 0;
            
        } while (terminationFlag == 1);
        
        string newFolderPath = destinationPathNameHold+"/"+extractedID+"-"+"new";
        
        mkdir(newFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        DIR *dir;
        struct dirent *dent;
        
        string entry;
        string cellFovPath4;
        
        unsigned long totalFileSize = 0;
        unsigned long freeSize = 0;
        unsigned long refSize = 0;
        long sizeForCopy = 0;
        
        fileDeleteCount = 0;
        totalFileSize = 0;
        
        dir = opendir(sourcePathNameHold.c_str());
        
        if (dir != NULL){
            struct stat sizeOfFile;
            
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                cellFovPath4 = sourcePathNameHold+"/"+entry;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" &&  ((int)entry.find(".TIFF") != -1 || (int)entry.find(".Tiff") != -1 || (int)entry.find(".tiff") != -1 || (int)entry.find(".TIF") != -1 || (int)entry.find(".Tif") != -1 || (int)entry.find(".tif") != -1)){
                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                    arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                    
                    if (stat(cellFovPath4.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                    }
                }
            }
            
            closedir(dir);
        }
        
        if (fileDeleteCount != 0){
            NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(destinationPathNameHold.c_str()) error:nil];
            freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
            refSize = totalFileSize+1048576000; //----1Gb----
            
            if (freeSize > refSize){
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
                    otherProcessOn = 1;
                    backSaveOn = 1;
                    
                    string sourceFileName;
                    string tiffExtensionHold;
                    string fileSaveName;
                    
                    unsigned long nextAddress = 0;
                    unsigned long stripFirstAddress = 0;
                    unsigned long stripByteCountAddress = 0;
                    unsigned long headPosition = 0;
                    unsigned long stripEntry = 0;
                    long sizeForCopy2 = 0;
                    
                    double xPosition = 0;
                    double yPosition = 0;
                    
                    int imageWidth = 0;
                    int imageHeight = 0;
                    int imageBit = 0; // Check 8, 16
                    int imageCompression = 0; // Check 1
                    int photoMetric = 0; //Check 0, 1, 2
                    int imageDimension = 0;
                    int verticalBmp = 0;
                    int horizontalBmp = 0;
                    int horizontalBmpEntry = 0;
                    int endianType = 0;
                    int samplePerPix = 0;
                    int dataConversion [4];
                    int mode = 0;
                    int processType = 3;
                    int numberOfLayers = 0;
                    
                    struct stat sizeOfFile;
                    
                    ifstream fin;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                        if (arrayFileDelete [counter2] != ""){
                            tiffExtensionHold = "";
                            
                            if ((int)arrayFileDelete [counter2].find(".TIFF") != -1) tiffExtensionHold = ".TIFF";
                            else if ((int)arrayFileDelete [counter2].find(".Tiff") != -1) tiffExtensionHold = ".Tiff";
                            else if ((int)arrayFileDelete [counter2].find(".tiff") != -1) tiffExtensionHold = ".tiff";
                            else if ((int)arrayFileDelete [counter2].find(".TIF") != -1 ) tiffExtensionHold = ".TIF";
                            else if ((int)arrayFileDelete [counter2].find(".Tif") != -1) tiffExtensionHold = ".Tif";
                            else if ((int)arrayFileDelete [counter2].find(".tif") != -1) tiffExtensionHold = ".tif";
                            
                            sourceFileName = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                            fileSaveName = arrayFileDelete [counter2].substr(0, arrayFileDelete [counter2].find(tiffExtensionHold));
                            
                            fileSavePathHold = newFolderPath+"/"+fileSaveName+".tif";
                            
                            if (stat(sourceFileName.c_str(), &sizeOfFile) == 0){
                                sizeForCopy2 = sizeOfFile.st_size;
                                
                                fileReadArray = new uint8_t [sizeForCopy2+4];
                                fin.open(sourceFileName.c_str(), ios::in | ios::binary);
                                
                                fin.read((char*)fileReadArray, sizeForCopy2+1);
                                fin.close();
                                
                                headPosition = 0;
                                
                                dataConversion [0] = fileReadArray [0];
                                dataConversion [1] = fileReadArray [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = fileReadArray [7];
                                    dataConversion [1] = fileReadArray [6];
                                    dataConversion [2] = fileReadArray [5];
                                    dataConversion [3] = fileReadArray [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = fileReadArray [4];
                                    dataConversion [1] = fileReadArray [5];
                                    dataConversion [2] = fileReadArray [6];
                                    dataConversion [3] = fileReadArray [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                int *arrayExtractedImage3 = new int [100];
                                
                                if (endianType == 1){ //----Big endian----
                                    self->tiffFileRead = [[TiffFileRead alloc] init];
                                    [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                    
                                    //cout<<imageWidth<<" "<<imageBit<<" "<<numberOfLayers<<" "<<samplePerPix<<" "<<photoMetric<<" Info"<<endl;
                                    
                                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && numberOfLayers == 1 && samplePerPix <= 4 && photoMetric < 3){
                                        if (imageWidth > imageHeight) imageDimension = imageWidth;
                                        else imageDimension = imageHeight;
                                        
                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [self->tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                    }
                                }
                                else if (endianType == 0){
                                    self->tiffFileRead = [[TiffFileRead alloc] init];
                                    [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                    
                                    //cout<<imageWidth<<" "<<imageBit<<" "<<numberOfLayers<<" "<<samplePerPix<<" "<<photoMetric<<" Info"<<endl;
                                    
                                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && numberOfLayers == 1 && samplePerPix <= 4 && photoMetric < 3){
                                        if (imageWidth > imageHeight) imageDimension = imageWidth;
                                        else imageDimension = imageHeight;
                                        
                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [self->tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                    }
                                }
                                
                                if (imageDimension != 0){
                                    arrayImageFileSave = new int *[imageHeight+1];
                                    
                                    for (int counter3 = 0; counter3 < imageHeight+1; counter3++){
                                        arrayImageFileSave [counter3] = new int [imageWidth*3+1];
                                    }
                                    
                                    verticalBmp = 0;
                                    horizontalBmp = 0;
                                    horizontalBmpEntry = 0;
                                    
                                    for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                        if (verticalBmp < imageHeight){
                                            if (horizontalBmp < imageWidth){
                                                if (photoMetric <= 1){
                                                    arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3]), horizontalBmpEntry++;
                                                }
                                                else if (photoMetric == 2){
                                                    arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3]), horizontalBmpEntry++;
                                                    arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+1]), horizontalBmpEntry++;
                                                    arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+2]), horizontalBmpEntry++;
                                                }
                                                
                                                horizontalBmp++;
                                            }
                                            
                                            if (horizontalBmp == imageWidth){
                                                horizontalBmp = 0;
                                                horizontalBmpEntry = 0;
                                                verticalBmp++;
                                            }
                                        }
                                    }
                                    
                                    if (photoMetric == 0) photoMetric = 1;
                                    if (samplePerPix == 4) samplePerPix = 3;
                                    
                                    if (xPosition == -1) xPosition = 100;
                                    if (yPosition == -1) yPosition = 100;
                                    
                                    self->singleTiffSave = [[SingleTiffSave alloc] init];
                                    [self->singleTiffSave singleTiffLayerSave:imageWidth:imageHeight:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:(unsigned long)mode];
                                    
                                    for (int counter3 = 0; counter3 < imageHeight+1; counter3++){
                                        delete [] arrayImageFileSave [counter3];
                                    }
                                    
                                    delete [] arrayImageFileSave;
                                }
                                
                                delete [] arrayExtractedImage3;
                                
                                delete [] fileReadArray;
                            }
                        }
                    }
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    backSaveOn = 3;
                    otherProcessOn = 0;
                });
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Disk Space Low"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tif File Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Select Source Folder"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)multiplicate:(id)sender{
    if (otherProcessOn == 0){
        if (sourcePathNameHold != "nil" && destinationPathNameHold != "nil"){
            string multiplicateString = [[multiplicateDisplay stringValue] UTF8String];
            
            int multiplicateInt = atoi(multiplicateString.c_str());
            
            if (multiplicateInt >= 1 && multiplicateInt <= 10){
                DIR *dir;
                struct dirent *dent;
                
                string entry;
                string cellFolderPath;
                
                dir = opendir(sourcePathNameHold.c_str());
                fileDeleteCount = 0;
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                            arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                        }
                    }
                    
                    closedir(dir);
                    
                    //----Directory Sort----
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                        [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                }
                
                int terminationFlag = 0;
                string extractedID = sourcePathNameHold;
                
                do{
                    
                    terminationFlag = 1;
                    
                    if ((int)extractedID.find("/") != -1){
                        extractedID = extractedID.substr(extractedID.find("/")+1);
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                string newFolderPath = destinationPathNameHold+"/"+extractedID+"-"+"new";
                
                mkdir(newFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                string sizeFindPath;
                string sizeFindPath2;
                
                struct stat sizeOfFile;
                
                string sequentialNo;
                int sequentialNoCount = 0;
                
                long sizeForCopy = 0;
                
                for (int counter3 = 0; counter3 < fileDeleteCount; counter3++){
                    sizeFindPath = sourcePathNameHold+"/"+arrayFileDelete [counter3];
                    
                    sequentialNo = to_string(sequentialNoCount);
                    
                    if (sequentialNo.length() == 1) sequentialNo = "0000"+sequentialNo;
                    else if (sequentialNo.length() == 2) sequentialNo = "000"+sequentialNo;
                    else if (sequentialNo.length() == 3) sequentialNo = "00"+sequentialNo;
                    else if (sequentialNo.length() == 4) sequentialNo = "0"+sequentialNo;
                    
                    sizeFindPath2 = newFolderPath+"/"+sequentialNo+"~"+arrayFileDelete [counter3];
                    
                    if (stat(sizeFindPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        ifstream infile (sizeFindPath.c_str(), ifstream::binary);
                        ofstream outfile (sizeFindPath2.c_str(), ofstream::binary);
                        
                        char* buffer = new char[sizeForCopy];
                        infile.read (buffer, sizeForCopy);
                        outfile.write (buffer, sizeForCopy);
                        delete[] buffer;
                        
                        outfile.close();
                        infile.close();
                        
                        sequentialNoCount = sequentialNoCount+multiplicateInt+1;
                    }
                }
                
                dir = opendir(newFolderPath.c_str());
                fileDeleteCount = 0;
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                            arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                        }
                    }
                    
                    closedir(dir);
                    
                    //----Directory Sort----
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                        [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                }
                
                int baseNumber = 0;
                int baseNumberIncrement = 0;
                
                for (int counter3 = 0; counter3 < fileDeleteCount; counter3++){
                    sizeFindPath = newFolderPath+"/"+arrayFileDelete [counter3];
                    baseNumber = atoi(arrayFileDelete [counter3].substr(0, 5).c_str());
                    
                    baseNumberIncrement = 0;
                    
                    for (int counter4 = 0; counter4 < multiplicateInt; counter4++){
                        baseNumberIncrement++;
                        
                        sequentialNo = to_string(baseNumber+baseNumberIncrement);
                        
                        if (sequentialNo.length() == 1) sequentialNo = "0000"+sequentialNo;
                        else if (sequentialNo.length() == 2) sequentialNo = "000"+sequentialNo;
                        else if (sequentialNo.length() == 3) sequentialNo = "00"+sequentialNo;
                        else if (sequentialNo.length() == 4) sequentialNo = "0"+sequentialNo;
                        
                        sizeFindPath2 = newFolderPath+"/"+sequentialNo+"~"+arrayFileDelete [counter3].substr(6);
                        
                        if (stat(sizeFindPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            ifstream infile (sizeFindPath.c_str(), ifstream::binary);
                            ofstream outfile (sizeFindPath2.c_str(), ofstream::binary);
                            
                            char* buffer = new char[sizeForCopy];
                            infile.read (buffer, sizeForCopy);
                            outfile.write (buffer, sizeForCopy);
                            delete[] buffer;
                            
                            outfile.close();
                            infile.close();
                        }
                    }
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Range: 1-10"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select Source/Destination Folder"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

@end
