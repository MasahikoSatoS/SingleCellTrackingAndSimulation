//
//  Processing2.h
//  FileConverter
//
//  Created by Masahiko Sato on 2018-06-14.
//
//

#ifndef PROCESSING2_H
#define PROCESSING2_H
#import "Controller.h"
#endif

@interface Processing2 : NSObject{
    IBOutlet NSTextField *contrastMeanDisplay;
    IBOutlet NSTextField *belowCutDisplay;
    IBOutlet NSTextField *aboveCutDisplay;
    IBOutlet NSTextField *valueBelowDisplay;
    IBOutlet NSTextField *valueMeanAboveDisplay;
    IBOutlet NSTextField *valueMeanBelowDisplay;
    IBOutlet NSTextField *valueFoldDisplay;
    IBOutlet NSTextField *rangeFromDisplay;
    IBOutlet NSTextField *rangeToDisplay;
    IBOutlet NSTextField *tiff16To8Display;
    
    IBOutlet NSTextField *body1;
    IBOutlet NSTextField *body2;
    IBOutlet NSTextField *body3;
    IBOutlet NSTextField *body4;
    IBOutlet NSTextField *body5;
    IBOutlet NSTextField *body6;
    IBOutlet NSTextField *body7;
    IBOutlet NSTextField *body8;
    
    IBOutlet NSTextField *multiplicateDisplay;
    
    IBOutlet NSProgressIndicator *backSave;
    
    id ascIIconversion;
    id singleTiffSave;
    id tiffFileRead;
    id processingOptions;
}

-(void)fileDeleteUpDate;

-(IBAction)tiffToTiff:(id)sender;
-(IBAction)imageSizeAdjust:(id)sender;
-(IBAction)fileDuplicate:(id)sender;
-(IBAction)multiplicate:(id)sender;

@end
