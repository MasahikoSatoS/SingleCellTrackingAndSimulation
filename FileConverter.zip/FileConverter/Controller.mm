//
//  Controller.mm
//  FileConverter
//
//  Created by Masahiko Sato on 11/07/17.
//  Copyright 2011 Masahiko Sato All rights reserved.
//

#import "Controller.h"

string pathNameString;
string sourcePathNameHold;
string destinationPathNameHold;
string fileSavePathHold;
int **arrayImageFileSave;
uint8_t *fileReadArray;

string *arrayFileDelete;
int fileDeleteCount;
int fileDeleteLimit;
string ascIIstring;
string fileNameHist;

int fovStatusHold;
int tiffReductionHold;
int contrastMeanHold;
int belowCutHold;
int aboveCutHold;
int valueBelowHold;
double meanAboveFoldHold;
double meanBelowFoldHold;
double valueFoldHold;
int rangeFromHold;
int rangeToHold;
int tiff16To8Hold;
int contrastActivateHold;
int backStartHold;
int to16SetHold;
int zPositionHold;
int nextValueHold;
int folderChangeHold;
int zPlaneNumberHold;
int bitNumberNumberHold;
int colorStatusHold;
int lowerHistHold;
int higherHistHold;
int currentFile;
int firstRead;
int backSaveOn;
int otherProcessOn;
int histDisplayCall;

int *wellFov1;
int *wellFov2;
int *wellFov3;
int *wellFov4;
int *wellFov5;
int *wellFov6;
int *wellFov7;
int *wellFov8;
string *wellNoTreatList;
int wellNoTreatListCount;

int *fovPosition;
int *histogramHold;

@implementation Controller

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSString *currentDirectoryPathNSString = [[NSBundle mainBundle] bundlePath];
        string userPathNameString = [currentDirectoryPathNSString cStringUsingEncoding:NSUTF8StringEncoding];
        
        if (userPathNameString.length() == 0) exit (0);
        else if ((int)userPathNameString.find("/Users/") == -1) exit (0);
        else{
            
            string pathName2 = userPathNameString.substr((unsigned long)userPathNameString.find("/Users/")+7);
            pathNameString = pathName2.substr(0, (unsigned long)pathName2.find("/"));
        }
        
        fluorescentSetHold = 0;
        fovStatusHold = 0;
        tiffReductionHold = 0;
        contrastMeanHold = -1;
        belowCutHold = -1;
        aboveCutHold = -1;
        valueBelowHold = -1;
        meanAboveFoldHold = -1;
        meanBelowFoldHold = -1;
        valueFoldHold = -1;
        rangeFromHold = -1;
        rangeToHold = -1;
        tiff16To8Hold = 0;
        backStartHold = 1;
        to16SetHold = 0;
        zPositionHold = 1;
        nextValueHold = 0;
        folderChangeHold = 0;
        histDisplayCall = 0;
        zPlaneNumberHold = 0;
        bitNumberNumberHold = 0;
        colorStatusHold = 0;
        firstRead = 0;
        backSaveOn = 0;
        otherProcessOn = 0;
        loadImageSizeDisplayCall = 0;
        
        sizeDisplayCall = 0;
        dimensionSelect = 0;
        colorGraySelect = 2;
        loadImageSizeDisplayCall = 0;
        
        sourcePathNameHold = "nil";
        destinationPathNameHold = "nil";
    }
    
    return self;
}

-(void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat xLength = screenRect.size.width;
    CGFloat yLength = screenRect.size.height;
    
    int mainControllerX = 717;
    
    NSRect windowSize = [controllerWindow frame];
    CGFloat windowWidth = windowSize.size.width;
    CGFloat windowHeight = windowSize.size.height;
    
    int displayPositionType = 0;
    
    if (80+mainControllerX+5+windowWidth+5+80 > xLength) displayPositionType = 1;
    
    CGFloat displayX;
    
    if (displayPositionType == 1) displayX = 550;
    else displayX = 80+mainControllerX+5;
    
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [controllerWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [contrastMeanDisplay setDelegate:self];
    [belowCutDisplay setDelegate:self];
    [aboveCutDisplay setDelegate:self];
    [valueBelowDisplay setDelegate:self];
    [valueFoldDisplay setDelegate:self];
    [rangeFromDisplay setDelegate:self];
    [rangeToDisplay setDelegate:self];
    [valueMeanAboveDisplay setDelegate:self];
    [valueMeanBelowDisplay setDelegate:self];
    [backStartDisplay setDelegate:self];
    [zPositionDisplay setDelegate:self];
    [imageSizeDisplay setDelegate:self];
    
    [imageSizeDisplay setStringValue:@"512"];
    
    //char 1byte, -128-+127
    //unsigned char 255, in the event that "char" is defined, it will be processed as "unsigned char"
    //unsigned int, 4 bytes, max 4294967295; int +-4294967295/2
    //unsigned long, unsigned long long, 8 bytes, max 9223372036854775807, use unsigned long; long, long long, +- 9223372036854775807/2
    //double 8 bytes, floating, max 9223372036854775807
}

-(void)applicationDidFinishLaunching:(NSNotification*)notification{
    arrayFileDelete = new string [100];
    fileDeleteCount = 0;
    fileDeleteLimit = 100;
    
    wellFov1 = new int [100];
    wellFov2 = new int [100];
    wellFov3 = new int [100];
    wellFov4 = new int [100];
    wellFov5 = new int [100];
    wellFov6 = new int [100];
    wellFov7 = new int [100];
    wellFov8 = new int [100];
    
    fovPosition = new int [200];
    
    int xPosition = 10+512*7;
    int yPosition = 10;
    int entryCount = 1;
    
    for (int counter2 = 1; counter2 <= 7; counter2++){
        for (int counter3 = 1; counter3 <= 7; counter3++){
            fovPosition [entryCount*2] = yPosition;
            fovPosition [entryCount*2+1] = xPosition;
            
            entryCount++;
            xPosition = xPosition-512;
        }
        
        yPosition = yPosition+512;
        xPosition = 10+512*7;
    }
    
    //for (int counterA = 1; counterA < entryCount; counterA++){
    //    cout<<" "<<fovPosition [counterA*2]<<" "<<fovPosition [counterA*2+1]<<" fovPosition"<<endl;
    //}
    
    histogramHold = new int [65537];
    wellNoTreatList = new string [100];
    
    controllerTimer = [NSTimer scheduledTimerWithTimeInterval:0.3 target:self selector:@selector(displayData) userInfo:nil repeats:YES];
}

-(void)displayData{
    if (histDisplayCall == 1){
        histDisplayCall = 0;
        
        [zPositionDisplay setIntegerValue:zPositionHold];
        [stepperSlice setIntegerValue: zPositionHold];
        
        [zNumberDisplay setIntegerValue:zPlaneNumberHold];
        [bitNoDisplay setIntegerValue:bitNumberNumberHold];
        
        if (colorStatusHold == 1 || colorStatusHold == 0) [colorStatusDisplay setStringValue:@"G"];
        else [colorStatusDisplay setStringValue:@"R"];
    }
    
    if (backSaveOn == 1){
        [backSave startAnimation:self];
        
        if (backSave) backSaveOn = 2;
    }
    else if (backSaveOn == 3){
        [backSave stopAnimation:self];
        
        if (backSave) backSaveOn = 0;
    }
    
    if (sizeDisplayCall == 1){
        [sourceImageSizeDisplay setStringValue:@(sizeDataString.c_str())];
        [newImageSizeDisplay setStringValue:@(sizeDataString2.c_str())];
        
        NSString *treatNSString = [sourceImageSizeDisplay stringValue];
        NSString *treatNSString2 = [newImageSizeDisplay stringValue];
        
        if (treatNSString != NULL){
            string treatString = [treatNSString UTF8String];
            string treatString2 = [treatNSString2 UTF8String];
            
            if (sizeDataString == treatString && sizeDataString2 == treatString2) sizeDisplayCall = 0;
        }
    }
    
    if (loadImageSizeDisplayCall == 1){
        [loadImageSizeDisplay setStringValue:@(loadSizeDataString.c_str())];
        [squareImageSizeDisplay setStringValue:@(loadSizeDataString2.c_str())];
        
        NSString *treatNSString = [loadImageSizeDisplay stringValue];
        NSString *treatNSString2 = [squareImageSizeDisplay stringValue];
        
        if (treatNSString != NULL){
            string treatString = [treatNSString UTF8String];
            string treatString2 = [treatNSString2 UTF8String];
            
            if (loadSizeDataString == treatString && loadSizeDataString2 == treatString2) sizeDisplayCall = 0;
        }
    }
}

-(void)controlTextDidChange:(NSNotification *)aNotification{
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == contrastMeanDisplay){
            if ([contrastMeanDisplay intValue] >= 0 && [contrastMeanDisplay intValue] <= 255){
                contrastMeanHold = [contrastMeanDisplay intValue];
            }
        }
        if ([aNotification object] == belowCutDisplay){
            if ([belowCutDisplay intValue] >= 0 && [belowCutDisplay intValue] <= 255){
                belowCutHold = [belowCutDisplay intValue];
            }
        }
        if ([aNotification object] == valueBelowDisplay){
            if ([valueBelowDisplay intValue] >= 0 && [valueBelowDisplay intValue] <= 255){
                valueBelowHold = [valueBelowDisplay intValue];
            }
        }
        if ([aNotification object] == aboveCutDisplay){
            if ([aboveCutDisplay intValue] >= 0 && [aboveCutDisplay intValue] <= 255){
                aboveCutHold = [aboveCutDisplay intValue];
            }
        }
        if ([aNotification object] == valueFoldDisplay){
            if ([valueFoldDisplay floatValue] >= -255 && [valueFoldDisplay floatValue] <= 255){
                valueFoldHold = [valueFoldDisplay floatValue];
            }
        }
        if ([aNotification object] == valueMeanAboveDisplay){
            if ([valueMeanAboveDisplay floatValue] >= -255 && [valueMeanAboveDisplay floatValue] <= 255){
                meanAboveFoldHold = [valueMeanAboveDisplay floatValue];
            }
        }
        if ([aNotification object] == valueMeanBelowDisplay){
            if ([valueMeanBelowDisplay floatValue] >= -255 && [valueMeanBelowDisplay floatValue] <= 255){
                meanBelowFoldHold = [valueMeanBelowDisplay floatValue];
            }
        }
        if ([aNotification object] == rangeFromDisplay){
            if ([rangeFromDisplay intValue] > 0 && [rangeFromDisplay intValue] <= 65535){
                rangeFromHold = [rangeFromDisplay intValue];
            }
        }
        if ([aNotification object] == rangeToDisplay){
            if ([rangeToDisplay intValue] > 0 && [rangeToDisplay intValue] <= 65535){
                rangeToHold = [rangeToDisplay intValue];
            }
        }
        if ([aNotification object] == backStartDisplay){
            if ([backStartDisplay intValue] > 0 && [backStartDisplay intValue] <= 99999){
                backStartHold = [backStartDisplay intValue];
            }
        }
        if ([aNotification object] == imageSizeDisplay){
            if ([imageSizeDisplay intValue] >= 100 && [imageSizeDisplay intValue] <= 100000){
                int imageSizeHold = [imageSizeDisplay intValue];
                
                int xPosition = 10+imageSizeHold*7;
                int yPosition = 10;
                int entryCount = 1;
                
                for (int counter2 = 1; counter2 <= 7; counter2++){
                    for (int counter3 = 1; counter3 <= 7; counter3++){
                        fovPosition [entryCount*2] = yPosition;
                        fovPosition [entryCount*2+1] = xPosition;
                        
                        entryCount++;
                        xPosition = xPosition-imageSizeHold;
                    }
                    
                    yPosition = yPosition+imageSizeHold;
                    xPosition = 10+imageSizeHold*7;
                }
            }
        }
    }
}

-(IBAction)selectFolderDirectory:(id)sender{
    if (otherProcessOn == 0){
        NSOpenPanel *openDlg = [NSOpenPanel openPanel];
        [openDlg setCanChooseFiles:NO];
        [openDlg setCanChooseDirectories:YES];
        [openDlg setCanCreateDirectories:YES];
        
        if ([openDlg runModal] == NSModalResponseOK){
            NSArray *files = [openDlg URLs];
            NSString *fileName = @"";
            
            for (NSURL *fileURL in files) {
                NSString *filePath = [fileURL path];
                fileName = [filePath stringByRemovingPercentEncoding];
            }
            
            string directoryPathExtract = [fileName UTF8String];
            
            if ((int)directoryPathExtract.find("/Volumes/") != -1){
                sourcePathNameHold = directoryPathExtract;
                folderChangeHold = 1;
                
                const char* cStr = sourcePathNameHold.c_str();
                NSString* nsStr = [NSString stringWithUTF8String:cStr];
                
                [sourcePathNameHoldDisplay setStringValue:nsStr];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else if ((int)directoryPathExtract.find("/Users/") != -1){
                sourcePathNameHold = directoryPathExtract;
                folderChangeHold = 1;
                
                const char* cStr = sourcePathNameHold.c_str();
                NSString* nsStr = [NSString stringWithUTF8String:cStr];
                
                [sourcePathNameHoldDisplay setStringValue:nsStr];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)selectDestinationFolderDirectory:(id)sender{
    if (otherProcessOn == 0){
        NSOpenPanel *openDlg = [NSOpenPanel openPanel];
        [openDlg setCanChooseFiles:NO];
        [openDlg setCanChooseDirectories:YES];
        [openDlg setCanCreateDirectories:YES];
        
        if ([openDlg runModal] == NSModalResponseOK){
            NSArray *files = [openDlg URLs];
            NSString *fileName = [[files objectAtIndex:0] absoluteString];
            
            string directoryPathExtract = [fileName UTF8String];
            
            if ((int)directoryPathExtract.find("/Volumes/") != -1){
                unsigned long directoryLength = directoryPathExtract.length();
                string extractedID = directoryPathExtract.substr(directoryPathExtract.find("/Volumes/"), directoryLength-directoryPathExtract.find("/Volumes/")-1);
                string extractedID2;
                
                int terminationFlag = 0;
                
                do{
                    
                    terminationFlag = 1;
                    
                    if ((int)extractedID.find("%20") != -1){
                        extractedID2 = extractedID.substr(0, extractedID.find("%20"));
                        extractedID = extractedID.substr(extractedID.find("%20")+3);
                        extractedID = extractedID2+" "+extractedID;
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                destinationPathNameHold = extractedID;
                
                [destinationPathNameHoldDisplay setStringValue:@(destinationPathNameHold.c_str())];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else if ((int)directoryPathExtract.find("/Users/") != -1){
                unsigned long directoryLength = directoryPathExtract.length();
                string extractedID = directoryPathExtract.substr(directoryPathExtract.find("/Users/"), directoryLength-directoryPathExtract.find("/Users/")-1);
                string extractedID2;
                
                int terminationFlag = 0;
                
                do{
                    
                    terminationFlag = 1;
                    
                    if ((int)extractedID.find("%20") != -1){
                        extractedID2 = extractedID.substr(0, extractedID.find("%20"));
                        extractedID = extractedID.substr(extractedID.find("%20")+3);
                        extractedID = extractedID2+" "+extractedID;
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                destinationPathNameHold = extractedID;
                
                [destinationPathNameHoldDisplay setStringValue:@(destinationPathNameHold.c_str())];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)multiToSingleTiff:(id)sender{
    /*
     Input file: Folder/###.tiff
     Output file: Folder-New/###/0001~###.tif
     
     Image will be converted into a square
     Gray 0: White will be converted into 0: black
     Color image will be converted into Gray scale image (8 bit). Calculate average of RGB
     Save as Small endian
     */
    
    if (otherProcessOn == 0){
        if (sourcePathNameHold != "nil" && destinationPathNameHold != "nil"){
            ifstream fin;
            fin.open(sourcePathNameHold.c_str(),ios::in);
            
            DIR *dir;
            struct dirent *dent;
            
            if (fin.is_open()){
                fin.close();
                
                dir = opendir(sourcePathNameHold.c_str());
                fileDeleteCount = 0;
                
                unsigned long totalFileSize = 0;
                
                if (dir != NULL){
                    string entry;
                    string pathName2;
                    
                    long sizeForCopy = 0;
                    
                    struct stat sizeOfFile;
                    
                    while((dent = readdir(dir))){
                        entry = dent -> d_name;
                        pathName2 = sourcePathNameHold+"/"+entry;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" && ((int)entry.find(".TIFF") != -1 || (int)entry.find(".Tiff") != -1 || (int)entry.find(".tiff") != -1 || (int)entry.find(".TIF") != -1 || (int)entry.find(".Tif") != -1 || (int)entry.find(".tif") != -1)){
                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                            arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                            
                            if (stat(pathName2.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                            }
                        }
                    }
                    
                    closedir(dir);
                    
                    //----Directory Sort----
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                        [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                }
                
                NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(destinationPathNameHold.c_str()) error:nil];
                unsigned long freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
                unsigned long refSize = (unsigned long)totalFileSize+1048576000; //----1Gb----
                
                if (freeSize > refSize){
                    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
                        otherProcessOn = 1;
                        backSaveOn = 1;
                        
                        int terminationFlag = 0;
                        string extractedID = sourcePathNameHold;
                        
                        do{
                            
                            terminationFlag = 1;
                            
                            if ((int)extractedID.find("/") != -1){
                                extractedID = extractedID.substr(extractedID.find("/")+1);
                            }
                            else terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                        
                        string newFolderPath = destinationPathNameHold+"/"+extractedID+"-"+"new";
                        
                        mkdir(newFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                        
                        //----Tiff reading----
                        unsigned long stripFirstAddress = 0;
                        unsigned long stripByteCountAddress = 0;
                        unsigned long nextAddress = 0;
                        unsigned long headPosition = 0;
                        unsigned long stripEntry = 0;
                        long sizeForCopy = 0;
                        
                        double xPosition = 0;
                        double yPosition = 0;
                        
                        int imageWidth = 0;
                        int imageHeight = 0;
                        int imageBit = 0; // Check 8, 16
                        int imageCompression = 0; // Check 1
                        int photoMetric = 0; //Check 0, 1, 2
                        int imageDimension = 0;
                        int dimensionAddition = 0;
                        int verticalBmp = 0;
                        int horizontalBmp = 0;
                        int horizontalBmpEntry = 0;
                        int sliceCount = 0;
                        int newImageDimension = 0;
                        int endianType = 0;
                        int samplePerPix = 0;
                        int dataConversion [4];
                        int mode = 0;
                        int processType = 2;
                        int numberOfLayers = 0;
                        
                        string sourceFileName;
                        string newFilePath;
                        string tiffExtensionHold;
                        string sliceString;
                        
                        struct stat sizeOfFile;
                        
                        ifstream fin2;
                        
                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            sourceFileName = sourcePathNameHold+"/"+arrayFileDelete [counter1];
                            newFilePath = newFolderPath+"/"+arrayFileDelete [counter1];
                            
                            tiffExtensionHold = "";
                            
                            if ((int)arrayFileDelete [counter1].find(".TIFF") != -1) tiffExtensionHold = ".TIFF";
                            else if ((int)arrayFileDelete [counter1].find(".Tiff") != -1) tiffExtensionHold = ".Tiff";
                            else if ((int)arrayFileDelete [counter1].find(".tiff") != -1) tiffExtensionHold = ".tiff";
                            else if ((int)arrayFileDelete [counter1].find(".TIF") != -1 ) tiffExtensionHold = ".TIF";
                            else if ((int)arrayFileDelete [counter1].find(".Tif") != -1) tiffExtensionHold = ".Tif";
                            else if ((int)arrayFileDelete [counter1].find(".tif") != -1) tiffExtensionHold = ".tif";
                            
                            newFilePath = newFolderPath+"/"+arrayFileDelete [counter1].substr(0, arrayFileDelete [counter1].find(tiffExtensionHold));
                            
                            //----File Read----
                            if (stat(sourceFileName.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                fileReadArray = new uint8_t [sizeForCopy+4];
                                fin2.open(sourceFileName.c_str(), ios::in | ios::binary);
                                
                                fin2.read((char*)fileReadArray, sizeForCopy+4);
                                fin2.close();
                                
                                dataConversion [0] = fileReadArray [0];
                                dataConversion [1] = fileReadArray [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                mkdir(newFilePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                
                                int *arrayExtractedImage3 = new int [100];
                                
                                sliceCount = 1;
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = fileReadArray [7];
                                    dataConversion [1] = fileReadArray [6];
                                    dataConversion [2] = fileReadArray [5];
                                    dataConversion [3] = fileReadArray [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = fileReadArray [4];
                                    dataConversion [1] = fileReadArray [5];
                                    dataConversion [2] = fileReadArray [6];
                                    dataConversion [3] = fileReadArray [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                do{
                                    
                                    imageDimension = 0;
                                    terminationFlag = 1;
                                    
                                    if (endianType == 1){
                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                        [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        
                                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                            if (imageWidth > imageHeight) imageDimension = imageWidth;
                                            else imageDimension = imageHeight;
                                            
                                            self->tiffFileRead = [[TiffFileRead alloc] init];
                                            delete [] arrayExtractedImage3;
                                            
                                            arrayExtractedImage3 = [self->tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                        }
                                    }
                                    else if (endianType == 0){
                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                        [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        
                                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                            if (imageWidth > imageHeight) imageDimension = imageWidth;
                                            else imageDimension = imageHeight;
                                            
                                            self->tiffFileRead = [[TiffFileRead alloc] init];
                                            delete [] arrayExtractedImage3;
                                            
                                            arrayExtractedImage3 = [self->tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                        }
                                    }
                                    
                                    if (imageDimension != 0){
                                        dimensionAddition = imageDimension%4;
                                        
                                        if (dimensionAddition == 1) dimensionAddition = 3;
                                        else if (dimensionAddition == 2) dimensionAddition = 2;
                                        else if (dimensionAddition == 3) dimensionAddition = 1;
                                        
                                        newImageDimension = imageDimension+dimensionAddition;
                                        
                                        self->sizeDataString = to_string(imageHeight)+" + "+ to_string(imageWidth);
                                        self->sizeDataString2 = to_string(newImageDimension)+" + "+ to_string(newImageDimension);
                                        
                                        self->sizeDisplayCall = 1;
                                        
                                        //----Saved image----
                                        arrayImageFileSave = new int *[newImageDimension+1];
                                        
                                        for (int counter3 = 0; counter3 < newImageDimension+1; counter3++){
                                            arrayImageFileSave [counter3] = new int [newImageDimension+1];
                                        }
                                        
                                        for (int counter3 = 0; counter3 < newImageDimension; counter3++){
                                            for (int counter4 = 0; counter4 < newImageDimension; counter4++){
                                                arrayImageFileSave [counter3][counter4] = 0;
                                            }
                                        }
                                        
                                        verticalBmp = 0;
                                        horizontalBmp = 0;
                                        horizontalBmpEntry = 0;
                                        
                                        for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                            if (verticalBmp < imageHeight){
                                                if (horizontalBmp < imageWidth){
                                                    arrayImageFileSave [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3];
                                                    horizontalBmp++;
                                                    horizontalBmpEntry++;
                                                }
                                                
                                                if (horizontalBmp == imageWidth && imageWidth < newImageDimension){
                                                    for (int counter4 = 0; counter4 < newImageDimension-imageWidth; counter4++){
                                                        arrayImageFileSave [verticalBmp][horizontalBmpEntry] = 0;
                                                        horizontalBmpEntry++;
                                                    }
                                                }
                                                
                                                if (horizontalBmp == imageWidth){
                                                    horizontalBmp = 0;
                                                    horizontalBmpEntry = 0;
                                                    verticalBmp++;
                                                }
                                            }
                                        }
                                        
                                        if (imageHeight < newImageDimension){
                                            for (int counter3 = imageHeight; counter3 < newImageDimension; counter3++){
                                                for (int counter4 = 0; counter4 < newImageDimension; counter4++){
                                                    arrayImageFileSave [counter3][counter4] = 0;
                                                }
                                            }
                                        }
                                        
                                        sliceString = to_string(sliceCount);
                                        
                                        if (sliceString.length() == 1) sliceString = "0000"+sliceString;
                                        else if (sliceString.length() == 2) sliceString = "000"+sliceString;
                                        else if (sliceString.length() == 3) sliceString = "00"+sliceString;
                                        else if (sliceString.length() == 4) sliceString = "0"+sliceString;
                                        
                                        fileSavePathHold = newFilePath+"/"+sliceString+"~"+arrayFileDelete [counter1].substr(0, arrayFileDelete [counter1].find(tiffExtensionHold))+".tif";
                                        
                                        sliceCount++;
                                        
                                        photoMetric = 1;
                                        
                                        if (xPosition == -1) xPosition = 100;
                                        if (yPosition == -1) yPosition = 100;
                                        
                                        self->singleTiffSave = [[SingleTiffSave alloc] init];
                                        [self->singleTiffSave singleTiffLayerSave:newImageDimension:newImageDimension:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:(unsigned long)mode];
                                        
                                        for (int counter3 = 0; counter3 < newImageDimension+1; counter3++){
                                            delete [] arrayImageFileSave [counter3];
                                        }
                                        
                                        delete [] arrayImageFileSave;
                                    }
                                    
                                    if (nextAddress != 0) headPosition = nextAddress;
                                    else terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                                
                                delete [] arrayExtractedImage3;
                                delete [] fileReadArray;
                            }
                        }
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        backSaveOn = 3;
                        otherProcessOn = 0;
                    });
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Disk Space Low"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select Source/Destination Folder"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)multiToMultiTiff:(id)sender{
    /*
     Input file: Folder/###.tiff
     Output file: Folder-New/###/0001~###.tif
     
     Image will be converted into a square
     Gray 0: White will be converted into 0: black
     Color image will be converted into Gray scale image (8 bit). Calculate average of RGB
     Save as Small endian
     */
    
    if (otherProcessOn == 0){
        if (sourcePathNameHold != "nil" && destinationPathNameHold != "nil"){
            string layerNoString = [[layerNoDisplay stringValue] UTF8String];
            int layerCombine = atoi(layerNoString.c_str());
            
            if (layerCombine >= 1 && layerCombine <= 1000){
                ifstream fin;
                fin.open(sourcePathNameHold.c_str(),ios::in);
                
                DIR *dir;
                struct dirent *dent;
                
                if (fin.is_open()){
                    fin.close();
                    
                    dir = opendir(sourcePathNameHold.c_str());
                    fileDeleteCount = 0;
                    
                    unsigned long totalFileSize = 0;
                    
                    if (dir != NULL){
                        string entry;
                        string pathName2;
                        
                        long sizeForCopy = 0;
                        struct stat sizeOfFile;
                        
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            pathName2 = sourcePathNameHold+"/"+entry;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store" && ((int)entry.find(".TIFF") != -1 || (int)entry.find(".Tiff") != -1 || (int)entry.find(".tiff") != -1 || (int)entry.find(".TIF") != -1 || (int)entry.find(".Tif") != -1 || (int)entry.find(".tif") != -1)){
                                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                                
                                if (stat(pathName2.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                                }
                            }
                        }
                        
                        closedir(dir);
                        
                        //----Directory Sort----
                        NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                        
                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                        }
                        
                        [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                        
                        for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                            arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                        }
                    }
                    
                    NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(destinationPathNameHold.c_str()) error:nil];
                    unsigned long freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
                    unsigned long refSize = (unsigned long)totalFileSize+1048576000; //----1Gb----
                    
                    if (freeSize > refSize){
                        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
                            otherProcessOn = 1;
                            backSaveOn = 1;
                            
                            int terminationFlag = 0;
                            string extractedID = sourcePathNameHold;
                            
                            do{
                                
                                terminationFlag = 1;
                                
                                if ((int)extractedID.find("/") != -1){
                                    extractedID = extractedID.substr(extractedID.find("/")+1);
                                }
                                else terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                            
                            string newFolderPath = destinationPathNameHold+"/"+extractedID+"-"+"new";
                            
                            mkdir(newFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                            
                            //----Tiff reading----
                            unsigned long stripFirstAddress = 0;
                            unsigned long stripByteCountAddress = 0;
                            unsigned long nextAddress = 0;
                            unsigned long headPosition = 0;
                            unsigned long stripEntry = 0;
                            unsigned long ifDPreviousHold = 0;
                            long sizeForCopy = 0;
                            
                            double xPosition = 0;
                            double yPosition = 0;
                            
                            int imageWidth = 0;
                            int imageHeight = 0;
                            int imageBit = 0; // Check 8, 16
                            int imageCompression = 0; // Check 1
                            int photoMetric = 0; //Check 0, 1, 2
                            int imageDimension = 0;
                            int dimensionAddition = 0;
                            int verticalBmp = 0;
                            int horizontalBmp = 0;
                            int horizontalBmpEntry = 0;
                            int sliceCount = 0;
                            int newImageDimension = 0;
                            int endianType = 0;
                            int samplePerPix = 0;
                            int loopCount = 0;
                            int dataConversion [4];
                            int mode = 0;
                            int processType = 2;
                            int numberOfLayers = 0;
                            
                            string sourceFileName;
                            string newFilePath;
                            string tiffExtensionHold;
                            string sliceString;
                            
                            struct stat sizeOfFile;
                            
                            ifstream fin2;
                            
                            if (layerCombine > 1) mode = 1;
                            
                            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                sourceFileName = sourcePathNameHold+"/"+arrayFileDelete [counter1];
                                newFilePath = newFolderPath+"/"+arrayFileDelete [counter1];
                                
                                tiffExtensionHold = "";
                                
                                if ((int)arrayFileDelete [counter1].find(".TIFF") != -1) tiffExtensionHold = ".TIFF";
                                else if ((int)arrayFileDelete [counter1].find(".Tiff") != -1) tiffExtensionHold = ".Tiff";
                                else if ((int)arrayFileDelete [counter1].find(".tiff") != -1) tiffExtensionHold = ".tiff";
                                else if ((int)arrayFileDelete [counter1].find(".TIF") != -1 ) tiffExtensionHold = ".TIF";
                                else if ((int)arrayFileDelete [counter1].find(".Tif") != -1) tiffExtensionHold = ".Tif";
                                else if ((int)arrayFileDelete [counter1].find(".tif") != -1) tiffExtensionHold = ".tif";
                                
                                newFilePath = newFolderPath+"/"+arrayFileDelete [counter1].substr(0, arrayFileDelete [counter1].find(tiffExtensionHold));
                                
                                //----File Read----
                                if (stat(sourceFileName.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    fileReadArray = new uint8_t [(int)sizeForCopy+4];
                                    fin2.open(sourceFileName.c_str(), ios::in | ios::binary);
                                    fin2.read((char*)fileReadArray, sizeForCopy+1);
                                    fin2.close();
                                    
                                    dataConversion [0] = fileReadArray [0];
                                    dataConversion [1] = fileReadArray [1];
                                    
                                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                    else endianType = 0;
                                    
                                    mkdir(newFilePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                    
                                    imageDimension = 0;
                                    
                                    int *arrayExtractedImage3 = new int [100];
                                    
                                    sliceCount = 1;
                                    headPosition = 0;
                                    
                                    if (endianType == 1){
                                        dataConversion [0] = fileReadArray [7];
                                        dataConversion [1] = fileReadArray [6];
                                        dataConversion [2] = fileReadArray [5];
                                        dataConversion [3] = fileReadArray [4];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    else if (endianType == 0){
                                        dataConversion [0] = fileReadArray [4];
                                        dataConversion [1] = fileReadArray [5];
                                        dataConversion [2] = fileReadArray [6];
                                        dataConversion [3] = fileReadArray [7];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    
                                    loopCount = 0;
                                    
                                    do{
                                        
                                        terminationFlag = 1;
                                        
                                        if (loopCount == 0){
                                            sliceString = to_string(sliceCount);
                                            
                                            if (sliceString.length() == 1) sliceString = "0000"+sliceString;
                                            else if (sliceString.length() == 2) sliceString = "000"+sliceString;
                                            else if (sliceString.length() == 3) sliceString = "00"+sliceString;
                                            else if (sliceString.length() == 4) sliceString = "0"+sliceString;
                                            
                                            fileSavePathHold = newFilePath+"/"+sliceString+"~"+arrayFileDelete [counter1].substr(0, arrayFileDelete [counter1].find(tiffExtensionHold))+".tif";
                                            
                                            sliceCount++;
                                            loopCount++;
                                            ifDPreviousHold = 0;
                                        }
                                        else if (loopCount < layerCombine){
                                            loopCount++;
                                        }
                                        else if (loopCount == layerCombine){
                                            sliceString = to_string(sliceCount);
                                            
                                            if (sliceString.length() == 1) sliceString = "0000"+sliceString;
                                            else if (sliceString.length() == 2) sliceString = "000"+sliceString;
                                            else if (sliceString.length() == 3) sliceString = "00"+sliceString;
                                            else if (sliceString.length() == 4) sliceString = "0"+sliceString;
                                            
                                            fileSavePathHold = newFilePath+"/"+sliceString+"~"+arrayFileDelete [counter1].substr(0, arrayFileDelete [counter1].find(tiffExtensionHold))+".tif";
                                            
                                            sliceCount++;
                                            loopCount = 1;
                                            ifDPreviousHold = 0;
                                        }
                                        
                                        if (endianType == 1){
                                            self->tiffFileRead = [[TiffFileRead alloc] init];
                                            [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                            
                                            if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                                if (imageWidth > imageHeight) imageDimension = imageWidth;
                                                else imageDimension = imageHeight;
                                                
                                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                                delete [] arrayExtractedImage3;
                                                
                                                arrayExtractedImage3 = [self->tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                            }
                                        }
                                        else if (endianType == 0){
                                            self->tiffFileRead = [[TiffFileRead alloc] init];
                                            [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                            
                                            if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                                if (imageWidth > imageHeight) imageDimension = imageWidth;
                                                else imageDimension = imageHeight;
                                                
                                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                                delete [] arrayExtractedImage3;
                                                
                                                arrayExtractedImage3 = [self->tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                            }
                                        }
                                        
                                        if (imageDimension != 0){
                                            dimensionAddition = imageDimension%4;
                                            
                                            if (dimensionAddition == 1) dimensionAddition = 3;
                                            else if (dimensionAddition == 2) dimensionAddition = 2;
                                            else if (dimensionAddition == 3) dimensionAddition = 1;
                                            
                                            newImageDimension = imageDimension+dimensionAddition;
                                            
                                            self->sizeDataString = to_string(imageHeight)+" + "+ to_string(imageWidth);
                                            self->sizeDataString2 = to_string(newImageDimension)+" + "+ to_string(newImageDimension);
                                            
                                            self->sizeDisplayCall = 1;
                                            
                                            arrayImageFileSave = new int *[newImageDimension+1];
                                            
                                            for (int counter3 = 0; counter3 < newImageDimension+1; counter3++){
                                                arrayImageFileSave [counter3] = new int [newImageDimension+1];
                                            }
                                            
                                            for (int counter3 = 0; counter3 < newImageDimension; counter3++){
                                                for (int counter4 = 0; counter4 < newImageDimension; counter4++){
                                                    arrayImageFileSave [counter3][counter4] = 0;
                                                }
                                            }
                                            
                                            verticalBmp = 0;
                                            horizontalBmp = 0;
                                            horizontalBmpEntry = 0;
                                            
                                            for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                                if (verticalBmp < imageHeight){
                                                    if (horizontalBmp < imageWidth){
                                                        arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3]);
                                                        horizontalBmp++;
                                                        horizontalBmpEntry++;
                                                    }
                                                    
                                                    if (horizontalBmp == imageWidth && imageWidth < newImageDimension){
                                                        for (int counter4 = 0; counter4 < newImageDimension-imageWidth; counter4++){
                                                            arrayImageFileSave [verticalBmp][horizontalBmpEntry] = 0;
                                                            horizontalBmpEntry++;
                                                        }
                                                    }
                                                    
                                                    if (horizontalBmp == imageWidth){
                                                        horizontalBmp = 0;
                                                        horizontalBmpEntry = 0;
                                                        verticalBmp++;
                                                    }
                                                }
                                            }
                                            
                                            if (imageHeight < newImageDimension){
                                                for (int counter3 = imageHeight; counter3 < newImageDimension; counter3++){
                                                    for (int counter4 = 0; counter4 < newImageDimension; counter4++){
                                                        arrayImageFileSave [counter3][counter4] = 0;
                                                    }
                                                }
                                            }
                                            
                                            photoMetric = 1;
                                            
                                            if (loopCount == 0 && nextAddress == 0) mode = 0;
                                            
                                            if (xPosition == -1) xPosition = 100;
                                            if (yPosition == -1) yPosition = 100;
                                            
                                            self->singleTiffSave = [[SingleTiffSave alloc] init];
                                            ifDPreviousHold = [self->singleTiffSave singleTiffLayerSave:newImageDimension:newImageDimension:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:ifDPreviousHold];
                                            
                                            for (int counter3 = 0; counter3 < newImageDimension+1; counter3++){
                                                delete [] arrayImageFileSave [counter3];
                                            }
                                            
                                            delete [] arrayImageFileSave;
                                        }
                                        
                                        if (nextAddress != 0) headPosition = nextAddress;
                                        else terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                    
                                    delete [] arrayExtractedImage3;
                                    delete [] fileReadArray;
                                }
                            }
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                            
                            backSaveOn = 3;
                            otherProcessOn = 0;
                        });
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Disk Space Low"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Range: 1-1000"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select Source/Destination Folder"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)singleToMultiTiff:(id)sender{
    /*
     Input file: Folder/###.tiff
     Output file: Folder-New/###/0001~###.tif
     
     Image will be converted into a square
     Gray 0: White will be converted into 0: black
     Color image will be converted into Gray scale image (8 bit). Calculate average of RGB
     Save as Small endian
     */
    
    if (otherProcessOn == 0){
        if (sourcePathNameHold != "nil" && destinationPathNameHold != "nil"){
            string layerNoString = [[layerNoDisplay2 stringValue] UTF8String];
            int layerCombine = atoi(layerNoString.c_str());
            
            if (layerCombine >= 1 && layerCombine <= 1000){
                ifstream fin;
                fin.open(sourcePathNameHold.c_str(),ios::in);
                
                DIR *dir;
                struct dirent *dent;
                
                if (fin.is_open()){
                    fin.close();
                    
                    dir = opendir(sourcePathNameHold.c_str());
                    fileDeleteCount = 0;
                    
                    unsigned long totalFileSize = 0;
                    
                    if (dir != NULL){
                        string entry;
                        string pathName2;
                        
                        long sizeForCopy = 0;
                        struct stat sizeOfFile;
                        
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            pathName2 = sourcePathNameHold+"/"+entry;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store" && ((int)entry.find(".TIFF") != -1 || (int)entry.find(".Tiff") != -1 || (int)entry.find(".tiff") != -1 || (int)entry.find(".TIF") != -1 || (int)entry.find(".Tif") != -1 || (int)entry.find(".tif") != -1)){
                                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                                
                                if (stat(pathName2.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                                }
                            }
                        }
                        
                        closedir(dir);
                        
                        //----Directory Sort----
                        NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                        
                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                        }
                        
                        [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                        
                        for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                            arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                        }
                    }
                    
                    if (fileDeleteCount >= 2){
                        if (layerCombine > fileDeleteCount) layerCombine = fileDeleteCount;
                        
                        NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(destinationPathNameHold.c_str()) error:nil];
                        unsigned long freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
                        unsigned long refSize = (unsigned long)totalFileSize+1048576000; //----1Gb----
                        
                        if (freeSize > refSize){
                            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
                                otherProcessOn = 1;
                                backSaveOn = 1;
                                
                                int terminationFlag = 0;
                                string extractedID = sourcePathNameHold;
                                
                                do{
                                    
                                    terminationFlag = 1;
                                    
                                    if ((int)extractedID.find("/") != -1){
                                        extractedID = extractedID.substr(extractedID.find("/")+1);
                                    }
                                    else terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                                
                                string newFolderPath = destinationPathNameHold+"/"+extractedID+"-"+"new";
                                
                                mkdir(newFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                
                                //----Tiff reading----
                                unsigned long stripFirstAddress = 0;
                                unsigned long stripByteCountAddress = 0;
                                unsigned long nextAddress = 0;
                                unsigned long headPosition = 0;
                                unsigned long stripEntry = 0;
                                unsigned long ifDPreviousHold = 0;
                                long sizeForCopy = 0;
                                
                                double xPosition = 0;
                                double yPosition = 0;
                                
                                int imageWidth = 0;
                                int imageHeight = 0;
                                int imageBit = 0; // Check 8, 16
                                int imageCompression = 0; // Check 1
                                int photoMetric = 0; //Check 0, 1, 2
                                int imageDimension = 0;
                                int dimensionAddition = 0;
                                int verticalBmp = 0;
                                int horizontalBmp = 0;
                                int horizontalBmpEntry = 0;
                                int sliceCount = 0;
                                int newImageDimension = 0;
                                int endianType = 0;
                                int samplePerPix = 0;
                                int loopCount = 0;
                                int dataConversion [4];
                                int mode = 0;
                                int processType = 3;
                                int numberOfLayers = 0;
                                int invertStatus = 0;
                                
                                string sourceFileName;
                                string newFilePath;
                                string tiffExtensionHold;
                                string sliceString;
                                
                                struct stat sizeOfFile;
                                
                                ifstream fin2;
                                
                                if (layerCombine > 1) mode = 1;
                                
                                if (self->colorGraySelect == 0 || self->colorGraySelect == 2) processType = 2;
                                
                                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                    sourceFileName = sourcePathNameHold+"/"+arrayFileDelete [counter1];
                                    
                                    tiffExtensionHold = "";
                                    
                                    if ((int)arrayFileDelete [counter1].find(".TIFF") != -1) tiffExtensionHold = ".TIFF";
                                    else if ((int)arrayFileDelete [counter1].find(".Tiff") != -1) tiffExtensionHold = ".Tiff";
                                    else if ((int)arrayFileDelete [counter1].find(".tiff") != -1) tiffExtensionHold = ".tiff";
                                    else if ((int)arrayFileDelete [counter1].find(".TIF") != -1 ) tiffExtensionHold = ".TIF";
                                    else if ((int)arrayFileDelete [counter1].find(".Tif") != -1) tiffExtensionHold = ".Tif";
                                    else if ((int)arrayFileDelete [counter1].find(".tif") != -1) tiffExtensionHold = ".tif";
                                    
                                    //----File Read----
                                    if (stat(sourceFileName.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                        
                                        fileReadArray = new uint8_t [(int)sizeForCopy+4];
                                        fin2.open(sourceFileName.c_str(), ios::in | ios::binary);
                                        
                                        fin2.read((char*)fileReadArray, sizeForCopy+1);
                                        fin2.close();
                                        
                                        dataConversion [0] = fileReadArray [0];
                                        dataConversion [1] = fileReadArray [1];
                                        
                                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                        else endianType = 0;
                                        
                                        if (endianType == 1){
                                            dataConversion [0] = fileReadArray [7];
                                            dataConversion [1] = fileReadArray [6];
                                            dataConversion [2] = fileReadArray [5];
                                            dataConversion [3] = fileReadArray [4];
                                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                        }
                                        else if (endianType == 0){
                                            dataConversion [0] = fileReadArray [4];
                                            dataConversion [1] = fileReadArray [5];
                                            dataConversion [2] = fileReadArray [6];
                                            dataConversion [3] = fileReadArray [7];
                                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                        }
                                        
                                        if (endianType == 1){ //----Big endian----
                                            self->tiffFileRead = [[TiffFileRead alloc] init];
                                            [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        }
                                        else if (endianType == 0){
                                            self->tiffFileRead = [[TiffFileRead alloc] init];
                                            [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        }
                                        
                                        if (numberOfLayers == 1){
                                            imageDimension = 0;
                                            headPosition = 0;
                                            
                                            int *arrayExtractedImage3 = new int [100];
                                            
                                            if (loopCount == 0){
                                                sliceString = to_string(sliceCount);
                                                
                                                if (sliceString.length() == 1) sliceString = "0000"+sliceString;
                                                else if (sliceString.length() == 2) sliceString = "000"+sliceString;
                                                else if (sliceString.length() == 3) sliceString = "00"+sliceString;
                                                else if (sliceString.length() == 4) sliceString = "0"+sliceString;
                                                
                                                fileSavePathHold = newFolderPath+"/"+sliceString+"~"+arrayFileDelete [counter1].substr(0, arrayFileDelete [counter1].find(tiffExtensionHold))+".tif";
                                                
                                                sliceCount++;
                                                loopCount++;
                                                ifDPreviousHold = 0;
                                            }
                                            else if (loopCount < layerCombine){
                                                loopCount++;
                                            }
                                            else if (loopCount == layerCombine){
                                                sliceString = to_string(sliceCount);
                                                
                                                if (sliceString.length() == 1) sliceString = "0000"+sliceString;
                                                else if (sliceString.length() == 2) sliceString = "000"+sliceString;
                                                else if (sliceString.length() == 3) sliceString = "00"+sliceString;
                                                else if (sliceString.length() == 4) sliceString = "0"+sliceString;
                                                
                                                fileSavePathHold = newFolderPath+"/"+sliceString+"~"+arrayFileDelete [counter1].substr(0, arrayFileDelete [counter1].find(tiffExtensionHold))+".tif";
                                                
                                                sliceCount++;
                                                loopCount = 1;
                                                ifDPreviousHold = 0;
                                            }
                                            
                                            if (endianType == 1){
                                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                                    if (imageWidth > imageHeight) imageDimension = imageWidth;
                                                    else imageDimension = imageHeight;
                                                    
                                                    self->tiffFileRead = [[TiffFileRead alloc] init];
                                                    delete [] arrayExtractedImage3;
                                                    
                                                    arrayExtractedImage3 = [self->tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                                }
                                            }
                                            else if (endianType == 0){
                                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                                    if (imageWidth > imageHeight) imageDimension = imageWidth;
                                                    else imageDimension = imageHeight;
                                                    
                                                    self->tiffFileRead = [[TiffFileRead alloc] init];
                                                    delete [] arrayExtractedImage3;
                                                    
                                                    arrayExtractedImage3 = [self->tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                                }
                                            }
                                            
                                            if (imageDimension != 0){
                                                dimensionAddition = imageDimension%4;
                                                
                                                if (dimensionAddition == 1) dimensionAddition = 3;
                                                else if (dimensionAddition == 2) dimensionAddition = 2;
                                                else if (dimensionAddition == 3) dimensionAddition = 1;
                                                
                                                newImageDimension = imageDimension+dimensionAddition;
                                                
                                                self->sizeDataString = to_string(imageHeight)+" + "+ to_string(imageWidth);
                                                self->sizeDataString2 = to_string(newImageDimension)+" + "+ to_string(newImageDimension);
                                                
                                                self->sizeDisplayCall = 1;
                                                
                                                arrayImageFileSave = new int *[newImageDimension+1];
                                                
                                                for (int counter3 = 0; counter3 < newImageDimension+1; counter3++){
                                                    arrayImageFileSave [counter3] = new int [newImageDimension*3+1];
                                                }
                                                
                                                for (int counter3 = 0; counter3 < newImageDimension; counter3++){
                                                    for (int counter4 = 0; counter4 < newImageDimension*3; counter4++){
                                                        arrayImageFileSave [counter3][counter4] = 0;
                                                    }
                                                }
                                                
                                                if (self->colorGraySelect == 0 || self->colorGraySelect == 2) photoMetric = 1;
                                                if (self->colorGraySelect == 0) invertStatus = 1;
                                                else invertStatus = 0;
                                                
                                                verticalBmp = 0;
                                                horizontalBmp = 0;
                                                horizontalBmpEntry = 0;
                                                
                                                if (self->dimensionSelect == 0){
                                                    for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                                        if (verticalBmp < imageHeight){
                                                            if (horizontalBmp < imageWidth){
                                                                if (photoMetric <= 1){
                                                                    if (invertStatus == 0) arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3]), horizontalBmpEntry++;
                                                                    else arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(255-arrayExtractedImage3 [counter3]), horizontalBmpEntry++;
                                                                }
                                                                else if (photoMetric == 2){
                                                                    arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3]), horizontalBmpEntry++;
                                                                    arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+1]), horizontalBmpEntry++;
                                                                    arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+2]), horizontalBmpEntry++;
                                                                }
                                                                
                                                                horizontalBmp++;
                                                            }
                                                            
                                                            if (horizontalBmp == imageWidth && imageWidth < newImageDimension){
                                                                for (int counter4 = 0; counter4 < newImageDimension-imageWidth; counter4++){
                                                                    if (photoMetric <= 1){
                                                                        arrayImageFileSave [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                    }
                                                                    else if (photoMetric == 2){
                                                                        arrayImageFileSave [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                        arrayImageFileSave [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                        arrayImageFileSave [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                    }
                                                                }
                                                            }
                                                            
                                                            if (horizontalBmp == imageWidth){
                                                                horizontalBmp = 0;
                                                                horizontalBmpEntry = 0;
                                                                verticalBmp++;
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (imageHeight < newImageDimension){
                                                        for (int counter3 = imageHeight; counter3 < newImageDimension; counter3++){
                                                            for (int counter4 = 0; counter4 < newImageDimension; counter4++){
                                                                if (photoMetric <= 1){
                                                                    arrayImageFileSave [counter3][counter4] = 0;
                                                                }
                                                                else if (photoMetric == 2){
                                                                    arrayImageFileSave [counter3][counter4] = 0;
                                                                    arrayImageFileSave [counter3][counter4] = 0;
                                                                    arrayImageFileSave [counter3][counter4] = 0;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                else{
                                                    
                                                    for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                                        if (horizontalBmp < imageWidth){
                                                            if (photoMetric <= 1){
                                                                if (invertStatus == 0) arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3]), horizontalBmpEntry++;
                                                                else arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(255-arrayExtractedImage3 [counter3]), horizontalBmpEntry++;
                                                            }
                                                            else if (photoMetric == 2){
                                                                arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3]), horizontalBmpEntry++;
                                                                arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+1]), horizontalBmpEntry++;
                                                                arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+2]), horizontalBmpEntry++;
                                                            }
                                                            
                                                            horizontalBmp++;
                                                        }
                                                        
                                                        if (horizontalBmp == imageWidth){
                                                            horizontalBmp = 0;
                                                            horizontalBmpEntry = 0;
                                                            verticalBmp++;
                                                        }
                                                    }
                                                }
                                                
                                                if (xPosition == -1) xPosition = 100;
                                                if (yPosition == -1) yPosition = 100;
                                                
                                                self->singleTiffSave = [[SingleTiffSave alloc] init];
                                                
                                                if (self->dimensionSelect == 0){
                                                    ifDPreviousHold = [self->singleTiffSave singleTiffLayerSave:newImageDimension:newImageDimension:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:ifDPreviousHold];
                                                }
                                                else{
                                                    
                                                    ifDPreviousHold = [self->singleTiffSave singleTiffLayerSave:imageWidth:imageHeight:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:ifDPreviousHold];
                                                }
                                                
                                                for (int counter3 = 0; counter3 < newImageDimension+1; counter3++){
                                                    delete [] arrayImageFileSave [counter3];
                                                }
                                                
                                                delete [] arrayImageFileSave;
                                            }
                                            
                                            delete [] arrayExtractedImage3;
                                        }
                                        
                                        delete [] fileReadArray;
                                    }
                                }
                                
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                                
                                backSaveOn = 3;
                                otherProcessOn = 0;
                            });
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Disk Space Low"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"No Of Files: < 2"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Range: 1-1000"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select Source/Destination Folder"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)fileNameReplace:(id)sender{
    if (otherProcessOn == 0){
        if (sourcePathNameHold != "nil"){
            string fileNameFromString = "";
            string fileNameToString = "";
            
            fileNameFromString = [[fileNameFromDisplay stringValue] UTF8String];
            fileNameToString = [[fileNameToDisplay stringValue] UTF8String];
            
            if (fileNameFromString != "" && fileNameToString != ""){
                if ((int)fileNameToString.find("%") == -1 && (int)fileNameToString.find("^") == -1 && (int)fileNameToString.find("@") == -1){
                    DIR *dir;
                    struct dirent *dent;
                    
                    string entry;
                    
                    dir = opendir(sourcePathNameHold.c_str());
                    
                    fileDeleteCount = 0;
                    
                    if (dir != NULL){
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                            }
                        }
                        
                        closedir(dir);
                        
                        //----Directory Sort----
                        NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                        
                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                        }
                        
                        [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                        
                        for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                            arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                        }
                    }
                    
                    string *arrayFileDelete2 = new string [fileDeleteCount+1];
                    int fileDeleteCount2 = 0;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                        if ((int)arrayFileDelete [counter2].find(fileNameFromString) != -1){
                            arrayFileDelete2 [fileDeleteCount2] = arrayFileDelete [counter2].substr(0, arrayFileDelete [counter2].find(fileNameFromString))+fileNameToString+arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find(fileNameFromString)+fileNameFromString.length()), fileDeleteCount2++;
                        }
                        else arrayFileDelete2 [fileDeleteCount2] = arrayFileDelete [counter2], fileDeleteCount2++;
                    }
                    
                    int matchFind = 0;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount2-1; counter2++){
                        for (int counter3 = counter2+1; counter3 < fileDeleteCount2; counter3++){
                            if (arrayFileDelete2 [counter2] == arrayFileDelete2 [counter3]){
                                matchFind = 1;
                                break;
                            }
                        }
                    }
                    
                    delete [] arrayFileDelete2;
                    
                    string sourcePath;
                    string destinationPath;
                    
                    if (matchFind == 0){
                        for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                            if ((int)arrayFileDelete [counter2].find(fileNameFromString) != -1){
                                sourcePath = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                                destinationPath = sourcePathNameHold+"/"+arrayFileDelete [counter2].substr(0, arrayFileDelete [counter2].find(fileNameFromString))+fileNameToString+arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find(fileNameFromString)+fileNameFromString.length());
                                
                                if (sourcePath != destinationPath){
                                    rename (sourcePath.c_str(), destinationPath.c_str());
                                }
                            }
                        }
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Removal Creates Files With The Same Names"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if ((int)fileNameToString.find("%") != -1 && (int)fileNameToString.find("^") != -1 && (int)fileNameToString.find("@") == -1){
                    DIR *dir;
                    struct dirent *dent;
                    
                    string entry;
                    
                    dir = opendir(sourcePathNameHold.c_str());
                    
                    fileDeleteCount = 0;
                    
                    if (dir != NULL){
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                            }
                        }
                        
                        closedir(dir);
                        
                        //----Directory Sort----
                        NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                        
                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                        }
                        
                        [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                        
                        for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                            arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                        }
                    }
                    
                    string frontString = fileNameToString.substr(0, fileNameToString.find("%"));
                    string behindString = fileNameToString.substr(fileNameToString.find("^")+1);
                    int lengthBetween = (int)fileNameToString.find("^")-(int)fileNameToString.find("%")-1;
                    
                    string frontFrom;
                    string behindFrom;
                    string middleFrom;
                    
                    if (lengthBetween == 2 || lengthBetween == 3 || lengthBetween == 4 || lengthBetween == 5){
                        string *arrayFileDelete2 = new string [fileDeleteCount+1];
                        int fileDeleteCount2 = 0;
                        
                        for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                            if ((int)arrayFileDelete [counter2].find(frontString) != -1 && (int)arrayFileDelete [counter2].find(behindString) != -1 && (int)arrayFileDelete [counter2].find(frontString) < (int)arrayFileDelete [counter2].find(behindString)){
                                frontFrom = arrayFileDelete [counter2].substr(0, arrayFileDelete [counter2].find(frontString)+frontString.length());
                                behindFrom = arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find(behindString));
                                middleFrom = arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find(frontString)+frontString.length(),arrayFileDelete [counter2].find(behindString)-(arrayFileDelete [counter2].find(frontString)+frontString.length()));
                                
                                if ((int)middleFrom.length() <= lengthBetween){
                                    if (lengthBetween == 2){
                                        if ((int)middleFrom.length() == 0) middleFrom = "00";
                                        else if ((int)middleFrom.length() == 1) middleFrom = "0"+middleFrom;
                                    }
                                    else if (lengthBetween == 3){
                                        if ((int)middleFrom.length() == 0) middleFrom = "000";
                                        else if ((int)middleFrom.length() == 1) middleFrom = "00"+middleFrom;
                                        else if ((int)middleFrom.length() == 2) middleFrom = "0"+middleFrom;
                                    }
                                    else if (lengthBetween == 4){
                                        if ((int)middleFrom.length() == 0) middleFrom = "0000";
                                        else if ((int)middleFrom.length() == 1) middleFrom = "000"+middleFrom;
                                        else if ((int)middleFrom.length() == 2) middleFrom = "00"+middleFrom;
                                        else if ((int)middleFrom.length() == 3) middleFrom = "0"+middleFrom;
                                    }
                                    else if (lengthBetween == 5){
                                        if ((int)middleFrom.length() == 0) middleFrom = "00000";
                                        else if ((int)middleFrom.length() == 1) middleFrom = "0000"+middleFrom;
                                        else if ((int)middleFrom.length() == 2) middleFrom = "000"+middleFrom;
                                        else if ((int)middleFrom.length() == 3) middleFrom = "00"+middleFrom;
                                        else if ((int)middleFrom.length() == 4) middleFrom = "0"+middleFrom;
                                    }
                                    
                                    arrayFileDelete2 [fileDeleteCount2] = frontFrom+middleFrom+behindFrom, fileDeleteCount2++;
                                }
                                else arrayFileDelete2 [fileDeleteCount2] = arrayFileDelete [counter2], fileDeleteCount2++;
                            }
                            else arrayFileDelete2 [fileDeleteCount2] = arrayFileDelete [counter2], fileDeleteCount2++;
                        }
                        
                        int matchFind = 0;
                        
                        for (int counter2 = 0; counter2 < fileDeleteCount2-1; counter2++){
                            for (int counter3 = counter2+1; counter3 < fileDeleteCount2; counter3++){
                                if (arrayFileDelete2 [counter2] == arrayFileDelete2 [counter3]){
                                    matchFind = 1;
                                    break;
                                }
                            }
                        }
                        
                        delete [] arrayFileDelete2;
                        
                        string sourcePath;
                        string destinationPath;
                        
                        if (matchFind == 0){
                            for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                                if ((int)arrayFileDelete [counter2].find(frontString) != -1 && (int)arrayFileDelete [counter2].find(behindString) != -1 && (int)arrayFileDelete [counter2].find(frontString) < (int)arrayFileDelete [counter2].find(behindString)){
                                    frontFrom = arrayFileDelete [counter2].substr(0, arrayFileDelete [counter2].find(frontString)+frontString.length());
                                    behindFrom = arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find(behindString));
                                    middleFrom = arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find(frontString)+frontString.length(), arrayFileDelete [counter2].find(behindString)-(arrayFileDelete [counter2].find(frontString)+frontString.length()));
                                    
                                    if ((int)middleFrom.length() <= lengthBetween){
                                        if (lengthBetween == 2){
                                            if ((int)middleFrom.length() == 0) middleFrom = "00";
                                            else if ((int)middleFrom.length() == 1) middleFrom = "0"+middleFrom;
                                        }
                                        else if (lengthBetween == 3){
                                            if ((int)middleFrom.length() == 0) middleFrom = "000";
                                            else if ((int)middleFrom.length() == 1) middleFrom = "00"+middleFrom;
                                            else if ((int)middleFrom.length() == 2) middleFrom = "0"+middleFrom;
                                        }
                                        else if (lengthBetween == 4){
                                            if ((int)middleFrom.length() == 0) middleFrom = "0000";
                                            else if ((int)middleFrom.length() == 1) middleFrom = "000"+middleFrom;
                                            else if ((int)middleFrom.length() == 2) middleFrom = "00"+middleFrom;
                                            else if ((int)middleFrom.length() == 3) middleFrom = "0"+middleFrom;
                                        }
                                        else if (lengthBetween == 5){
                                            if ((int)middleFrom.length() == 0) middleFrom = "00000";
                                            else if ((int)middleFrom.length() == 1) middleFrom = "0000"+middleFrom;
                                            else if ((int)middleFrom.length() == 2) middleFrom = "000"+middleFrom;
                                            else if ((int)middleFrom.length() == 3) middleFrom = "00"+middleFrom;
                                            else if ((int)middleFrom.length() == 4) middleFrom = "0"+middleFrom;
                                        }
                                        
                                        sourcePath = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                                        destinationPath = sourcePathNameHold+"/"+frontFrom+middleFrom+behindFrom;
                                        
                                        if (sourcePath != destinationPath){
                                            rename (sourcePath.c_str(), destinationPath.c_str());
                                        }
                                    }
                                }
                            }
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Will Create Files With Identical Names"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                }
                else if ((int)fileNameToString.find("%") != -1 && (int)fileNameToString.find("^") == -1 && (int)fileNameToString.find("@") != -1){
                    DIR *dir;
                    struct dirent *dent;
                    
                    string entry;
                    
                    dir = opendir(sourcePathNameHold.c_str());
                    
                    fileDeleteCount = 0;
                    
                    if (dir != NULL){
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                            }
                        }
                        
                        closedir(dir);
                        
                        //----Directory Sort----
                        NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                        
                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                        }
                        
                        [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                        
                        for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                            arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                        }
                    }
                    
                    string frontString = fileNameToString.substr(0, fileNameToString.find("%"));
                    string behindString = fileNameToString.substr(fileNameToString.find("@")+1);
                    string middleString = fileNameToString.substr(fileNameToString.find("%")+1, fileNameToString.find("@")-fileNameToString.find("%")-1);
                    
                    int lengthBetween = (int)fileNameToString.find("@")-(int)fileNameToString.find("%")-1;
                    
                    string middleString2 = "";
                    int startNumber = 0;
                    
                    for (int counter2 = 0; counter2 < lengthBetween; counter2++){
                        if (middleString.substr((unsigned long)counter2, 1) != "#"){
                            middleString2 = middleString.substr((unsigned long)counter2);
                            startNumber = atoi(middleString2.c_str());
                            break;
                        }
                    }
                    
                    string frontFrom;
                    string behindFrom;
                    string middleFrom;
                    
                    if (lengthBetween == 1 || lengthBetween == 2 || lengthBetween == 3 || lengthBetween == 4 || lengthBetween == 5){
                        string *arrayFileDelete2 = new string [fileDeleteCount+1];
                        int fileDeleteCount2 = 0;
                        
                        int numberCount = startNumber;
                        
                        for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                            if ((int)arrayFileDelete [counter2].find(frontString) != -1 && (int)arrayFileDelete [counter2].find(behindString) != -1 && (int)arrayFileDelete [counter2].find(frontString) < (int)arrayFileDelete [counter2].find(behindString)){
                                frontFrom = arrayFileDelete [counter2].substr(0, arrayFileDelete [counter2].find(frontString)+frontString.length());
                                behindFrom = arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find(behindString));
                                middleFrom = to_string(numberCount);
                                
                                if ((int)middleFrom.length() <= lengthBetween){
                                    if (lengthBetween == 2){
                                        if ((int)middleFrom.length() == 0) middleFrom = "00";
                                        else if ((int)middleFrom.length() == 1) middleFrom = "0"+middleFrom;
                                    }
                                    else if (lengthBetween == 3){
                                        if ((int)middleFrom.length() == 0) middleFrom = "000";
                                        else if ((int)middleFrom.length() == 1) middleFrom = "00"+middleFrom;
                                        else if ((int)middleFrom.length() == 2) middleFrom = "0"+middleFrom;
                                    }
                                    else if (lengthBetween == 4){
                                        if ((int)middleFrom.length() == 0) middleFrom = "0000";
                                        else if ((int)middleFrom.length() == 1) middleFrom = "000"+middleFrom;
                                        else if ((int)middleFrom.length() == 2) middleFrom = "00"+middleFrom;
                                        else if ((int)middleFrom.length() == 3) middleFrom = "0"+middleFrom;
                                    }
                                    else if (lengthBetween == 5){
                                        if ((int)middleFrom.length() == 0) middleFrom = "00000";
                                        else if ((int)middleFrom.length() == 1) middleFrom = "0000"+middleFrom;
                                        else if ((int)middleFrom.length() == 2) middleFrom = "000"+middleFrom;
                                        else if ((int)middleFrom.length() == 3) middleFrom = "00"+middleFrom;
                                        else if ((int)middleFrom.length() == 4) middleFrom = "0"+middleFrom;
                                    }
                                    
                                    arrayFileDelete2 [fileDeleteCount2] = frontFrom+middleFrom+behindFrom, fileDeleteCount2++;
                                    
                                    numberCount++;
                                }
                                else arrayFileDelete2 [fileDeleteCount2] = arrayFileDelete [counter2], fileDeleteCount2++;
                            }
                            else arrayFileDelete2 [fileDeleteCount2] = arrayFileDelete [counter2], fileDeleteCount2++;
                        }
                        
                        int matchFind = 0;
                        
                        for (int counter2 = 0; counter2 < fileDeleteCount2-1; counter2++){
                            for (int counter3 = counter2+1; counter3 < fileDeleteCount2; counter3++){
                                if (arrayFileDelete2 [counter2] == arrayFileDelete2 [counter3]){
                                    matchFind = 1;
                                    break;
                                }
                            }
                        }
                        
                        delete [] arrayFileDelete2;
                        
                        string sourcePath;
                        string destinationPath;
                        
                        if (matchFind == 0){
                            numberCount = startNumber;
                            
                            for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                                if ((int)arrayFileDelete [counter2].find(frontString) != -1 && (int)arrayFileDelete [counter2].find(behindString) != -1 && (int)arrayFileDelete [counter2].find(frontString) < (int)arrayFileDelete [counter2].find(behindString)){
                                    frontFrom = arrayFileDelete [counter2].substr(0, arrayFileDelete [counter2].find(frontString)+frontString.length());
                                    behindFrom = arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find(behindString));
                                    middleFrom = to_string(numberCount);
                                    
                                    if ((int)middleFrom.length() <= lengthBetween){
                                        if (lengthBetween == 2){
                                            if ((int)middleFrom.length() == 0) middleFrom = "00";
                                            else if ((int)middleFrom.length() == 1) middleFrom = "0"+middleFrom;
                                        }
                                        else if (lengthBetween == 3){
                                            if ((int)middleFrom.length() == 0) middleFrom = "000";
                                            else if ((int)middleFrom.length() == 1) middleFrom = "00"+middleFrom;
                                            else if ((int)middleFrom.length() == 2) middleFrom = "0"+middleFrom;
                                        }
                                        else if (lengthBetween == 4){
                                            if ((int)middleFrom.length() == 0) middleFrom = "0000";
                                            else if ((int)middleFrom.length() == 1) middleFrom = "000"+middleFrom;
                                            else if ((int)middleFrom.length() == 2) middleFrom = "00"+middleFrom;
                                            else if ((int)middleFrom.length() == 3) middleFrom = "0"+middleFrom;
                                        }
                                        else if (lengthBetween == 5){
                                            if ((int)middleFrom.length() == 0) middleFrom = "00000";
                                            else if ((int)middleFrom.length() == 1) middleFrom = "0000"+middleFrom;
                                            else if ((int)middleFrom.length() == 2) middleFrom = "000"+middleFrom;
                                            else if ((int)middleFrom.length() == 3) middleFrom = "00"+middleFrom;
                                            else if ((int)middleFrom.length() == 4) middleFrom = "0"+middleFrom;
                                        }
                                        
                                        sourcePath = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                                        destinationPath = sourcePathNameHold+"/"+frontFrom+middleFrom+behindFrom;
                                        
                                        if (sourcePath != destinationPath){
                                            rename (sourcePath.c_str(), destinationPath.c_str());
                                        }
                                        
                                        numberCount++;
                                    }
                                }
                            }
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Will Create Files With Identical Names"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select Source/Destination Folder"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)fileNameRemove:(id)sender{
    if (otherProcessOn == 0){
        if (sourcePathNameHold != "nil"){
            string fileNameFromString = "";
            fileNameFromString = [[fileNameFromDisplay stringValue] UTF8String];
            
            if (fileNameFromString != ""){
                if ((int)fileNameFromString.find("^") != -1 && (int)fileNameFromString.find("%") == -1 && (int)fileNameFromString.find("=") == -1 && (int)fileNameFromString.find("de/") == -1){
                    string targetString = fileNameFromString .substr(1);
                    
                    DIR *dir;
                    struct dirent *dent;
                    
                    string entry;
                    
                    dir = opendir(sourcePathNameHold.c_str());
                    
                    fileDeleteCount = 0;
                    
                    if (dir != NULL){
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                            }
                        }
                        
                        closedir(dir);
                        
                        //----Directory Sort----
                        NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                        
                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                        }
                        
                        [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                        
                        for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                            arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                        }
                    }
                    
                    string *arrayFileDelete2 = new string [fileDeleteCount+1];
                    int fileDeleteCount2 = 0;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                        if ((int)arrayFileDelete [counter2].find(targetString) != -1){
                            arrayFileDelete2 [fileDeleteCount2] = arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find(targetString)), fileDeleteCount2++;
                        }
                        else arrayFileDelete2 [fileDeleteCount2] = arrayFileDelete [counter2], fileDeleteCount2++;
                    }
                    
                    int matchFind = 0;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount2-1; counter2++){
                        for (int counter3 = counter2+1; counter3 < fileDeleteCount2; counter3++){
                            if (arrayFileDelete2 [counter2] == arrayFileDelete2 [counter3]){
                                matchFind = 1;
                                break;
                            }
                        }
                    }
                    
                    delete [] arrayFileDelete2;
                    
                    string sourcePath;
                    string destinationPath;
                    
                    if (matchFind == 0){
                        for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                            if ((int)arrayFileDelete [counter2].find(targetString) != -1){
                                sourcePath = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                                destinationPath = sourcePathNameHold+"/"+arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find(targetString));
                                
                                if (sourcePath != destinationPath){
                                    rename (sourcePath.c_str(), destinationPath.c_str());
                                }
                            }
                        }
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Removal Creates Files With The Same Names"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if ((int)fileNameFromString.find("^") == -1 && (int)fileNameFromString.find("%") == -1 && (int)fileNameFromString.find("=") == -1 && (int)fileNameFromString.find("de/") == -1){
                    DIR *dir;
                    struct dirent *dent;
                    
                    string entry;
                    
                    dir = opendir(sourcePathNameHold.c_str());
                    
                    fileDeleteCount = 0;
                    
                    if (dir != NULL){
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                            }
                        }
                        
                        closedir(dir);
                        
                        //----Directory Sort----
                        NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                        
                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                        }
                        
                        [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                        
                        for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                            arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                        }
                    }
                    
                    string *arrayFileDelete2 = new string [fileDeleteCount+1];
                    int fileDeleteCount2 = 0;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                        if ((int)arrayFileDelete [counter2].find(fileNameFromString) != -1){
                            arrayFileDelete2 [fileDeleteCount2] = arrayFileDelete [counter2].substr(0, arrayFileDelete [counter2].find(fileNameFromString))+arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find(fileNameFromString)+fileNameFromString.length()), fileDeleteCount2++;
                        }
                        else arrayFileDelete2 [fileDeleteCount2] = arrayFileDelete [counter2], fileDeleteCount2++;
                    }
                    
                    int matchFind = 0;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount2-1; counter2++){
                        for (int counter3 = counter2+1; counter3 < fileDeleteCount2; counter3++){
                            if (arrayFileDelete2 [counter2] == arrayFileDelete2 [counter3]){
                                matchFind = 1;
                                break;
                            }
                        }
                    }
                    
                    delete [] arrayFileDelete2;
                    
                    string sourcePath;
                    string destinationPath;
                    
                    if (matchFind == 0){
                        for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                            if ((int)arrayFileDelete [counter2].find(fileNameFromString) != -1){
                                sourcePath = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                                destinationPath = sourcePathNameHold+"/"+arrayFileDelete [counter2].substr(0, arrayFileDelete [counter2].find(fileNameFromString))+arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find(fileNameFromString)+fileNameFromString.length());
                                
                                if (sourcePath != destinationPath){
                                    rename (sourcePath.c_str(), destinationPath.c_str());
                                }
                            }
                        }
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Removal Creates Files With The Same Names"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if ((int)fileNameFromString.find("^") == -1 && (int)fileNameFromString.find("%") != -1 && (int)fileNameFromString.find("=") == -1 && (int)fileNameFromString.find("de/") == -1){
                    string targetString = fileNameFromString .substr(0, fileNameFromString.length()-1);
                    
                    DIR *dir;
                    struct dirent *dent;
                    
                    string entry;
                    
                    dir = opendir(sourcePathNameHold.c_str());
                    
                    fileDeleteCount = 0;
                    
                    if (dir != NULL){
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                            }
                        }
                        
                        closedir(dir);
                        
                        //----Directory Sort----
                        NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                        
                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                        }
                        
                        [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                        
                        for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                            arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                        }
                    }
                    
                    string *arrayFileDelete2 = new string [fileDeleteCount+1];
                    int fileDeleteCount2 = 0;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                        if ((int)arrayFileDelete [counter2].find(targetString) != -1){
                            arrayFileDelete2 [fileDeleteCount2] = arrayFileDelete [counter2].substr(0, arrayFileDelete [counter2].find(targetString)+targetString.length()), fileDeleteCount2++;
                        }
                        else arrayFileDelete2 [fileDeleteCount2] = arrayFileDelete [counter2], fileDeleteCount2++;
                    }
                    
                    int matchFind = 0;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount2-1; counter2++){
                        for (int counter3 = counter2+1; counter3 < fileDeleteCount2; counter3++){
                            if (arrayFileDelete2 [counter2] == arrayFileDelete2 [counter3]){
                                matchFind = 1;
                                break;
                            }
                        }
                    }
                    
                    delete [] arrayFileDelete2;
                    
                    string sourcePath;
                    string destinationPath;
                    
                    if (matchFind == 0){
                        for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                            if ((int)arrayFileDelete [counter2].find(targetString) != -1){
                                sourcePath = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                                destinationPath = sourcePathNameHold+"/"+arrayFileDelete [counter2].substr(0, arrayFileDelete [counter2].find(targetString)+targetString.length());
                                
                                if (sourcePath != destinationPath){
                                    rename (sourcePath.c_str(), destinationPath.c_str());
                                }
                            }
                        }
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Removal Creates Files With The Same Names"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if ((int)fileNameFromString.find("^") == -1 && (int)fileNameFromString.find("%") == -1 && (int)fileNameFromString.find("=") == -1 && (int)fileNameFromString.find("de/") != -1){
                    if (fileNameFromString.length() >= 4){
                        string targetString = fileNameFromString.substr(fileNameFromString.find("de/")+3);
                        int targetPosition = atoi(targetString.c_str());
                        
                        DIR *dir;
                        struct dirent *dent;
                        
                        string entry;
                        
                        dir = opendir(sourcePathNameHold.c_str());
                        
                        fileDeleteCount = 0;
                        
                        if (dir != NULL){
                            while((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                    arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                                }
                            }
                            
                            closedir(dir);
                            
                            //----Directory Sort----
                            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                            
                            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                            }
                            
                            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                            
                            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                                arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                            }
                        }
                        
                        string *arrayFileDelete2 = new string [fileDeleteCount+1];
                        int fileDeleteCount2 = 0;
                        
                        for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                            if ((int)arrayFileDelete [counter2].length() >= targetPosition){
                                arrayFileDelete2 [fileDeleteCount2] = arrayFileDelete [counter2].substr(0, (unsigned long)targetPosition-1)+arrayFileDelete [counter2].substr((unsigned long)targetPosition), fileDeleteCount2++;
                            }
                            else arrayFileDelete2 [fileDeleteCount2] = arrayFileDelete [counter2], fileDeleteCount2++;
                        }
                        
                        int matchFind = 0;
                        
                        for (int counter2 = 0; counter2 < fileDeleteCount2-1; counter2++){
                            for (int counter3 = counter2+1; counter3 < fileDeleteCount2; counter3++){
                                if (arrayFileDelete2 [counter2] == arrayFileDelete2 [counter3]){
                                    matchFind = 1;
                                    break;
                                }
                            }
                        }
                        
                        delete [] arrayFileDelete2;
                        
                        string sourcePath;
                        string destinationPath;
                        
                        if (matchFind == 0){
                            for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                                if ((int)arrayFileDelete [counter2].length() >= targetPosition){
                                    sourcePath = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                                    destinationPath = sourcePathNameHold+"/"+arrayFileDelete [counter2].substr(0, (unsigned long)targetPosition-1)+arrayFileDelete [counter2].substr((unsigned long)targetPosition);
                                    
                                    if (sourcePath != destinationPath){
                                        rename (sourcePath.c_str(), destinationPath.c_str());
                                    }
                                }
                            }
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Removal Creates Files With The Same Names"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                }
                else if ((int)fileNameFromString.find("^") == -1 && (int)fileNameFromString.find("%") != -1 && (int)fileNameFromString.find("=") != -1 && (int)fileNameFromString.find("de/") == -1){
                    string frontString = fileNameFromString.substr(0, fileNameFromString.find("%"));
                    string behindString = fileNameFromString.substr(fileNameFromString.find("=")+1);
                    
                    DIR *dir;
                    struct dirent *dent;
                    
                    string entry;
                    
                    dir = opendir(sourcePathNameHold.c_str());
                    
                    fileDeleteCount = 0;
                    
                    if (dir != NULL){
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                            }
                        }
                        
                        closedir(dir);
                        
                        //----Directory Sort----
                        NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                        
                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                        }
                        
                        [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                        
                        for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                            arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                        }
                    }
                    
                    string *arrayFileDelete2 = new string [fileDeleteCount+1];
                    int fileDeleteCount2 = 0;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                        if ((int)arrayFileDelete [counter2].find(frontString) != -1 && (int)arrayFileDelete [counter2].find(behindString) != -1 && (int)arrayFileDelete [counter2].find(frontString) < (int)arrayFileDelete [counter2].find(behindString)){
                            arrayFileDelete2 [fileDeleteCount2] = arrayFileDelete [counter2].substr(0, arrayFileDelete [counter2].find(frontString)+frontString.length())+arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find(behindString)), fileDeleteCount2++;
                        }
                        else arrayFileDelete2 [fileDeleteCount2] = arrayFileDelete [counter2], fileDeleteCount2++;
                    }
                    
                    int matchFind = 0;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount2-1; counter2++){
                        for (int counter3 = counter2+1; counter3 < fileDeleteCount2; counter3++){
                            if (arrayFileDelete2 [counter2] == arrayFileDelete2 [counter3]){
                                matchFind = 1;
                                break;
                            }
                        }
                    }
                    
                    delete [] arrayFileDelete2;
                    
                    string sourcePath;
                    string destinationPath;
                    
                    if (matchFind == 0){
                        for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                            if ((int)arrayFileDelete [counter2].find(frontString) != -1 && (int)arrayFileDelete [counter2].find(behindString) != -1 && (int)arrayFileDelete [counter2].find(frontString) < (int)arrayFileDelete [counter2].find(behindString)){
                                sourcePath = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                                destinationPath = sourcePathNameHold+"/"+arrayFileDelete [counter2].substr(0, arrayFileDelete [counter2].find(frontString)+frontString.length())+arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find(behindString));
                                
                                if (sourcePath != destinationPath){
                                    rename (sourcePath.c_str(), destinationPath.c_str());
                                }
                            }
                        }
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Removal Creates Files With The Same Names"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select Source/Destination Folder"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)fileNameInsert:(id)sender{
    if (otherProcessOn == 0){
        if (sourcePathNameHold != "nil"){
            string fileNameFromString = "";
            string fileNameToString = "";
            
            fileNameFromString = [[fileNameFromDisplay stringValue] UTF8String];
            fileNameToString = [[fileNameToDisplay stringValue] UTF8String];
            
            if (fileNameFromString != "" && fileNameToString != ""){
                if ((int)fileNameFromString.find("in/") != -1){
                    if (fileNameFromString.length() >= 4){
                        string targetString = fileNameFromString.substr(fileNameFromString.find("in/")+3);
                        int targetPosition = atoi(targetString.c_str());
                        
                        if (targetString == "T" && targetString != "L" && targetPosition == 0){
                            DIR *dir;
                            struct dirent *dent;
                            
                            string entry;
                            
                            dir = opendir(sourcePathNameHold.c_str());
                            
                            fileDeleteCount = 0;
                            
                            if (dir != NULL){
                                while((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                        arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                                    }
                                }
                                
                                closedir(dir);
                                
                                //----Directory Sort----
                                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                                
                                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                    [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                                }
                                
                                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                                
                                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                                    arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                                }
                            }
                            
                            string *arrayFileDelete2 = new string [fileDeleteCount+1];
                            int fileDeleteCount2 = 0;
                            
                            for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                                arrayFileDelete2 [fileDeleteCount2] = fileNameToString+arrayFileDelete [counter2], fileDeleteCount2++;
                            }
                            
                            int matchFind = 0;
                            
                            for (int counter2 = 0; counter2 < fileDeleteCount2-1; counter2++){
                                for (int counter3 = counter2+1; counter3 < fileDeleteCount2; counter3++){
                                    if (arrayFileDelete2 [counter2] == arrayFileDelete2 [counter3]){
                                        matchFind = 1;
                                        break;
                                    }
                                }
                            }
                            
                            delete [] arrayFileDelete2;
                            
                            string sourcePath;
                            string destinationPath;
                            
                            if (matchFind == 0){
                                for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                                    sourcePath = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                                    destinationPath = sourcePathNameHold+"/"+fileNameToString+arrayFileDelete [counter2];
                                    
                                    if (sourcePath != destinationPath){
                                        rename (sourcePath.c_str(), destinationPath.c_str());
                                    }
                                }
                                
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                            }
                            else{
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"Removal Creates Files With The Same Names"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                        else if (targetString != "T" && targetString == "L" && targetPosition == 0){
                            DIR *dir;
                            struct dirent *dent;
                            
                            string entry;
                            
                            dir = opendir(sourcePathNameHold.c_str());
                            
                            fileDeleteCount = 0;
                            
                            if (dir != NULL){
                                while((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                        arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                                    }
                                }
                                
                                closedir(dir);
                                
                                //----Directory Sort----
                                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                                
                                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                    [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                                }
                                
                                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                                
                                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                                    arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                                }
                            }
                            
                            string *arrayFileDelete2 = new string [fileDeleteCount+1];
                            int fileDeleteCount2 = 0;
                            
                            for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                                arrayFileDelete2 [fileDeleteCount2] = arrayFileDelete [counter2]+fileNameToString, fileDeleteCount2++;
                            }
                            
                            int matchFind = 0;
                            
                            for (int counter2 = 0; counter2 < fileDeleteCount2-1; counter2++){
                                for (int counter3 = counter2+1; counter3 < fileDeleteCount2; counter3++){
                                    if (arrayFileDelete2 [counter2] == arrayFileDelete2 [counter3]){
                                        matchFind = 1;
                                        break;
                                    }
                                }
                            }
                            
                            delete [] arrayFileDelete2;
                            
                            string sourcePath;
                            string destinationPath;
                            
                            if (matchFind == 0){
                                for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                                    sourcePath = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                                    destinationPath = sourcePathNameHold+"/"+arrayFileDelete [counter2]+fileNameToString;
                                    
                                    if (sourcePath != destinationPath){
                                        rename (sourcePath.c_str(), destinationPath.c_str());
                                    }
                                }
                                
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                            }
                            else{
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"Removal Creates Files With The Same Names"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                        else if (targetString != "T" && targetString != "L" && targetPosition > 0){
                            string targetString2 = fileNameFromString.substr(fileNameFromString.find("in/")+3);
                            int targetPosition2 = atoi(targetString2.c_str());
                            
                            DIR *dir;
                            struct dirent *dent;
                            
                            string entry;
                            
                            dir = opendir(sourcePathNameHold.c_str());
                            
                            fileDeleteCount = 0;
                            
                            if (dir != NULL){
                                while((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                        arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                                    }
                                }
                                
                                closedir(dir);
                                
                                //----Directory Sort----
                                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                                
                                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                    [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                                }
                                
                                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                                
                                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                                    arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                                }
                            }
                            
                            string *arrayFileDelete2 = new string [fileDeleteCount+1];
                            int fileDeleteCount2 = 0;
                            
                            for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                                if ((int)arrayFileDelete [counter2].length() >= targetPosition2){
                                    arrayFileDelete2 [fileDeleteCount2] = arrayFileDelete [counter2].substr(0, (unsigned long)targetPosition2-1)+fileNameToString+arrayFileDelete [counter2].substr((unsigned long)targetPosition2-1), fileDeleteCount2++;
                                }
                                else arrayFileDelete2 [fileDeleteCount2] = arrayFileDelete [counter2], fileDeleteCount2++;
                            }
                            
                            int matchFind = 0;
                            
                            for (int counter2 = 0; counter2 < fileDeleteCount2-1; counter2++){
                                for (int counter3 = counter2+1; counter3 < fileDeleteCount2; counter3++){
                                    if (arrayFileDelete2 [counter2] == arrayFileDelete2 [counter3]){
                                        matchFind = 1;
                                        break;
                                    }
                                }
                            }
                            
                            delete [] arrayFileDelete2;
                            
                            string sourcePath;
                            string destinationPath;
                            
                            if (matchFind == 0){
                                for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                                    if ((int)arrayFileDelete [counter2].length() >= targetPosition2){
                                        sourcePath = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                                        destinationPath = sourcePathNameHold+"/"+arrayFileDelete [counter2].substr(0, (unsigned long)targetPosition2-1)+fileNameToString+arrayFileDelete [counter2].substr((unsigned long)targetPosition2-1);
                                        
                                        if (sourcePath != destinationPath){
                                            rename (sourcePath.c_str(), destinationPath.c_str());
                                        }
                                    }
                                }
                                
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                            }
                            else{
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"Removal Creates Files With The Same Names"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                    }
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select Source/Destination Folder"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)fileReNumbering:(id)sender{
    if (otherProcessOn == 0){
        if (sourcePathNameHold != "nil" && destinationPathNameHold != "nil"){
            string renumberStartString = [[renumberStartDisplay stringValue] UTF8String];
            string renumberEveryString = [[renumberEveryDisplay stringValue] UTF8String];
            string renumberGapString = [[renumberGapDisplay stringValue] UTF8String];
            
            int renumberStart = atoi(renumberStartString.c_str());
            int renumberEvery = atoi(renumberEveryString.c_str());
            int renumberGap = atoi(renumberGapString.c_str());
            
            if (renumberStart <= 0) renumberStart = 1;
            if (renumberEvery <= 0) renumberEvery = 1;
            
            DIR *dir;
            struct dirent *dent;
            
            string entry;
            string cellFolderPath;
            
            dir = opendir(sourcePathNameHold.c_str());
            fileDeleteCount = 0;
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                        arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                    }
                }
                
                closedir(dir);
                
                //----Directory Sort----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                    [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                }
            }
            
            int typeCheck = 0;
            
            for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                if ((int)arrayFileDelete [counter2].find("_") != -1 && (int)arrayFileDelete [counter2].find("-") != -1 && (int)arrayFileDelete [counter2].find("FOV") != -1 && ((int)arrayFileDelete [counter2].find(".tif") != -1 || (int)arrayFileDelete [counter2].find(".TIF") != -1)){
                    typeCheck = 1;
                    break;
                }
                else if ((int)arrayFileDelete [counter2].find("STimage") != -1 && ((int)arrayFileDelete [counter2].find(".bmp") != -1 || (int)arrayFileDelete [counter2].find(".BMP") != -1)){
                    typeCheck = 2;
                    break;
                }
                else if ((int)arrayFileDelete [counter2].find("STimage") != -1 && ((int)arrayFileDelete [counter2].find(".tif") != -1 || (int)arrayFileDelete [counter2].find(".TIF") != -1)){
                    typeCheck = 3;
                    break;
                }
            }
            
            if (typeCheck == 1){
                int terminationFlag = 0;
                string extractedID = sourcePathNameHold;
                
                do{
                    
                    terminationFlag = 1;
                    
                    if ((int)extractedID.find("/") != -1){
                        extractedID = extractedID.substr(extractedID.find("/")+1);
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                string newFolderPath = destinationPathNameHold+"/"+extractedID+"-"+"new";
                
                mkdir(newFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                string sizeFindPath;
                string sizeFindPath2;
                
                for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                    if ((int)arrayFileDelete [counter2].find("_") != -1 && (int)arrayFileDelete [counter2].find("-") != -1 && (int)arrayFileDelete [counter2].find("FOV") != -1 && ((int)arrayFileDelete [counter2].find(".tif") || (int)arrayFileDelete [counter2].find(".TIF"))){
                        if ((int)arrayFileDelete [counter2].find("_") < (int)arrayFileDelete [counter2].find("-") && ((int)arrayFileDelete [counter2].find("-")-(int)arrayFileDelete [counter2].find("_"))-1 == 4){
                            sizeFindPath = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                            sizeFindPath2 = sourcePathNameHold+"/"+arrayFileDelete [counter2]+"~!A";
                            
                            arrayFileDelete [counter2] = arrayFileDelete [counter2]+"~!A";
                            rename (sizeFindPath.c_str(), sizeFindPath2.c_str());
                        }
                    }
                }
                
                int numberCount = renumberStart;
                int intervalCount = 0;
                int timePoint = 0;
                int timePoint2 = 0;
                string timeNumberString;
                string frontString;
                string behindString;
                
                for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                    if ((int)arrayFileDelete [counter2].find("~!A") != -1){
                        timePoint = atoi(arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find("_")+1, 4).c_str());
                        
                        for (int counter3 = 0; counter3 < 4; counter3++){
                            if (counter2+counter3 < fileDeleteCount){
                                timePoint2 = atoi(arrayFileDelete [counter2+counter3].substr(arrayFileDelete [counter2+counter3].find("_")+1, 4).c_str());
                                
                                if (timePoint == timePoint2){
                                    sizeFindPath = sourcePathNameHold+"/"+arrayFileDelete [counter2+counter3];
                                    timeNumberString = to_string(numberCount);
                                    
                                    if ((int)timeNumberString.length() == 1) timeNumberString = "000"+timeNumberString;
                                    else if ((int)timeNumberString.length() == 2) timeNumberString = "00"+timeNumberString;
                                    else if ((int)timeNumberString.length() == 3) timeNumberString = "0"+timeNumberString;
                                    else if ((int)timeNumberString.length() == 4) timeNumberString = timeNumberString;
                                    
                                    frontString = arrayFileDelete [counter2+counter3].substr(0, arrayFileDelete [counter2+counter3].find("_"));
                                    behindString = arrayFileDelete [counter2+counter3].substr(arrayFileDelete [counter2+counter3].find("-")+1);
                                    behindString = behindString.substr(0, behindString.length()-3);
                                    
                                    if ((int)arrayFileDelete [counter2+counter3].find(".tif") != -1){
                                        sizeFindPath2 = newFolderPath+"/"+frontString+"_"+timeNumberString+"-"+behindString; //========
                                    }
                                    else{
                                        
                                        sizeFindPath2 = newFolderPath+"/"+frontString+"_"+timeNumberString+"-"+behindString; //========
                                    }
                                    
                                    rename (sizeFindPath.c_str(), sizeFindPath2.c_str());
                                    
                                    arrayFileDelete [counter2+counter3] = arrayFileDelete [counter2+counter3].substr(0, arrayFileDelete [counter2+counter3].length()-3);
                                }
                            }
                        }
                        
                        intervalCount++;
                        numberCount++;
                        
                        if ((int)arrayFileDelete [counter2].find(".tif") != -1){
                            if (intervalCount == renumberEvery){
                                intervalCount = 0;
                                numberCount = numberCount+renumberGap;
                            }
                        }
                    }
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else if (typeCheck == 2){
                int terminationFlag = 0;
                string extractedID = sourcePathNameHold;
                
                do{
                    
                    terminationFlag = 1;
                    
                    if ((int)extractedID.find("/") != -1){
                        extractedID = extractedID.substr(extractedID.find("/")+1);
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                string newFolderPath = destinationPathNameHold+"/"+extractedID+"-"+"new";
                
                mkdir(newFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                string sizeFindPath;
                string sizeFindPath2;
                
                for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                    if ((int)arrayFileDelete [counter2].find("STimage") != -1){
                        sizeFindPath = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                        sizeFindPath2 = sourcePathNameHold+"/"+arrayFileDelete [counter2]+"~!A";
                        
                        arrayFileDelete [counter2] = arrayFileDelete [counter2]+"~!A";
                        rename (sizeFindPath.c_str(), sizeFindPath2.c_str());
                    }
                }
                
                int numberCount = renumberStart;
                int intervalCount = 0;
                int timePoint = 0;
                int timePoint2 = 0;
                string timeNumberString;
                string frontString;
                string behindString;
                
                for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                    if ((int)arrayFileDelete [counter2].find("~!A") != -1){
                        timePoint = atoi(arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find("STimage")+8, 4).c_str());
                        
                        for (int counter3 = 0; counter3 < 4; counter3++){
                            if (counter2+counter3 < fileDeleteCount){
                                timePoint2 = atoi(arrayFileDelete [counter2+counter3].substr(arrayFileDelete [counter2+counter3].find("STimage")+8, 4).c_str());
                                
                                if (timePoint == timePoint2){
                                    sizeFindPath = sourcePathNameHold+"/"+arrayFileDelete [counter2+counter3];
                                    timeNumberString = to_string(numberCount);
                                    
                                    if ((int)timeNumberString.length() == 1) timeNumberString = "000"+timeNumberString;
                                    else if ((int)timeNumberString.length() == 2) timeNumberString = "00"+timeNumberString;
                                    else if ((int)timeNumberString.length() == 3) timeNumberString = "0"+timeNumberString;
                                    else if ((int)timeNumberString.length() == 4) timeNumberString = timeNumberString;
                                    
                                    frontString = "STimage ";
                                    behindString = arrayFileDelete [counter2+counter3].substr(arrayFileDelete [counter2+counter3].find("STimage")+12);
                                    behindString = behindString.substr(0, behindString.length()-3);
                                    
                                    if ((int)arrayFileDelete [counter2+counter3].find(".bmp") != -1){
                                        sizeFindPath2 = newFolderPath+"/"+frontString+timeNumberString+behindString; //========
                                    }
                                    else{
                                        
                                        sizeFindPath2 = newFolderPath+"/"+frontString+timeNumberString+behindString; //========
                                    }
                                    
                                    rename (sizeFindPath.c_str(), sizeFindPath2.c_str());
                                    arrayFileDelete [counter2+counter3] = arrayFileDelete [counter2+counter3].substr(0, arrayFileDelete [counter2+counter3].length()-3);
                                }
                            }
                        }
                        
                        intervalCount++;
                        numberCount++;
                        
                        if ((int)arrayFileDelete [counter2].find(".bmp") != -1){
                            if (intervalCount == renumberEvery){
                                intervalCount = 0;
                                numberCount = numberCount+renumberGap;
                            }
                        }
                    }
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else if (typeCheck == 3){
                int terminationFlag = 0;
                string extractedID = sourcePathNameHold;
                
                do{
                    
                    terminationFlag = 1;
                    
                    if ((int)extractedID.find("/") != -1){
                        extractedID = extractedID.substr(extractedID.find("/")+1);
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                string newFolderPath = destinationPathNameHold+"/"+extractedID+"-"+"new";
                
                mkdir(newFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                string sizeFindPath;
                string sizeFindPath2;
                
                for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                    if ((int)arrayFileDelete [counter2].find("STimage") != -1){
                        sizeFindPath = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                        sizeFindPath2 = sourcePathNameHold+"/"+arrayFileDelete [counter2]+"~!A";
                        
                        arrayFileDelete [counter2] = arrayFileDelete [counter2]+"~!A";
                        rename (sizeFindPath.c_str(), sizeFindPath2.c_str());
                    }
                }
                
                int numberCount = renumberStart;
                int intervalCount = 0;
                int timePoint = 0;
                int timePoint2 = 0;
                string timeNumberString;
                string frontString;
                string behindString;
                
                for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                    if ((int)arrayFileDelete [counter2].find("~!A") != -1){
                        timePoint = atoi(arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find("STimage")+8, 4).c_str());
                        
                        for (int counter3 = 0; counter3 < 4; counter3++){
                            if (counter2+counter3 < fileDeleteCount){
                                timePoint2 = atoi(arrayFileDelete [counter2+counter3].substr(arrayFileDelete [counter2+counter3].find("STimage")+8, 4).c_str());
                                
                                if (timePoint == timePoint2){
                                    sizeFindPath = sourcePathNameHold+"/"+arrayFileDelete [counter2+counter3];
                                    timeNumberString = to_string(numberCount);
                                    
                                    if ((int)timeNumberString.length() == 1) timeNumberString = "000"+timeNumberString;
                                    else if ((int)timeNumberString.length() == 2) timeNumberString = "00"+timeNumberString;
                                    else if ((int)timeNumberString.length() == 3) timeNumberString = "0"+timeNumberString;
                                    else if ((int)timeNumberString.length() == 4) timeNumberString = timeNumberString;
                                    
                                    frontString = "STimage ";
                                    behindString = arrayFileDelete [counter2+counter3].substr(arrayFileDelete [counter2+counter3].find("STimage")+12);
                                    behindString = behindString.substr(0, behindString.length()-3);
                                    
                                    if ((int)arrayFileDelete [counter2+counter3].find(".tif") != -1){
                                        sizeFindPath2 = newFolderPath+"/"+frontString+timeNumberString+behindString; //========
                                    }
                                    else{
                                        
                                        sizeFindPath2 = newFolderPath+"/"+frontString+timeNumberString+behindString; //========
                                    }
                                    
                                    rename (sizeFindPath.c_str(), sizeFindPath2.c_str());
                                    arrayFileDelete [counter2+counter3] = arrayFileDelete [counter2+counter3].substr(0, arrayFileDelete [counter2+counter3].length()-3);
                                }
                            }
                        }
                        
                        intervalCount++;
                        numberCount++;
                        
                        if ((int)arrayFileDelete [counter2].find(".tif") != -1){
                            if (intervalCount == renumberEvery){
                                intervalCount = 0;
                                numberCount = numberCount+renumberGap;
                            }
                        }
                    }
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Tif/Bmp File Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select Source/Destination Folder"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)invertNo:(id)sender{
    if (otherProcessOn == 0){
        if (sourcePathNameHold != "nil" && destinationPathNameHold != "nil"){
            if (sourcePathNameHold != "nil"){
                DIR *dir;
                struct dirent *dent;
                
                string entry;
                string cellFolderPath;
                
                dir = opendir(sourcePathNameHold.c_str());
                fileDeleteCount = 0;
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                            arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                        }
                    }
                    
                    closedir(dir);
                    
                    //----Directory Sort----
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                        [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                }
                
                int typeCheck = 0;
                
                for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                    if ((int)arrayFileDelete [counter2].find("_") != -1 && (int)arrayFileDelete [counter2].find("-") != -1 && (int)arrayFileDelete [counter2].find("FOV") != -1 && ((int)arrayFileDelete [counter2].find(".tif") || (int)arrayFileDelete [counter2].find(".TIF"))){
                        typeCheck = 1;
                        break;
                    }
                    else if ((int)arrayFileDelete [counter2].find("STimage") != -1 && ((int)arrayFileDelete [counter2].find(".bmp") || (int)arrayFileDelete [counter2].find(".BMP"))){
                        typeCheck = 2;
                        break;
                    }
                    else if ((int)arrayFileDelete [counter2].find("STimage") != -1 && ((int)arrayFileDelete [counter2].find(".tif") || (int)arrayFileDelete [counter2].find(".TIF"))){
                        typeCheck = 3;
                        break;
                    }
                }
                
                if (typeCheck == 1){
                    int terminationFlag = 0;
                    string extractedID = sourcePathNameHold;
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        if ((int)extractedID.find("/") != -1){
                            extractedID = extractedID.substr(extractedID.find("/")+1);
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    string newFolderPath = destinationPathNameHold+"/"+extractedID+"-"+"new";
                    
                    mkdir(newFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    string sizeFindPath;
                    string sizeFindPath2;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                        if ((int)arrayFileDelete [counter2].find("_") != -1 && (int)arrayFileDelete [counter2].find("-") != -1 && (int)arrayFileDelete [counter2].find("FOV") != -1 && (int)arrayFileDelete [counter2].find(".tif") != -1){
                            if ((int)arrayFileDelete [counter2].find("_") < (int)arrayFileDelete [counter2].find("-") && ((int)arrayFileDelete [counter2].find("-")-(int)arrayFileDelete [counter2].find("_"))-1 == 4){
                                sizeFindPath = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                                sizeFindPath2 = sourcePathNameHold+"/"+arrayFileDelete [counter2]+"~!A";
                                
                                arrayFileDelete [counter2] = arrayFileDelete [counter2]+"~!A";
                                
                                rename (sizeFindPath.c_str(), sizeFindPath2.c_str());
                            }
                        }
                    }
                    
                    int maxTimePoint = 0;
                    int timePoint = 0;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                        if ((int)arrayFileDelete [counter2].find("~!A") != -1 && (int)arrayFileDelete [counter2].find(".tif") != -1){
                            timePoint = atoi(arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find("_")+1, 4).c_str());
                            
                            if (maxTimePoint < timePoint) maxTimePoint = timePoint;
                        }
                    }
                    
                    int numberCount = 0;
                    int timePoint2 = 0;
                    string timeNumberString;
                    string frontString;
                    string behindString;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                        if ((int)arrayFileDelete [counter2].find("~!A") != -1){
                            timePoint = atoi(arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find("_")+1, 4).c_str());
                            numberCount = (timePoint-maxTimePoint)*-1+1;
                            
                            for (int counter3 = 0; counter3 < 4; counter3++){
                                if (counter2+counter3 < fileDeleteCount && (int)arrayFileDelete [counter2+counter3].find("~!A") != -1){
                                    timePoint2 = atoi(arrayFileDelete [counter2+counter3].substr(arrayFileDelete [counter2+counter3].find("_")+1, 4).c_str());
                                    
                                    if (timePoint == timePoint2){
                                        sizeFindPath = sourcePathNameHold+"/"+arrayFileDelete [counter2+counter3];
                                        timeNumberString = to_string(numberCount);
                                        
                                        if ((int)timeNumberString.length() == 1) timeNumberString = "000"+timeNumberString;
                                        else if ((int)timeNumberString.length() == 2) timeNumberString = "00"+timeNumberString;
                                        else if ((int)timeNumberString.length() == 3) timeNumberString = "0"+timeNumberString;
                                        else if ((int)timeNumberString.length() == 4) timeNumberString = timeNumberString;
                                        
                                        frontString = arrayFileDelete [counter2+counter3].substr(0, arrayFileDelete [counter2+counter3].find("_"));
                                        behindString = arrayFileDelete [counter2+counter3].substr(arrayFileDelete [counter2+counter3].find("-")+1);
                                        behindString = behindString.substr(0, behindString.length()-3);
                                        
                                        sizeFindPath2 = newFolderPath+"/"+frontString+"_"+timeNumberString+"-"+behindString; //========
                                        
                                        rename (sizeFindPath.c_str(), sizeFindPath2.c_str());
                                        
                                        arrayFileDelete [counter2+counter3] = arrayFileDelete [counter2+counter3].substr(0, arrayFileDelete [counter2+counter3].length()-3)+"~!P";
                                    }
                                }
                            }
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                        if ((int)arrayFileDelete [counter2].find("~!P") == -1){
                            sizeFindPath = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                            sizeFindPath2 = newFolderPath+"/"+arrayFileDelete [counter2]; //========
                            rename (sizeFindPath.c_str(), sizeFindPath2.c_str());
                        }
                    }
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (typeCheck == 2){
                    int terminationFlag = 0;
                    string extractedID = sourcePathNameHold;
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        if ((int)extractedID.find("/") != -1){
                            extractedID = extractedID.substr(extractedID.find("/")+1);
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    string newFolderPath = destinationPathNameHold+"/"+extractedID+"-"+"new";
                    
                    mkdir(newFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    string sizeFindPath;
                    string sizeFindPath2;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                        if ((int)arrayFileDelete [counter2].find("STimage") != -1 && (int)arrayFileDelete [counter2].find("bmp") != -1){
                            sizeFindPath = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                            sizeFindPath2 = sourcePathNameHold+"/"+arrayFileDelete [counter2]+"~!A";
                            
                            arrayFileDelete [counter2] = arrayFileDelete [counter2]+"~!A";
                            rename (sizeFindPath.c_str(), sizeFindPath2.c_str());
                        }
                    }
                    
                    int maxTimePoint = 0;
                    int timePoint = 0;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                        if ((int)arrayFileDelete [counter2].find("~!A") != -1 && (int)arrayFileDelete [counter2].find(".bmp") != -1){
                            timePoint = atoi(arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find("STimage")+8, 4).c_str());
                            
                            if (maxTimePoint < timePoint) maxTimePoint = timePoint;
                        }
                    }
                    
                    int numberCount = 0;
                    int timePoint2 = 0;
                    string timeNumberString;
                    string frontString;
                    string behindString;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                        if ((int)arrayFileDelete [counter2].find("~!A") != -1){
                            timePoint = atoi(arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find("STimage")+8, 4).c_str());
                            
                            numberCount = (timePoint-maxTimePoint)*-1+1;
                            
                            for (int counter3 = 0; counter3 < 4; counter3++){
                                if (counter2+counter3 < fileDeleteCount && (int)arrayFileDelete [counter2+counter3].find("~!A") != -1){
                                    timePoint2 = atoi(arrayFileDelete [counter2+counter3].substr(arrayFileDelete [counter2+counter3].find("STimage")+8, 4).c_str());
                                    
                                    if (timePoint == timePoint2){
                                        sizeFindPath = sourcePathNameHold+"/"+arrayFileDelete [counter2+counter3];
                                        timeNumberString = to_string(numberCount);
                                        
                                        if ((int)timeNumberString.length() == 1) timeNumberString = "000"+timeNumberString;
                                        else if ((int)timeNumberString.length() == 2) timeNumberString = "00"+timeNumberString;
                                        else if ((int)timeNumberString.length() == 3) timeNumberString = "0"+timeNumberString;
                                        else if ((int)timeNumberString.length() == 4) timeNumberString = timeNumberString;
                                        
                                        frontString = "STimage ";
                                        behindString = arrayFileDelete [counter2+counter3].substr(arrayFileDelete [counter2+counter3].find("STimage")+12);
                                        behindString = behindString.substr(0, behindString.length()-3);
                                        
                                        sizeFindPath2 = newFolderPath+"/"+frontString+timeNumberString+behindString; //========
                                        
                                        rename (sizeFindPath.c_str(), sizeFindPath2.c_str());
                                        
                                        arrayFileDelete [counter2+counter3] = arrayFileDelete [counter2+counter3].substr(0, arrayFileDelete [counter2+counter3].length()-3)+"~P";
                                    }
                                }
                            }
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                        if ((int)arrayFileDelete [counter2].find("~!P") == -1){
                            sizeFindPath = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                            sizeFindPath2 = newFolderPath+"/"+arrayFileDelete [counter2]; //========
                            
                            rename (sizeFindPath.c_str(), sizeFindPath2.c_str());
                        }
                    }
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (typeCheck == 3){
                    int terminationFlag = 0;
                    string extractedID = sourcePathNameHold;
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        if ((int)extractedID.find("/") != -1){
                            extractedID = extractedID.substr(extractedID.find("/")+1);
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    string newFolderPath = destinationPathNameHold+"/"+extractedID+"-"+"new";
                    
                    mkdir(newFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    string sizeFindPath;
                    string sizeFindPath2;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                        if ((int)arrayFileDelete [counter2].find("STimage") != -1 && (int)arrayFileDelete [counter2].find("tif") != -1){
                            sizeFindPath = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                            sizeFindPath2 = sourcePathNameHold+"/"+arrayFileDelete [counter2]+"~!A";
                            
                            arrayFileDelete [counter2] = arrayFileDelete [counter2]+"~!A";
                            rename (sizeFindPath.c_str(), sizeFindPath2.c_str());
                        }
                    }
                    
                    int maxTimePoint = 0;
                    int timePoint = 0;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                        if ((int)arrayFileDelete [counter2].find("~!A") != -1 && (int)arrayFileDelete [counter2].find(".tif") != -1){
                            timePoint = atoi(arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find("STimage")+8, 4).c_str());
                            
                            if (maxTimePoint < timePoint) maxTimePoint = timePoint;
                        }
                    }
                    
                    int numberCount = 0;
                    int timePoint2 = 0;
                    string timeNumberString;
                    string frontString;
                    string behindString;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                        if ((int)arrayFileDelete [counter2].find("~!A") != -1){
                            timePoint = atoi(arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find("STimage")+8, 4).c_str());
                            
                            numberCount = (timePoint-maxTimePoint)*-1+1;
                            
                            for (int counter3 = 0; counter3 < 4; counter3++){
                                if (counter2+counter3 < fileDeleteCount && (int)arrayFileDelete [counter2+counter3].find("~!A") != -1){
                                    timePoint2 = atoi(arrayFileDelete [counter2+counter3].substr(arrayFileDelete [counter2+counter3].find("STimage")+8, 4).c_str());
                                    
                                    if (timePoint == timePoint2){
                                        sizeFindPath = sourcePathNameHold+"/"+arrayFileDelete [counter2+counter3];
                                        timeNumberString = to_string(numberCount);
                                        
                                        if ((int)timeNumberString.length() == 1) timeNumberString = "000"+timeNumberString;
                                        else if ((int)timeNumberString.length() == 2) timeNumberString = "00"+timeNumberString;
                                        else if ((int)timeNumberString.length() == 3) timeNumberString = "0"+timeNumberString;
                                        else if ((int)timeNumberString.length() == 4) timeNumberString = timeNumberString;
                                        
                                        frontString = "STimage ";
                                        behindString = arrayFileDelete [counter2+counter3].substr(arrayFileDelete [counter2+counter3].find("STimage")+12);
                                        behindString = behindString.substr(0, behindString.length()-3);
                                        
                                        sizeFindPath2 = newFolderPath+"/"+frontString+timeNumberString+behindString; //========
                                        
                                        rename (sizeFindPath.c_str(), sizeFindPath2.c_str());
                                        
                                        arrayFileDelete [counter2+counter3] = arrayFileDelete [counter2+counter3].substr(0, arrayFileDelete [counter2+counter3].length()-3)+"~P";
                                    }
                                }
                            }
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                        if ((int)arrayFileDelete [counter2].find("~!P") == -1){
                            sizeFindPath = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                            sizeFindPath2 = newFolderPath+"/"+arrayFileDelete [counter2]; //========
                            
                            rename (sizeFindPath.c_str(), sizeFindPath2.c_str());
                        }
                    }
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Tif/Bmp File Missing"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Body Name Or Interval Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select Source/Destination Folder"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)folderCombine:(id)sender{
    if (otherProcessOn == 0){
        if (sourcePathNameHold != "nil" && destinationPathNameHold != "nil"){
            DIR *dir;
            struct dirent *dent;
            
            string entry;
            string cellFolderPath;
            
            dir = opendir(sourcePathNameHold.c_str());
            fileDeleteCount = 0;
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                        arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                    }
                }
                
                closedir(dir);
                
                string *folderFileName = new string [fileDeleteCount+1];
                int folderFileNameCount = fileDeleteCount;
                
                //----Directory Sort----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                    [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    folderFileName [counter1] = [unsortedArray [counter1] UTF8String];
                }
                
                int terminationFlag = 0;
                string extractedID = sourcePathNameHold;
                
                do{
                    
                    terminationFlag = 1;
                    
                    if ((int)extractedID.find("/") != -1){
                        extractedID = extractedID.substr(extractedID.find("/")+1);
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                string newFolderPath = destinationPathNameHold+"/"+extractedID+"-"+"new";
                string newFolderPath2;
                
                mkdir(newFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                long sizeForCopy = 0;
                
                string newFilePath;
                string newFilePath2;
                string sequentialNo;
                string folderName2;
                string fileName2;
                string folderCount2;
                
                int sequentialNoCount = 0;
                int folderCount = 1;
                
                struct stat sizeOfFile;
                
                for (int counter2 = 0; counter2 < folderFileNameCount; counter2++){
                    newFilePath = sourcePathNameHold+"/"+folderFileName [counter2];
                    
                    dir = opendir(newFilePath.c_str());
                    fileDeleteCount = 0;
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                            }
                        }
                        
                        closedir(dir);
                        
                        //----Directory Sort----
                        NSMutableArray *unsortedArray2 = [[NSMutableArray alloc] init];
                        
                        for (int counter3 = 0; counter3 < fileDeleteCount; counter3++){
                            [unsortedArray2 addObject:@(arrayFileDelete [counter3].c_str())];
                        }
                        
                        [unsortedArray2 sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                        
                        for (NSUInteger counter3 = 0; counter3 < [unsortedArray2 count]; counter3++){
                            arrayFileDelete [counter3] = [unsortedArray2 [counter3] UTF8String];
                        }
                        
                        folderCount2 = to_string(folderCount);
                        
                        if (folderCount2.length() == 1) folderCount2 = "000"+folderCount2;
                        else if (folderCount2.length() == 2) folderCount2 = "00"+folderCount2;
                        else if (folderCount2.length() == 3) folderCount2 = "0"+folderCount2;
                        
                        sequentialNoCount = 1;
                        
                        for (int counter3 = 0; counter3 < fileDeleteCount; counter3++){
                            newFilePath2 = newFilePath+"/"+arrayFileDelete [counter3];
                            
                            sequentialNo = to_string(sequentialNoCount);
                            
                            if (sequentialNo.length() == 1) sequentialNo = "0000"+sequentialNo;
                            else if (sequentialNo.length() == 2) sequentialNo = "000"+sequentialNo;
                            else if (sequentialNo.length() == 3) sequentialNo = "00"+sequentialNo;
                            else if (sequentialNo.length() == 4) sequentialNo = "0"+sequentialNo;
                            
                            folderName2 = folderFileName [counter2].substr(0,9);
                            fileName2 = arrayFileDelete [counter3].substr(2);
                            
                            newFolderPath2 = newFolderPath+"/"+folderName2+"-"+folderCount2+"-"+sequentialNo+"~"+fileName2;
                            
                            if (stat(newFilePath2.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                ifstream infile (newFilePath2.c_str(), ifstream::binary);
                                ofstream outfile (newFolderPath2.c_str(), ofstream::binary);
                                
                                char* buffer = new char[sizeForCopy];
                                infile.read (buffer, sizeForCopy);
                                outfile.write (buffer, sizeForCopy);
                                delete[] buffer;
                                
                                outfile.close();
                                infile.close();
                                
                                sequentialNoCount++;
                            }
                        }
                        
                        folderCount++;
                    }
                }
                
                delete [] folderFileName;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select Source/Destination Folder"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)filePickUp:(id)sender{
    if (otherProcessOn == 0){
        if (sourcePathNameHold != "nil" && destinationPathNameHold != "nil"){
            string renumberStartString = [[pickUpStartDisplay stringValue] UTF8String];
            string renumberEveryString = [[pickUpEveryDisplay stringValue] UTF8String];
            
            int renumberStart = atoi(renumberStartString.c_str());
            int renumberEvery = atoi(renumberEveryString.c_str());
            
            if (renumberStart <= 0) renumberStart = 1;
            if (renumberEvery <= 0) renumberEvery = 1;
            
            DIR *dir;
            struct dirent *dent;
            
            string entry;
            string cellFolderPath;
            
            dir = opendir(sourcePathNameHold.c_str());
            fileDeleteCount = 0;
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                        arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                    }
                }
                
                closedir(dir);
                
                //----Directory Sort----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                    [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                }
            }
            
            int terminationFlag = 0;
            string extractedID = sourcePathNameHold;
            
            do{
                
                terminationFlag = 1;
                
                if ((int)extractedID.find("/") != -1){
                    extractedID = extractedID.substr(extractedID.find("/")+1);
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            string newFolderPath = destinationPathNameHold+"/"+extractedID+"-"+"new";
            
            mkdir(newFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            int numberCount = renumberStart-1;
            int pickUpFile = 0;
            
            for (int counter2 = numberCount; counter2 < fileDeleteCount; counter2++){
                if (pickUpFile == 0){
                    arrayFileDelete [counter2] = arrayFileDelete [counter2]+"~!A";
                    pickUpFile++;
                    
                    if (pickUpFile == renumberEvery) pickUpFile = 0;
                }
                else{
                    
                    pickUpFile++;
                    
                    if (pickUpFile == renumberEvery) pickUpFile = 0;
                }
            }
            
            string sizeFindPath;
            string sizeFindPath2;
            
            for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                if ((int)arrayFileDelete [counter2].find("~!A") != -1){
                    sizeFindPath = sourcePathNameHold+"/"+arrayFileDelete [counter2].substr(0, arrayFileDelete [counter2].length()-3);
                    sizeFindPath2 = newFolderPath+"/"+arrayFileDelete [counter2].substr(0, arrayFileDelete [counter2].length()-3);
                    
                    rename (sizeFindPath.c_str(), sizeFindPath2.c_str());
                }
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select Source/Destination Folder"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)keyPickUp:(id)sender{
    if (otherProcessOn == 0){
        if (sourcePathNameHold != "nil" && destinationPathNameHold != "nil"){
            string keyString = [[pickKeyDisplay stringValue] UTF8String];
            
            DIR *dir;
            struct dirent *dent;
            
            string entry;
            string cellFolderPath;
            
            dir = opendir(sourcePathNameHold.c_str());
            fileDeleteCount = 0;
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                        arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                    }
                }
                
                closedir(dir);
                
                //----Directory Sort----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                    [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                }
            }
            
            int terminationFlag = 0;
            string extractedID = sourcePathNameHold;
            
            do{
                
                terminationFlag = 1;
                
                if ((int)extractedID.find("/") != -1){
                    extractedID = extractedID.substr(extractedID.find("/")+1);
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            string newFolderPath = destinationPathNameHold+"/"+extractedID+"-"+"new";
            
            mkdir(newFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string sizeFindPath;
            string sizeFindPath2;
            
            for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                if ((int)arrayFileDelete [counter2].find(keyString) != -1){
                    sizeFindPath = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                    sizeFindPath2 = newFolderPath+"/"+arrayFileDelete [counter2];
                    
                    rename (sizeFindPath.c_str(), sizeFindPath2.c_str());
                }
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select Source/Destination Folder"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)conversionBmpToTif:(id)sender{
    //----Bit Map created by Cell Tracking software----Gray 8 bit, no compression, no Alpha----Convert to 8 bit Gray tiff----
    
    if (otherProcessOn == 0){
        if (sourcePathNameHold != "nil" && destinationPathNameHold != "nil"){
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
                otherProcessOn = 1;
                backSaveOn = 1;
                
                int imageWidth = 0;
                int imageHeight = 0;
                int headerType = 0;
                int fileType = 0;
                int bitPerPix = 0;
                int compressionType = 0;
                int bitRead [4];
                int bitData = 0;
                int imageDimensionCount = 0;
                int widthPadding = 0;
                int adjustedWidth = 0;
                int verticalOrientation = 0;
                int imageDimension = 0;
                int dimensionAddition = 0;
                int newImageDimension = 0;
                int readFlag = 0;
                int readFlag2 = 0;
                int readLimit = 0;
                int readAscII = 0;
                int imageBit = 0;
                int photoMetric = 0;
                int samplePerPix = 0;
                int mode = 0;
                
                double xPositionTF = 0;
                double yPositionTF = 0;
                
                unsigned long bitPosition = 0;
                unsigned long totalImageSize = 0;
                long sizeForCopy = 0;
                
                string xPositionAdjust;
                string yPositionAdjust;
                string readData;
                string fileNameExtract;
                string entry;
                string cellFolderPath;
                string sizeFindPath;
                string saveString;
                
                struct stat sizeOfFile;
                
                DIR *dir;
                struct dirent *dent;
                
                ifstream fin;
                
                dir = opendir(sourcePathNameHold.c_str());
                
                if (dir != NULL){
                    int terminationFlag = 0;
                    string extractedID = sourcePathNameHold;
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        if ((int)extractedID.find("/") != -1){
                            extractedID = extractedID.substr(extractedID.find("/")+1);
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    string newFolderPath = destinationPathNameHold+"/"+extractedID+"-"+"new";
                    mkdir(newFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    fileDeleteCount = 0;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (((int)entry.find(".bmp") != -1 || (int)entry.find(".BMP") != -1)){
                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                            arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                        }
                    }
                    
                    //----Directory Sort----
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                        [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                        sizeFindPath = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                        
                        imageWidth = 0;
                        imageHeight = 0;
                        headerType = 0;
                        fileType = 0;
                        bitPerPix = 0;
                        compressionType = 0;
                        
                        fin.open(sizeFindPath.c_str(),ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            bitPosition = 0;
                            
                            while ((bitData = fin.get()) != EOF){
                                if (bitPosition == 0) bitRead [0] = bitData;
                                if (bitPosition == 1){
                                    bitRead [1] = bitData;
                                    
                                    headerType = bitRead [1]*256+bitRead [0];
                                }
                                
                                if (bitPosition == 14) bitRead [0] = bitData;
                                if (bitPosition == 15) bitRead [1] = bitData;
                                if (bitPosition == 16) bitRead [2] = bitData;
                                if (bitPosition == 17){
                                    bitRead [3] = bitData;
                                    
                                    fileType = bitRead [3]*16777216+bitRead [2]*65536+bitRead [1]*256+bitRead [0];
                                }
                                
                                if (bitPosition == 18) bitRead [0] = bitData;
                                if (bitPosition == 19) bitRead [1] = bitData;
                                if (bitPosition == 20) bitRead [2] = bitData;
                                if (bitPosition == 21){
                                    bitRead [3] = bitData;
                                    
                                    imageWidth = bitRead [3]*16777216+bitRead [2]*65536+bitRead [1]*256+bitRead [0];
                                }
                                
                                if (bitPosition == 22) bitRead [0] = bitData;
                                if (bitPosition == 23) bitRead [1] = bitData;
                                if (bitPosition == 24) bitRead [2] = bitData;
                                if (bitPosition == 25){
                                    bitRead [3] = bitData;
                                    
                                    imageHeight = bitRead [3]*16777216+bitRead [2]*65536+bitRead [1]*256+bitRead [0];
                                }
                                
                                if (bitPosition == 28) bitRead [0] = bitData;
                                if (bitPosition == 29){
                                    bitRead [1] = bitData;
                                    
                                    bitPerPix = bitRead [1]*256+bitRead [0];
                                }
                                
                                if (bitPosition == 30) bitRead [0] = bitData;
                                if (bitPosition == 31) bitRead [1] = bitData;
                                if (bitPosition == 32) bitRead [2] = bitData;
                                if (bitPosition == 33){
                                    bitRead [3] = bitData;
                                    
                                    compressionType = bitRead [3]*16777216+bitRead [2]*65536+bitRead [1]*256+bitRead [0];
                                    break;
                                }
                                
                                bitPosition++;
                            }
                            
                            fin.close();
                        }
                        
                        //----Header 19778 = "BM", Header (14)+DIB(40)+Color palette (1024) = 1078----
                        if (headerType == 19778 && fileType == 40 && compressionType == 0 && bitPerPix >= 8 && imageWidth > 0 && imageHeight > 0){
                            verticalOrientation = 0;
                            
                            if (imageHeight < 0 ){
                                verticalOrientation = 1;
                                imageHeight = imageHeight*-1;
                            }
                            
                            widthPadding = 0;
                            adjustedWidth = imageWidth+widthPadding;
                            totalImageSize = 0;
                            
                            if (bitPerPix == 8){ //----+ Color table----
                                widthPadding = imageWidth%4;
                                adjustedWidth = imageWidth+widthPadding;
                                totalImageSize = (unsigned long)(adjustedWidth*imageHeight+1078);
                            }
                            else if (bitPerPix == 16){ //----2 byte----
                                widthPadding = (imageWidth*2)%4;
                                adjustedWidth = imageWidth*2+widthPadding;
                                totalImageSize = (unsigned long)(adjustedWidth*imageHeight+54);
                            }
                            else if (bitPerPix == 24){ //----3 byte----
                                widthPadding = (imageWidth*3)%4;
                                adjustedWidth = imageWidth*3+widthPadding;
                                totalImageSize = (unsigned long)(adjustedWidth*imageHeight+54);
                            }
                            else if (bitPerPix == 32){
                                widthPadding = (imageWidth*4)%4;
                                adjustedWidth = imageWidth*4+widthPadding;
                                totalImageSize = (unsigned long)(adjustedWidth*imageHeight+54);
                            }
                            
                            int **arrayExtractedImage = new int *[imageHeight+1];
                            
                            for (int counter3 = 0; counter3 < imageHeight+1; counter3++){
                                arrayExtractedImage [counter3] = new int [imageWidth+1];
                            }
                            
                            sizeForCopy = 0;
                            
                            if (stat(sizeFindPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            xPositionAdjust = "";
                            yPositionAdjust = "";
                            
                            if ((unsigned long)sizeForCopy > totalImageSize){ //----Read XY position information added at the end of Image bit----
                                fin.open(sizeFindPath.c_str(), ios::in | ios::binary);
                                fin.seekg((long)totalImageSize);
                                
                                readFlag = 0;
                                readFlag2 = 0;
                                readData = "";
                                readLimit = 0;
                                
                                self->ascIIconversion = [[ASCIIconversion alloc] init];
                                
                                do{
                                    
                                    terminationFlag = 1;
                                    readAscII = fin.get();
                                    
                                    if (readFlag == 1 && readAscII == 88){
                                        xPositionAdjust = readData;
                                        readFlag = 2;
                                    }
                                    
                                    if (readFlag == 0 && readAscII == 88) readFlag = 1;
                                    else if (readFlag == 1 && readAscII != 88){
                                        [self->ascIIconversion ascIIConversion2:readAscII];
                                        readData = readData+ascIIstring;
                                    }
                                    
                                    if (readFlag2 == 1 && readAscII == 89){
                                        yPositionAdjust = readData;
                                        readFlag2 = 2;
                                        
                                        terminationFlag = 0;
                                    }
                                    
                                    if (readFlag2 == 0 && readAscII == 89) readFlag2 = 1, readData = "";
                                    else if (readFlag2 == 1 && readAscII != 89){
                                        [self->ascIIconversion ascIIConversion2:readAscII];
                                        readData = readData+ascIIstring;
                                    }
                                    
                                    readLimit++;
                                    
                                    if (readLimit >= 100) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                                
                                fin.close();
                            }
                            
                            fileReadArray = new uint8_t [totalImageSize+1];
                            
                            fin.open(sizeFindPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)fileReadArray, (long)totalImageSize+1);
                                fin.close();
                                
                                imageDimensionCount = 0;
                                
                                if (bitPerPix == 8){
                                    for (int counter3 = imageHeight-1; counter3 >= 0; counter3--){
                                        for (int counter4 = 0; counter4 < imageWidth; counter4++){
                                            bitData = fileReadArray [1078+counter3*adjustedWidth+counter4];
                                            arrayExtractedImage [imageDimensionCount][counter4] = bitData;
                                        }
                                        
                                        imageDimensionCount++;
                                    }
                                }
                                else if (bitPerPix == 16){
                                    for (int counter3 = imageHeight-1; counter3 >= 0; counter3--){
                                        for (int counter4 = 0; counter4 < imageWidth; counter4++){
                                            bitData = fileReadArray [54+counter3*adjustedWidth+counter4*2];
                                            arrayExtractedImage [imageDimensionCount][counter4] = bitData;
                                        }
                                        
                                        imageDimensionCount++;
                                    }
                                }
                                else if (bitPerPix == 24){
                                    for (int counter3 = imageHeight-1; counter3 >= 0; counter3--){
                                        for (int counter4 = 0; counter4 < imageWidth; counter4++){
                                            bitData = fileReadArray [54+counter3*adjustedWidth+counter4*3];
                                            arrayExtractedImage [imageDimensionCount][counter4] = bitData;
                                        }
                                        
                                        imageDimensionCount++;
                                    }
                                }
                                else if (bitPerPix == 32){
                                    for (int counter3 = imageHeight-1; counter3 >= 0; counter3--){
                                        for (int counter4 = 0; counter4 < imageWidth; counter4++){
                                            bitData = fileReadArray [54+counter3*adjustedWidth+counter4*4];
                                            arrayExtractedImage [imageDimensionCount][counter4] = bitData;
                                        }
                                        
                                        imageDimensionCount++;
                                    }
                                }
                            }
                            
                            delete [] fileReadArray;
                            
                            if (imageWidth > imageHeight) imageDimension = imageWidth;
                            else imageDimension = imageHeight;
                            
                            dimensionAddition = imageDimension%4;
                            
                            if (dimensionAddition == 1) dimensionAddition = 3;
                            else if (dimensionAddition == 2) dimensionAddition = 2;
                            else if (dimensionAddition == 3) dimensionAddition = 1;
                            
                            newImageDimension = imageDimension+dimensionAddition;
                            
                            arrayImageFileSave = new int *[newImageDimension+1];
                            
                            for (int counter3 = 0; counter3 < newImageDimension+1; counter3++){
                                arrayImageFileSave [counter3] = new int [newImageDimension+1];
                            }
                            
                            for (int counter3 = 0; counter3 < newImageDimension; counter3++){
                                for (int counter4 = 0; counter4 < newImageDimension; counter4++){
                                    arrayImageFileSave [counter3][counter4] = 0;
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < imageHeight; counter3++){
                                for (int counter4 = 0; counter4 < imageWidth; counter4++){
                                    arrayImageFileSave [counter3][counter4] = arrayExtractedImage [counter3][counter4];
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < imageHeight+1; counter3++){
                                delete [] arrayExtractedImage [counter3];
                            }
                            
                            delete [] arrayExtractedImage;
                            
                            if (verticalOrientation == 0){
                                int **arrayExtractedImage4 = new int *[newImageDimension+1];
                                
                                for (int counter3 = 0; counter3 < newImageDimension+1; counter3++){
                                    arrayExtractedImage4 [counter3] = new int [newImageDimension+1];
                                }
                                
                                for (int counter3 = 0; counter3 < newImageDimension; counter3++){
                                    for (int counter4 = 0; counter4 < newImageDimension; counter4++){
                                        arrayExtractedImage4 [counter3][counter4] = 0;
                                    }
                                }
                                
                                for (int counter3 = newImageDimension-1; counter3 >= 0; counter3--){
                                    for (int counter4 = 0; counter4 < newImageDimension; counter4++){
                                        arrayExtractedImage4 [counter3][counter4] = arrayImageFileSave [counter3][counter4];
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < newImageDimension; counter3++){
                                    for (int counter4 = 0; counter4 < newImageDimension; counter4++){
                                        arrayImageFileSave [counter3][counter4] = arrayExtractedImage4 [counter3][counter4];
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < newImageDimension+1; counter3++){
                                    delete [] arrayExtractedImage4 [counter3];
                                }
                                
                                delete [] arrayExtractedImage4;
                            }
                            
                            fileNameExtract = "";
                            
                            if ((int)arrayFileDelete [counter2].find(".bmp") != -1){
                                fileNameExtract = arrayFileDelete [counter2].substr(0, arrayFileDelete [counter2].find(".bmp"));
                                fileSavePathHold = newFolderPath+"/"+fileNameExtract+".tif";
                            }
                            else  if ((int)arrayFileDelete [counter2].find(".BMP") != -1){
                                fileNameExtract = arrayFileDelete [counter2].substr(0, arrayFileDelete [counter2].find(".BMP"));
                                fileSavePathHold = newFolderPath+"/"+fileNameExtract+".TIF"+arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find(".BMP")+4);
                            }
                            
                            imageBit = 8;
                            photoMetric = 1;
                            samplePerPix = 1;
                            xPositionTF = atof(xPositionAdjust.c_str());
                            yPositionTF = atof(yPositionAdjust.c_str());
                            
                            self->singleTiffSave = [[SingleTiffSave alloc] init];
                            [self->singleTiffSave singleTiffLayerSave:newImageDimension:newImageDimension:imageBit:photoMetric:samplePerPix:xPositionTF:yPositionTF:mode:(unsigned long)mode];
                            
                            for (int counter3 = 0; counter3 < newImageDimension+1; counter3++){
                                delete [] arrayImageFileSave [counter3];
                            }
                            
                            delete [] arrayImageFileSave;
                        }
                    }
                    
                    closedir(dir);
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                backSaveOn = 3;
                otherProcessOn = 0;
            });
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select Source/Destination Folder"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)setWell1:(id)sender{
    for (int counter2 = 0; counter2 < 100; counter2++) wellFov1 [counter2] = 0;
    
    wellFov1 [1] = (int)[xyAssign17 integerValue];
    wellFov1 [2] = (int)[xyAssign16 integerValue];
    wellFov1 [3] = (int)[xyAssign15 integerValue];
    wellFov1 [4] = (int)[xyAssign14 integerValue];
    wellFov1 [5] = (int)[xyAssign13 integerValue];
    wellFov1 [6] = (int)[xyAssign12 integerValue];
    wellFov1 [7] = (int)[xyAssign11 integerValue];
    
    wellFov1 [8] = (int)[xyAssign27 integerValue];
    wellFov1 [9] = (int)[xyAssign26 integerValue];
    wellFov1 [10] = (int)[xyAssign25 integerValue];
    wellFov1 [11] = (int)[xyAssign24 integerValue];
    wellFov1 [12] = (int)[xyAssign23 integerValue];
    wellFov1 [13] = (int)[xyAssign22 integerValue];
    wellFov1 [14] = (int)[xyAssign21 integerValue];
    
    wellFov1 [15] = (int)[xyAssign37 integerValue];
    wellFov1 [16] = (int)[xyAssign36 integerValue];
    wellFov1 [17] = (int)[xyAssign35 integerValue];
    wellFov1 [18] = (int)[xyAssign34 integerValue];
    wellFov1 [19] = (int)[xyAssign33 integerValue];
    wellFov1 [20] = (int)[xyAssign32 integerValue];
    wellFov1 [21] = (int)[xyAssign31 integerValue];
    
    wellFov1 [22] = (int)[xyAssign47 integerValue];
    wellFov1 [23] = (int)[xyAssign46 integerValue];
    wellFov1 [24] = (int)[xyAssign45 integerValue];
    wellFov1 [25] = (int)[xyAssign44 integerValue];
    wellFov1 [26] = (int)[xyAssign43 integerValue];
    wellFov1 [27] = (int)[xyAssign42 integerValue];
    wellFov1 [28] = (int)[xyAssign41 integerValue];
    
    wellFov1 [29] = (int)[xyAssign57 integerValue];
    wellFov1 [30] = (int)[xyAssign56 integerValue];
    wellFov1 [31] = (int)[xyAssign55 integerValue];
    wellFov1 [32] = (int)[xyAssign54 integerValue];
    wellFov1 [33] = (int)[xyAssign53 integerValue];
    wellFov1 [34] = (int)[xyAssign52 integerValue];
    wellFov1 [35] = (int)[xyAssign51 integerValue];
    
    wellFov1 [36] = (int)[xyAssign67 integerValue];
    wellFov1 [37] = (int)[xyAssign66 integerValue];
    wellFov1 [38] = (int)[xyAssign65 integerValue];
    wellFov1 [39] = (int)[xyAssign64 integerValue];
    wellFov1 [40] = (int)[xyAssign63 integerValue];
    wellFov1 [41] = (int)[xyAssign62 integerValue];
    wellFov1 [42] = (int)[xyAssign61 integerValue];
    
    wellFov1 [43] = (int)[xyAssign77 integerValue];
    wellFov1 [44] = (int)[xyAssign76 integerValue];
    wellFov1 [45] = (int)[xyAssign75 integerValue];
    wellFov1 [46] = (int)[xyAssign74 integerValue];
    wellFov1 [47] = (int)[xyAssign73 integerValue];
    wellFov1 [48] = (int)[xyAssign72 integerValue];
    wellFov1 [49] = (int)[xyAssign71 integerValue];
    
    int fovCount = 0;
    
    for (int counter2 = 1; counter2 <= 49; counter2++){
        if (wellFov1 [counter2] != 0) fovCount++;
    }
    
    if (fovCount != 0) [dimension1 setIntegerValue: fovCount];
    else [dimension1 setStringValue:@"nil"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)setWell2:(id)sender{
    for (int counter2 = 0; counter2 < 100; counter2++) wellFov2 [counter2] = 0;
    
    wellFov2 [1] = (int)[xyAssign17 integerValue];
    wellFov2 [2] = (int)[xyAssign16 integerValue];
    wellFov2 [3] = (int)[xyAssign15 integerValue];
    wellFov2 [4] = (int)[xyAssign14 integerValue];
    wellFov2 [5] = (int)[xyAssign13 integerValue];
    wellFov2 [6] = (int)[xyAssign12 integerValue];
    wellFov2 [7] = (int)[xyAssign11 integerValue];
    
    wellFov2 [8] = (int)[xyAssign27 integerValue];
    wellFov2 [9] = (int)[xyAssign26 integerValue];
    wellFov2 [10] = (int)[xyAssign25 integerValue];
    wellFov2 [11] = (int)[xyAssign24 integerValue];
    wellFov2 [12] = (int)[xyAssign23 integerValue];
    wellFov2 [13] = (int)[xyAssign22 integerValue];
    wellFov2 [14] = (int)[xyAssign21 integerValue];
    
    wellFov2 [15] = (int)[xyAssign37 integerValue];
    wellFov2 [16] = (int)[xyAssign36 integerValue];
    wellFov2 [17] = (int)[xyAssign35 integerValue];
    wellFov2 [18] = (int)[xyAssign34 integerValue];
    wellFov2 [19] = (int)[xyAssign33 integerValue];
    wellFov2 [20] = (int)[xyAssign32 integerValue];
    wellFov2 [21] = (int)[xyAssign31 integerValue];
    
    wellFov2 [22] = (int)[xyAssign47 integerValue];
    wellFov2 [23] = (int)[xyAssign46 integerValue];
    wellFov2 [24] = (int)[xyAssign45 integerValue];
    wellFov2 [25] = (int)[xyAssign44 integerValue];
    wellFov2 [26] = (int)[xyAssign43 integerValue];
    wellFov2 [27] = (int)[xyAssign42 integerValue];
    wellFov2 [28] = (int)[xyAssign41 integerValue];
    
    wellFov2 [29] = (int)[xyAssign57 integerValue];
    wellFov2 [30] = (int)[xyAssign56 integerValue];
    wellFov2 [31] = (int)[xyAssign55 integerValue];
    wellFov2 [32] = (int)[xyAssign54 integerValue];
    wellFov2 [33] = (int)[xyAssign53 integerValue];
    wellFov2 [34] = (int)[xyAssign52 integerValue];
    wellFov2 [35] = (int)[xyAssign51 integerValue];
    
    wellFov2 [36] = (int)[xyAssign67 integerValue];
    wellFov2 [37] = (int)[xyAssign66 integerValue];
    wellFov2 [38] = (int)[xyAssign65 integerValue];
    wellFov2 [39] = (int)[xyAssign64 integerValue];
    wellFov2 [40] = (int)[xyAssign63 integerValue];
    wellFov2 [41] = (int)[xyAssign62 integerValue];
    wellFov2 [42] = (int)[xyAssign61 integerValue];
    
    wellFov2 [43] = (int)[xyAssign77 integerValue];
    wellFov2 [44] = (int)[xyAssign76 integerValue];
    wellFov2 [45] = (int)[xyAssign75 integerValue];
    wellFov2 [46] = (int)[xyAssign74 integerValue];
    wellFov2 [47] = (int)[xyAssign73 integerValue];
    wellFov2 [48] = (int)[xyAssign72 integerValue];
    wellFov2 [49] = (int)[xyAssign71 integerValue];
    
    int fovCount = 0;
    
    for (int counter2 = 1; counter2 <= 49; counter2++){
        if (wellFov2 [counter2] != 0) fovCount++;
    }
    
    if (fovCount != 0) [dimension2 setIntegerValue: fovCount];
    else [dimension2 setStringValue:@"nil"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)setWell3:(id)sender{
    for (int counter2 = 0; counter2 < 100; counter2++) wellFov3 [counter2] = 0;
    
    wellFov3 [1] = (int)[xyAssign17 integerValue];
    wellFov3 [2] = (int)[xyAssign16 integerValue];
    wellFov3 [3] = (int)[xyAssign15 integerValue];
    wellFov3 [4] = (int)[xyAssign14 integerValue];
    wellFov3 [5] = (int)[xyAssign13 integerValue];
    wellFov3 [6] = (int)[xyAssign12 integerValue];
    wellFov3 [7] = (int)[xyAssign11 integerValue];
    
    wellFov3 [8] = (int)[xyAssign27 integerValue];
    wellFov3 [9] = (int)[xyAssign26 integerValue];
    wellFov3 [10] = (int)[xyAssign25 integerValue];
    wellFov3 [11] = (int)[xyAssign24 integerValue];
    wellFov3 [12] = (int)[xyAssign23 integerValue];
    wellFov3 [13] = (int)[xyAssign22 integerValue];
    wellFov3 [14] = (int)[xyAssign21 integerValue];
    
    wellFov3 [15] = (int)[xyAssign37 integerValue];
    wellFov3 [16] = (int)[xyAssign36 integerValue];
    wellFov3 [17] = (int)[xyAssign35 integerValue];
    wellFov3 [18] = (int)[xyAssign34 integerValue];
    wellFov3 [19] = (int)[xyAssign33 integerValue];
    wellFov3 [20] = (int)[xyAssign32 integerValue];
    wellFov3 [21] = (int)[xyAssign31 integerValue];
    
    wellFov3 [22] = (int)[xyAssign47 integerValue];
    wellFov3 [23] = (int)[xyAssign46 integerValue];
    wellFov3 [24] = (int)[xyAssign45 integerValue];
    wellFov3 [25] = (int)[xyAssign44 integerValue];
    wellFov3 [26] = (int)[xyAssign43 integerValue];
    wellFov3 [27] = (int)[xyAssign42 integerValue];
    wellFov3 [28] = (int)[xyAssign41 integerValue];
    
    wellFov3 [29] = (int)[xyAssign57 integerValue];
    wellFov3 [30] = (int)[xyAssign56 integerValue];
    wellFov3 [31] = (int)[xyAssign55 integerValue];
    wellFov3 [32] = (int)[xyAssign54 integerValue];
    wellFov3 [33] = (int)[xyAssign53 integerValue];
    wellFov3 [34] = (int)[xyAssign52 integerValue];
    wellFov3 [35] = (int)[xyAssign51 integerValue];
    
    wellFov3 [36] = (int)[xyAssign67 integerValue];
    wellFov3 [37] = (int)[xyAssign66 integerValue];
    wellFov3 [38] = (int)[xyAssign65 integerValue];
    wellFov3 [39] = (int)[xyAssign64 integerValue];
    wellFov3 [40] = (int)[xyAssign63 integerValue];
    wellFov3 [41] = (int)[xyAssign62 integerValue];
    wellFov3 [42] = (int)[xyAssign61 integerValue];
    
    wellFov3 [43] = (int)[xyAssign77 integerValue];
    wellFov3 [44] = (int)[xyAssign76 integerValue];
    wellFov3 [45] = (int)[xyAssign75 integerValue];
    wellFov3 [46] = (int)[xyAssign74 integerValue];
    wellFov3 [47] = (int)[xyAssign73 integerValue];
    wellFov3 [48] = (int)[xyAssign72 integerValue];
    wellFov3 [49] = (int)[xyAssign71 integerValue];
    
    int fovCount = 0;
    
    for (int counter2 = 1; counter2 <= 49; counter2++){
        if (wellFov3 [counter2] != 0) fovCount++;
    }
    
    if (fovCount != 0) [dimension3 setIntegerValue: fovCount];
    else [dimension3 setStringValue:@"nil"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)setWell4:(id)sender{
    for (int counter2 = 0; counter2 < 100; counter2++) wellFov4 [counter2] = 0;
    
    wellFov4 [1] = (int)[xyAssign17 integerValue];
    wellFov4 [2] = (int)[xyAssign16 integerValue];
    wellFov4 [3] = (int)[xyAssign15 integerValue];
    wellFov4 [4] = (int)[xyAssign14 integerValue];
    wellFov4 [5] = (int)[xyAssign13 integerValue];
    wellFov4 [6] = (int)[xyAssign12 integerValue];
    wellFov4 [7] = (int)[xyAssign11 integerValue];
    
    wellFov4 [8] = (int)[xyAssign27 integerValue];
    wellFov4 [9] = (int)[xyAssign26 integerValue];
    wellFov4 [10] = (int)[xyAssign25 integerValue];
    wellFov4 [11] = (int)[xyAssign24 integerValue];
    wellFov4 [12] = (int)[xyAssign23 integerValue];
    wellFov4 [13] = (int)[xyAssign22 integerValue];
    wellFov4 [14] = (int)[xyAssign21 integerValue];
    
    wellFov4 [15] = (int)[xyAssign37 integerValue];
    wellFov4 [16] = (int)[xyAssign36 integerValue];
    wellFov4 [17] = (int)[xyAssign35 integerValue];
    wellFov4 [18] = (int)[xyAssign34 integerValue];
    wellFov4 [19] = (int)[xyAssign33 integerValue];
    wellFov4 [20] = (int)[xyAssign32 integerValue];
    wellFov4 [21] = (int)[xyAssign31 integerValue];
    
    wellFov4 [22] = (int)[xyAssign47 integerValue];
    wellFov4 [23] = (int)[xyAssign46 integerValue];
    wellFov4 [24] = (int)[xyAssign45 integerValue];
    wellFov4 [25] = (int)[xyAssign44 integerValue];
    wellFov4 [26] = (int)[xyAssign43 integerValue];
    wellFov4 [27] = (int)[xyAssign42 integerValue];
    wellFov4 [28] = (int)[xyAssign41 integerValue];
    
    wellFov4 [29] = (int)[xyAssign57 integerValue];
    wellFov4 [30] = (int)[xyAssign56 integerValue];
    wellFov4 [31] = (int)[xyAssign55 integerValue];
    wellFov4 [32] = (int)[xyAssign54 integerValue];
    wellFov4 [33] = (int)[xyAssign53 integerValue];
    wellFov4 [34] = (int)[xyAssign52 integerValue];
    wellFov4 [35] = (int)[xyAssign51 integerValue];
    
    wellFov4 [36] = (int)[xyAssign67 integerValue];
    wellFov4 [37] = (int)[xyAssign66 integerValue];
    wellFov4 [38] = (int)[xyAssign65 integerValue];
    wellFov4 [39] = (int)[xyAssign64 integerValue];
    wellFov4 [40] = (int)[xyAssign63 integerValue];
    wellFov4 [41] = (int)[xyAssign62 integerValue];
    wellFov4 [42] = (int)[xyAssign61 integerValue];
    
    wellFov4 [43] = (int)[xyAssign77 integerValue];
    wellFov4 [44] = (int)[xyAssign76 integerValue];
    wellFov4 [45] = (int)[xyAssign75 integerValue];
    wellFov4 [46] = (int)[xyAssign74 integerValue];
    wellFov4 [47] = (int)[xyAssign73 integerValue];
    wellFov4 [48] = (int)[xyAssign72 integerValue];
    wellFov4 [49] = (int)[xyAssign71 integerValue];
    
    int fovCount = 0;
    
    for (int counter2 = 1; counter2 <= 49; counter2++){
        if (wellFov4 [counter2] != 0) fovCount++;
    }
    
    if (fovCount != 0) [dimension4 setIntegerValue: fovCount];
    else [dimension4 setStringValue:@"nil"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)setWell5:(id)sender{
    for (int counter2 = 0; counter2 < 100; counter2++) wellFov5 [counter2] = 0;
    
    wellFov5 [1] = (int)[xyAssign17 integerValue];
    wellFov5 [2] = (int)[xyAssign16 integerValue];
    wellFov5 [3] = (int)[xyAssign15 integerValue];
    wellFov5 [4] = (int)[xyAssign14 integerValue];
    wellFov5 [5] = (int)[xyAssign13 integerValue];
    wellFov5 [6] = (int)[xyAssign12 integerValue];
    wellFov5 [7] = (int)[xyAssign11 integerValue];
    
    wellFov5 [8] = (int)[xyAssign27 integerValue];
    wellFov5 [9] = (int)[xyAssign26 integerValue];
    wellFov5 [10] = (int)[xyAssign25 integerValue];
    wellFov5 [11] = (int)[xyAssign24 integerValue];
    wellFov5 [12] = (int)[xyAssign23 integerValue];
    wellFov5 [13] = (int)[xyAssign22 integerValue];
    wellFov5 [14] = (int)[xyAssign21 integerValue];
    
    wellFov5 [15] = (int)[xyAssign37 integerValue];
    wellFov5 [16] = (int)[xyAssign36 integerValue];
    wellFov5 [17] = (int)[xyAssign35 integerValue];
    wellFov5 [18] = (int)[xyAssign34 integerValue];
    wellFov5 [19] = (int)[xyAssign33 integerValue];
    wellFov5 [20] = (int)[xyAssign32 integerValue];
    wellFov5 [21] = (int)[xyAssign31 integerValue];
    
    wellFov5 [22] = (int)[xyAssign47 integerValue];
    wellFov5 [23] = (int)[xyAssign46 integerValue];
    wellFov5 [24] = (int)[xyAssign45 integerValue];
    wellFov5 [25] = (int)[xyAssign44 integerValue];
    wellFov5 [26] = (int)[xyAssign43 integerValue];
    wellFov5 [27] = (int)[xyAssign42 integerValue];
    wellFov5 [28] = (int)[xyAssign41 integerValue];
    
    wellFov5 [29] = (int)[xyAssign57 integerValue];
    wellFov5 [30] = (int)[xyAssign56 integerValue];
    wellFov5 [31] = (int)[xyAssign55 integerValue];
    wellFov5 [32] = (int)[xyAssign54 integerValue];
    wellFov5 [33] = (int)[xyAssign53 integerValue];
    wellFov5 [34] = (int)[xyAssign52 integerValue];
    wellFov5 [35] = (int)[xyAssign51 integerValue];
    
    wellFov5 [36] = (int)[xyAssign67 integerValue];
    wellFov5 [37] = (int)[xyAssign66 integerValue];
    wellFov5 [38] = (int)[xyAssign65 integerValue];
    wellFov5 [39] = (int)[xyAssign64 integerValue];
    wellFov5 [40] = (int)[xyAssign63 integerValue];
    wellFov5 [41] = (int)[xyAssign62 integerValue];
    wellFov5 [42] = (int)[xyAssign61 integerValue];
    
    wellFov5 [43] = (int)[xyAssign77 integerValue];
    wellFov5 [44] = (int)[xyAssign76 integerValue];
    wellFov5 [45] = (int)[xyAssign75 integerValue];
    wellFov5 [46] = (int)[xyAssign74 integerValue];
    wellFov5 [47] = (int)[xyAssign73 integerValue];
    wellFov5 [48] = (int)[xyAssign72 integerValue];
    wellFov5 [49] = (int)[xyAssign71 integerValue];
    
    int fovCount = 0;
    
    for (int counter2 = 1; counter2 <= 49; counter2++){
        if (wellFov5 [counter2] != 0) fovCount++;
    }
    
    if (fovCount != 0) [dimension5 setIntegerValue: fovCount];
    else [dimension5 setStringValue:@"nil"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)setWell6:(id)sender{
    for (int counter2 = 0; counter2 < 100; counter2++) wellFov6 [counter2] = 0;
    
    wellFov6 [1] = (int)[xyAssign17 integerValue];
    wellFov6 [2] = (int)[xyAssign16 integerValue];
    wellFov6 [3] = (int)[xyAssign15 integerValue];
    wellFov6 [4] = (int)[xyAssign14 integerValue];
    wellFov6 [5] = (int)[xyAssign13 integerValue];
    wellFov6 [6] = (int)[xyAssign12 integerValue];
    wellFov6 [7] = (int)[xyAssign11 integerValue];
    
    wellFov6 [8] = (int)[xyAssign27 integerValue];
    wellFov6 [9] = (int)[xyAssign26 integerValue];
    wellFov6 [10] = (int)[xyAssign25 integerValue];
    wellFov6 [11] = (int)[xyAssign24 integerValue];
    wellFov6 [12] = (int)[xyAssign23 integerValue];
    wellFov6 [13] = (int)[xyAssign22 integerValue];
    wellFov6 [14] = (int)[xyAssign21 integerValue];
    
    wellFov6 [15] = (int)[xyAssign37 integerValue];
    wellFov6 [16] = (int)[xyAssign36 integerValue];
    wellFov6 [17] = (int)[xyAssign35 integerValue];
    wellFov6 [18] = (int)[xyAssign34 integerValue];
    wellFov6 [19] = (int)[xyAssign33 integerValue];
    wellFov6 [20] = (int)[xyAssign32 integerValue];
    wellFov6 [21] = (int)[xyAssign31 integerValue];
    
    wellFov6 [22] = (int)[xyAssign47 integerValue];
    wellFov6 [23] = (int)[xyAssign46 integerValue];
    wellFov6 [24] = (int)[xyAssign45 integerValue];
    wellFov6 [25] = (int)[xyAssign44 integerValue];
    wellFov6 [26] = (int)[xyAssign43 integerValue];
    wellFov6 [27] = (int)[xyAssign42 integerValue];
    wellFov6 [28] = (int)[xyAssign41 integerValue];
    
    wellFov6 [29] = (int)[xyAssign57 integerValue];
    wellFov6 [30] = (int)[xyAssign56 integerValue];
    wellFov6 [31] = (int)[xyAssign55 integerValue];
    wellFov6 [32] = (int)[xyAssign54 integerValue];
    wellFov6 [33] = (int)[xyAssign53 integerValue];
    wellFov6 [34] = (int)[xyAssign52 integerValue];
    wellFov6 [35] = (int)[xyAssign51 integerValue];
    
    wellFov6 [36] = (int)[xyAssign67 integerValue];
    wellFov6 [37] = (int)[xyAssign66 integerValue];
    wellFov6 [38] = (int)[xyAssign65 integerValue];
    wellFov6 [39] = (int)[xyAssign64 integerValue];
    wellFov6 [40] = (int)[xyAssign63 integerValue];
    wellFov6 [41] = (int)[xyAssign62 integerValue];
    wellFov6 [42] = (int)[xyAssign61 integerValue];
    
    wellFov6 [43] = (int)[xyAssign77 integerValue];
    wellFov6 [44] = (int)[xyAssign76 integerValue];
    wellFov6 [45] = (int)[xyAssign75 integerValue];
    wellFov6 [46] = (int)[xyAssign74 integerValue];
    wellFov6 [47] = (int)[xyAssign73 integerValue];
    wellFov6 [48] = (int)[xyAssign72 integerValue];
    wellFov6 [49] = (int)[xyAssign71 integerValue];
    
    int fovCount = 0;
    
    for (int counter2 = 1; counter2 <= 49; counter2++){
        if (wellFov6 [counter2] != 0) fovCount++;
    }
    
    if (fovCount != 0) [dimension6 setIntegerValue: fovCount];
    else [dimension6 setStringValue:@"nil"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)setWell7:(id)sender{
    for (int counter2 = 0; counter2 < 100; counter2++) wellFov7 [counter2] = 0;
    
    wellFov7 [1] = (int)[xyAssign17 integerValue];
    wellFov7 [2] = (int)[xyAssign16 integerValue];
    wellFov7 [3] = (int)[xyAssign15 integerValue];
    wellFov7 [4] = (int)[xyAssign14 integerValue];
    wellFov7 [5] = (int)[xyAssign13 integerValue];
    wellFov7 [6] = (int)[xyAssign12 integerValue];
    wellFov7 [7] = (int)[xyAssign11 integerValue];
    
    wellFov7 [8] = (int)[xyAssign27 integerValue];
    wellFov7 [9] = (int)[xyAssign26 integerValue];
    wellFov7 [10] = (int)[xyAssign25 integerValue];
    wellFov7 [11] = (int)[xyAssign24 integerValue];
    wellFov7 [12] = (int)[xyAssign23 integerValue];
    wellFov7 [13] = (int)[xyAssign22 integerValue];
    wellFov7 [14] = (int)[xyAssign21 integerValue];
    
    wellFov7 [15] = (int)[xyAssign37 integerValue];
    wellFov7 [16] = (int)[xyAssign36 integerValue];
    wellFov7 [17] = (int)[xyAssign35 integerValue];
    wellFov7 [18] = (int)[xyAssign34 integerValue];
    wellFov7 [19] = (int)[xyAssign33 integerValue];
    wellFov7 [20] = (int)[xyAssign32 integerValue];
    wellFov7 [21] = (int)[xyAssign31 integerValue];
    
    wellFov7 [22] = (int)[xyAssign47 integerValue];
    wellFov7 [23] = (int)[xyAssign46 integerValue];
    wellFov7 [24] = (int)[xyAssign45 integerValue];
    wellFov7 [25] = (int)[xyAssign44 integerValue];
    wellFov7 [26] = (int)[xyAssign43 integerValue];
    wellFov7 [27] = (int)[xyAssign42 integerValue];
    wellFov7 [28] = (int)[xyAssign41 integerValue];
    
    wellFov7 [29] = (int)[xyAssign57 integerValue];
    wellFov7 [30] = (int)[xyAssign56 integerValue];
    wellFov7 [31] = (int)[xyAssign55 integerValue];
    wellFov7 [32] = (int)[xyAssign54 integerValue];
    wellFov7 [33] = (int)[xyAssign53 integerValue];
    wellFov7 [34] = (int)[xyAssign52 integerValue];
    wellFov7 [35] = (int)[xyAssign51 integerValue];
    
    wellFov7 [36] = (int)[xyAssign67 integerValue];
    wellFov7 [37] = (int)[xyAssign66 integerValue];
    wellFov7 [38] = (int)[xyAssign65 integerValue];
    wellFov7 [39] = (int)[xyAssign64 integerValue];
    wellFov7 [40] = (int)[xyAssign63 integerValue];
    wellFov7 [41] = (int)[xyAssign62 integerValue];
    wellFov7 [42] = (int)[xyAssign61 integerValue];
    
    wellFov7 [43] = (int)[xyAssign77 integerValue];
    wellFov7 [44] = (int)[xyAssign76 integerValue];
    wellFov7 [45] = (int)[xyAssign75 integerValue];
    wellFov7 [46] = (int)[xyAssign74 integerValue];
    wellFov7 [47] = (int)[xyAssign73 integerValue];
    wellFov7 [48] = (int)[xyAssign72 integerValue];
    wellFov7 [49] = (int)[xyAssign71 integerValue];
    
    int fovCount = 0;
    
    for (int counter2 = 1; counter2 <= 49; counter2++){
        if (wellFov7 [counter2] != 0) fovCount++;
    }
    
    if (fovCount != 0) [dimension7 setIntegerValue: fovCount];
    else [dimension7 setStringValue:@"nil"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)setWell8:(id)sender{
    for (int counter2 = 0; counter2 < 100; counter2++) wellFov8 [counter2] = 0;
    
    wellFov8 [1] = (int)[xyAssign17 integerValue];
    wellFov8 [2] = (int)[xyAssign16 integerValue];
    wellFov8 [3] = (int)[xyAssign15 integerValue];
    wellFov8 [4] = (int)[xyAssign14 integerValue];
    wellFov8 [5] = (int)[xyAssign13 integerValue];
    wellFov8 [6] = (int)[xyAssign12 integerValue];
    wellFov8 [7] = (int)[xyAssign11 integerValue];
    
    wellFov8 [8] = (int)[xyAssign27 integerValue];
    wellFov8 [9] = (int)[xyAssign26 integerValue];
    wellFov8 [10] = (int)[xyAssign25 integerValue];
    wellFov8 [11] = (int)[xyAssign24 integerValue];
    wellFov8 [12] = (int)[xyAssign23 integerValue];
    wellFov8 [13] = (int)[xyAssign22 integerValue];
    wellFov8 [14] = (int)[xyAssign21 integerValue];
    
    wellFov8 [15] = (int)[xyAssign37 integerValue];
    wellFov8 [16] = (int)[xyAssign36 integerValue];
    wellFov8 [17] = (int)[xyAssign35 integerValue];
    wellFov8 [18] = (int)[xyAssign34 integerValue];
    wellFov8 [19] = (int)[xyAssign33 integerValue];
    wellFov8 [20] = (int)[xyAssign32 integerValue];
    wellFov8 [21] = (int)[xyAssign31 integerValue];
    
    wellFov8 [22] = (int)[xyAssign47 integerValue];
    wellFov8 [23] = (int)[xyAssign46 integerValue];
    wellFov8 [24] = (int)[xyAssign45 integerValue];
    wellFov8 [25] = (int)[xyAssign44 integerValue];
    wellFov8 [26] = (int)[xyAssign43 integerValue];
    wellFov8 [27] = (int)[xyAssign42 integerValue];
    wellFov8 [28] = (int)[xyAssign41 integerValue];
    
    wellFov8 [29] = (int)[xyAssign57 integerValue];
    wellFov8 [30] = (int)[xyAssign56 integerValue];
    wellFov8 [31] = (int)[xyAssign55 integerValue];
    wellFov8 [32] = (int)[xyAssign54 integerValue];
    wellFov8 [33] = (int)[xyAssign53 integerValue];
    wellFov8 [34] = (int)[xyAssign52 integerValue];
    wellFov8 [35] = (int)[xyAssign51 integerValue];
    
    wellFov8 [36] = (int)[xyAssign67 integerValue];
    wellFov8 [37] = (int)[xyAssign66 integerValue];
    wellFov8 [38] = (int)[xyAssign65 integerValue];
    wellFov8 [39] = (int)[xyAssign64 integerValue];
    wellFov8 [40] = (int)[xyAssign63 integerValue];
    wellFov8 [41] = (int)[xyAssign62 integerValue];
    wellFov8 [42] = (int)[xyAssign61 integerValue];
    
    wellFov8 [43] = (int)[xyAssign77 integerValue];
    wellFov8 [44] = (int)[xyAssign76 integerValue];
    wellFov8 [45] = (int)[xyAssign75 integerValue];
    wellFov8 [46] = (int)[xyAssign74 integerValue];
    wellFov8 [47] = (int)[xyAssign73 integerValue];
    wellFov8 [48] = (int)[xyAssign72 integerValue];
    wellFov8 [49] = (int)[xyAssign71 integerValue];
    
    int fovCount = 0;
    
    for (int counter2 = 1; counter2 <= 49; counter2++){
        if (wellFov8 [counter2] != 0) fovCount++;
    }
    
    if (fovCount != 0) [dimension8 setIntegerValue: fovCount];
    else [dimension8 setStringValue:@"nil"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)clearDimension:(id)sender{
    [xyAssign11 setStringValue:@""];
    [xyAssign21 setStringValue:@""];
    [xyAssign31 setStringValue:@""];
    [xyAssign41 setStringValue:@""];
    [xyAssign51 setStringValue:@""];
    [xyAssign61 setStringValue:@""];
    [xyAssign71 setStringValue:@""];
    
    [xyAssign12 setStringValue:@""];
    [xyAssign22 setStringValue:@""];
    [xyAssign32 setStringValue:@""];
    [xyAssign42 setStringValue:@""];
    [xyAssign52 setStringValue:@""];
    [xyAssign62 setStringValue:@""];
    [xyAssign72 setStringValue:@""];
    
    [xyAssign13 setStringValue:@""];
    [xyAssign23 setStringValue:@""];
    [xyAssign33 setStringValue:@""];
    [xyAssign43 setStringValue:@""];
    [xyAssign53 setStringValue:@""];
    [xyAssign63 setStringValue:@""];
    [xyAssign73 setStringValue:@""];
    
    [xyAssign14 setStringValue:@""];
    [xyAssign24 setStringValue:@""];
    [xyAssign34 setStringValue:@""];
    [xyAssign44 setStringValue:@""];
    [xyAssign54 setStringValue:@""];
    [xyAssign64 setStringValue:@""];
    [xyAssign74 setStringValue:@""];
    
    [xyAssign15 setStringValue:@""];
    [xyAssign25 setStringValue:@""];
    [xyAssign35 setStringValue:@""];
    [xyAssign45 setStringValue:@""];
    [xyAssign55 setStringValue:@""];
    [xyAssign65 setStringValue:@""];
    [xyAssign75 setStringValue:@""];
    
    [xyAssign16 setStringValue:@""];
    [xyAssign26 setStringValue:@""];
    [xyAssign36 setStringValue:@""];
    [xyAssign46 setStringValue:@""];
    [xyAssign56 setStringValue:@""];
    [xyAssign66 setStringValue:@""];
    [xyAssign76 setStringValue:@""];
    
    [xyAssign17 setStringValue:@""];
    [xyAssign27 setStringValue:@""];
    [xyAssign37 setStringValue:@""];
    [xyAssign47 setStringValue:@""];
    [xyAssign57 setStringValue:@""];
    [xyAssign67 setStringValue:@""];
    [xyAssign77 setStringValue:@""];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)clearAll:(id)sender{
    [xyAssign11 setStringValue:@""];
    [xyAssign21 setStringValue:@""];
    [xyAssign31 setStringValue:@""];
    [xyAssign41 setStringValue:@""];
    [xyAssign51 setStringValue:@""];
    [xyAssign61 setStringValue:@""];
    [xyAssign71 setStringValue:@""];
    
    [xyAssign12 setStringValue:@""];
    [xyAssign22 setStringValue:@""];
    [xyAssign32 setStringValue:@""];
    [xyAssign42 setStringValue:@""];
    [xyAssign52 setStringValue:@""];
    [xyAssign62 setStringValue:@""];
    [xyAssign72 setStringValue:@""];
    
    [xyAssign13 setStringValue:@""];
    [xyAssign23 setStringValue:@""];
    [xyAssign33 setStringValue:@""];
    [xyAssign43 setStringValue:@""];
    [xyAssign53 setStringValue:@""];
    [xyAssign63 setStringValue:@""];
    [xyAssign73 setStringValue:@""];
    
    [xyAssign14 setStringValue:@""];
    [xyAssign24 setStringValue:@""];
    [xyAssign34 setStringValue:@""];
    [xyAssign44 setStringValue:@""];
    [xyAssign54 setStringValue:@""];
    [xyAssign64 setStringValue:@""];
    [xyAssign74 setStringValue:@""];
    
    [xyAssign15 setStringValue:@""];
    [xyAssign25 setStringValue:@""];
    [xyAssign35 setStringValue:@""];
    [xyAssign45 setStringValue:@""];
    [xyAssign55 setStringValue:@""];
    [xyAssign65 setStringValue:@""];
    [xyAssign75 setStringValue:@""];
    
    [xyAssign16 setStringValue:@""];
    [xyAssign26 setStringValue:@""];
    [xyAssign36 setStringValue:@""];
    [xyAssign46 setStringValue:@""];
    [xyAssign56 setStringValue:@""];
    [xyAssign66 setStringValue:@""];
    [xyAssign76 setStringValue:@""];
    
    [xyAssign17 setStringValue:@""];
    [xyAssign27 setStringValue:@""];
    [xyAssign37 setStringValue:@""];
    [xyAssign47 setStringValue:@""];
    [xyAssign57 setStringValue:@""];
    [xyAssign67 setStringValue:@""];
    [xyAssign77 setStringValue:@""];
    
    for (int counter2 = 0; counter2 < 100; counter2++){
        wellFov1 [counter2] = 0;
        wellFov2 [counter2] = 0;
        wellFov3 [counter2] = 0;
        wellFov4 [counter2] = 0;
        wellFov5 [counter2] = 0;
        wellFov6 [counter2] = 0;
        wellFov7 [counter2] = 0;
        wellFov8 [counter2] = 0;
    }
    
    [dimension1 setStringValue:@"nil"];
    [dimension2 setStringValue:@"nil"];
    [dimension3 setStringValue:@"nil"];
    [dimension4 setStringValue:@"nil"];
    [dimension5 setStringValue:@"nil"];
    [dimension6 setStringValue:@"nil"];
    [dimension7 setStringValue:@"nil"];
    [dimension8 setStringValue:@"nil"];
    
    [body1 setStringValue:@""];
    [body2 setStringValue:@""];
    [body3 setStringValue:@""];
    [body4 setStringValue:@""];
    [body5 setStringValue:@""];
    [body6 setStringValue:@""];
    [body7 setStringValue:@""];
    [body8 setStringValue:@""];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)fovPositionSet:(id)sender{
    if (fovStatusHold == 0){
        fovStatusHold = 1;
        [fovStatusDisplay setStringValue:@"Yes"];
    }
    else{
        
        fovStatusHold = 0;
        [fovStatusDisplay setStringValue:@"No"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)tifReductionSet:(id)sender{
    if (tiffReductionHold == 0){
        tiffReductionHold = 1;
        [tifReductionDisplay setStringValue:@"On"];
    }
    else if (tiffReductionHold == 1){
        tiffReductionHold = 0;
        [tifReductionDisplay setStringValue:@"Off"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)tif16To8Set:(id)sender{
    if (tiff16To8Hold == 0){
        tiff16To8Hold = 1;
        rangeFromHold = -1;
        rangeToHold = -1;
        [rangeFromDisplay setStringValue:@""];
        [rangeToDisplay setStringValue:@""];
        
        [tiff16To8Display setStringValue:@"Range"];
    }
    else{
        
        tiff16To8Hold = 0;
        rangeFromHold = -1;
        rangeToHold = -1;
        [rangeFromDisplay setStringValue:@""];
        [rangeToDisplay setStringValue:@""];
        
        [tiff16To8Display setStringValue:@"Average"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)activateContrast:(id)sender{
    if (contrastActivateHold == 0){
        contrastActivateHold = 1;
        
        contrastMeanHold = 100;
        belowCutHold = -1;
        aboveCutHold = -1;
        valueBelowHold = -1;
        valueFoldHold = -1;
        meanAboveFoldHold = -1;
        meanBelowFoldHold = -1;
        
        [contrastMeanDisplay setStringValue:@"100"];
        [contrastActivateDisplay setStringValue:@"On"];
    }
    else if (contrastActivateHold == 1){
        contrastActivateHold = 0;
        
        contrastMeanHold = -1;
        belowCutHold = -1;
        aboveCutHold = -1;
        valueBelowHold = -1;
        valueFoldHold = -1;
        meanAboveFoldHold = -1;
        meanBelowFoldHold = -1;
        
        [contrastMeanDisplay setStringValue:@""];
        [belowCutDisplay setStringValue:@""];
        [aboveCutDisplay setStringValue:@""];
        [valueBelowDisplay setStringValue:@""];
        [valueMeanAboveDisplay setStringValue:@""];
        [valueMeanBelowDisplay setStringValue:@""];
        [valueFoldDisplay setStringValue:@""];
        [contrastActivateDisplay setStringValue:@"Off"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)to16Set:(id)sender{
    if (to16SetHold == 0){
        to16SetHold = 1;
        [to16HoldDisplay setStringValue:@"Gray 8/16"];
    }
    else if (to16SetHold == 1){
        to16SetHold = 0;
        [to16HoldDisplay setStringValue:@"Gray 8"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)imageLoad:(id)sender{
    /*
     Upload image files for analysis
     Color image data will be processed as a gray scale image
     Color image with Alpha will processed as a gray scale image
     */
    
    if (sourcePathNameHold != "nil"){
        DIR *dir;
        struct dirent *dent;
        
        string entry;
        string sourceFileName;
        string tiffExtensionHold;
        
        unsigned long nextAddress = 0;
        unsigned long stripFirstAddress = 0;
        unsigned long stripByteCountAddress = 0;
        unsigned long headPosition = 0;
        unsigned long totalImageCount = 0;
        unsigned long stripEntry = 0;
        long sizeForCopy = 0;
        
        double xPosition = 0;
        double yPosition = 0;
        
        int meanValueTemp = 0;
        int terminationFlag = 0;
        int pixNo90 = 0;
        int numberOfImagePoint = 0;
        
        int imageWidth = 0;
        int imageHeight = 0;
        int imageBit = 0; // Check 8, 16
        int imageCompression = 0; // Check 1
        int photoMetric = 0; //Check 0, 1, 2
        int imageDimension = 0;
        int dimensionAddition = 0;
        int verticalBmp = 0;
        int horizontalBmp = 0;
        int horizontalBmpEntry = 0;
        int newImageDimension = 0;
        int endianType = 0;
        int samplePerPix = 0;
        int dataConversion [4];
        int processType = 2;
        int numberOfLayers = 0;
        int layerTotalCount = 0;
        
        struct stat sizeOfFile;
        
        ifstream fin;
        
        fileDeleteCount = 0;
        
        dir = opendir(sourcePathNameHold.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" &&  ((int)entry.find(".TIFF") != -1 || (int)entry.find(".Tiff") != -1 || (int)entry.find(".tiff") != -1 || (int)entry.find(".TIF") != -1 || (int)entry.find(".Tif") != -1 || (int)entry.find(".tif") != -1)){
                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                    arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                }
            }
            
            closedir(dir);
            
            //----Directory Sort----
            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
            
            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
            }
            
            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
            
            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
            }
        }
        
        if (fileDeleteCount != 0){
            currentFile = 1;
            
            fileNameHist = arrayFileDelete [currentFile-1];
            
            tiffExtensionHold = "";
            
            if ((int)arrayFileDelete [currentFile-1].find(".TIFF") != -1) tiffExtensionHold = ".TIFF";
            else if ((int)arrayFileDelete [currentFile-1].find(".Tiff") != -1) tiffExtensionHold = ".Tiff";
            else if ((int)arrayFileDelete [currentFile-1].find(".tiff") != -1) tiffExtensionHold = ".tiff";
            else if ((int)arrayFileDelete [currentFile-1].find(".TIF") != -1 ) tiffExtensionHold = ".TIF";
            else if ((int)arrayFileDelete [currentFile-1].find(".Tif") != -1) tiffExtensionHold = ".Tif";
            else if ((int)arrayFileDelete [currentFile-1].find(".tif") != -1) tiffExtensionHold = ".tif";
            
            sourceFileName = sourcePathNameHold+"/"+arrayFileDelete [currentFile-1];
            
            //----File Read----
            if (stat(sourceFileName.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                fileReadArray = new uint8_t [sizeForCopy+4];
                fin.open(sourceFileName.c_str(), ios::in | ios::binary);
                
                fin.read((char*)fileReadArray, sizeForCopy+1);
                fin.close();
                
                dataConversion [0] = fileReadArray [0];
                dataConversion [1] = fileReadArray [1];
                
                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                else endianType = 0;
                
                headPosition = 0;
                
                if (endianType == 1){
                    dataConversion [0] = fileReadArray [7];
                    dataConversion [1] = fileReadArray [6];
                    dataConversion [2] = fileReadArray [5];
                    dataConversion [3] = fileReadArray [4];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                else if (endianType == 0){
                    dataConversion [0] = fileReadArray [4];
                    dataConversion [1] = fileReadArray [5];
                    dataConversion [2] = fileReadArray [6];
                    dataConversion [3] = fileReadArray [7];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                
                if (endianType == 1){ //----Big endian----
                    layerTotalCount = 1;
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        tiffFileRead = [[TiffFileRead alloc] init];
                        [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                        
                        if (nextAddress == 0) terminationFlag = 0;
                        else{
                            
                            headPosition = nextAddress;
                            layerTotalCount++;
                        }
                        
                    } while (terminationFlag == 1);
                    
                }
                else if (endianType == 0){
                    layerTotalCount = 1;
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        tiffFileRead = [[TiffFileRead alloc] init];
                        [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                        
                        if (nextAddress == 0) terminationFlag = 0;
                        else{
                            
                            headPosition = nextAddress;
                            layerTotalCount++;
                        }
                        
                    } while (terminationFlag == 1);
                    
                }
                
                zPlaneNumberHold = layerTotalCount;
                bitNumberNumberHold = imageBit;
                colorStatusHold = photoMetric;
                
                //cout<<imageCompression<<" "<<imageBit<<" "<<layerTotalCount<<" "<<samplePerPix<<" EntryInfo"<<endl;
                
                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                    zPositionHold = 1;
                    
                    int *arrayExtractedImage3 = new int [100];
                    
                    if (endianType == 1){
                        if (imageWidth > imageHeight) imageDimension = imageWidth;
                        else imageDimension = imageHeight;
                        
                        tiffFileRead = [[TiffFileRead alloc] init];
                        delete [] arrayExtractedImage3;
                        
                        arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                    }
                    else if (endianType == 0){
                        if (imageWidth > imageHeight) imageDimension = imageWidth;
                        else imageDimension = imageHeight;
                        
                        tiffFileRead = [[TiffFileRead alloc] init];
                        delete [] arrayExtractedImage3;
                        
                        arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                    }
                    
                    dimensionAddition = imageDimension%4;
                    
                    if (dimensionAddition == 1) dimensionAddition = 3;
                    else if (dimensionAddition == 2) dimensionAddition = 2;
                    else if (dimensionAddition == 3) dimensionAddition = 1;
                    
                    newImageDimension = imageDimension+dimensionAddition;
                    
                    loadSizeDataString = to_string(imageHeight)+" + "+ to_string(imageWidth);
                    loadSizeDataString2 = to_string(newImageDimension);
                    
                    loadImageSizeDisplayCall = 1;
                    
                    int **arrayExtractedImage = new int *[newImageDimension+1];
                    
                    for (int counter3 = 0; counter3 < newImageDimension+1; counter3++){
                        arrayExtractedImage [counter3] = new int [newImageDimension+1];
                    }
                    
                    for (int counter3 = 0; counter3 < newImageDimension; counter3++){
                        for (int counter4 = 0; counter4 < newImageDimension; counter4++){
                            arrayExtractedImage [counter3][counter4] = 0;
                        }
                    }
                    
                    verticalBmp = 0;
                    horizontalBmp = 0;
                    horizontalBmpEntry = 0;
                    
                    for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                        if (verticalBmp < imageHeight){
                            if (horizontalBmp < imageWidth){
                                arrayExtractedImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3]);
                                horizontalBmp++;
                                horizontalBmpEntry++;
                            }
                            
                            if (horizontalBmp == imageWidth && imageWidth < newImageDimension){
                                for (int counter4 = 0; counter4 < newImageDimension-imageWidth; counter4++){
                                    arrayExtractedImage [verticalBmp][horizontalBmpEntry] = 0;
                                    horizontalBmpEntry++;
                                }
                            }
                            
                            if (horizontalBmp == imageWidth){
                                horizontalBmp = 0;
                                horizontalBmpEntry = 0;
                                verticalBmp++;
                            }
                        }
                    }
                    
                    if (imageBit == 8){
                        for (int counter3 = 0; counter3 <= 255; counter3++) histogramHold [counter3] = 0;
                        
                        for (int counter3 = 0; counter3 < newImageDimension; counter3++){
                            for (int counter4 = 0; counter4 < newImageDimension; counter4++){
                                if (arrayExtractedImage [counter3][counter4] >= 255) histogramHold [255]++;
                                else if (arrayExtractedImage [counter3][counter4] < 0) histogramHold [0]++;
                                else histogramHold [arrayExtractedImage [counter3][counter4]]++;
                            }
                        }
                        
                        //for (int counterA = 0; counterA <= 255; counterA++){
                        //    cout<<counterA<<" "<<histogramHold [counterA]<<" Histogram"<<endl;
                        //}
                        
                        lowerHistHold = 0;
                        higherHistHold = 0;
                        meanValueTemp = 0;
                        
                        numberOfImagePoint = 0;
                        totalImageCount = 0;
                        
                        for (int counter3 = 1; counter3 <= 255; counter3++){
                            numberOfImagePoint = numberOfImagePoint+histogramHold [counter3];
                            totalImageCount = totalImageCount+(unsigned long)counter3*(unsigned long)histogramHold [counter3];
                        }
                        
                        if (numberOfImagePoint != 0) meanValueTemp = (int)(totalImageCount/(double)numberOfImagePoint);
                        pixNo90 = histogramHold [meanValueTemp];
                        
                        for (int counter3 = 1; counter3 <= 255; counter3++){
                            if (meanValueTemp-counter3 >= 0){
                                pixNo90 = pixNo90+histogramHold [meanValueTemp-counter3];
                                lowerHistHold = meanValueTemp-counter3;
                            }
                            if (meanValueTemp+counter3 <= 255){
                                pixNo90 = pixNo90+histogramHold [meanValueTemp+counter3];
                                higherHistHold = meanValueTemp+counter3;
                            }
                            if (pixNo90/(double)numberOfImagePoint > 0.8){
                                break;
                            }
                        }
                        
                        //cout<< lowerHistHold<<" "<<higherHistHold<<" "<<meanValueTemp <<" Value"endl;
                    }
                    else if (imageBit == 16){
                        for (int counter3 = 0; counter3 <= 65535; counter3++) histogramHold [counter3] = 0;
                        
                        for (int counter3 = 0; counter3 < newImageDimension; counter3++){
                            for (int counter4 = 0; counter4 < newImageDimension; counter4++){
                                if (arrayExtractedImage [counter3][counter4] >= 65535) histogramHold [65535]++;
                                else if (arrayExtractedImage [counter3][counter4] < 0) histogramHold [0]++;
                                else histogramHold [arrayExtractedImage [counter3][counter4]]++;
                            }
                        }
                        
                        lowerHistHold = 0;
                        higherHistHold = 0;
                        meanValueTemp = 0;
                        
                        numberOfImagePoint = 0;
                        totalImageCount = 0;
                        
                        for (int counter3 = 0; counter3 <= 65535; counter3++){
                            numberOfImagePoint = numberOfImagePoint+histogramHold [counter3];
                            totalImageCount = totalImageCount+(unsigned long)counter3*(unsigned long)histogramHold [counter3];
                        }
                        
                        if (numberOfImagePoint != 0) meanValueTemp = (int)(totalImageCount/(double)numberOfImagePoint);
                        pixNo90 = histogramHold [meanValueTemp];
                        
                        for (int counter3 = 0; counter3 <= 65535; counter3++){
                            if (meanValueTemp-counter3 >= 0){
                                pixNo90 = pixNo90+histogramHold [meanValueTemp-counter3];
                                lowerHistHold = meanValueTemp-counter3;
                            }
                            if (meanValueTemp+counter3 <= 65535){
                                pixNo90 = pixNo90+histogramHold [meanValueTemp+counter3];
                                higherHistHold = meanValueTemp+counter3;
                            }
                            if (pixNo90/(double)numberOfImagePoint > 0.8){
                                break;
                            }
                        }
                        
                        //cout<< lowerHistHold<<" "<<higherHistHold<<" "<<meanValueTemp <<" Value"endl;
                    }
                    
                    for (int counter3 = 0; counter3 < newImageDimension+1; counter3++){
                        delete [] arrayExtractedImage [counter3];
                    }
                    
                    delete [] arrayExtractedImage;
                    
                    delete [] arrayExtractedImage3;
                    
                    [zPositionDisplay setIntegerValue:zPositionHold];
                    [stepperSlice setIntegerValue:zPositionHold];
                    
                    [zNumberDisplay setIntegerValue:zPlaneNumberHold];
                    [bitNoDisplay setIntegerValue:bitNumberNumberHold];
                    
                    if (colorStatusHold == 1 || colorStatusHold == 0) [colorStatusDisplay setStringValue:@"G"];
                    else [colorStatusDisplay setStringValue:@"R"];
                    
                    firstRead = 1;
                    folderChangeHold = 0;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToHistogram object:self];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    string messageImageFormat = "Image format does not match/Compression = 1:"+to_string(imageCompression)+"/Bit = 8 or 16:"+to_string(imageBit);
                    NSString *messageImageNSstring = @(messageImageFormat.c_str());
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:messageImageNSstring];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                
                delete [] fileReadArray;
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select Tif File"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Select Source Folder"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)stepperActionNext:(id)sender{
    nextValueHold = [stepperNext intValue];
    
    if (nextValueHold == 0) [stepperNextDisplay setStringValue:@"x1"];
    else if (nextValueHold == 1) [stepperNextDisplay setStringValue:@"x10"];
    else if (nextValueHold == 2) [stepperNextDisplay setStringValue:@"x100"];
    else if (nextValueHold == 3) [stepperNextDisplay setStringValue:@"x1000"];
}

-(IBAction)stepperSlice:(id)sender{
    if (firstRead == 1 || folderChangeHold == 0){
        if (zPlaneNumberHold > 1){
            if ([stepperSlice intValue] <= zPlaneNumberHold){
                zPositionHold = [stepperSlice intValue];
                [zPositionDisplay setIntegerValue:zPositionHold];
                
                string entry;
                string sourceFileName;
                string tiffExtensionHold;
                
                unsigned long nextAddress = 0;
                unsigned long stripFirstAddress = 0;
                unsigned long stripByteCountAddress = 0;
                unsigned long headPosition = 0;
                unsigned long totalImageCount = 0;
                unsigned long stripEntry = 0;
                long sizeForCopy = 0;
                
                double xPosition = 0;
                double yPosition = 0;
                
                int meanValueTemp = 0;
                int loopCount = 0;
                int terminationFlag = 0;
                int pixNo90 = 0;
                int numberOfImagePoint = 0;
                int imageWidth = 0;
                int imageHeight = 0;
                int imageBit = 0; // Check 8, 16
                int imageCompression = 0; // Check 1
                int photoMetric = 0; //Check 0, 1, 2
                int imageDimension = 0;
                int dimensionAddition = 0;
                int verticalBmp = 0;
                int horizontalBmp = 0;
                int horizontalBmpEntry = 0;
                int newImageDimension = 0;
                int endianType = 0;
                int samplePerPix = 0;
                int dataConversion [4];
                int processType = 2;
                int numberOfLayers = 0;
                
                struct stat sizeOfFile;
                
                ifstream fin;
                
                if (fileDeleteCount != 0){
                    tiffExtensionHold = "";
                    
                    if ((int)arrayFileDelete [currentFile-1].find(".TIFF") != -1) tiffExtensionHold = ".TIFF";
                    else if ((int)arrayFileDelete [currentFile-1].find(".Tiff") != -1) tiffExtensionHold = ".Tiff";
                    else if ((int)arrayFileDelete [currentFile-1].find(".tiff") != -1) tiffExtensionHold = ".tiff";
                    else if ((int)arrayFileDelete [currentFile-1].find(".TIF") != -1 ) tiffExtensionHold = ".TIF";
                    else if ((int)arrayFileDelete [currentFile-1].find(".Tif") != -1) tiffExtensionHold = ".Tif";
                    else if ((int)arrayFileDelete [currentFile-1].find(".tif") != -1) tiffExtensionHold = ".tif";
                    
                    sourceFileName = sourcePathNameHold+"/"+arrayFileDelete [currentFile-1];
                    
                    //----File Read----
                    if (stat(sourceFileName.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        fileReadArray = new uint8_t [sizeForCopy+4];
                        fin.open(sourceFileName.c_str(), ios::in | ios::binary);
                        
                        fin.read((char*)fileReadArray, sizeForCopy+1);
                        fin.close();
                        
                        dataConversion [0] = fileReadArray [0];
                        dataConversion [1] = fileReadArray [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        imageDimension = 0;
                        
                        int *arrayExtractedImage3 = new int [100];
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = fileReadArray [7];
                            dataConversion [1] = fileReadArray [6];
                            dataConversion [2] = fileReadArray [5];
                            dataConversion [3] = fileReadArray [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = fileReadArray [4];
                            dataConversion [1] = fileReadArray [5];
                            dataConversion [2] = fileReadArray [6];
                            dataConversion [3] = fileReadArray [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        loopCount = 0;
                        
                        do{
                            
                            terminationFlag = 1;
                            
                            if (loopCount == 0) loopCount++;
                            else{
                                
                                if (zPositionHold == loopCount){
                                    break;
                                }
                                
                                loopCount++;
                            }
                            
                            if (endianType == 1){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    if (imageWidth > imageHeight) imageDimension = imageWidth;
                                    else imageDimension = imageHeight;
                                    
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                }
                            }
                            else if (endianType == 0){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    if (imageWidth > imageHeight) imageDimension = imageWidth;
                                    else imageDimension = imageHeight;
                                    
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                }
                            }
                            
                            dimensionAddition = imageDimension%4;
                            
                            if (dimensionAddition == 1) dimensionAddition = 3;
                            else if (dimensionAddition == 2) dimensionAddition = 2;
                            else if (dimensionAddition == 3) dimensionAddition = 1;
                            
                            newImageDimension = imageDimension+dimensionAddition;
                            
                            int **arrayExtractedImage = new int *[newImageDimension+1];
                            
                            for (int counter3 = 0; counter3 < newImageDimension+1; counter3++){
                                arrayExtractedImage [counter3] = new int [newImageDimension+1];
                            }
                            
                            for (int counter3 = 0; counter3 < newImageDimension; counter3++){
                                for (int counter4 = 0; counter4 < newImageDimension; counter4++){
                                    arrayExtractedImage [counter3][counter4] = 0;
                                }
                            }
                            
                            verticalBmp = 0;
                            horizontalBmp = 0;
                            horizontalBmpEntry = 0;
                            
                            for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                if (verticalBmp < imageHeight){
                                    if (horizontalBmp < imageWidth){
                                        arrayExtractedImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3]);
                                        horizontalBmp++;
                                        horizontalBmpEntry++;
                                    }
                                    
                                    if (horizontalBmp == imageWidth && imageWidth < newImageDimension){
                                        for (int counter4 = 0; counter4 < newImageDimension-imageWidth; counter4++){
                                            arrayExtractedImage [verticalBmp][horizontalBmpEntry] = 0;
                                            horizontalBmpEntry++;
                                        }
                                    }
                                    
                                    if (horizontalBmp == imageWidth){
                                        horizontalBmp = 0;
                                        horizontalBmpEntry = 0;
                                        verticalBmp++;
                                    }
                                }
                            }
                            
                            if (imageBit == 8){
                                for (int counter3 = 0; counter3 <= 255; counter3++) histogramHold [counter3] = 0;
                                
                                for (int counter3 = 0; counter3 < newImageDimension; counter3++){
                                    for (int counter4 = 0; counter4 < newImageDimension; counter4++){
                                        if (arrayExtractedImage [counter3][counter4] >= 255) histogramHold [255]++;
                                        else if (arrayExtractedImage [counter3][counter4] < 0) histogramHold [0]++;
                                        else histogramHold [arrayExtractedImage [counter3][counter4]]++;
                                    }
                                }
                                
                                lowerHistHold = 0;
                                higherHistHold = 0;
                                meanValueTemp = 0;
                                
                                numberOfImagePoint = 0;
                                totalImageCount = 0;
                                
                                for (int counter3 = 1; counter3 <= 255; counter3++){
                                    numberOfImagePoint = numberOfImagePoint+histogramHold [counter3];
                                    totalImageCount = totalImageCount+(unsigned long)counter3*(unsigned long)histogramHold [counter3];
                                }
                                
                                if (numberOfImagePoint != 0) meanValueTemp = (int)(totalImageCount/(double)numberOfImagePoint);
                                pixNo90 = histogramHold [meanValueTemp];
                                
                                for (int counter3 = 1; counter3 <= 255; counter3++){
                                    if (meanValueTemp-counter3 >= 0){
                                        pixNo90 = pixNo90+histogramHold [meanValueTemp-counter3];
                                        lowerHistHold = meanValueTemp-counter3;
                                    }
                                    if (meanValueTemp+counter3 <= 255){
                                        pixNo90 = pixNo90+histogramHold [meanValueTemp+counter3];
                                        higherHistHold = meanValueTemp+counter3;
                                    }
                                    if (pixNo90/(double)numberOfImagePoint > 0.8){
                                        break;
                                    }
                                }
                            }
                            else if (imageBit == 16){
                                for (int counter3 = 0; counter3 <= 65535; counter3++) histogramHold [counter3] = 0;
                                
                                for (int counter3 = 0; counter3 < newImageDimension; counter3++){
                                    for (int counter4 = 0; counter4 < newImageDimension; counter4++){
                                        if (arrayExtractedImage [counter3][counter4] >= 65535) histogramHold [65535]++;
                                        else if (arrayExtractedImage [counter3][counter4] < 0) histogramHold [0]++;
                                        else histogramHold [arrayExtractedImage [counter3][counter4]]++;
                                    }
                                }
                                
                                lowerHistHold = 0;
                                higherHistHold = 0;
                                meanValueTemp = 0;
                                
                                numberOfImagePoint = 0;
                                totalImageCount = 0;
                                
                                for (int counter3 = 0; counter3 <= 65535; counter3++){
                                    numberOfImagePoint = numberOfImagePoint+histogramHold [counter3];
                                    totalImageCount = totalImageCount+(unsigned long)counter3*(unsigned long)histogramHold [counter3];
                                }
                                
                                if (numberOfImagePoint != 0) meanValueTemp = (int)(totalImageCount/(double)numberOfImagePoint);
                                pixNo90 = histogramHold [meanValueTemp];
                                
                                for (int counter3 = 0; counter3 <= 65535; counter3++){
                                    if (meanValueTemp-counter3 >= 0){
                                        pixNo90 = pixNo90+histogramHold [meanValueTemp-counter3];
                                        lowerHistHold = meanValueTemp-counter3;
                                    }
                                    if (meanValueTemp+counter3 <= 65535){
                                        pixNo90 = pixNo90+histogramHold [meanValueTemp+counter3];
                                        higherHistHold = meanValueTemp+counter3;
                                    }
                                    if (pixNo90/(double)numberOfImagePoint > 0.8){
                                        break;
                                    }
                                }
                                
                                //cout<< lowerHistHold<<" "<<higherHistHold<<" "<<meanValueTemp <<" value"<<endl;
                            }
                            
                            for (int counter3 = 0; counter3 < newImageDimension+1; counter3++){
                                delete [] arrayExtractedImage [counter3];
                            }
                            
                            delete [] arrayExtractedImage;
                            
                            if (nextAddress != 0) headPosition = nextAddress;
                            else terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                        
                        delete [] arrayExtractedImage3;
                        
                        [zPositionDisplay setIntegerValue:zPositionHold];
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToHistogram object:self];
                        
                        delete [] fileReadArray;
                    }
                }
            }
            else {
                
                zPositionHold = zPlaneNumberHold;
                
                [stepperSlice setIntegerValue: zPlaneNumberHold];
                [zPositionDisplay setIntegerValue:zPositionHold];
            }
        }
        else {
            
            zPositionHold = zPlaneNumberHold;
            
            [stepperSlice setIntegerValue: zPlaneNumberHold];
            [zPositionDisplay setIntegerValue:zPositionHold];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dimensionSelect:(id)sender{
    if (otherProcessOn == 0){
        if (dimensionSelect == 0){
            dimensionSelect = 1;
            [dimensionDisplay setStringValue:@"Original"];
        }
        else if (dimensionSelect == 1){
            dimensionSelect = 0;
            [dimensionDisplay setStringValue:@"Square"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)colorGraySelect:(id)sender{
    if (otherProcessOn == 0){
        if (colorGraySelect == 0){
            colorGraySelect = 1;
            [colorGrayDisplay setStringValue:@"Color/gray"];
        }
        else if (colorGraySelect == 1){
            colorGraySelect = 2;
            [colorGrayDisplay setStringValue:@"Gray"];
        }
        else if (colorGraySelect == 2){
            colorGraySelect = 0;
            [colorGrayDisplay setStringValue:@"Invert"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)processQuit:(id)sender{
    delete [] arrayFileDelete;
    delete [] wellFov1;
    delete [] wellFov2;
    delete [] wellFov3;
    delete [] wellFov4;
    delete [] wellFov5;
    delete [] wellFov6;
    delete [] wellFov7;
    delete [] wellFov8;
    delete [] fovPosition;
    delete [] histogramHold;
    delete [] wellNoTreatList;
    
    exit(0);
}

-(IBAction)renumberPrivate:(id)sender{
    if (otherProcessOn == 0){
        if (sourcePathNameHold != "nil"){
            DIR *dir;
            struct dirent *dent;
            
            string entry;
            
            dir = opendir(sourcePathNameHold.c_str());
            
            fileDeleteCount = 0;
            
            if (dir != NULL){
                while((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                        arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                    }
                }
                
                closedir(dir);
                
                //----Directory Sort----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                    [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                }
            }
            
            string year = "";
            string month = "";
            string number = "";
            string name = "";
            string stringR;
            string stringI;
            
            string year2 = "";
            string month2 = "";
            string number2 = "";
            string name2 = "";
            
            string nameSource;
            string nameDestination;
            
            int entryCheck = 0;
            int entryCount = 0;
            int imageNoCount = 0;
            
            for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                nameSource = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                nameDestination = sourcePathNameHold+"/"+"a"+arrayFileDelete [counter2];
                
                arrayFileDelete [counter2] = "a"+arrayFileDelete [counter2];
                
                rename (nameSource.c_str(), nameDestination.c_str());
            }
            
            for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                year2 = arrayFileDelete [counter2].substr(1, 2);
                month2 = arrayFileDelete [counter2].substr(4, 4);
                number2 = arrayFileDelete [counter2].substr(9, 4);
                
                if (entryCheck == 0 && year == ""){
                    year = arrayFileDelete [counter2].substr(1, 2);
                    month = arrayFileDelete [counter2].substr(4, 4);
                    number = arrayFileDelete [counter2].substr(9, 4);
                    name = arrayFileDelete [counter2].substr(19);
                    
                    entryCheck = 1;
                    entryCount = 1;
                    imageNoCount = 1;
                    
                    stringR = to_string(entryCount);
                    
                    if ((int)stringR.length() == 1) stringR = "00"+stringR+"0";
                    else if ((int)stringR.length() == 2) stringR = "0"+stringR+"0";
                    else if ((int)stringR.length() == 3) stringR = stringR+"0";
                    
                    stringI = to_string(imageNoCount);
                    
                    if ((int)stringI.length() == 1) stringI = "000"+stringI;
                    else if ((int)stringI.length() == 2) stringI = "00"+stringI;
                    else if ((int)stringI.length() == 3) stringI = "0"+stringI;
                    else if ((int)stringI.length() == 4) stringI = stringI;
                    
                    nameSource = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                    nameDestination = sourcePathNameHold+"/"+year+"-"+month+"-"+stringR+"-"+stringI+"~"+name;
                    
                    rename (nameSource.c_str(), nameDestination.c_str());
                }
                else if (entryCheck == 1 && year == year2 && month == month2 && number == number2){
                    name = arrayFileDelete [counter2].substr(19);
                    
                    stringR = to_string(entryCount);
                    
                    if ((int)stringR.length() == 1) stringR = "00"+stringR+"0";
                    else if ((int)stringR.length() == 2) stringR = "0"+stringR+"0";
                    else if ((int)stringR.length() == 3) stringR = stringR+"0";
                    
                    imageNoCount++;
                    
                    stringI = to_string(imageNoCount);
                    
                    if ((int)stringI.length() == 1) stringI = "000"+stringI;
                    else if ((int)stringI.length() == 2) stringI = "00"+stringI;
                    else if ((int)stringI.length() == 3) stringI = "0"+stringI;
                    else if ((int)stringI.length() == 4) stringI = stringI;
                    
                    nameSource = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                    nameDestination = sourcePathNameHold+"/"+year+"-"+month+"-"+stringR+"-"+stringI+"~"+name;
                    
                    rename (nameSource.c_str(), nameDestination.c_str());
                }
                else if (entryCheck == 1 && (year != year2 || month != month2 || number != number2)){
                    if (year == year2 && month == month2) entryCount++;
                    else  entryCount = 1;
                    
                    year = year2;
                    month = month2;
                    number = number2;
                    name = arrayFileDelete [counter2].substr(19);
                    
                    stringR = to_string(entryCount);
                    
                    if ((int)stringR.length() == 1) stringR = "00"+stringR+"0";
                    else if ((int)stringR.length() == 2) stringR = "0"+stringR+"0";
                    else if ((int)stringR.length() == 3) stringR = stringR+"0";
                    
                    imageNoCount = 1;
                    
                    stringI = to_string(imageNoCount);
                    
                    if ((int)stringI.length() == 1) stringI = "000"+stringI;
                    else if ((int)stringI.length() == 2) stringI = "00"+stringI;
                    else if ((int)stringI.length() == 3) stringI = "0"+stringI;
                    else if ((int)stringI.length() == 4) stringI = stringI;
                    
                    nameSource = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                    nameDestination = sourcePathNameHold+"/"+year+"-"+month+"-"+stringR+"-"+stringI+"~"+name;
                    
                    rename (nameSource.c_str(), nameDestination.c_str());
                }
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select Source Folder"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    if (controllerTimer) [controllerTimer invalidate];
}

@end
