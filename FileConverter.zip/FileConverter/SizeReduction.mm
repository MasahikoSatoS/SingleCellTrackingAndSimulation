//
//  SizeReduction.m
//  FileConverter
//
//  Created by Masahiko Sato on 2018-06-17.
//
//

#import "SizeReduction.h"

@implementation SizeReduction

-(IBAction)sizeReductionSet:(id)sender{
    /*
     //----Image will be divided into four images, Black < 20 (8 bit) or 13005 (16 bit), White > 224 (8 bit) or 52020 (16 bit)
     //----Gray >= 20 and <= 225 (8 bit) or >= 13005 and <= 52020 (16 bit) (Gray scale), or same values in RGB channel (color)
     //----Color different values in RGB
     //----After dividing image into three (Gray) or four (Color), reconstruct image
     //----Reconstruction order: Gray White, Black, Gray
     //----Reconstruction order: Color, Gray White, Black, Gray
     */
    
    if (otherProcessOn == 0){
        if (sourcePathNameHold != "nil"){
            int terminationFlag = 0;
            string extractedID = sourcePathNameHold;
            
            do{
                
                terminationFlag = 1;
                
                if ((int)extractedID.find("/") != -1){
                    extractedID = extractedID.substr(extractedID.find("/")+1);
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            string newFolderPath = destinationPathNameHold+"/"+extractedID+"-"+"new";
            
            mkdir(newFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            DIR *dir;
            struct dirent *dent;
            
            string entry;
            string cellFovPath4;
            
            long sizeForCopy = 0;
            unsigned long totalFileSize = 0;
            unsigned long freeSize = 0;
            unsigned long refSize = 0;
            
            fileDeleteCount = 0;
            
            dir = opendir(sourcePathNameHold.c_str());
            
            if (dir != NULL){
                struct stat sizeOfFile;
                
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    cellFovPath4 = sourcePathNameHold+"/"+entry;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" &&  ((int)entry.find(".TIFF") != -1 || (int)entry.find(".Tiff") != -1 || (int)entry.find(".tiff") != -1 || (int)entry.find(".TIF") != -1 || (int)entry.find(".Tif") != -1 || (int)entry.find(".tif") != -1)){
                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                        arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                        
                        if (stat(cellFovPath4.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                        }
                    }
                }
                
                closedir(dir);
                
                //----Directory Sort----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                    [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                }
            }
            
            if (fileDeleteCount != 0){
                NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(destinationPathNameHold.c_str()) error:nil];
                freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
                refSize = totalFileSize+1048576000; //----1Gb----
                
                if (freeSize > refSize){
                    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
                        otherProcessOn = 1;
                        backSaveOn = 1;
                        
                        string sourceFileName;
                        string tiffExtensionHold;
                        string newFileSaveName;
                        
                        unsigned long nextAddress = 0;
                        unsigned long stripFirstAddress = 0;
                        unsigned long stripByteCountAddress = 0;
                        unsigned long headPosition = 0;
                        unsigned long stripEntry = 0;
                        long sizeForCopy2 = 0;
                        
                        double xPosition = 0;
                        double yPosition = 0;
                        
                        int dimensionAdditionW = 0;
                        int dimensionAdditionH = 0;
                        int newImageDimensionW = 0;
                        int newImageDimensionH = 0;
                        int reductionW = 0;
                        int reductionH = 0;
                        
                        int imageWidth = 0;
                        int imageHeight = 0;
                        int imageBit = 0; // Check 8, 16
                        int imageCompression = 0; // Check 1
                        int photoMetric = 0; //Check 0, 1, 2
                        int imageDimension = 0;
                        int verticalBmp = 0;
                        int horizontalBmp = 0;
                        int horizontalBmpEntry = 0;
                        int endianType = 0;
                        int samplePerPix = 0;
                        int dataConversion [4];
                        int mode = 0;
                        int processType = 3;
                        int numberOfLayers = 0;
                        
                        struct stat sizeOfFile;
                        
                        ifstream fin;
                        
                        for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                            tiffExtensionHold = "";
                            
                            if ((int)arrayFileDelete [counter2].find(".TIFF") != -1) tiffExtensionHold = ".TIFF";
                            else if ((int)arrayFileDelete [counter2].find(".Tiff") != -1) tiffExtensionHold = ".Tiff";
                            else if ((int)arrayFileDelete [counter2].find(".tiff") != -1) tiffExtensionHold = ".tiff";
                            else if ((int)arrayFileDelete [counter2].find(".TIF") != -1 ) tiffExtensionHold = ".TIF";
                            else if ((int)arrayFileDelete [counter2].find(".Tif") != -1) tiffExtensionHold = ".Tif";
                            else if ((int)arrayFileDelete [counter2].find(".tif") != -1) tiffExtensionHold = ".tif";
                            
                            sourceFileName = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                            
                            //----File Read----
                            if (stat(sourceFileName.c_str(), &sizeOfFile) == 0){
                                sizeForCopy2 = sizeOfFile.st_size;
                                
                                fileReadArray = new uint8_t [sizeForCopy2+4];
                                fin.open(sourceFileName.c_str(), ios::in | ios::binary);
                                
                                fin.read((char*)fileReadArray, sizeForCopy2+1);
                                fin.close();
                                
                                headPosition = 0;
                                
                                dataConversion [0] = fileReadArray [0];
                                dataConversion [1] = fileReadArray [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = fileReadArray [7];
                                    dataConversion [1] = fileReadArray [6];
                                    dataConversion [2] = fileReadArray [5];
                                    dataConversion [3] = fileReadArray [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = fileReadArray [4];
                                    dataConversion [1] = fileReadArray [5];
                                    dataConversion [2] = fileReadArray [6];
                                    dataConversion [3] = fileReadArray [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                if (endianType == 1){ //----Big endian----
                                    self->tiffFileRead = [[TiffFileRead alloc] init];
                                    [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                }
                                else if (endianType == 0){
                                    self->tiffFileRead = [[TiffFileRead alloc] init];
                                    [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                }
                                
                                //cout<<imageCompression<<" "<<imageBit<<" "<<plaineNumberTF<<" "<<samplePerPix<<" EntryInfo"<<endl;
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && numberOfLayers == 1 && samplePerPix <= 4 && photoMetric < 3){
                                    int *arrayExtractedImage3 = new int [100];
                                    
                                    if (endianType == 1){
                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                        [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        
                                        if (imageWidth > imageHeight) imageDimension = imageWidth;
                                        else imageDimension = imageHeight;
                                        
                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [self->tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                    }
                                    else if (endianType == 0){
                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                        [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        
                                        if (imageWidth > imageHeight) imageDimension = imageWidth;
                                        else imageDimension = imageHeight;
                                        
                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [self->tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                    }
                                    
                                    dimensionAdditionW = imageWidth%2;
                                    dimensionAdditionH = imageHeight%2;
                                    
                                    newImageDimensionW = imageWidth+dimensionAdditionW;
                                    newImageDimensionH = imageHeight+dimensionAdditionH;
                                    
                                    int **arrayExtractedImage = new int *[newImageDimensionH+1];
                                    
                                    for (int counter3 = 0; counter3 < newImageDimensionH+1; counter3++){
                                        arrayExtractedImage [counter3] = new int [newImageDimensionW*3+1];
                                    }
                                    
                                    for (int counter3 = 0; counter3 < newImageDimensionH+1; counter3++){
                                        for (int counter4 = 0; counter4 < newImageDimensionW*3+1; counter4++){
                                            arrayExtractedImage [counter3][counter4] = 0;
                                        }
                                    }
                                    
                                    verticalBmp = 0;
                                    horizontalBmp = 0;
                                    horizontalBmpEntry = 0;
                                    
                                    for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                        if (verticalBmp < imageHeight){
                                            if (horizontalBmp < imageWidth){
                                                if (photoMetric <= 1){
                                                    arrayExtractedImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3]), horizontalBmpEntry++;
                                                }
                                                else if (photoMetric == 2){
                                                    arrayExtractedImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3]), horizontalBmpEntry++;
                                                    arrayExtractedImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+1]), horizontalBmpEntry++;
                                                    arrayExtractedImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+2]), horizontalBmpEntry++;
                                                }
                                                
                                                horizontalBmp++;
                                            }
                                            
                                            if (horizontalBmp == imageWidth && imageWidth < newImageDimensionW){
                                                for (int counter4 = 0; counter4 < newImageDimensionW-imageWidth; counter4++){
                                                    if (photoMetric <= 1){
                                                        arrayExtractedImage [verticalBmp][horizontalBmpEntry] = -1, horizontalBmpEntry++;
                                                    }
                                                    else if (photoMetric == 2){
                                                        arrayExtractedImage [verticalBmp][horizontalBmpEntry] = -1, horizontalBmpEntry++;
                                                        arrayExtractedImage [verticalBmp][horizontalBmpEntry] = -1, horizontalBmpEntry++;
                                                        arrayExtractedImage [verticalBmp][horizontalBmpEntry] = -1, horizontalBmpEntry++;
                                                    }
                                                }
                                            }
                                            
                                            if (horizontalBmp == imageWidth){
                                                horizontalBmp = 0;
                                                horizontalBmpEntry = 0;
                                                verticalBmp++;
                                            }
                                        }
                                    }
                                    
                                    if (imageHeight < newImageDimensionH){
                                        for (int counter3 = imageHeight; counter3 < newImageDimensionH; counter3++){
                                            for (int counter4 = 0; counter4 < newImageDimensionW; counter4++){
                                                if (photoMetric <= 1){
                                                    arrayExtractedImage [counter3][counter4] = -1;
                                                }
                                                else if (photoMetric == 2){
                                                    arrayExtractedImage [counter3][counter4] = -1;
                                                    arrayExtractedImage [counter3][counter4] = -1;
                                                    arrayExtractedImage [counter3][counter4] = -1;
                                                }
                                            }
                                        }
                                    }
                                    
                                    int **blackMap = new int *[imageHeight+2];
                                    int **grayMap = new int *[imageHeight+2];
                                    int **whiteMap = new int *[imageHeight+2];
                                    int **colorMap = new int *[imageHeight+2];
                                    
                                    for (int counter3 = 0; counter3 < imageHeight+2; counter3++){
                                        blackMap [counter3] = new int [imageWidth*3+2];
                                        grayMap [counter3] = new int [imageWidth*3+2];
                                        whiteMap [counter3] = new int [imageWidth*3+2];
                                        colorMap [counter3] = new int [imageWidth*3+2];
                                    }
                                    
                                    for (int counter3 = 0; counter3 < imageHeight+2; counter3++){
                                        for (int counter4 = 0; counter4 < imageWidth*3+2; counter4++){
                                            blackMap [counter3][counter4] = -1;
                                            grayMap [counter3][counter4] = -1;
                                            whiteMap [counter3][counter4] = -1;
                                            colorMap [counter3][counter4] = -1;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < imageHeight; counter3++){
                                        for (int counter4 = 0; counter4 < imageWidth; counter4++){
                                            if (imageBit == 8 && (photoMetric == 0 || photoMetric == 1)){
                                                if (arrayExtractedImage [counter3][counter4] < 20) blackMap [counter3][counter4] = arrayExtractedImage [counter3][counter4];
                                                else if (arrayExtractedImage [counter3][counter4] > 224) whiteMap [counter3][counter4] = arrayExtractedImage [counter3][counter4];
                                                else grayMap [counter3][counter4] = arrayExtractedImage [counter3][counter4];
                                            }
                                            
                                            else if (imageBit == 16 && (photoMetric == 0 || photoMetric == 1)){
                                                if (arrayExtractedImage [counter3][counter4] < 13005) blackMap [counter3][counter4] = arrayExtractedImage [counter3][counter4];
                                                else if (arrayExtractedImage [counter3][counter4] > 52020) whiteMap [counter3][counter4] = arrayExtractedImage [counter3][counter4];
                                                else grayMap [counter3][counter4] = arrayExtractedImage [counter3][counter4];
                                            }
                                            else if (imageBit == 8 && photoMetric == 2){
                                                if (arrayExtractedImage [counter3][counter4*3] == arrayExtractedImage [counter3][counter4*3+1] && arrayExtractedImage [counter3][counter4*3] == arrayExtractedImage [counter3][counter4*3+2]){
                                                    if (arrayExtractedImage [counter3][counter4*3] < 20 && arrayExtractedImage [counter3][counter4*3+1] < 20 && arrayExtractedImage [counter3][counter4*3+2] < 20){
                                                        blackMap [counter3][counter4*3] = arrayExtractedImage [counter3][counter4*3];
                                                        blackMap [counter3][counter4*3+1] = arrayExtractedImage [counter3][counter4*3+1];
                                                        blackMap [counter3][counter4*3+2] = arrayExtractedImage [counter3][counter4*3+2];
                                                    }
                                                    else if (arrayExtractedImage [counter3][counter4*3] > 224 && arrayExtractedImage [counter3][counter4*3+1] > 224 && arrayExtractedImage [counter3][counter4*3+2] > 224){
                                                        whiteMap [counter3][counter4*3] = arrayExtractedImage [counter3][counter4*3];
                                                        whiteMap [counter3][counter4*3+1] = arrayExtractedImage [counter3][counter4*3+1];
                                                        whiteMap [counter3][counter4*3+2] = arrayExtractedImage [counter3][counter4*3+2];
                                                    }
                                                    else{
                                                        
                                                        grayMap [counter3][counter4*3] = arrayExtractedImage [counter3][counter4*3];
                                                        grayMap [counter3][counter4*3+1] = arrayExtractedImage [counter3][counter4*3+1];
                                                        grayMap [counter3][counter4*3+2] = arrayExtractedImage [counter3][counter4*3+2];
                                                    }
                                                }
                                                else{
                                                    
                                                    colorMap [counter3][counter4*3] = arrayExtractedImage [counter3][counter4*3];
                                                    colorMap [counter3][counter4*3+1] = arrayExtractedImage [counter3][counter4*3+1];
                                                    colorMap [counter3][counter4*3+2] = arrayExtractedImage [counter3][counter4*3+2];
                                                }
                                            }
                                            else if (imageBit == 16 && photoMetric == 2){
                                                if (arrayExtractedImage [counter3][counter4*3] == arrayExtractedImage [counter3][counter4*3+1] && arrayExtractedImage [counter3][counter4*3] == arrayExtractedImage [counter3][counter4*3+2]){
                                                    if (arrayExtractedImage [counter3][counter4*3] < 13005 && arrayExtractedImage [counter3][counter4*3+1] < 13005 && arrayExtractedImage [counter3][counter4*3+2] < 13005){
                                                        blackMap [counter3][counter4*3] = arrayExtractedImage [counter3][counter4*3];
                                                        blackMap [counter3][counter4*3+1] = arrayExtractedImage [counter3][counter4*3+1];
                                                        blackMap [counter3][counter4*3+2] = arrayExtractedImage [counter3][counter4*3+2];
                                                    }
                                                    else if (arrayExtractedImage [counter3][counter4*3] > 52020 && arrayExtractedImage [counter3][counter4*3+1] > 52020 && arrayExtractedImage [counter3][counter4*3+2] > 52020){
                                                        whiteMap [counter3][counter4*3] = arrayExtractedImage [counter3][counter4*3];
                                                        whiteMap [counter3][counter4*3+1] = arrayExtractedImage [counter3][counter4*3+1];
                                                        whiteMap [counter3][counter4*3+2] = arrayExtractedImage [counter3][counter4*3+2];
                                                    }
                                                    else{
                                                        
                                                        grayMap [counter3][counter4*3] = arrayExtractedImage [counter3][counter4*3];
                                                        grayMap [counter3][counter4*3+1] = arrayExtractedImage [counter3][counter4*3+1];
                                                        grayMap [counter3][counter4*3+2] = arrayExtractedImage [counter3][counter4*3+2];
                                                    }
                                                }
                                                else{
                                                    
                                                    colorMap [counter3][counter4*3] = arrayExtractedImage [counter3][counter4*3];
                                                    colorMap [counter3][counter4*3+1] = arrayExtractedImage [counter3][counter4*3+1];
                                                    colorMap [counter3][counter4*3+2] = arrayExtractedImage [counter3][counter4*3+2];
                                                }
                                            }
                                        }
                                    }
                                    
                                    reductionW = newImageDimensionW/2;
                                    reductionH = newImageDimensionH/2;
                                    
                                    int **blackRedMap = new int *[reductionH+2];
                                    int **grayRedMap = new int *[reductionH+2];
                                    int **whiteRedMap = new int *[reductionH+2];
                                    int **colorRedMap = new int *[reductionH+2];
                                    
                                    int **blackCountMap = new int *[reductionH+2];
                                    int **grayCountMap = new int *[reductionH+2];
                                    int **whiteCountMap = new int *[reductionH+2];
                                    int **colorCountMap = new int *[reductionH+2];
                                    
                                    for (int counter3 = 0; counter3 < reductionH+2; counter3++){
                                        blackRedMap [counter3] = new int [reductionW*3+2];
                                        grayRedMap [counter3] = new int [reductionW*3+2];
                                        whiteRedMap [counter3] = new int [reductionW*3+2];
                                        colorRedMap [counter3] = new int [reductionW*3+2];
                                        
                                        blackCountMap [counter3] = new int [reductionW*3+2];
                                        grayCountMap [counter3] = new int [reductionW*3+2];
                                        whiteCountMap [counter3] = new int [reductionW*3+2];
                                        colorCountMap [counter3] = new int [reductionW*3+2];
                                    }
                                    
                                    for (int counter3 = 0; counter3 < reductionH+2; counter3++){
                                        for (int counter4 = 0; counter4 < reductionW*3+2; counter4++){
                                            blackRedMap [counter3][counter4] = 0;
                                            grayRedMap [counter3][counter4] = 0;
                                            whiteRedMap [counter3][counter4] = 0;
                                            colorRedMap [counter3][counter4] = 0;
                                            
                                            blackCountMap [counter3][counter4] = 0;
                                            grayCountMap [counter3][counter4] = 0;
                                            whiteCountMap [counter3][counter4] = 0;
                                            colorCountMap [counter3][counter4] = 0;
                                        }
                                    }
                                    
                                    int horizontalCount = 0;
                                    int verticalCount = 0;
                                    int verticalLineRepeat = 0;
                                    
                                    if (photoMetric == 0 || photoMetric == 1){
                                        for (int counter5 = 0; counter5 < imageHeight; counter5++){
                                            for (int counter6 = 0; counter6 < imageWidth; counter6 = counter6+2){
                                                if (blackMap [counter5][counter6] != -1){
                                                    blackRedMap [verticalCount][horizontalCount] = blackRedMap [verticalCount][horizontalCount]+blackMap [counter5][counter6];
                                                    blackCountMap [verticalCount][horizontalCount]++;
                                                }
                                                
                                                if (blackMap [counter5][counter6+1] != -1){
                                                    blackRedMap [verticalCount][horizontalCount] = blackRedMap [verticalCount][horizontalCount]+blackMap [counter5][counter6+1];
                                                    blackCountMap [verticalCount][horizontalCount]++;
                                                }
                                                
                                                if (whiteMap [counter5][counter6] != -1){
                                                    whiteRedMap [verticalCount][horizontalCount] = whiteRedMap [verticalCount][horizontalCount]+whiteMap [counter5][counter6];
                                                    whiteCountMap [verticalCount][horizontalCount]++;
                                                }
                                                
                                                if (whiteMap [counter5][counter6+1] != -1){
                                                    whiteRedMap [verticalCount][horizontalCount] = whiteRedMap [verticalCount][horizontalCount]+whiteMap [counter5][counter6+1];
                                                    whiteCountMap [verticalCount][horizontalCount]++;
                                                }
                                                
                                                if (grayMap [counter5][counter6] != -1){
                                                    grayRedMap [verticalCount][horizontalCount] = grayRedMap [verticalCount][horizontalCount]+grayMap [counter5][counter6];
                                                    grayCountMap [verticalCount][horizontalCount]++;
                                                }
                                                
                                                if (grayMap [counter5][counter6+1] != -1){
                                                    grayRedMap [verticalCount][horizontalCount] = grayRedMap [verticalCount][horizontalCount]+grayMap [counter5][counter6+1];
                                                    grayCountMap [verticalCount][horizontalCount]++;
                                                }
                                                
                                                horizontalCount++;
                                            }
                                            
                                            horizontalCount = 0;
                                            verticalLineRepeat++;
                                            
                                            if (verticalLineRepeat == 2){
                                                verticalLineRepeat = 0;
                                                verticalCount++;
                                            }
                                        }
                                        
                                        for (int counter5 = 0; counter5 < reductionH; counter5++){
                                            for (int counter6 = 0; counter6 < reductionW; counter6++){
                                                if (blackCountMap [counter5][counter6] != 0){
                                                    blackRedMap [counter5][counter6] = (int)(blackRedMap [counter5][counter6]/(double)blackCountMap [counter5][counter6]);
                                                }
                                                if (whiteCountMap [counter5][counter6] != 0){
                                                    whiteRedMap [counter5][counter6] = (int)(whiteRedMap [counter5][counter6]/(double)whiteCountMap [counter5][counter6]);
                                                }
                                                if (grayCountMap [counter5][counter6] != 0){
                                                    grayRedMap [counter5][counter6] = (int)(grayRedMap [counter5][counter6]/(double)grayCountMap [counter5][counter6]);
                                                }
                                            }
                                        }
                                        
                                        for (int counter5 = 0; counter5 < reductionH; counter5++){
                                            for (int counter6 = 0; counter6 < reductionW; counter6++){
                                                if (whiteRedMap [counter5][counter6] != -1){
                                                    grayRedMap [counter5][counter6] = whiteRedMap [counter5][counter6];
                                                }
                                                else if (blackRedMap [counter5][counter6] != -1){
                                                    grayRedMap [counter5][counter6] = blackRedMap [counter5][counter6];
                                                }
                                                else if (grayRedMap [counter5][counter6] == -1){
                                                    grayRedMap [counter5][counter6] = 0;
                                                }
                                            }
                                        }
                                    }
                                    else{
                                        
                                        for (int counter5 = 0; counter5 < imageHeight; counter5++){
                                            for (int counter6 = 0; counter6 < imageWidth; counter6 = counter6+2){
                                                if (blackMap [counter5][counter6*3] != -1){
                                                    blackRedMap [verticalCount][horizontalCount*3] = blackRedMap [verticalCount][horizontalCount*3]+blackMap [counter5][counter6*3];
                                                    blackCountMap [verticalCount][horizontalCount*3]++;
                                                    blackRedMap [verticalCount][horizontalCount*3+1] = blackRedMap [verticalCount][horizontalCount*3+1]+blackMap [counter5][counter6*3+1];
                                                    blackCountMap [verticalCount][horizontalCount*3+1]++;
                                                    blackRedMap [verticalCount][horizontalCount*3+2] = blackRedMap [verticalCount][horizontalCount*3+2]+blackMap [counter5][counter6*3+2];
                                                    blackCountMap [verticalCount][horizontalCount*3+2]++;
                                                }
                                                
                                                if (blackMap [counter5][counter6*3+3] != -1){
                                                    blackRedMap [verticalCount][horizontalCount*3] = blackRedMap [verticalCount][horizontalCount*3]+blackMap [counter5][counter6*3+3];
                                                    blackCountMap [verticalCount][horizontalCount*3]++;
                                                    blackRedMap [verticalCount][horizontalCount*3+1] = blackRedMap [verticalCount][horizontalCount*3+1]+blackMap [counter5][counter6*3+4];
                                                    blackCountMap [verticalCount][horizontalCount*3+1]++;
                                                    blackRedMap [verticalCount][horizontalCount*3+2] = blackRedMap [verticalCount][horizontalCount*3+2]+blackMap [counter5][counter6*3+5];
                                                    blackCountMap [verticalCount][horizontalCount*3+2]++;
                                                }
                                                
                                                if (whiteMap [counter5][counter6*3] != -1){
                                                    whiteRedMap [verticalCount][horizontalCount*3] = whiteRedMap [verticalCount][horizontalCount*3]+whiteMap [counter5][counter6*3];
                                                    whiteCountMap [verticalCount][horizontalCount*3]++;
                                                    whiteRedMap [verticalCount][horizontalCount*3+1] = whiteRedMap [verticalCount][horizontalCount*3+1]+whiteMap [counter5][counter6*3+1];
                                                    whiteCountMap [verticalCount][horizontalCount*3+1]++;
                                                    whiteRedMap [verticalCount][horizontalCount*3+2] = whiteRedMap [verticalCount][horizontalCount*3+2]+whiteMap [counter5][counter6*3+2];
                                                    whiteCountMap [verticalCount][horizontalCount*3+2]++;
                                                }
                                                
                                                if (whiteMap [counter5][counter6*3+4] != -1){
                                                    whiteRedMap [verticalCount][horizontalCount*3] = whiteRedMap [verticalCount][horizontalCount*3]+whiteMap [counter5][counter6*3+3];
                                                    whiteCountMap [verticalCount][horizontalCount*3]++;
                                                    whiteRedMap [verticalCount][horizontalCount*3+1] = whiteRedMap [verticalCount][horizontalCount*3+1]+whiteMap [counter5][counter6*3+4];
                                                    whiteCountMap [verticalCount][horizontalCount*3+1]++;
                                                    whiteRedMap [verticalCount][horizontalCount*3+2] = whiteRedMap [verticalCount][horizontalCount*3+2]+whiteMap [counter5][counter6*3+5];
                                                    whiteCountMap [verticalCount][horizontalCount*3+2]++;
                                                }
                                                
                                                if (grayMap [counter5][counter6*3] != -1){
                                                    grayRedMap [verticalCount][horizontalCount*3] = grayRedMap [verticalCount][horizontalCount*3]+grayMap [counter5][counter6*3];
                                                    grayCountMap [verticalCount][horizontalCount*3]++;
                                                    grayRedMap [verticalCount][horizontalCount*3+1] = grayRedMap [verticalCount][horizontalCount*3+1]+grayMap [counter5][counter6*3+1];
                                                    grayCountMap [verticalCount][horizontalCount*3+1]++;
                                                    grayRedMap [verticalCount][horizontalCount*3+2] = grayRedMap [verticalCount][horizontalCount*3+2]+grayMap [counter5][counter6*3+2];
                                                    grayCountMap [verticalCount][horizontalCount*3+2]++;
                                                }
                                                
                                                if (grayMap [counter5][counter6*3+3] != -1){
                                                    grayRedMap [verticalCount][horizontalCount*3] = grayRedMap [verticalCount][horizontalCount*3]+grayMap [counter5][counter6*3+3];
                                                    grayCountMap [verticalCount][horizontalCount*3]++;
                                                    grayRedMap [verticalCount][horizontalCount*3+1] = grayRedMap [verticalCount][horizontalCount*3+1]+grayMap [counter5][counter6*3+4];
                                                    grayCountMap [verticalCount][horizontalCount*3+1]++;
                                                    grayRedMap [verticalCount][horizontalCount*3+2] = grayRedMap [verticalCount][horizontalCount*3+2]+grayMap [counter5][counter6*3+5];
                                                    grayCountMap [verticalCount][horizontalCount*3+2]++;
                                                }
                                                
                                                if (colorMap [counter5][counter6*3] != -1){
                                                    colorRedMap [verticalCount][horizontalCount*3] = colorRedMap [verticalCount][horizontalCount*3]+colorMap [counter5][counter6*3];
                                                    colorCountMap [verticalCount][horizontalCount*3]++;
                                                    colorRedMap [verticalCount][horizontalCount*3+1] = colorRedMap [verticalCount][horizontalCount*3+1]+colorMap [counter5][counter6*3+1];
                                                    colorCountMap [verticalCount][horizontalCount*3+1]++;
                                                    colorRedMap [verticalCount][horizontalCount*3+2] = colorRedMap [verticalCount][horizontalCount*3+2]+colorMap [counter5][counter6*3+2];
                                                    colorCountMap [verticalCount][horizontalCount*3+2]++;
                                                }
                                                
                                                if (colorMap [counter5][counter6*3+3] != -1){
                                                    colorRedMap [verticalCount][horizontalCount*3] = colorRedMap [verticalCount][horizontalCount*3]+colorMap [counter5][counter6*3+3];
                                                    colorCountMap [verticalCount][horizontalCount*3]++;
                                                    colorRedMap [verticalCount][horizontalCount*3+1] = colorRedMap [verticalCount][horizontalCount*3+1]+colorMap [counter5][counter6*3+4];
                                                    colorCountMap [verticalCount][horizontalCount*3+1]++;
                                                    colorRedMap [verticalCount][horizontalCount*3+2] = colorRedMap [verticalCount][horizontalCount*3+2]+colorMap [counter5][counter6*3+5];
                                                    colorCountMap [verticalCount][horizontalCount*3+2]++;
                                                }
                                                
                                                horizontalCount++;
                                            }
                                            
                                            horizontalCount = 0;
                                            verticalLineRepeat++;
                                            
                                            if (verticalLineRepeat == 2){
                                                verticalLineRepeat = 0;
                                                verticalCount++;
                                            }
                                        }
                                        
                                        for (int counter5 = 0; counter5 < reductionH; counter5++){
                                            for (int counter6 = 0; counter6 < reductionW; counter6++){
                                                if (blackCountMap [counter5][counter6*3] != 0){
                                                    blackRedMap [counter5][counter6*3] = (int)(blackRedMap [counter5][counter6*3]/(double)blackCountMap [counter5][counter6*3]);
                                                    blackRedMap [counter5][counter6*3+1] = (int)(blackRedMap [counter5][counter6*3+1]/(double)blackCountMap [counter5][counter6*3+1]);
                                                    blackRedMap [counter5][counter6*3+2] = (int)(blackRedMap [counter5][counter6*3+2]/(double)blackCountMap [counter5][counter6*3+2]);
                                                }
                                                if (whiteCountMap [counter5][counter6*3] != 0){
                                                    whiteRedMap [counter5][counter6*3] = (int)(whiteRedMap [counter5][counter6*3]/(double)whiteCountMap [counter5][counter6*3]);
                                                    whiteRedMap [counter5][counter6*3+1] = (int)(whiteRedMap [counter5][counter6*3+1]/(double)whiteCountMap [counter5][counter6*3+1]);
                                                    whiteRedMap [counter5][counter6*3+2] = (int)(whiteRedMap [counter5][counter6*3+2]/(double)whiteCountMap [counter5][counter6*3+2]);
                                                }
                                                if (grayCountMap [counter5][counter6*3] != 0){
                                                    grayRedMap [counter5][counter6*3] = (int)(grayRedMap [counter5][counter6*3]/(double)grayCountMap [counter5][counter6*3]);
                                                    grayRedMap [counter5][counter6*3+1] = (int)(grayRedMap [counter5][counter6*3+1]/(double)grayCountMap [counter5][counter6*3+1]);
                                                    grayRedMap [counter5][counter6*3+2] = (int)(grayRedMap [counter5][counter6*3+2]/(double)grayCountMap [counter5][counter6*3+2]);
                                                }
                                                if (colorCountMap [counter5][counter6*3] != 0){
                                                    colorRedMap [counter5][counter6*3] = (int)(colorRedMap [counter5][counter6*3]/(double)colorCountMap [counter5][counter6*3]);
                                                    colorRedMap [counter5][counter6*3+1] = (int)(colorRedMap [counter5][counter6*3+1]/(double)colorCountMap [counter5][counter6*3+1]);
                                                    colorRedMap [counter5][counter6*3+2] = (int)(colorRedMap [counter5][counter6*3+2]/(double)colorCountMap [counter5][counter6*3+2]);
                                                }
                                            }
                                        }
                                        
                                        for (int counter5 = 0; counter5 < reductionH; counter5++){
                                            for (int counter6 = 0; counter6 < reductionW; counter6++){
                                                if (colorRedMap [counter5][counter6*3] != 0){
                                                    colorRedMap [counter5][counter6*3] = colorRedMap [counter5][counter6*3];
                                                    colorRedMap [counter5][counter6*3+1] = colorRedMap [counter5][counter6*3+1];
                                                    colorRedMap [counter5][counter6*3+2] = colorRedMap [counter5][counter6*3+2];
                                                }
                                                else if (whiteRedMap [counter5][counter6*3] != 0){
                                                    colorRedMap [counter5][counter6*3] = whiteRedMap [counter5][counter6*3];
                                                    colorRedMap [counter5][counter6*3+1] = whiteRedMap [counter5][counter6*3+1];
                                                    colorRedMap [counter5][counter6*3+2] = whiteRedMap [counter5][counter6*3+2];
                                                }
                                                else if (blackRedMap [counter5][counter6*3] != 0){
                                                    colorRedMap [counter5][counter6*3] = blackRedMap [counter5][counter6*3];
                                                    colorRedMap [counter5][counter6*3+1] = blackRedMap [counter5][counter6*3+1];
                                                    colorRedMap [counter5][counter6*3+2] = blackRedMap [counter5][counter6*3+2];
                                                }
                                                else if (grayRedMap [counter5][counter6*3] != 0){
                                                    colorRedMap [counter5][counter6*3] = grayRedMap [counter5][counter6*3];
                                                    colorRedMap [counter5][counter6*3+1] = grayRedMap [counter5][counter6*3+1];
                                                    colorRedMap [counter5][counter6*3+2] = grayRedMap [counter5][counter6*3+2];
                                                }
                                            }
                                        }
                                        
                                        for (int counter5 = 0; counter5 < reductionH; counter5++){
                                            for (int counter6 = 0; counter6 < reductionW; counter6++){
                                                if (colorRedMap [counter5][counter6*3] == -1) colorRedMap [counter5][counter6*3] = 0;
                                                if (colorRedMap [counter5][counter6*3+1] == -1) colorRedMap [counter5][counter6*3+1] = 0;
                                                if (colorRedMap [counter5][counter6*3+2] == -1) colorRedMap [counter5][counter6*3+2] = 0;
                                            }
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < imageHeight+2; counter3++){
                                        delete [] blackMap [counter3];
                                        delete [] grayMap [counter3];
                                        delete [] whiteMap [counter3];
                                        delete [] colorMap [counter3];
                                    }
                                    
                                    delete [] blackMap;
                                    delete [] grayMap;
                                    delete [] whiteMap;
                                    delete [] colorMap;
                                    
                                    arrayImageFileSave = new int *[reductionH+1];
                                    
                                    for (int counter5 = 0; counter5 < reductionH+1; counter5++){
                                        arrayImageFileSave [counter5] = new int [reductionW*3+1];
                                    }
                                    
                                    if (photoMetric == 0 || photoMetric == 1){
                                        for (int counter5 = 0; counter5 < reductionH; counter5++){
                                            for (int counter6 = 0; counter6 < reductionW; counter6++){
                                                arrayImageFileSave [counter5][counter6] = grayRedMap [counter5][counter6];
                                            }
                                        }
                                    }
                                    else if (photoMetric == 2){
                                        for (int counter5 = 0; counter5 < reductionH; counter5++){
                                            for (int counter6 = 0; counter6 < reductionW; counter6++){
                                                arrayImageFileSave [counter5][counter6*3] = colorRedMap [counter5][counter6*3];
                                                arrayImageFileSave [counter5][counter6*3+1] = colorRedMap [counter5][counter6*3+1];
                                                arrayImageFileSave [counter5][counter6*3+2] = colorRedMap [counter5][counter6*3+2];
                                            }
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < reductionH+2; counter3++){
                                        delete [] blackRedMap [counter3];
                                        delete [] grayRedMap [counter3];
                                        delete [] whiteRedMap [counter3];
                                        delete [] colorRedMap [counter3];
                                        
                                        delete [] blackCountMap [counter3];
                                        delete [] grayCountMap [counter3];
                                        delete [] whiteCountMap [counter3];
                                        delete [] colorCountMap [counter3];
                                    }
                                    
                                    delete [] blackRedMap;
                                    delete [] grayRedMap;
                                    delete [] whiteRedMap;
                                    delete [] colorRedMap;
                                    
                                    delete [] blackCountMap;
                                    delete [] grayCountMap;
                                    delete [] whiteCountMap;
                                    delete [] colorCountMap;
                                    
                                    fileSavePathHold = newFolderPath+"/"+arrayFileDelete [counter2];
                                    
                                    if (photoMetric == 0) photoMetric = 1;
                                    if (samplePerPix == 4) samplePerPix = 3;
                                    
                                    if (xPosition == -1) xPosition = 100;
                                    if (yPosition == -1) yPosition = 100;
                                    
                                    self->singleTiffSave = [[SingleTiffSave alloc] init];
                                    [self->singleTiffSave singleTiffLayerSave:reductionW:reductionH:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:(unsigned long)mode];
                                    
                                    for (int counter3 = 0; counter3 < newImageDimensionH+1; counter3++){
                                        delete [] arrayExtractedImage [counter3];
                                    }
                                    
                                    delete [] arrayExtractedImage;
                                    
                                    for (int counter3 = 0; counter3 < reductionH+1; counter3++){
                                        delete [] arrayImageFileSave [counter3];
                                    }
                                    
                                    delete [] arrayImageFileSave;
                                }
                                
                                delete [] fileReadArray;
                            }
                        }
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        backSaveOn = 3;
                        otherProcessOn = 0;
                    });
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Disk Space Low"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select Source Folder"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

@end
