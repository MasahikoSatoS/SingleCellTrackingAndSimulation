//
//  Processing.m
//  FileConverter
//
//  Created by Masahiko Sato on 2018-06-05.
//
//

#import "Processing.h"

@implementation Processing

-(IBAction)tiffToProducts:(id)sender{
    /*
     //----Input format Folder/treat (Folder)/FOV**1 (folder)/Cont_0001-FOV001.tif
     //----Convert single layer Tiff to Products (Analysis information, Source_images and Temp_images)
     //----In the case of 16 bit tif, convert to 8 bit bmp
     //----FOV positions have to be set
     //----Option, Mean: Move mean to the set value: e.g. average 100, Mean: 90, 90 to be 100//if < fold set, after mean shift, (pix value-mean)*fold//if > fold set, after mean shift, (mean-pix value)*fold
     //----Option, Below cut: value below the cut will be replaced with the set value----
     //----Option, Above cut: value above cut will be multiplied by fold, e.g Cut: 100, pix value: 120, fold: 1.5, new value = (120-100)*1.5
     //----Option, Extract Tif range: Average: convert 16 bit to 8 bit, Range From-To: Extract range of 16 bit image and convert to 8 bit image
     //----Option Tiff reduction, reduce Tiff size to 1/2
     
     //----FOV setting: if no body name is given, number of FOVs in each well will be checked based on the finding order. If a body name is given, the number of FOVs that corresponds to the body name will be searched
     */
    
    if (otherProcessOn == 0){
        if (sourcePathNameHold != "nil" && destinationPathNameHold != "nil"){
            int terminationFlag = 0;
            
            if (fovStatusHold == 1){
                string extractedID = sourcePathNameHold;
                
                do{
                    
                    terminationFlag = 1;
                    
                    if ((int)extractedID.find("/") != -1) extractedID = extractedID.substr(extractedID.find("/")+1);
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                string newFolderPath = destinationPathNameHold+"/"+extractedID+"_Products";
                
                int folderCreationCheck = 0;
                
                folderCreationCheck = mkdir(newFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                if (folderCreationCheck == 0){
                    if (contrastActivateHold == 1){
                        if (contrastMeanHold <= 0 || contrastMeanHold > 255){
                            contrastMeanHold = -1;
                            [contrastMeanDisplay setStringValue:@""];
                            [valueMeanAboveDisplay setStringValue:@""];
                            [valueMeanBelowDisplay setStringValue:@""];
                        }
                        else{
                            
                            if (meanAboveFoldHold <= 0 || meanAboveFoldHold > 255) meanAboveFoldHold = -1;
                            if (meanBelowFoldHold <= 0 || meanBelowFoldHold > 255) meanBelowFoldHold = -1;
                        }
                        
                        if (belowCutHold <= 0 || belowCutHold > 255){
                            belowCutHold = -1;
                            valueBelowHold = -1;
                            [belowCutDisplay setStringValue:@""];
                            [valueBelowDisplay setStringValue:@""];
                        }
                        else{
                            
                            if (valueBelowHold <= 0 || valueBelowHold > 255){
                                belowCutHold = -1;
                                valueBelowHold = -1;
                                [belowCutDisplay setStringValue:@""];
                                [valueBelowDisplay setStringValue:@""];
                            }
                        }
                        
                        if (aboveCutHold <= 0 || aboveCutHold > 255){
                            aboveCutHold = -1;
                            valueFoldHold = -1;
                            [aboveCutDisplay setStringValue:@""];
                            [valueFoldDisplay setStringValue:@""];
                        }
                        else{
                            
                            if (valueFoldHold <= 0 || valueFoldHold > 255){
                                aboveCutHold = -1;
                                valueFoldHold = -1;
                                [aboveCutDisplay setStringValue:@""];
                                [valueFoldDisplay setStringValue:@""];
                            }
                        }
                        
                        if (tiff16To8Hold == 1){
                            if (rangeFromHold == -1 || rangeToHold == -1){
                                rangeFromHold = -1;
                                rangeToHold = -1;
                                tiff16To8Hold = 0;
                                [rangeFromDisplay setStringValue:@""];
                                [rangeToDisplay setStringValue:@""];
                                [tiff16To8Display setStringValue:@"Average"];
                            }
                            else if (rangeFromHold >= rangeToHold){
                                rangeFromHold = -1;
                                rangeToHold = -1;
                                tiff16To8Hold = 0;
                                [rangeFromDisplay setStringValue:@""];
                                [rangeToDisplay setStringValue:@""];
                                [tiff16To8Display setStringValue:@"Average"];
                            }
                        }
                        else if (tiff16To8Hold == 0 && (rangeFromHold != -1 || rangeToHold != -1)){
                            rangeFromHold = -1;
                            rangeToHold = -1;
                            [rangeFromDisplay setStringValue:@""];
                            [rangeToDisplay setStringValue:@""];
                        }
                    }
                    
                    DIR *dir;
                    struct dirent *dent;
                    DIR *dir2;
                    struct dirent *dent2;
                    
                    string entry;
                    string entry2;
                    string cellFolderPath;
                    string treatNameExtract;
                    
                    int wellCount = 0;
                    int fovNumber = 0;
                    int fovCheck = 0;
                    int fovMisMatch = 0;
                    int wellCountOption = 0;
                    
                    string *fovData =  new string [1000];
                    string *treatName = new string [1000];
                    string *contrastData = new string [4000];
                    
                    for (int counter2 = 0; counter2 < 1000; counter2++){
                        fovData [counter2] = "nil";
                        treatName [counter2] = "nil";
                    }
                    
                    wellNoTreatListCount = 0;
                    int matchFind = 0;
                    
                    for (int counter2 = 0; counter2 < wellNoTreatListCount; counter2++) wellNoTreatList [counter2] = "0";
                    
                    dir = opendir(sourcePathNameHold.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if ((int)entry.find("~") != -1){
                                    treatNameExtract = entry.substr(0, entry.find("~"));
                                }
                                else treatNameExtract = entry;
                                
                                matchFind = 0;
                                
                                for (int counter2 = 0; counter2 < wellNoTreatListCount/2; counter2++){
                                    if (wellNoTreatList [counter2*2] == treatNameExtract) matchFind = 1;
                                }
                                
                                if (matchFind == 0){
                                    wellNoTreatList [wellNoTreatListCount] = treatNameExtract, wellNoTreatListCount++;
                                    wellNoTreatList [wellNoTreatListCount] = "0", wellNoTreatListCount++;
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    //for (int counterA = 0; counterA < wellNoTreatListCount/2; counterA++){
                    //    cout<<wellNoTreatList [counterA*2]<<" "<<wellNoTreatList [counterA*2+1]<<" Well"<<endl;
                    //}
                    
                    string bodystring1 = "nil";
                    string bodystring2 = "nil";
                    string bodystring3 = "nil";
                    string bodystring4 = "nil";
                    string bodystring5 = "nil";
                    string bodystring6 = "nil";
                    string bodystring7 = "nil";
                    string bodystring8 = "nil";
                    
                    if ([body1 stringValue] != NULL) bodystring1 = [[body1 stringValue] UTF8String];
                    if ([body2 stringValue] != NULL) bodystring2 = [[body2 stringValue] UTF8String];
                    if ([body3 stringValue] != NULL) bodystring3 = [[body3 stringValue] UTF8String];
                    if ([body4 stringValue] != NULL) bodystring4 = [[body4 stringValue] UTF8String];
                    if ([body5 stringValue] != NULL) bodystring5 = [[body5 stringValue] UTF8String];
                    if ([body6 stringValue] != NULL) bodystring6 = [[body6 stringValue] UTF8String];
                    if ([body7 stringValue] != NULL) bodystring7 = [[body7 stringValue] UTF8String];
                    if ([body8 stringValue] != NULL) bodystring8 = [[body8 stringValue] UTF8String];
                    
                    if (bodystring1 != "nil"){
                        for (int counter2 = 0; counter2 < wellNoTreatListCount/2; counter2++){
                            if (wellNoTreatList [counter2*2] == bodystring1){
                                fovCheck = 0;
                                
                                for (int counter3 = 1; counter3 <= 49; counter3++){
                                    if (wellFov1 [counter3] != 0){
                                        fovCheck = 1;
                                        break;
                                    }
                                }
                                
                                if (fovCheck == 1) wellNoTreatList [counter2*2+1] = "1";
                            }
                        }
                    }
                    
                    if (bodystring2 != "nil"){
                        for (int counter2 = 0; counter2 < wellNoTreatListCount/2; counter2++){
                            if (wellNoTreatList [counter2*2] == bodystring2){
                                fovCheck = 0;
                                
                                for (int counter3 = 1; counter3 <= 49; counter3++){
                                    if (wellFov2 [counter3] != 0){
                                        fovCheck = 1;
                                        break;
                                    }
                                }
                                
                                if (fovCheck == 1) wellNoTreatList [counter2*2+1] = "2";
                            }
                        }
                    }
                    
                    if (bodystring3 != "nil"){
                        for (int counter2 = 0; counter2 < wellNoTreatListCount/2; counter2++){
                            if (wellNoTreatList [counter2*2] == bodystring3){
                                fovCheck = 0;
                                
                                for (int counter3 = 1; counter3 <= 49; counter3++){
                                    if (wellFov3 [counter3] != 0){
                                        fovCheck = 1;
                                        break;
                                    }
                                }
                                
                                if (fovCheck == 1) wellNoTreatList [counter2*2+1] = "3";
                            }
                        }
                    }
                    
                    if (bodystring4 != "nil"){
                        for (int counter2 = 0; counter2 < wellNoTreatListCount/2; counter2++){
                            if (wellNoTreatList [counter2*2] == bodystring4){
                                fovCheck = 0;
                                
                                for (int counter3 = 1; counter3 <= 49; counter3++){
                                    if (wellFov4 [counter3] != 0){
                                        fovCheck = 1;
                                        break;
                                    }
                                }
                                
                                if (fovCheck == 1) wellNoTreatList [counter2*2+1] = "4";
                            }
                        }
                    }
                    
                    if (bodystring5 != "nil"){
                        for (int counter2 = 0; counter2 < wellNoTreatListCount/2; counter2++){
                            if (wellNoTreatList [counter2*2] == bodystring5){
                                fovCheck = 0;
                                
                                for (int counter3 = 1; counter3 <= 49; counter3++){
                                    if (wellFov5 [counter3] != 0){
                                        fovCheck = 1;
                                        break;
                                    }
                                }
                                
                                if (fovCheck == 1) wellNoTreatList [counter2*2+1] = "5";
                            }
                        }
                    }
                    
                    if (bodystring6 != "nil"){
                        for (int counter2 = 0; counter2 < wellNoTreatListCount/2; counter2++){
                            if (wellNoTreatList [counter2*2] == bodystring6){
                                fovCheck = 0;
                                
                                for (int counter3 = 1; counter3 <= 49; counter3++){
                                    if (wellFov6 [counter3] != 0){
                                        fovCheck = 1;
                                        break;
                                    }
                                }
                                
                                if (fovCheck == 1) wellNoTreatList [counter2*2+1] = "6";
                            }
                        }
                    }
                    
                    if (bodystring7 != "nil"){
                        for (int counter2 = 0; counter2 < wellNoTreatListCount/2; counter2++){
                            if (wellNoTreatList [counter2*2] == bodystring7){
                                fovCheck = 0;
                                
                                for (int counter3 = 1; counter3 <= 49; counter3++){
                                    if (wellFov7 [counter3] != 0){
                                        fovCheck = 1;
                                        break;
                                    }
                                }
                                
                                if (fovCheck == 1) wellNoTreatList [counter2*2+1] = "7";
                            }
                        }
                    }
                    
                    if (bodystring8 != "nil"){
                        for (int counter2 = 0; counter2 < wellNoTreatListCount/2; counter2++){
                            if (wellNoTreatList [counter2*2] == bodystring8){
                                fovCheck = 0;
                                
                                for (int counter3 = 1; counter3 <= 49; counter3++){
                                    if (wellFov8 [counter3] != 0){
                                        fovCheck = 1;
                                        break;
                                    }
                                }
                                
                                if (fovCheck == 1) wellNoTreatList [counter2*2+1] = "8";
                            }
                        }
                    }
                    
                    fovCheck = 0;
                    
                    for (int counter2 = 0; counter2 < wellNoTreatListCount/2; counter2++){
                        if (wellNoTreatList [counter2*2] != "0" && wellNoTreatList [counter2*2+1] == "0") fovCheck = 1;
                        if (wellNoTreatList [counter2*2] == "0" && wellNoTreatList [counter2*2+1] != "0") fovCheck = 1;
                    }
                    
                    //for (int counterA = 0; counterA < wellNoTreatListCount/2; counterA++){
                    //    cout<<wellNoTreatList [counterA*2]<<" "<<wellNoTreatList [counterA*2+1]<<" Well2"<<endl;
                    //}
                    
                    if (fovCheck == 1){
                        wellCountOption = 0;
                        
                        [body1 setStringValue:@""];
                        [body2 setStringValue:@""];
                        [body3 setStringValue:@""];
                        [body4 setStringValue:@""];
                        [body5 setStringValue:@""];
                        [body6 setStringValue:@""];
                        [body7 setStringValue:@""];
                        [body8 setStringValue:@""];
                    }
                    else wellCountOption = 1;
                    
                    string *treatNameList = new string [20];
                    int treatNameListCount = 0;
                    
                    dir = opendir(sourcePathNameHold.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                treatNameList [treatNameListCount] = entry, treatNameListCount++;
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    //----Directory Sort----
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < treatNameListCount; counter1++){
                        [unsortedArray addObject:@(treatNameList [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        treatNameList [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                    
                    for (int counter1 = 0; counter1 < treatNameListCount; counter1++){
                        cellFolderPath = sourcePathNameHold+"/"+treatNameList [counter1];
                        
                        wellCount++;
                        treatNameExtract = "";
                        
                        if ((int)entry.find("~") != -1) treatNameExtract = entry.substr(0, entry.find("~"));
                        else treatNameExtract = entry;
                        
                        if (wellCountOption == 1){
                            for (int counter2 = 0; counter2 < wellNoTreatListCount/2; counter2++){
                                if (wellNoTreatList [counter2*2] == treatNameExtract){
                                    wellCount = atoi(wellNoTreatList [counter2*2+1].c_str());
                                }
                            }
                        }
                        
                        dir2 = opendir(cellFolderPath.c_str());
                        
                        if (dir2 != NULL){
                            while ((dent2 = readdir(dir2))){
                                entry2 = dent2 -> d_name;
                                
                                if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && (int)entry2.find("FOV") != -1){
                                    fovNumber = atoi(entry2.substr(entry2.find("FOV")+3).c_str());
                                    fovCheck = 0;
                                    
                                    if (wellCount == 1){
                                        for (int counter3 = 1; counter3 <= 49; counter3++){
                                            if (fovNumber == wellFov1 [counter3]){
                                                fovCheck = 1;
                                                break;
                                            }
                                        }
                                    }
                                    else if (wellCount == 2){
                                        for (int counter3 = 1; counter3 <= 49; counter3++){
                                            if (fovNumber == wellFov2 [counter3]){
                                                fovCheck = 1;
                                                break;
                                            }
                                        }
                                    }
                                    else if (wellCount == 3){
                                        for (int counter3 = 1; counter3 <= 49; counter3++){
                                            if (fovNumber == wellFov3 [counter3]){
                                                fovCheck = 1;
                                                break;
                                            }
                                        }
                                    }
                                    else if (wellCount == 4){
                                        for (int counter3 = 1; counter3 <= 49; counter3++){
                                            if (fovNumber == wellFov4 [counter3]){
                                                fovCheck = 1;
                                                break;
                                            }
                                        }
                                    }
                                    else if (wellCount == 5){
                                        for (int counter3 = 1; counter3 <= 49; counter3++){
                                            if (fovNumber == wellFov5 [counter3]){
                                                fovCheck = 1;
                                                break;
                                            }
                                        }
                                    }
                                    else if (wellCount == 6){
                                        for (int counter3 = 1; counter3 <= 49; counter3++){
                                            if (fovNumber == wellFov6 [counter3]){
                                                fovCheck = 1;
                                                break;
                                            }
                                        }
                                    }
                                    else if (wellCount == 7){
                                        for (int counter3 = 1; counter3 <= 49; counter3++){
                                            if (fovNumber == wellFov7 [counter3]){
                                                fovCheck = 1;
                                                break;
                                            }
                                        }
                                    }
                                    else if (wellCount == 8){
                                        for (int counter3 = 1; counter3 <= 49; counter3++){
                                            if (fovNumber == wellFov8 [counter3]){
                                                fovCheck = 1;
                                                break;
                                            }
                                        }
                                    }
                                    
                                    if (fovCheck == 0) fovMisMatch = 1;
                                }
                            }
                            
                            closedir(dir2);
                        }
                    }
                    
                    delete [] treatNameList;
                    
                    if (fovMisMatch == 0){
                        string sourcePath2 = newFolderPath+"/Source_Images";
                        mkdir(sourcePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                        
                        string sourcePath3 = newFolderPath+"/Temp_Images";
                        mkdir(sourcePath3.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                        
                        string analysisPath2 = newFolderPath+"/Analysis_Infomation";
                        mkdir(analysisPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                        
                        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
                            otherProcessOn = 1;
                            backSaveOn = 1;
                            
                            DIR *dir3;
                            struct dirent *dent3;
                            DIR *dir4;
                            struct dirent *dent4;
                            DIR *dir5;
                            struct dirent *dent5;
                            
                            string entry3;
                            string entry4;
                            string entry5;
                            string cellFolderPathA;
                            string cellFolderPath2;
                            string cellFovPath;
                            string cellFovPath2;
                            string cellFolderPath3;
                            string treatNameExtract2;
                            string cellFovPath3;
                            string fovNoTemp;
                            string cellFovPath4;
                            string fovNoExtract;
                            string sourceFileName;
                            string newFileSaveName;
                            string tiffExtensionHold;
                            string saveStringTemp;
                            string xPositionWriteString;
                            string yPositionWriteString;
                            string analysisFOV;
                            string analysisName;
                            
                            unsigned long totalFileSize = 0;
                            unsigned long freeSize = 0;
                            unsigned long refSize = 0;
                            unsigned long nextAddress = 0;
                            unsigned long stripFirstAddress = 0;
                            unsigned long stripByteCountAddress = 0;
                            unsigned long headPosition = 0;
                            unsigned long stripEntry = 0;
                            long sizeForCopy = 0;
                            
                            double xPosition = 0;
                            double yPosition = 0;
                            
                            int wellCount2 = 0;
                            int firstEntry = 0;
                            int contrastFirstEntry = 0;
                            int counterPosition = 0;
                            int fovCount = 0;
                            int treatNameCount = 0;
                            int contrastDataCount = 0;
                            int fovListCount = 0;
                            int treatNameListCount2 = 0;
                            
                            int imageWidth = 0;
                            int imageHeight = 0;
                            int imageBit = 0; // Check 8, 16
                            int imageCompression = 0; // Check 1
                            int photoMetric = 0; //Check 0, 1, 2
                            int imageDimension = 0;
                            int dimensionAddition = 0;
                            int verticalBmp = 0;
                            int horizontalBmp = 0;
                            int horizontalBmpEntry = 0;
                            int newImageDimension = 0;
                            int endianType = 0;
                            int samplePerPix = 0;
                            int dataConversion [4];
                            int processType = 2; //8 or 16 bit image has to be 8 or 16 bit,
                            int numberOfLayers = 0;
                            int mode = 0;
                            
                            struct stat sizeOfFile;
                            
                            ifstream fin2;
                            ofstream oin2;
                            
                            string *treatNameList2 = new string [20];
                            
                            dir3 = opendir(sourcePathNameHold.c_str());
                            
                            if (dir3 != NULL){
                                while ((dent3 = readdir(dir3))){
                                    entry3 = dent3 -> d_name;
                                    
                                    if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store"){
                                        treatNameList2 [treatNameListCount2] = entry3, treatNameListCount2++;
                                    }
                                }
                                
                                closedir(dir3);
                            }
                            
                            //----Directory Sort----
                            NSMutableArray *unsortedArray2 = [[NSMutableArray alloc] init];
                            
                            for (int counter1 = 0; counter1 < treatNameListCount2; counter1++){
                                [unsortedArray2 addObject:@(treatNameList2 [counter1].c_str())];
                            }
                            
                            [unsortedArray2 sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                            
                            for (NSUInteger counter1 = 0; counter1 < [unsortedArray2 count]; counter1++){
                                treatNameList2 [counter1] = [unsortedArray2 [counter1] UTF8String];
                            }
                            
                            for (int counter1 = 0; counter1 < treatNameListCount2; counter1++){
                                cellFolderPathA = sourcePathNameHold+"/"+treatNameList2 [counter1];
                                treatNameExtract2 = "";
                                
                                if ((int)treatNameList2 [counter1].find("~") != -1){
                                    treatNameExtract2 = treatNameList2 [counter1].substr(0, treatNameList2 [counter1].find("~"));
                                }
                                else treatNameExtract2 = treatNameList2 [counter1];
                                
                                cellFolderPath2 = sourcePath2+"/"+treatNameExtract2+"~Sorted"; //=======
                                
                                mkdir(cellFolderPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                
                                wellCount2++;
                                
                                if (wellCountOption == 1){
                                    for (int counter4 = 0; counter4 < wellNoTreatListCount/2; counter4++){
                                        if (wellNoTreatList [counter4*2] == treatNameExtract2){
                                            wellCount2 = atoi(wellNoTreatList [counter4*2+1].c_str());
                                        }
                                    }
                                }
                                
                                cellFolderPath3 = sourcePath3+"/"+treatNameExtract2+"~Sorted"; //=======
                                mkdir(cellFolderPath3.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                
                                fovData [fovCount] = "ND", fovCount++;
                                treatName [treatNameCount] = "ND", treatNameCount++;
                                
                                contrastData [contrastDataCount] = "0", contrastDataCount++;
                                contrastData [contrastDataCount] = "0", contrastDataCount++;
                                contrastData [contrastDataCount] = "0", contrastDataCount++;
                                
                                if (contrastFirstEntry == 0){
                                    contrastData [contrastDataCount] = "T1", contrastDataCount++;
                                    contrastFirstEntry = 1;
                                }
                                else contrastData [contrastDataCount] = "0", contrastDataCount++;
                                
                                firstEntry = 0;
                                
                                string *fovList = new string [3000];
                                fovListCount = 0;
                                
                                dir4 = opendir(cellFolderPathA.c_str());
                                
                                if (dir4 != NULL){
                                    while ((dent4 = readdir(dir4))){
                                        entry4 = dent4 -> d_name;
                                        
                                        if (entry4 != "." && entry4 != ".." && entry4 != ".DS_Store"){
                                            fovList [fovListCount] = entry4, fovListCount++;
                                        }
                                    }
                                    
                                    closedir(dir4);
                                }
                                
                                //----Directory Sort----
                                NSMutableArray *unsortedArray3 = [[NSMutableArray alloc] init];
                                
                                for (int counter2 = 0; counter2 < fovListCount; counter2++){
                                    [unsortedArray3 addObject:@(fovList [counter2].c_str())];
                                }
                                
                                [unsortedArray3 sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                                
                                for (NSUInteger counter2 = 0; counter2 < [unsortedArray3 count]; counter2++){
                                    fovList [counter2] = [unsortedArray3 [counter2] UTF8String];
                                }
                                
                                for (int counter2 = 0; counter2 < fovListCount; counter2++){
                                    cellFovPath = cellFolderPathA+"/"+fovList [counter2];
                                    cellFovPath2 = cellFolderPath2+"/"+fovList [counter2];
                                    
                                    if ((int)fovList [counter2].find("FOV") != -1){
                                        mkdir(cellFovPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                    }
                                    
                                    cellFovPath3 = cellFolderPath3+"/"+fovList [counter2];
                                    
                                    if ((int)fovList [counter2].find("FOV") != -1){
                                        mkdir(cellFovPath3.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                    }
                                    
                                    fovNoTemp = fovList [counter2].substr(3);
                                    
                                    if ((int)fovList [counter2].find("FOV") != -1){
                                        fovData [fovCount] = "FOV"+to_string(atoi(fovNoTemp.c_str())), fovCount++;
                                    }
                                    
                                    if ((int)fovList [counter2].find("FOV") != -1){
                                        if (firstEntry == 0){
                                            treatName [treatNameCount] = treatNameExtract2, treatNameCount++;
                                            firstEntry = 1;
                                        }
                                        else treatName [treatNameCount] = "ND", treatNameCount++;
                                    }
                                    
                                    if ((int)fovList [counter2].find("FOV") != -1){
                                        contrastData [contrastDataCount] = "0", contrastDataCount++;
                                        contrastData [contrastDataCount] = "0", contrastDataCount++;
                                        contrastData [contrastDataCount] = "0", contrastDataCount++;
                                        contrastData [contrastDataCount] = "73/103/133/0 B50:0~0", contrastDataCount++;
                                    }
                                    
                                    dir5 = opendir(cellFovPath.c_str());
                                    
                                    fileDeleteCount = 0;
                                    
                                    if (dir5 != NULL){
                                        while ((dent5 = readdir(dir5))){
                                            entry5 = dent5 -> d_name;
                                            cellFovPath4 = cellFovPath+"/"+entry5;
                                            
                                            if (entry5 != "." && entry5 != ".." && entry5 != ".DS_Store" && ((int)entry5.find(".TIFF") != -1 || (int)entry5.find(".Tiff") != -1 || (int)entry5.find(".tiff") != -1 || (int)entry5.find(".TIF") != -1 || (int)entry5.find(".Tif") != -1 || (int)entry5.find(".tif") != -1)){
                                                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                                arrayFileDelete [fileDeleteCount] = entry5, fileDeleteCount++;
                                                
                                                if (stat(cellFovPath4.c_str(), &sizeOfFile) == 0){
                                                    sizeForCopy = sizeOfFile.st_size;
                                                    
                                                    totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                                                }
                                            }
                                        }
                                        
                                        closedir(dir5);
                                        
                                        //----Directory Sort----
                                        NSMutableArray *unsortedArray4 = [[NSMutableArray alloc] init];
                                        
                                        for (int counter3 = 0; counter3 < fileDeleteCount; counter3++){
                                            [unsortedArray4 addObject:@(arrayFileDelete [counter3].c_str())];
                                        }
                                        
                                        [unsortedArray4 sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                                        
                                        for (NSUInteger counter3 = 0; counter3 < [unsortedArray4 count]; counter3++){
                                            arrayFileDelete [counter3] = [unsortedArray4 [counter3] UTF8String];
                                        }
                                    }
                                    
                                    NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(destinationPathNameHold.c_str()) error:nil];
                                    freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
                                    refSize = totalFileSize+1048576000; //----1Gb----
                                    
                                    if (freeSize > refSize){
                                        fovNoExtract = fovList [counter2].substr(3, 3);
                                        
                                        for (int counter4 = 0; counter4 < fileDeleteCount; counter4++){
                                            tiffExtensionHold = "";
                                            
                                            if ((int)arrayFileDelete [counter4].find(".TIFF") != -1) tiffExtensionHold = ".TIFF";
                                            else if ((int)arrayFileDelete [counter4].find(".Tiff") != -1) tiffExtensionHold = ".Tiff";
                                            else if ((int)arrayFileDelete [counter4].find(".tiff") != -1) tiffExtensionHold = ".tiff";
                                            else if ((int)arrayFileDelete [counter4].find(".TIF") != -1 ) tiffExtensionHold = ".TIF";
                                            else if ((int)arrayFileDelete [counter4].find(".Tif") != -1) tiffExtensionHold = ".Tif";
                                            else if ((int)arrayFileDelete [counter4].find(".tif") != -1) tiffExtensionHold = ".tif";
                                            
                                            sourceFileName = cellFovPath+"/"+arrayFileDelete [counter4];
                                            
                                            //----File Read----
                                            if (stat(sourceFileName.c_str(), &sizeOfFile) == 0){
                                                sizeForCopy = sizeOfFile.st_size;
                                                
                                                fileReadArray = new uint8_t [sizeForCopy+4];
                                                fin2.open(sourceFileName.c_str(), ios::in | ios::binary);
                                                
                                                fin2.read((char*)fileReadArray, sizeForCopy+1);
                                                fin2.close();
                                                
                                                headPosition = 0;
                                                
                                                dataConversion [0] = fileReadArray [0];
                                                dataConversion [1] = fileReadArray [1];
                                                
                                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                                else endianType = 0;
                                                
                                                if (endianType == 1){
                                                    dataConversion [0] = fileReadArray [7];
                                                    dataConversion [1] = fileReadArray [6];
                                                    dataConversion [2] = fileReadArray [5];
                                                    dataConversion [3] = fileReadArray [4];
                                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                                }
                                                else if (endianType == 0){
                                                    dataConversion [0] = fileReadArray [4];
                                                    dataConversion [1] = fileReadArray [5];
                                                    dataConversion [2] = fileReadArray [6];
                                                    dataConversion [3] = fileReadArray [7];
                                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                                }
                                                
                                                if (endianType == 1){ //----Big endian----
                                                    self->tiffFileRead = [[TiffFileRead alloc] init];
                                                    [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                                    
                                                }
                                                else if (endianType == 0){
                                                    self->tiffFileRead = [[TiffFileRead alloc] init];
                                                    [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                                    
                                                }
                                                
                                                //cout<<imageCompression<<" "<<imageBit<<" "<<photoMetric<<" "<<numberOfLayers <<" "<<imageWidth<<" "<<imageHeight<<" "<<photoMetric<<" EntryInfo"<<endl;
                                                
                                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && numberOfLayers == 1 && imageWidth > 0 && imageHeight > 0 && photoMetric <= 2){
                                                    imageDimension = 0;
                                                    
                                                    int *arrayExtractedImage3 = new int [100];
                                                    
                                                    if (endianType == 1){
                                                        if (imageWidth > imageHeight) imageDimension = imageWidth;
                                                        else imageDimension = imageHeight;
                                                        
                                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                                        delete [] arrayExtractedImage3;
                                                        
                                                        arrayExtractedImage3 = [self->tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                                        
                                                    }
                                                    else if (endianType == 0){
                                                        if (imageWidth > imageHeight) imageDimension = imageWidth;
                                                        else imageDimension = imageHeight;
                                                        
                                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                                        delete [] arrayExtractedImage3;
                                                        
                                                        arrayExtractedImage3 = [self->tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                                        
                                                    }
                                                    
                                                    //----Make image dimension multiply 4x----
                                                    dimensionAddition = imageDimension%4;
                                                    
                                                    if (dimensionAddition == 1) dimensionAddition = 3;
                                                    else if (dimensionAddition == 2) dimensionAddition = 2;
                                                    else if (dimensionAddition == 3) dimensionAddition = 1;
                                                    
                                                    newImageDimension = imageDimension+dimensionAddition;
                                                    
                                                    arrayImageFileSave = new int *[newImageDimension+1];
                                                    
                                                    for (int counter5 = 0; counter5 < newImageDimension+1; counter5++){
                                                        arrayImageFileSave [counter5] = new int [newImageDimension+1];
                                                    }
                                                    
                                                    for (int counter5 = 0; counter5 < newImageDimension; counter5++){
                                                        for (int counter6 = 0; counter6 < newImageDimension; counter6++){
                                                            arrayImageFileSave [counter5][counter6] = 0;
                                                        }
                                                    }
                                                    
                                                    verticalBmp = 0;
                                                    horizontalBmp = 0;
                                                    horizontalBmpEntry = 0;
                                                    
                                                    for (int counter5 = 0; counter5 < imageWidth*imageHeight; counter5++){
                                                        if (verticalBmp < imageHeight){
                                                            if (horizontalBmp < imageWidth){
                                                                arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter5]);
                                                                horizontalBmp++;
                                                                horizontalBmpEntry++;
                                                            }
                                                            
                                                            if (horizontalBmp == imageWidth && imageWidth < newImageDimension){
                                                                for (int counter6 = 0; counter6 < newImageDimension-imageWidth; counter6++){
                                                                    arrayImageFileSave [verticalBmp][horizontalBmpEntry] = -1; //----fill blank part with -1
                                                                    horizontalBmpEntry++;
                                                                }
                                                            }
                                                            
                                                            if (horizontalBmp == imageWidth){
                                                                horizontalBmp = 0;
                                                                horizontalBmpEntry = 0;
                                                                verticalBmp++;
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (imageHeight < newImageDimension){
                                                        for (int counter5 = imageHeight; counter5 < newImageDimension; counter5++){
                                                            for (int counter6 = 0; counter6 < newImageDimension; counter6++){
                                                                arrayImageFileSave [counter5][counter6] = -1; //----fill blank part with -1
                                                            }
                                                        }
                                                    }
                                                    
                                                    delete [] arrayExtractedImage3;
                                                    
                                                    self->processingOptions = [[ProcessingOptions alloc] init];
                                                    newImageDimension = [self->processingOptions imageProcessingOptions:imageBit:newImageDimension];
                                                    
                                                    counterPosition = 0;
                                                    
                                                    if (wellCount2 == 1){
                                                        for (int counter5 = 1; counter5 <= 49; counter5++){
                                                            if (atoi(fovNoExtract.c_str()) == wellFov1 [counter5]){
                                                                counterPosition = counter5;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                    else if (wellCount2 == 2){
                                                        for (int counter5 = 1; counter5 <= 49; counter5++){
                                                            if (atoi(fovNoExtract.c_str()) == wellFov2 [counter5]){
                                                                counterPosition = counter5;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                    else if (wellCount2 == 3){
                                                        for (int counter5 = 1; counter5 <= 49; counter5++){
                                                            if (atoi(fovNoExtract.c_str()) == wellFov3 [counter5]){
                                                                counterPosition = counter5;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                    else if (wellCount2 == 4){
                                                        for (int counter5 = 1; counter5 <= 49; counter5++){
                                                            if (atoi(fovNoExtract.c_str()) == wellFov4 [counter5]){
                                                                counterPosition = counter5;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                    else if (wellCount2 == 5){
                                                        for (int counter5 = 1; counter5 <= 49; counter5++){
                                                            if (atoi(fovNoExtract.c_str()) == wellFov5 [counter5]){
                                                                counterPosition = counter5;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                    else if (wellCount2 == 6){
                                                        for (int counter5 = 1; counter5 <= 49; counter5++){
                                                            if (atoi(fovNoExtract.c_str()) == wellFov6 [counter5]){
                                                                counterPosition = counter5;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                    else if (wellCount2 == 7){
                                                        for (int counter5 = 1; counter5 <= 49; counter5++){
                                                            if (atoi(fovNoExtract.c_str()) == wellFov7 [counter5]){
                                                                counterPosition = counter5;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                    else if (wellCount2 == 8){
                                                        for (int counter5 = 1; counter5 <= 49; counter5++){
                                                            if (atoi(fovNoExtract.c_str()) == wellFov8 [counter5]){
                                                                counterPosition = counter5;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                    
                                                    if ((int)arrayFileDelete [counter4].find(".TIF") != -1 && (int)arrayFileDelete [counter4].substr(arrayFileDelete [counter4].find(".TIF")).length() == 6){
                                                        fileSavePathHold = cellFovPath2+"/"+arrayFileDelete [counter4].substr(0, arrayFileDelete [counter4].find(".TIF"))+".TIF"+arrayFileDelete [counter4].substr(arrayFileDelete [counter4].find(".TIF")+4);
                                                    }
                                                    else{
                                                        
                                                        fileSavePathHold = cellFovPath2+"/"+arrayFileDelete [counter4].substr(0, arrayFileDelete [counter4].find(tiffExtensionHold))+".tif";
                                                    }
                                                    
                                                    imageBit = 8;
                                                    
                                                    xPosition = fovPosition [counterPosition*2];
                                                    yPosition = fovPosition [counterPosition*2+1];
                                                    
                                                    if (xPosition == -1) xPosition = 100;
                                                    if (yPosition == -1) yPosition = 100;
                                                    
                                                    photoMetric = 1;
                                                    
                                                    //cout<<imageBit<<" "<<photoMetric<<" "<<numberOfLayers<<" "<<ifDPreviousHold<<" "<<headPosition<<" "<<nextAddress<<" Info"<<endl;
                                                    
                                                    mode = 0;
                                                    
                                                    self->singleTiffSave = [[SingleTiffSave alloc] init];
                                                    [self->singleTiffSave singleTiffLayerSave:newImageDimension:newImageDimension:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:(unsigned long)mode];
                                                    
                                                    
                                                    for (int counter5 = 0; counter5 < newImageDimension+1; counter5++){
                                                        delete [] arrayImageFileSave [counter5];
                                                    }
                                                    
                                                    delete [] arrayImageFileSave;
                                                    
                                                }
                                                
                                                delete [] fileReadArray;
                                            }
                                        }
                                    }
                                }
                                
                                delete [] fovList;
                            }
                            
                            delete [] treatNameList2;
                            
                            analysisFOV = analysisPath2+"/FI-FOVData";
                            
                            oin2.open(analysisFOV.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < fovCount; counter1++) oin2<<fovData [counter1]<<endl;
                            
                            oin2.close();
                            
                            analysisName = analysisPath2+"/FI-TreatmentNameData";
                            
                            oin2.open(analysisName.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < treatNameCount; counter1++) oin2<<treatName [counter1]<<endl;
                            
                            oin2.close();
                            
                            analysisName = analysisPath2+"/FI-FocalPlaneData";
                            
                            oin2.open(analysisName.c_str(), ios::out);
                            
                            oin2<<1<<endl;
                            
                            oin2.close();
                            
                            analysisName = analysisPath2+"/FI-BasicSetting";
                            
                            oin2.open(analysisName.c_str(), ios::out);
                            
                            oin2<<1<<endl;
                            
                            oin2.close();
                            
                            analysisName = analysisPath2+"/CT-BasicSetting";
                            
                            oin2.open(analysisName.c_str(), ios::out);
                            
                            oin2<<1<<endl;
                            
                            oin2.close();
                            
                            analysisName = analysisPath2+"/CT-ContrastData";
                            
                            oin2.open(analysisName.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < contrastDataCount; counter1++) oin2<<contrastData [counter1]<<endl;
                            
                            oin2.close();
                            
                            delete [] fovData;
                            delete [] treatName;
                            delete [] contrastData;
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                            
                            backSaveOn = 3;
                            otherProcessOn = 0;
                        });
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Number Of FOV Mismatch"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Folder Creation Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Set FOV Position"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select Source/Destination Folder"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)tiffToSTimage:(id)sender{
    /*
     //----Input format Folder/treat (Folder)/FOV**1 (folder)/Cont_0001-FOV001.tif
     //----Convert single layer Tiff to STImage
     //----In the case of 16 bit tif, convert to 8 bit bmp
     //----Option, Mean: Move mean to the set value: e.g. average 100, Mean: 90, 90 to be 100//if < fold set, after mean shift, (pix value-mean)*fold//if > fold set, after mean shift, (mean-pix value)*fold
     //----Option, Below cut: value below the cut will be replaced with the set value----
     //----Option, Above cut: value above cut will be multiplied by fold, e.g Cut: 100, pix value: 120, fold: 1.5, new value = (120-100)*1.5
     //----Option, Extract Tif range: Average: convert 16 bit to 8 bit, Range From-To: Extract range of 16 bit image and convert to 8 bit image
     //----Option Tiff reduction, reduce Tiff size to 1/2
     */
    
    if (otherProcessOn == 0){
        if (sourcePathNameHold != "nil" && destinationPathNameHold != "nil"){
            int terminationFlag = 0;
            
            string extractedID = sourcePathNameHold;
            
            do{
                
                terminationFlag = 1;
                
                if ((int)extractedID.find("/") != -1){
                    extractedID = extractedID.substr(extractedID.find("/")+1);
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            string newFolderPath = destinationPathNameHold+"/"+extractedID+"_Image";
            
            int folderCreationCheck = 0;
            
            folderCreationCheck = mkdir(newFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            if (folderCreationCheck == 0){
                if (contrastActivateHold == 1){
                    if (contrastMeanHold <= 0 || contrastMeanHold > 255){
                        contrastMeanHold = -1;
                        [contrastMeanDisplay setStringValue:@""];
                        [valueMeanAboveDisplay setStringValue:@""];
                        [valueMeanBelowDisplay setStringValue:@""];
                    }
                    else{
                        
                        if (meanAboveFoldHold <= 0 || meanAboveFoldHold > 255) meanAboveFoldHold = -1;
                        if (meanBelowFoldHold <= 0 || meanBelowFoldHold > 255) meanBelowFoldHold = -1;
                    }
                    
                    if (belowCutHold <= 0 || belowCutHold > 255){
                        belowCutHold = -1;
                        valueBelowHold = -1;
                        [belowCutDisplay setStringValue:@""];
                        [valueBelowDisplay setStringValue:@""];
                    }
                    else{
                        
                        if (valueBelowHold <= 0 || valueBelowHold > 255){
                            belowCutHold = -1;
                            valueBelowHold = -1;
                            [belowCutDisplay setStringValue:@""];
                            [valueBelowDisplay setStringValue:@""];
                        }
                    }
                    
                    if (aboveCutHold <= 0 || aboveCutHold > 255){
                        aboveCutHold = -1;
                        valueFoldHold = -1;
                        [aboveCutDisplay setStringValue:@""];
                        [valueFoldDisplay setStringValue:@""];
                    }
                    else{
                        
                        if (valueFoldHold <= 0 || valueFoldHold > 255){
                            aboveCutHold = -1;
                            valueFoldHold = -1;
                            [aboveCutDisplay setStringValue:@""];
                            [valueFoldDisplay setStringValue:@""];
                        }
                    }
                    
                    if (tiff16To8Hold == 1){
                        if (rangeFromHold == -1 || rangeToHold == -1){
                            rangeFromHold = -1;
                            rangeToHold = -1;
                            tiff16To8Hold = 0;
                            [rangeFromDisplay setStringValue:@""];
                            [rangeToDisplay setStringValue:@""];
                            [tiff16To8Display setStringValue:@"Average"];
                        }
                        else if (rangeFromHold >= rangeToHold){
                            rangeFromHold = -1;
                            rangeToHold = -1;
                            tiff16To8Hold = 0;
                            [rangeFromDisplay setStringValue:@""];
                            [rangeToDisplay setStringValue:@""];
                            [tiff16To8Display setStringValue:@"Average"];
                        }
                    }
                    else{
                        
                        if (tiff16To8Hold == 0 && (rangeFromHold != -1 || rangeToHold != -1)){
                            rangeFromHold = -1;
                            rangeToHold = -1;
                            [rangeFromDisplay setStringValue:@""];
                            [rangeToDisplay setStringValue:@""];
                        }
                    }
                }
                
                DIR *dir;
                struct dirent *dent;
                DIR *dir2;
                struct dirent *dent2;
                
                string entry;
                string entry2;
                string cellFolderPath;
                
                int fovCount = 0;
                int fovCheck = 0;
                
                dir = opendir(sourcePathNameHold.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            cellFolderPath = sourcePathNameHold+"/"+entry;
                            fovCount = 0;
                            
                            dir2 = opendir(cellFolderPath.c_str());
                            
                            if (dir2 != NULL){
                                while ((dent2 = readdir(dir2))){
                                    entry2 = dent2 -> d_name;
                                    
                                    if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && (int)entry2.find("FOV") != -1){
                                        fovCount++;
                                    }
                                }
                                
                                if (fovCount != 1) fovCheck = 1;
                                
                                closedir(dir2);
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                
                if (fovCheck == 0){
                    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
                        otherProcessOn = 1;
                        backSaveOn = 1;
                        
                        DIR *dir3;
                        struct dirent *dent3;
                        DIR *dir4;
                        struct dirent *dent4;
                        DIR *dir5;
                        struct dirent *dent5;
                        
                        string entry3;
                        string entry4;
                        string entry5;
                        string cellFolderPathA;
                        string cellFolderPath2;
                        string cellFovPath;
                        string cellFovPath2;
                        string treatNameExtract;
                        string cellFovPath4;
                        string sourceFileName;
                        string tiffExtensionHold;
                        
                        unsigned long totalFileSize = 0;
                        unsigned long freeSize = 0;
                        unsigned long refSize = 0;
                        unsigned long nextAddress = 0;
                        unsigned long stripFirstAddress = 0;
                        unsigned long stripByteCountAddress = 0;
                        unsigned long headPosition = 0;
                        unsigned long stripEntry = 0;
                        long sizeForCopy = 0;
                        
                        double xPosition = 0;
                        double yPosition = 0;
                        
                        int imageWidth = 0;
                        int imageHeight = 0;
                        int imageBit = 0; // Check 8, 16
                        int imageCompression = 0; // Check 1
                        int photoMetric = 0; //Check 0, 1, 2
                        int imageDimension = 0;
                        int dimensionAddition = 0;
                        int verticalBmp = 0;
                        int horizontalBmp = 0;
                        int horizontalBmpEntry = 0;
                        int newImageDimension = 0;
                        int endianType = 0;
                        int samplePerPix = 0;
                        int dataConversion [4];
                        int processType = 2; //8 or 16 bit image has to be 8 or 16 bit,
                        int numberOfLayers = 0;
                        int mode = 0;
                        
                        struct stat sizeOfFile;
                        
                        ifstream fin2;
                        
                        dir3 = opendir(sourcePathNameHold.c_str());
                        
                        if (dir3 != NULL){
                            while ((dent3 = readdir(dir3))){
                                entry3 = dent3 -> d_name;
                                
                                if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store"){
                                    cellFolderPathA = sourcePathNameHold+"/"+entry3;
                                    
                                    dir4 = opendir(cellFolderPathA.c_str());
                                    
                                    if (dir4 != NULL){
                                        while ((dent4 = readdir(dir4))){
                                            entry4 = dent4 -> d_name;
                                            
                                            if (entry4 != "." && entry4 != ".." && entry4 != ".DS_Store" && (int)entry4.find("FOV") != -1){
                                                cellFovPath = cellFolderPathA+"/"+entry4;
                                                
                                                treatNameExtract = "";
                                                
                                                if ((int)entry3.find("~") != -1){
                                                    treatNameExtract = entry3.substr(0, entry3.find("_Stitch"));
                                                }
                                                else treatNameExtract = entry3;
                                                
                                                cellFolderPath2 = newFolderPath+"/"+treatNameExtract+"_Stitch"; //=======
                                                
                                                mkdir(cellFolderPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                                
                                                dir5 = opendir(cellFovPath.c_str());
                                                
                                                fileDeleteCount = 0;
                                                
                                                if (dir5 != NULL){
                                                    while ((dent5 = readdir(dir5))){
                                                        entry5 = dent5 -> d_name;
                                                        
                                                        cellFovPath4 = cellFovPath+"/"+entry5;
                                                        
                                                        if (entry5 != "." && entry5 != ".." && entry5 != ".DS_Store" && ((int)entry5.find(".TIFF") != -1 || (int)entry5.find(".Tiff") != -1 || (int)entry5.find(".tiff") != -1 || (int)entry5.find(".TIF") != -1 || (int)entry5.find(".Tif") != -1 || (int)entry5.find(".tif") != -1)){
                                                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                                            arrayFileDelete [fileDeleteCount] = entry5, fileDeleteCount++;
                                                            
                                                            if (stat(cellFovPath.c_str(), &sizeOfFile) == 0){
                                                                sizeForCopy = sizeOfFile.st_size;
                                                                
                                                                totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                                                            }
                                                        }
                                                    }
                                                    
                                                    closedir(dir5);
                                                    
                                                    //----Directory Sort----
                                                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                                                    
                                                    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                                        [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                                                    }
                                                    
                                                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                                                    
                                                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                                                        arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                                                    }
                                                }
                                                
                                                NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(destinationPathNameHold.c_str()) error:nil];
                                                freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
                                                refSize = totalFileSize+1048576000; //----1Gb----
                                                
                                                if (freeSize > refSize){
                                                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                                                        tiffExtensionHold = "";
                                                        
                                                        if ((int)arrayFileDelete [counter2].find(".TIFF") != -1) tiffExtensionHold = ".TIFF";
                                                        else if ((int)arrayFileDelete [counter2].find(".Tiff") != -1) tiffExtensionHold = ".Tiff";
                                                        else if ((int)arrayFileDelete [counter2].find(".tiff") != -1) tiffExtensionHold = ".tiff";
                                                        else if ((int)arrayFileDelete [counter2].find(".TIF") != -1 ) tiffExtensionHold = ".TIF";
                                                        else if ((int)arrayFileDelete [counter2].find(".Tif") != -1) tiffExtensionHold = ".Tif";
                                                        else if ((int)arrayFileDelete [counter2].find(".tif") != -1) tiffExtensionHold = ".tif";
                                                        
                                                        sourceFileName = cellFovPath+"/"+arrayFileDelete [counter2];
                                                        
                                                        //----File Read----
                                                        if (stat(sourceFileName.c_str(), &sizeOfFile) == 0){
                                                            sizeForCopy = sizeOfFile.st_size;
                                                            
                                                            fileReadArray = new uint8_t [sizeForCopy+4];
                                                            fin2.open(sourceFileName.c_str(), ios::in | ios::binary);
                                                            
                                                            fin2.read((char*)fileReadArray, sizeForCopy+1);
                                                            fin2.close();
                                                            
                                                            headPosition = 0;
                                                            
                                                            dataConversion [0] = fileReadArray [0];
                                                            dataConversion [1] = fileReadArray [1];
                                                            
                                                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                                            else endianType = 0;
                                                            
                                                            if (endianType == 1){
                                                                dataConversion [0] = fileReadArray [7];
                                                                dataConversion [1] = fileReadArray [6];
                                                                dataConversion [2] = fileReadArray [5];
                                                                dataConversion [3] = fileReadArray [4];
                                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                                            }
                                                            else if (endianType == 0){
                                                                dataConversion [0] = fileReadArray [4];
                                                                dataConversion [1] = fileReadArray [5];
                                                                dataConversion [2] = fileReadArray [6];
                                                                dataConversion [3] = fileReadArray [7];
                                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                                            }
                                                            
                                                            if (endianType == 1){ //----Big endian----
                                                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                                                [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                                                
                                                            }
                                                            else if (endianType == 0){
                                                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                                                [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                                                
                                                            }
                                                            
                                                            //cout<<imageCompression<<" "<<imageBit<<" "<<plaineNumberTF<<" EntryInfo"<<endl;
                                                            
                                                            if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && numberOfLayers == 1 && imageWidth > 0 && imageHeight > 0 && photoMetric <= 2){
                                                                imageDimension = 0;
                                                                
                                                                int *arrayExtractedImage3 = new int [100];
                                                                
                                                                if (endianType == 1){
                                                                    if (imageWidth > imageHeight) imageDimension = imageWidth;
                                                                    else imageDimension = imageHeight;
                                                                    
                                                                    self->tiffFileRead = [[TiffFileRead alloc] init];
                                                                    delete [] arrayExtractedImage3;
                                                                    
                                                                    arrayExtractedImage3 = [self->tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                                                    
                                                                }
                                                                else if (endianType == 0){
                                                                    if (imageWidth > imageHeight) imageDimension = imageWidth;
                                                                    else imageDimension = imageHeight;
                                                                    
                                                                    self->tiffFileRead = [[TiffFileRead alloc] init];
                                                                    delete [] arrayExtractedImage3;
                                                                    
                                                                    arrayExtractedImage3 = [self->tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                                                    
                                                                }
                                                                
                                                                dimensionAddition = imageDimension%4;
                                                                
                                                                if (dimensionAddition == 1) dimensionAddition = 3;
                                                                else if (dimensionAddition == 2) dimensionAddition = 2;
                                                                else if (dimensionAddition == 3) dimensionAddition = 1;
                                                                
                                                                newImageDimension = imageDimension+dimensionAddition;
                                                                
                                                                arrayImageFileSave = new int *[newImageDimension+1];
                                                                
                                                                for (int counter3 = 0; counter3 < newImageDimension+1; counter3++){
                                                                    arrayImageFileSave [counter3] = new int [newImageDimension+1];
                                                                }
                                                                
                                                                for (int counter3 = 0; counter3 < newImageDimension; counter3++){
                                                                    for (int counter4 = 0; counter4 < newImageDimension; counter4++){
                                                                        arrayImageFileSave [counter3][counter4] = 0;
                                                                    }
                                                                }
                                                                
                                                                verticalBmp = 0;
                                                                horizontalBmp = 0;
                                                                horizontalBmpEntry = 0;
                                                                
                                                                for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                                                    if (verticalBmp < imageHeight){
                                                                        if (horizontalBmp < imageWidth){
                                                                            arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3]);
                                                                            horizontalBmp++;
                                                                            horizontalBmpEntry++;
                                                                        }
                                                                        
                                                                        if (horizontalBmp == imageWidth && imageWidth < newImageDimension){
                                                                            for (int counter4 = 0; counter4 < newImageDimension-imageWidth; counter4++){
                                                                                arrayImageFileSave [verticalBmp][horizontalBmpEntry] = -1;
                                                                                horizontalBmpEntry++;
                                                                            }
                                                                        }
                                                                        
                                                                        if (horizontalBmp == imageWidth){
                                                                            horizontalBmp = 0;
                                                                            horizontalBmpEntry = 0;
                                                                            verticalBmp++;
                                                                        }
                                                                    }
                                                                }
                                                                
                                                                if (imageHeight < newImageDimension){
                                                                    for (int counter3 = imageHeight; counter3 < newImageDimension; counter3++){
                                                                        for (int counter4 = 0; counter4 < newImageDimension; counter4++){
                                                                            arrayImageFileSave [counter3][counter4] = -1;
                                                                        }
                                                                    }
                                                                }
                                                                
                                                                delete [] arrayExtractedImage3;
                                                                
                                                                self->processingOptions = [[ProcessingOptions alloc] init];
                                                                newImageDimension = [self->processingOptions imageProcessingOptions:imageBit:newImageDimension];
                                                                
                                                                if ((int)arrayFileDelete [counter2].find(".TIF") != -1 && (int)arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find(".TIF")).length() == 6 && (int)arrayFileDelete [counter2].find("-FOV") != -1){
                                                                    fileSavePathHold = cellFolderPath2+"/STimage "+arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find("-FOV")-4, 4)+".TIF"+arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find(".TIF")+4);
                                                                }
                                                                else if ((int)arrayFileDelete [counter2].find("-FOV") != -1){
                                                                    fileSavePathHold = cellFolderPath2+"/STimage "+arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find("-FOV")-4, 4)+".tif";
                                                                }
                                                                
                                                                imageBit = 8;
                                                                
                                                                if (xPosition == -1) xPosition = 100;
                                                                if (yPosition == -1) yPosition = 100;
                                                                
                                                                photoMetric = 1;
                                                                mode = 0;
                                                                
                                                                self->singleTiffSave = [[SingleTiffSave alloc] init];
                                                                [self->singleTiffSave singleTiffLayerSave:newImageDimension:newImageDimension:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:(unsigned long)mode];
                                                                
                                                                
                                                                for (int counter3 = 0; counter3 < newImageDimension+1; counter3++){
                                                                    delete [] arrayImageFileSave [counter3];
                                                                }
                                                                
                                                                delete [] arrayImageFileSave;
                                                            }
                                                            
                                                            delete [] fileReadArray;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        
                                        closedir(dir4);
                                    }
                                }
                            }
                            
                            closedir(dir3);
                        }
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        backSaveOn = 3;
                        otherProcessOn = 0;
                    });
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Number Of FOV folder: Must To Be 1"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Folder Creation Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select Source/Destination Folder"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)tiffToBackup:(id)sender{
    /*
     //----Input format Folder/Cont_####-FOV0001, Cont_####-FOV0002, treat_####-FOV001 etc/filename.tif
     //----Convert single layer Tiff to Backup format files
     //----Input image 16 bit tif, convert to 8 bit tif
     //----FOV positions have to be set
     //----Option, Mean: Move mean to the set value: e.g. average 100, Mean: 90, 90 to be 100//if < fold set, after mean shift, (pix value-mean)*fold//if > fold set, after mean shift, (mean-pix value)*fold
     //----Option, Below cut: value below the cut will be replaced with the set value----
     //----Option, Above cut: value above cut will be multiplied by fold, e.g Cut: 100, pix value: 120, fold: 1.5, new value = (120-100)*1.5
     //----Option/Auto, Extract Tif range: Average: convert 16 bit to 8 bit (Auto), Range From-To: Extract range of 16 bit image and convert to 8 bit image
     //----If Extract Tif range is set, but 8 bit, this process will be skipped----
     //----Option Tiff reduction, reduce Tiff size to 1/2
     
     //----FOV setting: Required to set Body name. The number of FOVs that corresponds to the Body name will be searched
     //----In the case of Div mode, image size has to be 1024x1024 and Fov should be set  1 1  to div image into four images
     //----                                                                              1 1
     //----Before FOV setting, make Div on
     //----Out image bit will be same with input image. Internally, 16 bit image (color or gray) will be converted to 8 bit gray, and then changed to 16 bit.
     */
    
    if (otherProcessOn == 0){
        if (sourcePathNameHold != "nil" && destinationPathNameHold != "nil"){
            NSString *bodyNameCheck = [bodyNameDisplay stringValue];
            string bodyNameDisplayString = [[bodyNameDisplay stringValue] UTF8String];
            
            ascIIconversion = [[ASCIIconversion alloc] init];
            int checkResults = [ascIIconversion nameCheck:bodyNameCheck];
            
            if (checkResults == 0){
                if (bodyNameDisplayString.length() < 3 || bodyNameDisplayString.length() > 15) checkResults = 1;
            }
            
            if (checkResults == 0 && fovStatusHold == 1){
                if (contrastActivateHold == 1){
                    if (contrastMeanHold <= 0 || contrastMeanHold > 255){
                        contrastMeanHold = -1;
                        [contrastMeanDisplay setStringValue:@""];
                        [valueMeanAboveDisplay setStringValue:@""];
                        [valueMeanBelowDisplay setStringValue:@""];
                    }
                    else{
                        
                        if (meanAboveFoldHold <= 0 || meanAboveFoldHold > 255) meanAboveFoldHold = -1;
                        if (meanBelowFoldHold <= 0 || meanBelowFoldHold > 255) meanBelowFoldHold = -1;
                    }
                    
                    if (belowCutHold <= 0 || belowCutHold > 255){
                        belowCutHold = -1;
                        valueBelowHold = -1;
                        [belowCutDisplay setStringValue:@""];
                        [valueBelowDisplay setStringValue:@""];
                    }
                    else{
                        
                        if (valueBelowHold <= 0 || valueBelowHold > 255){
                            belowCutHold = -1;
                            valueBelowHold = -1;
                            [belowCutDisplay setStringValue:@""];
                            [valueBelowDisplay setStringValue:@""];
                        }
                    }
                    
                    if (aboveCutHold <= 0 || aboveCutHold > 255){
                        aboveCutHold = -1;
                        valueFoldHold = -1;
                        [aboveCutDisplay setStringValue:@""];
                        [valueFoldDisplay setStringValue:@""];
                    }
                    else{
                        
                        if (valueFoldHold <= 0 || valueFoldHold > 255){
                            aboveCutHold = -1;
                            valueFoldHold = -1;
                            [aboveCutDisplay setStringValue:@""];
                            [valueFoldDisplay setStringValue:@""];
                        }
                    }
                    
                    if (rangeFromHold != -1 && rangeToHold != -1){
                        if (rangeFromHold >= rangeToHold){
                            rangeFromHold = -1;
                            rangeToHold = -1;
                            [rangeFromDisplay setStringValue:@""];
                            [rangeToDisplay setStringValue:@""];
                        }
                    }
                    else{
                        
                        rangeFromHold = -1;
                        rangeToHold = -1;
                        [rangeFromDisplay setStringValue:@""];
                        [rangeToDisplay setStringValue:@""];
                    }
                }
                
                string extractedID = sourcePathNameHold;
                int terminationFlag = 0;
                
                do{
                    
                    terminationFlag = 1;
                    
                    if ((int)extractedID.find("/") != -1) extractedID = extractedID.substr(extractedID.find("/")+1);
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                string newFolderPath = destinationPathNameHold+"/"+extractedID+"-New";
                
                int folderCreationCheck = 0;
                
                folderCreationCheck = mkdir(newFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                if (folderCreationCheck == 0){
                    DIR *dir;
                    struct dirent *dent;
                    DIR *dir2;
                    struct dirent *dent2;
                    
                    string entry;
                    string entry2;
                    string cellFolderPath;
                    string sourceFileName;
                    string treatNameExtract;
                    string cellFovPath4;
                    
                    unsigned long totalFileSize = 0;
                    unsigned long freeSize = 0;
                    unsigned long refSize = 0;
                    unsigned long nextAddress = 0;
                    unsigned long stripFirstAddress = 0;
                    unsigned long stripByteCountAddress = 0;
                    unsigned long headPosition = 0;
                    unsigned long stripEntry = 0;
                    long sizeForCopy = 0;
                    
                    int fovNumber = 0;
                    int fovCheck = 0;
                    int fovMisMatch = 0;
                    int fileNumberCheck = 0;
                    int fileNumberHold = 0;
                    int fileNumberMatch = 0;
                    int wellCountOption = 0;
                    int fovFolderNumber = 0;
                    int wellCount = 0;
                    int matchFind = 0;
                    
                    double xPosition = 0;
                    double yPosition = 0;
                    
                    int imageWidth = 0;
                    int imageHeight = 0;
                    int imageBit = 0; // Check 8, 16
                    int imageCompression = 0; // Check 1
                    int photoMetric = 0; //Check 0, 1, 2
                    int endianType = 0;
                    int samplePerPix = 0;
                    int dataConversion [4];
                    int numberOfLayers = 0;
                    
                    ifstream fin;
                    
                    wellNoTreatListCount = 0;
                    
                    int overflowFlag = 0;
                    
                    for (int counter2 = 0; counter2 < wellNoTreatListCount; counter2++) wellNoTreatList [counter2] = "0";
                    
                    dir = opendir(sourcePathNameHold.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                treatNameExtract = entry.substr(0, entry.find("_"));
                                matchFind = 0;
                                
                                for (int counter2 = 0; counter2 < wellNoTreatListCount/3; counter2++){
                                    if (wellNoTreatList [counter2*3] == treatNameExtract){
                                        matchFind = 1;
                                    }
                                }
                                
                                if (matchFind == 0){
                                    overflowFlag++;
                                    
                                    wellNoTreatList [wellNoTreatListCount] = treatNameExtract, wellNoTreatListCount++;
                                    wellNoTreatList [wellNoTreatListCount] = "0", wellNoTreatListCount++;
                                    wellNoTreatList [wellNoTreatListCount] = "0", wellNoTreatListCount++;
                                }
                                
                                if (overflowFlag > 48){
                                    overflowFlag = -1;
                                    break;
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    //for (int counterA = 0; counterA < wellNoTreatListCount/3; counterA++){
                    //    cout<<counterA<<" "<<wellNoTreatList [counterA*3] <<" "<<wellNoTreatList [counterA*3+1]<<" "<<wellNoTreatList [counterA*3+2]<<"  Well0"<<endl;
                    //}
                    
                    if (overflowFlag != -1){
                        dir = opendir(sourcePathNameHold.c_str());
                        
                        if (dir != NULL){
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("FOV") != -1){
                                    treatNameExtract = entry.substr(0, entry.find("_"));
                                    fovNumber = atoi(entry.substr(entry.find("FOV")+3).c_str());
                                    
                                    for (int counter2 = 0; counter2 < wellNoTreatListCount/3; counter2++){
                                        if (wellNoTreatList [counter2*3] == treatNameExtract){
                                            if (atoi(wellNoTreatList [counter2*3+1].c_str()) < fovNumber){
                                                wellNoTreatList [counter2*3+1] = to_string(fovNumber);
                                            }
                                        }
                                    }
                                }
                            }
                            
                            closedir(dir);
                        }
                        
                        //for (int counterA = 0; counterA < wellNoTreatListCount/3; counterA++){
                        //    cout<<counterA<<" "<<wellNoTreatList [counterA*3] <<" "<<wellNoTreatList [counterA*3+1]<<" "<<wellNoTreatList [counterA*3+2]<<"  Well"<<endl;
                        //}
                        
                        string bodystring1 = "nil";
                        string bodystring2 = "nil";
                        string bodystring3 = "nil";
                        string bodystring4 = "nil";
                        string bodystring5 = "nil";
                        string bodystring6 = "nil";
                        string bodystring7 = "nil";
                        string bodystring8 = "nil";
                        
                        if ([body1 stringValue] != NULL) bodystring1 = [[body1 stringValue] UTF8String];
                        if ([body2 stringValue] != NULL) bodystring2 = [[body2 stringValue] UTF8String];
                        if ([body3 stringValue] != NULL) bodystring3 = [[body3 stringValue] UTF8String];
                        if ([body4 stringValue] != NULL) bodystring4 = [[body4 stringValue] UTF8String];
                        if ([body5 stringValue] != NULL) bodystring5 = [[body5 stringValue] UTF8String];
                        if ([body6 stringValue] != NULL) bodystring6 = [[body6 stringValue] UTF8String];
                        if ([body7 stringValue] != NULL) bodystring7 = [[body7 stringValue] UTF8String];
                        if ([body8 stringValue] != NULL) bodystring8 = [[body8 stringValue] UTF8String];
                        
                        if (bodystring1 != "nil"){
                            for (int counter2 = 0; counter2 < wellNoTreatListCount/3; counter2++){
                                if (wellNoTreatList [counter2*3] == bodystring1){
                                    fovCheck = 0;
                                    
                                    for (int counter3 = 1; counter3 <= 49; counter3++){
                                        if (wellFov1 [counter3] != 0){
                                            fovCheck = 1;
                                            break;
                                        }
                                    }
                                    
                                    if (fovCheck == 1) wellNoTreatList [counter2*3+2] = "1";
                                }
                            }
                        }
                        
                        if (bodystring2 != "nil"){
                            for (int counter2 = 0; counter2 < wellNoTreatListCount/3; counter2++){
                                if (wellNoTreatList [counter2*3] == bodystring2){
                                    fovCheck = 0;
                                    
                                    for (int counter3 = 1; counter3 <= 49; counter3++){
                                        if (wellFov2 [counter3] != 0){
                                            fovCheck = 1;
                                            break;
                                        }
                                    }
                                    
                                    if (fovCheck == 1) wellNoTreatList [counter2*3+2] = "2";
                                }
                            }
                        }
                        
                        if (bodystring3 != "nil"){
                            for (int counter2 = 0; counter2 < wellNoTreatListCount/3; counter2++){
                                if (wellNoTreatList [counter2*3] == bodystring3){
                                    fovCheck = 0;
                                    
                                    for (int counter3 = 1; counter3 <= 49; counter3++){
                                        if (wellFov3 [counter3] != 0){
                                            fovCheck = 1;
                                            break;
                                        }
                                    }
                                    
                                    if (fovCheck == 1) wellNoTreatList [counter2*3+2] = "3";
                                }
                            }
                        }
                        
                        if (bodystring4 != "nil"){
                            for (int counter2 = 0; counter2 < wellNoTreatListCount/3; counter2++){
                                if (wellNoTreatList [counter2*3] == bodystring4){
                                    fovCheck = 0;
                                    
                                    for (int counter3 = 1; counter3 <= 49; counter3++){
                                        if (wellFov4 [counter3] != 0){
                                            fovCheck = 1;
                                            break;
                                        }
                                    }
                                    
                                    if (fovCheck == 1) wellNoTreatList [counter2*3+2] = "4";
                                }
                            }
                        }
                        
                        if (bodystring5 != "nil"){
                            for (int counter2 = 0; counter2 < wellNoTreatListCount/3; counter2++){
                                if (wellNoTreatList [counter2*3] == bodystring5){
                                    fovCheck = 0;
                                    
                                    for (int counter3 = 1; counter3 <= 49; counter3++){
                                        if (wellFov5 [counter3] != 0){
                                            fovCheck = 1;
                                            break;
                                        }
                                    }
                                    
                                    if (fovCheck == 1) wellNoTreatList [counter2*3+2] = "5";
                                }
                            }
                        }
                        
                        if (bodystring6 != "nil"){
                            for (int counter2 = 0; counter2 < wellNoTreatListCount/3; counter2++){
                                if (wellNoTreatList [counter2*3] == bodystring6){
                                    fovCheck = 0;
                                    
                                    for (int counter3 = 1; counter3 <= 49; counter3++){
                                        if (wellFov6 [counter3] != 0){
                                            fovCheck = 1;
                                            break;
                                        }
                                    }
                                    
                                    if (fovCheck == 1) wellNoTreatList [counter2*3+2] = "6";
                                }
                            }
                        }
                        
                        if (bodystring7 != "nil"){
                            for (int counter2 = 0; counter2 < wellNoTreatListCount/3; counter2++){
                                if (wellNoTreatList [counter2*3] == bodystring7){
                                    fovCheck = 0;
                                    
                                    for (int counter3 = 1; counter3 <= 49; counter3++){
                                        if (wellFov7 [counter3] != 0){
                                            fovCheck = 1;
                                            break;
                                        }
                                    }
                                    
                                    if (fovCheck == 1) wellNoTreatList [counter2*3+2] = "7";
                                }
                            }
                        }
                        
                        if (bodystring8 != "nil"){
                            for (int counter2 = 0; counter2 < wellNoTreatListCount/3; counter2++){
                                if (wellNoTreatList [counter2*3] == bodystring8){
                                    fovCheck = 0;
                                    
                                    for (int counter3 = 1; counter3 <= 49; counter3++){
                                        if (wellFov8 [counter3] != 0){
                                            fovCheck = 1;
                                            break;
                                        }
                                    }
                                    
                                    if (fovCheck == 1) wellNoTreatList [counter2*3+2] = "8";
                                }
                            }
                        }
                        
                        fovCheck = 0;
                        
                        for (int counter2 = 0; counter2 < wellNoTreatListCount/3; counter2++){
                            if (wellNoTreatList [counter2*3] != "0" && wellNoTreatList [counter2*3+2] == "0"){
                                fovCheck = 1;
                            }
                            
                            if (wellNoTreatList [counter2*3] == "0" && wellNoTreatList [counter2*3+2] != "0"){
                                fovCheck = 1;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < wellNoTreatListCount/3; counterA++){
                        //    cout<<counterA<<" "<<wellNoTreatList [counterA*3] <<" "<<wellNoTreatList [counterA*3+1]<<" "<<wellNoTreatList [counterA*3+2]<<"  Well3"<<endl;
                        //}
                        
                        if (fovCheck == 1){
                            wellCountOption = 0;
                            
                            [body1 setStringValue:@""];
                            [body2 setStringValue:@""];
                            [body3 setStringValue:@""];
                            [body4 setStringValue:@""];
                            [body5 setStringValue:@""];
                            [body6 setStringValue:@""];
                            [body7 setStringValue:@""];
                            [body8 setStringValue:@""];
                            
                            wellCount = 0;
                            
                            for (int counter2 = 0; counter2 < wellNoTreatListCount/3; counter2++){
                                if (wellNoTreatList [counter2*3] != "0"){
                                    wellCount++;
                                    
                                    wellNoTreatList [counter2*3+2] = to_string(wellCount);
                                }
                            }
                        }
                        else wellCountOption = 1;
                        
                        fovMisMatch = 0;
                        wellCount = 0;
                        
                        for (int counter2 = 0; counter2 < wellNoTreatListCount/3; counter2++){
                            if (wellNoTreatList [counter2*3] != "0"){
                                wellCount++;
                                
                                if (wellCountOption == 1){
                                    wellCount = atoi(wellNoTreatList [counter2*3+2].c_str());
                                }
                                
                                for (int counter3 = 1; counter3 <= atoi(wellNoTreatList [counter2*3+1].c_str()); counter3++){
                                    fovCheck = 0;
                                    
                                    if (wellCount == 1){
                                        for (int counter4 = 1; counter4 <= 49; counter4++){
                                            if (counter3 == wellFov1 [counter4]){
                                                fovCheck = 1;
                                                break;
                                            }
                                        }
                                    }
                                    else if (wellCount == 2){
                                        for (int counter4 = 1; counter4 <= 49; counter4++){
                                            if (counter3 == wellFov2 [counter4]){
                                                fovCheck = 1;
                                                break;
                                            }
                                        }
                                    }
                                    else if (wellCount == 3){
                                        for (int counter4 = 1; counter4 <= 49; counter4++){
                                            if (counter3 == wellFov3 [counter4]){
                                                fovCheck = 1;
                                                break;
                                            }
                                        }
                                    }
                                    else if (wellCount == 4){
                                        for (int counter4 = 1; counter4 <= 49; counter4++){
                                            if (counter3 == wellFov4 [counter4]){
                                                fovCheck = 1;
                                                break;
                                            }
                                        }
                                    }
                                    else if (wellCount == 5){
                                        for (int counter4 = 1; counter4 <= 49; counter4++){
                                            if (counter3 == wellFov5 [counter4]){
                                                fovCheck = 1;
                                                break;
                                            }
                                        }
                                    }
                                    else if (wellCount == 6){
                                        for (int counter4 = 1; counter4 <= 49; counter4++){
                                            if (counter3 == wellFov6 [counter4]){
                                                fovCheck = 1;
                                                break;
                                            }
                                        }
                                    }
                                    else if (wellCount == 7){
                                        for (int counter4 = 1; counter4 <= 49; counter4++){
                                            if (counter3 == wellFov7 [counter4]){
                                                fovCheck = 1;
                                                break;
                                            }
                                        }
                                    }
                                    else if (wellCount == 8){
                                        for (int counter4 = 1; counter4 <= 49; counter4++){
                                            if (counter3 == wellFov8 [counter4]){
                                                fovCheck = 1;
                                                break;
                                            }
                                        }
                                    }
                                    
                                    if (fovCheck == 0) fovMisMatch = 1;
                                }
                            }
                        }
                        
                        if (fovMisMatch == 0){
                            fileNumberHold = 0;
                            fileNumberMatch = 0;
                            fovFolderNumber = 0;
                            
                            dir = opendir(sourcePathNameHold.c_str());
                            
                            if (dir != NULL){
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("FOV") != -1){
                                        cellFolderPath = sourcePathNameHold+"/"+entry;
                                        
                                        fovFolderNumber++;
                                        
                                        dir2 = opendir(cellFolderPath.c_str());
                                        
                                        if (dir2 != NULL){
                                            fileNumberCheck = 0;
                                            
                                            while ((dent2 = readdir(dir2))){
                                                entry2 = dent2 -> d_name;
                                                
                                                if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" &&  ((int)entry2.find(".TIFF") != -1 || (int)entry2.find(".Tiff") != -1 || (int)entry2.find(".tiff") != -1 || (int)entry2.find(".TIF") != -1 || (int)entry2.find(".Tif") != -1 || (int)entry2.find(".tif") != -1)){
                                                    fileNumberCheck++;
                                                }
                                            }
                                            
                                            closedir(dir2);
                                            
                                            if (fileNumberHold == 0){
                                                fileNumberHold = fileNumberCheck;
                                            }
                                            
                                            if (fileNumberCheck != fileNumberHold){
                                                fileNumberMatch = 1;
                                            }
                                        }
                                    }
                                }
                                
                                closedir(dir);
                            }
                            
                            if (fileNumberMatch == 0){
                                fileDeleteCount = 0;
                                totalFileSize = 0;
                                
                                struct stat sizeOfFile;
                                
                                dir = opendir(sourcePathNameHold.c_str());
                                
                                if (dir != NULL){
                                    while ((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        
                                        if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("FOV") != -1){
                                            cellFolderPath = sourcePathNameHold+"/"+entry;
                                            
                                            dir2 = opendir(cellFolderPath.c_str());
                                            
                                            if (dir2 != NULL){
                                                while ((dent2 = readdir(dir2))){
                                                    entry2 = dent2 -> d_name;
                                                    cellFovPath4 = cellFolderPath+"/"+entry2;
                                                    
                                                    if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && ((int)entry2.find(".TIFF") != -1 || (int)entry2.find(".Tiff") != -1 || (int)entry2.find(".tiff") != -1 || (int)entry2.find(".TIF") != -1 || (int)entry2.find(".Tif") != -1 || (int)entry2.find(".tif") != -1)){
                                                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                                        arrayFileDelete [fileDeleteCount] = entry+"/"+entry2, fileDeleteCount++;
                                                        
                                                        if (stat(cellFovPath4.c_str(), &sizeOfFile) == 0){
                                                            sizeForCopy = sizeOfFile.st_size;
                                                            
                                                            totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                                                        }
                                                    }
                                                }
                                                
                                                closedir(dir2);
                                                
                                                //----Directory Sort----
                                                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                                                
                                                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                                    [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                                                }
                                                
                                                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                                                
                                                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                                                    arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                                                }
                                            }
                                        }
                                    }
                                    
                                    closedir(dir);
                                }
                                
                                NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(destinationPathNameHold.c_str()) error:nil];
                                freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
                                refSize = totalFileSize+1048576000; //----1Gb----
                                
                                for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                                    sourceFileName = sourcePathNameHold+"/"+arrayFileDelete [counter2];
                                    
                                    //----File Read----
                                    if (stat(sourceFileName.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                        
                                        fileReadArray = new uint8_t [sizeForCopy+4];
                                        fin.open(sourceFileName.c_str(), ios::in | ios::binary);
                                        
                                        fin.read((char*)fileReadArray, sizeForCopy+1);
                                        fin.close();
                                        
                                        dataConversion [0] = fileReadArray [0];
                                        dataConversion [1] = fileReadArray [1];
                                        
                                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                        else endianType = 0;
                                        
                                        if (endianType == 1){
                                            dataConversion [0] = fileReadArray [7];
                                            dataConversion [1] = fileReadArray [6];
                                            dataConversion [2] = fileReadArray [5];
                                            dataConversion [3] = fileReadArray [4];
                                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                        }
                                        else if (endianType == 0){
                                            dataConversion [0] = fileReadArray [4];
                                            dataConversion [1] = fileReadArray [5];
                                            dataConversion [2] = fileReadArray [6];
                                            dataConversion [3] = fileReadArray [7];
                                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                        }
                                        
                                        if (endianType == 1){ //----Big endian----
                                            tiffFileRead = [[TiffFileRead alloc] init];
                                            [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                            
                                        }
                                        else if (endianType == 0){
                                            tiffFileRead = [[TiffFileRead alloc] init];
                                            [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                            
                                        }
                                        
                                        delete [] fileReadArray;
                                    }
                                }
                                
                                if (imageBit == 8) tiff16To8Hold = 0;
                                
                                //cout<<imageBit<<" "<<fileStatusMatch<<" "<<imageHeight<<" "<<backStartHold<<" "<<imageWidth<<" "<<imageHeight<<" "<<imageCompression<<" "<<photoMetric<<" Info"<<endl;
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && numberOfLayers == 1 && imageWidth > 0 && imageHeight > 0 && photoMetric <= 2 && freeSize > refSize && backStartHold != 0){
                                    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
                                        otherProcessOn = 1;
                                        backSaveOn = 1;
                                        
                                        string sourceFileName2;
                                        string cellFovPath3;
                                        string fovNoExtract;
                                        string tiffExtensionHold;
                                        string fileNameExtract;
                                        string cellFovSavePath2;
                                        string cellFovSavePath3;
                                        string cellFovSavePath4;
                                        string bodyNameTemp;
                                        
                                        unsigned long nextAddress2 = 0;
                                        unsigned long stripFirstAddress2 = 0;
                                        unsigned long stripByteCountAddress2 = 0;
                                        unsigned long headPosition2 = 0;
                                        unsigned long headPosition3 = 0;
                                        unsigned long stripEntry2 = 0;
                                        unsigned long ifDPreviousHold = 0;
                                        long sizeForCopy2 = 0;
                                        
                                        double xPosition2 = 0;
                                        double yPosition2 = 0;
                                        
                                        int counterPosition = 0;
                                        int terminationFlag2 = 0;
                                        int loopCount = 0;
                                        int wellCount2 = 0;
                                        int fovNumberTemp = 0;
                                        int fluorescentPosition = 0;
                                        int dataConversion3 [4];
                                        
                                        int imageWidth2 = 0;
                                        int imageHeight2 = 0;
                                        int imageBit2 = 0; // Check 8, 16
                                        int imageCompression2 = 0; // Check 1
                                        int photoMetric2 = 0; //Check 0, 1, 2
                                        int imageDimension2 = 0;
                                        int dimensionAddition2 = 0;
                                        int verticalBmp2 = 0;
                                        int horizontalBmp2 = 0;
                                        int horizontalBmpEntry2 = 0;
                                        int newImageDimension2 = 0;
                                        int endianType2 = 0;
                                        int samplePerPix2 = 0;
                                        int processType2 = 2;
                                        int numberOfLayers2 = 0;
                                        int numberOfLayers3 = 0;
                                        int mode2 = 0;
                                        
                                        struct stat sizeOfFile2;
                                        
                                        ifstream fin2;
                                        
                                        string *newFileList = new string [fileDeleteCount+1];
                                        int newFileListCount = 0;
                                        
                                        for (int counter3 = 0; counter3 < fileNumberCheck; counter3++){
                                            for (int counter4 = 0; counter4 < fovFolderNumber; counter4++){
                                                newFileList [newFileListCount] = arrayFileDelete [counter3+counter4*fileNumberCheck], newFileListCount++;
                                            }
                                        }
                                        
                                        int timePointCount = backStartHold;
                                        int fileProcessCount = -1;
                                        string timePointCountString;
                                        string newBackUpPath;
                                        
                                        int *wellFovTemp1 = new int [100];
                                        int *wellFovTemp2 = new int [100];
                                        int *wellFovTemp3 = new int [100];
                                        int *wellFovTemp4 = new int [100];
                                        int *wellFovTemp5 = new int [100];
                                        int *wellFovTemp6 = new int [100];
                                        int *wellFovTemp7 = new int [100];
                                        int *wellFovTemp8 = new int [100];
                                        
                                        for (int counter4 = 1; counter4 <= 49; counter4++){
                                            wellFovTemp1 [counter4] = wellFov1 [counter4];
                                        }
                                        
                                        for (int counter4 = 1; counter4 <= 49; counter4++){
                                            wellFovTemp2 [counter4] = wellFov2 [counter4];
                                        }
                                        
                                        for (int counter4 = 1; counter4 <= 49; counter4++){
                                            wellFovTemp3 [counter4] = wellFov3 [counter4];
                                        }
                                        
                                        for (int counter4 = 1; counter4 <= 49; counter4++){
                                            wellFovTemp4 [counter4] = wellFov4 [counter4];
                                        }
                                        
                                        for (int counter4 = 1; counter4 <= 49; counter4++){
                                            wellFovTemp5 [counter4] = wellFov5 [counter4];
                                        }
                                        
                                        for (int counter4 = 1; counter4 <= 49; counter4++){
                                            wellFovTemp6 [counter4] = wellFov6 [counter4];
                                        }
                                        
                                        for (int counter4 = 1; counter4 <= 49; counter4++){
                                            wellFovTemp7 [counter4] = wellFov7 [counter4];
                                        }
                                        
                                        for (int counter4 = 1; counter4 <= 49; counter4++){
                                            wellFovTemp8 [counter4] = wellFov8 [counter4];
                                        }
                                        
                                        for (int counter1 = 0; counter1 < fileNumberCheck; counter1++){
                                            timePointCountString = to_string(timePointCount);
                                            
                                            if (timePointCountString.length() == 1) timePointCountString = "1000"+timePointCountString;
                                            else if (timePointCountString.length() == 2) timePointCountString = "100"+timePointCountString;
                                            else if (timePointCountString.length() == 3) timePointCountString = "10"+timePointCountString;
                                            else if (timePointCountString.length() == 4) timePointCountString = "1"+timePointCountString;
                                            
                                            newBackUpPath = newFolderPath+"/"+bodyNameDisplayString+"-"+timePointCountString;
                                            mkdir(newBackUpPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                            
                                            timePointCount++;
                                            
                                            for (int counter2 = 0; counter2 < fovFolderNumber; counter2++){
                                                fileProcessCount++;
                                                bodyNameTemp = newFileList [fileProcessCount].substr(0, newFileList [fileProcessCount].find("_"));
                                                wellCount2 = 0;
                                                
                                                for (int counter3 = 0; counter3 < wellNoTreatListCount/3; counter3++){
                                                    if (wellNoTreatList [counter3*3] == bodyNameTemp){
                                                        wellCount2 = atoi(wellNoTreatList [counter3*3+2].c_str());
                                                        break;
                                                    }
                                                }
                                                
                                                fovNoExtract = newFileList [fileProcessCount].substr(newFileList [fileProcessCount].find("FOV")+3, 3);
                                                
                                                tiffExtensionHold = "";
                                                
                                                if ((int)newFileList [fileProcessCount].find(".TIFF") != -1) tiffExtensionHold = ".TIFF";
                                                else if ((int)newFileList [fileProcessCount].find(".Tiff") != -1) tiffExtensionHold = ".Tiff";
                                                else if ((int)newFileList [fileProcessCount].find(".tiff") != -1) tiffExtensionHold = ".tiff";
                                                else if ((int)newFileList [fileProcessCount].find(".TIF") != -1 ) tiffExtensionHold = ".TIF";
                                                else if ((int)newFileList [fileProcessCount].find(".Tif") != -1) tiffExtensionHold = ".Tif";
                                                else if ((int)newFileList [fileProcessCount].find(".tif") != -1) tiffExtensionHold = ".tif";
                                                
                                                sourceFileName2 = sourcePathNameHold+"/"+newFileList [fileProcessCount];
                                                
                                                //----File Read----
                                                if (stat(sourceFileName2.c_str(), &sizeOfFile2) == 0){
                                                    sizeForCopy2 = sizeOfFile2.st_size;
                                                    
                                                    fileReadArray = new uint8_t [sizeForCopy2+4];
                                                    fin2.open(sourceFileName2.c_str(), ios::in | ios::binary);
                                                    
                                                    fin2.read((char*)fileReadArray, sizeForCopy2+1);
                                                    fin2.close();
                                                    
                                                    headPosition2 = 0;
                                                    
                                                    dataConversion3 [0] = fileReadArray [0];
                                                    dataConversion3 [1] = fileReadArray [1];
                                                    
                                                    if (dataConversion3 [0] == 77 && dataConversion3 [1] == 77) endianType2 = 1;
                                                    else endianType2 = 0;
                                                    
                                                    if (endianType2 == 1){
                                                        dataConversion3 [0] = fileReadArray [7];
                                                        dataConversion3 [1] = fileReadArray [6];
                                                        dataConversion3 [2] = fileReadArray [5];
                                                        dataConversion3 [3] = fileReadArray [4];
                                                        headPosition2 = (unsigned long)dataConversion3 [3]*16777216+(unsigned long)dataConversion3 [2]*65536+(unsigned long)dataConversion3 [1]*256+(unsigned long)dataConversion3 [0];
                                                    }
                                                    else if (endianType2 == 0){
                                                        dataConversion3 [0] = fileReadArray [4];
                                                        dataConversion3 [1] = fileReadArray [5];
                                                        dataConversion3 [2] = fileReadArray [6];
                                                        dataConversion3 [3] = fileReadArray [7];
                                                        headPosition2 = (unsigned long)dataConversion3 [3]*16777216+(unsigned long)dataConversion3 [2]*65536+(unsigned long)dataConversion3 [1]*256+(unsigned long)dataConversion3 [0];
                                                    }
                                                    
                                                    headPosition3 = headPosition2;
                                                    
                                                    //----Number of layer check----
                                                    if (endianType2 == 1){ //----Big endian----
                                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                                        [self->tiffFileRead tiffReadBigEndian: headPosition2:&imageWidth2:&imageHeight2:&imageBit2:&imageCompression2:&photoMetric2:&xPosition2:&yPosition2:&samplePerPix2:&stripFirstAddress2:&stripEntry2:&stripByteCountAddress2:&nextAddress2:&numberOfLayers2];
                                                        
                                                    }
                                                    else if (endianType2 == 0){
                                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                                        [self->tiffFileRead tiffReadLittleEndian: headPosition2:&imageWidth2:&imageHeight2:&imageBit2:&imageCompression2:&photoMetric2:&xPosition2:&yPosition2:&samplePerPix2:&stripFirstAddress2:&stripEntry2:&stripByteCountAddress2:&nextAddress2:&numberOfLayers2];
                                                        
                                                    }
                                                    
                                                    imageDimension2 = 0;
                                                    
                                                    int *arrayExtractedImage3 = new int [100];
                                                    
                                                    loopCount = 0;
                                                    
                                                    do{
                                                        
                                                        terminationFlag2 = 1;
                                                        
                                                        if (loopCount == 0){
                                                            cellFovSavePath2 = "";
                                                            cellFovSavePath3 = "";
                                                            cellFovSavePath4 = "";
                                                            
                                                            if ((int)newFileList [fileProcessCount].find(".tif") != -1){
                                                                bodyNameTemp = newFileList [fileProcessCount].substr(0, newFileList [fileProcessCount].find("_"));
                                                                fovNumberTemp = atoi(newFileList [fileProcessCount].substr(newFileList [fileProcessCount].find("FOV")+3, 3).c_str());
                                                                
                                                                if ((int)newFileList [fileProcessCount].find("_1_") != -1){
                                                                    fluorescentPosition = (int)newFileList [fileProcessCount].find("_1_");
                                                                }
                                                                else if ((int)newFileList [fileProcessCount].find("_2_") != -1){
                                                                    fluorescentPosition = (int)newFileList [fileProcessCount].find("_2_");
                                                                }
                                                                else if ((int)newFileList [fileProcessCount].find("_3_") != -1){
                                                                    fluorescentPosition = (int)newFileList [fileProcessCount].find("_3_");
                                                                }
                                                                else if ((int)newFileList [fileProcessCount].find("_4_") != -1){
                                                                    fluorescentPosition = (int)newFileList [fileProcessCount].find("_4_");
                                                                }
                                                                else if ((int)newFileList [fileProcessCount].find("_5_") != -1){
                                                                    fluorescentPosition = (int)newFileList [fileProcessCount].find("_5_");
                                                                }
                                                                
                                                                if (fluorescentPosition != 0){
                                                                    fileNameExtract = newFileList [fileProcessCount].substr((unsigned long)fluorescentPosition, newFileList [fileProcessCount].find(tiffExtensionHold)-(unsigned long)fluorescentPosition);
                                                                    fileSavePathHold = newBackUpPath+"/"+bodyNameTemp+"_"+timePointCountString.substr(1)+"-"+to_string(fovNumberTemp)+fileNameExtract+".tif";
                                                                }
                                                                else fileSavePathHold = newBackUpPath+"/"+bodyNameTemp+"_"+timePointCountString.substr(1)+"-"+to_string(fovNumberTemp)+".tif";
                                                            }
                                                            else if ((int)newFileList [fileProcessCount].find(".TIF") != -1 && (int)(newFileList [fileProcessCount].substr(newFileList [fileProcessCount].find(".TIF")).length()) == 6){
                                                                bodyNameTemp = newFileList [fileProcessCount].substr(0, newFileList [fileProcessCount].find("_"));
                                                                fovNumberTemp = atoi(newFileList [fileProcessCount].substr(newFileList [fileProcessCount].find("FOV")+3, 3).c_str());
                                                                
                                                                if ((int)newFileList [fileProcessCount].find("_1_") != -1){
                                                                    fluorescentPosition = (int)newFileList [fileProcessCount].find("_1_");
                                                                }
                                                                else if ((int)newFileList [fileProcessCount].find("_2_") != -1){
                                                                    fluorescentPosition = (int)newFileList [fileProcessCount].find("_2_");
                                                                }
                                                                else if ((int)newFileList [fileProcessCount].find("_3_") != -1){
                                                                    fluorescentPosition = (int)newFileList [fileProcessCount].find("_3_");
                                                                }
                                                                else if ((int)newFileList [fileProcessCount].find("_4_") != -1){
                                                                    fluorescentPosition = (int)newFileList [fileProcessCount].find("_4_");
                                                                }
                                                                else if ((int)newFileList [fileProcessCount].find("_5_") != -1){
                                                                    fluorescentPosition = (int)newFileList [fileProcessCount].find("_5_");
                                                                }
                                                                
                                                                if (fluorescentPosition != 0){
                                                                    fileNameExtract = newFileList [fileProcessCount].substr((unsigned long)fluorescentPosition, newFileList [fileProcessCount].find(".TIF")-(unsigned long)fluorescentPosition);
                                                                    fileSavePathHold = newBackUpPath+"/"+bodyNameTemp+"_"+timePointCountString.substr(1)+"-"+to_string(fovNumberTemp)+fileNameExtract+".TIF"+newFileList [fileProcessCount].substr(newFileList [fileProcessCount].find(".TIF")+4);
                                                                }
                                                                else{
                                                                    
                                                                    fileSavePathHold = newBackUpPath+"/"+bodyNameTemp+"_"+timePointCountString.substr(1)+"-"+to_string(fovNumberTemp)+".TIF"+newFileList [fileProcessCount].substr(newFileList [fileProcessCount].find(".TIF")+4);
                                                                }
                                                            }
                                                            else{
                                                                
                                                                bodyNameTemp = newFileList [fileProcessCount].substr(0, newFileList [fileProcessCount].find("_"));
                                                                fovNumberTemp = atoi(newFileList [fileProcessCount].substr(newFileList [fileProcessCount].find("FOV")+3, 3).c_str());
                                                                
                                                                if ((int)newFileList [fileProcessCount].find("_1_") != -1){
                                                                    fluorescentPosition = (int)newFileList [fileProcessCount].find("_1_");
                                                                }
                                                                else if ((int)newFileList [fileProcessCount].find("_2_") != -1){
                                                                    fluorescentPosition = (int)newFileList [fileProcessCount].find("_2_");
                                                                }
                                                                else if ((int)newFileList [fileProcessCount].find("_3_") != -1){
                                                                    fluorescentPosition = (int)newFileList [fileProcessCount].find("_3_");
                                                                }
                                                                else if ((int)newFileList [fileProcessCount].find("_4_") != -1){
                                                                    fluorescentPosition = (int)newFileList [fileProcessCount].find("_4_");
                                                                }
                                                                else if ((int)newFileList [fileProcessCount].find("_5_") != -1){
                                                                    fluorescentPosition = (int)newFileList [fileProcessCount].find("_5_");
                                                                }
                                                                
                                                                if (fluorescentPosition != 0){
                                                                    fileNameExtract = newFileList [fileProcessCount].substr((unsigned long)fluorescentPosition, newFileList [fileProcessCount].find(tiffExtensionHold)-(unsigned long)fluorescentPosition);
                                                                    fileSavePathHold = newBackUpPath+"/"+bodyNameTemp+"_"+timePointCountString.substr(1)+"-"+to_string(fovNumberTemp)+fileNameExtract+".tif";
                                                                }
                                                                else fileSavePathHold = newBackUpPath+"/"+bodyNameTemp+"_"+timePointCountString.substr(1)+"-"+to_string(fovNumberTemp)+".tif";
                                                            }
                                                            
                                                            loopCount++;
                                                            ifDPreviousHold = 0;
                                                        }
                                                        else loopCount++;
                                                        
                                                        if (endianType2 == 1){
                                                            self->tiffFileRead = [[TiffFileRead alloc] init];
                                                            [self->tiffFileRead tiffReadBigEndian: headPosition3:&imageWidth2:&imageHeight2:&imageBit2:&imageCompression2:&photoMetric2:&xPosition2:&yPosition2:&samplePerPix2:&stripFirstAddress2:&stripEntry2:&stripByteCountAddress2:&nextAddress2:&numberOfLayers3];
                                                            
                                                            
                                                            if (imageWidth2 > imageHeight2) imageDimension2 = imageWidth2;
                                                            else imageDimension2 = imageHeight2;
                                                            
                                                            self->tiffFileRead = [[TiffFileRead alloc] init];
                                                            delete [] arrayExtractedImage3;
                                                            
                                                            arrayExtractedImage3 = [self->tiffFileRead imageSetBigEndian:imageDimension2:imageBit2:photoMetric2:samplePerPix2:stripEntry2:stripFirstAddress2:stripByteCountAddress2:processType2];
                                                            
                                                        }
                                                        else if (endianType2 == 0){
                                                            self->tiffFileRead = [[TiffFileRead alloc] init];
                                                            [self->tiffFileRead tiffReadLittleEndian: headPosition3:&imageWidth2:&imageHeight2:&imageBit2:&imageCompression2:&photoMetric2:&xPosition2:&yPosition2:&samplePerPix2:&stripFirstAddress2:&stripEntry2:&stripByteCountAddress2:&nextAddress2:&numberOfLayers3];
                                                            
                                                            
                                                            if (imageWidth2 > imageHeight2) imageDimension2 = imageWidth2;
                                                            else imageDimension2 = imageHeight2;
                                                            
                                                            self->tiffFileRead = [[TiffFileRead alloc] init];
                                                            delete [] arrayExtractedImage3;
                                                            
                                                            arrayExtractedImage3 = [self->tiffFileRead imageSetLittleEndian:imageDimension2:imageBit2:photoMetric2:samplePerPix2:stripEntry2:stripFirstAddress2:stripByteCountAddress2:processType2];
                                                            
                                                        }
                                                        
                                                        dimensionAddition2 = imageDimension2%4;
                                                        
                                                        if (dimensionAddition2 == 1) dimensionAddition2 = 3;
                                                        else if (dimensionAddition2 == 2) dimensionAddition2 = 2;
                                                        else if (dimensionAddition2 == 3) dimensionAddition2 = 1;
                                                        
                                                        newImageDimension2 = imageDimension2+dimensionAddition2;
                                                        
                                                        arrayImageFileSave = new int *[newImageDimension2+1];
                                                        
                                                        for (int counter3 = 0; counter3 < newImageDimension2+1; counter3++){
                                                            arrayImageFileSave [counter3] = new int [newImageDimension2*3+1];
                                                        }
                                                        
                                                        for (int counter3 = 0; counter3 < newImageDimension2; counter3++){
                                                            for (int counter4 = 0; counter4 < newImageDimension2*3; counter4++){
                                                                arrayImageFileSave [counter3][counter4] = 0;
                                                            }
                                                        }
                                                        
                                                        verticalBmp2 = 0;
                                                        horizontalBmp2 = 0;
                                                        horizontalBmpEntry2 = 0;
                                                        
                                                        for (int counter3 = 0; counter3 < imageWidth2*imageHeight2; counter3++){
                                                            if (verticalBmp2 < imageHeight2){
                                                                if (horizontalBmp2 < imageWidth2){
                                                                    arrayImageFileSave [verticalBmp2][horizontalBmpEntry2] = (int)(arrayExtractedImage3 [counter3]);
                                                                    horizontalBmp2++;
                                                                    horizontalBmpEntry2++;
                                                                }
                                                                
                                                                if (horizontalBmp2 == imageWidth2 && imageWidth2 < newImageDimension2){
                                                                    for (int counter4 = 0; counter4 < newImageDimension2-imageWidth2; counter4++){
                                                                        arrayImageFileSave [verticalBmp2][horizontalBmpEntry2] = -1;
                                                                        horizontalBmpEntry2++;
                                                                    }
                                                                }
                                                                
                                                                if (horizontalBmp2 == imageWidth2){
                                                                    horizontalBmp2 = 0;
                                                                    horizontalBmpEntry2 = 0;
                                                                    verticalBmp2++;
                                                                }
                                                            }
                                                        }
                                                        
                                                        if (imageHeight2 < newImageDimension2){
                                                            for (int counter3 = imageHeight2; counter3 < newImageDimension2; counter3++){
                                                                for (int counter4 = 0; counter4 < newImageDimension2; counter4++){
                                                                    arrayImageFileSave [counter3][counter4] = -1;
                                                                }
                                                            }
                                                        }
                                                        
                                                        tiffReductionHold = 0;
                                                        
                                                        counterPosition = 0;
                                                        
                                                        if (wellCount2 == 1){
                                                            for (int counter4 = 1; counter4 <= 49; counter4++){
                                                                if (atoi(fovNoExtract.c_str()) == wellFovTemp1 [counter4]){
                                                                    counterPosition = counter4;
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                        else if (wellCount2 == 2){
                                                            for (int counter4 = 1; counter4 <= 49; counter4++){
                                                                if (atoi(fovNoExtract.c_str()) == wellFovTemp2 [counter4]){
                                                                    counterPosition = counter4;
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                        else if (wellCount2 == 3){
                                                            for (int counter4 = 1; counter4 <= 49; counter4++){
                                                                if (atoi(fovNoExtract.c_str()) == wellFovTemp3 [counter4]){
                                                                    counterPosition = counter4;
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                        else if (wellCount2 == 4){
                                                            for (int counter4 = 1; counter4 <= 49; counter4++){
                                                                if (atoi(fovNoExtract.c_str()) == wellFovTemp4 [counter4]){
                                                                    counterPosition = counter4;
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                        else if (wellCount2 == 5){
                                                            for (int counter4 = 1; counter4 <= 49; counter4++){
                                                                if (atoi(fovNoExtract.c_str()) == wellFovTemp5 [counter4]){
                                                                    counterPosition = counter4;
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                        else if (wellCount2 == 6){
                                                            for (int counter4 = 1; counter4 <= 49; counter4++){
                                                                if (atoi(fovNoExtract.c_str()) == wellFovTemp6 [counter4]){
                                                                    counterPosition = counter4;
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                        else if (wellCount2 == 7){
                                                            for (int counter4 = 1; counter4 <= 49; counter4++){
                                                                if (atoi(fovNoExtract.c_str()) == wellFovTemp7 [counter4]){
                                                                    counterPosition = counter4;
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                        else if (wellCount2 == 8){
                                                            for (int counter4 = 1; counter4 <= 49; counter4++){
                                                                if (atoi(fovNoExtract.c_str()) == wellFovTemp8 [counter4]){
                                                                    counterPosition = counter4;
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                        
                                                        xPosition2 = fovPosition [counterPosition*2];
                                                        yPosition2 = fovPosition [counterPosition*2+1];
                                                        
                                                        photoMetric2 = 1;
                                                        
                                                        if (numberOfLayers2 == 1) mode2 = 0;
                                                        else mode2 = 1;
                                                        
                                                        self->singleTiffSave = [[SingleTiffSave alloc] init];
                                                        ifDPreviousHold = [self->singleTiffSave singleTiffLayerSave:newImageDimension2:newImageDimension2:imageBit2:photoMetric2:samplePerPix2:xPosition2:yPosition2:mode2:ifDPreviousHold];
                                                        
                                                        
                                                        if (nextAddress2 != 0) headPosition3 = nextAddress2;
                                                        else terminationFlag2 = 0;
                                                        
                                                        for (int counter3 = 0; counter3 < newImageDimension2+1; counter3++){
                                                            delete [] arrayImageFileSave [counter3];
                                                        }
                                                        
                                                        delete [] arrayImageFileSave;
                                                        
                                                    } while (terminationFlag2 == 1);
                                                    
                                                    delete [] arrayExtractedImage3;
                                                    delete [] fileReadArray;
                                                }
                                            }
                                        }
                                        
                                        delete [] newFileList;
                                        delete [] wellFovTemp1;
                                        delete [] wellFovTemp2;
                                        delete [] wellFovTemp3;
                                        delete [] wellFovTemp4;
                                        delete [] wellFovTemp5;
                                        delete [] wellFovTemp6;
                                        delete [] wellFovTemp7;
                                        delete [] wellFovTemp8;
                                        
                                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                                        [sound play];
                                        
                                        backSaveOn = 3;
                                        otherProcessOn = 0;
                                    });
                                }
                                else{
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"File Format Mismatch/Disk Space Low/Set Start No"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                            }
                            else{
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"Folders Vary In File Count"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"FOV Number Or Body Name Error"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Exceeded No Of Treatment: Mubt Be <16"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Folder Creation Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                if (checkResults != 0){
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Check Naming Rule"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"FOV Set: Yes"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select Source/Destination Folder"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

@end
