//
//  Processing.h
//  FileConverter
//
//  Created by Masahiko Sato on 2018-06-05.
//
//

#ifndef PROCESSING_H
#define PROCESSING_H
#import "Controller.h"
#endif

@interface Processing : NSObject{
    IBOutlet NSTextField *contrastMeanDisplay;
    IBOutlet NSTextField *belowCutDisplay;
    IBOutlet NSTextField *aboveCutDisplay;
    IBOutlet NSTextField *valueBelowDisplay;
    IBOutlet NSTextField *valueMeanAboveDisplay;
    IBOutlet NSTextField *valueMeanBelowDisplay;
    IBOutlet NSTextField *valueFoldDisplay;
    IBOutlet NSTextField *rangeFromDisplay;
    IBOutlet NSTextField *rangeToDisplay;
    IBOutlet NSTextField *tiff16To8Display;
    IBOutlet NSTextField *bodyNameDisplay;
    
    IBOutlet NSTextField *body1;
    IBOutlet NSTextField *body2;
    IBOutlet NSTextField *body3;
    IBOutlet NSTextField *body4;
    IBOutlet NSTextField *body5;
    IBOutlet NSTextField *body6;
    IBOutlet NSTextField *body7;
    IBOutlet NSTextField *body8;
    
    IBOutlet NSProgressIndicator *backSave;
    
    id ascIIconversion;
    id singleTiffSave;
    id tiffFileRead;
    id processingOptions;
}

-(void)fileDeleteUpDate;

-(IBAction)tiffToProducts:(id)sender;
-(IBAction)tiffToSTimage:(id)sender;
-(IBAction)tiffToBackup:(id)sender;

@end
