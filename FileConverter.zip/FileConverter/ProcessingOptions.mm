//
//  ProcessingOptions.m
//  FileConverter
//
//  Created by Masahiko Sato on 2021-07-21.
//

#import "ProcessingOptions.h"

@implementation ProcessingOptions

-(int)imageProcessingOptions:(int)imageBit :(int)newImageDimension{
    //----Blank part of image is filled with -1. it will be changed to 0 before returning to main----
    
    int valueTempInt = 0;
    double valueTemp = 0;
    
    if (imageBit == 16){ //----16 bit to 8 bit conversion, if range is set, expand the range, out put 8 bit----
        if (tiff16To8Hold == 1 && rangeFromHold != -1 && rangeToHold != -1){
            for (int counter5 = 0; counter5 < newImageDimension; counter5++){
                for (int counter6 = 0; counter6 < newImageDimension; counter6++){
                    if (arrayImageFileSave [counter5][counter6] != -1){
                        if (arrayImageFileSave [counter5][counter6] < rangeFromHold) arrayImageFileSave [counter5][counter6] = 0;
                        else if (arrayImageFileSave [counter5][counter6] > rangeToHold) arrayImageFileSave [counter5][counter6] = 255;
                        else{
                            
                            valueTemp = (arrayImageFileSave [counter5][counter6]/(double)(rangeToHold-rangeFromHold))*256;
                            valueTempInt = (int)valueTemp;
                            
                            if (valueTemp-valueTempInt > 0.5) valueTempInt++;
                            if (valueTempInt > 255) valueTempInt = 255;
                            
                            arrayImageFileSave [counter5][counter6] = valueTempInt;
                        }
                    }
                }
            }
        }
        else{
            
            for (int counter5 = 0; counter5 < newImageDimension; counter5++){
                for (int counter6 = 0; counter6 < newImageDimension; counter6++){
                    if (arrayImageFileSave [counter5][counter6] != -1){
                        valueTemp = arrayImageFileSave [counter5][counter6]/(double)256;
                        valueTempInt = (int)valueTemp;
                        
                        if (valueTemp-valueTempInt > 0.5) valueTempInt++;
                        if (valueTempInt > 255) valueTempInt = 255;
                        
                        arrayImageFileSave [counter5][counter6] = valueTempInt;
                    }
                }
            }
        }
    }
    
    int *hitsgramTemp = new int [300];
    
    for (int counter5 = 1; counter5 <= 255; counter5++) hitsgramTemp [counter5] = 0;
    
    for (int counter5 = 0; counter5 < newImageDimension; counter5++){
        for (int counter6 = 0; counter6 < newImageDimension; counter6++){
            if (arrayImageFileSave [counter5][counter6] != -1){
                if (arrayImageFileSave [counter5][counter6] > 255) hitsgramTemp [255]++;
                else if (arrayImageFileSave [counter5][counter6] < 0) hitsgramTemp [0]++;
                else hitsgramTemp [arrayImageFileSave [counter5][counter6]]++;
            }
        }
    }
    
    unsigned long totalImageCount = 0;
    int numberOfImagePoint = 0;
    int meanValueTemp = 0;
    int meanShift = 0;
    
    for (int counter5 = 1; counter5 <= 255; counter5++){
        numberOfImagePoint = numberOfImagePoint+hitsgramTemp [counter5];
        totalImageCount = totalImageCount+(unsigned long)counter5*(unsigned long)hitsgramTemp [counter5];
    }
    
    if (numberOfImagePoint != 0) meanValueTemp = (int)(totalImageCount/(double)numberOfImagePoint);
    
    delete [] hitsgramTemp;
    
    if (contrastActivateHold == 1){ //----Contrast adjust----
        if (contrastMeanHold != -1){
            meanShift = meanValueTemp-contrastMeanHold;
            
            for (int counter5 = 0; counter5 < newImageDimension; counter5++){
                for (int counter6 = 0; counter6 < newImageDimension; counter6++){
                    if (arrayImageFileSave [counter5][counter6] != -1){
                        arrayImageFileSave [counter5][counter6] = arrayImageFileSave [counter5][counter6]-meanShift;
                        
                        if (meanAboveFoldHold != -1 && arrayImageFileSave [counter5][counter6] > contrastMeanHold){
                            arrayImageFileSave [counter5][counter6] = arrayImageFileSave [counter5][counter6]+(int)((arrayImageFileSave [counter5][counter6]-contrastMeanHold)*(double)meanAboveFoldHold);
                        }
                        
                        if (meanBelowFoldHold != -1 && arrayImageFileSave [counter5][counter6] < contrastMeanHold){
                            arrayImageFileSave [counter5][counter6] = arrayImageFileSave [counter5][counter6]-(int)((contrastMeanHold-arrayImageFileSave [counter5][counter6])*(double)meanBelowFoldHold);
                        }
                        
                        if (arrayImageFileSave [counter5][counter6] > 255) arrayImageFileSave [counter5][counter6] = 255;
                        if (arrayImageFileSave [counter5][counter6] < 0) arrayImageFileSave [counter5][counter6] = 0;
                    }
                }
            }
        }
        
        if (belowCutHold != -1){
            for (int counter5 = 0; counter5 < newImageDimension; counter5++){
                for (int counter6 = 0; counter6 < newImageDimension; counter6++){
                    if (arrayImageFileSave [counter5][counter6] != -1){
                        if (arrayImageFileSave [counter5][counter6] <= belowCutHold){
                            arrayImageFileSave [counter5][counter6] = valueBelowHold;
                        }
                    }
                }
            }
        }
        
        if (aboveCutHold != -1){
            for (int counter5 = 0; counter5 < newImageDimension; counter5++){
                for (int counter6 = 0; counter6 < newImageDimension; counter6++){
                    if (arrayImageFileSave [counter5][counter6] != -1){
                        if (arrayImageFileSave [counter5][counter6] >= aboveCutHold){
                            arrayImageFileSave [counter5][counter6] = arrayImageFileSave [counter5][counter6]+(int)((arrayImageFileSave [counter5][counter6]-aboveCutHold)*(double)valueFoldHold);
                        }
                        
                        if (arrayImageFileSave [counter5][counter6] > 255) arrayImageFileSave [counter5][counter6] = 255;
                    }
                }
            }
        }
    }
    
    if (tiffReductionHold != 0){ //----Tif size reduction----
        int **arrayImageFileSave2 = new int *[newImageDimension/2+10];
        int **arrayDivisionMap = new int *[newImageDimension/2+10];
        
        for (int counter5 = 0; counter5 < newImageDimension/2+10; counter5++){
            arrayImageFileSave2 [counter5] = new int [newImageDimension/2+10];
            arrayDivisionMap [counter5] = new int [newImageDimension/2+10];
        }
        
        for (int counter5 = 0; counter5 < newImageDimension/2+10; counter5++){
            for (int counter6 = 0; counter6 < newImageDimension/2+10; counter6++){
                arrayImageFileSave2 [counter5][counter6] = 0;
                arrayDivisionMap [counter5][counter6] = 0;
            }
        }
        
        int horizontalCount = 0;
        int verticalCount = 0;
        int verticalLineRepeat = 0;
        
        for (int counter5 = 0; counter5 < newImageDimension; counter5++){
            for (int counter6 = 0; counter6 < newImageDimension; counter6 = counter6+2){
                if (arrayImageFileSave [counter5][counter6] != -1){
                    arrayImageFileSave2 [verticalCount][horizontalCount] = arrayImageFileSave2 [verticalCount][horizontalCount]+arrayImageFileSave [counter5][counter6];
                    arrayDivisionMap [verticalCount][horizontalCount]++;
                }
                
                if (arrayImageFileSave [counter5][counter6+1] != -1){
                    arrayImageFileSave2 [verticalCount][horizontalCount] = arrayImageFileSave2 [verticalCount][horizontalCount]+arrayImageFileSave [counter5][counter6+1];
                    arrayDivisionMap [verticalCount][horizontalCount]++;
                }
                
                horizontalCount++;
            }
            
            horizontalCount = 0;
            verticalLineRepeat++;
            
            if (verticalLineRepeat == 2){
                verticalLineRepeat = 0;
                verticalCount++;
            }
        }
        
        for (int counter5 = 0; counter5 < newImageDimension+1; counter5++){
            delete [] arrayImageFileSave [counter5];
        }
        
        delete [] arrayImageFileSave;
        
        int newImageDimensionTemp = newImageDimension/2;
        
        for (int counter5 = 0; counter5 < newImageDimensionTemp; counter5++){
            for (int counter6 = 0; counter6 < newImageDimensionTemp; counter6++){
                if (arrayDivisionMap [counter5][counter6] != 0){
                    arrayImageFileSave2 [counter5][counter6] = (int)(arrayImageFileSave2 [counter5][counter6]/(double)arrayDivisionMap [counter5][counter6]);
                }
            }
        }
        
        arrayImageFileSave = new int *[newImageDimensionTemp+1];
        
        for (int counter5 = 0; counter5 < newImageDimensionTemp+1; counter5++){
            arrayImageFileSave [counter5] = new int [newImageDimensionTemp+1];
        }
        
        for (int counter5 = 0; counter5 < newImageDimensionTemp; counter5++){
            for (int counter6 = 0; counter6 < newImageDimensionTemp; counter6++){
                arrayImageFileSave [counter5][counter6] = arrayImageFileSave2 [counter5][counter6];
            }
        }
        
        for (int counter5 = 0; counter5 < newImageDimension/2+10; counter5++){
            delete [] arrayImageFileSave2 [counter5];
            delete [] arrayDivisionMap [counter5];
        }
        
        delete [] arrayImageFileSave2;
        delete [] arrayDivisionMap;
        
        newImageDimension = newImageDimensionTemp;
    }
    
    for (int counter5 = 0; counter5 < newImageDimension; counter5++){
        for (int counter6 = 0; counter6 < newImageDimension; counter6++){
            if (arrayImageFileSave [counter5][counter6] == -1){
                arrayImageFileSave [counter5][counter6] = 0;
            }
        }
    }
    
    return newImageDimension;
}

@end
