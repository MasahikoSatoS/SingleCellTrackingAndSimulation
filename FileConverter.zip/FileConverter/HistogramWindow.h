//
//  HistogramWindow.h
//  FileConverter
//
//  Created by Masahiko Sato on 2018-06-15.
//
//

#ifndef HISTOGRAMWINDOW_H
#define HISTOGRAMWINDOW_H
#import "Controller.h"
#endif

@interface HistogramWindow : NSView{
    int selectProcessLine; //Process line
    int dragFlag; //Drag flag
    int verticalMagnification; //Vertical magnification
    int verticalMagnificationStep; //Vertical magnification step
    double xPointDownHisto; //Histo
    double yPointDownHisto; //Histo
    double xPointDragHisto; //Histo
    
    id contrastAdjust;
    id tiffFileRead;
    
    IBOutlet NSImage *histogramImage;
}

-(void)mouseDown:(NSEvent *)event;
-(void)mouseDragged:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
