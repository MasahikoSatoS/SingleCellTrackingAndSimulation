//
//  SizeReduction.h
//  FileConverter
//
//  Created by Masahiko Sato on 2018-06-17.
//
//

#ifndef SIZEREDUCTION_H
#define SIZEREDUCTION_H
#import "Controller.h" 
#endif

@interface SizeReduction : NSObject{
    IBOutlet NSProgressIndicator *backSave;
    
    id singleTiffSave;
    id tiffFileRead;
}

-(void)fileDeleteUpDate;

-(IBAction)sizeReductionSet:(id)sender;

@end
