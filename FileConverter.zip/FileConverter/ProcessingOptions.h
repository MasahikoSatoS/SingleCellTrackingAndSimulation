//
//  ProcessingOptions.h
//  FileConverter
//
//  Created by Masahiko Sato on 2021-07-21.
//

#ifndef PROCESSINGOPTIONS_H
#define PROCESSINGOPTIONS_H
#import "Controller.h"
#endif

@interface ProcessingOptions : NSObject{
    IBOutlet NSTextField *body1;
    IBOutlet NSTextField *body2;
    IBOutlet NSTextField *body3;
    IBOutlet NSTextField *body4;
    IBOutlet NSTextField *body5;
    IBOutlet NSTextField *body6;
    IBOutlet NSTextField *body7;
    IBOutlet NSTextField *body8;
}

-(int)imageProcessingOptions:(int)imageBit :(int)newImageDimension;

@end
