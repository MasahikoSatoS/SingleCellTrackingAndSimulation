//
//  TiffFileRead.m
//  CellMovie3
//
//  Created by Masahiko Sato on 2021-07-01.
//  Copyright Masahiko Sato 2021 All rights reserved.
//

#import "TiffFileRead.h"

@implementation TiffFileRead

-(void)tiffReadBigEndian:(unsigned long)headPosition :(int*)imageWidth :(int*)imageHeight :(int*)imageBit :(int*)imageCompression :(int*)photoMetric : (double*)xPosition :(double*)yPosition :(int*)samplePerPix :(unsigned long*)stripFirstAddress :(unsigned long*)stripEntry :(unsigned long*)stripByteCountAddress :(unsigned long*)nextAddress :(int*)numberOfLayers{
    //----------IFD data read---------
    int dataConversion [4];
    int dataConversion2 [6];
    
    dataConversion [0] = fileReadArray [headPosition+1];
    dataConversion [1] = fileReadArray [headPosition];
    
    int numberOfIFDEntry = dataConversion[1]*256+dataConversion[0];
    
    int imageWidthTF = 0;
    int imageHeightTF = 0;
    int imageBitTF = 0;
    int imageCompressionTF = 1;
    int photoMetricTF = 0;
    int samplePerPixTF = 0;
    int numberOfLayersTF = 1;
    
    unsigned long stripEntryTF = 0;
    unsigned long stripFirstAddressTF = 0;
    unsigned long stripByteCountAddressTF = 0;
    unsigned long nextAddressTF = 0;
    unsigned long imageBitAddressTF = 0;
    
    double xPositionTF = -1;
    double yPositionTF = -1;
    
    string readData = "";
    
    for (int counter3 = 0; counter3 < numberOfIFDEntry; counter3++){
        dataConversion [0] = fileReadArray [headPosition+(unsigned long)counter3*12+3];
        dataConversion [1] = fileReadArray [headPosition+(unsigned long)counter3*12+2];
        dataConversion [2] = fileReadArray [headPosition+(unsigned long)counter3*12+5];
        
        if (dataConversion [0] == 0 && dataConversion [1] == 1){ //-------Image Width------
            if (dataConversion [2] == 4){ //------LONG
                dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+13];
                dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+12];
                dataConversion2 [2] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
                dataConversion2 [3] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
                imageWidthTF = (int)((unsigned long)dataConversion2 [3]*16777216+(unsigned long)dataConversion2 [2]*65536+(unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0]);
            }
            else if (dataConversion [2] == 3){ //------SHORT
                dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
                dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
                imageWidthTF = dataConversion2 [1]*256+dataConversion2 [0];
            }
            
            //cout<<imageWidthTF<<" Width"<<endl;
        }
        else if (dataConversion [0] == 1 && dataConversion [1] == 1){ //-------Image height-------
            if (dataConversion [2] == 4){ //-----LONG
                dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+13];
                dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+12];
                dataConversion2 [2] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
                dataConversion2 [3] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
                imageHeightTF = (int)((unsigned long)dataConversion2 [3]*16777216+(unsigned long)dataConversion2 [2]*65536+(unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0]);
            }
            else if (dataConversion [2] == 3){ //-----SHORT
                dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
                dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
                imageHeightTF = dataConversion2 [1]*256+dataConversion2 [0];
            }
            
            //cout<<imageHeightTF<<" Height"<<endl;
        }
        else if (dataConversion [0] == 2 && dataConversion [1] == 1){ //-----BitsPerSample------
            dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+9];
            
            if (dataConversion2 [0] == 1){ //------Gray-----
                dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
                dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
                imageBitTF = dataConversion2 [1]*256+dataConversion2 [0];
                
                if (imageBitTF == 8) samplePerPixTF = 1;
                else if (imageBitTF == 16) samplePerPixTF = 2;
            }
            else if (dataConversion2 [0] == 3 || dataConversion2 [0] == 4){ //------RGB-----
                dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+13];
                dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+12];
                dataConversion2 [2] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
                dataConversion2 [3] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
                imageBitAddressTF = (unsigned long)dataConversion2 [3]*16777216+(unsigned long)dataConversion2 [2]*65536+(unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0];
                
                for (int counter4 = 0; counter4 < 3; counter4++){
                    dataConversion2 [0] = fileReadArray [imageBitAddressTF+(unsigned long)counter4*2+1];
                    dataConversion2 [1] = fileReadArray [imageBitAddressTF+(unsigned long)counter4*2];
                    
                    if (counter4 == 0) imageBitTF = dataConversion2 [1]*256+dataConversion2 [0];
                    else if (imageBitTF != dataConversion2 [1]*256+dataConversion2 [0]) imageBitTF = 0;
                }
                
                if (imageBitTF == 8) samplePerPixTF = 3;
                else if (imageBitTF == 16) samplePerPixTF = 6;
            }
            else if (dataConversion2 [0] == 4){ //------RGB with Alpha-----
                dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+13];
                dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+12];
                dataConversion2 [2] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
                dataConversion2 [3] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
                imageBitAddressTF = (unsigned long)dataConversion2 [3]*16777216+(unsigned long)dataConversion2 [2]*65536+(unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0];
                
                for (int counter4 = 0; counter4 < 4; counter4++){
                    dataConversion2 [0] = fileReadArray [imageBitAddressTF+(unsigned long)counter4*2+1];
                    dataConversion2 [1] = fileReadArray [imageBitAddressTF+(unsigned long)counter4*2];
                    
                    if (counter4 == 0) imageBitTF = dataConversion2 [1]*256+dataConversion2 [0];
                    else if (imageBitTF != dataConversion2 [1]*256+dataConversion2 [0]) imageBitTF = 0; //----All channel depth has to be same, if not set zero----
                }
                
                if (imageBitTF == 8) samplePerPixTF = 4;
                else if (imageBitTF == 16) samplePerPixTF = 8;
            }
            
            //cout<<imageBitTF<<" imageBitTF "<<dataConversion2 [0]<<" "<<dataConversion2 [1]<<" "<<dataConversion2 [2]<<" "<<dataConversion2 [3]<<" "<<endl;
        }
        else if (dataConversion [0] == 3 && dataConversion [1] == 1){ //----Compression-----
            dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
            dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
            imageCompressionTF = dataConversion2 [1]*256+dataConversion2 [0];
            
            //cout<<imageCompressionTF<<" compression"<<endl; //----1 no compression
        }
        else if (dataConversion [0] == 6 && dataConversion [1] == 1){ //----Photometric-------
            dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
            dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
            photoMetricTF = dataConversion2 [1]*256+dataConversion2 [0];
            
            //cout<<photoMetric<<" photoMetric"<<endl; //----0: Gray, 0= white, 1: Gray, 0=Black, 2: RGB, Other format will not accept
        }
        else if (dataConversion [0] == 21 && dataConversion [1] == 1){ //----Sample per pix------
            dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
            dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
            samplePerPixTF = dataConversion2 [1]*256+dataConversion2 [0];
            
            //cout<<samplePerPix<<" samplePerPix "<<dataConversion2 [0]<<" "<<dataConversion2 [1]<<endl;
        }
        else if (dataConversion [0] == 17 && dataConversion [1] == 1){ //-----Strip entry-----
            dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+5];
            
            if (dataConversion2 [0] == 4){
                dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+13];
                dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+12];
                dataConversion2 [2] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
                dataConversion2 [3] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
                stripFirstAddressTF = (unsigned long)dataConversion2 [3]*16777216+(unsigned long)dataConversion2 [2]*65536+(unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0];
            }
            else if (dataConversion2 [0] == 3){
                dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
                dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
                stripFirstAddressTF = (unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0];
            }
            
            dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+9];
            dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+8];
            dataConversion2 [2] = fileReadArray [headPosition+(unsigned long)counter3*12+7];
            dataConversion2 [3] = fileReadArray [headPosition+(unsigned long)counter3*12+6];
            stripEntryTF = (unsigned long)dataConversion2 [3]*16777216+(unsigned long)dataConversion2 [2]*65536+(unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0];
            
            //cout<<stripFirstAddressTF<<" stripFirstAddressTF"<<endl;
        }
        else if (dataConversion [0] == 23 && dataConversion [1] == 1){ //-----StripByte-----
            dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+5];
            
            if (dataConversion2 [0] == 4){
                dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+13];
                dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+12];
                dataConversion2 [2] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
                dataConversion2 [3] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
                stripByteCountAddressTF = (unsigned long)dataConversion2 [3]*16777216+(unsigned long)dataConversion2 [2]*65536+(unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0];
            }
            else{
                
                dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
                dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
                stripByteCountAddressTF = (unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0];
            }
            
            //cout<<stripByteCountAddressTF<<" stripByteCountAddressTF"<<endl;
        }
        
        if (counter3 == numberOfIFDEntry-1){ //-----Next address-----
            dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+17];
            dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+16];
            dataConversion2 [2] = fileReadArray [headPosition+(unsigned long)counter3*12+15];
            dataConversion2 [3] = fileReadArray [headPosition+(unsigned long)counter3*12+14];
            nextAddressTF = (unsigned long)dataConversion2 [3]*16777216+(unsigned long)dataConversion2 [2]*65536+(unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0];
            
            if (nextAddressTF != 0) numberOfLayersTF++;
            
            //cout<<nextAddressTF<<" nextAddressTF"<<endl;
        }
    }
    
    *imageWidth = imageWidthTF;
    *imageHeight = imageHeightTF;
    *imageBit = imageBitTF;
    *imageCompression = imageCompressionTF;
    *photoMetric = photoMetricTF;
    *xPosition = xPositionTF;
    *yPosition = yPositionTF;
    *samplePerPix = samplePerPixTF;
    *stripFirstAddress = stripFirstAddressTF;
    *stripEntry = stripEntryTF;
    *stripByteCountAddress = stripByteCountAddressTF;
    *nextAddress = nextAddressTF;
    *numberOfLayers = numberOfLayersTF;
}

-(void)tiffReadLittleEndian:(unsigned long)headPosition :(int*)imageWidth :(int*)imageHeight :(int*)imageBit :(int*)imageCompression :(int*)photoMetric : (double*)xPosition :(double*)yPosition :(int*)samplePerPix :(unsigned long*)stripFirstAddress :(unsigned long*)stripEntry :(unsigned long*)stripByteCountAddress :(unsigned long*)nextAddress :(int*)numberOfLayers{
    
    int dataConversion [4];
    int dataConversion2 [6];
    
    dataConversion [0] = fileReadArray [headPosition];
    dataConversion [1] = fileReadArray [headPosition+1];
    
    int numberOfIFDEntry = dataConversion[1]*256+dataConversion[0];
    
    int imageWidthTF = 0;
    int imageHeightTF = 0;
    int imageBitTF = 0;
    int imageCompressionTF = 1;
    int photoMetricTF = 0;
    int samplePerPixTF = 0;
    int numberOfLayersTF = 1;
    
    unsigned long stripEntryTF = 0;
    unsigned long stripFirstAddressTF = 0;
    unsigned long stripByteCountAddressTF = 0;
    unsigned long nextAddressTF = 0;
    unsigned long imageBitAddressTF = 0;
    
    double xPositionTF = -1;
    double yPositionTF = -1;
    
    string readData = "";
    
    for (int counter3 = 0; counter3 < numberOfIFDEntry; counter3++){
        dataConversion [0] = fileReadArray [headPosition+(unsigned long)counter3*12+2];
        dataConversion [1] = fileReadArray [headPosition+(unsigned long)counter3*12+3];
        dataConversion [2] = fileReadArray [headPosition+(unsigned long)counter3*12+4];
        
        if (dataConversion [0] == 0 && dataConversion [1] == 1){ //-------Image Width------
            if (dataConversion [2] == 4){ //------LONG
                dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
                dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
                dataConversion2 [2] = fileReadArray [headPosition+(unsigned long)counter3*12+12];
                dataConversion2 [3] = fileReadArray [headPosition+(unsigned long)counter3*12+13];
                imageWidthTF = (int)((unsigned long)dataConversion2 [3]*16777216+(unsigned long)dataConversion2 [2]*65536+(unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0]);
            }
            else if (dataConversion [2] == 3){ //------SHORT
                dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
                dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
                imageWidthTF = dataConversion2 [1]*256+dataConversion2 [0];
            }
            
            //cout<<imageWidthTF<<" Width"<<endl;
        }
        else if (dataConversion [0] == 1 && dataConversion [1] == 1){ //-------Image height-------
            if (dataConversion [2] == 4){ //-----LONG
                dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
                dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
                dataConversion2 [2] = fileReadArray [headPosition+(unsigned long)counter3*12+12];
                dataConversion2 [3] = fileReadArray [headPosition+(unsigned long)counter3*12+13];
                imageHeightTF = (int)((unsigned long)dataConversion2 [3]*16777216+(unsigned long)dataConversion2 [2]*65536+(unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0]);
            }
            else if (dataConversion [2] == 3){ //------SHORT
                dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
                dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
                imageHeightTF = dataConversion2 [1]*256+dataConversion2 [0];
            }
            
            //cout<<imageHeightTF<<" Height"<<endl;
        }
        else if (dataConversion [0] == 2 && dataConversion [1] == 1){ //-----BitsPerSample------
            dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+6];
            
            if (dataConversion2 [0] == 1){ //------Gray-----
                dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
                dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
                imageBitTF = dataConversion2 [1]*256+dataConversion2 [0];
                
                if (imageBitTF == 8) samplePerPixTF = 1;
                else if (imageBitTF == 16) samplePerPixTF = 2;
            }
            else if (dataConversion2 [0] == 3 || dataConversion2 [0] == 4){ //------RGB-----
                dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
                dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
                dataConversion2 [2] = fileReadArray [headPosition+(unsigned long)counter3*12+12];
                dataConversion2 [3] = fileReadArray [headPosition+(unsigned long)counter3*12+13];
                imageBitAddressTF = (unsigned long)dataConversion2 [3]*16777216+(unsigned long)dataConversion2 [2]*65536+(unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0];
                
                for (int counter4 = 0; counter4 < 3; counter4++){
                    dataConversion2 [0] = fileReadArray [imageBitAddressTF+(unsigned long)counter4*2];
                    dataConversion2 [1] = fileReadArray [imageBitAddressTF+(unsigned long)counter4*2+1];
                    
                    if (counter4 == 0) imageBitTF = dataConversion2 [1]*256+dataConversion2 [0];
                    else if (imageBitTF != dataConversion2 [1]*256+dataConversion2 [0]) imageBitTF = 0;
                }
                
                if (imageBitTF == 8) samplePerPixTF = 3;
                else if (imageBitTF == 16) samplePerPixTF = 6;
            }
            else if (dataConversion2 [0] == 4){ //------RGB with Alpha-----
                dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
                dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
                dataConversion2 [2] = fileReadArray [headPosition+(unsigned long)counter3*12+12];
                dataConversion2 [3] = fileReadArray [headPosition+(unsigned long)counter3*12+13];
                imageBitAddressTF = (unsigned long)dataConversion2 [3]*16777216+(unsigned long)dataConversion2 [2]*65536+(unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0];
                
                for (int counter4 = 0; counter4 < 4; counter4++){
                    dataConversion2 [0] = fileReadArray [imageBitAddressTF+(unsigned long)counter4*2+1];
                    dataConversion2 [1] = fileReadArray [imageBitAddressTF+(unsigned long)counter4*2];
                    
                    if (counter4 == 0) imageBitTF = dataConversion2 [1]*256+dataConversion2 [0];
                    else if (imageBitTF != dataConversion2 [1]*256+dataConversion2 [0]) imageBitTF = 0; //----All channel depth has to be same, if not set zero----
                }
                
                if (imageBitTF == 8) samplePerPixTF = 4;
                else if (imageBitTF == 16) samplePerPixTF = 8;
            }
            
            //cout<<imageBit<<" imageBit"<<endl;
        }
        else if (dataConversion [0] == 3 && dataConversion [1] == 1){ //----Compression-----
            dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
            dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
            imageCompressionTF = dataConversion2 [1]*256+dataConversion2 [0];
            
            //cout<<imageCompression<<" compression"<<endl; //----1 no compression
        }
        else if (dataConversion [0] == 6 && dataConversion [1] == 1){  //----Photometric-------
            dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
            dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
            photoMetricTF = dataConversion2 [1]*256+dataConversion2 [0];
            
            //cout<<photoMetric<<" photoMetric"<<endl; //----1 0-black
        }
        else if (dataConversion [0] == 21 && dataConversion [1] == 1){ //----Sample per pix------
            dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
            dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
            samplePerPixTF = dataConversion2 [1]*256+dataConversion2 [0];
            
            //cout<<samplePerPix<<" samplePerPix "<<dataConversion2 [0]<<" "<<dataConversion2 [1]<<endl;
        }
        else if (dataConversion [0] == 17 && dataConversion [1] == 1){ //-----Strip entry-----
            dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+4];
            
            if (dataConversion2 [0] == 4){
                dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
                dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
                dataConversion2 [2] = fileReadArray [headPosition+(unsigned long)counter3*12+12];
                dataConversion2 [3] = fileReadArray [headPosition+(unsigned long)counter3*12+13];
                stripFirstAddressTF = (unsigned long)dataConversion2 [3]*16777216+(unsigned long)dataConversion2 [2]*65536+(unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0];
            }
            else if (dataConversion2 [0] == 3){
                dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
                dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
                stripFirstAddressTF = (unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0];
            }
            
            dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+6];
            dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+7];
            dataConversion2 [2] = fileReadArray [headPosition+(unsigned long)counter3*12+8];
            dataConversion2 [3] = fileReadArray [headPosition+(unsigned long)counter3*12+9];
            stripEntryTF = (unsigned long)dataConversion2 [3]*16777216+(unsigned long)dataConversion2 [2]*65536+(unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0];
            
            //cout<<stripFirstAddress<<" stripFirstAddress"<<endl;
        }
        else if (dataConversion [0] == 23 && dataConversion [1] == 1){ //-----StripByte-----
            dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+4];
            
            if (dataConversion2 [0] == 4){
                dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
                dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
                dataConversion2 [2] = fileReadArray [headPosition+(unsigned long)counter3*12+12];
                dataConversion2 [3] = fileReadArray [headPosition+(unsigned long)counter3*12+13];
                stripByteCountAddressTF = (unsigned long)dataConversion2 [3]*16777216+(unsigned long)dataConversion2 [2]*65536+(unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0];
            }
            else{
                
                dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+10];
                dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+11];
                stripByteCountAddressTF = (unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0];
            }
            
            //cout<<stripByteCountAddress<<" stripByteCountAddress"<<endl;
        }
        
        if (counter3 == numberOfIFDEntry-1){ //-----Next address-----
            dataConversion2 [0] = fileReadArray [headPosition+(unsigned long)counter3*12+14];
            dataConversion2 [1] = fileReadArray [headPosition+(unsigned long)counter3*12+15];
            dataConversion2 [2] = fileReadArray [headPosition+(unsigned long)counter3*12+16];
            dataConversion2 [3] = fileReadArray [headPosition+(unsigned long)counter3*12+17];
            nextAddressTF = (unsigned long)dataConversion2 [3]*16777216+(unsigned long)dataConversion2 [2]*65536+(unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0];
            
            if (nextAddressTF != 0) numberOfLayersTF++;
            
            //cout<<nextAddressTF<<" "<<numberOfLayersTF<<" nextAddress"<<endl;
        }
    }
    
    *imageWidth = imageWidthTF;
    *imageHeight = imageHeightTF;
    *imageBit = imageBitTF;
    *imageCompression = imageCompressionTF;
    *photoMetric = photoMetricTF;
    *xPosition = xPositionTF;
    *yPosition = yPositionTF;
    *samplePerPix = samplePerPixTF;
    *stripFirstAddress = stripFirstAddressTF;
    *stripEntry = stripEntryTF;
    *stripByteCountAddress = stripByteCountAddressTF;
    *nextAddress = nextAddressTF;
    *numberOfLayers = numberOfLayersTF;
}

-(int*)imageSetBigEndian:(int)imageDimension :(int)imageBit :(int)photoMetric :(int)samplePerPix :(unsigned long)stripEntry :(unsigned long)stripFirstAddress :(unsigned long) stripByteCountAddress :(int)processType{
    int *arrayExtractedImage = new int [imageDimension*imageDimension*3+1];
    
    unsigned long *blockAddressList = new unsigned long [stripEntry+10];
    unsigned long blockAddressListCount = 0;
    unsigned long *blockByteList = new unsigned long [stripEntry+10];
    unsigned long blockByteListCount = 0;
    
    int dataConversion2 [6];
    
    if (stripEntry == 1){
        blockAddressList [blockAddressListCount] = stripFirstAddress, blockAddressListCount++;
        blockByteList [blockByteListCount] = stripByteCountAddress, blockByteListCount++;
    }
    else{
        
        for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
            dataConversion2 [0] = fileReadArray [stripFirstAddress+counter3*4+3];
            dataConversion2 [1] = fileReadArray [stripFirstAddress+counter3*4+2];
            dataConversion2 [2] = fileReadArray [stripFirstAddress+counter3*4+1];
            dataConversion2 [3] = fileReadArray [stripFirstAddress+counter3*4];
            blockAddressList [blockAddressListCount] = (unsigned long)dataConversion2 [3]*16777216+(unsigned long)dataConversion2 [2]*65536+(unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0], blockAddressListCount++;
            
            dataConversion2 [0] = fileReadArray [stripByteCountAddress+counter3*4+3];
            dataConversion2 [1] = fileReadArray [stripByteCountAddress+counter3*4+2];
            dataConversion2 [2] = fileReadArray [stripByteCountAddress+counter3*4+1];
            dataConversion2 [3] = fileReadArray [stripByteCountAddress+counter3*4];
            blockByteList [blockByteListCount] = (unsigned long)dataConversion2 [3]*16777216+(unsigned long)dataConversion2 [2]*65536+(unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0], blockByteListCount++;
        }
    }
    
    //processType = 0; 8 bit gray (8 bit gray)
    //processType = 1; 8 bit color (8 bit color or gray)
    //processType = 2; 16 bit gray (16 or 8 bit gray)
    //processType = 3; 16 bit color (16 or 8 bit gray or color)
    
    unsigned long entryBiteCount = 0;
    
    //cout<<imageBit <<" "<<photoMetric<<" "<<samplePerPix<<" "<<processType <<" info"<<endl;
    
    if (imageBit == 8 && photoMetric <= 1 && (processType == 0 || processType == 1 || processType == 2 || processType == 3)){ //-----8 bit gray--
        for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
            for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4++){
                if (photoMetric == 0) arrayExtractedImage [entryBiteCount] = 255-(int)fileReadArray [blockAddressList [counter3]+counter4];
                else arrayExtractedImage [entryBiteCount] = (int)fileReadArray [blockAddressList [counter3]+counter4];
                entryBiteCount++;
            }
        }
    }
    else if (imageBit == 8 && photoMetric == 2 && (samplePerPix == 3 || samplePerPix == 4) && (processType == 0 || processType == 2)){ //------8 bit color to 8 bit gray------
        if (samplePerPix == 3){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+3){
                    arrayExtractedImage [entryBiteCount] = fileReadArray [blockAddressList [counter3]+counter4];
                    entryBiteCount++;
                }
            }
        }
        else if (samplePerPix == 4){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+4){
                    arrayExtractedImage [entryBiteCount] = (int)((fileReadArray [blockAddressList [counter3]+counter4]+fileReadArray [blockAddressList [counter3]+counter4+1]+fileReadArray [blockAddressList [counter3]+counter4+2])/(double)3);
                    entryBiteCount++;
                }
            }
        }
    }
    else if (imageBit == 8 && photoMetric == 2 && (samplePerPix == 3 || samplePerPix == 4) && (processType == 1 || processType == 3)){ //----- 8 bit color-----
        if (samplePerPix == 3){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+3){
                    arrayExtractedImage [entryBiteCount] = (int)fileReadArray [blockAddressList [counter3]+counter4], entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = (int)fileReadArray [blockAddressList [counter3]+counter4+1], entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = (int)fileReadArray [blockAddressList [counter3]+counter4+2], entryBiteCount++;
                }
            }
        }
        else if (samplePerPix == 4){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+4){
                    arrayExtractedImage [entryBiteCount] = (int)fileReadArray [blockAddressList [counter3]+counter4], entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = (int)fileReadArray [blockAddressList [counter3]+counter4+1], entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = (int)fileReadArray [blockAddressList [counter3]+counter4+2], entryBiteCount++;
                }
            }
        }
    }
    else if (imageBit == 16 && photoMetric <= 1 && (processType == 0 || processType == 1)){ //----- 16 bit to 8 bit gray-----
        for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
            for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+2){
                if (photoMetric == 0) arrayExtractedImage [entryBiteCount] = (int)((65535-(fileReadArray [blockAddressList [counter3]+counter4]*256+fileReadArray [blockAddressList [counter3]+counter4+1]))/(double)256);
                else arrayExtractedImage [entryBiteCount] = (int)((fileReadArray [blockAddressList [counter3]+counter4]*256+fileReadArray [blockAddressList [counter3]+counter4+1])/(double)256);
                entryBiteCount++;
            }
        }
    }
    else if (imageBit == 16 && photoMetric <= 1 && (processType == 2 || processType == 3)){ //----- 16 bit gray-----
        for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
            for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+2){
                if (photoMetric == 0) arrayExtractedImage [entryBiteCount] = 65535-(fileReadArray [blockAddressList [counter3]+counter4]*256+fileReadArray [blockAddressList [counter3]+counter4+1]);
                else arrayExtractedImage [entryBiteCount] = fileReadArray [blockAddressList [counter3]+counter4]*256+fileReadArray [blockAddressList [counter3]+counter4+1];
                entryBiteCount++;
            }
        }
    }
    else if (imageBit == 16 && photoMetric == 2 && (samplePerPix == 3 || samplePerPix == 4) && processType == 0){ //----- 16 bit color to 8 bit gray-----
        if (samplePerPix == 3){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+6){
                    arrayExtractedImage [entryBiteCount] = (int)(((fileReadArray [blockAddressList [counter3]+counter4]*256+fileReadArray [blockAddressList [counter3]+counter4+1]+fileReadArray [blockAddressList [counter3]+counter4+2]*256+fileReadArray [blockAddressList [counter3]+counter4+3]+fileReadArray [blockAddressList [counter3]+counter4+4]*256+fileReadArray [blockAddressList [counter3]+counter4+5])/(double)3)/(double)256);
                    entryBiteCount++;
                }
            }
        }
        else if (samplePerPix == 4){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+8){
                    arrayExtractedImage [entryBiteCount] = (int)(((fileReadArray [blockAddressList [counter3]+counter4]*256+fileReadArray [blockAddressList [counter3]+counter4+1]+fileReadArray [blockAddressList [counter3]+counter4+2]*256+fileReadArray [blockAddressList [counter3]+counter4+3]+fileReadArray [blockAddressList [counter3]+counter4+4]*256+fileReadArray [blockAddressList [counter3]+counter4+5])/(double)3)/(double)256);
                    entryBiteCount++;
                }
            }
        }
    }
    else if (imageBit == 16 && photoMetric == 2 && (samplePerPix == 3 || samplePerPix == 4) && processType == 2){ //----- 16 bit color to 16 bit gray-----
        if (samplePerPix == 3){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+6){
                    arrayExtractedImage [entryBiteCount] = (int)((fileReadArray [blockAddressList [counter3]+counter4]*256+fileReadArray [blockAddressList [counter3]+counter4+1]+fileReadArray [blockAddressList [counter3]+counter4+2]*256+fileReadArray [blockAddressList [counter3]+counter4+3]+fileReadArray [blockAddressList [counter3]+counter4+4]*256+fileReadArray [blockAddressList [counter3]+counter4+5])/(double)3);
                    entryBiteCount++;
                }
            }
        }
        else if (samplePerPix == 4){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+8){
                    arrayExtractedImage [entryBiteCount] = (int)((fileReadArray [blockAddressList [counter3]+counter4]*256+fileReadArray [blockAddressList [counter3]+counter4+1]+fileReadArray [blockAddressList [counter3]+counter4+2]*256+fileReadArray [blockAddressList [counter3]+counter4+3]+fileReadArray [blockAddressList [counter3]+counter4+4]*256+fileReadArray [blockAddressList [counter3]+counter4+5])/(double)3);
                    entryBiteCount++;
                }
            }
        }
    }
    else if (imageBit == 16 && photoMetric == 2 && (samplePerPix == 3 || samplePerPix == 4) && processType == 3){ //----- 16 bit color to 16 bit color-----
        if (samplePerPix == 3){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+6){
                    arrayExtractedImage [entryBiteCount] = fileReadArray [blockAddressList [counter3]+counter4]*256+(int)fileReadArray [blockAddressList [counter3]+counter4+1], entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = fileReadArray [blockAddressList [counter3]+counter4+2]*256+(int)fileReadArray [blockAddressList [counter3]+counter4+3], entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = fileReadArray [blockAddressList [counter3]+counter4+4]*256+(int)fileReadArray [blockAddressList [counter3]+counter4+5], entryBiteCount++;
                }
            }
        }
        else if (samplePerPix == 4){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+8){
                    arrayExtractedImage [entryBiteCount] = fileReadArray [blockAddressList [counter3]+counter4]*256+(int)fileReadArray [blockAddressList [counter3]+counter4+1], entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = fileReadArray [blockAddressList [counter3]+counter4+2]*256+(int)fileReadArray [blockAddressList [counter3]+counter4+3], entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = fileReadArray [blockAddressList [counter3]+counter4+4]*256+(int)fileReadArray [blockAddressList [counter3]+counter4+5], entryBiteCount++;
                }
            }
        }
    }
    else if (imageBit == 16 && photoMetric == 2 && (samplePerPix == 3 || samplePerPix == 4) && processType == 1){ //----- 16 bit color to 8 bit color-----
        if (samplePerPix == 3){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+6){
                    arrayExtractedImage [entryBiteCount] = (int)((fileReadArray [blockAddressList [counter3]+counter4]*256+(int)fileReadArray [blockAddressList [counter3]+counter4+1])/(double)256), entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = (int)((fileReadArray [blockAddressList [counter3]+counter4+2]*256+(int)fileReadArray [blockAddressList [counter3]+counter4+3])/(double)256), entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = (int)((fileReadArray [blockAddressList [counter3]+counter4+4]*256+(int)fileReadArray [blockAddressList [counter3]+counter4+5])/(double)256), entryBiteCount++;
                }
            }
        }
        else if (samplePerPix == 4){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+8){
                    arrayExtractedImage [entryBiteCount] = (int)((fileReadArray [blockAddressList [counter3]+counter4]*256+(int)fileReadArray [blockAddressList [counter3]+counter4+1])/(double)256), entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = (int)((fileReadArray [blockAddressList [counter3]+counter4+2]*256+(int)fileReadArray [blockAddressList [counter3]+counter4+3])/(double)256), entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = (int)((fileReadArray [blockAddressList [counter3]+counter4+4]*256+(int)fileReadArray [blockAddressList [counter3]+counter4+5])/(double)256), entryBiteCount++;
                }
            }
        }
    }
    
    delete [] blockAddressList;
    delete [] blockByteList;
    
    return arrayExtractedImage;
}

-(int*)imageSetLittleEndian:(int)imageDimension :(int)imageBit :(int)photoMetric :(int)samplePerPix :(unsigned long)stripEntry :(unsigned long)stripFirstAddress :(unsigned long) stripByteCountAddress :(int)processType{
    int *arrayExtractedImage = new int [imageDimension*imageDimension*3+1];
    
    unsigned long *blockAddressList = new unsigned long [stripEntry+10];
    unsigned long blockAddressListCount = 0;
    unsigned long *blockByteList = new unsigned long [stripEntry+10];
    unsigned long blockByteListCount = 0;
    
    int dataConversion2 [6];
    
    if (stripEntry == 1){
        blockAddressList [blockAddressListCount] = stripFirstAddress, blockAddressListCount++;
        blockByteList [blockByteListCount] = stripByteCountAddress, blockByteListCount++;
    }
    else{
        
        for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
            dataConversion2 [0] = fileReadArray [stripFirstAddress+counter3*4];
            dataConversion2 [1] = fileReadArray [stripFirstAddress+counter3*4+1];
            dataConversion2 [2] = fileReadArray [stripFirstAddress+counter3*4+2];
            dataConversion2 [3] = fileReadArray [stripFirstAddress+counter3*4+3];
            blockAddressList [blockAddressListCount] = (unsigned long)dataConversion2 [3]*16777216+(unsigned long)dataConversion2 [2]*65536+(unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0], blockAddressListCount++;
            
            dataConversion2 [0] = fileReadArray [stripByteCountAddress+counter3*4];
            dataConversion2 [1] = fileReadArray [stripByteCountAddress+counter3*4+1];
            dataConversion2 [2] = fileReadArray [stripByteCountAddress+counter3*4+2];
            dataConversion2 [3] = fileReadArray [stripByteCountAddress+counter3*4+3];
            blockByteList [blockByteListCount] = (unsigned long)dataConversion2 [3]*16777216+(unsigned long)dataConversion2 [2]*65536+(unsigned long)dataConversion2 [1]*256+(unsigned long)dataConversion2 [0], blockByteListCount++;
        }
    }
    
    //processType = 0; 8 bit gray (8 bit gray)
    //processType = 1; 8 bit color (8 bit color or gray)
    //processType = 2; 16 bit gray (16 or 8 bit gray)
    //processType = 3; 16 bit color (16 or 8 bit gray or color)
    
    //cout<<imageBit <<" "<<photoMetric<<" "<<samplePerPix<<" "<<processType <<" info"<<endl;
    
    unsigned long entryBiteCount = 0;
    
    if (imageBit == 8 && photoMetric <= 1 && (processType == 0 || processType == 1 || processType == 2 || processType == 3)){ //-----8 bit gray--
        for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
            for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4++){
                if (photoMetric == 0) arrayExtractedImage [entryBiteCount] = 255-(int)fileReadArray [blockAddressList [counter3]+counter4];
                else arrayExtractedImage [entryBiteCount] = (int)fileReadArray [blockAddressList [counter3]+counter4];
                entryBiteCount++;
            }
        }
    }
    else if (imageBit == 8 && photoMetric == 2 && (samplePerPix == 3 || samplePerPix == 4) && (processType == 0 || processType == 2)){ //------8 bit color to 8 bit gray------
        if (samplePerPix == 3){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+3){
                    arrayExtractedImage [entryBiteCount] = (int)((fileReadArray [blockAddressList [counter3]+counter4]+fileReadArray [blockAddressList [counter3]+counter4+1]+fileReadArray [blockAddressList [counter3]+counter4+2])/(double)3);
                    entryBiteCount++;
                }
            }
        }
        else if (samplePerPix == 4){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+4){
                    arrayExtractedImage [entryBiteCount] = (int)((fileReadArray [blockAddressList [counter3]+counter4]+fileReadArray [blockAddressList [counter3]+counter4+1]+fileReadArray [blockAddressList [counter3]+counter4+2])/(double)3);
                    entryBiteCount++;
                }
            }
        }
    }
    else if (imageBit == 8 && photoMetric == 2 && (samplePerPix == 3 || samplePerPix == 4) && (processType == 1 || processType == 3)){ //----- 8 bit color-----
        if (samplePerPix == 3){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+3){
                    arrayExtractedImage [entryBiteCount] = (int)fileReadArray [blockAddressList [counter3]+counter4], entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = (int)fileReadArray [blockAddressList [counter3]+counter4+1], entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = (int)fileReadArray [blockAddressList [counter3]+counter4+2], entryBiteCount++;
                }
            }
        }
        else if (samplePerPix == 4){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+4){
                    arrayExtractedImage [entryBiteCount] = (int)fileReadArray [blockAddressList [counter3]+counter4], entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = (int)fileReadArray [blockAddressList [counter3]+counter4+1], entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = (int)fileReadArray [blockAddressList [counter3]+counter4+2], entryBiteCount++;
                }
            }
        }
    }
    else if (imageBit == 16 && photoMetric <= 1 && (processType == 0 || processType == 1)){ //----- 16 bit to 8 bit gray-----
        for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
            for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+2){
                if (photoMetric == 0) arrayExtractedImage [entryBiteCount] = (int)((65535-(fileReadArray [blockAddressList [counter3]+counter4+1]*256+fileReadArray [blockAddressList [counter3]+counter4]))/(double)256);
                else arrayExtractedImage [entryBiteCount] = (int)((fileReadArray [blockAddressList [counter3]+counter4+1]*256+fileReadArray [blockAddressList [counter3]+counter4])/(double)256);
                entryBiteCount++;
            }
        }
    }
    else if (imageBit == 16 && photoMetric <= 1 && (processType == 2 || processType == 3)){ //----- 16 bit gray-----
        for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
            for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+2){
                if (photoMetric == 0) arrayExtractedImage [entryBiteCount] = 65535-(fileReadArray [blockAddressList [counter3]+counter4+1]*256+fileReadArray [blockAddressList [counter3]+counter4]);
                else arrayExtractedImage [entryBiteCount] = fileReadArray [blockAddressList [counter3]+counter4+1]*256+fileReadArray [blockAddressList [counter3]+counter4];
                entryBiteCount++;
            }
        }
    }
    else if (imageBit == 16 && photoMetric == 2 && (samplePerPix == 3 || samplePerPix == 4) && processType == 0){ //----- 16 bit color to 8 bit gray-----
        if (samplePerPix == 3){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+6){
                    arrayExtractedImage [entryBiteCount] = (int)(((fileReadArray [blockAddressList [counter3]+counter4+1]*256+fileReadArray [blockAddressList [counter3]+counter4]+fileReadArray [blockAddressList [counter3]+counter4+3]*256+fileReadArray [blockAddressList [counter3]+counter4+2]+fileReadArray [blockAddressList [counter3]+counter4+5]*256+fileReadArray [blockAddressList [counter3]+counter4+4])/(double)3)/(double)256);
                    entryBiteCount++;
                }
            }
        }
        else if (samplePerPix == 4){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+8){
                    arrayExtractedImage [entryBiteCount] = (int)(((fileReadArray [blockAddressList [counter3]+counter4+1]*256+fileReadArray [blockAddressList [counter3]+counter4]+fileReadArray [blockAddressList [counter3]+counter4+3]*256+fileReadArray [blockAddressList [counter3]+counter4+2]+fileReadArray [blockAddressList [counter3]+counter4+5]*256+fileReadArray [blockAddressList [counter3]+counter4+4])/(double)3)/(double)256);
                    entryBiteCount++;
                }
            }
        }
    }
    else if (imageBit == 16 && photoMetric == 2 && (samplePerPix == 3 || samplePerPix == 4) && processType == 2){ //----- 16 bit color to 16 bit gray-----
        if (samplePerPix == 3){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+6){
                    arrayExtractedImage [entryBiteCount] = (int)((fileReadArray [blockAddressList [counter3]+counter4+1]*256+fileReadArray [blockAddressList [counter3]+counter4]+fileReadArray [blockAddressList [counter3]+counter4+3]*256+fileReadArray [blockAddressList [counter3]+counter4+2]+fileReadArray [blockAddressList [counter3]+counter4+5]*256+fileReadArray [blockAddressList [counter3]+counter4+4])/(double)3);
                    entryBiteCount++;
                }
            }
        }
        else if (samplePerPix == 4){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+8){
                    arrayExtractedImage [entryBiteCount] = (int)((fileReadArray [blockAddressList [counter3]+counter4+1]*256+fileReadArray [blockAddressList [counter3]+counter4]+fileReadArray [blockAddressList [counter3]+counter4+3]*256+fileReadArray [blockAddressList [counter3]+counter4+2]+fileReadArray [blockAddressList [counter3]+counter4+5]*256+fileReadArray [blockAddressList [counter3]+counter4+4])/(double)3);
                    entryBiteCount++;
                }
            }
        }
    }
    else if (imageBit == 16 && photoMetric == 2 && (samplePerPix == 3 || samplePerPix == 4) && processType == 3){ //----- 16 bit color to 16 bit color-----
        if (samplePerPix == 3){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+6){
                    arrayExtractedImage [entryBiteCount] = fileReadArray [blockAddressList [counter3]+counter4+1]*256+(int)fileReadArray [blockAddressList [counter3]+counter4], entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = fileReadArray [blockAddressList [counter3]+counter4+3]*256+(int)fileReadArray [blockAddressList [counter3]+counter4+2], entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = fileReadArray [blockAddressList [counter3]+counter4+5]*256+(int)fileReadArray [blockAddressList [counter3]+counter4+4], entryBiteCount++;
                }
            }
        }
        else if (samplePerPix == 4){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+8){
                    arrayExtractedImage [entryBiteCount] = fileReadArray [blockAddressList [counter3]+counter4+1]*256+(int)fileReadArray [blockAddressList [counter3]+counter4], entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = fileReadArray [blockAddressList [counter3]+counter4+3]*256+(int)fileReadArray [blockAddressList [counter3]+counter4+2], entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = fileReadArray [blockAddressList [counter3]+counter4+5]*256+(int)fileReadArray [blockAddressList [counter3]+counter4+4], entryBiteCount++;
                }
            }
        }
    }
    else if (imageBit == 16 && photoMetric == 2 && (samplePerPix == 3 || samplePerPix == 4) && processType == 1){ //----- 16 bit color to 8 bit color-----
        if (samplePerPix == 3){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+6){
                    arrayExtractedImage [entryBiteCount] = (int)((fileReadArray [blockAddressList [counter3]+counter4+1]*256+(int)fileReadArray [blockAddressList [counter3]+counter4])/(double)256), entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = (int)((fileReadArray [blockAddressList [counter3]+counter4+3]*256+(int)fileReadArray [blockAddressList [counter3]+counter4+2])/(double)256), entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = (int)((fileReadArray [blockAddressList [counter3]+counter4+5]*256+(int)fileReadArray [blockAddressList [counter3]+counter4+4])/(double)256), entryBiteCount++;
                }
            }
        }
        else if (samplePerPix == 4){
            for (unsigned long counter3 = 0; counter3 < stripEntry; counter3++){
                for (unsigned long counter4 = 0; counter4 < blockByteList [counter3]; counter4 = counter4+8){
                    arrayExtractedImage [entryBiteCount] = (int)((fileReadArray [blockAddressList [counter3]+counter4+1]*256+(int)fileReadArray [blockAddressList [counter3]+counter4])/(double)256), entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = (int)((fileReadArray [blockAddressList [counter3]+counter4+3]*256+(int)fileReadArray [blockAddressList [counter3]+counter4+2])/(double)256), entryBiteCount++;
                    arrayExtractedImage [entryBiteCount] = (int)((fileReadArray [blockAddressList [counter3]+counter4+5]*256+(int)fileReadArray [blockAddressList [counter3]+counter4+4])/(double)256), entryBiteCount++;
                }
            }
        }
    }
    
    delete [] blockAddressList;
    delete [] blockByteList;
    
    return arrayExtractedImage;
}

@end
