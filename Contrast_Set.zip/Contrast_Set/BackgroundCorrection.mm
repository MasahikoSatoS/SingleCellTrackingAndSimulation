//
//  BackgroundCorrection.mm
//  Contrast_Set
//
//  Created by Masahiko Sato on 15/05/12.
//  Copyright 2011 Masahiko Sato All rights reserved.
//

#import "BackgroundCorrection.h"

@implementation BackgroundCorrection

-(void)backgroundImageSub:(int)bcType :(int)fovNoSet :(int)imageDimensionBackgroundX :(int)imageDimensionBackgroundY{
    double maskMatrix [5][5] = {{0.0035, 0.0145, 0.0256, 0.0145, 0.0035}, {0.0145, 0.0586, 0.0952, 0.0556, 0.0145}, {0.0256, 0.0952, 0.1501, 0.0952, 0.0256}, {0.0145, 0.0586, 0.0952, 0.0586, 0.0145}, {0.0035, 0.0145, 0.0256, 0.0145, 0.0035}};
    
    int **backgroundImage1 = new int *[imageDimensionBackgroundY+1];
    int **gaussianImage = new int *[imageDimensionBackgroundY+1];
    int **sdMap = new int *[imageDimensionBackgroundY+1];
    int **backgroundImage2 = new int *[imageDimensionBackgroundY+1];
    int **backgroundImage3 = new int *[imageDimensionBackgroundY+1];
    int **backgroundImage4 = new int *[imageDimensionBackgroundY+1];
    
    for (int counter1 = 0; counter1 < imageDimensionBackgroundY+1; counter1++){
        backgroundImage1 [counter1] = new int [imageDimensionBackgroundX+1];
        gaussianImage [counter1] = new int [imageDimensionBackgroundX+1];
        sdMap [counter1] = new int [imageDimensionBackgroundX+1];
        backgroundImage2 [counter1] = new int [imageDimensionBackgroundX+1];
        backgroundImage3 [counter1] = new int [imageDimensionBackgroundX+1];
        backgroundImage4 [counter1] = new int [imageDimensionBackgroundX+1];
    }
    
    int xBlockNo = 1;
    int yBlockNo = 1;
    
    if (imageDimensionBackgroundX > 0) xBlockNo = imageDimensionBackgroundX/8;
    if (imageDimensionBackgroundY > 0) yBlockNo = imageDimensionBackgroundY/8;
    
    int **linkMap = new int *[yBlockNo+1];
    int **imageMatrix = new int *[yBlockNo+1];
    int **imageMatrix2 = new int *[yBlockNo+1];
    int **middleIntensity = new int *[yBlockNo+1];
    
    for (int counter1 = 0; counter1 < yBlockNo+1; counter1++){
        linkMap [counter1] = new int [xBlockNo+1];
        imageMatrix  [counter1] = new int [xBlockNo+1];
        imageMatrix2  [counter1] = new int [xBlockNo+1];
        middleIntensity  [counter1] = new int [xBlockNo+1];
    }
    
    int *imageValueInBlock = new int [xBlockNo+1];
    
    int *connectAnalysisX2 = new int [imageDimensionBackgroundX*4];
    int *connectAnalysisY2 = new int [imageDimensionBackgroundY*4];
    int *connectAnalysisTempX2 = new int [imageDimensionBackgroundX*4];
    int *connectAnalysisTempY2 = new int [imageDimensionBackgroundY*4];
    
    int *bkNumberHold = new int [treatmentNameDisplayCount*2+50];
    
    int fovNoForProcess = 0;
    
    string treatmentNameBack;
    string backgroundRemoveLevel = "";
    
    if (bcType == 2){
        string bkNumberExtract;
        string timeDetermine;
        string treatNameTemp2;
        string fovName2;
        string contrastDataTemp;
        
        int timeDataUse = 1;
        
        for (int counter2 = 1; counter2 <= entryNumber; counter2++){
            timeDetermine = arrayContrastData [0][counter2+2];
            timeDetermine = timeDetermine.substr(1);
            
            if (autoType == 1 || autoType == 3){
                if (atoi(timeDetermine.c_str()) < currentTimePoint+1) timeDataUse = counter2;
            }
            if (autoType == 2){
                if (atoi(timeDetermine.c_str()) < loadImageNo+1) timeDataUse = counter2;
            }
            else if (atoi(timeDetermine.c_str()) < reprocessImageNo+1) timeDataUse = counter2;
        }
        
        int treatFind = 0;
        int bkNumberHoldCount = 0;
        
        for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++){
            treatNameTemp2 = arrayTreatmentNameDisplay [counter2];
            fovName2 = arrayFOVNameDisplay [counter2];
            
            if (treatNameTemp2 == treatmentNameAuto && fovName2 != "ND" && treatFind == 0){
                treatFind = 1;
                
                contrastDataTemp = arrayContrastData [counter2][timeDataUse+2];
                bkNumberExtract = contrastDataTemp.substr(contrastDataTemp.find(":")+1, contrastDataTemp.find("~")-contrastDataTemp.find(":")-1);
                bkNumberHold [bkNumberHoldCount] = atoi(bkNumberExtract.c_str()), bkNumberHoldCount++;
                
                backgroundRemoveLevel = contrastDataTemp.substr(contrastDataTemp.find(" ")+1, 1);
            }
            else if (treatNameTemp2 == "ND" && fovName2 != "ND" && treatFind == 1){
                contrastDataTemp = arrayContrastData [counter2][timeDataUse+2];
                bkNumberExtract = contrastDataTemp.substr(contrastDataTemp.find(":")+1, contrastDataTemp.find("~")-contrastDataTemp.find(":")-1);
                bkNumberHold [bkNumberHoldCount] = atoi(bkNumberExtract.c_str()), bkNumberHoldCount++;
            }
            else if (((treatNameTemp2 != "ND" && fovName2 != "ND") || (treatNameTemp2 == "ND" && fovName2 == "ND")) && treatFind == 1){
                treatFind = 2;
            }
        }
        
        fovNoForProcess = fovNoSet;
        treatmentNameBack = treatmentNameAuto;
    }
    
    if (bcType == 1 || bcType == 3){
        string bkNumberExtract;
        string timeDetermine;
        string treatNameTemp2;
        string fovName2;
        string contrastDataTemp;
        
        int treatFind = 0;
        int bkNumberHoldCount = 0;
        
        for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++){
            treatNameTemp2 = arrayTreatmentNameDisplay [counter2];
            fovName2 = arrayFOVNameDisplay [counter2];
            
            if (treatNameTemp2 == loadImageTreatName && fovName2 != "ND" && treatFind == 0){
                treatFind = 1;
                
                contrastDataTemp = arrayTableDisplay [counter2*5+2];
                bkNumberExtract = contrastDataTemp.substr(contrastDataTemp.find(":")+1, contrastDataTemp.find("~")-contrastDataTemp.find(":")-1);
                bkNumberHold [bkNumberHoldCount] = atoi(bkNumberExtract.c_str()), bkNumberHoldCount++;
                
                backgroundRemoveLevel = contrastDataTemp.substr(contrastDataTemp.find(" ")+1, 1);
            }
            else if (treatNameTemp2 == "ND" && fovName2 != "ND" && treatFind == 1){
                contrastDataTemp = arrayTableDisplay [counter2*5+2];
                bkNumberExtract = contrastDataTemp.substr(contrastDataTemp.find(":")+1, contrastDataTemp.find("~")-contrastDataTemp.find(":")-1);
                bkNumberHold [bkNumberHoldCount] = atoi(bkNumberExtract.c_str()), bkNumberHoldCount++;
            }
            else if (((treatNameTemp2 != "ND" && fovName2 != "ND") || (treatNameTemp2 == "ND" && fovName2 == "ND")) && treatFind == 1){
                treatFind = 2;
            }
        }
        
        fovNoForProcess = loadImageFOVNo;
        treatmentNameBack = loadImageTreatName;
    }
    
    int backgroundSetFind = 0;
    
    for (int counter1 = 0; counter1 < fovNoForProcess; counter1++){
        if (bkNumberHold [counter1] != 0) backgroundSetFind = 1;
    }
    
    /*
     R:0 No BK selection
     R:No Subtract selected BK
     A-G:0 BK Auto selection, then process BK
     A-G:No Subtract selected BK. then process BK
     
     R:No and A:No, yield same results
     
     If Rang is set, adjust Range before BK processing
     */
    
    int stepSelect2 = 0; //2:B. Find connect group with +- 10 value and total pix no > 25
    int stepSelect3 = 0; //3:C. Remove pixel < 50 and value 51-199
    int stepSelect4 = 0; //4:D. Remove pixel two side- or three-side surrounded by 100
    int stepSelect5 = 0; //5:E. Remove pixel group surrounded by 100 using bluer data
    int stepSelect6 = 0; //6:F. Remove pixel < 50 and surrounded by 100
    int stepSelect7 = 0; //7:G. Remove pixel group surrounded by 100 or A:B are surrounded by 100 or horizontal A:A:A and vertical B:B:B: Required time
    
    if (backgroundRemoveLevel == "A" || backgroundRemoveLevel == "R"){
        stepSelect2 = 1;
        stepSelect3 = 1;
        stepSelect4 = 1;
        stepSelect5 = 1;
        stepSelect6 = 1;
        stepSelect7 = 1;
    }
    else if (backgroundRemoveLevel == "B"){
        stepSelect2 = 0;
        stepSelect3 = 1;
        stepSelect4 = 1;
        stepSelect5 = 1;
        stepSelect6 = 1;
        stepSelect7 = 1;
    }
    else if (backgroundRemoveLevel == "C"){
        stepSelect2 = 0;
        stepSelect3 = 0;
        stepSelect4 = 1;
        stepSelect5 = 1;
        stepSelect6 = 1;
        stepSelect7 = 1;
    }
    else if (backgroundRemoveLevel == "D"){
        stepSelect2 = 0;
        stepSelect3 = 0;
        stepSelect4 = 0;
        stepSelect5 = 1;
        stepSelect6 = 1;
        stepSelect7 = 1;
    }
    else if (backgroundRemoveLevel == "E"){
        stepSelect2 = 0;
        stepSelect3 = 0;
        stepSelect4 = 0;
        stepSelect5 = 0;
        stepSelect6 = 1;
        stepSelect7 = 1;
    }
    else if (backgroundRemoveLevel == "F"){
        stepSelect2 = 0;
        stepSelect3 = 0;
        stepSelect4 = 0;
        stepSelect5 = 0;
        stepSelect6 = 0;
        stepSelect7 = 1;
    }
    else if (backgroundRemoveLevel == "G"){
        stepSelect2 = 0;
        stepSelect3 = 0;
        stepSelect4 = 0;
        stepSelect5 = 0;
        stepSelect6 = 0;
        stepSelect7 = 0;
    }
    
    //-----Main process-----
    int bkNumber = -1;
    int flattenPixCount = 0;
    int totalForAverage = 0;
    int middleCount = 0;
    int middleData = 0;
    int maxFit = -1;
    int difference = 0;
    int connectivityNumber = 0;
    int valueHoldTemp = 0;
    int connectAnalysisCount = 0;
    int connectAnalysisTempCount = 0;
    int terminationFlag = 0;
    int xSource = 0;
    int ySource = 0;
    int connectValue = 0;
    int totalCount = 0;
    int xStart = 0;
    int xEnd = 0;
    int yStart = 0;
    int yEnd = 0;
    int findFlag = 0;
    int connectivityValueTemp = 0;
    int pixValueTemp = 0;
    int findFlag2 = 0;
    int findFlag3 = 0;
    int findFlag4 = 0;
    int findFlag5 = 0;
    int findFlag6 = 0;
    int findFlag7 = 0;
    int processFlag = 0;
    int horizontal1 = 0;
    int horizontal2 = 0;
    int vertical1 = 0;
    int vertical2 = 0;
    
    double bitGaussian = 0;
    double averagePix = 0;
    double totalForStandardDev = 0;
    double standardDevPix = 0;
    double maxFitCount = 0;
    
    for (int counter1 = 0; counter1 < fovNoForProcess; counter1++){
        bkNumber = -1;
        
        if (bkNumberHold [counter1] != 0) bkNumber = bkNumberHold [counter1]-1;
        
        if ((backgroundRemoveLevel != "R" && backgroundPatternModifyArrayCount > 0) || (backgroundRemoveLevel == "R" && backgroundSetFind == 1 && bkNumber != -1)){
            if (bcType == 1){
                for (int counter2 = 0; counter2 < imageDimensionBackgroundY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionBackgroundX; counter3++){
                        gaussianImage [counter2][counter3] = 0;
                        backgroundImage1 [counter2][counter3] = arrayBackgroundDataHold [counter1*imageDimensionBackgroundY+counter2][counter3];
                    }
                }
            }
            else if (bcType == 2){
                for (int counter2 = 0; counter2 < imageDimensionBackgroundY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionBackgroundX; counter3++){
                        gaussianImage [counter2][counter3] = 0;
                        backgroundImage1 [counter2][counter3] = arrayBackgroundCorrectionData [counter1*autoImageSizeY+counter2][counter3];
                    }
                }
            }
            else{
                
                for (int counter2 = 0; counter2 < imageDimensionBackgroundY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionBackgroundX; counter3++){
                        gaussianImage [counter2][counter3] = 0;
                        backgroundImage1 [counter2][counter3] = arrayBalanceBaseData [counter1*imageDimensionBackgroundY+counter2][counter3];
                    }
                }
            }
            
            //-----Apply Gaussian blur-----
            for (int counter2 = 0; counter2 < imageDimensionBackgroundY; counter2++){
                for (int counter3 = 0; counter3 < imageDimensionBackgroundX; counter3++){
                    bitGaussian = 0;
                    
                    for (int counter4 = -2; counter4 <= 2; counter4++){
                        for (int counter5 = -2; counter5 <= 2; counter5++){
                            if (counter2+counter4 >= imageDimensionBackgroundY || counter2+counter4 < 0 || counter3+counter5 >= imageDimensionBackgroundX || counter3+counter5 < 0){
                                bitGaussian = bitGaussian+backgroundImage1 [counter2][counter3]*maskMatrix [counter4+2][counter5+2];
                            }
                            else bitGaussian = bitGaussian+backgroundImage1 [counter2+counter4][counter3+counter5]*maskMatrix [counter4+2][counter5+2];
                        }
                    }
                    
                    gaussianImage [counter2][counter3] = (int)bitGaussian;
                }
            }
            
            if (blurStatusHold == 0){
                for (int counter2 = 0; counter2 < imageDimensionBackgroundY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionBackgroundX; counter3++){
                        backgroundImage1 [counter2][counter3] = gaussianImage [counter2][counter3];
                    }
                }
            }
            
            //for (int counterA = 0; counterA < 100; counterA++){
            //    for (int counterB = 0; counterB < 512; counterB++) cout<<" "<<gaussianImage [counterA][counterB];
            //    cout<<" gaussianImage"<<counterA<<endl;
            //}
            
            //-----Determine Mean and Standard Deviation (SD); based on SD value, identify areas with object (+value) and without object (-value); -500 represents areas below 50 or above 150-----
            //-----middleIntensity should hold values between 75 and 175-----
            
            //-----Image matrix set: Determine SD -----
            for (int counter2 = 0; counter2 < yBlockNo; counter2++){
                for (int counter3 = 0; counter3 < xBlockNo; counter3++){
                    flattenPixCount = 0;
                    totalForAverage = 0;
                    totalForStandardDev = 0;
                    middleCount = 0;
                    middleData = 0;
                    
                    //-----For Sd calculation-----
                    for (int counter4 = counter2*8; counter4 < counter2*8+8; counter4++){
                        for (int counter5 = counter3*8; counter5 < counter3*8+8; counter5++){
                            imageValueInBlock [flattenPixCount] = gaussianImage [counter4][counter5];
                            totalForAverage = totalForAverage+gaussianImage [counter4][counter5], flattenPixCount++;
                        }
                    }
                    
                    //-----For middle intensity-----
                    for (int counter4 = counter2*8; counter4 < counter2*8+8; counter4++){
                        for (int counter5 = counter3*8; counter5 < counter3*8+8; counter5++){
                            if (gaussianImage [counter4][counter5] > 75 && gaussianImage [counter4][counter5] < 175){
                                middleData = middleData+gaussianImage [counter4][counter5], middleCount++;
                            }
                        }
                    }
                    
                    if (middleCount != 0) middleIntensity [counter2][counter3] = (int)(middleData/(double)middleCount);
                    else middleIntensity [counter2][counter3] = 0;
                    
                    //-----SD calculation-----
                    averagePix = totalForAverage/(double)64;
                    
                    for (int counter4 = counter2*8; counter4 < counter2*8+8; counter4++){
                        for (int counter5 = counter3*8; counter5 < counter3*8+8; counter5++){
                            totalForStandardDev = totalForStandardDev+(gaussianImage [counter4][counter5]-averagePix)*(gaussianImage [counter4][counter5]-averagePix);
                        }
                    }
                    
                    imageMatrix2 [counter2][counter3] = (int)averagePix;
                }
            }
            
            //========Select best match background==========
            if (bkNumber == -1){
                int **backCheckTemp = new int *[yBlockNo+1];
                
                for (int counter2 = 0; counter2 < yBlockNo+1; counter2++) backCheckTemp [counter2] = new int [xBlockNo+1];
                
                double *sdList = new double [backgroundPatternModifyArrayCount/(xBlockNo*yBlockNo)+1];
                
                for (int counter2 = 0; counter2 < backgroundPatternModifyArrayCount/(xBlockNo*yBlockNo); counter2++) sdList [counter2] = 0;
                
                for (int counter2 = 0; counter2 < backgroundPatternModifyArrayCount/(xBlockNo*yBlockNo); counter2++){
                    for (int counter3 = 0; counter3 < yBlockNo; counter3++){
                        for (int counter4 = 0; counter4 < xBlockNo; counter4++) backCheckTemp [counter3][counter4] = backgroundPatternModifyArray [counter2*(xBlockNo*yBlockNo)+counter3*yBlockNo+counter4];
                    }
                    
                    //-----For Sd calculation-----
                    totalForAverage = 0;
                    
                    for (int counter3 = 0; counter3 < yBlockNo; counter3++){
                        for (int counter4 = 0; counter4 < xBlockNo; counter4++){
                            totalForAverage = totalForAverage+abs(backCheckTemp [counter3][counter4]-imageMatrix2 [counter3][counter4]);
                            flattenPixCount++;
                        }
                    }
                    
                    averagePix = totalForAverage/(double)(xBlockNo*yBlockNo);
                    
                    //-----SD calculation-----
                    totalForStandardDev = 0;
                    
                    for (int counter3 = 0; counter3 < yBlockNo; counter3++){
                        for (int counter4 = 0; counter4 < xBlockNo; counter4++){
                            totalForStandardDev = totalForStandardDev+(abs(backCheckTemp [counter3][counter4]-imageMatrix2 [counter3][counter4])-averagePix)*(abs(backCheckTemp [counter3][counter4]-imageMatrix2 [counter3][counter4])-averagePix);
                        }
                    }
                    
                    standardDevPix = sqrt(totalForStandardDev/(double)(xBlockNo*yBlockNo));
                    
                    sdList [counter2] = standardDevPix;
                }
                
                maxFit = -1;
                maxFitCount = 10000000;
                
                for (int counter2 = 0; counter2 < backgroundPatternArrayCount/(xBlockNo*yBlockNo); counter2++){
                    if (sdList [counter2] < maxFitCount){
                        maxFitCount = sdList [counter2];
                        maxFit = counter2;
                    }
                }
                
                for (int counter2 = 0; counter2 < yBlockNo; counter2++){
                    for (int counter3 = 0; counter3 < xBlockNo; counter3++) imageMatrix [counter2][counter3] = backgroundPatternModifyArray [maxFit*(xBlockNo*yBlockNo)+counter2*yBlockNo+counter3];
                }
                
                for (int counter2 = 0; counter2 < yBlockNo+1; counter2++){
                    delete [] backCheckTemp [counter2];
                }
                
                delete [] backCheckTemp;
                
                delete [] sdList;
            }
            else{
                
                for (int counter2 = 0; counter2 < yBlockNo; counter2++){
                    for (int counter3 = 0; counter3 < xBlockNo; counter3++) imageMatrix [counter2][counter3] = backgroundPatternModifyArray [bkNumber*(xBlockNo*yBlockNo)+counter2*yBlockNo+counter3];
                }
            }
            
            //cout<<counter1<<" "<<bkNumber<<" bkNumber"<<endl;
            
            //-----Background pattern set-----
            for (int counter2 = 0; counter2 < yBlockNo; counter2++){
                for (int counter3 = 0; counter3 < xBlockNo; counter3++){
                    for (int counter4 = 0; counter4 < 8; counter4++){
                        for (int counter5 = 0; counter5 < 8; counter5++) gaussianImage [counter2*8+counter4][counter3*8+counter5] = imageMatrix [counter2][counter3];
                    }
                }
            }
            
            //-----Value adjust (first adjusted image)-----
            for (int counter2 = 0; counter2 < imageDimensionBackgroundY; counter2++){
                for (int counter3 = 0; counter3 < imageDimensionBackgroundX; counter3++){
                    difference = 100-gaussianImage [counter2][counter3];
                    
                    if (backgroundImage1 [counter2][counter3]+difference > 225){
                        backgroundImage3 [counter2][counter3] = 255;
                        backgroundImage2 [counter2][counter3] = -255;
                    }
                    else if (backgroundImage1 [counter2][counter3]+difference < 20){
                        backgroundImage3 [counter2][counter3] = 0;
                        backgroundImage2 [counter2][counter3] = 0;
                    }
                    else if (backgroundImage1 [counter2][counter3]+difference >= 95 && backgroundImage1 [counter2][counter3]+difference <= 100){
                        backgroundImage3 [counter2][counter3] = 94;
                        backgroundImage2 [counter2][counter3] = -94;
                    }
                    else if (backgroundImage1 [counter2][counter3]+difference >= 101 && backgroundImage1 [counter2][counter3]+difference <= 105){
                        backgroundImage3 [counter2][counter3] = 106;
                        backgroundImage2 [counter2][counter3] = -106;
                    }
                    else{
                        
                        backgroundImage3 [counter2][counter3] = backgroundImage1 [counter2][counter3]+difference;
                        backgroundImage2 [counter2][counter3] = (backgroundImage1 [counter2][counter3]+difference)*-1;
                    }
                }
            }
            
            //========1. Connect analysis, based on each pix value: remove pix group > 50 and pix value 51-199=========
            connectivityNumber = 0;
            
            for (int counterY = 0; counterY < imageDimensionBackgroundY; counterY++){
                for (int counterX = 0; counterX < imageDimensionBackgroundX; counterX++){
                    if (backgroundImage2 [counterY][counterX] < 0){
                        valueHoldTemp = backgroundImage2 [counterY][counterX];
                        connectivityNumber++;
                        
                        backgroundImage2 [counterY][counterX] = connectivityNumber;
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && counterX-1 >= 0 && backgroundImage2 [counterY-1][counterX-1] == valueHoldTemp){
                            backgroundImage2 [counterY-1][counterX-1] = connectivityNumber;
                            connectAnalysisX2 [connectAnalysisCount] = counterX-1, connectAnalysisY2 [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && backgroundImage2 [counterY-1][counterX] == valueHoldTemp){
                            backgroundImage2 [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX2 [connectAnalysisCount] = counterX, connectAnalysisY2 [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && counterX+1 < imageDimensionBackgroundX && backgroundImage2 [counterY-1][counterX+1] == valueHoldTemp){
                            backgroundImage2 [counterY-1][counterX+1] = connectivityNumber;
                            connectAnalysisX2 [connectAnalysisCount] = counterX+1, connectAnalysisY2 [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < imageDimensionBackgroundX && backgroundImage2 [counterY][counterX+1] == valueHoldTemp){
                            backgroundImage2 [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX2 [connectAnalysisCount] = counterX+1, connectAnalysisY2 [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < imageDimensionBackgroundY && counterX+1 < imageDimensionBackgroundX && backgroundImage2 [counterY+1][counterX+1] == valueHoldTemp){
                            backgroundImage2 [counterY+1][counterX+1] = connectivityNumber;
                            connectAnalysisX2 [connectAnalysisCount] = counterX+1, connectAnalysisY2 [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < imageDimensionBackgroundY && backgroundImage2 [counterY+1][counterX] == valueHoldTemp){
                            backgroundImage2 [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX2 [connectAnalysisCount] = counterX, connectAnalysisY2 [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < imageDimensionBackgroundY && counterX-1 >= 0 && backgroundImage2 [counterY+1][counterX-1] == valueHoldTemp){
                            backgroundImage2 [counterY+1][counterX-1] = connectivityNumber;
                            connectAnalysisX2 [connectAnalysisCount] = counterX-1, connectAnalysisY2 [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && backgroundImage2 [counterY][counterX-1] == valueHoldTemp){
                            backgroundImage2 [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX2 [connectAnalysisCount] = counterX-1, connectAnalysisY2 [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                    xSource = connectAnalysisX2 [counter2];
                                    ySource = connectAnalysisY2 [counter2];
                                    
                                    if (ySource-1 >= 0 && xSource-1 >= 0 && backgroundImage2 [ySource-1][xSource-1] == valueHoldTemp){
                                        backgroundImage2 [ySource-1][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX2 [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && backgroundImage2 [ySource-1][xSource] == valueHoldTemp){
                                        backgroundImage2 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX2 [connectAnalysisTempCount] = xSource, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && xSource+1 < imageDimensionBackgroundX && backgroundImage2 [ySource-1][xSource+1] == valueHoldTemp){
                                        backgroundImage2 [ySource-1][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX2 [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < imageDimensionBackgroundX && backgroundImage2 [ySource][xSource+1] == valueHoldTemp){
                                        backgroundImage2 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX2 [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 > imageDimensionBackgroundY && xSource+1 < imageDimensionBackgroundX && backgroundImage2 [ySource+1][xSource+1] == valueHoldTemp){
                                        backgroundImage2 [ySource+1][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX2 [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < imageDimensionBackgroundY && backgroundImage2 [ySource+1][xSource] == valueHoldTemp){
                                        backgroundImage2 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX2 [connectAnalysisTempCount] = xSource, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < imageDimensionBackgroundY && xSource-1 >= 0 && backgroundImage2 [ySource+1][xSource-1] == valueHoldTemp){
                                        backgroundImage2 [ySource+1][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX2 [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && backgroundImage2 [ySource][xSource-1] == valueHoldTemp){
                                        backgroundImage2 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX2 [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                    connectAnalysisX2 [counter2] = connectAnalysisTempX2 [counter2], connectAnalysisY2 [counter2] = connectAnalysisTempY2 [counter2];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //-----Determine number of pixels-----
            int *connectedPix2 = new int [connectivityNumber*7+7];
            
            for (int counter2 = 0; counter2 <= connectivityNumber; counter2++){
                connectedPix2 [counter2*7] = 0;
                connectedPix2 [counter2*7+1] = 0;
                connectedPix2 [counter2*7+2] = 0;
                connectedPix2 [counter2*7+3] = 1000;
                connectedPix2 [counter2*7+4] = 0;
                connectedPix2 [counter2*7+5] = 1000;
                connectedPix2 [counter2*7+6] = 0;
            }
            
            for (int counterY = 0; counterY < imageDimensionBackgroundY; counterY++){
                for (int counterX = 0; counterX < imageDimensionBackgroundX; counterX++){
                    if (backgroundImage2 [counterY][counterX] != 0){
                        connectedPix2 [backgroundImage2 [counterY][counterX]*7]++;
                        connectedPix2 [backgroundImage2 [counterY][counterX]*7+1] = backgroundImage3 [counterY][counterX];
                        
                        if (counterY < connectedPix2 [backgroundImage2 [counterY][counterX]*7+5]) connectedPix2 [backgroundImage2 [counterY][counterX]*7+5] = counterY;
                        if (counterY > connectedPix2 [backgroundImage2 [counterY][counterX]*7+6]) connectedPix2 [backgroundImage2 [counterY][counterX]*7+6] = counterY;
                        if (counterX < connectedPix2 [backgroundImage2 [counterY][counterX]*7+3]) connectedPix2 [backgroundImage2 [counterY][counterX]*7+3] = counterX;
                        if (counterY > connectedPix2 [backgroundImage2 [counterY][counterX]*7+4]) connectedPix2 [backgroundImage2 [counterY][counterX]*7+4] = counterX;
                    }
                }
            }
            
            for (int counter2 = 1; counter2 <= connectivityNumber; counter2++){
                if (connectedPix2 [counter2*7] > 300 && connectedPix2 [counter2*7+1] < 200 && connectedPix2 [counter2*7+1] > 70) connectedPix2 [counter2*7] = -1;
            }
            
            for (int counterY = 0; counterY < imageDimensionBackgroundY; counterY++){
                for (int counterX = 0; counterX < imageDimensionBackgroundX; counterX++){
                    if (connectedPix2 [backgroundImage2 [counterY][counterX]*7] == -1) backgroundImage3 [counterY][counterX] = 100;
                }
            }
            
            //===========2. Find connect group with +- 10 value and total pix no > 25================
            if (stepSelect2 == 0){
                int *connectedPix3 = new int [connectivityNumber*2+3];
                
                for (int counter2 = 1; counter2 <= connectivityNumber; counter2++){
                    if (connectedPix2 [counter2*7] <= 50 && connectedPix2 [counter2*7] > 15 && connectedPix2 [counter2*7] != -1 && connectedPix2 [counter2*7+1] < 200 && connectedPix2 [counter2*7+1] > 50 && connectedPix2 [counter2*7+1] != 100){
                        for (int counter3 = 1; counter3 <= connectivityNumber*2; counter3++) connectedPix3 [counter3] = 0;
                        
                        connectValue = connectedPix2 [counter2*7+1];
                        
                        xStart = connectedPix2 [counter2*7+3];
                        xEnd = connectedPix2 [counter2*7+4];
                        yStart = connectedPix2 [counter2*7+5];
                        yEnd = connectedPix2 [counter2*7+6];
                        
                        for (int counterY = yStart; counterY < yEnd; counterY++){
                            for (int counterX = xStart; counterX < xEnd; counterX++){
                                if (backgroundImage2 [counterY][counterX] == counter2){
                                    if (counterY-1 >= 0 && counterX-1 >= 0 && backgroundImage2 [counterY-1][counterX-1] != counter2 && backgroundImage3 [counterY-1][counterX-1] != 100){
                                        connectedPix3 [backgroundImage2 [counterY-1][counterX-1]*2]++;
                                        connectedPix3 [backgroundImage2 [counterY-1][counterX-1]*2+1] = backgroundImage3 [counterY-1][counterX-1];
                                    }
                                    if (counterY-1 >= 0 && backgroundImage2 [counterY-1][counterX] != counter2 && backgroundImage3 [counterY-1][counterX] != 100){
                                        connectedPix3 [backgroundImage2 [counterY-1][counterX]*2]++;
                                        connectedPix3 [backgroundImage2 [counterY-1][counterX]*2+1] = backgroundImage3 [counterY-1][counterX];
                                    }
                                    if (counterY-1 >= 0 && counterX+1 < imageDimensionBackgroundX && backgroundImage2 [counterY-1][counterX+1] != counter2 && backgroundImage3 [counterY-1][counterX+1] != 100){
                                        connectedPix3 [backgroundImage2 [counterY-1][counterX+1]*2]++;
                                        connectedPix3 [backgroundImage2 [counterY-1][counterX+1]*2+1] = backgroundImage3 [counterY-1][counterX+1];
                                    }
                                    if (counterX+1 < imageDimensionBackgroundX && backgroundImage2 [counterY][counterX+1] != counter2 && backgroundImage3 [counterY][counterX+1] != 100){
                                        connectedPix3 [backgroundImage2 [counterY][counterX+1]*2]++;
                                        connectedPix3 [backgroundImage2 [counterY][counterX+1]*2+1] = backgroundImage3 [counterY][counterX+1];
                                    }
                                    if (counterY+1 < imageDimensionBackgroundY && counterX+1 < imageDimensionBackgroundX && backgroundImage2 [counterY+1][counterX+1] != counter2 && backgroundImage3 [counterY+1][counterX+1] != 100){
                                        connectedPix3 [backgroundImage2 [counterY+1][counterX+1]*2]++;
                                        connectedPix3 [backgroundImage2 [counterY+1][counterX+1]*2+1] = backgroundImage3 [counterY+1][counterX+1];
                                    }
                                    if (counterY+1 < imageDimensionBackgroundY && backgroundImage2 [counterY+1][counterX] != counter2 && backgroundImage3 [counterY+1][counterX] != 100){
                                        connectedPix3 [backgroundImage2 [counterY+1][counterX]*2]++;
                                        connectedPix3 [backgroundImage2 [counterY+1][counterX]*2+1] = backgroundImage3 [counterY+1][counterX];
                                    }
                                    if (counterY+1 < imageDimensionBackgroundY && counterX-1 >= 0 && backgroundImage2 [counterY+1][counterX-1] != counter2 && backgroundImage3 [counterY+1][counterX-1] != 100){
                                        connectedPix3 [backgroundImage2 [counterY+1][counterX-1]*2]++;
                                        connectedPix3 [backgroundImage2 [counterY+1][counterX-1]*2+1] = backgroundImage3 [counterY+1][counterX-1];
                                    }
                                    if (counterX-1 >= 0 && backgroundImage2 [counterY][counterX-1] != counter2 && backgroundImage3 [counterY][counterX-1] != 100){
                                        connectedPix3 [backgroundImage2 [counterY][counterX-1]*2]++;
                                        connectedPix3 [backgroundImage2 [counterY][counterX-1]*2+1] = backgroundImage3 [counterY][counterX-1];
                                    }
                                }
                            }
                        }
                        
                        totalCount = connectedPix2 [counter2*7];
                        
                        for (int counter3 = 1; counter3 <= connectivityNumber; counter3++){
                            if (connectedPix3 [counter3*2] != 0 && connectedPix3 [counter3*2+1] > connectValue-10 && connectedPix3 [counter3*2+1] < connectValue+10){
                                totalCount = totalCount+connectedPix3 [counter3*2];
                            }
                        }
                        
                        if (totalCount > 25){ //========removal cut off==========
                            if (xStart-1 < 0) xStart = 0;
                            else xStart = xStart-1;
                            
                            if (xEnd+1 == imageDimensionBackgroundX) xEnd = imageDimensionBackgroundX-1;
                            else xEnd = xEnd+1;
                            
                            if (yStart-1 < 0) yStart = 0;
                            else yStart = yStart-1;
                            
                            if (yEnd+1 == imageDimensionBackgroundY) yEnd = imageDimensionBackgroundY-1;
                            else yEnd = yEnd+1;
                            
                            for (int counter3 = 1; counter3 <= connectivityNumber; counter3++){
                                if (connectedPix3 [counter3*2] != 0 && connectedPix3 [counter3*2+1] > connectValue-10 && connectedPix3 [counter3*2+1] < connectValue+10){
                                    for (int counterY = yStart; counterY < yEnd; counterY++){
                                        for (int counterX = xStart; counterX < xEnd; counterX++){
                                            if (backgroundImage2 [counterY][counterX] == counter3){
                                                backgroundImage3 [counterY][counterX] = 100;
                                                connectedPix2 [counter3*7] = -1;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
                delete [] connectedPix3;
                
                //===========Redo connect analysis with value > 130 and < 80. Then enhance cell which is closed to the background================
                for (int counter2 = 0; counter2 < imageDimensionBackgroundY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionBackgroundX; counter3++){
                        backgroundImage1 [counter2][counter3] = backgroundImage3 [counter2][counter3]*-1;
                    }
                }
                
                //===========Redo connect analysis================
                connectivityNumber = 0;
                
                for (int counterY = 0; counterY < imageDimensionBackgroundY; counterY++){
                    for (int counterX = 0; counterX < imageDimensionBackgroundX; counterX++){
                        if (backgroundImage1 [counterY][counterX] < 0){
                            valueHoldTemp = backgroundImage1 [counterY][counterX];
                            connectivityNumber++;
                            
                            backgroundImage1 [counterY][counterX] = connectivityNumber;
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && counterX-1 >= 0 && backgroundImage1 [counterY-1][counterX-1] == valueHoldTemp){
                                backgroundImage1 [counterY-1][counterX-1] = connectivityNumber;
                                connectAnalysisX2 [connectAnalysisCount] = counterX-1, connectAnalysisY2 [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && backgroundImage1 [counterY-1][counterX] == valueHoldTemp){
                                backgroundImage1 [counterY-1][counterX] = connectivityNumber;
                                connectAnalysisX2 [connectAnalysisCount] = counterX, connectAnalysisY2 [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && counterX+1 < imageDimensionBackgroundX && backgroundImage1 [counterY-1][counterX+1] == valueHoldTemp){
                                backgroundImage1 [counterY-1][counterX+1] = connectivityNumber;
                                connectAnalysisX2 [connectAnalysisCount] = counterX+1, connectAnalysisY2 [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < imageDimensionBackgroundX && backgroundImage1 [counterY][counterX+1] == valueHoldTemp){
                                backgroundImage1 [counterY][counterX+1] = connectivityNumber;
                                connectAnalysisX2 [connectAnalysisCount] = counterX+1, connectAnalysisY2 [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < imageDimensionBackgroundY && counterX+1 < imageDimensionBackgroundX && backgroundImage1 [counterY+1][counterX+1] == valueHoldTemp){
                                backgroundImage1 [counterY+1][counterX+1] = connectivityNumber;
                                connectAnalysisX2 [connectAnalysisCount] = counterX+1, connectAnalysisY2 [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < imageDimensionBackgroundY && backgroundImage1 [counterY+1][counterX] == valueHoldTemp){
                                backgroundImage1 [counterY+1][counterX] = connectivityNumber;
                                connectAnalysisX2 [connectAnalysisCount] = counterX, connectAnalysisY2 [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < imageDimensionBackgroundY && counterX-1 >= 0 && backgroundImage1 [counterY+1][counterX-1] == valueHoldTemp){
                                backgroundImage1 [counterY+1][counterX-1] = connectivityNumber;
                                connectAnalysisX2 [connectAnalysisCount] = counterX-1, connectAnalysisY2 [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && backgroundImage1 [counterY][counterX-1] == valueHoldTemp){
                                backgroundImage1 [counterY][counterX-1] = connectivityNumber;
                                connectAnalysisX2 [connectAnalysisCount] = counterX-1, connectAnalysisY2 [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                        xSource = connectAnalysisX2 [counter2];
                                        ySource = connectAnalysisY2 [counter2];
                                        
                                        if (ySource-1 >= 0 && xSource-1 >= 0 && backgroundImage1 [ySource-1][xSource-1] == valueHoldTemp){
                                            backgroundImage1 [ySource-1][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX2 [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && backgroundImage1 [ySource-1][xSource] == valueHoldTemp){
                                            backgroundImage1 [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX2 [connectAnalysisTempCount] = xSource, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && xSource+1 < imageDimensionBackgroundX && backgroundImage1 [ySource-1][xSource+1] == valueHoldTemp){
                                            backgroundImage1 [ySource-1][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX2 [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < imageDimensionBackgroundX && backgroundImage1 [ySource][xSource+1] == valueHoldTemp){
                                            backgroundImage1 [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX2 [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 > imageDimensionBackgroundY && xSource+1 < imageDimensionBackgroundX && backgroundImage1 [ySource+1][xSource+1] == valueHoldTemp){
                                            backgroundImage1 [ySource+1][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX2 [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < imageDimensionBackgroundY && backgroundImage1 [ySource+1][xSource] == valueHoldTemp){
                                            backgroundImage1 [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX2 [connectAnalysisTempCount] = xSource, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < imageDimensionBackgroundY && xSource-1 >= 0 && backgroundImage1 [ySource+1][xSource-1] == valueHoldTemp){
                                            backgroundImage1 [ySource+1][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX2 [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && backgroundImage1 [ySource][xSource-1] == valueHoldTemp){
                                            backgroundImage1 [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX2 [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                        connectAnalysisX2 [counter2] = connectAnalysisTempX2 [counter2], connectAnalysisY2 [counter2] = connectAnalysisTempY2 [counter2];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //-----Determine number of pixels-----
                delete [] connectedPix2;
                
                connectedPix2 = new int [connectivityNumber*3+3];
                
                for (int counter2 = 0; counter2 <= connectivityNumber; counter2++){
                    connectedPix2 [counter2*3] = 0;
                    connectedPix2 [counter2*3+1] = 0;
                    connectedPix2 [counter2*3+2] = 0;
                }
                
                for (int counterY = 0; counterY < imageDimensionBackgroundY; counterY++){
                    for (int counterX = 0; counterX < imageDimensionBackgroundX; counterX++){
                        if (backgroundImage1 [counterY][counterX] != 0){
                            connectedPix2 [backgroundImage1 [counterY][counterX]*3]++;
                            connectedPix2 [backgroundImage1 [counterY][counterX]*3+1] = backgroundImage3 [counterY][counterX];
                        }
                    }
                }
            }
            
            //=========3. Remove pixel < 50 and value 51-199=========
            if (stepSelect3 == 0){
                for (int counterY = 0; counterY < imageDimensionBackgroundY; counterY++){
                    for (int counterX = 0; counterX < imageDimensionBackgroundX; counterX++){
                        connectivityValueTemp = backgroundImage1 [counterY][counterX];
                        pixValueTemp = backgroundImage3 [counterY][counterX];
                        
                        findFlag = 0;
                        
                        if (connectedPix2 [connectivityValueTemp*3] != -1 && backgroundImage3 [counterY][counterX] != 100){
                            if (counterY-1 >= 0 && backgroundImage1 [counterY-1][counterX] != connectivityValueTemp && backgroundImage3 [counterY-1][counterX] != 100 && (backgroundImage3 [counterY-1][counterX] < pixValueTemp-10 || backgroundImage3 [counterY-1][counterX] > pixValueTemp+10)) findFlag = 1;
                            if (counterX+1 < imageDimensionBackgroundX && backgroundImage1 [counterY][counterX+1] != connectivityValueTemp && backgroundImage3 [counterY][counterX+1] != 100 && (backgroundImage3 [counterY][counterX+1] < pixValueTemp-10 || backgroundImage3 [counterY][counterX+1] > pixValueTemp+10)) findFlag = 1;
                            if (counterY+1 < imageDimensionBackgroundY && backgroundImage1 [counterY+1][counterX] != connectivityValueTemp && backgroundImage3 [counterY+1][counterX] != 100 && (backgroundImage3 [counterY+1][counterX] < pixValueTemp-10 || backgroundImage3 [counterY+1][counterX] > pixValueTemp+10)) findFlag = 1;
                            if (counterX-1 >= 0 && backgroundImage1 [counterY][counterX-1] != connectivityValueTemp && backgroundImage3 [counterY][counterX-1] != 100 && (backgroundImage3 [counterY][counterX-1] < pixValueTemp-10 || backgroundImage3 [counterY][counterX-1] > pixValueTemp+10)) findFlag = 1;
                            
                            if (findFlag == 1) connectedPix2 [connectivityValueTemp*3+2] = 1;
                        }
                    }
                }
                
                for (int counterY = 0; counterY < imageDimensionBackgroundY; counterY++){
                    for (int counterX = 0; counterX < imageDimensionBackgroundX; counterX++){
                        connectivityValueTemp = backgroundImage1 [counterY][counterX];
                        
                        if (connectedPix2 [connectivityValueTemp*3+2] == 0 && connectedPix2 [connectivityValueTemp*3] != -1 && connectedPix2 [connectivityValueTemp*3] < 50 && connectedPix2 [connectivityValueTemp*3+1] < 200 && connectedPix2 [connectivityValueTemp*3+1] > 50){
                            backgroundImage3 [counterY][counterX] = 100;
                        }
                    }
                }
            }
            
            //========4. Remove pixel two side- or three-side surrounded by 100==========
            if (stepSelect4 == 0){
                do{
                    
                    processFlag = 0;
                    
                    for (int counterY = 0; counterY < imageDimensionBackgroundY; counterY++){
                        for (int counterX = 0; counterX < imageDimensionBackgroundX; counterX++){
                            connectivityValueTemp = backgroundImage3 [counterY][counterX];
                            
                            findFlag2 = 0;
                            findFlag3 = 0;
                            findFlag4 = 0;
                            findFlag5 = 0;
                            findFlag6 = 0;
                            findFlag7 = 0;
                            
                            if (connectivityValueTemp != 100){
                                if (counterY-1 >= 0 && backgroundImage3 [counterY-1][counterX] == 100){
                                    if (findFlag2 == 0) findFlag2 = 1;
                                    else if (findFlag2 == 1) findFlag2 = 2;
                                    
                                    if (findFlag4 == 0) findFlag4 = 1;
                                    else if (findFlag4 == 1) findFlag4 = 2;
                                    else if (findFlag4 == 2) findFlag4 = 3;
                                    
                                    if (findFlag6 == 0) findFlag6 = 1;
                                    else if (findFlag6 == 1) findFlag6 = 2;
                                    else if (findFlag6 == 2) findFlag6 = 3;
                                    
                                    if (findFlag7 == 0) findFlag7 = 1;
                                    else if (findFlag7 == 1) findFlag7 = 2;
                                    else if (findFlag7 == 2) findFlag7 = 3;
                                }
                                if (counterX+1 < imageDimensionBackgroundX && backgroundImage3 [counterY][counterX+1] == 100){
                                    if (findFlag3 == 0) findFlag3 = 1;
                                    else if (findFlag3 == 1) findFlag3 = 2;
                                    
                                    if (findFlag4 == 0) findFlag4 = 1;
                                    else if (findFlag4 == 1) findFlag4 = 2;
                                    else if (findFlag4 == 2) findFlag4 = 3;
                                    
                                    if (findFlag5 == 0) findFlag5 = 1;
                                    else if (findFlag5 == 1) findFlag5 = 2;
                                    else if (findFlag5 == 2) findFlag5 = 3;
                                    
                                    if (findFlag7 == 0) findFlag7 = 1;
                                    else if (findFlag7 == 1) findFlag7 = 2;
                                    else if (findFlag7 == 2) findFlag7 = 3;
                                }
                                if (counterY+1 < imageDimensionBackgroundY && backgroundImage3 [counterY+1][counterX] == 100){
                                    if (findFlag2 == 0) findFlag2 = 1;
                                    else if (findFlag2 == 1) findFlag2 = 2;
                                    
                                    if (findFlag4 == 0) findFlag4 = 1;
                                    else if (findFlag4 == 1) findFlag4 = 2;
                                    else if (findFlag4 == 2) findFlag4 = 3;
                                    
                                    if (findFlag5 == 0) findFlag5 = 1;
                                    else if (findFlag5 == 1) findFlag5 = 2;
                                    else if (findFlag5 == 2) findFlag5 = 3;
                                    
                                    if (findFlag6 == 0) findFlag6 = 1;
                                    else if (findFlag6 == 1) findFlag6 = 2;
                                    else if (findFlag6 == 2) findFlag6 = 3;
                                }
                                if (counterX-1 >= 0 && backgroundImage3 [counterY][counterX-1] == 100){
                                    if (findFlag3 == 0) findFlag3 = 1;
                                    else if (findFlag3 == 1) findFlag3 = 2;
                                    
                                    if (findFlag5 == 0) findFlag5 = 1;
                                    else if (findFlag5 == 1) findFlag5 = 2;
                                    else if (findFlag5 == 2) findFlag5 = 3;
                                    
                                    if (findFlag6 == 0) findFlag6 = 1;
                                    else if (findFlag6 == 1) findFlag6 = 2;
                                    else if (findFlag6 == 2) findFlag6 = 3;
                                    
                                    if (findFlag7 == 0) findFlag7 = 1;
                                    else if (findFlag7 == 1) findFlag7 = 2;
                                    else if (findFlag7 == 2) findFlag7 = 3;
                                }
                                
                                if (findFlag2 == 2 || findFlag3 == 2 || findFlag4 == 3 || findFlag5 == 3 || findFlag6 == 3 || findFlag7 == 3){
                                    backgroundImage3 [counterY][counterX] = 100;
                                    processFlag = 1;
                                }
                            }
                        }
                    }
                    
                } while (processFlag == 1);
            }
            
            //-----Apply Gaussian blur, background pattern-----
            if (stepSelect5 == 0){
                for (int counter2 = 0; counter2 < imageDimensionBackgroundY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionBackgroundX; counter3++){
                        backgroundImage1 [counter2][counter3] = backgroundImage3 [counter2][counter3];
                    }
                }
                
                for (int counter2 = 0; counter2 < imageDimensionBackgroundY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionBackgroundX; counter3++){
                        bitGaussian = 0;
                        
                        for (int counter4 = -2; counter4 <= 2; counter4++){
                            for (int counter5 = -2; counter5 <= 2; counter5++){
                                if (counter2+counter4 >= imageDimensionBackgroundY || counter2+counter4 < 0 || counter3+counter5 >= imageDimensionBackgroundX || counter3+counter5 < 0){
                                    bitGaussian = bitGaussian+backgroundImage1 [counter2][counter3]*maskMatrix [counter4+2][counter5+2];
                                }
                                else bitGaussian = bitGaussian+backgroundImage1 [counter2+counter4][counter3+counter5]*maskMatrix [counter4+2][counter5+2];
                            }
                        }
                        
                        backgroundImage4 [counter2][counter3] = (int)bitGaussian;
                    }
                }
                
                for (int counter2 = 0; counter2 < imageDimensionBackgroundY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionBackgroundX; counter3++){
                        backgroundImage1 [counter2][counter3] = backgroundImage4 [counter2][counter3]*-1;
                    }
                }
                
                //========5. Remove pixel group surrounded by 100 using bluer data========
                connectivityNumber = 0;
                
                for (int counterY = 0; counterY < imageDimensionBackgroundY; counterY++){
                    for (int counterX = 0; counterX < imageDimensionBackgroundX; counterX++){
                        if (backgroundImage1 [counterY][counterX] != -100 & backgroundImage1 [counterY][counterX] < 0){
                            connectivityNumber++;
                            
                            backgroundImage1 [counterY][counterX] = connectivityNumber;
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && backgroundImage1 [counterY-1][counterX] != -100 && backgroundImage1 [counterY-1][counterX] < 0){
                                backgroundImage1 [counterY-1][counterX] = connectivityNumber;
                                connectAnalysisX2 [connectAnalysisCount] = counterX, connectAnalysisY2 [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < imageDimensionBackgroundX && backgroundImage1 [counterY][counterX+1] != -100 && backgroundImage1 [counterY][counterX+1] < 0){
                                backgroundImage1 [counterY][counterX+1] = connectivityNumber;
                                connectAnalysisX2 [connectAnalysisCount] = counterX+1, connectAnalysisY2 [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < imageDimensionBackgroundY && backgroundImage1 [counterY+1][counterX] != -100 && backgroundImage1 [counterY+1][counterX] < 0){
                                backgroundImage1 [counterY+1][counterX] = connectivityNumber;
                                connectAnalysisX2 [connectAnalysisCount] = counterX, connectAnalysisY2 [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && backgroundImage1 [counterY][counterX-1] != -100 && backgroundImage1 [counterY][counterX-1] < 0){
                                backgroundImage1 [counterY][counterX-1] = connectivityNumber;
                                connectAnalysisX2 [connectAnalysisCount] = counterX-1, connectAnalysisY2 [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                        xSource = connectAnalysisX2 [counter2];
                                        ySource = connectAnalysisY2 [counter2];
                                        
                                        if (ySource-1 >= 0 && backgroundImage1 [ySource-1][xSource] != -100 && backgroundImage1 [ySource-1][xSource] < 0){
                                            backgroundImage1 [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX2 [connectAnalysisTempCount] = xSource, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < imageDimensionBackgroundX && backgroundImage1 [ySource][xSource+1] != -100 && backgroundImage1 [ySource][xSource+1] < 0){
                                            backgroundImage1 [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX2 [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < imageDimensionBackgroundY && backgroundImage1 [ySource+1][xSource] != -100 && backgroundImage1 [ySource+1][xSource] < 0){
                                            backgroundImage1 [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX2 [connectAnalysisTempCount] = xSource, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && backgroundImage1 [ySource][xSource-1] != -100 && backgroundImage1 [ySource][xSource-1] < 0){
                                            backgroundImage1 [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX2 [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                        connectAnalysisX2 [counter2] = connectAnalysisTempX2 [counter2], connectAnalysisY2 [counter2] = connectAnalysisTempY2 [counter2];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                delete [] connectedPix2;
                
                connectedPix2 = new int [connectivityNumber*3+3];
                
                for (int counter2 = 0; counter2 <= connectivityNumber; counter2++){
                    connectedPix2 [counter2*3] = 0;
                    connectedPix2 [counter2*3+1] = 0;
                    connectedPix2 [counter2*3+2] = 0;
                }
                
                for (int counterY = 0; counterY < imageDimensionBackgroundY; counterY++){
                    for (int counterX = 0; counterX < imageDimensionBackgroundX; counterX++){
                        if (backgroundImage1 [counterY][counterX] > 0){
                            connectedPix2 [backgroundImage1 [counterY][counterX]*3]++;
                            if (connectedPix2 [backgroundImage1 [counterY][counterX]*3] < 500) connectedPix2 [backgroundImage1 [counterY][counterX]*3+1] = connectedPix2 [backgroundImage1 [counterY][counterX]*3+1]+backgroundImage3 [counterY][counterX];
                        }
                    }
                }
                
                for (int counter2 = 1; counter2 <= connectivityNumber; counter2++){
                    if (connectedPix2 [counter2*3] <= 50) connectedPix2 [counter2*3] = -1;
                    if (connectedPix2 [counter2*3] > 50 && connectedPix2 [counter2*3] < 500 && connectedPix2 [counter2*3+1]/connectedPix2 [counter2*3] < 200 && connectedPix2 [counter2*3+1]/connectedPix2 [counter2*3] > 50) connectedPix2 [counter2*3] = -1;
                }
                
                for (int counterY = 0; counterY < imageDimensionBackgroundY; counterY++){
                    for (int counterX = 0; counterX < imageDimensionBackgroundX; counterX++){
                        if (backgroundImage1 [counterY][counterX] > 0 && connectedPix2 [backgroundImage1 [counterY][counterX]*3] == -1) backgroundImage3 [counterY][counterX] = 100;
                    }
                }
            }
            
            //========6. Remove pixel < 50 and surrounded by 100========
            if (stepSelect6 == 0){
                for (int counter2 = 0; counter2 < imageDimensionBackgroundY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionBackgroundX; counter3++){
                        backgroundImage1 [counter2][counter3] = backgroundImage3 [counter2][counter3]*-1;
                    }
                }
                
                connectivityNumber = 0;
                
                for (int counterY = 0; counterY < imageDimensionBackgroundY; counterY++){
                    for (int counterX = 0; counterX < imageDimensionBackgroundX; counterX++){
                        if (backgroundImage1 [counterY][counterX] != -100 & backgroundImage1 [counterY][counterX] < 0){
                            connectivityNumber++;
                            
                            backgroundImage1 [counterY][counterX] = connectivityNumber;
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && backgroundImage1 [counterY-1][counterX] != -100 && backgroundImage1 [counterY-1][counterX] < 0){
                                backgroundImage1 [counterY-1][counterX] = connectivityNumber;
                                connectAnalysisX2 [connectAnalysisCount] = counterX, connectAnalysisY2 [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < imageDimensionBackgroundX && backgroundImage1 [counterY][counterX+1] != -100 && backgroundImage1 [counterY][counterX+1] < 0){
                                backgroundImage1 [counterY][counterX+1] = connectivityNumber;
                                connectAnalysisX2 [connectAnalysisCount] = counterX+1, connectAnalysisY2 [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < imageDimensionBackgroundY && backgroundImage1 [counterY+1][counterX] != -100 && backgroundImage1 [counterY+1][counterX] < 0){
                                backgroundImage1 [counterY+1][counterX] = connectivityNumber;
                                connectAnalysisX2 [connectAnalysisCount] = counterX, connectAnalysisY2 [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && backgroundImage1 [counterY][counterX-1] != -100 && backgroundImage1 [counterY][counterX-1] < 0){
                                backgroundImage1 [counterY][counterX-1] = connectivityNumber;
                                connectAnalysisX2 [connectAnalysisCount] = counterX-1, connectAnalysisY2 [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                        xSource = connectAnalysisX2 [counter2];
                                        ySource = connectAnalysisY2 [counter2];
                                        
                                        if (ySource-1 >= 0 && backgroundImage1 [ySource-1][xSource] != -100 && backgroundImage1 [ySource-1][xSource] < 0){
                                            backgroundImage1 [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX2 [connectAnalysisTempCount] = xSource, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < imageDimensionBackgroundX && backgroundImage1 [ySource][xSource+1] != -100 && backgroundImage1 [ySource][xSource+1] < 0){
                                            backgroundImage1 [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX2 [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < imageDimensionBackgroundY && backgroundImage1 [ySource+1][xSource] != -100 && backgroundImage1 [ySource+1][xSource] < 0){
                                            backgroundImage1 [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX2 [connectAnalysisTempCount] = xSource, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && backgroundImage1 [ySource][xSource-1] != -100 && backgroundImage1 [ySource][xSource-1] < 0){
                                            backgroundImage1 [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX2 [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                        connectAnalysisX2 [counter2] = connectAnalysisTempX2 [counter2], connectAnalysisY2 [counter2] = connectAnalysisTempY2 [counter2];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                delete [] connectedPix2;
                
                connectedPix2 = new int [connectivityNumber*3+3];
                
                for (int counter2 = 0; counter2 <= connectivityNumber; counter2++){
                    connectedPix2 [counter2*3] = 0;
                    connectedPix2 [counter2*3+1] = 0;
                    connectedPix2 [counter2*3+2] = 0;
                }
                
                for (int counterY = 0; counterY < imageDimensionBackgroundY; counterY++){
                    for (int counterX = 0; counterX < imageDimensionBackgroundX; counterX++){
                        if (backgroundImage1 [counterY][counterX] > 0){
                            connectedPix2 [backgroundImage1 [counterY][counterX]*3]++;
                            
                            if (connectedPix2 [backgroundImage1 [counterY][counterX]*3] < 100) connectedPix2 [backgroundImage1 [counterY][counterX]*3+1] = connectedPix2 [backgroundImage1 [counterY][counterX]*3+1]+backgroundImage3 [counterY][counterX];
                        }
                    }
                }
                
                for (int counter2 = 1; counter2 <= connectivityNumber; counter2++){
                    if (connectedPix2 [counter2*3] <= 50) connectedPix2 [counter2*3] = -1;
                    else if (connectedPix2 [counter2*3] > 50 && connectedPix2 [counter2*3] < 100 && connectedPix2 [counter2*3+1]/connectedPix2 [counter2*3] < 150 && connectedPix2 [counter2*3+1]/connectedPix2 [counter2*3] > 50) connectedPix2 [counter2*3] = -1;
                }
                
                for (int counterY = 0; counterY < imageDimensionBackgroundY; counterY++){
                    for (int counterX = 0; counterX < imageDimensionBackgroundX; counterX++){
                        if (backgroundImage1 [counterY][counterX] > 0 && connectedPix2 [backgroundImage1 [counterY][counterX]*3] == -1) backgroundImage3 [counterY][counterX] = 100;
                    }
                }
            }
            
            //========7. Remove pixel group surrounded by 100 or A:B are surrounded by 100 or horizontal A:A:A and vertical B:B:B========
            if (stepSelect7 == 0){
                do{
                    
                    processFlag = 0;
                    
                    for (int counterY = 0; counterY < imageDimensionBackgroundY; counterY++){
                        for (int counterX = 0; counterX < imageDimensionBackgroundX; counterX++){
                            connectivityValueTemp = backgroundImage3 [counterY][counterX];
                            
                            findFlag2 = 0;
                            findFlag3 = 0;
                            findFlag4 = 0;
                            findFlag5 = 0;
                            findFlag6 = 0;
                            findFlag7 = 0;
                            
                            if (connectivityValueTemp != 100){
                                if (counterY-1 >= 0 && backgroundImage3 [counterY-1][counterX] == 100){
                                    if (findFlag2 == 0) findFlag2 = 1;
                                    else if (findFlag2 == 1) findFlag2 = 2;
                                    
                                    if (findFlag4 == 0) findFlag4 = 1;
                                    else if (findFlag4 == 1) findFlag4 = 2;
                                    else if (findFlag4 == 2) findFlag4 = 3;
                                    
                                    if (findFlag6 == 0) findFlag6 = 1;
                                    else if (findFlag6 == 1) findFlag6 = 2;
                                    else if (findFlag6 == 2) findFlag6 = 3;
                                    
                                    if (findFlag7 == 0) findFlag7 = 1;
                                    else if (findFlag7 == 1) findFlag7 = 2;
                                    else if (findFlag7 == 2) findFlag7 = 3;
                                }
                                if (counterX+1 < imageDimensionBackgroundX && backgroundImage3 [counterY][counterX+1] == 100){
                                    if (findFlag3 == 0) findFlag3 = 1;
                                    else if (findFlag3 == 1) findFlag3 = 2;
                                    
                                    if (findFlag4 == 0) findFlag4 = 1;
                                    else if (findFlag4 == 1) findFlag4 = 2;
                                    else if (findFlag4 == 2) findFlag4 = 3;
                                    
                                    if (findFlag5 == 0) findFlag5 = 1;
                                    else if (findFlag5 == 1) findFlag5 = 2;
                                    else if (findFlag5 == 2) findFlag5 = 3;
                                    
                                    if (findFlag7 == 0) findFlag7 = 1;
                                    else if (findFlag7 == 1) findFlag7 = 2;
                                    else if (findFlag7 == 2) findFlag7 = 3;
                                }
                                if (counterY+1 < imageDimensionBackgroundY && backgroundImage3 [counterY+1][counterX] == 100){
                                    if (findFlag2 == 0) findFlag2 = 1;
                                    else if (findFlag2 == 1) findFlag2 = 2;
                                    
                                    if (findFlag4 == 0) findFlag4 = 1;
                                    else if (findFlag4 == 1) findFlag4 = 2;
                                    else if (findFlag4 == 2) findFlag4 = 3;
                                    
                                    if (findFlag5 == 0) findFlag5 = 1;
                                    else if (findFlag5 == 1) findFlag5 = 2;
                                    else if (findFlag5 == 2) findFlag5 = 3;
                                    
                                    if (findFlag6 == 0) findFlag6 = 1;
                                    else if (findFlag6 == 1) findFlag6 = 2;
                                    else if (findFlag6 == 2) findFlag6 = 3;
                                }
                                if (counterX-1 >= 0 && backgroundImage3 [counterY][counterX-1] == 100){
                                    if (findFlag3 == 0) findFlag3 = 1;
                                    else if (findFlag3 == 1) findFlag3 = 2;
                                    
                                    if (findFlag5 == 0) findFlag5 = 1;
                                    else if (findFlag5 == 1) findFlag5 = 2;
                                    else if (findFlag5 == 2) findFlag5 = 3;
                                    
                                    if (findFlag6 == 0) findFlag6 = 1;
                                    else if (findFlag6 == 1) findFlag6 = 2;
                                    else if (findFlag6 == 2) findFlag6 = 3;
                                    
                                    if (findFlag7 == 0) findFlag7 = 1;
                                    else if (findFlag7 == 1) findFlag7 = 2;
                                    else if (findFlag7 == 2) findFlag7 = 3;
                                }
                                
                                if (findFlag2 == 2 || findFlag3 == 2 || findFlag4 == 3 || findFlag5 == 3 || findFlag6 == 3 || findFlag7 == 3){
                                    backgroundImage3 [counterY][counterX] = 100;
                                    processFlag = 1;
                                }
                                else if (findFlag2 == 1 || findFlag3 == 1){
                                    if (findFlag2 == 1){
                                        if (counterY-1 >= 0 && backgroundImage3 [counterY-1][counterX] == 100){
                                            if (counterY+1 < imageDimensionBackgroundY && backgroundImage3 [counterY+1][counterX] != 100){
                                                if (counterY+2 < imageDimensionBackgroundY && backgroundImage3 [counterY+2][counterX] == 100){
                                                    backgroundImage3 [counterY][counterX] = 100;
                                                    backgroundImage3 [counterY+1][counterX] = 100;
                                                    processFlag = 1;
                                                }
                                            }
                                        }
                                        else if (counterY+1 < imageDimensionBackgroundY && backgroundImage3 [counterY+1][counterX] == 100){
                                            if (counterY-1 >= 0 && backgroundImage3 [counterY-1][counterX] != 100){
                                                if (counterY-2 >= 0 && backgroundImage3 [counterY-2][counterX] == 100){
                                                    backgroundImage3 [counterY][counterX] = 100;
                                                    backgroundImage3 [counterY-1][counterX] = 100;
                                                    processFlag = 1;
                                                }
                                            }
                                        }
                                    }
                                    else if (findFlag3 == 1){
                                        if (counterX-1 >= 0 && backgroundImage3 [counterY][counterX-1] == 100){
                                            if (counterX+1 < imageDimensionBackgroundX && backgroundImage3 [counterY][counterX+1] != 100){
                                                if (counterX+2 < imageDimensionBackgroundX && backgroundImage3 [counterY][counterX+2] == 100){
                                                    backgroundImage3 [counterY][counterX] = 100;
                                                    backgroundImage3 [counterY][counterX+1] = 100;
                                                    processFlag = 1;
                                                }
                                            }
                                        }
                                        else if (counterX+1 < imageDimensionBackgroundX && backgroundImage3 [counterY][counterX+1] == 100){
                                            if (counterX-1 >= 0 && backgroundImage3 [counterY][counterX-1] != 100){
                                                if (counterX-2 >= 0 && backgroundImage3 [counterY][counterX-2] == 100){
                                                    backgroundImage3 [counterY][counterX] = 100;
                                                    backgroundImage3 [counterY][counterX-1] = 100;
                                                    processFlag = 1;
                                                }
                                            }
                                        }
                                    }
                                    
                                    if (processFlag == 0 && findFlag2 == 1 && findFlag3 == 1){
                                        horizontal1 = 0;
                                        horizontal2 = 0;
                                        vertical1 = 0;
                                        vertical2 = 0;
                                        
                                        if (counterY-1 >= 0 && backgroundImage3 [counterY-1][counterX] == 100 && counterX-1 >= 0 && backgroundImage3 [counterY][counterX-1] == 100){
                                            if (counterY+1 < imageDimensionBackgroundY && backgroundImage3 [counterY+1][counterX] != 100){
                                                if (counterX-1 >= 0 && backgroundImage3 [counterY+1][counterX-1] == 100) vertical1 = 1;
                                            }
                                            
                                            if (counterY+2 < imageDimensionBackgroundY && backgroundImage3 [counterY+2][counterX] != 100){
                                                if (counterX-1 >= 0 && backgroundImage3 [counterY+2][counterX-1] == 100) vertical2 = 1;
                                            }
                                            
                                            if (counterX+1 < imageDimensionBackgroundX && backgroundImage3 [counterY][counterX+1] != 100){
                                                if (counterY-1 >= 0 && backgroundImage3 [counterY-1][counterX+1] == 100) horizontal1 = 1;
                                            }
                                            
                                            if (counterX+2 < imageDimensionBackgroundX && backgroundImage3 [counterY][counterX+2] != 100){
                                                if (counterY-1 >= 0 && backgroundImage3 [counterY-1][counterX+2] == 100) horizontal2 = 1;
                                            }
                                            
                                            if (horizontal1 == 1 && horizontal2 == 1 && vertical1 == 1 && vertical2 == 1){
                                                backgroundImage3 [counterY][counterX] = 100;
                                                backgroundImage3 [counterY+1][counterX] = 100;
                                                backgroundImage3 [counterY+2][counterX] = 100;
                                                backgroundImage3 [counterY][counterX+1] = 100;
                                                backgroundImage3 [counterY][counterX+2] = 100;
                                                processFlag = 1;
                                            }
                                        }
                                        
                                        horizontal1 = 0;
                                        horizontal2 = 0;
                                        vertical1 = 0;
                                        vertical2 = 0;
                                        
                                        if (counterY-1 >= 0 && backgroundImage3 [counterY-1][counterX] == 100 && counterX+1 < imageDimensionBackgroundX && backgroundImage3 [counterY][counterX+1] == 100){
                                            if (counterY+1 < imageDimensionBackgroundY && backgroundImage3 [counterY+1][counterX] != 100){
                                                if (counterX+1 < imageDimensionBackgroundX && backgroundImage3 [counterY+1][counterX+1] == 100) vertical1 = 1;
                                            }
                                            
                                            if (counterY+2 < imageDimensionBackgroundY && backgroundImage3 [counterY+2][counterX] != 100){
                                                if (counterX+1 < imageDimensionBackgroundX && backgroundImage3 [counterY+2][counterX+1] == 100) vertical2 = 1;
                                            }
                                            
                                            if (counterX-1 >= 0 && backgroundImage3 [counterY][counterX-1] != 100){
                                                if (counterY-1 >= 0 && backgroundImage3 [counterY-1][counterX-1] == 100) horizontal1 = 1;
                                            }
                                            
                                            if (counterX-2 >= 0 && backgroundImage3 [counterY][counterX-2] != 100){
                                                if (counterY-1 >= 0 && backgroundImage3 [counterY-1][counterX-2] == 100) horizontal2 = 1;
                                            }
                                            
                                            if (horizontal1 == 1 && horizontal2 == 1 && vertical1 == 1 && vertical2 == 1){
                                                backgroundImage3 [counterY][counterX] = 100;
                                                backgroundImage3 [counterY+1][counterX] = 100;
                                                backgroundImage3 [counterY+2][counterX] = 100;
                                                backgroundImage3 [counterY][counterX-1] = 100;
                                                backgroundImage3 [counterY][counterX-2] = 100;
                                                processFlag = 1;
                                            }
                                        }
                                        
                                        horizontal1 = 0;
                                        horizontal2 = 0;
                                        vertical1 = 0;
                                        vertical2 = 0;
                                        
                                        if (counterY+1 < imageDimensionBackgroundY && backgroundImage3 [counterY+1][counterX] == 100 && counterX+1 < imageDimensionBackgroundX && backgroundImage3 [counterY][counterX+1] == 100){
                                            if (counterY-1 >= 0 && backgroundImage3 [counterY-1][counterX] != 100){
                                                if (counterX+1 < imageDimensionBackgroundX && backgroundImage3 [counterY-1][counterX+1] == 100) vertical1 = 1;
                                            }
                                            
                                            if (counterY-2 >= 0 && backgroundImage3 [counterY-2][counterX] != 100){
                                                if (counterX+1 < imageDimensionBackgroundX && backgroundImage3 [counterY-2][counterX+1] == 100) vertical2 = 1;
                                            }
                                            
                                            if (counterX-1 >= 0 && backgroundImage3 [counterY][counterX-1] != 100){
                                                if (counterY+1 < imageDimensionBackgroundY && backgroundImage3 [counterY+1][counterX-1] == 100) horizontal1 = 1;
                                            }
                                            
                                            if (counterX-2 >= 0 && backgroundImage3 [counterY][counterX-2] != 100){
                                                if (counterY+1 < imageDimensionBackgroundY && backgroundImage3 [counterY+1][counterX-2] == 100) horizontal2 = 1;
                                            }
                                            
                                            if (horizontal1 == 1 && horizontal2 == 1 && vertical1 == 1 && vertical2 == 1){
                                                backgroundImage3 [counterY][counterX] = 100;
                                                backgroundImage3 [counterY-1][counterX] = 100;
                                                backgroundImage3 [counterY-2][counterX] = 100;
                                                backgroundImage3 [counterY][counterX-1] = 100;
                                                backgroundImage3 [counterY][counterX-2] = 100;
                                                processFlag = 1;
                                            }
                                            
                                            horizontal1 = 0;
                                            horizontal2 = 0;
                                            vertical1 = 0;
                                            vertical2 = 0;
                                            
                                            if (counterY-1 < imageDimensionBackgroundY && backgroundImage3 [counterY+1][counterX] == 100 && counterX-1 >= 0 && backgroundImage3 [counterY][counterX-1] == 100){
                                                if (counterY-1 >= 0 && backgroundImage3 [counterY-1][counterX] != 100){
                                                    if (counterX-1 >= 0 && backgroundImage3 [counterY-1][counterX-1] == 100) vertical1 = 1;
                                                }
                                                
                                                if (counterY-2 >= 0 && backgroundImage3 [counterY-2][counterX] != 100){
                                                    if (counterX-1 >= 0 && backgroundImage3 [counterY-2][counterX-1] == 100) vertical2 = 1;
                                                }
                                                
                                                if (counterX+1 < imageDimensionBackgroundX && backgroundImage3 [counterY][counterX+1] != 100){
                                                    if (counterY+1 < imageDimensionBackgroundY && backgroundImage3 [counterY+1][counterX+1] == 100) horizontal1 = 1;
                                                }
                                                
                                                if (counterX+2 < imageDimensionBackgroundX && backgroundImage3 [counterY][counterX+2] != 100){
                                                    if (counterY+1 < imageDimensionBackgroundY && backgroundImage3 [counterY+1][counterX+2] == 100) horizontal2 = 1;
                                                }
                                                
                                                if (horizontal1 == 1 && horizontal2 == 1 && vertical1 == 1 && vertical2 == 1){
                                                    backgroundImage3 [counterY][counterX] = 100;
                                                    backgroundImage3 [counterY-1][counterX] = 100;
                                                    backgroundImage3 [counterY-2][counterX] = 100;
                                                    backgroundImage3 [counterY][counterX+1] = 100;
                                                    backgroundImage3 [counterY][counterX+2] = 100;
                                                    processFlag = 1;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                } while (processFlag == 1);
            }
            
            delete [] connectedPix2;
            
            if (bcType == 1){
                for (int counter2 = 0; counter2 < imageDimensionBackgroundY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionBackgroundX; counter3++){
                        arrayBackgroundDataHold [counter1*imageDimensionBackgroundY+counter2][counter3] = backgroundImage3 [counter2][counter3];
                    }
                }
            }
            else if (bcType == 2){
                for (int counter2 = 0; counter2 < autoImageSizeY; counter2++){
                    for (int counter3 = 0; counter3 < autoImageSizeX; counter3++){
                        arrayBackgroundCorrectionData [counter1*autoImageSizeY+counter2][counter3] = backgroundImage3 [counter2][counter3];
                    }
                }
            }
            else{
                
                for (int counter2 = 0; counter2 < imageDimensionBackgroundY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionBackgroundX; counter3++){
                        arrayBackgroundDataHold2 [counter1*imageDimensionBackgroundY+counter2][counter3] = backgroundImage3 [counter2][counter3];
                    }
                }
            }
        }
        else{
            
            if (bcType == 3){
                for (int counter2 = 0; counter2 < imageDimensionBackgroundY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionBackgroundX; counter3++){
                        arrayBackgroundDataHold2 [counter1*imageDimensionBackgroundY+counter2][counter3] = arrayBalanceBaseData [counter1*imageDimensionBackgroundY+counter2][counter3];
                    }
                }
            }
        }
    }
    
    for (int counter1 = 0; counter1 < imageDimensionBackgroundY+1; counter1++){
        delete [] backgroundImage1 [counter1];
        delete [] gaussianImage [counter1];
        delete [] sdMap [counter1];
        delete [] backgroundImage2 [counter1];
        delete [] backgroundImage3 [counter1];
        delete [] backgroundImage4 [counter1];
    }
    
    delete [] backgroundImage1;
    delete [] gaussianImage;
    delete [] sdMap;
    delete [] backgroundImage2;
    delete [] backgroundImage3;
    delete [] backgroundImage4;
    
    for (int counter1 = 0; counter1 < yBlockNo+1; counter1++){
        delete [] imageMatrix [counter1];
        delete [] imageMatrix2 [counter1];
        delete [] middleIntensity [counter1];
        delete [] linkMap [counter1];
    }
    
    delete [] imageMatrix;
    delete [] imageMatrix2;
    delete [] middleIntensity;
    delete [] linkMap;
    
    delete [] imageValueInBlock;
    delete [] connectAnalysisX2;
    delete [] connectAnalysisY2;
    delete [] connectAnalysisTempX2;
    delete [] connectAnalysisTempY2;
    delete [] bkNumberHold;
    
    backgroundCorrectionCall = 4;
}

@end
