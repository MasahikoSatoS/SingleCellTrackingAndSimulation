//
//  ContrastWindow.h
//  Contrast_Set
//
//  Created by Masahiko Sato on 2014-04-19.
//  Copyright Masahiko Sato 2014 All rights reserved.
//

#ifndef CONTRASTWINDOW_H
#define CONTRASTWINDOW_H
#import "Controller.h"
#endif

@interface ContrastWindow : NSView{
    int selectProcessLine; //Select process line
    double xPointDownCont; //X position count
    double xPointDragCont; //X position drag
    
    IBOutlet NSImage *contrastImage;
    
    id contrastAdjust;
}

-(void)mouseDown:(NSEvent *)event;
-(void)mouseDragged:(NSEvent *)event;
-(void)dealloc;

@end
