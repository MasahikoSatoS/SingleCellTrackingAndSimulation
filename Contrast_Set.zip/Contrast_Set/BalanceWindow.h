//
//  BalanceWindow.h
//  Contrast_Set
//
//  Created by Masahiko Sato on 6/8/16.
//  Copyright Masahiko Sato 2016 All rights reserved.
//
//

#ifndef BALANCEWINDOW_H
#define BALANCEWINDOW_H
#import "Controller.h"
#endif

@interface BalanceWindow : NSView{
    int mouseDragFlag; //Display
    int mouseDownFlag; //Display
    
    int imageFirstLoadFlagDisplayBL; //Image first load flag
    int magnificationDisplayBL; //BL position set magnification
    
    double xPointDownDisplayBL; //Display
    double yPointDownDisplayBL; //Display
    double xPositionMoveDisplayBL; //Display
    double yPositionMoveDisplayBL; //Display
    double xPointDragDisplayBL; //Display
    double yPointDragDisplayBL; //Display
    double xPositionDisplayBL; //Display
    double yPositionDisplayBL; //Display
    double xPositionAdjustDisplayBL; //Display
    double yPositionAdjustDisplayBL; //Display
    double windowWidthDisplayBL; //Display
    double windowHeightDisplayBL; //Display
    
    IBOutlet NSImage *balanceImage;
}

-(void)mouseDown:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)mouseDragged:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
