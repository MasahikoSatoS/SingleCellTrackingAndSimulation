//
//  ImageDataSet.m
//  Contrast_Set
//
//  Created by Masahiko Sato on 2014-04-11.
//
//

#import "ImageDataSet.h"

@implementation ImageDataSet

-(void)imageDataSetProcess:(int)processType{
    string treatNameRead;
    
    if (processType == 2) treatNameRead = arrayTreatmentNameDisplay [rowIndexHold]; //=====Table click======
    else if (processType == 3 || processType == 4 || processType == 5) treatNameRead = loadImageTreatName; //=========FW BW=========
    else if (processType == 1) treatNameRead = arrayTreatmentNameDisplay [1]; //========First read=========
    
    if ((treatNameRead != "ND" && (loadImageTreatName == "" || loadImageTreatName != treatNameRead)) || (processType == 3 && loadImageTreatName == treatNameRead) || ((processType == 4 || processType == 5) && loadImageTreatName == treatNameRead) || orientationSetFlag == 1){
        orientationSetFlag = 0;
        
        if (treatNameRead != "ND") loadImageTreatName = treatNameRead;
        
        string extractString = loadImageTreatName.substr(loadImageTreatName.length()-3, 2);
        string treatString;
        string channelString;
        
        if (extractString == "CH"){
            treatString = loadImageTreatName.substr(0, loadImageTreatName.length()-3);
            channelString = loadImageTreatName.substr(loadImageTreatName.length()-1, 1);
        }
        else{
            
            treatString = loadImageTreatName;
            channelString = "";
        }
        
        string extension = to_string(loadImageNo);
        string timeString;
        
        if (extension.length() == 1) timeString = "000"+extension;
        else if (extension.length() == 2) timeString = "00"+extension;
        else if (extension.length() == 3) timeString = "0"+extension;
        else if (extension.length() == 4) timeString = extension;
        
        int fovNumberCount = 0;
        string folderName = treatString+"~Sorted";
        string processFilePath = productsFilesImagePath+"/"+folderName;
        string entry;
        
        ifstream fin;
        
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(processFilePath.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    if ((int)entry.find("FOV") != -1) fovNumberCount++;
                }
            }
            
            closedir(dir);
        }
        
        int fileExistCheck = 0;
        string fovString;
        string colorName;
        string colorNameNo;
        string processFilePath2;
        string processFilePathWithExt;
        
        for (int counter1 = 1; counter1 <= fovNumberCount; counter1++){
            extension = to_string(counter1);
            
            if (extension.length() == 1) fovString = "FOV00"+extension;
            else if (extension.length() == 2) fovString = "FOV0"+extension;
            else if (extension.length() == 3) fovString = "FOV"+extension;
            
            if (channelString == ""){
                if (currentTimePoint < lastImageNo){
                    processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString;
                }
                else if (currentTimePoint == lastImageNo){
                    processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString;
                    processFilePath2 = processFilePath+".tif";
                    
                    fin.open(processFilePath2.c_str(), ios::in);
                    
                    if (!fin.is_open()){
                        processFilePath2 = processFilePath+".bmp";
                        
                        fin.open(processFilePath2.c_str(), ios::in);
                        
                        if (fin.is_open()) fin.close();
                        else processFilePath = productsFilesImagePath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+timeString+"-"+fovString;
                    }
                    else fin.close();
                }
            }
            else{
                
                if (channelString == "1"){
                    colorName = fluorescent1;
                    colorNameNo = fluorescentNo1;
                }
                else if (channelString == "2"){
                    colorName = fluorescent2;
                    colorNameNo = fluorescentNo2;
                }
                else if (channelString == "3"){
                    colorName = fluorescent3;
                    colorNameNo = fluorescentNo3;
                }
                else if (channelString == "4"){
                    colorName = fluorescent4;
                    colorNameNo = fluorescentNo4;
                }
                else if (channelString == "5"){
                    colorName = fluorescent5;
                    colorNameNo = fluorescentNo5;
                }
                else if (channelString == "6"){
                    colorName = fluorescent6;
                    colorNameNo = fluorescentNo6;
                }
                
                if (currentTimePoint < lastImageNo){
                    processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString+"_"+colorNameNo+"_"+colorName;
                }
                else if (currentTimePoint == lastImageNo){
                    processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString+"_"+colorNameNo+"_"+colorName;
                    processFilePath2 = processFilePath+".tif";
                    
                    fin.open(processFilePath2.c_str(), ios::in);
                    
                    if (!fin.is_open()){
                        processFilePath2 = processFilePath+".bmp";
                        
                        fin.open(processFilePath2.c_str(), ios::in);
                        
                        if (fin.is_open()) fin.close();
                        else processFilePath = productsFilesImagePath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+timeString+"-"+fovString+"_"+colorNameNo+"_"+colorName;
                    }
                    else fin.close();
                }
            }
            
            processFilePathWithExt = processFilePath+".tif";
            
            fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()) fin.close();
            else{
                
                processFilePathWithExt = processFilePath+".bmp";
                
                fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()) fin.close();
            }
            
            fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
            
            if (!fin.is_open()) fileExistCheck = 1;
            else fin.close();
        }
        
        if (fileExistCheck == 0) imageFindFlag = 0;
        else imageFindFlag = 1;
        
        if (fileExistCheck == 0){
            if (fovNumberCount != 0){
                if (imageDataHoldStatus == 1){
                    int imageSizeTotal = imageDimensionY*loadImageFOVNo;
                    
                    for (int counter1 = 0; counter1 < imageSizeTotal+2; counter1++){
                        delete [] arrayImageDataHold [counter1];
                        delete [] arrayImageRangeAdjust [counter1];
                        delete [] arrayBackgroundDataHold [counter1];
                        delete [] arrayBackgroundDataHold2 [counter1];
                        delete [] arrayImageCutoffAdjust [counter1];
                        delete [] arrayImageContrastAdjust [counter1];
                        delete [] arrayBalanceBaseData [counter1];
                        delete [] arrayBalanceBaseModify [counter1];
                    }
                    
                    delete [] arrayImageDataHold;
                    delete [] arrayImageRangeAdjust;
                    delete [] arrayBackgroundDataHold;
                    delete [] arrayBackgroundDataHold2;
                    delete [] arrayImageCutoffAdjust;
                    delete [] arrayImageContrastAdjust;
                    delete [] arrayBalanceBaseData;
                    delete [] arrayBalanceBaseModify;
                    
                    delete [] xyPositionData;
                    delete [] xyPositionDataHold;
                    delete [] arrayXYWritingPosition;
                    delete [] arrayXYWritingPositionBase;
                    delete [] arrayXYWritingPositionFluorescent;
                    
                    for (int counter1 = 0; counter1 < stitchImageDimension+2; counter1++){
                        delete [] imageDisplayArray [counter1];
                        delete [] imagePositionMap [counter1];
                        delete [] imageDisplayBaseArray [counter1];
                        delete [] imageDisplayFluorescentArray [counter1];
                        delete [] arrayBalanceDataHold [counter1];
                    }
                    
                    delete [] imageDisplayArray;
                    delete [] imagePositionMap;
                    delete [] imageDisplayBaseArray;
                    delete [] imageDisplayFluorescentArray;
                    delete [] arrayBalanceDataHold;
                    
                    delete [] arrayImageDataHistogram;
                    delete [] arrayImageDataHistogramG;
                    delete [] arrayImageDataHistogramB;
                    delete [] arrayImageCutoffAdjustHistogram;
                    delete [] arrayImageCutoffAdjustHistogramG;
                    delete [] arrayImageCutoffAdjustHistogramB;
                    delete [] arrayImageRangeAdjustHistogram;
                    delete [] arrayImageRangeAdjustHistogramG;
                    delete [] arrayImageRangeAdjustHistogramB;
                    delete [] arrayImageContrastAdjustHistogram;
                    delete [] arrayImageContrastAdjustHistogramG;
                    delete [] arrayImageContrastAdjustHistogramB;
                    delete [] arrayImageDataLMH;
                    delete [] arrayImageDataLMHG;
                    delete [] arrayImageDataLMHB;
                    delete [] arrayImageRangeAdjustLMH;
                    delete [] arrayImageRangeAdjustLMHG;
                    delete [] arrayImageRangeAdjustLMHB;
                    delete [] autoContrastCorrectLMH;
                    delete [] autoContrastCorrectLMHG;
                    delete [] autoContrastCorrectLMHB;
                    delete [] autoContrastCorrectLMH2;
                    delete [] autoContrastCorrectLMH2G;
                    delete [] autoContrastCorrectLMH2B;
                    delete [] arrayHorizontalLink;
                    delete [] arrayVerticalLink;
                }
                
                loadImageFOVNo = fovNumberCount;
                int imageSizeTotal = imageDimensionY*loadImageFOVNo;
                
                arrayImageDataHold = new int *[imageSizeTotal+2];
                arrayImageRangeAdjust = new int *[imageSizeTotal+2];
                arrayBackgroundDataHold = new int *[imageSizeTotal+2];
                arrayBackgroundDataHold2 = new int *[imageSizeTotal+2];
                arrayImageCutoffAdjust = new int *[imageSizeTotal+2];
                arrayImageContrastAdjust = new int *[imageSizeTotal+2];
                arrayBalanceBaseData = new int *[imageSizeTotal+2];
                arrayBalanceBaseModify = new int *[imageSizeTotal+2];
                
                imageDataHoldStatus = 1;
                
                for (int counter1 = 0; counter1 < imageSizeTotal+2; counter1++){
                    arrayImageDataHold [counter1] = new int [imageDimensionX*3+2];
                    arrayImageRangeAdjust [counter1] = new int [imageDimensionX*3+2];
                    arrayBackgroundDataHold [counter1] = new int [imageDimensionX+2];
                    arrayBackgroundDataHold2 [counter1] = new int [imageDimensionX+2];
                    arrayImageCutoffAdjust [counter1] = new int [imageDimensionX*3+2];
                    arrayImageContrastAdjust [counter1] = new int [imageDimensionX*3+2];
                    arrayBalanceBaseData [counter1] = new int [imageDimensionX+2];
                    arrayBalanceBaseModify [counter1] = new int [imageDimensionX+2];
                }
                
                xyPositionData = new string [loadImageFOVNo*2+50];
                arrayXYWritingPosition = new int [loadImageFOVNo*2+50];
                arrayXYWritingPositionBase = new int [loadImageFOVNo*2+50];
                arrayXYWritingPositionFluorescent = new int [loadImageFOVNo*2+50];
                xyPositionDataHold = new int [loadImageFOVNo*2+50];
                arrayImageDataHistogram = new int [(loadImageFOVNo+1)*256+50];
                arrayImageDataHistogramG = new int [(loadImageFOVNo+1)*256+50];
                arrayImageDataHistogramB = new int [(loadImageFOVNo+1)*256+50];
                arrayImageCutoffAdjustHistogram = new int [(loadImageFOVNo+1)*256+50];
                arrayImageCutoffAdjustHistogramG = new int [(loadImageFOVNo+1)*256+50];
                arrayImageCutoffAdjustHistogramB = new int [(loadImageFOVNo+1)*256+50];
                
                arrayImageRangeAdjustHistogram = new int [(loadImageFOVNo+1)*256+50];
                arrayImageRangeAdjustHistogramG = new int [(loadImageFOVNo+1)*256+50];
                arrayImageRangeAdjustHistogramB = new int [(loadImageFOVNo+1)*256+50];
                arrayImageContrastAdjustHistogram = new int [(loadImageFOVNo+1)*256+50];
                arrayImageContrastAdjustHistogramG = new int [(loadImageFOVNo+1)*256+50];
                arrayImageContrastAdjustHistogramB = new int [(loadImageFOVNo+1)*256+50];
                arrayImageDataLMH = new int [loadImageFOVNo*3+50];
                arrayImageDataLMHG = new int [loadImageFOVNo*3+50];
                arrayImageDataLMHB = new int [loadImageFOVNo*3+50];
                arrayImageRangeAdjustLMH = new int [loadImageFOVNo*3+50];
                arrayImageRangeAdjustLMHG = new int [loadImageFOVNo*3+50];
                arrayImageRangeAdjustLMHB = new int [loadImageFOVNo*3+50];
                autoContrastCorrectLMH = new int [loadImageFOVNo*3+50];
                autoContrastCorrectLMHG = new int [loadImageFOVNo*3+50];
                autoContrastCorrectLMHB = new int [loadImageFOVNo*3+50];
                autoContrastCorrectLMH2 = new int [loadImageFOVNo*3+50];
                autoContrastCorrectLMH2G = new int [loadImageFOVNo*3+50];
                autoContrastCorrectLMH2B = new int [loadImageFOVNo*3+50];
                arrayHorizontalLink = new string [loadImageFOVNo*3+50];
                arrayVerticalLink = new string [loadImageFOVNo*3+50];
                horizontalLinkCount = 0;
                verticalLinkCount = 0;
                
                for (int counter1 = 0; counter1 < loadImageFOVNo*2+50; counter1++){
                    xyPositionData [counter1] = "";
                    xyPositionDataHold [counter1] = 0;
                    arrayXYWritingPosition [counter1] = 0;
                }
                
                //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
                //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayTableDisplay [counterA*5+counterB];
                //    cout<<" arrayTableDisplay "<<counterA+1<<endl;
                //}
                
                if ((processMode == 2 || processMode == 8 || processMode == 10 || processMode == 3 || processMode == 9 || processMode == 11) && (statusIFHold == 0 || statusIFHold == 3)){
                    int largestX = -10000000;
                    int smallestX = 10000000;
                    int largestY = -10000000;
                    int smallestY = 10000000;
                    int terminationFlag = 0;
                    int imageDimensionCount = 0;
                    int yDimensionCount = 0;
                    int readFlag = 0;
                    int readFlag2 = 0;
                    int readAscII = 0;
                    int treatFind = 0;
                    int entryCount = 0;
                    int extensionType = 0;
                    int verticalBmp = 0;
                    
                    double xyPositionAdjust = 0;
                    
                    //-----Tiff reading-----
                    unsigned long stripFirstAddress = 0;
                    unsigned long stripByteCountAddress = 0;
                    unsigned long nextAddress = 0;
                    unsigned long headPosition = 0;
                    unsigned long stripEntry = 0;
                    long sizeForCopy = 0;
                    
                    double xPosition = 0;
                    double yPosition = 0;
                    
                    int imageWidth = 0;
                    int imageHeight = 0;
                    int imageBit = 0; // Check 8, 16
                    int imageCompression = 0; // Check 1
                    int photoMetric = 0;//check 0, 1, 2
                    int imageDimensionTif = 0;
                    int horizontalBmp = 0;
                    int horizontalBmpEntry = 0;
                    int endianType = 0;
                    int samplePerPix = 0;
                    int dataConversion [4];
                    int processTypeTif = 1;
                    int numberOfLayers = 0;
                    
                    string readData;
                    string getString;
                    string xPositionTemp;
                    string yPositionTemp;
                    
                    struct stat sizeOfFile;
                    
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        extension = to_string(counter1);
                        
                        if (extension.length() == 1) fovString = "FOV00"+extension;
                        else if (extension.length() == 2) fovString = "FOV0"+extension;
                        else if (extension.length() == 3) fovString = "FOV"+extension;
                        
                        if (channelString == ""){
                            if (currentTimePoint < lastImageNo){
                                processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString;
                            }
                            else if (currentTimePoint == lastImageNo){
                                processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString;
                                processFilePath2 = processFilePath+".tif";
                                
                                fin.open(processFilePath2.c_str(), ios::in);
                                
                                if (!fin.is_open()){
                                    processFilePath2 = processFilePath+".bmp";
                                    
                                    fin.open(processFilePath2.c_str(), ios::in);
                                    
                                    if (fin.is_open()) fin.close();
                                    else processFilePath = productsFilesImagePath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+timeString+"-"+fovString;
                                }
                                else fin.close();
                            }
                        }
                        else{
                            
                            if (channelString == "1"){
                                colorName = fluorescent1;
                                colorNameNo = fluorescentNo1;
                            }
                            else if (channelString == "2"){
                                colorName = fluorescent2;
                                colorNameNo = fluorescentNo2;
                            }
                            else if (channelString == "3"){
                                colorName = fluorescent3;
                                colorNameNo = fluorescentNo3;
                            }
                            else if (channelString == "4"){
                                colorName = fluorescent4;
                                colorNameNo = fluorescentNo4;
                            }
                            else if (channelString == "5"){
                                colorName = fluorescent5;
                                colorNameNo = fluorescentNo5;
                            }
                            else if (channelString == "6"){
                                colorName = fluorescent6;
                                colorNameNo = fluorescentNo6;
                            }
                            
                            if (currentTimePoint < lastImageNo){
                                processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString+"_"+colorNameNo+"_"+colorName;
                            }
                            else if (currentTimePoint == lastImageNo){
                                processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString+"_"+colorNameNo+"_"+colorName;
                                processFilePath2 = processFilePath+".tif";
                                
                                fin.open(processFilePath2.c_str(), ios::in);
                                
                                if (!fin.is_open()){
                                    processFilePath2 = processFilePath+".bmp";
                                    
                                    fin.open(processFilePath2.c_str(), ios::in);
                                    
                                    if (fin.is_open()) fin.close();
                                    else processFilePath = productsFilesImagePath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+timeString+"-"+fovString+"_"+colorNameNo+"_"+colorName;
                                }
                                else fin.close();
                            }
                            
                            if (positionAdjustFlag == 1){
                                positionAdjustFlag = 0;
                                imageFirstLoadFlagDisplayFluorescent = 0;
                            }
                        }
                        
                        extensionType = 0;
                        
                        processFilePathWithExt = processFilePath+".tif";
                        
                        fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            extensionType = 1;
                            fin.close();
                        }
                        else{
                            
                            processFilePathWithExt = processFilePath+".bmp";
                            
                            fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                extensionType = 2;
                                fin.close();
                            }
                        }
                        
                        if (extensionType == 1){
                            if (stat(processFilePathWithExt.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                fileReadArray = new uint8_t [sizeForCopy+4];
                                fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
                                
                                fin.read((char*)fileReadArray, sizeForCopy+4);
                                fin.close();
                                
                                dataConversion [0] = fileReadArray [0];
                                dataConversion [1] = fileReadArray [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                int *arrayExtractedImage3 = new int [100];
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = fileReadArray [7];
                                    dataConversion [1] = fileReadArray [6];
                                    dataConversion [2] = fileReadArray [5];
                                    dataConversion [3] = fileReadArray [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = fileReadArray [4];
                                    dataConversion [1] = fileReadArray [5];
                                    dataConversion [2] = fileReadArray [6];
                                    dataConversion [3] = fileReadArray [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                if (endianType == 1){
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                    
                                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                        if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                        else imageDimensionTif = imageHeight;
                                        
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                    }
                                }
                                else if (endianType == 0){
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                    
                                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                        if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                        else imageDimensionTif = imageHeight;
                                        
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                    }
                                }
                                
                                if (photoMetric == 0 || photoMetric == 1) photoMetricHold = 1;
                                else photoMetricHold = 2;
                                
                                verticalBmp = 0;
                                horizontalBmp = 0;
                                horizontalBmpEntry = 0;
                                
                                for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                    if (verticalBmp < imageHeight){
                                        if (horizontalBmp < imageWidth){
                                            if (photoMetric <= 1){
                                                arrayImageDataHold [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3]);
                                                arrayImageRangeAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3]);
                                                arrayImageCutoffAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3]);
                                                arrayImageContrastAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3]);
                                                
                                                horizontalBmpEntry++;
                                            }
                                            else if (photoMetric == 2){
                                                arrayImageDataHold [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3]);
                                                arrayImageRangeAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3]);
                                                arrayImageCutoffAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3]);
                                                arrayImageContrastAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3]);
                                                horizontalBmpEntry++;
                                                
                                                arrayImageDataHold [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+1]);
                                                arrayImageRangeAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+1]);
                                                arrayImageCutoffAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+1]);
                                                arrayImageContrastAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+1]);
                                                horizontalBmpEntry++;
                                                
                                                arrayImageDataHold [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+2]);
                                                arrayImageRangeAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+2]);
                                                arrayImageCutoffAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+2]);
                                                arrayImageContrastAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+2]);
                                                
                                                horizontalBmpEntry++;
                                            }
                                            
                                            horizontalBmp++;
                                        }
                                        
                                        if (horizontalBmp == imageWidth && imageWidth < imageDimensionX){
                                            for (int counter6 = 0; counter6 < imageDimensionX-imageWidth; counter6++){
                                                if (photoMetric <= 1){
                                                    arrayImageDataHold [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageRangeAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageCutoffAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageContrastAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    
                                                    horizontalBmpEntry++;
                                                }
                                                else if (photoMetric == 2){
                                                    arrayImageDataHold [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageRangeAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageCutoffAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageContrastAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    horizontalBmpEntry++;
                                                    
                                                    arrayImageDataHold [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageRangeAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageCutoffAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageContrastAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    horizontalBmpEntry++;
                                                    
                                                    arrayImageDataHold [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageRangeAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageCutoffAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageContrastAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    
                                                    horizontalBmpEntry++;
                                                }
                                            }
                                        }
                                        
                                        if (horizontalBmp == imageWidth){
                                            horizontalBmp = 0;
                                            horizontalBmpEntry = 0;
                                            imageDimensionCount++;
                                            verticalBmp++;
                                        }
                                    }
                                }
                                
                                if (imageHeight < imageDimensionY){
                                    for (int counter5 = imageHeight; counter5 < imageDimensionY; counter5++){
                                        for (int counter6 = 0; counter6 < imageDimensionX; counter6++){
                                            if (photoMetric <= 1){
                                                arrayImageDataHold [counter5][counter6] = -1;
                                                arrayImageRangeAdjust [counter5][counter6] = -1;
                                                arrayImageCutoffAdjust [counter5][counter6] = -1;
                                                arrayImageContrastAdjust [counter5][counter6] = -1; //-----Fill blank part with -1
                                            }
                                            else if (photoMetric == 2){
                                                arrayImageDataHold [counter5][counter6] = -1;
                                                arrayImageRangeAdjust [counter5][counter6] = -1;
                                                arrayImageCutoffAdjust [counter5][counter6] = -1;
                                                arrayImageContrastAdjust [counter5][counter6] = -1;
                                                
                                                arrayImageDataHold [counter5][counter6] = -1;
                                                arrayImageRangeAdjust [counter5][counter6] = -1;
                                                arrayImageCutoffAdjust [counter5][counter6] = -1;
                                                arrayImageContrastAdjust [counter5][counter6] = -1;
                                                
                                                arrayImageDataHold [counter5][counter6] = -1;
                                                arrayImageRangeAdjust [counter5][counter6] = -1;
                                                arrayImageCutoffAdjust [counter5][counter6]= -1;
                                                arrayImageContrastAdjust [counter5][counter6] = -1;
                                            }
                                        }
                                    }
                                }
                                
                                if (objectiveType == "1"){
                                    stringstream extension1;
                                    extension1 << yPosition;
                                    extension = extension1.str();
                                    
                                    xyPositionData [counter1*2] = extension;
                                    
                                    stringstream extension2;
                                    extension2 << xPosition;
                                    extension = extension2.str();
                                    
                                    xyPositionData [counter1*2+1] = extension;
                                }
                                else if (objectiveType == "2"){
                                    stringstream extension1;
                                    extension1 << yPosition*2;
                                    extension = extension1.str();
                                    
                                    xyPositionData [counter1*2] = extension;
                                    
                                    stringstream extension2;
                                    extension2 << xPosition*2;
                                    extension = extension2.str();
                                    
                                    xyPositionData [counter1*2+1] = extension;
                                }
                                else if (objectiveType == "3"){
                                    stringstream extension1;
                                    extension1 << yPosition*4;
                                    extension = extension1.str();
                                    
                                    xyPositionData [counter1*2] = extension;
                                    
                                    stringstream extension2;
                                    extension2 << xPosition*4;
                                    extension = extension2.str();
                                    
                                    xyPositionData [counter1*2+1] = extension;
                                }
                                
                                delete [] fileReadArray;
                                delete [] arrayExtractedImage3;
                                
                                colorNameHold = "nil";
                                colorNoHold = "nil";
                                colorNameHoldStatus = 0;
                                
                                if (channelString == "" && photoMetric == 1){
                                    colorNameHold = "Gray";
                                }
                                else if (channelString == "" && photoMetric == 2){
                                    if (tableColorStatus == 0) colorNameHold = "Color R";
                                    else if (tableColorStatus == 1) colorNameHold = "Color G";
                                    else if (tableColorStatus == 2) colorNameHold = "Color B";
                                    
                                }
                                else if (channelString != ""){
                                    colorNameHold = colorName;
                                    colorNoHold = colorNameNo;
                                    colorNameHoldStatus = 1;
                                }
                                
                                colorNameDisplayCall = 1;
                            }
                        }
                        else if (extensionType == 2){
                            if (stat(processFilePathWithExt.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy];
                                fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.read((char*)uploadTemp, sizeForCopy+1);
                                    fin.close();
                                    
                                    for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                            arrayImageDataHold [imageDimensionCount][counter3] = uploadTemp [1078+counter2*imageDimensionY+counter3];
                                            arrayImageRangeAdjust [imageDimensionCount][counter3] = uploadTemp [1078+counter2*imageDimensionY+counter3];
                                            arrayImageCutoffAdjust [imageDimensionCount][counter3] = uploadTemp [1078+counter2*imageDimensionY+counter3];
                                            arrayImageContrastAdjust [imageDimensionCount][counter3] = uploadTemp [1078+counter2*imageDimensionY+counter3];
                                        }
                                        
                                        imageDimensionCount++;
                                    }
                                }
                                
                                delete [] uploadTemp;
                            }
                            
                            yDimensionCount = imageDimensionY;
                            
                            fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
                            fin.seekg((1078+(yDimensionCount-1)*yDimensionCount-1)+imageDimensionX+1);
                            
                            readFlag = 0;
                            readFlag2 = 0;
                            readData = "";
                            
                            ascIIconversion = [[ASCIIconversion alloc] init];
                            
                            do{
                                
                                terminationFlag = 1;
                                readAscII = fin.get();
                                
                                if (readFlag == 1 && readAscII == 88){
                                    if (objectiveType == "1"){
                                        xyPositionData [counter1*2+1] = readData;
                                        readFlag = 2;
                                    }
                                    else if (objectiveType == "2"){
                                        xyPositionAdjust = atof(readData.c_str());
                                        xyPositionAdjust = xyPositionAdjust*2;
                                        
                                        stringstream extension1;
                                        extension1 << xyPositionAdjust;
                                        extension = extension1.str();
                                        
                                        xyPositionData [counter1*2+1] = extension;
                                        readFlag = 2;
                                    }
                                    else if (objectiveType == "3"){
                                        xyPositionAdjust = atof(readData.c_str());
                                        xyPositionAdjust = xyPositionAdjust*4;
                                        
                                        stringstream extension1;
                                        extension1 << xyPositionAdjust;
                                        extension = extension1.str();
                                        
                                        xyPositionData [counter1*2+1] = extension;
                                        readFlag = 2;
                                    }
                                }
                                
                                if (readFlag == 0 && readAscII == 88) readFlag = 1;
                                else if (readFlag == 1 && readAscII != 88){
                                    [ascIIconversion ascIIConversion2:readAscII];
                                    readData = readData+ascIIstring;
                                }
                                
                                if (readFlag2 == 1 && readAscII == 89){
                                    if (objectiveType == "1"){
                                        xyPositionData [counter1*2] = readData;
                                    }
                                    else if (objectiveType == "2"){
                                        xyPositionAdjust = atof(readData.c_str());
                                        xyPositionAdjust = xyPositionAdjust*2;
                                        
                                        stringstream extension1;
                                        extension1 << xyPositionAdjust;
                                        extension = extension1.str();
                                        
                                        xyPositionData [counter1*2] = extension;
                                    }
                                    else if (objectiveType == "3"){
                                        xyPositionAdjust = atof(readData.c_str());
                                        xyPositionAdjust = xyPositionAdjust*4;
                                        
                                        stringstream extension1;
                                        extension1 << xyPositionAdjust;
                                        extension = extension1.str();
                                        
                                        xyPositionData [counter1*2] = extension;
                                    }
                                    
                                    terminationFlag = 0;
                                }
                                
                                if (readFlag2 == 0 && readAscII == 89) readFlag2 = 1, readData = "";
                                else if (readFlag2 == 1 && readAscII != 89){
                                    [ascIIconversion ascIIConversion2:readAscII];
                                    readData = readData+ascIIstring;
                                }
                                
                            } while (terminationFlag == 1);
                            
                            fin.close();
                            
                            colorNameHold = "nil";
                            colorNoHold = "nil";
                            
                            if (channelString == ""){
                                colorNameHold = "Gray";
                            }
                            else if (channelString != ""){
                                colorNameHold = colorName;
                                colorNoHold = colorNameNo;
                                colorNameHoldStatus = 1;
                            }
                            
                            photoMetricHold = 1;
                            colorNameDisplayCall = 1;
                        }
                    }
                    
                    if (xyInvert == 1){
                        string xPositionSW;
                        
                        for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                            xPositionSW = xyPositionData [counter1*2];
                            xyPositionData [counter1*2] = xyPositionData [counter1*2+1];
                            xyPositionData [counter1*2+1] = xPositionSW;
                        }
                    }
                    
                    if (xOrientation == 1){
                        double minXPosition = 0;
                        double maxXPosition = 0;
                        double centerXPosition = 0;
                        double newPosition = 0;
                        
                        for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                            if (maxXPosition < atof(xyPositionData [counter1*2].c_str())) maxXPosition = atof(xyPositionData [counter1*2].c_str());
                            if (minXPosition > atof(xyPositionData [counter1*2].c_str())) minXPosition = atof(xyPositionData [counter1*2].c_str());
                        }
                        
                        centerXPosition = (maxXPosition-minXPosition)/(double)2;
                        
                        for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                            if (atof(xyPositionData [counter1*2].c_str()) > centerXPosition){
                                newPosition = (maxXPosition-atof(xyPositionData [counter1*2].c_str()))+minXPosition;
                                
                                stringstream extension1;
                                extension1 << newPosition;
                                extension = extension1.str();
                                
                                xyPositionData [counter1*2] = extension;
                            }
                            else  if (atof(xyPositionData [counter1*2].c_str()) <= centerXPosition){
                                newPosition = maxXPosition-(atof(xyPositionData [counter1*2].c_str())-minXPosition);
                                
                                stringstream extension1;
                                extension1 << newPosition;
                                extension = extension1.str();
                                
                                xyPositionData [counter1*2] = extension;
                            }
                        }
                    }
                    
                    if (yOrientation == 1){
                        double minXPosition = 0;
                        double maxXPosition = 0;
                        double centerXPosition = 0;
                        double newPosition = 0;
                        
                        for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                            if (maxXPosition < atof(xyPositionData [counter1*2+1].c_str())) maxXPosition = atof(xyPositionData [counter1*2+1].c_str());
                            if (minXPosition > atof(xyPositionData [counter1*2+1].c_str())) minXPosition = atof(xyPositionData [counter1*2+1].c_str());
                        }
                        
                        centerXPosition = (maxXPosition-minXPosition)/(double)2;
                        
                        for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                            if (atof(xyPositionData [counter1*2+1].c_str()) > centerXPosition){
                                newPosition = (maxXPosition-atof(xyPositionData [counter1*2+1].c_str()))+minXPosition;
                                
                                stringstream extension1;
                                extension1 << newPosition;
                                extension = extension1.str();
                                
                                xyPositionData [counter1*2+1] = extension;
                            }
                            else  if (atof(xyPositionData [counter1*2+1].c_str()) <= centerXPosition){
                                newPosition = maxXPosition-(atof(xyPositionData [counter1*2+1].c_str())-minXPosition);
                                
                                stringstream extension1;
                                extension1 << newPosition;
                                extension = extension1.str();
                                
                                xyPositionData [counter1*2+1] = extension;
                            }
                        }
                    }
                    
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        if (largestX < atof(xyPositionData [counter1*2].c_str())) largestX = (int)(atof(xyPositionData [counter1*2].c_str()));
                        if (smallestX > atof(xyPositionData [counter1*2].c_str())) smallestX = (int)(atof(xyPositionData [counter1*2].c_str()));
                        if (largestY < atof(xyPositionData [counter1*2+1].c_str())) largestY = (int)(atof(xyPositionData [counter1*2+1].c_str()));
                        if (smallestY > atof(xyPositionData [counter1*2+1].c_str())) smallestY = (int)(atof(xyPositionData [counter1*2+1].c_str()));
                    }
                    
                    int stitchDimensionTemp = 0;
                    int startX = 0;
                    int startY = 0;
                    
                    if (largestX-smallestX > largestY-smallestY){
                        stitchDimensionTemp = ((largestX-smallestX+imageDimensionX)/4)*4;
                        startX = smallestX-80;
                        startY = smallestY-(stitchDimensionTemp-(largestY-smallestY+imageDimensionY))/2-80;
                    }
                    else{
                        
                        stitchDimensionTemp = ((largestY-smallestY+imageDimensionY)/4)*4;
                        startX = smallestX-(stitchDimensionTemp-(largestX-smallestX+imageDimensionX))/2-80;
                        startY = smallestY-80;
                    }
                    
                    int stitchImageDimensionTemp1 = 0;
                    
                    if (statusIFHold == 0) stitchImageDimension = stitchDimensionTemp+160;
                    else{
                        
                        string bodyNameTemp;
                        string productsFilesInfoTempPath;
                        string treatNameTemp;
                        
                        if ((int)bodyName.find("IF") != -1){
                            bodyNameTemp = bodyName.substr(0, bodyName.find("IF"));
                            
                            productsFilesInfoTempPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyNameTemp+"_Products"+"/"+"Analysis_Information/CT-FOVPosition";
                            
                            treatNameTemp = loadImageTreatName.substr(loadImageTreatName.length()-3);
                            
                            if (treatNameTemp.find("CH") == 0) treatNameTemp = loadImageTreatName.substr(0, treatNameTemp.find("CH")-3);
                            else treatNameTemp = loadImageTreatName;
                            
                            fin.open(productsFilesInfoTempPath.c_str(), ios::in);
                            
                            if (fin.is_open()){
                                stitchImageDimensionTemp1 = 0;
                                terminationFlag = 0;
                                
                                do{
                                    
                                    getline(fin, getString);
                                    
                                    if (treatNameTemp == getString){
                                        getline(fin, getString);
                                        
                                        stitchImageDimensionTemp1 = atoi(getString.c_str());
                                        break;
                                    }
                                    
                                    if (getString == "") terminationFlag = 1;
                                    
                                } while (terminationFlag == 0);
                                
                                if (stitchImageDimensionTemp1 == 0) stitchImageDimension = stitchDimensionTemp+160;
                                else stitchImageDimension = stitchImageDimensionTemp1;
                                
                                fin.close();
                            }
                            else stitchImageDimension = stitchDimensionTemp+160;
                        }
                        else stitchImageDimension = stitchDimensionTemp+160;
                    }
                    
                    if (stat(fovPositionPath.c_str(), &sizeOfFile) == 0){
                        treatFind = 0;
                        
                        fin.open(fovPositionPath.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            do{
                                
                                getline(fin, getString);
                                
                                if (loadImageTreatName == getString){
                                    getline(fin, getString);
                                    
                                    stitchImageDimension = atoi(getString.c_str());
                                    treatFind = 1;
                                    break;
                                }
                                
                            } while (getString != "");
                            
                            fin.close();
                        }
                        
                        if (treatFind == 1){
                            for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                                xyPositionDataHold [counter1*2] = stitchImageDimension-((int)(atof(xyPositionData [counter1*2].c_str()))-startX)-imageDimensionX;
                                xyPositionDataHold [counter1*2+1] = (int)(atof(xyPositionData [counter1*2+1].c_str()))-startY;
                            }
                            
                            entryCount = 2;
                            treatFind = 0;
                            
                            fin.open(fovPositionPath.c_str(), ios::in);
                            
                            if (fin.is_open()){
                                do{
                                    
                                    getline(fin, getString);
                                    
                                    if (loadImageTreatName == getString && treatFind == 0){
                                        treatFind = 1;
                                        getline(fin, getString);
                                    }
                                    else if (getString != "ND" && treatFind == 1) arrayXYWritingPosition [entryCount] = atoi(getString.c_str()), entryCount++;
                                    else if (getString == "ND" && treatFind == 1) treatFind = 2;
                                    
                                } while (getString != "");
                                
                                fin.close();
                            }
                        }
                        else{
                            
                            for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                                arrayXYWritingPosition [counter1*2] = stitchImageDimension-((int)(atof(xyPositionData [counter1*2].c_str()))-startX)-imageDimensionX;
                                arrayXYWritingPosition [counter1*2+1] = (int)(atof(xyPositionData [counter1*2+1].c_str()))-startY;
                                
                                xyPositionDataHold [counter1*2] = stitchImageDimension-((int)(atof(xyPositionData [counter1*2].c_str()))-startX)-imageDimensionX;
                                xyPositionDataHold [counter1*2+1] = (int)(atof(xyPositionData [counter1*2+1].c_str()))-startY;
                            }
                        }
                    }
                    else{
                        
                        for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                            arrayXYWritingPosition [counter1*2] = stitchImageDimension-((int)(atof(xyPositionData [counter1*2].c_str()))-startX)-imageDimensionX;
                            arrayXYWritingPosition [counter1*2+1] = (int)(atof(xyPositionData [counter1*2+1].c_str()))-startY;
                            
                            xyPositionDataHold [counter1*2] = stitchImageDimension-((int)(atof(xyPositionData [counter1*2].c_str()))-startX)-imageDimensionX;
                            xyPositionDataHold [counter1*2+1] = (int)(atof(xyPositionData [counter1*2+1].c_str()))-startY;
                        }
                    }
                }
                else{
                    
                    int imageDimensionCount = 0;
                    int extensionType = 0;
                    int verticalBmp = 0;
                    
                    //-----Tiff reading-----
                    unsigned long stripFirstAddress = 0;
                    unsigned long stripByteCountAddress = 0;
                    unsigned long nextAddress = 0;
                    unsigned long headPosition = 0;
                    unsigned long stripEntry = 0;
                    long sizeForCopy = 0;
                    
                    double xPosition = 0;
                    double yPosition = 0;
                    
                    int imageWidth = 0;
                    int imageHeight = 0;
                    int imageBit = 0; // Check 8, 16
                    int imageCompression = 0; // Check 1
                    int photoMetric = 0;//check 0, 1, 2
                    int imageDimensionTif = 0;
                    int horizontalBmp = 0;
                    int horizontalBmpEntry = 0;
                    int endianType = 0;
                    int samplePerPix = 0;
                    int dataConversion [4];
                    int processTypeTif = 1;
                    int numberOfLayers = 0;
                    
                    struct stat sizeOfFile;
                    
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        extension = to_string(counter1);
                        
                        if (extension.length() == 1) fovString = "FOV00"+extension;
                        else if (extension.length() == 2) fovString = "FOV0"+extension;
                        else if (extension.length() == 3) fovString = "FOV"+extension;
                        
                        if (channelString == ""){
                            if (currentTimePoint < lastImageNo){
                                processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString;
                            }
                            else if (currentTimePoint == lastImageNo){
                                processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString;
                                processFilePath2 = processFilePath+".tif";
                                
                                fin.open(processFilePath2.c_str(), ios::in);
                                
                                if (!fin.is_open()){
                                    processFilePath2 = processFilePath+".bmp";
                                    
                                    fin.open(processFilePath2.c_str(), ios::in);
                                    
                                    if (fin.is_open()) fin.close();
                                    else processFilePath = productsFilesImagePath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+timeString+"-"+fovString;
                                }
                                else fin.close();
                            }
                        }
                        else{
                            
                            if (channelString == "1"){
                                colorName = fluorescent1;
                                colorNameNo = fluorescentNo1;
                            }
                            else if (channelString == "2"){
                                colorName = fluorescent2;
                                colorNameNo = fluorescentNo2;
                            }
                            else if (channelString == "3"){
                                colorName = fluorescent3;
                                colorNameNo = fluorescentNo3;
                            }
                            else if (channelString == "4"){
                                colorName = fluorescent4;
                                colorNameNo = fluorescentNo4;
                            }
                            else if (channelString == "5"){
                                colorName = fluorescent5;
                                colorNameNo = fluorescentNo5;
                            }
                            else if (channelString == "6"){
                                colorName = fluorescent6;
                                colorNameNo = fluorescentNo6;
                            }
                            
                            if (currentTimePoint < lastImageNo){
                                processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString+"_"+colorNameNo+"_"+colorName;
                            }
                            else if (currentTimePoint == lastImageNo){
                                processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString+"_"+colorNameNo+"_"+colorName;
                                processFilePath2 = processFilePath+".tif";
                                
                                fin.open(processFilePath2.c_str(), ios::in);
                                
                                if (!fin.is_open()){
                                    processFilePath2 = processFilePath+".bmp";
                                    
                                    fin.open(processFilePath2.c_str(), ios::in);
                                    
                                    if (fin.is_open()) fin.close();
                                    else processFilePath = productsFilesImagePath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+timeString+"-"+fovString+"_"+colorNameNo+"_"+colorName;
                                }
                                else fin.close();
                            }
                            
                            if (positionAdjustFlag == 1){
                                positionAdjustFlag = 0;
                                imageFirstLoadFlagDisplayFluorescent = 0;
                            }
                        }
                        
                        extensionType = 0;
                        
                        processFilePathWithExt = processFilePath+".tif";
                        
                        fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            extensionType = 1;
                            fin.close();
                        }
                        else{
                            
                            processFilePathWithExt = processFilePath+".bmp";
                            
                            fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                extensionType = 2;
                                fin.close();
                            }
                        }
                        
                        if (extensionType == 1){
                            if (stat(processFilePathWithExt.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                fileReadArray = new uint8_t [sizeForCopy+4];
                                fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
                                
                                fin.read((char*)fileReadArray, sizeForCopy+4);
                                fin.close();
                                
                                dataConversion [0] = fileReadArray [0];
                                dataConversion [1] = fileReadArray [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                int *arrayExtractedImage3 = new int [100];
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = fileReadArray [7];
                                    dataConversion [1] = fileReadArray [6];
                                    dataConversion [2] = fileReadArray [5];
                                    dataConversion [3] = fileReadArray [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = fileReadArray [4];
                                    dataConversion [1] = fileReadArray [5];
                                    dataConversion [2] = fileReadArray [6];
                                    dataConversion [3] = fileReadArray [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                if (endianType == 1){
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                    
                                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                        if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                        else imageDimensionTif = imageHeight;
                                        
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                    }
                                }
                                else if (endianType == 0){
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                    
                                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                        if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                        else imageDimensionTif = imageHeight;
                                        
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                    }
                                }
                                
                                if (photoMetric == 0 || photoMetric == 1) photoMetricHold = 1;
                                else photoMetricHold = 2;
                                
                                verticalBmp = 0;
                                horizontalBmp = 0;
                                horizontalBmpEntry = 0;
                                
                                for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                    if (verticalBmp < imageHeight){
                                        if (horizontalBmp < imageWidth){
                                            if (photoMetric <= 1){
                                                arrayImageDataHold [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3]);
                                                arrayImageRangeAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3]);
                                                arrayImageCutoffAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3]);
                                                arrayImageContrastAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3]);
                                                
                                                horizontalBmpEntry++;
                                            }
                                            else if (photoMetric == 2){
                                                arrayImageDataHold [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3]);
                                                arrayImageRangeAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3]);
                                                arrayImageCutoffAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3]);
                                                arrayImageContrastAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3]);
                                                horizontalBmpEntry++;
                                                
                                                arrayImageDataHold [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+1]);
                                                arrayImageRangeAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+1]);
                                                arrayImageCutoffAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+1]);
                                                arrayImageContrastAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+1]);
                                                horizontalBmpEntry++;
                                                
                                                arrayImageDataHold [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+2]);
                                                arrayImageRangeAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+2]);
                                                arrayImageCutoffAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+2]);
                                                arrayImageContrastAdjust [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+2]);
                                                
                                                horizontalBmpEntry++;
                                            }
                                            
                                            horizontalBmp++;
                                        }
                                        
                                        if (horizontalBmp == imageWidth && imageWidth < imageDimensionX){
                                            for (int counter6 = 0; counter6 < imageDimensionX-imageWidth; counter6++){
                                                if (photoMetric <= 1){
                                                    arrayImageDataHold [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageRangeAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageCutoffAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageContrastAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    
                                                    horizontalBmpEntry++;
                                                }
                                                else if (photoMetric == 2){
                                                    arrayImageDataHold [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageRangeAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageCutoffAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageContrastAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    horizontalBmpEntry++;
                                                    
                                                    arrayImageDataHold [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageRangeAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageCutoffAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageContrastAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    horizontalBmpEntry++;
                                                    
                                                    arrayImageDataHold [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageRangeAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageCutoffAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    arrayImageContrastAdjust [imageDimensionCount][horizontalBmpEntry] = -1;
                                                    
                                                    horizontalBmpEntry++;
                                                }
                                            }
                                        }
                                        
                                        if (horizontalBmp == imageWidth){
                                            horizontalBmp = 0;
                                            horizontalBmpEntry = 0;
                                            imageDimensionCount++;
                                            verticalBmp++;
                                        }
                                    }
                                }
                                
                                if (imageHeight < imageDimensionY){
                                    for (int counter5 = imageHeight; counter5 < imageDimensionY; counter5++){
                                        for (int counter6 = 0; counter6 < imageDimensionX; counter6++){
                                            if (photoMetric <= 1){
                                                arrayImageDataHold [counter5][counter6] = -1;
                                                arrayImageRangeAdjust [counter5][counter6] = -1;
                                                arrayImageCutoffAdjust [counter5][counter6] = -1;
                                                arrayImageContrastAdjust [counter5][counter6] = -1; //-----Fill blank part with -1
                                            }
                                            else if (photoMetric == 2){
                                                arrayImageDataHold [counter5][counter6] = -1;
                                                arrayImageRangeAdjust [counter5][counter6] = -1;
                                                arrayImageCutoffAdjust [counter5][counter6] = -1;
                                                arrayImageContrastAdjust [counter5][counter6] = -1;
                                                
                                                arrayImageDataHold [counter5][counter6] = -1;
                                                arrayImageRangeAdjust [counter5][counter6] = -1;
                                                arrayImageCutoffAdjust [counter5][counter6] = -1;
                                                arrayImageContrastAdjust [counter5][counter6] = -1;
                                                
                                                arrayImageDataHold [counter5][counter6] = -1;
                                                arrayImageRangeAdjust [counter5][counter6] = -1;
                                                arrayImageCutoffAdjust [counter5][counter6]= -1;
                                                arrayImageContrastAdjust [counter5][counter6] = -1;
                                            }
                                        }
                                    }
                                }
                                
                                delete [] fileReadArray;
                                delete [] arrayExtractedImage3;
                                
                                colorNameHold = "nil";
                                colorNoHold = "nil";
                                colorNameHoldStatus = 0;
                                
                                if (channelString == "" && photoMetric == 1){
                                    colorNameHold = "Gray";
                                }
                                else if (channelString == "" && photoMetric == 2){
                                    if (tableColorStatus == 0) colorNameHold = "Color R";
                                    else if (tableColorStatus == 1) colorNameHold = "Color G";
                                    else if (tableColorStatus == 2) colorNameHold = "Color B";
                                    
                                }
                                else if (channelString != ""){
                                    colorNameHold = colorName;
                                    colorNoHold = colorNameNo;
                                    colorNameHoldStatus = 1;
                                }
                            }
                        }
                        else if (extensionType == 2){
                            if (stat(processFilePathWithExt.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy];
                                fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.read((char*)uploadTemp, sizeForCopy+1);
                                    fin.close();
                                    
                                    for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                            arrayImageDataHold [imageDimensionCount][counter3] = uploadTemp [1078+counter2*imageDimensionY+counter3];
                                            arrayImageRangeAdjust [imageDimensionCount][counter3] = uploadTemp [1078+counter2*imageDimensionY+counter3];
                                            arrayImageCutoffAdjust [imageDimensionCount][counter3] = uploadTemp [1078+counter2*imageDimensionY+counter3];
                                            arrayImageContrastAdjust [imageDimensionCount][counter3] = uploadTemp [1078+counter2*imageDimensionY+counter3];
                                        }
                                        
                                        imageDimensionCount++;
                                    }
                                }
                                
                                delete [] uploadTemp;
                                
                                photoMetricHold = 1;
                                
                                colorNameHold = "nil";
                                colorNoHold = "nil";
                                
                                if (channelString == ""){
                                    colorNameHold = "Gray";
                                }
                                else if (channelString != ""){
                                    colorNameHold = colorName;
                                    colorNoHold = colorNameNo;
                                    colorNameHoldStatus = 1;
                                }
                            }
                            
                            fin.close();
                        }
                    }
                    
                    int entryCount = 2;
                    int treatFind = 0;
                    string getString;
                    
                    if (processMode == 5 || processMode == 13 || processMode == 7) fin.open(fovPositionTempPath.c_str(), ios::in);
                    else fin.open(fovPositionPath.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        do{
                            
                            getline(fin, getString);
                            
                            if (loadImageTreatName == getString && treatFind == 0){
                                getline(fin, getString);
                                
                                stitchImageDimension = atoi(getString.c_str());
                                treatFind = 1;
                            }
                            else if (getString != "ND" && treatFind == 1){
                                arrayXYWritingPosition [entryCount] = atoi(getString.c_str());
                                xyPositionDataHold [entryCount] = atoi(getString.c_str()), entryCount++;
                            }
                            else if (getString == "ND" && treatFind == 1) treatFind = 2;
                            
                        } while (getString != "");
                        
                        fin.close();
                    }
                }
                
                //for (int counterA = 0; counterA <= loadImageFOVNo; counterA++){
                //    cout<<counterA<<" "<<arrayXYWritingPosition [counterA*2]<<" "<<arrayXYWritingPosition [counterA*2+1]<<"  xyPosition"<<endl;
                //}
                
                imageDisplayArray = new int *[stitchImageDimension+2];
                imagePositionMap = new int *[stitchImageDimension+2];
                imageDisplayBaseArray = new int *[stitchImageDimension+2];
                imageDisplayFluorescentArray = new int *[stitchImageDimension+2];
                arrayBalanceDataHold = new int *[stitchImageDimension+2];
                
                for (int counter1 = 0; counter1 < stitchImageDimension+2; counter1++){
                    imageDisplayArray [counter1] = new int [stitchImageDimension*3+2];
                    imagePositionMap [counter1] = new int [stitchImageDimension*3+2];
                    imageDisplayBaseArray [counter1] = new int [stitchImageDimension+2];
                    imageDisplayFluorescentArray [counter1] = new int [stitchImageDimension+2];
                    arrayBalanceDataHold [counter1] = new int [stitchImageDimension+2];
                }
                
                //========Histogram data set=======
                int *histogramTemp = new int [256];
                
                if (photoMetricHold == 1){
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                        
                        for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                if (arrayImageDataHold [(counter1-1)*imageDimensionY+counter2][counter3] >= 0){
                                    histogramTemp [arrayImageDataHold [(counter1-1)*imageDimensionY+counter2][counter3]]++;
                                }
                            }
                        }
                        
                        for (int counter2 = 0; counter2 <= 255; counter2++){
                            arrayImageDataHistogram [(counter1-1)*256+counter2] = histogramTemp [counter2];
                            arrayImageRangeAdjustHistogram [(counter1-1)*256+counter2] = histogramTemp [counter2];
                            arrayImageCutoffAdjustHistogram [(counter1-1)*256+counter2] = histogramTemp [counter2];
                            arrayImageContrastAdjustHistogram [(counter1-1)*256+counter2] = histogramTemp [counter2];
                        }
                    }
                    
                    for (int counter1 = 0; counter1 <= 255; counter1++) histogramTemp [counter1] = 0;
                    
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 < 256; counter2++){
                            histogramTemp [counter2] = histogramTemp [counter2]+arrayImageDataHistogram [(counter1-1)*256+counter2];
                        }
                    }
                    
                    for (int counter1 = 1; counter1 <= 255; counter1++){
                        arrayImageDataHistogram [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                        arrayImageRangeAdjustHistogram [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                        arrayImageCutoffAdjustHistogram [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                        arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                    }
                }
                else if (photoMetricHold == 2){
                    //=====R range set=====
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                        
                        for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                if (arrayImageDataHold [(counter1-1)*imageDimensionY+counter2][counter3*3] >= 0){
                                    histogramTemp [arrayImageDataHold [(counter1-1)*imageDimensionY+counter2][counter3*3]]++;
                                }
                            }
                        }
                        
                        for (int counter2 = 0; counter2 <= 255; counter2++){
                            arrayImageDataHistogram [(counter1-1)*256+counter2] = histogramTemp [counter2];
                            arrayImageRangeAdjustHistogram [(counter1-1)*256+counter2] = histogramTemp [counter2];
                            arrayImageCutoffAdjustHistogram [(counter1-1)*256+counter2] = histogramTemp [counter2];
                            arrayImageContrastAdjustHistogram [(counter1-1)*256+counter2] = histogramTemp [counter2];
                        }
                    }
                    
                    for (int counter1 = 0; counter1 <= 255; counter1++) histogramTemp [counter1] = 0;
                    
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 < 256; counter2++){
                            histogramTemp [counter2] = histogramTemp [counter2]+arrayImageDataHistogram [(counter1-1)*256+counter2];
                        }
                    }
                    
                    for (int counter1 = 1; counter1 <= 255; counter1++){
                        arrayImageDataHistogram [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                        arrayImageRangeAdjustHistogram [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                        arrayImageCutoffAdjustHistogram [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                        arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                    }
                    
                    //=====G range set=====
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                        
                        for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                if (arrayImageDataHold [(counter1-1)*imageDimensionY+counter2][counter3*3+1] >= 0){
                                    histogramTemp [arrayImageDataHold [(counter1-1)*imageDimensionY+counter2][counter3*3+1]]++;
                                }
                            }
                        }
                        
                        for (int counter2 = 0; counter2 <= 255; counter2++){
                            arrayImageDataHistogramG [(counter1-1)*256+counter2] = histogramTemp [counter2];
                            arrayImageRangeAdjustHistogramG [(counter1-1)*256+counter2] = histogramTemp [counter2];
                            arrayImageCutoffAdjustHistogramG [(counter1-1)*256+counter2] = histogramTemp [counter2];
                            arrayImageContrastAdjustHistogramG [(counter1-1)*256+counter2] = histogramTemp [counter2];
                        }
                    }
                    
                    for (int counter1 = 0; counter1 <= 255; counter1++) histogramTemp [counter1] = 0;
                    
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 < 256; counter2++){
                            histogramTemp [counter2] = histogramTemp [counter2]+arrayImageDataHistogramG [(counter1-1)*256+counter2];
                        }
                    }
                    
                    for (int counter1 = 1; counter1 <= 255; counter1++){
                        arrayImageDataHistogramG [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                        arrayImageRangeAdjustHistogramG [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                        arrayImageCutoffAdjustHistogramG [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                        arrayImageContrastAdjustHistogramG [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                    }
                    
                    //=====B range set=====
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                        
                        for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                if (arrayImageDataHold [(counter1-1)*imageDimensionY+counter2][counter3*3+2] >= 0){
                                    histogramTemp [arrayImageDataHold [(counter1-1)*imageDimensionY+counter2][counter3*3+2]]++;
                                }
                            }
                        }
                        
                        for (int counter2 = 0; counter2 <= 255; counter2++){
                            arrayImageDataHistogramB [(counter1-1)*256+counter2] = histogramTemp [counter2];
                            arrayImageRangeAdjustHistogramB [(counter1-1)*256+counter2] = histogramTemp [counter2];
                            arrayImageCutoffAdjustHistogramB [(counter1-1)*256+counter2] = histogramTemp [counter2];
                            arrayImageContrastAdjustHistogramB [(counter1-1)*256+counter2] = histogramTemp [counter2];
                        }
                    }
                    
                    for (int counter1 = 0; counter1 <= 255; counter1++) histogramTemp [counter1] = 0;
                    
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 < 256; counter2++){
                            histogramTemp [counter2] = histogramTemp [counter2]+arrayImageDataHistogramB [(counter1-1)*256+counter2];
                        }
                    }
                    
                    for (int counter1 = 1; counter1 <= 255; counter1++){
                        arrayImageDataHistogramB [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                        arrayImageRangeAdjustHistogramB [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                        arrayImageCutoffAdjustHistogramB [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                        arrayImageContrastAdjustHistogramB [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                    }
                }
                
                //for (int counterA = 0; counterA <= 255; counterA++){
                //    cout<<counterA<<" "<<arrayImageDataHistogram [loadImageFOVNo*256+counterA]<<" Histo2"<<endl;
                //}
                
                //for (int counterA = 0; counterA <= 255; counterA++){
                //    cout<<counterA<<" "<<arrayImageDataHistogramG [loadImageFOVNo*256+counterA]<<" Histo2G"<<endl;
                //}
                
                //for (int counterA = 0; counterA <= 255; counterA++){
                //    cout<<counterA<<" "<<arrayImageDataHistogramB [loadImageFOVNo*256+counterA]<<" Histo2B"<<endl;
                //}
                
                //========Low Mean High Data set to each array======
                int numberOfPoint = 0;
                int lowestValueTemp = 0;
                int highestValueTemp = 0;
                int meanValueTemp = 0;
                int lowestValueTempG = 0;
                int highestValueTempG = 0;
                int meanValueTempG = 0;
                int lowestValueTempB = 0;
                int highestValueTempB = 0;
                int meanValueTempB = 0;
                int pixNo90 = 0;
                
                unsigned long totalCount = 0;
                
                for (int counter1 = 0; counter1 <= loadImageFOVNo; counter1++){
                    numberOfPoint = 0;
                    totalCount = 0;
                    lowestValueTemp = 0;
                    highestValueTemp = 0;
                    
                    for (int counter2 = 1; counter2 <= 255; counter2++){
                        numberOfPoint = numberOfPoint+arrayImageDataHistogram [counter1*256+counter2];
                        totalCount = totalCount+(unsigned long)(counter2*arrayImageDataHistogram [counter1*256+counter2]);
                    }
                    
                    if (numberOfPoint != 0) meanValueTemp = (int)(totalCount/(double)numberOfPoint);
                    
                    pixNo90 = arrayImageDataHistogram [counter1*256+meanValueTemp];
                    
                    for (int counter2 = 1; counter2 <= 255; counter2++){
                        if (meanValueTemp-counter2 >= 0){
                            pixNo90 = pixNo90+arrayImageDataHistogram [counter1*256+meanValueTemp-counter2];
                            lowestValueTemp = meanValueTemp-counter2;
                        }
                        
                        if (meanValueTemp+counter2 <= 255){
                            pixNo90 = pixNo90+arrayImageDataHistogram [counter1*256+meanValueTemp+counter2];
                            highestValueTemp = meanValueTemp+counter2;
                        }
                        
                        if (pixNo90/(double)numberOfPoint > 0.8){
                            break;
                        }
                    }
                    
                    arrayImageDataLMH [counter1*3] = lowestValueTemp;
                    arrayImageDataLMH [counter1*3+1] = meanValueTemp;
                    arrayImageDataLMH [counter1*3+2] = highestValueTemp;
                    
                    arrayImageRangeAdjustLMH [counter1*3] = lowestValueTemp;
                    arrayImageRangeAdjustLMH [counter1*3+1] = meanValueTemp;
                    arrayImageRangeAdjustLMH [counter1*3+2] = highestValueTemp;
                    
                    autoContrastCorrectLMH [counter1*3] = lowestValueTemp;
                    autoContrastCorrectLMH [counter1*3+1] = meanValueTemp;
                    autoContrastCorrectLMH [counter1*3+2] = highestValueTemp;
                    
                    autoContrastCorrectLMH2 [counter1*3] = lowestValueTemp;
                    autoContrastCorrectLMH2 [counter1*3+1] = meanValueTemp;
                    autoContrastCorrectLMH2 [counter1*3+2] = highestValueTemp;
                    
                    if (photoMetricHold == 2){
                        numberOfPoint = 0;
                        totalCount = 0;
                        lowestValueTemp = 0;
                        highestValueTemp = 0;
                        
                        for (int counter2 = 1; counter2 <= 255; counter2++){
                            numberOfPoint = numberOfPoint+arrayImageDataHistogramG [counter1*256+counter2];
                            totalCount = totalCount+(unsigned long)(counter2*arrayImageDataHistogramG [counter1*256+counter2]);
                        }
                        
                        if (numberOfPoint != 0) meanValueTemp = (int)(totalCount/(double)numberOfPoint);
                        
                        pixNo90 = arrayImageDataHistogramG [counter1*256+meanValueTemp];
                        
                        for (int counter2 = 1; counter2 <= 255; counter2++){
                            if (meanValueTemp-counter2 >= 0){
                                pixNo90 = pixNo90+arrayImageDataHistogramG [counter1*256+meanValueTemp-counter2];
                                lowestValueTemp = meanValueTemp-counter2;
                            }
                            
                            if (meanValueTemp+counter2 <= 255){
                                pixNo90 = pixNo90+arrayImageDataHistogramG [counter1*256+meanValueTemp+counter2];
                                highestValueTemp = meanValueTemp+counter2;
                            }
                            
                            if (pixNo90/(double)numberOfPoint > 0.8){
                                break;
                            }
                        }
                        
                        arrayImageDataLMHG [counter1*3] = lowestValueTemp;
                        arrayImageDataLMHG [counter1*3+1] = meanValueTemp;
                        arrayImageDataLMHG [counter1*3+2] = highestValueTemp;
                        
                        arrayImageRangeAdjustLMHG [counter1*3] = lowestValueTemp;
                        arrayImageRangeAdjustLMHG [counter1*3+1] = meanValueTemp;
                        arrayImageRangeAdjustLMHG [counter1*3+2] = highestValueTemp;
                        
                        autoContrastCorrectLMHG [counter1*3] = lowestValueTemp;
                        autoContrastCorrectLMHG [counter1*3+1] = meanValueTemp;
                        autoContrastCorrectLMHG [counter1*3+2] = highestValueTemp;
                        
                        autoContrastCorrectLMH2G [counter1*3] = lowestValueTemp;
                        autoContrastCorrectLMH2G [counter1*3+1] = meanValueTemp;
                        autoContrastCorrectLMH2G [counter1*3+2] = highestValueTemp;
                        
                        numberOfPoint = 0;
                        totalCount = 0;
                        lowestValueTemp = 0;
                        highestValueTemp = 0;
                        
                        for (int counter2 = 1; counter2 <= 255; counter2++){
                            numberOfPoint = numberOfPoint+arrayImageDataHistogramB [counter1*256+counter2];
                            totalCount = totalCount+(unsigned long)(counter2*arrayImageDataHistogramB [counter1*256+counter2]);
                        }
                        
                        if (numberOfPoint != 0) meanValueTemp = (int)(totalCount/(double)numberOfPoint);
                        
                        pixNo90 = arrayImageDataHistogramB [counter1*256+meanValueTemp];
                        
                        for (int counter2 = 1; counter2 <= 255; counter2++){
                            if (meanValueTemp-counter2 >= 0){
                                pixNo90 = pixNo90+arrayImageDataHistogramB [counter1*256+meanValueTemp-counter2];
                                lowestValueTemp = meanValueTemp-counter2;
                            }
                            if (meanValueTemp+counter2 <= 255){
                                pixNo90 = pixNo90+arrayImageDataHistogramB [counter1*256+meanValueTemp+counter2];
                                highestValueTemp = meanValueTemp+counter2;
                            }
                            if (pixNo90/(double)numberOfPoint > 0.8){
                                break;
                            }
                        }
                        
                        arrayImageDataLMHB [counter1*3] = lowestValueTemp;
                        arrayImageDataLMHB [counter1*3+1] = meanValueTemp;
                        arrayImageDataLMHB [counter1*3+2] = highestValueTemp;
                        
                        arrayImageRangeAdjustLMHB [counter1*3] = lowestValueTemp;
                        arrayImageRangeAdjustLMHB [counter1*3+1] = meanValueTemp;
                        arrayImageRangeAdjustLMHB [counter1*3+2] = highestValueTemp;
                        
                        autoContrastCorrectLMHB [counter1*3] = lowestValueTemp;
                        autoContrastCorrectLMHB [counter1*3+1] = meanValueTemp;
                        autoContrastCorrectLMHB [counter1*3+2] = highestValueTemp;
                        
                        autoContrastCorrectLMH2B [counter1*3] = lowestValueTemp;
                        autoContrastCorrectLMH2B [counter1*3+1] = meanValueTemp;
                        autoContrastCorrectLMH2B [counter1*3+2] = highestValueTemp;
                    }
                }
                
                //for (int counterA = 0; counterA <= loadImageFOVNo; counterA++){
                //    cout<<counterA<<" "<<arrayImageDataLMH [counterA*3]<<" "<<arrayImageDataLMH [counterA*3+1]<<" "<<arrayImageDataLMH [counterA*3+2]<<" LMH2"<<endl;
                //}
                
                //for (int counterA = 0; counterA <= loadImageFOVNo; counterA++){
                //    cout<<counterA<<" "<<arrayImageDataLMHG [counterA*3]<<" "<<arrayImageDataLMHG [counterA*3+1]<<" "<<arrayImageDataLMHG [counterA*3+2]<<" LMH2G"<<endl;
                //}
                
                //for (int counterA = 0; counterA <= loadImageFOVNo; counterA++){
                //    cout<<counterA<<" "<<arrayImageDataLMHB [counterA*3]<<" "<<arrayImageDataLMHB [counterA*3+1]<<" "<<arrayImageDataLMHB [counterA*3+2]<<" LMH2B"<<endl;
                //}
                
                //=======Table data set=======
                int entryCount = 0;
                int writeStartFlag = 0;
                int contrastDoubleTemp = 0;
                int lowCut2 = 0;
                int meanValue2 = 0;
                int highCut2 = 0;
                
                double contrastDouble = 0;
                
                string stringData;
                string contrastString;
                
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    if (arrayTableDisplay [counter1*5] == loadImageTreatName && arrayTableDisplay [counter1*5+2] != " "){
                        writeStartFlag = 1;
                        
                        lowCut2 = autoContrastCorrectLMH2 [entryCount*3];
                        meanValue2 = autoContrastCorrectLMH2 [entryCount*3+1];
                        highCut2 = autoContrastCorrectLMH2 [entryCount*3+2];
                        
                        stringData = arrayTableDisplay [counter1*5+2];
                        stringData = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                        
                        contrastDoubleTemp = (int)(contrastValueDisplay*100);
                        contrastDouble = contrastDoubleTemp/(double)100;
                        
                        stringstream extension4;
                        extension4 << contrastDouble;
                        contrastString = extension4.str();
                        
                        arrayTableDisplay [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringData+"~0";
                        
                        if (photoMetricHold == 2){
                            lowCut2 = autoContrastCorrectLMH2G [entryCount*3];
                            meanValue2 = autoContrastCorrectLMH2G [entryCount*3+1];
                            highCut2 = autoContrastCorrectLMH2G [entryCount*3+2];
                            
                            stringData = arrayTableDisplayG [counter1*5+2];
                            stringData = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                            
                            contrastDoubleTemp = (int)(contrastValueDisplayG*100);
                            contrastDouble = contrastDoubleTemp/(double)100;
                            
                            stringstream extension5;
                            extension5 << contrastDouble;
                            contrastString = extension5.str();
                            
                            arrayTableDisplayG [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringData+"~0";
                            
                            lowCut2 = autoContrastCorrectLMH2B [entryCount*3];
                            meanValue2 = autoContrastCorrectLMH2B [entryCount*3+1];
                            highCut2 = autoContrastCorrectLMH2B [entryCount*3+2];
                            
                            stringData = arrayTableDisplayB [counter1*5+2];
                            stringData = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                            
                            contrastDoubleTemp = (int)(contrastValueDisplayB*100);
                            contrastDouble = contrastDoubleTemp/(double)100;
                            
                            stringstream extension6;
                            extension6 << contrastDouble;
                            contrastString = extension6.str();
                            
                            arrayTableDisplayB [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringData+"~0";
                        }
                        
                        entryCount++;
                    }
                    else if (writeStartFlag == 1 && arrayTableDisplay [counter1*5] == " " && arrayTableDisplay [counter1*5+2] != " "){
                        lowCut2 = autoContrastCorrectLMH2 [entryCount*3];
                        meanValue2 = autoContrastCorrectLMH2 [entryCount*3+1];
                        highCut2 = autoContrastCorrectLMH2 [entryCount*3+2];
                        
                        stringData = arrayTableDisplay [counter1*5+2];
                        stringData = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                        
                        contrastDoubleTemp = (int)(contrastValueDisplay*100);
                        contrastDouble = contrastDoubleTemp/(double)100;
                        
                        stringstream extension4;
                        extension4 << contrastDouble;
                        contrastString = extension4.str();
                        
                        arrayTableDisplay [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringData+"~0";
                        
                        if (photoMetricHold == 2){
                            lowCut2 = autoContrastCorrectLMH2G [entryCount*3];
                            meanValue2 = autoContrastCorrectLMH2G [entryCount*3+1];
                            highCut2 = autoContrastCorrectLMH2G [entryCount*3+2];
                            
                            stringData = arrayTableDisplayG [counter1*5+2];
                            stringData = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                            
                            contrastDoubleTemp = (int)(contrastValueDisplayG*100);
                            contrastDouble = contrastDoubleTemp/(double)100;
                            
                            stringstream extension5;
                            extension5 << contrastDouble;
                            contrastString = extension5.str();
                            
                            arrayTableDisplayG [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringData+"~0";
                            
                            lowCut2 = autoContrastCorrectLMH2B [entryCount*3];
                            meanValue2 = autoContrastCorrectLMH2B [entryCount*3+1];
                            highCut2 = autoContrastCorrectLMH2B [entryCount*3+2];
                            
                            stringData = arrayTableDisplayB [counter1*5+2];
                            stringData = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                            
                            contrastDoubleTemp = (int)(contrastValueDisplayB*100);
                            contrastDouble = contrastDoubleTemp/(double)100;
                            
                            stringstream extension6;
                            extension6 << contrastDouble;
                            contrastString = extension6.str();
                            
                            arrayTableDisplayB [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringData+"~0";
                        }
                        
                        entryCount++;
                    }
                    else if (writeStartFlag == 1 && ((arrayTableDisplay [counter1*5] != " " && arrayTableDisplay [counter1*5+2] != " ") || (arrayTableDisplay [counter1*5] == " " && arrayTableDisplay [counter1*5+2] == " "))){
                        break;
                    }
                }
                
                //========Contrast Current data set========
                if ((processType == 1 || processType == 3 || contrastFirstRead == 0 || sourceTimeDisplayFlag == 1) && processType != 5){
                    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                        contrastCurrentHold [counter1] = "0";
                        contrastCurrentHoldG [counter1] = "0";
                        contrastCurrentHoldB [counter1] = "0";
                    }
                    
                    if (sourceTimeDisplayFlag == 0 && (processType == 1 || processType == 3 || contrastFirstRead == 0)){
                        for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                            contrastCurrentHold [counter2] = arrayTableDisplay [counter2*5+2];
                            contrastCurrentHoldG [counter2] = arrayTableDisplayG [counter2*5+2];
                            contrastCurrentHoldB [counter2] = arrayTableDisplayB [counter2*5+2];
                        }
                    }
                    else if (sourceTimeDisplayFlag == 1){
                        int timeDataUse = 3;
                        string timeDetermine;
                        
                        for (int counter2 = 3; counter2 < 3+entryNumber; counter2++){
                            timeDetermine = arrayContrastData [0][counter2];
                            timeDetermine = timeDetermine.substr(1);
                            
                            if (atoi(timeDetermine.c_str()) <= loadImageNo) timeDataUse = counter2;
                        }
                        
                        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                            if (arrayContrastData [counter1][timeDataUse] == "0") contrastCurrentHold [counter1] = " ";
                            else contrastCurrentHold [counter1] = arrayContrastData [counter1][timeDataUse];
                            
                            if (photoMetricHold == 2){
                                if (arrayContrastDataG [counter1][timeDataUse] == "0") contrastCurrentHoldG [counter1] = " ";
                                else contrastCurrentHoldG [counter1] = arrayContrastDataG [counter1][timeDataUse];
                                
                                if (arrayContrastDataB [counter1][timeDataUse] == "0") contrastCurrentHoldB [counter1] = " ";
                                else contrastCurrentHoldB [counter1] = arrayContrastDataB [counter1][timeDataUse];
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
                //    for (int counterB = 0; counterB < entryNumber+3; counterB++) cout<<" "<<arrayContrastData [counterA][counterB];
                //    cout<<"  arrayContrastData "<<counterA+1<<endl;
                //}
                
                //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
                //    for (int counterB = 0; counterB < entryNumber+3; counterB++) cout<<" "<<arrayContrastDataG [counterA][counterB];
                //    cout<<"  arrayContrastDataG "<<counterA+1<<endl;
                //}
                
                //for (int counterA = 1; counterA < treatmentNameDisplayCount; counterA++){
                //    cout<<counterA<<" "<<contrastCurrentHold [counterA]<<" contrastHold"<<endl;
                //}
                
                //for (int counterA = 1; counterA < treatmentNameDisplayCount; counterA++){
                //    cout<<counterA<<" "<<contrastCurrentHoldG [counterA]<<" contrastHoldG"<<endl;
                //}
                
                //for (int counterA = 1; counterA < treatmentNameDisplayCount; counterA++){
                //    cout<<counterA<<" "<<contrastCurrentHoldB [counterA]<<" contrastHoldB"<<endl;
                //}
                
                if (sourceTimeDisplayFlag == 1 || processType == 4 || contrastFirstRead == 1 || processType == 5){
                    //========Set cut off and contrast values to an array to create contrast adjusted images=======
                    int treatFind = 0;
                    int cutOffTempCount = 0;
                    int cutOffTempCountG = 0;
                    int cutOffTempCountB = 0;
                    int contrastTempCount = 0;
                    int contrastTempCountG = 0;
                    int contrastTempCountB = 0;
                    int processStatusTempCount = 0;
                    
                    int *cutOffTemp = new int [treatmentNameDisplayCount*3+50];
                    int *cutOffTempG = new int [treatmentNameDisplayCount*3+50];
                    int *cutOffTempB = new int [treatmentNameDisplayCount*3+50];
                    double *contrastTemp = new double [treatmentNameDisplayCount+50];
                    double *contrastTempG = new double [treatmentNameDisplayCount+50];
                    double *contrastTempB = new double [treatmentNameDisplayCount+50];
                    int *processStatusTemp = new int [treatmentNameDisplayCount*2+50];
                    
                    string treatNameTemp2;
                    string fovName2;
                    string cutOffData;
                    string lowExtract;
                    string meanExtract;
                    string highExtract;
                    string contrastExtract;
                    string autoExtract;
                    string rangeExtract;
                    
                    //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
                    //    for (int counterB = 0; counterB < entryNumber+3; counterB++) cout<<" "<<arrayContrastData [counterA][counterB];
                    //    cout<<"  arrayContrastData "<<counterA+1<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayTableDisplay [counterA*5+counterB];
                    //    cout<<" arrayTableDisplay "<<counterA+1<<endl;
                    //}
                    
                    for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++){
                        treatNameTemp2 = arrayTreatmentNameDisplay [counter2];
                        fovName2 = arrayFOVNameDisplay [counter2];
                        
                        if (treatNameTemp2 == loadImageTreatName && fovName2 != "ND" && treatFind == 0){
                            treatFind = 1;
                            cutOffData = contrastCurrentHold [counter2];
                            
                            lowExtract = cutOffData.substr(0, cutOffData.find("/"));
                            cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                            meanExtract = cutOffData.substr(0, cutOffData.find("/"));
                            cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                            highExtract = cutOffData.substr(0, cutOffData.find("/"));
                            cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                            contrastExtract = cutOffData.substr(0, cutOffData.find(" "));
                            cutOffData = cutOffData.substr(cutOffData.find(" ")+1);
                            autoExtract = cutOffData.substr(0, 1);
                            cutOffData = cutOffData.substr(1);
                            rangeExtract = cutOffData.substr(0, cutOffData.find(":"));
                            
                            cutOffTemp [cutOffTempCount] = atoi(lowExtract.c_str()), cutOffTempCount++;
                            cutOffTemp [cutOffTempCount] = atoi(meanExtract.c_str()), cutOffTempCount++;
                            cutOffTemp [cutOffTempCount] = atoi(highExtract.c_str()), cutOffTempCount++;
                            contrastTemp [contrastTempCount] = atof(contrastExtract.c_str()), contrastTempCount++;
                            
                            if (autoExtract == "A") processStatusTemp [processStatusTempCount] = 1, processStatusTempCount++;
                            else if (autoExtract == "B") processStatusTemp [processStatusTempCount] = 2, processStatusTempCount++;
                            else if (autoExtract == "C") processStatusTemp [processStatusTempCount] = 3, processStatusTempCount++;
                            else if (autoExtract == "D") processStatusTemp [processStatusTempCount] = 4, processStatusTempCount++;
                            else if (autoExtract == "E") processStatusTemp [processStatusTempCount] = 5, processStatusTempCount++;
                            else if (autoExtract == "F") processStatusTemp [processStatusTempCount] = 6, processStatusTempCount++;
                            else if (autoExtract == "G") processStatusTemp [processStatusTempCount] = 7, processStatusTempCount++;
                            else processStatusTemp [processStatusTempCount] = 0, processStatusTempCount++;
                            
                            processStatusTemp [processStatusTempCount] = atoi(rangeExtract.c_str()), processStatusTempCount++;
                            
                            if (photoMetricHold == 2){
                                cutOffData = contrastCurrentHoldG [counter2];
                                
                                lowExtract = cutOffData.substr(0, cutOffData.find("/"));
                                cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                meanExtract = cutOffData.substr(0, cutOffData.find("/"));
                                cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                highExtract = cutOffData.substr(0, cutOffData.find("/"));
                                cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                contrastExtract = cutOffData.substr(0, cutOffData.find(" "));
                                cutOffData = cutOffData.substr(cutOffData.find(" ")+1);
                                autoExtract = cutOffData.substr(0, 1);
                                cutOffData = cutOffData.substr(1);
                                rangeExtract = cutOffData.substr(0, cutOffData.find(":"));
                                
                                cutOffTempG [cutOffTempCountG] = atoi(lowExtract.c_str()), cutOffTempCountG++;
                                cutOffTempG [cutOffTempCountG] = atoi(meanExtract.c_str()), cutOffTempCountG++;
                                cutOffTempG [cutOffTempCountG] = atoi(highExtract.c_str()), cutOffTempCountG++;
                                contrastTempG [contrastTempCountG] = atof(contrastExtract.c_str()), contrastTempCountG++;
                                
                                cutOffData = contrastCurrentHoldB [counter2];
                                
                                lowExtract = cutOffData.substr(0, cutOffData.find("/"));
                                cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                meanExtract = cutOffData.substr(0, cutOffData.find("/"));
                                cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                highExtract = cutOffData.substr(0, cutOffData.find("/"));
                                cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                contrastExtract = cutOffData.substr(0, cutOffData.find(" "));
                                cutOffData = cutOffData.substr(cutOffData.find(" ")+1);
                                autoExtract = cutOffData.substr(0, 1);
                                cutOffData = cutOffData.substr(1);
                                rangeExtract = cutOffData.substr(0, cutOffData.find(":"));
                                
                                cutOffTempB [cutOffTempCountB] = atoi(lowExtract.c_str()), cutOffTempCountB++;
                                cutOffTempB [cutOffTempCountB] = atoi(meanExtract.c_str()), cutOffTempCountB++;
                                cutOffTempB [cutOffTempCountB] = atoi(highExtract.c_str()), cutOffTempCountB++;
                                contrastTempB [contrastTempCountB] = atof(contrastExtract.c_str()), contrastTempCountB++;
                            }
                            
                            //cout<<lowExtract<<" "<<meanExtract<<" "<<highExtract<<" "<<contrastExtract<<" "<<autoExtract<<" Info"<<endl;
                        }
                        else if (treatNameTemp2 == "ND" && fovName2 != "ND" && treatFind == 1){
                            cutOffData = contrastCurrentHold [counter2];
                            
                            lowExtract = cutOffData.substr(0, cutOffData.find("/"));
                            cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                            meanExtract = cutOffData.substr(0, cutOffData.find("/"));
                            cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                            highExtract = cutOffData.substr(0, cutOffData.find("/"));
                            cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                            contrastExtract = cutOffData.substr(0, cutOffData.find(" "));
                            cutOffData = cutOffData.substr(cutOffData.find(" ")+1);
                            autoExtract = cutOffData.substr(0, 1);
                            cutOffData = cutOffData.substr(1);
                            rangeExtract = cutOffData.substr(0, cutOffData.find(":"));
                            
                            cutOffTemp [cutOffTempCount] = atoi(lowExtract.c_str()), cutOffTempCount++;
                            cutOffTemp [cutOffTempCount] = atoi(meanExtract.c_str()), cutOffTempCount++;
                            cutOffTemp [cutOffTempCount] = atoi(highExtract.c_str()), cutOffTempCount++;
                            contrastTemp [contrastTempCount] = atof(contrastExtract.c_str()), contrastTempCount++;
                            
                            if (autoExtract == "A") processStatusTemp [processStatusTempCount] = 1, processStatusTempCount++;
                            else if (autoExtract == "B") processStatusTemp [processStatusTempCount] = 2, processStatusTempCount++;
                            else if (autoExtract == "C") processStatusTemp [processStatusTempCount] = 3, processStatusTempCount++;
                            else if (autoExtract == "D") processStatusTemp [processStatusTempCount] = 4, processStatusTempCount++;
                            else if (autoExtract == "E") processStatusTemp [processStatusTempCount] = 5, processStatusTempCount++;
                            else if (autoExtract == "F") processStatusTemp [processStatusTempCount] = 6, processStatusTempCount++;
                            else if (autoExtract == "G") processStatusTemp [processStatusTempCount] = 7, processStatusTempCount++;
                            else processStatusTemp [processStatusTempCount] = 0, processStatusTempCount++;
                            
                            processStatusTemp [processStatusTempCount] = atoi(rangeExtract.c_str()), processStatusTempCount++;
                            
                            if (photoMetricHold == 2){
                                cutOffData = contrastCurrentHoldG [counter2];
                                
                                lowExtract = cutOffData.substr(0, cutOffData.find("/"));
                                cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                meanExtract = cutOffData.substr(0, cutOffData.find("/"));
                                cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                highExtract = cutOffData.substr(0, cutOffData.find("/"));
                                cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                contrastExtract = cutOffData.substr(0, cutOffData.find(" "));
                                cutOffData = cutOffData.substr(cutOffData.find(" ")+1);
                                autoExtract = cutOffData.substr(0, 1);
                                cutOffData = cutOffData.substr(1);
                                rangeExtract = cutOffData.substr(0, cutOffData.find(":"));
                                
                                cutOffTempG [cutOffTempCountG] = atoi(lowExtract.c_str()), cutOffTempCountG++;
                                cutOffTempG [cutOffTempCountG] = atoi(meanExtract.c_str()), cutOffTempCountG++;
                                cutOffTempG [cutOffTempCountG] = atoi(highExtract.c_str()), cutOffTempCountG++;
                                contrastTempG [contrastTempCountG] = atof(contrastExtract.c_str()), contrastTempCountG++;
                                
                                cutOffData = contrastCurrentHoldB [counter2];
                                
                                lowExtract = cutOffData.substr(0, cutOffData.find("/"));
                                cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                meanExtract = cutOffData.substr(0, cutOffData.find("/"));
                                cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                highExtract = cutOffData.substr(0, cutOffData.find("/"));
                                cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                contrastExtract = cutOffData.substr(0, cutOffData.find(" "));
                                cutOffData = cutOffData.substr(cutOffData.find(" ")+1);
                                autoExtract = cutOffData.substr(0, 1);
                                cutOffData = cutOffData.substr(1);
                                rangeExtract = cutOffData.substr(0, cutOffData.find(":"));
                                
                                cutOffTempB [cutOffTempCountB] = atoi(lowExtract.c_str()), cutOffTempCountB++;
                                cutOffTempB [cutOffTempCountB] = atoi(meanExtract.c_str()), cutOffTempCountB++;
                                cutOffTempB [cutOffTempCountB] = atoi(highExtract.c_str()), cutOffTempCountB++;
                                contrastTempB [contrastTempCountB] = atof(contrastExtract.c_str()), contrastTempCountB++;
                            }
                        }
                        else if (((treatNameTemp2 != "ND" && fovName2 != "ND") || (treatNameTemp2 == "ND" && fovName2 == "ND")) && treatFind == 1){
                            treatFind = 2;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < contrastTempCount; counterA++){
                    //    cout<<" "<<contrastTemp [counterA]<< " contrastTempCount "<<counterA+1<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < cutOffTempCount/3; counterA++){
                    //    cout<<" "<<cutOffTemp [counterA*3]<<" "<<cutOffTemp [counterA*3+1]<<" "<<cutOffTemp [counterA*3+2]<< " Cutoff "<<counterA+1<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < processStatusTempCount/3; counterA++){
                    //    cout<<" "<<processStatusTemp [counterA*3]<<" "<<processStatusTemp [counterA*3+1]<<" processStatusTemp "<<counterA+1<<endl;
                    //}
                    
                    //========Range process=======
                    /*Color image will not be processed*/
                    
                    double expansionFactor1 = 0;
                    int newPixValue = 0;
                    
                    if (photoMetricHold == 1){
                        int *valueFrequency = new int [256];
                        
                        int valueAverage = 0;
                        int totalPix = imageDimensionX*imageDimensionY;
                        int valueShift = 0;
                        
                        //-----Image data update following the cut off value-----
                        for (int counter2 = 0; counter2 < loadImageFOVNo; counter2++){
                            if (processStatusTemp [counter2*2+1] != 0){
                                for (int counter3 = 0; counter3 <= 255; counter3++) valueFrequency [counter3] = 0;
                                valueAverage = 0;
                                
                                for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                    for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                        if (arrayImageDataHold [counter2*imageDimensionY+counter3][counter4] >= 0){
                                            valueAverage = valueAverage+arrayImageDataHold [counter2*imageDimensionY+counter3][counter4];
                                            valueFrequency [arrayImageDataHold [counter2*imageDimensionY+counter3][counter4]]++;
                                        }
                                    }
                                }
                                
                                valueAverage = (int)(valueAverage/(double)totalPix);
                                pixNo90 = valueFrequency [valueAverage];
                                lowestValueTemp = 0;
                                highestValueTemp = 0;
                                
                                for (int counter3 = 1; counter3 <= 255; counter3++){
                                    if (valueAverage-counter3 >= 0){
                                        pixNo90 = pixNo90+valueFrequency [valueAverage-counter3];
                                        lowestValueTemp = valueAverage-counter3;
                                    }
                                    if (valueAverage+counter3 <= 255){
                                        pixNo90 = pixNo90+valueFrequency [valueAverage+counter3];
                                        highestValueTemp = valueAverage+counter3;
                                    }
                                    if (pixNo90/(double)totalPix > 0.8){
                                        break;
                                    }
                                }
                                
                                expansionFactor1 = processStatusTemp [counter2*2+1]/(double)(highestValueTemp-lowestValueTemp);
                                valueShift = 100-valueAverage;
                                
                                for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                    for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                        if (arrayImageDataHold [counter2*imageDimensionY+counter3][counter4] >= 0){
                                            newPixValue = arrayImageDataHold [counter2*imageDimensionY+counter3][counter4]+valueShift;
                                            
                                            if (newPixValue < 100) newPixValue = newPixValue-(int)(abs(100-newPixValue)*expansionFactor1);
                                            else newPixValue = newPixValue+(int)(abs(100-newPixValue)*expansionFactor1);
                                            
                                            if (newPixValue < 0) newPixValue = 0;
                                            if (newPixValue > 255) newPixValue = 255;
                                            
                                            arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4] = newPixValue;
                                        }
                                        else arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4] = -1;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 <= 255; counter3++) histogramTemp [counter3] = 0;
                                
                                for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                    for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                        if (arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4] >= 0){
                                            arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4] = arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4];
                                            arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4] = arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4];
                                            
                                            histogramTemp [arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4]]++;
                                        }
                                        else arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4] = -1;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < 256; counter3++){
                                    arrayImageRangeAdjustHistogram [counter2*256+counter3] = histogramTemp [counter3];
                                    arrayImageCutoffAdjustHistogram [counter2*256+counter3] = histogramTemp [counter3];
                                    arrayImageContrastAdjustHistogram [counter2*256+counter3] = histogramTemp [counter3];
                                }
                            }
                            else{
                                
                                for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                    for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                        arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4] = arrayImageDataHold [counter2*imageDimensionY+counter3][counter4];
                                        arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4] = arrayImageDataHold [counter2*imageDimensionY+counter3][counter4];
                                        arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4] = arrayImageDataHold [counter2*imageDimensionY+counter3][counter4];
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < 256; counter3++){
                                    arrayImageRangeAdjustHistogram [counter2*256+counter3] = arrayImageDataHistogram [counter2*256+counter3];
                                    arrayImageCutoffAdjustHistogram [counter2*256+counter3] = arrayImageDataHistogram [counter2*256+counter3];
                                    arrayImageContrastAdjustHistogram [counter2*256+counter3] = arrayImageDataHistogram [counter2*256+counter3];
                                }
                            }
                        }
                        
                        //-----Histogram data update-----
                        for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                        
                        for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                            for (int counter3 = 0; counter3 < 256; counter3++){
                                histogramTemp [counter3] = histogramTemp [counter3]+arrayImageRangeAdjustHistogram [(counter2-1)*256+counter3];
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < 256; counter3++){
                            arrayImageRangeAdjustHistogram [loadImageFOVNo*256+counter3] = histogramTemp [counter3];
                            arrayImageCutoffAdjustHistogram [loadImageFOVNo*256+counter3] = histogramTemp [counter3];
                            arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter3] = histogramTemp [counter3];
                        }
                        
                        //for (int counterA = 1; counterA <= 255; counterA++){
                        //    cout<<" "<<counterA<<" "<<arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counterA]<<" Histo"<<endl;
                        // }
                        
                        for (int counter2 = 0; counter2 <= loadImageFOVNo; counter2++){
                            numberOfPoint = 0;
                            totalCount = 0;
                            lowestValueTemp = 0;
                            highestValueTemp = 0;
                            meanValueTemp = 0;
                            
                            //for (int counterA = 1; counterA <= 255; counterA++){
                            //    cout<<" "<<counterA<<" "<<arrayHistogramContrastHoldTemp [counter2*256+counterA]<<" Histo"<<endl;
                            // }
                            
                            for (int counter3 = 1; counter3 <= 255; counter3++){
                                numberOfPoint = numberOfPoint+arrayImageRangeAdjustHistogram [counter2*256+counter3];
                                totalCount = totalCount+(unsigned long)(counter3*arrayImageRangeAdjustHistogram [counter2*256+counter3]);
                            }
                            
                            if (numberOfPoint != 0) meanValueTemp = (int)(totalCount/(double)numberOfPoint);
                            
                            pixNo90 = arrayImageRangeAdjustHistogram [counter2*256+meanValueTemp];
                            
                            for (int counter4 = 1; counter4 <= 255; counter4++){
                                if (meanValueTemp-counter4 >= 0){
                                    pixNo90 = pixNo90+arrayImageRangeAdjustHistogram [counter2*256+meanValueTemp-counter4];
                                    lowestValueTemp = meanValueTemp-counter4;
                                }
                                
                                if (meanValueTemp+counter4 <= 255){
                                    pixNo90 = pixNo90+arrayImageRangeAdjustHistogram [counter2*256+meanValueTemp+counter4];
                                    highestValueTemp = meanValueTemp+counter4;
                                }
                                
                                if (pixNo90/(double)numberOfPoint > 0.8){
                                    break;
                                }
                            }
                            
                            arrayImageRangeAdjustLMH [counter2*3] = lowestValueTemp;
                            arrayImageRangeAdjustLMH [counter2*3+1] = meanValueTemp;
                            arrayImageRangeAdjustLMH [counter2*3+2] = highestValueTemp;
                            
                            autoContrastCorrectLMH [counter2*3] = lowestValueTemp;
                            autoContrastCorrectLMH [counter2*3+1] = meanValueTemp;
                            autoContrastCorrectLMH [counter2*3+2] = highestValueTemp;
                            
                            autoContrastCorrectLMH2 [counter2*3] = lowestValueTemp;
                            autoContrastCorrectLMH2 [counter2*3+1] = meanValueTemp;
                            autoContrastCorrectLMH2 [counter2*3+2] = highestValueTemp;
                        }
                        
                        delete [] valueFrequency;
                    }
                    
                    //for (int counterA = 0; counterA <= loadImageFOVNo; counterA++){
                    //    cout<<counterA<<" "<<autoContrastCorrectLMH2 [counterA*3]<<" "<<autoContrastCorrectLMH2 [counterA*3+1]<<" "<<autoContrastCorrectLMH2 [counterA*3+2]<<" autoContrastCorrectLMH2"<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA <= loadImageFOVNo; counterA++){
                    //    cout<<counterA<<" "<<autoContrastCorrectLMH2G [counterA*3]<<" "<<autoContrastCorrectLMH2G [counterA*3+1]<<" "<<autoContrastCorrectLMH2G [counterA*3+2]<<" autoContrastCorrectLMH2G"<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA <= loadImageFOVNo; counterA++){
                    //    cout<<counterA<<" "<<autoContrastCorrectLMH2B [counterA*3]<<" "<<autoContrastCorrectLMH2B [counterA*3+1]<<" "<<autoContrastCorrectLMH2B [counterA*3+2]<<" autoContrastCorrectLMH2B"<<endl;
                    //}
                    
                    //==========Cut Off Process=======
                    //for (int counterA = 0; counterA < loadImageFOVNo; counterA++){
                    //    cout<<counterA<<" "<<contrastDataTempLMH [counterA*3]<<" "<<contrastDataTempLMH [counterA*3+1]<<" "<<contrastDataTempLMH [counterA*3+2]<<"  contrastDataTempLMH"<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < loadImageFOVNo; counterA++){
                    //    cout<<counterA<<" "<<cutOffTemp [counterA*3]<<" "<<cutOffTemp [counterA*3+1]<<" "<<cutOffTemp [counterA*3+2]<<"  cutOffTemp"<<endl;
                    //}
                    
                    //----Update image data-----
                    double expansionFactor2 = 0;
                    
                    for (int counter2 = 0; counter2 < loadImageFOVNo; counter2++){
                        if (photoMetricHold == 1){
                            if (cutOffTemp [counter2*3] != arrayImageRangeAdjustLMH [counter2*3] || cutOffTemp [counter2*3+1] != arrayImageRangeAdjustLMH [counter2*3+1] || cutOffTemp [counter2*3+2] != arrayImageRangeAdjustLMH [counter2*3+2]){
                                
                                highestValueTemp = arrayImageRangeAdjustLMH [counter2*3+2]-cutOffTemp [counter2*3+1];
                                if (arrayImageRangeAdjustLMH [counter2*3+2]-cutOffTemp [counter2*3+1] <= 0) highestValueTemp = 1;
                                
                                lowestValueTemp = cutOffTemp [counter2*3+1]-arrayImageRangeAdjustLMH [counter2*3];
                                if (cutOffTemp [counter2*3+1]-arrayImageRangeAdjustLMH [counter2*3] <= 0) lowestValueTemp = 1;
                                
                                expansionFactor1 = (cutOffTemp [counter2*3+2]-cutOffTemp [counter2*3+1])/(double)highestValueTemp;
                                expansionFactor2 = (cutOffTemp [counter2*3+1]-cutOffTemp [counter2*3])/(double)lowestValueTemp;
                                
                                for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                    for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                        if (arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4] >= 0){
                                            if (arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4] > cutOffTemp [counter2*3+1] && expansionFactor1 != 1) newPixValue = cutOffTemp [counter2*3+1]+(int)((arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4]-cutOffTemp [counter2*3+1])*expansionFactor1);
                                            else if (arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4] < cutOffTemp [counter2*3+1] && expansionFactor2 != 1) newPixValue = cutOffTemp [counter2*3+1]-(int)((cutOffTemp [counter2*3+1]-arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4])*expansionFactor2);
                                            else newPixValue = arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4];
                                            
                                            if (newPixValue < 0) newPixValue = 0;
                                            else if (newPixValue > 255) newPixValue = 255;
                                            
                                            arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4] = newPixValue;
                                            arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4] = newPixValue;
                                        }
                                        else{
                                            
                                            arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4] = -1;
                                            arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4] = -1;
                                        }
                                    }
                                }
                            }
                        }
                        else if (photoMetricHold == 2){
                            if (cutOffTemp [counter2*3] != arrayImageRangeAdjustLMH [counter2*3] || cutOffTemp [counter2*3+1] != arrayImageRangeAdjustLMH [counter2*3+1] || cutOffTemp [counter2*3+2] != arrayImageRangeAdjustLMH [counter2*3+2]){
                                highestValueTemp = arrayImageRangeAdjustLMH [counter2*3+2]-cutOffTemp [counter2*3+1];
                                if (arrayImageRangeAdjustLMH [counter2*3+2]-cutOffTemp [counter2*3+1] <= 0) highestValueTemp = 1;
                                
                                lowestValueTemp = cutOffTemp [counter2*3+1]-arrayImageRangeAdjustLMH [counter2*3];
                                if (cutOffTemp [counter2*3+1]-arrayImageRangeAdjustLMH [counter2*3] <= 0) lowestValueTemp = 1;
                                
                                expansionFactor1 = (cutOffTemp [counter2*3+2]-cutOffTemp [counter2*3+1])/(double)highestValueTemp;
                                expansionFactor2 = (cutOffTemp [counter2*3+1]-cutOffTemp [counter2*3])/(double)lowestValueTemp;
                                
                                for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                    for (int counter4 = 0; counter4 < imageDimensionX; counter4 = counter4+3){
                                        if (arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4*3] >= 0){
                                            if (arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4*3] > cutOffTemp [counter2*3+1] && expansionFactor1 != 1) newPixValue = cutOffTemp [counter2*3+1]+(int)((arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4*3]-cutOffTemp [counter2*3+1])*expansionFactor1);
                                            else if (arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4*3] < cutOffTemp [counter2*3+1] && expansionFactor2 != 1) newPixValue = cutOffTemp [counter2*3+1]-(int)((cutOffTemp [counter2*3+1]-arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4*3])*expansionFactor2);
                                            else newPixValue = arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4*3];
                                            
                                            if (newPixValue < 0) newPixValue = 0;
                                            else if (newPixValue > 255) newPixValue = 255;
                                            
                                            arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3] = newPixValue;
                                            arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4*3] = newPixValue;
                                        }
                                        else{
                                            
                                            arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3] = -1;
                                            arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4*3] = -1;
                                        }
                                    }
                                }
                            }
                            
                            if (cutOffTempG [counter2*3] != arrayImageRangeAdjustLMHG [counter2*3] || cutOffTempG [counter2*3+1] != arrayImageRangeAdjustLMHG [counter2*3+1] || cutOffTempG [counter2*3+2] != arrayImageRangeAdjustLMHG [counter2*3+2]){
                                highestValueTemp = arrayImageRangeAdjustLMHG [counter2*3+2]-cutOffTempG [counter2*3+1];
                                if (arrayImageRangeAdjustLMHG [counter2*3+2]-cutOffTempG [counter2*3+1] <= 0) highestValueTemp = 1;
                                
                                lowestValueTemp = cutOffTempG [counter2*3+1]-arrayImageRangeAdjustLMHG [counter2*3];
                                if (cutOffTempG [counter2*3+1]-arrayImageRangeAdjustLMHG [counter2*3] <= 0) lowestValueTemp = 1;
                                
                                expansionFactor1 = (cutOffTempG [counter2*3+2]-cutOffTempG [counter2*3+1])/(double)highestValueTemp;
                                expansionFactor2 = (cutOffTempG [counter2*3+1]-cutOffTempG [counter2*3])/(double)lowestValueTemp;
                                
                                for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                    for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                        if (arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4*3+1] >= 0){
                                            if (arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4*3+1] > cutOffTempG [counter2*3+1] && expansionFactor1 != 1) newPixValue = cutOffTempG [counter2*3+1]+(int)((arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4*3+1]-cutOffTempG [counter2*3+1])*expansionFactor1);
                                            else if (arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4*3+1] < cutOffTempG [counter2*3+1] && expansionFactor2 != 1) newPixValue = cutOffTempG [counter2*3+1]-(int)((cutOffTempG [counter2*3+1]-arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4*3+1])*expansionFactor2);
                                            else newPixValue = arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4*3+1];
                                            
                                            if (newPixValue < 0) newPixValue = 0;
                                            else if (newPixValue > 255) newPixValue = 255;
                                            
                                            arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+1] = newPixValue;
                                            arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4*3+1] = newPixValue;
                                        }
                                        else{
                                            
                                            arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+1] = -1;
                                            arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4*3+1] = -1;
                                        }
                                    }
                                }
                            }
                            
                            if (cutOffTempB [counter2*3] != arrayImageRangeAdjustLMHB [counter2*3] || cutOffTempB [counter2*3+1] != arrayImageRangeAdjustLMHB [counter2*3+1] || cutOffTempB [counter2*3+2] != arrayImageRangeAdjustLMHB [counter2*3+2]){
                                highestValueTemp = arrayImageRangeAdjustLMHB [counter2*3+2]-cutOffTempB [counter2*3+1];
                                if (arrayImageRangeAdjustLMHB [counter2*3+2]-cutOffTempB [counter2*3+1] <= 0) highestValueTemp = 1;
                                
                                lowestValueTemp = cutOffTempB [counter2*3+1]-arrayImageRangeAdjustLMHB [counter2*3];
                                if (cutOffTempB [counter2*3+1]-arrayImageRangeAdjustLMHB [counter2*3] <= 0) lowestValueTemp = 1;
                                
                                expansionFactor1 = (cutOffTempB [counter2*3+2]-cutOffTempB [counter2*3+1])/(double)highestValueTemp;
                                expansionFactor2 = (cutOffTempB [counter2*3+1]-cutOffTempB [counter2*3])/(double)lowestValueTemp;
                                
                                for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                    for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                        if (arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4*3+2] >= 0){
                                            if (arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4*3+2] > cutOffTempB [counter2*3+1] && expansionFactor1 != 1) newPixValue = cutOffTempB [counter2*3+1]+(int)((arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4*3+2]-cutOffTempB [counter2*3+1])*expansionFactor1);
                                            else if (arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4*3+2] < cutOffTempB [counter2*3+1] && expansionFactor2 != 1) newPixValue = cutOffTempB [counter2*3+1]-(int)((cutOffTempB [counter2*3+1]-arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4*3+2])*expansionFactor2);
                                            else newPixValue = arrayImageRangeAdjust [counter2*imageDimensionY+counter3][counter4*3+2];
                                            
                                            if (newPixValue < 0) newPixValue = 0;
                                            else if (newPixValue > 255) newPixValue = 255;
                                            
                                            arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+2] = newPixValue;
                                            arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4*3+2] = newPixValue;
                                        }
                                        else{
                                            
                                            arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+2] = -1;
                                            arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4*3+2] = -1;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    //-----FOV histogram-----
                    if (photoMetricHold == 1){
                        for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                            for (int counter3 = 0; counter3 <= 255; counter3++) histogramTemp [counter3] = 0;
                            
                            for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                    if (arrayImageCutoffAdjust [(counter2-1)*imageDimensionY+counter3][counter4] >= 0){
                                        histogramTemp [arrayImageCutoffAdjust [(counter2-1)*imageDimensionY+counter3][counter4]]++;
                                    }
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < 256; counter3++){
                                arrayImageCutoffAdjustHistogram [(counter2-1)*256+counter3] = histogramTemp [counter3];
                                arrayImageContrastAdjustHistogram [(counter2-1)*256+counter3] = histogramTemp [counter3];
                            }
                        }
                    }
                    else if (photoMetricHold == 2){
                        for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                            for (int counter3 = 0; counter3 <= 255; counter3++) histogramTemp [counter3] = 0;
                            
                            for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                    if (arrayImageCutoffAdjust [(counter2-1)*imageDimensionY+counter3][counter4*3] >= 0){
                                        histogramTemp [arrayImageCutoffAdjust [(counter2-1)*imageDimensionY+counter3][counter4*3]]++;
                                    }
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < 256; counter3++){
                                arrayImageCutoffAdjustHistogram [(counter2-1)*256+counter3] = histogramTemp [counter3];
                                arrayImageContrastAdjustHistogram [(counter2-1)*256+counter3] = histogramTemp [counter3];
                            }
                        }
                        
                        for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                            for (int counter3 = 0; counter3 <= 255; counter3++) histogramTemp [counter3] = 0;
                            
                            for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                    if (arrayImageCutoffAdjust [(counter2-1)*imageDimensionY+counter3][counter4*3+1] >= 0){
                                        histogramTemp [arrayImageCutoffAdjust [(counter2-1)*imageDimensionY+counter3][counter4*3+1]]++;
                                    }
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < 256; counter3++){
                                arrayImageCutoffAdjustHistogramG [(counter2-1)*256+counter3] = histogramTemp [counter3];
                                arrayImageContrastAdjustHistogramG [(counter2-1)*256+counter3] = histogramTemp [counter3];
                            }
                        }
                        
                        for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                            for (int counter3 = 0; counter3 <= 255; counter3++) histogramTemp [counter3] = 0;
                            
                            for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                    if (arrayImageCutoffAdjust [(counter2-1)*imageDimensionY+counter3][counter4*3+2] >= 0){
                                        histogramTemp [arrayImageCutoffAdjust [(counter2-1)*imageDimensionY+counter3][counter4*3+2]]++;
                                    }
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < 256; counter3++){
                                arrayImageCutoffAdjustHistogramB [(counter2-1)*256+counter3] = histogramTemp [counter3];
                                arrayImageContrastAdjustHistogramB [(counter2-1)*256+counter3] = histogramTemp [counter3];
                            }
                        }
                    }
                    
                    //-----Entier image histogram-----
                    if (photoMetricHold == 1){
                        for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                        
                        for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                            for (int counter3 = 0; counter3 < 256; counter3++){
                                histogramTemp [counter3] = histogramTemp [counter3]+arrayImageCutoffAdjustHistogram [(counter2-1)*256+counter3];
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < 256; counter2++){
                            arrayImageCutoffAdjustHistogram [loadImageFOVNo*256+counter2] = histogramTemp [counter2];
                            arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter2] = histogramTemp [counter2];
                        }
                    }
                    else if (photoMetricHold == 2){
                        for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                        
                        for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                            for (int counter3 = 0; counter3 < 256; counter3++){
                                histogramTemp [counter3] = histogramTemp [counter3]+arrayImageCutoffAdjustHistogram [(counter2-1)*256+counter3];
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < 256; counter2++){
                            arrayImageCutoffAdjustHistogram [loadImageFOVNo*256+counter2] = histogramTemp [counter2];
                            arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter2] = histogramTemp [counter2];
                        }
                        
                        for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                        
                        for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                            for (int counter3 = 0; counter3 < 256; counter3++){
                                histogramTemp [counter3] = histogramTemp [counter3]+arrayImageCutoffAdjustHistogramG [(counter2-1)*256+counter3];
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < 256; counter2++){
                            arrayImageCutoffAdjustHistogramG [loadImageFOVNo*256+counter2] = histogramTemp [counter2];
                            arrayImageContrastAdjustHistogramG [loadImageFOVNo*256+counter2] = histogramTemp [counter2];
                        }
                        
                        for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                        
                        for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                            for (int counter3 = 0; counter3 < 256; counter3++){
                                histogramTemp [counter3] = histogramTemp [counter3]+arrayImageCutoffAdjustHistogramB [(counter2-1)*256+counter3];
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < 256; counter2++){
                            arrayImageCutoffAdjustHistogramB [loadImageFOVNo*256+counter2] = histogramTemp [counter2];
                            arrayImageContrastAdjustHistogramB [loadImageFOVNo*256+counter2] = histogramTemp [counter2];
                        }
                    }
                    
                    //-----Enter Low Mean high value-----
                    lowestValueTemp = 0;
                    meanValueTemp = 0;
                    highestValueTemp = 0;
                    lowestValueTempG = 0;
                    meanValueTempG = 0;
                    highestValueTempG = 0;
                    lowestValueTempB = 0;
                    meanValueTempB = 0;
                    highestValueTempB = 0;
                    
                    for (int counter1 = 0; counter1 <= loadImageFOVNo; counter1++){
                        if (counter1 != loadImageFOVNo){
                            autoContrastCorrectLMH [counter1*3] = cutOffTemp [counter1*3];
                            autoContrastCorrectLMH [counter1*3+1] = cutOffTemp [counter1*3+1];
                            autoContrastCorrectLMH [counter1*3+2] = cutOffTemp [counter1*3+2];
                            
                            autoContrastCorrectLMH2 [counter1*3] = cutOffTemp [counter1*3];
                            autoContrastCorrectLMH2 [counter1*3+1] = cutOffTemp [counter1*3+1];
                            autoContrastCorrectLMH2 [counter1*3+2] = cutOffTemp [counter1*3+2];
                            
                            lowestValueTemp = lowestValueTemp+cutOffTemp [counter1*3];
                            meanValueTemp = meanValueTemp+cutOffTemp [counter1*3+1];
                            highestValueTemp = highestValueTemp+cutOffTemp [counter1*3+2];
                            
                            if (photoMetricHold == 2){
                                autoContrastCorrectLMHG [counter1*3] = cutOffTempG [counter1*3];
                                autoContrastCorrectLMHG [counter1*3+1] = cutOffTempG [counter1*3+1];
                                autoContrastCorrectLMHG [counter1*3+2] = cutOffTempG [counter1*3+2];
                                
                                autoContrastCorrectLMH2G [counter1*3] = cutOffTempG [counter1*3];
                                autoContrastCorrectLMH2G [counter1*3+1] = cutOffTempG [counter1*3+1];
                                autoContrastCorrectLMH2G [counter1*3+2] = cutOffTempG [counter1*3+2];
                                
                                lowestValueTempG = lowestValueTempG+cutOffTempG [counter1*3];
                                meanValueTempG = meanValueTempG+cutOffTempG [counter1*3+1];
                                highestValueTempG = highestValueTempG+cutOffTempG [counter1*3+2];
                                
                                autoContrastCorrectLMHB [counter1*3] = cutOffTempB [counter1*3];
                                autoContrastCorrectLMHB [counter1*3+1] = cutOffTempB [counter1*3+1];
                                autoContrastCorrectLMHB [counter1*3+2] = cutOffTempB [counter1*3+2];
                                
                                autoContrastCorrectLMH2B [counter1*3] = cutOffTempB [counter1*3];
                                autoContrastCorrectLMH2B [counter1*3+1] = cutOffTempB [counter1*3+1];
                                autoContrastCorrectLMH2B [counter1*3+2] = cutOffTempB [counter1*3+2];
                                
                                lowestValueTempB = lowestValueTempB+cutOffTempB [counter1*3];
                                meanValueTempB = meanValueTempB+cutOffTempB [counter1*3+1];
                                highestValueTempB = highestValueTempB+cutOffTempB [counter1*3+2];
                            }
                        }
                        else{
                            
                            autoContrastCorrectLMH [counter1*3] = lowestValueTemp/loadImageFOVNo;
                            autoContrastCorrectLMH [counter1*3+1] = meanValueTemp/loadImageFOVNo;
                            autoContrastCorrectLMH [counter1*3+2] = highestValueTemp/loadImageFOVNo;
                            
                            autoContrastCorrectLMH2 [counter1*3] = lowestValueTemp/loadImageFOVNo;
                            autoContrastCorrectLMH2 [counter1*3+1] = meanValueTemp/loadImageFOVNo;
                            autoContrastCorrectLMH2 [counter1*3+2] = highestValueTemp/loadImageFOVNo;
                            
                            if (photoMetricHold == 2){
                                autoContrastCorrectLMHG [counter1*3] = lowestValueTempG/loadImageFOVNo;
                                autoContrastCorrectLMHG [counter1*3+1] = meanValueTempG/loadImageFOVNo;
                                autoContrastCorrectLMHG [counter1*3+2] = highestValueTempG/loadImageFOVNo;
                                
                                autoContrastCorrectLMH2G [counter1*3] = lowestValueTempG/loadImageFOVNo;
                                autoContrastCorrectLMH2G [counter1*3+1] = meanValueTempG/loadImageFOVNo;
                                autoContrastCorrectLMH2G [counter1*3+2] = highestValueTempG/loadImageFOVNo;
                                
                                autoContrastCorrectLMHB [counter1*3] = lowestValueTempB/loadImageFOVNo;
                                autoContrastCorrectLMHB [counter1*3+1] = meanValueTempB/loadImageFOVNo;
                                autoContrastCorrectLMHB [counter1*3+2] = highestValueTempB/loadImageFOVNo;
                                
                                autoContrastCorrectLMH2B [counter1*3] = lowestValueTempB/loadImageFOVNo;
                                autoContrastCorrectLMH2B [counter1*3+1] = meanValueTempB/loadImageFOVNo;
                                autoContrastCorrectLMH2B [counter1*3+2] = highestValueTempB/loadImageFOVNo;
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA <= loadImageFOVNo; counterA++){
                    //    cout<<counterA<<" "<<autoContrastCorrectLMH2 [counterA*3]<<" "<<autoContrastCorrectLMH2 [counterA*3+1]<<" "<<autoContrastCorrectLMH2 [counterA*3+2]<<" autoContrastCorrectLMH2A"<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA <= loadImageFOVNo; counterA++){
                    //    cout<<counterA<<" "<<autoContrastCorrectLMH2G [counterA*3]<<" "<<autoContrastCorrectLMH2G [counterA*3+1]<<" "<<autoContrastCorrectLMH2G [counterA*3+2]<<" autoContrastCorrectLMH2GA"<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA <= loadImageFOVNo; counterA++){
                    //    cout<<counterA<<" "<<autoContrastCorrectLMH2B [counterA*3]<<" "<<autoContrastCorrectLMH2B [counterA*3+1]<<" "<<autoContrastCorrectLMH2B [counterA*3+2]<<" autoContrastCorrectLMH2BA"<<endl;
                    //}
                    
                    //=========Contrast Set============
                    if (photoMetricHold == 1){
                        for (int counter2 = 0; counter2 < loadImageFOVNo; counter2++){
                            if (contrastTemp [counter2] != 0){
                                for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                    for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                        if (arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4] >= 0){
                                            if (arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4]-cutOffTemp [counter2*3+1] < 0 && arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4] >= 0){
                                                newPixValue = arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4]-(int)((cutOffTemp [counter2*3+1]-arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4])*contrastTemp [counter2]);
                                            }
                                            else if (arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4]-cutOffTemp [counter2*3+1] > 0 && arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4] <= 255){
                                                newPixValue = arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4]+(int)((arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4]-cutOffTemp [counter2*3+1])*contrastTemp [counter2]);
                                            }
                                            else newPixValue = arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4];
                                            
                                            if (newPixValue < 0) newPixValue = 0;
                                            else if (newPixValue > 255) newPixValue = 255;
                                            
                                            arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4] = newPixValue;
                                        }
                                        else arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4] = -1;
                                    }
                                }
                            }
                        }
                        
                        for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                            for (int counter3 = 0; counter3 <= 255; counter3++) histogramTemp [counter3] = 0;
                            
                            for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                    if (arrayImageContrastAdjust [(counter2-1)*imageDimensionY+counter3][counter4] >= 0){
                                        histogramTemp [arrayImageContrastAdjust [(counter2-1)*imageDimensionY+counter3][counter4]]++;
                                    }
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < 256; counter3++) arrayImageContrastAdjustHistogram [(counter2-1)*256+counter3] = histogramTemp [counter3];
                        }
                        
                        for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                        
                        for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                            for (int counter3 = 0; counter3 < 256; counter3++){
                                histogramTemp [counter3] = histogramTemp [counter3]+arrayImageContrastAdjustHistogram [(counter2-1)*256+counter3];
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < 256; counter2++) arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter2] = histogramTemp [counter2];
                        
                        for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++) arrayTableDisplay [counter2*5+2] = contrastCurrentHold [counter2];
                    }
                    else if (photoMetricHold == 2){
                        //-----Image data set-----
                        for (int counter2 = 0; counter2 < loadImageFOVNo; counter2++){
                            if (contrastTemp [counter2] != 0){
                                for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                    for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                        if (arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3] >= 0){
                                            if (arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3]-cutOffTemp [counter2*3+1] < 0 && arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3] >= 0){
                                                newPixValue = arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3]-(int)((cutOffTemp [counter2*3+1]-arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3])*contrastTemp [counter2]);
                                            }
                                            else if (arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3]-cutOffTemp [counter2*3+1] > 0 && arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3] <= 255){
                                                newPixValue = arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3]+(int)((arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3]-cutOffTemp [counter2*3+1])*contrastTemp [counter2]);
                                            }
                                            else newPixValue = arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3];
                                            
                                            if (newPixValue < 0) newPixValue = 0;
                                            else if (newPixValue > 255) newPixValue = 255;
                                            
                                            arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4*3] = newPixValue;
                                        }
                                        else arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4*3] = -1;
                                    }
                                }
                            }
                            
                            if (contrastTempG [counter2] != 0){
                                for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                    for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                        if (arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+1] >= 0){
                                            if (arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+1]-cutOffTempG [counter2*3+1] < 0 && arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+1] >= 0){
                                                newPixValue = arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+1]-(int)((cutOffTempG [counter2*3+1]-arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+1])*contrastTempG [counter2]);
                                            }
                                            else if (arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+1]-cutOffTempG [counter2*3+1] > 0 && arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+1] <= 255){
                                                newPixValue = arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+1]+(int)((arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+1]-cutOffTempG [counter2*3+1])*contrastTempG [counter2]);
                                            }
                                            else newPixValue = arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+1];
                                            
                                            if (newPixValue < 0) newPixValue = 0;
                                            else if (newPixValue > 255) newPixValue = 255;
                                            
                                            arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4*3+1] = newPixValue;
                                        }
                                        else arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4*3+1] = -1;
                                    }
                                }
                            }
                            
                            if (contrastTempB [counter2] != 0){
                                for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                    for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                        if (arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+2] >= 0){
                                            if (arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+2]-cutOffTempB [counter2*3+1] < 0 && arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+2] >= 0){
                                                newPixValue = arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+2]-(int)((cutOffTempB [counter2*3+1]-arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+2])*contrastTempB [counter2]);
                                            }
                                            else if (arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+2]-cutOffTempB [counter2*3+1] > 0 && arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+2] <= 255){
                                                newPixValue = arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+2]+(int)((arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+2]-cutOffTempB [counter2*3+1])*contrastTempB [counter2]);
                                            }
                                            else newPixValue = arrayImageCutoffAdjust [counter2*imageDimensionY+counter3][counter4*3+2];
                                            
                                            if (newPixValue < 0) newPixValue = 0;
                                            else if (newPixValue > 255) newPixValue = 255;
                                            
                                            arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4*3+2] = newPixValue;
                                        }
                                        else arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4*3+2] = -1;
                                    }
                                }
                            }
                        }
                        
                        //-----Contrast data set-----
                        for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                            for (int counter3 = 0; counter3 <= 255; counter3++) histogramTemp [counter3] = 0;
                            
                            for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                    if (arrayImageContrastAdjust [(counter2-1)*imageDimensionY+counter3][counter4*3] >= 0){
                                        histogramTemp [arrayImageContrastAdjust [(counter2-1)*imageDimensionY+counter3][counter4*3]]++;
                                    }
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < 256; counter3++) arrayImageContrastAdjustHistogram [(counter2-1)*256+counter3] = histogramTemp [counter3];
                        }
                        
                        if (photoMetricHold == 2){
                            for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                                for (int counter3 = 0; counter3 <= 255; counter3++) histogramTemp [counter3] = 0;
                                
                                for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                    for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                        if (arrayImageContrastAdjust [(counter2-1)*imageDimensionY+counter3][counter4*3+1] >= 0){
                                            histogramTemp [arrayImageContrastAdjust [(counter2-1)*imageDimensionY+counter3][counter4*3+1]]++;
                                        }
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < 256; counter3++) arrayImageContrastAdjustHistogramG [(counter2-1)*256+counter3] = histogramTemp [counter3];
                            }
                            
                            for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                                for (int counter3 = 0; counter3 <= 255; counter3++) histogramTemp [counter3] = 0;
                                
                                for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                    for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                        if (arrayImageContrastAdjust [(counter2-1)*imageDimensionY+counter3][counter4*3+2] >= 0){
                                            histogramTemp [arrayImageContrastAdjust [(counter2-1)*imageDimensionY+counter3][counter4*3+2]]++;
                                        }
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < 256; counter3++) arrayImageContrastAdjustHistogramB [(counter2-1)*256+counter3] = histogramTemp [counter3];
                            }
                        }
                        
                        //-----Contrast data set-----
                        for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                        
                        for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                            for (int counter3 = 0; counter3 < 256; counter3++){
                                histogramTemp [counter3] = histogramTemp [counter3]+arrayImageContrastAdjustHistogram [(counter2-1)*256+counter3];
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < 256; counter2++) arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter2] = histogramTemp [counter2];
                        
                        for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++) arrayTableDisplay [counter2*5+2] = contrastCurrentHold [counter2];
                        
                        //-----G Table set----
                        for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                        
                        for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                            for (int counter3 = 0; counter3 < 256; counter3++){
                                histogramTemp [counter3] = histogramTemp [counter3]+arrayImageContrastAdjustHistogramG [(counter2-1)*256+counter3];
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < 256; counter2++) arrayImageContrastAdjustHistogramG [loadImageFOVNo*256+counter2] = histogramTemp [counter2];
                        
                        for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++) arrayTableDisplayG [counter2*5+2] = contrastCurrentHoldG [counter2];
                        
                        //-----B Table set----
                        for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                        
                        for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                            for (int counter3 = 0; counter3 < 256; counter3++){
                                histogramTemp [counter3] = histogramTemp [counter3]+arrayImageContrastAdjustHistogramB [(counter2-1)*256+counter3];
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < 256; counter2++) arrayImageContrastAdjustHistogramB [loadImageFOVNo*256+counter2] = histogramTemp [counter2];
                        
                        for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++) arrayTableDisplayB [counter2*5+2] = contrastCurrentHoldB [counter2];
                    }
                    
                    delete [] cutOffTemp;
                    delete [] cutOffTempG;
                    delete [] cutOffTempB;
                    delete [] contrastTemp;
                    delete [] contrastTempG;
                    delete [] contrastTempB;
                    delete [] processStatusTemp;
                }
                
                if (contrastFirstRead == 0) contrastFirstRead = 1;
                
                delete [] histogramTemp;
                
                imageInfoDisplayCall = 1;
                
                if (processType == 1 || processType == 2 || processType == 3 || processType == 4 || processType == 5){
                    for (int counter1 = 0; counter1 < stitchImageDimension; counter1++){
                        for (int counter2 = 0; counter2 < stitchImageDimension; counter2++){
                            if (photoMetricHold == 1){
                                if (colorNameHoldStatus == 0) imageDisplayArray [counter1][counter2] = 100;
                                else imageDisplayArray [counter1][counter2] = 0;
                                
                                imagePositionMap [counter1][counter2] = 0;
                            }
                            else if (photoMetricHold == 2){
                                if (colorNameHoldStatus == 0){
                                    imageDisplayArray [counter1][counter2*3] = 100;
                                    imageDisplayArray [counter1][counter2*3+1] = 100;
                                    imageDisplayArray [counter1][counter2*3+2] = 100;
                                }
                                else{
                                    
                                    imageDisplayArray [counter1][counter2*3] = 0;
                                    imageDisplayArray [counter1][counter2*3+1] = 0;
                                    imageDisplayArray [counter1][counter2*3+2] = 0;
                                }
                                
                                imagePositionMap [counter1][counter2*3] = 0;
                                imagePositionMap [counter1][counter2*3+1] = 0;
                                imagePositionMap [counter1][counter2*3+2] = 0;
                            }
                        }
                    }
                    
                    objectMatch = [[ObjectMatch alloc] init];
                    [objectMatch overlapCheck];
                }
                
                for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                    if (photoMetricHold == 1){
                        for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                if (counter2+arrayXYWritingPosition [counter1*2+1] >= 0 && counter2+arrayXYWritingPosition [counter1*2+1] < stitchImageDimension && counter3+arrayXYWritingPosition [counter1*2] >= 0 && counter3+arrayXYWritingPosition [counter1*2] < stitchImageDimension){
                                    if (arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3] >= 0){
                                        imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3];
                                    }
                                    else imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = 0;
                                    
                                    imagePositionMap [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = counter1;
                                }
                            }
                        }
                    }
                    else if (photoMetricHold == 2){
                        for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                if (counter2+arrayXYWritingPosition [counter1*2+1] >= 0 && counter2+arrayXYWritingPosition [counter1*2+1] < stitchImageDimension && counter3+arrayXYWritingPosition [counter1*2] >= 0 && counter3+arrayXYWritingPosition [counter1*2] < stitchImageDimension){
                                    if (arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3] >= 0){
                                        imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3] = arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3];
                                        imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3+1] = arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3+1];
                                        imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3+2] = arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3+2];
                                    }
                                    else{
                                        
                                        imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3] = 0;
                                        imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3+1] = 0;
                                        imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3+2] = 0;
                                    }
                                    
                                    imagePositionMap [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3] = counter1;
                                    imagePositionMap [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3+1] = counter1;
                                    imagePositionMap [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3+2] = counter1;
                                }
                            }
                        }
                    }
                }
                
                histoMaxCount = 0;
                
                if (processingFovNo == -1){
                    lowValueDisplay = 0;
                    meanValueDisplay = 0;
                    highValueDisplay = 0;
                    lowValueDisplayG = 0;
                    meanValueDisplayG = 0;
                    highValueDisplayG = 0;
                    lowValueDisplayB = 0;
                    meanValueDisplayB = 0;
                    highValueDisplayB = 0;
                    
                    for (int counter1 = 1; counter1 < 256; counter1++){
                        if (arrayImageCutoffAdjustHistogram [loadImageFOVNo*256+counter1] > histoMaxCount) histoMaxCount = arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter1];
                        
                        if (photoMetricHold == 2){
                            if (arrayImageCutoffAdjustHistogramG [loadImageFOVNo*256+counter1] > histoMaxCount) histoMaxCount = arrayImageContrastAdjustHistogramG [loadImageFOVNo*256+counter1];
                            if (arrayImageCutoffAdjustHistogramB [loadImageFOVNo*256+counter1] > histoMaxCount) histoMaxCount = arrayImageContrastAdjustHistogramB [loadImageFOVNo*256+counter1];
                        }
                    }
                    
                    lowValueDisplay = autoContrastCorrectLMH2 [loadImageFOVNo*3];
                    meanValueDisplay = autoContrastCorrectLMH2 [loadImageFOVNo*3+1];
                    highValueDisplay = autoContrastCorrectLMH2 [loadImageFOVNo*3+2];
                    
                    if (photoMetricHold == 2){
                        lowValueDisplayG = autoContrastCorrectLMH2G [loadImageFOVNo*3];
                        meanValueDisplayG = autoContrastCorrectLMH2G [loadImageFOVNo*3+1];
                        highValueDisplayG = autoContrastCorrectLMH2G [loadImageFOVNo*3+2];
                        
                        lowValueDisplayB = autoContrastCorrectLMH2B [loadImageFOVNo*3];
                        meanValueDisplayB = autoContrastCorrectLMH2B [loadImageFOVNo*3+1];
                        highValueDisplayB = autoContrastCorrectLMH2B [loadImageFOVNo*3+2];
                    }
                    
                    if (histoMaxCount > 2000*loadImageFOVNo) histoMaxCount = 2000*loadImageFOVNo;
                }
                else if (processingFovNo > 0){
                    lowValueDisplay = 0;
                    meanValueDisplay = 0;
                    highValueDisplay = 0;
                    lowValueDisplayG = 0;
                    meanValueDisplayG = 0;
                    highValueDisplayG = 0;
                    lowValueDisplayB = 0;
                    meanValueDisplayB = 0;
                    highValueDisplayB = 0;
                    
                    for (int counter1 = 1; counter1 < 256; counter1++){
                        if (arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1] > histoMaxCount) histoMaxCount = arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1];
                        
                        if (photoMetricHold == 2){
                            if (arrayImageContrastAdjustHistogramG [(processingFovNo-1)*256+counter1] > histoMaxCount) histoMaxCount = arrayImageContrastAdjustHistogramG [(processingFovNo-1)*256+counter1];
                            if (arrayImageContrastAdjustHistogramB [(processingFovNo-1)*256+counter1] > histoMaxCount) histoMaxCount = arrayImageContrastAdjustHistogramB [(processingFovNo-1)*256+counter1];
                        }
                    }
                    
                    lowValueDisplay = autoContrastCorrectLMH2 [(processingFovNo-1)*3];
                    meanValueDisplay = autoContrastCorrectLMH2 [(processingFovNo-1)*3+1];
                    highValueDisplay = autoContrastCorrectLMH2 [(processingFovNo-1)*3+2];
                    
                    if (photoMetricHold == 2){
                        lowValueDisplayG = autoContrastCorrectLMH2G [(processingFovNo-1)*3];
                        meanValueDisplayG = autoContrastCorrectLMH2G [(processingFovNo-1)*3+1];
                        highValueDisplayG = autoContrastCorrectLMH2G [(processingFovNo-1)*3+2];
                        
                        lowValueDisplayB = autoContrastCorrectLMH2B [(processingFovNo-1)*3];
                        meanValueDisplayB = autoContrastCorrectLMH2B [(processingFovNo-1)*3+1];
                        highValueDisplayB = autoContrastCorrectLMH2B [(processingFovNo-1)*3+2];
                    }
                    
                    if (histoMaxCount > 2000) histoMaxCount = 2000;
                }
                
                currentFOVNoHold = 0;
                contrastValueDisplay = 0;
                
                if (contrastValueCount == 1){
                    delete [] contrastValueHold;
                    
                    if (photoMetricHold == 2){
                        delete [] contrastValueHoldG;
                        delete [] contrastValueHoldB;
                    }
                }
                
                contrastValueHold = new double [loadImageFOVNo+5];
                
                if (photoMetricHold == 2){
                    contrastValueHoldG = new double [loadImageFOVNo+5];
                    contrastValueHoldB = new double [loadImageFOVNo+5];
                }
                
                for (int counter1 = 0; counter1 <= loadImageFOVNo+1; counter1++){
                    contrastValueHold [counter1] = 0;
                    
                    if (photoMetricHold == 2){
                        contrastValueHoldG [counter1] = 0;
                        contrastValueHoldB [counter1] = 0;
                    }
                }
                
                tableViewCall = 1;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMainImage object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToHistogram object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToContrastWindow object:self];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"FOV Folder Issue"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Entry Found"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (treatNameRead == "ND"){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Choose A Treatment To Proceed"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (treatNameRead != "ND" && loadImageTreatName == treatNameRead){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select A New Treatment"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Choose A Treatment To Proceed"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

@end
