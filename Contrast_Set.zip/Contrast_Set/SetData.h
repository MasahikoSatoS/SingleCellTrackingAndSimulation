//
//  SetData.h
//  Contrast_Set
//
//  Created by Masahiko Sato on 2014-06-20.
//  Copyright Masahiko Sato 2014 All rights reserved.
//
//

#ifndef SETDATA_H
#define SETDATA_H
#import "Controller.h" 
#endif

@interface SetData : NSObject {
    id subprocesses;
}

-(void)setDataMain;

@end

