//
//  ObjectMatch.h
//  Contrast_Set
//
//  Created by Masahiko Sato on 2014-04-08.
//  Copyright Masahiko Sato 2014 All rights reserved.
//

#ifndef OBJECTMATCH_H
#define OBJECTMATCH_H
#import "Controller.h" 
#endif

@interface ObjectMatch : NSObject {
}

-(void)overlapCheck;
-(void)objectMatchMain:(int)orientationType;

@end
