//
//  BackgroundController.m
//  Contrast_Set
//
//  Created by Masahiko Sato on 4/7/16.
//
//

#import "BackgroundController.h"

NSString *notificationToBackgroundController = @"notificationToExecuteBackgroundController";

@implementation BackgroundController

-(id)init{
    self = [super init];
    
    if (self != nil){
        timingCount = 0;
        
        sliderUpMax = 10;
        sliderUpMin = -10;
        sliderUpDiff = 20;
        sliderDownMax = 10;
        sliderDownMin = -10;
        sliderDownDiff = 20;
        sliderGainMax = 50;
        sliderGainMin = -50;
        sliderGainDiff = 100;
        
        sliderExUpMax = 20;
        sliderExUpMin = 0.01;
        sliderExUpDiff = 19.99;
        sliderExDownMax = 20;
        sliderExDownMin = 0.01;
        sliderExDownDiff = 19.99;
        sliderExRightMax = 20;
        sliderExRightMin = 0.01;
        sliderExRightDiff = 19.99;
        sliderExLeftMax = 20;
        sliderExLeftMin = 0.01;
        sliderExLeftDiff = 19.99;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToBackgroundController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    backgroundWindowController = [[NSWindowController alloc] initWithWindowNibName:@"BackgroundProcessing"];
    [backgroundWindowController showWindow:self];
    
    if (backArraysSetStatus == 0){
        backArraysSetStatus = 1;
        
        backBaseArray = new int *[imageDimensionY+1];
        backBaseMap = new int *[imageDimensionY+1];
        backBaseArrayModify = new int *[imageDimensionY+1];
        backBaseArrayEdge = new int *[imageDimensionY+1];
        backAreaMapUpArray = new int *[imageDimensionY+1];
        backAreaMapDownArray = new int *[imageDimensionY+1];
        
        for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
            backBaseArray [counter1] = new int [imageDimensionX+1];
            backBaseMap [counter1] = new int [imageDimensionX+1];
            backBaseArrayModify [counter1] = new int [imageDimensionX+1];
            backBaseArrayEdge [counter1] = new int [imageDimensionX+1];
            backAreaMapUpArray [counter1] = new int [imageDimensionX+1];
            backAreaMapDownArray [counter1] = new int [imageDimensionX+1];
        }
        
        backAreaLineUpArray = new int [imageDimensionX*imageDimensionY*2+1];
        backAreaLineUpArrayCount = 0;
        
        backAreaLineDownArray = new int [imageDimensionX*imageDimensionY*2+1];
        backAreaLineDownArrayCount = 0;
        
        backBaseArrayPrevious = new int *[10];
        
        for (int counter1 = 0; counter1 < 10; counter1++) backBaseArrayPrevious [counter1] = new int [imageDimensionX*imageDimensionY+1];
        
        backBasePositionArray = new int [10];
        
        for (int counter1 = 0; counter1 < 10; counter1++) backBasePositionArray [counter1] = 0;
    }
    
    if (backgroundPatternFirstSet == 0){
        string xDimensionString = to_string(imageDimensionX);
        string yDimensionString = to_string(imageDimensionY);
        
        int numberOfBlock = (imageDimensionX/8)*(imageDimensionY/8)*250;
        
        backgroundPatternArrayStatus = 1;
        
        backgroundPatternArray = new int [numberOfBlock+50];
        backgroundPatternArrayCount = 0;
        
        backgroundPatternModifyArray = new int [numberOfBlock+50];
        backgroundPatternModifyArrayCount = 0;
        
        backgroundPatternName = new string [260];
        
        string patternPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/BKPattern"+"-"+xDimensionString+"&"+yDimensionString+".dat";
        
        ifstream fin;
        
        fin.open(patternPath.c_str(), ios::in);
        
        if (fin.is_open()){
            string getString;
            
            do{
                
                getline(fin, getString);
                
                if (getString != "") backgroundPatternArray [backgroundPatternArrayCount] = atoi(getString.c_str()), backgroundPatternArrayCount++;
                
            } while (getString != "");
            
            fin.close();
            
            backgroundPatternFirstSet = 1;
            
            patternPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/BKPatternModify"+"-"+xDimensionString+"&"+yDimensionString+".dat";
            
            fin.open(patternPath.c_str(), ios::in);
            
            if (fin.is_open()){
                do{
                    
                    getline(fin, getString);
                    
                    if (getString != "") backgroundPatternModifyArray [backgroundPatternModifyArrayCount] = atoi(getString.c_str()), backgroundPatternModifyArrayCount++;
                    
                } while (getString != "");
                
                fin.close();
            }
            
            patternPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/BKPatternName"+"-"+xDimensionString+"&"+yDimensionString+".dat";
            
            int backgroundPatternNameCount = 0;
            
            for (int counter1 = 0; counter1 < 250; counter1++) backgroundPatternName [counter1] = "nil";
            
            fin.open(patternPath.c_str(), ios::in);
            
            if (fin.is_open()){
                do{
                    
                    getline(fin, getString);
                    
                    if (getString != "") backgroundPatternName [backgroundPatternNameCount] = getString, backgroundPatternNameCount++;
                    
                } while (getString != "");
                
                fin.close();
            }
        }
        else{
            
            backgroundPatternArrayCount = 0;
            backgroundPatternModifyArrayCount = 0;
        }
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [backgroundMainWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [backgroundMainWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [treatmentAdjust setStringValue:@(loadImageTreatName.c_str())];
    [displayImageStatus setStringValue:@"Background"];
    
    [cutUpDisplay1 setIntegerValue:contrastCutOff1];
    [cutDownDisplay1 setIntegerValue:contrastCutOff3];
    [gainDisplay setIntegerValue:contrastCutOffAS];
    
    [sliderUpKnob1 setDoubleValue:baseContrastSet1];
    [sliderDownKnob1 setDoubleValue:baseContrastSet3];
    [sliderAddSubtractKnob setDoubleValue:baseContrastSetAS];
    
    int valueDisplayTemp = (int)(baseContrastSet1*100);
    double valueDisplayTemp2 = valueDisplayTemp/(double)100;
    
    [sliderValueDisplay1 setDoubleValue:valueDisplayTemp2];
    
    valueDisplayTemp = (int)(baseContrastSet3*100);
    valueDisplayTemp2 = valueDisplayTemp/(double)100;
    
    [sliderValueDisplay3 setDoubleValue:valueDisplayTemp2];
    
    valueDisplayTemp = (int)(baseContrastSetAS*100);
    valueDisplayTemp2 = valueDisplayTemp/(double)100;
    
    [addSubtractDisplay setDoubleValue:valueDisplayTemp2];
    
    valueDisplayTemp = (int)(expansionUPCurrent*100);
    valueDisplayTemp2 = valueDisplayTemp/(double)100;
    
    [extensionUpDisplay setDoubleValue:valueDisplayTemp2];
    [sliderExtensionKnobUp setDoubleValue:expansionUPCurrent];
    
    valueDisplayTemp = (int)(expansionDownCurrent*100);
    valueDisplayTemp2 = valueDisplayTemp/(double)100;
    
    [extensionDownDisplay setDoubleValue:valueDisplayTemp2];
    [sliderExtensionKnobDown setDoubleValue:expansionDownCurrent];
    
    valueDisplayTemp = (int)(expansionRightCurrent*100);
    valueDisplayTemp2 = valueDisplayTemp/(double)100;
    
    [extensionRightDisplay setDoubleValue:valueDisplayTemp2];
    [sliderExtensionKnobRight setDoubleValue:expansionRightCurrent];
    
    valueDisplayTemp = (int)(expansionLeftCurrent*100);
    valueDisplayTemp2 = valueDisplayTemp/(double)100;
    
    [extensionLeftDisplay setDoubleValue:valueDisplayTemp2];
    [sliderExtensionKnobLeft setDoubleValue:expansionLeftCurrent];
    
    expansionUPPosition1 = 0;
    expansionUPPosition2 = 0;
    
    [extensionUpLine1 setIntegerValue:(long)expansionUPPosition1];
    [extensionUpLine2 setIntegerValue:(long)expansionUPPosition2];
    
    expansionDownPosition1 = imageDimensionY-1;
    expansionDownPosition2 = imageDimensionY-1;
    
    [extensionDownLine1 setIntegerValue:(long)expansionDownPosition1];
    [extensionDownLine2 setIntegerValue:(long)expansionDownPosition2];
    
    expansionRightPosition1 = imageDimensionX-1;
    expansionRightPosition2 = imageDimensionX-1;
    
    [extensionRightLine1 setIntegerValue:(long)expansionRightPosition1];
    [extensionRightLine2 setIntegerValue:(long)expansionRightPosition2];
    
    expansionLeftPosition1 = 0;
    expansionLeftPosition2 = 0;
    
    [extensionLeftLine1 setIntegerValue:(long)expansionLeftPosition1];
    [extensionLeftLine2 setIntegerValue:(long)expansionLeftPosition2];
    
    [sliderExUpCircle setDoubleValue:1];
    [sliderExUpLineCircle1 setDoubleValue:1];
    [sliderExUpLineCircle2 setDoubleValue:1];
    [sliderExUpLineCircle3 setDoubleValue:1];
    [sliderExUpLineCircle4 setDoubleValue:1];
    
    [sliderExDownCircle setDoubleValue:1];
    [sliderExDownLineCircle1 setDoubleValue:1];
    [sliderExDownLineCircle2 setDoubleValue:1];
    [sliderExDownLineCircle3 setDoubleValue:1];
    [sliderExDownLineCircle4 setDoubleValue:1];
    
    [sliderExRightCircle setDoubleValue:1];
    [sliderExRightLineCircle1 setDoubleValue:1];
    [sliderExRightLineCircle2 setDoubleValue:1];
    [sliderExRightLineCircle3 setDoubleValue:1];
    [sliderExRightLineCircle4 setDoubleValue:1];
    
    [sliderExLeftCircle setDoubleValue:1];
    [sliderExLeftLineCircle1 setDoubleValue:1];
    [sliderExLeftLineCircle2 setDoubleValue:1];
    [sliderExLeftLineCircle3 setDoubleValue:1];
    [sliderExLeftLineCircle4 setDoubleValue:1];
    
    if (overlayStatusHold == 0) [overlayStatusDisplay setStringValue:@"Off"];
    else if (overlayStatusHold == 1) [overlayStatusDisplay setStringValue:@"On"];
    
    backgroundTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
}

-(void)display{
    if (treatmentBKCall == 1){
        [treatmentAdjust setStringValue:@(loadImageTreatName.c_str())];
        
        timingCount++;
        
        if (timingCount == 20){
            treatmentBKCall = 0;
            timingCount = 0;
        }
    }
}

-(IBAction)savePosition:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            int xBlockNo = 1;
            int yBlockNo = 1;
            
            if (imageDimensionX > 0) xBlockNo = imageDimensionX/8;
            if (imageDimensionY > 0) yBlockNo = imageDimensionY/8;
            
            int backgroundSave = (backgroundDisplayPage-1)*(xBlockNo*yBlockNo);
            
            for (int counter3 = 0; counter3 < imageDimensionY; counter3 = counter3+8){
                for (int counter4 = 0; counter4 < imageDimensionX; counter4 = counter4+8){
                    backgroundPatternModifyArray [backgroundSave] = backBaseArrayEdge [counter3][counter4], backgroundSave++;
                }
            }
            
            string xDimensionString = to_string(imageDimensionX);
            string yDimensionString = to_string(imageDimensionY);
            
            string patternPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/BKPatternModify"+"-"+xDimensionString+"&"+yDimensionString+".dat";
            
            ofstream oin;
            oin.open(patternPath.c_str(), ios::out);
            
            for (int counter3 = 0; counter3 < backgroundPatternModifyArrayCount; counter3++) oin<<backgroundPatternModifyArray [counter3]<<endl;
            
            oin.close();
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)saveAsPosition:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            int xBlockNo = 1;
            int yBlockNo = 1;
            
            if (imageDimensionX > 0) xBlockNo = imageDimensionX/8;
            if (imageDimensionY > 0) yBlockNo = imageDimensionY/8;
            
            if (backgroundPatternModifyArrayCount/(xBlockNo*yBlockNo) <= 250){
                for (int counter3 = 0; counter3 < imageDimensionY; counter3 = counter3+8){
                    for (int counter4 = 0; counter4 < imageDimensionX; counter4 = counter4+8){
                        backgroundPatternArray [backgroundPatternArrayCount] = backBaseArrayEdge [counter3][counter4],
                        backgroundPatternModifyArray [backgroundPatternModifyArrayCount] = backBaseArrayEdge [counter3][counter4];
                        backgroundPatternModifyArrayCount++;
                        backgroundPatternArrayCount++;
                    }
                }
                
                areaSetFlag3 = 0;
                areaSetFlag1 = 0;
                
                string xDimensionString = to_string(imageDimensionX);
                string yDimensionString = to_string(imageDimensionY);
                
                string patternPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/BKPatternModify"+"-"+xDimensionString+"&"+yDimensionString+".dat";
                
                ofstream oin;
                
                oin.open(patternPath.c_str(), ios::out);
                
                for (int counter3 = 0; counter3 < backgroundPatternModifyArrayCount; counter3++) oin<<backgroundPatternModifyArray [counter3]<<endl;
                
                oin.close();
                
                patternPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/BKPattern"+"-"+xDimensionString+"&"+yDimensionString+".dat";
                
                oin.open(patternPath.c_str(), ios::out);
                
                for (int counter3 = 0; counter3 < backgroundPatternArrayCount; counter3++) oin<<backgroundPatternArray [counter3]<<endl;
                
                oin.close();
                
                backgroundDisplayPage = backgroundPatternArrayCount/(xBlockNo*yBlockNo);
                backgroundOriginalLoadFlag = 1;
                
                subprocesses = [[SubProcesses alloc] init];
                [subprocesses variableSave];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Max BK Images (250) Saved"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageOriginal:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            backgroundOriginalLoadFlag = 0;
            areaSetFlag3 = 0;
            areaSetFlag1 = 0;
            [displayImageStatus setStringValue:@"Original"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageBackground:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            backgroundOriginalLoadFlag = 1;
            areaSetFlag3 = 0;
            areaSetFlag1 = 0;
            [displayImageStatus setStringValue:@"Background"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageModify:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundOriginalLoadFlag == 1 || backgroundOriginalLoadFlag == 2 || backgroundOriginalLoadFlag == 3 || backgroundOriginalLoadFlag == 4){
                backgroundOriginalLoadFlag = 2;
                
                if (backBasePositionArray [0] == 0){
                    for (int counter1 = 0; counter1 < 10; counter1++) backBasePositionArray [counter1] = 0;
                    
                    int entryCount = 0;
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            backBaseArrayPrevious [0][entryCount] = backBaseArray [counter2][counter3], entryCount++;
                        }
                    }
                    
                    backBasePositionArray [0] = 1;
                }
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        backBaseArrayModify [counter2][counter3] = backBaseArray [counter2][counter3];
                        backBaseArrayEdge [counter2][counter3] = backBaseArray [counter2][counter3];
                    }
                }
                
                [displayImageStatus setStringValue:@"Modify"];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageAdjust:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundOriginalLoadFlag == 1 || backgroundOriginalLoadFlag == 2 || backgroundOriginalLoadFlag == 3 || backgroundOriginalLoadFlag == 4){
                backgroundOriginalLoadFlag = 3;
                [displayImageStatus setStringValue:@"Adjust"];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)edgeSet:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundOriginalLoadFlag == 1 || backgroundOriginalLoadFlag == 2 || backgroundOriginalLoadFlag == 3 || backgroundOriginalLoadFlag == 4){
                backgroundOriginalLoadFlag = 4;
                [displayImageStatus setStringValue:@"Edge"];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)createBackground:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0 && imageDimensionY > 0 && imageDimensionX > 0){
            int xBlockNo = 1;
            int yBlockNo = 1;
            
            if (imageDimensionX > 0) xBlockNo = imageDimensionX/8;
            if (imageDimensionY > 0) yBlockNo = imageDimensionY/8;
            
            if (backgroundPatternArrayCount < xBlockNo*yBlockNo*250){
                if (backgroundOriginalLoadFlag == 0){
                    double maskMatrix [5][5] = {{0.0035, 0.0145, 0.0256, 0.0145, 0.0035}, {0.0145, 0.0586, 0.0952, 0.0556, 0.0145}, {0.0256, 0.0952, 0.1501, 0.0952, 0.0256}, {0.0145, 0.0586, 0.0952, 0.0586, 0.0145}, {0.0035, 0.0145, 0.0256, 0.0145, 0.0035}};
                    
                    int **backgroundImage1 = new int *[imageDimensionY+1];
                    int **gaussianImage = new int *[imageDimensionY+1];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                        backgroundImage1 [counter1] = new int [imageDimensionX+1];
                        gaussianImage [counter1] = new int [imageDimensionX+1];
                    }
                    
                    int **imageMatrixTemp2 = new int *[yBlockNo+1];
                    int **middleIntensity = new int *[yBlockNo+1];
                    
                    for (int counter1 = 0; counter1 < yBlockNo+1; counter1++){
                        imageMatrixTemp2  [counter1] = new int [xBlockNo+1];
                        middleIntensity  [counter1] = new int [xBlockNo+1];
                    }
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            gaussianImage [counter2][counter3] = 0;
                            backgroundImage1 [counter2][counter3] = arrayImageContrastAdjust [(currentOriginalNo-1)*imageDimensionY+counter2][counter3];
                        }
                    }
                    double bitGaussian = 0;
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            bitGaussian = 0;
                            
                            for (int counter4 = -2; counter4 <= 2; counter4++){
                                for (int counter5 = -2; counter5 <= 2; counter5++){
                                    if (counter2+counter4 >= imageDimensionY || counter2+counter4 < 0 || counter3+counter5 >= imageDimensionX || counter3+counter5 < 0){
                                        bitGaussian = bitGaussian+backgroundImage1 [counter2][counter3]*maskMatrix [counter4+2][counter5+2];
                                    }
                                    else bitGaussian = bitGaussian+backgroundImage1 [counter2+counter4][counter3+counter5]*maskMatrix [counter4+2][counter5+2];
                                }
                            }
                            
                            gaussianImage [counter2][counter3] = (int)bitGaussian;
                        }
                    }
                    
                    int middleDataAverage = 0;
                    int middleDataLow = 10000;
                    int flattenPixCount = 0;
                    int totalForAverage = 0;
                    int middleCount = 0;
                    int middleData = 0;
                    
                    double averagePix = 0;
                    double totalForStandardDev = 0;
                    
                    //-----Image matrix set: Determine SD -----
                    for (int counter2 = 0; counter2 < yBlockNo; counter2++){
                        for (int counter3 = 0; counter3 < xBlockNo; counter3++){
                            flattenPixCount = 0;
                            totalForAverage = 0;
                            totalForStandardDev = 0;
                            middleCount = 0;
                            middleData = 0;
                            
                            //-----For Sd calculation-----
                            for (int counter4 = counter2*8; counter4 < counter2*8+8; counter4++){
                                for (int counter5 = counter3*8; counter5 < counter3*8+8; counter5++){
                                    totalForAverage = totalForAverage+gaussianImage [counter4][counter5], flattenPixCount++;
                                }
                            }
                            
                            //-----For middle intensity-----
                            for (int counter4 = counter2*8; counter4 < counter2*8+8; counter4++){
                                for (int counter5 = counter3*8; counter5 < counter3*8+8; counter5++){
                                    if (gaussianImage [counter4][counter5] > 75 && gaussianImage [counter4][counter5] < 175){
                                        middleData = middleData+gaussianImage [counter4][counter5], middleCount++;
                                    }
                                }
                            }
                            
                            if (middleCount != 0) middleIntensity [counter2][counter3] = (int)(middleData/(double)middleCount);
                            else middleIntensity [counter2][counter3] = 0;
                            
                            middleDataAverage = middleDataAverage+middleIntensity [counter2][counter3];
                            
                            if (middleDataLow > middleIntensity [counter2][counter3] && middleIntensity [counter2][counter3] != 0) middleDataLow = middleIntensity [counter2][counter3];
                            
                            //-----SD calculation-----
                            averagePix = totalForAverage/(double)64;
                            
                            for (int counter4 = counter2*8; counter4 < counter2*8+8; counter4++){
                                for (int counter5 = counter3*8; counter5 < counter3*8+8; counter5++){
                                    totalForStandardDev = totalForStandardDev+(gaussianImage [counter4][counter5]-averagePix)*(gaussianImage [counter4][counter5]-averagePix);
                                }
                            }
                            
                            imageMatrixTemp2 [counter2][counter3] = (int)averagePix;
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < yBlockNo; counter1++){
                        for (int counter2 = 0; counter2 < xBlockNo; counter2++){
                            backgroundPatternArray [backgroundPatternArrayCount] = imageMatrixTemp2 [counter1][counter2], backgroundPatternArrayCount++;
                            backgroundPatternModifyArray [backgroundPatternModifyArrayCount] = imageMatrixTemp2 [counter1][counter2], backgroundPatternModifyArrayCount++;
                        }
                    }
                    
                    areaSetFlag3 = 0;
                    areaSetFlag1 = 0;
                    
                    string xDimensionString = to_string(imageDimensionX);
                    string yDimensionString = to_string(imageDimensionY);
                    
                    string patternPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/BKPattern"+"-"+xDimensionString+"&"+yDimensionString+".dat";
                    
                    ofstream oin;
                    
                    oin.open(patternPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < backgroundPatternArrayCount; counter1++) oin<<backgroundPatternArray [counter1]<<endl;
                    
                    oin.close();
                    
                    patternPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/BKPatternModify"+"-"+xDimensionString+"&"+yDimensionString+".dat";
                    
                    oin.open(patternPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < backgroundPatternModifyArrayCount; counter1++) oin<<backgroundPatternModifyArray [counter1]<<endl;
                    
                    oin.close();
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    backgroundDisplayPage = backgroundPatternArrayCount/(xBlockNo*yBlockNo);
                    backgroundOriginalLoadFlag = 1;
                    
                    for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                        delete [] backgroundImage1 [counter1];
                        delete [] gaussianImage [counter1];
                    }
                    
                    delete [] backgroundImage1;
                    delete [] gaussianImage;
                    
                    for (int counter1 = 0; counter1 < yBlockNo+1; counter1++){
                        delete [] imageMatrixTemp2  [counter1];
                        delete [] middleIntensity [counter1];
                    }
                    
                    delete [] imageMatrixTemp2;
                    delete [] middleIntensity;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Original Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Exceed The Limit: Max 250 Patterns"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)backgroundJump:(id)sender{
    if (loadImageTreatName != ""){
        int copyTimeNumber = (int)[inputField integerValue];
        [inputField setStringValue:@""];
        
        int proceedingFlag = 0;
        
        if (copyTimeNumber > 0){
            if (backgroundOriginalLoadFlag == 0){
                if (copyTimeNumber <= loadImageFOVNo){
                    currentOriginalNo = copyTimeNumber;
                    proceedingFlag = 1;
                }
            }
            
            int xBlockNo = 1;
            int yBlockNo = 1;
            
            if (imageDimensionX > 0) xBlockNo = imageDimensionX/8;
            if (imageDimensionY > 0) yBlockNo = imageDimensionY/8;
            
            if (backgroundOriginalLoadFlag == 1 && backgroundPatternModifyArrayCount != 0){
                if (copyTimeNumber <= backgroundPatternModifyArrayCount/(xBlockNo*yBlockNo)){
                    backgroundDisplayPage = copyTimeNumber;
                    proceedingFlag = 1;
                }
            }
            
            areaSetFlag3 = 0;
            areaSetFlag1 = 0;
            
            subprocesses = [[SubProcesses alloc] init];
            [subprocesses variableSave];
            
            if (proceedingFlag == 1){
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)deleteBackground:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 1){
                    int *backgroundPatternArrayTemp = new int [backgroundPatternArrayCount+50];
                    int *backgroundPatternArrayTemp2 = new int [backgroundPatternModifyArrayCount+50];
                    int backgroundPatternArrayTempCount = 0;
                    
                    int xBlockNo = 1;
                    int yBlockNo = 1;
                    
                    if (imageDimensionX > 0) xBlockNo = imageDimensionX/8;
                    if (imageDimensionY > 0) yBlockNo = imageDimensionY/8;
                    
                    for (int counter1 = 0; counter1 < backgroundPatternArrayCount/(xBlockNo*yBlockNo); counter1++){
                        if (counter1 != (backgroundDisplayPage-1)){
                            for (int counter2 = 0; counter2 < yBlockNo; counter2++){
                                for (int counter3 = 0; counter3 < xBlockNo; counter3++){
                                    backgroundPatternArrayTemp [backgroundPatternArrayTempCount] = backgroundPatternArray [counter1*(xBlockNo*yBlockNo)+counter2*yBlockNo+counter3];
                                    backgroundPatternArrayTemp2 [backgroundPatternArrayTempCount] = backgroundPatternModifyArray [counter1*(xBlockNo*yBlockNo)+counter2*yBlockNo+counter3];
                                    backgroundPatternArrayTempCount++;
                                }
                            }
                        }
                    }
                    
                    for (int counter1 = backgroundDisplayPage-1; counter1 < backgroundPatternArrayCount/(xBlockNo*yBlockNo); counter1++){
                        backgroundPatternName [counter1] = backgroundPatternName [counter1+1];
                    }
                    
                    string backExtract;
                    string mainExtract;
                    string balanceExtract;
                    
                    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                        if ((int)arrayTableDisplay [counter1*5+2].find(":") != -1){
                            backExtract = arrayTableDisplay [counter1*5+2].substr(arrayTableDisplay [counter1*5+2].find(":")+1, arrayTableDisplay [counter1*5+2].find("~")-arrayTableDisplay [counter1*5+2].find(":")-1);
                            
                            mainExtract = arrayTableDisplay [counter1*5+2].substr(0, arrayTableDisplay [counter1*5+2].find(":")+1);
                            balanceExtract = arrayTableDisplay [counter1*5+2].substr(arrayTableDisplay [counter1*5+2].find("~"));
                            
                            if (backExtract != "0"){
                                if (atoi(backExtract.c_str()) == backgroundDisplayPage){
                                    backExtract = "0";
                                }
                                else if (atoi(backExtract.c_str()) > backgroundDisplayPage){
                                    backExtract = to_string(atoi(backExtract.c_str())-1);
                                }
                                
                                arrayTableDisplay [counter1*5+2] = mainExtract+backExtract+balanceExtract;
                            }
                        }
                        
                        if ((int)arrayTableDisplay [counter1*5+3].find(":") != -1){
                            backExtract = arrayTableDisplay [counter1*5+3].substr(arrayTableDisplay [counter1*5+3].find(":")+1, arrayTableDisplay [counter1*5+3].find("~")-arrayTableDisplay [counter1*5+3].find(":")-1);
                            mainExtract = arrayTableDisplay [counter1*5+3].substr(0, arrayTableDisplay [counter1*5+3].find(":")+1);
                            balanceExtract = arrayTableDisplay [counter1*5+3].substr(arrayTableDisplay [counter1*5+3].find("~"));
                            
                            if (backExtract != "0"){
                                if (atoi(backExtract.c_str()) == backgroundDisplayPage){
                                    backExtract = "0";
                                }
                                else if (atoi(backExtract.c_str()) > backgroundDisplayPage){
                                    backExtract = to_string(atoi(backExtract.c_str())-1);
                                }
                                
                                arrayTableDisplay [counter1*5+3] = mainExtract+backExtract+balanceExtract;
                            }
                        }
                        
                        if ((int)arrayTableDisplay [counter1*5+4].find(":") != -1){
                            backExtract = arrayTableDisplay [counter1*5+4].substr(arrayTableDisplay [counter1*5+4].find(":")+1, arrayTableDisplay [counter1*5+4].find("~")-arrayTableDisplay [counter1*5+4].find(":")-1);
                            mainExtract = arrayTableDisplay [counter1*5+4].substr(0, arrayTableDisplay [counter1*5+4].find(":")+1);
                            balanceExtract = arrayTableDisplay [counter1*5+4].substr(arrayTableDisplay [counter1*5+4].find("~"));
                            
                            if (backExtract != "0"){
                                if (atoi(backExtract.c_str()) == backgroundDisplayPage){
                                    backExtract = "0";
                                }
                                else if (atoi(backExtract.c_str()) > backgroundDisplayPage){
                                    backExtract = to_string(atoi(backExtract.c_str())-1);
                                }
                                
                                arrayTableDisplay [counter1*5+4] = mainExtract+backExtract+balanceExtract;
                            }
                        }
                    }
                    
                    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                        contrastCurrentHold [counter1] = arrayTableDisplay [counter1*5+2];
                    }
                    
                    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                        for (int counter2 = 0; counter2 < entryNumber+3; counter2++){
                            if ((int)arrayContrastData [counter1][counter2].find(":") != -1){
                                backExtract = arrayContrastData [counter1][counter2].substr(arrayContrastData [counter1][counter2].find(":")+1, arrayContrastData [counter1][counter2].find("~")-arrayContrastData [counter1][counter2].find(":")-1);
                                mainExtract = arrayContrastData [counter1][counter2].substr(0, arrayContrastData [counter1][counter2].find(":")+1);
                                balanceExtract = arrayContrastData [counter1][counter2].substr(arrayContrastData [counter1][counter2].find("~"));
                                
                                if (backExtract != "0"){
                                    if (atoi(backExtract.c_str()) == backgroundDisplayPage){
                                        backExtract = "0";
                                    }
                                    else if (atoi(backExtract.c_str()) > backgroundDisplayPage){
                                        backExtract = to_string(atoi(backExtract.c_str())-1);
                                    }
                                    
                                    arrayContrastData [counter1][counter2] = mainExtract+backExtract+balanceExtract;
                                }
                            }
                        }
                    }
                    
                    string productsContrastPath = productsFilesInfoPath+"/"+"CT-ContrastData";
                    
                    ofstream oin;
                    
                    oin.open(productsContrastPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                        for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastData [counter1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    if (backgroundPatternArrayTempCount == 0){
                        backgroundPatternArrayCount = 0;
                        backgroundPatternModifyArrayCount = 0;
                        backgroundDisplayPage = 0;
                        
                        subprocesses = [[SubProcesses alloc] init];
                        [subprocesses variableSave];
                    }
                    else{
                        
                        backgroundPatternArrayCount = 0;
                        backgroundPatternModifyArrayCount = 0;
                        
                        for (int counter1 = 0; counter1 < backgroundPatternArrayTempCount; counter1++){
                            backgroundPatternArray [backgroundPatternArrayCount] = backgroundPatternArrayTemp [counter1], backgroundPatternArrayCount++;
                            backgroundPatternModifyArray [backgroundPatternModifyArrayCount] = backgroundPatternArrayTemp2 [counter1], backgroundPatternModifyArrayCount++;
                        }
                        
                        backgroundDisplayPage--;
                        
                        if (backgroundDisplayPage == 0) backgroundDisplayPage = 1;
                        
                        string xDimensionString = to_string(imageDimensionX);
                        string yDimensionString = to_string(imageDimensionY);
                        
                        string patternPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/BKPattern"+"-"+xDimensionString+"&"+yDimensionString+".dat";
                        
                        oin.open(patternPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < backgroundPatternArrayCount; counter1++) oin<<backgroundPatternArray [counter1]<<endl;
                        
                        oin.close();
                        
                        patternPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/BKPatternModify"+"-"+xDimensionString+"&"+yDimensionString+".dat";
                        
                        oin.open(patternPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < backgroundPatternModifyArrayCount; counter1++) oin<<backgroundPatternModifyArray [counter1]<<endl;
                        
                        oin.close();
                        
                        patternPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/BKPatternName"+"-"+xDimensionString+"&"+yDimensionString+".dat";
                        
                        oin.open(patternPath.c_str(), ios::out);
                        
                        for (int counter3 = 0; counter3 < backgroundPatternArrayCount/(xBlockNo*yBlockNo); counter3++) oin<<backgroundPatternName [counter3]<<endl;
                        
                        oin.close();
                        
                        subprocesses = [[SubProcesses alloc] init];
                        [subprocesses variableSave];
                    }
                    
                    delete [] backgroundPatternArrayTemp;
                    delete [] backgroundPatternArrayTemp2;
                    
                    areaSetFlag3 = 0;
                    areaSetFlag1 = 0;
                    
                    tableViewCall = 1;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)deleteBackgroundAll:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 1){
                    string contrastDataTemp;
                    string bkNumberExtract;
                    string bkNumberFront;
                    string bkNumberBack;
                    
                    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                        contrastDataTemp = arrayTableDisplay [counter1*5+2];
                        
                        if ((int)contrastDataTemp.find(":") != -1 && (int)contrastDataTemp.find("~") != -1){
                            bkNumberExtract = contrastDataTemp.substr(contrastDataTemp.find(":")+1, contrastDataTemp.find("~")-contrastDataTemp.find(":")-1);
                            
                            if (atoi(bkNumberExtract.c_str()) != 0){
                                bkNumberFront = contrastDataTemp.substr(0, contrastDataTemp.find(":")+1);
                                bkNumberBack = contrastDataTemp.substr(contrastDataTemp.find("~"));
                                arrayTableDisplay [counter1*5+2] = bkNumberFront+"0"+bkNumberBack;
                            }
                        }
                        
                        contrastDataTemp = arrayTableDisplay [counter1*5+3];
                        
                        if ((int)contrastDataTemp.find(":") != -1 && (int)contrastDataTemp.find("~") != -1){
                            bkNumberExtract = contrastDataTemp.substr(contrastDataTemp.find(":")+1, contrastDataTemp.find("~")-contrastDataTemp.find(":")-1);
                            
                            if (atoi(bkNumberExtract.c_str()) != 0){
                                bkNumberFront = contrastDataTemp.substr(0, contrastDataTemp.find(":")+1);
                                bkNumberBack = contrastDataTemp.substr(contrastDataTemp.find("~"));
                                arrayTableDisplay [counter1*5+3] = bkNumberFront+"0"+bkNumberBack;
                            }
                        }
                        
                        contrastDataTemp = arrayTableDisplay [counter1*5+4];
                        
                        if ((int)contrastDataTemp.find(":") != -1 && (int)contrastDataTemp.find("~") != -1){
                            bkNumberExtract = contrastDataTemp.substr(contrastDataTemp.find(":")+1, contrastDataTemp.find("~")-contrastDataTemp.find(":")-1);
                            
                            if (atoi(bkNumberExtract.c_str()) != 0){
                                bkNumberFront = contrastDataTemp.substr(0, contrastDataTemp.find(":")+1);
                                bkNumberBack = contrastDataTemp.substr(contrastDataTemp.find("~"));
                                arrayTableDisplay [counter1*5+4] = bkNumberFront+"0"+bkNumberBack;
                            }
                        }
                    }
                    
                    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                        contrastCurrentHold [counter1] = arrayTableDisplay [counter1*5+2];
                    }
                    
                    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                        for (int counter2 = 0; counter2 < entryNumber+3; counter2++){
                            if (arrayContrastData [counter1][counter2] != ""){
                                contrastDataTemp = arrayContrastData [counter1][counter2];
                                
                                if ((int)contrastDataTemp.find(":") != -1 && (int)contrastDataTemp.find("~") != -1){
                                    bkNumberExtract = contrastDataTemp.substr(contrastDataTemp.find(":")+1, contrastDataTemp.find("~")-contrastDataTemp.find(":")-1);
                                    
                                    if (atoi(bkNumberExtract.c_str()) != 0){
                                        bkNumberFront = contrastDataTemp.substr(0, contrastDataTemp.find(":")+1);
                                        bkNumberBack = contrastDataTemp.substr(contrastDataTemp.find("~"));
                                        arrayContrastData [counter1][counter2] = bkNumberFront+"0"+bkNumberBack;
                                    }
                                }
                            }
                        }
                    }
                    
                    string productsContrastPath = productsFilesInfoPath+"/"+"CT-ContrastData";
                    
                    ofstream oin;
                    
                    oin.open(productsContrastPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                        for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastData [counter1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    backgroundPatternArrayCount = 0;
                    backgroundPatternModifyArrayCount = 0;
                    backgroundDisplayPage = 0;
                    areaSetFlag3 = 0;
                    areaSetFlag1 = 0;
                    
                    int xBlockNo = 1;
                    int yBlockNo = 1;
                    
                    if (imageDimensionX > 0) xBlockNo = imageDimensionX/8;
                    if (imageDimensionY > 0) yBlockNo = imageDimensionY/8;
                    string xDimensionString = to_string(imageDimensionX);
                    string yDimensionString = to_string(imageDimensionY);
                    
                    string patternPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/BKPatternName"+"-"+xDimensionString+"&"+yDimensionString+".dat";
                    
                    for (int counter1 = 0; counter1 < 250; counter1++) backgroundPatternName [counter1] = "nil";
                    
                    oin.open(patternPath.c_str(), ios::out);
                    
                    for (int counter3 = 0; counter3 < backgroundPatternArrayCount/(xBlockNo*yBlockNo); counter3++) oin<<backgroundPatternName [counter3]<<endl;
                    
                    oin.close();
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    tableViewCall = 1;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)deleteBackgroundUnused:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 1){
                    [self deleteBackgroundUnusedProcess];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)deleteBackgroundUnusedProcess{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        autoProcessingFlag = 1;
        
        string contrastDataTemp;
        string bkNumberExtract;
        string bkNumberFront;
        string bkNumberBack;
        string backExtract;
        string mainExtract;
        string balanceExtract;
        
        int pageNoFind = 0;
        int backgroundPatternArrayTempCount = 0;
        int terminationFlag = 0;
        
        int xBlockNo = 1;
        int yBlockNo = 1;
        
        if (imageDimensionX > 0) xBlockNo = imageDimensionX/8;
        if (imageDimensionY > 0) yBlockNo = imageDimensionY/8;
        
        progressValue = backgroundPatternArrayCount/(xBlockNo*yBlockNo);
        progressTiming = 1;
        
        do usleep(10);
        while (progressTiming == 1);
        
        int processCount = 0;
        
        do{
            
            terminationFlag = 0;
            
            processCount++;
            progressValue = processCount;
            progressTiming = 3;
            
            for (int counter1 = 0; counter1 < backgroundPatternArrayCount/(xBlockNo*yBlockNo); counter1++){
                pageNoFind = 0;
                
                for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                    for (int counter3 = 0; counter3 < entryNumber+3; counter3++){
                        if (arrayContrastData [counter2][counter3] != ""){
                            contrastDataTemp = arrayContrastData [counter2][counter3];
                            
                            if ((int)contrastDataTemp.find(":") != -1 && (int)contrastDataTemp.find("~") != -1){
                                bkNumberExtract = contrastDataTemp.substr(contrastDataTemp.find(":")+1, contrastDataTemp.find("~")-contrastDataTemp.find(":")-1);
                                
                                if (atoi(bkNumberExtract.c_str()) == counter1+1){
                                    pageNoFind = 1;
                                    break;
                                }
                            }
                        }
                    }
                    
                    if (pageNoFind == 1){
                        break;
                    }
                }
                
                if (pageNoFind == 0){
                    int *backgroundPatternArrayTemp = new int [backgroundPatternArrayCount+50];
                    int *backgroundPatternArrayTemp2 = new int [backgroundPatternModifyArrayCount+50];
                    backgroundPatternArrayTempCount = 0;
                    
                    for (int counter2 = 0; counter2 < backgroundPatternArrayCount/(xBlockNo*yBlockNo); counter2++){
                        if (counter2 != counter1){
                            for (int counter3 = 0; counter3 < yBlockNo; counter3++){
                                for (int counter4 = 0; counter4 < xBlockNo; counter4++){
                                    backgroundPatternArrayTemp [backgroundPatternArrayTempCount] = backgroundPatternArray [counter2*(xBlockNo*yBlockNo)+counter3*yBlockNo+counter4];
                                    backgroundPatternArrayTemp2 [backgroundPatternArrayTempCount] = backgroundPatternModifyArray [counter2*(xBlockNo*yBlockNo)+counter3*yBlockNo+counter4];
                                    backgroundPatternArrayTempCount++;
                                }
                            }
                        }
                    }
                    
                    for (int counter2 = counter1; counter2 < backgroundPatternArrayCount/(xBlockNo*yBlockNo); counter2++){
                        backgroundPatternName [counter2] = backgroundPatternName [counter2+1];
                    }
                    
                    for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++){
                        if ((int)arrayTableDisplay [counter2*5+2].find(":") != -1){
                            backExtract = arrayTableDisplay [counter2*5+2].substr(arrayTableDisplay [counter2*5+2].find(":")+1, arrayTableDisplay [counter2*5+2].find("~")-arrayTableDisplay [counter2*5+2].find(":")-1);
                            
                            mainExtract = arrayTableDisplay [counter2*5+2].substr(0, arrayTableDisplay [counter2*5+2].find(":")+1);
                            balanceExtract = arrayTableDisplay [counter2*5+2].substr(arrayTableDisplay [counter2*5+2].find("~"));
                            
                            if (backExtract != "0"){
                                if (atoi(backExtract.c_str()) == counter1+1){
                                    backExtract = "0";
                                }
                                else if (atoi(backExtract.c_str()) > counter1+1){
                                    backExtract = to_string(atoi(backExtract.c_str())-1);
                                }
                                
                                arrayTableDisplay [counter2*5+2] = mainExtract+backExtract+balanceExtract;
                            }
                        }
                        
                        if ((int)arrayTableDisplay [counter2*5+3].find(":") != -1){
                            backExtract = arrayTableDisplay [counter2*5+3].substr(arrayTableDisplay [counter2*5+3].find(":")+1, arrayTableDisplay [counter2*5+3].find("~")-arrayTableDisplay [counter2*5+3].find(":")-1);
                            mainExtract = arrayTableDisplay [counter2*5+3].substr(0, arrayTableDisplay [counter2*5+3].find(":")+1);
                            balanceExtract = arrayTableDisplay [counter2*5+3].substr(arrayTableDisplay [counter2*5+3].find("~"));
                            
                            if (backExtract != "0"){
                                if (atoi(backExtract.c_str()) == counter1+1){
                                    backExtract = "0";
                                }
                                else if (atoi(backExtract.c_str()) > counter1+1){
                                    backExtract = to_string(atoi(backExtract.c_str())-1);
                                }
                                
                                arrayTableDisplay [counter2*5+3] = mainExtract+backExtract+balanceExtract;
                            }
                        }
                        
                        if ((int)arrayTableDisplay [counter2*5+4].find(":") != -1){
                            backExtract = arrayTableDisplay [counter2*5+4].substr(arrayTableDisplay [counter2*5+4].find(":")+1, arrayTableDisplay [counter2*5+4].find("~")-arrayTableDisplay [counter2*5+4].find(":")-1);
                            mainExtract = arrayTableDisplay [counter2*5+4].substr(0, arrayTableDisplay [counter2*5+4].find(":")+1);
                            balanceExtract = arrayTableDisplay [counter2*5+4].substr(arrayTableDisplay [counter2*5+4].find("~"));
                            
                            if (backExtract != "0"){
                                if (atoi(backExtract.c_str()) == counter1+1){
                                    backExtract = "0";
                                }
                                else if (atoi(backExtract.c_str()) > counter1+1){
                                    backExtract = to_string(atoi(backExtract.c_str())-1);
                                }
                                
                                arrayTableDisplay [counter2*5+4] = mainExtract+backExtract+balanceExtract;
                            }
                        }
                    }
                    
                    for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++){
                        contrastCurrentHold [counter2] = arrayTableDisplay [counter2*5+2];
                    }
                    
                    //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
                    //    for (int counterB = 0; counterB < entryNumber+3; counterB++) cout<<" "<<arrayContrastData [counterA][counterB];
                    //    cout<<"  arrayContrastData "<<counterA+1<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                        for (int counter3 = 0; counter3 < entryNumber+3; counter3++){
                            if ((int)arrayContrastData [counter2][counter3].find(":") != -1){
                                backExtract = arrayContrastData [counter2][counter3].substr(arrayContrastData [counter2][counter3].find(":")+1, arrayContrastData [counter2][counter3].find("~")-arrayContrastData [counter2][counter3].find(":")-1);
                                mainExtract = arrayContrastData [counter2][counter3].substr(0, arrayContrastData [counter2][counter3].find(":")+1);
                                balanceExtract = arrayContrastData [counter2][counter3].substr(arrayContrastData [counter2][counter3].find("~"));
                                
                                if (backExtract != "0"){
                                    if (atoi(backExtract.c_str()) == counter1+1){
                                        backExtract = "0";
                                    }
                                    else if (atoi(backExtract.c_str()) > counter1+1){
                                        backExtract = to_string(atoi(backExtract.c_str())-1);
                                    }
                                    
                                    arrayContrastData [counter2][counter3] = mainExtract+backExtract+balanceExtract;
                                }
                            }
                        }
                    }
                    
                    string productsContrastPath = productsFilesInfoPath+"/"+"CT-ContrastData";
                    
                    ofstream oin;
                    
                    oin.open(productsContrastPath.c_str(), ios::out);
                    
                    for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                        for (int counter3 = 0; counter3 < entryNumber+3; counter3++) oin<<arrayContrastData [counter2][counter3]<<endl;
                    }
                    
                    oin.close();
                    
                    //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
                    //    for (int counterB = 0; counterB < entryNumber+3; counterB++) cout<<" "<<arrayContrastData [counterA][counterB];
                    //    cout<<"  arrayContrastData "<<counterA+1<<endl;
                    //}
                    
                    if (backgroundPatternArrayTempCount == 0){
                        backgroundPatternArrayCount = 0;
                        backgroundPatternModifyArrayCount = 0;
                        backgroundDisplayPage = 0;
                        
                        self->subprocesses = [[SubProcesses alloc] init];
                        [self->subprocesses variableSave];
                    }
                    else{
                        
                        backgroundPatternArrayCount = 0;
                        backgroundPatternModifyArrayCount = 0;
                        
                        for (int counter2 = 0; counter2 < backgroundPatternArrayTempCount; counter2++){
                            backgroundPatternArray [backgroundPatternArrayCount] = backgroundPatternArrayTemp [counter2], backgroundPatternArrayCount++;
                            backgroundPatternModifyArray [backgroundPatternModifyArrayCount] = backgroundPatternArrayTemp2 [counter2], backgroundPatternModifyArrayCount++;
                        }
                        
                        backgroundDisplayPage--;
                        
                        if (backgroundDisplayPage == 0) backgroundDisplayPage = 1;
                        
                        string xDimensionString = to_string(imageDimensionX);
                        string yDimensionString = to_string(imageDimensionY);
                        
                        string patternPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/BKPattern"+"-"+xDimensionString+"&"+yDimensionString+".dat";
                        
                        oin.open(patternPath.c_str(), ios::out);
                        
                        for (int counter2 = 0; counter2 < backgroundPatternArrayCount; counter2++) oin<<backgroundPatternArray [counter2]<<endl;
                        
                        oin.close();
                        
                        patternPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/BKPatternModify"+"-"+xDimensionString+"&"+yDimensionString+".dat";
                        
                        oin.open(patternPath.c_str(), ios::out);
                        
                        for (int counter2 = 0; counter2 < backgroundPatternModifyArrayCount; counter2++) oin<<backgroundPatternModifyArray [counter2]<<endl;
                        
                        oin.close();
                        
                        patternPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/BKPatternName"+"-"+xDimensionString+"&"+yDimensionString+".dat";
                        
                        oin.open(patternPath.c_str(), ios::out);
                        
                        for (int counter3 = 0; counter3 < backgroundPatternArrayCount/(xBlockNo*yBlockNo); counter3++) oin<<backgroundPatternName [counter3]<<endl;
                        
                        oin.close();
                        
                        self->subprocesses = [[SubProcesses alloc] init];
                        [self->subprocesses variableSave];
                    }
                    
                    delete [] backgroundPatternArrayTemp;
                    delete [] backgroundPatternArrayTemp2;
                    
                    terminationFlag = 1;
                    
                    break;
                }
            }
            
        } while (terminationFlag == 1);
        
        areaSetFlag3 = 0;
        areaSetFlag1 = 0;
        
        tableViewCall = 1;
        progressTiming = 5;
        
        do usleep(10);
        while (progressTiming == 5);
        
        progressTiming = 7;
        
        bkUnUsedCall = 1;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        autoProcessingFlag = 0;
    });
}

-(IBAction)backgroundNameSet:(id)sender{
    if (loadImageTreatName != ""){
        if (backgroundPatternArrayCount > 0){
            string inputData = [[inputField stringValue] UTF8String];
            [inputField setStringValue:@""];
            
            if (inputData.length() < 20){
                if (inputData.length() > 0) backgroundPatternName [backgroundDisplayPage-1] = inputData;
                else backgroundPatternName [backgroundDisplayPage-1] = "nil";
                
                int xBlockNo = 1;
                int yBlockNo = 1;
                
                if (imageDimensionX > 0) xBlockNo = imageDimensionX/8;
                if (imageDimensionY > 0) yBlockNo = imageDimensionY/8;
                string xDimensionString = to_string(imageDimensionX);
                string yDimensionString = to_string(imageDimensionY);
                
                string patternPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/BKPatternName"+"-"+xDimensionString+"&"+yDimensionString+".dat";
                
                ofstream oin;
                oin.open(patternPath.c_str(), ios::out);
                
                for (int counter3 = 0; counter3 < backgroundPatternArrayCount/(xBlockNo*yBlockNo); counter3++) oin<<backgroundPatternName [counter3]<<endl;
                
                oin.close();
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
    }
}

-(IBAction)areaLineSW:(id)sender{
    if (lineAreaStatusHold == 0){
        lineAreaStatusHold = 1;
        [areaLineDisplay setStringValue:@"Link"];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
    }
    else if (lineAreaStatusHold == 1){
        lineAreaStatusHold = 0;
        [areaLineDisplay setStringValue:@"Point"];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
    }
}

-(IBAction)sliderAreaSet:(id)sender{
    backArea = (int)[areaSet integerValue];
    
    if (backArea == 2) backArea = 3;
    if (backArea == 4) backArea = 5;
    if (backArea == 6) backArea = 7;
    if (backArea == 8) backArea = 9;
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
}

-(IBAction)setCutUp1:(id)sender{
    if (loadImageTreatName != ""){
        if (backgroundPatternArrayCount >= 1){
            if (backgroundOriginalLoadFlag == 3){
                int valueSet = (int)[inputField integerValue];
                [inputField setStringValue:@""];
                
                if (valueSet > contrastCutOff3 && valueSet < 256){
                    contrastCutOff1 = valueSet;
                    baseContrastSet1 = 0;
                    
                    [cutUpDisplay1 setIntegerValue:contrastCutOff1];
                    [sliderUpKnob1 setDoubleValue:baseContrastSet1];
                    
                    int valueDisplayTemp = (int)(baseContrastSet1*100);
                    double valueDisplayTemp2 = valueDisplayTemp/(double)100;
                    
                    [sliderValueDisplay1 setDoubleValue:valueDisplayTemp2];
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"> First Must be Larger Than < First"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Background Image Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)setCutDown1:(id)sender{
    if (loadImageTreatName != ""){
        if (backgroundPatternArrayCount >= 1){
            if (backgroundOriginalLoadFlag == 3){
                int valueSet = (int)[inputField integerValue];
                [inputField setStringValue:@""];
                
                if (valueSet < contrastCutOff1 && valueSet >= 1){
                    contrastCutOff3 = valueSet;
                    baseContrastSet3 = 0;
                    
                    [cutDownDisplay1 setIntegerValue:contrastCutOff3];
                    [sliderDownKnob1 setDoubleValue:baseContrastSet3];
                    
                    int valueDisplayTemp = (int)(baseContrastSet3*100);
                    double valueDisplayTemp2 = valueDisplayTemp/(double)100;
                    
                    [sliderValueDisplay3 setDoubleValue:valueDisplayTemp2];
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"< First Must Be Smaller Than > First"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Background Image Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clearCutUp1:(id)sender{
    if (loadImageTreatName != ""){
        if (backgroundPatternArrayCount >= 1){
            if (backgroundOriginalLoadFlag == 3){
                if (100 >= contrastCutOff3) contrastCutOff1 = 100;
                else contrastCutOff1 = contrastCutOff3;
                
                baseContrastSet1 = 0;
                areaSetFlag3 = 0;
                areaSetFlag1 = 0;
                
                [cutUpDisplay1 setIntegerValue:contrastCutOff1];
                [sliderUpKnob1 setDoubleValue:baseContrastSet1];
                
                int valueDisplayTemp = (int)(baseContrastSet1*100);
                double valueDisplayTemp2 = valueDisplayTemp/(double)100;
                
                [sliderValueDisplay1 setDoubleValue:valueDisplayTemp2];
                
                [sliderUp1 setMaxValue:sliderUpMax];
                [sliderUp1 setMinValue:sliderUpMin];
                [sliderUp1 setDoubleValue:0];
                
                [sliderUpCircle setDoubleValue:1];
                
                subprocesses = [[SubProcesses alloc] init];
                [subprocesses variableSave];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Background Image Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clearCutDown1:(id)sender{
    if (loadImageTreatName != ""){
        if (backgroundPatternArrayCount >= 1){
            if (backgroundOriginalLoadFlag == 3){
                if (100 <= contrastCutOff1) contrastCutOff3 = 100;
                else contrastCutOff3 = contrastCutOff1;
                
                baseContrastSet3 = 0;
                areaSetFlag3 = 0;
                areaSetFlag1 = 0;
                
                [cutDownDisplay1 setIntegerValue:contrastCutOff3];
                [sliderDownKnob1 setDoubleValue:baseContrastSet3];
                
                int valueDisplayTemp = (int)(baseContrastSet3*100);
                double valueDisplayTemp2 = valueDisplayTemp/(double)100;
                
                [sliderValueDisplay3 setDoubleValue:valueDisplayTemp2];
                
                [sliderDown1 setMaxValue:sliderDownMax];
                [sliderDown1 setMinValue:sliderDownMin];
                [sliderDown1 setDoubleValue:0];
                
                [sliderDownCircle setDoubleValue:1];
                
                subprocesses = [[SubProcesses alloc] init];
                [subprocesses variableSave];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Background Image Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderUpKnobAction1:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 3){
                    baseContrastSet1 = [sliderUp1 doubleValue];
                    baseContrastSetFlag1 = 1;
                    
                    int valueDisplayTemp = (int)(baseContrastSet1*100);
                    double valueDisplayTemp2 = valueDisplayTemp/(double)100;
                    
                    [sliderValueDisplay1 setDoubleValue:valueDisplayTemp2];
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderDownKnobAction1:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 3){
                    baseContrastSet3 = [sliderDown1 doubleValue];
                    baseContrastSetFlag3 = 1;
                    
                    int valueDisplayTemp = (int)(baseContrastSet3*100);
                    double valueDisplayTemp2 = valueDisplayTemp/(double)100;
                    
                    [sliderValueDisplay3 setDoubleValue:valueDisplayTemp2];
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderUpKnobCircle:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 3){
                    double sliderCircleValue = sliderUpMax*[sliderUpCircle doubleValue];
                    double sliderCircleValue2 = sliderUpMin/[sliderUpCircle doubleValue];
                    double sliderValue = [sliderUp1 doubleValue];
                    
                    double range2 = sliderCircleValue-sliderCircleValue2;
                    range2 = range2/sliderUpDiff;
                    
                    sliderCircleValue = sliderValue+(sliderUpMax-sliderValue)/range2;
                    sliderCircleValue2 = sliderValue-(sliderValue-sliderUpMin)/range2;
                    
                    [sliderUp1 setMaxValue:sliderCircleValue];
                    [sliderUp1 setMinValue:sliderCircleValue2];
                    
                    int baseEnhanceInt = (int)([sliderUp1 doubleValue]*100);
                    double baseEnhanceDouble = baseEnhanceInt/(double)100;
                    
                    [sliderValueDisplay1 setDoubleValue:baseEnhanceDouble];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderDownKnobCircle:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 3){
                    double sliderCircleValue = sliderDownMax*[sliderDownCircle doubleValue];
                    double sliderCircleValue2 = sliderDownMin/[sliderDownCircle doubleValue];
                    double sliderValue = [sliderDown1 doubleValue];
                    
                    double range2 = sliderCircleValue-sliderCircleValue2;
                    range2 = range2/sliderDownDiff;
                    
                    sliderCircleValue = sliderValue+(sliderDownMax-sliderValue)/range2;
                    sliderCircleValue2 = sliderValue-(sliderValue-sliderDownMin)/range2;
                    
                    [sliderDown1 setMaxValue:sliderCircleValue];
                    [sliderDown1 setMinValue:sliderCircleValue2];
                    
                    int baseEnhanceInt = (int)([sliderDown1 doubleValue]*100);
                    double baseEnhanceDouble = baseEnhanceInt/(double)100;
                    
                    [sliderValueDisplay3 setDoubleValue:baseEnhanceDouble];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderAddSubtractKnobCircle:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 3){
                    double sliderCircleValue = sliderGainMax*[sliderAddSubtractCircle doubleValue];
                    double sliderCircleValue2 = sliderGainMin/[sliderAddSubtractCircle doubleValue];
                    double sliderValue = [sliderAddSubtract doubleValue];
                    
                    double range2 = sliderCircleValue-sliderCircleValue2;
                    range2 = range2/sliderGainDiff;
                    
                    sliderCircleValue = sliderValue+(sliderGainMax-sliderValue)/range2;
                    sliderCircleValue2 = sliderValue-(sliderValue-sliderGainMin)/range2;
                    
                    [sliderAddSubtract setMaxValue:sliderCircleValue];
                    [sliderAddSubtract setMinValue:sliderCircleValue2];
                    
                    int baseEnhanceInt = (int)([sliderAddSubtract doubleValue]*100);
                    double baseEnhanceDouble = baseEnhanceInt/(double)100;
                    
                    [gainDisplay setDoubleValue:baseEnhanceDouble];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)areaSetUp:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 3 && clickAreaSetValue != 0){
                    if (overlayStatusHold == 1){
                        int **backBaseTemp = new int *[imageDimensionY+4];
                        
                        for (int counter2 = 0; counter2 < imageDimensionY+4; counter2++) backBaseTemp [counter2] = new int [imageDimensionX+4];
                        
                        for (int counter2 = 0; counter2 < imageDimensionY+4; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionX+4; counter3++) backBaseTemp [counter2][counter3] = 0;
                        }
                        
                        for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                backBaseTemp [counter2+1][counter3+1] = arrayImageContrastAdjust [(currentOriginalNo-1)*imageDimensionY+counter2][counter3];
                            }
                        }
                        
                        int difference = 0;
                        
                        for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                difference = 100-backBaseArrayEdge [counter2][counter3];
                                
                                if (backBaseTemp [counter2+1][counter3+1]+difference >= 255) backBaseTemp [counter2+1][counter3+1] = 255;
                                else if (backBaseTemp [counter2+1][counter3+1]+difference < 0) backBaseTemp [counter2+1][counter3+1] = 0;
                                else backBaseTemp [counter2+1][counter3+1] = backBaseTemp [counter2+1][counter3+1]+difference;
                            }
                        }
                        
                        int clickAreaSetValueTemp = backBaseTemp [yClickPosition+1][xClickPosition+1];
                        int clickBKSetValueTemp = backBaseArray [yClickPosition+1][xClickPosition+1];
                        
                        int yClickTemp = yClickPosition+1;
                        int xClickTemp = xClickPosition+1;
                        
                        if (yClickTemp-1 >= 0 && xClickTemp-1 >= 0 && backBaseTemp [yClickTemp-1][xClickTemp-1] != 0 && backBaseTemp [yClickTemp-1][xClickTemp-1] < clickAreaSetValueTemp){
                            clickAreaSetValueTemp = backBaseTemp [yClickTemp-1][xClickTemp-1];
                            clickBKSetValueTemp = backBaseArray [yClickTemp-1][xClickTemp-1];
                        }
                        if (yClickTemp-1 >= 0 && backBaseTemp [yClickTemp-1][xClickTemp] != 0 && backBaseTemp [yClickTemp-1][xClickTemp] < clickAreaSetValueTemp){
                            clickAreaSetValueTemp = backBaseTemp [yClickTemp-1][xClickTemp];
                            clickBKSetValueTemp = backBaseArray [yClickTemp-1][xClickTemp];
                        }
                        if (yClickTemp-1 >= 0 && xClickTemp+1 < imageDimensionX+2 && backBaseTemp [yClickTemp-1][xClickTemp+1] != 0 && backBaseTemp [yClickTemp-1][xClickTemp+1] < clickAreaSetValueTemp){
                            clickAreaSetValueTemp = backBaseTemp [yClickTemp-1][xClickTemp+1];
                            clickBKSetValueTemp = backBaseArray [yClickTemp-1][xClickTemp+1];
                        }
                        if (xClickTemp+1 < imageDimensionX+2 && backBaseTemp [yClickTemp][xClickTemp+1] != 0 && backBaseTemp [yClickTemp][xClickTemp+1] < clickAreaSetValueTemp){
                            clickAreaSetValueTemp = backBaseTemp [yClickTemp][xClickTemp+1];
                            clickBKSetValueTemp = backBaseArray [yClickTemp][xClickTemp+1];
                        }
                        if (yClickTemp+1 < imageDimensionY+2 && xClickTemp+1 < imageDimensionX+2 && backBaseTemp [yClickTemp+1][xClickTemp+1] != 0 && backBaseTemp [yClickTemp+1][xClickTemp+1] < clickAreaSetValueTemp){
                            clickAreaSetValueTemp = backBaseTemp [yClickTemp+1][xClickTemp+1];
                            clickBKSetValueTemp = backBaseArray [yClickTemp+1][xClickTemp+1];
                        }
                        if (yClickTemp+1 < imageDimensionY+2 && backBaseTemp [yClickTemp+1][xClickTemp] != 0 && backBaseTemp [yClickTemp+1][xClickTemp] < clickAreaSetValueTemp){
                            clickAreaSetValueTemp = backBaseTemp [yClickTemp+1][xClickTemp];
                            clickBKSetValueTemp = backBaseArray [yClickTemp+1][xClickTemp];
                        }
                        if (yClickTemp+1 < imageDimensionY+2 && xClickTemp-1 >= 0 && backBaseTemp [yClickTemp+1][xClickTemp-1] != 0 && backBaseTemp [yClickTemp+1][xClickTemp-1] < clickAreaSetValueTemp){
                            clickAreaSetValueTemp = backBaseTemp [yClickTemp+1][xClickTemp-1];
                            clickBKSetValueTemp = backBaseArray [yClickTemp+1][xClickTemp-1];
                        }
                        if (yClickTemp-1 >= 0 && backBaseTemp [yClickTemp][xClickTemp-1] != 0 && backBaseTemp [yClickTemp][xClickTemp-1] < clickAreaSetValueTemp){
                            clickAreaSetValueTemp = backBaseTemp [yClickTemp][xClickTemp-1];
                            clickBKSetValueTemp = backBaseArray [yClickTemp][xClickTemp-1];
                        }
                        
                        clickAreaHighValue = clickAreaSetValueTemp;
                        clickAreaSetValueTemp = clickAreaSetValueTemp*-1;
                        
                        contrastAreaOffHold1 = clickBKSetValueTemp;
                        
                        for (int counter2 = 0; counter2 < imageDimensionY+2; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionX+2; counter3++){
                                backBaseTemp [counter2][counter3] = backBaseTemp [counter2][counter3]*-1;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < 200; counterA++){
                        //    for (int counterB = 0; counterB < 50; counterB++) cout<<" "<<backBaseTemp [counterA][counterB];
                        //    cout<<" backBaseTemp "<<counterA<<endl;
                        //}
                        
                        //-----Connectivity analysis, Area find-----
                        int *connectAnalysisX = new int [(imageDimensionY+2)*4];
                        int *connectAnalysisY = new int [(imageDimensionY+2)*4];
                        int *connectAnalysisTempX = new int [(imageDimensionY+2)*4];
                        int *connectAnalysisTempY = new int [(imageDimensionY+2)*4];
                        
                        int connectivityNumber = 0;
                        int connectAnalysisCount = 0;
                        int terminationFlag = 0;
                        int connectAnalysisTempCount = 0;
                        int xSource = 0;
                        int ySource = 0;
                        
                        for (int counterY = 0; counterY < imageDimensionY+2; counterY++){
                            for (int counterX = 0; counterX < imageDimensionX+2; counterX++){
                                if (backBaseTemp [counterY][counterX] <= clickAreaSetValueTemp){
                                    connectivityNumber++;
                                    backBaseTemp [counterY][counterX] = connectivityNumber;
                                    connectAnalysisCount = 0;
                                    
                                    if (counterY-1 >= 0 && counterX-1 >= 0 && backBaseTemp [counterY-1][counterX-1] <= clickAreaSetValueTemp){
                                        backBaseTemp [counterY-1][counterX-1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                    }
                                    if (counterY-1 >= 0 && backBaseTemp [counterY-1][counterX] <= clickAreaSetValueTemp){
                                        backBaseTemp [counterY-1][counterX] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                    }
                                    if (counterY-1 >= 0 && counterX+1 < imageDimensionX+2 && backBaseTemp [counterY-1][counterX+1] <= clickAreaSetValueTemp){
                                        backBaseTemp [counterY-1][counterX+1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                    }
                                    if (counterX+1 < imageDimensionX+2 && backBaseTemp [counterY][counterX+1] <= clickAreaSetValueTemp){
                                        backBaseTemp [counterY][counterX+1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                    }
                                    if (counterY+1 < imageDimensionY+2 && counterX+1 < imageDimensionX+2 && backBaseTemp [counterY+1][counterX+1] <= clickAreaSetValueTemp){
                                        backBaseTemp [counterY+1][counterX+1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                    }
                                    if (counterY+1 < imageDimensionY+2 && backBaseTemp [counterY+1][counterX] <= clickAreaSetValueTemp){
                                        backBaseTemp [counterY+1][counterX] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                    }
                                    if (counterY+1 < imageDimensionY+2 && counterX-1 >= 0 && backBaseTemp [counterY+1][counterX-1] <= clickAreaSetValueTemp){
                                        backBaseTemp [counterY+1][counterX-1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                    }
                                    if (counterX-1 >= 0 && backBaseTemp [counterY][counterX-1] <= clickAreaSetValueTemp){
                                        backBaseTemp [counterY][counterX-1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                    }
                                    
                                    if (connectAnalysisCount != 0){
                                        do{
                                            
                                            terminationFlag = 1;
                                            connectAnalysisTempCount = 0;
                                            
                                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                                
                                                if (ySource-1 >= 0 && xSource-1 >= 0 && backBaseTemp [ySource-1][xSource-1] <= clickAreaSetValueTemp){
                                                    backBaseTemp [ySource-1][xSource-1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (ySource-1 >= 0 && backBaseTemp [ySource-1][xSource] <= clickAreaSetValueTemp){
                                                    backBaseTemp [ySource-1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (ySource-1 >= 0 && xSource+1 < imageDimensionX+2 && backBaseTemp [ySource-1][xSource+1] <= clickAreaSetValueTemp){
                                                    backBaseTemp [ySource-1][xSource+1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (xSource+1 < imageDimensionX+2 && backBaseTemp [ySource][xSource+1] <= clickAreaSetValueTemp){
                                                    backBaseTemp [ySource][xSource+1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 > imageDimensionY+2 && xSource+1 < imageDimensionY+2 && backBaseTemp [ySource+1][xSource+1] <= clickAreaSetValueTemp){
                                                    backBaseTemp [ySource+1][xSource+1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 < imageDimensionY+2 && backBaseTemp [ySource+1][xSource] <= clickAreaSetValueTemp){
                                                    backBaseTemp [ySource+1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 < imageDimensionY+2 && xSource-1 >= 0 && backBaseTemp [ySource+1][xSource-1] <= clickAreaSetValueTemp){
                                                    backBaseTemp [ySource+1][xSource-1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (xSource-1 >= 0 && backBaseTemp [ySource][xSource-1] <= clickAreaSetValueTemp){
                                                    backBaseTemp [ySource][xSource-1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                            }
                                            
                                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                            }
                                            
                                            connectAnalysisCount = connectAnalysisTempCount;
                                            
                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < 200; counterA++){
                        //    for (int counterB = 0; counterB < 50; counterB++) cout<<" "<<backBaseTemp [counterA][counterB];
                        //    cout<<" backBaseTemp "<<counterA<<endl;
                        //}
                        
                        int targetConnectNo = backBaseTemp [yClickPosition+1][xClickPosition+1];
                        
                        if (targetConnectNo != 0){
                            double areaCount = 0;
                            
                            for (int counter2 = 0; counter2 < imageDimensionY+2; counter2++){
                                for (int counter3 = 0; counter3 < imageDimensionX+2; counter3++){
                                    if (targetConnectNo == backBaseTemp [counter2][counter3]){
                                        backBaseTemp [counter2][counter3] = 1;
                                        areaCount++;
                                    }
                                    else backBaseTemp [counter2][counter3] = 0;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < 200; counterA++){
                            //    for (int counterB = 0; counterB < 50; counterB++) cout<<" "<<backBaseTemp [counterA][counterB];
                            //    cout<<" backBaseTemp "<<counterA<<endl;
                            //}
                            
                            if (areaCount > 50){
                                //-----Zero Fill-----
                                int **connectivityUpdate5 = new int *[imageDimensionY+4];
                                
                                for (int counter1 = 0; counter1 < imageDimensionY+4; counter1++) connectivityUpdate5 [counter1] = new int [imageDimensionX+4];
                                
                                for (int counterX = 0; counterX < imageDimensionY+4; counterX++){
                                    for (int counterY = 0; counterY < imageDimensionX+4; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
                                }
                                
                                for (int counterY = 0; counterY < imageDimensionY+2; counterY++){
                                    for (int counterX = 0; counterX < imageDimensionX+2; counterX++) connectivityUpdate5 [counterY][counterX] = backBaseTemp [counterY][counterX];
                                }
                                
                                connectivityNumber = 0;
                                
                                for (int counterY2 = 0; counterY2 < imageDimensionY+2; counterY2++){
                                    for (int counterX2 = 0; counterX2 < imageDimensionX+2; counterX2++){
                                        if (connectivityUpdate5 [counterY2][counterX2] == 0){
                                            connectivityNumber--;
                                            connectAnalysisCount = 0;
                                            
                                            connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                                            
                                            if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                                                connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                            }
                                            if (counterX2+1 < imageDimensionX+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                                connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                            }
                                            if (counterY2+1 < imageDimensionY+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                                connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                            }
                                            if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                                connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                            }
                                            
                                            if (connectAnalysisCount != 0){
                                                do{
                                                    
                                                    terminationFlag = 1;
                                                    connectAnalysisTempCount = 0;
                                                    
                                                    for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                                        xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                                        
                                                        if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                                            connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource+1 < imageDimensionX+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                                            connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                        if (ySource+1 < imageDimensionY+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                                            connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                                            connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                    }
                                                    
                                                    for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                                        connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                                    }
                                                    
                                                    connectAnalysisCount = connectAnalysisTempCount;
                                                    
                                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                                    
                                                } while (terminationFlag == 1);
                                            }
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < 512+2; counterA++){
                                //	for (int counterB = 0; counterB < 512+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                                //	cout<<" connectivityUpdate5 "<<counterA<<endl;
                                //}
                                
                                int connectTemp2 = 0;
                                
                                if (connectivityNumber < -1){
                                    int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                                    
                                    for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
                                    
                                    for (int counterY2 = 0; counterY2 < imageDimensionY+2; counterY2++){
                                        for (int counterX2 = 0; counterX2 < imageDimensionX+2; counterX2++){
                                            connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                                            
                                            if (connectTemp2 < -1){
                                                connectTemp2 = connectTemp2*-1;
                                                
                                                if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterY2-1 >= 0 && counterX2+1 < imageDimensionX+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterX2+1 < imageDimensionX+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterY2+1 < imageDimensionY+2 && counterX2+1 < imageDimensionY+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterY2+1 < imageDimensionY+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterY2+1 < imageDimensionY+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                            }
                                        }
                                    }
                                    
                                    int zeroFillFlag = 0;
                                    
                                    for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                                        if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
                                    }
                                    
                                    //for (int counterA = 1; counterA <= connectivityNumber*-1; counterA++){
                                    //    cout<<counterA<<" "<<connectCheckArray [counterA*2]<<" "<<connectCheckArray [counterA*2+1]<<" check"<<endl;
                                    //}
                                    
                                    //for (int counterA = 0; counterA < 512+2; counterA++){
                                    //    for (int counterB = 0; counterB < 512+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                                    //    cout<<" connectivityUpdate5 "<<counterA<<endl;
                                    //}
                                    
                                    if (zeroFillFlag == 1){
                                        for (int counterY2 = 0; counterY2 < imageDimensionY+2; counterY2++){
                                            for (int counterX2 = 0; counterX2 < imageDimensionX+2; counterX2++){
                                                connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                                                
                                                if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                                            }
                                        }
                                        
                                        for (int counterY2 = 0; counterY2 < imageDimensionY+2; counterY2++){
                                            for (int counterX2 = 0; counterX2 < imageDimensionX+2; counterX2++){
                                                if (connectivityUpdate5 [counterY2][counterX2] > 0){
                                                    backBaseTemp [counterY2][counterX2] = connectivityUpdate5 [counterY2][counterX2];
                                                }
                                            }
                                        }
                                    }
                                    
                                    delete [] connectCheckArray;
                                }
                                
                                for (int counter1 = 0; counter1 < imageDimensionY+4; counter1++) delete [] connectivityUpdate5 [counter1];
                                
                                delete [] connectivityUpdate5;
                                
                                for (int counterY = 0; counterY < imageDimensionY+2; counterY++){
                                    for (int counterX = 0; counterX < imageDimensionX+2; counterX++){
                                        if (backBaseTemp [counterY][counterX] != 0){
                                            if (counterX+1 < imageDimensionX+2 && backBaseTemp [counterY][counterX+1] == 0) backBaseTemp [counterY][counterX] = -1;
                                            else if (counterY+1 < imageDimensionY+2 && backBaseTemp [counterY+1][counterX] == 0) backBaseTemp [counterY][counterX] = -1;
                                            else if (counterX-1 >= 0 && backBaseTemp [counterY][counterX-1] == 0) backBaseTemp [counterY][counterX] = -1;
                                            else if (counterY-1 >= 0 && backBaseTemp [counterY-1][counterX] == 0) backBaseTemp [counterY][counterX] = -1;
                                        }
                                    }
                                }
                                
                                for (int counterY = 0; counterY < imageDimensionY+2; counterY++){
                                    for (int counterX = 0; counterX < imageDimensionX+2; counterX++){
                                        if (backBaseTemp [counterY][counterX] > 0) backBaseTemp [counterY][counterX] = 0;
                                        if (backBaseTemp [counterY][counterX] < 0) backBaseTemp [counterY][counterX] = 1;
                                    }
                                }
                                
                                connectivityNumber = 0;
                                
                                for (int counterY2 = 0; counterY2 < imageDimensionY+2; counterY2++){
                                    for (int counterX2 = 0; counterX2 < imageDimensionX+2; counterX2++){
                                        if (backBaseTemp [counterY2][counterX2] == 0){
                                            connectivityNumber--;
                                            connectAnalysisCount = 0;
                                            
                                            backBaseTemp [counterY2][counterX2] = connectivityNumber;
                                            
                                            if (counterY2-1 >= 0 && backBaseTemp [counterY2-1][counterX2] == 0){
                                                backBaseTemp [counterY2-1][counterX2] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                            }
                                            if (counterX2+1 < imageDimensionX+2 && backBaseTemp [counterY2][counterX2+1] == 0){
                                                backBaseTemp [counterY2][counterX2+1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                            }
                                            if (counterY2+1 < imageDimensionY+2 && backBaseTemp [counterY2+1][counterX2] == 0){
                                                backBaseTemp [counterY2+1][counterX2] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                            }
                                            if (counterX2-1 >= 0 && backBaseTemp [counterY2][counterX2-1] == 0){
                                                backBaseTemp [counterY2][counterX2-1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                            }
                                            
                                            if (connectAnalysisCount != 0){
                                                do{
                                                    
                                                    terminationFlag = 1;
                                                    connectAnalysisTempCount = 0;
                                                    
                                                    for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                                        xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                                        
                                                        if (ySource-1 >= 0 && backBaseTemp [ySource-1][xSource] == 0){
                                                            backBaseTemp [ySource-1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource+1 < imageDimensionX+2 && backBaseTemp [ySource][xSource+1] == 0){
                                                            backBaseTemp [ySource][xSource+1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                        if (ySource+1 < imageDimensionY+2 && backBaseTemp [ySource+1][xSource] == 0){
                                                            backBaseTemp [ySource+1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource-1 >= 0 && backBaseTemp [ySource][xSource-1] == 0){
                                                            backBaseTemp [ySource][xSource-1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                    }
                                                    
                                                    for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                                        connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                                    }
                                                    
                                                    connectAnalysisCount = connectAnalysisTempCount;
                                                    
                                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                                    
                                                } while (terminationFlag == 1);
                                            }
                                        }
                                    }
                                }
                                
                                //-----Determine number of pixels-----
                                connectivityNumber = connectivityNumber*-1;
                                
                                int *connectedPix = new int [connectivityNumber+50];
                                for (int counter1 = 0; counter1 <= connectivityNumber; counter1++) connectedPix [counter1] = 0;
                                
                                for (int counterY2 = 0; counterY2 < imageDimensionY+2; counterY2++){
                                    for (int counterX2 = 0; counterX2 < imageDimensionX+2; counterX2++){
                                        if (backBaseTemp [counterY2][counterX2] < -1) connectedPix [backBaseTemp [counterY2][counterX2]*-1]++;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA <= connectivityNumber; counterA++){
                                //    cout<<counterA<<" "<<connectedPix [counterA]<<" connect"<<endl;
                                //}
                                
                                int **newConnectivityMapTemp = new int *[(imageDimensionY+2)+4];
                                for (int counter1 = 0; counter1 < (imageDimensionY+2)+4; counter1++) newConnectivityMapTemp [counter1] = new int [(imageDimensionX+2)+4];
                                
                                for (int counterY = 0; counterY < (imageDimensionY+2)+4; counterY++){
                                    for (int counterX = 0; counterX < (imageDimensionX+2)+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
                                }
                                
                                int targetConnectNo2 = backBaseTemp [yClickPosition+1][xClickPosition+1]*-1;
                                
                                if (targetConnectNo2 != -1 && connectedPix [targetConnectNo2] > 50){
                                    for (int counterY2 = 0; counterY2 < imageDimensionY+2; counterY2++){
                                        for (int counterX2 = 0; counterX2 < imageDimensionX+2; counterX2++){
                                            if (backBaseTemp [counterY2][counterX2] == targetConnectNo2*-1){
                                                if (counterY2-1 >= 0 && counterX2-1 >= 0 && backBaseTemp [counterY2-1][counterX2-1] == 1){
                                                    newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                                                    backBaseTemp [counterY2-1][counterX2-1] = 0;
                                                }
                                                if (counterY2-1 >= 0 && backBaseTemp [counterY2-1][counterX2] == 1){
                                                    newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                                                    backBaseTemp [counterY2-1][counterX2] = 0;
                                                }
                                                if (counterY2-1 >= 0 && counterX2+1 < imageDimensionX+2 && backBaseTemp [counterY2-1][counterX2+1] == 1){
                                                    newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                                                    backBaseTemp [counterY2-1][counterX2+1] = 0;
                                                }
                                                if (counterX2+1 < imageDimensionX+2 && backBaseTemp [counterY2][counterX2+1] == 1){
                                                    newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                                                    backBaseTemp [counterY2][counterX2+1] = 0;
                                                }
                                                if (counterY2+1 < imageDimensionY+2 && counterX2+1 < imageDimensionX+2 && backBaseTemp [counterY2+1][counterX2+1] == 1){
                                                    newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                                                    backBaseTemp [counterY2+1][counterX2+1] = 0;
                                                }
                                                if (counterY2+1 < imageDimensionY+2 && backBaseTemp [counterY2+1][counterX2] == 1){
                                                    newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                                                    backBaseTemp [counterY2+1][counterX2] = 0;
                                                }
                                                if (counterY2+1 < imageDimensionY+2 && counterX2-1 >= 0 && backBaseTemp [counterY2+1][counterX2-1] == 1){
                                                    newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                                                    backBaseTemp [counterY2+1][counterX2-1] = 0;
                                                }
                                                if (counterX2-1 >= 0 && backBaseTemp [counterY2][counterX2-1] == 1){
                                                    newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                                                    backBaseTemp [counterY2][counterX2-1] = 0;
                                                }
                                            }
                                        }
                                    }
                                    
                                    int xPositionTempStart = 0;
                                    int yPositionTempStart = 0;
                                    int lineSize = 0;
                                    
                                    for (int counterY2 = 0; counterY2 < imageDimensionY+2; counterY2++){
                                        for (int counterX2 = 0; counterX2 < imageDimensionX+2; counterX2++){
                                            if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                                                backBaseTemp [counterY2][counterX2] = 1;
                                                xPositionTempStart = counterX2;
                                                yPositionTempStart = counterY2;
                                                lineSize++;
                                            }
                                            else backBaseTemp [counterY2][counterX2] = 0;
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < 512; counterA++){
                                    //	for (int counterB = 0; counterB < 512; counterB++) cout<<" "<<backBaseTemp [counterA][counterB];
                                    //	cout<<" backBaseTemp "<<counterA<<endl;
                                    //}
                                    
                                    int constructedLineCount = 0;
                                    int findFlag = 0;
                                    
                                    int *arrayNewLines = new int [lineSize*2+50];
                                    
                                    backBaseTemp [yPositionTempStart][xPositionTempStart] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                    
                                    do{
                                        
                                        findFlag = 0;
                                        terminationFlag = 0;
                                        
                                        if (xPositionTempStart+1 < imageDimensionX+2){
                                            if (backBaseTemp [yPositionTempStart][xPositionTempStart+1] == 1){
                                                backBaseTemp [yPositionTempStart][xPositionTempStart+1] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                                xPositionTempStart = xPositionTempStart+1;
                                                terminationFlag = 1;
                                                findFlag = 1;
                                            }
                                        }
                                        if (xPositionTempStart+1 < imageDimensionX+2 && yPositionTempStart+1 < imageDimensionY+2 && findFlag == 0){
                                            if (backBaseTemp [yPositionTempStart+1][xPositionTempStart+1] == 1){
                                                backBaseTemp [yPositionTempStart+1][xPositionTempStart+1] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                                xPositionTempStart = xPositionTempStart+1;
                                                yPositionTempStart = yPositionTempStart+1;
                                                terminationFlag = 1;
                                                findFlag = 1;
                                            }
                                        }
                                        if (yPositionTempStart+1 < imageDimensionY+2 && findFlag == 0){
                                            if (backBaseTemp [yPositionTempStart+1][xPositionTempStart] == 1){
                                                backBaseTemp [yPositionTempStart+1][xPositionTempStart] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                                yPositionTempStart = yPositionTempStart+1;
                                                terminationFlag = 1;
                                                findFlag = 1;
                                            }
                                        }
                                        if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < imageDimensionY+2 && findFlag == 0){
                                            if (backBaseTemp [yPositionTempStart+1][xPositionTempStart-1] == 1){
                                                backBaseTemp [yPositionTempStart+1][xPositionTempStart-1] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                                xPositionTempStart = xPositionTempStart-1;
                                                yPositionTempStart = yPositionTempStart+1;
                                                terminationFlag = 1;
                                                findFlag = 1;
                                            }
                                        }
                                        if (xPositionTempStart-1 >= 0 && findFlag == 0){
                                            if (backBaseTemp [yPositionTempStart][xPositionTempStart-1] == 1){
                                                backBaseTemp [yPositionTempStart][xPositionTempStart-1] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                                xPositionTempStart = xPositionTempStart-1;
                                                terminationFlag = 1;
                                                findFlag = 1;
                                            }
                                        }
                                        if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                                            if (backBaseTemp [yPositionTempStart-1][xPositionTempStart-1] == 1){
                                                backBaseTemp [yPositionTempStart-1][xPositionTempStart-1] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                                xPositionTempStart = xPositionTempStart-1;
                                                yPositionTempStart = yPositionTempStart-1;
                                                terminationFlag = 1;
                                                findFlag = 1;
                                            }
                                        }
                                        if (yPositionTempStart-1 >= 0 && findFlag == 0){
                                            if (backBaseTemp [yPositionTempStart-1][xPositionTempStart] == 1){
                                                backBaseTemp [yPositionTempStart-1][xPositionTempStart] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                                yPositionTempStart = yPositionTempStart-1;
                                                terminationFlag = 1;
                                                findFlag = 1;
                                            }
                                        }
                                        if (xPositionTempStart+1 < imageDimensionX+2 && yPositionTempStart-1 >= 0 && findFlag == 0){
                                            if (backBaseTemp [yPositionTempStart-1][xPositionTempStart+1] == 1){
                                                backBaseTemp [yPositionTempStart-1][xPositionTempStart+1] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                                xPositionTempStart = xPositionTempStart+1;
                                                yPositionTempStart = yPositionTempStart-1;
                                                terminationFlag = 1;
                                            }
                                        }
                                        
                                    } while (terminationFlag == 1);
                                    
                                    backAreaLineUpArrayCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < constructedLineCount/2; counter2++){
                                        backAreaLineUpArray [backAreaLineUpArrayCount] = arrayNewLines [counter2*2]-1, backAreaLineUpArrayCount++;
                                        backAreaLineUpArray [backAreaLineUpArrayCount] = arrayNewLines [counter2*2+1]-1, backAreaLineUpArrayCount++;
                                    }
                                    
                                    for (int counterY = 0; counterY < imageDimensionY+2; counterY++){
                                        for (int counterX = 0; counterX < imageDimensionX+2; counterX++){
                                            if (backBaseTemp [counterY][counterX] == -1) backBaseTemp [counterY][counterX] = 1;
                                        }
                                    }
                                    
                                    connectivityNumber = -3;
                                    
                                    for (int counterY = 0; counterY < imageDimensionY+2; counterY++){
                                        for (int counterX = 0; counterX < imageDimensionX+2; counterX++){
                                            if (backBaseTemp [counterY][counterX] == 0){
                                                connectivityNumber = connectivityNumber+2;
                                                backBaseTemp [counterY][counterX] = connectivityNumber;
                                                
                                                connectAnalysisCount = 0;
                                                
                                                if (counterY-1 >= 0 && backBaseTemp [counterY-1][counterX] == 0){
                                                    backBaseTemp [counterY-1][counterX] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                }
                                                if (counterX+1 < imageDimensionX+2 && backBaseTemp [counterY][counterX+1] == 0){
                                                    backBaseTemp [counterY][counterX+1] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                }
                                                if (counterY+1 < imageDimensionY+2 && backBaseTemp [counterY+1][counterX] == 0){
                                                    backBaseTemp [counterY+1][counterX] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                }
                                                if (counterX-1 >= 0 && backBaseTemp [counterY][counterX-1] == 0){
                                                    backBaseTemp [counterY][counterX-1] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                }
                                                
                                                if (connectAnalysisCount != 0){
                                                    do{
                                                        
                                                        terminationFlag = 1;
                                                        connectAnalysisTempCount = 0;
                                                        
                                                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                                            xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                                            
                                                            if (ySource-1 >= 0 && backBaseTemp [ySource-1][xSource] == 0){
                                                                backBaseTemp [ySource-1][xSource] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                            }
                                                            if (xSource+1 < imageDimensionX+2 && backBaseTemp [ySource][xSource+1] == 0){
                                                                backBaseTemp [ySource][xSource+1] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                            }
                                                            if (ySource+1 < imageDimensionY+2 && backBaseTemp [ySource+1][xSource] == 0){
                                                                backBaseTemp [ySource+1][xSource] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                            }
                                                            if (xSource-1 >= 0 && backBaseTemp [ySource][xSource-1] == 0){
                                                                backBaseTemp [ySource][xSource-1] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                            }
                                                        }
                                                        
                                                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                                        }
                                                        
                                                        connectAnalysisCount = connectAnalysisTempCount;
                                                        
                                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                                        
                                                    } while (terminationFlag == 1);
                                                }
                                            }
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < 512; counterA++){
                                    //    for (int counterB = 0; counterB < 512; counterB++) cout<<" "<<backBaseTemp [counterA][counterB];
                                    //    cout<<" backBaseTemp "<<counterA<<endl;
                                    //}
                                    
                                    //-----Remove connectivity groups that are attached to the edge; extract the inner part of linked lines groups, which attach edge, extract inner part of Linked Line-----
                                    for (int counterY = 0; counterY < imageDimensionY+2; counterY++){
                                        for (int counterX = 0; counterX < imageDimensionX+2; counterX++){
                                            if (backBaseTemp [counterY][counterX] == -1) backBaseTemp [counterY][counterX] = 0;
                                        }
                                    }
                                    
                                    for (int counterY = 0; counterY < imageDimensionY; counterY++){
                                        for (int counterX = 0; counterX < imageDimensionX; counterX++){
                                            backAreaMapUpArray [counterY][counterX] = 0;
                                        }
                                    }
                                    
                                    for (int counterY = 0; counterY < imageDimensionY+2; counterY++){
                                        for (int counterX = 0; counterX < imageDimensionX+2; counterX++){
                                            if (backBaseTemp [counterY][counterX] > 0){
                                                backAreaMapUpArray [counterY-1][counterX-1] = backBaseTemp [counterY][counterX];
                                            }
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < 200; counterA++){
                                    //    for (int counterB = 0; counterB < 50; counterB++) cout<<" "<<backAreaMapUpArray [counterA][counterB];
                                    //    cout<<" backAreaMapUpArray "<<counterA<<endl;
                                    //}
                                    
                                    delete [] arrayNewLines;
                                    
                                    areaSetFlag1 = 1;
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                }
                                else{
                                    
                                    areaSetFlag1 = 0;
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                                
                                for (int counter1 = 0; counter1 < (imageDimensionY+2)+4; counter1++) delete [] newConnectivityMapTemp [counter1];
                                delete [] newConnectivityMapTemp;
                                
                                delete [] connectedPix;
                            }
                            else{
                                
                                areaSetFlag1 = 0;
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                        else{
                            
                            areaSetFlag1 = 0;
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                        
                        for (int counter1 = 0; counter1 < imageDimensionY+4; counter1++){
                            delete [] backBaseTemp [counter1];
                        }
                        
                        delete [] backBaseTemp;
                        
                        delete [] connectAnalysisX;
                        delete [] connectAnalysisY;
                        delete [] connectAnalysisTempX;
                        delete [] connectAnalysisTempY;
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Overlay Mode Off"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    if (backgroundOriginalLoadFlag != 3){
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Background Image Mode Off"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"No Image Point Selected"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)areaSetDown:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 3 && clickAreaSetValue != 0){
                    if (overlayStatusHold == 1){
                        int **backBaseTemp = new int *[imageDimensionY+4];
                        
                        for (int counter2 = 0; counter2 < imageDimensionY+4; counter2++) backBaseTemp [counter2] = new int [imageDimensionX+4];
                        
                        for (int counter2 = 0; counter2 < imageDimensionY+4; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionX+4; counter3++) backBaseTemp [counter2][counter3] = 0;
                        }
                        
                        for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                backBaseTemp [counter2+1][counter3+1] = arrayImageContrastAdjust [(currentOriginalNo-1)*imageDimensionY+counter2][counter3];
                            }
                        }
                        
                        int difference = 0;
                        
                        for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                difference = 100-backBaseArrayEdge [counter2][counter3];
                                
                                if (backBaseTemp [counter2+1][counter3+1]+difference >= 255) backBaseTemp [counter2+1][counter3+1] = 255;
                                else if (backBaseTemp [counter2+1][counter3+1]+difference < 0) backBaseTemp [counter2+1][counter3+1] = 0;
                                else backBaseTemp [counter2+1][counter3+1] = backBaseTemp [counter2+1][counter3+1]+difference;
                            }
                        }
                        
                        int clickAreaSetValueTemp = backBaseTemp [yClickPosition+1][xClickPosition+1];
                        int clickBKSetValueTemp = backBaseArray [yClickPosition+1][xClickPosition+1];
                        
                        int yClickTemp = yClickPosition+1;
                        int xClickTemp = xClickPosition+1;
                        
                        if (yClickTemp-1 >= 0 && xClickTemp-1 >= 0 && backBaseTemp [yClickTemp-1][xClickTemp-1] > clickAreaSetValueTemp){
                            clickAreaSetValueTemp = backBaseTemp [yClickTemp-1][xClickTemp-1];
                            clickBKSetValueTemp = backBaseArray [yClickPosition-1][xClickPosition-1];
                        }
                        if (yClickTemp-1 >= 0 && backBaseTemp [yClickTemp-1][xClickTemp] > clickAreaSetValueTemp){
                            clickAreaSetValueTemp = backBaseTemp [yClickTemp-1][xClickTemp];
                            clickBKSetValueTemp = backBaseArray [yClickPosition-1][xClickPosition];
                        }
                        if (yClickTemp-1 >= 0 && xClickTemp+1 < imageDimensionX+2 && backBaseTemp [yClickTemp-1][xClickTemp+1] > clickAreaSetValueTemp){
                            clickAreaSetValueTemp = backBaseTemp [yClickTemp-1][xClickTemp+1];
                            clickBKSetValueTemp = backBaseArray [yClickPosition-1][xClickPosition+1];
                        }
                        if (xClickTemp+1 < imageDimensionX+2 && backBaseTemp [yClickTemp][xClickTemp+1] > clickAreaSetValueTemp){
                            clickAreaSetValueTemp = backBaseTemp [yClickTemp][xClickTemp+1];
                            clickBKSetValueTemp = backBaseArray [yClickPosition][xClickPosition+1];
                        }
                        if (yClickTemp+1 < imageDimensionY+2 && xClickTemp+1 < imageDimensionY+2 && backBaseTemp [yClickTemp+1][xClickTemp+1] > clickAreaSetValueTemp){
                            clickAreaSetValueTemp = backBaseTemp [yClickTemp+1][xClickTemp+1];
                            clickBKSetValueTemp = backBaseArray [yClickPosition+1][xClickPosition+1];
                        }
                        if (yClickTemp+1 < imageDimensionY+2 && backBaseTemp [yClickTemp+1][xClickTemp] > clickAreaSetValueTemp){
                            clickAreaSetValueTemp = backBaseTemp [yClickTemp+1][xClickTemp];
                            clickBKSetValueTemp = backBaseArray [yClickPosition+1][xClickPosition];
                        }
                        if (yClickTemp+1 < imageDimensionY+2 && xClickTemp-1 >= 0 && backBaseTemp [yClickTemp+1][xClickTemp-1] > clickAreaSetValueTemp){
                            clickAreaSetValueTemp = backBaseTemp [yClickTemp+1][xClickTemp-1];
                            clickBKSetValueTemp = backBaseArray [yClickPosition+1][xClickPosition-1];
                        }
                        if (yClickTemp-1 >= 0 && backBaseTemp [yClickTemp][xClickTemp-1] > clickAreaSetValueTemp){
                            clickAreaSetValueTemp = backBaseTemp [yClickTemp][xClickTemp-1];
                            clickBKSetValueTemp = backBaseArray [yClickPosition][xClickPosition-1];
                        }
                        
                        clickAreaLowValue = clickAreaSetValueTemp;
                        clickAreaSetValueTemp = clickAreaSetValueTemp*-1;
                        contrastAreaOffHold3 = clickBKSetValueTemp;
                        
                        for (int counter2 = 0; counter2 < imageDimensionY+2; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionX+2; counter3++){
                                backBaseTemp [counter2][counter3] = backBaseTemp [counter2][counter3]*-1;
                            }
                        }
                        
                        //-----Connectivity analysis, Area find-----
                        int *connectAnalysisX = new int [(imageDimensionY+2)*4];
                        int *connectAnalysisY = new int [(imageDimensionY+2)*4];
                        int *connectAnalysisTempX = new int [(imageDimensionY+2)*4];
                        int *connectAnalysisTempY = new int [(imageDimensionY+2)*4];
                        
                        int connectivityNumber = 0;
                        int connectAnalysisCount = 0;
                        int terminationFlag = 0;
                        int connectAnalysisTempCount = 0;
                        int xSource = 0;
                        int ySource = 0;
                        
                        for (int counterY = 0; counterY < imageDimensionY+2; counterY++){
                            for (int counterX = 0; counterX < imageDimensionX+2; counterX++){
                                if (backBaseTemp [counterY][counterX] < 0 && backBaseTemp [counterY][counterX] >= clickAreaSetValueTemp){
                                    connectivityNumber++;
                                    backBaseTemp [counterY][counterX] = connectivityNumber;
                                    connectAnalysisCount = 0;
                                    
                                    if (counterY-1 >= 0 && counterX-1 >= 0 && backBaseTemp [counterY-1][counterX-1] < 0 && backBaseTemp [counterY-1][counterX-1] >= clickAreaSetValueTemp){
                                        backBaseTemp [counterY-1][counterX-1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                    }
                                    if (counterY-1 >= 0 && backBaseTemp [counterY-1][counterX] < 0 && backBaseTemp [counterY-1][counterX] >= clickAreaSetValueTemp){
                                        backBaseTemp [counterY-1][counterX] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                    }
                                    if (counterY-1 >= 0 && counterX+1 < imageDimensionX+2 && backBaseTemp [counterY-1][counterX+1] < 0 && backBaseTemp [counterY-1][counterX+1] >= clickAreaSetValueTemp){
                                        backBaseTemp [counterY-1][counterX+1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                    }
                                    if (counterX+1 < imageDimensionX+2 && backBaseTemp [counterY][counterX+1] < 0 && backBaseTemp [counterY][counterX+1] >= clickAreaSetValueTemp){
                                        backBaseTemp [counterY][counterX+1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                    }
                                    if (counterY+1 < imageDimensionY+2 && counterX+1 < imageDimensionX+2 && backBaseTemp [counterY+1][counterX+1] < 0 && backBaseTemp [counterY+1][counterX+1] >= clickAreaSetValueTemp){
                                        backBaseTemp [counterY+1][counterX+1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                    }
                                    if (counterY+1 < imageDimensionY+2 && backBaseTemp [counterY+1][counterX] < 0 && backBaseTemp [counterY+1][counterX] >= clickAreaSetValueTemp){
                                        backBaseTemp [counterY+1][counterX] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                    }
                                    if (counterY+1 < imageDimensionY+2 && counterX-1 >= 0 && backBaseTemp [counterY+1][counterX-1] < 0 && backBaseTemp [counterY+1][counterX-1] >= clickAreaSetValueTemp){
                                        backBaseTemp [counterY+1][counterX-1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                    }
                                    if (counterX-1 >= 0 && backBaseTemp [counterY][counterX-1] < 0 && backBaseTemp [counterY][counterX-1] >= clickAreaSetValueTemp){
                                        backBaseTemp [counterY][counterX-1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                    }
                                    
                                    if (connectAnalysisCount != 0){
                                        do{
                                            
                                            terminationFlag = 1;
                                            connectAnalysisTempCount = 0;
                                            
                                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                                
                                                if (ySource-1 >= 0 && xSource-1 >= 0 && backBaseTemp [ySource-1][xSource-1] < 0 && backBaseTemp [ySource-1][xSource-1] >= clickAreaSetValueTemp){
                                                    backBaseTemp [ySource-1][xSource-1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (ySource-1 >= 0 && backBaseTemp [ySource-1][xSource] < 0 && backBaseTemp [ySource-1][xSource] >= clickAreaSetValueTemp){
                                                    backBaseTemp [ySource-1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (ySource-1 >= 0 && xSource+1 < imageDimensionX+2 && backBaseTemp [ySource-1][xSource+1] < 0 && backBaseTemp [ySource-1][xSource+1] >= clickAreaSetValueTemp){
                                                    backBaseTemp [ySource-1][xSource+1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (xSource+1 < imageDimensionX+2 && backBaseTemp [ySource][xSource+1] < 0 && backBaseTemp [ySource][xSource+1] >= clickAreaSetValueTemp){
                                                    backBaseTemp [ySource][xSource+1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 > imageDimensionY+2 && xSource+1 < imageDimensionX+2 && backBaseTemp [ySource+1][xSource+1] < 0 && backBaseTemp [ySource+1][xSource+1] >= clickAreaSetValueTemp){
                                                    backBaseTemp [ySource+1][xSource+1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 < imageDimensionY+2 && backBaseTemp [ySource+1][xSource] < 0 && backBaseTemp [ySource+1][xSource] >= clickAreaSetValueTemp){
                                                    backBaseTemp [ySource+1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 < imageDimensionY+2 && xSource-1 >= 0 && backBaseTemp [ySource+1][xSource-1] < 0 && backBaseTemp [ySource+1][xSource-1] >= clickAreaSetValueTemp){
                                                    backBaseTemp [ySource+1][xSource-1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (xSource-1 >= 0 && backBaseTemp [ySource][xSource-1] < 0 && backBaseTemp [ySource][xSource-1] >= clickAreaSetValueTemp){
                                                    backBaseTemp [ySource][xSource-1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                            }
                                            
                                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                            }
                                            
                                            connectAnalysisCount = connectAnalysisTempCount;
                                            
                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < 200; counterA++){
                        //    for (int counterB = 0; counterB < 50; counterB++) cout<<" "<<backBaseTemp [counterA][counterB];
                        //    cout<<" backBaseTemp "<<counterA<<endl;
                        //}
                        
                        int targetConnectNo = backBaseTemp [yClickPosition+1][xClickPosition+1];
                        
                        if (targetConnectNo != 0){
                            double areaCount = 0;
                            
                            for (int counter2 = 0; counter2 < imageDimensionY+2; counter2++){
                                for (int counter3 = 0; counter3 < imageDimensionX+2; counter3++){
                                    if (targetConnectNo == backBaseTemp [counter2][counter3]){
                                        backBaseTemp [counter2][counter3] = 1;
                                        areaCount++;
                                    }
                                    else backBaseTemp [counter2][counter3] = 0;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < 200; counterA++){
                            //    for (int counterB = 0; counterB < 50; counterB++) cout<<" "<<backBaseTemp [counterA][counterB];
                            //    cout<<" backBaseTemp "<<counterA<<endl;
                            //}
                            
                            if (areaCount > 50){
                                //-----Zero Fill-----
                                int **connectivityUpdate5 = new int *[imageDimensionY+4];
                                
                                for (int counter1 = 0; counter1 < imageDimensionY+4; counter1++) connectivityUpdate5 [counter1] = new int [imageDimensionX+4];
                                
                                for (int counterX = 0; counterX < imageDimensionY+4; counterX++){
                                    for (int counterY = 0; counterY < imageDimensionX+4; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
                                }
                                
                                for (int counterY = 0; counterY < imageDimensionY+2; counterY++){
                                    for (int counterX = 0; counterX < imageDimensionX+2; counterX++) connectivityUpdate5 [counterY][counterX] = backBaseTemp [counterY][counterX];
                                }
                                
                                connectivityNumber = 0;
                                
                                for (int counterY2 = 0; counterY2 < imageDimensionY+2; counterY2++){
                                    for (int counterX2 = 0; counterX2 < imageDimensionX+2; counterX2++){
                                        if (connectivityUpdate5 [counterY2][counterX2] == 0){
                                            connectivityNumber--;
                                            connectAnalysisCount = 0;
                                            
                                            connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                                            
                                            if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                                                connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                            }
                                            if (counterX2+1 < imageDimensionX+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                                connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                            }
                                            if (counterY2+1 < imageDimensionY+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                                connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                            }
                                            if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                                connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                            }
                                            
                                            if (connectAnalysisCount != 0){
                                                do{
                                                    
                                                    terminationFlag = 1;
                                                    connectAnalysisTempCount = 0;
                                                    
                                                    for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                                        xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                                        
                                                        if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                                            connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource+1 < imageDimensionX+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                                            connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                        if (ySource+1 < imageDimensionY+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                                            connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                                            connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                    }
                                                    
                                                    for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                                        connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                                    }
                                                    
                                                    connectAnalysisCount = connectAnalysisTempCount;
                                                    
                                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                                    
                                                } while (terminationFlag == 1);
                                            }
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < 512+2; counterA++){
                                //	for (int counterB = 0; counterB < 512+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                                //	cout<<" connectivityUpdate5 "<<counterA<<endl;
                                //}
                                
                                int connectTemp2 = 0;
                                
                                if (connectivityNumber < -1){
                                    int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                                    
                                    for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
                                    
                                    for (int counterY2 = 0; counterY2 < imageDimensionY+2; counterY2++){
                                        for (int counterX2 = 0; counterX2 < imageDimensionX+2; counterX2++){
                                            connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                                            
                                            if (connectTemp2 < -1){
                                                connectTemp2 = connectTemp2*-1;
                                                
                                                if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterY2-1 >= 0 && counterX2+1 < imageDimensionX+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterX2+1 < imageDimensionX+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterY2+1 < imageDimensionY+2 && counterX2+1 < imageDimensionX+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterY2+1 < imageDimensionY+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterY2+1 < imageDimensionY+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                            }
                                        }
                                    }
                                    
                                    int zeroFillFlag = 0;
                                    
                                    for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                                        if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
                                    }
                                    
                                    //for (int counterA = 1; counterA <= connectivityNumber*-1; counterA++){
                                    //    cout<<counterA<<" "<<connectCheckArray [counterA*2]<<" "<<connectCheckArray [counterA*2+1]<<" check"<<endl;
                                    //}
                                    
                                    //for (int counterA = 0; counterA < 512+2; counterA++){
                                    //    for (int counterB = 0; counterB < 512+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                                    //    cout<<" connectivityUpdate5 "<<counterA<<endl;
                                    //}
                                    
                                    if (zeroFillFlag == 1){
                                        for (int counterY2 = 0; counterY2 < imageDimensionY+2; counterY2++){
                                            for (int counterX2 = 0; counterX2 < imageDimensionX+2; counterX2++){
                                                connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                                                
                                                if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                                            }
                                        }
                                        
                                        for (int counterY2 = 0; counterY2 < imageDimensionY+2; counterY2++){
                                            for (int counterX2 = 0; counterX2 < imageDimensionX+2; counterX2++){
                                                if (connectivityUpdate5 [counterY2][counterX2] > 0){
                                                    backBaseTemp [counterY2][counterX2] = connectivityUpdate5 [counterY2][counterX2];
                                                }
                                            }
                                        }
                                    }
                                    
                                    delete [] connectCheckArray;
                                }
                                
                                for (int counter1 = 0; counter1 < imageDimensionY+4; counter1++) delete [] connectivityUpdate5 [counter1];
                                
                                delete [] connectivityUpdate5;
                                //-----
                                
                                for (int counterY = 0; counterY < imageDimensionY+2; counterY++){
                                    for (int counterX = 0; counterX < imageDimensionX+2; counterX++){
                                        if (backBaseTemp [counterY][counterX] != 0){
                                            if (counterX+1 < imageDimensionX+2 && backBaseTemp [counterY][counterX+1] == 0) backBaseTemp [counterY][counterX] = -1;
                                            else if (counterY+1 < imageDimensionY+2 && backBaseTemp [counterY+1][counterX] == 0) backBaseTemp [counterY][counterX] = -1;
                                            else if (counterX-1 >= 0 && backBaseTemp [counterY][counterX-1] == 0) backBaseTemp [counterY][counterX] = -1;
                                            else if (counterY-1 >= 0 && backBaseTemp [counterY-1][counterX] == 0) backBaseTemp [counterY][counterX] = -1;
                                        }
                                    }
                                }
                                
                                for (int counterY = 0; counterY < imageDimensionY+2; counterY++){
                                    for (int counterX = 0; counterX < imageDimensionX+2; counterX++){
                                        if (backBaseTemp [counterY][counterX] > 0) backBaseTemp [counterY][counterX] = 0;
                                        if (backBaseTemp [counterY][counterX] < 0) backBaseTemp [counterY][counterX] = 1;
                                    }
                                }
                                
                                connectivityNumber = 0;
                                
                                for (int counterY2 = 0; counterY2 < imageDimensionY+2; counterY2++){
                                    for (int counterX2 = 0; counterX2 < imageDimensionX+2; counterX2++){
                                        if (backBaseTemp [counterY2][counterX2] == 0){
                                            connectivityNumber--;
                                            connectAnalysisCount = 0;
                                            
                                            backBaseTemp [counterY2][counterX2] = connectivityNumber;
                                            
                                            if (counterY2-1 >= 0 && backBaseTemp [counterY2-1][counterX2] == 0){
                                                backBaseTemp [counterY2-1][counterX2] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                            }
                                            if (counterX2+1 < imageDimensionX+2 && backBaseTemp [counterY2][counterX2+1] == 0){
                                                backBaseTemp [counterY2][counterX2+1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                            }
                                            if (counterY2+1 < imageDimensionY+2 && backBaseTemp [counterY2+1][counterX2] == 0){
                                                backBaseTemp [counterY2+1][counterX2] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                            }
                                            if (counterX2-1 >= 0 && backBaseTemp [counterY2][counterX2-1] == 0){
                                                backBaseTemp [counterY2][counterX2-1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                            }
                                            
                                            if (connectAnalysisCount != 0){
                                                do{
                                                    
                                                    terminationFlag = 1;
                                                    connectAnalysisTempCount = 0;
                                                    
                                                    for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                                        xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                                        
                                                        if (ySource-1 >= 0 && backBaseTemp [ySource-1][xSource] == 0){
                                                            backBaseTemp [ySource-1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource+1 < imageDimensionX+2 && backBaseTemp [ySource][xSource+1] == 0){
                                                            backBaseTemp [ySource][xSource+1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                        if (ySource+1 < imageDimensionY+2 && backBaseTemp [ySource+1][xSource] == 0){
                                                            backBaseTemp [ySource+1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource-1 >= 0 && backBaseTemp [ySource][xSource-1] == 0){
                                                            backBaseTemp [ySource][xSource-1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                    }
                                                    
                                                    for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                                        connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                                    }
                                                    
                                                    connectAnalysisCount = connectAnalysisTempCount;
                                                    
                                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                                    
                                                } while (terminationFlag == 1);
                                            }
                                        }
                                    }
                                }
                                
                                //-----Determine number of pixels-----
                                connectivityNumber = connectivityNumber*-1;
                                
                                int *connectedPix = new int [connectivityNumber+50];
                                for (int counter1 = 0; counter1 <= connectivityNumber; counter1++) connectedPix [counter1] = 0;
                                
                                for (int counterY2 = 0; counterY2 < imageDimensionY+2; counterY2++){
                                    for (int counterX2 = 0; counterX2 < imageDimensionX+2; counterX2++){
                                        if (backBaseTemp [counterY2][counterX2] < -1) connectedPix [backBaseTemp [counterY2][counterX2]*-1]++;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA <= connectivityNumber; counterA++){
                                //    cout<<counterA<<" "<<connectedPix [counterA]<<" connect"<<endl;
                                //}
                                
                                int **newConnectivityMapTemp = new int *[(imageDimensionY+2)+4];
                                for (int counter1 = 0; counter1 < (imageDimensionY+2)+4; counter1++) newConnectivityMapTemp [counter1] = new int [(imageDimensionX+2)+4];
                                
                                for (int counterY = 0; counterY < (imageDimensionY+2)+4; counterY++){
                                    for (int counterX = 0; counterX < (imageDimensionX+2)+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
                                }
                                
                                int targetConnectNo2 = backBaseTemp [yClickPosition+1][xClickPosition+1]*-1;
                                
                                if (targetConnectNo2 != -1 && connectedPix [targetConnectNo2] > 50){
                                    for (int counterY2 = 0; counterY2 < imageDimensionY+2; counterY2++){
                                        for (int counterX2 = 0; counterX2 < imageDimensionX+2; counterX2++){
                                            if (backBaseTemp [counterY2][counterX2] == targetConnectNo2*-1){
                                                if (counterY2-1 >= 0 && counterX2-1 >= 0 && backBaseTemp [counterY2-1][counterX2-1] == 1){
                                                    newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                                                    backBaseTemp [counterY2-1][counterX2-1] = 0;
                                                }
                                                if (counterY2-1 >= 0 && backBaseTemp [counterY2-1][counterX2] == 1){
                                                    newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                                                    backBaseTemp [counterY2-1][counterX2] = 0;
                                                }
                                                if (counterY2-1 >= 0 && counterX2+1 < imageDimensionX+2 && backBaseTemp [counterY2-1][counterX2+1] == 1){
                                                    newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                                                    backBaseTemp [counterY2-1][counterX2+1] = 0;
                                                }
                                                if (counterX2+1 < imageDimensionX+2 && backBaseTemp [counterY2][counterX2+1] == 1){
                                                    newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                                                    backBaseTemp [counterY2][counterX2+1] = 0;
                                                }
                                                if (counterY2+1 < imageDimensionY+2 && counterX2+1 < imageDimensionX+2 && backBaseTemp [counterY2+1][counterX2+1] == 1){
                                                    newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                                                    backBaseTemp [counterY2+1][counterX2+1] = 0;
                                                }
                                                if (counterY2+1 < imageDimensionY+2 && backBaseTemp [counterY2+1][counterX2] == 1){
                                                    newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                                                    backBaseTemp [counterY2+1][counterX2] = 0;
                                                }
                                                if (counterY2+1 < imageDimensionY+2 && counterX2-1 >= 0 && backBaseTemp [counterY2+1][counterX2-1] == 1){
                                                    newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                                                    backBaseTemp [counterY2+1][counterX2-1] = 0;
                                                }
                                                if (counterX2-1 >= 0 && backBaseTemp [counterY2][counterX2-1] == 1){
                                                    newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                                                    backBaseTemp [counterY2][counterX2-1] = 0;
                                                }
                                            }
                                        }
                                    }
                                    
                                    int xPositionTempStart = 0;
                                    int yPositionTempStart = 0;
                                    int lineSize = 0;
                                    
                                    for (int counterY2 = 0; counterY2 < imageDimensionY+2; counterY2++){
                                        for (int counterX2 = 0; counterX2 < imageDimensionX+2; counterX2++){
                                            if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                                                backBaseTemp [counterY2][counterX2] = 1;
                                                xPositionTempStart = counterX2;
                                                yPositionTempStart = counterY2;
                                                lineSize++;
                                            }
                                            else backBaseTemp [counterY2][counterX2] = 0;
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < 512; counterA++){
                                    //	for (int counterB = 0; counterB < 512; counterB++) cout<<" "<<backBaseTemp [counterA][counterB];
                                    //	cout<<" backBaseTemp "<<counterA<<endl;
                                    //}
                                    
                                    int constructedLineCount = 0;
                                    int findFlag = 0;
                                    
                                    int *arrayNewLines = new int [lineSize*2+50];
                                    
                                    backBaseTemp [yPositionTempStart][xPositionTempStart] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                    
                                    do{
                                        
                                        findFlag = 0;
                                        terminationFlag = 0;
                                        
                                        if (xPositionTempStart+1 < imageDimensionX+2){
                                            if (backBaseTemp [yPositionTempStart][xPositionTempStart+1] == 1){
                                                backBaseTemp [yPositionTempStart][xPositionTempStart+1] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                                xPositionTempStart = xPositionTempStart+1;
                                                terminationFlag = 1;
                                                findFlag = 1;
                                            }
                                        }
                                        if (xPositionTempStart+1 < imageDimensionX+2 && yPositionTempStart+1 < imageDimensionY+2 && findFlag == 0){
                                            if (backBaseTemp [yPositionTempStart+1][xPositionTempStart+1] == 1){
                                                backBaseTemp [yPositionTempStart+1][xPositionTempStart+1] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                                xPositionTempStart = xPositionTempStart+1;
                                                yPositionTempStart = yPositionTempStart+1;
                                                terminationFlag = 1;
                                                findFlag = 1;
                                            }
                                        }
                                        if (yPositionTempStart+1 < imageDimensionY+2 && findFlag == 0){
                                            if (backBaseTemp [yPositionTempStart+1][xPositionTempStart] == 1){
                                                backBaseTemp [yPositionTempStart+1][xPositionTempStart] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                                yPositionTempStart = yPositionTempStart+1;
                                                terminationFlag = 1;
                                                findFlag = 1;
                                            }
                                        }
                                        if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < imageDimensionY+2 && findFlag == 0){
                                            if (backBaseTemp [yPositionTempStart+1][xPositionTempStart-1] == 1){
                                                backBaseTemp [yPositionTempStart+1][xPositionTempStart-1] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                                xPositionTempStart = xPositionTempStart-1;
                                                yPositionTempStart = yPositionTempStart+1;
                                                terminationFlag = 1;
                                                findFlag = 1;
                                            }
                                        }
                                        if (xPositionTempStart-1 >= 0 && findFlag == 0){
                                            if (backBaseTemp [yPositionTempStart][xPositionTempStart-1] == 1){
                                                backBaseTemp [yPositionTempStart][xPositionTempStart-1] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                                xPositionTempStart = xPositionTempStart-1;
                                                terminationFlag = 1;
                                                findFlag = 1;
                                            }
                                        }
                                        if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                                            if (backBaseTemp [yPositionTempStart-1][xPositionTempStart-1] == 1){
                                                backBaseTemp [yPositionTempStart-1][xPositionTempStart-1] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                                xPositionTempStart = xPositionTempStart-1;
                                                yPositionTempStart = yPositionTempStart-1;
                                                terminationFlag = 1;
                                                findFlag = 1;
                                            }
                                        }
                                        if (yPositionTempStart-1 >= 0 && findFlag == 0){
                                            if (backBaseTemp [yPositionTempStart-1][xPositionTempStart] == 1){
                                                backBaseTemp [yPositionTempStart-1][xPositionTempStart] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                                yPositionTempStart = yPositionTempStart-1;
                                                terminationFlag = 1;
                                                findFlag = 1;
                                            }
                                        }
                                        if (xPositionTempStart+1 < imageDimensionX+2 && yPositionTempStart-1 >= 0 && findFlag == 0){
                                            if (backBaseTemp [yPositionTempStart-1][xPositionTempStart+1] == 1){
                                                backBaseTemp [yPositionTempStart-1][xPositionTempStart+1] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                                xPositionTempStart = xPositionTempStart+1;
                                                yPositionTempStart = yPositionTempStart-1;
                                                terminationFlag = 1;
                                            }
                                        }
                                        
                                    } while (terminationFlag == 1);
                                    
                                    backAreaLineDownArrayCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < constructedLineCount/2; counter2++){
                                        backAreaLineDownArray [backAreaLineDownArrayCount] = arrayNewLines [counter2*2]-1, backAreaLineDownArrayCount++;
                                        backAreaLineDownArray [backAreaLineDownArrayCount] = arrayNewLines [counter2*2+1]-1, backAreaLineDownArrayCount++;
                                    }
                                    
                                    for (int counterY = 0; counterY < imageDimensionY+2; counterY++){
                                        for (int counterX = 0; counterX < imageDimensionX+2; counterX++){
                                            if (backBaseTemp [counterY][counterX] == -1) backBaseTemp [counterY][counterX] = 1;
                                        }
                                    }
                                    
                                    connectivityNumber = -3;
                                    
                                    for (int counterY = 0; counterY < imageDimensionY+2; counterY++){
                                        for (int counterX = 0; counterX < imageDimensionX+2; counterX++){
                                            if (backBaseTemp [counterY][counterX] == 0){
                                                connectivityNumber = connectivityNumber+2;
                                                backBaseTemp [counterY][counterX] = connectivityNumber;
                                                
                                                connectAnalysisCount = 0;
                                                
                                                if (counterY-1 >= 0 && backBaseTemp [counterY-1][counterX] == 0){
                                                    backBaseTemp [counterY-1][counterX] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                }
                                                if (counterX+1 < imageDimensionY+2 && backBaseTemp [counterY][counterX+1] == 0){
                                                    backBaseTemp [counterY][counterX+1] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                }
                                                if (counterY+1 < imageDimensionY+2 && backBaseTemp [counterY+1][counterX] == 0){
                                                    backBaseTemp [counterY+1][counterX] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                }
                                                if (counterX-1 >= 0 && backBaseTemp [counterY][counterX-1] == 0){
                                                    backBaseTemp [counterY][counterX-1] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                }
                                                
                                                if (connectAnalysisCount != 0){
                                                    do{
                                                        
                                                        terminationFlag = 1;
                                                        connectAnalysisTempCount = 0;
                                                        
                                                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                                            xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                                            
                                                            if (ySource-1 >= 0 && backBaseTemp [ySource-1][xSource] == 0){
                                                                backBaseTemp [ySource-1][xSource] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                            }
                                                            if (xSource+1 < imageDimensionX+2 && backBaseTemp [ySource][xSource+1] == 0){
                                                                backBaseTemp [ySource][xSource+1] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                            }
                                                            if (ySource+1 < imageDimensionY+2 && backBaseTemp [ySource+1][xSource] == 0){
                                                                backBaseTemp [ySource+1][xSource] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                            }
                                                            if (xSource-1 >= 0 && backBaseTemp [ySource][xSource-1] == 0){
                                                                backBaseTemp [ySource][xSource-1] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                            }
                                                        }
                                                        
                                                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                                        }
                                                        
                                                        connectAnalysisCount = connectAnalysisTempCount;
                                                        
                                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                                        
                                                    } while (terminationFlag == 1);
                                                }
                                            }
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < 512; counterA++){
                                    //    for (int counterB = 0; counterB < 512; counterB++) cout<<" "<<backBaseTemp [counterA][counterB];
                                    //    cout<<" backBaseTemp "<<counterA<<endl;
                                    //}
                                    
                                    //-----Remove connectivity groups that are attached to the edge; extract the inner part of linked lines groups, which attach edge, extract inner part of Linked Line-----
                                    for (int counterY = 0; counterY < imageDimensionY+2; counterY++){
                                        for (int counterX = 0; counterX < imageDimensionX+2; counterX++){
                                            if (backBaseTemp [counterY][counterX] == -1) backBaseTemp [counterY][counterX] = 0;
                                        }
                                    }
                                    
                                    for (int counterY = 0; counterY < imageDimensionY; counterY++){
                                        for (int counterX = 0; counterX < imageDimensionX; counterX++){
                                            backAreaMapDownArray [counterY][counterX] = 0;
                                        }
                                    }
                                    
                                    for (int counterY = 0; counterY < imageDimensionY+2; counterY++){
                                        for (int counterX = 0; counterX < imageDimensionX+2; counterX++){
                                            if (backBaseTemp [counterY][counterX] > 0){
                                                backAreaMapDownArray [counterY-1][counterX-1] = backBaseTemp [counterY][counterX];
                                            }
                                        }
                                    }
                                    
                                    delete [] arrayNewLines;
                                    
                                    areaSetFlag3 = 1;
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                }
                                else{
                                    
                                    areaSetFlag3 = 0;
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                                
                                for (int counter1 = 0; counter1 < (imageDimensionY+2)+4; counter1++) delete [] newConnectivityMapTemp [counter1];
                                delete [] newConnectivityMapTemp;
                                
                                delete [] connectedPix;
                            }
                            else{
                                
                                areaSetFlag3 = 0;
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                        else{
                            
                            areaSetFlag3 = 0;
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                        
                        for (int counter1 = 0; counter1 < imageDimensionY+4; counter1++){
                            delete [] backBaseTemp [counter1];
                        }
                        
                        delete [] backBaseTemp;
                        
                        delete [] connectAnalysisX;
                        delete [] connectAnalysisY;
                        delete [] connectAnalysisTempX;
                        delete [] connectAnalysisTempY;
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Overlay Mode Off"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    if (backgroundOriginalLoadFlag != 3){
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Background Image Mode Off"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"No Image Point Selected"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)findBestMatchBK:(id)sender{
    if (loadImageTreatName != ""){
        if (backgroundOriginalLoadFlag == 0 && imageFindFlag == 0  && imageDimensionY > 0 && imageDimensionX > 0){
            double maskMatrix [5][5] = {{0.0035, 0.0145, 0.0256, 0.0145, 0.0035}, {0.0145, 0.0586, 0.0952, 0.0556, 0.0145}, {0.0256, 0.0952, 0.1501, 0.0952, 0.0256}, {0.0145, 0.0586, 0.0952, 0.0586, 0.0145}, {0.0035, 0.0145, 0.0256, 0.0145, 0.0035}};
            
            int **backgroundImage1 = new int *[imageDimensionY+1];
            int **gaussianImage = new int *[imageDimensionY+1];
            
            for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                backgroundImage1 [counter1] = new int [imageDimensionX+1];
                gaussianImage [counter1] = new int [imageDimensionX+1];
            }
            
            int xBlockNo = 1;
            int yBlockNo = 1;
            
            if (imageDimensionX > 0) xBlockNo = imageDimensionX/8;
            if (imageDimensionY > 0) yBlockNo = imageDimensionY/8;
            
            int **imageMatrixTemp2 = new int *[yBlockNo+1];
            int **middleIntensity = new int *[yBlockNo+1];
            int **backCheckTemp = new int *[yBlockNo+1];
            
            for (int counter1 = 0; counter1 < yBlockNo+1; counter1++){
                imageMatrixTemp2 [counter1] = new int [xBlockNo+1];
                middleIntensity [counter1] = new int [xBlockNo+1];
                backCheckTemp [counter1] = new int [xBlockNo+1];
            }
            
            for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                    backgroundImage1 [counter2][counter3] = arrayImageContrastAdjust [(currentOriginalNo-1)*imageDimensionY+counter2][counter3];
                }
            }
            
            //-----Apply Gaussian blur-----
            double bitGaussian = 0;
            
            for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                    bitGaussian = 0;
                    
                    for (int counter4 = -2; counter4 <= 2; counter4++){
                        for (int counter5 = -2; counter5 <= 2; counter5++){
                            if (counter2+counter4 >= imageDimensionY || counter2+counter4 < 0 || counter3+counter5 >= imageDimensionX || counter3+counter5 < 0){
                                bitGaussian = bitGaussian+backgroundImage1 [counter2][counter3]*maskMatrix [counter4+2][counter5+2];
                            }
                            else bitGaussian = bitGaussian+backgroundImage1 [counter2+counter4][counter3+counter5]*maskMatrix [counter4+2][counter5+2];
                        }
                    }
                    
                    gaussianImage [counter2][counter3] = (int)bitGaussian;
                }
            }
            
            int middleDataAverage = 0;
            int middleDataLow = 10000;
            int flattenPixCount = 0;
            int totalForAverage = 0;
            int middleCount = 0;
            int middleData = 0;
            
            double averagePix = 0;
            double totalForStandardDev = 0;
            double standardDevPix = 0;
            
            //-----Image matrix set: Determine SD -----
            for (int counter2 = 0; counter2 < yBlockNo; counter2++){
                for (int counter3 = 0; counter3 < xBlockNo; counter3++){
                    flattenPixCount = 0;
                    totalForAverage = 0;
                    totalForStandardDev = 0;
                    middleCount = 0;
                    middleData = 0;
                    
                    //-----For Sd calculation-----
                    for (int counter4 = counter2*8; counter4 < counter2*8+8; counter4++){
                        for (int counter5 = counter3*8; counter5 < counter3*8+8; counter5++){
                            totalForAverage = totalForAverage+gaussianImage [counter4][counter5], flattenPixCount++;
                        }
                    }
                    
                    //-----For middle intensity-----
                    for (int counter4 = counter2*8; counter4 < counter2*8+8; counter4++){
                        for (int counter5 = counter3*8; counter5 < counter3*8+8; counter5++){
                            if (gaussianImage [counter4][counter5] > 75 && gaussianImage [counter4][counter5] < 175){
                                middleData = middleData+gaussianImage [counter4][counter5], middleCount++;
                            }
                        }
                    }
                    
                    if (middleCount != 0) middleIntensity [counter2][counter3] = (int)(middleData/(double)middleCount);
                    else middleIntensity [counter2][counter3] = 0;
                    
                    middleDataAverage = middleDataAverage+middleIntensity [counter2][counter3];
                    
                    if (middleDataLow > middleIntensity [counter2][counter3] && middleIntensity [counter2][counter3] != 0) middleDataLow = middleIntensity [counter2][counter3];
                    
                    //-----SD calculation-----
                    averagePix = totalForAverage/(double)64;
                    
                    for (int counter4 = counter2*8; counter4 < counter2*8+8; counter4++){
                        for (int counter5 = counter3*8; counter5 < counter3*8+8; counter5++){
                            totalForStandardDev = totalForStandardDev+(gaussianImage [counter4][counter5]-averagePix)*(gaussianImage [counter4][counter5]-averagePix);
                        }
                    }
                    
                    imageMatrixTemp2 [counter2][counter3] = (int)averagePix;
                }
            }
            
            double *sdList = new double [backgroundPatternArrayCount/(xBlockNo*yBlockNo)+1];
            
            for (int counter2 = 0; counter2 < backgroundPatternArrayCount/(xBlockNo*yBlockNo); counter2++) sdList [counter2] = 0;
            
            for (int counter2 = 0; counter2 < backgroundPatternArrayCount/(xBlockNo*yBlockNo); counter2++){
                for (int counter3 = 0; counter3 < yBlockNo; counter3++){
                    for (int counter4 = 0; counter4 < xBlockNo; counter4++) backCheckTemp [counter3][counter4] = backgroundPatternArray [counter2*(xBlockNo*yBlockNo)+counter3*yBlockNo+counter4];
                }
                
                //-----For Sd calculation-----
                totalForAverage = 0;
                
                for (int counter3 = 0; counter3 < yBlockNo; counter3++){
                    for (int counter4 = 0; counter4 < xBlockNo; counter4++){
                        totalForAverage = totalForAverage+abs(backCheckTemp [counter3][counter4]-imageMatrixTemp2 [counter3][counter4]);
                        flattenPixCount++;
                    }
                }
                
                averagePix = totalForAverage/(double)(xBlockNo*yBlockNo);
                
                //-----SD calculation-----
                totalForStandardDev = 0;
                
                for (int counter3 = 0; counter3 < yBlockNo; counter3++){
                    for (int counter4 = 0; counter4 < xBlockNo; counter4++){
                        totalForStandardDev = totalForStandardDev+(abs(backCheckTemp [counter3][counter4]-imageMatrixTemp2 [counter3][counter4])-averagePix)*(abs(backCheckTemp [counter3][counter4]-imageMatrixTemp2 [counter3][counter4])-averagePix);
                    }
                }
                
                standardDevPix = sqrt(totalForStandardDev/(double)(xBlockNo*yBlockNo));
                
                sdList [counter2] = standardDevPix;
            }
            
            int maxFit = -1;
            double maxFitCount = 10000000;
            
            for (int counter2 = 0; counter2 < backgroundPatternArrayCount/(xBlockNo*yBlockNo); counter2++){
                if (sdList [counter2] < maxFitCount){
                    maxFitCount = sdList [counter2];
                    maxFit = counter2;
                }
            }
            
            if (maxFit != -1){
                backgroundDisplayPage = maxFit+1;
                backgroundOriginalLoadFlag = 1;
            }
            
            for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                delete [] backgroundImage1 [counter1];
                delete [] gaussianImage [counter1];
            }
            
            delete [] backgroundImage1;
            delete [] gaussianImage;
            
            for (int counter1 = 0; counter1 < yBlockNo+1; counter1++){
                delete [] middleIntensity [counter1];
                delete [] backCheckTemp [counter1];
                delete [] imageMatrixTemp2 [counter1];
            }
            
            delete [] middleIntensity;
            delete [] backCheckTemp;
            delete [] imageMatrixTemp2;
            
            delete [] sdList;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Original Mode Off"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageOverlaySelect:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (overlayStatusHold == 0){
                    overlayStatusHold = 1;
                    overlayStatusSend = 1;
                    [overlayStatusDisplay setStringValue:@"On"];
                }
                else if (overlayStatusHold == 1){
                    overlayStatusHold = 0;
                    overlayStatusSend = 1;
                    [overlayStatusDisplay setStringValue:@"Off"];
                }
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExtensionUpSet:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionUPCurrent = [sliderExtensionUp doubleValue];
                    
                    int limitTemp = (int)(expansionUPCurrent*100);
                    double limitTemp2 = limitTemp/(double)100;
                    
                    [extensionUpDisplay setDoubleValue:limitTemp2];
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    edgeSetFlag = 1;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExtensionDownSet:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionDownCurrent = [sliderExtensionDown doubleValue];
                    
                    int limitTemp = (int)(expansionDownCurrent*100);
                    double limitTemp2 = limitTemp/(double)100;
                    
                    [extensionDownDisplay setDoubleValue:limitTemp2];
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    edgeSetFlag = 1;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExtensionRightSet:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionRightCurrent = [sliderExtensionRight doubleValue];
                    
                    int limitTemp = (int)(expansionRightCurrent*100);
                    double limitTemp2 = limitTemp/(double)100;
                    
                    [extensionRightDisplay setDoubleValue:limitTemp2];
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    edgeSetFlag = 1;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExtensionLeftSet:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionLeftCurrent = [sliderExtensionLeft doubleValue];
                    
                    int limitTemp = (int)(expansionLeftCurrent*100);
                    double limitTemp2 = limitTemp/(double)100;
                    
                    [extensionLeftDisplay setDoubleValue:limitTemp2];
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    edgeSetFlag = 1;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)extensionUpClear:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionUPCurrent = 1;
                    
                    int limitTemp = (int)(expansionUPCurrent*100);
                    double limitTemp2 = limitTemp/(double)100;
                    
                    [extensionUpDisplay setDoubleValue:limitTemp2];
                    [sliderExtensionKnobUp setDoubleValue:expansionUPCurrent];
                    
                    [sliderExtensionUp setMaxValue:sliderExUpMax];
                    [sliderExtensionUp setMinValue:sliderExUpMin];
                    [sliderExtensionUp setDoubleValue:1];
                    
                    [sliderExUpCircle setDoubleValue:1];
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    edgeSetFlag = 1;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)extensionDownClear:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionDownCurrent = 1;
                    
                    int limitTemp = (int)(expansionDownCurrent*100);
                    double limitTemp2 = limitTemp/(double)100;
                    
                    [extensionDownDisplay setDoubleValue:limitTemp2];
                    [sliderExtensionKnobDown setDoubleValue:expansionDownCurrent];
                    
                    [sliderExtensionDown setMaxValue:sliderExDownMax];
                    [sliderExtensionDown setMinValue:sliderExDownMin];
                    [sliderExtensionDown setDoubleValue:1];
                    
                    [sliderExDownCircle setDoubleValue:1];
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    edgeSetFlag = 1;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)extensionRightClear:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionRightCurrent = 1;
                    
                    int limitTemp = (int)(expansionRightCurrent*100);
                    double limitTemp2 = limitTemp/(double)100;
                    
                    [extensionRightDisplay setDoubleValue:limitTemp2];
                    [sliderExtensionKnobRight setDoubleValue:expansionRightCurrent];
                    
                    [sliderExtensionRight setMaxValue:sliderExRightMax];
                    [sliderExtensionRight setMinValue:sliderExRightMin];
                    [sliderExtensionRight setDoubleValue:1];
                    
                    [sliderExRightCircle setDoubleValue:1];
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    edgeSetFlag = 1;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)extensionLeftClear:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionLeftCurrent = 1;
                    
                    int limitTemp = (int)(expansionLeftCurrent*100);
                    double limitTemp2 = limitTemp/(double)100;
                    
                    [extensionLeftDisplay setDoubleValue:limitTemp2];
                    [sliderExtensionKnobLeft setDoubleValue:expansionLeftCurrent];
                    
                    [sliderExtensionLeft setMaxValue:sliderExLeftMax];
                    [sliderExtensionLeft setMinValue:sliderExLeftMin];
                    [sliderExtensionLeft setDoubleValue:1];
                    
                    [sliderExLeftCircle setDoubleValue:1];
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    edgeSetFlag = 1;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderAddSubtractAction:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 3){
                    baseContrastSetAS = [sliderAddSubtract doubleValue];
                    baseContrastSetFlagAS = 1;
                    
                    int valueDisplayTemp = (int)(baseContrastSetAS*10);
                    double valueDisplayTemp2 = valueDisplayTemp/(double)10;
                    
                    [addSubtractDisplay setDoubleValue:valueDisplayTemp2];
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)setAddSubtract:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 3){
                    int valueSet = (int)[inputField integerValue];
                    [inputField setStringValue:@""];
                    
                    if (valueSet >= 1 && valueSet <= 10){
                        contrastCutOffAS = valueSet;
                        baseContrastSetAS = 0;
                        
                        [gainDisplay setIntegerValue:contrastCutOffAS];
                        [sliderAddSubtractKnob setDoubleValue:baseContrastSetAS];
                        
                        int valueDisplayTemp = (int)(baseContrastSetAS*100);
                        double valueDisplayTemp2 = valueDisplayTemp/(double)100;
                        
                        [addSubtractDisplay setDoubleValue:valueDisplayTemp2];
                        
                        subprocesses = [[SubProcesses alloc] init];
                        [subprocesses variableSave];
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Value Out Of Range"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clearAddSubtract:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 3){
                    contrastCutOffAS = 1;
                    baseContrastSetAS = 0;
                    
                    [gainDisplay setIntegerValue:contrastCutOffAS];
                    [sliderAddSubtractKnob setDoubleValue:baseContrastSetAS];
                    
                    int valueDisplayTemp = (int)(baseContrastSetAS*100);
                    double valueDisplayTemp2 = valueDisplayTemp/(double)100;
                    
                    [addSubtractDisplay setDoubleValue:valueDisplayTemp2];
                    
                    [sliderAddSubtract setMaxValue:sliderGainMax];
                    [sliderAddSubtract setMinValue:sliderGainMin];
                    [sliderAddSubtract setDoubleValue:0];
                    
                    [sliderAddSubtractCircle setDoubleValue:1];
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)extensionUpLineClear:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionUPPosition1 = 0;
                    expansionUPPosition2 = 0;
                    
                    [extensionUpLine1 setIntegerValue:(long)expansionUPPosition1];
                    [extensionUpLine2 setIntegerValue:(long)expansionUPPosition2];
                    
                    [sliderExUpLineCircle1 setDoubleValue:1];
                    [sliderExUpLineCircle2 setDoubleValue:1];
                    [sliderExUpLineCircle3 setDoubleValue:1];
                    [sliderExUpLineCircle4 setDoubleValue:1];
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    edgeSetFlag = 1;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)extensionDownLineClear:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionDownPosition1 = imageDimensionY-1;
                    expansionDownPosition2 = imageDimensionY-1;
                    
                    [extensionDownLine1 setIntegerValue:(long)expansionDownPosition1];
                    [extensionDownLine2 setIntegerValue:(long)expansionDownPosition2];
                    
                    [sliderExDownLineCircle1 setDoubleValue:1];
                    [sliderExDownLineCircle2 setDoubleValue:1];
                    [sliderExDownLineCircle3 setDoubleValue:1];
                    [sliderExDownLineCircle4 setDoubleValue:1];
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    edgeSetFlag = 1;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)extensionRightLineClear:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionRightPosition1 = imageDimensionX-1;
                    expansionRightPosition2 = imageDimensionX-1;
                    
                    [extensionRightLine1 setIntegerValue:(long)expansionRightPosition1];
                    [extensionRightLine2 setIntegerValue:(long)expansionRightPosition2];
                    
                    [sliderExRightLineCircle1 setDoubleValue:1];
                    [sliderExRightLineCircle2 setDoubleValue:1];
                    [sliderExRightLineCircle3 setDoubleValue:1];
                    [sliderExRightLineCircle4 setDoubleValue:1];
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    edgeSetFlag = 1;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)extensionLeftLineClear:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionLeftPosition1 = 0;
                    expansionLeftPosition2 = 0;
                    
                    [extensionLeftLine1 setIntegerValue:(long)expansionLeftPosition1];
                    [extensionLeftLine2 setIntegerValue:(long)expansionLeftPosition2];
                    
                    [sliderExLeftLineCircle1 setDoubleValue:1];
                    [sliderExLeftLineCircle2 setDoubleValue:1];
                    [sliderExLeftLineCircle3 setDoubleValue:1];
                    [sliderExLeftLineCircle4 setDoubleValue:1];
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    edgeSetFlag = 1;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExUpCircleSet:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    double sliderCircleValue = sliderExUpMax*[sliderExUpCircle doubleValue];
                    double sliderCircleValue2 = sliderExUpMin/[sliderExUpCircle doubleValue];
                    double sliderValue = [sliderExtensionUp doubleValue];
                    
                    double range2 = sliderCircleValue-sliderCircleValue2;
                    range2 = range2/sliderExUpDiff;
                    
                    sliderCircleValue = sliderValue+(sliderExUpMax-sliderValue)/range2;
                    sliderCircleValue2 = sliderValue-(sliderValue-sliderExUpMin)/range2;
                    
                    [sliderExtensionUp setMaxValue:sliderCircleValue];
                    [sliderExtensionUp setMinValue:sliderCircleValue2];
                    
                    int baseEnhanceInt = (int)([sliderExtensionUp doubleValue]*100);
                    double baseEnhanceDouble = baseEnhanceInt/(double)100;
                    
                    [extensionUpDisplay setDoubleValue:baseEnhanceDouble];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExUpLineCircle1Set:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionUPPosition1--;
                    
                    if (expansionUPPosition1 >= 0){
                        [extensionUpLine1 setIntegerValue:(long)expansionUPPosition1];
                        
                        subprocesses = [[SubProcesses alloc] init];
                        [subprocesses variableSave];
                        
                        edgeSetFlag = 1;
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                    }
                    else expansionUPPosition1 = 0;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExUpLineCircle2Set:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionUPPosition1++;
                    
                    if (expansionUPPosition1 >= 0 && expansionUPPosition1 < imageDimensionY/2){
                        [extensionUpLine1 setIntegerValue:(long)expansionUPPosition1];
                        
                        subprocesses = [[SubProcesses alloc] init];
                        [subprocesses variableSave];
                        
                        edgeSetFlag = 1;
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                    }
                    else expansionUPPosition1 = imageDimensionY/2-1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExUpLineCircle3Set:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionUPPosition2--;
                    
                    if (expansionUPPosition2 >= 0){
                        [extensionUpLine2 setIntegerValue:(long)expansionUPPosition2];
                        
                        subprocesses = [[SubProcesses alloc] init];
                        [subprocesses variableSave];
                        
                        edgeSetFlag = 1;
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                    }
                    else expansionUPPosition2 = 0;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExUpLineCircle4Set:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionUPPosition2++;
                    
                    if (expansionUPPosition2 >= 0 && expansionUPPosition2 < imageDimensionY/2){
                        [extensionUpLine2 setIntegerValue:(long)expansionUPPosition2];
                        
                        subprocesses = [[SubProcesses alloc] init];
                        [subprocesses variableSave];
                        
                        edgeSetFlag = 1;
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                    }
                    else expansionUPPosition2 = imageDimensionY/2-1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExDownCircleSet:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    double sliderCircleValue = sliderExDownMax*[sliderExDownCircle doubleValue];
                    double sliderCircleValue2 = sliderExDownMin/[sliderExDownCircle doubleValue];
                    double sliderValue = [sliderExtensionDown doubleValue];
                    
                    double range2 = sliderCircleValue-sliderCircleValue2;
                    range2 = range2/sliderExDownDiff;
                    
                    sliderCircleValue = sliderValue+(sliderExDownMax-sliderValue)/range2;
                    sliderCircleValue2 = sliderValue-(sliderValue-sliderExDownMin)/range2;
                    
                    [sliderExtensionDown setMaxValue:sliderCircleValue];
                    [sliderExtensionDown setMinValue:sliderCircleValue2];
                    
                    int baseEnhanceInt = (int)([sliderExtensionDown doubleValue]*100);
                    double baseEnhanceDouble = baseEnhanceInt/(double)100;
                    
                    [extensionDownDisplay setDoubleValue:baseEnhanceDouble];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExDownLineCircle1Set:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionDownPosition1--;
                    
                    if (expansionDownPosition1 >= imageDimensionY/2){
                        [extensionDownLine1 setIntegerValue:(long)expansionDownPosition1];
                        
                        subprocesses = [[SubProcesses alloc] init];
                        [subprocesses variableSave];
                        
                        edgeSetFlag = 1;
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                    }
                    else expansionDownPosition1 = imageDimensionY/2;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExDownLineCircle2Set:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionDownPosition1++;
                    
                    if (expansionDownPosition1 >= imageDimensionY/2 && expansionDownPosition1 < imageDimensionY){
                        [extensionDownLine1 setIntegerValue:(long)expansionDownPosition1];
                        
                        subprocesses = [[SubProcesses alloc] init];
                        [subprocesses variableSave];
                        
                        edgeSetFlag = 1;
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                    }
                    else expansionDownPosition1 = imageDimensionY-1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExDownLineCircle3Set:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionDownPosition2--;
                    
                    if (expansionDownPosition2 >= imageDimensionY/2){
                        [extensionDownLine2 setIntegerValue:(long)expansionDownPosition2];
                        
                        subprocesses = [[SubProcesses alloc] init];
                        [subprocesses variableSave];
                        
                        edgeSetFlag = 1;
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                    }
                    else expansionDownPosition2 = imageDimensionY/2;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExDownLineCircle4Set:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionDownPosition2++;
                    
                    if (expansionDownPosition2 >= imageDimensionY/2 && expansionDownPosition2 < imageDimensionY){
                        [extensionDownLine2 setIntegerValue:(long)expansionDownPosition2];
                        
                        subprocesses = [[SubProcesses alloc] init];
                        [subprocesses variableSave];
                        
                        edgeSetFlag = 1;
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                    }
                    else expansionDownPosition2 = imageDimensionY-1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExRightCircleSet:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    double sliderCircleValue = sliderExRightMax*[sliderExRightCircle doubleValue];
                    double sliderCircleValue2 = sliderExRightMin/[sliderExRightCircle doubleValue];
                    double sliderValue = [sliderExtensionRight doubleValue];
                    
                    double range2 = sliderCircleValue-sliderCircleValue2;
                    range2 = range2/sliderExRightDiff;
                    
                    sliderCircleValue = sliderValue+(sliderExRightMax-sliderValue)/range2;
                    sliderCircleValue2 = sliderValue-(sliderValue-sliderExRightMin)/range2;
                    
                    [sliderExtensionRight setMaxValue:sliderCircleValue];
                    [sliderExtensionRight setMinValue:sliderCircleValue2];
                    
                    int baseEnhanceInt = (int)([sliderExtensionRight doubleValue]*100);
                    double baseEnhanceDouble = baseEnhanceInt/(double)100;
                    
                    [extensionRightDisplay setDoubleValue:baseEnhanceDouble];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExRightLineCircle1Set:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionRightPosition1--;
                    
                    if (expansionRightPosition1 >= imageDimensionX/2){
                        [extensionRightLine1 setIntegerValue:(long)expansionRightPosition1];
                        
                        subprocesses = [[SubProcesses alloc] init];
                        [subprocesses variableSave];
                        
                        edgeSetFlag = 1;
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                    }
                    else expansionRightPosition1 = imageDimensionX/2;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExRightLineCircle2Set:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionRightPosition1++;
                    
                    if (expansionRightPosition1 >= imageDimensionX/2 && expansionRightPosition1 < imageDimensionX){
                        [extensionRightLine1 setIntegerValue:(long)expansionRightPosition1];
                        
                        subprocesses = [[SubProcesses alloc] init];
                        [subprocesses variableSave];
                        
                        edgeSetFlag = 1;
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                    }
                    else expansionRightPosition1 = imageDimensionX-1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExRightLineCircle3Set:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionRightPosition2--;
                    
                    if (expansionRightPosition2 >= imageDimensionX/2){
                        [extensionRightLine2 setIntegerValue:(long)expansionRightPosition2];
                        
                        subprocesses = [[SubProcesses alloc] init];
                        [subprocesses variableSave];
                        
                        edgeSetFlag = 1;
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                    }
                    else expansionRightPosition2 = imageDimensionX/2;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExRightLineCircle4Set:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionRightPosition2++;
                    
                    if (expansionRightPosition2 >= imageDimensionX/2 && expansionRightPosition2 < imageDimensionX){
                        [extensionRightLine2 setIntegerValue:(long)expansionRightPosition2];
                        
                        subprocesses = [[SubProcesses alloc] init];
                        [subprocesses variableSave];
                        
                        edgeSetFlag = 1;
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                    }
                    else expansionRightPosition2 = imageDimensionX-1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExLeftCircleSet:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    double sliderCircleValue = sliderExLeftMax*[sliderExLeftCircle doubleValue];
                    double sliderCircleValue2 = sliderExLeftMin/[sliderExLeftCircle doubleValue];
                    double sliderValue = [sliderExtensionLeft doubleValue];
                    
                    double range2 = sliderCircleValue-sliderCircleValue2;
                    range2 = range2/sliderExLeftDiff;
                    
                    sliderCircleValue = sliderValue+(sliderExLeftMax-sliderValue)/range2;
                    sliderCircleValue2 = sliderValue-(sliderValue-sliderExLeftMin)/range2;
                    
                    [sliderExtensionLeft setMaxValue:sliderCircleValue];
                    [sliderExtensionLeft setMinValue:sliderCircleValue2];
                    
                    int baseEnhanceInt = (int)([sliderExtensionLeft doubleValue]*100);
                    double baseEnhanceDouble = baseEnhanceInt/(double)100;
                    
                    [extensionLeftDisplay setDoubleValue:baseEnhanceDouble];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExLeftLineCircle1Set:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionLeftPosition1--;
                    
                    if (expansionLeftPosition1 >= 0){
                        [extensionLeftLine1 setIntegerValue:(long)expansionLeftPosition1];
                        
                        subprocesses = [[SubProcesses alloc] init];
                        [subprocesses variableSave];
                        
                        edgeSetFlag = 1;
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                    }
                    else expansionLeftPosition1 = 0;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExLeftLineCircle2Set:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionLeftPosition1++;
                    
                    if (expansionLeftPosition1 >= 0 && expansionLeftPosition1 < imageDimensionX/2){
                        [extensionLeftLine1 setIntegerValue:(long)expansionLeftPosition1];
                        
                        subprocesses = [[SubProcesses alloc] init];
                        [subprocesses variableSave];
                        
                        edgeSetFlag = 1;
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                    }
                    else expansionLeftPosition1 = imageDimensionX/2-1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExLeftLineCircle3Set:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionLeftPosition2--;
                    
                    if (expansionLeftPosition2 >= 0){
                        [extensionLeftLine2 setIntegerValue:(long)expansionLeftPosition2];
                        
                        subprocesses = [[SubProcesses alloc] init];
                        [subprocesses variableSave];
                        
                        edgeSetFlag = 1;
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                    }
                    else expansionLeftPosition2 = 0;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderExLeftLineCircle4Set:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundPatternArrayCount >= 1){
                if (backgroundOriginalLoadFlag == 4){
                    expansionLeftPosition2++;
                    
                    if (expansionLeftPosition2 >= 0 && expansionLeftPosition2 < imageDimensionX/2){
                        [extensionLeftLine2 setIntegerValue:(long)expansionLeftPosition2];
                        
                        subprocesses = [[SubProcesses alloc] init];
                        [subprocesses variableSave];
                        
                        edgeSetFlag = 1;
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                    }
                    else expansionLeftPosition2 = imageDimensionX/2-1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Background Image Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)bkFlipHorizontal:(id)sender{
    if (loadImageTreatName != ""){
        if (backgroundPatternArrayCount >= 1){
            if (backgroundOriginalLoadFlag == 3){
                baseContrastSetFlagHorizontal = 1;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Background Image Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)bkFlipVertical:(id)sender{
    if (loadImageTreatName != ""){
        if (backgroundPatternArrayCount >= 1){
            if (backgroundOriginalLoadFlag == 3){
                baseContrastSetFlagVertical = 1;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Background Image Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Background Image Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)closeWindow:(id)sender{
    [backgroundMainWindow orderOut:self];
    backgroundAdjustOperation = 2;
    backgroundTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
    [backgroundTimer2 invalidate];
}

-(void)reDisplayWindow{
    if (backgroundAdjustOperation == 3){
        [backgroundMainWindow makeKeyAndOrderFront:self];
        backgroundAdjustOperation = 1;
        [backgroundTimer invalidate];
        backgroundTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToBackgroundController object:nil];
    if (backgroundTimer) [backgroundTimer invalidate];
    if (backgroundTimer2) [backgroundTimer2 invalidate];
}

@end
