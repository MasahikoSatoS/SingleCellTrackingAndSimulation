//
//  BalanceController.h
//  Contrast_Set
//
//  Created by Masahiko Sato on 6/8/16.
//  Copyright Masahiko Sato 2016 All rights reserved.
//
//

#ifndef BALANCECONTROLLER_H
#define BALANCECONTROLLER_H
#import "Controller.h" 
#endif

@interface BalanceController : NSObject{
    int rangeSetFlag; //Flag for Calc. perform
    int backgroundLoadFlag; //Background load
    
    double sliderBalanceMax; //Slider
    double sliderBalanceMin; //Slider
    double sliderBalanceDiff; //Slider
    
    double sliderBalanceMaxHorizontal; //Slider
    double sliderBalanceMinHorizontal; //Slider
    double sliderBalanceDiffHorizontal; //Slider
    
    double sliderBalanceMaxVertical; //Slider
    double sliderBalanceMinVertical; //Slider
    double sliderBalanceDiffVertical; //Slider
    
    IBOutlet NSTextField *tretmentBalance;
    IBOutlet NSTextField *balanceLimitDisplay;
    IBOutlet NSTextField *calculationRange;
    IBOutlet NSTextField *currentLimitValue;
    IBOutlet NSTextField *currentLimitValueHorizontal;
    IBOutlet NSTextField *currentLimitValueVertical;
    IBOutlet NSSlider *sliderRangeLimit;
    IBOutlet NSSlider *sliderRangeLimitCircle;
    IBOutlet NSCell *sliderRangeLimitKnob;
    IBOutlet NSSlider *sliderRangeLimitHorizontal;
    IBOutlet NSSlider *sliderRangeLimitCircleHorizontal;
    IBOutlet NSCell *sliderRangeLimitKnobHorizontal;
    IBOutlet NSSlider *sliderRangeLimitVertical;
    IBOutlet NSSlider *sliderRangeLimitCircleVertical;
    IBOutlet NSCell *sliderRangeLimitKnobVertical;
    IBOutlet NSWindow *balanceWindow;
    
    IBOutlet NSProgressIndicator *backSave;
    
    id balanceSet;
    id backgroundCorrection;
    id subprocesses;
    
    NSTimer *balanceTimer;
    NSTimer *balanceTimer2;
    
    NSWindowController *balanceWindController;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;
-(void)display;

-(IBAction)closeWindow:(id)sender;
-(IBAction)saveData:(id)sender;
-(IBAction)imageLoad:(id)sender;
-(IBAction)sliderRangeSet:(id)sender;
-(IBAction)sliderRangeSetCircle:(id)sender;

-(IBAction)sliderRangeHorizontalSet:(id)sender;
-(IBAction)sliderRangeSetHorizontalCircle:(id)sender;
-(IBAction)clearHorizontalRangeLimit:(id)sender;

-(IBAction)sliderRangeVerticalSet:(id)sender;
-(IBAction)sliderRangeSetVerticalCircle:(id)sender;
-(IBAction)clearVerticalRangeLimit:(id)sender;

-(IBAction)calcRangeLimit:(id)sender;
-(IBAction)clearRangeLimit:(id)sender;
-(IBAction)backgroundLoad:(id)sender;

@end
