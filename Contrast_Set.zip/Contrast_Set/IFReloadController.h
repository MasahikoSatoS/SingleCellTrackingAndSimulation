//
//  IFReloadController.h
//  Contrast_Set
//
//  Created by Masahiko Sato on 11/17/16.
//  Copyright Masahiko Sato 2016 All rights reserved.
//
//

#ifndef IFRELOADCONTROLLER_H
#define IFRELOADCONTROLLER_H
#import "Controller.h" 
#endif

@interface IFReloadController : NSObject {
    IBOutlet NSWindow *ifReloadWindow;
    NSTimer *ifReloadTimer;
    
    NSWindowController *ifReloadWindowController;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;

-(IBAction)closeWindow:(id)sender;

@end
