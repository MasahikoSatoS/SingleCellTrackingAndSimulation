//
//  BalanceSet.h
//  Contrast_Set
//
//  Created by Masahiko Sato on 6/8/16.
//  Copyright Masahiko Sato 2016 All rights reserved.
//
//

#ifndef BALANCESET_H
#define BALANCESET_H
#import "Controller.h" 
#endif


@interface BalanceSet : NSObject{
}

-(void)balanceSetMain:(int)fovNoSet;
-(void)balanceSetAuto:(int)fovNoSet;

@end
