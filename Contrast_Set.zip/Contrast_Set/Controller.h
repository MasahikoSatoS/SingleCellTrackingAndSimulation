/*
 *  Controller.h
 *  Contrast_Set
 *
 *  Created by Masahiko Sato on 01/01/10.
 *  Copyright Masahiko Sato 2010 All rights reserved.
 */

#ifndef CONTROLLER_H
#define CONTROLLER_H
#import <Cocoa/Cocoa.h>
#import "Autocontrast.h"
#import "MainImage.h"
#import "HistogramWindow.h"
#import "ObjectMatch.h"
#import "BackgroundCorrection.h"
#import "ImageDataSet.h"
#import "ContrastWindow.h"
#import "TerminationMonitor.h"
#import "FluorescentAdjustController.h"
#import "SetData.h"
#import "BackgroundController.h"
#import "BalanceController.h"
#import "ASCIIconversion.h"
#import "ContrastAdjust.h"
#import "BalanceSet.h"
#import "FluorescentAdjust.h"
#import "BackgroundWindow.h"
#import "BalanceWindow.h"
#import "IFReloadController.h"
#import "IFReloadOperation.h"
#import "SingleTiffSave.h"
#import "TiffFileRead.h"
#import "SubProcesses.h"
#include <iostream>
#include <dirent.h>
#include <sys/stat.h>
#include <fstream>
#include <sstream>
#endif

using namespace std;

extern NSString *notificationToTermination;
extern NSString *notificationToAutocontrast;
extern NSString *notificationToMainImage;
extern NSString *notificationToHistogram;
extern NSString *notificationToContrastWindow;
extern NSString *notificationToAdjustController;
extern NSString *notificationToFluorescentAdjust;
extern NSString *notificationToBackgroundController;
extern NSString *notificationToBackgroundWindow;
extern NSString *notificationToBalanceController;
extern NSString *notificationToBalanceWindow;
extern NSString *notificationToIFReloadController;
extern NSString *notificationToIFReloadOperation;

//-----Basic Info-----
extern int imageDimensionX;//Image size X
extern int imageDimensionY;//Image size Y
extern int stitchImageDimension; //Stitched image dimension
extern int totalFOVNoHoldInt; //Hold Total No of FOV Int
extern int tableCallCount; //Table Row count control
extern int fluorescentCount;// Fluorescent CH count

extern string pathNameString;//Path name
extern string bodyName;//Body name
extern string totalFOVNoHold;//Hold total No of FOVs
extern string fluorescent1;//Fluorescent name
extern string fluorescent2;//Fluorescent name
extern string fluorescent3;//Fluorescent name
extern string fluorescent4;//Fluorescent name
extern string fluorescent5;//Fluorescent name
extern string fluorescent6;//Fluorescent name
extern string fluorescentNo1;//Fluorescent no
extern string fluorescentNo2;//Fluorescent no
extern string fluorescentNo3;//Fluorescent no
extern string fluorescentNo4;//Fluorescent no
extern string fluorescentNo5;//Fluorescent no
extern string fluorescentNo6;//Fluorescent no

extern string colorNameHold; //Color name for histogram
extern string colorNoHold; //Color no for histogram
extern int colorNameHoldStatus; //Hold status of color name set: increase the speed of array set
extern int colorNameDisplayCall; //Color name display call
extern int tableColorStatus; //Table color display
extern int fluorescentDisplayModeHold; //Fluorescent image add color or BW

//-----Calls-----
extern int tableViewCall; //Table Call
extern int rowIndexHold; //Table Row Info Hold
extern int imageInfoDisplayCall; //Call image info display
extern int mainImageDisplayCall; //Call main image display
extern int histogramDisplayCall; //Call histogram display
extern int contrastDisplayCall; //Call contrast display
extern int timePointDisplayCall; //Call for time Point display
extern int timePointRequest; //Time Point display
extern int callFromHistogram; //Call Main image from histogram
extern int backgroundCorrectionCall; //Call background correction

//-----Processing-----
extern int imageFirstLoadFlagDisplay; //Main image first display
extern int magnificationDisplay; //Main image magnification
extern int currentTimePoint; //Hold Current time point
extern int entryNumber; //Number of contrast data entry
extern int loadImageNo; //Hold loading image no
extern int loadImageFOVNo; //FOV no of loaded image
extern int lastImageNo; //Hold last image no
extern int contrastDataLimit; //Contrast Data Table limit
extern int sourceTimeDisplayFlag; //Source time image display flag
extern int blurStatusHold; //Blur Status hold
extern int autoProcessingFlag; //Hold auto processing status
extern int reprocessStartFlag; //Set when reprocessing starts
extern int reprocessImageNo; //Hold reprocessing image no
extern int progressValue; //Hold Progress indicator value
extern int progressTiming; //Hold Progress indicator timing
extern int progressTimingB; //Hold Progress indicator timing
extern int progressTimingC; //Hold Progress indicator timing
extern int imageFindFlag; //Set when images are found
extern double windowWidthDisplay;//Window size
extern double windowHeightDisplay;//Window size
extern string ascIIstring;// ASCII code
extern string fileNoStringTemp; //File No
extern string batchImageBodyName; //Batch image body name
extern string baseTreatmentName; //Treatment name
extern string objectiveType; //Objective type
extern string loadImageTreatName; //Hold loading image Treatment Name

//-----Main Image Control-----
extern int lowValueDisplay; //Histo Low Value
extern int meanValueDisplay; //Histo Mean Value
extern int highValueDisplay; //Histo High Value
extern int lowValueDisplayG; //Histo Low Value
extern int meanValueDisplayG; //Histo Mean Value
extern int highValueDisplayG; //Histo High Value
extern int lowValueDisplayB; //Histo Low Value
extern int meanValueDisplayB; //Histo Mean Value
extern int highValueDisplayB; //Histo High Value
extern int processingFovNo; //FOV no that is under the processing
extern int contrastBarActivate; //Flag for contrast bar
extern int fovFirstClick; //Fov first click
extern int fovSecondClick; //Fov second click
extern int fovClickSide; //Click side hold
extern int positionSetStatus; //XY position set status, 1: X, 2: Y
extern int fovFirstSetFlag; //FOV set first time check
extern int fovFirstClickOR1; //FOV Click Orientation Hold:use for U
extern int fovSecondClickOR1; //FOV Click Orientation Hold:use for U
extern int fovFirstClickOR2; //FOV Click Orientation Hold:use for U
extern int fovSecondClickOR2; //FOV Click Orientation Hold:use for U
extern double histoMaxCount; //Histogram total hold
extern int currentFOVNoHold; //For Holding each Fov's contrast data, current Fov no hold
extern int contrastFirstRead; //When cut off data is set for the first time, set the flag
extern double contrastValueDisplay; //Contrast Value Hold
extern double contrastValueDisplayG; //Contrast Value Hold
extern double contrastValueDisplayB; //Contrast Value Hold
extern int resolutionStatus; //Hold resolution status
extern int photoMetricHold; //Image photometric
extern int rgbDisplayStatus; //In the case image is RGB, select display status, Histo allow to change
extern int xOrientation; //Image display orientation X: 0: FW, 1: RV
extern int yOrientation; //Image display orientation Y: 0: FW, 1: RW
extern int xyInvert; //Invert xy position
extern int firstDataSetFlag; //Set when the first data set is done, if this flag is 1, not allow to change image orientation
extern int orientationSetFlag; // Flag for orientation set

extern string imageFLStatus; //Image Lock/Free status
extern string contrastOADisplay; //Contrast Auto or Off display status
extern string backgroundOADisplay; //Background or Off display status

//-----Stitched image making-----
extern int autoType; //Auto process type
extern int autoImageSizeX; //Image size X determined by the auto mode
extern int autoImageSizeY; //Image size Y determined by the auto mode
extern string treatmentNameAuto; //Treatment name for stitched image making

//-----Fluorescent Image Overlay-----
extern int positionAdjustOperation; //Fluorescent window display control
extern int positionAdjustFlag; //Set when fluorescent image is loaded
extern int imageMoveStatus; //Fluorescent image move allow
extern int imageFirstLoadFlagDisplayFluorescent; //Fluorescent image first load
extern int magnificationDisplayFluorescent; //Fluorescent position set magnification
extern int xMovePositionHoldMain; //Fluorescent image move
extern int yMovePositionHoldMain; //Fluorescent image move
extern int channelAdjustHoldX1; //CH position adjust X hold
extern int channelAdjustHoldX2; //CH position adjust X hold
extern int channelAdjustHoldX3; //CH position adjust X hold
extern int channelAdjustHoldX4; //CH position adjust X hold
extern int channelAdjustHoldX5; //CH position adjust X hold
extern int channelAdjustHoldX6; //CH position adjust X hold
extern int channelAdjustHoldY1; //CH position adjust Y hold
extern int channelAdjustHoldY2; //CH position adjust Y hold
extern int channelAdjustHoldY3; //CH position adjust Y hold
extern int channelAdjustHoldY4; //CH position adjust Y hold
extern int channelAdjustHoldY5; //CH position adjust Y hold
extern int channelAdjustHoldY6; //CH position adjust Y hold
extern int channelAdjustFirstSet1; //CH position first set
extern int channelAdjustFirstSet2; //CH position first set
extern int channelAdjustFirstSet3; //CH position first set
extern int channelAdjustFirstSet4; //CH position first set
extern int channelAdjustFirstSet5; //CH position first set
extern int channelAdjustFirstSet6; //CH position first set
extern double baseCut; //Hold cut level
extern double fluorescentEnhance; //Fluorescent intensity
extern int fluorescentStitchDimension; //Fluorescent image dimension
extern double dicLevelHold; //Hold dic level
extern double dicContrastHold; //Hold dic contrast level
extern string zImageColorSet; //Color no hold

//-----IF processing-----
extern int statusIFHold; //IF status hold

//-----Background Adjust Operation-----
extern int backgroundAdjustOperation; //Background operation
extern int backgroundOriginalLoadFlag; //Background original image load
extern int currentOriginalNo; //FOV no for display
extern int backgroundDisplayPage; //BK no for display
extern int imageFirstLoadFlagDisplayBK; //BK image first load
extern int magnificationDisplayBK; //BK position set magnification
extern int treatmentBKCall; //Treatment BK call
extern int contrastCutOff1; //Adjust cut off value
extern int contrastCutOff3; //Adjust cut off value
extern int contrastCutOffAS; //Add Subtract Gain
extern int baseContrastSetFlag1; //Set when contrast is changed
extern int baseContrastSetFlag3; //Set when contrast is changed
extern int baseContrastSetFlagAS; //Add Subtract, set when the value is changed
extern int baseContrastSetFlagVertical; //Vertical flip
extern int baseContrastSetFlagHorizontal; //Horizontal flip
extern int areaSetFlag1; //Set area flag 1
extern int areaSetFlag3; //Set area flag 1
extern int contrastAreaOffHold1; //Adjust cut off value for area
extern int contrastAreaOffHold3; //Adjust cut off value for area
extern double baseContrastSet1; //Contrast adjust value
extern double baseContrastSet3; //Contrast adjust value
extern double baseContrastSetAS; //Add Subtract, Adjust value
extern int xClickPosition; //Click position x hold
extern int yClickPosition; //Click position y hold
extern int lineAreaStatusHold; //Point/Link mode hold
extern int backArea; //Point/Link box size
extern int clickNumber; //A 64x64 box number hold
extern int overlayStatusHold; //Hold overlay Status
extern int overlayStatusSend; //Set when overlay Status changed
extern double expansionUPCurrent; //Expansion parameters
extern double expansionDownCurrent; //Expansion parameters
extern double expansionRightCurrent; //Expansion parameters
extern double expansionLeftCurrent; //Expansion parameters
extern double expansionUPPosition1; //Expansion parameters
extern double expansionUPPosition2; //Expansion parameters
extern double expansionDownPosition1; //Expansion parameters
extern double expansionDownPosition2; //Expansion parameters
extern double expansionRightPosition1; //Expansion parameters
extern double expansionRightPosition2; //Expansion parameters
extern double expansionLeftPosition1; //Expansion parameters
extern double expansionLeftPosition2; //Expansion parameters
extern int edgeSetFlag; //Set when edge is changed
extern int clickAreaSetValue; //Click position value for area set
extern int clickAreaHighValue; //Click position value for area set, High
extern int clickAreaLowValue; //Click position value for area set, Low
extern int bkUnUsedCall; //Call when BK unused is done

//-----Paths-----
extern string productsFilesImagePath; //Products file path
extern string productsFilesTempPath; //Products temp file path
extern string productsFilesInfoPath; //Products file info path
extern string contrastSettingPath; //Products setting path
extern string fovPositionPath; //Fov position path
extern string fovPositionIFHoldPath; //Fov position IF path
extern string stitchedFolderPath; //Stitched folder path
extern string productsStitchTempPath; //Products stitched temp path
extern string instructionCSPath; //Instraction
extern string instructionAPPath; //Instraction
extern string contrastSettingTempPath; //Contrast setting path
extern string fovPositionTempPath; //Fov position path
extern string stitchedFolderImagePath; //Stitched folder path
extern string loadingCompletePath; //Loading completion path
extern string fileSavePathHold; //Path for Tiff file save

//-----Arrays-----
extern string *arrayTreatmentNameDisplay; //Array for Table Display, treatment name
extern int treatmentNameDisplayCount;
extern string *arrayFOVNameDisplay; //Array for Table Display, FOV
extern int fOVNameDisplayCount;
extern string *arrayTableDisplay; //Array for table display (if an image is color, hold red data)
extern int tableDisplayCount;
extern string *arrayTableDisplayG; //Array for table display for green
extern int tableDisplayCountG;
extern string *arrayTableDisplayB; //Array for table display for blue
extern int tableDisplayCountB;

extern string **arrayContrastData; // Contrast data
extern string **arrayContrastDataG; // Contrast data
extern string **arrayContrastDataB; // Contrast data
extern int contrastDataHorizontal;
extern int contrastDataEntry;

extern int **arrayImageDataHold; //Source Image data array
extern int imageDataHoldStatus;
extern int **arrayImageRangeAdjust; //Range Adjusted data array
extern int **arrayImageCutoffAdjust; //Image cut off apply
extern int **arrayImageContrastAdjust; //Image Contrasted adjust

extern int **arrayBackgroundDataHold; //Background data array
extern int **arrayBackgroundDataHold2; //Background data array For Balance
extern int **arrayBalanceDataHold; //Balance data array
extern int **arrayBalanceBaseData; //Balance data array
extern int **arrayBalanceBaseModify; //Balance data array

extern int *arrayImageDataHistogram; //Source Image Histogram: 255 for each FOV and then 255 for the whole image
extern int *arrayImageDataHistogramG; //Source Image Histogram: 255 for each FOV and then 255 for the whole image
extern int *arrayImageDataHistogramB; //Source Image Histogram: 255 for each FOV and then 255 for the whole image
extern int *arrayImageRangeAdjustHistogram; //Range adjust Histogram
extern int *arrayImageRangeAdjustHistogramG; //Range adjust Histogram
extern int *arrayImageRangeAdjustHistogramB; //Range adjust Histogram
extern int *arrayImageCutoffAdjustHistogram; //Cut off adjust histogram
extern int *arrayImageCutoffAdjustHistogramG; //Cut off adjust histogram
extern int *arrayImageCutoffAdjustHistogramB; //Cut off adjust histogram
extern int *arrayImageContrastAdjustHistogram; //Contrast adjust histogram
extern int *arrayImageContrastAdjustHistogramG; //Contrast adjust histogram
extern int *arrayImageContrastAdjustHistogramB; //Contrast adjust histogram

extern int *arrayImageDataLMH; //Source Image LMH
extern int *arrayImageDataLMHG; //Source Image LMH
extern int *arrayImageDataLMHB; //Source Image LMH
extern int *arrayImageRangeAdjustLMH; //Range adjust Image LMH
extern int *arrayImageRangeAdjustLMHG; //Range adjust Image LMH
extern int *arrayImageRangeAdjustLMHB; //Range adjust Image LMH
extern int *autoContrastCorrectLMH; //Cut off adjust LMH
extern int *autoContrastCorrectLMHG; //Cut off adjust LMH
extern int *autoContrastCorrectLMHB; //Cut off adjust LMH
extern int *autoContrastCorrectLMH2; //Contrast adjusted LMH
extern int *autoContrastCorrectLMH2G; //Contrast adjusted LMH
extern int *autoContrastCorrectLMH2B; //Contrast adjusted LMH

extern string *xyPositionData; //XY position read from image files
extern int *xyPositionDataHold; //XY position read from image files data hold
extern int *arrayXYWritingPosition; //XY position data for display, read saved data
extern int *arrayXYWritingPositionBase; //Base XY position, for fluorescent position set
extern int *arrayXYWritingPositionFluorescent; //Base XY position, for fluorescent position set

extern int **imageDisplayArray; //Hold image display data
extern int **imagePositionMap; //FOV no map
extern int **imageDisplayBaseArray; //Hold Base image display data
extern int **imageDisplayFluorescentArray; //Hold Base image display data

extern string *arrayHorizontalLink; //Fov horizontal order
extern int horizontalLinkCount;
extern string *arrayVerticalLink; //Fov vertical order
extern int verticalLinkCount;

extern double *contrastValueHold; //Hold each FOV's contrast data
extern int contrastValueCount;
extern double *contrastValueHoldG; //Hold each FOV's contrast data
extern int contrastValueCountG;
extern double *contrastValueHoldB; //Hold each FOV's contrast data
extern int contrastValueCountB;
extern string *contrastCurrentHold; //Current Cut off data hold
extern string *contrastCurrentHoldG; //Current Cut off data hold
extern string *contrastCurrentHoldB; //Current Cut off data hold

extern int **arrayBackgroundCorrectionData; //Array used for Auto processing, Background and Balance correction

extern int *backgroundPatternArray; //Background pattern original hold=====BK correction and BK
extern int backgroundPatternArrayCount;
extern int *backgroundPatternModifyArray; //Background pattern modified hold=====BK correction and BK
extern int backgroundPatternModifyArrayCount;
extern int backgroundPatternFirstSet; //Set when "B" is pressed first time, set background pattern arrays
extern int backgroundPatternArrayStatus; //Set this flag when arrays are allocated.
extern string *backgroundPatternName; //Background name=====BK

extern int **backBaseArray; //Hold back grayscale value (for point/link modify)=====BK
extern int **backBaseMap; //Hold back 64x64 box no map data=====BK
extern int **backBaseArrayModify; //Hold back grayscale value (for adjust)======BK
extern int **backBaseArrayEdge; //Hold back grayscale value (for edge)======BK

extern int **backBaseArrayPrevious; //Hold back grayscale value (for point/link modify): Previous images======BK
extern int *backBasePositionArray; //Hold base position sequence
extern int *backAreaLineUpArray; //Hold back area line up array ======BK
extern int backAreaLineUpArrayCount;
extern int *backAreaLineDownArray; //Hold back area line Down array======BK
extern int backAreaLineDownArrayCount;
extern int **backAreaMapUpArray; //Hold back area map array======BK
extern int **backAreaMapDownArray; //Hold back area map Down array======BK
extern int backArraysSetStatus; //Set this flag when background arrays are set

extern double *correctionValues; //Hold Fov correction values
extern string *arrayFileDelete; //File order/delete array
extern int fileDeleteCount;
extern int fileDeleteLimit;
extern uint8_t *fileReadArray;//array holding image data
extern int **arrayImageFileSave;//image array for tif save

//-----Communication-----
extern int processMode; //Process Mode
extern int imageProcessTiming; //Image Processing timing control

//-----Balance Window-----
extern int positionBalanceOperation; //Balance window operation
extern int balanceImageLoadFlag; //Set when image is loaded
extern double rangeLimitCurrent; //Current range limit
extern double rangeLimitCurrentHorizontal; //Range limit
extern double rangeLimitCurrentVertical; //Range limit

//-----IF reload-----
extern int ifReloadWindowOperation; //IF read operation
extern int *arrayIfReload; //IF read array
extern int ifReloadCount;
extern int ifReloadStatus;

//========Data format=========
//low/mean/high/gain S00:0~0.00
//Low/ Mean/ High/ Gain BK correction Range: BK No~ UD Boarder= RL Boarder +UP extension| Down extension# Right extension% Left Extension

//E.G. 76/106/136/0 A50:6~0.351501^1.1369%-0.471034

/*
 Old format. Focal images were saved as a bmp format, and a histogram data and XY position were written in the bmp file by Focal selection software. The format (bmp) was changed to tif (8 bit, Gray or RGB, any dimension). A histogram is determined after uploading image file. XY position was written in the comment section of tif.
 
 Image data is processed as a 8 bit Gray or Color
 */

/*
 processMode = "2"; //Initial Auto mode
 processMode = "3"; //Initial Auto After set
 processMode = "4"; //Batch BK, during the holding
 processMode = "5"; //Batch BK running
 processMode = "6"; //Auto, during the holding
 processMode = "7"; //Auto running
 processMode = "8"; //Initial Batch BK
 processMode = "9"; //Initial Batch BK, after set
 processMode = "10"; //Initial Batch IG
 processMode = "11"; //Initial Batch IG, after set
 processMode = "12"; //Batch IG, during the holding
 processMode = "13"; //Batch IG running
 */

@interface Controller : NSObject <NSTableViewDataSource, NSTextFieldDelegate> {
    //-----Basic Information-----
    int tableCurrentRowHold; //Table current position hold
    int exitFlag; //Exit Flag
    int initialArraySet; //First Array Set
    int noFileFoundFlag; //When no files are found, terminate
    int lastProductFileNo; //Hold last product file no
    int processingFromHold; //Hold reprocessing from
    int processingToHold; //Hold reprocessing To
    int reprocessStatus; //Hold re-processing status
    int copyFirstTime; //Set copy is used
    int bkRemoveLevel; //Strength to remove BK
    
    //-----Image Processing Info-----
    int imagePosition; //Image position
    int imageFirstLoadFlag; //Set when image was loaded
    
    //-----Communication-----
    int firstCommunication; //Communication First check
    int basicInfoRead; //Read status data
    
    IBOutlet NSTableView *tableViewList;
    
    IBOutlet NSTextField *analysisName;
    IBOutlet NSTextField *treatmentName;
    IBOutlet NSTextField *timePointDisplay;
    IBOutlet NSTextField *totalFileDisplay;
    IBOutlet NSTextField *fovNoDisplay;
    IBOutlet NSTextField *processModeDisplay;
    IBOutlet NSTextField *lockStatus;
    IBOutlet NSTextField *contrastImageDisplay;
    IBOutlet NSTextField *backImageDisplay;
    IBOutlet NSTextField *imagePositionDisplay;
    IBOutlet NSTextField *delTime;
    IBOutlet NSTextField *copyTime;
    IBOutlet NSTextField *rangeValueSet;
    IBOutlet NSTextField *sourceTimeStatusDisplay;
    IBOutlet NSTextField *sourceTimeStatusDisplay2;
    IBOutlet NSTextField *lastTimePositionDisplay;
    IBOutlet NSTextField *bkRemovalLevelDisplay;
    IBOutlet NSTextField *bkRemovalLevelSet;
    IBOutlet NSTextField *lastPageNoDisplay;
    IBOutlet NSTextField *blurStatusDisplay;
    IBOutlet NSTextField *reprocessFromDisplay;
    IBOutlet NSTextField *reprocessToDisplay;
    IBOutlet NSTextField *reprocessNoDisplay;
    IBOutlet NSTextField *histColorStatusDisplay;
    IBOutlet NSTextField *fluorescentModeDisplay;
    IBOutlet NSTextField *rgbStatusDisplay;
    IBOutlet NSTextField *rgbStatusHistDisplay;
    IBOutlet NSTextField *xOrientationDisplay;
    IBOutlet NSTextField *yOrientationDisplay;
    IBOutlet NSTextField *xySwitchDisplay;
    
    IBOutlet NSStepper *stepperFrom;
    IBOutlet NSStepper *stepperTo;
    
    IBOutlet NSWindow *autocontrast;
    
    id imageDataSet;
    id setData;
    id ascIIconversion;
    id objectMatch;
    id backgroundCorrection;
    id tiffFileRead;
    id subprocesses;
    
    NSTimer *controllerTimer;
    
    IBOutlet NSProgressIndicator *backSave;
    IBOutlet NSProgressIndicator *progressIndicator;
}

-(id)init;
-(void)dealloc;
-(void)processStartSub;
-(void)processStopMain;
-(void)displayData;
-(void)communication;
-(void)imageLoadMain;
-(void)currentTableData;
-(void)fileDeleteUpDate;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

-(IBAction)processStart:(id)sender;
-(IBAction)processStop:(id)sender;
-(IBAction)omnibusSet:(id)sender;
-(IBAction)tableFW:(id)sender;
-(IBAction)tableBW:(id)sender;
-(IBAction)tableTenFW:(id)sender;
-(IBAction)tableTenBW:(id)sender;
-(IBAction)imageLoad:(id)sender;
-(IBAction)setData:(id)sender;
-(IBAction)removeData:(id)sender;
-(IBAction)imageFB:(id)sender;
-(IBAction)imageTenFB:(id)sender;
-(IBAction)imageHundredFB:(id)sender;
-(IBAction)imageBW:(id)sender;
-(IBAction)imageTenBW:(id)sender;
-(IBAction)imageHundredBW:(id)sender;
-(IBAction)tableLoad:(id)sender;
-(IBAction)positionAdjustStart:(id)sender;
-(IBAction)copySetting:(id)sender;
-(IBAction)setPixRange:(id)sender;
-(IBAction)clearRange:(id)sender;
-(IBAction)timeSourceSet:(id)sender;
-(IBAction)backgroundAdjustStart:(id)sender;
-(IBAction)bkRemovalSet:(id)sender;
-(IBAction)blurSet:(id)sender;
-(IBAction)positionBalanceStart:(id)sender;
-(IBAction)stepperActionFrom:(id)sender;
-(IBAction)stepperActionTo:(id)sender;
-(IBAction)reProcessingSet:(id)sender;
-(IBAction)ifReloadStart:(id)sender;
-(IBAction)tempContrastReloadStart:(id)sender;
-(IBAction)fovPositionRead:(id)sender;
-(IBAction)fluorescentImageDisplayMode:(id)sender;
-(IBAction)selectDisplayRed:(id)sender;
-(IBAction)selectDisplayGreen:(id)sender;
-(IBAction)selectDisplayBlue:(id)sender;
-(IBAction)orientationXFWYFWNSW:(id)sender;
-(IBAction)orientationXFWYRVNSW:(id)sender;
-(IBAction)orientationXRVYFWNSW:(id)sender;
-(IBAction)orientationXRVYRVNSW:(id)sender;
-(IBAction)orientationXFWYFWSW:(id)sender;
-(IBAction)orientationXFWYRVSW:(id)sender;
-(IBAction)orientationXRVYFWSW:(id)sender;
-(IBAction)orientationXRVYRVSW:(id)sender;

@end
