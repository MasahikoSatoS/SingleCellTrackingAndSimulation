//
//  IFReloadOperation.h
//  Contrast_Set
//
//  Created by Masahiko Sato on 11/17/16.
//  Copyright Masahiko Sato 2016 All rights reserved.
//
//

#ifndef IFRELOADOPERATION_H
#define IFRELOADOPERATION_H
#import "Controller.h" 
#endif

@interface IFReloadOperation : NSObject <NSTableViewDataSource>{
    int tableCallReloadCount;
    int rowIndexHoldReload;
    int tableCurrentRowHoldReload;
    
    IBOutlet NSTableView *timeViewReload;
    NSTimer *reLoadOperationTimer;
    
    id subprocesses;
}

-(id)init;
-(void)dealloc;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

-(IBAction)setContrastData:(id)sender;

@end
