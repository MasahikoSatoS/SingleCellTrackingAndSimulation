//
//  BackgroundWindow.m
//  Contrast_Set
//
//  Created by Masahiko Sato on 4/7/16.
//
//

#import "BackgroundWindow.h"

NSString *notificationToBackgroundWindow = @"notificationToExecuteBackgroundWindow";

@implementation BackgroundWindow

- (id)initWithFrame:(NSRect)frame{
    self = [super initWithFrame:frame];
    
    if (self) {
        adjustImageBK = [[NSImage alloc] initWithContentsOfFile:@""];
        
        mouseDragFlag = 0;
        mouseDownFlag = 0;
        xStartHold = 0;
        yStartHold = 0;
        xClickHold = 0;
        yClickHold = 0;
        positionHold = 0;
        
        bkLineCenterX1 = 0;
        bkLineCenterY1 = 0;
        bkLineCenterX2 = 0;
        bkLineCenterY2 = 0;
        
        clickValue = -1;
        bkLine1 = -1;
        bkLine2 = -1;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToBackgroundWindow object:nil];
    }
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    if (backgroundOriginalLoadFlag == 0){
        if (overlayStatusHold == 0){
            int displayImageSize = 0;
            
            if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
            else displayImageSize = imageDimensionY;
            
            NSBitmapImageRep *bitmapReps;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                    *bitmapData++ = (unsigned char)(arrayImageContrastAdjust [(currentOriginalNo-1)*imageDimensionY+counter1][counter2]);
                }
            }
            
            adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
            [adjustImageBK addRepresentation:bitmapReps];
        }
        else{
            
            int **backBaseArrayTemp = new int *[imageDimensionY+1];
            
            for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                backBaseArrayTemp [counter1] = new int [imageDimensionX+1];
            }
            
            for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                    backBaseArrayTemp [counter2][counter3] = arrayImageContrastAdjust [(currentOriginalNo-1)*imageDimensionY+counter2][counter3];
                }
            }
            
            //-----Value adjust (first adjusted image)-----
            int difference = 0;
            
            for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                    difference = 100-backBaseArrayModify [counter2][counter3];
                    
                    if (backBaseArrayTemp [counter2][counter3]+difference >= 255) backBaseArrayTemp [counter2][counter3] = 255;
                    else if (backBaseArrayTemp [counter2][counter3]+difference < 0) backBaseArrayTemp [counter2][counter3] = 0;
                    else backBaseArrayTemp [counter2][counter3] = backBaseArrayTemp [counter2][counter3]+difference;
                }
            }
            
            int displayImageSize = 0;
            
            if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
            else displayImageSize = imageDimensionY;
            
            NSBitmapImageRep *bitmapReps;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                    *bitmapData++ = (unsigned char)backBaseArrayTemp [counter1][counter2];
                }
            }
            
            adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
            [adjustImageBK addRepresentation:bitmapReps];
            
            for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                delete [] backBaseArrayTemp [counter1];
            }
            
            delete [] backBaseArrayTemp;
        }
        
        if (imageFirstLoadFlagDisplayBK == 0){
            xPositionDisplayBK = 0;
            yPositionDisplayBK = 0;
            xPositionAdjustDisplayBK = 0;
            yPositionAdjustDisplayBK = 0;
            magnificationDisplayBK = 10;
            imageFirstLoadFlagDisplayBK = 1;
        }
        
        //-----Re-adjust window size and position-----
        int vertical = 500+78;
        int horizontal = 500;
        
        windowWidthDisplayBK = imageDimensionX/(double)horizontal;
        windowHeightDisplayBK = imageDimensionY/(double)(vertical-78);
        
        xPositionAdjustDisplayBK = (imageDimensionX-imageDimensionX/(double)(magnificationDisplayBK*0.1))/(double)2;
        yPositionAdjustDisplayBK = (imageDimensionY-imageDimensionY/(double)(magnificationDisplayBK*0.1))/(double)2;
        
        [self setNeedsDisplay:YES];
    }
    else if (backgroundOriginalLoadFlag == 1){
        if (backgroundPatternModifyArrayCount != 0){
            for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                    backBaseArray [counter2][counter3] = 0;
                    backBaseArrayModify [counter2][counter3] = 0;
                    backBaseArrayEdge [counter2][counter3] = 0;
                    backBaseMap [counter2][counter3] = -1;
                }
            }
            
            int xBlockNo = 1;
            int yBlockNo = 1;
            
            if (imageDimensionX > 0) xBlockNo = imageDimensionX/8;
            if (imageDimensionY > 0) yBlockNo = imageDimensionY/8;
            
            for (int counter2 = 0; counter2 < yBlockNo; counter2++){
                for (int counter4 = 0; counter4 < 8; counter4++){
                    for (int counter3 = 0; counter3 < xBlockNo; counter3++){
                        for (int counter5 = 0; counter5 < 8; counter5++){
                            backBaseArray [counter2*8+counter4][counter3*8+counter5] = backgroundPatternModifyArray [(backgroundDisplayPage-1)*(xBlockNo*yBlockNo)+counter2*yBlockNo+counter3];
                            backBaseArrayModify [counter2*8+counter4][counter3*8+counter5] = backgroundPatternModifyArray [(backgroundDisplayPage-1)*(xBlockNo*yBlockNo)+counter2*yBlockNo+counter3];
                            backBaseArrayEdge [counter2*8+counter4][counter3*8+counter5] = backgroundPatternModifyArray [(backgroundDisplayPage-1)*(xBlockNo*yBlockNo)+counter2*yBlockNo+counter3];
                            backBaseMap [counter2*8+counter4][counter3*8+counter5] = counter2*yBlockNo+counter3;
                        }
                    }
                }
            }
            
            if (overlayStatusHold == 0){
                int displayImageSize = 0;
                
                if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                else displayImageSize = imageDimensionY;
                
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                for (int counter2 = 0; counter2 < yBlockNo; counter2++){
                    for (int counter4 = 0; counter4 < 8; counter4++){
                        for (int counter3 = 0; counter3 < xBlockNo; counter3++){
                            for (int counter5 = 0; counter5 < 8; counter5++){
                                *bitmapData++ = (unsigned char)backgroundPatternModifyArray [(backgroundDisplayPage-1)*(xBlockNo*yBlockNo)+counter2*yBlockNo+counter3];
                            }
                        }
                    }
                }
                
                adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                [adjustImageBK addRepresentation:bitmapReps];
            }
            else{
                
                int **backBaseArrayTemp = new int *[imageDimensionY+1];
                
                for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                    backBaseArrayTemp [counter1] = new int [imageDimensionX+1];
                }
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        backBaseArrayTemp [counter2][counter3] = arrayImageContrastAdjust [(currentOriginalNo-1)*imageDimensionY+counter2][counter3];
                    }
                }
                
                int displayImageSize = 0;
                
                if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                else displayImageSize = imageDimensionY;
                
                //-----Value adjust (first adjusted image)-----
                int difference = 0;
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        difference = 100-backBaseArrayEdge [counter2][counter3];
                        
                        if (backBaseArrayTemp [counter2][counter3]+difference >= 255) backBaseArrayTemp [counter2][counter3] = 255;
                        else if (backBaseArrayTemp [counter2][counter3]+difference < 0) backBaseArrayTemp [counter2][counter3] = 0;
                        else backBaseArrayTemp [counter2][counter3] = backBaseArrayTemp [counter2][counter3]+difference;
                    }
                }
                
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                    for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                        *bitmapData++ = (unsigned char)backBaseArrayTemp [counter1][counter2];
                    }
                }
                
                adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                [adjustImageBK addRepresentation:bitmapReps];
                
                for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                    delete [] backBaseArrayTemp [counter1];
                }
                
                delete [] backBaseArrayTemp;
            }
            
            if (imageFirstLoadFlagDisplayBK == 0){
                xPositionDisplayBK = 0;
                yPositionDisplayBK = 0;
                xPositionAdjustDisplayBK = 0;
                yPositionAdjustDisplayBK = 0;
                magnificationDisplayBK = 10;
                imageFirstLoadFlagDisplayBK = 1;
            }
            
            //-----Re-adjust window size and position-----
            int vertical = 500+78;
            int horizontal = 500;
            
            windowWidthDisplayBK = imageDimensionX/(double)horizontal;
            windowHeightDisplayBK = imageDimensionY/(double)(vertical-78);
            
            xPositionAdjustDisplayBK = (imageDimensionX-imageDimensionX/(double)(magnificationDisplayBK*0.1))/(double)2;
            yPositionAdjustDisplayBK = (imageDimensionY-imageDimensionY/(double)(magnificationDisplayBK*0.1))/(double)2;
            
            [self setNeedsDisplay:YES];
        }
        else{
            
            int displayImageSize = 0;
            
            if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
            else displayImageSize = imageDimensionY;
            
            NSBitmapImageRep *bitmapReps;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                    *bitmapData++ = 0;
                }
            }
            
            adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
            [adjustImageBK addRepresentation:bitmapReps];
            
            if (imageFirstLoadFlagDisplayBK == 0){
                xPositionDisplayBK = 0;
                yPositionDisplayBK = 0;
                xPositionAdjustDisplayBK = 0;
                yPositionAdjustDisplayBK = 0;
                magnificationDisplayBK = 10;
                imageFirstLoadFlagDisplayBK = 1;
            }
            
            //-----Re-adjust window size and position-----
            int vertical = 500+78;
            int horizontal = 500;
            
            windowWidthDisplayBK = imageDimensionX/(double)horizontal;
            windowHeightDisplayBK = imageDimensionY/(double)(vertical-78);
            
            xPositionAdjustDisplayBK = (imageDimensionX-imageDimensionX/(double)(magnificationDisplayBK*0.1))/(double)2;
            yPositionAdjustDisplayBK = (imageDimensionY-imageDimensionY/(double)(magnificationDisplayBK*0.1))/(double)2;
            
            [self setNeedsDisplay:YES];
        }
    }
    else if (backgroundOriginalLoadFlag == 2){
        if (backgroundPatternModifyArrayCount != 0){
            if (overlayStatusHold == 0 && overlayStatusSend == 1){
                int displayImageSize = 0;
                
                if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                else displayImageSize = imageDimensionY;
                
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                    for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                        *bitmapData++ = (unsigned char)backBaseArrayEdge [counter1][counter2];
                    }
                }
                
                adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                [adjustImageBK addRepresentation:bitmapReps];
            }
            else if (overlayStatusHold == 1 && overlayStatusSend == 1){
                int displayImageSize = 0;
                
                if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                else displayImageSize = imageDimensionY;
                
                
                int **backBaseArrayTemp = new int *[imageDimensionY+1];
                
                for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                    backBaseArrayTemp [counter1] = new int [imageDimensionX+1];
                }
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        backBaseArrayTemp [counter2][counter3] = arrayImageContrastAdjust [(currentOriginalNo-1)*imageDimensionY+counter2][counter3];
                    }
                }
                
                //-----Value adjust (first adjusted image)-----
                int difference = 0;
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX+1; counter3++){
                        difference = 100-backBaseArrayEdge [counter2][counter3];
                        
                        if (backBaseArrayTemp [counter2][counter3]+difference >= 255) backBaseArrayTemp [counter2][counter3] = 255;
                        else if (backBaseArrayTemp [counter2][counter3]+difference < 0) backBaseArrayTemp [counter2][counter3] = 0;
                        else backBaseArrayTemp [counter2][counter3] = backBaseArrayTemp [counter2][counter3]+difference;
                    }
                }
                
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                    for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                        *bitmapData++ = (unsigned char)backBaseArrayTemp [counter1][counter2];
                    }
                }
                
                adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                [adjustImageBK addRepresentation:bitmapReps];
                
                for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                    delete [] backBaseArrayTemp [counter1];
                }
                
                delete [] backBaseArrayTemp;
            }
            
            if (imageFirstLoadFlagDisplayBK == 0){
                xPositionDisplayBK = 0;
                yPositionDisplayBK = 0;
                xPositionAdjustDisplayBK = 0;
                yPositionAdjustDisplayBK = 0;
                magnificationDisplayBK = 10;
                imageFirstLoadFlagDisplayBK = 1;
            }
            
            //-----Re-adjust window size and position-----
            int vertical = 500+78;
            int horizontal = 500;
            
            windowWidthDisplayBK = imageDimensionX/(double)horizontal;
            windowHeightDisplayBK = imageDimensionY/(double)(vertical-78);
            
            xPositionAdjustDisplayBK = (imageDimensionX-imageDimensionX/(double)(magnificationDisplayBK*0.1))/(double)2;
            yPositionAdjustDisplayBK = (imageDimensionY-imageDimensionY/(double)(magnificationDisplayBK*0.1))/(double)2;
            
            [self setNeedsDisplay:YES];
        }
        else{
            
            int displayImageSize = 0;
            
            if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
            else displayImageSize = imageDimensionY;
            
            
            NSBitmapImageRep *bitmapReps;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                    *bitmapData++ = 0;
                }
            }
            
            adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
            [adjustImageBK addRepresentation:bitmapReps];
            
            if (imageFirstLoadFlagDisplayBK == 0){
                xPositionDisplayBK = 0;
                yPositionDisplayBK = 0;
                xPositionAdjustDisplayBK = 0;
                yPositionAdjustDisplayBK = 0;
                magnificationDisplayBK = 10;
                imageFirstLoadFlagDisplayBK = 1;
            }
            
            //-----Re-adjust window size and position-----
            int vertical = 500+78;
            int horizontal = 500;
            
            windowWidthDisplayBK = imageDimensionX/(double)horizontal;
            windowHeightDisplayBK = imageDimensionY/(double)(vertical-78);
            
            xPositionAdjustDisplayBK = (imageDimensionX-imageDimensionX/(double)(magnificationDisplayBK*0.1))/(double)2;
            yPositionAdjustDisplayBK = (imageDimensionY-imageDimensionY/(double)(magnificationDisplayBK*0.1))/(double)2;
            
            [self setNeedsDisplay:YES];
        }
    }
    else if (backgroundOriginalLoadFlag == 3){
        if (backgroundPatternModifyArrayCount != 0){
            int newValue = 0;
            
            if (baseContrastSetFlag1 == 1 && areaSetFlag1 == 0){
                baseContrastSetFlag1 = 0;
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        if (backBaseArray [counter2][counter3] > contrastCutOff1){
                            newValue = backBaseArray [counter2][counter3]+(int)((backBaseArray [counter2][counter3]-contrastCutOff1)*baseContrastSet1);
                            
                            if (newValue >= 255){
                                backBaseArrayModify [counter2][counter3] = 255;
                                backBaseArrayEdge [counter2][counter3] = 255;
                            }
                            else if (newValue < 0){
                                backBaseArrayModify [counter2][counter3] = 0;
                                backBaseArrayEdge [counter2][counter3] = 0;
                            }
                            else{
                                
                                backBaseArrayModify [counter2][counter3] = newValue;
                                backBaseArrayEdge [counter2][counter3] = newValue;
                            }
                        }
                    }
                }
            }
            else if (baseContrastSetFlag1 == 1 && areaSetFlag1 == 1){
                baseContrastSetFlag1 = 0;
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        if (backAreaMapUpArray [counter2][counter3] == 1 && backBaseArray [counter2][counter3] <= contrastAreaOffHold1){
                            newValue = backBaseArray [counter2][counter3]+(int)((backBaseArray [counter2][counter3]-contrastAreaOffHold1)*baseContrastSet1);
                            
                            if (newValue >= 255){
                                backBaseArrayModify [counter2][counter3] = 255;
                                backBaseArrayEdge [counter2][counter3] = 255;
                            }
                            else if (newValue < 0){
                                backBaseArrayModify [counter2][counter3] = 0;
                                backBaseArrayEdge [counter2][counter3] = 0;
                            }
                            else{
                                
                                backBaseArrayModify [counter2][counter3] = newValue;
                                backBaseArrayEdge [counter2][counter3] = newValue;
                            }
                        }
                    }
                }
            }
            
            if (baseContrastSetFlag3 == 1 && areaSetFlag3 == 0){
                baseContrastSetFlag3 = 0;
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        if (backBaseArray [counter2][counter3] < contrastCutOff3){
                            newValue = backBaseArray [counter2][counter3]-(int)((contrastCutOff3-backBaseArray [counter2][counter3])*baseContrastSet3);
                            
                            if (newValue >= 255){
                                backBaseArrayModify [counter2][counter3] = 255;
                                backBaseArrayEdge [counter2][counter3] = 255;
                            }
                            else if (newValue < 0){
                                backBaseArrayModify [counter2][counter3] = 0;
                                backBaseArrayEdge [counter2][counter3] = 0;
                            }
                            else{
                                
                                backBaseArrayModify [counter2][counter3] = newValue;
                                backBaseArrayEdge [counter2][counter3] = newValue;
                            }
                        }
                    }
                }
            }
            else if (baseContrastSetFlag3 == 1 && areaSetFlag3 == 1){
                baseContrastSetFlag3 = 0;
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        if (backAreaMapDownArray [counter2][counter3] == 1 && backBaseArray [counter2][counter3] >= contrastAreaOffHold3){
                            newValue = backBaseArray [counter2][counter3]-(int)((contrastAreaOffHold3-backBaseArray [counter2][counter3])*baseContrastSet3);
                            
                            if (newValue >= 255){
                                backBaseArrayModify [counter2][counter3] = 255;
                                backBaseArrayEdge [counter2][counter3] = 255;
                            }
                            else if (newValue < 0){
                                backBaseArrayModify [counter2][counter3] = 0;
                                backBaseArrayEdge [counter2][counter3] = 0;
                            }
                            else{
                                
                                backBaseArrayModify [counter2][counter3] = newValue;
                                backBaseArrayEdge [counter2][counter3] = newValue;
                            }
                        }
                    }
                }
            }
            
            if (baseContrastSetFlagAS == 1){
                baseContrastSetFlagAS = 0;
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        newValue = backBaseArray [counter2][counter3]+(int)(baseContrastSetAS*contrastCutOffAS);
                        
                        if (newValue >= 255){
                            backBaseArrayModify [counter2][counter3] = 255;
                            backBaseArrayEdge [counter2][counter3] = 255;
                        }
                        else if (newValue < 0){
                            backBaseArrayModify [counter2][counter3] = 0;
                            backBaseArrayEdge [counter2][counter3] = 0;
                        }
                        else{
                            
                            backBaseArrayModify [counter2][counter3] = newValue;
                            backBaseArrayEdge [counter2][counter3] = newValue;
                        }
                    }
                }
            }
            
            if (baseContrastSetFlagVertical == 1){
                baseContrastSetFlagVertical = 0;
                
                int **backBaseArrayTemp = new int *[imageDimensionY+1];
                
                for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                    backBaseArrayTemp [counter1] = new int [imageDimensionX+1];
                }
                
                int verticalCount = imageDimensionY-8;
                int verticalBlockCount = 0;
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        backBaseArrayTemp [verticalCount][counter3] = backBaseArrayModify [counter2][counter3];
                    }
                    
                    verticalBlockCount++;
                    verticalCount++;
                    
                    if (verticalBlockCount == 8){
                        verticalBlockCount = 0;
                        verticalCount = verticalCount-16;
                    }
                }
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        backBaseArrayModify [counter2][counter3] = backBaseArrayTemp [counter2][counter3];
                        backBaseArrayEdge [counter2][counter3] = backBaseArrayTemp [counter2][counter3];
                    }
                }
                
                for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                    delete [] backBaseArrayTemp [counter1];
                }
                
                delete [] backBaseArrayTemp;
            }
            
            if (baseContrastSetFlagHorizontal == 1){
                baseContrastSetFlagHorizontal = 0;
                
                int **backBaseArrayTemp = new int *[imageDimensionY+1];
                
                for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                    backBaseArrayTemp [counter1] = new int [imageDimensionX+1];
                }
                
                int horizontalCount = imageDimensionX-8;
                int horizontalBlockCount = 0;
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        backBaseArrayTemp [counter3][horizontalCount] = backBaseArrayModify [counter3][counter2];
                    }
                    
                    horizontalBlockCount++;
                    horizontalCount++;
                    
                    if (horizontalBlockCount == 8){
                        horizontalBlockCount = 0;
                        horizontalCount = horizontalCount-16;
                    }
                }
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        backBaseArrayModify [counter2][counter3] = backBaseArrayTemp [counter2][counter3];
                        backBaseArrayEdge [counter2][counter3] = backBaseArrayTemp [counter2][counter3];
                    }
                }
                
                for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                    delete [] backBaseArrayTemp [counter1];
                }
                
                delete [] backBaseArrayTemp;
            }
            
            if (overlayStatusHold == 0){
                int displayImageSize = 0;
                
                if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                else displayImageSize = imageDimensionY;
                
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        *bitmapData++ = (unsigned char)backBaseArrayEdge [counter2][counter3];
                    }
                }
                
                adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                [adjustImageBK addRepresentation:bitmapReps];
            }
            else{
                
                int **backBaseArrayTemp = new int *[imageDimensionY+1];
                
                for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                    backBaseArrayTemp [counter1] = new int [imageDimensionX+1];
                }
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        backBaseArrayTemp [counter2][counter3] = arrayImageContrastAdjust [(currentOriginalNo-1)*imageDimensionY+counter2][counter3];
                    }
                }
                
                //-----Value adjust (first adjusted image)-----
                int difference = 0;
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        difference = 100-backBaseArrayEdge [counter2][counter3];
                        
                        if (backBaseArrayTemp [counter2][counter3]+difference >= 255) backBaseArrayTemp [counter2][counter3] = 255;
                        else if (backBaseArrayTemp [counter2][counter3]+difference < 0) backBaseArrayTemp [counter2][counter3] = 0;
                        else backBaseArrayTemp [counter2][counter3] = backBaseArrayTemp [counter2][counter3]+difference;
                    }
                }
                
                int displayImageSize = 0;
                
                if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                else displayImageSize = imageDimensionY;
                
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                    for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                        *bitmapData++ = (unsigned char)backBaseArrayTemp [counter1][counter2];
                    }
                }
                
                adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                [adjustImageBK addRepresentation:bitmapReps];
                
                for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                    delete [] backBaseArrayTemp [counter1];
                }
                
                delete [] backBaseArrayTemp;
            }
            
            if (imageFirstLoadFlagDisplayBK == 0){
                xPositionDisplayBK = 0;
                yPositionDisplayBK = 0;
                xPositionAdjustDisplayBK = 0;
                yPositionAdjustDisplayBK = 0;
                magnificationDisplayBK = 10;
                imageFirstLoadFlagDisplayBK = 1;
            }
            
            //-----Re-adjust window size and position-----
            int vertical = 500+78;
            int horizontal = 500;
            
            windowWidthDisplayBK = imageDimensionX/(double)horizontal;
            windowHeightDisplayBK = imageDimensionY/(double)(vertical-78);
            
            xPositionAdjustDisplayBK = (imageDimensionX-imageDimensionX/(double)(magnificationDisplayBK*0.1))/(double)2;
            yPositionAdjustDisplayBK = (imageDimensionY-imageDimensionY/(double)(magnificationDisplayBK*0.1))/(double)2;
            
            [self setNeedsDisplay:YES];
        }
        else{
            
            int displayImageSize = 0;
            
            if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
            else displayImageSize = imageDimensionY;
            
            NSBitmapImageRep *bitmapReps;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                    *bitmapData++ = 0;
                }
            }
            
            adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
            [adjustImageBK addRepresentation:bitmapReps];
            
            if (imageFirstLoadFlagDisplayBK == 0){
                xPositionDisplayBK = 0;
                yPositionDisplayBK = 0;
                xPositionAdjustDisplayBK = 0;
                yPositionAdjustDisplayBK = 0;
                magnificationDisplayBK = 10;
                imageFirstLoadFlagDisplayBK = 1;
            }
            
            //-----Re-adjust window size and position-----
            int vertical = 500+78;
            int horizontal = 500;
            
            windowWidthDisplayBK = imageDimensionX/(double)horizontal;
            windowHeightDisplayBK = imageDimensionY/(double)(vertical-78);
            
            xPositionAdjustDisplayBK = (imageDimensionX-imageDimensionX/(double)(magnificationDisplayBK*0.1))/(double)2;
            yPositionAdjustDisplayBK = (imageDimensionY-imageDimensionY/(double)(magnificationDisplayBK*0.1))/(double)2;
            
            [self setNeedsDisplay:YES];
        }
    }
    else if (backgroundOriginalLoadFlag == 4){
        if (backgroundPatternModifyArrayCount != 0){
            if (edgeSetFlag == 1){
                edgeSetFlag = 0;
                int newValue = 0;
                int newValue2 = 0;
                double upA = 0;
                double upB = 0;
                double downA = 0;
                double downB = 0;
                double rightA = 0;
                double rightB = 0;
                double leftA = 0;
                double leftB = 0;
                
                if (expansionUPPosition1 == expansionUPPosition2){
                    upA = 0;
                    upB = expansionUPPosition1;
                }
                else if (expansionUPPosition1 != expansionUPPosition2){
                    upA = (expansionUPPosition2-expansionUPPosition1)/(double)imageDimensionY;
                    upB = expansionUPPosition1;
                }
                
                if (expansionDownPosition1 == expansionDownPosition2){
                    downA = 0;
                    downB = expansionDownPosition1;
                }
                else if (expansionDownPosition1 != expansionDownPosition2){
                    downA = (expansionDownPosition2-expansionDownPosition1)/(double)imageDimensionY;
                    downB = expansionDownPosition1;
                }
                
                if (expansionRightPosition1 == expansionRightPosition2){
                    rightA = 0;
                    rightB = 0;
                }
                else if (expansionRightPosition1 != expansionRightPosition2){
                    rightA = imageDimensionX/(double)(expansionRightPosition2-expansionRightPosition1);
                    rightB = 0-expansionRightPosition1*rightA;
                }
                
                if (expansionLeftPosition1 == expansionLeftPosition2){
                    leftA = 0;
                    leftB = 0;
                }
                else if (expansionLeftPosition1 != expansionLeftPosition2){
                    leftA = imageDimensionX/(double)(expansionLeftPosition2-expansionLeftPosition1);
                    leftB = 0-expansionLeftPosition1*leftA;
                }
                
                int upY = 0;
                int downY = 0;
                int rightX = 0;
                int leftX = 0;
                int upFind = 0;
                int downFind = 0;
                int rightFind = 0;
                int leftFind = 0;
                
                double sourceValue = 0;
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        if (expansionUPPosition1 == expansionUPPosition2){
                            upY = (int)expansionUPPosition1;
                        }
                        else if (expansionUPPosition1 != expansionUPPosition2){
                            upY = (int)(upA*counter3+upB);
                        }
                        
                        if (expansionDownPosition1 == expansionDownPosition2){
                            downY = (int)expansionDownPosition1;
                        }
                        else if (expansionDownPosition1 != expansionDownPosition2){
                            downY = (int)(downA*counter3+downB);
                        }
                        
                        if (expansionRightPosition1 == expansionRightPosition2){
                            rightX = (int)expansionRightPosition1;
                        }
                        else if (expansionRightPosition1 != expansionRightPosition2){
                            rightX = (int)((counter2-rightB)/(double)rightA);
                        }
                        
                        if (expansionLeftPosition1 == expansionLeftPosition2){
                            leftX = (int)expansionLeftPosition1;
                        }
                        else if (expansionLeftPosition1 != expansionLeftPosition2){
                            leftX = (int)((counter2-leftB)/(double)leftA);
                        }
                        
                        upFind = 0;
                        downFind = 0;
                        rightFind = 0;
                        leftFind = 0;
                        newValue = 0;
                        
                        if (counter2 <= upY) upFind = 1;
                        if (counter2 >= downY) downFind = 1;
                        if (counter3 <= leftX) leftFind = 1;
                        if (counter3 >= rightX) rightFind = 1;
                        
                        sourceValue = backBaseArrayModify [counter2][counter3];
                        
                        if (sourceValue == 0) sourceValue = 10;
                        
                        if (upFind == 1 && downFind == 0 && leftFind == 0 && rightFind == 0){
                            if (expansionUPCurrent > 1){
                                newValue = (int)(sourceValue*(expansionUPCurrent-((expansionUPCurrent-1)/(double)(upY+1))*counter2));
                            }
                            else newValue = (int)(sourceValue*(expansionUPCurrent+((1-expansionUPCurrent)/(double)(upY+1))*counter2));
                        }
                        else if (upFind == 0 && downFind == 1 && leftFind == 0 && rightFind == 0){
                            if (expansionDownCurrent > 1){
                                newValue = (int)(sourceValue*(expansionDownCurrent-((expansionDownCurrent-1)/(double)(imageDimensionY-downY))*(imageDimensionY-counter2)));
                            }
                            else newValue = (int)(sourceValue*(expansionDownCurrent+((1-expansionDownCurrent)/(double)(imageDimensionY-downY))*(imageDimensionY-counter2)));
                        }
                        else if (upFind == 0 && downFind == 0 && leftFind == 1 && rightFind == 0){
                            if (expansionLeftCurrent > 1){
                                newValue = (int)(sourceValue*(expansionLeftCurrent-((expansionLeftCurrent-1)/(double)(leftX+1))*counter3));
                            }
                            else newValue = (int)(sourceValue*(expansionLeftCurrent+((1-expansionLeftCurrent)/(double)(leftX+1))*counter3));
                        }
                        else if (upFind == 0 && downFind == 0 && leftFind == 0 && rightFind == 1){
                            if (expansionRightCurrent > 1){
                                newValue = (int)(sourceValue*(expansionRightCurrent-((expansionRightCurrent-1)/(double)(imageDimensionX-rightX))*(imageDimensionX-counter3)));
                            }
                            else newValue = (int)(sourceValue*(expansionRightCurrent+((1-expansionRightCurrent)/(double)(imageDimensionX-rightX))*(imageDimensionX-counter3)));
                        }
                        else if (upFind == 1 && downFind == 0 && leftFind == 1 && rightFind == 0){
                            if (expansionUPCurrent > 1){
                                newValue = (int)(sourceValue*(expansionUPCurrent-((expansionUPCurrent-1)/(double)(upY+1))*counter2));
                            }
                            else  newValue = (int)(sourceValue*(expansionUPCurrent+((1-expansionUPCurrent)/(double)(upY+1))*counter2));
                            
                            if (expansionLeftCurrent > 1){
                                newValue2 = (int)(sourceValue*(expansionLeftCurrent-((expansionLeftCurrent-1)/(double)(leftX+1))*counter3));
                            }
                            else newValue2 = (int)(sourceValue*(expansionLeftCurrent+((1-expansionLeftCurrent)/(double)(leftX+1))*counter3));
                            
                            newValue = (newValue+newValue2)/2;
                        }
                        else if (upFind == 1 && downFind == 0 && leftFind == 0 && rightFind == 1){
                            if (expansionUPCurrent > 1){
                                newValue = (int)(sourceValue*(expansionUPCurrent-((expansionUPCurrent-1)/(double)(upY+1))*counter2));
                            }
                            else newValue = (int)(sourceValue*(expansionUPCurrent+((1-expansionUPCurrent)/(double)(upY+1))*counter2));
                            
                            if (expansionRightCurrent > 1){
                                newValue2 = (int)(sourceValue*(expansionRightCurrent-((expansionRightCurrent-1)/(double)(imageDimensionX-rightX))*(imageDimensionX-counter3)));
                            }
                            else newValue2 = (int)(sourceValue*(expansionRightCurrent+((1-expansionRightCurrent)/(double)(imageDimensionX-rightX))*(imageDimensionX-counter3)));
                            
                            newValue = (newValue+newValue2)/2;
                        }
                        else if (upFind == 0 && downFind == 1 && leftFind == 1 && rightFind == 0){
                            if (expansionDownCurrent > 1){
                                newValue = (int)(sourceValue*(expansionDownCurrent-((expansionDownCurrent-1)/(double)(imageDimensionY-downY))*(imageDimensionY-counter2)));
                            }
                            else newValue = (int)(sourceValue*(expansionDownCurrent+((1-expansionDownCurrent)/(double)(imageDimensionY-downY))*(imageDimensionY-counter2)));
                            
                            if (expansionLeftCurrent > 1){
                                newValue2 = (int)(sourceValue*(expansionLeftCurrent-((expansionLeftCurrent-1)/(double)(leftX+1))*counter3));
                            }
                            else newValue2 = (int)(sourceValue*(expansionLeftCurrent+((1-expansionLeftCurrent)/(double)(leftX+1))*counter3));
                            
                            newValue = (newValue+newValue2)/2;
                        }
                        else if (upFind == 0 && downFind == 1 && leftFind == 0 && rightFind == 1){
                            if (expansionDownCurrent > 1){
                                newValue = (int)(sourceValue*(expansionDownCurrent-((expansionDownCurrent-1)/(double)(imageDimensionY-downY))*(imageDimensionY-counter2)));
                            }
                            else newValue = (int)(sourceValue*(expansionDownCurrent+((1-expansionDownCurrent)/(double)(imageDimensionY-downY))*(imageDimensionY-counter2)));
                            
                            if (expansionRightCurrent > 1){
                                newValue2 = (int)(sourceValue*(expansionRightCurrent-((expansionRightCurrent-1)/(double)(imageDimensionX-rightX))*(imageDimensionX-counter3)));
                            }
                            else newValue2 = (int)(sourceValue*(expansionRightCurrent+((1-expansionRightCurrent)/(double)(imageDimensionX-rightX))*(imageDimensionX-counter3)));
                            
                            newValue = (newValue+newValue2)/2;
                        }
                        
                        if (newValue != 0){
                            if (newValue >= 255) backBaseArrayEdge [counter2][counter3] = 255;
                            else if (newValue < 0) backBaseArrayEdge [counter2][counter3] = 0;
                            else backBaseArrayEdge [counter2][counter3] = newValue;
                        }
                        else backBaseArrayEdge [counter2][counter3] = backBaseArrayModify [counter2][counter3];
                    }
                }
            }
            
            if (overlayStatusHold == 0){
                int displayImageSize = 0;
                
                if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                else displayImageSize = imageDimensionY;
                
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        *bitmapData++ = (unsigned char)backBaseArrayEdge [counter2][counter3];
                    }
                }
                
                adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                [adjustImageBK addRepresentation:bitmapReps];
            }
            else{
                
                int **backBaseArrayTemp = new int *[imageDimensionY+1];
                
                for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                    backBaseArrayTemp [counter1] = new int [imageDimensionX+1];
                }
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        backBaseArrayTemp [counter2][counter3] = arrayImageContrastAdjust [(currentOriginalNo-1)*imageDimensionY+counter2][counter3];
                    }
                }
                
                //-----Value adjust (first adjusted image)-----
                int difference = 0;
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        difference = 100-backBaseArrayEdge [counter2][counter3];
                        
                        if (backBaseArrayTemp [counter2][counter3]+difference >= 255) backBaseArrayTemp [counter2][counter3] = 255;
                        else if (backBaseArrayTemp [counter2][counter3]+difference < 0) backBaseArrayTemp [counter2][counter3] = 0;
                        else backBaseArrayTemp [counter2][counter3] = backBaseArrayTemp [counter2][counter3]+difference;
                    }
                }
                
                int displayImageSize = 0;
                
                if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                else displayImageSize = imageDimensionY;
                
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                    for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                        *bitmapData++ = (unsigned char)backBaseArrayTemp [counter1][counter2];
                    }
                }
                
                adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                [adjustImageBK addRepresentation:bitmapReps];
                
                for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                    delete [] backBaseArrayTemp [counter1];
                }
                
                delete [] backBaseArrayTemp;
            }
            
            if (imageFirstLoadFlagDisplayBK == 0){
                xPositionDisplayBK = 0;
                yPositionDisplayBK = 0;
                xPositionAdjustDisplayBK = 0;
                yPositionAdjustDisplayBK = 0;
                magnificationDisplayBK = 10;
                imageFirstLoadFlagDisplayBK = 1;
            }
            
            //-----Re-adjust window size and position-----
            int vertical = 500+78;
            int horizontal = 500;
            
            windowWidthDisplayBK = imageDimensionX/(double)horizontal;
            windowHeightDisplayBK = imageDimensionY/(double)(vertical-78);
            
            xPositionAdjustDisplayBK = (imageDimensionX-imageDimensionX/(double)(magnificationDisplayBK*0.1))/(double)2;
            yPositionAdjustDisplayBK = (imageDimensionY-imageDimensionY/(double)(magnificationDisplayBK*0.1))/(double)2;
            
            [self setNeedsDisplay:YES];
        }
        else{
            
            int displayImageSize = 0;
            
            if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
            else displayImageSize = imageDimensionY;
            
            NSBitmapImageRep *bitmapReps;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                    *bitmapData++ = 0;
                }
            }
            
            adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
            [adjustImageBK addRepresentation:bitmapReps];
            
            if (imageFirstLoadFlagDisplayBK == 0){
                xPositionDisplayBK = 0;
                yPositionDisplayBK = 0;
                xPositionAdjustDisplayBK = 0;
                yPositionAdjustDisplayBK = 0;
                magnificationDisplayBK = 10;
                imageFirstLoadFlagDisplayBK = 1;
            }
            
            //-----Re-adjust window size and position-----
            int vertical = 500+78;
            int horizontal = 500;
            
            windowWidthDisplayBK = imageDimensionX/(double)horizontal;
            windowHeightDisplayBK = imageDimensionY/(double)(vertical-78);
            
            xPositionAdjustDisplayBK = (imageDimensionX-imageDimensionX/(double)(magnificationDisplayBK*0.1))/(double)2;
            yPositionAdjustDisplayBK = (imageDimensionY-imageDimensionY/(double)(magnificationDisplayBK*0.1))/(double)2;
            
            [self setNeedsDisplay:YES];
        }
    }
}

-(void)mouseDown:(NSEvent *)event{
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDownDisplayBK = clickPoint.x;
        yPointDownDisplayBK = clickPoint.y;
        
        if (backgroundOriginalLoadFlag == 2){
            if (lineAreaStatusHold == 0){
                int xPositionTemp = (int)(xPointDownDisplayBK*(double)windowWidthDisplayBK/(double)magnificationDisplayBK/(double)0.1+xPositionAdjustDisplayBK+xPositionDisplayBK);
                int yPositionTemp = imageDimensionY-(int)((yPointDownDisplayBK*(double)windowHeightDisplayBK/(double)magnificationDisplayBK/(double)0.1+yPositionAdjustDisplayBK+yPositionDisplayBK+windowHeightDisplayBK));
                
                if (yPositionTemp >= 0 && yPositionTemp < imageDimensionY && xPositionTemp >= 0 && xPositionTemp < imageDimensionX){
                    clickNumber = backBaseMap [yPositionTemp][xPositionTemp];
                    clickValue = backBaseArray [yPositionTemp][xPositionTemp];
                    
                    int xPositionTemp2 = 100000;
                    int yPositionTemp2 = 100000;
                    int startX = xPositionTemp-10;
                    int endX = xPositionTemp+10;
                    int startY = yPositionTemp-10;
                    int endY = yPositionTemp+10;
                    
                    if (startX < 0) startX = 0;
                    if (endX >= imageDimensionX) endX = imageDimensionX;
                    if (startY < 0) startY = 0;
                    if (endY >= imageDimensionY) endY = imageDimensionY;
                    
                    for (int counter2 = startY; counter2 < endY; counter2++){
                        for (int counter3 = startX; counter3 < endX; counter3++){
                            if (backBaseMap [counter2][counter3] == clickNumber){
                                if (xPositionTemp2 > counter3) xPositionTemp2 = counter3;
                                if (yPositionTemp2 > counter2) yPositionTemp2 = counter2;
                            }
                        }
                    }
                    
                    if (backArea == 3){
                        xPositionTemp2 = xPositionTemp2-8;
                        yPositionTemp2 = yPositionTemp2-8;
                    }
                    
                    if (backArea == 5){
                        xPositionTemp2 = xPositionTemp2-16;
                        yPositionTemp2 = yPositionTemp2-16;
                    }
                    
                    if (backArea == 7){
                        xPositionTemp2 = xPositionTemp2-24;
                        yPositionTemp2 = yPositionTemp2-24;
                    }
                    
                    if (backArea == 9){
                        xPositionTemp2 = xPositionTemp2-32;
                        yPositionTemp2 = yPositionTemp2-32;
                    }
                    
                    xClickPosition = xPositionTemp2;
                    yClickPosition = yPositionTemp2;
                }
            }
            else if (lineAreaStatusHold == 1){
                int xPositionTemp = (int)(xPointDownDisplayBK*(double)windowWidthDisplayBK/(double)magnificationDisplayBK/(double)0.1+xPositionAdjustDisplayBK+xPositionDisplayBK);
                int yPositionTemp = imageDimensionY-(int)((yPointDownDisplayBK*(double)windowHeightDisplayBK/(double)magnificationDisplayBK/(double)0.1+yPositionAdjustDisplayBK+yPositionDisplayBK+windowHeightDisplayBK));
                
                if (yPositionTemp >= 0 && yPositionTemp < imageDimensionY && xPositionTemp >= 0 && xPositionTemp < imageDimensionX){
                    clickNumber = backBaseMap [yPositionTemp][xPositionTemp];
                    clickValue = backBaseArray [yPositionTemp][xPositionTemp];
                    
                    int xPositionTemp2 = 100000;
                    int yPositionTemp2 = 100000;
                    int startX = xPositionTemp-10;
                    int endX = xPositionTemp+10;
                    int startY = yPositionTemp-10;
                    int endY = yPositionTemp+10;
                    
                    if (startX < 0) startX = 0;
                    if (endX >= imageDimensionX) endX = imageDimensionX;
                    if (startY < 0) startY = 0;
                    if (endY >= imageDimensionY) endY = imageDimensionY;
                    
                    for (int counter2 = startY; counter2 < endY; counter2++){
                        for (int counter3 = startX; counter3 < endX; counter3++){
                            if (backBaseMap [counter2][counter3] == clickNumber){
                                if (xPositionTemp2 > counter3) xPositionTemp2 = counter3;
                                if (yPositionTemp2 > counter2) yPositionTemp2 = counter2;
                            }
                        }
                    }
                    
                    if (bkLine1 == -1){
                        bkLineCenterX1 = xPositionTemp2;
                        bkLineCenterY1 = yPositionTemp2;
                    }
                    else if (bkLine1 != -1 && bkLine2 == -1){
                        bkLineCenterX2 = xPositionTemp2;
                        bkLineCenterY2 = yPositionTemp2;
                    }
                    else if (bkLine1 != -1 && bkLine2 != -1){
                        bkLineCenterX1 = xPositionTemp2;
                        bkLineCenterY1 = yPositionTemp2;
                    }
                    
                    if (backArea == 3){
                        xPositionTemp2 = xPositionTemp2-8;
                        yPositionTemp2 = yPositionTemp2-8;
                    }
                    
                    if (backArea == 5){
                        xPositionTemp2 = xPositionTemp2-16;
                        yPositionTemp2 = yPositionTemp2-16;
                    }
                    
                    if (backArea == 7){
                        xPositionTemp2 = xPositionTemp2-24;
                        yPositionTemp2 = yPositionTemp2-24;
                    }
                    
                    if (backArea == 9){
                        xPositionTemp2 = xPositionTemp2-32;
                        yPositionTemp2 = yPositionTemp2-32;
                    }
                    
                    if (bkLine1 == -1){
                        bkLineX1 = xPositionTemp2;
                        bkLineY1 = yPositionTemp2;
                        bkLine1 = backBaseArray [yPositionTemp][xPositionTemp];
                    }
                    else if (bkLine1 != -1 && bkLine2 == -1){
                        bkLineX2 = xPositionTemp2;
                        bkLineY2 = yPositionTemp2;
                        bkLine2 = backBaseArray [yPositionTemp][xPositionTemp];
                    }
                    else if (bkLine1 != -1 && bkLine2 != -1){
                        bkLineX1 = xPositionTemp2;
                        bkLineY1 = yPositionTemp2;
                        bkLine1 = backBaseArray [yPositionTemp][xPositionTemp];
                        bkLine2 = -1;
                    }
                }
            }
            
            [self setNeedsDisplay:YES];
        }
        else if (backgroundOriginalLoadFlag == 3){
            int xPositionTemp = (int)(xPointDownDisplayBK*(double)windowWidthDisplayBK/(double)magnificationDisplayBK/(double)0.1+xPositionAdjustDisplayBK+xPositionDisplayBK);
            int yPositionTemp = imageDimensionY-(int)((yPointDownDisplayBK*(double)windowHeightDisplayBK/(double)magnificationDisplayBK/(double)0.1+yPositionAdjustDisplayBK+yPositionDisplayBK+windowHeightDisplayBK));
            
            if (yPositionTemp >= 0 && yPositionTemp < imageDimensionY && xPositionTemp >= 0 && xPositionTemp < imageDimensionX){
                clickAreaSetValue  = backBaseArray [yPositionTemp][xPositionTemp];
                
                xClickPosition = xPositionTemp;
                yClickPosition = yPositionTemp;
            }
        }
    }
}

-(void)mouseUp:(NSEvent *)event{
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        xPositionDisplayBK = xPositionDisplayBK+xPositionMoveDisplayBK;
        yPositionDisplayBK = yPositionDisplayBK+yPositionMoveDisplayBK;
        
        xPositionMoveDisplayBK = 0;
        yPositionMoveDisplayBK = 0;
        mouseDragFlag = 0;
        mouseDownFlag = 0;
        
        [self setNeedsDisplay:YES];
    }
}

-(void)mouseDragged:(NSEvent *)event{
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDragDisplayBK = clickPoint.x;
        yPointDragDisplayBK = clickPoint.y;
        
        xPositionMoveDisplayBK = (xPointDownDisplayBK-xPointDragDisplayBK)*windowWidthDisplayBK/(double)(magnificationDisplayBK*0.1);
        yPositionMoveDisplayBK = (yPointDownDisplayBK-yPointDragDisplayBK)*windowHeightDisplayBK/(double)(magnificationDisplayBK*0.1);
        
        mouseDragFlag = 1;
        
        [self setNeedsDisplay:YES];
    }
}

-(void)keyDown:(NSEvent *)event{
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        int proceedingFlag = 0;
        int keyCode = [event keyCode];
        
        if (keyCode == 124 && backgroundOriginalLoadFlag == 0){
            currentOriginalNo++;
            
            if (currentOriginalNo > loadImageFOVNo) currentOriginalNo = loadImageFOVNo;
            
            subprocesses = [[SubProcesses alloc] init];
            [subprocesses variableSave];
            
            proceedingFlag = 1;
        }
        
        if (keyCode == 123 && backgroundOriginalLoadFlag == 0){
            currentOriginalNo--;
            
            if (currentOriginalNo <= 0) currentOriginalNo = 1;
            
            subprocesses = [[SubProcesses alloc] init];
            [subprocesses variableSave];
            
            proceedingFlag = 1;
        }
        
        if (keyCode == 124 && backgroundOriginalLoadFlag == 1 && backgroundPatternModifyArrayCount != 0){
            int xBlockNo = 1;
            int yBlockNo = 1;
            
            if (imageDimensionX > 0) xBlockNo = imageDimensionX/8;
            if (imageDimensionY > 0) yBlockNo = imageDimensionY/8;
            
            backgroundDisplayPage++;
            
            if (backgroundDisplayPage > backgroundPatternModifyArrayCount/(xBlockNo*yBlockNo)) backgroundDisplayPage = backgroundPatternModifyArrayCount/(xBlockNo*yBlockNo);
            
            subprocesses = [[SubProcesses alloc] init];
            [subprocesses variableSave];
            
            for (int counter1 = 0; counter1 < 10; counter1++) backBasePositionArray [counter1] = 0;
            
            proceedingFlag = 1;
        }
        
        if (keyCode == 123 && backgroundOriginalLoadFlag == 1 && backgroundPatternModifyArrayCount != 0){
            backgroundDisplayPage--;
            
            if (backgroundDisplayPage <= 0) backgroundDisplayPage = 1;
            
            subprocesses = [[SubProcesses alloc] init];
            [subprocesses variableSave];
            
            for (int counter1 = 0; counter1 < 10; counter1++) backBasePositionArray [counter1] = 0;
            
            proceedingFlag = 1;
        }
        
        //-----Magnification Magnify-----
        if (keyCode == 125){
            if (magnificationDisplayBK >= 10 && magnificationDisplayBK <= 490){
                if (magnificationDisplayBK-10 < 10) magnificationDisplayBK = 10;
                else magnificationDisplayBK = magnificationDisplayBK-10;
                
                xPositionAdjustDisplayBK = -1*(imageDimensionX/(double)(magnificationDisplayBK*0.1)-imageDimensionX)/(double)2;
                yPositionAdjustDisplayBK = -1*(imageDimensionY/(double)(magnificationDisplayBK*0.1)-imageDimensionY)/(double)2;
            }
            else if (magnificationDisplayBK < 10) magnificationDisplayBK = 10;
            
            proceedingFlag = 1;
        }
        
        //-----Magnification Reduction-----
        if (keyCode == 126){
            if (magnificationDisplayBK >= 10 && magnificationDisplayBK <= 490){
                if (magnificationDisplayBK+10 > 490) magnificationDisplayBK = 490;
                else magnificationDisplayBK = magnificationDisplayBK+10;
                
                xPositionAdjustDisplayBK = (imageDimensionX-imageDimensionX/(double)(magnificationDisplayBK*0.1))/(double)2;
                yPositionAdjustDisplayBK = (imageDimensionY-imageDimensionY/(double)(magnificationDisplayBK*0.1))/(double)2;
            }
            else if (magnificationDisplayBK > 490) magnificationDisplayBK = 490;
            
            proceedingFlag = 1;
        }
        
        if (proceedingFlag == 1){
            if (backgroundOriginalLoadFlag == 0 && (keyCode == 124 || keyCode == 123)){
                if (overlayStatusHold == 0){
                    int displayImageSize = 0;
                    
                    if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                    else displayImageSize = imageDimensionY;
                    
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                        for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                            *bitmapData++ = (unsigned char)arrayImageContrastAdjust [(currentOriginalNo-1)*imageDimensionY+counter1][counter2];
                        }
                    }
                    
                    adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                    [adjustImageBK addRepresentation:bitmapReps];
                }
                else{
                    
                    int **backBaseArrayTemp = new int *[imageDimensionY+1];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                        backBaseArrayTemp [counter1] = new int [imageDimensionX+1];
                    }
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            backBaseArrayTemp [counter2][counter3] = arrayImageContrastAdjust [(currentOriginalNo-1)*imageDimensionY+counter2][counter3];
                        }
                    }
                    
                    //-----Value adjust (first adjusted image)-----
                    int difference = 0;
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            difference = 100-backBaseArrayEdge [counter2][counter3];
                            
                            if (backBaseArrayTemp [counter2][counter3]+difference >= 255) backBaseArrayTemp [counter2][counter3] = 255;
                            else if (backBaseArrayTemp [counter2][counter3]+difference < 0) backBaseArrayTemp [counter2][counter3] = 0;
                            else backBaseArrayTemp [counter2][counter3] = backBaseArrayTemp [counter2][counter3]+difference;
                        }
                    }
                    
                    int displayImageSize = 0;
                    
                    if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                    else displayImageSize = imageDimensionY;
                    
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                        for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                            *bitmapData++ = (unsigned char)backBaseArrayTemp [counter1][counter2];
                        }
                    }
                    
                    adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                    [adjustImageBK addRepresentation:bitmapReps];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                        delete [] backBaseArrayTemp [counter1];
                    }
                    
                    delete [] backBaseArrayTemp;
                }
            }
            else if (backgroundOriginalLoadFlag == 1 && (keyCode == 124 || keyCode == 123)){
                xClickPosition = 0;
                yClickPosition = 0;
                clickNumber = 0;
                clickValue = -1;
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        backBaseArray [counter2][counter3] = 0;
                        backBaseArrayModify [counter2][counter3] = 0;
                        backBaseArrayEdge [counter2][counter3] = 0;
                        backBaseMap [counter2][counter3] = -1;
                    }
                }
                
                int xBlockNo = 1;
                int yBlockNo = 1;
                
                if (imageDimensionX > 0) xBlockNo = imageDimensionX/8;
                if (imageDimensionY > 0) yBlockNo = imageDimensionY/8;
                
                for (int counter2 = 0; counter2 < yBlockNo; counter2++){
                    for (int counter4 = 0; counter4 < 8; counter4++){
                        for (int counter3 = 0; counter3 < xBlockNo; counter3++){
                            for (int counter5 = 0; counter5 < 8; counter5++){
                                backBaseArray [counter2*8+counter4][counter3*8+counter5] = backgroundPatternModifyArray [(backgroundDisplayPage-1)*(xBlockNo*yBlockNo)+counter2*yBlockNo+counter3];
                                backBaseArrayModify [counter2*8+counter4][counter3*8+counter5] = backgroundPatternModifyArray [(backgroundDisplayPage-1)*(xBlockNo*yBlockNo)+counter2*yBlockNo+counter3];
                                backBaseArrayEdge [counter2*8+counter4][counter3*8+counter5] = backgroundPatternModifyArray [(backgroundDisplayPage-1)*(xBlockNo*yBlockNo)+counter2*yBlockNo+counter3];
                                backBaseMap [counter2*8+counter4][counter3*8+counter5] = counter2*yBlockNo+counter3;
                            }
                        }
                    }
                }
                
                for (int counter1 = 0; counter1 < 10; counter1++) backBasePositionArray [counter1] = 0;
                
                int entryCount = 0;
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        backBaseArrayPrevious [0][entryCount] = backBaseArray [counter2][counter3], entryCount++;
                    }
                }
                
                backBasePositionArray [0] = 1;
                
                if (overlayStatusHold == 0){
                    int displayImageSize = 0;
                    
                    if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                    else displayImageSize = imageDimensionY;
                    
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                    
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter2 = 0; counter2 < yBlockNo; counter2++){
                        for (int counter4 = 0; counter4 < 8; counter4++){
                            for (int counter3 = 0; counter3 < xBlockNo; counter3++){
                                for (int counter5 = 0; counter5 < 8; counter5++){
                                    *bitmapData++ = (unsigned char)backgroundPatternModifyArray [(backgroundDisplayPage-1)*(xBlockNo*yBlockNo)+counter2*yBlockNo+counter3];
                                }
                            }
                        }
                    }
                    
                    adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                    [adjustImageBK addRepresentation:bitmapReps];
                }
                else{
                    
                    int **backBaseArrayTemp = new int *[imageDimensionY+1];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                        backBaseArrayTemp [counter1] = new int [imageDimensionX+1];
                    }
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            backBaseArrayTemp [counter2][counter3] = arrayImageContrastAdjust [(currentOriginalNo-1)*imageDimensionY+counter2][counter3];
                        }
                    }
                    
                    //-----Value adjust (first adjusted image)-----
                    int difference = 0;
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            difference = 100-backBaseArrayEdge  [counter2][counter3];
                            
                            if (backBaseArrayTemp [counter2][counter3]+difference >= 255) backBaseArrayTemp [counter2][counter3] = 255;
                            else if (backBaseArrayTemp [counter2][counter3]+difference < 0) backBaseArrayTemp [counter2][counter3] = 0;
                            else backBaseArrayTemp [counter2][counter3] = backBaseArrayTemp [counter2][counter3]+difference;
                        }
                    }
                    
                    int displayImageSize = 0;
                    
                    if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                    else displayImageSize = imageDimensionY;
                    
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                        for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                            *bitmapData++ = (unsigned char)backBaseArrayTemp [counter1][counter2];
                        }
                    }
                    
                    adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                    [adjustImageBK addRepresentation:bitmapReps];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                        delete [] backBaseArrayTemp [counter1];
                    }
                    
                    delete [] backBaseArrayTemp;
                }
            }
            
            [self setNeedsDisplay:YES];
        }
        
        //-----Background Box level reduction-----
        if (lineAreaStatusHold == 0 && keyCode == 123 && backgroundOriginalLoadFlag == 2 && clickValue != -1){
            clickValue--;
            
            if (clickValue < 0) clickValue = 0;
            else{
                
                int startX = xClickPosition;
                int endX = xClickPosition+8;
                int startY = yClickPosition;
                int endY = yClickPosition+8;
                
                if (backArea == 3){
                    endX = xClickPosition+24;
                    endY = yClickPosition+24;
                }
                
                if (backArea == 5){
                    endX = xClickPosition+40;
                    endY = yClickPosition+40;
                }
                
                if (backArea == 7){
                    endX = xClickPosition+56;
                    endY = yClickPosition+56;
                }
                
                if (backArea == 9){
                    endX = xClickPosition+72;
                    endY = yClickPosition+72;
                }
                
                for (int counter2 = startY; counter2 < endY; counter2++){
                    for (int counter3 = startX; counter3 < endX; counter3++){
                        if (counter2 >= 0 && counter2 < imageDimensionY && counter3 >= 0 && counter3 < imageDimensionX){
                            backBaseArray [counter2][counter3] = clickValue;
                            backBaseArrayModify [counter2][counter3] = clickValue;
                            backBaseArrayEdge [counter2][counter3] = clickValue;
                        }
                    }
                }
                
                if (xClickHold != xClickPosition && yClickHold != yClickPosition){
                    positionHold = -1;
                    int largestPoint = 0;
                    
                    for (int counter1 = 0; counter1 < 10; counter1++){
                        if (backBasePositionArray [counter1] == 0){
                            positionHold = counter1;
                        }
                        
                        if (backBasePositionArray [counter1] > largestPoint){
                            largestPoint = backBasePositionArray [counter1];
                        }
                    }
                    
                    if (positionHold == -1){
                        int smallestPoint = 100;
                        
                        for (int counter1 = 0; counter1 < 10; counter1++){
                            if (backBasePositionArray [counter1] < smallestPoint){
                                smallestPoint = backBasePositionArray [counter1];
                                positionHold = counter1;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < 10; counter1++){
                            if (positionHold != counter1){
                                backBasePositionArray [counter1] = backBasePositionArray [counter1]-1;
                            }
                        }
                        
                        backBasePositionArray [positionHold] = 10;
                    }
                    else backBasePositionArray [positionHold] = largestPoint+1;
                    
                    xClickHold = xClickPosition;
                    yClickHold = yClickPosition;
                    
                    int entryCount = 0;
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            backBaseArrayPrevious [positionHold][entryCount] = backBaseArray [counter2][counter3], entryCount++;
                        }
                    }
                }
                else{
                    
                    int entryCount = 0;
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            backBaseArrayPrevious [positionHold][entryCount] = backBaseArray [counter2][counter3], entryCount++;
                        }
                    }
                }
                
                if (overlayStatusHold == 0){
                    int displayImageSize = 0;
                    
                    if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                    else displayImageSize = imageDimensionY;
                    
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            *bitmapData++ = (unsigned char)backBaseArray [counter2][counter3];
                        }
                    }
                    
                    adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                    [adjustImageBK addRepresentation:bitmapReps];
                }
                else{
                    
                    int **backBaseArrayTemp = new int *[imageDimensionY+1];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                        backBaseArrayTemp [counter1] = new int [imageDimensionX+1];
                    }
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            backBaseArrayTemp [counter2][counter3] = arrayImageContrastAdjust [(currentOriginalNo-1)*imageDimensionY+counter2][counter3];
                        }
                    }
                    
                    //-----Value adjust (first adjusted image)-----
                    int difference = 0;
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            difference = 100-backBaseArrayModify [counter2][counter3];
                            
                            if (backBaseArrayTemp [counter2][counter3]+difference >= 255) backBaseArrayTemp [counter2][counter3] = 255;
                            else if (backBaseArrayTemp [counter2][counter3]+difference < 0) backBaseArrayTemp [counter2][counter3] = 0;
                            else backBaseArrayTemp [counter2][counter3] = backBaseArrayTemp [counter2][counter3]+difference;
                        }
                    }
                    
                    int displayImageSize = 0;
                    
                    if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                    else displayImageSize = imageDimensionY;
                    
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                        for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                            *bitmapData++ = (unsigned char)backBaseArrayTemp [counter1][counter2];
                        }
                    }
                    
                    adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                    [adjustImageBK addRepresentation:bitmapReps];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                        delete [] backBaseArrayTemp [counter1];
                    }
                    
                    delete [] backBaseArrayTemp;
                }
                
                [self setNeedsDisplay:YES];
            }
        }
        
        //-----Background Box level increase-----
        if (lineAreaStatusHold == 0 && keyCode == 124 && backgroundOriginalLoadFlag == 2 && clickValue != -1){
            clickValue++;
            
            if (clickValue > 255) clickValue = 255;
            else{
                
                int startX = xClickPosition;
                int endX = xClickPosition+8;
                int startY = yClickPosition;
                int endY = yClickPosition+8;
                
                if (backArea == 3){
                    endX = xClickPosition+24;
                    endY = yClickPosition+24;
                }
                
                if (backArea == 5){
                    endX = xClickPosition+40;
                    endY = yClickPosition+40;
                }
                
                if (backArea == 7){
                    endX = xClickPosition+56;
                    endY = yClickPosition+56;
                }
                
                if (backArea == 9){
                    endX = xClickPosition+72;
                    endY = yClickPosition+72;
                }
                
                for (int counter2 = startY; counter2 < endY; counter2++){
                    for (int counter3 = startX; counter3 < endX; counter3++){
                        if (counter2 >= 0 && counter2 < imageDimensionY && counter3 >= 0 && counter3 < imageDimensionX){
                            backBaseArray [counter2][counter3] = clickValue;
                            backBaseArrayModify [counter2][counter3] = clickValue;
                            backBaseArrayEdge [counter2][counter3] = clickValue;
                        }
                    }
                }
                
                if (xClickHold != xClickPosition && yClickHold != yClickPosition){
                    positionHold = -1;
                    int largestPoint = 0;
                    
                    for (int counter1 = 0; counter1 < 10; counter1++){
                        if (backBasePositionArray [counter1] == 0){
                            positionHold = counter1;
                        }
                        
                        if (backBasePositionArray [counter1] > largestPoint){
                            largestPoint = backBasePositionArray [counter1];
                        }
                    }
                    
                    if (positionHold == -1){
                        int smallestPoint = 100;
                        
                        for (int counter1 = 0; counter1 < 10; counter1++){
                            if (backBasePositionArray [counter1] < smallestPoint){
                                smallestPoint = backBasePositionArray [counter1];
                                positionHold = counter1;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < 10; counter1++){
                            if (positionHold != counter1){
                                backBasePositionArray [counter1] = backBasePositionArray [counter1]-1;
                            }
                        }
                        
                        backBasePositionArray [positionHold] = 10;
                    }
                    else backBasePositionArray [positionHold] = largestPoint+1;
                    
                    xClickHold = xClickPosition;
                    yClickHold = yClickPosition;
                    
                    int entryCount = 0;
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            backBaseArrayPrevious [positionHold][entryCount] = backBaseArray [counter2][counter3], entryCount++;
                        }
                    }
                }
                else{
                    
                    int entryCount = 0;
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            backBaseArrayPrevious [positionHold][entryCount] = backBaseArray [counter2][counter3], entryCount++;
                        }
                    }
                }
                
                if (overlayStatusHold == 0){
                    int displayImageSize = 0;
                    
                    if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                    else displayImageSize = imageDimensionY;
                    
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            *bitmapData++ = (unsigned char)backBaseArray [counter2][counter3];
                        }
                    }
                    
                    adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                    [adjustImageBK addRepresentation:bitmapReps];
                }
                else{
                    
                    int **backBaseArrayTemp = new int *[imageDimensionY+1];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                        backBaseArrayTemp [counter1] = new int [imageDimensionX+1];
                    }
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            backBaseArrayTemp [counter2][counter3] = arrayImageContrastAdjust [(currentOriginalNo-1)*imageDimensionY+counter2][counter3];
                        }
                    }
                    
                    //-----Value adjust (first adjusted image)-----
                    int difference = 0;
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            difference = 100-backBaseArrayModify [counter2][counter3];
                            
                            if (backBaseArrayTemp [counter2][counter3]+difference >= 255) backBaseArrayTemp [counter2][counter3] = 255;
                            else if (backBaseArrayTemp [counter2][counter3]+difference < 0) backBaseArrayTemp [counter2][counter3] = 0;
                            else backBaseArrayTemp [counter2][counter3] = backBaseArrayTemp [counter2][counter3]+difference;
                        }
                    }
                    
                    int displayImageSize = 0;
                    
                    if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                    else displayImageSize = imageDimensionY;
                    
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                        for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                            *bitmapData++ = (unsigned char)backBaseArrayTemp [counter1][counter2];
                        }
                    }
                    
                    adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                    [adjustImageBK addRepresentation:bitmapReps];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                        delete [] backBaseArrayTemp [counter1];
                    }
                    
                    delete [] backBaseArrayTemp;
                }
                
                [self setNeedsDisplay:YES];
            }
        }
        
        //-----Fill line-----
        if (lineAreaStatusHold == 1 && keyCode == 124 && backgroundOriginalLoadFlag == 2 && clickValue != -1){
            if (bkLine1 != -1 || bkLine2 != -1){
                int startX1 = bkLineCenterX1;
                int endX1 = bkLineCenterX1;
                
                int startY2 = bkLineCenterY1;
                int startX3 = bkLineCenterX1;
                
                int startY4 = bkLineCenterY1;
                int endY4 = bkLineCenterY1;
                
                int startX5 = bkLineCenterX2;
                int endX5 = bkLineCenterX2;
                
                int startY6 = bkLineCenterY2;
                int startX7 = bkLineCenterX2;
                
                int startY8 = bkLineCenterY2;
                int endY8 = bkLineCenterY2;
                
                //cout<<startX1<<" "<<endX1<<" "<<startY2<<" "<<startX3<<" "<<startY4<<" "<<endY4<<" "<<startX5<<" "<<endX5<<" "<<startY6<<" "<<startX7<<" "<<startY8<<" "<<endY8<<" value"<<endl;
                
                if (backArea == 1){
                    if (startX1 == startX5){
                        int clickValue1 = backBaseArray [startY2][startX1];
                        int clickValue2 = backBaseArray [startY6][startX1];
                        int length = abs (startY2-startY6)/8;
                        
                        if (length != 0){
                            double increment = (clickValue2-clickValue1)/(double)length;
                            double accumulate = increment;
                            
                            if (startY2 < startY6){
                                for (int counter2 = startY2+8; counter2 <= startY6; counter2 = counter2+8){
                                    for (int counter3 = startX1; counter3 < startX1+8; counter3++){
                                        for (int counter4 = counter2; counter4 < counter2+8; counter4++){
                                            if (counter3 >= 0 && counter3 < imageDimensionY && counter4 >= 0 && counter4 < imageDimensionX){
                                                backBaseArray [counter4][counter3] = (int)(clickValue1+accumulate);
                                                backBaseArrayModify [counter4][counter3] = (int)(clickValue1+accumulate);
                                                backBaseArrayEdge [counter4][counter3] = (int)(clickValue1+accumulate);
                                            }
                                        }
                                    }
                                    
                                    accumulate = accumulate+increment;
                                }
                            }
                            if (startY2 > startY6){
                                for (int counter2 = startY2-8; counter2 >= startY6; counter2 = counter2-8){
                                    for (int counter3 = startX1; counter3 < startX1+8; counter3++){
                                        for (int counter4 = counter2; counter4 < counter2+8; counter4++){
                                            if (counter3 >= 0 && counter3 < imageDimensionY && counter4 >= 0 && counter4 < imageDimensionX){
                                                backBaseArray [counter4][counter3] = (int)(clickValue1+accumulate);
                                                backBaseArrayModify [counter4][counter3] = (int)(clickValue1+accumulate);
                                                backBaseArrayEdge [counter4][counter3] = (int)(clickValue1+accumulate);
                                            }
                                        }
                                    }
                                    
                                    accumulate = accumulate+increment;
                                }
                            }
                        }
                    }
                    
                    if (startY2 == startY6){
                        int clickValue1 = backBaseArray [startY2][startX1];
                        int clickValue2 = backBaseArray [startY2][startX5];
                        int length = abs (startX1-startX5)/8;
                        
                        if (length != 0){
                            double increment = (clickValue2-clickValue1)/(double)length;
                            double accumulate = increment;
                            
                            if (startX1 < startX5){
                                for (int counter2 = startX1+8; counter2 <= startX5; counter2 = counter2+8){
                                    for (int counter3 = startY2; counter3 < startY2+8; counter3++){
                                        for (int counter4 = counter2; counter4 < counter2+8; counter4++){
                                            if (counter3 >= 0 && counter3 < imageDimensionY && counter4 >= 0 && counter4 < imageDimensionX){
                                                backBaseArray [counter3][counter4] = (int)(clickValue1+accumulate);
                                                backBaseArrayModify [counter3][counter4] = (int)(clickValue1+accumulate);
                                                backBaseArrayEdge [counter3][counter4] = (int)(clickValue1+accumulate);
                                            }
                                        }
                                    }
                                    
                                    accumulate = accumulate+increment;
                                }
                            }
                            
                            if (startX1 > startX5){
                                for (int counter2 = startX1-8; counter2 >= startX5; counter2 = counter2-8){
                                    
                                    for (int counter3 = startY2; counter3 < startY2+8; counter3++){
                                        for (int counter4 = counter2; counter4 < counter2+8; counter4++){
                                            if (counter3 >= 0 && counter3 < imageDimensionY && counter4 >= 0 && counter4 < imageDimensionX){
                                                backBaseArray [counter3][counter4] = (int)(clickValue1+accumulate);
                                                backBaseArrayModify [counter3][counter4] = (int)(clickValue1+accumulate);
                                                backBaseArrayEdge [counter3][counter4] = (int)(clickValue1+accumulate);
                                            }
                                        }
                                    }
                                    
                                    accumulate = accumulate+increment;
                                }
                            }
                        }
                    }
                }
                
                if (backArea == 3){
                    if (bkLineCenterX1-8 < 0) startX1 = 0;
                    else startX1 = bkLineCenterX1-8;
                    
                    if (bkLineCenterX1+8 > imageDimensionX-1) endX1 = imageDimensionX-8;
                    else endX1 = bkLineCenterX1+8;
                    
                    startY2 = bkLineCenterY1;
                    startX3 = bkLineCenterX1;
                    
                    if (bkLineCenterY1-8 < 0) startY4 = 0;
                    else startY4 = bkLineCenterY1-8;
                    
                    if (bkLineCenterY1+8 > imageDimensionY-1) endY4 = imageDimensionY-8;
                    else endY4 = bkLineCenterY1+8;
                    
                    if (bkLineCenterX2-8 < 0) startX5 = 0;
                    else startX5 = bkLineCenterX2-8;
                    
                    if (bkLineCenterX2+8 > imageDimensionX-1) endX5 = imageDimensionX-8;
                    else endX5 = bkLineCenterX2+8;
                    
                    startY6 = bkLineCenterY2;
                    startX7 = bkLineCenterX2;
                    
                    if (bkLineCenterY2-8 < 0) startY8 = 0;
                    else startY8 = bkLineCenterY2-8;
                    
                    if (bkLineCenterY2+8 > imageDimensionY-1) endY8 = imageDimensionY-8;
                    else endY8 = bkLineCenterY2+8;
                }
                
                if (backArea == 5){
                    if (bkLineCenterX1-16 < 0) startX1 = 0;
                    else startX1 = bkLineCenterX1-16;
                    
                    if (bkLineCenterX1+16 > imageDimensionX-1) endX1 = imageDimensionX-8;
                    else endX1 = bkLineCenterX1+16;
                    
                    startY2 = bkLineCenterY1;
                    startX3 = bkLineCenterX1;
                    
                    if (bkLineCenterY1-16 < 0) startY4 = 0;
                    else startY4 = bkLineCenterY1-16;
                    
                    if (bkLineCenterY1+16 > imageDimensionY-1) endY4 = imageDimensionY-8;
                    else endY4 = bkLineCenterY1+16;
                    
                    if (bkLineCenterX2-16 < 0) startX5 = 0;
                    else startX5 = bkLineCenterX2-16;
                    
                    if (bkLineCenterX2+16 > imageDimensionX-1) endX5 = imageDimensionX-8;
                    else endX5 = bkLineCenterX2+16;
                    
                    startY6 = bkLineCenterY2;
                    startX7 = bkLineCenterX2;
                    
                    if (bkLineCenterY2-16 < 0) startY8 = 0;
                    else startY8 = bkLineCenterY2-16;
                    
                    if (bkLineCenterY2+16 > imageDimensionY-1) endY8 = imageDimensionY-8;
                    else endY8 = bkLineCenterY2+16;
                }
                
                if (backArea == 7){
                    if (bkLineCenterX1-24 < 0) startX1 = 0;
                    else startX1 = bkLineCenterX1-24;
                    
                    if (bkLineCenterX1+24 > imageDimensionX-1) endX1 = imageDimensionX-8;
                    else endX1 = bkLineCenterX1+24;
                    
                    startY2 = bkLineCenterY1;
                    startX3 = bkLineCenterX1;
                    
                    if (bkLineCenterY1-24 < 0) startY4 = 0;
                    else startY4 = bkLineCenterY1-24;
                    
                    if (bkLineCenterY1+24 > imageDimensionY-1) endY4 = imageDimensionY-8;
                    else endY4 = bkLineCenterY1+24;
                    
                    if (bkLineCenterX2-24 < 0) startX5 = 0;
                    else startX5 = bkLineCenterX2-24;
                    
                    if (bkLineCenterX2+24 > imageDimensionX-1) endX5 = imageDimensionX-8;
                    else endX5 = bkLineCenterX2+24;
                    
                    startY6 = bkLineCenterY2;
                    startX7 = bkLineCenterX2;
                    
                    if (bkLineCenterY2-24 < 0) startY8 = 0;
                    else startY8 = bkLineCenterY2-24;
                    
                    if (bkLineCenterY2+24 > imageDimensionY-1) endY8 = imageDimensionY-8;
                    else endY8 = bkLineCenterY2+24;
                }
                
                if (backArea == 9){
                    if (bkLineCenterX1-32 < 0) startX1 = 0;
                    else startX1 = bkLineCenterX1-32;
                    
                    if (bkLineCenterX1+32 > imageDimensionX-1) endX1 = imageDimensionX-8;
                    else endX1 = bkLineCenterX1+32;
                    
                    startY2 = bkLineCenterY1;
                    startX3 = bkLineCenterX1;
                    
                    if (bkLineCenterY1-32 < 0) startY4 = 0;
                    else startY4 = bkLineCenterY1-32;
                    
                    if (bkLineCenterY1+32 > imageDimensionY-1) endY4 = imageDimensionY-8;
                    else endY4 = bkLineCenterY1+32;
                    
                    if (bkLineCenterX2-32 < 0) startX5 = 0;
                    else startX5 = bkLineCenterX2-32;
                    
                    if (bkLineCenterX2+32 > imageDimensionX-1) endX5 = imageDimensionX-8;
                    else endX5 = bkLineCenterX2+32;
                    
                    startY6 = bkLineCenterY2;
                    startX7 = bkLineCenterX2;
                    
                    if (bkLineCenterY2-32 < 0) startY8 = 0;
                    else startY8 = bkLineCenterY2-32;
                    
                    if (bkLineCenterY2+32 > imageDimensionY-1) endY8 = imageDimensionY-8;
                    else endY8 = bkLineCenterY2+32;
                }
                
                //cout<<startX1<<" "<<endX1<<" "<<startY2<<" "<<startX3<<" "<<startY4<<" "<<endY4<<" "<<startX5<<" "<<endX5<<" "<<startY6<<" "<<startX7<<" "<<startY8<<" "<<endY8<<" value2"<<endl;
                
                if (backArea > 1){
                    int length = 0;
                    double increment = 0;
                    double accumulate = 0;
                    
                    for (int counter5 = startX1; counter5 <= endX1; counter5 = counter5+8){
                        for (int counter6 = startX5; counter6 <= endX5; counter6 = counter6+8){
                            if (counter5 == counter6){
                                length = abs (startY2-startY6)/8;
                                
                                if (length != 0){
                                    increment = (backBaseArray [startY6][counter5]-backBaseArray [startY2][counter5])/(double)length;
                                    accumulate = increment;
                                    
                                    if (startY2 < startY6){
                                        for (int counter2 = startY2+8; counter2 <= startY6; counter2 = counter2+8){
                                            for (int counter3 = counter5; counter3 < counter5+8; counter3++){
                                                for (int counter4 = counter2; counter4 < counter2+8; counter4++){
                                                    if (counter3 >= 0 && counter3 < imageDimensionY && counter4 >= 0 && counter4 < imageDimensionX){
                                                        backBaseArray [counter4][counter3] = (int)(backBaseArray [startY2][counter5]+accumulate);
                                                        backBaseArrayModify [counter4][counter3] = (int)(backBaseArrayModify [startY2][counter5]+accumulate);
                                                        backBaseArrayEdge [counter4][counter3] = (int)(backBaseArrayModify [startY2][counter5]+accumulate);
                                                    }
                                                }
                                            }
                                            
                                            accumulate = accumulate+increment;
                                        }
                                    }
                                    
                                    if (startY2 > startY6){
                                        for (int counter2 = startY2-8; counter2 >= startY6; counter2 = counter2-8){
                                            for (int counter3 = counter5; counter3 < counter5+8; counter3++){
                                                for (int counter4 = counter2; counter4 < counter2+8; counter4++){
                                                    if (counter3 >= 0 && counter3 < imageDimensionY && counter4 >= 0 && counter4 < imageDimensionX){
                                                        backBaseArray [counter4][counter3] = (int)(backBaseArray [startY2][counter5]+accumulate);
                                                        backBaseArrayModify [counter4][counter3] = (int)(backBaseArrayModify [startY2][counter5]+accumulate);
                                                        backBaseArrayEdge [counter4][counter3] = (int)(backBaseArrayModify [startY2][counter5]+accumulate);
                                                    }
                                                }
                                            }
                                            
                                            accumulate = accumulate+increment;
                                        }
                                    }
                                }
                                
                                break;
                            }
                        }
                    }
                    
                    for (int counter5 = startY4; counter5 <= endY4; counter5 = counter5+8){
                        for (int counter6 = startY8; counter6 <= endY8; counter6 = counter6+8){
                            if (counter5 == counter6){
                                length = abs (startX3-startX7)/8;
                                
                                if (length != 0){
                                    increment = (backBaseArray [counter5][startX7]-backBaseArray [counter5][startX3])/(double)length;
                                    accumulate = increment;
                                    
                                    if (startX3 < startX7){
                                        for (int counter2 = startX3+8; counter2 <= startX7; counter2 = counter2+8){
                                            for (int counter3 = counter5; counter3 <counter5+8; counter3++){
                                                for (int counter4 = counter2; counter4 < counter2+8; counter4++){
                                                    if (counter3 >= 0 && counter3 < imageDimensionY && counter4 >= 0 && counter4 < imageDimensionX){
                                                        backBaseArray [counter3][counter4] = (int)(backBaseArray [counter5][startX3]+accumulate);
                                                        backBaseArrayModify [counter3][counter4] = (int)(backBaseArrayModify [counter5][startX3]+accumulate);
                                                        backBaseArrayEdge [counter3][counter4] = (int)(backBaseArrayModify [counter5][startX3]+accumulate);
                                                    }
                                                }
                                            }
                                            
                                            accumulate = accumulate+increment;
                                        }
                                    }
                                    
                                    if (startX3 > startX7){
                                        for (int counter2 = startX3-8; counter2 >= startX7; counter2 = counter2-8){
                                            for (int counter3 = counter5; counter3 < counter5+8; counter3++){
                                                for (int counter4 = counter2; counter4 < counter2+8; counter4++){
                                                    if (counter3 >= 0 && counter3 < imageDimensionY && counter4 >= 0 && counter4 < imageDimensionX){
                                                        backBaseArray [counter3][counter4] = (int)(backBaseArray [counter5][startX3]+accumulate);
                                                        backBaseArrayModify [counter3][counter4] = (int)(backBaseArrayModify [counter5][startX3]+accumulate);
                                                        backBaseArrayEdge [counter3][counter4] = (int)(backBaseArrayModify [counter5][startX3]+accumulate);
                                                    }
                                                }
                                            }
                                            
                                            accumulate = accumulate+increment;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    int largestPoint = 0;
                    int setPoint = -1;
                    
                    for (int counter1 = 0; counter1 < 10; counter1++){
                        if (backBasePositionArray [counter1] == 0) setPoint = counter1;
                        
                        if (backBasePositionArray [counter1] > largestPoint){
                            largestPoint = backBasePositionArray [counter1];
                        }
                    }
                    
                    if (setPoint == -1){
                        int smallestPoint = 100;
                        
                        for (int counter1 = 0; counter1 < 10; counter1++){
                            if (backBasePositionArray [counter1] < smallestPoint){
                                smallestPoint = backBasePositionArray [counter1];
                                setPoint = counter1;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < 10; counter1++){
                            if (setPoint != counter1){
                                backBasePositionArray [counter1] = backBasePositionArray [counter1]-1;
                            }
                        }
                        
                        backBasePositionArray [setPoint] = 10;
                    }
                    else backBasePositionArray [setPoint] = largestPoint+1;
                    
                    int entryCount = 0;
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            backBaseArrayPrevious [setPoint][entryCount] = backBaseArray [counter2][counter3], entryCount++;
                        }
                    }
                }
                
                if (overlayStatusHold == 0){
                    int displayImageSize = 0;
                    
                    if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                    else displayImageSize = imageDimensionY;
                    
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            *bitmapData++ = (unsigned char)backBaseArray [counter2][counter3];
                        }
                    }
                    
                    bkLine1 = -1;
                    bkLine2 = -1;
                    
                    adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                    [adjustImageBK addRepresentation:bitmapReps];
                }
                else{
                    
                    int **backBaseArrayTemp = new int *[imageDimensionY+1];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                        backBaseArrayTemp [counter1] = new int [imageDimensionX+1];
                    }
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            backBaseArrayTemp [counter2][counter3] = arrayImageContrastAdjust [(currentOriginalNo-1)*imageDimensionY+counter2][counter3];
                        }
                    }
                    
                    //-----Value adjust (first adjusted image)-----
                    int difference = 0;
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            difference = 100-backBaseArrayModify [counter2][counter3];
                            
                            if (backBaseArrayTemp [counter2][counter3]+difference >= 255) backBaseArrayTemp [counter2][counter3] = 255;
                            else if (backBaseArrayTemp [counter2][counter3]+difference < 0) backBaseArrayTemp [counter2][counter3] = 0;
                            else backBaseArrayTemp [counter2][counter3] = backBaseArrayTemp [counter2][counter3]+difference;
                        }
                    }
                    
                    int displayImageSize = 0;
                    
                    if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                    else displayImageSize = imageDimensionY;
                    
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                        for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                            *bitmapData++ = (unsigned char)backBaseArrayTemp [counter1][counter2];
                        }
                    }
                    
                    bkLine1 = -1;
                    bkLine2 = -1;
                    
                    adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                    [adjustImageBK addRepresentation:bitmapReps];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                        delete [] backBaseArrayTemp [counter1];
                    }
                    
                    delete [] backBaseArrayTemp;
                }
                
                [self setNeedsDisplay:YES];
            }
            else{
                
                bkLine1 = -1;
                bkLine2 = -1;
            }
        }
        
        //-----Original Position-----
        if (keyCode == 6){
            xPositionDisplayBK = 0;
            yPositionDisplayBK = 0;
            xPositionAdjustDisplayBK = 0;
            yPositionAdjustDisplayBK = 0;
            magnificationDisplayBK = 10;
            
            xPositionAdjustDisplayBK = (imageDimensionX-imageDimensionX/(double)(magnificationDisplayBK*0.1))/(double)2;
            yPositionAdjustDisplayBK = (imageDimensionY-imageDimensionY/(double)(magnificationDisplayBK*0.1))/(double)2;
            
            [self setNeedsDisplay:YES];
        }
        
        //-----Retry-----
        if (keyCode == 15){
            if (backgroundOriginalLoadFlag == 2){
                int largestPoint = 0;
                int setPoint = -1;
                
                for (int counter1 = 0; counter1 < 10; counter1++){
                    if (backBasePositionArray [counter1] > largestPoint){
                        largestPoint = backBasePositionArray [counter1];
                        setPoint = counter1;
                    }
                }
                
                int largestPoint2 = 0;
                int setPoint2 = -1;
                
                for (int counter1 = 0; counter1 < 10; counter1++){
                    if (backBasePositionArray [counter1] > largestPoint2 && setPoint != counter1){
                        largestPoint2 = backBasePositionArray [counter1];
                        setPoint2 = counter1;
                    }
                }
                
                if (setPoint2 != -1){
                    int entryCountY = 0;
                    int entryCountX = 0;
                    
                    for (int counter2 = 0; counter2 < imageDimensionY*imageDimensionX; counter2++){
                        backBaseArray [entryCountY][entryCountX] = backBaseArrayPrevious [setPoint2][counter2];
                        backBaseArrayModify [entryCountY][entryCountX] = backBaseArrayPrevious [setPoint2][counter2];
                        backBaseArrayEdge [entryCountY][entryCountX] = backBaseArrayPrevious [setPoint2][counter2];
                        
                        entryCountX++;
                        
                        if (entryCountX == imageDimensionX){
                            entryCountY++;
                            entryCountX = 0;
                        }
                    }
                }
                
                backBasePositionArray [setPoint] = 0;
                
                if (overlayStatusHold == 0){
                    int displayImageSize = 0;
                    
                    if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                    else displayImageSize = imageDimensionY;
                    
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            *bitmapData++ = (unsigned char)backBaseArray [counter2][counter3];
                        }
                    }
                    
                    adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                    [adjustImageBK addRepresentation:bitmapReps];
                }
                else{
                    
                    int **backBaseArrayTemp = new int *[imageDimensionY+1];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                        backBaseArrayTemp [counter1] = new int [imageDimensionX+1];
                    }
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            backBaseArrayTemp [counter2][counter3] = arrayImageContrastAdjust [(currentOriginalNo-1)*imageDimensionY+counter2][counter3];
                        }
                    }
                    
                    //-----Value adjust (first adjusted image)-----
                    int difference = 0;
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            difference = 100-backBaseArrayEdge [counter2][counter3];
                            
                            if (backBaseArrayTemp [counter2][counter3]+difference >= 255) backBaseArrayTemp [counter2][counter3] = 255;
                            else if (backBaseArrayTemp [counter2][counter3]+difference < 0) backBaseArrayTemp [counter2][counter3] = 0;
                            else backBaseArrayTemp [counter2][counter3] = backBaseArrayTemp [counter2][counter3]+difference;
                        }
                    }
                    
                    int displayImageSize = 0;
                    
                    if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                    else displayImageSize = imageDimensionY;
                    
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                        for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                            *bitmapData++ = (unsigned char)backBaseArrayTemp [counter1][counter2];
                        }
                    }
                    
                    adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                    [adjustImageBK addRepresentation:bitmapReps];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                        delete [] backBaseArrayTemp [counter1];
                    }
                    
                    delete [] backBaseArrayTemp;
                }
                
                [self setNeedsDisplay:YES];
            }
            else if (backgroundOriginalLoadFlag == 3){
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        backBaseArrayModify [counter2][counter3] = backBaseArray [counter2][counter3];
                        backBaseArrayEdge [counter2][counter3] = backBaseArray [counter2][counter3];
                    }
                }
                
                if (overlayStatusHold == 0){
                    int displayImageSize = 0;
                    
                    if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                    else displayImageSize = imageDimensionY;
                    
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            *bitmapData++ = (unsigned char)backBaseArrayEdge  [counter2][counter3];
                        }
                    }
                    
                    adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                    [adjustImageBK addRepresentation:bitmapReps];
                }
                else{
                    
                    int **backBaseArrayTemp = new int *[imageDimensionY+1];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                        backBaseArrayTemp [counter1] = new int [imageDimensionX+1];
                    }
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            backBaseArrayTemp [counter2][counter3] = arrayImageContrastAdjust [(currentOriginalNo-1)*imageDimensionY+counter2][counter3];
                        }
                    }
                    
                    //-----Value adjust (first adjusted image)-----
                    int difference = 0;
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            difference = 100-backBaseArrayEdge  [counter2][counter3];
                            
                            if (backBaseArrayTemp [counter2][counter3]+difference >= 255) backBaseArrayTemp [counter2][counter3] = 255;
                            else if (backBaseArrayTemp [counter2][counter3]+difference < 0) backBaseArrayTemp [counter2][counter3] = 0;
                            else backBaseArrayTemp [counter2][counter3] = backBaseArrayTemp [counter2][counter3]+difference;
                        }
                    }
                    
                    int displayImageSize = 0;
                    
                    if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                    else displayImageSize = imageDimensionY;
                    
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                        for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                            *bitmapData++ = (unsigned char)backBaseArrayTemp [counter1][counter2];
                        }
                    }
                    
                    adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                    [adjustImageBK addRepresentation:bitmapReps];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                        delete [] backBaseArrayTemp [counter1];
                    }
                    
                    delete [] backBaseArrayTemp;
                }
                
                [self setNeedsDisplay:YES];
            }
            else if (backgroundOriginalLoadFlag == 1){
                int xBlockNo = 1;
                int yBlockNo = 1;
                
                if (imageDimensionX > 0) xBlockNo = imageDimensionX/8;
                if (imageDimensionY > 0) yBlockNo = imageDimensionY/8;
                
                for (int counter2 = 0; counter2 < yBlockNo; counter2++){
                    for (int counter3 = 0; counter3 < xBlockNo; counter3++){
                        backgroundPatternModifyArray [(backgroundDisplayPage-1)*(xBlockNo*yBlockNo)+counter2*yBlockNo+counter3] = backgroundPatternModifyArray [(backgroundDisplayPage-1)*(xBlockNo*yBlockNo)+counter2*yBlockNo+counter3];
                    }
                }
                
                for (int counter2 = 0; counter2 < yBlockNo; counter2++){
                    for (int counter4 = 0; counter4 < 8; counter4++){
                        for (int counter3 = 0; counter3 < xBlockNo; counter3++){
                            for (int counter5 = 0; counter5 < 8; counter5++){
                                backBaseArray [counter2*8+counter4][counter3*8+counter5] = backgroundPatternArray [(backgroundDisplayPage-1)*(xBlockNo*yBlockNo)+counter2*yBlockNo+counter3];
                                backBaseArrayModify [counter2*8+counter4][counter3*8+counter5] = backgroundPatternArray [(backgroundDisplayPage-1)*(xBlockNo*yBlockNo)+counter2*yBlockNo+counter3];
                                backBaseArrayEdge [counter2*8+counter4][counter3*8+counter5] = backgroundPatternArray [(backgroundDisplayPage-1)*(xBlockNo*yBlockNo)+counter2*yBlockNo+counter3];
                                backBaseMap [counter2*8+counter4][counter3*8+counter5] = counter2*yBlockNo+counter3;
                            }
                        }
                    }
                }
                
                if (overlayStatusHold == 0){
                    int displayImageSize = 0;
                    
                    if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                    else displayImageSize = imageDimensionY;
                    
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter2 = 0; counter2 < yBlockNo; counter2++){
                        for (int counter4 = 0; counter4 < 8; counter4++){
                            for (int counter3 = 0; counter3 < xBlockNo; counter3++){
                                for (int counter5 = 0; counter5 < 8; counter5++){
                                    *bitmapData++ = (unsigned char)backgroundPatternModifyArray [(backgroundDisplayPage-1)*(xBlockNo*yBlockNo)+counter2*yBlockNo+counter3];
                                }
                            }
                        }
                    }
                    
                    adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                    [adjustImageBK addRepresentation:bitmapReps];
                }
                else{
                    
                    int **backBaseArrayTemp = new int *[imageDimensionY+1];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                        backBaseArrayTemp [counter1] = new int [imageDimensionX+1];
                    }
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            backBaseArrayTemp [counter2][counter3] = arrayImageContrastAdjust [(currentOriginalNo-1)*imageDimensionY+counter2][counter3];
                        }
                    }
                    
                    //-----Value adjust (first adjusted image)-----
                    int difference = 0;
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            difference = 100-backBaseArrayEdge [counter2][counter3];
                            
                            if (backBaseArrayTemp [counter2][counter3]+difference >= 255) backBaseArrayTemp [counter2][counter3] = 255;
                            else if (backBaseArrayTemp [counter2][counter3]+difference < 0) backBaseArrayTemp [counter2][counter3] = 0;
                            else backBaseArrayTemp [counter2][counter3] = backBaseArrayTemp [counter2][counter3]+difference;
                        }
                    }
                    
                    int displayImageSize = 0;
                    
                    if (imageDimensionX > imageDimensionY) displayImageSize = imageDimensionX;
                    else displayImageSize = imageDimensionY;
                    
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:displayImageSize pixelsHigh:displayImageSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:displayImageSize bitsPerPixel:8];
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                        for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                            *bitmapData++ = (unsigned char)backBaseArrayTemp [counter1][counter2];
                        }
                    }
                    
                    adjustImageBK = [[NSImage alloc] initWithSize:NSMakeSize(displayImageSize, displayImageSize)];
                    [adjustImageBK addRepresentation:bitmapReps];
                    
                    for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                        delete [] backBaseArrayTemp [counter1];
                    }
                    
                    delete [] backBaseArrayTemp;
                }
                
                [self setNeedsDisplay:YES];
            }
        }
        
        //-----Set fov no-----
        if (keyCode == 0){
            if (loadImageTreatName != ""){
                string treatNameTemp2;
                string fovName2;
                string contrastDataTemp;
                string extract1;
                string extract2;
                string fovPosition;
                
                if ((int)loadImageTreatName.find("CH") != -1){
                    fovPosition = loadImageTreatName.substr(loadImageTreatName.find("CH"))+"-"+to_string(currentOriginalNo);
                }
                else fovPosition = "FOV"+to_string(currentOriginalNo);
                
                string backPageNo = to_string(backgroundDisplayPage);
                
                int treatFind = 0;
                
                for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++){
                    treatNameTemp2 = arrayTreatmentNameDisplay [counter2];
                    fovName2 = arrayFOVNameDisplay [counter2];
                    
                    if (treatNameTemp2 == loadImageTreatName && fovName2 != "ND" && treatFind == 0){
                        treatFind = 1;
                        
                        if (fovName2 == fovPosition){
                            contrastDataTemp = arrayTableDisplay [counter2*5+2];
                            extract1 = contrastDataTemp.substr(0, contrastDataTemp.find(":"));
                            extract2 = contrastDataTemp.substr(contrastDataTemp.find("~"));
                            extract1 = extract1+":"+backPageNo+extract2;
                            arrayTableDisplay [counter2*5+2] = extract1;
                            break;
                        }
                    }
                    else if (treatNameTemp2 == "ND" && fovName2 != "ND" && treatFind == 1){
                        if (fovName2 == fovPosition){
                            contrastDataTemp = arrayTableDisplay [counter2*5+2];
                            extract1 = contrastDataTemp.substr(0, contrastDataTemp.find(":"));
                            extract2 = contrastDataTemp.substr(contrastDataTemp.find("~"));
                            extract1 = extract1+":"+backPageNo+extract2;
                            arrayTableDisplay [counter2*5+2] = extract1;
                            break;
                        }
                    }
                    else if (((treatNameTemp2 != "ND" && fovName2 != "ND") || (treatNameTemp2 == "ND" && fovName2 == "ND")) && treatFind == 1){
                        treatFind = 2;
                    }
                }
                
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    contrastCurrentHold [counter1] = arrayTableDisplay [counter1*5+2];
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                tableViewCall = 1;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Treatment Not Selected"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        //-----Set to all-----
        if (keyCode == 17){
            if (loadImageTreatName != ""){
                string treatNameTemp2;
                string fovName2;
                string contrastDataTemp;
                string extract1;
                string extract2;
                string fovPosition;
                
                if ((int)loadImageTreatName.find("CH") != -1){
                    fovPosition = loadImageTreatName.substr(loadImageTreatName.find("CH"))+"-"+to_string(currentOriginalNo);
                }
                else fovPosition = "FOV"+to_string(currentOriginalNo);
                
                string backPageNo = to_string(backgroundDisplayPage);
                
                int treatFind = 0;
                
                for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++){
                    treatNameTemp2 = arrayTreatmentNameDisplay [counter2];
                    fovName2 = arrayFOVNameDisplay [counter2];
                    
                    if (treatNameTemp2 == loadImageTreatName && fovName2 != "ND" && treatFind == 0){
                        treatFind = 1;
                        
                        contrastDataTemp = arrayTableDisplay [counter2*5+2];
                        extract1 = contrastDataTemp.substr(0, contrastDataTemp.find(":"));
                        extract2 = contrastDataTemp.substr(contrastDataTemp.find("~"));
                        extract1 = extract1+":"+backPageNo+extract2;
                        
                        arrayTableDisplay [counter2*5+2] = extract1;
                    }
                    else if (treatNameTemp2 == "ND" && fovName2 != "ND" && treatFind == 1){
                        contrastDataTemp = arrayTableDisplay [counter2*5+2];
                        extract1 = contrastDataTemp.substr(0, contrastDataTemp.find(":"));
                        extract2 = contrastDataTemp.substr(contrastDataTemp.find("~"));
                        extract1 = extract1+":"+backPageNo+extract2;
                        
                        arrayTableDisplay [counter2*5+2] = extract1;
                    }
                    else if (((treatNameTemp2 != "ND" && fovName2 != "ND") || (treatNameTemp2 == "ND" && fovName2 == "ND")) && treatFind == 1){
                        treatFind = 2;
                    }
                }
                
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    contrastCurrentHold [counter1] = arrayTableDisplay [counter1*5+2];
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                tableViewCall = 1;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Treatment Not Selected"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        //-----Set to R1-----
        if (keyCode == 11){
            if (loadImageTreatName != ""){
                int fovNoForProcess = loadImageFOVNo;
                int imageSizeTempX = imageDimensionX;
                int imageSizeTempY = imageDimensionX;
                
                string treatmentNameBack = loadImageTreatName;
                
                ifstream fin;
                
                int treatFind = 0;
                string getString;
                
                int *fovPositionHoldTemp = new int [treatmentNameDisplayCount*2+50];
                int *fovStartEnd = new int [treatmentNameDisplayCount*4+50];
                int *boarderData = new int [treatmentNameDisplayCount*5+50];
                
                int fovPositionHoldTempCount = 0;
                
                if (processMode == 5 || processMode == 13 || processMode == 7) fin.open(fovPositionTempPath.c_str(), ios::in);
                else fin.open(fovPositionPath.c_str(), ios::in);
                
                if (fin.is_open()){
                    do{
                        
                        getline(fin, getString);
                        
                        if (treatmentNameBack == getString && treatFind == 0) treatFind = 1;
                        else if (getString != "ND" && treatFind == 1){
                            treatFind = 2;
                        }
                        else if (getString != "ND" && treatFind == 2){
                            fovPositionHoldTemp [fovPositionHoldTempCount] = atoi(getString.c_str()), fovPositionHoldTempCount++;
                        }
                        else if (getString == "ND" && treatFind == 2) treatFind = 3;
                        
                    } while (getString != "");
                    
                    fin.close();
                    
                    for (int counter2 = 0; counter2 < fovPositionHoldTempCount/2; counter2++){
                        fovStartEnd [counter2*4] = fovPositionHoldTemp [counter2*2];
                        fovStartEnd [counter2*4+1] = fovPositionHoldTemp [counter2*2]+imageSizeTempX-1;
                        fovStartEnd [counter2*4+2] = fovPositionHoldTemp [counter2*2+1];
                        fovStartEnd [counter2*4+3] = fovPositionHoldTemp [counter2*2+1]+imageSizeTempY-1;
                    }
                    
                    //for (int counterA = 0; counterA < fovNoForProcess; counterA++){
                    //    cout<<counterA<<" "<<fovStartEnd [counterA*4]<<" "<<fovStartEnd [counterA*4+1]<<" "<<fovStartEnd [counterA*4+2]<<" "<<fovStartEnd [counterA*4+3]<<" starEnd"<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < fovNoForProcess*5; counter2++) boarderData [counter2] = 0;
                    
                    int hitCount = 0;
                    
                    for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                        for (int counter3 = 0; counter3 < fovNoForProcess; counter3++){
                            if (counter2 != counter3){
                                boarderData [counter2*5] = counter2+1;
                                hitCount = 0;
                                
                                for (int counter4 = fovStartEnd [counter2*4]; counter4 <= fovStartEnd [counter2*4+1]; counter4++){
                                    if (fovStartEnd [counter3*4] <= counter4 && fovStartEnd [counter3*4+1] >= counter4){
                                        hitCount++;
                                    }
                                }
                                
                                if (hitCount/(double)imageSizeTempY > 0.8){
                                    if (fovStartEnd [counter3*4+2] >= fovStartEnd [counter2*4+2] && fovStartEnd [counter3*4+2] <= fovStartEnd [counter2*4+3]){ //-----Down-----
                                        boarderData [counter2*5+2] = counter3+1;
                                    }
                                    else if (fovStartEnd [counter3*4+3] >= fovStartEnd [counter2*4+2] && fovStartEnd [counter3*4+3] <= fovStartEnd [counter2*4+3]){ //-----Up-----
                                        boarderData [counter2*5+1] = counter3+1;
                                    }
                                }
                                
                                hitCount = 0;
                                
                                for (int counter4 = fovStartEnd [counter2*4+2]; counter4 <= fovStartEnd [counter2*4+3]; counter4++){
                                    if (fovStartEnd [counter3*4+2] <= counter4 && fovStartEnd [counter3*4+3] >= counter4){
                                        hitCount++;
                                    }
                                }
                                
                                if (hitCount/(double)imageSizeTempY > 0.8){
                                    if (fovStartEnd [counter3*4] >= fovStartEnd [counter2*4] && fovStartEnd [counter3*4] <= fovStartEnd [counter2*4+1]){ //-----Right-----
                                        boarderData [counter2*5+3] = counter3+1;
                                    }
                                    else if (fovStartEnd [counter3*4+1] >= fovStartEnd [counter2*4] && fovStartEnd [counter3*4+1] <= fovStartEnd [counter2*4+1]){ //-----Left-----
                                        boarderData [counter2*5+4] = counter3+1;
                                    }
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < fovNoForProcess; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<boarderData [counterA*5+counterB];
                    //    cout<<" boarderData "<<counterA+1<<endl;
                    //}
                    
                    int leftTopFov = 0;
                    
                    for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                        if (boarderData [counter2*5+1] == 0 && boarderData [counter2*5+4] == 0){
                            leftTopFov = counter2+1;
                            break;
                        }
                    }
                    
                    int terminationFlag = 0;
                    int horizontalDimension = 0;
                    int currentFov = leftTopFov;
                    
                    //-----Right to left-----
                    do{
                        
                        terminationFlag = 0;
                        
                        for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                            if (currentFov == counter2+1){
                                currentFov = boarderData [counter2*5+3];
                                horizontalDimension++;
                                terminationFlag = 1;
                            }
                        }
                        
                    } while (terminationFlag == 1);
                    
                    int verticalDimension = 0;
                    currentFov = leftTopFov;
                    
                    //-----Top to bottom-----
                    do{
                        
                        terminationFlag = 0;
                        
                        for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                            if (currentFov == counter2+1){
                                currentFov = boarderData [counter2*5+2];
                                verticalDimension++;
                                terminationFlag = 1;
                            }
                        }
                        
                    } while (terminationFlag == 1);
                    
                    if (horizontalDimension > 2 && verticalDimension > 2){
                        int **fovNoMap = new int *[verticalDimension+2];
                        
                        for (int counter2 = 0; counter2 < verticalDimension+1; counter2++){
                            fovNoMap [counter2] = new int [horizontalDimension+2];
                        }
                        
                        for (int counter2 = 0; counter2 < verticalDimension+1; counter2++){
                            for (int counter3 = 0; counter3 < horizontalDimension+1; counter3++){
                                fovNoMap [counter2][counter3] = 0;
                            }
                        }
                        
                        int dimensionCount = 1;
                        int verticalCount = 1;
                        int currentVerticalFov = leftTopFov;
                        
                        currentFov = leftTopFov;
                        fovNoMap [1][1] = leftTopFov;
                        
                        //-----Top Center-----
                        do{
                            
                            terminationFlag = 0;
                            
                            for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                                if (currentFov == counter2+1){
                                    dimensionCount++;
                                    
                                    if (boarderData [counter2*5+3] != 0){
                                        fovNoMap [verticalCount][dimensionCount] = boarderData [counter2*5+3];
                                        currentFov = boarderData [counter2*5+3];
                                        terminationFlag = 1;
                                    }
                                }
                            }
                            
                            if (terminationFlag == 0){
                                for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                                    if (currentVerticalFov == counter2+1){
                                        if (boarderData [counter2*5+2] != 0){
                                            dimensionCount = 1;
                                            verticalCount++;
                                            currentVerticalFov = boarderData [counter2*5+2];
                                            currentFov = boarderData [counter2*5+2];
                                            
                                            fovNoMap [verticalCount][dimensionCount] = boarderData [counter2*5+2];
                                            terminationFlag = 1;
                                            
                                            break;
                                        }
                                    }
                                }
                            }
                            
                        } while (terminationFlag == 1);
                        
                        //for (int counterA = 1; counterA <= verticalDimension; counterA++){
                        //    for (int counterB = 1; counterB <= horizontalDimension; counterB++) cout<<" "<<fovNoMap [counterA][counterB];
                        //    cout<<" fovNoMap "<<counterA+1<<endl;
                        //}
                        
                        string treatNameTemp2;
                        string fovName2;
                        string contrastDataTemp;
                        string extract1;
                        string extract2;
                        string fovPositionHead;
                        
                        if ((int)loadImageTreatName.find("CH") != -1){
                            fovPositionHead = loadImageTreatName.substr(loadImageTreatName.find("CH"))+"-";
                        }
                        else fovPositionHead = "FOV";
                        
                        int *fovNoSelect = new int [10];
                        
                        for (int counter2 = 0; counter2 < 10; counter2++) fovNoSelect [counter2] = 0;
                        
                        int horizontalPosition = 0;
                        int verticalPosition = 0;
                        
                        for (int counter1 = 1; counter1 <= verticalDimension; counter1++){
                            for (int counter2 = 1; counter2 <= horizontalDimension; counter2++){
                                if (fovNoMap [counter1][counter2] == currentOriginalNo){
                                    horizontalPosition = counter2;
                                    verticalPosition = counter1;
                                }
                            }
                        }
                        
                        //cout<<fovNoSelect [0]<<" "<<fovNoSelect [1]<<" "<<fovNoSelect [2]<<" "<<fovNoSelect [3]<<" "<<fovNoSelect [4]<<" "<<fovNoSelect [5]<<" "<<fovNoSelect [6]<<" "<<fovNoSelect [7]<<" "<<fovNoSelect [8]<<" fov"<<endl;
                        
                        fovNoSelect [0] = currentOriginalNo;
                        
                        if (horizontalPosition-1 >= 1) fovNoSelect [1] = fovNoMap [verticalPosition][horizontalPosition-1];
                        if (horizontalPosition+1 <= horizontalDimension) fovNoSelect [2] = fovNoMap [verticalPosition][horizontalPosition+1];
                        if (verticalPosition-1 >= 1) fovNoSelect [3] = fovNoMap [verticalPosition-1][horizontalPosition];
                        if (verticalPosition+1 <= verticalDimension) fovNoSelect [4] = fovNoMap [verticalPosition+1][horizontalPosition];
                        if (horizontalPosition-1 >= 1 && verticalPosition-1 >= 1) fovNoSelect [5] = fovNoMap [verticalPosition-1][horizontalPosition-1];
                        if (horizontalPosition-1 >= 1 && verticalPosition+1 <= verticalDimension) fovNoSelect [6] = fovNoMap [verticalPosition+1][horizontalPosition-1];
                        if (horizontalPosition+1 <= horizontalDimension && verticalPosition-1 >= 1) fovNoSelect [7] = fovNoMap [verticalPosition-1][horizontalPosition+1];
                        if (horizontalPosition+1 <= horizontalDimension && verticalPosition+1 <= verticalDimension) fovNoSelect [8] = fovNoMap [verticalPosition+1][horizontalPosition+1];
                        
                        string backPageNo = to_string(backgroundDisplayPage);
                        
                        treatFind = 0;
                        int findFlag = 0;
                        
                        for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++){
                            treatNameTemp2 = arrayTreatmentNameDisplay [counter2];
                            fovName2 = arrayFOVNameDisplay [counter2];
                            
                            if (treatNameTemp2 == loadImageTreatName && fovName2 != "ND" && treatFind == 0){
                                treatFind = 1;
                                
                                findFlag = 0;
                                
                                for (int counter3 = 0; counter3 < 10; counter3++){
                                    if (fovPositionHead+to_string(fovNoSelect [counter3]) == fovName2){
                                        findFlag = 1;
                                        break;
                                    }
                                }
                                
                                if (findFlag == 1){
                                    contrastDataTemp = arrayTableDisplay [counter2*5+2];
                                    extract1 = contrastDataTemp.substr(0, contrastDataTemp.find(":"));
                                    extract2 = contrastDataTemp.substr(contrastDataTemp.find("~"));
                                    extract1 = extract1+":"+backPageNo+extract2;
                                    
                                    arrayTableDisplay [counter2*5+2] = extract1;
                                }
                            }
                            else if (treatNameTemp2 == "ND" && fovName2 != "ND" && treatFind == 1){
                                findFlag = 0;
                                
                                for (int counter3 = 0; counter3 < 10; counter3++){
                                    if (fovPositionHead+to_string(fovNoSelect [counter3]) == fovName2){
                                        findFlag = 1;
                                        break;
                                    }
                                }
                                
                                if (findFlag == 1){
                                    contrastDataTemp = arrayTableDisplay [counter2*5+2];
                                    extract1 = contrastDataTemp.substr(0, contrastDataTemp.find(":"));
                                    extract2 = contrastDataTemp.substr(contrastDataTemp.find("~"));
                                    extract1 = extract1+":"+backPageNo+extract2;
                                    
                                    arrayTableDisplay [counter2*5+2] = extract1;
                                }
                            }
                            else if (((treatNameTemp2 != "ND" && fovName2 != "ND") || (treatNameTemp2 == "ND" && fovName2 == "ND")) && treatFind == 1){
                                treatFind = 2;
                            }
                        }
                        
                        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                            contrastCurrentHold [counter1] = arrayTableDisplay [counter1*5+2];
                        }
                        
                        for (int counter2 = 0; counter2 < verticalDimension+1; counter2++){
                            delete [] fovNoMap [counter2];
                        }
                        
                        delete [] fovNoMap;
                        delete [] fovNoSelect;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        tableViewCall = 1;
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Perform Set Condition"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                
                delete [] fovPositionHoldTemp;
                delete [] fovStartEnd;
                delete [] boarderData;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Treatment Not Selected"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        //-----Set to R2-----
        if (keyCode == 46){
            if (loadImageTreatName != ""){
                int fovNoForProcess = loadImageFOVNo;
                int imageSizeTempX = imageDimensionX;
                int imageSizeTempY = imageDimensionY;
                
                string treatmentNameBack = loadImageTreatName;
                
                ifstream fin;
                
                int treatFind = 0;
                string getString;
                
                int *fovPositionHoldTemp = new int [treatmentNameDisplayCount*2+50];
                int *fovStartEnd = new int [treatmentNameDisplayCount*4+50];
                int *boarderData = new int [treatmentNameDisplayCount*5+50];
                
                int fovPositionHoldTempCount = 0;
                
                if (processMode == 5 || processMode == 13 || processMode == 7) fin.open(fovPositionTempPath.c_str(), ios::in);
                else fin.open(fovPositionPath.c_str(), ios::in);
                
                if (fin.is_open()){
                    do{
                        
                        getline(fin, getString);
                        
                        if (treatmentNameBack == getString && treatFind == 0) treatFind = 1;
                        else if (getString != "ND" && treatFind == 1){
                            treatFind = 2;
                        }
                        else if (getString != "ND" && treatFind == 2){
                            fovPositionHoldTemp [fovPositionHoldTempCount] = atoi(getString.c_str()), fovPositionHoldTempCount++;
                        }
                        else if (getString == "ND" && treatFind == 2) treatFind = 3;
                        
                    } while (getString != "");
                    
                    fin.close();
                    
                    for (int counter2 = 0; counter2 < fovPositionHoldTempCount/2; counter2++){
                        fovStartEnd [counter2*4] = fovPositionHoldTemp [counter2*2];
                        fovStartEnd [counter2*4+1] = fovPositionHoldTemp [counter2*2]+imageSizeTempX-1;
                        fovStartEnd [counter2*4+2] = fovPositionHoldTemp [counter2*2+1];
                        fovStartEnd [counter2*4+3] = fovPositionHoldTemp [counter2*2+1]+imageSizeTempY-1;
                    }
                    
                    //for (int counterA = 0; counterA < fovNoForProcess; counterA++){
                    //    cout<<counterA<<" "<<fovStartEnd [counterA*4]<<" "<<fovStartEnd [counterA*4+1]<<" "<<fovStartEnd [counterA*4+2]<<" "<<fovStartEnd [counterA*4+3]<<" starEnd"<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < fovNoForProcess*5; counter2++) boarderData [counter2] = 0;
                    
                    int hitCount = 0;
                    
                    for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                        for (int counter3 = 0; counter3 < fovNoForProcess; counter3++){
                            if (counter2 != counter3){
                                boarderData [counter2*5] = counter2+1;
                                hitCount = 0;
                                
                                for (int counter4 = fovStartEnd [counter2*4]; counter4 <= fovStartEnd [counter2*4+1]; counter4++){
                                    if (fovStartEnd [counter3*4] <= counter4 && fovStartEnd [counter3*4+1] >= counter4){
                                        hitCount++;
                                    }
                                }
                                
                                if (hitCount/(double)imageSizeTempY > 0.8){
                                    if (fovStartEnd [counter3*4+2] >= fovStartEnd [counter2*4+2] && fovStartEnd [counter3*4+2] <= fovStartEnd [counter2*4+3]){ //-----Down-----
                                        boarderData [counter2*5+2] = counter3+1;
                                    }
                                    else if (fovStartEnd [counter3*4+3] >= fovStartEnd [counter2*4+2] && fovStartEnd [counter3*4+3] <= fovStartEnd [counter2*4+3]){ //-----Up-----
                                        boarderData [counter2*5+1] = counter3+1;
                                    }
                                }
                                
                                hitCount = 0;
                                
                                for (int counter4 = fovStartEnd [counter2*4+2]; counter4 <= fovStartEnd [counter2*4+3]; counter4++){
                                    if (fovStartEnd [counter3*4+2] <= counter4 && fovStartEnd [counter3*4+3] >= counter4){
                                        hitCount++;
                                    }
                                }
                                
                                if (hitCount/(double)imageSizeTempY > 0.8){
                                    if (fovStartEnd [counter3*4] >= fovStartEnd [counter2*4] && fovStartEnd [counter3*4] <= fovStartEnd [counter2*4+1]){ //-----Right-----
                                        boarderData [counter2*5+3] = counter3+1;
                                    }
                                    else if (fovStartEnd [counter3*4+1] >= fovStartEnd [counter2*4] && fovStartEnd [counter3*4+1] <= fovStartEnd [counter2*4+1]){ //-----Left-----
                                        boarderData [counter2*5+4] = counter3+1;
                                    }
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < fovNoForProcess; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<boarderData [counterA*5+counterB];
                    //    cout<<" boarderData "<<counterA+1<<endl;
                    //}
                    
                    int leftTopFov = 0;
                    
                    for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                        if (boarderData [counter2*5+1] == 0 && boarderData [counter2*5+4] == 0){
                            leftTopFov = counter2+1;
                            break;
                        }
                    }
                    
                    int terminationFlag = 0;
                    int horizontalDimension = 0;
                    int currentFov = leftTopFov;
                    
                    //-----Right to left-----
                    do{
                        
                        terminationFlag = 0;
                        
                        for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                            if (currentFov == counter2+1){
                                currentFov = boarderData [counter2*5+3];
                                horizontalDimension++;
                                terminationFlag = 1;
                            }
                        }
                        
                    } while (terminationFlag == 1);
                    
                    int verticalDimension = 0;
                    currentFov = leftTopFov;
                    
                    //-----Top to bottom-----
                    do{
                        
                        terminationFlag = 0;
                        
                        for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                            if (currentFov == counter2+1){
                                currentFov = boarderData [counter2*5+2];
                                verticalDimension++;
                                terminationFlag = 1;
                            }
                        }
                        
                    } while (terminationFlag == 1);
                    
                    if (horizontalDimension > 2 && verticalDimension > 2){
                        int **fovNoMap = new int *[verticalDimension+2];
                        
                        for (int counter2 = 0; counter2 < verticalDimension+1; counter2++){
                            fovNoMap [counter2] = new int [horizontalDimension+2];
                        }
                        
                        for (int counter2 = 0; counter2 < verticalDimension+1; counter2++){
                            for (int counter3 = 0; counter3 < horizontalDimension+1; counter3++){
                                fovNoMap [counter2][counter3] = 0;
                            }
                        }
                        
                        int dimensionCount = 1;
                        int verticalCount = 1;
                        int currentVerticalFov = leftTopFov;
                        
                        currentFov = leftTopFov;
                        fovNoMap [1][1] = leftTopFov;
                        
                        //-----Top Center-----
                        do{
                            
                            terminationFlag = 0;
                            
                            for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                                if (currentFov == counter2+1){
                                    dimensionCount++;
                                    
                                    if (boarderData [counter2*5+3] != 0){
                                        fovNoMap [verticalCount][dimensionCount] = boarderData [counter2*5+3];
                                        currentFov = boarderData [counter2*5+3];
                                        terminationFlag = 1;
                                    }
                                }
                            }
                            
                            if (terminationFlag == 0){
                                for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                                    if (currentVerticalFov == counter2+1){
                                        if (boarderData [counter2*5+2] != 0){
                                            dimensionCount = 1;
                                            verticalCount++;
                                            currentVerticalFov = boarderData [counter2*5+2];
                                            currentFov = boarderData [counter2*5+2];
                                            
                                            fovNoMap [verticalCount][dimensionCount] = boarderData [counter2*5+2];
                                            terminationFlag = 1;
                                            
                                            break;
                                        }
                                    }
                                }
                            }
                            
                        } while (terminationFlag == 1);
                        
                        //for (int counterA = 1; counterA <= verticalDimension; counterA++){
                        //    for (int counterB = 1; counterB <= horizontalDimension; counterB++) cout<<" "<<fovNoMap [counterA][counterB];
                        //    cout<<" fovNoMap "<<counterA+1<<endl;
                        //}
                        
                        string treatNameTemp2;
                        string fovName2;
                        string contrastDataTemp;
                        string extract1;
                        string extract2;
                        string fovPositionHead;
                        
                        if ((int)loadImageTreatName.find("CH") != -1){
                            fovPositionHead = loadImageTreatName.substr(loadImageTreatName.find("CH"))+"-";
                        }
                        else fovPositionHead = "FOV";
                        
                        int *fovNoSelect = new int [26];
                        
                        for (int counter2 = 0; counter2 < 26; counter2++) fovNoSelect [counter2] = 0;
                        
                        int horizontalPosition = 0;
                        int verticalPosition = 0;
                        
                        for (int counter1 = 1; counter1 <= verticalDimension; counter1++){
                            for (int counter2 = 1; counter2 <= horizontalDimension; counter2++){
                                if (fovNoMap [counter1][counter2] == currentOriginalNo){
                                    horizontalPosition = counter2;
                                    verticalPosition = counter1;
                                }
                            }
                        }
                        
                        fovNoSelect [0] = currentOriginalNo;
                        
                        if (horizontalPosition-1 >= 1) fovNoSelect [1] = fovNoMap [verticalPosition][horizontalPosition-1];
                        if (horizontalPosition+1 <= horizontalDimension) fovNoSelect [2] = fovNoMap [verticalPosition][horizontalPosition+1];
                        if (verticalPosition-1 >= 1) fovNoSelect [3] = fovNoMap [verticalPosition-1][horizontalPosition];
                        if (verticalPosition+1 <= verticalDimension) fovNoSelect [4] = fovNoMap [verticalPosition+1][horizontalPosition];
                        if (horizontalPosition-1 >= 1 && verticalPosition-1 >= 1) fovNoSelect [5] = fovNoMap [verticalPosition-1][horizontalPosition-1];
                        if (horizontalPosition-1 >= 1 && verticalPosition+1 <= verticalDimension) fovNoSelect [6] = fovNoMap [verticalPosition+1][horizontalPosition-1];
                        if (horizontalPosition+1 <= horizontalDimension && verticalPosition-1 >= 1) fovNoSelect [7] = fovNoMap [verticalPosition-1][horizontalPosition+1];
                        if (horizontalPosition+1 <= horizontalDimension && verticalPosition+1 <= verticalDimension) fovNoSelect [8] = fovNoMap [verticalPosition+1][horizontalPosition+1];
                        if (horizontalPosition-2 >= 1) fovNoSelect [9] = fovNoMap [verticalPosition][horizontalPosition-2];
                        if (horizontalPosition+2 <= horizontalDimension) fovNoSelect [10] = fovNoMap [verticalPosition][horizontalPosition+2];
                        if (verticalPosition-2 >= 1) fovNoSelect [11] = fovNoMap [verticalPosition-2][horizontalPosition];
                        if (verticalPosition+2 <= verticalDimension) fovNoSelect [12] = fovNoMap [verticalPosition+2][horizontalPosition];
                        if (horizontalPosition-2 >= 1 && verticalPosition-1 >= 1) fovNoSelect [13] = fovNoMap [verticalPosition-1][horizontalPosition-2];
                        if (horizontalPosition-2 >= 1 && verticalPosition+1 <= verticalDimension) fovNoSelect [14] = fovNoMap [verticalPosition+1][horizontalPosition-2];
                        if (horizontalPosition+2 <= horizontalDimension && verticalPosition-1 >= 1) fovNoSelect [15] = fovNoMap [verticalPosition-1][horizontalPosition+2];
                        if (horizontalPosition+2 <= horizontalDimension && verticalPosition+1 <= verticalDimension) fovNoSelect [16] = fovNoMap [verticalPosition+1][horizontalPosition+2];
                        if (horizontalPosition-1 >= 1 && verticalPosition-2 >= 1) fovNoSelect [17] = fovNoMap [verticalPosition-2][horizontalPosition-1];
                        if (horizontalPosition+1 <= horizontalDimension && verticalPosition-2 >= 1) fovNoSelect [18] = fovNoMap [verticalPosition-2][horizontalPosition+1];
                        if (horizontalPosition-1 >= 1 && verticalPosition+2 <= verticalDimension) fovNoSelect [19] = fovNoMap [verticalPosition+2][horizontalPosition-1];
                        if (horizontalPosition+1 <= horizontalDimension && verticalPosition+2 <= verticalDimension) fovNoSelect [20] = fovNoMap [verticalPosition+2][horizontalPosition+1];
                        if (horizontalPosition-2 >= 1 && verticalPosition-2 >= 1) fovNoSelect [21] = fovNoMap [verticalPosition-2][horizontalPosition-2];
                        if (horizontalPosition-2 >= 1 && verticalPosition+2 <= verticalDimension) fovNoSelect [22] = fovNoMap [verticalPosition+2][horizontalPosition-2];
                        if (horizontalPosition+2 <= horizontalDimension && verticalPosition-2 >= 1) fovNoSelect [23] = fovNoMap [verticalPosition-2][horizontalPosition+2];
                        if (horizontalPosition+2 <= horizontalDimension && verticalPosition+2 <= verticalDimension) fovNoSelect [24] = fovNoMap [verticalPosition+2][horizontalPosition+2];
                        
                        string backPageNo = to_string(backgroundDisplayPage);
                        
                        treatFind = 0;
                        int findFlag = 0;
                        
                        for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++){
                            treatNameTemp2 = arrayTreatmentNameDisplay [counter2];
                            fovName2 = arrayFOVNameDisplay [counter2];
                            
                            if (treatNameTemp2 == loadImageTreatName && fovName2 != "ND" && treatFind == 0){
                                treatFind = 1;
                                
                                findFlag = 0;
                                
                                for (int counter3 = 0; counter3 < 26; counter3++){
                                    if (fovPositionHead+to_string(fovNoSelect [counter3]) == fovName2){
                                        findFlag = 1;
                                        break;
                                    }
                                }
                                
                                if (findFlag == 1){
                                    contrastDataTemp = arrayTableDisplay [counter2*5+2];
                                    extract1 = contrastDataTemp.substr(0, contrastDataTemp.find(":"));
                                    extract2 = contrastDataTemp.substr(contrastDataTemp.find("~"));
                                    extract1 = extract1+":"+backPageNo+extract2;
                                    
                                    arrayTableDisplay [counter2*5+2] = extract1;
                                }
                            }
                            else if (treatNameTemp2 == "ND" && fovName2 != "ND" && treatFind == 1){
                                findFlag = 0;
                                
                                for (int counter3 = 0; counter3 < 26; counter3++){
                                    if (fovPositionHead+to_string(fovNoSelect [counter3]) == fovName2){
                                        findFlag = 1;
                                        break;
                                    }
                                }
                                
                                if (findFlag == 1){
                                    contrastDataTemp = arrayTableDisplay [counter2*5+2];
                                    extract1 = contrastDataTemp.substr(0, contrastDataTemp.find(":"));
                                    extract2 = contrastDataTemp.substr(contrastDataTemp.find("~"));
                                    extract1 = extract1+":"+backPageNo+extract2;
                                    
                                    arrayTableDisplay [counter2*5+2] = extract1;
                                }
                            }
                            else if (((treatNameTemp2 != "ND" && fovName2 != "ND") || (treatNameTemp2 == "ND" && fovName2 == "ND")) && treatFind == 1){
                                treatFind = 2;
                            }
                        }
                        
                        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                            contrastCurrentHold [counter1] = arrayTableDisplay [counter1*5+2];
                        }
                        
                        for (int counter2 = 0; counter2 < verticalDimension+1; counter2++){
                            delete [] fovNoMap [counter2];
                        }
                        
                        delete [] fovNoMap;
                        delete [] fovNoSelect;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        tableViewCall = 1;
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Perform Set Condition"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                
                delete [] fovPositionHoldTemp;
                delete [] fovStartEnd;
                delete [] boarderData;
                
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Treatment Not Selected"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        //-----Set clear-----
        if (keyCode == 8){
            if (loadImageTreatName != ""){
                string treatNameTemp2;
                string fovName2;
                string contrastDataTemp;
                string extract1;
                string extract2;
                string fovPosition;
                
                if ((int)loadImageTreatName.find("CH") != -1){
                    fovPosition = loadImageTreatName.substr(loadImageTreatName.find("CH"))+"-"+to_string(currentOriginalNo);
                }
                else fovPosition = "FOV"+to_string(currentOriginalNo);
                
                int treatFind = 0;
                
                for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++){
                    treatNameTemp2 = arrayTreatmentNameDisplay [counter2];
                    fovName2 = arrayFOVNameDisplay [counter2];
                    
                    if (treatNameTemp2 == loadImageTreatName && fovName2 != "ND" && treatFind == 0){
                        treatFind = 1;
                        
                        contrastDataTemp = arrayTableDisplay [counter2*5+2];
                        extract1 = contrastDataTemp.substr(0, contrastDataTemp.find(":"));
                        extract2 = contrastDataTemp.substr(contrastDataTemp.find("~"));
                        extract1 = extract1+":0"+extract2;
                        arrayTableDisplay [counter2*5+2] = extract1;
                    }
                    else if (treatNameTemp2 == "ND" && fovName2 != "ND" && treatFind == 1){
                        contrastDataTemp = arrayTableDisplay [counter2*5+2];
                        extract1 = contrastDataTemp.substr(0, contrastDataTemp.find(":"));
                        extract2 = contrastDataTemp.substr(contrastDataTemp.find("~"));
                        extract1 = extract1+":0"+extract2;
                        arrayTableDisplay [counter2*5+2] = extract1;
                    }
                    else if (((treatNameTemp2 != "ND" && fovName2 != "ND") || (treatNameTemp2 == "ND" && fovName2 == "ND")) && treatFind == 1){
                        treatFind = 2;
                    }
                }
                
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    contrastCurrentHold [counter1] = arrayTableDisplay [counter1*5+2];
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                tableViewCall = 1;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Treatment Not Selected"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        //-----Set to horizontal-----
        if (keyCode == 4){
            if (loadImageTreatName != ""){
                int fovNoForProcess = loadImageFOVNo;
                int imageSizeTempX = imageDimensionX;
                int imageSizeTempY = imageDimensionY;
                string treatmentNameBack = loadImageTreatName;
                
                ifstream fin;
                
                int treatFind = 0;
                string getString;
                
                int *fovPositionHoldTemp = new int [treatmentNameDisplayCount*2+50];
                int *fovStartEnd = new int [treatmentNameDisplayCount*4+50];
                int *boarderData = new int [treatmentNameDisplayCount*5+50];
                
                int fovPositionHoldTempCount = 0;
                
                if (processMode == 5 || processMode == 13 || processMode == 7) fin.open(fovPositionTempPath.c_str(), ios::in);
                else fin.open(fovPositionPath.c_str(), ios::in);
                
                if (fin.is_open()){
                    do{
                        
                        getline(fin, getString);
                        
                        if (treatmentNameBack == getString && treatFind == 0) treatFind = 1;
                        else if (getString != "ND" && treatFind == 1){
                            treatFind = 2;
                        }
                        else if (getString != "ND" && treatFind == 2){
                            fovPositionHoldTemp [fovPositionHoldTempCount] = atoi(getString.c_str()), fovPositionHoldTempCount++;
                        }
                        else if (getString == "ND" && treatFind == 2) treatFind = 3;
                        
                    } while (getString != "");
                    
                    fin.close();
                    
                    //for (int counterA = 0; counterA < fovPositionHoldTempCount/2; counterA++){
                    //    cout<<counterA<<" "<<fovPositionHoldTemp [counterA*2]<<" "<<fovPositionHoldTemp [counterA*2+1]<<" fovPosition"<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < fovPositionHoldTempCount/2; counter2++){
                        fovStartEnd [counter2*4] = fovPositionHoldTemp [counter2*2];
                        fovStartEnd [counter2*4+1] = fovPositionHoldTemp [counter2*2]+imageSizeTempX-1;
                        fovStartEnd [counter2*4+2] = fovPositionHoldTemp [counter2*2+1];
                        fovStartEnd [counter2*4+3] = fovPositionHoldTemp [counter2*2+1]+imageSizeTempY-1;
                    }
                    
                    //for (int counterA = 0; counterA < fovNoForProcess; counterA++){
                    //    cout<<counterA<<" "<<fovStartEnd [counterA*4]<<" "<<fovStartEnd [counterA*4+1]<<" "<<fovStartEnd [counterA*4+2]<<" "<<fovStartEnd [counterA*4+3]<<" starEnd"<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < fovNoForProcess*5; counter2++) boarderData [counter2] = 0;
                    
                    int hitCount = 0;
                    
                    for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                        for (int counter3 = 0; counter3 < fovNoForProcess; counter3++){
                            if (counter2 != counter3){
                                boarderData [counter2*5] = counter2+1;
                                hitCount = 0;
                                
                                for (int counter4 = fovStartEnd [counter2*4]; counter4 <= fovStartEnd [counter2*4+1]; counter4++){
                                    if (fovStartEnd [counter3*4] <= counter4 && fovStartEnd [counter3*4+1] >= counter4){
                                        hitCount++;
                                    }
                                }
                                
                                if (hitCount/(double)imageSizeTempY > 0.8){
                                    if (fovStartEnd [counter3*4+2] >= fovStartEnd [counter2*4+2] && fovStartEnd [counter3*4+2] <= fovStartEnd [counter2*4+3]){ //-----Down-----
                                        boarderData [counter2*5+2] = counter3+1;
                                    }
                                    else if (fovStartEnd [counter3*4+3] >= fovStartEnd [counter2*4+2] && fovStartEnd [counter3*4+3] <= fovStartEnd [counter2*4+3]){ //-----Up-----
                                        boarderData [counter2*5+1] = counter3+1;
                                    }
                                }
                                
                                hitCount = 0;
                                
                                for (int counter4 = fovStartEnd [counter2*4+2]; counter4 <= fovStartEnd [counter2*4+3]; counter4++){
                                    if (fovStartEnd [counter3*4+2] <= counter4 && fovStartEnd [counter3*4+3] >= counter4){
                                        hitCount++;
                                    }
                                }
                                
                                if (hitCount/(double)imageSizeTempY > 0.8){
                                    if (fovStartEnd [counter3*4] >= fovStartEnd [counter2*4] && fovStartEnd [counter3*4] <= fovStartEnd [counter2*4+1]){ //-----Right-----
                                        boarderData [counter2*5+3] = counter3+1;
                                    }
                                    else if (fovStartEnd [counter3*4+1] >= fovStartEnd [counter2*4] && fovStartEnd [counter3*4+1] <= fovStartEnd [counter2*4+1]){ //-----Left-----
                                        boarderData [counter2*5+4] = counter3+1;
                                    }
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < fovNoForProcess; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<boarderData [counterA*5+counterB];
                    //    cout<<" boarderData "<<counterA+1<<endl;
                    //}
                    
                    int leftTopFov = 0;
                    
                    for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                        if (boarderData [counter2*5+1] == 0 && boarderData [counter2*5+4] == 0){
                            leftTopFov = counter2+1;
                            break;
                        }
                    }
                    
                    int terminationFlag = 0;
                    int horizontalDimension = 0;
                    int currentFov = leftTopFov;
                    
                    //-----Right to left-----
                    do{
                        
                        terminationFlag = 0;
                        
                        for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                            if (currentFov == counter2+1){
                                currentFov = boarderData [counter2*5+3];
                                horizontalDimension++;
                                terminationFlag = 1;
                            }
                        }
                        
                    } while (terminationFlag == 1);
                    
                    int verticalDimension = 0;
                    currentFov = leftTopFov;
                    
                    //-----Top to bottom-----
                    do{
                        
                        terminationFlag = 0;
                        
                        for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                            if (currentFov == counter2+1){
                                currentFov = boarderData [counter2*5+2];
                                verticalDimension++;
                                terminationFlag = 1;
                            }
                        }
                        
                    } while (terminationFlag == 1);
                    
                    if (horizontalDimension > 2 && verticalDimension > 2){
                        int **fovNoMap = new int *[verticalDimension+2];
                        
                        for (int counter2 = 0; counter2 < verticalDimension+1; counter2++){
                            fovNoMap [counter2] = new int [horizontalDimension+2];
                        }
                        
                        for (int counter2 = 0; counter2 < verticalDimension+1; counter2++){
                            for (int counter3 = 0; counter3 < horizontalDimension+1; counter3++){
                                fovNoMap [counter2][counter3] = 0;
                            }
                        }
                        
                        int dimensionCount = 1;
                        int verticalCount = 1;
                        int currentVerticalFov = leftTopFov;
                        
                        currentFov = leftTopFov;
                        fovNoMap [1][1] = leftTopFov;
                        
                        //-----Top Center-----
                        do{
                            
                            terminationFlag = 0;
                            
                            for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                                if (currentFov == counter2+1){
                                    dimensionCount++;
                                    
                                    if (boarderData [counter2*5+3] != 0){
                                        fovNoMap [verticalCount][dimensionCount] = boarderData [counter2*5+3];
                                        currentFov = boarderData [counter2*5+3];
                                        terminationFlag = 1;
                                    }
                                }
                            }
                            
                            if (terminationFlag == 0){
                                for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                                    if (currentVerticalFov == counter2+1){
                                        if (boarderData [counter2*5+2] != 0){
                                            dimensionCount = 1;
                                            verticalCount++;
                                            currentVerticalFov = boarderData [counter2*5+2];
                                            currentFov = boarderData [counter2*5+2];
                                            
                                            fovNoMap [verticalCount][dimensionCount] = boarderData [counter2*5+2];
                                            terminationFlag = 1;
                                            
                                            break;
                                        }
                                    }
                                }
                            }
                            
                        } while (terminationFlag == 1);
                        
                        //for (int counterA = 1; counterA <= verticalDimension; counterA++){
                        //    for (int counterB = 1; counterB <= horizontalDimension; counterB++) cout<<" "<<fovNoMap [counterA][counterB];
                        //    cout<<" fovNoMap "<<counterA+1<<endl;
                        //}
                        
                        string treatNameTemp2;
                        string fovName2;
                        string contrastDataTemp;
                        string extract1;
                        string extract2;
                        string fovPositionHead;
                        
                        if ((int)loadImageTreatName.find("CH") != -1){
                            fovPositionHead = loadImageTreatName.substr(loadImageTreatName.find("CH"))+"-";
                        }
                        else fovPositionHead = "FOV";
                        
                        int *fovNoSelect = new int [10];
                        
                        for (int counter2 = 0; counter2 < 10; counter2++) fovNoSelect [counter2] = 0;
                        
                        int horizontalPosition = 0;
                        int verticalPosition = 0;
                        
                        for (int counter1 = 1; counter1 <= verticalDimension; counter1++){
                            for (int counter2 = 1; counter2 <= horizontalDimension; counter2++){
                                if (fovNoMap [counter1][counter2] == currentOriginalNo){
                                    horizontalPosition = counter2;
                                    verticalPosition = counter1;
                                }
                            }
                        }
                        
                        fovNoSelect [0] = currentOriginalNo;
                        
                        if (horizontalPosition-1 >= 1) fovNoSelect [1] = fovNoMap [verticalPosition][horizontalPosition-1];
                        if (horizontalPosition-2 >= 1) fovNoSelect [2] = fovNoMap [verticalPosition][horizontalPosition-2];
                        if (horizontalPosition+1 <= horizontalDimension) fovNoSelect [3] = fovNoMap [verticalPosition][horizontalPosition+1];
                        if (horizontalPosition+2 <= horizontalDimension) fovNoSelect [4] = fovNoMap [verticalPosition][horizontalPosition+2];
                        
                        string backPageNo = to_string(backgroundDisplayPage);
                        
                        treatFind = 0;
                        int findFlag = 0;
                        
                        for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++){
                            treatNameTemp2 = arrayTreatmentNameDisplay [counter2];
                            fovName2 = arrayFOVNameDisplay [counter2];
                            
                            if (treatNameTemp2 == loadImageTreatName && fovName2 != "ND" && treatFind == 0){
                                treatFind = 1;
                                
                                findFlag = 0;
                                
                                for (int counter3 = 0; counter3 < 10; counter3++){
                                    if (fovPositionHead+to_string(fovNoSelect [counter3]) == fovName2){
                                        findFlag = 1;
                                        break;
                                    }
                                }
                                
                                if (findFlag == 1){
                                    contrastDataTemp = arrayTableDisplay [counter2*5+2];
                                    extract1 = contrastDataTemp.substr(0, contrastDataTemp.find(":"));
                                    extract2 = contrastDataTemp.substr(contrastDataTemp.find("~"));
                                    extract1 = extract1+":"+backPageNo+extract2;
                                    
                                    arrayTableDisplay [counter2*5+2] = extract1;
                                }
                            }
                            else if (treatNameTemp2 == "ND" && fovName2 != "ND" && treatFind == 1){
                                findFlag = 0;
                                
                                for (int counter3 = 0; counter3 < 10; counter3++){
                                    if (fovPositionHead+to_string(fovNoSelect [counter3]) == fovName2){
                                        findFlag = 1;
                                        break;
                                    }
                                }
                                
                                if (findFlag == 1){
                                    contrastDataTemp = arrayTableDisplay [counter2*5+2];
                                    extract1 = contrastDataTemp.substr(0, contrastDataTemp.find(":"));
                                    extract2 = contrastDataTemp.substr(contrastDataTemp.find("~"));
                                    extract1 = extract1+":"+backPageNo+extract2;
                                    
                                    arrayTableDisplay [counter2*5+2] = extract1;
                                }
                            }
                            else if (((treatNameTemp2 != "ND" && fovName2 != "ND") || (treatNameTemp2 == "ND" && fovName2 == "ND")) && treatFind == 1){
                                treatFind = 2;
                            }
                        }
                        
                        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                            contrastCurrentHold [counter1] = arrayTableDisplay [counter1*5+2];
                        }
                        
                        for (int counter2 = 0; counter2 < verticalDimension+1; counter2++){
                            delete [] fovNoMap [counter2];
                        }
                        
                        delete [] fovNoMap;
                        delete [] fovNoSelect;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        tableViewCall = 1;
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Perform Set Condition"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                
                delete [] fovPositionHoldTemp;
                delete [] fovStartEnd;
                delete [] boarderData;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Treatment Not Selected"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        //-----Set to vertical-----
        if (keyCode == 9){
            if (loadImageTreatName != ""){
                int fovNoForProcess = loadImageFOVNo;
                int imageSizeTempX = imageDimensionX;
                int imageSizeTempY = imageDimensionY;
                string treatmentNameBack = loadImageTreatName;
                
                ifstream fin;
                
                int treatFind = 0;
                string getString;
                
                int *fovPositionHoldTemp = new int [treatmentNameDisplayCount*2+50];
                int *fovStartEnd = new int [treatmentNameDisplayCount*4+50];
                int *boarderData = new int [treatmentNameDisplayCount*5+50];
                
                int fovPositionHoldTempCount = 0;
                
                if (processMode == 5 || processMode == 13 || processMode == 7) fin.open(fovPositionTempPath.c_str(), ios::in);
                else fin.open(fovPositionPath.c_str(), ios::in);
                
                if (fin.is_open()){
                    do{
                        
                        getline(fin, getString);
                        
                        if (treatmentNameBack == getString && treatFind == 0) treatFind = 1;
                        else if (getString != "ND" && treatFind == 1){
                            treatFind = 2;
                        }
                        else if (getString != "ND" && treatFind == 2){
                            fovPositionHoldTemp [fovPositionHoldTempCount] = atoi(getString.c_str()), fovPositionHoldTempCount++;
                        }
                        else if (getString == "ND" && treatFind == 2) treatFind = 3;
                        
                    } while (getString != "");
                    
                    fin.close();
                    
                    //for (int counterA = 0; counterA < fovPositionHoldTempCount/2; counterA++){
                    //    cout<<counterA<<" "<<fovPositionHoldTemp [counterA*2]<<" "<<fovPositionHoldTemp [counterA*2+1]<<" fovPosition"<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < fovPositionHoldTempCount/2; counter2++){
                        fovStartEnd [counter2*4] = fovPositionHoldTemp [counter2*2];
                        fovStartEnd [counter2*4+1] = fovPositionHoldTemp [counter2*2]+imageSizeTempX-1;
                        fovStartEnd [counter2*4+2] = fovPositionHoldTemp [counter2*2+1];
                        fovStartEnd [counter2*4+3] = fovPositionHoldTemp [counter2*2+1]+imageSizeTempY-1;
                    }
                    
                    //for (int counterA = 0; counterA < fovNoForProcess; counterA++){
                    //    cout<<counterA<<" "<<fovStartEnd [counterA*4]<<" "<<fovStartEnd [counterA*4+1]<<" "<<fovStartEnd [counterA*4+2]<<" "<<fovStartEnd [counterA*4+3]<<" starEnd"<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < fovNoForProcess*5; counter2++) boarderData [counter2] = 0;
                    
                    int hitCount = 0;
                    
                    for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                        for (int counter3 = 0; counter3 < fovNoForProcess; counter3++){
                            if (counter2 != counter3){
                                boarderData [counter2*5] = counter2+1;
                                hitCount = 0;
                                
                                for (int counter4 = fovStartEnd [counter2*4]; counter4 <= fovStartEnd [counter2*4+1]; counter4++){
                                    if (fovStartEnd [counter3*4] <= counter4 && fovStartEnd [counter3*4+1] >= counter4){
                                        hitCount++;
                                    }
                                }
                                
                                if (hitCount/(double)imageSizeTempY > 0.8){
                                    if (fovStartEnd [counter3*4+2] >= fovStartEnd [counter2*4+2] && fovStartEnd [counter3*4+2] <= fovStartEnd [counter2*4+3]){ //-----Down-----
                                        boarderData [counter2*5+2] = counter3+1;
                                    }
                                    else if (fovStartEnd [counter3*4+3] >= fovStartEnd [counter2*4+2] && fovStartEnd [counter3*4+3] <= fovStartEnd [counter2*4+3]){ //-----Up-----
                                        boarderData [counter2*5+1] = counter3+1;
                                    }
                                }
                                
                                hitCount = 0;
                                
                                for (int counter4 = fovStartEnd [counter2*4+2]; counter4 <= fovStartEnd [counter2*4+3]; counter4++){
                                    if (fovStartEnd [counter3*4+2] <= counter4 && fovStartEnd [counter3*4+3] >= counter4){
                                        hitCount++;
                                    }
                                }
                                
                                if (hitCount/(double)imageSizeTempY > 0.8){
                                    if (fovStartEnd [counter3*4] >= fovStartEnd [counter2*4] && fovStartEnd [counter3*4] <= fovStartEnd [counter2*4+1]){ //-----Right-----
                                        boarderData [counter2*5+3] = counter3+1;
                                    }
                                    else if (fovStartEnd [counter3*4+1] >= fovStartEnd [counter2*4] && fovStartEnd [counter3*4+1] <= fovStartEnd [counter2*4+1]){ //-----Left-----
                                        boarderData [counter2*5+4] = counter3+1;
                                    }
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < fovNoForProcess; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<boarderData [counterA*5+counterB];
                    //    cout<<" boarderData "<<counterA+1<<endl;
                    //}
                    
                    int leftTopFov = 0;
                    
                    for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                        if (boarderData [counter2*5+1] == 0 && boarderData [counter2*5+4] == 0){
                            leftTopFov = counter2+1;
                            break;
                        }
                    }
                    
                    int terminationFlag = 0;
                    int horizontalDimension = 0;
                    int currentFov = leftTopFov;
                    
                    //-----Right to left-----
                    do{
                        
                        terminationFlag = 0;
                        
                        for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                            if (currentFov == counter2+1){
                                currentFov = boarderData [counter2*5+3];
                                horizontalDimension++;
                                terminationFlag = 1;
                            }
                        }
                        
                    } while (terminationFlag == 1);
                    
                    int verticalDimension = 0;
                    currentFov = leftTopFov;
                    
                    //-----Top to bottom-----
                    do{
                        
                        terminationFlag = 0;
                        
                        for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                            if (currentFov == counter2+1){
                                currentFov = boarderData [counter2*5+2];
                                verticalDimension++;
                                terminationFlag = 1;
                            }
                        }
                        
                    } while (terminationFlag == 1);
                    
                    if (horizontalDimension > 2 && verticalDimension > 2){
                        int **fovNoMap = new int *[verticalDimension+2];
                        
                        for (int counter2 = 0; counter2 < verticalDimension+1; counter2++){
                            fovNoMap [counter2] = new int [horizontalDimension+2];
                        }
                        
                        for (int counter2 = 0; counter2 < verticalDimension+1; counter2++){
                            for (int counter3 = 0; counter3 < horizontalDimension+1; counter3++){
                                fovNoMap [counter2][counter3] = 0;
                            }
                        }
                        
                        int dimensionCount = 1;
                        int verticalCount = 1;
                        int currentVerticalFov = leftTopFov;
                        
                        currentFov = leftTopFov;
                        fovNoMap [1][1] = leftTopFov;
                        
                        //-----Top Center-----
                        do{
                            
                            terminationFlag = 0;
                            
                            for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                                if (currentFov == counter2+1){
                                    dimensionCount++;
                                    
                                    if (boarderData [counter2*5+3] != 0){
                                        fovNoMap [verticalCount][dimensionCount] = boarderData [counter2*5+3];
                                        currentFov = boarderData [counter2*5+3];
                                        terminationFlag = 1;
                                    }
                                }
                            }
                            
                            if (terminationFlag == 0){
                                for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                                    if (currentVerticalFov == counter2+1){
                                        if (boarderData [counter2*5+2] != 0){
                                            dimensionCount = 1;
                                            verticalCount++;
                                            currentVerticalFov = boarderData [counter2*5+2];
                                            currentFov = boarderData [counter2*5+2];
                                            
                                            fovNoMap [verticalCount][dimensionCount] = boarderData [counter2*5+2];
                                            terminationFlag = 1;
                                            
                                            break;
                                        }
                                    }
                                }
                            }
                            
                        } while (terminationFlag == 1);
                        
                        //for (int counterA = 1; counterA <= verticalDimension; counterA++){
                        //    for (int counterB = 1; counterB <= horizontalDimension; counterB++) cout<<" "<<fovNoMap [counterA][counterB];
                        //    cout<<" fovNoMap "<<counterA+1<<endl;
                        //}
                        
                        string treatNameTemp2;
                        string fovName2;
                        string contrastDataTemp;
                        string extract1;
                        string extract2;
                        string fovPositionHead;
                        
                        if ((int)loadImageTreatName.find("CH") != -1){
                            fovPositionHead = loadImageTreatName.substr(loadImageTreatName.find("CH"))+"-";
                        }
                        else fovPositionHead = "FOV";
                        
                        int *fovNoSelect = new int [10];
                        
                        for (int counter2 = 0; counter2 < 10; counter2++) fovNoSelect [counter2] = 0;
                        
                        int horizontalPosition = 0;
                        int verticalPosition = 0;
                        
                        for (int counter1 = 1; counter1 <= verticalDimension; counter1++){
                            for (int counter2 = 1; counter2 <= horizontalDimension; counter2++){
                                if (fovNoMap [counter1][counter2] == currentOriginalNo){
                                    horizontalPosition = counter2;
                                    verticalPosition = counter1;
                                }
                            }
                        }
                        
                        fovNoSelect [0] = currentOriginalNo;
                        
                        if (verticalPosition-1 >= 1) fovNoSelect [1] = fovNoMap [verticalPosition-1][horizontalPosition];
                        if (verticalPosition-2 >= 1) fovNoSelect [2] = fovNoMap [verticalPosition-2][horizontalPosition];
                        if (verticalPosition+1 <= verticalDimension) fovNoSelect [3] = fovNoMap [verticalPosition+1][horizontalPosition];
                        if (verticalPosition+2 <= verticalDimension) fovNoSelect [4] = fovNoMap [verticalPosition+2][horizontalPosition];
                        
                        string backPageNo = to_string(backgroundDisplayPage);
                        
                        treatFind = 0;
                        int findFlag = 0;
                        
                        for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++){
                            treatNameTemp2 = arrayTreatmentNameDisplay [counter2];
                            fovName2 = arrayFOVNameDisplay [counter2];
                            
                            if (treatNameTemp2 == loadImageTreatName && fovName2 != "ND" && treatFind == 0){
                                treatFind = 1;
                                findFlag = 0;
                                
                                for (int counter3 = 0; counter3 < 10; counter3++){
                                    if (fovPositionHead+to_string(fovNoSelect [counter3]) == fovName2){
                                        findFlag = 1;
                                        break;
                                    }
                                }
                                
                                if (findFlag == 1){
                                    contrastDataTemp = arrayTableDisplay [counter2*5+2];
                                    extract1 = contrastDataTemp.substr(0, contrastDataTemp.find(":"));
                                    extract2 = contrastDataTemp.substr(contrastDataTemp.find("~"));
                                    extract1 = extract1+":"+backPageNo+extract2;
                                    
                                    arrayTableDisplay [counter2*5+2] = extract1;
                                }
                            }
                            else if (treatNameTemp2 == "ND" && fovName2 != "ND" && treatFind == 1){
                                findFlag = 0;
                                
                                for (int counter3 = 0; counter3 < 10; counter3++){
                                    if (fovPositionHead+to_string(fovNoSelect [counter3]) == fovName2){
                                        findFlag = 1;
                                        break;
                                    }
                                }
                                
                                if (findFlag == 1){
                                    contrastDataTemp = arrayTableDisplay [counter2*5+2];
                                    extract1 = contrastDataTemp.substr(0, contrastDataTemp.find(":"));
                                    extract2 = contrastDataTemp.substr(contrastDataTemp.find("~"));
                                    extract1 = extract1+":"+backPageNo+extract2;
                                    
                                    arrayTableDisplay [counter2*5+2] = extract1;
                                }
                            }
                            else if (((treatNameTemp2 != "ND" && fovName2 != "ND") || (treatNameTemp2 == "ND" && fovName2 == "ND")) && treatFind == 1){
                                treatFind = 2;
                            }
                        }
                        
                        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                            contrastCurrentHold [counter1] = arrayTableDisplay [counter1*5+2];
                        }
                        
                        for (int counter2 = 0; counter2 < verticalDimension+1; counter2++){
                            delete [] fovNoMap [counter2];
                        }
                        
                        delete [] fovNoMap;
                        delete [] fovNoSelect;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        tableViewCall = 1;
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Perform Set Condition"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                
                delete [] fovPositionHoldTemp;
                delete [] fovStartEnd;
                delete [] boarderData;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Treatment Not Selected"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)drawRect:(NSRect)rect{
    NSRect srcRect;
    srcRect.origin.x = xPositionDisplayBK+xPositionAdjustDisplayBK+xPositionMoveDisplayBK;
    srcRect.origin.y = yPositionDisplayBK+yPositionAdjustDisplayBK+yPositionMoveDisplayBK;
    srcRect.size.width = imageDimensionX/(double)(magnificationDisplayBK*0.1);
    srcRect.size.height = imageDimensionY/(double)(magnificationDisplayBK*0.1);
    
    [adjustImageBK drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
    
    double xPositionAdj = xPositionAdjustDisplayBK+xPositionDisplayBK;
    double yPositionAdj = yPositionAdjustDisplayBK+yPositionDisplayBK;
    double xCalValue = 1/(double)windowWidthDisplayBK*magnificationDisplayBK*0.1;
    double yCalValue = 1/(double)windowHeightDisplayBK*magnificationDisplayBK*0.1;
    
    if (backgroundPatternArrayStatus == 1){
        if (backgroundOriginalLoadFlag == 0){
            NSPoint pointC;
            NSAttributedString *attrStrB;
            NSMutableDictionary *attributesB = [NSMutableDictionary dictionary];
            
            [attributesB setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            [attributesB setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
            [attributesB setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
            
            string fovNoDisplay = "FOV No.: "+to_string(currentOriginalNo);
            
            attrStrB = [[NSAttributedString alloc] initWithString:@(fovNoDisplay.c_str()) attributes:attributesB];
            pointC.x = 10;
            pointC.y = 485;
            [attrStrB drawAtPoint:pointC];
        }
        else if (backgroundOriginalLoadFlag == 1 && backgroundDisplayPage > 0){
            NSPoint pointC;
            NSAttributedString *attrStrB;
            NSMutableDictionary *attributesB = [NSMutableDictionary dictionary];
            
            [attributesB setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            [attributesB setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
            [attributesB setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
            
            string backNameDisplay = "Background Name: "+backgroundPatternName [backgroundDisplayPage-1];
            
            attrStrB = [[NSAttributedString alloc] initWithString:@(backNameDisplay.c_str()) attributes:attributesB];
            pointC.x = 5;
            pointC.y = 10;
            [attrStrB drawAtPoint:pointC];
            
            string fovNoDisplay = "BK No.: "+to_string(backgroundDisplayPage);
            
            attrStrB = [[NSAttributedString alloc] initWithString:@(fovNoDisplay.c_str()) attributes:attributesB];
            pointC.x = 430;
            pointC.y = 485;
            [attrStrB drawAtPoint:pointC];
            
            fovNoDisplay = "FOV No.: "+to_string(currentOriginalNo);
            
            attrStrB = [[NSAttributedString alloc] initWithString:@(fovNoDisplay.c_str()) attributes:attributesB];
            pointC.x = 10;
            pointC.y = 485;
            [attrStrB drawAtPoint:pointC];
        }
        else if (backgroundOriginalLoadFlag == 2 && lineAreaStatusHold == 0){
            NSBezierPath *path;
            [[NSColor greenColor] set];
            [NSBezierPath setDefaultLineWidth:0.8];
            
            double positionAAX = (xClickPosition-xPositionAdj)*xCalValue;
            double positionAAY = (imageDimensionY-yClickPosition-yPositionAdj)*yCalValue;
            double positionBBX = ((xClickPosition+8*backArea)-xPositionAdj)*xCalValue-(xClickPosition-xPositionAdj)*xCalValue;
            double positionBBY = (imageDimensionY-(yClickPosition+8*backArea)-yPositionAdj)*yCalValue-(imageDimensionY-yClickPosition-yPositionAdj)*yCalValue;
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(positionAAX, positionAAY, positionBBX, positionBBY)];
            [path stroke];
            
            stringstream extension1;
            extension1 << clickValue;
            string extension = extension1.str();
            
            NSPoint pointA;
            NSAttributedString *attrStrA;
            NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
            
            [attributesA setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
            [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
            
            string centerValue = "Center Value: "+extension;
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(centerValue.c_str()) attributes:attributesA];
            pointA.x = 90;
            pointA.y = 485;
            [attrStrA drawAtPoint:pointA];
            
            string fovNoDisplay = "BK No.: "+to_string(backgroundDisplayPage);
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(fovNoDisplay.c_str()) attributes:attributesA];
            pointA.x = 430;
            pointA.y = 485;
            [attrStrA drawAtPoint:pointA];
            
            fovNoDisplay = "FOV No.: "+to_string(currentOriginalNo);
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(fovNoDisplay.c_str()) attributes:attributesA];
            pointA.x = 10;
            pointA.y = 485;
            [attrStrA drawAtPoint:pointA];
        }
        else if (backgroundOriginalLoadFlag == 2 && lineAreaStatusHold == 1){
            if (bkLine1 != -1 && bkLine2 == -1){
                NSBezierPath *path;
                [[NSColor greenColor] set];
                [NSBezierPath setDefaultLineWidth:0.8];
                
                double positionAAX = (bkLineX1-xPositionAdj)*xCalValue;
                double positionAAY = (imageDimensionY-bkLineY1-yPositionAdj)*yCalValue;
                double positionBBX = ((bkLineX1+8*backArea)-xPositionAdj)*xCalValue-(bkLineX1-xPositionAdj)*xCalValue;
                double positionBBY = (imageDimensionY-(bkLineY1+8*backArea)-yPositionAdj)*yCalValue-(imageDimensionY-bkLineY1-yPositionAdj)*yCalValue;
                
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(positionAAX, positionAAY, positionBBX, positionBBY)];
                [path stroke];
            }
            
            if (bkLine1 != -1 && bkLine2 != -1){
                NSBezierPath *path;
                [[NSColor greenColor] set];
                [NSBezierPath setDefaultLineWidth:0.8];
                
                double positionAAX = (bkLineX1-xPositionAdj)*xCalValue;
                double positionAAY = (imageDimensionY-bkLineY1-yPositionAdj)*yCalValue;
                double positionBBX = ((bkLineX1+8*backArea)-xPositionAdj)*xCalValue-(bkLineX1-xPositionAdj)*xCalValue;
                double positionBBY = (imageDimensionY-(bkLineY1+8*backArea)-yPositionAdj)*yCalValue-(imageDimensionY-bkLineY1-yPositionAdj)*yCalValue;
                
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(positionAAX, positionAAY, positionBBX, positionBBY)];
                [path stroke];
                
                [[NSColor redColor] set];
                
                positionAAX = (bkLineX2-xPositionAdj)*xCalValue;
                positionAAY = (imageDimensionY-bkLineY2-yPositionAdj)*yCalValue;
                positionBBX = ((bkLineX2+8*backArea)-xPositionAdj)*xCalValue-(bkLineX2-xPositionAdj)*xCalValue;
                positionBBY = (imageDimensionY-(bkLineY2+8*backArea)-yPositionAdj)*yCalValue-(imageDimensionY-bkLineY2-yPositionAdj)*yCalValue;
                
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(positionAAX, positionAAY, positionBBX, positionBBY)];
                [path stroke];
            }
            
            stringstream extension1;
            extension1 << clickValue;
            string extension = extension1.str();
            
            NSPoint pointA;
            NSAttributedString *attrStrA;
            NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
            
            [attributesA setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
            [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
            
            if (bkLine1 == -1 && bkLine2 == -1){
                string centerValue = "Set Position 1";
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(centerValue.c_str()) attributes:attributesA];
                pointA.x = 90;
                pointA.y = 485;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (bkLine1 != -1 && bkLine2 == -1){
                string centerValue = "Set Position 2";
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(centerValue.c_str()) attributes:attributesA];
                pointA.x = 90;
                pointA.y = 485;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (bkLine1 != -1 && bkLine2 != -1){
                string centerValue = "Ready";
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(centerValue.c_str()) attributes:attributesA];
                pointA.x = 90;
                pointA.y = 485;
                [attrStrA drawAtPoint:pointA];
            }
            
            string fovNoDisplay = "BK No.: "+to_string(backgroundDisplayPage);
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(fovNoDisplay.c_str()) attributes:attributesA];
            pointA.x = 430;
            pointA.y = 485;
            [attrStrA drawAtPoint:pointA];
            
            fovNoDisplay = "FOV No.: "+to_string(currentOriginalNo);
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(fovNoDisplay.c_str()) attributes:attributesA];
            pointA.x = 10;
            pointA.y = 485;
            [attrStrA drawAtPoint:pointA];
        }
        else if (backgroundOriginalLoadFlag == 3){
            NSPoint pointA;
            NSAttributedString *attrStrA;
            NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
            
            [attributesA setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
            [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
            
            string fovNoDisplay = "BK No.: "+to_string(backgroundDisplayPage);
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(fovNoDisplay.c_str()) attributes:attributesA];
            pointA.x = 430;
            pointA.y = 485;
            [attrStrA drawAtPoint:pointA];
            
            fovNoDisplay = "FOV No.: "+to_string(currentOriginalNo);
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(fovNoDisplay.c_str()) attributes:attributesA];
            pointA.x = 10;
            pointA.y = 485;
            [attrStrA drawAtPoint:pointA];
            
            double magnificationDisplayWindow = magnificationDisplayBK*0.1;
            
            if (areaSetFlag1 == 1){
                NSBezierPath *path3;
                [NSBezierPath setDefaultLineWidth:0.5];
                [[NSColor redColor] set];
                
                double xPointMarkTemp = 0;
                double yPointMarkTemp = 0;
                
                for (int counter1 = 0; counter1 < backAreaLineUpArrayCount/2; counter1++){
                    xPointMarkTemp = (int)((backAreaLineUpArray [counter1*2]-xPositionAdj)*(double)xCalValue);
                    yPointMarkTemp = (int)(((imageDimensionY-backAreaLineUpArray [counter1*2+1])-yPositionAdj)*(double)yCalValue);
                    
                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplayWindow, magnificationDisplayWindow)];
                    [path3 fill];
                }
                
                fovNoDisplay = "High: "+to_string(clickAreaHighValue);
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(fovNoDisplay.c_str()) attributes:attributesA];
                pointA.x = 90;
                pointA.y = 485;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (areaSetFlag3== 1){
                NSBezierPath *path3;
                [NSBezierPath setDefaultLineWidth:0.5];
                [[NSColor blueColor] set];
                
                double xPointMarkTemp = 0;
                double yPointMarkTemp = 0;
                
                for (int counter1 = 0; counter1 < backAreaLineDownArrayCount/2; counter1++){
                    xPointMarkTemp = (int)((backAreaLineDownArray [counter1*2]-xPositionAdj)*(double)xCalValue);
                    yPointMarkTemp = (int)(((imageDimensionY-backAreaLineDownArray [counter1*2+1])-yPositionAdj)*(double)yCalValue);
                    
                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplayWindow, magnificationDisplayWindow)];
                    [path3 fill];
                }
                
                fovNoDisplay = "Low: "+to_string(clickAreaLowValue);
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(fovNoDisplay.c_str()) attributes:attributesA];
                pointA.x = 160;
                pointA.y = 485;
                [attrStrA drawAtPoint:pointA];
            }
        }
        
        if (backgroundOriginalLoadFlag == 4){
            NSPoint pointA;
            NSAttributedString *attrStrA;
            NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
            
            [attributesA setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
            [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
            
            string fovNoDisplay = "BK No.: "+to_string(backgroundDisplayPage);
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(fovNoDisplay.c_str()) attributes:attributesA];
            pointA.x = 430;
            pointA.y = 485;
            [attrStrA drawAtPoint:pointA];
            
            fovNoDisplay = "FOV No.: "+to_string(currentOriginalNo);
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(fovNoDisplay.c_str()) attributes:attributesA];
            pointA.x = 10;
            pointA.y = 485;
            [attrStrA drawAtPoint:pointA];
            
            NSPoint positionAA, positionBB;
            
            positionAA.x = (0-xPositionAdj)*xCalValue;
            positionAA.y = (imageDimensionY-expansionUPPosition1-yPositionAdj)*yCalValue;
            
            positionBB.x = (imageDimensionX-xPositionAdj)*xCalValue;
            positionBB.y = (imageDimensionY-expansionUPPosition2-yPositionAdj)*yCalValue;
            
            [[NSColor redColor] set];
            [NSBezierPath setDefaultLineWidth:1.0];
            
            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            
            positionAA.x = (0-xPositionAdj)*xCalValue;
            positionAA.y = (imageDimensionY-expansionDownPosition1-yPositionAdj)*yCalValue;
            
            positionBB.x = (imageDimensionX-xPositionAdj)*xCalValue;
            positionBB.y = (imageDimensionY-expansionDownPosition2-yPositionAdj)*yCalValue;
            
            [[NSColor yellowColor] set];
            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            
            positionAA.x = (expansionLeftPosition1-xPositionAdj)*xCalValue;
            positionAA.y = (imageDimensionY-0-yPositionAdj)*yCalValue;
            
            positionBB.x = (expansionLeftPosition2-xPositionAdj)*xCalValue;
            positionBB.y = (imageDimensionY-imageDimensionY-yPositionAdj)*yCalValue;
            
            [[NSColor blueColor] set];
            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            
            positionAA.x = (expansionRightPosition1-xPositionAdj)*xCalValue;
            positionAA.y = (imageDimensionY-0-yPositionAdj)*yCalValue;
            
            positionBB.x = (expansionRightPosition2-xPositionAdj)*xCalValue;
            positionBB.y = (imageDimensionY-imageDimensionY-yPositionAdj)*yCalValue;
            
            [[NSColor greenColor] set];
            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
        }
    }
    
    if (overlayStatusSend == 1) overlayStatusSend++;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToBackgroundWindow object:nil];
}

@end
