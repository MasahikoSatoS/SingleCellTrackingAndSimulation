/*
 *  Controller.m
 *  Contrast_Set
 *
 *  Created by Masahiko Sato on 01/01/10.
 *  Copyright Masahiko Sato 2010 All rights reserved.
 *
 */

#import "Controller.h"

int imageDimensionX;
int imageDimensionY;
int stitchImageDimension;
int totalFOVNoHoldInt;
int tableCallCount;
int fluorescentCount;

string pathNameString;
string bodyName;
string totalFOVNoHold;
string fluorescent1;
string fluorescent2;
string fluorescent3;
string fluorescent4;
string fluorescent5;
string fluorescent6;
string fluorescentNo1;
string fluorescentNo2;
string fluorescentNo3;
string fluorescentNo4;
string fluorescentNo5;
string fluorescentNo6;

string colorNameHold;
string colorNoHold;
int colorNameHoldStatus;
int colorNameDisplayCall;
int tableColorStatus;
int fluorescentDisplayModeHold;

//-----Calls-----
int tableViewCall;
int rowIndexHold;
int imageInfoDisplayCall;
int mainImageDisplayCall;
int histogramDisplayCall;
int contrastDisplayCall;
int timePointDisplayCall;
int timePointRequest;
int callFromHistogram;
int backgroundCorrectionCall;

//-----Processing-----
int imageFirstLoadFlagDisplay;
int magnificationDisplay;
int currentTimePoint;
int entryNumber;
int loadImageNo;
int loadImageFOVNo;
int lastImageNo;
int contrastDataLimit;
int sourceTimeDisplayFlag;
int blurStatusHold;
int autoProcessingFlag;
int reprocessStartFlag;
int reprocessImageNo;
int progressValue;
int progressTiming;
int progressTimingB;
int progressTimingC;
int imageFindFlag;
double windowWidthDisplay;
double windowHeightDisplay;
string ascIIstring;
string fileNoStringTemp;
string batchImageBodyName;
string baseTreatmentName;
string objectiveType;
string loadImageTreatName;

//-----Main Image Control-----
int lowValueDisplay;
int meanValueDisplay;
int highValueDisplay;
int lowValueDisplayG;
int meanValueDisplayG;
int highValueDisplayG;
int lowValueDisplayB;
int meanValueDisplayB;
int highValueDisplayB;
int processingFovNo;
int contrastBarActivate;
int fovFirstClick;
int fovSecondClick;
int fovClickSide;
int positionSetStatus;
int fovFirstClickOR1;
int fovSecondClickOR1;
int fovFirstClickOR2;
int fovSecondClickOR2;
int fovFirstSetFlag;
double histoMaxCount;
int currentFOVNoHold;
int contrastFirstRead;
double contrastValueDisplay;
double contrastValueDisplayG;
double contrastValueDisplayB;
int resolutionStatus;
int photoMetricHold;
int rgbDisplayStatus;
int xOrientation;
int yOrientation;
int xyInvert;
int firstDataSetFlag;
int orientationSetFlag;

string imageFLStatus;
string contrastOADisplay;
string backgroundOADisplay;

//-----Stitched image making-----
int autoType;
int autoImageSizeX;
int autoImageSizeY;
string treatmentNameAuto;

//-----Fluorescent Image Overlay-----
int positionAdjustOperation;
int positionAdjustFlag;
int imageMoveStatus;
int imageFirstLoadFlagDisplayFluorescent;
int magnificationDisplayFluorescent;
int xMovePositionHoldMain;
int yMovePositionHoldMain;
int channelAdjustHoldX1;
int channelAdjustHoldX2;
int channelAdjustHoldX3;
int channelAdjustHoldX4;
int channelAdjustHoldX5;
int channelAdjustHoldX6;
int channelAdjustHoldY1;
int channelAdjustHoldY2;
int channelAdjustHoldY3;
int channelAdjustHoldY4;
int channelAdjustHoldY5;
int channelAdjustHoldY6;
int channelAdjustFirstSet1;
int channelAdjustFirstSet2;
int channelAdjustFirstSet3;
int channelAdjustFirstSet4;
int channelAdjustFirstSet5;
int channelAdjustFirstSet6;
double baseCut;
double fluorescentEnhance;
int fluorescentStitchDimension;
double dicLevelHold;
double dicContrastHold;
string zImageColorSet;

//-----IF processing-----
int statusIFHold;

//-----Background Adjust Operation-----
int backgroundAdjustOperation;
int backgroundOriginalLoadFlag;
int currentOriginalNo;
int backgroundDisplayPage;
int imageFirstLoadFlagDisplayBK;
int magnificationDisplayBK;
int treatmentBKCall;
int contrastCutOff1;
int contrastCutOff3;
int contrastCutOffAS;
int baseContrastSetFlag1;
int baseContrastSetFlag3;
int baseContrastSetFlagAS;
int baseContrastSetFlagVertical;
int baseContrastSetFlagHorizontal;
int areaSetFlag1;
int areaSetFlag3;
int contrastAreaOffHold1;
int contrastAreaOffHold3;
double baseContrastSet1;
double baseContrastSet3;
double baseContrastSetAS;
int xClickPosition;
int yClickPosition;
int lineAreaStatusHold;
int backArea;
int clickNumber;
int overlayStatusHold;
int overlayStatusSend;
double expansionUPCurrent;
double expansionDownCurrent;
double expansionRightCurrent;
double expansionLeftCurrent;
double expansionUPPosition1;
double expansionUPPosition2;
double expansionDownPosition1;
double expansionDownPosition2;
double expansionRightPosition1;
double expansionRightPosition2;
double expansionLeftPosition1;
double expansionLeftPosition2;
int edgeSetFlag;
int clickAreaSetValue;
int clickAreaHighValue;
int clickAreaLowValue;
int bkUnUsedCall;

//-----Paths-----
string productsFilesImagePath;
string productsFilesTempPath;
string productsFilesInfoPath;
string contrastSettingPath;
string fovPositionPath;
string fovPositionIFHoldPath;
string stitchedFolderPath;
string productsStitchTempPath;
string instructionCSPath;
string instructionAPPath;
string contrastSettingTempPath;
string fovPositionTempPath;
string stitchedFolderImagePath;
string loadingCompletePath;
string fileSavePathHold;

//-----Arrays-----
string *arrayTreatmentNameDisplay;
int treatmentNameDisplayCount;
string *arrayFOVNameDisplay;
int fOVNameDisplayCount;
string *arrayTableDisplay;
int tableDisplayCount;
string *arrayTableDisplayG;
int tableDisplayCountG;
string *arrayTableDisplayB;
int tableDisplayCountB;

string **arrayContrastData;
string **arrayContrastDataG;
string **arrayContrastDataB;
int contrastDataHorizontal;
int contrastDataEntry;

int **arrayImageDataHold;
int imageDataHoldStatus;
int **arrayImageRangeAdjust;
int **arrayImageCutoffAdjust;
int **arrayImageContrastAdjust;

int **arrayBackgroundDataHold;
int **arrayBackgroundDataHold2;
int **arrayBalanceBaseData;
int **arrayBalanceBaseModify;

int *arrayImageDataHistogram;
int *arrayImageDataHistogramG;
int *arrayImageDataHistogramB;
int *arrayImageRangeAdjustHistogram;
int *arrayImageRangeAdjustHistogramG;
int *arrayImageRangeAdjustHistogramB;
int *arrayImageCutoffAdjustHistogram;
int *arrayImageCutoffAdjustHistogramG;
int *arrayImageCutoffAdjustHistogramB;
int *arrayImageContrastAdjustHistogram;
int *arrayImageContrastAdjustHistogramG;
int *arrayImageContrastAdjustHistogramB;

int *arrayImageDataLMH;
int *arrayImageDataLMHG;
int *arrayImageDataLMHB;
int *arrayImageRangeAdjustLMH;
int *arrayImageRangeAdjustLMHG;
int *arrayImageRangeAdjustLMHB;
int *autoContrastCorrectLMH;
int *autoContrastCorrectLMHG;
int *autoContrastCorrectLMHB;
int *autoContrastCorrectLMH2;
int *autoContrastCorrectLMH2G;
int *autoContrastCorrectLMH2B;

string *xyPositionData;
int *xyPositionDataHold;
int *arrayXYWritingPosition;
int *arrayXYWritingPositionBase;
int *arrayXYWritingPositionFluorescent;

int **imageDisplayArray;
int **imagePositionMap;
int **imageDisplayBaseArray;
int **imageDisplayFluorescentArray;

string *arrayHorizontalLink;
int horizontalLinkCount;
string *arrayVerticalLink;
int verticalLinkCount;

double *contrastValueHold;
int contrastValueCount;
double *contrastValueHoldG;
int contrastValueCountG;
double *contrastValueHoldB;
int contrastValueCountB;
string *contrastCurrentHold;
string *contrastCurrentHoldG;
string *contrastCurrentHoldB;

int **arrayBalanceDataHold;

int *backgroundPatternArray;
int backgroundPatternArrayCount;
int *backgroundPatternModifyArray;
int backgroundPatternModifyArrayCount;
int backgroundPatternFirstSet;
int backgroundPatternArrayStatus;
string *backgroundPatternName;

int **backBaseArray;
int **backBaseMap;
int **backBaseArrayModify;
int **backBaseArrayEdge;

int **backBaseArrayPrevious;
int *backBasePositionArray;
int **arrayBackgroundCorrectionData;
int *backAreaLineUpArray;
int backAreaLineUpArrayCount;
int *backAreaLineDownArray;
int backAreaLineDownArrayCount;
int **backAreaMapUpArray;
int **backAreaMapDownArray;
int backArraysSetStatus;

double *correctionValues;
string *arrayFileDelete;
int fileDeleteCount, fileDeleteLimit;
uint8_t *fileReadArray;
int **arrayImageFileSave;

//-----Communication-----
int processMode;
int imageProcessTiming;

//-----Balance Window-----
int positionBalanceOperation;
int balanceImageLoadFlag;
double rangeLimitCurrent;
double rangeLimitCurrentHorizontal;
double rangeLimitCurrentVertical;

//-----IF reload-----
int ifReloadWindowOperation;
int *arrayIfReload;
int ifReloadCount;
int ifReloadStatus;

@implementation Controller

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSString *currentDirectoryPathNSString = [[NSBundle mainBundle] bundlePath];
        string userPathNameString = [currentDirectoryPathNSString cStringUsingEncoding:NSUTF8StringEncoding];
        
        if (userPathNameString.length() == 0) exit (0);
        else if ((int)userPathNameString.find("/Users/") == -1) exit (0);
        else{
            
            string pathName2 = userPathNameString.substr((unsigned long)userPathNameString.find("/Users/")+7);
            pathNameString = pathName2.substr(0, (unsigned long)pathName2.find("/"));
        }
        
        imageDimensionX = 0;
        imageDimensionY = 0;
        stitchImageDimension = 0;
        tableCallCount = 0;
        fluorescentCount = 0;
        
        fluorescent1 = "";
        fluorescent2 = "";
        fluorescent3 = "";
        fluorescent4 = "";
        fluorescent5 = "";
        fluorescent6 = "";
        fluorescentNo1 = "";
        fluorescentNo2 = "";
        fluorescentNo3 = "";
        fluorescentNo4 = "";
        fluorescentNo5 = "";
        fluorescentNo6 = "";
        
        colorNameHold = "nil";
        colorNoHold = "nil";
        colorNameHoldStatus = 0;
        colorNameDisplayCall = 0;
        tableColorStatus = 0;
        fluorescentDisplayModeHold = 0;
        
        tableViewCall = 0;
        rowIndexHold = 0;
        imageInfoDisplayCall = 0;
        mainImageDisplayCall = 0;
        histogramDisplayCall = 0;
        contrastDisplayCall = 0;
        timePointDisplayCall = 0;
        timePointRequest = 0;
        callFromHistogram = 0;
        backgroundCorrectionCall = 0;
        
        imageFirstLoadFlagDisplay = 0;
        magnificationDisplay = 10;
        currentTimePoint = 0;
        entryNumber = 0;
        loadImageNo = 0;
        loadImageFOVNo = 0;
        lastImageNo = 0;
        sourceTimeDisplayFlag = 0;
        autoProcessingFlag = 0;
        reprocessStartFlag = 0;
        progressValue = 0;
        progressTiming = 0;
        progressTimingB = 0;
        progressTimingC = 0;
        imageFindFlag = 0;
        batchImageBodyName = "nil";
        objectiveType = "1";
        loadImageTreatName = "";
        
        lowValueDisplay = 0;
        meanValueDisplay = 0;
        highValueDisplay = 0;
        lowValueDisplayG = 0;
        meanValueDisplayG = 0;
        highValueDisplayG = 0;
        lowValueDisplayB = 0;
        meanValueDisplayB = 0;
        highValueDisplayB = 0;
        processingFovNo = -1;
        contrastBarActivate = 0;
        fovFirstClick = 0;
        fovSecondClick = 0;
        fovClickSide = 1;
        positionSetStatus = 0;
        fovFirstSetFlag = 0;
        fovFirstClickOR1 = -1;
        fovSecondClickOR1 = -1;
        fovFirstClickOR2 = -1;
        fovSecondClickOR2 = -1;
        histoMaxCount = 0;
        currentFOVNoHold = 0;
        contrastFirstRead = 0;
        contrastValueDisplay = 0;
        contrastValueDisplayG = 0;
        contrastValueDisplayB = 0;
        resolutionStatus = 0;
        photoMetricHold = 0;
        rgbDisplayStatus = 0;
        firstDataSetFlag = 0;
        orientationSetFlag = 0;
        
        imageFLStatus = "Lock";
        contrastOADisplay = "Off";
        backgroundOADisplay = "Off";
        
        autoType = 0;
        autoImageSizeX = 0;
        autoImageSizeY = 0;
        
        positionAdjustOperation = 0;
        positionAdjustFlag = 0;
        imageMoveStatus = 0;
        imageFirstLoadFlagDisplayFluorescent = 0;
        magnificationDisplayFluorescent = 10;
        channelAdjustHoldX1 = 0;
        channelAdjustHoldX2 = 0;
        channelAdjustHoldX3 = 0;
        channelAdjustHoldX4 = 0;
        channelAdjustHoldX5 = 0;
        channelAdjustHoldX6 = 0;
        channelAdjustHoldY1 = 0;
        channelAdjustHoldY2 = 0;
        channelAdjustHoldY3 = 0;
        channelAdjustHoldY4 = 0;
        channelAdjustHoldY5 = 0;
        channelAdjustHoldY6 = 0;
        channelAdjustFirstSet1 = 0;
        channelAdjustFirstSet2 = 0;
        channelAdjustFirstSet3 = 0;
        channelAdjustFirstSet4 = 0;
        channelAdjustFirstSet5 = 0;
        channelAdjustFirstSet6 = 0;
        baseCut = 50;
        fluorescentEnhance = 1;
        dicLevelHold = 50;
        dicContrastHold = 1;
        
        statusIFHold = 0;
        
        backgroundAdjustOperation = 0;
        backgroundOriginalLoadFlag = 1;
        imageFirstLoadFlagDisplayBK = 0;
        magnificationDisplayBK = 10;
        treatmentBKCall = 0;
        baseContrastSetFlag1 = 0;
        baseContrastSetFlag3 = 0;
        baseContrastSetFlagAS = 0;
        baseContrastSetFlagVertical = 0;
        baseContrastSetFlagHorizontal = 0;
        areaSetFlag1 = 0;
        areaSetFlag3 = 0;
        xClickPosition = 0;
        yClickPosition = 0;
        lineAreaStatusHold = 0;
        backArea = 5;
        clickNumber = 0;
        overlayStatusHold = 0;
        overlayStatusSend = 0;
        edgeSetFlag = 0;
        clickAreaSetValue = 0;
        clickAreaHighValue = 0;
        clickAreaLowValue = 0;
        bkUnUsedCall = 0;
        
        contrastDataEntry = 0;
        imageDataHoldStatus = 0;
        backgroundPatternFirstSet = 0;
        backgroundPatternArrayStatus = 0;
        backArraysSetStatus = 0;
        
        processMode = 0;
        imageProcessTiming = 0;
        
        positionBalanceOperation = 0;
        balanceImageLoadFlag = 0;
        rangeLimitCurrent = 0;
        rangeLimitCurrentHorizontal = 0;
        rangeLimitCurrentVertical = 0;
        
        ifReloadWindowOperation = 0;
        ifReloadStatus = 0;
        
        tableCurrentRowHold = 0;
        exitFlag = 0;
        initialArraySet = 0;
        noFileFoundFlag = 0;
        processingFromHold = 0;
        processingToHold = 0;
        reprocessStatus = 0;
        copyFirstTime = 0;
        bkRemoveLevel = 0;
        
        imagePosition = 0;
        imageFirstLoadFlag = 0;
        
        firstCommunication = 0;
        basicInfoRead = 0;
    }
    
    return self;
}

-(void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat xLength = screenRect.size.width;
    CGFloat yLength = screenRect.size.height;
    
    int mainControllerX = 800;
    
    NSRect windowSize = [autocontrast frame];
    CGFloat windowWidth = windowSize.size.width;
    CGFloat windowHeight = windowSize.size.height;
    
    int displayPositionType = 0;
    
    if (80+mainControllerX+5+windowWidth+5+80 > xLength) displayPositionType = 1;
    
    CGFloat displayX;
    
    if (displayPositionType == 1) displayX = 350;
    else displayX = 80+mainControllerX+5;
    
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [autocontrast setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [reprocessFromDisplay setDelegate:self];
    [reprocessToDisplay setDelegate:self];
    [tableViewList setDataSource:self];
}

-(void)applicationDidFinishLaunching:(NSNotification*)notification{
    string analysisDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/AnalysisSetting";
    string nameAssignFilePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/NAAssignedName";
    string batchProcessImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/BatchImageList";
    string contrastSettingParameterPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ContrastParameters";
    
    instructionCSPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"CS_Instruction1";
    instructionAPPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"AP_Instruction1";
    loadingCompletePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CSComplete1";
    
    string getString;
    
    ifstream fin;
    fin.open(analysisDataPath.c_str(), ios::in);
    
    if (fin.is_open()){
        getline(fin, getString), bodyName = getString;
        getline(fin, getString);
        getline(fin, getString), totalFOVNoHold = getString;
        getline(fin, getString);
        getline(fin, getString);
        getline(fin, getString);
        getline(fin, getString);
        getline(fin, getString);
        getline(fin, getString);
        getline(fin, getString);
        getline(fin, getString);
        getline(fin, getString), objectiveType = getString;
        
        fin.close();
    }
    
    fin.open(batchProcessImagePath.c_str(), ios::in);
    
    if (fin.is_open()){
        getline(fin, getString);
        getline(fin, getString), batchImageBodyName = getString;
        
        fin.close();
    }
    
    fluorescentCount = 0;
    fin.open(nameAssignFilePath.c_str(), ios::in);
    
    if (fin.is_open()){
        for (int counter1 = 0; counter1 < 57; counter1++) getline(fin, getString);
        for (int counter1 = 0; counter1 < 6; counter1++){
            getline(fin, getString);
            
            if (getString != "nil") fluorescentCount++;
            
            getline(fin, getString);
            
            if (getString != "nil" && counter1 == 0) fluorescent1 = getString;
            if (getString != "nil" && counter1 == 1) fluorescent2 = getString;
            if (getString != "nil" && counter1 == 2) fluorescent3 = getString;
            if (getString != "nil" && counter1 == 3) fluorescent4 = getString;
            if (getString != "nil" && counter1 == 4) fluorescent5 = getString;
            if (getString != "nil" && counter1 == 5) fluorescent6 = getString;
            
            getline(fin, getString);
            
            if (getString != "nil" && counter1 == 0) fluorescentNo1 = getString;
            if (getString != "nil" && counter1 == 1) fluorescentNo2 = getString;
            if (getString != "nil" && counter1 == 2) fluorescentNo3 = getString;
            if (getString != "nil" && counter1 == 3) fluorescentNo4 = getString;
            if (getString != "nil" && counter1 == 4) fluorescentNo5 = getString;
            if (getString != "nil" && counter1 == 5) fluorescentNo6 = getString;
            
            //cout<<fluorescent1<<" "<<fluorescent2<<" "<<fluorescent3<<" "<<fluorescent4<<" "<<fluorescent5<<" "<<fluorescent6<<" color"<<endl;
        }
        
        fin.close();
    }
    
    [analysisName setStringValue:@(bodyName.c_str())];
    [contrastImageDisplay setStringValue:@"nil"];
    [sourceTimeStatusDisplay setTextColor:[NSColor blackColor]];
    [sourceTimeStatusDisplay setStringValue:@"Source"];
    [sourceTimeStatusDisplay2 setStringValue:@"Source"];
    
    fin.open(contrastSettingParameterPath.c_str(), ios::in);
    
    if (fin.is_open()){
        getline(fin, getString), currentOriginalNo = atoi(getString.c_str());
        getline(fin, getString), backgroundDisplayPage = atoi(getString.c_str());
        getline(fin, getString), contrastCutOff1 = atoi(getString.c_str());
        getline(fin, getString), contrastCutOff3 = atoi(getString.c_str());
        getline(fin, getString), contrastCutOffAS = atoi(getString.c_str());
        getline(fin, getString), baseContrastSet1 = atof(getString.c_str());
        getline(fin, getString), baseContrastSet3 = atof(getString.c_str());
        getline(fin, getString), baseContrastSetAS = atof(getString.c_str());
        getline(fin, getString), rangeLimitCurrent = atof(getString.c_str());
        getline(fin, getString), rangeLimitCurrentHorizontal = atof(getString.c_str());
        getline(fin, getString), rangeLimitCurrentVertical = atof(getString.c_str());
        getline(fin, getString), expansionUPCurrent = atof(getString.c_str());
        getline(fin, getString), expansionDownCurrent = atof(getString.c_str());
        getline(fin, getString), expansionRightCurrent = atof(getString.c_str());
        getline(fin, getString), expansionLeftCurrent = atof(getString.c_str());
        
        getline(fin, getString), expansionUPPosition1 = atof(getString.c_str());
        getline(fin, getString), expansionUPPosition2 = atof(getString.c_str());
        getline(fin, getString), expansionDownPosition1 = atof(getString.c_str());
        getline(fin, getString), expansionDownPosition2 = atof(getString.c_str());
        
        getline(fin, getString), expansionRightPosition1 = atof(getString.c_str());
        getline(fin, getString), expansionRightPosition2 = atof(getString.c_str());
        getline(fin, getString), expansionLeftPosition1 = atof(getString.c_str());
        getline(fin, getString), expansionLeftPosition2 = atof(getString.c_str());
        getline(fin, getString), blurStatusHold = atoi(getString.c_str());
        
        getline(fin, getString), xOrientation = atoi(getString.c_str());
        getline(fin, getString), yOrientation = atoi(getString.c_str());
        getline(fin, getString), xyInvert = atoi(getString.c_str());
        
        fin.close();
    }
    else{
        
        currentOriginalNo = 1;
        backgroundDisplayPage = 0;
        contrastCutOff1 = 100;
        contrastCutOff3 = 100;
        contrastCutOffAS = 1;
        baseContrastSet1 = 0;
        baseContrastSet3 = 0;
        baseContrastSetAS = 0;
        rangeLimitCurrent = 0;
        rangeLimitCurrentHorizontal = 0;
        rangeLimitCurrentVertical = 0;
        
        expansionUPCurrent = 1;
        expansionDownCurrent = 1;
        expansionRightCurrent = 1;
        expansionLeftCurrent = 1;
        expansionUPPosition1 = 0;
        expansionUPPosition2 = 0;
        expansionDownPosition1 = 511;
        expansionDownPosition2 = 511;
        expansionRightPosition1 = 511;
        expansionRightPosition2 = 511;
        expansionLeftPosition1 = 0;
        expansionLeftPosition2 = 0;
        blurStatusHold = 1;
        xOrientation = 0;
        yOrientation = 0;
        xyInvert = 0;
    }
    
    if (xOrientation == 0) [xOrientationDisplay setStringValue:@"FW"];
    else [xOrientationDisplay setStringValue:@"RV"];
    
    if (yOrientation == 0) [yOrientationDisplay setStringValue:@"FW"];
    else [xOrientationDisplay setStringValue:@"RV"];
    
    if (xyInvert == 0) [xySwitchDisplay setStringValue:@"Off"];
    else [xySwitchDisplay setStringValue:@"On"];
    
    if (blurStatusHold == 0) [blurStatusDisplay setStringValue:@"On"];
    else [blurStatusDisplay setStringValue:@"Off"];
    
    productsFilesImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyName+"_Products"+"/"+"Source_Images";
    productsFilesTempPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyName+"_Products"+"/"+"Temp_Images";
    productsFilesInfoPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyName+"_Products"+"/"+"Analysis_Information";
    stitchedFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images"+"/"+bodyName+"_Image";
    productsStitchTempPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images"+"/"+"Temp_Image";
    stitchedFolderImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images"+"/"+batchImageBodyName+"_Image";
    
    if (batchImageBodyName == "nil") mkdir(stitchedFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    else mkdir(stitchedFolderImagePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    
    string productsFocalTreatmentPath = productsFilesInfoPath+"/"+"FI-TreatmentNameData";
    string productsFocalFOVPath = productsFilesInfoPath+"/"+"FI-FOVData";
    string productsContrastPath = productsFilesInfoPath+"/"+"CT-ContrastData";
    string productsContrastPathG = productsFilesInfoPath+"/"+"CT-ContrastDataG";
    string productsContrastPathB = productsFilesInfoPath+"/"+"CT-ContrastDataB";
    
    contrastSettingPath = productsFilesInfoPath+"/"+"CT-BasicSetting";
    fovPositionPath = productsFilesInfoPath+"/"+"CT-FOVPosition";
    fovPositionIFHoldPath = productsFilesInfoPath+"/"+"CT-FOVIFHoldPosition";
    contrastSettingTempPath = productsFilesTempPath+"/"+"CT-BasicSetting";
    fovPositionTempPath = productsFilesTempPath+"/"+"CT-FOVPosition";
    
    fin.open(contrastSettingPath.c_str(), ios::in);
    
    if (fin.is_open()){
        getline(fin, getString);
        entryNumber = atoi(getString.c_str());
        fin.close();
    }
    else entryNumber = 0;
    
    string entry;
    string entry2;
    string entry3;
    string timeValue;
    string productsFilesImagePath2;
    string productsFilesImagePath3;
    
    DIR *dir;
    struct dirent *dent;
    DIR *dir2;
    struct dirent *dent2;
    DIR *dir3;
    struct dirent *dent3;
    
    lastProductFileNo = 0;
    
    dir = opendir(productsFilesImagePath.c_str());
    
    if (dir != NULL){
        while ((dent = readdir(dir))){
            entry = dent -> d_name;
            
            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                if ((int)entry.find("~Sorted") != -1){
                    productsFilesImagePath2 = productsFilesImagePath+"/"+entry;
                    
                    dir2 = opendir(productsFilesImagePath2.c_str());
                    
                    if (dir2 != NULL){
                        while ((dent2 = readdir(dir2))){
                            entry2 = dent2 -> d_name;
                            
                            if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                if ((int)entry2.find("FOV") != -1){
                                    productsFilesImagePath3 = productsFilesImagePath2+"/"+entry2;
                                    
                                    dir3 = opendir(productsFilesImagePath3.c_str());
                                    
                                    if (dir3 != NULL){
                                        while ((dent3 = readdir(dir3))){
                                            entry3 = dent3 -> d_name;
                                            
                                            if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store"){
                                                if ((int)entry3.find("bmp") != -1 || (int)entry3.find("tif") != -1){
                                                    timeValue = entry3.substr(entry3.find("_")+1, 4);
                                                    
                                                    if (atoi(timeValue.c_str()) > lastProductFileNo) lastProductFileNo = atoi(timeValue.c_str());
                                                }
                                            }
                                        }
                                        
                                        closedir(dir3);
                                    }
                                    
                                    break;
                                }
                            }
                        }
                        
                        closedir(dir2);
                    }
                }
            }
        }
        
        closedir(dir);
    }
    
    totalFOVNoHoldInt = atoi(totalFOVNoHold.c_str());
    
    arrayContrastData = new string *[totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
    arrayContrastDataG = new string *[totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
    arrayContrastDataB = new string *[totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
    contrastDataLimit = entryNumber+50;
    
    for (int counter1 = 0; counter1 < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100; counter1++){
        arrayContrastData [counter1] = new string [entryNumber+50];
        arrayContrastDataG [counter1] = new string [entryNumber+50];
        arrayContrastDataB [counter1] = new string [entryNumber+50];
    }
    
    for (int counter1 = 0; counter1 < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100; counter1++){
        for (int counter2 = 0; counter2 < entryNumber+50; counter2++){
            arrayContrastData [counter1][counter2] = "0";
            arrayContrastDataG [counter1][counter2] = "0";
            arrayContrastDataB [counter1][counter2] = "0";
        }
    }
    
    contrastDataHorizontal = totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100;
    contrastDataEntry = entryNumber+50;
    
    int lineCount = 0;
    int rgbCheck = 0;
    
    fin.open(productsContrastPath.c_str(), ios::in);
    
    if (fin.is_open()){
        do{
            
            getline(fin, getString);
            
            if (getString != ""){
                arrayContrastData [lineCount][0] = "0";
                getline(fin, getString);
                arrayContrastData [lineCount][1] = "0";
                getline(fin, getString);
                arrayContrastData [lineCount][2] = "0";
                
                for (int counter1 = 0; counter1 < entryNumber; counter1++){
                    getline(fin, getString);
                    arrayContrastData [lineCount][counter1+3] = getString;
                }
                
                lineCount++;
            }
            
        } while (getString != "");
        
        fin.close();
    }
    
    fin.open(productsContrastPathG.c_str(), ios::in);
    
    if (fin.is_open()){
        lineCount = 0;
        rgbCheck = 1;
        
        do{
            
            getline(fin, getString);
            
            if (getString != ""){
                arrayContrastDataG [lineCount][0] = "0";
                getline(fin, getString);
                arrayContrastDataG [lineCount][1] = "0";
                getline(fin, getString);
                arrayContrastDataG [lineCount][2] = "0";
                
                for (int counter1 = 0; counter1 < entryNumber; counter1++){
                    getline(fin, getString);
                    arrayContrastDataG [lineCount][counter1+3] = getString;
                }
                
                lineCount++;
            }
            
        } while (getString != "");
        
        fin.close();
    }
    
    fin.open(productsContrastPathB.c_str(), ios::in);
    
    if (fin.is_open()){
        lineCount = 0;
        rgbCheck = 1;
        
        do{
            
            getline(fin, getString);
            
            if (getString != ""){
                arrayContrastDataB [lineCount][0] = "0";
                getline(fin, getString);
                arrayContrastDataB [lineCount][1] = "0";
                getline(fin, getString);
                arrayContrastDataB [lineCount][2] = "0";
                
                for (int counter1 = 0; counter1 < entryNumber; counter1++){
                    getline(fin, getString);
                    arrayContrastDataB [lineCount][counter1+3] = getString;
                }
                
                lineCount++;
            }
            
        } while (getString != "");
        
        fin.close();
    }
    
    arrayTreatmentNameDisplay = new string [totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
    arrayFOVNameDisplay = new string [totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
    
    treatmentNameDisplayCount = 0;
    fOVNameDisplayCount = 0;
    
    for (int counter1 = 0; counter1 < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100; counter1++){
        arrayTreatmentNameDisplay [counter1] = "nil";
        arrayFOVNameDisplay [counter1] = "nil";
    }
    
    fin.open(productsFocalTreatmentPath.c_str(), ios::in);
    
    if (fin.is_open()){
        do{
            
            getline(fin, getString);
            
            if (getString != "") arrayTreatmentNameDisplay [treatmentNameDisplayCount] = getString, treatmentNameDisplayCount++;
            
        } while (getString != "");
        
        fin.close();
    }
    
    contrastCurrentHold = new string [treatmentNameDisplayCount+10];
    contrastCurrentHoldG = new string [treatmentNameDisplayCount+10];
    contrastCurrentHoldB = new string [treatmentNameDisplayCount+10];
    
    fin.open(productsFocalFOVPath.c_str(), ios::in);
    
    if (fin.is_open()){
        do{
            
            getline(fin, getString);
            
            if (getString != "") arrayFOVNameDisplay [fOVNameDisplayCount] = getString, fOVNameDisplayCount++;
            
        } while (getString != "");
        
        fin.close();
    }
    
    string treatNameCheck;
    string fileNoCheckPath;
    string fileNoCheck;
    int lastImageNoTemp = 0;
    
    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
        if (arrayTreatmentNameDisplay [counter1] != "ND" && (int)arrayTreatmentNameDisplay [counter1].find("CH") == -1){
            treatNameCheck = arrayTreatmentNameDisplay [counter1];
            
            if (batchImageBodyName == "nil") fileNoCheckPath = stitchedFolderPath+"/"+treatNameCheck+"_Stitch";
            else fileNoCheckPath = stitchedFolderImagePath+"/"+treatNameCheck+"_Stitch";
            
            dir = opendir(fileNoCheckPath.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("STimage ") != -1){
                        fileNoCheck = entry.substr(entry.find("STimage ")+8, 4);
                        
                        if (atoi(fileNoCheck.c_str()) > lastImageNoTemp) lastImageNoTemp = atoi(fileNoCheck.c_str());
                    }
                }
                
                closedir(dir);
            }
            
            if (lastImageNo < lastImageNoTemp) lastImageNo = lastImageNoTemp;
        }
    }
    
    if (lastProductFileNo != 0) [lastPageNoDisplay setIntegerValue:lastProductFileNo];
    else [lastPageNoDisplay setIntegerValue:lastImageNo];
    
    int tempFileFind = 0;
    fileNoStringTemp = "";
    
    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
        if (arrayTreatmentNameDisplay [counter1] != "ND" && (int)arrayTreatmentNameDisplay [counter1].find("CH") == -1){
            treatNameCheck = arrayTreatmentNameDisplay [counter1];
            fileNoCheckPath = productsFilesTempPath+"/"+treatNameCheck+"~Sorted/FOV001";
            
            dir = opendir(fileNoCheckPath.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        fileNoCheck = entry.substr(entry.find("_")+1, entry.find("-")-entry.find("_")-1);
                        
                        if (atoi(fileNoCheck.c_str()) > tempFileFind){
                            tempFileFind = atoi(fileNoCheck.c_str());
                            fileNoStringTemp = fileNoCheck;
                        }
                    }
                }
                
                closedir(dir);
            }
        }
    }
    
    currentTimePoint = lastImageNo;
    
    if (tempFileFind != 0) lastImageNo++;
    
    [ timePointDisplay setIntegerValue:currentTimePoint];
    [totalFileDisplay setIntegerValue:lastImageNo];
    
    imagePosition = currentTimePoint;
    
    int startingTimePoint = 1;
    string timeDetermine;
    
    tableDisplayCount = 0;
    tableDisplayCountG = 0;
    tableDisplayCountB = 0;
    
    arrayTableDisplay = new string [(totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100)*5];
    arrayTableDisplayG = new string [(totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100)*5];
    arrayTableDisplayB = new string [(totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100)*5];
    
    for (int counter1 = 1; counter1 <= entryNumber; counter1++){
        timeDetermine = arrayContrastData [0][counter1+2];
        timeDetermine = timeDetermine.substr(1);
        
        if (atoi(timeDetermine.c_str()) < currentTimePoint+1) startingTimePoint = counter1;
    }
    
    int mode = 0;
    
    subprocesses = [[SubProcesses alloc] init];
    [subprocesses displayTableSetInit:startingTimePoint:rgbCheck:mode];
    
    if (rgbCheck == 1){
        rgbDisplayStatus = 1;
        [rgbStatusDisplay setStringValue:@"Red"];
        [rgbStatusHistDisplay setStringValue:@"Red"];
    }
    else{
        
        rgbDisplayStatus = 0;
        [rgbStatusDisplay setStringValue:@"Gray"];
        [rgbStatusHistDisplay setStringValue:@"Gray"];
    }
    
    //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayTableDisplay [counterA*5+counterB];
    //    cout<<" arrayTableDisplay "<<counterA+1<<endl;
    //}
    
    [reprocessFromDisplay setIntegerValue:0];
    [reprocessToDisplay setIntegerValue:0];
    
    arrayFileDelete = new string [100];
    fileDeleteCount = 0;
    fileDeleteLimit = 100;
    
    contrastValueHold = new double[50];
    contrastValueCount = 50;
    contrastValueHoldG = new double[50];
    contrastValueCountG = 50;
    contrastValueHoldB = new double[50];
    contrastValueCountB = 50;
    
    initialArraySet = 1;
    tableViewCall = 1;
    
    //for (int counterA = 0; counterA < lineCount; counterA++){
    //    for (int counterB = 0; counterB < entryNumber+3; counterB++) cout<<" "<<arrayContrastData [counterA][counterB];
    //    cout<<"  arrayContrastData "<<counterA+1<<endl;
    //}
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTermination object:self];
    controllerTimer = [NSTimer scheduledTimerWithTimeInterval:0.3 target:self selector:@selector(displayData) userInfo:nil repeats:YES];
}

-(void)displayData{
    if (tableViewCall == 1){
        tableViewCall = 0;
        [tableViewList reloadData];
    }
    
    if (tableCallCount == 1){
        tableCallCount = 0;
        rowIndexHold = tableCurrentRowHold;
    }
    
    if (tableCallCount > 1) tableCallCount = 0;
    
    if (imageInfoDisplayCall == 1){
        imageInfoDisplayCall = 2;
        
        [treatmentName setStringValue:@(loadImageTreatName.c_str())];
        
        if (processingFovNo == -1) [fovNoDisplay setStringValue:@"All"];
        else [fovNoDisplay setIntegerValue:processingFovNo];
        
        [lockStatus setStringValue:@(imageFLStatus.c_str())];
        [backImageDisplay setStringValue:@(backgroundOADisplay.c_str())];
    }
    
    if (backgroundCorrectionCall == 1){
        [backSave startAnimation:self];
        
        if (backSave) backgroundCorrectionCall = 2;
    }
    else if (backgroundCorrectionCall == 2){
        backgroundCorrectionCall = 3;
        
        int bcType = 1;
        int fovNoSend = 0;
        
        backgroundCorrection = [[BackgroundCorrection alloc] init];
        [backgroundCorrection backgroundImageSub:bcType:fovNoSend:imageDimensionX:imageDimensionY];
        
        mainImageDisplayCall = 1;
        imageInfoDisplayCall = 1;
        contrastDisplayCall = 1;
        histogramDisplayCall = 1;
    }
    else if (backgroundCorrectionCall == 4){
        [backSave stopAnimation:self];
        
        if (backSave) backgroundCorrectionCall = 0;
    }
    
    if (mainImageDisplayCall == 1){
        mainImageDisplayCall = 0;
        
        if (backgroundOADisplay == "Off"){
            if (photoMetricHold == 1){
                for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                    for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            if (counter2+arrayXYWritingPosition [counter1*2+1] >= 0 && counter2+arrayXYWritingPosition [counter1*2+1] < stitchImageDimension && counter3+arrayXYWritingPosition [counter1*2] >= 0 && counter3+arrayXYWritingPosition [counter1*2] < stitchImageDimension){
                                if (arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3] >= 0){
                                    imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3];
                                }
                                else imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = 0;
                                
                                imagePositionMap [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = counter1;
                            }
                        }
                    }
                }
            }
            else if (photoMetricHold == 2){
                for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                    for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            if (counter2+arrayXYWritingPosition [counter1*2+1] >= 0 && counter2+arrayXYWritingPosition [counter1*2+1] < stitchImageDimension && counter3+arrayXYWritingPosition [counter1*2] >= 0 && counter3+arrayXYWritingPosition [counter1*2] < stitchImageDimension){
                                if (arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3] >= 0){
                                    imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3] = arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3];
                                    imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3+1] = arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3+1];
                                    imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3+2] = arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3+2];
                                }
                                else{
                                    
                                    imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3] = 0;
                                    imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3+1] = 0;
                                    imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3+2] = 0;
                                }
                                
                                imagePositionMap [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3] = counter1;
                                imagePositionMap [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3+1] = counter1;
                                imagePositionMap [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3+2] = counter1;
                            }
                        }
                    }
                }
            }
        }
        else if (backgroundOADisplay == "On"){
            for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        if (counter2+arrayXYWritingPosition [counter1*2+1] >= 0 && counter2+arrayXYWritingPosition [counter1*2+1] < stitchImageDimension && counter3+arrayXYWritingPosition [counter1*2] >= 0 && counter3+arrayXYWritingPosition [counter1*2] < stitchImageDimension){
                            if (arrayBackgroundDataHold [(counter1-1)*imageDimensionY+counter2][counter3] >= 0){
                                imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = arrayBackgroundDataHold [(counter1-1)*imageDimensionY+counter2][counter3];
                            }
                            else imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = 0;
                            
                            imagePositionMap [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = counter1;
                        }
                    }
                }
            }
        }
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMainImage object:self];
    }
    
    if (histogramDisplayCall == 1){
        histogramDisplayCall = 0;
        histoMaxCount = 0;
        
        if (processingFovNo == -1){
            histoMaxCount = 0;
            lowValueDisplay = 0;
            meanValueDisplay = 0;
            highValueDisplay = 0;
            lowValueDisplayG = 0;
            meanValueDisplayG = 0;
            highValueDisplayG = 0;
            lowValueDisplayB = 0;
            meanValueDisplayB = 0;
            highValueDisplayB = 0;
            
            for (int counter1 = 1; counter1 < 256; counter1++){
                if (arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter1] > histoMaxCount) histoMaxCount = arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter1];
                
                if (photoMetricHold == 2){
                    if (arrayImageContrastAdjustHistogramG [loadImageFOVNo*256+counter1] > histoMaxCount) histoMaxCount = arrayImageContrastAdjustHistogramG [loadImageFOVNo*256+counter1];
                    if (arrayImageContrastAdjustHistogramB [loadImageFOVNo*256+counter1] > histoMaxCount) histoMaxCount = arrayImageContrastAdjustHistogramB [loadImageFOVNo*256+counter1];
                }
            }
            
            if (histoMaxCount > 2000*loadImageFOVNo) histoMaxCount = 2000*loadImageFOVNo;
            
            lowValueDisplay = autoContrastCorrectLMH2 [loadImageFOVNo*3];
            meanValueDisplay = autoContrastCorrectLMH2 [loadImageFOVNo*3+1];
            highValueDisplay = autoContrastCorrectLMH2 [loadImageFOVNo*3+2];
            
            if (photoMetricHold == 2){
                lowValueDisplayG = autoContrastCorrectLMH2G [loadImageFOVNo*3];
                meanValueDisplayG = autoContrastCorrectLMH2G [loadImageFOVNo*3+1];
                highValueDisplayG = autoContrastCorrectLMH2G [loadImageFOVNo*3+2];
                
                lowValueDisplayB = autoContrastCorrectLMH2B [loadImageFOVNo*3];
                meanValueDisplayB = autoContrastCorrectLMH2B [loadImageFOVNo*3+1];
                highValueDisplayB = autoContrastCorrectLMH2B [loadImageFOVNo*3+2];
            }
        }
        else if (processingFovNo > 0){
            histoMaxCount = 0;
            lowValueDisplay = 0;
            meanValueDisplay = 0;
            highValueDisplay = 0;
            lowValueDisplayG = 0;
            meanValueDisplayG = 0;
            highValueDisplayG = 0;
            lowValueDisplayB = 0;
            meanValueDisplayB = 0;
            highValueDisplayB = 0;
            
            for (int counter1 = 1; counter1 < 256; counter1++){
                if (arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1] > histoMaxCount) histoMaxCount = arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1];
                
                if (photoMetricHold == 2){
                    if (arrayImageContrastAdjustHistogramG [(processingFovNo-1)*256+counter1] > histoMaxCount) histoMaxCount = arrayImageContrastAdjustHistogramG [(processingFovNo-1)*256+counter1];
                    if (arrayImageContrastAdjustHistogramB [(processingFovNo-1)*256+counter1] > histoMaxCount) histoMaxCount = arrayImageContrastAdjustHistogramB [(processingFovNo-1)*256+counter1];
                }
            }
            
            if (histoMaxCount > 2000) histoMaxCount = 2000;
            
            lowValueDisplay = autoContrastCorrectLMH2 [(processingFovNo-1)*3];
            meanValueDisplay = autoContrastCorrectLMH2 [(processingFovNo-1)*3+1];
            highValueDisplay = autoContrastCorrectLMH2 [(processingFovNo-1)*3+2];
            
            if (photoMetricHold == 2){
                lowValueDisplayG = autoContrastCorrectLMH2G [(processingFovNo-1)*3];
                meanValueDisplayG = autoContrastCorrectLMH2G [(processingFovNo-1)*3+1];
                highValueDisplayG = autoContrastCorrectLMH2G [(processingFovNo-1)*3+2];
                
                lowValueDisplayB = autoContrastCorrectLMH2B [(processingFovNo-1)*3];
                meanValueDisplayB = autoContrastCorrectLMH2B [(processingFovNo-1)*3+1];
                highValueDisplayB = autoContrastCorrectLMH2B [(processingFovNo-1)*3+2];
            }
        }
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToHistogram object:self];
    }
    
    if (contrastDisplayCall == 1){
        contrastDisplayCall = 0;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToContrastWindow object:self];
    }
    
    if (timePointDisplayCall == 1){
        timePointDisplayCall = 0;
        [timePointDisplay setIntegerValue:currentTimePoint];
    }
    
    if ((processMode == 5 || processMode == 7 || processMode == 13) && imageProcessTiming == 1){
        int instructionCSFlag = 0;
        string getString;
        
        ifstream fin;
        
        fin.open(instructionCSPath.c_str(), ios::in);
        if (fin.is_open()) instructionCSFlag = 1, fin.close();
        
        if (instructionCSFlag != 0){
            fin.open(instructionCSPath.c_str(), ios::in);
            
            getline(fin, getString);
            
            fin.close();
            
            if (getString == "Next"){
                int dirOpenCheck = 0;
                int lastImageNoTemp = 0;
                
                string treatNameCheckTemp;
                string fileNoCheckPath;
                string entry;
                string fileNoCheck;
                
                lastImageNo = 0;
                currentTimePoint = 0;
                
                DIR *dir;
                struct dirent *dent;
                
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    if (arrayTreatmentNameDisplay [counter1] != "ND" && (int)arrayTreatmentNameDisplay [counter1].find("CH") == -1){
                        treatNameCheckTemp = arrayTreatmentNameDisplay [counter1];
                        
                        if (batchImageBodyName == "nil") fileNoCheckPath = stitchedFolderPath+"/"+treatNameCheckTemp+"_Stitch";
                        else fileNoCheckPath = stitchedFolderImagePath+"/"+treatNameCheckTemp+"_Stitch";
                        
                        dir = opendir(fileNoCheckPath.c_str());
                        
                        if (dir != NULL){
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                    fileNoCheck = entry.substr(entry.find("STimage ")+8, 4);
                                    
                                    if (atoi(fileNoCheck.c_str()) > lastImageNoTemp) lastImageNoTemp = atoi(fileNoCheck.c_str());
                                }
                            }
                            
                            closedir(dir);
                        }
                        else dirOpenCheck = 1;
                        
                        if (lastImageNo < lastImageNoTemp) lastImageNo = lastImageNoTemp;
                    }
                }
                
                if (lastProductFileNo != 0) [lastPageNoDisplay setIntegerValue:lastProductFileNo];
                else [lastPageNoDisplay setIntegerValue:lastImageNo];
                
                int tempFileFind = 0;
                fileNoStringTemp = "";
                
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    if (arrayTreatmentNameDisplay [counter1] != "ND" && (int)arrayTreatmentNameDisplay [counter1].find("CH") == -1){
                        treatNameCheckTemp = arrayTreatmentNameDisplay [counter1];
                        fileNoCheckPath = productsFilesTempPath+"/"+treatNameCheckTemp+"~Sorted/FOV001";
                        
                        dir = opendir(fileNoCheckPath.c_str());
                        
                        if (dir != NULL){
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                    fileNoCheck = entry.substr(entry.find("_")+1, entry.find("-")-entry.find("_")-1);
                                    
                                    if (atoi(fileNoCheck.c_str()) > tempFileFind){
                                        tempFileFind = atoi(fileNoCheck.c_str());
                                        fileNoStringTemp = fileNoCheck;
                                    }
                                }
                            }
                            
                            closedir(dir);
                        }
                        else dirOpenCheck = 1;
                    }
                }
                
                if (dirOpenCheck == 0){
                    currentTimePoint = lastImageNo;
                    
                    if (tempFileFind != 0) lastImageNo++;
                    if (fileNoStringTemp != "") imageProcessTiming = 2;
                }
            }
            else if (getString == "Exit") exitFlag = 1;
        }
    }
    if ((processMode == 5 || processMode == 7 || processMode == 13) && imageProcessTiming == 2){
        imageProcessTiming = 4;
        [self processStartSub];
    }
    
    if (timePointRequest == 1){
        timePointRequest = 0;
        [timePointDisplay setIntegerValue:currentTimePoint];
    }
    
    if (exitFlag == 1) [self processStopMain];
    
    if (callFromHistogram >= 2) callFromHistogram = 0;
    
    if (overlayStatusSend >= 2) overlayStatusSend = 0;
    
    //-----Re-do process-----
    if (reprocessStartFlag == 1){
        reprocessStartFlag = 2;
        reprocessImageNo++;
        
        [reprocessNoDisplay setIntegerValue:reprocessImageNo];
        
        if (reprocessImageNo > processingToHold){
            reprocessStartFlag = 0;
            [reprocessNoDisplay setStringValue:@"nil"];
        }
    }
    else if (reprocessStartFlag == 2){
        reprocessStartFlag = 3;
        autoType = 5;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToAutocontrast object:self];
    }
    else if (reprocessStartFlag == 4){
        if (reprocessStatus == 0){
            reprocessStartFlag = 0;
            [reprocessNoDisplay setStringValue:@"nil"];
        }
        else reprocessStartFlag = 1;
    }
    
    if (progressTiming == 1){
        [progressIndicator setMinValue:0];
        [progressIndicator setMaxValue:progressValue];
        [progressIndicator startAnimation:self];
        [progressIndicator setHidden:NO];
        
        double bValue = [progressIndicator maxValue];
        
        if (progressIndicator){
            if (bValue == progressValue){
                [progressIndicator setDoubleValue:progressValue*0.1];
                [progressIndicator displayIfNeeded];
                
                double bValue2 = [progressIndicator doubleValue];
                
                if (bValue2 == progressValue*0.1) progressTiming = 2;
            }
        }
    }
    else if (progressTiming == 3){
        [progressIndicator setDoubleValue:progressValue];
        [progressIndicator displayIfNeeded];
        
        double bValue = [progressIndicator doubleValue];
        
        if (bValue == progressValue) progressTiming = 4;
    }
    else if (progressTiming == 5){
        [progressIndicator setDoubleValue:0];
        [progressIndicator displayIfNeeded];
        
        double bValue = [progressIndicator doubleValue];
        
        if (bValue == 0) progressTiming = 6;
    }
    else if (progressTiming == 7){
        [progressIndicator stopAnimation:self];
        
        if (!progressIndicator) progressTiming = 0;
    }
    
    if (bkUnUsedCall == 1){
        bkUnUsedCall = 0;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
    }
    
    if (colorNameDisplayCall == 1){
        colorNameDisplayCall = 0;
        [histColorStatusDisplay setStringValue:@(colorNameHold.c_str())];
    }
    
    [self communication];
}

-(void)communication{
    //-----Initial establishment-----
    if (firstCommunication == 0){
        firstCommunication = 1;
        basicInfoRead = 1;
    }
    
    //-----Basic info and holding flag read-----
    if (firstCommunication == 1 && basicInfoRead == 1) basicInfoRead = 2;
    
    if (firstCommunication == 1 && basicInfoRead == 2){
        string runStatusTemp = "nil";
        string statusIFTemp;
        string receivedData = "0";
        string getString = "nil";
        
        int instructionCSFlag = 0;
        
        ifstream fin;
        fin.open(instructionCSPath.c_str(), ios::in);
        if (fin.is_open()){
            instructionCSFlag = 1;
            fin.close();
        }
        
        if (instructionCSFlag != 0){
            fin.open(instructionCSPath.c_str(), ios::in);
            
            getline(fin, getString), runStatusTemp = getString;
            getline(fin, getString), statusIFTemp = getString;
            
            if (atoi(runStatusTemp.c_str()) >= 2 && atoi(runStatusTemp.c_str()) <= 13){
                receivedData = runStatusTemp;
                remove (instructionCSPath.c_str());
            }
            
            fin.close();
        }
        
        if (receivedData != "nil"){
            processMode = atoi(runStatusTemp.c_str());
            statusIFHold = atoi(statusIFTemp.c_str());
            
            if (processMode == 2 || processMode == 8 || processMode == 10){ //-----In the case of Batch, NAAssign File has to be created by Process Controller-----
                if (processMode == 2 || processMode == 8){
                    remove(fovPositionPath.c_str());
                    remove(contrastSettingPath.c_str());
                    remove(fovPositionIFHoldPath.c_str());
                }
                
                remove(loadingCompletePath.c_str());
                
                ofstream oin;
                
                [processModeDisplay setStringValue:@"Init."];
                
                fluorescentCount = 0;
                
                string nameAssignFilePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/NAAssignedName";
                
                fin.open(nameAssignFilePath.c_str(), ios::in);
                
                if (fin.is_open()){
                    for (int counter1 = 0; counter1 < 57; counter1++) getline(fin, getString);
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        getline(fin, getString);
                        
                        if (getString != "nil") fluorescentCount++;
                        
                        getline(fin, getString);
                        
                        if (getString != "nil" && counter1 == 0) fluorescent1 = getString;
                        if (getString != "nil" && counter1 == 1) fluorescent2 = getString;
                        if (getString != "nil" && counter1 == 2) fluorescent3 = getString;
                        if (getString != "nil" && counter1 == 3) fluorescent4 = getString;
                        if (getString != "nil" && counter1 == 4) fluorescent5 = getString;
                        if (getString != "nil" && counter1 == 5) fluorescent6 = getString;
                        
                        getline(fin, getString);
                    }
                    
                    fin.close();
                }
                
                if (statusIFHold == 1){
                    string stringIFFind = bodyName.substr(bodyName.length()-2);
                    
                    if (stringIFFind == "IF"){
                        stringIFFind = bodyName.substr(0, bodyName.length()-2);
                        string sourceFovPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+stringIFFind+"_Products"+"/"+"Analysis_Information/CT-FOVPosition";
                        
                        struct stat sizeOfFile;
                        
                        long sizeForCopy = 0;
                        
                        if (stat(sourceFovPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            ifstream infile (sourceFovPath.c_str(), ifstream::binary);
                            ofstream outfile (fovPositionPath.c_str(), ofstream::binary);
                            
                            char* buffer = new char[sizeForCopy];
                            infile.read (buffer, sizeForCopy);
                            outfile.write (buffer, sizeForCopy);
                            delete[] buffer;
                            
                            outfile.close();
                            infile.close();
                        }
                        
                        int entryCount = 0;
                        
                        fin.open(fovPositionPath.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            do{
                                
                                getline(fin, getString);
                                
                                if (getString != "") entryCount++;
                                
                            } while (getString != "");
                            
                            fin.close();
                        }
                        
                        string *fovPositionTempHold = new string [entryCount+50];
                        int fovPositionTempHoldCount = 0;
                        
                        int treatFind = 0;
                        int firstEntry = 0;
                        int chFindFlag = 0;
                        
                        fin.open(fovPositionPath.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            do{
                                
                                getline(fin, getString);
                                
                                if (firstEntry == 0){
                                    firstEntry = 1, treatFind = 1;
                                    fovPositionTempHold [fovPositionTempHoldCount] = getString, fovPositionTempHoldCount++;
                                }
                                else if (getString != "ND" && treatFind == 1 && firstEntry == 1){
                                    fovPositionTempHold [fovPositionTempHoldCount] = getString, fovPositionTempHoldCount++;
                                }
                                else if (getString == "ND" && treatFind == 1 && firstEntry == 1){
                                    firstEntry = 2, treatFind = 0;
                                    fovPositionTempHold [fovPositionTempHoldCount] = getString, fovPositionTempHoldCount++;
                                }
                                else if (firstEntry == 2 && treatFind == 0 && chFindFlag == 0){
                                    if ((int)getString.find("CH1") != -1) chFindFlag = 1;
                                    else if ((int)getString.find("CH2") != -1) chFindFlag = 1;
                                    else if ((int)getString.find("CH3") != -1) chFindFlag = 1;
                                    else if ((int)getString.find("CH4") != -1) chFindFlag = 1;
                                    else if ((int)getString.find("CH5") != -1) chFindFlag = 1;
                                    else if ((int)getString.find("CH6") != -1) chFindFlag = 1;
                                    else chFindFlag = 2;
                                }
                                
                                if (getString != "" && firstEntry == 2 && treatFind == 0 && chFindFlag == 1) treatFind = 1;
                                else if (getString == "ND" && treatFind == 1 && firstEntry == 2 && chFindFlag == 1){
                                    treatFind = 0;
                                    chFindFlag = 0;
                                }
                                
                                if (getString != "" && firstEntry == 2 && treatFind == 0 && chFindFlag == 2){
                                    treatFind = 1;
                                    fovPositionTempHold [fovPositionTempHoldCount] = getString, fovPositionTempHoldCount++;
                                }
                                else if (getString != "" && getString != "ND" && treatFind == 1 && firstEntry == 2 && chFindFlag == 2){
                                    fovPositionTempHold [fovPositionTempHoldCount] = getString, fovPositionTempHoldCount++;
                                }
                                else if (getString == "ND" && treatFind == 1 && firstEntry == 2 && chFindFlag == 2){
                                    treatFind = 0;
                                    chFindFlag = 0;
                                    fovPositionTempHold [fovPositionTempHoldCount] = getString, fovPositionTempHoldCount++;
                                }
                                
                            } while (getString != "");
                            
                            fin.close();
                        }
                        
                        string *fovPositionTempHold2 = new string [fovPositionTempHoldCount*6+50];
                        int fovPositionTempHoldCount2 = 0;
                        
                        string *fovPositionTreat = new string [fovPositionTempHoldCount*6+50];
                        int fovPositionTreatCount = 0;
                        
                        treatFind = 0;
                        firstEntry = 0;
                        string entryNo = "";
                        string fluorescentNameTemp = "";
                        
                        for (int counter1 = 0; counter1 < fovPositionTempHoldCount; counter1++){
                            entryNo = fovPositionTempHold [counter1];
                            
                            if (firstEntry == 0){
                                firstEntry = 1, treatFind = 1;
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = entryNo, fovPositionTempHoldCount2++;
                                fovPositionTreat [fovPositionTreatCount] = entryNo, fovPositionTreatCount++;
                            }
                            else if (entryNo != "ND" && treatFind == 1 && firstEntry == 1){
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = entryNo, fovPositionTempHoldCount2++;
                                fovPositionTreat [fovPositionTreatCount] = entryNo, fovPositionTreatCount++;
                            }
                            else if (entryNo == "ND" && treatFind == 1 && firstEntry == 1){
                                firstEntry = 2, treatFind = 2;
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = entryNo, fovPositionTempHoldCount2++;
                                fovPositionTreat [fovPositionTreatCount] = entryNo, fovPositionTreatCount++;
                            }
                            
                            if (firstEntry == 2 && treatFind == 0){
                                treatFind = 1;
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = entryNo, fovPositionTempHoldCount2++;
                                fovPositionTreat [fovPositionTreatCount] = entryNo, fovPositionTreatCount++;
                            }
                            else if (entryNo != "ND" && treatFind == 1 && firstEntry == 2){
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = entryNo, fovPositionTempHoldCount2++;
                                fovPositionTreat [fovPositionTreatCount] = entryNo, fovPositionTreatCount++;
                            }
                            else if (entryNo == "ND" && treatFind == 1 && firstEntry == 2){
                                treatFind = 2;
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = entryNo, fovPositionTempHoldCount2++;
                                fovPositionTreat [fovPositionTreatCount] = entryNo, fovPositionTreatCount++;
                            }
                            
                            if (fluorescent1 != "" && treatFind == 2){
                                fluorescentNameTemp = fovPositionTreat [0]+"CH1";
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = fluorescentNameTemp, fovPositionTempHoldCount2++;
                                
                                for (int counter2 = 1; counter2 < fovPositionTreatCount; counter2++){
                                    fovPositionTempHold2 [fovPositionTempHoldCount2] = fovPositionTreat [counter2], fovPositionTempHoldCount2++;
                                }
                            }
                            
                            if (fluorescent2 != "" && treatFind == 2){
                                fluorescentNameTemp = fovPositionTreat [0]+"CH2";
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = fluorescentNameTemp, fovPositionTempHoldCount2++;
                                
                                for (int counter2 = 1; counter2 < fovPositionTreatCount; counter2++){
                                    fovPositionTempHold2 [fovPositionTempHoldCount2] = fovPositionTreat [counter2], fovPositionTempHoldCount2++;
                                }
                            }
                            
                            if (fluorescent3 != "" && treatFind == 2){
                                fluorescentNameTemp = fovPositionTreat [0]+"CH3";
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = fluorescentNameTemp, fovPositionTempHoldCount2++;
                                
                                for (int counter2 = 1; counter2 < fovPositionTreatCount; counter2++){
                                    fovPositionTempHold2 [fovPositionTempHoldCount2] = fovPositionTreat [counter2], fovPositionTempHoldCount2++;
                                }
                            }
                            
                            if (fluorescent4 != "" && treatFind == 2){
                                fluorescentNameTemp = fovPositionTreat [0]+"CH4";
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = fluorescentNameTemp, fovPositionTempHoldCount2++;
                                
                                for (int counter2 = 1; counter2 < fovPositionTreatCount; counter2++){
                                    fovPositionTempHold2 [fovPositionTempHoldCount2] = fovPositionTreat [counter2], fovPositionTempHoldCount2++;
                                }
                            }
                            
                            if (fluorescent5 != "" && treatFind == 2){
                                fluorescentNameTemp = fovPositionTreat [0]+"CH5";
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = fluorescentNameTemp, fovPositionTempHoldCount2++;
                                
                                for (int counter2 = 1; counter2 < fovPositionTreatCount; counter2++){
                                    fovPositionTempHold2 [fovPositionTempHoldCount2] = fovPositionTreat [counter2], fovPositionTempHoldCount2++;
                                }
                            }
                            
                            if (fluorescent6 != "" && treatFind == 2){
                                fluorescentNameTemp = fovPositionTreat [0]+"CH6";
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = fluorescentNameTemp, fovPositionTempHoldCount2++;
                                
                                for (int counter2 = 1; counter2 < fovPositionTreatCount; counter2++){
                                    fovPositionTempHold2 [fovPositionTempHoldCount2] = fovPositionTreat [counter2], fovPositionTempHoldCount2++;
                                }
                            }
                            
                            if (treatFind == 2){
                                treatFind = 0;
                                fovPositionTreatCount = 0;
                            }
                        }
                        
                        oin.open(fovPositionPath.c_str(), ios::out);
                        for (int counter1 = 0; counter1 <fovPositionTempHoldCount2; counter1++) oin<<fovPositionTempHold2 [counter1]<<endl;
                        oin.close();
                        
                        oin.open(fovPositionIFHoldPath.c_str(), ios::out);
                        for (int counter1 = 0; counter1 <fovPositionTempHoldCount2; counter1++) oin<<fovPositionTempHold2 [counter1]<<endl;
                        oin.close();
                        
                        delete [] fovPositionTempHold;
                        delete [] fovPositionTempHold2;
                        delete [] fovPositionTreat;
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"IF Folder Missing. Check Its Presence And Name"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                        
                        exitFlag = 1;
                    }
                }
                else if (statusIFHold == 2){
                    string stringIFFind = bodyName.substr(bodyName.length()-2);
                    
                    if (stringIFFind == "IF"){
                        int entryCount = 0;
                        
                        fin.open(fovPositionPath.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            do{
                                
                                getline(fin, getString);
                                
                                if (getString != "") entryCount++;
                                
                            } while (getString != "");
                            
                            fin.close();
                        }
                        
                        string *fovPositionTempHold = new string [entryCount+50];
                        int fovPositionTempHoldCount = 0;
                        
                        int treatFind = 0;
                        int firstEntry = 0;
                        int chFindFlag = 0;
                        
                        fin.open(fovPositionPath.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            do{
                                
                                getline(fin, getString);
                                
                                if (firstEntry == 0){
                                    firstEntry = 1, treatFind = 1;
                                    fovPositionTempHold [fovPositionTempHoldCount] = getString, fovPositionTempHoldCount++;
                                }
                                else if (getString != "ND" && treatFind == 1 && firstEntry == 1){
                                    fovPositionTempHold [fovPositionTempHoldCount] = getString, fovPositionTempHoldCount++;
                                }
                                else if (getString == "ND" && treatFind == 1 && firstEntry == 1){
                                    firstEntry = 2;
                                    treatFind = 0;
                                    fovPositionTempHold [fovPositionTempHoldCount] = getString, fovPositionTempHoldCount++;
                                }
                                else if (firstEntry == 2 && treatFind == 0 && chFindFlag == 0){
                                    if ((int)getString.find("CH1") != -1) chFindFlag = 1;
                                    else if ((int)getString.find("CH2") != -1) chFindFlag = 1;
                                    else if ((int)getString.find("CH3") != -1) chFindFlag = 1;
                                    else if ((int)getString.find("CH4") != -1) chFindFlag = 1;
                                    else if ((int)getString.find("CH5") != -1) chFindFlag = 1;
                                    else if ((int)getString.find("CH6") != -1) chFindFlag = 1;
                                    else chFindFlag = 2;
                                }
                                
                                if (getString != "" && firstEntry == 2 && treatFind == 0 && chFindFlag == 1){
                                    treatFind = 1;
                                }
                                else if (getString == "ND" && treatFind == 1 && firstEntry == 2 && chFindFlag == 1){
                                    treatFind = 0;
                                    chFindFlag = 0;
                                }
                                
                                if (getString != "" && firstEntry == 2 && treatFind == 0 && chFindFlag == 2){
                                    treatFind = 1;
                                    fovPositionTempHold [fovPositionTempHoldCount] = getString, fovPositionTempHoldCount++;
                                }
                                else if (getString != "" && getString != "ND" && treatFind == 1 && firstEntry == 2 && chFindFlag == 2){
                                    fovPositionTempHold [fovPositionTempHoldCount] = getString, fovPositionTempHoldCount++;
                                }
                                else if (getString == "ND" && treatFind == 1 && firstEntry == 2 && chFindFlag == 2){
                                    treatFind = 0;
                                    chFindFlag = 0;
                                    fovPositionTempHold [fovPositionTempHoldCount] = getString, fovPositionTempHoldCount++;
                                }
                                
                            } while (getString != "");
                            
                            fin.close();
                        }
                        
                        string *fovPositionTempHold2 = new string [fovPositionTempHoldCount*4+50];
                        int fovPositionTempHoldCount2 = 0;
                        
                        string *fovPositionTreat = new string [fovPositionTempHoldCount*4+50];
                        int fovPositionTreatCount = 0;
                        
                        treatFind = 0;
                        firstEntry = 0;
                        string entryNo = "";
                        string fluorescentNameTemp = "";
                        
                        for (int counter1 = 0; counter1 < fovPositionTempHoldCount; counter1++){
                            entryNo = fovPositionTempHold [counter1];
                            
                            if (firstEntry == 0){
                                firstEntry = 1;
                                treatFind = 1;
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = entryNo, fovPositionTempHoldCount2++;
                                fovPositionTreat [fovPositionTreatCount] = entryNo, fovPositionTreatCount++;
                            }
                            else if (entryNo != "ND" && treatFind == 1 && firstEntry == 1){
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = entryNo, fovPositionTempHoldCount2++;
                                fovPositionTreat [fovPositionTreatCount] = entryNo, fovPositionTreatCount++;
                            }
                            else if (entryNo == "ND" && treatFind == 1 && firstEntry == 1){
                                firstEntry = 2;
                                treatFind = 2;
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = entryNo, fovPositionTempHoldCount2++;
                                fovPositionTreat [fovPositionTreatCount] = entryNo, fovPositionTreatCount++;
                            }
                            
                            if (firstEntry == 2 && treatFind == 0){
                                treatFind = 1;
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = entryNo, fovPositionTempHoldCount2++;
                                fovPositionTreat [fovPositionTreatCount] = entryNo, fovPositionTreatCount++;
                            }
                            else if (entryNo != "ND" && treatFind == 1 && firstEntry == 2){
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = entryNo, fovPositionTempHoldCount2++;
                                fovPositionTreat [fovPositionTreatCount] = entryNo, fovPositionTreatCount++;
                            }
                            else if (entryNo == "ND" && treatFind == 1 && firstEntry == 2){
                                treatFind = 2;
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = entryNo, fovPositionTempHoldCount2++;
                                fovPositionTreat [fovPositionTreatCount] = entryNo, fovPositionTreatCount++;
                            }
                            
                            if (fluorescent1 != "" && treatFind == 2){
                                fluorescentNameTemp = fovPositionTreat [0]+"CH1";
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = fluorescentNameTemp, fovPositionTempHoldCount2++;
                                
                                for (int counter2 = 1; counter2 < fovPositionTreatCount; counter2++){
                                    fovPositionTempHold2 [fovPositionTempHoldCount2] = fovPositionTreat [counter2], fovPositionTempHoldCount2++;
                                }
                            }
                            
                            if (fluorescent2 != "" && treatFind == 2){
                                fluorescentNameTemp = fovPositionTreat [0]+"CH2";
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = fluorescentNameTemp, fovPositionTempHoldCount2++;
                                
                                for (int counter2 = 1; counter2 < fovPositionTreatCount; counter2++){
                                    fovPositionTempHold2 [fovPositionTempHoldCount2] = fovPositionTreat [counter2], fovPositionTempHoldCount2++;
                                }
                            }
                            
                            if (fluorescent3 != "" && treatFind == 2){
                                fluorescentNameTemp = fovPositionTreat [0]+"CH3";
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = fluorescentNameTemp, fovPositionTempHoldCount2++;
                                
                                for (int counter2 = 1; counter2 < fovPositionTreatCount; counter2++){
                                    fovPositionTempHold2 [fovPositionTempHoldCount2] = fovPositionTreat [counter2], fovPositionTempHoldCount2++;
                                }
                            }
                            
                            if (fluorescent4 != "" && treatFind == 2){
                                fluorescentNameTemp = fovPositionTreat [0]+"CH4";
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = fluorescentNameTemp, fovPositionTempHoldCount2++;
                                
                                for (int counter2 = 1; counter2 < fovPositionTreatCount; counter2++){
                                    fovPositionTempHold2 [fovPositionTempHoldCount2] = fovPositionTreat [counter2], fovPositionTempHoldCount2++;
                                }
                            }
                            
                            if (fluorescent5 != "" && treatFind == 2){
                                fluorescentNameTemp = fovPositionTreat [0]+"CH5";
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = fluorescentNameTemp, fovPositionTempHoldCount2++;
                                
                                for (int counter2 = 1; counter2 < fovPositionTreatCount; counter2++){
                                    fovPositionTempHold2 [fovPositionTempHoldCount2] = fovPositionTreat [counter2], fovPositionTempHoldCount2++;
                                }
                            }
                            
                            if (fluorescent6 != "" && treatFind == 2){
                                fluorescentNameTemp = fovPositionTreat [0]+"CH6";
                                fovPositionTempHold2 [fovPositionTempHoldCount2] = fluorescentNameTemp, fovPositionTempHoldCount2++;
                                
                                for (int counter2 = 1; counter2 < fovPositionTreatCount; counter2++){
                                    fovPositionTempHold2 [fovPositionTempHoldCount2] = fovPositionTreat [counter2], fovPositionTempHoldCount2++;
                                }
                            }
                            
                            if (treatFind == 2){
                                treatFind = 0;
                                fovPositionTreatCount = 0;
                            }
                        }
                        
                        oin.open(fovPositionPath.c_str(), ios::out);
                        for (int counter1 = 0; counter1 <fovPositionTempHoldCount2; counter1++) oin<<fovPositionTempHold2 [counter1]<<endl;
                        oin.close();
                        
                        oin.open(fovPositionIFHoldPath.c_str(), ios::out);
                        for (int counter1 = 0; counter1 <fovPositionTempHoldCount2; counter1++) oin<<fovPositionTempHold2 [counter1]<<endl;
                        oin.close();
                        
                        delete [] fovPositionTempHold;
                        delete [] fovPositionTempHold2;
                        delete [] fovPositionTreat;
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"IF Folder Missing. Check Its Presence And Name"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                        
                        exitFlag = 1;
                    }
                }
                
                treatmentNameDisplayCount = 0;
                fOVNameDisplayCount = 0;
                
                for (int counter1 = 0; counter1 < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100; counter1++){
                    arrayTreatmentNameDisplay [counter1] = "nil";
                    arrayFOVNameDisplay [counter1] = "nil";
                }
                
                string productsFocalTreatmentPath = productsFilesInfoPath+"/"+"FI-TreatmentNameData";
                
                fin.open(productsFocalTreatmentPath.c_str(), ios::in);
                
                if (fin.is_open()){
                    do{
                        
                        getline(fin, getString);
                        
                        if (getString != "") arrayTreatmentNameDisplay [treatmentNameDisplayCount] = getString, treatmentNameDisplayCount++;
                        
                    } while (getString != "");
                    
                    fin.close();
                }
                
                //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
                //    cout<<arrayTreatmentNameDisplay [counterA]<<"  arrayTreatmentNameDisplay "<<endl;
                //}
                
                string productsFocalFOVPath = productsFilesInfoPath+"/"+"FI-FOVData";
                
                fin.open(productsFocalFOVPath.c_str(), ios::in);
                
                if (fin.is_open()){
                    do{
                        
                        getline(fin, getString);
                        
                        if (getString != "") arrayFOVNameDisplay [fOVNameDisplayCount] = getString, fOVNameDisplayCount++;
                        
                    } while (getString != "");
                    
                    fin.close();
                }
                
                //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
                //    cout<<counterA<<" "<<arrayTreatmentNameDisplay [counterA]<<" Treat"<<endl;
                //}
                
                //for (int counterA = 0; counterA < fOVNameDisplayCount; counterA++){
                //    cout<<counterA<<" "<<arrayFOVNameDisplay [counterA]<<" FOV"<<endl;
                //}
                
                if (processMode == 2 || processMode == 8){
                    currentTimePoint = 0;
                    entryNumber = 1;
                    
                    oin.open(contrastSettingPath.c_str(), ios::out);
                    oin<<to_string(entryNumber)<<endl;
                    oin.close();
                    
                    tableDisplayCount = 0;
                    
                    arrayTableDisplay [tableDisplayCount] = "Name", tableDisplayCount++;
                    arrayTableDisplay [tableDisplayCount] = "FOV", tableDisplayCount++;
                    arrayTableDisplay [tableDisplayCount] = "Image Data", tableDisplayCount++;
                    arrayTableDisplay [tableDisplayCount] = "T1", tableDisplayCount++;
                    arrayTableDisplay [tableDisplayCount] = "T*", tableDisplayCount++;
                    
                    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                        if (arrayTreatmentNameDisplay [counter1] != "ND") arrayTableDisplay [tableDisplayCount] = arrayTreatmentNameDisplay [counter1], tableDisplayCount++;
                        else arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
                        
                        if (arrayFOVNameDisplay [counter1] != "ND") arrayTableDisplay [tableDisplayCount] = arrayFOVNameDisplay [counter1], tableDisplayCount++;
                        else arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
                        
                        if (arrayFOVNameDisplay [counter1] != "ND"){
                            arrayTableDisplay [tableDisplayCount] = "ND", tableDisplayCount++;
                            
                            for (int counter2 = 0; counter2 < 2; counter2++) arrayTableDisplay [tableDisplayCount] = "0", tableDisplayCount++;
                        }
                        else{
                            
                            for (int counter2 = 0; counter2 < 3; counter2++) arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
                        }
                    }
                    
                    tableDisplayCountG = 0;
                    
                    arrayTableDisplayG [tableDisplayCountG] = "Name", tableDisplayCountG++;
                    arrayTableDisplayG [tableDisplayCountG] = "FOV", tableDisplayCountG++;
                    arrayTableDisplayG [tableDisplayCountG] = "Image Data", tableDisplayCountG++;
                    arrayTableDisplayG [tableDisplayCountG] = "T1", tableDisplayCountG++;
                    arrayTableDisplayG [tableDisplayCountG] = "T*", tableDisplayCountG++;
                    
                    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                        if (arrayTreatmentNameDisplay [counter1] != "ND") arrayTableDisplayG [tableDisplayCountG] = arrayTreatmentNameDisplay [counter1], tableDisplayCountG++;
                        else arrayTableDisplayG [tableDisplayCountG] = " ", tableDisplayCountG++;
                        
                        if (arrayFOVNameDisplay [counter1] != "ND") arrayTableDisplayG [tableDisplayCountG] = arrayFOVNameDisplay [counter1], tableDisplayCountG++;
                        else arrayTableDisplayG [tableDisplayCountG] = " ", tableDisplayCountG++;
                        
                        if (arrayFOVNameDisplay [counter1] != "ND"){
                            arrayTableDisplayG [tableDisplayCountG] = "ND", tableDisplayCountG++;
                            
                            for (int counter2 = 0; counter2 < 2; counter2++) arrayTableDisplayG [tableDisplayCountG] = "0", tableDisplayCountG++;
                        }
                        else{
                            
                            for (int counter2 = 0; counter2 < 3; counter2++) arrayTableDisplayG [tableDisplayCountG] = " ", tableDisplayCountG++;
                        }
                    }
                    
                    tableDisplayCountB = 0;
                    
                    arrayTableDisplayB [tableDisplayCountB] = "Name", tableDisplayCountB++;
                    arrayTableDisplayB [tableDisplayCountB] = "FOV", tableDisplayCountB++;
                    arrayTableDisplayB [tableDisplayCountB] = "Image Data", tableDisplayCountB++;
                    arrayTableDisplayB [tableDisplayCountB] = "T1", tableDisplayCountB++;
                    arrayTableDisplayB [tableDisplayCountB] = "T*", tableDisplayCountB++;
                    
                    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                        if (arrayTreatmentNameDisplay [counter1] != "ND") arrayTableDisplayB [tableDisplayCountB] = arrayTreatmentNameDisplay [counter1], tableDisplayCountB++;
                        else arrayTableDisplayB [tableDisplayCountB] = " ", tableDisplayCountB++;
                        
                        if (arrayFOVNameDisplay [counter1] != "ND") arrayTableDisplayB [tableDisplayCountB] = arrayFOVNameDisplay [counter1], tableDisplayCountB++;
                        else arrayTableDisplayB [tableDisplayCountB] = " ", tableDisplayCountB++;
                        
                        if (arrayFOVNameDisplay [counter1] != "ND"){
                            arrayTableDisplayB [tableDisplayCountB] = "ND", tableDisplayCountB++;
                            
                            for (int counter2 = 0; counter2 < 2; counter2++) arrayTableDisplayB [tableDisplayCountB] = "0", tableDisplayCountB++;
                        }
                        else{
                            
                            for (int counter2 = 0; counter2 < 3; counter2++) arrayTableDisplayB [tableDisplayCountB] = " ", tableDisplayCountB++;
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
                //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayTableDisplay [counterA*5+counterB];
                //    cout<<" arrayTableDisplay "<<counterA+1<<endl;
                //}
                
                imageFirstLoadFlag = 1;
                loadImageNo = currentTimePoint+1;
                imagePosition = 1;
                
                [totalFileDisplay setIntegerValue:lastImageNo];
                [timePointDisplay setIntegerValue:currentTimePoint];
                
                [self currentTableData];
                
                if (processMode == 10){
                    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++) arrayTableDisplay [counter1*5+2] = arrayTableDisplay [counter1*5+3];
                    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++) arrayTableDisplayG [counter1*5+2] = arrayTableDisplayG [counter1*5+3];
                    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++) arrayTableDisplayB [counter1*5+2] = arrayTableDisplayB [counter1*5+3];
                }
                
                //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
                //    for (int counterB = 0; counterB < entryNumber+3; counterB++) cout<<" "<<arrayContrastData [counterA][counterB];
                //    cout<<"  arrayContrastData "<<counterA+1<<endl;
                //}
                
                if (noFileFoundFlag == 0){
                    imageDataSet = [[ImageDataSet alloc] init];
                    int processType = 1;
                    [imageDataSet imageDataSetProcess:processType];
                    
                    if (photoMetricHold == 2){
                        if (rgbDisplayStatus == 0){
                            rgbDisplayStatus = 1;
                            [rgbStatusDisplay setStringValue:@"Red"];
                            [rgbStatusHistDisplay setStringValue:@"Red"];
                        }
                    }
                    else{
                        
                        rgbDisplayStatus = 0;
                        [rgbStatusDisplay setStringValue:@"Gray"];
                        [rgbStatusHistDisplay setStringValue:@"Gray"];
                    }
                    
                    if (processMode == 2 || processMode == 8){
                        string productsContrastPath = productsFilesInfoPath+"/"+"CT-ContrastData";
                        string productsContrastPathG = productsFilesInfoPath+"/"+"CT-ContrastDataG";
                        string productsContrastPathB = productsFilesInfoPath+"/"+"CT-ContrastDataB";
                        
                        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                            if (arrayTableDisplay [counter1*5+2] != " ") arrayTableDisplay [counter1*5+3] = arrayTableDisplay [counter1*5+2];
                        }
                        
                        arrayContrastData [0][0] = "0";
                        arrayContrastData [0][1] = "0";
                        arrayContrastData [0][2] = "0";
                        arrayContrastData [0][3] = "T1";
                        
                        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                            arrayContrastData [counter1][0] = "0";
                            arrayContrastData [counter1][1] = "0";
                            arrayContrastData [counter1][2] = "0";
                            
                            if (arrayFOVNameDisplay [counter1] != "ND") arrayContrastData [counter1][3] = arrayTableDisplay [counter1*5+3];
                            else arrayContrastData [counter1][3] = "0";
                        }
                        
                        oin.open(productsContrastPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < 4; counter2++) oin<<arrayContrastData [counter1][counter2]<<endl;
                        }
                        
                        oin.close();
                        
                        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                            if (arrayTableDisplayG [counter1*5+2] != " ") arrayTableDisplayG [counter1*5+3] = arrayTableDisplayG [counter1*5+2];
                        }
                        
                        arrayContrastDataG [0][0] = "0";
                        arrayContrastDataG [0][1] = "0";
                        arrayContrastDataG [0][2] = "0";
                        arrayContrastDataG [0][3] = "T1";
                        
                        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                            arrayContrastDataG [counter1][0] = "0";
                            arrayContrastDataG [counter1][1] = "0";
                            arrayContrastDataG [counter1][2] = "0";
                            
                            if (arrayFOVNameDisplay [counter1] != "ND") arrayContrastDataG [counter1][3] = arrayTableDisplayG [counter1*5+3];
                            else arrayContrastDataG [counter1][3] = "0";
                        }
                        
                        oin.open(productsContrastPathG.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < 4; counter2++) oin<<arrayContrastDataG [counter1][counter2]<<endl;
                        }
                        
                        oin.close();
                        
                        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                            if (arrayTableDisplayB [counter1*5+2] != " ") arrayTableDisplayB [counter1*5+3] = arrayTableDisplayB [counter1*5+2];
                        }
                        
                        arrayContrastDataB [0][0] = "0";
                        arrayContrastDataB [0][1] = "0";
                        arrayContrastDataB [0][2] = "0";
                        arrayContrastDataB [0][3] = "T1";
                        
                        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                            arrayContrastDataB [counter1][0] = "0";
                            arrayContrastDataB [counter1][1] = "0";
                            arrayContrastDataB [counter1][2] = "0";
                            
                            if (arrayFOVNameDisplay [counter1] != "ND") arrayContrastDataB [counter1][3] = arrayTableDisplayB [counter1*5+3];
                            else arrayContrastDataB [counter1][3] = "0";
                        }
                        
                        oin.open(productsContrastPathB.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < 4; counter2++) oin<<arrayContrastDataB [counter1][counter2]<<endl;
                        }
                        
                        oin.close();
                    }
                    
                    tableViewCall = 1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"File Missing"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                    
                    [self processStopMain];
                }
            }
            else if (processMode == 3 || processMode == 9 || processMode == 11) [processModeDisplay setStringValue:@"Init."];
            else if (processMode == 4) [processModeDisplay setStringValue:@"Batch (BK)"];
            else if (processMode == 5){
                [processModeDisplay setStringValue:@"Batch (BK)"];
                imageProcessTiming = 1;
            }
            else if (processMode == 12) [processModeDisplay setStringValue:@"Batch (IG)"];
            else if (processMode == 13){
                [processModeDisplay setStringValue:@"Batch (IG)"];
                [lastTimePositionDisplay setIntegerValue:lastProductFileNo];
                imageProcessTiming = 1;
            }
            else if (processMode == 6) [processModeDisplay setStringValue:@"Auto"];
            else if (processMode == 7){
                [processModeDisplay setStringValue:@"Auto"];
                imageProcessTiming = 1;
            }
            
            if (processMode == 5 || processMode == 13 || processMode == 7){
                string focalPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data";
                string entry;
                
                DIR *dir;
                struct dirent *dent;
                
                dir = opendir(focalPath.c_str());
                fileDeleteCount = 0;
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("~CP") != -1){
                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                            
                            arrayFileDelete [fileDeleteCount] = focalPath+"/"+entry, fileDeleteCount++;
                        }
                    }
                    
                    closedir(dir);
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                        remove (arrayFileDelete [counter1].c_str());
                    }
                }
                
                [NSApp miniaturizeAll:self];
            }
            
            basicInfoRead = 3;
        }
    }
    
    if (firstCommunication == 1 && basicInfoRead == 3){
        basicInfoRead = 4;
    }
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = tableDisplayCount/5;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    
    if (initialArraySet == 1){
        string getString;
        
        string displayData1;
        string displayData2;
        string displayData3;
        string displayData4;
        string displayData5;
        
        if (rgbDisplayStatus == 0 || rgbDisplayStatus == 1){
            displayData1 = arrayTableDisplay [rowIndex*5];
            displayData2 = arrayTableDisplay [rowIndex*5+1];
            displayData3 = arrayTableDisplay [rowIndex*5+2];
            displayData4 = arrayTableDisplay [rowIndex*5+3];
            displayData5 = arrayTableDisplay [rowIndex*5+4];
        }
        else if (rgbDisplayStatus == 2){
            displayData1 = arrayTableDisplayG [rowIndex*5];
            displayData2 = arrayTableDisplayG [rowIndex*5+1];
            displayData3 = arrayTableDisplayG [rowIndex*5+2];
            displayData4 = arrayTableDisplayG [rowIndex*5+3];
            displayData5 = arrayTableDisplayG [rowIndex*5+4];
        }
        else if (rgbDisplayStatus == 3){
            displayData1 = arrayTableDisplayB [rowIndex*5];
            displayData2 = arrayTableDisplayB [rowIndex*5+1];
            displayData3 = arrayTableDisplayB [rowIndex*5+2];
            displayData4 = arrayTableDisplayB [rowIndex*5+3];
            displayData5 = arrayTableDisplayB [rowIndex*5+4];
        }
        
        if ((int)displayData3.find("~") != -1){
            if (displayData3.substr(displayData3.find("~")+1, displayData3.find("=")-displayData3.find("~")-1) != "0"){
                displayData3 = displayData3.substr(0, displayData3.find("~"))+"*";
            }
            else displayData3 = displayData3.substr(0, displayData3.find("~"));
        }
        
        if ((int)displayData4.find("~") != -1){
            if (displayData4.substr(displayData4.find("~")+1, displayData4.find("=")-displayData4.find("~")-1) != "0"){
                displayData4 = displayData4.substr(0, displayData4.find("~"))+"*";
            }
            else displayData4 = displayData4.substr(0, displayData4.find("~"));
        }
        
        if ((int)displayData5.find("~") != -1){
            if (displayData5.substr(displayData5.find("~")+1, displayData5.find("=")-displayData5.find("~")-1) != "0"){
                displayData5 = displayData5.substr(0, displayData5.find("~"))+"*";
            }
            else displayData5 = displayData5.substr(0, displayData5.find("~"));
        }
        
        int positionSaveFlag = 0;
        
        if (displayData1 != " "){
            struct stat sizeOfFile;
            int fileOpenCheck = 0;
            
            if (processMode == 5 || processMode == 13 || processMode == 7){
                fileOpenCheck = stat(fovPositionTempPath.c_str(), &sizeOfFile);
            }
            else{
                
                fileOpenCheck = stat(fovPositionPath.c_str(), &sizeOfFile);
            }
            
            if (fileOpenCheck == 0){
                ifstream fin;
                
                if (processMode == 5 || processMode == 13 || processMode == 7) fin.open(fovPositionTempPath.c_str(), ios::in);
                else fin.open(fovPositionPath.c_str(), ios::in);
                
                if (fin.is_open()){
                    do{
                        
                        getline(fin, getString);
                        
                        if (getString != "Name" && getString == displayData1){
                            positionSaveFlag = 1;
                            break;
                        }
                        
                    } while (getString != "");
                    
                    fin.close();
                }
            }
        }
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        if (rowIndex == 0) [attributes setObject:[NSFont boldSystemFontOfSize:9] forKey:NSFontAttributeName];
        else [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
        
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"] && rowIndex != 0 && positionSaveFlag == 1){
            [attributes setObject:[NSFont boldSystemFontOfSize:9] forKey:NSFontAttributeName];
            [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && rowIndex != 0 && positionSaveFlag == 0){
            [attributes setObject:[NSFont boldSystemFontOfSize:9] forKey:NSFontAttributeName];
            [attributes setObject:[NSColor darkGrayColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && rowIndex == 0){
            [attributes setObject:[NSFont boldSystemFontOfSize:9] forKey:NSFontAttributeName];
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && rowIndex != 0){
            [attributes setObject:[NSFont boldSystemFontOfSize:9] forKey:NSFontAttributeName];
            [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && rowIndex == 0){
            [attributes setObject:[NSFont boldSystemFontOfSize:9] forKey:NSFontAttributeName];
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData3.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"]){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData4.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL5"]){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData5.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else{
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL5"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    tableCallCount++;
    
    if (tableCallCount == 2) tableCurrentRowHold = rowIndexHold;
    else if (tableCallCount == 1) tableCurrentRowHold = rowIndex;
    
    return YES;
}

-(void)currentTableData{
    string timeString = to_string(loadImageNo);
    
    if (timeString.length() == 1) timeString = "000"+timeString;
    else if (timeString.length() == 2) timeString = "00"+timeString;
    else if (timeString.length() == 3) timeString = "0"+timeString;
    else if (timeString.length() == 4) timeString = timeString;
    
    string treatNameRead = "";
    string extractString;
    string treatString;
    string channelString;
    string folderName;
    string fovNameRead;
    string fovString;
    string processFilePath;
    string colorName;
    string colorNameNo;
    string readData;
    string contrastString;
    string processFilePathWithExt;
    
    int dimensionTotal = 0;
    int numberOfPoint = 0;
    int numberOfPointG = 0;
    int numberOfPointB = 0;
    int lowestValueTemp = 0;
    int lowestValueTempG = 0;
    int lowestValueTempB = 0;
    int highestValueTemp = 0;
    int highestValueTempG = 0;
    int highestValueTempB = 0;
    int meanValueTemp = 0;
    int meanValueTempG = 0;
    int meanValueTempB = 0;
    int pixNo90 = 0;
    int pixNo90G = 0;
    int pixNo90B = 0;
    int yDimensionCount = 0;
    int readFlag = 0;
    int readFlag2 = 0;
    int readFlag3 = 0;
    int endFindCount = 0;
    int saveDataStatus = 0;
    int terminationFlag = 0;
    int readAscII = 0;
    int contrastTemp = 0;
    int extensionType = 0;
    
    double contrastDouble = 0;
    unsigned long totalCount = 0;
    unsigned long totalCountG = 0;
    unsigned long totalCountB = 0;
    
    //-----Tiff reading-----
    unsigned long stripFirstAddress = 0;
    unsigned long stripByteCountAddress = 0;
    unsigned long nextAddress = 0;
    unsigned long headPosition = 0;
    unsigned long stripEntry = 0;
    long sizeForCopy = 0;
    
    double xPosition = 0;
    double yPosition = 0;
    
    int imageWidth = 0;
    int imageHeight = 0;
    int imageBit = 0;
    int imageCompression = 0;
    int photoMetric = 0;
    int imageDimensionTif = 0;
    int verticalBmp = 0;
    int horizontalBmp = 0;
    int horizontalBmpEntry = 0;
    int endianType = 0;
    int samplePerPix = 0;
    int dataConversion [4];
    int processTypeTif = 1;
    int numberOfLayers = 0;
    int dimensionAdditionY = 0;
    int dimensionAdditionX = 0;
    
    struct stat sizeOfFile;
    
    int *histogramTemp = new int [300];
    int *histogramTempG = new int [300];
    int *histogramTempB = new int [300];
    
    ifstream fin;
    
    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
        if (arrayTableDisplay [counter1*5] != " ") treatNameRead = arrayTableDisplay [counter1*5];
        
        if (treatNameRead != " " && arrayTableDisplay [counter1*5+1] != " "){
            extractString = treatNameRead.substr(treatNameRead.length()-3, 2);
            
            if (extractString == "CH"){
                treatString = treatNameRead.substr(0, treatNameRead.length()-3);
                channelString = treatNameRead.substr(treatNameRead.length()-1, 1);
            }
            else{
                
                treatString = treatNameRead;
                channelString = "";
            }
            
            folderName = treatString+"~Sorted";
            fovNameRead = arrayTableDisplay [counter1*5+1];
            
            fovString = fovNameRead.substr(fovNameRead.find("FOV")+3);
            
            if ((int)fovNameRead.find("FOV") != -1){
                if (fovString.length() == 1) fovString = "FOV00"+fovString;
                else if (fovString.length() == 2) fovString = "FOV0"+fovString;
                else if (fovString.length() == 3) fovString = "FOV"+fovString;
                
                if (currentTimePoint < lastImageNo){
                    processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString;
                }
                else if (currentTimePoint == lastImageNo){
                    processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString;
                    
                    fin.open(processFilePath.c_str(), ios::in);
                    
                    if (!fin.is_open()){
                        processFilePath = productsFilesImagePath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+timeString+"-"+fovString;
                    }
                    else fin.close();
                }
            }
            else{
                
                extractString = fovNameRead.substr(fovNameRead.find("-")+1);
                
                if (extractString.length() == 1) fovString = "FOV00"+extractString;
                else if (extractString.length() == 2) fovString = "FOV0"+extractString;
                else if (extractString.length() == 3) fovString = "FOV"+extractString;
                
                if (channelString == "1"){
                    colorName = fluorescent1;
                    colorNameNo = fluorescentNo1;
                }
                else if (channelString == "2"){
                    colorName = fluorescent2;
                    colorNameNo = fluorescentNo2;
                }
                else if (channelString == "3"){
                    colorName = fluorescent3;
                    colorNameNo = fluorescentNo3;
                }
                else if (channelString == "4"){
                    colorName = fluorescent4;
                    colorNameNo = fluorescentNo4;
                }
                else if (channelString == "5"){
                    colorName = fluorescent5;
                    colorNameNo = fluorescentNo5;
                }
                else if (channelString == "6"){
                    colorName = fluorescent6;
                    colorNameNo = fluorescentNo6;
                }
                
                if (currentTimePoint < lastImageNo){
                    processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString+"_"+colorNameNo+"_"+colorName;
                }
                else if (currentTimePoint == lastImageNo){
                    processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString+"_"+colorNameNo+"_"+colorName;
                    
                    fin.open(processFilePath.c_str(), ios::in);
                    
                    if (!fin.is_open()){
                        processFilePath = productsFilesImagePath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+timeString+"-"+fovString+"_"+colorNameNo+"_"+colorName;
                    }
                    else fin.close();
                }
            }
            
            extensionType = 0;
            
            processFilePathWithExt = processFilePath+".tif";
            
            fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                extensionType = 1;
                fin.close();
            }
            else{
                
                processFilePathWithExt = processFilePath+".bmp";
                
                fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    extensionType = 2;
                    fin.close();
                }
            }
            
            if (extensionType != 0){
                if (extensionType == 1){
                    if (stat(processFilePathWithExt.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        fileReadArray = new uint8_t [sizeForCopy+4];
                        fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
                        
                        fin.read((char*)fileReadArray, sizeForCopy+4);
                        fin.close();
                        
                        dataConversion [0] = fileReadArray [0];
                        dataConversion [1] = fileReadArray [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        int *arrayExtractedImage3 = new int [100];
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = fileReadArray [7];
                            dataConversion [1] = fileReadArray [6];
                            dataConversion [2] = fileReadArray [5];
                            dataConversion [3] = fileReadArray [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = fileReadArray [4];
                            dataConversion [1] = fileReadArray [5];
                            dataConversion [2] = fileReadArray [6];
                            dataConversion [3] = fileReadArray [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        if (endianType == 1){
                            tiffFileRead = [[TiffFileRead alloc] init];
                            [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            
                            if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                else imageDimensionTif = imageHeight;
                                
                                tiffFileRead = [[TiffFileRead alloc] init];
                                delete [] arrayExtractedImage3;
                                
                                arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                            }
                        }
                        else if (endianType == 0){
                            tiffFileRead = [[TiffFileRead alloc] init];
                            [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            
                            if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                else imageDimensionTif = imageHeight;
                                
                                tiffFileRead = [[TiffFileRead alloc] init];
                                delete [] arrayExtractedImage3;
                                
                                arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                            }
                        }
                        
                        if (photoMetric == 0 || photoMetric == 1) photoMetricHold = 1;
                        else photoMetricHold = 2;
                        
                        imageDimensionX = imageWidth;
                        imageDimensionY = imageHeight;
                        
                        //-----Multiply image dimensions by a factor of 8-----
                        dimensionAdditionY = imageDimensionY%8;
                        
                        if (dimensionAdditionY == 1) dimensionAdditionY = 7;
                        else if (dimensionAdditionY == 2) dimensionAdditionY = 6;
                        else if (dimensionAdditionY == 3) dimensionAdditionY = 5;
                        else if (dimensionAdditionY == 4) dimensionAdditionY = 4;
                        else if (dimensionAdditionY == 5) dimensionAdditionY = 3;
                        else if (dimensionAdditionY == 6) dimensionAdditionY = 2;
                        else if (dimensionAdditionY == 7) dimensionAdditionY = 1;
                        
                        imageDimensionY = imageDimensionY+dimensionAdditionY;
                        
                        dimensionAdditionX = imageDimensionX%8;
                        
                        if (dimensionAdditionX == 1) dimensionAdditionX = 7;
                        else if (dimensionAdditionX == 2) dimensionAdditionX = 6;
                        else if (dimensionAdditionX == 3) dimensionAdditionX = 5;
                        else if (dimensionAdditionX == 4) dimensionAdditionX = 4;
                        else if (dimensionAdditionX == 5) dimensionAdditionX = 3;
                        else if (dimensionAdditionX == 6) dimensionAdditionX = 2;
                        else if (dimensionAdditionX == 7) dimensionAdditionX = 1;
                        
                        imageDimensionX = imageDimensionX+dimensionAdditionX;
                        
                        arrayImageFileSave = new int *[imageDimensionY+1];
                        
                        for (int counter3 = 0; counter3 < imageDimensionY+1; counter3++){
                            arrayImageFileSave [counter3] = new int [imageDimensionX*3+1];
                        }
                        
                        for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                            for (int counter4 = 0; counter4 < imageDimensionX*3; counter4++){
                                arrayImageFileSave [counter3][counter4] = 0;
                            }
                        }
                        
                        verticalBmp = 0;
                        horizontalBmp = 0;
                        horizontalBmpEntry = 0;
                        
                        for (int counter5 = 0; counter5 < imageWidth*imageHeight; counter5++){
                            if (verticalBmp < imageHeight){
                                if (horizontalBmp < imageWidth){
                                    if (photoMetric <= 1){
                                        arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter5]), horizontalBmpEntry++;
                                    }
                                    else if (photoMetric == 2){
                                        arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter5*3]), horizontalBmpEntry++;
                                        arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter5*3+1]), horizontalBmpEntry++;
                                        arrayImageFileSave [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter5*3+2]), horizontalBmpEntry++;
                                    }
                                    
                                    horizontalBmp++;
                                }
                                
                                if (horizontalBmp == imageWidth && imageWidth < imageDimensionX){
                                    for (int counter6 = 0; counter6 < imageDimensionX-imageWidth; counter6++){
                                        if (photoMetric <= 1){
                                            arrayImageFileSave [verticalBmp][horizontalBmpEntry] = -1, horizontalBmpEntry++; //-----Fill blank part with -1
                                        }
                                        else if (photoMetric == 2){
                                            arrayImageFileSave [verticalBmp][horizontalBmpEntry] = -1, horizontalBmpEntry++;
                                            arrayImageFileSave [verticalBmp][horizontalBmpEntry] = -1, horizontalBmpEntry++;
                                            arrayImageFileSave [verticalBmp][horizontalBmpEntry] = -1, horizontalBmpEntry++;
                                        }
                                    }
                                }
                                
                                if (horizontalBmp == imageWidth){
                                    horizontalBmp = 0;
                                    horizontalBmpEntry = 0;
                                    verticalBmp++;
                                }
                            }
                        }
                        
                        if (imageHeight < imageDimensionY){
                            for (int counter5 = imageHeight; counter5 < imageDimensionY; counter5++){
                                for (int counter6 = 0; counter6 < imageDimensionX; counter6++){
                                    if (photoMetric <= 1){
                                        arrayImageFileSave [counter5][counter6] = -1; //-----Fill blank part with -1
                                    }
                                    else if (photoMetric == 2){
                                        arrayImageFileSave [counter5][counter6] = -1;
                                        arrayImageFileSave [counter5][counter6] = -1;
                                        arrayImageFileSave [counter5][counter6] = -1;
                                    }
                                }
                            }
                        }
                        
                        if (photoMetric == 1){
                            numberOfPoint = 0;
                            totalCount = 0;
                            lowestValueTemp = 0;
                            highestValueTemp = 0;
                            
                            for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                            
                            for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                    if (arrayImageFileSave [counter3][counter4] >= 0 && arrayImageFileSave [counter3][counter4] < 255) histogramTemp [arrayImageFileSave [counter3][counter4]]++;
                                }
                            }
                            
                            for (int counter2 = 1; counter2 <= 255; counter2++){
                                numberOfPoint = numberOfPoint+histogramTemp [counter2];
                                totalCount = totalCount+(unsigned long)(counter2*histogramTemp [counter2]);
                            }
                            
                            if (numberOfPoint != 0) meanValueTemp = (int)(totalCount/(double)numberOfPoint);
                            
                            pixNo90 = histogramTemp [meanValueTemp];
                            
                            for (int counter2 = 1; counter2 <= 255; counter2++){
                                if (meanValueTemp-counter2 >= 0){
                                    pixNo90 = pixNo90+histogramTemp [meanValueTemp-counter2];
                                    lowestValueTemp = meanValueTemp-counter2;
                                }
                                if (meanValueTemp+counter2 <= 255){
                                    pixNo90 = pixNo90+histogramTemp [meanValueTemp+counter2];
                                    highestValueTemp = meanValueTemp+counter2;
                                }
                                if (pixNo90/(double)numberOfPoint > 0.8){
                                    break;
                                }
                            }
                            
                            contrastTemp = (int)(contrastValueDisplay*100);
                            contrastDouble = contrastTemp/(double)100;
                            
                            stringstream extension1;
                            extension1 << contrastDouble;
                            contrastString = extension1.str();
                            
                            arrayTableDisplay [counter1*5+2] = to_string(lowestValueTemp)+"/"+to_string(meanValueTemp)+"/"+to_string(highestValueTemp)+"/"+contrastString+" R0:0~0";
                        }
                        else if (photoMetric == 2){
                            for (int counter2 = 0; counter2 <= 255; counter2++){
                                histogramTemp [counter2] = 0;
                                histogramTempG [counter2] = 0;
                                histogramTempB [counter2] = 0;
                            }
                            
                            numberOfPoint = 0;
                            totalCount = 0;
                            lowestValueTemp = 0;
                            highestValueTemp = 0;
                            
                            numberOfPointG = 0;
                            totalCountG = 0;
                            lowestValueTempG = 0;
                            highestValueTempG = 0;
                            
                            numberOfPointB = 0;
                            totalCountB = 0;
                            lowestValueTempB = 0;
                            highestValueTempB = 0;
                            
                            for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                    if (arrayImageFileSave [counter3][counter4*3] >= 0 && arrayImageFileSave [counter3][counter4*3] < 255) histogramTemp [arrayImageFileSave [counter3][counter4*3]]++;
                                    if (arrayImageFileSave [counter3][counter4*3+1] >= 0 && arrayImageFileSave [counter3][counter4*3+1] < 255) histogramTempG [arrayImageFileSave [counter3][counter4*3+1]]++;
                                    if (arrayImageFileSave [counter3][counter4*3+2] >= 0 && arrayImageFileSave [counter3][counter4*3+2] < 255) histogramTempB [arrayImageFileSave [counter3][counter4*3+2]]++;
                                }
                            }
                            
                            for (int counter2 = 1; counter2 <= 255; counter2++){
                                numberOfPoint = numberOfPoint+histogramTemp [counter2];
                                totalCount = totalCount+(unsigned long)(counter2*histogramTemp [counter2]);
                                
                                numberOfPointG = numberOfPointG+histogramTempG [counter2];
                                totalCountG = totalCountG+(unsigned long)(counter2*histogramTempG [counter2]);
                                
                                numberOfPointB = numberOfPointB+histogramTempB [counter2];
                                totalCountB = totalCountB+(unsigned long)(counter2*histogramTempB [counter2]);
                            }
                            
                            if (numberOfPoint != 0) meanValueTemp = (int)(totalCount/(double)numberOfPoint);
                            pixNo90 = histogramTemp [meanValueTemp];
                            
                            if (numberOfPointG != 0) meanValueTempG = (int)(totalCountG/(double)numberOfPointG);
                            pixNo90G = histogramTempG [meanValueTempG];
                            
                            if (numberOfPointB != 0) meanValueTempB = (int)(totalCountB/(double)numberOfPointB);
                            pixNo90B = histogramTempB [meanValueTempB];
                            
                            for (int counter2 = 1; counter2 <= 255; counter2++){
                                if (meanValueTemp-counter2 >= 0){
                                    pixNo90 = pixNo90+histogramTemp [meanValueTemp-counter2];
                                    lowestValueTemp = meanValueTemp-counter2;
                                }
                                if (meanValueTemp+counter2 <= 255){
                                    pixNo90 = pixNo90+histogramTemp [meanValueTemp+counter2];
                                    highestValueTemp = meanValueTemp+counter2;
                                }
                                if (pixNo90/(double)numberOfPoint > 0.8){
                                    break;
                                }
                            }
                            
                            for (int counter2 = 1; counter2 <= 255; counter2++){
                                if (meanValueTempG-counter2 >= 0){
                                    pixNo90G = pixNo90G+histogramTempG [meanValueTempG-counter2];
                                    lowestValueTempG = meanValueTempG-counter2;
                                }
                                if (meanValueTempG+counter2 <= 255){
                                    pixNo90G = pixNo90G+histogramTempG [meanValueTempG+counter2];
                                    highestValueTempG = meanValueTempG+counter2;
                                }
                                if (pixNo90G/(double)numberOfPointG > 0.8){
                                    break;
                                }
                            }
                            
                            for (int counter2 = 1; counter2 <= 255; counter2++){
                                if (meanValueTempB-counter2 >= 0){
                                    pixNo90B = pixNo90B+histogramTempB [meanValueTempB-counter2];
                                    lowestValueTempB = meanValueTempB-counter2;
                                }
                                if (meanValueTempB+counter2 <= 255){
                                    pixNo90B = pixNo90B+histogramTempB [meanValueTempB+counter2];
                                    highestValueTempB = meanValueTempB+counter2;
                                }
                                if (pixNo90B/(double)numberOfPointB > 0.8){
                                    break;
                                }
                            }
                            
                            contrastTemp = (int)(contrastValueDisplay*100);
                            contrastDouble = contrastTemp/(double)100;
                            
                            stringstream extension1;
                            extension1 << contrastDouble;
                            contrastString = extension1.str();
                            
                            arrayTableDisplay [counter1*5+2] = to_string(lowestValueTemp)+"/"+to_string(meanValueTemp)+"/"+to_string(highestValueTemp)+"/"+contrastString+" R0:0~0";
                            
                            contrastTemp = (int)(contrastValueDisplayG*100);
                            contrastDouble = contrastTemp/(double)100;
                            
                            stringstream extension2;
                            extension2 << contrastDouble;
                            contrastString = extension2.str();
                            
                            arrayTableDisplayG [counter1*5+2] = to_string(lowestValueTempG)+"/"+to_string(meanValueTempG)+"/"+to_string(highestValueTempG)+"/"+contrastString+" R0:0~0";
                            
                            contrastTemp = (int)(contrastValueDisplayB*100);
                            contrastDouble = contrastTemp/(double)100;
                            
                            stringstream extension3;
                            extension3 << contrastDouble;
                            contrastString = extension3.str();
                            
                            arrayTableDisplayB [counter1*5+2] = to_string(lowestValueTempB)+"/"+to_string(meanValueTempB)+"/"+to_string(highestValueTempB)+"/"+contrastString+" R0:0~0";
                        }
                        
                        delete [] arrayExtractedImage3;
                        delete [] fileReadArray;
                        
                        for (int counter3 = 0; counter3 < imageDimensionY+1; counter3++){
                            delete [] arrayImageFileSave [counter3];
                        }
                        
                        delete [] arrayImageFileSave;
                    }
                }
                else if (extensionType == 2){
                    fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
                    
                    if (dimensionTotal == 0){
                        fin.seekg (18);
                        
                        dataConversion [0] = fin.get();
                        dataConversion [1] = fin.get();
                        dataConversion [2] = fin.get();
                        dataConversion [3] = fin.get();
                        imageDimensionX = dataConversion [3]*16777216+dataConversion [2]*65536+dataConversion [1]*256+dataConversion [0];
                        
                        dimensionTotal = imageDimensionX*imageDimensionX;
                    }
                    
                    imageDimensionY = imageDimensionX;
                    
                    fin.close();
                    
                    yDimensionCount = imageDimensionX;
                    
                    fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
                    fin.seekg((1078+(yDimensionCount-1)*yDimensionCount-1)+imageDimensionX+1);
                    
                    endFindCount = 0;
                    saveDataStatus = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        readAscII = fin.get();
                        
                        if (readAscII == 89 && endFindCount == 0) endFindCount++;
                        else if (readAscII == 89 && endFindCount == 1) endFindCount++;
                        else if (endFindCount == 2){
                            terminationFlag = 0;
                            saveDataStatus = readAscII;
                        }
                        
                    } while (terminationFlag == 1);
                    
                    fin.close();
                    
                    if (saveDataStatus == 121){
                        fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
                        fin.seekg((1078+(yDimensionCount-1)*yDimensionCount-1)+imageDimensionX+1);
                        
                        readFlag = 0;
                        readFlag2 = 0;
                        readData = "";
                        readFlag3 = 0;
                        lowestValueTemp = 0;
                        highestValueTemp = 0;
                        meanValueTemp = 0;
                        
                        ascIIconversion = [[ASCIIconversion alloc] init];
                        
                        do{
                            
                            terminationFlag = 1;
                            readAscII = fin.get();
                            
                            if (readFlag == 1 && readAscII == 121){
                                lowestValueTemp = atoi(readData.c_str());
                                readFlag = 2;
                            }
                            
                            if (readFlag == 0 && readAscII == 121) readFlag = 1;
                            else if (readFlag == 1 && readAscII != 121){
                                [ascIIconversion ascIIConversion2:readAscII];
                                readData = readData+ascIIstring;
                            }
                            
                            if (readFlag2 == 1 && readAscII == 122){
                                meanValueTemp = atoi(readData.c_str());
                                readFlag2 = 2;
                            }
                            
                            if (readFlag2 == 0 && readAscII == 122) readFlag2 = 1, readData = "";
                            else if (readFlag2 == 1 && readAscII != 122){
                                [ascIIconversion ascIIConversion2:readAscII];
                                readData = readData+ascIIstring;
                            }
                            
                            if (readFlag3 == 1 && readAscII == 123){
                                highestValueTemp = atoi(readData.c_str());
                                readFlag3 = 2;
                                terminationFlag = 0;
                            }
                            
                            if (readFlag3 == 0 && readAscII == 123) readFlag3 = 1, readData = "";
                            else if (readFlag3 == 1 && readAscII != 123){
                                [ascIIconversion ascIIConversion2:readAscII];
                                readData = readData+ascIIstring;
                            }
                            
                        } while (terminationFlag == 1);
                        
                        fin.close();
                    }
                    else if (saveDataStatus != 121){
                        if (stat(processFilePathWithExt.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy];
                            fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+1);
                                fin.close();
                                
                                for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                                
                                for (int counter2 = 0; counter2 < dimensionTotal; counter2++){
                                    if (uploadTemp [1078+counter2] > 25 && uploadTemp [1078+counter2] < 255) histogramTemp [uploadTemp [1078+counter2]]++;
                                }
                            }
                            
                            delete [] uploadTemp;
                        }
                        
                        numberOfPoint = 0;
                        totalCount = 0;
                        lowestValueTemp = 0;
                        highestValueTemp = 0;
                        
                        for (int counter2 = 1; counter2 <= 255; counter2++){
                            numberOfPoint = numberOfPoint+histogramTemp [counter2];
                            totalCount = totalCount+(unsigned long)(counter2*histogramTemp [counter2]);
                        }
                        
                        if (numberOfPoint != 0) meanValueTemp = (int)(totalCount/(double)numberOfPoint);
                        pixNo90 = histogramTemp [meanValueTemp];
                        
                        for (int counter2 = 1; counter2 <= 255; counter2++){
                            if (meanValueTemp-counter2 >= 0){
                                pixNo90 = pixNo90+histogramTemp [meanValueTemp-counter2];
                                lowestValueTemp = meanValueTemp-counter2;
                            }
                            if (meanValueTemp+counter2 <= 255){
                                pixNo90 = pixNo90+histogramTemp [meanValueTemp+counter2];
                                highestValueTemp = meanValueTemp+counter2;
                            }
                            if (pixNo90/(double)numberOfPoint > 0.8){
                                break;
                            }
                        }
                    }
                    
                    contrastTemp = (int)(contrastValueDisplay*100);
                    contrastDouble = contrastTemp/(double)100;
                    
                    stringstream extension1;
                    extension1 << contrastDouble;
                    contrastString = extension1.str();
                    
                    arrayTableDisplay [counter1*5+2] = to_string(lowestValueTemp)+"/"+to_string(meanValueTemp)+"/"+to_string(highestValueTemp)+"/"+contrastString+" R0:0~0";
                    
                    photoMetricHold = 1;
                }
            }
            else if (processMode == 2 || processMode == 8 || processMode == 10 || processMode == 3 || processMode == 9 || processMode == 11) noFileFoundFlag = 1;
            else arrayTableDisplay [counter1*5+2] = "nil";
        }
    }
    
    if (photoMetricHold == 2){
        if (rgbDisplayStatus == 0){
            rgbDisplayStatus = 1;
            [rgbStatusDisplay setStringValue:@"Red"];
            [rgbStatusHistDisplay setStringValue:@"Red"];
        }
    }
    else{
        
        rgbDisplayStatus = 0;
        [rgbStatusDisplay setStringValue:@"Gray"];
        [rgbStatusHistDisplay setStringValue:@"Gray"];
    }
    
    delete [] histogramTemp;
    delete [] histogramTempG;
    delete [] histogramTempB;
    
    tableViewCall = 1;
}

-(IBAction)imageLoad:(id)sender{
    if (arrayTableDisplay [rowIndexHold*5] != " " && arrayTableDisplay [rowIndexHold*5] != "Name"){
        if (autoProcessingFlag == 0){
            if (imageFirstLoadFlag == 0){
                loadImageNo = 0;
                
                if (lastImageNo > currentTimePoint) loadImageNo = currentTimePoint+1;
                else if (lastImageNo == currentTimePoint) loadImageNo = imagePosition;
                
                [imagePositionDisplay setIntegerValue:loadImageNo];
            }
            
            if (loadImageNo != 0) [self imageLoadMain];
            
            if (imageFirstLoadFlagDisplayBK == 1){
                backgroundOriginalLoadFlag = 1;
                currentOriginalNo = 1;
                treatmentBKCall = 1;
                
                subprocesses = [[SubProcesses alloc] init];
                [subprocesses variableSave];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)imageLoadMain{
    if (backgroundOADisplay == "Off"){
        if (imageFirstLoadFlag == 0){
            imageFirstLoadFlag = 1;
            [self currentTableData];
            [contrastImageDisplay setStringValue:@"nil"];
            
            int processType = 2;
            imageDataSet = [[ImageDataSet alloc] init];
            [imageDataSet imageDataSetProcess:processType];
            tableViewCall = 1;
        }
        else{
            
            processingFovNo = -1;
            contrastOADisplay = "Off";
            backgroundOADisplay = "Off";
            contrastBarActivate = 0;
            imageFLStatus = "Lock";
            
            [self currentTableData];
            [contrastImageDisplay setStringValue:@"nil"];
            
            int processType = 2;
            imageDataSet = [[ImageDataSet alloc] init];
            [imageDataSet imageDataSetProcess:processType];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            tableViewCall = 1;
        }
        
        if (photoMetricHold == 2){
            if (rgbDisplayStatus == 0){
                rgbDisplayStatus = 1;
                [rgbStatusDisplay setStringValue:@"Red"];
                [rgbStatusHistDisplay setStringValue:@"Red"];
            }
        }
        else{
            
            rgbDisplayStatus = 0;
            [rgbStatusDisplay setStringValue:@"Gray"];
            [rgbStatusHistDisplay setStringValue:@"Gray"];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Turn Off Background Mode To Proceed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)setData:(id)sender{
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        if (loadImageTreatName != ""){
            setData = [[SetData alloc] init];
            [setData setDataMain];
            
            backgroundOADisplay = "Off";
            
            int processType = 4;
            imageDataSet = [[ImageDataSet alloc] init];
            [imageDataSet imageDataSetProcess:processType];
            
            if (photoMetricHold == 2){
                if (rgbDisplayStatus == 0){
                    rgbDisplayStatus = 1;
                    [rgbStatusDisplay setStringValue:@"Red"];
                    [rgbStatusHistDisplay setStringValue:@"Red"];
                }
            }
            else{
                
                rgbDisplayStatus = 0;
                [rgbStatusDisplay setStringValue:@"Gray"];
                [rgbStatusHistDisplay setStringValue:@"Gray"];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Treatment Not Selected"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Processing Image. Please Wait"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)removeData:(id)sender{
    int delTimeNumber = (int)[delTime integerValue];
    [delTime setStringValue:@""];
    
    int proceedingFlag = 0;
    int entryPoint = 0;
    string timeData;
    
    if (delTimeNumber > 0){
        for (int counter1 = 1; counter1 <= entryNumber; counter1++){
            timeData = arrayContrastData [0][counter1+2];
            timeData = timeData.substr(1);
            
            if (delTimeNumber == atoi(timeData.c_str())){
                proceedingFlag = 1;
                entryPoint = counter1;
                break;
            }
        }
    }
    else if (delTimeNumber == -1) entryPoint = -1;
    
    if (autoProcessingFlag == 0){
        if (proceedingFlag == 1 && (entryPoint > 1 || delTimeNumber == -1)){
            string **arrayContrastDataTemp = new string *[contrastDataHorizontal];
            string **arrayContrastDataTempG = new string *[contrastDataHorizontal];
            string **arrayContrastDataTempB = new string *[contrastDataHorizontal];
            
            for (int counter1 = 0; counter1 < contrastDataHorizontal; counter1++){
                arrayContrastDataTemp [counter1] = new string [contrastDataEntry+50];
                arrayContrastDataTempG [counter1] = new string [contrastDataEntry+50];
                arrayContrastDataTempB [counter1] = new string [contrastDataEntry+50];
            }
            
            if (entryPoint > 1){
                int saveCount = 0;
                
                for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                    arrayContrastDataTemp [counter1][0] = arrayContrastData [counter1][0];
                    arrayContrastDataTemp [counter1][1] = arrayContrastData [counter1][1];
                    arrayContrastDataTemp [counter1][2] = arrayContrastData [counter1][2];
                    
                    if (photoMetricHold == 2){
                        arrayContrastDataTempG [counter1][0] = arrayContrastDataG [counter1][0];
                        arrayContrastDataTempG [counter1][1] = arrayContrastDataG [counter1][1];
                        arrayContrastDataTempG [counter1][2] = arrayContrastDataG [counter1][2];
                        
                        arrayContrastDataTempB [counter1][0] = arrayContrastDataB [counter1][0];
                        arrayContrastDataTempB [counter1][1] = arrayContrastDataB [counter1][1];
                        arrayContrastDataTempB [counter1][2] = arrayContrastDataB [counter1][2];
                    }
                    
                    saveCount = 1;
                    
                    for (int counter2 = 1; counter2 <= entryNumber; counter2++){
                        if (counter2 != entryPoint){
                            arrayContrastDataTemp [counter1][saveCount+2] = arrayContrastData [counter1][counter2+2];
                            
                            if (photoMetricHold == 2){
                                arrayContrastDataTempG [counter1][saveCount+2] = arrayContrastDataG [counter1][counter2+2];
                                arrayContrastDataTempB [counter1][saveCount+2] = arrayContrastDataB [counter1][counter2+2];
                            }
                            
                            saveCount++;
                        }
                    }
                }
            }
            else if (entryPoint == -1){
                for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                    arrayContrastDataTemp [counter1][0] = arrayContrastData [counter1][0];
                    arrayContrastDataTemp [counter1][1] = arrayContrastData [counter1][1];
                    arrayContrastDataTemp [counter1][2] = arrayContrastData [counter1][2];
                    arrayContrastDataTemp [counter1][3] = arrayContrastData [counter1][3];
                    
                    if (photoMetricHold == 2){
                        arrayContrastDataTempG [counter1][0] = arrayContrastDataG [counter1][0];
                        arrayContrastDataTempG [counter1][1] = arrayContrastDataG [counter1][1];
                        arrayContrastDataTempG [counter1][2] = arrayContrastDataG [counter1][2];
                        arrayContrastDataTempG [counter1][3] = arrayContrastDataG [counter1][3];
                        
                        arrayContrastDataTempB [counter1][0] = arrayContrastDataB [counter1][0];
                        arrayContrastDataTempB [counter1][1] = arrayContrastDataB [counter1][1];
                        arrayContrastDataTempB [counter1][2] = arrayContrastDataB [counter1][2];
                        arrayContrastDataTempB [counter1][3] = arrayContrastDataB [counter1][3];
                    }
                }
            }
            
            for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                for (int counter2 = 0; counter2 < entryNumber+2; counter2++){
                    arrayContrastData [counter1][counter2] = arrayContrastDataTemp [counter1][counter2];
                    
                    if (photoMetricHold == 2){
                        arrayContrastDataG [counter1][counter2] = arrayContrastDataTempG [counter1][counter2];
                        arrayContrastDataB [counter1][counter2] = arrayContrastDataTempB [counter1][counter2];
                    }
                }
            }
            
            for (int counter1 = 0; counter1 < contrastDataHorizontal; counter1++){
                delete [] arrayContrastDataTemp [counter1];
                delete [] arrayContrastDataTempG [counter1];
                delete [] arrayContrastDataTempB [counter1];
            }
            
            delete [] arrayContrastDataTemp;
            delete [] arrayContrastDataTempG;
            delete [] arrayContrastDataTempB;
            
            ofstream oin;
            
            if (processMode == 5 || processMode == 13 || processMode == 7){
                string productsContrastTempPath = productsFilesTempPath+"/"+"CT-ContrastData";
                string productsContrastTempPathG = productsFilesTempPath+"/"+"CT-ContrastDataG";
                string productsContrastTempPathB = productsFilesTempPath+"/"+"CT-ContrastDataB";
                
                oin.open(productsContrastTempPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                    for (int counter2 = 0; counter2 < entryNumber+2; counter2++) oin<<arrayContrastData [counter1][counter2]<<endl;
                }
                
                oin.close();
                
                if (photoMetricHold == 2){
                    oin.open(productsContrastTempPathG.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                        for (int counter2 = 0; counter2 < entryNumber+2; counter2++) oin<<arrayContrastDataG [counter1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    oin.open(productsContrastTempPathB.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                        for (int counter2 = 0; counter2 < entryNumber+2; counter2++) oin<<arrayContrastDataB [counter1][counter2]<<endl;
                    }
                    
                    oin.close();
                }
            }
            else{
                
                string productsContrastPath = productsFilesInfoPath+"/"+"CT-ContrastData";
                string productsContrastPathG = productsFilesInfoPath+"/"+"CT-ContrastDataG";
                string productsContrastPathB = productsFilesInfoPath+"/"+"CT-ContrastDataB";
                
                oin.open(productsContrastPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                    for (int counter2 = 0; counter2 < entryNumber+2; counter2++) oin<<arrayContrastData [counter1][counter2]<<endl;
                }
                
                oin.close();
                
                if (photoMetricHold == 2){
                    oin.open(productsContrastPathG.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                        for (int counter2 = 0; counter2 < entryNumber+2; counter2++) oin<<arrayContrastDataG [counter1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    oin.open(productsContrastPathB.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                        for (int counter2 = 0; counter2 < entryNumber+2; counter2++) oin<<arrayContrastDataB [counter1][counter2]<<endl;
                    }
                }
            }
            
            entryNumber--;
            
            string extension;
            
            if (processMode == 5 || processMode == 13 || processMode == 7){
                oin.open(contrastSettingTempPath.c_str(), ios::out);
                extension = to_string(entryNumber);
                oin<<extension<<endl;
                oin.close();
            }
            else{
                
                oin.open(contrastSettingPath.c_str(), ios::out);
                extension = to_string(entryNumber);
                oin<<extension<<endl;
                oin.close();
            }
            
            int startingTimePoint = 0;
            
            for (int counter1 = 1; counter1 <= entryNumber; counter1++){
                timeData = arrayContrastData [0][counter1+2];
                timeData = timeData.substr(1);
                
                if (atoi(timeData.c_str()) < entryPoint) startingTimePoint = counter1;
            }
            
            if (startingTimePoint != 0){
                subprocesses = [[SubProcesses alloc] init];
                [subprocesses displayTableSet:startingTimePoint];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                tableViewCall = 1;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Time Point Mismatch. Check Settings"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time Point Mismatch. Check Settings"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Processing Image. Please Wait"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)processStart:(id)sender{
    if (tableDisplayCount != 0 && (processMode == 2 || processMode == 8 || processMode == 10 || processMode == 3 || processMode == 9 || processMode == 11)){
        if (autoProcessingFlag == 0){
            if (currentTimePoint == 1){
                currentTimePoint = 0;
                [timePointDisplay setIntegerValue:currentTimePoint];
            }
            
            ifstream fin;
            
            //-----Check if Field of View (FOV) is set for all treatments-----
            int treatNotFind = 0;
            int fileOpenCheck = 0;
            
            struct stat sizeOfFile;
            
            if (processMode == 5 || processMode == 13 || processMode == 7){
                fileOpenCheck = stat(fovPositionTempPath.c_str(), &sizeOfFile);
            }
            else{
                
                fileOpenCheck = stat(fovPositionPath.c_str(), &sizeOfFile);
            }
            
            if (fileOpenCheck == 0){
                string treatName;
                string getString;
                int treatFind = 0;
                
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    if (arrayTreatmentNameDisplay [counter1] != "ND"){
                        treatName = arrayTreatmentNameDisplay [counter1];
                        treatFind = 0;
                        
                        if (processMode == 5 || processMode == 13 || processMode == 7){
                            fin.open(fovPositionTempPath.c_str(), ios::in);
                        }
                        else fin.open(fovPositionPath.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            do{
                                
                                getline(fin, getString);
                                
                                if (treatName == getString){
                                    treatFind = 1;
                                    break;
                                }
                                
                            } while (getString != "");
                            
                            fin.close();
                        }
                        
                        if (treatFind == 0){
                            treatNotFind = 1;
                            break;
                        }
                    }
                }
            }
            else treatNotFind = 1;
            
            if (treatNotFind == 0){
                DIR *dir;
                struct dirent *dent;
                DIR *dir2;
                struct dirent *dent2;
                
                if (batchImageBodyName == "nil") dir = opendir(stitchedFolderPath.c_str());
                else dir = opendir(stitchedFolderImagePath.c_str());
                
                fileDeleteCount = 0;
                
                if (dir != NULL){
                    string entry;
                    string entry2;
                    string productDataPath1;
                    string productDataPath2;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (batchImageBodyName == "nil") productDataPath1 = stitchedFolderPath+"/"+entry;
                        else productDataPath1 = stitchedFolderImagePath+"/"+entry;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            dir2 = opendir(productDataPath1.c_str());
                            
                            if (dir2 != NULL){
                                while ((dent2 = readdir(dir2))){
                                    entry2 = dent2 -> d_name;
                                    
                                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                    arrayFileDelete [fileDeleteCount] = productDataPath1+"/"+entry2, fileDeleteCount++;
                                }
                                
                                closedir(dir2);
                            }
                        }
                        else remove (productDataPath1.c_str());
                    }
                    
                    closedir(dir);
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                        remove (arrayFileDelete [counter1].c_str());
                    }
                }
                
                if (batchImageBodyName == "nil") dir = opendir(stitchedFolderPath.c_str());
                else dir = opendir(stitchedFolderImagePath.c_str());
                
                if (dir != NULL){
                    string entry;
                    string productDataPath1;
                    
                    fileDeleteCount = 0;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (batchImageBodyName == "nil") productDataPath1 = stitchedFolderPath+"/"+entry;
                        else productDataPath1 = stitchedFolderImagePath+"/"+entry;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                            arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                        }
                    }
                    
                    closedir(dir);
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                        if (batchImageBodyName == "nil") productDataPath1 = stitchedFolderPath+"/"+arrayFileDelete [counter1];
                        else productDataPath1 = stitchedFolderImagePath+"/"+arrayFileDelete [counter1];
                        
                        rmdir (productDataPath1.c_str());
                    }
                }
                
                if (batchImageBodyName == "nil"){
                    rmdir(stitchedFolderPath.c_str());
                    mkdir(stitchedFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                }
                else{
                    
                    rmdir(stitchedFolderImagePath.c_str());
                    mkdir(stitchedFolderImagePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                }
                
                dir = opendir(productsStitchTempPath.c_str());
                fileDeleteCount = 0;
                
                if (dir != NULL){
                    string entry;
                    string entry2;
                    string productDataPath1;
                    string productDataPath2;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        productDataPath1 = productsStitchTempPath+"/"+entry;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            dir2 = opendir(productDataPath1.c_str());
                            
                            if (dir2 != NULL){
                                while ((dent2 = readdir(dir2))){
                                    entry2 = dent2 -> d_name;
                                    
                                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                    arrayFileDelete [fileDeleteCount] = productDataPath1+"/"+entry2, fileDeleteCount++;
                                }
                                
                                closedir(dir2);
                            }
                        }
                        else remove (productDataPath1.c_str());
                    }
                    
                    closedir(dir);
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                        remove (arrayFileDelete [counter1].c_str());
                    }
                }
                
                dir = opendir(productsStitchTempPath.c_str());
                
                if (dir != NULL){
                    string entry;
                    string productDataPath1;
                    
                    fileDeleteCount = 0;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                            arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                        }
                    }
                    
                    closedir(dir);
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                        productDataPath1 = productsStitchTempPath+"/"+arrayFileDelete [counter1];
                        rmdir (productDataPath1.c_str());
                    }
                }
                
                rmdir (productsStitchTempPath.c_str());
                mkdir (productsStitchTempPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                string treatName;
                string fovName;
                string productDataPath1;
                string productDataPath2;
                
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    treatName = arrayTreatmentNameDisplay [counter1];
                    fovName = arrayFOVNameDisplay [counter1];
                    
                    if (treatName != "ND" && fovName != "ND"){
                        if (batchImageBodyName == "nil") productDataPath1 = stitchedFolderPath+"/"+treatName+"_Stitch";
                        else productDataPath1 = stitchedFolderImagePath+"/"+treatName+"_Stitch";
                        
                        productDataPath2 = productsStitchTempPath+"/"+treatName+"_Stitch";
                        
                        if (treatName.substr(treatName.length()-3, 2) != "CH"){
                            mkdir(productDataPath1.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                            mkdir(productDataPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                        }
                    }
                }
                
                remove(loadingCompletePath.c_str());
                
                ofstream oin;
                oin.open(loadingCompletePath.c_str(), ios::out);
                oin<<"End"<<endl;
                oin.close();
                
                [self processStartSub];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"XY-Position Not Set"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Init Mode Required"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)processStartSub{
    autoType = 1;
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToAutocontrast object:self];
}

-(IBAction)processStop:(id)sender{
    int loadingCompleteFlag = 0;
    
    ifstream fin;
    fin.open(loadingCompletePath.c_str(), ios::in);
    
    if (fin.is_open()){
        loadingCompleteFlag = 1;
        fin.close();
    }
    
    if (loadingCompleteFlag == 1){
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"Cancel"];
        [alert addButtonWithTitle:@"Quit"];
        [alert setMessageText:@"Processing File. Please Wait"];
        [alert setInformativeText:@"Quit will result in a termination of Initial setting. Wait until CTS/Done is displayed."];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertSecondButtonReturn){
            remove (loadingCompletePath.c_str());
            [self processStopMain];
        }
    }
    else [self processStopMain];
}

-(void)processStopMain{
    remove (instructionCSPath.c_str());
    
    for (int counter1 = 0; counter1 < contrastDataHorizontal; counter1++){
        delete [] arrayContrastData [counter1];
        delete [] arrayContrastDataG [counter1];
        delete [] arrayContrastDataB [counter1];
    }
    
    delete [] arrayContrastData;
    delete [] arrayContrastDataG;
    delete [] arrayContrastDataB;
    
    delete [] arrayTreatmentNameDisplay;
    delete [] arrayFOVNameDisplay;
    delete [] arrayTableDisplay;
    delete [] arrayTableDisplayG;
    delete [] arrayTableDisplayB;
    
    if (backgroundPatternFirstSet == 1){
        delete [] backgroundPatternArray;
        delete [] backgroundPatternModifyArray;
        delete [] backgroundPatternName;
    }
    
    delete [] contrastValueHold;
    delete [] contrastValueHoldG;
    delete [] contrastValueHoldB;
    delete [] contrastCurrentHold;
    delete [] contrastCurrentHoldG;
    delete [] contrastCurrentHoldB;
    delete [] arrayFileDelete;
    
    if (imageDataHoldStatus == 1){
        for (int counter1 = 0; counter1 < imageDimensionY*loadImageFOVNo+2; counter1++){
            delete [] arrayImageDataHold [counter1];
            delete [] arrayImageRangeAdjust [counter1];
            delete [] arrayBackgroundDataHold [counter1];
            delete [] arrayBackgroundDataHold2 [counter1];
            delete [] arrayImageCutoffAdjust [counter1];
            delete [] arrayBalanceBaseData [counter1];
            delete [] arrayBalanceBaseModify [counter1];
        }
        
        delete [] arrayImageDataHold;
        delete [] arrayImageRangeAdjust;
        delete [] arrayBackgroundDataHold;
        delete [] arrayBackgroundDataHold2;
        delete [] arrayImageCutoffAdjust;
        delete [] arrayImageContrastAdjust;
        delete [] arrayBalanceBaseData;
        delete [] arrayBalanceBaseModify;
        
        delete [] xyPositionData;
        delete [] xyPositionDataHold;
        delete [] arrayXYWritingPosition;
        delete [] arrayXYWritingPositionBase;
        delete [] arrayXYWritingPositionFluorescent;
        
        for (int counter1 = 0; counter1 < stitchImageDimension+2; counter1++){
            delete [] imageDisplayArray [counter1];
            delete [] imagePositionMap [counter1];
            delete [] imageDisplayBaseArray [counter1];
            delete [] imageDisplayFluorescentArray [counter1];
            delete [] arrayBalanceDataHold [counter1];
        }
        
        delete [] imageDisplayArray;
        delete [] imagePositionMap;
        delete [] imageDisplayBaseArray;
        delete [] imageDisplayFluorescentArray;
        delete [] arrayBalanceDataHold;
        
        if (backArraysSetStatus == 1){
            for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                delete [] backBaseArray [counter1];
                delete [] backBaseMap [counter1];
                delete [] backBaseArrayModify [counter1];
                delete [] backBaseArrayEdge [counter1];
                delete [] backAreaMapUpArray [counter1];
                delete [] backAreaMapDownArray [counter1];
            }
            
            delete [] backBaseArray;
            delete [] backBaseMap;
            delete [] backBaseArrayModify;
            delete [] backBaseArrayEdge;
            delete [] backAreaMapUpArray;
            delete [] backAreaMapDownArray;
            
            delete [] backAreaLineUpArray;
            delete [] backAreaLineDownArray;
            
            for (int counter1 = 0; counter1 < 10; counter1++){
                delete [] backBaseArrayPrevious [counter1];
            }
            
            delete [] backBaseArrayPrevious;
            
            delete [] backBasePositionArray;
        }
        
        delete [] arrayImageDataHistogram;
        delete [] arrayImageDataHistogramG;
        delete [] arrayImageDataHistogramB;
        delete [] arrayImageCutoffAdjustHistogram;
        delete [] arrayImageCutoffAdjustHistogramG;
        delete [] arrayImageCutoffAdjustHistogramB;
        delete [] arrayImageRangeAdjustHistogram;
        delete [] arrayImageRangeAdjustHistogramG;
        delete [] arrayImageRangeAdjustHistogramB;
        delete [] arrayImageContrastAdjustHistogram;
        delete [] arrayImageContrastAdjustHistogramG;
        delete [] arrayImageContrastAdjustHistogramB;
        delete [] arrayImageDataLMH;
        delete [] arrayImageDataLMHG;
        delete [] arrayImageDataLMHB;
        delete [] arrayImageRangeAdjustLMH;
        delete [] arrayImageRangeAdjustLMHG;
        delete [] arrayImageRangeAdjustLMHB;
        delete [] autoContrastCorrectLMH;
        delete [] autoContrastCorrectLMHG;
        delete [] autoContrastCorrectLMHB;
        delete [] autoContrastCorrectLMH2;
        delete [] autoContrastCorrectLMH2G;
        delete [] autoContrastCorrectLMH2B;
        delete [] arrayHorizontalLink;
        delete [] arrayVerticalLink;
        
        if (ifReloadStatus == 1) delete [] arrayIfReload;
    }
    
    exit (0);
}

-(IBAction)omnibusSet:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (processMode == 4 || processMode == 6 || processMode == 12){
                if (loadImageNo <= currentTimePoint){
                    autoType = 2;
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToAutocontrast object:self];
                }
                else if (loadImageNo == currentTimePoint+1){
                    autoType = 3;
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToAutocontrast object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Image Number: Below Current Point"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Use 'Contrast Set'"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Treatment Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)tableFW:(id)sender{
    if (autoProcessingFlag == 0){
        string rowNumber = arrayTableDisplay [3].substr(1);
        int entryPoint = 1;
        string timeDetermine;
        
        for (int counter1 = 1; counter1 <= entryNumber; counter1++){
            timeDetermine = arrayContrastData [0][counter1+2];
            timeDetermine = timeDetermine.substr(1);
            
            if (timeDetermine == rowNumber){
                entryPoint = counter1;
                break;
            }
        }
        
        if (entryPoint+1 <= entryNumber){
            int startingTimePoint = entryPoint+1;
            
            subprocesses = [[SubProcesses alloc] init];
            [subprocesses displayTableSet:startingTimePoint];
            
            tableViewCall = 1;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time Point Exceeded"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Processing Image. Please Wait"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)tableBW:(id)sender{
    if (autoProcessingFlag == 0){
        string rowNumber = arrayTableDisplay [3].substr(1);
        int entryPoint = 1;
        string timeDetermine;
        
        for (int counter1 = 1; counter1 <= entryNumber; counter1++){
            timeDetermine = arrayContrastData [0][counter1+2];
            timeDetermine = timeDetermine.substr(1);
            
            if (timeDetermine == rowNumber){
                entryPoint = counter1;
                break;
            }
        }
        
        if (entryPoint-1 > 0){
            int startingTimePoint = entryPoint-1;
            
            subprocesses = [[SubProcesses alloc] init];
            [subprocesses displayTableSet:startingTimePoint];
            
            tableViewCall = 1;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time Point Exceeded"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Processing Image. Please Wait"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)tableTenFW:(id)sender{
    if (autoProcessingFlag == 0){
        string rowNumber = arrayTableDisplay [3].substr(1);
        int entryPoint = 1;
        string timeDetermine;
        
        for (int counter1 = 1; counter1 <= entryNumber; counter1++){
            timeDetermine = arrayContrastData [0][counter1+2];
            timeDetermine = timeDetermine.substr(1);
            
            if (timeDetermine == rowNumber){
                entryPoint = counter1;
                break;
            }
        }
        
        if (entryPoint+10 <= entryNumber){
            int startingTimePoint = entryPoint+10;
            
            subprocesses = [[SubProcesses alloc] init];
            [subprocesses displayTableSet:startingTimePoint];
            
            tableViewCall = 1;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time Point Exceeded"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Processing Image. Please Wait"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)tableTenBW:(id)sender{
    if (autoProcessingFlag == 0){
        string rowNumber = arrayTableDisplay [3].substr(1);
        int entryPoint = 1;
        string timeDetermine;
        
        for (int counter1 = 1; counter1 <= entryNumber; counter1++){
            timeDetermine = arrayContrastData [0][counter1+2];
            timeDetermine = timeDetermine.substr(1);
            
            if (timeDetermine == rowNumber){
                entryPoint = counter1;
                break;
            }
        }
        
        if (entryPoint-10 > 0){
            int startingTimePoint = entryPoint-10;
            
            subprocesses = [[SubProcesses alloc] init];
            [subprocesses displayTableSet:startingTimePoint];
            
            tableViewCall = 1;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time Point Exceeded"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Processing Image. Please Wait"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageFB:(id)sender{
    if (loadImageNo != 0){
        if (autoProcessingFlag == 0){
            if (processMode == 4 || processMode == 6 || processMode == 12){
                loadImageNo++;
                
                if (((processMode == 4 || processMode == 6) && loadImageNo <= lastImageNo) || (processMode == 12 && loadImageNo <= lastProductFileNo)){
                    contrastOADisplay = "Off";
                    imageFLStatus = "Lock";
                    backgroundOADisplay = "Off";
                    processingFovNo = -1;
                    contrastFirstRead = 0;
                    copyFirstTime = 0;
                    
                    [lockStatus setStringValue:@(imageFLStatus.c_str())];
                    [backImageDisplay setStringValue:@(backgroundOADisplay.c_str())];
                    
                    [self currentTableData];
                    
                    [imagePositionDisplay setIntegerValue:loadImageNo];
                    int processType = 3;
                    imageDataSet = [[ImageDataSet alloc] init];
                    [imageDataSet imageDataSetProcess:processType];
                    
                    if (photoMetricHold == 2){
                        if (rgbDisplayStatus == 0){
                            rgbDisplayStatus = 1;
                            [rgbStatusDisplay setStringValue:@"Red"];
                            [rgbStatusHistDisplay setStringValue:@"Red"];
                        }
                    }
                    else{
                        
                        rgbDisplayStatus = 0;
                        [rgbStatusDisplay setStringValue:@"Gray"];
                        [rgbStatusHistDisplay setStringValue:@"Gray"];
                    }
                    
                    if (imageFirstLoadFlagDisplayBK == 1){
                        backgroundOriginalLoadFlag = 1;
                        currentOriginalNo = 1;
                        treatmentBKCall = 1;
                        
                        subprocesses = [[SubProcesses alloc] init];
                        [subprocesses variableSave];
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                    }
                }
                else if (((processMode == 4 || processMode == 6) && loadImageNo > lastImageNo) || (processMode == 12 && loadImageNo > lastProductFileNo)){
                    loadImageNo--;
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Mode Mismatch Detected"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageTenFB:(id)sender{
    if (loadImageNo != 0){
        if (processMode == 4 || processMode == 6 || processMode == 12){
            if (autoProcessingFlag == 0){
                if (((processMode == 4 || processMode == 6) && loadImageNo != lastImageNo) || (processMode == 12 && loadImageNo != lastProductFileNo)){
                    loadImageNo = loadImageNo+10;
                    
                    if (((processMode == 4 || processMode == 6) && loadImageNo <= lastImageNo) || (processMode == 12 && loadImageNo <= lastProductFileNo)){
                        contrastOADisplay = "Off";
                        imageFLStatus = "Lock";
                        backgroundOADisplay = "Off";
                        processingFovNo = -1;
                        contrastFirstRead = 0;
                        copyFirstTime = 0;
                        
                        [lockStatus setStringValue:@(imageFLStatus.c_str())];
                        [backImageDisplay setStringValue:@(backgroundOADisplay.c_str())];
                        
                        [self currentTableData];
                        
                        [imagePositionDisplay setIntegerValue:loadImageNo];
                        int processType = 3;
                        imageDataSet = [[ImageDataSet alloc] init];
                        [imageDataSet imageDataSetProcess:processType];
                        
                        if (photoMetricHold == 2){
                            if (rgbDisplayStatus == 0){
                                rgbDisplayStatus = 1;
                                [rgbStatusDisplay setStringValue:@"Red"];
                                [rgbStatusHistDisplay setStringValue:@"Red"];
                            }
                        }
                        else{
                            
                            rgbDisplayStatus = 0;
                            [rgbStatusDisplay setStringValue:@"Gray"];
                            [rgbStatusHistDisplay setStringValue:@"Gray"];
                        }
                        
                        if (imageFirstLoadFlagDisplayBK == 1){
                            backgroundOriginalLoadFlag = 1;
                            currentOriginalNo = 1;
                            treatmentBKCall = 1;
                            
                            subprocesses = [[SubProcesses alloc] init];
                            [subprocesses variableSave];
                            
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                        }
                    }
                    else if (((processMode == 4 || processMode == 6) && loadImageNo > lastImageNo) || (processMode == 12 && loadImageNo > lastProductFileNo)){
                        if ((processMode == 4 || processMode == 6) && loadImageNo > lastImageNo) loadImageNo = lastImageNo;
                        else if (processMode == 12 && loadImageNo > lastProductFileNo) loadImageNo = lastProductFileNo;
                        
                        contrastOADisplay = "Off";
                        imageFLStatus = "Lock";
                        backgroundOADisplay = "Off";
                        processingFovNo = -1;
                        contrastFirstRead = 0;
                        copyFirstTime = 0;
                        
                        [lockStatus setStringValue:@(imageFLStatus.c_str())];
                        [backImageDisplay setStringValue:@(backgroundOADisplay.c_str())];
                        
                        [self currentTableData];
                        
                        [imagePositionDisplay setIntegerValue:loadImageNo];
                        
                        int processType = 3;
                        imageDataSet = [[ImageDataSet alloc] init];
                        [imageDataSet imageDataSetProcess:processType];
                        
                        if (photoMetricHold == 2){
                            if (rgbDisplayStatus == 0){
                                rgbDisplayStatus = 1;
                                [rgbStatusDisplay setStringValue:@"Red"];
                                [rgbStatusHistDisplay setStringValue:@"Red"];
                            }
                        }
                        else{
                            
                            rgbDisplayStatus = 0;
                            [rgbStatusDisplay setStringValue:@"Gray"];
                            [rgbStatusHistDisplay setStringValue:@"Gray"];
                        }
                        
                        if (imageFirstLoadFlagDisplayBK == 1){
                            backgroundOriginalLoadFlag = 1;
                            currentOriginalNo = 1;
                            treatmentBKCall = 1;
                            
                            subprocesses = [[SubProcesses alloc] init];
                            [subprocesses variableSave];
                            
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                        }
                    }
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Processing Image. Please Wait"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Mode Mismatch Detected"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageHundredFB:(id)sender{
    if (loadImageNo != 0){
        if (processMode == 4 || processMode == 6 || processMode == 12){
            if (autoProcessingFlag == 0){
                if (((processMode == 4 || processMode == 6) && loadImageNo != lastImageNo) || (processMode == 12 && loadImageNo != lastProductFileNo)){
                    loadImageNo = loadImageNo+100;
                    
                    if (((processMode == 4 || processMode == 6) && loadImageNo <= lastImageNo) || (processMode == 12 && loadImageNo <= lastProductFileNo)){
                        contrastOADisplay = "Off";
                        imageFLStatus = "Lock";
                        backgroundOADisplay = "Off";
                        processingFovNo = -1;
                        contrastFirstRead = 0;
                        copyFirstTime = 0;
                        
                        [lockStatus setStringValue:@(imageFLStatus.c_str())];
                        [backImageDisplay setStringValue:@(backgroundOADisplay.c_str())];
                        
                        [self currentTableData];
                        
                        [imagePositionDisplay setIntegerValue:loadImageNo];
                        
                        int processType = 3;
                        imageDataSet = [[ImageDataSet alloc] init];
                        [imageDataSet imageDataSetProcess:processType];
                        
                        if (photoMetricHold == 2){
                            if (rgbDisplayStatus == 0){
                                rgbDisplayStatus = 1;
                                [rgbStatusDisplay setStringValue:@"Red"];
                                [rgbStatusHistDisplay setStringValue:@"Red"];
                            }
                        }
                        else{
                            
                            rgbDisplayStatus = 0;
                            [rgbStatusDisplay setStringValue:@"Gray"];
                            [rgbStatusHistDisplay setStringValue:@"Gray"];
                        }
                        
                        if (imageFirstLoadFlagDisplayBK == 1){
                            backgroundOriginalLoadFlag = 1;
                            currentOriginalNo = 1;
                            treatmentBKCall = 1;
                            
                            subprocesses = [[SubProcesses alloc] init];
                            [subprocesses variableSave];
                            
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                        }
                    }
                    else if (((processMode == 4 || processMode == 6) && loadImageNo > lastImageNo) || (processMode == 12 && loadImageNo > lastProductFileNo)){
                        if ((processMode == 4 || processMode == 6) && loadImageNo > lastImageNo) loadImageNo = lastImageNo;
                        else if (processMode == 12 && loadImageNo > lastProductFileNo) loadImageNo = lastProductFileNo;
                        
                        contrastOADisplay = "Off";
                        imageFLStatus = "Lock";
                        backgroundOADisplay = "Off";
                        processingFovNo = -1;
                        contrastFirstRead = 0;
                        copyFirstTime = 0;
                        
                        [lockStatus setStringValue:@(imageFLStatus.c_str())];
                        [backImageDisplay setStringValue:@(backgroundOADisplay.c_str())];
                        
                        [self currentTableData];
                        
                        [imagePositionDisplay setIntegerValue:loadImageNo];
                        
                        int processType = 3;
                        imageDataSet = [[ImageDataSet alloc] init];
                        [imageDataSet imageDataSetProcess:processType];
                        
                        if (photoMetricHold == 2){
                            if (rgbDisplayStatus == 0){
                                rgbDisplayStatus = 1;
                                [rgbStatusDisplay setStringValue:@"Red"];
                                [rgbStatusHistDisplay setStringValue:@"Red"];
                            }
                        }
                        else{
                            
                            rgbDisplayStatus = 0;
                            [rgbStatusDisplay setStringValue:@"Gray"];
                            [rgbStatusHistDisplay setStringValue:@"Gray"];
                        }
                        
                        if (imageFirstLoadFlagDisplayBK == 1){
                            backgroundOriginalLoadFlag = 1;
                            currentOriginalNo = 1;
                            treatmentBKCall = 1;
                            
                            subprocesses = [[SubProcesses alloc] init];
                            [subprocesses variableSave];
                            
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                        }
                    }
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Processing Image. Please Wait"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Mode Mismatch Detected"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageBW:(id)sender{
    if (loadImageNo != 0){
        if (autoProcessingFlag == 0){
            if (processMode == 4 || processMode == 6 || processMode == 12){
                loadImageNo--;
                
                if (loadImageNo >= 1){
                    contrastOADisplay = "Off";
                    imageFLStatus = "Lock";
                    backgroundOADisplay = "Off";
                    processingFovNo = -1;
                    contrastFirstRead = 0;
                    copyFirstTime = 0;
                    
                    [lockStatus setStringValue:@(imageFLStatus.c_str())];
                    [backImageDisplay setStringValue:@(backgroundOADisplay.c_str())];
                    
                    [self currentTableData];
                    
                    [imagePositionDisplay setIntegerValue:loadImageNo];
                    
                    int processType = 3;
                    imageDataSet = [[ImageDataSet alloc] init];
                    [imageDataSet imageDataSetProcess:processType];
                    
                    if (photoMetricHold == 2){
                        if (rgbDisplayStatus == 0){
                            rgbDisplayStatus = 1;
                            [rgbStatusDisplay setStringValue:@"Red"];
                            [rgbStatusHistDisplay setStringValue:@"Red"];
                        }
                    }
                    else{
                        
                        rgbDisplayStatus = 0;
                        [rgbStatusDisplay setStringValue:@"Gray"];
                        [rgbStatusHistDisplay setStringValue:@"Gray"];
                    }
                    
                    if (imageFirstLoadFlagDisplayBK == 1){
                        backgroundOriginalLoadFlag = 1;
                        currentOriginalNo = 1;
                        treatmentBKCall = 1;
                        
                        subprocesses = [[SubProcesses alloc] init];
                        [subprocesses variableSave];
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                    }
                }
                else if (loadImageNo < 1){
                    loadImageNo = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Mode Mismatch Detected"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageTenBW:(id)sender{
    if (loadImageNo != 0){
        if (autoProcessingFlag == 0){
            if (processMode == 4 || processMode == 6 || processMode == 12){
                if (loadImageNo != 1){
                    loadImageNo = loadImageNo-10;
                    
                    if (loadImageNo >= 1){
                        contrastOADisplay = "Off";
                        imageFLStatus = "Lock";
                        backgroundOADisplay = "Off";
                        processingFovNo = -1;
                        contrastFirstRead = 0;
                        copyFirstTime = 0;
                        
                        [lockStatus setStringValue:@(imageFLStatus.c_str())];
                        [backImageDisplay setStringValue:@(backgroundOADisplay.c_str())];
                        
                        [self currentTableData];
                        
                        [imagePositionDisplay setIntegerValue:loadImageNo];
                        
                        int processType = 3;
                        imageDataSet = [[ImageDataSet alloc] init];
                        [imageDataSet imageDataSetProcess:processType];
                        
                        if (photoMetricHold == 2){
                            if (rgbDisplayStatus == 0){
                                rgbDisplayStatus = 1;
                                [rgbStatusDisplay setStringValue:@"Red"];
                                [rgbStatusHistDisplay setStringValue:@"Red"];
                            }
                        }
                        else{
                            
                            rgbDisplayStatus = 0;
                            [rgbStatusDisplay setStringValue:@"Gray"];
                            [rgbStatusHistDisplay setStringValue:@"Gray"];
                        }
                        
                        if (imageFirstLoadFlagDisplayBK == 1){
                            backgroundOriginalLoadFlag = 1;
                            currentOriginalNo = 1;
                            treatmentBKCall = 1;
                            
                            subprocesses = [[SubProcesses alloc] init];
                            [subprocesses variableSave];
                            
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                        }
                    }
                    else if (loadImageNo < 1){
                        loadImageNo = 1;
                        
                        contrastOADisplay = "Off";
                        imageFLStatus = "Lock";
                        backgroundOADisplay = "Off";
                        processingFovNo = -1;
                        contrastFirstRead = 0;
                        copyFirstTime = 0;
                        
                        [lockStatus setStringValue:@(imageFLStatus.c_str())];
                        [backImageDisplay setStringValue:@(backgroundOADisplay.c_str())];
                        
                        [self currentTableData];
                        
                        [imagePositionDisplay setIntegerValue:loadImageNo];
                        
                        int processType = 3;
                        imageDataSet = [[ImageDataSet alloc] init];
                        [imageDataSet imageDataSetProcess:processType];
                        
                        if (photoMetricHold == 2){
                            if (rgbDisplayStatus == 0){
                                rgbDisplayStatus = 1;
                                [rgbStatusDisplay setStringValue:@"Red"];
                                [rgbStatusHistDisplay setStringValue:@"Red"];
                            }
                        }
                        else{
                            
                            rgbDisplayStatus = 0;
                            [rgbStatusDisplay setStringValue:@"Gray"];
                            [rgbStatusHistDisplay setStringValue:@"Gray"];
                        }
                        
                        if (imageFirstLoadFlagDisplayBK == 1){
                            backgroundOriginalLoadFlag = 1;
                            currentOriginalNo = 1;
                            treatmentBKCall = 1;
                            
                            subprocesses = [[SubProcesses alloc] init];
                            [subprocesses variableSave];
                            
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                        }
                    }
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Mode Mismatch Detected"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageHundredBW:(id)sender{
    if (loadImageNo != 0){
        if (autoProcessingFlag == 0){
            if (processMode == 4 || processMode == 6 || processMode == 12){
                if (loadImageNo != 1){
                    loadImageNo = loadImageNo-100;
                    
                    if (loadImageNo >= 1){
                        contrastOADisplay = "Off";
                        imageFLStatus = "Lock";
                        backgroundOADisplay = "Off";
                        processingFovNo = -1;
                        contrastFirstRead = 0;
                        copyFirstTime = 0;
                        
                        [lockStatus setStringValue:@(imageFLStatus.c_str())];
                        [backImageDisplay setStringValue:@(backgroundOADisplay.c_str())];
                        
                        [self currentTableData];
                        
                        [imagePositionDisplay setIntegerValue:loadImageNo];
                        
                        int processType = 3;
                        imageDataSet = [[ImageDataSet alloc] init];
                        [imageDataSet imageDataSetProcess:processType];
                        
                        if (photoMetricHold == 2){
                            if (rgbDisplayStatus == 0){
                                rgbDisplayStatus = 1;
                                [rgbStatusDisplay setStringValue:@"Red"];
                                [rgbStatusHistDisplay setStringValue:@"Red"];
                            }
                        }
                        else{
                            
                            rgbDisplayStatus = 0;
                            [rgbStatusDisplay setStringValue:@"Gray"];
                            [rgbStatusHistDisplay setStringValue:@"Gray"];
                        }
                        
                        if (imageFirstLoadFlagDisplayBK == 1){
                            backgroundOriginalLoadFlag = 1;
                            currentOriginalNo = 1;
                            treatmentBKCall = 1;
                            
                            subprocesses = [[SubProcesses alloc] init];
                            [subprocesses variableSave];
                            
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                        }
                    }
                    else if (loadImageNo < 1){
                        loadImageNo = 1;
                        
                        contrastOADisplay = "Off";
                        imageFLStatus = "Lock";
                        backgroundOADisplay = "Off";
                        processingFovNo = -1;
                        contrastFirstRead = 0;
                        copyFirstTime = 0;
                        
                        [lockStatus setStringValue:@(imageFLStatus.c_str())];
                        [backImageDisplay setStringValue:@(backgroundOADisplay.c_str())];
                        
                        [self currentTableData];
                        
                        [imagePositionDisplay setIntegerValue:loadImageNo];
                        
                        int processType = 3;
                        imageDataSet = [[ImageDataSet alloc] init];
                        [imageDataSet imageDataSetProcess:processType];
                        
                        if (photoMetricHold == 2){
                            if (rgbDisplayStatus == 0){
                                rgbDisplayStatus = 1;
                                [rgbStatusDisplay setStringValue:@"Red"];
                                [rgbStatusHistDisplay setStringValue:@"Red"];
                            }
                        }
                        else{
                            
                            rgbDisplayStatus = 0;
                            [rgbStatusDisplay setStringValue:@"Gray"];
                            [rgbStatusHistDisplay setStringValue:@"Gray"];
                        }
                        
                        if (imageFirstLoadFlagDisplayBK == 1){
                            backgroundOriginalLoadFlag = 1;
                            currentOriginalNo = 1;
                            treatmentBKCall = 1;
                            
                            subprocesses = [[SubProcesses alloc] init];
                            [subprocesses variableSave];
                            
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundWindow object:self];
                        }
                    }
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Mode Mismatch Detected"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)tableLoad:(id)sender{
    if (processMode == 8 || processMode == 10){
        if (autoProcessingFlag == 0){
            if (statusIFHold == 0 || statusIFHold == 3){
                NSOpenPanel* openDlg = [NSOpenPanel openPanel];
                [openDlg setCanChooseFiles:NO];
                [openDlg setCanChooseDirectories:YES];
                
                if ([openDlg runModal] == NSModalResponseOK){
                    NSArray *files = [openDlg URLs];
                    NSString *fileName = [[files objectAtIndex:0] absoluteString];
                    
                    string directoryPathExtract = [fileName UTF8String];
                    
                    int findString1 = (int)directoryPathExtract.find("/Users/");
                    if (findString1 == -1) findString1 = (int)directoryPathExtract.find("/Volumes/");
                    
                    string directoryPath = directoryPathExtract.substr((unsigned long)findString1, directoryPathExtract.length()-(unsigned long)findString1-1);
                    string extractedID;
                    string extractedID2;
                    
                    int terminationFlag = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        if ((int)directoryPath.find("%20") != -1){
                            extractedID2 = directoryPath.substr(0, directoryPath.find("%20"));
                            directoryPath = directoryPath.substr(directoryPath.find("%20")+3);
                            directoryPath = extractedID2+" "+directoryPath;
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    extractedID = directoryPath;
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        if ((int)extractedID.find("/") != -1){
                            extractedID = extractedID.substr(extractedID.find("/")+1);
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
                    //    for (int counterB = 0; counterB < entryNumber+3; counterB++) cout<<" "<<arrayContrastData [counterA][counterB];
                    //    cout<<"  arrayContrastData "<<counterA+1<<endl;
                    //}
                    
                    if (extractedID != "" && (int)extractedID.find("_Products") != -1 && (int)extractedID.find("_Products_") == -1){
                        string *arrayTreatmentNameDisplayTemp = new string [totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
                        int treatmentNameDisplayTempCount = 0;
                        
                        string *arrayFOVNameDisplayTemp = new string [totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
                        int fovNameDisplayTempCount = 0;
                        
                        string *arrayFOVPositionTemp = new string [treatmentNameDisplayCount*2+50];
                        int fovPositionTempCount = 0;
                        
                        string treatmentPath = directoryPath+"/"+"Analysis_Information"+"/"+"FI-TreatmentNameData";
                        string fovPath = directoryPath+"/"+"Analysis_Information"+"/"+"FI-FOVData";
                        string focalPath = directoryPath+"/"+"Analysis_Information"+"/"+"CT-ContrastData";
                        string focalPathG = directoryPath+"/"+"Analysis_Information"+"/"+"CT-ContrastDataG";
                        string focalPathB = directoryPath+"/"+"Analysis_Information"+"/"+"CT-ContrastDataB";
                        string currentTimePath = directoryPath+"/"+"Analysis_Information"+"/"+"CT-BasicSetting";
                        string fovPositionUploadPath = directoryPath+"/"+"Analysis_Information"+"/"+"CT-FOVPosition";
                        
                        string getString;
                        
                        ifstream fin;
                        fin.open(treatmentPath.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            do{
                                
                                getline(fin, getString);
                                
                                if (getString != "" && treatmentNameDisplayTempCount < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100) arrayTreatmentNameDisplayTemp [treatmentNameDisplayTempCount] = getString, treatmentNameDisplayTempCount++;
                                
                            } while (getString != "");
                            
                            fin.close();
                        }
                        
                        //for (int counterA = 0; counterA < treatmentNameDisplayTempCount; counterA++){
                        //    cout<<arrayTreatmentNameDisplayTemp [counterA]<<"  arrayTreatmentNameDisplayTemp "<<endl;
                        //}
                        
                        fin.open(fovPath.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            do{
                                
                                getline(fin, getString);
                                
                                if (getString != "" && fovNameDisplayTempCount < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100) arrayFOVNameDisplayTemp [fovNameDisplayTempCount] = getString, fovNameDisplayTempCount++;
                                
                            } while (getString != "");
                            
                            fin.close();
                        }
                        
                        //for (int counterA = 0; counterA < fovNameDisplayTempCount; counterA++){
                        //    cout<<arrayFOVNameDisplayTemp [counterA]<<"  arrayFOVNameDisplayTemp "<<endl;
                        //}
                        
                        if (treatmentNameDisplayTempCount == treatmentNameDisplayCount && fovNameDisplayTempCount == fOVNameDisplayCount){
                            int missMatchFind = 0;
                            
                            for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                                if (arrayTreatmentNameDisplay [counter1] != arrayTreatmentNameDisplayTemp [counter1]){
                                    missMatchFind = 1;
                                    break;
                                }
                            }
                            
                            if (missMatchFind == 0){
                                for (int counter1 = 0; counter1 < fOVNameDisplayCount; counter1++){
                                    if (arrayFOVNameDisplay [counter1] != arrayFOVNameDisplayTemp [counter1]){
                                        missMatchFind = 1;
                                        break;
                                    }
                                }
                            }
                            
                            if (missMatchFind == 0){
                                for (int counter1 = 0; counter1 < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100; counter1++){
                                    delete [] arrayContrastData [counter1];
                                    delete [] arrayContrastDataG [counter1];
                                    delete [] arrayContrastDataB [counter1];
                                }
                                
                                delete [] arrayContrastData;
                                delete [] arrayContrastDataG;
                                delete [] arrayContrastDataB;
                                
                                int entryCount = 0;
                                
                                fin.open(focalPath.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    do{
                                        
                                        getline(fin, getString);
                                        
                                        if (getString != "") entryCount++;
                                        
                                    } while (getString != "");
                                    
                                    fin.close();
                                }
                                
                                currentTimePoint = 0;
                                fin.open(currentTimePath.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    getline(fin, getString), entryNumber = atoi(getString.c_str()); //-----Entry Number-----
                                    fin.close();
                                }
                                
                                //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
                                //    for (int counterB = 0; counterB < entryNumber+3; counterB++) cout<<" "<<arrayContrastData [counterA][counterB];
                                //    cout<<"  arrayContrastData "<<counterA+1<<endl;
                                //}
                                
                                contrastDataEntry = entryNumber+50;
                                
                                arrayContrastData = new string *[totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
                                arrayContrastDataG = new string *[totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
                                arrayContrastDataB = new string *[totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
                                
                                contrastDataLimit = entryNumber+50;
                                
                                for (int counter1 = 0; counter1 < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100; counter1++){
                                    arrayContrastData [counter1] = new string [entryNumber+50];
                                    arrayContrastDataG [counter1] = new string [entryNumber+50];
                                    arrayContrastDataB [counter1] = new string [entryNumber+50];
                                }
                                
                                int lineCount = 0;
                                int rgbCheck = 0;
                                
                                fin.open(focalPath.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    do{
                                        
                                        getline(fin, getString);
                                        
                                        if (getString != ""){
                                            arrayContrastData [lineCount][0] = "0";
                                            getline(fin, getString);
                                            arrayContrastData [lineCount][1] = "0";
                                            getline(fin, getString);
                                            arrayContrastData [lineCount][2] = "0";
                                            
                                            for (int counter1 = 0; counter1 < entryNumber; counter1++){
                                                getline(fin, getString);
                                                arrayContrastData [lineCount][counter1+3] = getString;
                                            }
                                            
                                            lineCount++;
                                        }
                                        
                                    } while (getString != "");
                                    
                                    fin.close();
                                }
                                
                                fin.open(focalPathG.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    lineCount = 0;
                                    rgbCheck = 1;
                                    
                                    do{
                                        
                                        getline(fin, getString);
                                        
                                        if (getString != ""){
                                            arrayContrastDataG [lineCount][0] = "0";
                                            getline(fin, getString);
                                            arrayContrastDataG [lineCount][1] = "0";
                                            getline(fin, getString);
                                            arrayContrastDataG [lineCount][2] = "0";
                                            
                                            for (int counter1 = 0; counter1 < entryNumber; counter1++){
                                                getline(fin, getString);
                                                arrayContrastDataG [lineCount][counter1+3] = getString;
                                            }
                                            
                                            lineCount++;
                                        }
                                        
                                    } while (getString != "");
                                    
                                    fin.close();
                                }
                                
                                fin.open(focalPathB.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    lineCount = 0;
                                    
                                    do{
                                        
                                        getline(fin, getString);
                                        
                                        if (getString != ""){
                                            arrayContrastDataB [lineCount][0] = "0";
                                            getline(fin, getString);
                                            arrayContrastDataB [lineCount][1] = "0";
                                            getline(fin, getString);
                                            arrayContrastDataB [lineCount][2] = "0";
                                            
                                            for (int counter1 = 0; counter1 < entryNumber; counter1++){
                                                getline(fin, getString);
                                                arrayContrastDataB [lineCount][counter1+3] = getString;
                                            }
                                            
                                            lineCount++;
                                        }
                                        
                                    } while (getString != "");
                                    
                                    fin.close();
                                }
                                
                                int xBlockNo = 1;
                                int yBlockNo = 1;
                                
                                if (imageDimensionX > 0) xBlockNo = imageDimensionX/8;
                                if (imageDimensionY > 0) yBlockNo = imageDimensionY/8;
                                
                                int backgroundPageMax = backgroundPatternArrayCount/(xBlockNo*yBlockNo);
                                string contrastDataTemp;
                                string bkNumberExtract;
                                string bkNumberFront;
                                string bkNumberBack;
                                
                                for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                                    for (int counter3 = 0; counter3 < entryNumber+3; counter3++){
                                        if (arrayContrastData [counter2][counter3] != ""){
                                            contrastDataTemp = arrayContrastData [counter2][counter3];
                                            
                                            if ((int)contrastDataTemp.find(":") != -1 && (int)contrastDataTemp.find("~") != -1){
                                                bkNumberExtract = contrastDataTemp.substr(contrastDataTemp.find(":")+1, contrastDataTemp.find("~")-contrastDataTemp.find(":")-1);
                                                
                                                if (atoi(bkNumberExtract.c_str()) > backgroundPageMax){
                                                    bkNumberFront = contrastDataTemp.substr(0, contrastDataTemp.find(":")+1);
                                                    bkNumberBack = contrastDataTemp.substr(contrastDataTemp.find("~"));
                                                    arrayContrastData [counter2][counter3] = bkNumberFront+"0"+bkNumberBack;
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                if (photoMetricHold == 2){
                                    for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                                        for (int counter3 = 0; counter3 < entryNumber+3; counter3++){
                                            if (arrayContrastDataG [counter2][counter3] != ""){
                                                contrastDataTemp = arrayContrastDataG [counter2][counter3];
                                                
                                                if ((int)contrastDataTemp.find(":") != -1 && (int)contrastDataTemp.find("~") != -1){
                                                    bkNumberExtract = contrastDataTemp.substr(contrastDataTemp.find(":")+1, contrastDataTemp.find("~")-contrastDataTemp.find(":")-1);
                                                    
                                                    if (atoi(bkNumberExtract.c_str()) > backgroundPageMax){
                                                        bkNumberFront = contrastDataTemp.substr(0, contrastDataTemp.find(":")+1);
                                                        bkNumberBack = contrastDataTemp.substr(contrastDataTemp.find("~"));
                                                        arrayContrastDataG [counter2][counter3] = bkNumberFront+"0"+bkNumberBack;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                                        for (int counter3 = 0; counter3 < entryNumber+3; counter3++){
                                            if (arrayContrastDataB [counter2][counter3] != ""){
                                                contrastDataTemp = arrayContrastDataB [counter2][counter3];
                                                
                                                if ((int)contrastDataTemp.find(":") != -1 && (int)contrastDataTemp.find("~") != -1){
                                                    bkNumberExtract = contrastDataTemp.substr(contrastDataTemp.find(":")+1, contrastDataTemp.find("~")-contrastDataTemp.find(":")-1);
                                                    
                                                    if (atoi(bkNumberExtract.c_str()) > backgroundPageMax){
                                                        bkNumberFront = contrastDataTemp.substr(0, contrastDataTemp.find(":")+1);
                                                        bkNumberBack = contrastDataTemp.substr(contrastDataTemp.find("~"));
                                                        arrayContrastDataB [counter2][counter3] = bkNumberFront+"0"+bkNumberBack;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                //-----Table Set-----
                                int startingTimePoint = 1;
                                tableDisplayCount = 0;
                                tableDisplayCountG = 0;
                                tableDisplayCountB = 0;
                                
                                string timeDetermine;
                                
                                for (int counter1 = 1; counter1 <= entryNumber; counter1++){
                                    timeDetermine = arrayContrastData [0][counter1+2];
                                    timeDetermine = timeDetermine.substr(1);
                                    
                                    if (atoi(timeDetermine.c_str()) < currentTimePoint+1) startingTimePoint = counter1;
                                }
                                
                                int mode = 1;
                                
                                subprocesses = [[SubProcesses alloc] init];
                                [subprocesses displayTableSetInit:startingTimePoint:rgbCheck:mode];
                                
                                ofstream oin;
                                
                                if (processMode == 5 || processMode == 13 || processMode == 7){
                                    string productsContrastTempPath = productsFilesTempPath+"/"+"CT-ContrastData";
                                    string productsContrastTempPathG = productsFilesTempPath+"/"+"CT-ContrastDataG";
                                    string productsContrastTempPathB = productsFilesTempPath+"/"+"CT-ContrastDataB";
                                    
                                    oin.open(productsContrastTempPath.c_str(), ios::out);
                                    
                                    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                                        for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastData [counter1][counter2]<<endl;
                                    }
                                    
                                    oin.close();
                                    
                                    if (photoMetricHold == 2){
                                        oin.open(productsContrastTempPathG.c_str(), ios::out);
                                        
                                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                                            for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastDataG [counter1][counter2]<<endl;
                                        }
                                        
                                        oin.close();
                                        
                                        oin.open(productsContrastTempPathB.c_str(), ios::out);
                                        
                                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                                            for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastDataB [counter1][counter2]<<endl;
                                        }
                                        
                                        oin.close();
                                    }
                                }
                                else{
                                    
                                    string productsContrastPath = productsFilesInfoPath+"/"+"CT-ContrastData";
                                    string productsContrastPathG = productsFilesInfoPath+"/"+"CT-ContrastDataG";
                                    string productsContrastPathB = productsFilesInfoPath+"/"+"CT-ContrastDataB";
                                    
                                    oin.open(productsContrastPath.c_str(), ios::out);
                                    
                                    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                                        for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastData [counter1][counter2]<<endl;
                                    }
                                    
                                    oin.close();
                                    
                                    if (photoMetricHold == 2){
                                        oin.open(productsContrastPathG.c_str(), ios::out);
                                        
                                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                                            for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastDataG [counter1][counter2]<<endl;
                                        }
                                        
                                        oin.close();
                                        
                                        oin.open(productsContrastPathB.c_str(), ios::out);
                                        
                                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                                            for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastDataB [counter1][counter2]<<endl;
                                        }
                                        
                                        oin.close();
                                    }
                                }
                                
                                if (processMode == 5 || processMode == 13 || processMode == 7){
                                    oin.open(contrastSettingTempPath.c_str(), ios::out);
                                    string extension = to_string(entryNumber);
                                    oin<<extension<<endl;
                                    oin.close();
                                }
                                else{
                                    
                                    oin.open(contrastSettingPath.c_str(), ios::out);
                                    string extension = to_string(entryNumber);
                                    oin<<extension<<endl;
                                    oin.close();
                                }
                                
                                fin.open(fovPositionUploadPath.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    do{
                                        
                                        getline(fin, getString);
                                        
                                        if (getString != "") arrayFOVPositionTemp [fovPositionTempCount] = getString, fovPositionTempCount++;
                                        
                                    } while (getString != "");
                                    
                                    fin.close();
                                }
                                
                                if (processMode == 5 || processMode == 13 || processMode == 7) oin.open(fovPositionTempPath.c_str(), ios::out);
                                else oin.open(fovPositionPath.c_str(), ios::out);
                                
                                for (int counter1 = 0; counter1 < fovPositionTempCount; counter1++) oin<<arrayFOVPositionTemp [counter1]<<endl;
                                
                                oin.close();
                                
                                tableViewCall = 1;
                                
                                int processType = 3;
                                imageDataSet = [[ImageDataSet alloc] init];
                                [imageDataSet imageDataSetProcess:processType];
                                
                                if (photoMetricHold == 2){
                                    if (rgbDisplayStatus == 0){
                                        rgbDisplayStatus = 1;
                                        [rgbStatusDisplay setStringValue:@"Red"];
                                        [rgbStatusHistDisplay setStringValue:@"Red"];
                                    }
                                }
                                else{
                                    
                                    rgbDisplayStatus = 0;
                                    [rgbStatusDisplay setStringValue:@"Gray"];
                                    [rgbStatusHistDisplay setStringValue:@"Gray"];
                                }
                                
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                            }
                            else{
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"Table Data Mismatch"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Table Data Mismatch"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                        
                        delete [] arrayTreatmentNameDisplayTemp;
                        delete [] arrayFOVNameDisplayTemp;
                        delete [] arrayFOVPositionTemp;
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Products Folder Missing"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Copying Disabled in IF Mode"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Check Current Mode"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)positionAdjustStart:(id)sender{
    if (autoProcessingFlag == 0  && imageFindFlag == 0){
        if (photoMetricHold == 1){
            if (positionAdjustOperation == 0){
                positionAdjustOperation = 1;
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToAdjustController object:self];
            }
            
            if (positionAdjustOperation == 2) positionAdjustOperation = 3;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Color Images Unsupported"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Processing Image. Please Wait"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)copySetting:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0){
            if (processMode == 4 || processMode == 6 || processMode == 12){
                int copyTimeNumber = (int)[copyTime integerValue];
                int proceedingFlag = 0;
                int entryPoint = 0;
                int currentPointMatch = 0;
                string timeData;
                
                if (copyTimeNumber != 0){
                    for (int counter1 = 1; counter1 <= entryNumber; counter1++){
                        timeData = arrayContrastData [0][counter1+2];
                        timeData = timeData.substr(1);
                        
                        if (copyTimeNumber == atoi(timeData.c_str())){
                            proceedingFlag = 1;
                            entryPoint = counter1;
                            break;
                        }
                    }
                    
                    for (int counter1 = 1; counter1 <= entryNumber; counter1++){
                        timeData = arrayContrastData [0][counter1+2];
                        timeData = timeData.substr(1);
                        
                        if (currentTimePoint == atoi(timeData.c_str())){
                            currentPointMatch = 1;
                            break;
                        }
                    }
                }
                
                if (currentPointMatch == 1) copyFirstTime = 1;
                
                if (proceedingFlag == 1 && copyTimeNumber >= 1){
                    int treatFind = 0;
                    string treatNameTemp2;
                    string fovName2;
                    string copyData;
                    
                    if (copyFirstTime == 1){
                        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                            treatNameTemp2 = arrayTreatmentNameDisplay [counter1];
                            fovName2 = arrayFOVNameDisplay [counter1];
                            
                            if (treatNameTemp2 == loadImageTreatName && fovName2 != "ND" && treatFind == 0){
                                treatFind = 1;
                                
                                if (arrayTableDisplay [counter1*5+2] != "nil"){
                                    arrayTableDisplay [counter1*5+2] = arrayContrastData [counter1][entryPoint+2];
                                    contrastCurrentHold [counter1] = arrayContrastData [counter1][entryPoint+2];
                                    
                                    if (photoMetricHold == 2){
                                        arrayTableDisplayG [counter1*5+2] = arrayContrastDataG [counter1][entryPoint+2];
                                        contrastCurrentHoldG [counter1] = arrayContrastDataG [counter1][entryPoint+2];
                                        
                                        arrayTableDisplayB [counter1*5+2] = arrayContrastDataB [counter1][entryPoint+2];
                                        contrastCurrentHoldB [counter1] = arrayContrastDataB [counter1][entryPoint+2];
                                    }
                                }
                            }
                            else if (treatNameTemp2 == "ND" && fovName2 != "ND" && treatFind == 1){
                                if (arrayTableDisplay [counter1*5+2] != "nil"){
                                    arrayTableDisplay [counter1*5+2] = arrayContrastData [counter1][entryPoint+2];
                                    contrastCurrentHold [counter1] = arrayContrastData [counter1][entryPoint+2];
                                    
                                    if (photoMetricHold == 2){
                                        arrayTableDisplayG [counter1*5+2] = arrayContrastDataG [counter1][entryPoint+2];
                                        contrastCurrentHoldG [counter1] = arrayContrastDataG [counter1][entryPoint+2];
                                        
                                        arrayTableDisplayB [counter1*5+2] = arrayContrastDataB [counter1][entryPoint+2];
                                        contrastCurrentHoldB [counter1] = arrayContrastDataB [counter1][entryPoint+2];
                                    }
                                }
                            }
                            else if (((treatNameTemp2 != "ND" && fovName2 != "ND") || (treatNameTemp2 == "ND" && fovName2 == "ND")) && treatFind == 1){
                                treatFind = 2;
                            }
                        }
                    }
                    else{
                        
                        copyFirstTime = 1;
                        
                        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                            treatNameTemp2 = arrayTreatmentNameDisplay [counter1];
                            fovName2 = arrayFOVNameDisplay [counter1];
                            
                            if (treatNameTemp2 != "ND" && fovName2 != "ND" && treatFind == 0){
                                treatFind = 1;
                                if (arrayTableDisplay [counter1*5+2] != "nil"){
                                    arrayTableDisplay [counter1*5+2] = arrayContrastData [counter1][entryPoint+2];
                                    contrastCurrentHold [counter1] = arrayContrastData [counter1][entryPoint+2];
                                    
                                    if (photoMetricHold == 2){
                                        arrayTableDisplayG [counter1*5+2] = arrayContrastDataG [counter1][entryPoint+2];
                                        contrastCurrentHoldG [counter1] = arrayContrastDataG [counter1][entryPoint+2];
                                        
                                        arrayTableDisplayB [counter1*5+2] = arrayContrastDataB [counter1][entryPoint+2];
                                        contrastCurrentHoldB [counter1] = arrayContrastDataB [counter1][entryPoint+2];
                                    }
                                }
                            }
                            else if (treatNameTemp2 == "ND" && fovName2 != "ND" && treatFind == 1){
                                if (arrayTableDisplay [counter1*5+2] != "nil"){
                                    arrayTableDisplay [counter1*5+2] = arrayContrastData [counter1][entryPoint+2];
                                    contrastCurrentHold [counter1] = arrayContrastData [counter1][entryPoint+2];
                                    
                                    if (photoMetricHold == 2){
                                        arrayTableDisplayG [counter1*5+2] = arrayContrastDataG [counter1][entryPoint+2];
                                        contrastCurrentHoldG [counter1] = arrayContrastDataG [counter1][entryPoint+2];
                                        
                                        arrayTableDisplayB [counter1*5+2] = arrayContrastDataB [counter1][entryPoint+2];
                                        contrastCurrentHoldB [counter1] = arrayContrastDataB [counter1][entryPoint+2];
                                    }
                                }
                            }
                            else if (treatNameTemp2 != "ND" && fovName2 != "ND" && treatFind == 1){
                                if (arrayTableDisplay [counter1*5+2] != "nil"){
                                    arrayTableDisplay [counter1*5+2] = arrayContrastData [counter1][entryPoint+2];
                                    contrastCurrentHold [counter1] = arrayContrastData [counter1][entryPoint+2];
                                    
                                    if (photoMetricHold == 2){
                                        arrayTableDisplayG [counter1*5+2] = arrayContrastDataG [counter1][entryPoint+2];
                                        contrastCurrentHoldG [counter1] = arrayContrastDataG [counter1][entryPoint+2];
                                        
                                        arrayTableDisplayB [counter1*5+2] = arrayContrastDataB [counter1][entryPoint+2];
                                        contrastCurrentHoldB [counter1] = arrayContrastDataB [counter1][entryPoint+2];
                                    }
                                }
                            }
                            else if (treatNameTemp2 == "ND" && fovName2 == "ND" && treatFind == 1) treatFind = 0;
                        }
                    }
                    
                    tableViewCall = 1;
                    
                    int processType = 5;
                    imageDataSet = [[ImageDataSet alloc] init];
                    [imageDataSet imageDataSetProcess:processType];
                    
                    if (photoMetricHold == 2){
                        if (rgbDisplayStatus == 0){
                            rgbDisplayStatus = 1;
                            [rgbStatusDisplay setStringValue:@"Red"];
                            [rgbStatusHistDisplay setStringValue:@"Red"];
                        }
                    }
                    else{
                        
                        rgbDisplayStatus = 0;
                        [rgbStatusDisplay setStringValue:@"Gray"];
                        [rgbStatusHistDisplay setStringValue:@"Gray"];
                    }
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"No Matching Time point"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Mode Mismatch Detected"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)setPixRange:(id)sender{
    /* This works for Gray scale image. */
    
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundOADisplay == "Off"){
                if (photoMetricHold == 1){
                    int rangeTemp = (int)[rangeValueSet integerValue];
                    
                    if (rangeTemp >= 1 && rangeTemp < 100){
                        int pixNo90 = 0;
                        int valueAverage = 0;
                        int totalPix = imageDimensionY*imageDimensionX;
                        int lowerLimitCount = 0;
                        int higherLimitCount = 0;
                        int valueShift = 0;
                        int newPixValue = 0;
                        
                        double expansionFactor = 0;
                        
                        string stringData;
                        string stringExtract;
                        string contrastString;
                        string bkExtract;
                        
                        int *valueFrequency = new int [256];
                        int *histogramTemp = new int [300];
                        
                        for (int counter1 = 0; counter1 < loadImageFOVNo; counter1++){
                            for (int counter2 = 0; counter2 <= 255; counter2++) valueFrequency [counter2] = 0;
                            valueAverage = 0;
                            
                            for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                                for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                    if (arrayImageDataHold [counter1*imageDimensionY+counter2][counter3] >= 0){
                                        valueAverage = valueAverage+arrayImageDataHold [counter1*imageDimensionY+counter2][counter3];
                                        valueFrequency [arrayImageDataHold [counter1*imageDimensionY+counter2][counter3]]++;
                                    }
                                }
                            }
                            
                            valueAverage = (int)(valueAverage/(double)totalPix);
                            pixNo90 = valueFrequency [valueAverage];
                            lowerLimitCount = 0;
                            higherLimitCount = 0;
                            
                            for (int counter2 = 1; counter2 <= 255; counter2++){
                                if (valueAverage-counter2 >= 0){
                                    pixNo90 = pixNo90+valueFrequency [valueAverage-counter2];
                                    lowerLimitCount = valueAverage-counter2;
                                }
                                if (valueAverage+counter2 <= 255){
                                    pixNo90 = pixNo90+valueFrequency [valueAverage+counter2];
                                    higherLimitCount = valueAverage+counter2;
                                }
                                if (pixNo90/(double)totalPix > 0.8){
                                    break;
                                }
                            }
                            
                            expansionFactor = rangeTemp/(double)(higherLimitCount-lowerLimitCount);
                            valueShift = 100-valueAverage;
                            
                            for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                                for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                    if (arrayImageDataHold [counter1*imageDimensionY+counter2][counter3] >= 0){
                                        newPixValue = arrayImageDataHold [counter1*imageDimensionY+counter2][counter3]+valueShift;
                                        
                                        if (newPixValue < 100) newPixValue = newPixValue-(int)(abs(100-newPixValue)*expansionFactor);
                                        else newPixValue = newPixValue+(int)(abs(100-newPixValue)*expansionFactor);
                                        
                                        if (newPixValue < 0) newPixValue = 0;
                                        if (newPixValue > 255) newPixValue = 255;
                                        
                                        arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3] = newPixValue;
                                    }
                                    else arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3] = -1;
                                }
                            }
                            
                            for (int counter3 = 0; counter3 <= 255; counter3++) histogramTemp [counter3] = 0;
                            
                            for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                                for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                    if (arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3] >= 0){
                                        arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3] = arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3];
                                        arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3] = arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3];
                                        
                                        histogramTemp [arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3]]++;
                                    }
                                    else{
                                        
                                        arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3] = -1;
                                        arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3] = -1;
                                    }
                                }
                            }
                            
                            for (int counter2 = 0; counter2 < 256; counter2++){
                                arrayImageCutoffAdjustHistogram [counter1*256+counter2] = histogramTemp [counter2];
                                arrayImageRangeAdjustHistogram [counter1*256+counter2] = histogramTemp [counter2];
                                arrayImageContrastAdjustHistogram [counter1*256+counter2] = histogramTemp [counter2];
                            }
                        }
                        
                        for (int counter1 = 0; counter1 <= 255; counter1++) histogramTemp [counter1] = 0;
                        
                        for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                            for (int counter2 = 0; counter2 < 256; counter2++){
                                histogramTemp [counter2] = histogramTemp [counter2]+arrayImageCutoffAdjustHistogram [(counter1-1)*256+counter2];
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < 256; counter1++){
                            arrayImageCutoffAdjustHistogram [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                            arrayImageRangeAdjustHistogram [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                            arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                        }
                        
                        int numberOfPoint = 0;
                        int lowestValueTemp = 0;
                        int highestValueTemp = 0;
                        int meanValueTemp = 0;
                        
                        unsigned long totalCount = 0;
                        
                        for (int counter1 = 0; counter1 <= loadImageFOVNo; counter1++){
                            numberOfPoint = 0;
                            totalCount = 0;
                            lowestValueTemp = 0;
                            highestValueTemp = 0;
                            meanValueTemp = 0;
                            
                            for (int counter2 = 1; counter2 <= 255; counter2++){
                                numberOfPoint = numberOfPoint+arrayImageCutoffAdjustHistogram [counter1*256+counter2];
                                totalCount = totalCount+(unsigned long)(counter2*arrayImageCutoffAdjustHistogram [counter1*256+counter2]);
                            }
                            
                            if (numberOfPoint != 0) meanValueTemp = (int)(totalCount/(double)numberOfPoint);
                            
                            pixNo90 = arrayImageCutoffAdjustHistogram [counter1*256+meanValueTemp];
                            
                            for (int counter2 = 1; counter2 <= 255; counter2++){
                                if (meanValueTemp-counter2 >= 0){
                                    pixNo90 = pixNo90+arrayImageCutoffAdjustHistogram [counter1*256+meanValueTemp-counter2];
                                    lowestValueTemp = meanValueTemp-counter2;
                                }
                                if (meanValueTemp+counter2 <= 255){
                                    pixNo90 = pixNo90+arrayImageCutoffAdjustHistogram [counter1*256+meanValueTemp+counter2];
                                    highestValueTemp = meanValueTemp+counter2;
                                }
                                if (pixNo90/(double)numberOfPoint > 0.8){
                                    break;
                                }
                            }
                            
                            arrayImageRangeAdjustLMH [counter1*3] = lowestValueTemp;
                            arrayImageRangeAdjustLMH [counter1*3+1] = meanValueTemp;
                            arrayImageRangeAdjustLMH [counter1*3+2] = highestValueTemp;
                            
                            autoContrastCorrectLMH [counter1*3] = lowestValueTemp;
                            autoContrastCorrectLMH [counter1*3+1] = meanValueTemp;
                            autoContrastCorrectLMH [counter1*3+2] = highestValueTemp;
                            
                            autoContrastCorrectLMH2 [counter1*3] = lowestValueTemp;
                            autoContrastCorrectLMH2 [counter1*3+1] = meanValueTemp;
                            autoContrastCorrectLMH2 [counter1*3+2] = highestValueTemp;
                        }
                        
                        if (processingFovNo == -1){
                            lowValueDisplay = autoContrastCorrectLMH [loadImageFOVNo*3];
                            meanValueDisplay = autoContrastCorrectLMH [loadImageFOVNo*3+1];
                            highValueDisplay = autoContrastCorrectLMH [loadImageFOVNo*3+2];
                        }
                        else{
                            
                            lowValueDisplay = autoContrastCorrectLMH [(processingFovNo-1)*3];
                            meanValueDisplay = autoContrastCorrectLMH [(processingFovNo-1)*3+1];
                            highValueDisplay = autoContrastCorrectLMH [(processingFovNo-1)*3+2];
                        }
                        
                        contrastValueDisplay = 0;
                        
                        int entryCount = 0;
                        int writeStartFlag = 0;
                        int lowCut2 = 0;
                        int meanValue2 = 0;
                        int highCut2 = 0;
                        int contrastTemp = 0;
                        double contrastDouble = 0;
                        
                        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                            if (arrayTableDisplay [counter1*5] == loadImageTreatName && arrayTableDisplay [counter1*5+2] != " "){
                                writeStartFlag = 1;
                                
                                lowCut2 = autoContrastCorrectLMH [entryCount*3];
                                meanValue2 = autoContrastCorrectLMH [entryCount*3+1];
                                highCut2 = autoContrastCorrectLMH [entryCount*3+2];
                                
                                stringData = arrayTableDisplay [counter1*5+2];
                                stringExtract = stringData.substr(stringData.find(" ")+1);
                                bkExtract = stringExtract.substr(stringExtract.find(":"));
                                
                                if (bkRemoveLevel == 0) stringExtract = " R"+to_string(rangeTemp);
                                else if (bkRemoveLevel == 1) stringExtract = " A"+to_string(rangeTemp);
                                else if (bkRemoveLevel == 2) stringExtract = " B"+to_string(rangeTemp);
                                else if (bkRemoveLevel == 3) stringExtract = " C"+to_string(rangeTemp);
                                else if (bkRemoveLevel == 4) stringExtract = " D"+to_string(rangeTemp);
                                else if (bkRemoveLevel == 5) stringExtract = " E"+to_string(rangeTemp);
                                else if (bkRemoveLevel == 6) stringExtract = " F"+to_string(rangeTemp);
                                else if (bkRemoveLevel == 7) stringExtract = " G"+to_string(rangeTemp);
                                
                                if (rgbDisplayStatus == 1) stringExtract = " R"+to_string(rangeTemp);
                                
                                contrastTemp = (int)(contrastValueDisplay*100);
                                contrastDouble = contrastTemp/(double)100;
                                
                                stringstream extension4;
                                extension4 << contrastDouble;
                                contrastString = extension4.str();
                                
                                arrayTableDisplay [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringExtract+bkExtract;
                                entryCount++;
                            }
                            else if (writeStartFlag == 1 && arrayTableDisplay [counter1*5] == " " && arrayTableDisplay [counter1*5+2] != " "){
                                lowCut2 = autoContrastCorrectLMH [entryCount*3];
                                meanValue2 = autoContrastCorrectLMH [entryCount*3+1];
                                highCut2 = autoContrastCorrectLMH [entryCount*3+2];
                                
                                stringData = arrayTableDisplay [counter1*5+2];
                                stringExtract = stringData.substr(stringData.find(" "));
                                bkExtract = stringExtract.substr(stringExtract.find(":"));
                                
                                if (bkRemoveLevel == 0) stringExtract = " R"+to_string(rangeTemp);
                                else if (bkRemoveLevel == 1) stringExtract = " A"+to_string(rangeTemp);
                                else if (bkRemoveLevel == 2) stringExtract = " B"+to_string(rangeTemp);
                                else if (bkRemoveLevel == 3) stringExtract = " C"+to_string(rangeTemp);
                                else if (bkRemoveLevel == 4) stringExtract = " D"+to_string(rangeTemp);
                                else if (bkRemoveLevel == 5) stringExtract = " E"+to_string(rangeTemp);
                                else if (bkRemoveLevel == 6) stringExtract = " F"+to_string(rangeTemp);
                                else if (bkRemoveLevel == 7) stringExtract = " G"+to_string(rangeTemp);
                                
                                if (rgbDisplayStatus == 1) stringExtract = " R"+to_string(rangeTemp);
                                
                                contrastTemp = (int)(contrastValueDisplay*100);
                                contrastDouble = contrastTemp/(double)100;
                                
                                stringstream extension4;
                                extension4 << contrastDouble;
                                contrastString = extension4.str();
                                
                                arrayTableDisplay [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringExtract+bkExtract;
                                entryCount++;
                            }
                            else if (writeStartFlag == 1 && ((arrayTableDisplay [counter1*5] != " " && arrayTableDisplay [counter1*5+2] != " ") || (arrayTableDisplay [counter1*5] == " " && arrayTableDisplay [counter1*5+2] == " "))){
                                break;
                            }
                        }
                        
                        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++) contrastCurrentHold [counter1] = arrayTableDisplay [counter1*5+2];
                        
                        contrastValueDisplay = 0;
                        contrastBarActivate = 0;
                        tableViewCall = 1;
                        imageInfoDisplayCall = 1;
                        mainImageDisplayCall = 1;
                        contrastDisplayCall = 1;
                        histogramDisplayCall = 1;
                        
                        delete [] valueFrequency;
                        delete [] histogramTemp;
                        
                        contrastOADisplay = "On";
                        
                        [contrastImageDisplay setIntegerValue:rangeTemp];
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Value Out Of Range"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Color Images Unsupported"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Turn Off Background Correction"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clearRange:(id)sender{
    /* This works for Gray scale image. */
    
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (backgroundOADisplay == "Off"){
                if (photoMetricHold == 1){
                    for (int counter1 = 0; counter1 < loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3] = arrayImageDataHold [counter1*imageDimensionY+counter2][counter3];
                                arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3] = arrayImageDataHold [counter1*imageDimensionY+counter2][counter3];
                                arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3] = arrayImageDataHold [counter1*imageDimensionY+counter2][counter3];
                            }
                        }
                    }
                    
                    for (int counter1 = 0; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 < 256; counter2++){
                            arrayImageRangeAdjustHistogram [counter1*256+counter2] = arrayImageDataHistogram [counter1*256+counter2];
                            arrayImageCutoffAdjustHistogram [counter1*256+counter2] = arrayImageDataHistogram [counter1*256+counter2];
                            arrayImageContrastAdjustHistogram [counter1*256+counter2] = arrayImageDataHistogram [counter1*256+counter2];
                        }
                    }
                    
                    for (int counter1 = 0; counter1 <= loadImageFOVNo; counter1++){
                        arrayImageRangeAdjustLMH [counter1*3] = arrayImageDataLMH [counter1*3];
                        arrayImageRangeAdjustLMH [counter1*3+1] = arrayImageDataLMH [counter1*3+1];
                        arrayImageRangeAdjustLMH [counter1*3+2] = arrayImageDataLMH [counter1*3+2];
                        
                        autoContrastCorrectLMH [counter1*3] = arrayImageDataLMH [counter1*3];
                        autoContrastCorrectLMH [counter1*3+1] = arrayImageDataLMH [counter1*3+1];
                        autoContrastCorrectLMH [counter1*3+2] = arrayImageDataLMH [counter1*3+2];
                        
                        autoContrastCorrectLMH2 [counter1*3] = arrayImageDataLMH [counter1*3];
                        autoContrastCorrectLMH2 [counter1*3+1] = arrayImageDataLMH [counter1*3+1];
                        autoContrastCorrectLMH2 [counter1*3+2] = arrayImageDataLMH [counter1*3+2];
                    }
                    
                    if (processingFovNo == -1){
                        lowValueDisplay = arrayImageDataLMH [loadImageFOVNo*3];
                        meanValueDisplay = arrayImageDataLMH [loadImageFOVNo*3+1];
                        highValueDisplay = arrayImageDataLMH [loadImageFOVNo*3+2];
                    }
                    else{
                        
                        lowValueDisplay = arrayImageDataLMH [(processingFovNo-1)*3];
                        meanValueDisplay = arrayImageDataLMH [(processingFovNo-1)*3+1];
                        highValueDisplay = arrayImageDataLMH [(processingFovNo-1)*3+2];
                    }
                    
                    contrastValueDisplay = 0;
                    
                    int entryCount = 0;
                    int writeStartFlag = 0;
                    int lowCut2 = 0;
                    int meanValue2 = 0;
                    int highCut2 = 0;
                    int contrastTemp = 0;
                    double contrastDouble = 0;
                    
                    string stringData;
                    string stringExtract;
                    string contrastString;
                    string bkExtract;
                    
                    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                        if (arrayTableDisplay [counter1*5] == loadImageTreatName && arrayTableDisplay [counter1*5+2] != " "){
                            writeStartFlag = 1;
                            
                            lowCut2 = arrayImageDataLMH [entryCount*3];
                            meanValue2 = arrayImageDataLMH [entryCount*3+1];
                            highCut2 = arrayImageDataLMH [entryCount*3+2];
                            
                            stringData = arrayTableDisplay [counter1*5+2];
                            stringExtract = stringData.substr(stringData.find(" ")+1);
                            bkExtract = stringExtract.substr(stringExtract.find(":"));
                            
                            if (bkRemoveLevel == 0) stringExtract = " R0";
                            else if (bkRemoveLevel == 1) stringExtract = " A0";
                            else if (bkRemoveLevel == 2) stringExtract = " B0";
                            else if (bkRemoveLevel == 3) stringExtract = " C0";
                            else if (bkRemoveLevel == 4) stringExtract = " D0";
                            else if (bkRemoveLevel == 5) stringExtract = " E0";
                            else if (bkRemoveLevel == 6) stringExtract = " F0";
                            else if (bkRemoveLevel == 7) stringExtract = " G0";
                            
                            if (rgbDisplayStatus == 1) stringExtract = " R0";
                            
                            contrastTemp = (int)(contrastValueDisplay*100);
                            contrastDouble = contrastTemp/(double)100;
                            
                            stringstream extension4;
                            extension4 << contrastDouble;
                            contrastString = extension4.str();
                            
                            arrayTableDisplay [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringExtract+bkExtract;
                            entryCount++;
                        }
                        else if (writeStartFlag == 1 && arrayTableDisplay [counter1*5] == " " && arrayTableDisplay [counter1*5+2] != " "){
                            lowCut2 = autoContrastCorrectLMH [entryCount*3];
                            meanValue2 = autoContrastCorrectLMH [entryCount*3+1];
                            highCut2 = autoContrastCorrectLMH [entryCount*3+2];
                            
                            stringData = arrayTableDisplay [counter1*5+2];
                            stringExtract = stringData.substr(stringData.find(" "));
                            bkExtract = stringExtract.substr(stringExtract.find(":"));
                            
                            if (bkRemoveLevel == 0) stringExtract = " R0";
                            else if (bkRemoveLevel == 1) stringExtract = " A0";
                            else if (bkRemoveLevel == 2) stringExtract = " B0";
                            else if (bkRemoveLevel == 3) stringExtract = " C0";
                            else if (bkRemoveLevel == 4) stringExtract = " D0";
                            else if (bkRemoveLevel == 5) stringExtract = " E0";
                            else if (bkRemoveLevel == 6) stringExtract = " F0";
                            else if (bkRemoveLevel == 7) stringExtract = " G0";
                            
                            if (rgbDisplayStatus == 1) stringExtract = " R0";
                            
                            contrastTemp = (int)(contrastValueDisplay*100);
                            contrastDouble = contrastTemp/(double)100;
                            
                            stringstream extension4;
                            extension4 << contrastDouble;
                            contrastString = extension4.str();
                            
                            arrayTableDisplay [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringExtract+bkExtract;
                            entryCount++;
                        }
                        else{
                            
                            if (writeStartFlag == 1 && ((arrayTableDisplay [counter1*5] != " " && arrayTableDisplay [counter1*5+2] != " ") || (arrayTableDisplay [counter1*5] == " " && arrayTableDisplay [counter1*5+2] == " "))){
                                break;
                            }
                        }
                    }
                    
                    contrastValueDisplay = 0;
                    contrastBarActivate = 0;
                    tableViewCall = 1;
                    imageInfoDisplayCall = 1;
                    mainImageDisplayCall = 1;
                    contrastDisplayCall = 1;
                    histogramDisplayCall = 1;
                    
                    contrastOADisplay = "On";
                    
                    [contrastImageDisplay setStringValue:@"nil"];
                    [rangeValueSet setStringValue:@""];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Color Images Unsupported"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Turn Off Background Correction"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)timeSourceSet:(id)sender{
    if (sourceTimeDisplayFlag == 1){
        sourceTimeDisplayFlag = 0;
        
        [sourceTimeStatusDisplay setTextColor:[NSColor blackColor]];
        [sourceTimeStatusDisplay setStringValue:@"Source"];
        [sourceTimeStatusDisplay2 setStringValue:@"Source"];
    }
    else{
        
        sourceTimeDisplayFlag = 1;
        
        [sourceTimeStatusDisplay setTextColor:[NSColor redColor]];
        [sourceTimeStatusDisplay setStringValue:@"Time"];
        [sourceTimeStatusDisplay2 setStringValue:@"Time"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)backgroundAdjustStart:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (photoMetricHold == 1){
                if (imageDimensionY == imageDimensionX){
                    if (backgroundAdjustOperation == 0){
                        backgroundAdjustOperation = 1;
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackgroundController object:self];
                    }
                    
                    if (backgroundAdjustOperation == 2) backgroundAdjustOperation = 3;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Images Must Be Square"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Color Images Unsupported"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Treatment Not Selected"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Processing Image. Please Wait"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)bkRemovalSet:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (photoMetricHold == 1){
                if (backgroundOADisplay == "Off"){
                    NSString *levelNumber = [bkRemovalLevelSet stringValue];
                    string levelNumberString = [levelNumber UTF8String];
                    
                    if (levelNumberString == "a" || levelNumberString == "A" || levelNumberString == "b" || levelNumberString == "B" || levelNumberString == "c" || levelNumberString == "C" || levelNumberString == "d" || levelNumberString == "D" || levelNumberString == "e" || levelNumberString == "E" || levelNumberString == "f" || levelNumberString == "F" || levelNumberString == "g" || levelNumberString == "G" || levelNumberString == "r" || levelNumberString == "R"){
                        if (levelNumberString == "a" || levelNumberString == "A") bkRemoveLevel = 1;
                        else if (levelNumberString == "b" || levelNumberString == "B") bkRemoveLevel = 2;
                        else if (levelNumberString == "c" || levelNumberString == "C") bkRemoveLevel = 3;
                        else if (levelNumberString == "d" || levelNumberString == "D") bkRemoveLevel = 4;
                        else if (levelNumberString == "e" || levelNumberString == "E") bkRemoveLevel = 5;
                        else if (levelNumberString == "f" || levelNumberString == "F") bkRemoveLevel = 6;
                        else if (levelNumberString == "g" || levelNumberString == "G") bkRemoveLevel = 7;
                        else if (levelNumberString == "r" || levelNumberString == "R") bkRemoveLevel = 0;
                        
                        if (bkRemoveLevel == 1) [bkRemovalLevelDisplay setStringValue:@"A"];
                        else if (bkRemoveLevel == 2) [bkRemovalLevelDisplay setStringValue:@"B"];
                        else if (bkRemoveLevel == 3) [bkRemovalLevelDisplay setStringValue:@"C"];
                        else if (bkRemoveLevel == 4) [bkRemovalLevelDisplay setStringValue:@"D"];
                        else if (bkRemoveLevel == 5) [bkRemovalLevelDisplay setStringValue:@"E"];
                        else if (bkRemoveLevel == 6) [bkRemovalLevelDisplay setStringValue:@"F"];
                        else if (bkRemoveLevel == 7) [bkRemovalLevelDisplay setStringValue:@"G"];
                        else if (bkRemoveLevel == 0) [bkRemovalLevelDisplay setStringValue:@"R"];
                        
                        int entryCount = 0;
                        int writeStartFlag = 0;
                        
                        string stringData;
                        string stringExtract;
                        string bkExtract;
                        
                        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                            if (arrayTableDisplay [counter1*5] == loadImageTreatName && arrayTableDisplay [counter1*5+2] != " "){
                                writeStartFlag = 1;
                                
                                stringData = arrayTableDisplay [counter1*5+2];
                                stringExtract = stringData.substr(0, stringData.find(" "));
                                bkExtract = stringData.substr(stringData.find(" ")+2);
                                
                                if (bkRemoveLevel == 0) stringExtract = stringExtract+" R"+bkExtract;
                                else if (bkRemoveLevel == 1) stringExtract = stringExtract+" A"+bkExtract;
                                else if (bkRemoveLevel == 2) stringExtract = stringExtract+" B"+bkExtract;
                                else if (bkRemoveLevel == 3) stringExtract = stringExtract+" C"+bkExtract;
                                else if (bkRemoveLevel == 4) stringExtract = stringExtract+" D"+bkExtract;
                                else if (bkRemoveLevel == 5) stringExtract = stringExtract+" E"+bkExtract;
                                else if (bkRemoveLevel == 6) stringExtract = stringExtract+" F"+bkExtract;
                                else if (bkRemoveLevel == 7) stringExtract = stringExtract+" G"+bkExtract;
                                
                                arrayTableDisplay [counter1*5+2] = stringExtract;
                                entryCount++;
                            }
                            else if (writeStartFlag == 1 && arrayTableDisplay [counter1*5] == " " && arrayTableDisplay [counter1*5+2] != " "){
                                stringData = arrayTableDisplay [counter1*5+2];
                                stringExtract = stringData.substr(0, stringData.find(" "));
                                bkExtract = stringData.substr(stringData.find(" ")+2);
                                
                                if (bkRemoveLevel == 0) stringExtract = stringExtract+" R"+bkExtract;
                                else if (bkRemoveLevel == 1) stringExtract = stringExtract+" A"+bkExtract;
                                else if (bkRemoveLevel == 2) stringExtract = stringExtract+" B"+bkExtract;
                                else if (bkRemoveLevel == 3) stringExtract = stringExtract+" C"+bkExtract;
                                else if (bkRemoveLevel == 4) stringExtract = stringExtract+" D"+bkExtract;
                                else if (bkRemoveLevel == 5) stringExtract = stringExtract+" E"+bkExtract;
                                else if (bkRemoveLevel == 6) stringExtract = stringExtract+" F"+bkExtract;
                                else if (bkRemoveLevel == 7) stringExtract = stringExtract+" G"+bkExtract;
                                
                                arrayTableDisplay [counter1*5+2] = stringExtract;
                                entryCount++;
                            }
                            else if (writeStartFlag == 1 && ((arrayTableDisplay [counter1*5] != " " && arrayTableDisplay [counter1*5+2] != " ") || (arrayTableDisplay [counter1*5] == " " && arrayTableDisplay [counter1*5+2] == " "))){
                                break;
                            }
                        }
                        
                        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                            contrastCurrentHold [counter1] = arrayTableDisplay [counter1*5+2];
                        }
                        
                        tableViewCall = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        [bkRemovalLevelSet setStringValue:@""];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Turn Off Background Correction"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Color Images Unsupported"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)blurSet:(id)sender{
    if (loadImageTreatName != ""){
        if (blurStatusHold == 1){
            blurStatusHold = 0;
            [blurStatusDisplay setStringValue:@"On"];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            blurStatusHold = 1;
            [blurStatusDisplay setStringValue:@"Off"];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        
        subprocesses = [[SubProcesses alloc] init];
        [subprocesses variableSave];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)positionBalanceStart:(id)sender{
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        if (photoMetricHold == 1){
            if (positionBalanceOperation == 0){
                positionBalanceOperation = 1;
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBalanceController object:self];
            }
            
            if (positionBalanceOperation == 2) positionBalanceOperation = 3;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Color Images Unsupported"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Processing Image. Please Wait"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)ifReloadStart:(id)sender{
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        if (processMode == 2 || processMode == 8 || processMode == 10){
            if (statusIFHold == 1 || statusIFHold == 2){
                if (ifReloadWindowOperation == 0){
                    ifReloadWindowOperation = 1;
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToIFReloadController object:self];
                }
                
                if (ifReloadWindowOperation == 2) ifReloadWindowOperation = 3;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"IF Mode Not Active"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Init Mode Off"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Processing Image. Please Wait"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)tempContrastReloadStart:(id)sender{
    if (autoProcessingFlag == 0){
        if (processMode == 2 || processMode == 8 || processMode == 10){
            string focalPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ContrastDataTemp-"+bodyName+"~CP";
            string focalPathG = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ContrastDataTemp-"+bodyName+"~CPG";
            string focalPathB = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ContrastDataTemp-"+bodyName+"~CPB";
            
            ifstream fin;
            
            fin.open(focalPath.c_str(), ios::in);
            
            if (fin.is_open()){
                fin.close();
                
                string currentTimePath;
                string getString;
                
                for (int counter1 = 0; counter1 < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100; counter1++){
                    delete [] arrayContrastData [counter1];
                    delete [] arrayContrastDataG [counter1];
                    delete [] arrayContrastDataB [counter1];
                }
                
                delete [] arrayContrastData;
                delete [] arrayContrastDataG;
                delete [] arrayContrastDataB;
                
                int entryCount = 0;
                
                fin.open(focalPath.c_str(), ios::in);
                
                if (fin.is_open()){
                    do{
                        
                        getline(fin, getString);
                        
                        if ((int)getString.find("T") != -1) entryCount++;
                        
                    } while (getString != "");
                    
                    fin.close();
                }
                
                entryNumber = 1;
                
                contrastDataEntry = entryNumber+50;
                arrayContrastData = new string *[totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
                arrayContrastDataG = new string *[totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
                arrayContrastDataB = new string *[totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
                
                contrastDataLimit = entryNumber+50;
                
                for (int counter1 = 0; counter1 < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100; counter1++){
                    arrayContrastData [counter1] = new string [entryNumber+50];
                    arrayContrastDataG [counter1] = new string [entryNumber+50];
                    arrayContrastDataB [counter1] = new string [entryNumber+50];
                }
                
                string **contrastTemp = new string *[totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
                for (int counter1 = 0; counter1 < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100; counter1++) contrastTemp [counter1] = new string [entryCount+50];
                
                int lineCount = 0;
                int rgbCheck = 0;
                
                fin.open(focalPath.c_str(), ios::in);
                
                if (fin.is_open()){
                    do{
                        
                        getline(fin, getString);
                        
                        if (getString != ""){
                            contrastTemp [lineCount][0] = "0";
                            getline(fin, getString);
                            contrastTemp [lineCount][1] = "0";
                            getline(fin, getString);
                            contrastTemp [lineCount][2] = "0";
                            
                            for (int counter1 = 0; counter1 < entryCount; counter1++) getline(fin, getString), contrastTemp [lineCount][counter1+3] = getString;
                            
                            lineCount++;
                        }
                        
                    } while (getString != "");
                    
                    fin.close();
                    
                    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                        for (int counter2 = 0; counter2 < entryNumber+3; counter2++){
                            arrayContrastData [counter1][counter2] = contrastTemp [counter1][counter2];
                        }
                    }
                }
                
                fin.open(focalPathG.c_str(), ios::in);
                
                if (fin.is_open()){
                    lineCount = 0;
                    rgbCheck = 1;
                    
                    do{
                        
                        getline(fin, getString);
                        
                        if (getString != ""){
                            contrastTemp [lineCount][0] = "0";
                            getline(fin, getString);
                            contrastTemp [lineCount][1] = "0";
                            getline(fin, getString);
                            contrastTemp [lineCount][2] = "0";
                            
                            for (int counter1 = 0; counter1 < entryCount; counter1++) getline(fin, getString), contrastTemp [lineCount][counter1+3] = getString;
                            
                            lineCount++;
                        }
                        
                    } while (getString != "");
                    
                    fin.close();
                    
                    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                        for (int counter2 = 0; counter2 < entryNumber+3; counter2++){
                            arrayContrastDataG [counter1][counter2] = contrastTemp [counter1][counter2];
                        }
                    }
                }
                
                fin.open(focalPathB.c_str(), ios::in);
                
                if (fin.is_open()){
                    lineCount = 0;
                    
                    do{
                        
                        getline(fin, getString);
                        
                        if (getString != ""){
                            contrastTemp [lineCount][0] = "0";
                            getline(fin, getString);
                            contrastTemp [lineCount][1] = "0";
                            getline(fin, getString);
                            contrastTemp [lineCount][2] = "0";
                            
                            for (int counter1 = 0; counter1 < entryCount; counter1++) getline(fin, getString), contrastTemp [lineCount][counter1+3] = getString;
                            
                            lineCount++;
                        }
                        
                    } while (getString != "");
                    
                    fin.close();
                    
                    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                        for (int counter2 = 0; counter2 < entryNumber+3; counter2++){
                            arrayContrastDataB [counter1][counter2] = contrastTemp [counter1][counter2];
                        }
                    }
                }
                
                for (int counter1 = 0; counter1 < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100; counter1++){
                    delete [] contrastTemp [counter1];
                }
                
                delete [] contrastTemp;
                
                //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
                //    for (int counterB = 0; counterB < entryNumber+3; counterB++) cout<<" "<<arrayContrastData [counterA][counterB];
                //    cout<<"  arrayContrastData "<<counterA+1<<endl;
                //}
                
                int xBlockNo = 1;
                int yBlockNo = 1;
                
                if (imageDimensionX > 0) xBlockNo = imageDimensionX/8;
                if (imageDimensionY > 0) yBlockNo = imageDimensionY/8;
                
                int backgroundPageMax = backgroundPatternArrayCount/(xBlockNo*yBlockNo);
                string contrastDataTemp;
                string bkNumberExtract;
                string bkNumberFront;
                string bkNumberBack;
                
                for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                    for (int counter3 = 0; counter3 < entryNumber+3; counter3++){
                        if (arrayContrastData [counter2][counter3] != ""){
                            contrastDataTemp = arrayContrastData [counter2][counter3];
                            
                            if ((int)contrastDataTemp.find(":") != -1 && (int)contrastDataTemp.find("~") != -1){
                                bkNumberExtract = contrastDataTemp.substr(contrastDataTemp.find(":")+1, contrastDataTemp.find("~")-contrastDataTemp.find(":")-1);
                                
                                if (atoi(bkNumberExtract.c_str()) > backgroundPageMax){
                                    bkNumberFront = contrastDataTemp.substr(0, contrastDataTemp.find(":")+1);
                                    bkNumberBack = contrastDataTemp.substr(contrastDataTemp.find("~"));
                                    arrayContrastData [counter2][counter3] = bkNumberFront+"0"+bkNumberBack;
                                }
                            }
                        }
                    }
                }
                
                if (photoMetricHold == 2){
                    for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                        for (int counter3 = 0; counter3 < entryNumber+3; counter3++){
                            if (arrayContrastDataG [counter2][counter3] != ""){
                                contrastDataTemp = arrayContrastDataG [counter2][counter3];
                                
                                if ((int)contrastDataTemp.find(":") != -1 && (int)contrastDataTemp.find("~") != -1){
                                    bkNumberExtract = contrastDataTemp.substr(contrastDataTemp.find(":")+1, contrastDataTemp.find("~")-contrastDataTemp.find(":")-1);
                                    
                                    if (atoi(bkNumberExtract.c_str()) > backgroundPageMax){
                                        bkNumberFront = contrastDataTemp.substr(0, contrastDataTemp.find(":")+1);
                                        bkNumberBack = contrastDataTemp.substr(contrastDataTemp.find("~"));
                                        arrayContrastDataG [counter2][counter3] = bkNumberFront+"0"+bkNumberBack;
                                    }
                                }
                            }
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                        for (int counter3 = 0; counter3 < entryNumber+3; counter3++){
                            if (arrayContrastDataB [counter2][counter3] != ""){
                                contrastDataTemp = arrayContrastDataB [counter2][counter3];
                                
                                if ((int)contrastDataTemp.find(":") != -1 && (int)contrastDataTemp.find("~") != -1){
                                    bkNumberExtract = contrastDataTemp.substr(contrastDataTemp.find(":")+1, contrastDataTemp.find("~")-contrastDataTemp.find(":")-1);
                                    
                                    if (atoi(bkNumberExtract.c_str()) > backgroundPageMax){
                                        bkNumberFront = contrastDataTemp.substr(0, contrastDataTemp.find(":")+1);
                                        bkNumberBack = contrastDataTemp.substr(contrastDataTemp.find("~"));
                                        arrayContrastDataB [counter2][counter3] = bkNumberFront+"0"+bkNumberBack;
                                    }
                                }
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
                //    for (int counterB = 0; counterB < entryNumber+3; counterB++) cout<<" "<<arrayContrastData [counterA][counterB];
                //    cout<<"  arrayContrastData "<<counterA+1<<endl;
                //}
                
                //-----Table Set-----
                int startingTimePoint = 1;
                tableDisplayCount = 0;
                tableDisplayCountG = 0;
                tableDisplayCountB = 0;
                
                string timeDetermine;
                
                for (int counter1 = 1; counter1 <= entryNumber; counter1++){
                    timeDetermine = arrayContrastData [0][counter1+2];
                    timeDetermine = timeDetermine.substr(1);
                    
                    if (atoi(timeDetermine.c_str()) < currentTimePoint+1) startingTimePoint = counter1;
                }
                
                int mode = 1;
                
                subprocesses = [[SubProcesses alloc] init];
                [subprocesses displayTableSetInit:startingTimePoint:rgbCheck:mode];
                
                tableViewCall = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Temp Contrast File Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Init Setting Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Processing Image. Please Wait"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)controlTextDidChange:(NSNotification *)aNotification {
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]) {
        if ([aNotification object] == reprocessFromDisplay){
            if ([reprocessFromDisplay intValue] >= 1 && [reprocessFromDisplay intValue] <= lastProductFileNo){
                [stepperFrom setIntValue:[reprocessFromDisplay intValue]];
                processingFromHold = [reprocessFromDisplay intValue];
            }
        }
        
        if ([aNotification object] == reprocessToDisplay){
            if ([reprocessToDisplay intValue] >= 1 && [reprocessToDisplay intValue] <= lastProductFileNo){
                [stepperTo setIntValue:[reprocessToDisplay intValue]];
                processingToHold = [reprocessToDisplay intValue];
            }
        }
    }
}

-(IBAction)stepperActionFrom:(id)sender{
    if ([stepperFrom intValue] >= 1 && [stepperFrom intValue] <= lastProductFileNo){
        [reprocessFromDisplay setIntValue:[stepperFrom intValue]];
        processingFromHold = [stepperFrom intValue];
    }
}

-(IBAction)stepperActionTo:(id)sender{
    if ([stepperTo intValue] >= 1 && [stepperTo intValue] <= lastProductFileNo){
        [reprocessToDisplay setIntValue:[stepperTo intValue]];
        processingToHold = [stepperTo intValue];
    }
}

-(IBAction)reProcessingSet:(id)sender{
    if (loadImageTreatName != ""){
        if (processMode == 4 || processMode == 6 || processMode == 12){
            if (reprocessStatus == 0){
                if (processingFromHold == 0 || processingToHold == 0){
                    [reprocessFromDisplay setIntegerValue:0];
                    [reprocessToDisplay setIntegerValue:0];
                    [stepperFrom setIntValue:0];
                    [stepperTo setIntValue:0];
                    
                    processingFromHold = 0;
                    processingToHold = 0;
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                else if (processingFromHold >= processingToHold || processingFromHold+1 == processingToHold){
                    [reprocessFromDisplay setIntegerValue:0];
                    [reprocessToDisplay setIntegerValue:0];
                    [stepperFrom setIntValue:0];
                    [stepperTo setIntValue:0];
                    
                    processingFromHold = 0;
                    processingToHold = 0;
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                else{
                    
                    int fileNoTemp = 0;
                    
                    DIR *dir;
                    struct dirent *dent;
                    DIR *dir2;
                    struct dirent *dent2;
                    
                    dir = opendir(stitchedFolderPath.c_str());
                    
                    if (dir != NULL){
                        string entry;
                        string entry2;
                        string productDataPath1;
                        string productDataPath2;
                        string fileNoCheckTemp;
                        
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            productDataPath1 = stitchedFolderPath+"/"+entry;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                dir2 = opendir(productDataPath1.c_str());
                                
                                if (dir2 != NULL){
                                    while ((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && (int)entry2.find("STimage ") != -1){
                                            fileNoCheckTemp = entry2.substr(entry2.find("STimage ")+8, 4);
                                            
                                            if (atoi(fileNoCheckTemp.c_str()) > fileNoTemp) fileNoTemp = atoi(fileNoCheckTemp.c_str());
                                        }
                                    }
                                    
                                    closedir(dir2);
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    int processingFromSet = 0;
                    int processingToSet = 0;
                    
                    if (processingToHold <= fileNoTemp){
                        processingFromSet = processingFromHold;
                        processingToSet = processingToHold;
                    }
                    else if (processingToHold > fileNoTemp && processingFromHold < fileNoTemp && processingFromHold+1 < fileNoTemp){
                        processingFromSet = processingToHold;
                        processingToSet = fileNoTemp;
                    }
                    else{
                        
                        [reprocessFromDisplay setIntegerValue:0];
                        [reprocessToDisplay setIntegerValue:0];
                        [stepperFrom setIntValue:0];
                        [stepperTo setIntValue:0];
                        
                        processingFromHold = 0;
                        processingToHold = 0;
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    
                    if (processingFromSet != 0 && processingToSet != 0){
                        processingFromHold = processingFromSet;
                        processingToHold = processingToSet;
                        
                        [stepperFrom setIntValue:processingFromHold];
                        [stepperTo setIntValue:processingToHold];
                        [reprocessFromDisplay setIntegerValue:processingFromHold];
                        [reprocessToDisplay setIntegerValue:processingToHold];
                        
                        reprocessStatus = 1;
                        reprocessStartFlag = 1;
                        reprocessImageNo = processingFromHold-1;
                    }
                }
            }
            else if (reprocessStatus == 1){
                reprocessStatus = 0;
                [reprocessNoDisplay setStringValue:@"Wait"];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Correct Mode Not Selected."];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)fovPositionRead:(id)sender{
    if (processMode == 8 || processMode == 10){
        if (autoProcessingFlag == 0){
            if (statusIFHold == 0 || statusIFHold == 3){
                NSOpenPanel* openDlg = [NSOpenPanel openPanel];
                [openDlg setCanChooseFiles:NO];
                [openDlg setCanChooseDirectories:YES];
                
                if ([openDlg runModal] == NSModalResponseOK){
                    NSArray *files = [openDlg URLs];
                    NSString *fileName = [[files objectAtIndex:0] absoluteString];
                    
                    string directoryPathExtract = [fileName UTF8String];
                    
                    int findString1 = (int)directoryPathExtract.find("/Users/");
                    if (findString1 == -1) findString1 = (int)directoryPathExtract.find("/Volumes/");
                    
                    string directoryPath = directoryPathExtract.substr((unsigned long)findString1, directoryPathExtract.length()-(unsigned long)findString1-1);
                    string extractedID;
                    string extractedID2;
                    
                    int terminationFlag = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        if ((int)directoryPath.find("%20") != -1){
                            extractedID2 = directoryPath.substr(0, directoryPath.find("%20"));
                            directoryPath = directoryPath.substr(directoryPath.find("%20")+3);
                            directoryPath = extractedID2+" "+directoryPath;
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    extractedID = directoryPath;
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        if ((int)extractedID.find("/") != -1){
                            extractedID = extractedID.substr(extractedID.find("/")+1);
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    if (extractedID != "" && (int)extractedID.find("_Products") != -1 && (int)extractedID.find("_Products_") == -1){
                        string *arrayTreatmentNameDisplayTemp = new string [totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
                        int treatmentNameDisplayTempCount = 0;
                        
                        string *arrayFOVNameDisplayTemp = new string [totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
                        int fovNameDisplayTempCount = 0;
                        
                        string *arrayFOVPositionTemp = new string [treatmentNameDisplayCount*2+50];
                        int fovPositionTempCount = 0;
                        
                        string *arrayFOVPositionTempNew = new string [treatmentNameDisplayCount*3+50];
                        int fovPositionTempNewCount = 0;
                        
                        string treatmentPath = directoryPath+"/"+"Analysis_Information"+"/"+"FI-TreatmentNameData";
                        string fovPath = directoryPath+"/"+"Analysis_Information"+"/"+"FI-FOVData";
                        string fovPositionUploadPath = directoryPath+"/"+"Analysis_Information"+"/"+"CT-FOVPosition";
                        
                        string getString;
                        
                        ifstream fin;
                        fin.open(treatmentPath.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            do{
                                
                                getline(fin, getString);
                                
                                if (getString != "" && treatmentNameDisplayTempCount < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100) arrayTreatmentNameDisplayTemp [treatmentNameDisplayTempCount] = getString, treatmentNameDisplayTempCount++;
                                
                            } while (getString != "");
                            
                            fin.close();
                        }
                        
                        //for (int counterA = 0; counterA < treatmentNameDisplayTempCount; counterA++){
                        //    cout<<arrayTreatmentNameDisplayTemp [counterA]<<"  arrayTreatmentNameDisplayTemp "<<endl;
                        //}
                        
                        fin.open(fovPath.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            do{
                                
                                getline(fin, getString);
                                
                                if (getString != "" && fovNameDisplayTempCount < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100) arrayFOVNameDisplayTemp [fovNameDisplayTempCount] = getString, fovNameDisplayTempCount++;
                                
                            } while (getString != "");
                            
                            fin.close();
                        }
                        
                        int matchFind = 0;
                        int noMatchFind = 0;
                        int fovCountTemp = 0;
                        int fovCountTable = 0;
                        int maxFovEntry = 0;
                        int fovCountTablePosition = 0;
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayTempCount; counter1++){
                            if (arrayTreatmentNameDisplayTemp [counter1] != "ND" && (int)arrayTreatmentNameDisplayTemp [counter1].find("CH1") == -1 && (int)arrayTreatmentNameDisplayTemp [counter1].find("CH2") == -1 && (int)arrayTreatmentNameDisplayTemp [counter1].find("CH3") == -1 && (int)arrayTreatmentNameDisplayTemp [counter1].find("CH4") == -1 && (int)arrayTreatmentNameDisplayTemp [counter1].find("CH5") == -1 && (int)arrayTreatmentNameDisplayTemp [counter1].find("CH6") == -1){
                                matchFind = 0;
                                fovCountTablePosition = 0;
                                
                                for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                                    if (arrayTreatmentNameDisplay [counter2] == arrayTreatmentNameDisplayTemp [counter1]){
                                        matchFind = 1;
                                        fovCountTablePosition = counter2;
                                        break;
                                    }
                                }
                                
                                if (matchFind == 0) noMatchFind = 1;
                                else{
                                    
                                    fovCountTemp = 0;
                                    fovCountTable = 0;
                                    
                                    for (int counter2 = counter1; counter2 < fovNameDisplayTempCount; counter2++){
                                        if ((int)arrayFOVNameDisplayTemp [counter2].find("FOV") != -1){
                                            fovCountTemp++;
                                        }
                                        else{
                                            
                                            break;
                                        }
                                    }
                                    
                                    for (int counter2 = fovCountTablePosition; counter2 < fOVNameDisplayCount; counter2++){
                                        if ((int)arrayFOVNameDisplay [counter2].find("FOV") != -1){
                                            fovCountTable++;
                                        }
                                        else{
                                            
                                            break;
                                        }
                                    }
                                    
                                    if (fovCountTemp == 0 || fovCountTable == 0 || fovCountTemp != fovCountTable){
                                        noMatchFind = 1;
                                    }
                                    else if (maxFovEntry < fovCountTemp) maxFovEntry = fovCountTemp;
                                }
                            }
                        }
                        
                        if (noMatchFind == 0){
                            fin.open(fovPositionUploadPath.c_str(), ios::in);
                            
                            if (fin.is_open()){
                                do{
                                    
                                    getline(fin, getString);
                                    
                                    if (getString != "") arrayFOVPositionTemp [fovPositionTempCount] = getString, fovPositionTempCount++;
                                    
                                } while (getString != "");
                                
                                fin.close();
                            }
                            
                            //for (int counterA = 0; counterA < fovPositionTempCount; counterA++){
                            //    cout<<arrayFOVPositionTemp [counterA]<<"  arrayFOVPositionTemp "<<endl;
                            //}
                            
                            string *fovEntryDataHold = new string [maxFovEntry+50];
                            int fovEntryDataHoldCount = 0;
                            
                            int entryStart = 0;
                            
                            for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                                if (arrayTreatmentNameDisplay [counter1] != "ND" && (int)arrayTreatmentNameDisplay [counter1].find("CH1") == -1 && (int)arrayTreatmentNameDisplay [counter1].find("CH2") == -1 && (int)arrayTreatmentNameDisplay [counter1].find("CH3") == -1 && (int)arrayTreatmentNameDisplay [counter1].find("CH4") == -1 && (int)arrayTreatmentNameDisplay [counter1].find("CH5") == -1 && (int)arrayTreatmentNameDisplay [counter1].find("CH6") == -1){
                                    fovEntryDataHoldCount = 0;
                                    entryStart = 0;
                                    
                                    for (int counter2 = 0; counter2 < fovPositionTempCount; counter2++){
                                        if (arrayFOVPositionTemp [counter2] == arrayTreatmentNameDisplay [counter1] && entryStart == 0){
                                            entryStart = 1;
                                        }
                                        else if (arrayFOVPositionTemp [counter2] != "ND" && entryStart == 1){
                                            fovEntryDataHold [fovEntryDataHoldCount] = arrayFOVPositionTemp [counter2], fovEntryDataHoldCount++;
                                        }
                                        else if (arrayFOVPositionTemp [counter2] == "ND" && entryStart == 1){
                                            break;
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < fovEntryDataHoldCount; counterA++){
                                    //    cout<<fovEntryDataHold [counterA]<<"  fovEntryDataHold "<<endl;
                                    //}
                                    
                                    for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                                        if ((int)arrayTreatmentNameDisplay [counter2].find(arrayTreatmentNameDisplay [counter1]) != -1){
                                            arrayFOVPositionTempNew [fovPositionTempNewCount] = arrayTreatmentNameDisplay [counter2], fovPositionTempNewCount++;
                                            
                                            for (int counter3 = 0; counter3 < fovEntryDataHoldCount; counter3++){
                                                arrayFOVPositionTempNew [fovPositionTempNewCount] = fovEntryDataHold [counter3], fovPositionTempNewCount++;
                                            }
                                            
                                            arrayFOVPositionTempNew [fovPositionTempNewCount] = "ND", fovPositionTempNewCount++;
                                        }
                                    }
                                }
                            }
                            
                            ofstream oin;
                            
                            oin.open(fovPositionPath.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < fovPositionTempNewCount; counter1++) oin<< arrayFOVPositionTempNew [counter1]<<endl;
                            
                            oin.close();
                            
                            delete [] fovEntryDataHold;
                            
                            tableViewCall = 1;
                            
                            int processType = 3;
                            imageDataSet = [[ImageDataSet alloc] init];
                            [imageDataSet imageDataSetProcess:processType];
                            
                            if (photoMetricHold == 2){
                                if (rgbDisplayStatus == 0){
                                    rgbDisplayStatus = 1;
                                    [rgbStatusDisplay setStringValue:@"Red"];
                                    [rgbStatusHistDisplay setStringValue:@"Red"];
                                }
                            }
                            else{
                                
                                rgbDisplayStatus = 0;
                                [rgbStatusDisplay setStringValue:@"Gray"];
                                [rgbStatusHistDisplay setStringValue:@"Gray"];
                            }
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Data Format Mismatch"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                        
                        //for (int counterA = 0; counterA < fovNameDisplayTempCount; counterA++){
                        //    cout<<arrayFOVNameDisplayTemp [counterA]<<"  arrayFOVNameDisplayTemp "<<endl;
                        //}
                        
                        delete [] arrayTreatmentNameDisplayTemp;
                        delete [] arrayFOVNameDisplayTemp;
                        delete [] arrayFOVPositionTemp;
                        delete [] arrayFOVPositionTempNew;
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Products Folder Missing"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"IF mode On: Copy Not Allowed"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Check Current Mode"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)selectDisplayRed:(id)sender{
    if (photoMetricHold == 2){
        rgbDisplayStatus = 1;
        [rgbStatusDisplay setStringValue:@"Red"];
        [rgbStatusHistDisplay setStringValue:@"Red"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        tableViewCall = 1;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Color Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)selectDisplayGreen:(id)sender{
    if (photoMetricHold == 2){
        rgbDisplayStatus = 2;
        [rgbStatusDisplay setStringValue:@"Green"];
        [rgbStatusHistDisplay setStringValue:@"Green"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        tableViewCall = 1;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Color Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)selectDisplayBlue:(id)sender{
    if (photoMetricHold == 2){
        rgbDisplayStatus = 3;
        [rgbStatusDisplay setStringValue:@"Blue"];
        [rgbStatusHistDisplay setStringValue:@"Blue"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        tableViewCall = 1;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Color Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)fluorescentImageDisplayMode:(id)sender{
    if (fluorescentDisplayModeHold == 1){
        fluorescentDisplayModeHold = 0;
        [fluorescentModeDisplay setStringValue:@"Color"];
    }
    else{
        
        fluorescentDisplayModeHold = 1;
        [fluorescentModeDisplay setStringValue:@"B&W"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMainImage object:self];
}

-(IBAction)orientationXFWYFWNSW:(id)sender{
    if (processMode == 2 || processMode == 8 || processMode == 10){
        if (firstDataSetFlag == 0){
            orientationSetFlag = 1;
            xOrientation = 0;
            yOrientation = 0;
            xyInvert = 0;
            
            imageDataSet = [[ImageDataSet alloc] init];
            int processType = 1;
            [imageDataSet imageDataSetProcess:processType];
            
            subprocesses = [[SubProcesses alloc] init];
            [subprocesses variableSave];
            
            [xOrientationDisplay setStringValue:@"FW"];
            [yOrientationDisplay setStringValue:@"FW"];
            [xySwitchDisplay setStringValue:@"Off"];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Complete 'Set Condition' First. If Done, Quit, Change Orientation, And Return To 'Focal Image Selection' If Contrast Images Exist"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Allowed In Init Mode"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)orientationXFWYRVNSW:(id)sender{
    if (processMode == 2 || processMode == 8 || processMode == 10){
        if (firstDataSetFlag == 0){
            orientationSetFlag = 1;
            xOrientation = 0;
            yOrientation = 1;
            xyInvert = 0;
            
            imageDataSet = [[ImageDataSet alloc] init];
            int processType = 1;
            [imageDataSet imageDataSetProcess:processType];
            
            subprocesses = [[SubProcesses alloc] init];
            [subprocesses variableSave];
            
            [xOrientationDisplay setStringValue:@"FW"];
            [yOrientationDisplay setStringValue:@"RV"];
            [xySwitchDisplay setStringValue:@"Off"];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Complete 'Set Condition' First. If Done, Quit, Change Orientation, And Return To 'Focal Image Selection' If Contrast Images Exist"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Allowed In Init Mode"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)orientationXRVYFWNSW:(id)sender{
    if (processMode == 2 || processMode == 8 || processMode == 10){
        if (firstDataSetFlag == 0){
            orientationSetFlag = 1;
            xOrientation = 1;
            yOrientation = 0;
            xyInvert = 0;
            
            imageDataSet = [[ImageDataSet alloc] init];
            int processType = 1;
            [imageDataSet imageDataSetProcess:processType];
            
            subprocesses = [[SubProcesses alloc] init];
            [subprocesses variableSave];
            
            [xOrientationDisplay setStringValue:@"RV"];
            [yOrientationDisplay setStringValue:@"FW"];
            [xySwitchDisplay setStringValue:@"Off"];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Complete 'Set Condition' First. If Done, Quit, Change Orientation, And Return To 'Focal Image Selection' If Contrast Images Exist"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Allowed In Init Mode"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)orientationXRVYRVNSW:(id)sender{
    if (processMode == 2 || processMode == 8 || processMode == 10){
        if (firstDataSetFlag == 0){
            orientationSetFlag = 1;
            xOrientation = 1;
            yOrientation = 1;
            xyInvert = 0;
            
            imageDataSet = [[ImageDataSet alloc] init];
            int processType = 1;
            [imageDataSet imageDataSetProcess:processType];
            
            subprocesses = [[SubProcesses alloc] init];
            [subprocesses variableSave];
            
            [xOrientationDisplay setStringValue:@"RV"];
            [yOrientationDisplay setStringValue:@"RV"];
            [xySwitchDisplay setStringValue:@"Off"];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Complete 'Set Condition' First. If Done, Quit, Change Orientation, And Return To 'Focal Image Selection' If Contrast Images Exist"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Allowed In Init Mode"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)orientationXFWYFWSW:(id)sender{
    if (processMode == 2 || processMode == 8 || processMode == 10){
        if (firstDataSetFlag == 0){
            orientationSetFlag = 1;
            xOrientation = 0;
            yOrientation = 0;
            xyInvert = 1;
            
            imageDataSet = [[ImageDataSet alloc] init];
            int processType = 1;
            [imageDataSet imageDataSetProcess:processType];
            
            subprocesses = [[SubProcesses alloc] init];
            [subprocesses variableSave];
            
            [xOrientationDisplay setStringValue:@"FW"];
            [yOrientationDisplay setStringValue:@"FW"];
            [xySwitchDisplay setStringValue:@"On"];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Complete 'Set Condition' First. If Done, Quit, Change Orientation, And Return To 'Focal Image Selection' If Contrast Images Exist"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Allowed In Init Mode"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)orientationXFWYRVSW:(id)sender{
    if (processMode == 2 || processMode == 8 || processMode == 10){
        if (firstDataSetFlag == 0){
            orientationSetFlag = 1;
            xOrientation = 0;
            yOrientation = 1;
            xyInvert = 1;
            
            imageDataSet = [[ImageDataSet alloc] init];
            int processType = 1;
            [imageDataSet imageDataSetProcess:processType];
            
            subprocesses = [[SubProcesses alloc] init];
            [subprocesses variableSave];
            
            [xOrientationDisplay setStringValue:@"FW"];
            [yOrientationDisplay setStringValue:@"RV"];
            [xySwitchDisplay setStringValue:@"On"];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Complete 'Set Condition' First. If Done, Quit, Change Orientation, And Return To 'Focal Image Selection' If Contrast Images Exist"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Allowed In Init Mode"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)orientationXRVYFWSW:(id)sender{
    if (processMode == 2 || processMode == 8 || processMode == 10){
        if (firstDataSetFlag == 0){
            orientationSetFlag = 1;
            xOrientation = 1;
            yOrientation = 0;
            xyInvert = 1;
            
            imageDataSet = [[ImageDataSet alloc] init];
            int processType = 1;
            [imageDataSet imageDataSetProcess:processType];
            
            subprocesses = [[SubProcesses alloc] init];
            [subprocesses variableSave];
            
            [xOrientationDisplay setStringValue:@"RV"];
            [yOrientationDisplay setStringValue:@"FW"];
            [xySwitchDisplay setStringValue:@"On"];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Complete 'Set Condition' First. If Done, Quit, Change Orientation, And Return To 'Focal Image Selection' If Contrast Images Exist"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Allowed In Init Mode"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)orientationXRVYRVSW:(id)sender{
    if (processMode == 2 || processMode == 8 || processMode == 10){
        if (firstDataSetFlag == 0){
            orientationSetFlag = 1;
            xOrientation = 1;
            yOrientation = 1;
            xyInvert = 1;
            
            imageDataSet = [[ImageDataSet alloc] init];
            int processType = 1;
            [imageDataSet imageDataSetProcess:processType];
            
            subprocesses = [[SubProcesses alloc] init];
            [subprocesses variableSave];
            
            [xOrientationDisplay setStringValue:@"RV"];
            [yOrientationDisplay setStringValue:@"RV"];
            [xySwitchDisplay setStringValue:@"On"];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Complete 'Set Condition' First. If Done, Quit, Change Orientation, And Return To 'Focal Image Selection' If Contrast Images Exist"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Allowed In Init Mode"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    if (controllerTimer) [controllerTimer invalidate];
}

@end
