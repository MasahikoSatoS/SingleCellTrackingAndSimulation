/*
 *  Autocontrast.h
 *  Contrast_Set
 *
 *  Created by Masahiko Sato on 01/01/10.
 *  Copyright Masahiko Sato 2010 All rights reserved.
 *
 */

#ifndef AUTOCONTRAST_H
#define AUTOCONTRAST_H
#import "Controller.h"
#endif

@interface Autocontrast : NSObject {
    id backgroundCorrection;
    id balanceSet;
    id singleTiffSave;
    id tiffFileRead;
}

-(id)init;
-(void)dealloc;
-(void)fileDeleteUpDate;

@end
