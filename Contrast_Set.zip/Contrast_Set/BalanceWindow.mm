//
//  BalanceWindow.m
//  Contrast_Set
//
//  Created by Masahiko Sato on 6/8/16.
//
//

#import "BalanceWindow.h"

NSString *notificationToBalanceWindow = @"notificationToExecuteBalanceWindow";

@implementation BalanceWindow

- (id)initWithFrame:(NSRect)frame{
    self = [super initWithFrame:frame];
    
    if (self) {
        balanceImage = [[NSImage alloc] initWithContentsOfFile:@""];
        
        mouseDragFlag = 0;
        mouseDownFlag = 0;
        imageFirstLoadFlagDisplayBL = 0;
        magnificationDisplayBL = 10;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToBalanceWindow object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    if (balanceImageLoadFlag == 1){
        int imageSetSize = 0;
        int counterIncrement = 0;
        
        if (stitchImageDimension <= 1000){
            imageSetSize = stitchImageDimension;
            counterIncrement = 1;
        }
        else if (stitchImageDimension <= 4000){
            imageSetSize = stitchImageDimension/2;
            counterIncrement = 2;
        }
        else{
            
            imageSetSize = stitchImageDimension/4;
            counterIncrement = 4;
        }
        
        NSBitmapImageRep *bitmapReps;
        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize pixelsHigh:imageSetSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageSetSize bitsPerPixel:8];
        unsigned char *bitmapData = [bitmapReps bitmapData];
        
        for (int counter1 = 0; counter1 < stitchImageDimension; counter1 = counter1+counterIncrement){
            for (int counter2 = 0; counter2 < stitchImageDimension; counter2 = counter2+counterIncrement){
                *bitmapData++ = (unsigned char)arrayBalanceDataHold [counter1][counter2];
            }
        }
        
        balanceImage = [[NSImage alloc] initWithSize:NSMakeSize(stitchImageDimension, stitchImageDimension)];
        [balanceImage addRepresentation:bitmapReps];
        
        if (imageFirstLoadFlagDisplayBL == 0){
            xPositionDisplayBL = 0;
            yPositionDisplayBL = 0;
            xPositionAdjustDisplayBL = 0;
            yPositionAdjustDisplayBL = 0;
            magnificationDisplayBL = 10;
            imageFirstLoadFlagDisplayBL = 1;
        }
        
        //-----Re-adjust window size and position-----
        int vertical = 450+78;
        int horizontal = 450;
        
        windowWidthDisplayBL = stitchImageDimension/(double)horizontal;
        windowHeightDisplayBL = stitchImageDimension/(double)(vertical-78);
        
        xPositionAdjustDisplayBL = (stitchImageDimension-stitchImageDimension/(double)(magnificationDisplayBL*0.1))/(double)2;
        yPositionAdjustDisplayBL = (stitchImageDimension-stitchImageDimension/(double)(magnificationDisplayBL*0.1))/(double)2;
        
        [self setNeedsDisplay:YES];
    }
}

-(void)mouseDown:(NSEvent *)event{
    if (imageFindFlag == 0){
        NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDownDisplayBL = clickPoint.x;
        yPointDownDisplayBL = clickPoint.y;
        
        [self setNeedsDisplay:YES];
    }
}

-(void)mouseUp:(NSEvent *)event{
    if (imageFindFlag == 0){
        xPositionDisplayBL = xPositionDisplayBL+xPositionMoveDisplayBL;
        yPositionDisplayBL = yPositionDisplayBL+yPositionMoveDisplayBL;
        
        xPositionMoveDisplayBL = 0;
        yPositionMoveDisplayBL = 0;
        mouseDragFlag = 0;
        mouseDownFlag = 0;
        
        [self setNeedsDisplay:YES];
    }
}

-(void)mouseDragged:(NSEvent *)event{
    if (imageFindFlag == 0){
        NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDragDisplayBL = clickPoint.x;
        yPointDragDisplayBL = clickPoint.y;
        
        xPositionMoveDisplayBL = (xPointDownDisplayBL-xPointDragDisplayBL)*windowWidthDisplayBL/(double)(magnificationDisplayBL*0.1);
        yPositionMoveDisplayBL = (yPointDownDisplayBL-yPointDragDisplayBL)*windowHeightDisplayBL/(double)(magnificationDisplayBL*0.1);
        
        mouseDragFlag = 1;
        
        [self setNeedsDisplay:YES];
    }
}

-(void)keyDown:(NSEvent *)event{
    int keyCode = [event keyCode];
    
    if (imageFindFlag == 0){
        //-----Magnification Magnify-----
        if (keyCode == 125){
            if (magnificationDisplayBL >= 10 && magnificationDisplayBL <= 490){
                if (magnificationDisplayBL-10 < 10) magnificationDisplayBL = 10;
                else magnificationDisplayBL = magnificationDisplayBL-10;
                
                xPositionAdjustDisplayBL = -1*(stitchImageDimension/(double)(magnificationDisplayBL*0.1)-stitchImageDimension)/(double)2;
                yPositionAdjustDisplayBL = -1*(stitchImageDimension/(double)(magnificationDisplayBL*0.1)-stitchImageDimension)/(double)2;
            }
            else if (magnificationDisplayBL < 10) magnificationDisplayBL = 10;
        }
        
        //-----Magnification Reduction-----
        if (keyCode == 126){
            if (magnificationDisplayBL >= 10 && magnificationDisplayBL <= 490){
                if (magnificationDisplayBL+10 > 490) magnificationDisplayBL = 490;
                else magnificationDisplayBL = magnificationDisplayBL+10;
                
                xPositionAdjustDisplayBL = (stitchImageDimension-stitchImageDimension/(double)(magnificationDisplayBL*0.1))/(double)2;
                yPositionAdjustDisplayBL = (stitchImageDimension-stitchImageDimension/(double)(magnificationDisplayBL*0.1))/(double)2;
            }
            else if (magnificationDisplayBL > 490) magnificationDisplayBL = 490;
        }
        
        //-----Original Position-----
        if (keyCode == 6){
            xPositionDisplayBL = 0;
            yPositionDisplayBL = 0;
            xPositionAdjustDisplayBL = 0;
            yPositionAdjustDisplayBL = 0;
            magnificationDisplayBL = 10;
            
            xPositionAdjustDisplayBL = (imageDimensionX-imageDimensionX/(double)(magnificationDisplayBL*0.1))/(double)2;
            yPositionAdjustDisplayBL = (imageDimensionY-imageDimensionY/(double)(magnificationDisplayBL*0.1))/(double)2;
        }
        
        [self setNeedsDisplay:YES];
    }
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)drawRect:(NSRect)rect{
    NSRect srcRect;
    srcRect.origin.x = xPositionDisplayBL+xPositionAdjustDisplayBL+xPositionMoveDisplayBL;
    srcRect.origin.y = yPositionDisplayBL+yPositionAdjustDisplayBL+yPositionMoveDisplayBL;
    srcRect.size.width = stitchImageDimension/(double)(magnificationDisplayBL*0.1);
    srcRect.size.height = stitchImageDimension/(double)(magnificationDisplayBL*0.1);
    
    [balanceImage drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToBalanceWindow object:nil];
}

@end
