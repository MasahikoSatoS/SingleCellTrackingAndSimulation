//
//  ObjectMatch.m
//  Contrast_Set
//
//  Created by Masahiko Sato on 2014-04-08.
//
//

#import "ObjectMatch.h"

@implementation ObjectMatch

-(void)overlapCheck{
    horizontalLinkCount = 0;
    verticalLinkCount = 0;
    
    int downFind = 0;
    int upFind = 0;
    int rightFind = 0;
    int leftFind = 0;
    int findFlag = 0;
    int terminationFlag = 0;
    
    string extractString;
    string extractString2;
    string stringTemp;
    string extension;
    string extension2;
    
    for (int counter1 = 1; counter1 < loadImageFOVNo; counter1++){
        downFind = 0;
        upFind = 0;
        rightFind = 0;
        leftFind = 0;
        
        for (int counter2 = counter1+1; counter2 <= loadImageFOVNo; counter2++){
            //-----Top/Left-----
            if (arrayXYWritingPosition [counter1*2]+imageDimensionX/2 < arrayXYWritingPosition [counter2*2] && arrayXYWritingPosition [counter1*2]+imageDimensionX >= arrayXYWritingPosition [counter2*2] && arrayXYWritingPosition [counter1*2+1] <= arrayXYWritingPosition [counter2*2+1] && arrayXYWritingPosition [counter1*2+1]+imageDimensionY/2 > arrayXYWritingPosition [counter2*2+1]){
                if (rightFind == 0) rightFind = counter2;
            }
            
            if (arrayXYWritingPosition [counter1*2] <= arrayXYWritingPosition [counter2*2] && arrayXYWritingPosition [counter1*2]+imageDimensionX/2 > arrayXYWritingPosition [counter2*2] && arrayXYWritingPosition [counter1*2+1]+imageDimensionY/2 < arrayXYWritingPosition [counter2*2+1] && arrayXYWritingPosition [counter1*2+1]+imageDimensionY >= arrayXYWritingPosition [counter2*2+1]){
                if (downFind == 0) downFind = counter2;
            }
            
            //-----Top/Right-----
            if (arrayXYWritingPosition [counter1*2] <= arrayXYWritingPosition [counter2*2]+imageDimensionX && arrayXYWritingPosition [counter1*2]+imageDimensionX/2 > arrayXYWritingPosition [counter2*2]+imageDimensionX && arrayXYWritingPosition [counter1*2+1] <= arrayXYWritingPosition [counter2*2+1] && arrayXYWritingPosition [counter1*2+1]+imageDimensionY/2 > arrayXYWritingPosition [counter2*2+1]){
                if (leftFind == 0) leftFind = counter2;
            }
            
            if (arrayXYWritingPosition [counter1*2]+imageDimensionX/2 < arrayXYWritingPosition [counter2*2]+imageDimensionX && arrayXYWritingPosition [counter1*2]+imageDimensionX >= arrayXYWritingPosition [counter2*2]+imageDimensionX && arrayXYWritingPosition [counter1*2+1]+imageDimensionY/2 < arrayXYWritingPosition [counter2*2+1] && arrayXYWritingPosition [counter1*2+1]+imageDimensionY >= arrayXYWritingPosition [counter2*2+1]){
                if (downFind == 0) downFind = counter2;
            }
            
            //-----Down/Left-----
            if (arrayXYWritingPosition [counter1*2] <= arrayXYWritingPosition [counter2*2] && arrayXYWritingPosition [counter1*2]+imageDimensionX/2 > arrayXYWritingPosition [counter2*2] && arrayXYWritingPosition [counter1*2+1] <= arrayXYWritingPosition [counter2*2+1]+imageDimensionY && arrayXYWritingPosition [counter1*2+1]+imageDimensionY/2 > arrayXYWritingPosition [counter2*2+1]+imageDimensionY){
                if (upFind == 0) upFind = counter2;
            }
            
            if (arrayXYWritingPosition [counter1*2]+imageDimensionX/2 < arrayXYWritingPosition [counter2*2] && arrayXYWritingPosition [counter1*2]+imageDimensionX >= arrayXYWritingPosition [counter2*2] && arrayXYWritingPosition [counter1*2+1]+imageDimensionY/2 < arrayXYWritingPosition [counter2*2+1]+imageDimensionY && arrayXYWritingPosition [counter1*2+1]+imageDimensionY >= arrayXYWritingPosition [counter2*2+1]+imageDimensionY){
                if (rightFind == 0) rightFind = counter2;
            }
            
            //-----Down/Right-----
            if (arrayXYWritingPosition [counter1*2]+imageDimensionX/2 < arrayXYWritingPosition [counter2*2]+imageDimensionX && arrayXYWritingPosition [counter1*2]+imageDimensionX >= arrayXYWritingPosition [counter2*2]+imageDimensionX && arrayXYWritingPosition [counter1*2+1] <= arrayXYWritingPosition [counter2*2+1]+imageDimensionY && arrayXYWritingPosition [counter1*2+1]+imageDimensionY/2 > arrayXYWritingPosition [counter2*2+1]+imageDimensionY){
                if (upFind == 0) upFind = counter2;
            }
            
            if (arrayXYWritingPosition [counter1*2] <= arrayXYWritingPosition [counter2*2]+imageDimensionX && arrayXYWritingPosition [counter1*2]+imageDimensionX/2 > arrayXYWritingPosition [counter2*2]+imageDimensionX && arrayXYWritingPosition [counter1*2+1]+imageDimensionY/2 < arrayXYWritingPosition [counter2*2+1]+imageDimensionY && arrayXYWritingPosition [counter1*2+1]+imageDimensionY >= arrayXYWritingPosition [counter2*2+1]+imageDimensionY){
                if (leftFind == 0) leftFind = counter2;
            }
        }
        
        extension = to_string(counter1);
        
        if (rightFind != 0){
            extension2 = to_string(rightFind);
            
            if (horizontalLinkCount != 0){
                findFlag = 0;
                
                for (int counter2 = 0; counter2 < horizontalLinkCount; counter2++){
                    stringTemp = arrayHorizontalLink [counter2];
                    
                    do{
                        
                        terminationFlag = 0;
                        
                        if ((int)stringTemp.find ("/") == -1){
                            extractString2 = stringTemp;
                            terminationFlag = 1;
                        }
                        else stringTemp = stringTemp.substr(stringTemp.find ("/")+1);
                        
                    } while (terminationFlag == 0);
                    
                    if (extension == extractString2){
                        arrayHorizontalLink [counter2] = arrayHorizontalLink [counter2]+"/"+extension2;
                        findFlag = 1;
                        break;
                    }
                }
                
                if (findFlag == 0) arrayHorizontalLink [horizontalLinkCount] = extension+"/"+extension2, horizontalLinkCount++;
            }
            else arrayHorizontalLink [0] = extension+"/"+extension2, horizontalLinkCount++;
        }
        
        if (leftFind != 0){
            extension2 = to_string(leftFind);
            
            if (horizontalLinkCount != 0){
                findFlag = 0;
                
                for (int counter2 = 0; counter2 < horizontalLinkCount; counter2++){
                    stringTemp = arrayHorizontalLink [counter2];
                    extractString = stringTemp.substr(0, stringTemp.find ("/"));
                    
                    if (extension == extractString){
                        arrayHorizontalLink [counter2] = extension2+"/"+arrayHorizontalLink [counter2];
                        findFlag = 1;
                    }
                }
                
                if (findFlag == 0) arrayHorizontalLink [horizontalLinkCount] = extension2+"/"+extension, horizontalLinkCount++;
            }
            else arrayHorizontalLink [0] = extension2+"/"+extension, horizontalLinkCount++;
        }
        
        if (upFind != 0){
            extension2 = to_string(upFind);
            
            if (verticalLinkCount != 0){
                findFlag = 0;
                
                for (int counter2 = 0; counter2 < verticalLinkCount; counter2++){
                    stringTemp = arrayVerticalLink [counter2];
                    extractString = stringTemp.substr(0, stringTemp.find ("/"));
                    
                    if (extension == extractString){
                        arrayVerticalLink [counter2] = extension2+"/"+arrayVerticalLink [counter2];
                        findFlag = 1;
                    }
                }
                
                if (findFlag == 0) arrayVerticalLink [verticalLinkCount] = extension2+"/"+extension, verticalLinkCount++;
            }
            else arrayVerticalLink [0] = extension2+"/"+extension, verticalLinkCount++;
        }
        
        if (downFind != 0){
            extension2 = to_string(downFind);
            
            if (verticalLinkCount != 0){
                findFlag = 0;
                
                for (int counter2 = 0; counter2 < verticalLinkCount; counter2++){
                    stringTemp = arrayVerticalLink [counter2];
                    
                    do{
                        
                        terminationFlag = 0;
                        
                        if ((int)stringTemp.find ("/") == -1){
                            extractString2 = stringTemp;
                            terminationFlag = 1;
                        }
                        else stringTemp = stringTemp.substr(stringTemp.find ("/")+1);
                        
                    } while (terminationFlag == 0);
                    
                    if (extension == extractString2){
                        arrayVerticalLink [counter2] = arrayVerticalLink [counter2]+"/"+extension2;
                        findFlag = 1;
                    }
                }
                
                if (findFlag == 0) arrayVerticalLink [verticalLinkCount] = extension+"/"+extension2, verticalLinkCount++;
            }
            else arrayVerticalLink [0] = extension+"/"+extension2, verticalLinkCount++;
        }
    }
}

-(void)objectMatchMain:(int)orientationType{
    if (orientationType == 1 || orientationType == 3){
        int xDistance = 0;
        int yDistance = 0;
        int findNumber = 0;
        int findCount = 0;
        int find1 = 0;
        int find2 = 0;
        int terminationFlag = 0;
        
        string stringTemp;
        string extractString1;
        
        if (fovFirstClick != 0 || fovSecondClick != 0){
            if (orientationType == 1){
                for (int counter1 = 0; counter1 < horizontalLinkCount; counter1++){
                    findNumber = 0;
                    findCount = 0;
                    find1 = 0;
                    find2 = 0;
                    
                    stringTemp = arrayHorizontalLink [counter1];
                    
                    do{
                        
                        terminationFlag = 0;
                        
                        if ((int)stringTemp.find ("/") == -1){
                            findCount++;
                            terminationFlag = 1;
                            
                            if (atoi(stringTemp.c_str()) == fovFirstClick || atoi(stringTemp.c_str()) == fovSecondClick){
                                findNumber++;
                                
                                if (atoi(stringTemp.c_str()) == fovFirstClick && find1 == 0) find1 = findCount;
                                if (atoi(stringTemp.c_str()) == fovSecondClick && find2 == 0) find2 = findCount;
                            }
                        }
                        else{
                            
                            extractString1 = stringTemp.substr(0, stringTemp.find ("/"));
                            findCount++;
                            
                            if (atoi(extractString1.c_str()) == fovFirstClick || atoi(extractString1.c_str()) == fovSecondClick){
                                findNumber++;
                                
                                if (atoi(extractString1.c_str()) == fovFirstClick && find1 == 0) find1 = findCount;
                                if (atoi(extractString1.c_str()) == fovSecondClick && find2 == 0) find2 = findCount;
                            }
                            
                            stringTemp = stringTemp.substr(stringTemp.find ("/")+1);
                        }
                        
                    } while (terminationFlag == 0);
                    
                    if (findNumber == 2 && abs(find1-find2) == 1 && find1 != 0 && find2 != 0){
                        if (find1 > find2){
                            xDistance = arrayXYWritingPosition [fovFirstClick*2]-arrayXYWritingPosition [fovSecondClick*2];
                            yDistance = arrayXYWritingPosition [fovFirstClick*2+1]-arrayXYWritingPosition [fovSecondClick*2+1];
                        }
                        if (find1 < find2){
                            xDistance = arrayXYWritingPosition [fovSecondClick*2]-arrayXYWritingPosition [fovFirstClick*2];
                            yDistance = arrayXYWritingPosition [fovSecondClick*2+1]-arrayXYWritingPosition [fovFirstClick*2+1];
                        }
                        
                        break;
                    }
                }
                
                fovFirstClickOR1 = xDistance;
                fovSecondClickOR1 = yDistance;
                
                if (fovFirstSetFlag == 0) fovFirstSetFlag = 1;
            }
            else{
                
                xDistance = fovFirstClickOR1;
                yDistance = fovSecondClickOR1;
            }
            
            if (xDistance != 0 || yDistance != 0){
                int xDistanceOthers = 0;
                int yDistanceOthers = 0;
                int firstFovNo = 0;
                int xBefore1 = 0;
                int yBefore1 = 0;
                int secondFovNo = 0;
                int xAfter1 = 0;
                int yAfter1 = 0;
                
                for (int counter1 = 0; counter1 < horizontalLinkCount; counter1++){
                    stringTemp = arrayHorizontalLink [counter1];
                    findCount = 0;
                    
                    int *fovDataTemp = new int [stringTemp.length()];
                    
                    do{
                        
                        terminationFlag = 0;
                        
                        if ((int)stringTemp.find ("/") == -1){
                            terminationFlag = 1;
                            fovDataTemp [findCount] = atoi(stringTemp.c_str()), findCount++;
                        }
                        else{
                            
                            extractString1 = stringTemp.substr(0, stringTemp.find ("/"));
                            fovDataTemp [findCount] = atoi(extractString1.c_str()), findCount++;
                            stringTemp = stringTemp.substr(stringTemp.find ("/")+1);
                        }
                        
                    } while (terminationFlag == 0);
                    
                    for (int counter2 = 0; counter2 < findCount-1; counter2++){
                        firstFovNo = fovDataTemp [counter2];
                        
                        if (counter2 == 0 && positionSetStatus == 0){
                            xBefore1 = xyPositionDataHold [firstFovNo*2];
                            yBefore1 = xyPositionDataHold [firstFovNo*2+1];
                            arrayXYWritingPosition [firstFovNo*2] = xBefore1;
                            arrayXYWritingPosition [firstFovNo*2+1] = yBefore1;
                        }
                        else{
                            
                            xBefore1 = arrayXYWritingPosition [firstFovNo*2];
                            yBefore1 = arrayXYWritingPosition [firstFovNo*2+1];
                        }
                        
                        for (int counter3 = counter2+1; counter3 < findCount; counter3++){
                            secondFovNo = fovDataTemp [counter3];
                            
                            if (counter2 == 0 && counter3 == counter2+1 && positionSetStatus == 0){
                                xAfter1 = xyPositionDataHold [secondFovNo*2];
                                yAfter1 = xyPositionDataHold [secondFovNo*2+1];
                                arrayXYWritingPosition [secondFovNo*2] = xBefore1+xDistance;
                                arrayXYWritingPosition [secondFovNo*2+1] = yBefore1+yDistance;
                                
                                xDistanceOthers = xAfter1-xBefore1;
                                yDistanceOthers = yAfter1-yBefore1;
                                xBefore1 = arrayXYWritingPosition [secondFovNo*2];
                                yBefore1 = arrayXYWritingPosition [secondFovNo*2+1];
                            }
                            
                            if (counter2 == 0 && counter3 > counter2+1){
                                arrayXYWritingPosition [secondFovNo*2] = xBefore1+xDistanceOthers;
                                arrayXYWritingPosition [secondFovNo*2+1] = yBefore1+yDistanceOthers;
                                xBefore1 = arrayXYWritingPosition [secondFovNo*2];
                                yBefore1 = arrayXYWritingPosition [secondFovNo*2+1];
                            }
                            
                            if ((counter2 != 0 && counter3 == counter2+1) || (counter2 == 0 && counter3 == counter2+1 && positionSetStatus == 2)){
                                arrayXYWritingPosition [secondFovNo*2] = xBefore1+xDistance;
                                arrayXYWritingPosition [secondFovNo*2+1] = yBefore1+yDistance;
                                xBefore1 = arrayXYWritingPosition [secondFovNo*2];
                                yBefore1 = arrayXYWritingPosition [secondFovNo*2+1];
                            }
                            
                            if (counter2 == 0 && counter3 > counter2+1){
                                arrayXYWritingPosition [secondFovNo*2] = xBefore1+xDistanceOthers;
                                arrayXYWritingPosition [secondFovNo*2+1] = xBefore1+yDistanceOthers;
                            }
                        }
                    }
                    
                    delete [] fovDataTemp;
                }
                
                if (positionSetStatus == 0) positionSetStatus = 1;
                else if (positionSetStatus == 2) positionSetStatus = 0;
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    
    if (orientationType == 2 || orientationType == 4){
        int xDistance = 0;
        int yDistance = 0;
        int terminationFlag = 0;
        
        if (fovFirstClick != 0 || fovSecondClick != 0){
            if (orientationType == 2){
                int findNumber = 0;
                int findCount = 0;
                int find1 = 0;
                int find2 = 0;
                
                string stringTemp;
                string extractString1;
                
                for (int counter1 = 0; counter1 < verticalLinkCount; counter1++){
                    findNumber = 0;
                    findCount = 0;
                    find1 = 0;
                    find2 = 0;
                    stringTemp = arrayVerticalLink [counter1];
                    
                    do{
                        
                        terminationFlag = 0;
                        
                        if ((int)stringTemp.find ("/") == -1){
                            findCount++;
                            terminationFlag = 1;
                            
                            if (atoi(stringTemp.c_str()) == fovFirstClick || atoi(stringTemp.c_str()) == fovSecondClick){
                                findNumber++;
                                
                                if (atoi(stringTemp.c_str()) == fovFirstClick && find1 == 0) find1 = findCount;
                                if (atoi(stringTemp.c_str()) == fovSecondClick && find2 == 0) find2 = findCount;
                            }
                        }
                        else{
                            
                            extractString1 = stringTemp.substr(0, stringTemp.find ("/")), findCount++;
                            
                            if (atoi(extractString1.c_str()) == fovFirstClick || atoi(extractString1.c_str()) == fovSecondClick){
                                findNumber++;
                                
                                if (atoi(extractString1.c_str()) == fovFirstClick && find1 == 0) find1 = findCount;
                                if (atoi(extractString1.c_str()) == fovSecondClick && find2 == 0) find2 = findCount;
                            }
                            
                            stringTemp = stringTemp.substr(stringTemp.find ("/")+1);
                        }
                        
                    } while (terminationFlag == 0);
                    
                    if (findNumber == 2 && abs(find1-find2) == 1 && find1 != 0 && find2 != 0){
                        if (find1 > find2){
                            xDistance = arrayXYWritingPosition [fovFirstClick*2]-arrayXYWritingPosition [fovSecondClick*2];
                            yDistance = arrayXYWritingPosition [fovFirstClick*2+1]-arrayXYWritingPosition [fovSecondClick*2+1];
                        }
                        if (find1 <= find2){
                            xDistance = arrayXYWritingPosition [fovSecondClick*2]-arrayXYWritingPosition [fovFirstClick*2];
                            yDistance = arrayXYWritingPosition [fovSecondClick*2+1]-arrayXYWritingPosition [fovFirstClick*2+1];
                        }
                        
                        break;
                    }
                }
                
                fovFirstClickOR2 = xDistance;
                fovSecondClickOR2 = yDistance;
                
                if (fovFirstSetFlag == 0) fovFirstSetFlag = 1;
            }
            else{
                
                xDistance = fovFirstClickOR2;
                yDistance = fovSecondClickOR2;
            }
            
            if (xDistance != 0 || yDistance != 0){
                int xDistanceOthers = 0;
                int yDistanceOthers = 0;
                int findCount = 0;
                int firstFovNo = 0;
                int xBefore1 = 0;
                int yBefore1 = 0;
                int secondFovNo = 0;
                int xAfter1 = 0;
                int yAfter1 = 0;
                
                string stringTemp;
                string extractString1;
                
                for (int counter1 = 0; counter1 < verticalLinkCount; counter1++){
                    stringTemp = arrayVerticalLink [counter1];
                    findCount = 0;
                    
                    int *fovDataTemp = new int [stringTemp.length()];
                    
                    do{
                        
                        terminationFlag = 0;
                        
                        if ((int)stringTemp.find ("/") == -1){
                            terminationFlag = 1;
                            fovDataTemp [findCount] = atoi(stringTemp.c_str()), findCount++;
                        }
                        else{
                            
                            extractString1 = stringTemp.substr(0, stringTemp.find ("/"));
                            fovDataTemp [findCount] = atoi(extractString1.c_str()), findCount++;
                            stringTemp = stringTemp.substr(stringTemp.find ("/")+1);
                        }
                        
                    } while (terminationFlag == 0);
                    
                    for (int counter2 = 0; counter2 < findCount-1; counter2++){
                        firstFovNo = fovDataTemp [counter2];
                        
                        if (counter2 == 0 && positionSetStatus == 0){
                            xBefore1 = xyPositionDataHold [firstFovNo*2];
                            yBefore1 = xyPositionDataHold [firstFovNo*2+1];
                            arrayXYWritingPosition [firstFovNo*2] = xBefore1;
                            arrayXYWritingPosition [firstFovNo*2+1] = yBefore1;
                        }
                        else{
                            
                            xBefore1 = arrayXYWritingPosition [firstFovNo*2];
                            yBefore1 = arrayXYWritingPosition [firstFovNo*2+1];
                        }
                        
                        for (int counter3 = counter2+1; counter3 < findCount; counter3++){
                            secondFovNo = fovDataTemp [counter3];
                            
                            if (counter2 == 0 && counter3 == counter2+1 && positionSetStatus == 0){
                                xAfter1 = xyPositionDataHold [secondFovNo*2];
                                yAfter1 = xyPositionDataHold [secondFovNo*2+1];
                                arrayXYWritingPosition [secondFovNo*2] = xBefore1+xDistance;
                                arrayXYWritingPosition [secondFovNo*2+1] = yBefore1+yDistance;
                                
                                xDistanceOthers = xAfter1-xBefore1;
                                yDistanceOthers = yAfter1-yBefore1;
                                xBefore1 = arrayXYWritingPosition [secondFovNo*2];
                                yBefore1 = arrayXYWritingPosition [secondFovNo*2+1];
                            }
                            
                            if (counter2 == 0 && counter3 > counter2+1){
                                arrayXYWritingPosition [secondFovNo*2] = xBefore1+xDistanceOthers;
                                arrayXYWritingPosition [secondFovNo*2+1] = yBefore1+yDistanceOthers;
                                xBefore1 = arrayXYWritingPosition [secondFovNo*2];
                                yBefore1 = arrayXYWritingPosition [secondFovNo*2+1];
                            }
                            
                            if ((counter2 != 0 && counter3 == counter2+1) || (counter2 == 0 && counter3 == counter2+1 && positionSetStatus == 1)){
                                arrayXYWritingPosition [secondFovNo*2] = xBefore1+xDistance;
                                arrayXYWritingPosition [secondFovNo*2+1] = yBefore1+yDistance;
                                xBefore1 = arrayXYWritingPosition [secondFovNo*2];
                                yBefore1 = arrayXYWritingPosition [secondFovNo*2+1];
                            }
                            
                            if (counter2 == 0 && counter3 > counter2+1){
                                arrayXYWritingPosition [secondFovNo*2] = xBefore1+xDistanceOthers;
                                arrayXYWritingPosition [secondFovNo*2+1] = xBefore1+yDistanceOthers;
                            }
                        }
                    }
                    
                    delete [] fovDataTemp;
                }
                
                if (positionSetStatus == 0) positionSetStatus = 2;
                else if (positionSetStatus == 1) positionSetStatus = 0;
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

@end
