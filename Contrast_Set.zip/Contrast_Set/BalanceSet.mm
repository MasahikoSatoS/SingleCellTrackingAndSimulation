//
//  BalanceSet.m
//  Contrast_Set
//
//  Created by Masahiko Sato on 6/8/16.
//
//

#import "BalanceSet.h"

@implementation BalanceSet

-(void)balanceSetMain:(int)fovNoSet{
    int *bkNumberHold = new int [treatmentNameDisplayCount*2+50];
    
    int fovNoForProcess = 0;
    int treatFind = 0;
    int bkNumberHoldCount = 0;
    double rangeLimit = 0;
    
    string treatmentNameBack;
    string bkNumberExtract;
    string timeDetermine;
    string treatNameTemp2;
    string fovName2;
    string contrastDataTemp;
    string balanceExtract;
    string extensionExtract;
    
    for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++){
        treatNameTemp2 = arrayTreatmentNameDisplay [counter2];
        fovName2 = arrayFOVNameDisplay [counter2];
        
        if (treatNameTemp2 == loadImageTreatName && fovName2 != "ND" && treatFind == 0){
            treatFind = 1;
            
            contrastDataTemp = arrayTableDisplay [counter2*5+2];
            bkNumberExtract = contrastDataTemp.substr(contrastDataTemp.find(":")+1, contrastDataTemp.find("~")-contrastDataTemp.find(":")-1);
            bkNumberHold [bkNumberHoldCount] = atoi(bkNumberExtract.c_str()), bkNumberHoldCount++;
            
            balanceExtract = contrastDataTemp.substr(contrastDataTemp.find("~")+1);
        }
        else if (treatNameTemp2 == "ND" && fovName2 != "ND" && treatFind == 1){
            contrastDataTemp = arrayTableDisplay [counter2*5+2];
            bkNumberExtract = contrastDataTemp.substr(contrastDataTemp.find(":")+1, contrastDataTemp.find("~")-contrastDataTemp.find(":")-1);
            bkNumberHold [bkNumberHoldCount] = atoi(bkNumberExtract.c_str()), bkNumberHoldCount++;
        }
        else if (((treatNameTemp2 != "ND" && fovName2 != "ND") || (treatNameTemp2 == "ND" && fovName2 == "ND")) && treatFind == 1){
            treatFind = 2;
        }
    }
    
    fovNoForProcess = loadImageFOVNo;
    treatmentNameBack = loadImageTreatName;
    rangeLimit = atof(balanceExtract.c_str());
    
    //-----Edge information-----
    ifstream fin;
    
    treatFind = 0;
    string getString;
    
    int numberOfBlock = imageDimensionX/8;
    
    int *fovPositionHoldTemp = new int [treatmentNameDisplayCount*2+50];
    int *fovStartEnd = new int [treatmentNameDisplayCount*4+50];
    int *boarderData = new int [treatmentNameDisplayCount*17+50];
    
    int **edgeLinedata = new int *[treatmentNameDisplayCount*4+1];
    
    for (int counter2 = 0; counter2 < treatmentNameDisplayCount*4+1; counter2++) edgeLinedata [counter2] = new int [numberOfBlock+1];
    
    int fovPositionHoldTempCount = 0;
    
    if (processMode == 5 || processMode == 13 || processMode == 7) fin.open(fovPositionTempPath.c_str(), ios::in);
    else fin.open(fovPositionPath.c_str(), ios::in);
    
    if (fin.is_open()){
        do{
            
            getline(fin, getString);
            
            if (treatmentNameBack == getString && treatFind == 0) treatFind = 1;
            else if (getString != "ND" && treatFind == 1){
                treatFind = 2;
            }
            else if (getString != "ND" && treatFind == 2){
                fovPositionHoldTemp [fovPositionHoldTempCount] = atoi(getString.c_str()), fovPositionHoldTempCount++;
            }
            else if (getString == "ND" && treatFind == 2) treatFind = 3;
            
        } while (getString != "");
        
        fin.close();
    }
    
    //for (int counterA = 0; counterA < fovPositionHoldTempCount/2; counterA++){
    //    cout<<counterA<<" "<<fovPositionHoldTemp [counterA*2]<<" "<<fovPositionHoldTemp [counterA*2+1]<<" fovPosition"<<endl;
    //}
    
    for (int counter2 = 0; counter2 < fovPositionHoldTempCount/2; counter2++){
        fovStartEnd [counter2*4] = fovPositionHoldTemp [counter2*2];
        fovStartEnd [counter2*4+1] = fovPositionHoldTemp [counter2*2]+imageDimensionX-1;
        fovStartEnd [counter2*4+2] = fovPositionHoldTemp [counter2*2+1];
        fovStartEnd [counter2*4+3] = fovPositionHoldTemp [counter2*2+1]+imageDimensionY-1;
    }
    
    //for (int counterA = 0; counterA < fovNoForProcess; counterA++){
    //    cout<<counterA<<" "<<fovStartEnd [counterA*4]<<" "<<fovStartEnd [counterA*4+1]<<" "<<fovStartEnd [counterA*4+2]<<" "<<fovStartEnd [counterA*4+3]<<" starEnd"<<endl;
    //}
    
    for (int counter2 = 0; counter2 < fovNoForProcess*17; counter2++) boarderData [counter2] = 0;
    
    int hitCount = 0;
    int start = 0;
    int end = 0;
    
    for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
        for (int counter3 = 0; counter3 < fovNoForProcess; counter3++){
            if (counter2 != counter3){
                boarderData [counter2*17] = counter2+1;
                hitCount = 0;
                start = 0;
                end = 0;
                
                for (int counter4 = fovStartEnd [counter2*4]; counter4 <= fovStartEnd [counter2*4+1]; counter4++){
                    if (fovStartEnd [counter3*4] <= counter4 && fovStartEnd [counter3*4+1] >= counter4){
                        hitCount++;
                        
                        if (start == 0) start = counter4;
                        if (start != 0) end = counter4;
                    }
                }
                
                if (hitCount/(double)imageDimensionY > 0.8){
                    if (fovStartEnd [counter3*4+2] >= fovStartEnd [counter2*4+2] && fovStartEnd [counter3*4+2] <= fovStartEnd [counter2*4+3]){ //-----Down-----
                        boarderData [counter2*17+5] = counter3+1;
                        boarderData [counter2*17+6] = start;
                        boarderData [counter2*17+7] = end;
                        boarderData [counter2*17+8] = fovStartEnd [counter3*4+2]-1;
                    }
                    else if (fovStartEnd [counter3*4+3] >= fovStartEnd [counter2*4+2] && fovStartEnd [counter3*4+3] <= fovStartEnd [counter2*4+3]){ //-----Up-----
                        boarderData [counter2*17+1] = counter3+1;
                        boarderData [counter2*17+2] = start;
                        boarderData [counter2*17+3] = end;
                        boarderData [counter2*17+4] = fovStartEnd [counter2*4+2];
                    }
                }
                
                hitCount = 0;
                start = 0;
                end = 0;
                
                for (int counter4 = fovStartEnd [counter2*4+2]; counter4 <= fovStartEnd [counter2*4+3]; counter4++){
                    if (fovStartEnd [counter3*4+2] <= counter4 && fovStartEnd [counter3*4+3] >= counter4){
                        hitCount++;
                        
                        if (start == 0) start = counter4;
                        if (start != 0) end = counter4;
                    }
                }
                
                if (hitCount/(double)imageDimensionY > 0.8){
                    if (fovStartEnd [counter3*4] >= fovStartEnd [counter2*4] && fovStartEnd [counter3*4] <= fovStartEnd [counter2*4+1]){ //-----Right-----
                        boarderData [counter2*17+9] = counter3+1;
                        boarderData [counter2*17+10] = start;
                        boarderData [counter2*17+11] = end;
                        boarderData [counter2*17+12] = fovStartEnd [counter2*4+1];
                    }
                    else if (fovStartEnd [counter3*4+1] >= fovStartEnd [counter2*4] && fovStartEnd [counter3*4+1] <= fovStartEnd [counter2*4+1]){ //-----Left-----
                        boarderData [counter2*17+13] = counter3+1;
                        boarderData [counter2*17+14] = start;
                        boarderData [counter2*17+15] = end;
                        boarderData [counter2*17+16] = fovStartEnd [counter3*4+1]+1;
                    }
                }
            }
        }
    }
    
    //for (int counterA = 0; counterA < fovNoForProcess; counterA++){
    //    for (int counterB = 0; counterB < 17; counterB++) cout<<" "<<boarderData [counterA*17+counterB];
    //    cout<<" boarderData "<<counterA+1<<endl;
    //}
    
    for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
        for (int counter3 = 0; counter3 < numberOfBlock; counter3++){
            edgeLinedata [counter2*4][counter3]= 0; //-----Up-----
            edgeLinedata [counter2*4+1][counter3]= 0; //-----Down-----
            edgeLinedata [counter2*4+2][counter3]= 0; //-----Right-----
            edgeLinedata [counter2*4+3][counter3]= 0; //-----Left-----
        }
    }
    
    int rightFovNo = 0;
    int leftFovNo = 0;
    int upFovNo = 0;
    int downFovNo = 0;
    int selfFovNo = 0;
    int imageValue = 0;
    int imageValue2 = 0;
    int imageValue3 = 0;
    int imageValue4 = 0;
    int entryCount = 0;
    int entryCount2 = 0;
    int entryCount3 = 0;
    int entryCount4 = 0;
    int pixCount = 0;
    int blockCount = 0;
    int scanStart = 0;
    int scanEnd = 0;
    int constantLine = 0;
    int scanStart2 = 0;
    int scanEnd2 = 0;
    int blockCount2 = 0;
    
    for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
        selfFovNo = boarderData [counter2*17];
        rightFovNo = boarderData [counter2*17+9];
        leftFovNo = boarderData [counter2*17+13];
        upFovNo = boarderData [counter2*17+1];
        downFovNo = boarderData [counter2*17+5];
        
        //cout<<selfFovNo<<" "<<rightFovNo<<" "<<leftFovNo<<" "<<upFovNo<<" "<<downFovNo<<"  AroundFOV"<<endl;
        
        if (boarderData [counter2*17+1] != 0){ //-----UP-----
            imageValue = 0;
            imageValue2 = 0;
            entryCount = 0;
            entryCount2 = 0;
            pixCount = 0;
            blockCount = 1;
            
            scanStart = boarderData [(upFovNo-1)*17+6]-fovStartEnd [(upFovNo-1)*4];
            scanEnd = boarderData [(upFovNo-1)*17+7]-fovStartEnd [(upFovNo-1)*4];
            constantLine = boarderData [(upFovNo-1)*17+8]-fovStartEnd [(upFovNo-1)*4+2];
            
            scanStart2 = boarderData [counter2*17+2]-fovStartEnd [counter2*4];
            scanEnd2 = boarderData [counter2*17+3]-fovStartEnd [counter2*4];
            
            //cout<<scanStart<<" "<<scanEnd<<" "<<constantLine<<" "<<scanStart2<<" "<<scanEnd2<<" Start"<<endl;
            
            for (int counter4 = scanStart; counter4 <= scanEnd; counter4++){
                if (arrayImageContrastAdjust [(upFovNo-1)*imageDimensionY+constantLine][counter4] > 20 && arrayImageContrastAdjust [(upFovNo-1)*imageDimensionY+constantLine][counter4] < 230){
                    imageValue = imageValue+arrayImageContrastAdjust [(upFovNo-1)*imageDimensionY+constantLine][counter4];
                    entryCount++;
                }
                
                if (arrayImageContrastAdjust [(upFovNo-1)*imageDimensionY+constantLine-1][counter4] > 20 && arrayImageContrastAdjust [(upFovNo-1)*imageDimensionY+constantLine-1][counter4] < 230){
                    imageValue2 = imageValue2+arrayImageContrastAdjust [(upFovNo-1)*imageDimensionY+constantLine-1][counter4];
                    entryCount2++;
                }
                
                if (pixCount == 8){
                    if (entryCount != 0) imageValue = (int)(imageValue/(double)entryCount);
                    if (entryCount2 != 0) imageValue2 = (int)(imageValue2/(double)entryCount2);
                    
                    imageValue = (imageValue+imageValue2)/2;
                    
                    if (edgeLinedata [upFovNo*4+1][0] == 0) edgeLinedata [upFovNo*4+1][blockCount]= imageValue;
                    
                    imageValue = 0;
                    imageValue2 = 0;
                    entryCount = 0;
                    entryCount2 = 0;
                    pixCount = 0;
                    blockCount++;
                }
                else pixCount++;
            }
            
            imageValue3 = 0;
            imageValue4 = 0;
            entryCount3 = 0;
            entryCount4 = 0;
            pixCount = 0;
            blockCount2 = 1;
            
            for (int counter4 = scanStart2; counter4 <= scanEnd2; counter4++){
                if (arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY][counter4] > 20 && arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY][counter4] < 230){
                    imageValue3 = imageValue3+arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY][counter4];
                    entryCount3++;
                }
                
                if (arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY+1][counter4] > 20 && arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY+1][counter4] < 230){
                    imageValue4 = imageValue4+arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY+1][counter4];
                    entryCount4++;
                }
                
                if (pixCount == 8){
                    if (entryCount3 != 0) imageValue3 = (int)(imageValue3/(double)entryCount3);
                    if (entryCount4 != 0) imageValue4 = (int)(imageValue4/(double)entryCount4);
                    
                    imageValue3 = (imageValue3+imageValue4)/2;
                    
                    if (edgeLinedata [selfFovNo*4][0] == 0) edgeLinedata [selfFovNo*4][blockCount2]= imageValue3;
                    
                    imageValue3 = 0;
                    imageValue4 = 0;
                    entryCount3 = 0;
                    entryCount4 = 0;
                    pixCount = 0;
                    blockCount2++;
                }
                else pixCount++;
            }
            
            if (edgeLinedata [upFovNo*4+1][0] == 0) edgeLinedata [upFovNo*4+1][0]= blockCount;
            if (edgeLinedata [selfFovNo*4][0] == 0) edgeLinedata [selfFovNo*4][0]= blockCount2;
        }
        
        if (boarderData [counter2*17+5] != 0){ //-----Down-----
            imageValue = 0;
            imageValue2 = 0;
            entryCount = 0;
            entryCount2 = 0;
            pixCount = 0;
            blockCount = 1;
            
            scanStart = boarderData [(downFovNo-1)*17+2]-fovStartEnd [(downFovNo-1)*4];
            scanEnd = boarderData [(downFovNo-1)*17+3]-fovStartEnd [(downFovNo-1)*4];
            
            scanStart2 = boarderData [counter2*17+6]-fovStartEnd [counter2*4];
            scanEnd2 = boarderData [counter2*17+7]-fovStartEnd [counter2*4];
            constantLine = boarderData [counter2*17+8]-fovStartEnd [counter2*4+2];
            
            for (int counter4 = scanStart; counter4 <= scanEnd; counter4++){
                if (arrayImageContrastAdjust [(downFovNo-1)*imageDimensionY][counter4] > 20 && arrayImageContrastAdjust [(downFovNo-1)*imageDimensionY][counter4] < 230){
                    imageValue = imageValue+arrayImageContrastAdjust [(downFovNo-1)*imageDimensionY][counter4];
                    entryCount++;
                }
                
                if (arrayImageContrastAdjust [(downFovNo-1)*imageDimensionY+1][counter4] > 20 && arrayImageContrastAdjust [(downFovNo-1)*imageDimensionY+1][counter4] < 230){
                    imageValue2 = imageValue2+arrayImageContrastAdjust [(downFovNo-1)*imageDimensionY+1][counter4];
                    entryCount2++;
                }
                
                if (pixCount == 8){
                    if (entryCount != 0) imageValue = (int)(imageValue/(double)entryCount);
                    if (entryCount2 != 0) imageValue2 = (int)(imageValue2/(double)entryCount2);
                    
                    imageValue = (imageValue+imageValue2)/2;
                    
                    if (edgeLinedata [downFovNo*4][0] == 0) edgeLinedata [downFovNo*4][blockCount]= imageValue;
                    
                    imageValue = 0;
                    imageValue2 = 0;
                    entryCount = 0;
                    entryCount2 = 0;
                    pixCount = 0;
                    blockCount++;
                }
                else pixCount++;
            }
            
            imageValue3 = 0;
            imageValue4 = 0;
            entryCount3 = 0;
            entryCount4 = 0;
            pixCount = 0;
            blockCount2 = 1;
            
            for (int counter4 = scanStart2; counter4 <= scanEnd2; counter4++){
                if (arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY+constantLine][counter4] > 20 && arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY+constantLine][counter4] < 230){
                    imageValue3 = imageValue3+arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY+constantLine][counter4];
                    entryCount3++;
                }
                
                if (arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY+constantLine-1][counter4] > 20 && arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY+constantLine-1][counter4] < 230){
                    imageValue4 = imageValue4+arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY+constantLine-1][counter4];
                    entryCount4++;
                }
                
                if (pixCount == 8){
                    if (entryCount3 != 0) imageValue3 = (int)(imageValue3/(double)entryCount3);
                    if (entryCount4 != 0) imageValue4 = (int)(imageValue4/(double)entryCount4);
                    
                    imageValue3 = (imageValue3+imageValue4)/2;
                    
                    if (edgeLinedata [selfFovNo*4+1][0] == 0) edgeLinedata [selfFovNo*4+1][blockCount2]= imageValue3;
                    
                    imageValue3 = 0;
                    imageValue4 = 0;
                    entryCount3 = 0;
                    entryCount4 = 0;
                    pixCount = 0;
                    blockCount2++;
                }
                else pixCount++;
            }
            
            if (edgeLinedata [downFovNo*4][0] == 0) edgeLinedata [downFovNo*4][0]= blockCount;
            if (edgeLinedata [selfFovNo*4+1][0] == 0) edgeLinedata [selfFovNo*4+1][0]= blockCount2;
        }
        
        if (boarderData [counter2*17+13] != 0){ //-----Left-----
            imageValue = 0;
            imageValue2 = 0;
            entryCount = 0;
            entryCount2 = 0;
            pixCount = 0;
            blockCount = 1;
            
            scanStart = boarderData [(leftFovNo-1)*17+10]-fovStartEnd [(leftFovNo-1)*4+2];
            scanEnd = boarderData [(leftFovNo-1)*17+11]-fovStartEnd [(leftFovNo-1)*4+2];
            
            scanStart2 = boarderData [counter2*17+14]-fovStartEnd [counter2*4+2];
            scanEnd2 = boarderData [counter2*17+15]-fovStartEnd [counter2*4+2];
            constantLine = boarderData [counter2*17+16]-fovStartEnd [counter2*4];
            
            for (int counter4 = scanStart; counter4 <= scanEnd; counter4++){
                if (arrayImageContrastAdjust [(leftFovNo-1)*imageDimensionY+counter4][imageDimensionX-1] > 20 && arrayImageContrastAdjust [(leftFovNo-1)*imageDimensionY+counter4][imageDimensionX-1] < 230){
                    imageValue = imageValue+arrayImageContrastAdjust [(leftFovNo-1)*imageDimensionY+counter4][imageDimensionX-1];
                    entryCount++;
                }
                
                if (arrayImageContrastAdjust [(leftFovNo-1)*imageDimensionY+counter4][imageDimensionX-2] > 20 && arrayImageContrastAdjust [(leftFovNo-1)*imageDimensionY+counter4][imageDimensionX-2] < 230){
                    imageValue2 = imageValue2+arrayImageContrastAdjust [(leftFovNo-1)*imageDimensionY+counter4][imageDimensionX-2];
                    entryCount2++;
                }
                
                if (pixCount == 8){
                    if (entryCount != 0) imageValue = (int)(imageValue/(double)entryCount);
                    if (entryCount2 != 0) imageValue2 = (int)(imageValue2/(double)entryCount2);
                    
                    imageValue = (imageValue+imageValue2)/2;
                    
                    if (edgeLinedata [leftFovNo*4+2][0] == 0) edgeLinedata [leftFovNo*4+2][blockCount]= imageValue;
                    
                    imageValue = 0;
                    imageValue2 = 0;
                    entryCount = 0;
                    entryCount2 = 0;
                    pixCount = 0;
                    blockCount++;
                }
                else pixCount++;
            }
            
            imageValue3 = 0;
            imageValue4 = 0;
            entryCount3 = 0;
            entryCount4 = 0;
            pixCount = 0;
            blockCount2 = 1;
            
            for (int counter4 = scanStart2; counter4 <= scanEnd2; counter4++){
                if (arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY+counter4][constantLine] > 20 && arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY+counter4][constantLine] < 230){
                    imageValue3 = imageValue3+arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY+counter4][constantLine];
                    entryCount3++;
                }
                
                if (arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY+counter4][constantLine+1] > 20 && arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY+counter4][constantLine+1] < 230){
                    imageValue4 = imageValue4+arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY+counter4][constantLine+1];
                    entryCount4++;
                }
                
                if (pixCount == 8){
                    if (entryCount3 != 0) imageValue3 = (int)(imageValue3/(double)entryCount3);
                    if (entryCount4 != 0) imageValue4 = (int)(imageValue4/(double)entryCount4);
                    
                    imageValue3 = (imageValue3+imageValue4)/2;
                    
                    if (edgeLinedata [selfFovNo*4+3][0] == 0) edgeLinedata [selfFovNo*4+3][blockCount2]= imageValue3;
                    
                    imageValue3 = 0;
                    imageValue4 = 0;
                    entryCount3 = 0;
                    entryCount4 = 0;
                    pixCount = 0;
                    blockCount2++;
                }
                else pixCount++;
            }
            
            if (edgeLinedata [leftFovNo*4+2][0] == 0) edgeLinedata [leftFovNo*4+2][0]= blockCount;
            if (edgeLinedata [selfFovNo*4+3][0] == 0) edgeLinedata [selfFovNo*4+3][0]= blockCount2;
        }
        
        if (boarderData [counter2*17+9] != 0){
            imageValue = 0;
            imageValue2 = 0;
            entryCount = 0;
            entryCount2 = 0;
            pixCount = 0;
            blockCount = 1;
            
            scanStart = boarderData [(rightFovNo-1)*17+14]-fovStartEnd [(rightFovNo-1)*4+2];
            scanEnd = boarderData [(rightFovNo-1)*17+15]-fovStartEnd [(rightFovNo-1)*4+2];
            constantLine = boarderData [(rightFovNo-1)*17+16]-fovStartEnd [(rightFovNo-1)*4];
            
            scanStart2 = boarderData [counter2*17+10]-fovStartEnd [counter2*4+2];
            scanEnd2 = boarderData [counter2*17+11]-fovStartEnd [counter2*4+2];
            
            for (int counter4 = scanStart; counter4 <= scanEnd; counter4++){
                if (arrayImageContrastAdjust [(rightFovNo-1)*imageDimensionY+counter4][constantLine] > 20 && arrayImageContrastAdjust [(rightFovNo-1)*imageDimensionY+counter4][constantLine] < 230){
                    imageValue = imageValue+arrayImageContrastAdjust [(rightFovNo-1)*imageDimensionY+counter4][constantLine];
                    entryCount++;
                }
                
                if (arrayImageContrastAdjust [(rightFovNo-1)*imageDimensionY+counter4][constantLine+1] > 20 && arrayImageContrastAdjust [(rightFovNo-1)*imageDimensionY+counter4][constantLine+1] < 230){
                    imageValue2 = imageValue2+arrayImageContrastAdjust [(rightFovNo-1)*imageDimensionY+counter4][constantLine+1];
                    entryCount2++;
                }
                
                if (pixCount == 8){
                    if (entryCount != 0) imageValue = (int)(imageValue/(double)entryCount);
                    if (entryCount2 != 0) imageValue2 = (int)(imageValue2/(double)entryCount2);
                    
                    imageValue = (imageValue+imageValue2)/2;
                    
                    if (edgeLinedata [rightFovNo*4+3][0] == 0) edgeLinedata [rightFovNo*4+3][blockCount]= imageValue;
                    
                    imageValue = 0;
                    imageValue2 = 0;
                    entryCount = 0;
                    entryCount2 = 0;
                    pixCount = 0;
                    blockCount++;
                }
                else pixCount++;
            }
            
            imageValue3 = 0;
            imageValue4 = 0;
            entryCount3 = 0;
            entryCount4 = 0;
            pixCount = 0;
            blockCount2 = 1;
            
            for (int counter4 = scanStart2; counter4 <= scanEnd2; counter4++){ //-----Right-----
                if (arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY+counter4][imageDimensionX-1] > 20 && arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY+counter4][imageDimensionX-1] < 230){
                    imageValue3 = imageValue3+arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY+counter4][imageDimensionX-1];
                    entryCount3++;
                }
                
                if (arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY+counter4][imageDimensionX-2] > 20 && arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY+counter4][imageDimensionX-2] < 230){
                    imageValue4 = imageValue4+arrayImageContrastAdjust [(selfFovNo-1)*imageDimensionY+counter4][imageDimensionX-2];
                    entryCount4++;
                }
                
                if (pixCount == 8){
                    if (entryCount3 != 0) imageValue3 = (int)(imageValue3/(double)entryCount3);
                    if (entryCount4 != 0) imageValue4 = (int)(imageValue4/(double)entryCount4);
                    
                    imageValue3 = (imageValue3+imageValue4)/2;
                    
                    if (edgeLinedata [selfFovNo*4+2][0] == 0) edgeLinedata [selfFovNo*4+2][blockCount2]= imageValue3;
                    
                    imageValue3 = 0;
                    imageValue4 = 0;
                    entryCount3 = 0;
                    entryCount4 = 0;
                    pixCount = 0;
                    blockCount2++;
                }
                else pixCount++;
            }
            
            if (edgeLinedata [rightFovNo*4+3][0] == 0) edgeLinedata [rightFovNo*4+3][0] = blockCount;
            if (edgeLinedata [selfFovNo*4+2][0] == 0) edgeLinedata [selfFovNo*4+2][0] = blockCount2;
        }
    }
    
    //for (int counterA = 1; counterA <= fovNoForProcess; counterA++){
    //    cout<<counterA<<" "<<endl;
    //    for (int counterB = 0; counterB < numberOfBlock; counterB++) cout<<" "<<edgeLinedata [counterA*4][counterB];
    //    cout<<" edgeLinedata "<<counterA+1<<endl;
    //    for (int counterB = 0; counterB < numberOfBlock; counterB++) cout<<" "<<edgeLinedata [counterA*4+1][counterB];
    //    cout<<" edgeLinedata "<<counterA+1<<endl;
    //    for (int counterB = 0; counterB < numberOfBlock; counterB++) cout<<" "<<edgeLinedata [counterA*4+2][counterB];
    //    cout<<" edgeLinedata "<<counterA+1<<endl;
    //    for (int counterB = 0; counterB < numberOfBlock; counterB++) cout<<" "<<edgeLinedata [counterA*4+3][counterB];
    //    cout<<" edgeLinedata "<<counterA+1<<endl;
    //}
    
    int *valueList = new int [fovNoForProcess*4+50];
    
    for (int counter2 = 0; counter2 < fovNoForProcess*4; counter2++) valueList [counter2] = 0;
    
    int totalBlockNo = 0;
    int totalBlockNo2 = 0;
    int totalBlockNo3 = 0;
    int totalBlockNo4 = 0;
    int totalValueNo = 0;
    int totalValueNo2 = 0;
    int totalValueNo3 = 0;
    int totalValueNo4 = 0;
    
    for (int counter2 = 1; counter2 <= fovNoForProcess; counter2++){
        totalBlockNo = edgeLinedata [counter2*4][0];
        totalValueNo = 0;
        
        for (int counter3 = 1; counter3 <= totalBlockNo; counter3++){
            totalValueNo = totalValueNo+edgeLinedata [counter2*4][counter3];
        }
        
        totalBlockNo2 = edgeLinedata [counter2*4+1][0];
        totalValueNo2 = 0;
        
        for (int counter3 = 1; counter3 <= totalBlockNo2; counter3++){
            totalValueNo2 = totalValueNo2+edgeLinedata [counter2*4+1][counter3];
        }
        
        totalBlockNo3 = edgeLinedata [counter2*4+2][0];
        totalValueNo3 = 0;
        
        for (int counter3 = 1; counter3 <= totalBlockNo3; counter3++){
            totalValueNo3 = totalValueNo3+edgeLinedata [counter2*4+2][counter3];
        }
        
        totalBlockNo4 = edgeLinedata [counter2*4+3][0];
        totalValueNo4 = 0;
        
        for (int counter3 = 1; counter3 <= totalBlockNo4; counter3++){
            totalValueNo4 = totalValueNo4+edgeLinedata [counter2*4+3][counter3];
        }
        
        if (totalBlockNo != 0) totalValueNo = (int)(totalValueNo/(double)totalBlockNo);
        if (totalBlockNo2 != 0) totalValueNo2 = (int)(totalValueNo2/(double)totalBlockNo2);
        if (totalBlockNo3 != 0) totalValueNo3 = (int)(totalValueNo3/(double)totalBlockNo3);
        if (totalBlockNo4 != 0) totalValueNo4 = (int)(totalValueNo4/(double)totalBlockNo4);
        
        valueList [counter2*4] = totalValueNo;
        valueList [counter2*4+1] = totalValueNo2;
        valueList [counter2*4+2] = totalValueNo3;
        valueList [counter2*4+3] = totalValueNo4;
    }
    
    //for (int counterA = 1; counterA <= fovNoForProcess; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<valueList [counterA*4+counterB];
    //    cout<<" valueList "<<counterA+1<<endl;
    //}
    
    int upMin = 1000;
    int upMax = 0;
    int rightMin = 1000;
    int rightMax = 0;
    
    for (int counter2 = 1; counter2 <= fovNoForProcess; counter2++){
        if (valueList [counter2*4] != 0){
            if (upMin > valueList [counter2*4]) upMin = valueList [counter2*4];
            if (upMax < valueList [counter2*4]) upMax = valueList [counter2*4];
        }
        
        if (valueList [counter2*4+2] != 0){
            if (rightMin > valueList [counter2*4+2]) rightMin = valueList [counter2*4+2];
            if (rightMax < valueList [counter2*4+2]) rightMax = valueList [counter2*4+2];
        }
    }
    
    double upRatio = upMax/(double)upMin;
    double rightRatio = rightMax/(double)rightMin;
    
    if (rangeLimit == 0){
        rangeLimit = (upRatio+rightRatio)/(double)2;
        
        if (rangeLimit > 1.8) rangeLimit = 1.8;
    }
    
    if (rangeLimitCurrent == -1) rangeLimitCurrent = rangeLimit;
    
    for (int counter2 = 0; counter2 <= fovNoForProcess; counter2++) correctionValues [counter2] = 1;
    
    if (fovNoForProcess >= 9){
        int leftTopFov = 0;
        
        for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
            if (boarderData [counter2*17+1] == 0 && boarderData [counter2*17+13] == 0){
                leftTopFov = counter2+1;
                break;
            }
        }
        
        int terminationFlag = 0;
        int horizontalDimension = 0;
        int currentFov = leftTopFov;
        
        //-----Right to left-----
        do{
            
            terminationFlag = 0;
            
            for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                if (currentFov == counter2+1){
                    currentFov = boarderData [counter2*17+9];
                    horizontalDimension++;
                    terminationFlag = 1;
                }
            }
            
        } while (terminationFlag == 1);
        
        int verticalDimension = 0;
        currentFov = leftTopFov;
        
        //-----Top to bottom-----
        do{
            
            terminationFlag = 0;
            
            for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                if (currentFov == counter2+1){
                    currentFov = boarderData [counter2*17+5];
                    verticalDimension++;
                    terminationFlag = 1;
                }
            }
            
        } while (terminationFlag == 1);
        
        if (horizontalDimension > 2 && verticalDimension > 2){
            int **fovNoMap = new int *[verticalDimension+2];
            double **fovNoValue = new double *[verticalDimension+2];
            
            for (int counter2 = 0; counter2 < verticalDimension+1; counter2++){
                fovNoMap [counter2] = new int [horizontalDimension+2];
                fovNoValue [counter2] = new double [horizontalDimension+2];
            }
            
            for (int counter2 = 0; counter2 < verticalDimension+1; counter2++){
                for (int counter3 = 0; counter3 < horizontalDimension+1; counter3++){
                    fovNoMap [counter2][counter3] = 0;
                    fovNoValue [counter2][counter3] = 0;
                }
            }
            
            int dimensionCount = 1;
            int verticalCount = 1;
            int currentVerticalFov = leftTopFov;
            
            currentFov = leftTopFov;
            fovNoMap [1][1] = leftTopFov;
            
            //-----Top Center-----
            do{
                
                terminationFlag = 0;
                
                for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                    if (currentFov == counter2+1){
                        dimensionCount++;
                        
                        if (boarderData [counter2*17+9] != 0){
                            fovNoMap [verticalCount][dimensionCount] = boarderData [counter2*17+9];
                            currentFov = boarderData [counter2*17+9];
                            terminationFlag = 1;
                        }
                    }
                }
                
                if (terminationFlag == 0){
                    for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                        if (currentVerticalFov == counter2+1){
                            if (boarderData [counter2*17+5] != 0){
                                dimensionCount = 1;
                                verticalCount++;
                                currentVerticalFov = boarderData [counter2*17+5];
                                currentFov = boarderData [counter2*17+5];
                                
                                fovNoMap [verticalCount][dimensionCount] = boarderData [counter2*17+5];
                                terminationFlag = 1;
                                
                                break;
                            }
                        }
                    }
                }
                
            } while (terminationFlag == 1);
            
            //for (int counterA = 1; counterA <= verticalDimension; counterA++){
            //    for (int counterB = 1; counterB <= horizontalDimension; counterB++) cout<<" "<<fovNoMap [counterA][counterB];
            //    cout<<" fovNoMap "<<counterA+1<<endl;
            //}
            
            //-----Center horizontal-----
            int horizontalCenter = 0;
            
            if (horizontalDimension%2 != 0) horizontalCenter = horizontalDimension/2+1;
            else horizontalCenter = horizontalDimension/2;
            
            int verticalCenter = 0;
            
            if (verticalDimension%2 != 0) verticalCenter = verticalDimension/2+1;
            else verticalCenter = verticalDimension/2;
            
            int centerFov = fovNoMap [verticalCenter][horizontalCenter];
            
            //cout<<centerFov<<" "<<horizontalCenter<<" "<<verticalCenter<<" dimension"<<endl;
            
            int *horizontalValueList = new int [horizontalDimension+2];
            int horizontalFovNo = 0;
            
            for (int counter2 = 1; counter2 <= horizontalDimension; counter2++) horizontalValueList [counter2] = 0;
            
            for (int counter2 = 1; counter2 <= horizontalDimension; counter2++){
                horizontalFovNo = fovNoMap [verticalCenter][counter2];
                horizontalValueList [counter2] = valueList [horizontalFovNo*4+2];
            }
            
            int sumVH = 0;
            int sumV = 0;
            int sumH = 0;
            int sumHH = 0;
            int numberOfPoint = 0;
            int centerValue = valueList [centerFov*4+2];
            
            double constA = 0;
            double constAdjustB = 0;
            
            do{
                
                sumVH = 0;
                sumV = 0;
                sumH = 0;
                sumHH = 0;
                numberOfPoint = 0;
                
                terminationFlag = 0;
                
                for (int counter2 = 1; counter2 <= horizontalDimension; counter2++){
                    if (horizontalValueList [counter2] != 0){
                        sumVH = sumVH+horizontalValueList [counter2]*counter2;
                        sumV = sumV+horizontalValueList [counter2];
                        sumH = sumH+counter2;
                        sumHH = sumHH+counter2*counter2;
                        numberOfPoint++;
                    }
                }
                
                constA = (numberOfPoint*sumVH-sumV*sumH)/(double)(numberOfPoint*sumHH-sumH*sumH);
                constAdjustB = centerValue-constA*horizontalCenter;
                
                //cout<<constA <<" "<<constAdjustB<<" const"<<endl;
                
                if (constA < 0){
                    for (int counter2 = 1; counter2 <= horizontalDimension; counter2++){
                        if (horizontalValueList [counter2] != 0){
                            horizontalValueList [counter2] = horizontalValueList [counter2]-1;
                            break;
                        }
                    }
                    
                    for (int counter2 = horizontalDimension; counter2 >= 1; counter2--){
                        if (horizontalValueList [counter2] != 0){
                            horizontalValueList [counter2] = horizontalValueList [counter2]+1;
                            break;
                        }
                    }
                    
                    terminationFlag = 1;
                }
                
            } while (terminationFlag == 1);
            
            for (int counter2 = 1; counter2 <= horizontalDimension; counter2++){
                horizontalValueList [counter2] = (int)(constA*counter2+constAdjustB);
            }
            
            int horizontalCenterValue = horizontalValueList [horizontalCenter];
            
            for (int counter2 = 1; counter2 <= horizontalDimension; counter2++){
                fovNoValue [verticalCenter][counter2] = horizontalValueList [counter2]/(double)horizontalCenterValue;
                
                //cout<<counter2<<" "<<horizontalValueList [counter2]<<" horizontalValue"<<endl;
            }
            
            //-----Center vertical-----
            int *verticalValueList = new int [verticalDimension+2];
            int verticalFovNo = 0;
            
            for (int counter2 = 1; counter2 <= verticalDimension; counter2++) verticalValueList [counter2] = 0;
            
            for (int counter2 = 1; counter2 <= verticalDimension; counter2++){
                verticalFovNo = fovNoMap [counter2][horizontalCenter];
                verticalValueList [counter2] = valueList [verticalFovNo*4];
            }
            
            centerValue = valueList [centerFov*4];
            
            do{
                
                sumVH = 0;
                sumV = 0;
                sumH = 0;
                sumHH = 0;
                numberOfPoint = 0;
                
                terminationFlag = 0;
                
                for (int counter2 = 1; counter2 <= verticalDimension; counter2++){
                    if (verticalValueList [counter2] != 0){
                        sumVH = sumVH+verticalValueList [counter2]*counter2;
                        sumV = sumV+verticalValueList [counter2];
                        sumH = sumH+counter2;
                        sumHH = sumHH+counter2*counter2;
                        numberOfPoint++;
                    }
                }
                
                //cout<<sumVH<<" "<<sumV<<" "<<sumH<<" "<<sumHH<<" "<<numberOfPoint<<" "<<numberOfPoint*sumVH-sumV*sumH<<" "<<numberOfPoint*sumVH<<" "<<sumV*sumH<<" calValue"<<endl;
                
                constA = (numberOfPoint*sumVH-sumV*sumH)/(double)(numberOfPoint*sumHH-sumH*sumH);
                constAdjustB = centerValue-constA*verticalCenter;
                
                if (constA < 0){
                    for (int counter2 = 1; counter2 <= verticalDimension; counter2++){
                        if (verticalValueList [counter2] != 0){
                            verticalValueList [counter2] = verticalValueList [counter2]-1;
                            break;
                        }
                    }
                    
                    for (int counter2 = verticalDimension; counter2 >= 1; counter2--){
                        if (verticalValueList [counter2] != 0){
                            verticalValueList [counter2] = verticalValueList [counter2]+1;
                            break;
                        }
                    }
                    
                    terminationFlag = 1;
                }
                
            } while (terminationFlag == 1);
            
            //cout<<constA<<" "<<constAdjustB<<" const"<<endl;
            
            for (int counter2 = 1; counter2 <= verticalDimension; counter2++){
                verticalValueList [counter2] = (int)(constA*counter2+constAdjustB);
            }
            
            int verticalCenterValue = verticalValueList [verticalCenter];
            
            for (int counter2 = 1; counter2 <= verticalDimension; counter2++){
                fovNoValue [counter2][horizontalCenter] = verticalValueList [counter2]/(double)verticalCenterValue;
            }
            
            int horizontalCenterFix = horizontalValueList [horizontalCenter];
            
            //for (int counterA = 1; counterA <= verticalDimension; counterA++){
            //    for (int counterB = 1; counterB <= horizontalDimension; counterB++) cout<<" "<<fovNoValue [counterA][counterB];
            //    cout<<" fovNoValue "<<counterA+1<<endl;
            //}
            
            int redoFlag = 0;
            double newFovRatio = 0;
            
            //-----Horizontal Below remain-----
            for (int counter2 = verticalCenter+1; counter2 <= verticalDimension; counter2++){
                centerFov = fovNoMap [counter2][horizontalCenter];
                
                for (int counter3 = 1; counter3 <= horizontalDimension; counter3++) horizontalValueList [counter3] = 0;
                
                for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                    horizontalFovNo = fovNoMap [counter2][counter3];
                    horizontalValueList [counter3] = valueList [horizontalFovNo*4+2];
                }
                
                newFovRatio = fovNoValue [counter2][horizontalCenter];
                centerValue = valueList [centerFov*4+2];
                
                do{
                    
                    sumVH = 0;
                    sumV = 0;
                    sumH = 0;
                    sumHH = 0;
                    numberOfPoint = 0;
                    
                    terminationFlag = 0;
                    
                    for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                        if (horizontalValueList [counter3] != 0){
                            sumVH = sumVH+horizontalValueList [counter3]*counter3;
                            sumV = sumV+horizontalValueList [counter3];
                            sumH = sumH+counter3;
                            sumHH = sumHH+counter3*counter3;
                            numberOfPoint++;
                        }
                    }
                    
                    constA = (numberOfPoint*sumVH-sumV*sumH)/(double)(numberOfPoint*sumHH-sumH*sumH);
                    constAdjustB = centerValue-constA*horizontalCenter;
                    
                    if (constA < 0){
                        for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                            if (horizontalValueList [counter3] != 0){
                                horizontalValueList [counter3] = horizontalValueList [counter3]-1;
                                break;
                            }
                        }
                        
                        for (int counter3 = horizontalDimension; counter3 >= 1; counter3--){
                            if (horizontalValueList [counter3] != 0){
                                horizontalValueList [counter3] = horizontalValueList [counter3]+1;
                                break;
                            }
                        }
                        
                        terminationFlag = 1;
                    }
                    else{
                        
                        for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                            horizontalValueList [counter3] = (int)(constA*counter3+constAdjustB);
                        }
                        
                        //for (int counterA = 1; counterA <= verticalDimension; counterA++){
                        //    for (int counterB = 1; counterB <= horizontalDimension; counterB++) cout<<" "<<fovNoValue [counterA][counterB];
                        //    cout<<" fovNoValue "<<counterA+1<<endl;
                        //}
                        
                        for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                            fovNoValue [counter2][counter3] = (horizontalValueList [counter3]/(double)horizontalCenterFix)*newFovRatio;
                        }
                        
                        redoFlag = 0;
                        
                        for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                            if (fovNoValue [counter2-1][counter3] > fovNoValue [counter2][counter3]){
                                redoFlag = 1;
                            }
                        }
                        
                        if (redoFlag == 1){
                            centerValue++;
                            terminationFlag = 1;
                        }
                    }
                    
                } while (terminationFlag == 1);
            }
            
            //-----Horizontal Up remain-----
            for (int counter2 = verticalCenter-1; counter2 >= 2; counter2--){
                centerFov = fovNoMap [counter2][horizontalCenter];
                
                for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                    horizontalValueList [counter3] = 0;
                }
                
                for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                    horizontalFovNo = fovNoMap [counter2][counter3];
                    horizontalValueList [counter3] = valueList [horizontalFovNo*4+2];
                }
                
                newFovRatio = fovNoValue [counter2][horizontalCenter];
                centerValue = valueList [centerFov*4+2];
                
                do{
                    
                    sumVH = 0;
                    sumV = 0;
                    sumH = 0;
                    sumHH = 0;
                    numberOfPoint = 0;
                    
                    terminationFlag = 0;
                    
                    for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                        if (horizontalValueList [counter3] != 0){
                            sumVH = sumVH+horizontalValueList [counter3]*counter3;
                            sumV = sumV+horizontalValueList [counter3];
                            sumH = sumH+counter3;
                            sumHH = sumHH+counter3*counter3;
                            numberOfPoint++;
                        }
                    }
                    
                    constA = (numberOfPoint*sumVH-sumV*sumH)/(double)(numberOfPoint*sumHH-sumH*sumH);
                    constAdjustB = centerValue-constA*horizontalCenter;
                    
                    if (constA < 0){
                        for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                            if (horizontalValueList [counter3] != 0){
                                horizontalValueList [counter3] = horizontalValueList [counter3]-1;
                                break;
                            }
                        }
                        
                        for (int counter3 = horizontalDimension; counter3 >= 1; counter3--){
                            if (horizontalValueList [counter3] != 0){
                                horizontalValueList [counter3] = horizontalValueList [counter3]+1;
                                break;
                            }
                        }
                        
                        terminationFlag = 1;
                    }
                    else{
                        
                        for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                            horizontalValueList [counter3] = (int)(constA*counter3+constAdjustB);
                        }
                        
                        //for (int counterA = 1; counterA <= verticalDimension; counterA++){
                        //    for (int counterB = 1; counterB <= horizontalDimension; counterB++) cout<<" "<<fovNoValue [counterA][counterB];
                        //    cout<<" fovNoValue "<<counterA+1<<endl;
                        //}
                        
                        for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                            fovNoValue [counter2][counter3] = (horizontalValueList [counter3]/(double)horizontalCenterFix)*newFovRatio;
                        }
                        
                        redoFlag = 0;
                        
                        for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                            if (fovNoValue [counter2+1][counter3] < fovNoValue [counter2][counter3]){
                                redoFlag = 1;
                            }
                        }
                        
                        if (redoFlag == 1){
                            centerValue--;
                            terminationFlag = 1;
                        }
                    }
                    
                } while (terminationFlag == 1);
            }
            
            //for (int counterA = 1; counterA <= verticalDimension; counterA++){
            //    for (int counterB = 1; counterB <= horizontalDimension; counterB++) cout<<" "<<fovNoValue [counterA][counterB];
            //    cout<<" fovNoValue "<<counterA+1<<endl;
            //}
            
            double *verticalValueListDouble = new double [verticalDimension+2];
            double centerValueDouble = 0;
            
            //-----Vertical Value Set1-----
            double sumVHDouble = 0;
            double sumVDouble = 0;
            double sumHDouble = 0;
            double sumHHDouble = 0;
            
            for (int counter2 = 1; counter2 <= horizontalDimension; counter2++){
                for (int counter3 = 1; counter3 <= verticalDimension; counter3++) verticalValueListDouble [counter3] = 0;
                
                for (int counter3 = 1; counter3 <= verticalDimension; counter3++){
                    verticalValueListDouble [counter3] = fovNoValue [counter3][counter2];
                }
                
                centerValueDouble = fovNoValue [verticalCenter][counter2];
                
                sumVHDouble = 0;
                sumVDouble = 0;
                sumHDouble = 0;
                sumHHDouble = 0;
                numberOfPoint = 0;
                
                for (int counter3 = 1; counter3 <= verticalDimension; counter3++){
                    if (verticalValueListDouble [counter3] != 0){
                        sumVHDouble = sumVHDouble+verticalValueListDouble [counter3]*counter3;
                        sumVDouble = sumVDouble+verticalValueListDouble [counter3];
                        sumHDouble = sumHDouble+counter3;
                        sumHHDouble = sumHHDouble+counter3*counter3;
                        numberOfPoint++;
                    }
                }
                
                //cout<<sumVHDouble<<" "<<sumVDouble<<" "<<sumHDouble<<" "<<sumHHDouble<<" "<<numberOfPoint<<" "<<numberOfPoint*sumVHDouble-sumVDouble*sumHDouble<<" "<<numberOfPoint*sumVHDouble<<" "<<sumVDouble*sumHDouble<<" verticalCal"<<endl;
                
                constA = (numberOfPoint*sumVHDouble-sumVDouble*sumHDouble)/(double)(numberOfPoint*sumHHDouble-sumHDouble*sumHDouble);
                constAdjustB = centerValueDouble-constA*verticalCenter;
                
                //cout<<constA<<" "<<constAdjustB<<" const"<<endl;
                
                for (int counter3 = 1; counter3 <= verticalDimension; counter3++){
                    fovNoValue [counter3][counter2] = constA*counter3+constAdjustB;
                }
            }
            
            if (rangeLimitCurrentHorizontal == 0 && rangeLimitCurrentVertical == 0){
                for (int counter3 = 1; counter3 <= verticalDimension; counter3++){
                    for (int counter4 = 1; counter4 <= horizontalDimension; counter4++){
                        if (fovNoValue [counter3][counter4] > 1){
                            fovNoValue [counter3][counter4] = (fovNoValue [counter3][counter4]-1)*rangeLimitCurrent+1;
                        }
                        
                        if (fovNoValue [counter3][counter4] < 1){
                            fovNoValue [counter3][counter4] = 1-(1-fovNoValue [counter3][counter4])*rangeLimitCurrent;
                        }
                    }
                }
            }
            
            if (rangeLimitCurrentHorizontal != 0){
                double centerValue2 = 0;
                
                for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                    centerValue2 = fovNoValue [verticalCenter][counter3];
                    
                    for (int counter4 = 1; counter4 <= verticalDimension; counter4++){
                        if (fovNoValue [counter4][counter3] >= centerValue2){
                            fovNoValue [counter4][counter3] = (fovNoValue [counter4][counter3]-centerValue2)*rangeLimitCurrentHorizontal+1;
                        }
                        
                        if (fovNoValue [counter4][counter3] < centerValue2){
                            fovNoValue [counter4][counter3] = centerValue2-(centerValue2-fovNoValue [counter4][counter3])*rangeLimitCurrentHorizontal;
                        }
                    }
                }
            }
            
            if (rangeLimitCurrentVertical != 0){
                double centerValue2 = 0;
                
                for (int counter3 = 1; counter3 <= verticalDimension; counter3++){
                    centerValue2 = fovNoValue [counter3][horizontalCenter];
                    
                    for (int counter4 = 1; counter4 <= horizontalDimension; counter4++){
                        if (fovNoValue [counter3][counter4] >= centerValue2){
                            fovNoValue [counter3][counter4] = (fovNoValue [counter3][counter4]-centerValue2)*rangeLimitCurrentVertical+1;
                        }
                        
                        if (fovNoValue [counter3][counter4] < centerValue2){
                            fovNoValue [counter3][counter4] = centerValue2-(centerValue2-fovNoValue [counter3][counter4])*rangeLimitCurrentVertical;
                        }
                    }
                }
            }
            
            int horizontalCheck = 0;
            int verticalCheck = 0;
            
            for (int counter2 = 1; counter2 <= fovNoForProcess; counter2++){
                for (int counter3 = 1; counter3 <= verticalDimension; counter3++){
                    for (int counter4 = 1; counter4 <= horizontalDimension; counter4++){
                        if (fovNoMap [counter3][counter4] == counter2){
                            horizontalCheck = counter4;
                            verticalCheck = counter3;
                        }
                    }
                }
                
                correctionValues [counter2] = fovNoValue [verticalCheck][horizontalCheck];
            }
            
            for (int counter2 = 0; counter2 < verticalDimension+1; counter2++){
                delete [] fovNoMap [counter2];
                delete [] fovNoValue [counter2];
            }
            
            delete [] fovNoMap;
            delete [] fovNoValue;
            
            delete [] horizontalValueList;
            delete [] verticalValueList;
            delete [] verticalValueListDouble;
        }
    }
    else rangeLimitCurrent = 0;
    
    for (int counter2 = 0; counter2 < treatmentNameDisplayCount*4+1; counter2++) delete [] edgeLinedata [counter2];
    delete [] edgeLinedata;
    
    delete [] valueList;
    delete [] bkNumberHold;
    delete [] fovPositionHoldTemp;
    delete [] fovStartEnd;
    delete [] boarderData;
}

-(void)balanceSetAuto:(int)fovNoSet{
    /*Balance set for Auto processing*/
    
    int *bkNumberHold = new int [treatmentNameDisplayCount*2+50];
    
    int fovNoForProcess = 0;
    
    string treatmentNameBack;
    string bkNumberExtract;
    string timeDetermine;
    string treatNameTemp2;
    string fovName2;
    string contrastDataTemp;
    string balanceExtract;
    
    int timeDataUse = 1;
    
    for (int counter2 = 1; counter2 <= entryNumber; counter2++){
        timeDetermine = arrayContrastData [0][counter2+2];
        timeDetermine = timeDetermine.substr(1);
        
        if (atoi(timeDetermine.c_str()) < currentTimePoint+1) timeDataUse = counter2;
    }
    
    int treatFind = 0;
    int bkNumberHoldCount = 0;
    
    for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++){
        treatNameTemp2 = arrayTreatmentNameDisplay [counter2];
        fovName2 = arrayFOVNameDisplay [counter2];
        
        if (treatNameTemp2 == treatmentNameAuto && fovName2 != "ND" && treatFind == 0){
            treatFind = 1;
            
            contrastDataTemp = arrayContrastData [counter2][timeDataUse+2];
            bkNumberExtract = contrastDataTemp.substr(contrastDataTemp.find(":")+1, contrastDataTemp.find("~")-contrastDataTemp.find(":")-1);
            bkNumberHold [bkNumberHoldCount] = atoi(bkNumberExtract.c_str()), bkNumberHoldCount++;
            balanceExtract = contrastDataTemp.substr(contrastDataTemp.find("~")+1);
        }
        else if (treatNameTemp2 == "ND" && fovName2 != "ND" && treatFind == 1){
            contrastDataTemp = arrayContrastData [counter2][timeDataUse+2];
            bkNumberExtract = contrastDataTemp.substr(contrastDataTemp.find(":")+1, contrastDataTemp.find("~")-contrastDataTemp.find(":")-1);
            bkNumberHold [bkNumberHoldCount] = atoi(bkNumberExtract.c_str()), bkNumberHoldCount++;
        }
        else if (((treatNameTemp2 != "ND" && fovName2 != "ND") || (treatNameTemp2 == "ND" && fovName2 == "ND")) && treatFind == 1){
            treatFind = 2;
        }
    }
    
    fovNoForProcess = fovNoSet;
    treatmentNameBack = treatmentNameAuto;
    
    double rangeLimitBase = 0;
    double rangeLimitHorizontal = 0;
    double rangeLimitVertical = 0;
    
    if ((int)balanceExtract.find("^") != -1){
        rangeLimitBase = atof(balanceExtract.substr(0, balanceExtract.find("^")).c_str());
        rangeLimitHorizontal = atof(balanceExtract.substr(balanceExtract.find("^")+1, balanceExtract.find("%")-balanceExtract.find("^")-1).c_str());
        rangeLimitVertical = atof(balanceExtract.substr(balanceExtract.find("%")+1).c_str());
    }
    else rangeLimitBase = atof(balanceExtract.c_str());
    
    //-----Edge information-----
    ifstream fin;
    
    treatFind = 0;
    string getString;
    
    int numberOfBlock = autoImageSizeX/8;
    
    int *fovPositionHoldTemp = new int [treatmentNameDisplayCount*2+50];
    int *fovStartEnd = new int [treatmentNameDisplayCount*4+50];
    int *boarderData = new int [treatmentNameDisplayCount*17+50];
    
    int **edgeLinedata = new int *[treatmentNameDisplayCount*4+1];
    
    for (int counter2 = 0; counter2 < treatmentNameDisplayCount*4+1; counter2++) edgeLinedata [counter2] = new int [numberOfBlock+1];
    
    int fovPositionHoldTempCount = 0;
    
    if (processMode == 5 || processMode == 13 || processMode == 7) fin.open(fovPositionTempPath.c_str(), ios::in);
    else fin.open(fovPositionPath.c_str(), ios::in);
    
    if (fin.is_open()){
        do{
            
            getline(fin, getString);
            
            if (treatmentNameBack == getString && treatFind == 0) treatFind = 1;
            else if (getString != "ND" && treatFind == 1){
                treatFind = 2;
            }
            else if (getString != "ND" && treatFind == 2){
                fovPositionHoldTemp [fovPositionHoldTempCount] = atoi(getString.c_str()), fovPositionHoldTempCount++;
            }
            else if (getString == "ND" && treatFind == 2) treatFind = 3;
            
        } while (getString != "");
        
        fin.close();
    }
    
    //for (int counterA = 0; counterA < fovPositionHoldTempCount/2; counterA++){
    //    cout<<counterA<<" "<<fovPositionHoldTemp [counterA*2]<<" "<<fovPositionHoldTemp [counterA*2+1]<<" fovPosition"<<endl;
    //}
    
    for (int counter2 = 0; counter2 < fovPositionHoldTempCount/2; counter2++){
        fovStartEnd [counter2*4] = fovPositionHoldTemp [counter2*2];
        fovStartEnd [counter2*4+1] = fovPositionHoldTemp [counter2*2]+autoImageSizeX-1;
        fovStartEnd [counter2*4+2] = fovPositionHoldTemp [counter2*2+1];
        fovStartEnd [counter2*4+3] = fovPositionHoldTemp [counter2*2+1]+autoImageSizeY-1;
    }
    
    //for (int counterA = 0; counterA < fovNoForProcess; counterA++){
    //    cout<<counterA<<" "<<fovStartEnd [counterA*4]<<" "<<fovStartEnd [counterA*4+1]<<" "<<fovStartEnd [counterA*4+2]<<" "<<fovStartEnd [counterA*4+3]<<" starEnd"<<endl;
    //}
    
    for (int counter2 = 0; counter2 < fovNoForProcess*17; counter2++) boarderData [counter2] = 0;
    
    int hitCount = 0;
    int start = 0;
    int end = 0;
    
    for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
        for (int counter3 = 0; counter3 < fovNoForProcess; counter3++){
            if (counter2 != counter3){
                boarderData [counter2*17] = counter2+1;
                hitCount = 0;
                start = 0;
                end = 0;
                
                for (int counter4 = fovStartEnd [counter2*4]; counter4 <= fovStartEnd [counter2*4+1]; counter4++){
                    if (fovStartEnd [counter3*4] <= counter4 && fovStartEnd [counter3*4+1] >= counter4){
                        hitCount++;
                        
                        if (start == 0) start = counter4;
                        if (start != 0) end = counter4;
                    }
                }
                
                if (hitCount/(double)autoImageSizeY > 0.8){
                    if (fovStartEnd [counter3*4+2] >= fovStartEnd [counter2*4+2] && fovStartEnd [counter3*4+2] <= fovStartEnd [counter2*4+3]){ //-----Down-----
                        boarderData [counter2*17+5] = counter3+1;
                        boarderData [counter2*17+6] = start;
                        boarderData [counter2*17+7] = end;
                        boarderData [counter2*17+8] = fovStartEnd [counter3*4+2]-1;
                    }
                    else if (fovStartEnd [counter3*4+3] >= fovStartEnd [counter2*4+2] && fovStartEnd [counter3*4+3] <= fovStartEnd [counter2*4+3]){ //-----Up-----
                        boarderData [counter2*17+1] = counter3+1;
                        boarderData [counter2*17+2] = start;
                        boarderData [counter2*17+3] = end;
                        boarderData [counter2*17+4] = fovStartEnd [counter2*4+2];
                    }
                }
                
                hitCount = 0;
                start = 0;
                end = 0;
                
                for (int counter4 = fovStartEnd [counter2*4+2]; counter4 <= fovStartEnd [counter2*4+3]; counter4++){
                    if (fovStartEnd [counter3*4+2] <= counter4 && fovStartEnd [counter3*4+3] >= counter4){
                        hitCount++;
                        
                        if (start == 0) start = counter4;
                        if (start != 0) end = counter4;
                    }
                }
                
                if (hitCount/(double)autoImageSizeY > 0.8){
                    if (fovStartEnd [counter3*4] >= fovStartEnd [counter2*4] && fovStartEnd [counter3*4] <= fovStartEnd [counter2*4+1]){ //-----Right-----
                        boarderData [counter2*17+9] = counter3+1;
                        boarderData [counter2*17+10] = start;
                        boarderData [counter2*17+11] = end;
                        boarderData [counter2*17+12] = fovStartEnd [counter2*4+1];
                    }
                    else if (fovStartEnd [counter3*4+1] >= fovStartEnd [counter2*4] && fovStartEnd [counter3*4+1] <= fovStartEnd [counter2*4+1]){ //-----Left-----
                        boarderData [counter2*17+13] = counter3+1;
                        boarderData [counter2*17+14] = start;
                        boarderData [counter2*17+15] = end;
                        boarderData [counter2*17+16] = fovStartEnd [counter3*4+1]+1;
                    }
                }
            }
        }
    }
    
    //for (int counterA = 0; counterA < fovNoForProcess; counterA++){
    //    for (int counterB = 0; counterB < 17; counterB++) cout<<" "<<boarderData [counterA*17+counterB];
    //    cout<<" boarderData "<<counterA+1<<endl;
    //}
    
    for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
        for (int counter3 = 0; counter3 < numberOfBlock; counter3++){
            edgeLinedata [counter2*4][counter3]= 0; //-----Up-----
            edgeLinedata [counter2*4+1][counter3]= 0; //-----Down-----
            edgeLinedata [counter2*4+2][counter3]= 0; //-----Right-----
            edgeLinedata [counter2*4+3][counter3]= 0; //-----Left-----
        }
    }
    
    int rightFovNo = 0;
    int leftFovNo = 0;
    int upFovNo = 0;
    int downFovNo = 0;
    int selfFovNo = 0;
    int imageValue = 0;
    int imageValue2 = 0;
    int imageValue3 = 0;
    int imageValue4 = 0;
    int entryCount = 0;
    int entryCount2 = 0;
    int entryCount3 = 0;
    int entryCount4 = 0;
    int pixCount = 0;
    int blockCount = 0;
    int scanStart = 0;
    int scanEnd = 0;
    int constantLine = 0;
    int scanStart2 = 0;
    int scanEnd2 = 0;
    int blockCount2 = 0;
    
    for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
        selfFovNo = boarderData [counter2*17];
        rightFovNo = boarderData [counter2*17+9];
        leftFovNo = boarderData [counter2*17+13];
        upFovNo = boarderData [counter2*17+1];
        downFovNo = boarderData [counter2*17+5];
        
        //cout<<selfFovNo<<" "<<rightFovNo<<" "<<leftFovNo<<" "<<upFovNo<<" "<<downFovNo<<"  AroundFOV"<<endl;
        
        if (boarderData [counter2*17+1] != 0){ //-----UP-----
            imageValue = 0;
            imageValue2 = 0;
            entryCount = 0;
            entryCount2 = 0;
            pixCount = 0;
            blockCount = 1;
            
            scanStart = boarderData [(upFovNo-1)*17+6]-fovStartEnd [(upFovNo-1)*4];
            scanEnd = boarderData [(upFovNo-1)*17+7]-fovStartEnd [(upFovNo-1)*4];
            constantLine = boarderData [(upFovNo-1)*17+8]-fovStartEnd [(upFovNo-1)*4+2];
            
            scanStart2 = boarderData [counter2*17+2]-fovStartEnd [counter2*4];
            scanEnd2 = boarderData [counter2*17+3]-fovStartEnd [counter2*4];
            
            //cout<<scanStart<<" "<<scanEnd<<" "<<constantLine<<" "<<scanStart2<<" "<<scanEnd2<<" Start"<<endl;
            
            for (int counter4 = scanStart; counter4 <= scanEnd; counter4++){
                if (arrayBackgroundCorrectionData [(upFovNo-1)*autoImageSizeY+constantLine][counter4] > 20 && arrayBackgroundCorrectionData [(upFovNo-1)*autoImageSizeY+constantLine][counter4] < 230){
                    imageValue = imageValue+arrayBackgroundCorrectionData [(upFovNo-1)*autoImageSizeY+constantLine][counter4];
                    entryCount++;
                }
                
                if (arrayBackgroundCorrectionData [(upFovNo-1)*autoImageSizeY+constantLine-1][counter4] > 20 && arrayBackgroundCorrectionData [(upFovNo-1)*autoImageSizeY+constantLine-1][counter4] < 230){
                    imageValue2 = imageValue2+arrayBackgroundCorrectionData [(upFovNo-1)*autoImageSizeY+constantLine-1][counter4];
                    entryCount2++;
                }
                
                if (pixCount == 8){
                    if (entryCount != 0) imageValue = (int)(imageValue/(double)entryCount);
                    if (entryCount2 != 0) imageValue2 = (int)(imageValue2/(double)entryCount2);
                    
                    imageValue = (imageValue+imageValue2)/2;
                    
                    if (edgeLinedata [upFovNo*4+1][0] == 0) edgeLinedata [upFovNo*4+1][blockCount]= imageValue;
                    
                    imageValue = 0;
                    imageValue2 = 0;
                    entryCount = 0;
                    entryCount2 = 0;
                    pixCount = 0;
                    blockCount++;
                }
                else pixCount++;
            }
            
            imageValue3 = 0;
            imageValue4 = 0;
            entryCount3 = 0;
            entryCount4 = 0;
            pixCount = 0;
            blockCount2 = 1;
            
            for (int counter4 = scanStart2; counter4 <= scanEnd2; counter4++){
                if (arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY][counter4] > 20 && arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY][counter4] < 230){
                    imageValue3 = imageValue3+arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY][counter4];
                    entryCount3++;
                }
                
                if (arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY+1][counter4] > 20 && arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY+1][counter4] < 230){
                    imageValue4 = imageValue4+arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY+1][counter4];
                    entryCount4++;
                }
                
                if (pixCount == 8){
                    if (entryCount3 != 0) imageValue3 = (int)(imageValue3/(double)entryCount3);
                    if (entryCount4 != 0) imageValue4 = (int)(imageValue4/(double)entryCount4);
                    
                    imageValue3 = (imageValue3+imageValue4)/2;
                    
                    if (edgeLinedata [selfFovNo*4][0] == 0) edgeLinedata [selfFovNo*4][blockCount2]= imageValue3;
                    
                    imageValue3 = 0;
                    imageValue4 = 0;
                    entryCount3 = 0;
                    entryCount4 = 0;
                    pixCount = 0;
                    blockCount2++;
                }
                else pixCount++;
            }
            
            if (edgeLinedata [upFovNo*4+1][0] == 0) edgeLinedata [upFovNo*4+1][0]= blockCount;
            if (edgeLinedata [selfFovNo*4][0] == 0) edgeLinedata [selfFovNo*4][0]= blockCount2;
        }
        
        if (boarderData [counter2*17+5] != 0){ //-----Down-----
            imageValue = 0;
            imageValue2 = 0;
            entryCount = 0;
            entryCount2 = 0;
            pixCount = 0;
            blockCount = 1;
            
            scanStart = boarderData [(downFovNo-1)*17+2]-fovStartEnd [(downFovNo-1)*4];
            scanEnd = boarderData [(downFovNo-1)*17+3]-fovStartEnd [(downFovNo-1)*4];
            
            scanStart2 = boarderData [counter2*17+6]-fovStartEnd [counter2*4];
            scanEnd2 = boarderData [counter2*17+7]-fovStartEnd [counter2*4];
            constantLine = boarderData [counter2*17+8]-fovStartEnd [counter2*4+2];
            
            for (int counter4 = scanStart; counter4 <= scanEnd; counter4++){
                if (arrayBackgroundCorrectionData [(downFovNo-1)*autoImageSizeY][counter4] > 20 && arrayBackgroundCorrectionData [(downFovNo-1)*autoImageSizeY][counter4] < 230){
                    imageValue = imageValue+arrayBackgroundCorrectionData [(downFovNo-1)*autoImageSizeY][counter4];
                    entryCount++;
                }
                
                if (arrayBackgroundCorrectionData [(downFovNo-1)*autoImageSizeY+1][counter4] > 20 && arrayBackgroundCorrectionData [(downFovNo-1)*autoImageSizeY+1][counter4] < 230){
                    imageValue2 = imageValue2+arrayBackgroundCorrectionData [(downFovNo-1)*autoImageSizeY+1][counter4];
                    entryCount2++;
                }
                
                if (pixCount == 8){
                    if (entryCount != 0) imageValue = (int)(imageValue/(double)entryCount);
                    if (entryCount2 != 0) imageValue2 = (int)(imageValue2/(double)entryCount2);
                    
                    imageValue = (imageValue+imageValue2)/2;
                    
                    if (edgeLinedata [downFovNo*4][0] == 0) edgeLinedata [downFovNo*4][blockCount]= imageValue;
                    
                    imageValue = 0;
                    imageValue2 = 0;
                    entryCount = 0;
                    entryCount2 = 0;
                    pixCount = 0;
                    blockCount++;
                }
                else pixCount++;
            }
            
            imageValue3 = 0;
            imageValue4 = 0;
            entryCount3 = 0;
            entryCount4 = 0;
            pixCount = 0;
            blockCount2 = 1;
            
            for (int counter4 = scanStart2; counter4 <= scanEnd2; counter4++){
                if (arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY+constantLine][counter4] > 20 && arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY+constantLine][counter4] < 230){
                    imageValue3 = imageValue3+arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY+constantLine][counter4];
                    entryCount3++;
                }
                
                if (arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY+constantLine-1][counter4] > 20 && arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY+constantLine-1][counter4] < 230){
                    imageValue4 = imageValue4+arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY+constantLine-1][counter4];
                    entryCount4++;
                }
                
                if (pixCount == 8){
                    if (entryCount3 != 0) imageValue3 = (int)(imageValue3/(double)entryCount3);
                    if (entryCount4 != 0) imageValue4 = (int)(imageValue4/(double)entryCount4);
                    
                    imageValue3 = (imageValue3+imageValue4)/2;
                    
                    if (edgeLinedata [selfFovNo*4+1][0] == 0) edgeLinedata [selfFovNo*4+1][blockCount2]= imageValue3;
                    
                    imageValue3 = 0;
                    imageValue4 = 0;
                    entryCount3 = 0;
                    entryCount4 = 0;
                    pixCount = 0;
                    blockCount2++;
                }
                else pixCount++;
            }
            
            if (edgeLinedata [downFovNo*4][0] == 0) edgeLinedata [downFovNo*4][0]= blockCount;
            if (edgeLinedata [selfFovNo*4+1][0] == 0) edgeLinedata [selfFovNo*4+1][0]= blockCount2;
        }
        
        if (boarderData [counter2*17+13] != 0){ //-----Left-----
            imageValue = 0;
            imageValue2 = 0;
            entryCount = 0;
            entryCount2 = 0;
            pixCount = 0;
            blockCount = 1;
            
            scanStart = boarderData [(leftFovNo-1)*17+10]-fovStartEnd [(leftFovNo-1)*4+2];
            scanEnd = boarderData [(leftFovNo-1)*17+11]-fovStartEnd [(leftFovNo-1)*4+2];
            
            scanStart2 = boarderData [counter2*17+14]-fovStartEnd [counter2*4+2];
            scanEnd2 = boarderData [counter2*17+15]-fovStartEnd [counter2*4+2];
            constantLine = boarderData [counter2*17+16]-fovStartEnd [counter2*4];
            
            for (int counter4 = scanStart; counter4 <= scanEnd; counter4++){
                if (arrayBackgroundCorrectionData [(leftFovNo-1)*autoImageSizeY+counter4][autoImageSizeX-1] > 20 && arrayBackgroundCorrectionData [(leftFovNo-1)*autoImageSizeY+counter4][autoImageSizeX-1] < 230){
                    imageValue = imageValue+arrayBackgroundCorrectionData [(leftFovNo-1)*autoImageSizeY+counter4][autoImageSizeX-1];
                    entryCount++;
                }
                
                if (arrayBackgroundCorrectionData [(leftFovNo-1)*autoImageSizeY+counter4][autoImageSizeX-2] > 20 && arrayBackgroundCorrectionData [(leftFovNo-1)*autoImageSizeY+counter4][autoImageSizeX-2] < 230){
                    imageValue2 = imageValue2+arrayBackgroundCorrectionData [(leftFovNo-1)*autoImageSizeY+counter4][autoImageSizeX-2];
                    entryCount2++;
                }
                
                if (pixCount == 8){
                    if (entryCount != 0) imageValue = (int)(imageValue/(double)entryCount);
                    if (entryCount2 != 0) imageValue2 = (int)(imageValue2/(double)entryCount2);
                    
                    imageValue = (imageValue+imageValue2)/2;
                    
                    if (edgeLinedata [leftFovNo*4+2][0] == 0) edgeLinedata [leftFovNo*4+2][blockCount]= imageValue;
                    
                    imageValue = 0;
                    imageValue2 = 0;
                    entryCount = 0;
                    entryCount2 = 0;
                    pixCount = 0;
                    blockCount++;
                }
                else pixCount++;
            }
            
            imageValue3 = 0;
            imageValue4 = 0;
            entryCount3 = 0;
            entryCount4 = 0;
            pixCount = 0;
            blockCount2 = 1;
            
            for (int counter4 = scanStart2; counter4 <= scanEnd2; counter4++){
                if (arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY+counter4][constantLine] > 20 && arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY+counter4][constantLine] < 230){
                    imageValue3 = imageValue3+arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY+counter4][constantLine];
                    entryCount3++;
                }
                
                if (arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY+counter4][constantLine+1] > 20 && arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY+counter4][constantLine+1] < 230){
                    imageValue4 = imageValue4+arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY+counter4][constantLine+1];
                    entryCount4++;
                }
                
                if (pixCount == 8){
                    if (entryCount3 != 0) imageValue3 = (int)(imageValue3/(double)entryCount3);
                    if (entryCount4 != 0) imageValue4 = (int)(imageValue4/(double)entryCount4);
                    
                    imageValue3 = (imageValue3+imageValue4)/2;
                    
                    if (edgeLinedata [selfFovNo*4+3][0] == 0) edgeLinedata [selfFovNo*4+3][blockCount2]= imageValue3;
                    
                    imageValue3 = 0;
                    imageValue4 = 0;
                    entryCount3 = 0;
                    entryCount4 = 0;
                    pixCount = 0;
                    blockCount2++;
                }
                else pixCount++;
            }
            
            if (edgeLinedata [leftFovNo*4+2][0] == 0) edgeLinedata [leftFovNo*4+2][0]= blockCount;
            if (edgeLinedata [selfFovNo*4+3][0] == 0) edgeLinedata [selfFovNo*4+3][0]= blockCount2;
        }
        
        if (boarderData [counter2*17+9] != 0){
            imageValue = 0;
            imageValue2 = 0;
            entryCount = 0;
            entryCount2 = 0;
            pixCount = 0;
            blockCount = 1;
            
            scanStart = boarderData [(rightFovNo-1)*17+14]-fovStartEnd [(rightFovNo-1)*4+2];
            scanEnd = boarderData [(rightFovNo-1)*17+15]-fovStartEnd [(rightFovNo-1)*4+2];
            constantLine = boarderData [(rightFovNo-1)*17+16]-fovStartEnd [(rightFovNo-1)*4];
            
            scanStart2 = boarderData [counter2*17+10]-fovStartEnd [counter2*4+2];
            scanEnd2 = boarderData [counter2*17+11]-fovStartEnd [counter2*4+2];
            
            for (int counter4 = scanStart; counter4 <= scanEnd; counter4++){
                if (arrayBackgroundCorrectionData [(rightFovNo-1)*autoImageSizeY+counter4][constantLine] > 20 && arrayBackgroundCorrectionData [(rightFovNo-1)*autoImageSizeY+counter4][constantLine] < 230){
                    imageValue = imageValue+arrayBackgroundCorrectionData [(rightFovNo-1)*autoImageSizeY+counter4][constantLine];
                    entryCount++;
                }
                
                if (arrayBackgroundCorrectionData [(rightFovNo-1)*autoImageSizeY+counter4][constantLine+1] > 20 && arrayBackgroundCorrectionData [(rightFovNo-1)*autoImageSizeY+counter4][constantLine+1] < 230){
                    imageValue2 = imageValue2+arrayBackgroundCorrectionData [(rightFovNo-1)*autoImageSizeY+counter4][constantLine+1];
                    entryCount2++;
                }
                
                if (pixCount == 8){
                    if (entryCount != 0) imageValue = (int)(imageValue/(double)entryCount);
                    if (entryCount2 != 0) imageValue2 = (int)(imageValue2/(double)entryCount2);
                    
                    imageValue = (imageValue+imageValue2)/2;
                    
                    if (edgeLinedata [rightFovNo*4+3][0] == 0) edgeLinedata [rightFovNo*4+3][blockCount]= imageValue;
                    
                    imageValue = 0;
                    imageValue2 = 0;
                    entryCount = 0;
                    entryCount2 = 0;
                    pixCount = 0;
                    blockCount++;
                }
                else pixCount++;
            }
            
            imageValue3 = 0;
            imageValue4 = 0;
            entryCount3 = 0;
            entryCount4 = 0;
            pixCount = 0;
            blockCount2 = 1;
            
            for (int counter4 = scanStart2; counter4 <= scanEnd2; counter4++){ //-----Right-----
                if (arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY+counter4][autoImageSizeX-1] > 20 && arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY+counter4][autoImageSizeX-1] < 230){
                    imageValue3 = imageValue3+arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY+counter4][autoImageSizeX-1];
                    entryCount3++;
                }
                
                if (arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY+counter4][autoImageSizeX-2] > 20 && arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY+counter4][autoImageSizeX-2] < 230){
                    imageValue4 = imageValue4+arrayBackgroundCorrectionData [(selfFovNo-1)*autoImageSizeY+counter4][autoImageSizeX-2];
                    entryCount4++;
                }
                
                if (pixCount == 8){
                    if (entryCount3 != 0) imageValue3 = (int)(imageValue3/(double)entryCount3);
                    if (entryCount4 != 0) imageValue4 = (int)(imageValue4/(double)entryCount4);
                    
                    imageValue3 = (imageValue3+imageValue4)/2;
                    
                    if (edgeLinedata [selfFovNo*4+2][0] == 0) edgeLinedata [selfFovNo*4+2][blockCount2]= imageValue3;
                    
                    imageValue3 = 0;
                    imageValue4 = 0;
                    entryCount3 = 0;
                    entryCount4 = 0;
                    pixCount = 0;
                    blockCount2++;
                }
                else pixCount++;
            }
            
            if (edgeLinedata [rightFovNo*4+3][0] == 0) edgeLinedata [rightFovNo*4+3][0] = blockCount;
            if (edgeLinedata [selfFovNo*4+2][0] == 0) edgeLinedata [selfFovNo*4+2][0] = blockCount2;
        }
    }
    
    //for (int counterA = 1; counterA <= fovNoForProcess; counterA++){
    //    cout<<counterA<<" "<<endl;
    //    for (int counterB = 0; counterB < numberOfBlock; counterB++) cout<<" "<<edgeLinedata [counterA*4][counterB];
    //    cout<<" edgeLinedata "<<counterA+1<<endl;
    //    for (int counterB = 0; counterB < numberOfBlock; counterB++) cout<<" "<<edgeLinedata [counterA*4+1][counterB];
    //    cout<<" edgeLinedata "<<counterA+1<<endl;
    //    for (int counterB = 0; counterB < numberOfBlock; counterB++) cout<<" "<<edgeLinedata [counterA*4+2][counterB];
    //    cout<<" edgeLinedata "<<counterA+1<<endl;
    //    for (int counterB = 0; counterB < numberOfBlock; counterB++) cout<<" "<<edgeLinedata [counterA*4+3][counterB];
    //    cout<<" edgeLinedata "<<counterA+1<<endl;
    //}
    
    int *valueList = new int [fovNoForProcess*4+50];
    
    for (int counter2 = 0; counter2 < fovNoForProcess*4; counter2++) valueList [counter2] = 0;
    
    int totalBlockNo = 0;
    int totalBlockNo2 = 0;
    int totalBlockNo3 = 0;
    int totalBlockNo4 = 0;
    int totalValueNo = 0;
    int totalValueNo2 = 0;
    int totalValueNo3 = 0;
    int totalValueNo4 = 0;
    
    for (int counter2 = 1; counter2 <= fovNoForProcess; counter2++){
        totalBlockNo = edgeLinedata [counter2*4][0];
        totalValueNo = 0;
        
        for (int counter3 = 1; counter3 <= totalBlockNo; counter3++){
            totalValueNo = totalValueNo+edgeLinedata [counter2*4][counter3];
        }
        
        totalBlockNo2 = edgeLinedata [counter2*4+1][0];
        totalValueNo2 = 0;
        
        for (int counter3 = 1; counter3 <= totalBlockNo2; counter3++){
            totalValueNo2 = totalValueNo2+edgeLinedata [counter2*4+1][counter3];
        }
        
        totalBlockNo3 = edgeLinedata [counter2*4+2][0];
        totalValueNo3 = 0;
        
        for (int counter3 = 1; counter3 <= totalBlockNo3; counter3++){
            totalValueNo3 = totalValueNo3+edgeLinedata [counter2*4+2][counter3];
        }
        
        totalBlockNo4 = edgeLinedata [counter2*4+3][0];
        totalValueNo4 = 0;
        
        for (int counter3 = 1; counter3 <= totalBlockNo4; counter3++){
            totalValueNo4 = totalValueNo4+edgeLinedata [counter2*4+3][counter3];
        }
        
        if (totalBlockNo != 0) totalValueNo = (int)(totalValueNo/(double)totalBlockNo);
        if (totalBlockNo2 != 0) totalValueNo2 = (int)(totalValueNo2/(double)totalBlockNo2);
        if (totalBlockNo3 != 0) totalValueNo3 = (int)(totalValueNo3/(double)totalBlockNo3);
        if (totalBlockNo4 != 0) totalValueNo4 = (int)(totalValueNo4/(double)totalBlockNo4);
        
        valueList [counter2*4] = totalValueNo;
        valueList [counter2*4+1] = totalValueNo2;
        valueList [counter2*4+2] = totalValueNo3;
        valueList [counter2*4+3] = totalValueNo4;
    }
    
    //for (int counterA = 1; counterA <= fovNoForProcess; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<valueList [counterA*4+counterB];
    //    cout<<" valueList "<<counterA+1<<endl;
    //}
    
    for (int counter2 = 0; counter2 <= fovNoForProcess; counter2++) correctionValues [counter2] = 1;
    
    if (fovNoForProcess >= 9){
        int leftTopFov = 0;
        
        for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
            if (boarderData [counter2*17+1] == 0 && boarderData [counter2*17+13] == 0){
                leftTopFov = counter2+1;
                break;
            }
        }
        
        int terminationFlag = 0;
        int horizontalDimension = 0;
        int currentFov = leftTopFov;
        
        //-----Right to left-----
        do{
            
            terminationFlag = 0;
            
            for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                if (currentFov == counter2+1){
                    currentFov = boarderData [counter2*17+9];
                    horizontalDimension++;
                    terminationFlag = 1;
                }
            }
            
        } while (terminationFlag == 1);
        
        int verticalDimension = 0;
        currentFov = leftTopFov;
        
        //-----Top to bottom-----
        do{
            
            terminationFlag = 0;
            
            for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                if (currentFov == counter2+1){
                    currentFov = boarderData [counter2*17+5];
                    verticalDimension++;
                    terminationFlag = 1;
                }
            }
            
        } while (terminationFlag == 1);
        
        if (horizontalDimension > 2 && verticalDimension > 2){
            int **fovNoMap = new int *[verticalDimension+2];
            double **fovNoValue = new double *[verticalDimension+2];
            
            for (int counter2 = 0; counter2 < verticalDimension+1; counter2++){
                fovNoMap [counter2] = new int [horizontalDimension+2];
                fovNoValue [counter2] = new double [horizontalDimension+2];
            }
            
            for (int counter2 = 0; counter2 < verticalDimension+1; counter2++){
                for (int counter3 = 0; counter3 < horizontalDimension+1; counter3++){
                    fovNoMap [counter2][counter3] = 0;
                    fovNoValue [counter2][counter3] = 0;
                }
            }
            
            int dimensionCount = 1;
            int verticalCount = 1;
            int currentVerticalFov = leftTopFov;
            
            currentFov = leftTopFov;
            fovNoMap [1][1] = leftTopFov;
            
            //-----Top Center-----
            do{
                
                terminationFlag = 0;
                
                for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                    if (currentFov == counter2+1){
                        dimensionCount++;
                        
                        if (boarderData [counter2*17+9] != 0){
                            fovNoMap [verticalCount][dimensionCount] = boarderData [counter2*17+9];
                            currentFov = boarderData [counter2*17+9];
                            terminationFlag = 1;
                        }
                    }
                }
                
                if (terminationFlag == 0){
                    for (int counter2 = 0; counter2 < fovNoForProcess; counter2++){
                        if (currentVerticalFov == counter2+1){
                            if (boarderData [counter2*17+5] != 0){
                                dimensionCount = 1;
                                verticalCount++;
                                currentVerticalFov = boarderData [counter2*17+5];
                                currentFov = boarderData [counter2*17+5];
                                
                                fovNoMap [verticalCount][dimensionCount] = boarderData [counter2*17+5];
                                terminationFlag = 1;
                                
                                break;
                            }
                        }
                    }
                }
                
            } while (terminationFlag == 1);
            
            //for (int counterA = 1; counterA <= verticalDimension; counterA++){
            //    for (int counterB = 1; counterB <= horizontalDimension; counterB++) cout<<" "<<fovNoMap [counterA][counterB];
            //    cout<<" fovNoMap "<<counterA+1<<endl;
            //}
            
            //-----Center horizontal-----
            int horizontalCenter = 0;
            
            if (horizontalDimension%2 != 0) horizontalCenter = horizontalDimension/2+1;
            else horizontalCenter = horizontalDimension/2;
            
            int verticalCenter = 0;
            
            if (verticalDimension%2 != 0) verticalCenter = verticalDimension/2+1;
            else verticalCenter = verticalDimension/2;
            
            int centerFov = fovNoMap [verticalCenter][horizontalCenter];
            
            //cout<<centerFov<<" "<<horizontalCenter<<" "<<verticalCenter<<" dimension"<<endl;
            
            int *horizontalValueList = new int [horizontalDimension+2];
            int horizontalFovNo = 0;
            
            for (int counter2 = 1; counter2 <= horizontalDimension; counter2++) horizontalValueList [counter2] = 0;
            
            for (int counter2 = 1; counter2 <= horizontalDimension; counter2++){
                horizontalFovNo = fovNoMap [verticalCenter][counter2];
                horizontalValueList [counter2] = valueList [horizontalFovNo*4+2];
            }
            
            int sumVH = 0;
            int sumV = 0;
            int sumH = 0;
            int sumHH = 0;
            int numberOfPoint = 0;
            int centerValue = valueList [centerFov*4+2];
            
            double constA = 0;
            double constAdjustB = 0;
            
            do{
                
                sumVH = 0;
                sumV = 0;
                sumH = 0;
                sumHH = 0;
                numberOfPoint = 0;
                
                terminationFlag = 0;
                
                for (int counter2 = 1; counter2 <= horizontalDimension; counter2++){
                    if (horizontalValueList [counter2] != 0){
                        sumVH = sumVH+horizontalValueList [counter2]*counter2;
                        sumV = sumV+horizontalValueList [counter2];
                        sumH = sumH+counter2;
                        sumHH = sumHH+counter2*counter2;
                        numberOfPoint++;
                    }
                }
                
                constA = (numberOfPoint*sumVH-sumV*sumH)/(double)(numberOfPoint*sumHH-sumH*sumH);
                constAdjustB = centerValue-constA*horizontalCenter;
                
                //cout<<constA <<" "<<constAdjustB<<" const"<<endl;
                
                if (constA < 0){
                    for (int counter2 = 1; counter2 <= horizontalDimension; counter2++){
                        if (horizontalValueList [counter2] != 0){
                            horizontalValueList [counter2] = horizontalValueList [counter2]-1;
                            break;
                        }
                    }
                    
                    for (int counter2 = horizontalDimension; counter2 >= 1; counter2--){
                        if (horizontalValueList [counter2] != 0){
                            horizontalValueList [counter2] = horizontalValueList [counter2]+1;
                            break;
                        }
                    }
                    
                    terminationFlag = 1;
                }
                
            } while (terminationFlag == 1);
            
            for (int counter2 = 1; counter2 <= horizontalDimension; counter2++){
                horizontalValueList [counter2] = (int)(constA*counter2+constAdjustB);
                
                //cout<<counter2<<" "<<horizontalValueList [counter2]<<" horizontalValue"<<endl;
            }
            
            int horizontalCenterValue = horizontalValueList [horizontalCenter];
            
            for (int counter2 = 1; counter2 <= horizontalDimension; counter2++){
                fovNoValue [verticalCenter][counter2] = horizontalValueList [counter2]/(double)horizontalCenterValue;
                
                //cout<<counter2<<" "<<horizontalValueList [counter2]<<" horizontalValue"<<endl;
            }
            
            //-----Center vertical-----
            int *verticalValueList = new int [verticalDimension+2];
            int verticalFovNo = 0;
            
            for (int counter2 = 1; counter2 <= verticalDimension; counter2++) verticalValueList [counter2] = 0;
            
            for (int counter2 = 1; counter2 <= verticalDimension; counter2++){
                verticalFovNo = fovNoMap [counter2][horizontalCenter];
                verticalValueList [counter2] = valueList [verticalFovNo*4];
            }
            
            centerValue = valueList [centerFov*4];
            
            do{
                
                sumVH = 0;
                sumV = 0;
                sumH = 0;
                sumHH = 0;
                numberOfPoint = 0;
                
                terminationFlag = 0;
                
                for (int counter2 = 1; counter2 <= verticalDimension; counter2++){
                    if (verticalValueList [counter2] != 0){
                        sumVH = sumVH+verticalValueList [counter2]*counter2;
                        sumV = sumV+verticalValueList [counter2];
                        sumH = sumH+counter2;
                        sumHH = sumHH+counter2*counter2;
                        numberOfPoint++;
                    }
                }
                
                //cout<<sumVH<<" "<<sumV<<" "<<sumH<<" "<<sumHH<<" "<<numberOfPoint<<" "<<numberOfPoint*sumVH-sumV*sumH<<" "<<numberOfPoint*sumVH<<" "<<sumV*sumH<<" calValue"<<endl;
                
                constA = (numberOfPoint*sumVH-sumV*sumH)/(double)(numberOfPoint*sumHH-sumH*sumH);
                constAdjustB = centerValue-constA*verticalCenter;
                
                if (constA < 0){
                    for (int counter2 = 1; counter2 <= verticalDimension; counter2++){
                        if (verticalValueList [counter2] != 0){
                            verticalValueList [counter2] = verticalValueList [counter2]-1;
                            break;
                        }
                    }
                    
                    for (int counter2 = verticalDimension; counter2 >= 1; counter2--){
                        if (verticalValueList [counter2] != 0){
                            verticalValueList [counter2] = verticalValueList [counter2]+1;
                            break;
                        }
                    }
                    
                    terminationFlag = 1;
                }
                
            } while (terminationFlag == 1);
            
            //cout<<constA<<" "<<constAdjustB<<" const"<<endl;
            
            for (int counter2 = 1; counter2 <= verticalDimension; counter2++){
                verticalValueList [counter2] = (int)(constA*counter2+constAdjustB);
            }
            
            int verticalCenterValue = verticalValueList [verticalCenter];
            
            for (int counter2 = 1; counter2 <= verticalDimension; counter2++){
                fovNoValue [counter2][horizontalCenter] = verticalValueList [counter2]/(double)verticalCenterValue;
            }
            
            int horizontalCenterFix = horizontalValueList [horizontalCenter];
            
            //for (int counterA = 1; counterA <= verticalDimension; counterA++){
            //    for (int counterB = 1; counterB <= horizontalDimension; counterB++) cout<<" "<<fovNoValue [counterA][counterB];
            //    cout<<" fovNoValue "<<counterA+1<<endl;
            //}
            
            //-----Horizontal Below remain-----
            int redoFlag = 0;
            double newFovRatio = 0;
            
            for (int counter2 = verticalCenter+1; counter2 <= verticalDimension; counter2++){
                centerFov = fovNoMap [counter2][horizontalCenter];
                
                for (int counter3 = 1; counter3 <= horizontalDimension; counter3++) horizontalValueList [counter3] = 0;
                
                for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                    horizontalFovNo = fovNoMap [counter2][counter3];
                    horizontalValueList [counter3] = valueList [horizontalFovNo*4+2];
                }
                
                newFovRatio = fovNoValue [counter2][horizontalCenter];
                centerValue = valueList [centerFov*4+2];
                
                do{
                    
                    sumVH = 0;
                    sumV = 0;
                    sumH = 0;
                    sumHH = 0;
                    numberOfPoint = 0;
                    
                    terminationFlag = 0;
                    
                    for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                        if (horizontalValueList [counter3] != 0){
                            sumVH = sumVH+horizontalValueList [counter3]*counter3;
                            sumV = sumV+horizontalValueList [counter3];
                            sumH = sumH+counter3;
                            sumHH = sumHH+counter3*counter3;
                            numberOfPoint++;
                        }
                    }
                    
                    constA = (numberOfPoint*sumVH-sumV*sumH)/(double)(numberOfPoint*sumHH-sumH*sumH);
                    constAdjustB = centerValue-constA*horizontalCenter;
                    
                    if (constA < 0){
                        for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                            if (horizontalValueList [counter3] != 0){
                                horizontalValueList [counter3] = horizontalValueList [counter3]-1;
                                break;
                            }
                        }
                        
                        for (int counter3 = horizontalDimension; counter3 >= 1; counter3--){
                            if (horizontalValueList [counter3] != 0){
                                horizontalValueList [counter3] = horizontalValueList [counter3]+1;
                                break;
                            }
                        }
                        
                        terminationFlag = 1;
                    }
                    else{
                        
                        for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                            horizontalValueList [counter3] = (int)(constA*counter3+constAdjustB);
                        }
                        
                        //for (int counterA = 1; counterA <= verticalDimension; counterA++){
                        //    for (int counterB = 1; counterB <= horizontalDimension; counterB++) cout<<" "<<fovNoValue [counterA][counterB];
                        //    cout<<" fovNoValue "<<counterA+1<<endl;
                        //}
                        
                        for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                            fovNoValue [counter2][counter3] = (horizontalValueList [counter3]/(double)horizontalCenterFix)*newFovRatio;
                        }
                        
                        redoFlag = 0;
                        
                        for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                            if (fovNoValue [counter2-1][counter3] > fovNoValue [counter2][counter3]){
                                redoFlag = 1;
                            }
                        }
                        
                        if (redoFlag == 1){
                            centerValue++;
                            terminationFlag = 1;
                        }
                    }
                    
                } while (terminationFlag == 1);
            }
            
            //-----Horizontal Up remain-----
            for (int counter2 = verticalCenter-1; counter2 >= 2; counter2--){
                centerFov = fovNoMap [counter2][horizontalCenter];
                
                for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                    horizontalValueList [counter3] = 0;
                }
                
                for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                    horizontalFovNo = fovNoMap [counter2][counter3];
                    horizontalValueList [counter3] = valueList [horizontalFovNo*4+2];
                }
                
                newFovRatio = fovNoValue [counter2][horizontalCenter];
                centerValue = valueList [centerFov*4+2];
                
                do{
                    
                    sumVH = 0;
                    sumV = 0;
                    sumH = 0;
                    sumHH = 0;
                    numberOfPoint = 0;
                    
                    terminationFlag = 0;
                    
                    for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                        if (horizontalValueList [counter3] != 0){
                            sumVH = sumVH+horizontalValueList [counter3]*counter3;
                            sumV = sumV+horizontalValueList [counter3];
                            sumH = sumH+counter3;
                            sumHH = sumHH+counter3*counter3;
                            numberOfPoint++;
                        }
                    }
                    
                    constA = (numberOfPoint*sumVH-sumV*sumH)/(double)(numberOfPoint*sumHH-sumH*sumH);
                    constAdjustB = centerValue-constA*horizontalCenter;
                    
                    if (constA < 0){
                        for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                            if (horizontalValueList [counter3] != 0){
                                horizontalValueList [counter3] = horizontalValueList [counter3]-1;
                                break;
                            }
                        }
                        
                        for (int counter3 = horizontalDimension; counter3 >= 1; counter3--){
                            if (horizontalValueList [counter3] != 0){
                                horizontalValueList [counter3] = horizontalValueList [counter3]+1;
                                break;
                            }
                        }
                        
                        terminationFlag = 1;
                    }
                    else{
                        
                        for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                            horizontalValueList [counter3] = (int)(constA*counter3+constAdjustB);
                        }
                        
                        //for (int counterA = 1; counterA <= verticalDimension; counterA++){
                        //    for (int counterB = 1; counterB <= horizontalDimension; counterB++) cout<<" "<<fovNoValue [counterA][counterB];
                        //    cout<<" fovNoValue "<<counterA+1<<endl;
                        //}
                        
                        for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                            fovNoValue [counter2][counter3] = (horizontalValueList [counter3]/(double)horizontalCenterFix)*newFovRatio;
                        }
                        
                        redoFlag = 0;
                        
                        for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                            if (fovNoValue [counter2+1][counter3] < fovNoValue [counter2][counter3]){
                                redoFlag = 1;
                            }
                        }
                        
                        if (redoFlag == 1){
                            centerValue--;
                            terminationFlag = 1;
                        }
                    }
                    
                } while (terminationFlag == 1);
            }
            
            //for (int counterA = 1; counterA <= verticalDimension; counterA++){
            //    for (int counterB = 1; counterB <= horizontalDimension; counterB++) cout<<" "<<fovNoValue [counterA][counterB];
            //    cout<<" fovNoValue "<<counterA+1<<endl;
            //}
            
            double *verticalValueListDouble = new double [verticalDimension+2];
            double centerValueDouble = 0;
            
            //-----Vertical Value Set1-----
            double sumVHDouble = 0;
            double sumVDouble = 0;
            double sumHDouble = 0;
            double sumHHDouble = 0;
            
            for (int counter2 = 1; counter2 <= horizontalDimension; counter2++){
                for (int counter3 = 1; counter3 <= verticalDimension; counter3++) verticalValueListDouble [counter3] = 0;
                
                for (int counter3 = 1; counter3 <= verticalDimension; counter3++){
                    verticalValueListDouble [counter3] = fovNoValue [counter3][counter2];
                }
                
                centerValueDouble = fovNoValue [verticalCenter][counter2];
                
                sumVHDouble = 0;
                sumVDouble = 0;
                sumHDouble = 0;
                sumHHDouble = 0;
                numberOfPoint = 0;
                
                for (int counter3 = 1; counter3 <= verticalDimension; counter3++){
                    if (verticalValueListDouble [counter3] != 0){
                        sumVHDouble = sumVHDouble+verticalValueListDouble [counter3]*counter3;
                        sumVDouble = sumVDouble+verticalValueListDouble [counter3];
                        sumHDouble = sumHDouble+counter3;
                        sumHHDouble = sumHHDouble+counter3*counter3;
                        numberOfPoint++;
                    }
                }
                
                //cout<<sumVHDouble<<" "<<sumVDouble<<" "<<sumHDouble<<" "<<sumHHDouble<<" "<<numberOfPoint<<" "<<numberOfPoint*sumVHDouble-sumVDouble*sumHDouble<<" "<<numberOfPoint*sumVHDouble<<" "<<sumVDouble*sumHDouble<<" verticalCal"<<endl;
                
                constA = (numberOfPoint*sumVHDouble-sumVDouble*sumHDouble)/(double)(numberOfPoint*sumHHDouble-sumHDouble*sumHDouble);
                constAdjustB = centerValueDouble-constA*verticalCenter;
                
                for (int counter3 = 1; counter3 <= verticalDimension; counter3++){
                    fovNoValue [counter3][counter2] = constA*counter3+constAdjustB;
                }
            }
            
            if (rangeLimitHorizontal == 0 && rangeLimitVertical == 0){
                for (int counter3 = 1; counter3 <= verticalDimension; counter3++){
                    for (int counter4 = 1; counter4 <= horizontalDimension; counter4++){
                        if (fovNoValue [counter3][counter4] > 1){
                            fovNoValue [counter3][counter4] = (fovNoValue [counter3][counter4]-1)*rangeLimitBase+1;
                        }
                        
                        if (fovNoValue [counter3][counter4] < 1){
                            fovNoValue [counter3][counter4] = 1-(1-fovNoValue [counter3][counter4])*rangeLimitBase;
                        }
                    }
                }
            }
            
            if (rangeLimitHorizontal != 0){
                double centerValue2 = 0;
                
                for (int counter3 = 1; counter3 <= horizontalDimension; counter3++){
                    centerValue2 = fovNoValue [verticalCenter][counter3];
                    
                    for (int counter4 = 1; counter4 <= verticalDimension; counter4++){
                        if (fovNoValue [counter4][counter3] >= centerValue2){
                            fovNoValue [counter4][counter3] = (fovNoValue [counter4][counter3]-centerValue2)*rangeLimitHorizontal+1;
                        }
                        
                        if (fovNoValue [counter4][counter3] < centerValue2){
                            fovNoValue [counter4][counter3] = centerValue2-(centerValue2-fovNoValue [counter4][counter3])*rangeLimitHorizontal;
                        }
                    }
                }
            }
            
            if (rangeLimitVertical != 0){
                double centerValue2 = 0;
                
                for (int counter3 = 1; counter3 <= verticalDimension; counter3++){
                    centerValue2 = fovNoValue [counter3][horizontalCenter];
                    
                    for (int counter4 = 1; counter4 <= horizontalDimension; counter4++){
                        if (fovNoValue [counter3][counter4] >= centerValue2){
                            fovNoValue [counter3][counter4] = (fovNoValue [counter3][counter4]-centerValue2)*rangeLimitVertical+1;
                        }
                        
                        if (fovNoValue [counter3][counter4] < centerValue2){
                            fovNoValue [counter3][counter4] = centerValue2-(centerValue2-fovNoValue [counter3][counter4])*rangeLimitVertical;
                        }
                    }
                }
            }
            
            //for (int counterA = 1; counterA <= verticalDimension; counterA++){
            //    for (int counterB = 1; counterB <= horizontalDimension; counterB++) cout<<" "<<fovNoValue [counterA][counterB];
            //    cout<<" fovNoValueE "<<counterA+1<<endl;
            //}
            
            int horizontalCheck = 0;
            int verticalCheck = 0;
            
            for (int counter2 = 1; counter2 <= fovNoForProcess; counter2++){
                for (int counter3 = 1; counter3 <= verticalDimension; counter3++){
                    for (int counter4 = 1; counter4 <= horizontalDimension; counter4++){
                        if (fovNoMap [counter3][counter4] == counter2){
                            horizontalCheck = counter4;
                            verticalCheck = counter3;
                        }
                    }
                }
                
                correctionValues [counter2] = fovNoValue [verticalCheck][horizontalCheck];
            }
            
            for (int counter2 = 0; counter2 < verticalDimension+1; counter2++){
                delete [] fovNoMap [counter2];
                delete [] fovNoValue [counter2];
            }
            
            delete [] fovNoMap;
            delete [] fovNoValue;
            
            delete [] horizontalValueList;
            delete [] verticalValueList;
            delete [] verticalValueListDouble;
        }
    }
    else rangeLimitCurrent = 0;
    
    for (int counter2 = 0; counter2 < treatmentNameDisplayCount*4+1; counter2++) delete [] edgeLinedata [counter2];
    delete [] edgeLinedata;
    
    delete [] valueList;
    delete [] bkNumberHold;
    delete [] fovPositionHoldTemp;
    delete [] fovStartEnd;
    delete [] boarderData;
}

@end
