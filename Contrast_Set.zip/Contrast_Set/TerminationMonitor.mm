//
//  TerminationMonitor.m
//  Contrast_Set
//
//  Created by Masahiko Sato on 2014-05-14.
//
//

#import "TerminationMonitor.h"

NSString *notificationToTermination = @"notificationExecuteTermination";

@implementation TerminationMonitor

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToTermination object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    commTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(processControl) userInfo:nil repeats:YES];
}

-(void)processControl{
    NSString *activeProcess;
    
    int mainControllerActive = 1;
    
    for (NSRunningApplication *currApp in [[NSWorkspace sharedWorkspace] runningApplications]) {
        activeProcess = [currApp localizedName];
        
        if ([activeProcess isEqualToString:@"Imaging_Controller"]) mainControllerActive = 2;
    }
    
    if (mainControllerActive == 1){
        for (int counter1 = 0; counter1 < contrastDataHorizontal; counter1++){
            delete [] arrayContrastData [counter1];
            delete [] arrayContrastDataG [counter1];
            delete [] arrayContrastDataB [counter1];
        }
        
        delete [] arrayContrastData;
        delete [] arrayContrastDataG;
        delete [] arrayContrastDataB;
        
        delete [] arrayTreatmentNameDisplay;
        delete [] arrayFOVNameDisplay;
        delete [] arrayTableDisplay;
        delete [] arrayTableDisplayG;
        delete [] arrayTableDisplayB;
        
        if (backgroundPatternFirstSet == 1){
            delete [] backgroundPatternArray;
            delete [] backgroundPatternModifyArray;
            delete [] backgroundPatternName;
        }
        
        delete [] contrastValueHold;
        delete [] contrastValueHoldG;
        delete [] contrastValueHoldB;
        delete [] contrastCurrentHold;
        delete [] contrastCurrentHoldG;
        delete [] contrastCurrentHoldB;
        delete [] arrayFileDelete;
        
        if (imageDataHoldStatus == 1){
            for (int counter1 = 0; counter1 < imageDimensionY*loadImageFOVNo+2; counter1++){
                delete [] arrayImageDataHold [counter1];
                delete [] arrayImageRangeAdjust [counter1];
                delete [] arrayBackgroundDataHold [counter1];
                delete [] arrayBackgroundDataHold2 [counter1];
                delete [] arrayImageCutoffAdjust [counter1];
                delete [] arrayImageContrastAdjust [counter1];
                delete [] arrayBalanceBaseData [counter1];
                delete [] arrayBalanceBaseModify [counter1];
            }
            
            delete [] arrayImageDataHold;
            delete [] arrayImageRangeAdjust;
            delete [] arrayBackgroundDataHold;
            delete [] arrayBackgroundDataHold2;
            delete [] arrayImageCutoffAdjust;
            delete [] arrayImageContrastAdjust;
            delete [] arrayBalanceBaseData;
            delete [] arrayBalanceBaseModify;
            
            delete [] xyPositionData;
            delete [] xyPositionDataHold;
            delete [] arrayXYWritingPosition;
            delete [] arrayXYWritingPositionBase;
            delete [] arrayXYWritingPositionFluorescent;
            
            for (int counter1 = 0; counter1 < stitchImageDimension+2; counter1++){
                delete [] imageDisplayArray [counter1];
                delete [] imagePositionMap [counter1];
                delete [] imageDisplayBaseArray [counter1];
                delete [] imageDisplayFluorescentArray [counter1];
                delete [] arrayBalanceDataHold [counter1];
            }
            
            delete [] imageDisplayArray;
            delete [] imagePositionMap;
            delete [] imageDisplayBaseArray;
            delete [] imageDisplayFluorescentArray;
            delete [] arrayBalanceDataHold;
            
            if (backArraysSetStatus == 1){
                for (int counter1 = 0; counter1 < imageDimensionY+1; counter1++){
                    delete [] backBaseArray [counter1];
                    delete [] backBaseMap [counter1];
                    delete [] backBaseArrayModify [counter1];
                    delete [] backBaseArrayEdge [counter1];
                    delete [] backAreaMapUpArray [counter1];
                    delete [] backAreaMapDownArray [counter1];
                }
                
                delete [] backBaseArray;
                delete [] backBaseMap;
                delete [] backBaseArrayModify;
                delete [] backBaseArrayEdge;
                delete [] backAreaMapUpArray;
                delete [] backAreaMapDownArray;
                
                delete [] backAreaLineUpArray;
                delete [] backAreaLineDownArray;
                
                for (int counter1 = 0; counter1 < 10; counter1++){
                    delete [] backBaseArrayPrevious [counter1];
                }
                
                delete [] backBaseArrayPrevious;
                delete [] backBasePositionArray;
            }
            
            delete [] arrayImageDataHistogram;
            delete [] arrayImageDataHistogramG;
            delete [] arrayImageDataHistogramB;
            delete [] arrayImageCutoffAdjustHistogram;
            delete [] arrayImageCutoffAdjustHistogramG;
            delete [] arrayImageCutoffAdjustHistogramB;
            delete [] arrayImageContrastAdjustHistogram;
            delete [] arrayImageContrastAdjustHistogramG;
            delete [] arrayImageContrastAdjustHistogramB;
            delete [] arrayImageRangeAdjustHistogram;
            delete [] arrayImageRangeAdjustHistogramG;
            delete [] arrayImageRangeAdjustHistogramB;
            delete [] arrayImageDataLMH;
            delete [] arrayImageDataLMHG;
            delete [] arrayImageDataLMHB;
            delete [] arrayImageRangeAdjustLMH;
            delete [] arrayImageRangeAdjustLMHG;
            delete [] arrayImageRangeAdjustLMHB;
            delete [] autoContrastCorrectLMH;
            delete [] autoContrastCorrectLMHG;
            delete [] autoContrastCorrectLMHB;
            delete [] autoContrastCorrectLMH2;
            delete [] autoContrastCorrectLMH2G;
            delete [] autoContrastCorrectLMH2B;
            delete [] arrayHorizontalLink;
            delete [] arrayVerticalLink;
        }
        
        exit (0);
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToTermination object:nil];
    if (commTimer) [commTimer invalidate];
}

@end
