//
//  IFReloadController.m
//  Contrast_Set
//
//  Created by Masahiko Sato on 11/17/16.
//
//

#import "IFReloadController.h"

NSString *notificationToIFReloadController = @"notificationToIFReloadController";

@implementation IFReloadController

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToIFReloadController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    ifReloadWindowController = [[NSWindowController alloc] initWithWindowNibName:@"PrevIFLoad"];
    [ifReloadWindowController showWindow:self];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToIFReloadOperation object:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [ifReloadWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [ifReloadWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
}

-(IBAction)closeWindow:(id)sender{
    ifReloadWindowController = [[NSWindowController alloc] initWithWindowNibName:@"PrevIFLoad"];
    [ifReloadWindow orderOut:self];
    ifReloadWindowOperation = 2;
    ifReloadTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (ifReloadWindowOperation == 3){
        [ifReloadWindow makeKeyAndOrderFront:self];
        ifReloadWindowOperation = 1;
        [ifReloadTimer invalidate];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToIFReloadController object:nil];
}

@end
