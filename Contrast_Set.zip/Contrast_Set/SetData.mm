//
//  SetData.m
//  Contrast_Set
//
//  Created by Masahiko Sato on 2014-06-20.
//
//

#import "SetData.h"

@implementation  SetData

-(void)setDataMain {
    int saveStatus = 0;
    int proceedingFlag = 0;
    
    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
        if (arrayTableDisplay [counter1*5+2] == "nil" && arrayTableDisplay [counter1*5+2] != " "){
            if (proceedingFlag == 0) proceedingFlag = 1;
            if (proceedingFlag == 2) proceedingFlag = 3;
        }
        
        if (arrayTableDisplay [counter1*5+2] != "nil" && arrayTableDisplay [counter1*5+2] != " "){
            if (proceedingFlag == 0) proceedingFlag = 2;
            if (proceedingFlag == 1) proceedingFlag = 3;
        }
    }
    
    if (entryNumber+5 < contrastDataLimit){
        if (proceedingFlag == 2 || proceedingFlag == 3){
            int processStatus = 3; //-----Add-----
            int entryPoint = entryNumber+1;
            string timeData;
            
            for (int counter1 = 1; counter1 <= entryNumber; counter1++){
                timeData = arrayContrastData [0][counter1+2];
                timeData = timeData.substr(1);
                
                if (atoi(timeData.c_str()) == loadImageNo){
                    processStatus = 1; //-----Replace-----
                    entryPoint = counter1;
                    break;
                }
                if (atoi(timeData.c_str()) > loadImageNo){
                    processStatus = 2; //-----Insert-----
                    entryPoint = counter1;
                    break;
                }
            }
            
            if (processStatus == 1){
                int startFlag = 0;
                
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    if (arrayTreatmentNameDisplay [counter1] == loadImageTreatName && startFlag == 0){
                        arrayContrastData [counter1][entryPoint+2] = arrayTableDisplay [counter1*5+2];
                        
                        if (photoMetricHold == 2){
                            arrayContrastDataG [counter1][entryPoint+2] = arrayTableDisplayG [counter1*5+2];
                            arrayContrastDataB [counter1][entryPoint+2] = arrayTableDisplayB [counter1*5+2];
                        }
                        
                        startFlag = 1;
                    }
                    else if (arrayFOVNameDisplay [counter1] != "ND" && arrayTreatmentNameDisplay [counter1] == "ND" &&  startFlag == 1){
                        arrayContrastData [counter1][entryPoint+2] = arrayTableDisplay [counter1*5+2];
                        
                        if (photoMetricHold == 2){
                            arrayContrastDataG [counter1][entryPoint+2] = arrayTableDisplayG [counter1*5+2];
                            arrayContrastDataB [counter1][entryPoint+2] = arrayTableDisplayB [counter1*5+2];
                        }
                    }
                    else if ((arrayFOVNameDisplay [counter1] == "ND" || arrayTreatmentNameDisplay [counter1] != "ND") &&  startFlag == 1){
                        break;
                    }
                }
                
                //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
                //    for (int counterB = 0; counterB < entryNumber+3; counterB++) cout<<" "<<arrayContrastData [counterA][counterB];
                //    cout<<"  arrayContrastData "<<counterA+1<<endl;
                //}
                
                ofstream oin;
                
                if (processMode == 5 || processMode == 13 || processMode == 7){
                    string productsContrastTempPath = productsFilesTempPath+"/"+"CT-ContrastData";
                    string productsContrastTempPathG = productsFilesTempPath+"/"+"CT-ContrastDataG";
                    string productsContrastTempPathB = productsFilesTempPath+"/"+"CT-ContrastDataB";
                    
                    oin.open(productsContrastTempPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                        for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastData [counter1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    if (photoMetricHold == 2){
                        oin.open(productsContrastTempPathG.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastDataG [counter1][counter2]<<endl;
                        }
                        
                        oin.close();
                        
                        oin.open(productsContrastTempPathB.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastDataB [counter1][counter2]<<endl;
                        }
                        
                        oin.close();
                    }
                }
                else{
                    
                    string productsContrastPath = productsFilesInfoPath+"/"+"CT-ContrastData";
                    string productsContrastPathG = productsFilesInfoPath+"/"+"CT-ContrastDataG";
                    string productsContrastPathB = productsFilesInfoPath+"/"+"CT-ContrastDataB";
                    
                    oin.open(productsContrastPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                        for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastData [counter1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    if (photoMetricHold == 2){
                        oin.open(productsContrastPathG.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastDataG [counter1][counter2]<<endl;
                        }
                        
                        oin.close();
                        
                        oin.open(productsContrastPathB.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastDataB [counter1][counter2]<<endl;
                        }
                        
                        oin.close();
                    }
                    
                    string contrastSettingToSystemPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ContrastDataTemp-"+bodyName+"~CP";
                    
                    oin.open(contrastSettingToSystemPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                        for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastData [counter1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    oin.open(productsContrastPathG.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                        for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastDataG [counter1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    string contrastSettingToSystemPathG = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ContrastDataTemp-"+bodyName+"~CPG";
                    
                    oin.open(contrastSettingToSystemPathG.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                        for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastDataG [counter1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    oin.open(productsContrastPathB.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                        for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastDataB [counter1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    string contrastSettingToSystemPathB = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ContrastDataTemp-"+bodyName+"~CPB";
                    
                    oin.open(contrastSettingToSystemPathB.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                        for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastDataB [counter1][counter2]<<endl;
                    }
                    
                    oin.close();
                }
                
                int writingPoint = 0;
                
                timeData = arrayTableDisplay [3];
                timeData = timeData.substr(1);
                
                if (atoi(timeData.c_str()) == loadImageNo) writingPoint = 1;
                else{
                    
                    timeData = arrayTableDisplay [4];
                    timeData = timeData.substr(1);
                    
                    if (atoi(timeData.c_str()) == loadImageNo) writingPoint = 2;
                }
                
                if (writingPoint != 0){
                    startFlag = 0;
                    
                    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                        if (arrayTreatmentNameDisplay [counter1] == loadImageTreatName && startFlag == 0){
                            arrayTableDisplay [counter1*5+writingPoint+2] = arrayTableDisplay [counter1*5+2];
                            startFlag = 1;
                        }
                        else if (arrayFOVNameDisplay [counter1] != "ND" && arrayTreatmentNameDisplay [counter1] == "ND" &&  startFlag == 1){
                            arrayTableDisplay [counter1*5+writingPoint+2] = arrayTableDisplay [counter1*5+2];
                        }
                        else if ((arrayFOVNameDisplay [counter1] == "ND" || arrayTreatmentNameDisplay [counter1] != "ND") &&  startFlag == 1){
                            break;
                        }
                    }
                    
                    if (photoMetricHold == 2){
                        startFlag = 0;
                        
                        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                            if (arrayTreatmentNameDisplay [counter1] == loadImageTreatName && startFlag == 0){
                                arrayTableDisplayG [counter1*5+writingPoint+2] = arrayTableDisplayG [counter1*5+2];
                                startFlag = 1;
                            }
                            else if (arrayFOVNameDisplay [counter1] != "ND" && arrayTreatmentNameDisplay [counter1] == "ND" &&  startFlag == 1){
                                arrayTableDisplayG [counter1*5+writingPoint+2] = arrayTableDisplayG [counter1*5+2];
                            }
                            else if ((arrayFOVNameDisplay [counter1] == "ND" || arrayTreatmentNameDisplay [counter1] != "ND") &&  startFlag == 1){
                                break;
                            }
                        }
                        
                        startFlag = 0;
                        
                        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                            if (arrayTreatmentNameDisplay [counter1] == loadImageTreatName && startFlag == 0){
                                arrayTableDisplayB [counter1*5+writingPoint+2] = arrayTableDisplayB [counter1*5+2];
                                startFlag = 1;
                            }
                            else if (arrayFOVNameDisplay [counter1] != "ND" && arrayTreatmentNameDisplay [counter1] == "ND" &&  startFlag == 1){
                                arrayTableDisplayB [counter1*5+writingPoint+2] = arrayTableDisplayB [counter1*5+2];
                            }
                            else if ((arrayFOVNameDisplay [counter1] == "ND" || arrayTreatmentNameDisplay [counter1] != "ND") &&  startFlag == 1){
                                break;
                            }
                        }
                    }
                }
                
                tableViewCall = 1;
            }
            
            if (processStatus == 2 || processStatus == 3){
                if (processStatus == 2){
                    int timeDataUse = 1;
                    string timeDetermine;
                    
                    for (int counter2 = 1; counter2 <= entryNumber; counter2++){
                        timeDetermine = arrayContrastData [0][counter2+2];
                        timeDetermine = timeDetermine.substr(1);
                        
                        if (atoi(timeDetermine.c_str()) < currentTimePoint+1) timeDataUse = counter2;
                    }
                    
                    string *contrastDataTimePoint = new string [treatmentNameDisplayCount+50];
                    int contrastDataTimePointCount = 0;
                    string *contrastDataTimePointG = new string [treatmentNameDisplayCount+50];
                    int contrastDataTimePointCountG = 0;
                    string *contrastDataTimePointB = new string [treatmentNameDisplayCount+50];
                    int contrastDataTimePointCountB = 0;
                    
                    string **arrayContrastDataTemp = new string *[contrastDataHorizontal];
                    string **arrayContrastDataTempG = new string *[contrastDataHorizontal];
                    string **arrayContrastDataTempB = new string *[contrastDataHorizontal];
                    
                    for (int counter1 = 0; counter1 < contrastDataHorizontal; counter1++){
                        arrayContrastDataTemp [counter1] = new string [contrastDataEntry+50];
                        arrayContrastDataTempG [counter1] = new string [contrastDataEntry+50];
                        arrayContrastDataTempB [counter1] = new string [contrastDataEntry+50];
                    }
                    
                    for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                        contrastDataTimePoint [contrastDataTimePointCount] = arrayContrastData [counter2][timeDataUse+2], contrastDataTimePointCount++;
                    }
                    
                    arrayContrastDataTemp [0][0] = "0";
                    arrayContrastDataTemp [0][1] = "0";
                    arrayContrastDataTemp [0][2] = "0";
                    
                    string extension;
                    
                    for (int counter1 = 1; counter1 <= entryNumber+1; counter1++){
                        if (counter1 < entryPoint) arrayContrastDataTemp [0][counter1+2] = arrayContrastData [0][counter1+2];
                        
                        if (counter1 == entryPoint){
                            extension = to_string(loadImageNo);
                            
                            arrayContrastDataTemp [0][counter1+2] = "T"+extension;
                            arrayContrastDataTemp [0][counter1+3] = arrayContrastData [0][counter1+2];
                        }
                        
                        if (counter1 > entryPoint) arrayContrastDataTemp [0][counter1+3] = arrayContrastData [0][counter1+2];
                    }
                    
                    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                        arrayContrastDataTemp [counter1][0] = arrayContrastData [counter1][0];
                        arrayContrastDataTemp [counter1][1] = arrayContrastData [counter1][1];
                        arrayContrastDataTemp [counter1][2] = arrayContrastData [counter1][2];
                        
                        for (int counter2 = 1; counter2 <= entryNumber+1; counter2++){
                            if (arrayFOVNameDisplay [counter1] != "ND"){
                                if (counter2 < entryPoint) arrayContrastDataTemp [counter1][counter2+2] = arrayContrastData [counter1][counter2+2];
                                
                                if (counter2 == entryPoint){
                                    if (arrayTableDisplay [counter1*5+2] == "nil") arrayContrastDataTemp [counter1][counter2+2] = contrastDataTimePoint [counter1];
                                    else arrayContrastDataTemp [counter1][counter2+2] = arrayTableDisplay [counter1*5+2];
                                    
                                    arrayContrastDataTemp [counter1][counter2+3] = arrayContrastData [counter1][counter2+2];
                                }
                                
                                if (counter2 > entryPoint) arrayContrastDataTemp [counter1][counter2+3] = arrayContrastData [counter1][counter2+2];
                            }
                            else{
                                
                                if (counter2 < entryPoint) arrayContrastDataTemp [counter1][counter2+2] = "0";
                                
                                if (counter2 == entryPoint){
                                    arrayContrastDataTemp [counter1][counter2+2] = "0";
                                    arrayContrastDataTemp [counter1][counter2+3] = "0";
                                }
                                
                                if (counter2 > entryPoint) arrayContrastDataTemp [counter1][counter2+3] = "0";
                            }
                        }
                    }
                    
                    if (photoMetricHold == 2){
                        contrastDataTimePointCountG = 0;
                        
                        for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                            contrastDataTimePointG [contrastDataTimePointCountG] = arrayContrastDataG [counter2][timeDataUse+2], contrastDataTimePointCountG++;
                        }
                        
                        arrayContrastDataTempG [0][0] = "0";
                        arrayContrastDataTempG [0][1] = "0";
                        arrayContrastDataTempG [0][2] = "0";
                        
                        for (int counter1 = 1; counter1 <= entryNumber+1; counter1++){
                            if (counter1 < entryPoint) arrayContrastDataTempG [0][counter1+2] = arrayContrastDataG [0][counter1+2];
                            
                            if (counter1 == entryPoint){
                                extension = to_string(loadImageNo);
                                
                                arrayContrastDataTempG [0][counter1+2] = "T"+extension;
                                arrayContrastDataTempG [0][counter1+3] = arrayContrastDataG [0][counter1+2];
                            }
                            
                            if (counter1 > entryPoint) arrayContrastDataTempG [0][counter1+3] = arrayContrastDataG [0][counter1+2];
                        }
                        
                        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                            arrayContrastDataTempG [counter1][0] = arrayContrastDataG [counter1][0];
                            arrayContrastDataTempG [counter1][1] = arrayContrastDataG [counter1][1];
                            arrayContrastDataTempG [counter1][2] = arrayContrastDataG [counter1][2];
                            
                            for (int counter2 = 1; counter2 <= entryNumber+1; counter2++){
                                if (arrayFOVNameDisplay [counter1] != "ND"){
                                    if (counter2 < entryPoint) arrayContrastDataTempG [counter1][counter2+2] = arrayContrastDataG [counter1][counter2+2];
                                    
                                    if (counter2 == entryPoint){
                                        if (arrayTableDisplayG [counter1*5+2] == "nil") arrayContrastDataTempG [counter1][counter2+2] = contrastDataTimePointG [counter1];
                                        else arrayContrastDataTempG [counter1][counter2+2] = arrayTableDisplayG [counter1*5+2];
                                        
                                        arrayContrastDataTempG [counter1][counter2+3] = arrayContrastDataG [counter1][counter2+2];
                                    }
                                    
                                    if (counter2 > entryPoint) arrayContrastDataTempG [counter1][counter2+3] = arrayContrastDataG [counter1][counter2+2];
                                }
                                else{
                                    
                                    if (counter2 < entryPoint) arrayContrastDataTempG [counter1][counter2+2] = "0";
                                    
                                    if (counter2 == entryPoint){
                                        arrayContrastDataTempG [counter1][counter2+2] = "0";
                                        arrayContrastDataTempG [counter1][counter2+3] = "0";
                                    }
                                    
                                    if (counter2 > entryPoint) arrayContrastDataTempG [counter1][counter2+3] = "0";
                                }
                            }
                        }
                        
                        contrastDataTimePointCountB = 0;
                        
                        for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                            contrastDataTimePointB [contrastDataTimePointCountB] = arrayContrastDataB [counter2][timeDataUse+2], contrastDataTimePointCountB++;
                        }
                        
                        arrayContrastDataTempB [0][0] = "0";
                        arrayContrastDataTempB [0][1] = "0";
                        arrayContrastDataTempB [0][2] = "0";
                        
                        for (int counter1 = 1; counter1 <= entryNumber+1; counter1++){
                            if (counter1 < entryPoint) arrayContrastDataTempB [0][counter1+2] = arrayContrastDataB [0][counter1+2];
                            
                            if (counter1 == entryPoint){
                                extension = to_string(loadImageNo);
                                
                                arrayContrastDataTempB [0][counter1+2] = "T"+extension;
                                arrayContrastDataTempB [0][counter1+3] = arrayContrastDataB [0][counter1+2];
                            }
                            
                            if (counter1 > entryPoint) arrayContrastDataTempB [0][counter1+3] = arrayContrastDataB [0][counter1+2];
                        }
                        
                        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                            arrayContrastDataTempB [counter1][0] = arrayContrastDataB [counter1][0];
                            arrayContrastDataTempB [counter1][1] = arrayContrastDataB [counter1][1];
                            arrayContrastDataTempB [counter1][2] = arrayContrastDataB [counter1][2];
                            
                            for (int counter2 = 1; counter2 <= entryNumber+1; counter2++){
                                if (arrayFOVNameDisplay [counter1] != "ND"){
                                    if (counter2 < entryPoint) arrayContrastDataTempB [counter1][counter2+2] = arrayContrastDataB [counter1][counter2+2];
                                    
                                    if (counter2 == entryPoint){
                                        if (arrayTableDisplayB [counter1*5+2] == "nil") arrayContrastDataTempB [counter1][counter2+2] = contrastDataTimePointB [counter1];
                                        else arrayContrastDataTempB [counter1][counter2+2] = arrayTableDisplayB [counter1*5+2];
                                        
                                        arrayContrastDataTempB [counter1][counter2+3] = arrayContrastDataB [counter1][counter2+2];
                                    }
                                    
                                    if (counter2 > entryPoint) arrayContrastDataTempB [counter1][counter2+3] = arrayContrastDataB [counter1][counter2+2];
                                }
                                else{
                                    
                                    if (counter2 < entryPoint) arrayContrastDataTempB [counter1][counter2+2] = "0";
                                    
                                    if (counter2 == entryPoint){
                                        arrayContrastDataTempB [counter1][counter2+2] = "0";
                                        arrayContrastDataTempB [counter1][counter2+3] = "0";
                                    }
                                    
                                    if (counter2 > entryPoint) arrayContrastDataTempB [counter1][counter2+3] = "0";
                                }
                            }
                        }
                    }
                    
                    if (contrastDataEntry > entryNumber+1){
                        for (int counter1 = 0; counter1 < contrastDataHorizontal; counter1++){
                            delete [] arrayContrastData [counter1];
                            delete [] arrayContrastDataG [counter1];
                            delete [] arrayContrastDataB [counter1];
                        }
                        
                        delete [] arrayContrastData;
                        delete [] arrayContrastDataG;
                        delete [] arrayContrastDataB;
                        
                        arrayContrastData = new string *[contrastDataHorizontal];
                        arrayContrastDataG = new string *[contrastDataHorizontal];
                        arrayContrastDataB = new string *[contrastDataHorizontal];
                        
                        for (int counter1 = 0; counter1 < contrastDataHorizontal; counter1++){
                            arrayContrastData [counter1] = new string [contrastDataEntry+50];
                            arrayContrastDataG [counter1] = new string [contrastDataEntry+50];
                            arrayContrastDataB [counter1] = new string [contrastDataEntry+50];
                        }
                        
                        contrastDataEntry = contrastDataEntry+50;
                    }
                    
                    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                        for (int counter2 = 0; counter2 < entryNumber+4; counter2++) arrayContrastData [counter1][counter2] = arrayContrastDataTemp [counter1][counter2];
                    }
                    
                    if (photoMetricHold == 2){
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < entryNumber+4; counter2++) arrayContrastDataG [counter1][counter2] = arrayContrastDataTempG [counter1][counter2];
                        }
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < entryNumber+4; counter2++) arrayContrastDataB [counter1][counter2] = arrayContrastDataTempB [counter1][counter2];
                        }
                    }
                    
                    delete [] contrastDataTimePoint;
                    delete [] contrastDataTimePointG;
                    delete [] contrastDataTimePointB;
                    
                    for (int counter1 = 0; counter1 < contrastDataHorizontal; counter1++){
                        delete [] arrayContrastDataTemp [counter1];
                        delete [] arrayContrastDataTempG [counter1];
                        delete [] arrayContrastDataTempB [counter1];
                    }
                    
                    delete [] arrayContrastDataTemp;
                    delete [] arrayContrastDataTempG;
                    delete [] arrayContrastDataTempB;
                    
                    ofstream oin;
                    
                    if (processMode == 5 || processMode == 13 || processMode == 7){
                        string productsContrastTempPath = productsFilesTempPath+"/"+"CT-ContrastData";
                        string productsContrastTempPathG = productsFilesTempPath+"/"+"CT-ContrastDataG";
                        string productsContrastTempPathB = productsFilesTempPath+"/"+"CT-ContrastDataB";
                        
                        oin.open(productsContrastTempPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < entryNumber+4; counter2++) oin<<arrayContrastData [counter1][counter2]<<endl;
                        }
                        
                        oin.close();
                        
                        if (photoMetricHold == 2){
                            oin.open(productsContrastTempPathG.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                                for (int counter2 = 0; counter2 < entryNumber+4; counter2++) oin<<arrayContrastDataG [counter1][counter2]<<endl;
                            }
                            
                            oin.close();
                            
                            oin.open(productsContrastTempPathB.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                                for (int counter2 = 0; counter2 < entryNumber+4; counter2++) oin<<arrayContrastDataB [counter1][counter2]<<endl;
                            }
                            
                            oin.close();
                        }
                    }
                    else{
                        
                        string productsContrastPath = productsFilesInfoPath+"/"+"CT-ContrastData";
                        string productsContrastPathG = productsFilesInfoPath+"/"+"CT-ContrastDataG";
                        string productsContrastPathB = productsFilesInfoPath+"/"+"CT-ContrastDataB";
                        
                        oin.open(productsContrastPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < entryNumber+4; counter2++) oin<<arrayContrastData [counter1][counter2]<<endl;
                        }
                        
                        oin.close();
                        
                        if (photoMetricHold == 2){
                            oin.open(productsContrastPathG.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                                for (int counter2 = 0; counter2 < entryNumber+4; counter2++) oin<<arrayContrastDataG [counter1][counter2]<<endl;
                            }
                            
                            oin.close();
                            
                            oin.open(productsContrastPathB.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                                for (int counter2 = 0; counter2 < entryNumber+4; counter2++) oin<<arrayContrastDataB [counter1][counter2]<<endl;
                            }
                            
                            oin.close();
                        }
                        
                        string contrastSettingToSystemPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ContrastDataTemp-"+bodyName+"~CP";
                        
                        oin.open(contrastSettingToSystemPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastData [counter1][counter2]<<endl;
                        }
                        
                        oin.close();
                        
                        oin.open(productsContrastPathG.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < entryNumber+4; counter2++) oin<<arrayContrastDataG [counter1][counter2]<<endl;
                        }
                        
                        oin.close();
                        
                        string contrastSettingToSystemPathG = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ContrastDataTemp-"+bodyName+"~CPG";
                        
                        oin.open(contrastSettingToSystemPathG.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastDataG [counter1][counter2]<<endl;
                        }
                        
                        oin.close();
                        
                        oin.open(productsContrastPathB.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < entryNumber+4; counter2++) oin<<arrayContrastDataB [counter1][counter2]<<endl;
                        }
                        
                        oin.close();
                        
                        string contrastSettingToSystemPathB = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ContrastDataTemp-"+bodyName+"~CPB";
                        
                        oin.open(contrastSettingToSystemPathB.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastDataB [counter1][counter2]<<endl;
                        }
                        
                        oin.close();
                    }
                    
                    int writingPoint = 0;
                    
                    for (int counter1 = 1; counter1 <= entryNumber+1; counter1++){
                        timeData = arrayContrastData [0][counter1];
                        timeData = timeData.substr(1);
                        
                        if (atoi(timeData.c_str()) == loadImageNo){
                            writingPoint = counter1;
                            break;
                        }
                    }
                    
                    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                        if (arrayFOVNameDisplay [counter1] != "ND"){
                            arrayTableDisplay [counter1*5+3] = arrayContrastData [counter1][writingPoint+2];
                            arrayTableDisplay [counter1*5+4] = arrayContrastData [counter1][writingPoint+3];
                            
                            if (photoMetricHold == 2){
                                arrayTableDisplayG [counter1*5+3] = arrayContrastDataG [counter1][writingPoint+2];
                                arrayTableDisplayG [counter1*5+4] = arrayContrastDataG [counter1][writingPoint+3];
                                
                                arrayTableDisplayB [counter1*5+3] = arrayContrastDataB [counter1][writingPoint+2];
                                arrayTableDisplayB [counter1*5+4] = arrayContrastDataB [counter1][writingPoint+3];
                            }
                        }
                        else{
                            
                            arrayTableDisplay [counter1*5+3] = "0";
                            arrayTableDisplay [counter1*5+4] = "0";
                            
                            if (photoMetricHold == 2){
                                arrayTableDisplayG [counter1*5+3] = "0";
                                arrayTableDisplayG [counter1*5+4] = "0";
                                
                                arrayTableDisplayB [counter1*5+3] = "0";
                                arrayTableDisplayB [counter1*5+4] = "0";
                            }
                        }
                    }
                    
                    entryNumber++;
                    
                    if (processMode == 5 || processMode == 13 || processMode == 7){
                        oin.open(contrastSettingTempPath.c_str(), ios::out);
                        
                        extension = to_string(entryNumber);
                        oin<<extension<<endl;
                        oin.close();
                    }
                    else{
                        
                        oin.open(contrastSettingPath.c_str(), ios::out);
                        
                        extension = to_string(entryNumber);
                        oin<<extension<<endl;
                        oin.close();
                    }
                }
                
                if (processStatus == 3){
                    int timeDataUse = 1;
                    string timeDetermine;
                    
                    for (int counter2 = 1; counter2 <= entryNumber; counter2++){
                        timeDetermine = arrayContrastData [0][counter2+2];
                        timeDetermine = timeDetermine.substr(1);
                        
                        if (atoi(timeDetermine.c_str()) < currentTimePoint+1) timeDataUse = counter2;
                    }
                    
                    string *contrastDataTimePoint = new string [treatmentNameDisplayCount+50];
                    int contrastDataTimePointCount = 0;
                    string *contrastDataTimePointG = new string [treatmentNameDisplayCount+50];
                    int contrastDataTimePointCountG = 0;
                    string *contrastDataTimePointB = new string [treatmentNameDisplayCount+50];
                    int contrastDataTimePointCountB = 0;
                    
                    string **arrayContrastDataTemp = new string *[contrastDataHorizontal];
                    string **arrayContrastDataTempG = new string *[contrastDataHorizontal];
                    string **arrayContrastDataTempB = new string *[contrastDataHorizontal];
                    
                    for (int counter1 = 0; counter1 < contrastDataHorizontal; counter1++){
                        arrayContrastDataTemp [counter1] = new string [contrastDataEntry+50];
                        arrayContrastDataTempG [counter1] = new string [contrastDataEntry+50];
                        arrayContrastDataTempB [counter1] = new string [contrastDataEntry+50];
                    }
                    
                    for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                        contrastDataTimePoint [contrastDataTimePointCount] = arrayContrastData [counter2][timeDataUse+2], contrastDataTimePointCount++;
                    }
                    
                    arrayContrastDataTemp [0][0] = "0";
                    arrayContrastDataTemp [0][1] = "0";
                    arrayContrastDataTemp [0][2] = "0";
                    
                    string extension;
                    
                    for (int counter1 = 1; counter1 <= entryNumber+1; counter1++){
                        if (counter1 < entryPoint) arrayContrastDataTemp [0][counter1+2] = arrayContrastData [0][counter1+2];
                        
                        if (counter1 == entryPoint){
                            extension = to_string(loadImageNo);
                            arrayContrastDataTemp [0][counter1+2] = "T"+extension;
                        }
                    }
                    
                    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                        arrayContrastDataTemp [counter1][0] = arrayContrastData [counter1][0];
                        arrayContrastDataTemp [counter1][1] = arrayContrastData [counter1][1];
                        arrayContrastDataTemp [counter1][2] = arrayContrastData [counter1][2];
                        
                        for (int counter2 = 1; counter2 <= entryNumber; counter2++){
                            if (arrayFOVNameDisplay [counter1] != "ND") arrayContrastDataTemp [counter1][counter2+2] = arrayContrastData [counter1][counter2+2];
                            else arrayContrastDataTemp [counter1][counter2+2] = "0";
                        }
                        
                        if (arrayFOVNameDisplay [counter1] != "ND"){
                            if (arrayTableDisplay [counter1*5+2] == "nil") arrayContrastDataTemp [counter1][entryPoint+2] = contrastDataTimePoint [counter1];
                            else arrayContrastDataTemp [counter1][entryPoint+2] = arrayTableDisplay [counter1*5+2];
                        }
                        else arrayContrastDataTemp [counter1][entryPoint+2] = "0";
                    }
                    
                    if (photoMetricHold == 2){
                        contrastDataTimePointCountG = 0;
                        
                        //-----G set-----
                        for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                            contrastDataTimePointG [contrastDataTimePointCountG] = arrayContrastDataG [counter2][timeDataUse+2], contrastDataTimePointCountG++;
                        }
                        
                        arrayContrastDataTempG [0][0] = "0";
                        arrayContrastDataTempG [0][1] = "0";
                        arrayContrastDataTempG [0][2] = "0";
                        
                        for (int counter1 = 1; counter1 <= entryNumber+1; counter1++){
                            if (counter1 < entryPoint) arrayContrastDataTempG [0][counter1+2] = arrayContrastDataG [0][counter1+2];
                            
                            if (counter1 == entryPoint){
                                extension = to_string(loadImageNo);
                                arrayContrastDataTempG [0][counter1+2] = "T"+extension;
                            }
                        }
                        
                        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                            arrayContrastDataTempG [counter1][0] = arrayContrastDataG [counter1][0];
                            arrayContrastDataTempG [counter1][1] = arrayContrastDataG [counter1][1];
                            arrayContrastDataTempG [counter1][2] = arrayContrastDataG [counter1][2];
                            
                            for (int counter2 = 1; counter2 <= entryNumber; counter2++){
                                if (arrayFOVNameDisplay [counter1] != "ND") arrayContrastDataTempG [counter1][counter2+2] = arrayContrastDataG [counter1][counter2+2];
                                else arrayContrastDataTempG [counter1][counter2+2] = "0";
                            }
                            
                            if (arrayFOVNameDisplay [counter1] != "ND"){
                                if (arrayTableDisplayG [counter1*5+2] == "nil") arrayContrastDataTempG [counter1][entryPoint+2] = contrastDataTimePointG [counter1];
                                else arrayContrastDataTempG [counter1][entryPoint+2] = arrayTableDisplayG [counter1*5+2];
                            }
                            else arrayContrastDataTempG [counter1][entryPoint+2] = "0";
                        }
                        
                        //-----B set-----
                        contrastDataTimePointCountB = 0;
                        
                        for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                            contrastDataTimePointB [contrastDataTimePointCountB] = arrayContrastDataB [counter2][timeDataUse+2], contrastDataTimePointCountB++;
                        }
                        
                        arrayContrastDataTempB [0][0] = "0";
                        arrayContrastDataTempB [0][1] = "0";
                        arrayContrastDataTempB [0][2] = "0";
                        
                        for (int counter1 = 1; counter1 <= entryNumber+1; counter1++){
                            if (counter1 < entryPoint) arrayContrastDataTempB [0][counter1+2] = arrayContrastDataB [0][counter1+2];
                            
                            if (counter1 == entryPoint){
                                extension = to_string(loadImageNo);
                                arrayContrastDataTempB [0][counter1+2] = "T"+extension;
                            }
                        }
                        
                        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                            arrayContrastDataTempB [counter1][0] = arrayContrastDataB [counter1][0];
                            arrayContrastDataTempB [counter1][1] = arrayContrastDataB [counter1][1];
                            arrayContrastDataTempB [counter1][2] = arrayContrastDataB [counter1][2];
                            
                            for (int counter2 = 1; counter2 <= entryNumber; counter2++){
                                if (arrayFOVNameDisplay [counter1] != "ND") arrayContrastDataTempB [counter1][counter2+2] = arrayContrastDataB [counter1][counter2+2];
                                else arrayContrastDataTempB [counter1][counter2+2] = "0";
                            }
                            
                            if (arrayFOVNameDisplay [counter1] != "ND"){
                                if (arrayTableDisplayB [counter1*5+2] == "nil") arrayContrastDataTempB [counter1][entryPoint+2] = contrastDataTimePointB [counter1];
                                else arrayContrastDataTempB [counter1][entryPoint+2] = arrayTableDisplayB [counter1*5+2];
                            }
                            else arrayContrastDataTempB [counter1][entryPoint+2] = "0";
                        }
                    }
                    
                    if (contrastDataEntry > entryNumber+1){
                        for (int counter1 = 0; counter1 < contrastDataHorizontal; counter1++){
                            delete [] arrayContrastData [counter1];
                            delete [] arrayContrastDataG [counter1];
                            delete [] arrayContrastDataB [counter1];
                        }
                        
                        delete [] arrayContrastData;
                        delete [] arrayContrastDataG;
                        delete [] arrayContrastDataB;
                        
                        arrayContrastData = new string *[contrastDataHorizontal];
                        arrayContrastDataG = new string *[contrastDataHorizontal];
                        arrayContrastDataB = new string *[contrastDataHorizontal];
                        
                        for (int counter1 = 0; counter1 < contrastDataHorizontal; counter1++){
                            arrayContrastData [counter1] = new string [contrastDataEntry+50];
                            arrayContrastDataG [counter1] = new string [contrastDataEntry+50];
                            arrayContrastDataB [counter1] = new string [contrastDataEntry+50];
                        }
                        
                        contrastDataEntry = contrastDataEntry+50;
                    }
                    
                    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                        for (int counter2 = 0; counter2 < entryNumber+4; counter2++) arrayContrastData [counter1][counter2] = arrayContrastDataTemp [counter1][counter2];
                    }
                    
                    if (photoMetricHold == 2){
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < entryNumber+4; counter2++) arrayContrastDataG [counter1][counter2] = arrayContrastDataTempG [counter1][counter2];
                        }
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < entryNumber+4; counter2++) arrayContrastDataB [counter1][counter2] = arrayContrastDataTempB [counter1][counter2];
                        }
                    }
                    
                    delete [] contrastDataTimePoint;
                    delete [] contrastDataTimePointG;
                    delete [] contrastDataTimePointB;
                    
                    for (int counter1 = 0; counter1 < contrastDataHorizontal; counter1++){
                        delete [] arrayContrastDataTemp [counter1];
                        delete [] arrayContrastDataTempG [counter1];
                        delete [] arrayContrastDataTempB [counter1];
                    }
                    
                    delete [] arrayContrastDataTemp;
                    delete [] arrayContrastDataTempG;
                    delete [] arrayContrastDataTempB;
                    
                    ofstream oin;
                    
                    if (processMode == 5 || processMode == 13 || processMode == 7){
                        string productsContrastTempPath = productsFilesTempPath+"/"+"CT-ContrastData";
                        string productsContrastTempPathG = productsFilesTempPath+"/"+"CT-ContrastDataG";
                        string productsContrastTempPathB = productsFilesTempPath+"/"+"CT-ContrastDataB";
                        
                        oin.open(productsContrastTempPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < entryNumber+4; counter2++) oin<<arrayContrastData [counter1][counter2]<<endl;
                        }
                        
                        oin.close();
                        
                        if (photoMetricHold == 2){
                            oin.open(productsContrastTempPathG.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                                for (int counter2 = 0; counter2 < entryNumber+4; counter2++) oin<<arrayContrastDataG [counter1][counter2]<<endl;
                            }
                            
                            oin.close();
                            
                            oin.open(productsContrastTempPathB.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                                for (int counter2 = 0; counter2 < entryNumber+4; counter2++) oin<<arrayContrastDataB [counter1][counter2]<<endl;
                            }
                            
                            oin.close();
                        }
                    }
                    else{
                        
                        string productsContrastPath = productsFilesInfoPath+"/"+"CT-ContrastData";
                        string productsContrastPathG = productsFilesInfoPath+"/"+"CT-ContrastDataG";
                        string productsContrastPathB = productsFilesInfoPath+"/"+"CT-ContrastDataB";
                        
                        oin.open(productsContrastPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < entryNumber+4; counter2++) oin<<arrayContrastData [counter1][counter2]<<endl;
                        }
                        
                        oin.close();
                        
                        if (photoMetricHold == 2){
                            oin.open(productsContrastPathG.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                                for (int counter2 = 0; counter2 < entryNumber+4; counter2++) oin<<arrayContrastDataG [counter1][counter2]<<endl;
                            }
                            
                            oin.close();
                            
                            oin.open(productsContrastPathB.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                                for (int counter2 = 0; counter2 < entryNumber+4; counter2++) oin<<arrayContrastDataB [counter1][counter2]<<endl;
                            }
                            
                            oin.close();
                        }
                        
                        string contrastSettingToSystemPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ContrastDataTemp-"+bodyName+"~CP";
                        
                        oin.open(contrastSettingToSystemPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastData [counter1][counter2]<<endl;
                        }
                        
                        oin.close();
                        
                        oin.open(productsContrastPathG.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < entryNumber+4; counter2++) oin<<arrayContrastDataG [counter1][counter2]<<endl;
                        }
                        
                        oin.close();
                        
                        string contrastSettingToSystemPathG = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ContrastDataTemp-"+bodyName+"~CPG";
                        
                        oin.open(contrastSettingToSystemPathG.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastDataG [counter1][counter2]<<endl;
                        }
                        
                        oin.close();
                        
                        oin.open(productsContrastPathB.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < entryNumber+4; counter2++) oin<<arrayContrastDataB [counter1][counter2]<<endl;
                        }
                        
                        oin.close();
                        
                        string contrastSettingToSystemPathB = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ContrastDataTemp-"+bodyName+"~CPB";
                        
                        oin.open(contrastSettingToSystemPathB.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                            for (int counter2 = 0; counter2 < entryNumber+3; counter2++) oin<<arrayContrastDataB [counter1][counter2]<<endl;
                        }
                        
                        oin.close();
                    }
                    
                    int writingPoint = 0;
                    
                    for (int counter1 = 1; counter1 <= entryNumber+1; counter1++){
                        timeData = arrayContrastData [0][counter1];
                        timeData = timeData.substr(1);
                        
                        if (atoi(timeData.c_str()) == loadImageNo){
                            writingPoint = counter1;
                            break;
                        }
                    }
                    
                    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                        if (arrayFOVNameDisplay [counter1] != "ND"){
                            arrayTableDisplay [counter1*5+3] = arrayContrastData [counter1][writingPoint+2];
                            arrayTableDisplay [counter1*5+4] = "0";
                            
                            if (photoMetricHold == 2){
                                arrayTableDisplayG [counter1*5+3] = arrayContrastDataG [counter1][writingPoint+2];
                                arrayTableDisplayG [counter1*5+4] = "0";
                                
                                arrayTableDisplayB [counter1*5+3] = arrayContrastDataB [counter1][writingPoint+2];
                                arrayTableDisplayB [counter1*5+4] = "0";
                            }
                        }
                        else{
                            
                            arrayTableDisplay [counter1*5+3] = "0";
                            arrayTableDisplay [counter1*5+4] = "0";
                            
                            if (photoMetricHold == 2){
                                arrayTableDisplayG [counter1*5+3] = "0";
                                arrayTableDisplayG [counter1*5+4] = "0";
                                
                                arrayTableDisplayB [counter1*5+3] = "0";
                                arrayTableDisplayB [counter1*5+4] = "0";
                            }
                        }
                    }
                    
                    entryNumber++;
                    
                    if (processMode == 5 || processMode == 13 || processMode == 7){
                        oin.open(contrastSettingTempPath.c_str(), ios::out);
                        
                        extension = to_string(entryNumber);
                        oin<<extension<<endl;
                        oin.close();
                    }
                    else{
                        
                        oin.open(contrastSettingPath.c_str(), ios::out);
                        
                        extension = to_string(entryNumber);
                        oin<<extension<<endl;
                        oin.close();
                    }
                }
                
                int startingTimePoint = entryPoint;
                
                subprocesses = [[SubProcesses alloc] init];
                [subprocesses displayTableSet:startingTimePoint];
                
                tableViewCall = 1;
            }
            
            if (processMode == 2 || processMode == 8 || processMode == 10 || processMode == 3 || processMode == 9 || processMode == 11){
                string *xyPositionHoldTemp = new string [treatmentNameDisplayCount*3];
                string *xyPositionIFHoldTemp = new string [treatmentNameDisplayCount*3];
                string *xyPositionHoldCurrent = new string [treatmentNameDisplayCount*3];
                string *xyPositionHoldIF = new string [treatmentNameDisplayCount*3];
                int xyPositionHoldCurrentCount = 0;
                int xyPositionHoldIFCount = 0;
                
                ifstream fin;
                
                if (statusIFHold == 0 || statusIFHold == 3){
                    fin.open(fovPositionPath.c_str(), ios::in);
                    
                    xyPositionHoldCurrentCount = 0;
                    string getString;
                    
                    if (fin.is_open()){
                        do{
                            
                            getline(fin, getString);
                            
                            xyPositionHoldCurrent [xyPositionHoldCurrentCount] = getString, xyPositionHoldCurrentCount++;
                            
                            if (getString == "ND") xyPositionHoldCurrent [xyPositionHoldCurrentCount] = getString, xyPositionHoldCurrentCount++;
                            
                        } while (getString != "");
                        
                        fin.close();
                    }
                }
                
                if (statusIFHold == 1 || statusIFHold == 2){
                    fin.open(fovPositionPath.c_str(), ios::in);
                    
                    xyPositionHoldCurrentCount = 0;
                    string getString;
                    
                    if (fin.is_open()){
                        do{
                            
                            getline(fin, getString);
                            
                            xyPositionHoldCurrent [xyPositionHoldCurrentCount] = getString, xyPositionHoldCurrentCount++;
                            
                            if (getString == "ND") xyPositionHoldCurrent [xyPositionHoldCurrentCount] = getString, xyPositionHoldCurrentCount++;
                            
                        } while (getString != "");
                        
                        fin.close();
                    }
                    
                    fin.open(fovPositionIFHoldPath.c_str(), ios::in);
                    
                    xyPositionHoldIFCount = 0;
                    
                    if (fin.is_open()){
                        do{
                            
                            getline(fin, getString);
                            
                            xyPositionHoldIF [xyPositionHoldIFCount] = getString, xyPositionHoldIFCount++;
                            
                            if (getString == "ND") xyPositionHoldIF [xyPositionHoldIFCount] = getString, xyPositionHoldIFCount++;
                            
                        } while (getString != "");
                        
                        fin.close();
                    }
                }
                
                string extractString = loadImageTreatName.substr(loadImageTreatName.length()-3, 2);
                string treatString;
                string readName;
                
                if (extractString == "CH") treatString = loadImageTreatName.substr(0, loadImageTreatName.length()-3);
                else treatString = loadImageTreatName;
                
                int setFirstTime = 0;
                
                for (int counter1 = 0; counter1 < xyPositionHoldCurrentCount; counter1++){
                    readName = xyPositionHoldCurrent [counter1];
                    
                    if ((int)readName.find(treatString) != -1){
                        setFirstTime = 1;
                        break;
                    }
                }
                
                int stitchDimensionTemp = 0;
                int startX = 0;
                int startY = 0;
                saveStatus = setFirstTime;
                
                //-----If FOV is not set initially, determine stitch dimensions using DIC and other channel-----
                if (setFirstTime == 1 && (statusIFHold == 0 || statusIFHold == 3)){
                    int largestX = -10000000;
                    int smallestX = 10000000;
                    int largestY = -10000000;
                    int smallestY = 10000000;
                    int readStartFlag = 0;
                    
                    for (int counter1 = 0; counter1 < xyPositionHoldCurrentCount/2; counter1++){
                        if (xyPositionHoldCurrent [counter1*2] == loadImageTreatName && readStartFlag == 0){
                            readStartFlag = 1;
                            
                            for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                                if (largestX < arrayXYWritingPosition [counter2*2]) largestX = arrayXYWritingPosition [counter2*2];
                                if (smallestX > arrayXYWritingPosition [counter2*2]) smallestX = arrayXYWritingPosition [counter2*2];
                                if (largestY < arrayXYWritingPosition [counter2*2+1]) largestY = arrayXYWritingPosition [counter2*2+1];
                                if (smallestY > arrayXYWritingPosition [counter2*2+1]) smallestY = arrayXYWritingPosition [counter2*2+1];
                            }
                        }
                        else if ((int)xyPositionHoldCurrent [counter1*2].find(treatString) != -1 && xyPositionHoldCurrent [counter1*2] != loadImageTreatName && readStartFlag == 0){
                            readStartFlag = 1;
                        }
                        else if (readStartFlag == 1 && xyPositionHoldCurrent [counter1*2] != "ND"){
                            if (largestX < atoi(xyPositionHoldCurrent [counter1*2].c_str())) largestX = atoi(xyPositionHoldCurrent [counter1*2].c_str());
                            if (smallestX > atoi(xyPositionHoldCurrent [counter1*2].c_str())) smallestX = atoi(xyPositionHoldCurrent [counter1*2].c_str());
                            if (largestY < atoi(xyPositionHoldCurrent [counter1*2+1].c_str())) largestY = atoi(xyPositionHoldCurrent [counter1*2+1].c_str());
                            if (smallestY > atoi(xyPositionHoldCurrent [counter1*2+1].c_str())) smallestY = atoi(xyPositionHoldCurrent [counter1*2+1].c_str());
                        }
                        else if (readStartFlag == 1 && xyPositionHoldCurrent [counter1*2] == "ND") readStartFlag = 0;
                    }
                    
                    if (largestX-smallestX > largestY-smallestY){
                        stitchDimensionTemp = ((largestX-smallestX+imageDimensionX)/4)*4;
                        startX = smallestX-80;
                        startY = smallestY-(stitchDimensionTemp-(largestY-smallestY+imageDimensionY))/2-80;
                    }
                    else{
                        
                        stitchDimensionTemp = ((largestY-smallestY+imageDimensionY)/4)*4;
                        startX = smallestX-(stitchDimensionTemp-(largestX-smallestX+imageDimensionX))/2-80;
                        startY = smallestY-80;
                    }
                    
                    stitchDimensionTemp = stitchDimensionTemp+160; //============
                    
                    if (statusIFHold == 3) stitchDimensionTemp = stitchImageDimension; //============
                }
                
                //----- If FOV is not set initially, use the IF mode-----
                if (statusIFHold == 1 || statusIFHold == 2){
                    int largestX = -10000000;
                    int smallestX = 10000000;
                    int largestY = -10000000;
                    int smallestY = 10000000;
                    int readStartFlag = 0;
                    
                    for (int counter1 = 0; counter1 < xyPositionHoldIFCount/2; counter1++){
                        if (xyPositionHoldCurrent [counter1*2] == treatString && readStartFlag == 0){
                            readStartFlag = 1;
                        }
                        else if (readStartFlag == 1 && xyPositionHoldIF [counter1*2] != "ND"){
                            if (largestX < atoi(xyPositionHoldIF [counter1*2].c_str())) largestX = atoi(xyPositionHoldIF [counter1*2].c_str());
                            if (smallestX > atoi(xyPositionHoldIF [counter1*2].c_str())) smallestX = atoi(xyPositionHoldIF [counter1*2].c_str());
                            if (largestY < atoi(xyPositionHoldIF [counter1*2+1].c_str())) largestY = atoi(xyPositionHoldIF [counter1*2+1].c_str());
                            if (smallestY > atoi(xyPositionHoldIF [counter1*2+1].c_str())) smallestY = atoi(xyPositionHoldIF [counter1*2+1].c_str());
                        }
                        else if (readStartFlag == 1 && xyPositionHoldIF [counter1*2] == "ND") readStartFlag = 0;
                    }
                    
                    if (largestX-smallestX > largestY-smallestY){
                        stitchDimensionTemp = ((largestX-smallestX+imageDimensionX)/4)*4;
                        startX = smallestX-80;
                        startY = smallestY-(stitchDimensionTemp-(largestY-smallestY+imageDimensionY))/2-80;
                    }
                    else{
                        
                        stitchDimensionTemp = ((largestY-smallestY+imageDimensionY)/4)*4;
                        startX = smallestX-(stitchDimensionTemp-(largestX-smallestX+imageDimensionX))/2-80;
                        startY = smallestY-80;
                    }
                    
                    stitchDimensionTemp = stitchImageDimension; //============
                }
                
                int xyPositionCount = 0;
                int largestX = 0;
                int smallestX = 0;
                int largestY = 0;
                int smallestY = 0;
                int treatFind = 0;
                int xyPositionSetTempCount = 0;
                int readStartFlag = 0;
                
                string treatName;
                string treatString2;
                string getString;
                
                //=======Fluorescent set first time check=========
                int stitchImageDimensionFluorescentFirst = 0;
                int fluorescentFirstFind = 0;
                int fluorescentStartX = 0;
                int fluorescentStartY = 0;
                int setFlag = 0;
                
                string loadedExtractString = loadImageTreatName.substr(loadImageTreatName.length()-3, 2);
                string loadedNameString;
                
                if (loadedExtractString == "CH"){
                    loadedNameString = loadImageTreatName.substr(0, loadImageTreatName.length()-3);
                }
                else loadedNameString = loadImageTreatName;
                
                largestX = -10000000;
                smallestX = 10000000;
                largestY = -10000000;
                smallestY = 10000000;
                
                for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                    if (arrayTreatmentNameDisplay [counter1] != "ND"){
                        treatName = arrayTreatmentNameDisplay [counter1];
                        extractString = treatName.substr(treatName.length()-3, 2);
                        
                        if (extractString == "CH") treatString2 = treatName.substr(0, treatName.length()-3);
                        else treatString2 = treatName;
                        
                        //cout<<treatName<<" "<<treatString2<<" "<<arrayTreatmentNameDisplay [counter1].substr(arrayTreatmentNameDisplay [counter1].length()-1, 1)<<" "<<extractString<<" "<<loadedNameString<<" Info"<<endl;
                        
                        if (setFirstTime == 0 && statusIFHold == 0 && loadedNameString == treatString2){
                            setFlag = 0;
                            
                            if (extractString == "CH" && arrayTreatmentNameDisplay [counter1].substr(arrayTreatmentNameDisplay [counter1].length()-1, 1) == "1" && channelAdjustFirstSet1 == 1){
                                for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                                    if (largestX < arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX1) largestX = arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX1;
                                    if (smallestX > arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX1) smallestX = arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX1;
                                    if (largestY < arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY1) largestY = arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY1;
                                    if (smallestY > arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY1) smallestY = arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY1;
                                }
                                
                                fluorescentFirstFind = 1;
                                setFlag = 1;
                            }
                            else if (extractString == "CH" && arrayTreatmentNameDisplay [counter1].substr(arrayTreatmentNameDisplay [counter1].length()-1, 1) == "2" && channelAdjustFirstSet2 == 1){
                                for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                                    if (largestX < arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX2) largestX = arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX2;
                                    if (smallestX > arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX2) smallestX = arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX2;
                                    if (largestY < arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY2) largestY = arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY2;
                                    if (smallestY > arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY2) smallestY = arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY2;
                                }
                                
                                fluorescentFirstFind = 1;
                                setFlag = 1;
                            }
                            else if (extractString == "CH" && arrayTreatmentNameDisplay [counter1].substr(arrayTreatmentNameDisplay [counter1].length()-1, 1) == "3" && channelAdjustFirstSet3 == 1){
                                for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                                    if (largestX < arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX3) largestX = arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX3;
                                    if (smallestX > arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX3) smallestX = arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX3;
                                    if (largestY < arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY3) largestY = arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY3;
                                    if (smallestY > arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY3) smallestY = arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY3;
                                }
                                
                                fluorescentFirstFind = 1;
                                setFlag = 1;
                            }
                            else if (extractString == "CH" && arrayTreatmentNameDisplay [counter1].substr(arrayTreatmentNameDisplay [counter1].length()-1, 1) == "4" && channelAdjustFirstSet3 == 1){
                                for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                                    if (largestX < arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX4) largestX = arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX4;
                                    if (smallestX > arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX4) smallestX = arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX4;
                                    if (largestY < arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY4) largestY = arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY4;
                                    if (smallestY > arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY4) smallestY = arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY4;
                                }
                                
                                fluorescentFirstFind = 1;
                                setFlag = 1;
                            }
                            else if (extractString == "CH" && arrayTreatmentNameDisplay [counter1].substr(arrayTreatmentNameDisplay [counter1].length()-1, 1) == "5" && channelAdjustFirstSet3 == 1){
                                for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                                    if (largestX < arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX5) largestX = arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX5;
                                    if (smallestX > arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX5) smallestX = arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX5;
                                    if (largestY < arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY5) largestY = arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY5;
                                    if (smallestY > arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY5) smallestY = arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY5;
                                }
                                
                                fluorescentFirstFind = 1;
                                setFlag = 1;
                            }
                            else if (extractString == "CH" && arrayTreatmentNameDisplay [counter1].substr(arrayTreatmentNameDisplay [counter1].length()-1, 1) == "6" && channelAdjustFirstSet3 == 1){
                                for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                                    if (largestX < arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX6) largestX = arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX6;
                                    if (smallestX > arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX6) smallestX = arrayXYWritingPosition [(counter2+1)*2]-channelAdjustHoldX6;
                                    if (largestY < arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY6) largestY = arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY6;
                                    if (smallestY > arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY6) smallestY = arrayXYWritingPosition [(counter2+1)*2+1]+channelAdjustHoldY6;
                                }
                                
                                fluorescentFirstFind = 1;
                                setFlag = 1;
                            }
                            
                            if (setFlag == 0){
                                for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                                    if (largestX < arrayXYWritingPosition [counter2*2]) largestX = arrayXYWritingPosition [counter2*2];
                                    if (smallestX > arrayXYWritingPosition [counter2*2]) smallestX = arrayXYWritingPosition [counter2*2];
                                    if (largestY < arrayXYWritingPosition [counter2*2+1]) largestY = arrayXYWritingPosition [counter2*2+1];
                                    if (smallestY > arrayXYWritingPosition [counter2*2+1]) smallestY = arrayXYWritingPosition [counter2*2+1];
                                }
                            }
                            
                            if (largestX-smallestX > largestY-smallestY){
                                stitchDimensionTemp = ((largestX-smallestX+imageDimensionX)/4)*4;
                            }
                            else stitchDimensionTemp = ((largestY-smallestY+imageDimensionY)/4)*4;
                            
                            if (stitchImageDimensionFluorescentFirst < stitchDimensionTemp+160){
                                stitchImageDimensionFluorescentFirst = stitchDimensionTemp+160;
                                
                                if (largestX-smallestX > largestY-smallestY){
                                    fluorescentStartX = smallestX-80;
                                    fluorescentStartY = smallestY-(stitchDimensionTemp-(largestY-smallestY+imageDimensionY))/2-80;
                                }
                                else{
                                    
                                    fluorescentStartX = smallestX-(stitchDimensionTemp-(largestX-smallestX+imageDimensionX))/2-80;
                                    fluorescentStartY = smallestY-80;
                                }
                            }
                        }
                    }
                }
                
                int xAdjust = 0;
                int yAdjust = 0;
                
                for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                    if (arrayTreatmentNameDisplay [counter1] != "ND"){
                        treatName = arrayTreatmentNameDisplay [counter1];
                        extractString = treatName.substr(treatName.length()-3, 2);
                        
                        if (extractString == "CH") treatString2 = treatName.substr(0, treatName.length()-3);
                        else treatString2 = treatName;
                        
                        if (setFirstTime == 0 && (statusIFHold == 0 || statusIFHold == 3)){
                            if (treatString == treatString2){
                                xAdjust = 0;
                                yAdjust = 0;
                                
                                if (extractString == "CH" && arrayTreatmentNameDisplay [counter1].substr(arrayTreatmentNameDisplay [counter1].length()-1, 1) == "1" && channelAdjustFirstSet1 == 1){
                                    xAdjust = channelAdjustHoldX1;
                                    yAdjust = channelAdjustHoldY1;
                                }
                                else if (extractString == "CH" && arrayTreatmentNameDisplay [counter1].substr(arrayTreatmentNameDisplay [counter1].length()-1, 1) == "2" && channelAdjustFirstSet2 == 1){
                                    xAdjust = channelAdjustHoldX2;
                                    yAdjust = channelAdjustHoldY2;
                                }
                                else if (extractString == "CH" && arrayTreatmentNameDisplay [counter1].substr(arrayTreatmentNameDisplay [counter1].length()-1, 1) == "3" && channelAdjustFirstSet3 == 1){
                                    xAdjust = channelAdjustHoldX3;
                                    yAdjust = channelAdjustHoldY3;
                                }
                                else if (extractString == "CH" && arrayTreatmentNameDisplay [counter1].substr(arrayTreatmentNameDisplay [counter1].length()-1, 1) == "4" && channelAdjustFirstSet4 == 1){
                                    xAdjust = channelAdjustHoldX4;
                                    yAdjust = channelAdjustHoldY4;
                                }else if (extractString == "CH" && arrayTreatmentNameDisplay [counter1].substr(arrayTreatmentNameDisplay [counter1].length()-1, 1) == "5" && channelAdjustFirstSet5 == 1){
                                    xAdjust = channelAdjustHoldX5;
                                    yAdjust = channelAdjustHoldY5;
                                }
                                else if (extractString == "CH" && arrayTreatmentNameDisplay [counter1].substr(arrayTreatmentNameDisplay [counter1].length()-1, 1) == "6" && channelAdjustFirstSet6 == 1){
                                    xAdjust = channelAdjustHoldX6;
                                    yAdjust = channelAdjustHoldY6;
                                }
                                
                                largestX = -10000000;
                                smallestX = 10000000;
                                largestY = -10000000;
                                smallestY = 10000000;
                                
                                for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                                    if (largestX < arrayXYWritingPosition [counter2*2]) largestX = arrayXYWritingPosition [counter2*2];
                                    if (smallestX > arrayXYWritingPosition [counter2*2]) smallestX = arrayXYWritingPosition [counter2*2];
                                    if (largestY < arrayXYWritingPosition [counter2*2+1]) largestY = arrayXYWritingPosition [counter2*2+1];
                                    if (smallestY > arrayXYWritingPosition [counter2*2+1]) smallestY = arrayXYWritingPosition [counter2*2+1];
                                }
                                
                                if (largestX-smallestX > largestY-smallestY){
                                    stitchDimensionTemp = ((largestX-smallestX+imageDimensionX)/4)*4;
                                    startX = smallestX-80;
                                    startY = smallestY-(stitchDimensionTemp-(largestY-smallestY+imageDimensionY))/2-80;
                                }
                                else{
                                    
                                    stitchDimensionTemp = ((largestY-smallestY+imageDimensionY)/4)*4;
                                    startX = smallestX-(stitchDimensionTemp-(largestX-smallestX+imageDimensionX))/2-80;
                                    startY = smallestY-80;
                                }
                                
                                stitchDimensionTemp = stitchDimensionTemp+160;
                                
                                if (statusIFHold == 3) stitchDimensionTemp = stitchImageDimension; //============
                                
                                if (fluorescentFirstFind == 1){ //-----For fluorescent setups, override stitch dimensions, startX, and startY-----
                                    stitchDimensionTemp = stitchImageDimensionFluorescentFirst;
                                    startX = fluorescentStartX;
                                    startY = fluorescentStartY;
                                }
                                
                                int *xyPositionSetTemp = new int [loadImageFOVNo*2+50];
                                
                                for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                                    xyPositionSetTemp [counter2*2] = arrayXYWritingPosition [counter2*2]-startX-xAdjust;
                                    xyPositionSetTemp [counter2*2+1] = arrayXYWritingPosition [counter2*2+1]-startY+yAdjust;
                                }
                                
                                xyPositionHoldTemp [xyPositionCount] = treatName, xyPositionCount++;
                                xyPositionHoldTemp [xyPositionCount] = to_string(stitchDimensionTemp), xyPositionCount++; //============
                                
                                for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                                    xyPositionHoldTemp [xyPositionCount] = to_string(xyPositionSetTemp [counter2*2]), xyPositionCount++;
                                    xyPositionHoldTemp [xyPositionCount] = to_string(xyPositionSetTemp [counter2*2+1]), xyPositionCount++;
                                }
                                
                                xyPositionHoldTemp [xyPositionCount] = "ND", xyPositionCount++;
                                
                                delete [] xyPositionSetTemp;
                                
                                //for (int counterA = 0; counterA < xyPositionCount; counterA++){
                                //    cout<<" "<<xyPositionHoldTemp [counterA]<<" xyPositionHoldTemp  "<<counterA+1<<endl;
                                //}
                            }
                            else{
                                
                                struct stat sizeOfFile;
                                int fileOpenCheck = 0;
                                
                                if (processMode == 5 || processMode == 13 || processMode == 7){
                                    fileOpenCheck = stat(fovPositionTempPath.c_str(), &sizeOfFile);
                                }
                                else{
                                    
                                    fileOpenCheck = stat(fovPositionPath.c_str(), &sizeOfFile);
                                }
                                
                                if (fileOpenCheck == 0){
                                    treatFind = 0;
                                    
                                    if (processMode == 5 || processMode == 13 || processMode == 7){
                                        fin.open(fovPositionTempPath.c_str(), ios::in);
                                    }
                                    else fin.open(fovPositionPath.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        do{
                                            
                                            getline(fin, getString);
                                            
                                            if (treatName == getString && treatFind == 0){
                                                xyPositionHoldTemp [xyPositionCount] = getString, xyPositionCount++;
                                                treatFind = 1;
                                            }
                                            else if (getString != "ND" && treatFind == 1){
                                                xyPositionHoldTemp [xyPositionCount] = getString, xyPositionCount++;
                                            }
                                            else if (getString == "ND" && treatFind == 1){
                                                xyPositionHoldTemp [xyPositionCount] = getString, xyPositionCount++;
                                                treatFind = 2;
                                            }
                                            
                                        } while (getString != "");
                                        
                                        fin.close();
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < xyPositionCount; counterA++){
                                //    cout<<" "<<xyPositionHoldTemp [counterA]<<" xyPositionHoldTemp "<<counterA+1<<endl;
                                //}
                            }
                        }
                        else if (treatString == treatString2){
                            if (treatName == loadImageTreatName){
                                int *xyPositionSetTemp = new int [loadImageFOVNo*2+50];
                                
                                for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                                    xyPositionSetTemp [counter2*2] = arrayXYWritingPosition [counter2*2]-startX;
                                    xyPositionSetTemp [counter2*2+1] = arrayXYWritingPosition [counter2*2+1]-startY;
                                }
                                
                                xyPositionHoldTemp [xyPositionCount] = treatName, xyPositionCount++;
                                xyPositionHoldTemp [xyPositionCount] = to_string(stitchDimensionTemp), xyPositionCount++; //=============
                                
                                for (int counter2 = 1; counter2 <= loadImageFOVNo; counter2++){
                                    xyPositionHoldTemp [xyPositionCount] = to_string(xyPositionSetTemp [counter2*2]), xyPositionCount++;
                                    xyPositionHoldTemp [xyPositionCount] = to_string(xyPositionSetTemp [counter2*2+1]), xyPositionCount++;
                                }
                                
                                xyPositionHoldTemp [xyPositionCount] = "ND", xyPositionCount++;
                                
                                delete [] xyPositionSetTemp;
                            }
                            else{
                                
                                int *xyPositionSetTemp = new int [loadImageFOVNo*2+50];
                                xyPositionSetTempCount = 0;
                                
                                readStartFlag = 0;
                                
                                for (int counter2 = 0; counter2 < xyPositionHoldCurrentCount/2; counter2++){
                                    if (xyPositionHoldCurrent [counter2*2] == treatName){
                                        readStartFlag = 1;
                                    }
                                    else if (readStartFlag == 1 && xyPositionHoldCurrent [counter2*2] != "ND"){
                                        xyPositionSetTemp [xyPositionSetTempCount] = atoi(xyPositionHoldCurrent [counter2*2].c_str())-startX, xyPositionSetTempCount++;
                                        xyPositionSetTemp [xyPositionSetTempCount] = atoi(xyPositionHoldCurrent [counter2*2+1].c_str())-startY, xyPositionSetTempCount++;
                                    }
                                    else if (readStartFlag == 1 && xyPositionHoldCurrent [counter2*2] == "ND"){
                                        break;
                                    }
                                }
                                
                                xyPositionHoldTemp [xyPositionCount] = treatName, xyPositionCount++;
                                xyPositionHoldTemp [xyPositionCount] = to_string(stitchDimensionTemp), xyPositionCount++; //=============
                                
                                for (int counter2 = 0; counter2 < xyPositionSetTempCount/2; counter2++){
                                    xyPositionHoldTemp [xyPositionCount] = to_string(xyPositionSetTemp [counter2*2]), xyPositionCount++;
                                    xyPositionHoldTemp [xyPositionCount] = to_string(xyPositionSetTemp [counter2*2+1]), xyPositionCount++;
                                }
                                
                                xyPositionHoldTemp [xyPositionCount] = "ND", xyPositionCount++;
                                
                                delete [] xyPositionSetTemp;
                            }
                        }
                        else{
                            
                            struct stat sizeOfFile;
                            int fileOpenCheck = 0;
                            
                            if (processMode == 5 || processMode == 13 || processMode == 7){
                                fileOpenCheck = stat(fovPositionTempPath.c_str(), &sizeOfFile);
                            }
                            else{
                                
                                fileOpenCheck = stat(fovPositionPath.c_str(), &sizeOfFile);
                            }
                            
                            if (fileOpenCheck == 0){
                                treatFind = 0;
                                
                                if (processMode == 5 || processMode == 13 || processMode == 7){
                                    fin.open(fovPositionTempPath.c_str(), ios::in);
                                }
                                else fin.open(fovPositionPath.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    do{
                                        
                                        getline(fin, getString);
                                        
                                        if (treatName == getString && treatFind == 0){
                                            xyPositionHoldTemp [xyPositionCount] = getString, xyPositionCount++;
                                            treatFind = 1;
                                        }
                                        else if (getString != "ND" && treatFind == 1){
                                            xyPositionHoldTemp [xyPositionCount] = getString, xyPositionCount++;
                                        }
                                        else if (getString == "ND" && treatFind == 1){
                                            xyPositionHoldTemp [xyPositionCount] = getString, xyPositionCount++;
                                            treatFind = 2;
                                        }
                                        
                                    } while (getString != "");
                                    
                                    fin.close();
                                }
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < xyPositionCount; counterA++){
                //    cout<<" "<<xyPositionHoldTemp [counterA]<<" xyPositionHoldTemp "<<counterA+1<<endl;
                //}
                
                ofstream oin;
                
                oin.open(fovPositionPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < xyPositionCount; counter1++) oin<<xyPositionHoldTemp [counter1]<<endl;
                
                oin.close();
                
                delete [] xyPositionHoldTemp;
                delete [] xyPositionIFHoldTemp;
                delete [] xyPositionHoldCurrent;
                delete [] xyPositionHoldIF;
            }
            
            firstDataSetFlag = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Data Set"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Entry Limit Reached"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    
    return saveStatus;
}

@end
