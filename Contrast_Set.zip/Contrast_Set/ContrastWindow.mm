//
//  ContrastWindow.m
//  Contrast_Set
//
//  Created by Masahiko Sato on 2014-04-19.
//
//

#import "ContrastWindow.h"

NSString *notificationToContrastWindow = @"notificationExecuteContrastWindow";

@implementation ContrastWindow

- (id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    
    if (self) {
        contrastImage = [[NSImage alloc] initWithContentsOfFile:@""];
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToContrastWindow object:nil];
    }
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [self setNeedsDisplay:YES];
}

-(void)mouseDown:(NSEvent *)event{
    if (autoProcessingFlag == 0){
        NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
        
        if (contrastOADisplay == "On" && backgroundOADisplay == "Off" && processingFovNo != 0){
            if (rgbDisplayStatus == 0 || rgbDisplayStatus == 1){
                if (currentFOVNoHold == 0) currentFOVNoHold = processingFovNo;
                else if (currentFOVNoHold != processingFovNo){
                    currentFOVNoHold = processingFovNo;
                    
                    if (currentFOVNoHold != -1) contrastValueDisplay = contrastValueHold [currentFOVNoHold];
                    else contrastValueDisplay = contrastValueHold [loadImageFOVNo+1];
                }
            }
            else if (rgbDisplayStatus == 2){
                if (currentFOVNoHold == 0) currentFOVNoHold = processingFovNo;
                else if (currentFOVNoHold != processingFovNo){
                    currentFOVNoHold = processingFovNo;
                    
                    if (currentFOVNoHold != -1) contrastValueDisplayG = contrastValueHoldG [currentFOVNoHold];
                    else contrastValueDisplayG = contrastValueHoldG [loadImageFOVNo+1];
                }
            }
            else if (rgbDisplayStatus == 3){
                if (currentFOVNoHold == 0) currentFOVNoHold = processingFovNo;
                else if (currentFOVNoHold != processingFovNo){
                    currentFOVNoHold = processingFovNo;
                    
                    if (currentFOVNoHold != -1) contrastValueDisplayB = contrastValueHoldB [currentFOVNoHold];
                    else contrastValueDisplayB = contrastValueHoldB [loadImageFOVNo+1];
                }
            }
            
            xPointDownCont = clickPoint.x;
            selectProcessLine = 0;
            
            if (rgbDisplayStatus == 0 || rgbDisplayStatus == 1){
                if (contrastValueDisplay*0.85*100+129 > xPointDownCont-10 && contrastValueDisplay*0.85*100+129 < xPointDownCont+10) selectProcessLine = 1;
            }
            else if (rgbDisplayStatus == 2){
                if (contrastValueDisplayG*0.85*100+129 > xPointDownCont-10 && contrastValueDisplayG*0.85*100+129 < xPointDownCont+10) selectProcessLine = 1;
            }
            else if (rgbDisplayStatus == 3){
                if (contrastValueDisplayB*0.85*100+129 > xPointDownCont-10 && contrastValueDisplayB*0.85*100+129 < xPointDownCont+10) selectProcessLine = 1;
            }
            
            [self setNeedsDisplay:YES];
        }
    }
}

-(void)mouseDragged:(NSEvent *)event{
    if (autoProcessingFlag == 0){
        NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
        
        if (contrastOADisplay == "On" && backgroundOADisplay == "Off" && processingFovNo != 0){
            xPointDragCont = clickPoint.x;
            
            if (selectProcessLine == 1){
                if (rgbDisplayStatus == 0 || rgbDisplayStatus == 1){
                    contrastValueDisplay = contrastValueDisplay-(xPointDownCont-xPointDragCont)/(double)0.85/(double)100;
                    xPointDownCont = xPointDragCont;
                    contrastBarActivate = 1;
                    
                    if (contrastValueDisplay < -1.50) contrastValueDisplay = -1.50;
                    if (contrastValueDisplay > 1.50) contrastValueDisplay = 1.50;
                    
                    if (currentFOVNoHold != -1) contrastValueHold [currentFOVNoHold] = contrastValueDisplay;
                    else contrastValueHold [loadImageFOVNo+1] = contrastValueDisplay;
                }
                else if (rgbDisplayStatus == 2){
                    contrastValueDisplayG = contrastValueDisplayG-(xPointDownCont-xPointDragCont)/(double)0.85/(double)100;
                    xPointDownCont = xPointDragCont;
                    contrastBarActivate = 1;
                    
                    if (contrastValueDisplayG < -1.50) contrastValueDisplayG = -1.50;
                    if (contrastValueDisplayG > 1.50) contrastValueDisplayG = 1.50;
                    
                    if (currentFOVNoHold != -1) contrastValueHoldG [currentFOVNoHold] = contrastValueDisplayG;
                    else contrastValueHoldG [loadImageFOVNo+1] = contrastValueDisplayG;
                }
                else if (rgbDisplayStatus == 3){
                    contrastValueDisplayB = contrastValueDisplayB-(xPointDownCont-xPointDragCont)/(double)0.85/(double)100;
                    xPointDownCont = xPointDragCont;
                    contrastBarActivate = 1;
                    
                    if (contrastValueDisplayB < -1.50) contrastValueDisplayB = -1.50;
                    if (contrastValueDisplayB > 1.50) contrastValueDisplayB = 1.50;
                    
                    if (currentFOVNoHold != -1) contrastValueHoldB [currentFOVNoHold] = contrastValueDisplayB;
                    else contrastValueHoldB [loadImageFOVNo+1] = contrastValueDisplayB;
                }
                
                int type = 5;
                contrastAdjust = [[ContrastAdjust alloc] init];
                [contrastAdjust contrastAdjustMain:type];
                
                callFromHistogram = 1;
                mainImageDisplayCall = 1;
                histogramDisplayCall = 1;
            }
            
            [self setNeedsDisplay:YES];
        }
    }
}

-(void)drawRect:(NSRect)rect{
    [[NSColor lightGrayColor] set];
    
    NSBezierPath *path;
    path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 297, 14)];
    [path fill];
    
    if (imageDataHoldStatus == 1 && backgroundOADisplay == "Off"){
        [[NSColor redColor] set];
        [NSBezierPath setDefaultLineWidth:1.0];
        
        double barPosition = 0;
        
        if (rgbDisplayStatus == 0 || rgbDisplayStatus == 1) barPosition = contrastValueDisplay*0.85*100+129;
        else if (rgbDisplayStatus == 2) barPosition = contrastValueDisplayG*0.85*100+129;
        else if (rgbDisplayStatus == 3) barPosition = contrastValueDisplayB*0.85*100+129;
        
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(barPosition, 3, 8, 8)];
        [path stroke];
        
        NSPoint positionAA, positionBB;
        positionAA.x = barPosition+4;
        positionAA.y = 1;
        positionBB.x = barPosition+4;
        positionBB.y = 13;
        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
        
        double displayDouble = 0;
        
        if (rgbDisplayStatus == 0 || rgbDisplayStatus == 1) displayDouble = (contrastValueDisplay*100)/(double)100;
        else if (rgbDisplayStatus == 2) displayDouble = (contrastValueDisplayG*100)/(double)100;
        else if (rgbDisplayStatus == 3) displayDouble = (contrastValueDisplayB*100)/(double)100;
        
        
        NSAttributedString *attrStrA;
        NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
        
        stringstream extension1;
        extension1 << displayDouble;
        string extension = extension1.str();
        
        [attributesA setObject:[NSFont systemFontOfSize:12] forKey:NSFontAttributeName];
        [attributesA setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributesA];
        positionAA.x = 265;
        positionAA.y = 1;
        [attrStrA drawAtPoint:positionAA];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToContrastWindow object:nil];
}

@end
