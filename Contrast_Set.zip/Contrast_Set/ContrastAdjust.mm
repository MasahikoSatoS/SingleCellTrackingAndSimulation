//
//  ContrastAdjust.mm
//  Contrast_Set
//
//  Created by Masahiko Sato on 2014-04-14.
//
//

#import "ContrastAdjust.h"

@implementation ContrastAdjust

-(void)contrastAdjustMain:(int)processType{
    if (processingFovNo == -1){
        double expansionFactor1 = 0;
        double expansionFactor2 = 0;
        int newPixValue = 0;
        int lowCut2 = 0;
        int meanValue2 = 0;
        int highCut2 = 0;
        
        if (photoMetricHold == 1){
            for (int counter1 = 0; counter1 < loadImageFOVNo; counter1++){
                expansionFactor1 = 1;
                expansionFactor2 = 1;
                
                if (processType == 2 || processType == 3 || processType == 4){
                    highCut2 = arrayImageRangeAdjustLMH [counter1*3+2]-meanValueDisplay;
                    
                    if (arrayImageRangeAdjustLMH [counter1*3+2]-meanValueDisplay <= 0) highCut2 = 1;
                    
                    lowCut2 = meanValueDisplay-arrayImageRangeAdjustLMH [counter1*3];
                    
                    if (meanValueDisplay-arrayImageRangeAdjustLMH [counter1*3] <= 0) lowCut2 = 1;
                    
                    expansionFactor1 = (highValueDisplay-meanValueDisplay)/(double)highCut2;
                    expansionFactor2 = (meanValueDisplay-lowValueDisplay)/(double)lowCut2;
                }
                
                for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        newPixValue = 0;
                        
                        if (arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3] >= 0){
                            if (processType == 2 || processType == 3 || processType == 4){
                                if (arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3] > meanValueDisplay && expansionFactor1 != 1) newPixValue = meanValueDisplay+(int)((arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3]-meanValueDisplay)*expansionFactor1);
                                else if (arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3] < meanValueDisplay && expansionFactor2 != 1) newPixValue = meanValueDisplay-(int)((meanValueDisplay-arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3])*expansionFactor2);
                                else newPixValue = arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3];
                            }
                            else if (processType == 5){
                                if (arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3]-meanValueDisplay < 0 && arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3] >= 0) newPixValue = arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3]-(int)((meanValueDisplay-arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3])*contrastValueDisplay);
                                else if (arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3]-meanValueDisplay > 0 && arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3] <= 255) newPixValue = arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3]+(int)((arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3]-meanValueDisplay)*contrastValueDisplay);
                                else newPixValue = arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3];
                            }
                            
                            if (newPixValue < 0) newPixValue = 0;
                            else if (newPixValue > 255) newPixValue = 255;
                            
                            if (processType == 2 || processType == 3 || processType == 4){
                                arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3] = newPixValue;
                                arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3] = newPixValue;
                            }
                            else if (processType == 5) arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3] = newPixValue;
                        }
                        else{
                            
                            if (processType == 2 || processType == 3 || processType == 4){
                                arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3] = -1;
                                arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3] = -1;
                            }
                            else if (processType == 5) arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3] = -1;
                            
                        }
                    }
                }
            }
        }
        else if (photoMetricHold == 2){
            if (rgbDisplayStatus == 1){
                for (int counter1 = 0; counter1 < loadImageFOVNo; counter1++){
                    expansionFactor1 = 1;
                    expansionFactor2 = 1;
                    
                    if (processType == 2 || processType == 3 || processType == 4){
                        highCut2 = arrayImageRangeAdjustLMH [counter1*3+2]-meanValueDisplay;
                        
                        if (arrayImageRangeAdjustLMH [counter1*3+2]-meanValueDisplay <= 0) highCut2 = 1;
                        
                        lowCut2 = meanValueDisplay-arrayImageRangeAdjustLMH [counter1*3];
                        
                        if (meanValueDisplay-arrayImageRangeAdjustLMH [counter1*3] <= 0) lowCut2 = 1;
                        
                        expansionFactor1 = (highValueDisplay-meanValueDisplay)/(double)highCut2;
                        expansionFactor2 = (meanValueDisplay-lowValueDisplay)/(double)lowCut2;
                    }
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            newPixValue = 0;
                            
                            if (arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3] >= 0){
                                if (processType == 2 || processType == 3 || processType == 4){
                                    if (arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3] > meanValueDisplay && expansionFactor1 != 1) newPixValue = meanValueDisplay+(int)((arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3]-meanValueDisplay)*expansionFactor1);
                                    else if (arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3] < meanValueDisplay && expansionFactor2 != 1) newPixValue = meanValueDisplay-(int)((meanValueDisplay-arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3])*expansionFactor2);
                                    else newPixValue = arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3];
                                }
                                else if (processType == 5){
                                    if (arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3]-meanValueDisplay < 0 && arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3] >= 0) newPixValue = arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3]-(int)((meanValueDisplay-arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3])*contrastValueDisplay);
                                    else if (arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3]-meanValueDisplay > 0 && arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3] <= 255) newPixValue = arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3]+(int)((arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3]-meanValueDisplay)*contrastValueDisplay);
                                    else newPixValue = arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3];
                                }
                                
                                if (newPixValue < 0) newPixValue = 0;
                                else if (newPixValue > 255) newPixValue = 255;
                                
                                if (processType == 2 || processType == 3 || processType == 4){
                                    arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3] = newPixValue;
                                    arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3*3] = newPixValue;
                                }
                                else if (processType == 5) arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3*3] = newPixValue;
                            }
                            else{
                                
                                if (processType == 2 || processType == 3 || processType == 4){
                                    arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3] = -1;
                                    arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3*3] = -1;
                                }
                                else if (processType == 5) arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3*3] = -1;
                            }
                        }
                    }
                }
            }
            else if (rgbDisplayStatus == 2){
                for (int counter1 = 0; counter1 < loadImageFOVNo; counter1++){
                    expansionFactor1 = 1;
                    expansionFactor2 = 1;
                    
                    if (processType == 2 || processType == 3 || processType == 4){
                        highCut2 = arrayImageRangeAdjustLMHG [counter1*3+2]-meanValueDisplayG;
                        
                        if (arrayImageRangeAdjustLMHG [counter1*3+2]-meanValueDisplayG <= 0) highCut2 = 1;
                        
                        lowCut2 = meanValueDisplayG-arrayImageRangeAdjustLMHG [counter1*3];
                        
                        if (meanValueDisplayG-arrayImageRangeAdjustLMHG [counter1*3] <= 0) lowCut2 = 1;
                        
                        expansionFactor1 = (highValueDisplayG-meanValueDisplayG)/(double)highCut2;
                        expansionFactor2 = (meanValueDisplayG-lowValueDisplayG)/(double)lowCut2;
                    }
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            newPixValue = 0;
                            
                            if (arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3+1] >= 0){
                                if (processType == 2 || processType == 3 || processType == 4){
                                    if (arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3+1] > meanValueDisplayG && expansionFactor1 != 1) newPixValue = meanValueDisplayG+(int)((arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3+1]-meanValueDisplayG)*expansionFactor1);
                                    else if (arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3+1] < meanValueDisplayG && expansionFactor2 != 1) newPixValue = meanValueDisplayG-(int)((meanValueDisplayG-arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3+1])*expansionFactor2);
                                    else newPixValue = arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3+1];
                                }
                                else if (processType == 5){
                                    if (arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+1]-meanValueDisplayG < 0 && arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+1] >= 0) newPixValue = arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+1]-(int)((meanValueDisplayG-arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+1])*contrastValueDisplayG);
                                    else if (arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+1]-meanValueDisplayG > 0 && arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+1] <= 255) newPixValue = arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+1]+(int)((arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+1]-meanValueDisplayG)*contrastValueDisplayG);
                                    else newPixValue = arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+1];
                                }
                                
                                if (newPixValue < 0) newPixValue = 0;
                                else if (newPixValue > 255) newPixValue = 255;
                                
                                if (processType == 2 || processType == 3 || processType == 4){
                                    arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+1] = newPixValue;
                                    arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3*3+1] = newPixValue;
                                }
                                else if (processType == 5) arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3*3+1] = newPixValue;
                            }
                            else{
                                
                                if (processType == 2 || processType == 3 || processType == 4){
                                    arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+1] = -1;
                                    arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3*3+1] = -1;
                                }
                                else if (processType == 5) arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3*3+1] = -1;
                            }
                        }
                    }
                }
            }
            else if (rgbDisplayStatus == 3){
                for (int counter1 = 0; counter1 < loadImageFOVNo; counter1++){
                    expansionFactor1 = 1;
                    expansionFactor2 = 1;
                    
                    if (processType == 2 || processType == 3 || processType == 4){
                        highCut2 = arrayImageRangeAdjustLMHB [counter1*3+2]-meanValueDisplayB;
                        
                        if (arrayImageRangeAdjustLMHB [counter1*3+2]-meanValueDisplayB <= 0) highCut2 = 1;
                        
                        lowCut2 = meanValueDisplayB-arrayImageRangeAdjustLMHB [counter1*3];
                        
                        if (meanValueDisplayB-arrayImageRangeAdjustLMHB [counter1*3] <= 0) lowCut2 = 1;
                        
                        expansionFactor1 = (highValueDisplayB-meanValueDisplayB)/(double)highCut2;
                        expansionFactor2 = (meanValueDisplayB-lowValueDisplayB)/(double)lowCut2;
                    }
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            newPixValue = 0;
                            
                            if (arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3+2] >= 0){
                                if (processType == 2 || processType == 3 || processType == 4){
                                    if (arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3+2] > meanValueDisplayB && expansionFactor1 != 1) newPixValue = meanValueDisplayB+(int)((arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3+2]-meanValueDisplayB)*expansionFactor1);
                                    else if (arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3+2] < meanValueDisplayB && expansionFactor2 != 1) newPixValue = meanValueDisplayB-(int)((meanValueDisplayB-arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3+2])*expansionFactor2);
                                    else newPixValue = arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3+2];
                                }
                                else if (processType == 5){
                                    if (arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+2]-meanValueDisplayB < 0 && arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+2] >= 0) newPixValue = arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+2]-(int)((meanValueDisplayB-arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+2])*contrastValueDisplayB);
                                    else if (arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+2]-meanValueDisplayB > 0 && arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+2] <= 255) newPixValue = arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+2]+(int)((arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+2]-meanValueDisplayB)*contrastValueDisplayB);
                                    else newPixValue = arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+2];
                                }
                                
                                if (newPixValue < 0) newPixValue = 0;
                                else if (newPixValue > 255) newPixValue = 255;
                                
                                if (processType == 2 || processType == 3 || processType == 4){
                                    arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+2] = newPixValue;
                                    arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3*3+2] = newPixValue;
                                }
                                else if (processType == 5) arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3*3+2] = newPixValue;
                            }
                            else{
                                
                                if (processType == 2 || processType == 3 || processType == 4){
                                    arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+2] = -1;
                                    arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3*3+2] = -1;
                                }
                                else if (processType == 5) arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3*3+2] = -1;
                            }
                        }
                    }
                }
            }
        }
        
        int *histogramTemp = new int [300];
        
        if (processType == 2 || processType == 3 || processType == 4){
            if (photoMetricHold == 1){
                for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                    for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            if (arrayImageCutoffAdjust [(counter1-1)*imageDimensionY+counter2][counter3] >= 0){
                                histogramTemp [arrayImageCutoffAdjust [(counter1-1)*imageDimensionY+counter2][counter3]]++;
                            }
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < 256; counter2++){
                        arrayImageCutoffAdjustHistogram [(counter1-1)*256+counter2] = histogramTemp [counter2];
                        arrayImageContrastAdjustHistogram [(counter1-1)*256+counter2] = histogramTemp [counter2];
                    }
                }
                
                for (int counter1 = 0; counter1 <= 255; counter1++) histogramTemp [counter1] = 0;
                
                for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                    for (int counter2 = 0; counter2 < 256; counter2++){
                        histogramTemp [counter2] = histogramTemp [counter2]+arrayImageCutoffAdjustHistogram [(counter1-1)*256+counter2];
                    }
                }
                
                for (int counter1 = 0; counter1 < 256; counter1++){
                    arrayImageCutoffAdjustHistogram [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                    arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                }
            }
            else if (photoMetricHold == 2){
                if (rgbDisplayStatus == 1){
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                        
                        for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                if (arrayImageCutoffAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3] >= 0){
                                    histogramTemp [arrayImageCutoffAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3]]++;
                                }
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < 256; counter2++){
                            arrayImageCutoffAdjustHistogram [(counter1-1)*256+counter2] = histogramTemp [counter2];
                            arrayImageContrastAdjustHistogram [(counter1-1)*256+counter2] = histogramTemp [counter2];
                        }
                    }
                    
                    for (int counter1 = 0; counter1 <= 255; counter1++) histogramTemp [counter1] = 0;
                    
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 < 256; counter2++){
                            histogramTemp [counter2] = histogramTemp [counter2]+arrayImageCutoffAdjustHistogram [(counter1-1)*256+counter2];
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < 256; counter1++){
                        arrayImageCutoffAdjustHistogram [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                        arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                    }
                }
                else if (rgbDisplayStatus == 2){
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                        
                        for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                if (arrayImageCutoffAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3+1] >= 0){
                                    histogramTemp [arrayImageCutoffAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3+1]]++;
                                }
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < 256; counter2++){
                            arrayImageCutoffAdjustHistogramG [(counter1-1)*256+counter2] = histogramTemp [counter2];
                            arrayImageContrastAdjustHistogramG [(counter1-1)*256+counter2] = histogramTemp [counter2];
                        }
                    }
                    
                    for (int counter1 = 0; counter1 <= 255; counter1++) histogramTemp [counter1] = 0;
                    
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 < 256; counter2++){
                            histogramTemp [counter2] = histogramTemp [counter2]+arrayImageCutoffAdjustHistogramG [(counter1-1)*256+counter2];
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < 256; counter1++){
                        arrayImageCutoffAdjustHistogramG [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                        arrayImageContrastAdjustHistogramG [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                    }
                }
                else if (rgbDisplayStatus == 3){
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                        
                        for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                if (arrayImageCutoffAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3+2] >= 0){
                                    histogramTemp [arrayImageCutoffAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3+2]]++;
                                }
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < 256; counter2++){
                            arrayImageCutoffAdjustHistogramB [(counter1-1)*256+counter2] = histogramTemp [counter2];
                            arrayImageContrastAdjustHistogramB [(counter1-1)*256+counter2] = histogramTemp [counter2];
                        }
                    }
                    
                    for (int counter1 = 0; counter1 <= 255; counter1++) histogramTemp [counter1] = 0;
                    
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 < 256; counter2++){
                            histogramTemp [counter2] = histogramTemp [counter2]+arrayImageCutoffAdjustHistogramB [(counter1-1)*256+counter2];
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < 256; counter1++){
                        arrayImageCutoffAdjustHistogramB [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                        arrayImageContrastAdjustHistogramB [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                    }
                }
            }
        }
        
        if (processType == 5){
            if (photoMetricHold == 1){
                for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                    for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                    
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            if (arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3] >= 0){
                                histogramTemp [arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3]]++;
                            }
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < 256; counter2++) arrayImageContrastAdjustHistogram [(counter1-1)*256+counter2] = histogramTemp [counter2];
                }
                
                for (int counter1 = 0; counter1 <= 255; counter1++) histogramTemp [counter1] = 0;
                
                for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                    for (int counter2 = 0; counter2 < 256; counter2++){
                        histogramTemp [counter2] = histogramTemp [counter2]+arrayImageContrastAdjustHistogram [(counter1-1)*256+counter2];
                    }
                }
                
                for (int counter1 = 0; counter1 < 256; counter1++) arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
            }
            else if (photoMetricHold == 2){
                if (rgbDisplayStatus == 1){
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                        
                        for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                if (arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3] >= 0){
                                    histogramTemp [arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3]]++;
                                }
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < 256; counter2++) arrayImageContrastAdjustHistogram [(counter1-1)*256+counter2] = histogramTemp [counter2];
                    }
                    
                    for (int counter1 = 0; counter1 <= 255; counter1++) histogramTemp [counter1] = 0;
                    
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 < 256; counter2++){
                            histogramTemp [counter2] = histogramTemp [counter2]+arrayImageContrastAdjustHistogram [(counter1-1)*256+counter2];
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < 256; counter1++) arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                }
                else if (rgbDisplayStatus == 2){
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                        
                        for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                if (arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3+1] >= 0){
                                    histogramTemp [arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3+1]]++;
                                }
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < 256; counter2++) arrayImageContrastAdjustHistogramG [(counter1-1)*256+counter2] = histogramTemp [counter2];
                    }
                    
                    for (int counter1 = 0; counter1 <= 255; counter1++) histogramTemp [counter1] = 0;
                    
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 < 256; counter2++){
                            histogramTemp [counter2] = histogramTemp [counter2]+arrayImageContrastAdjustHistogramG [(counter1-1)*256+counter2];
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < 256; counter1++) arrayImageContrastAdjustHistogramG [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                }
                else if (rgbDisplayStatus == 3){
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                        
                        for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                if (arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3+2] >= 0){
                                    histogramTemp [arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3+2]]++;
                                }
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < 256; counter2++) arrayImageContrastAdjustHistogramB [(counter1-1)*256+counter2] = histogramTemp [counter2];
                    }
                    
                    for (int counter1 = 0; counter1 <= 255; counter1++) histogramTemp [counter1] = 0;
                    
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 < 256; counter2++){
                            histogramTemp [counter2] = histogramTemp [counter2]+arrayImageContrastAdjustHistogramB [(counter1-1)*256+counter2];
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < 256; counter1++) arrayImageContrastAdjustHistogramB [loadImageFOVNo*256+counter1] = histogramTemp [counter1];
                }
            }
        }
        
        delete [] histogramTemp;
        
        if (processType == 2 || processType == 3 || processType == 4){
            if (rgbDisplayStatus == 0 || rgbDisplayStatus == 1){
                for (int counter1 = 0; counter1 <= loadImageFOVNo; counter1++){
                    autoContrastCorrectLMH [counter1*3] = lowValueDisplay;
                    autoContrastCorrectLMH [counter1*3+1] = meanValueDisplay;
                    autoContrastCorrectLMH [counter1*3+2] = highValueDisplay;
                    
                    autoContrastCorrectLMH2 [counter1*3] = lowValueDisplay;
                    autoContrastCorrectLMH2 [counter1*3+1] = meanValueDisplay;
                    autoContrastCorrectLMH2 [counter1*3+2] = highValueDisplay;
                }
            }
            else if (rgbDisplayStatus == 2){
                for (int counter1 = 0; counter1 <= loadImageFOVNo; counter1++){
                    autoContrastCorrectLMHG [counter1*3] = lowValueDisplayG;
                    autoContrastCorrectLMHG [counter1*3+1] = meanValueDisplayG;
                    autoContrastCorrectLMHG [counter1*3+2] = highValueDisplayG;
                    
                    autoContrastCorrectLMH2G [counter1*3] = lowValueDisplayG;
                    autoContrastCorrectLMH2G [counter1*3+1] = meanValueDisplayG;
                    autoContrastCorrectLMH2G [counter1*3+2] = highValueDisplayG;
                }
            }
            else if (rgbDisplayStatus == 3){
                for (int counter1 = 0; counter1 <= loadImageFOVNo; counter1++){
                    autoContrastCorrectLMHB [counter1*3] = lowValueDisplayB;
                    autoContrastCorrectLMHB [counter1*3+1] = meanValueDisplayB;
                    autoContrastCorrectLMHB [counter1*3+2] = highValueDisplayB;
                    
                    autoContrastCorrectLMH2B [counter1*3] = lowValueDisplayB;
                    autoContrastCorrectLMH2B [counter1*3+1] = meanValueDisplayB;
                    autoContrastCorrectLMH2B [counter1*3+2] = highValueDisplayB;
                }
            }
        }
        
        if (processType == 2 || processType == 3 || processType == 4 || processType == 5){
            int entryCount = 0;
            int writeStartFlag = 0;
            int contrastDoubleTemp = 0;
            
            double contrastDouble = 0;
            
            string stringData;
            string contrastString;
            
            if (rgbDisplayStatus == 0 || rgbDisplayStatus == 1){
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    if (arrayTableDisplay [counter1*5] == loadImageTreatName && arrayTableDisplay [counter1*5+2] != " "){
                        writeStartFlag = 1;
                        
                        lowCut2 = autoContrastCorrectLMH2 [entryCount*3];
                        meanValue2 = autoContrastCorrectLMH2 [entryCount*3+1];
                        highCut2 = autoContrastCorrectLMH2 [entryCount*3+2];
                        stringData = arrayTableDisplay [counter1*5+2];
                        stringData = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                        
                        contrastDoubleTemp = (int)(contrastValueDisplay*100);
                        contrastDouble = contrastDoubleTemp/(double)100;
                        
                        stringstream extension4;
                        extension4 << contrastDouble;
                        contrastString = extension4.str();
                        
                        arrayTableDisplay [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringData+"~0";
                        
                        entryCount++;
                    }
                    else if (writeStartFlag == 1 && arrayTableDisplay [counter1*5] == " " && arrayTableDisplay [counter1*5+2] != " "){
                        lowCut2 = autoContrastCorrectLMH2 [entryCount*3];
                        meanValue2 = autoContrastCorrectLMH2 [entryCount*3+1];
                        highCut2 = autoContrastCorrectLMH2 [entryCount*3+2];
                        stringData = arrayTableDisplay [counter1*5+2];
                        stringData = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                        
                        contrastDoubleTemp = (int)(contrastValueDisplay*100);
                        contrastDouble = contrastDoubleTemp/(double)100;
                        
                        stringstream extension4;
                        extension4 << contrastDouble;
                        contrastString = extension4.str();
                        
                        arrayTableDisplay [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringData+"~0";
                        entryCount++;
                    }
                    else if (writeStartFlag == 1 && ((arrayTableDisplay [counter1*5] != " " && arrayTableDisplay [counter1*5+2] != " ") || (arrayTableDisplay [counter1*5] == " " && arrayTableDisplay [counter1*5+2] == " "))){
                        break;
                    }
                }
            }
            else if (rgbDisplayStatus == 2){
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    if (arrayTableDisplayG [counter1*5] == loadImageTreatName && arrayTableDisplayG [counter1*5+2] != " "){
                        writeStartFlag = 1;
                        
                        lowCut2 = autoContrastCorrectLMH2G [entryCount*3];
                        meanValue2 = autoContrastCorrectLMH2G [entryCount*3+1];
                        highCut2 = autoContrastCorrectLMH2G [entryCount*3+2];
                        stringData = arrayTableDisplayG [counter1*5+2];
                        stringData = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                        
                        contrastDoubleTemp = (int)(contrastValueDisplayG*100);
                        contrastDouble = contrastDoubleTemp/(double)100;
                        
                        stringstream extension4;
                        extension4 << contrastDouble;
                        contrastString = extension4.str();
                        
                        arrayTableDisplayG [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringData+"~0";
                        
                        entryCount++;
                    }
                    else if (writeStartFlag == 1 && arrayTableDisplayG [counter1*5] == " " && arrayTableDisplayG [counter1*5+2] != " "){
                        lowCut2 = autoContrastCorrectLMH2G [entryCount*3];
                        meanValue2 = autoContrastCorrectLMH2G [entryCount*3+1];
                        highCut2 = autoContrastCorrectLMH2G [entryCount*3+2];
                        stringData = arrayTableDisplayG [counter1*5+2];
                        stringData = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                        
                        contrastDoubleTemp = (int)(contrastValueDisplayG*100);
                        contrastDouble = contrastDoubleTemp/(double)100;
                        
                        stringstream extension4;
                        extension4 << contrastDouble;
                        contrastString = extension4.str();
                        
                        arrayTableDisplayG [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringData+"~0";
                        entryCount++;
                    }
                    else if (writeStartFlag == 1 && ((arrayTableDisplayG [counter1*5] != " " && arrayTableDisplayG [counter1*5+2] != " ") || (arrayTableDisplayG [counter1*5] == " " && arrayTableDisplayG [counter1*5+2] == " "))){
                        break;
                    }
                }
            }
            else if (rgbDisplayStatus == 3){
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    if (arrayTableDisplayB [counter1*5] == loadImageTreatName && arrayTableDisplayB [counter1*5+2] != " "){
                        writeStartFlag = 1;
                        
                        lowCut2 = autoContrastCorrectLMH2B [entryCount*3];
                        meanValue2 = autoContrastCorrectLMH2B [entryCount*3+1];
                        highCut2 = autoContrastCorrectLMH2B [entryCount*3+2];
                        stringData = arrayTableDisplayB [counter1*5+2];
                        stringData = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                        
                        contrastDoubleTemp = (int)(contrastValueDisplayB*100);
                        contrastDouble = contrastDoubleTemp/(double)100;
                        
                        stringstream extension4;
                        extension4 << contrastDouble;
                        contrastString = extension4.str();
                        
                        arrayTableDisplayB [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringData+"~0";
                        
                        entryCount++;
                    }
                    else if (writeStartFlag == 1 && arrayTableDisplayB [counter1*5] == " " && arrayTableDisplayB [counter1*5+2] != " "){
                        lowCut2 = autoContrastCorrectLMH2B [entryCount*3];
                        meanValue2 = autoContrastCorrectLMH2B [entryCount*3+1];
                        highCut2 = autoContrastCorrectLMH2B [entryCount*3+2];
                        stringData = arrayTableDisplayB [counter1*5+2];
                        stringData = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                        
                        contrastDoubleTemp = (int)(contrastValueDisplayB*100);
                        contrastDouble = contrastDoubleTemp/(double)100;
                        
                        stringstream extension4;
                        extension4 << contrastDouble;
                        contrastString = extension4.str();
                        
                        arrayTableDisplayB [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringData+"~0";
                        entryCount++;
                    }
                    else if (writeStartFlag == 1 && ((arrayTableDisplayB [counter1*5] != " " && arrayTableDisplayB [counter1*5+2] != " ") || (arrayTableDisplayB [counter1*5] == " " && arrayTableDisplayB [counter1*5+2] == " "))){
                        break;
                    }
                }
            }
            
            tableViewCall = 1;
        }
        
        if (rgbDisplayStatus == 0 || rgbDisplayStatus == 1){
            for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                contrastCurrentHold [counter1] = arrayTableDisplay [counter1*5+2];
            }
        }
        else if (rgbDisplayStatus == 2){
            for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                contrastCurrentHoldG [counter1] = arrayTableDisplayG [counter1*5+2];
            }
        }
        else if (rgbDisplayStatus == 3){
            for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                contrastCurrentHoldB [counter1] = arrayTableDisplayB [counter1*5+2];
            }
        }
        
        histoMaxCount = 0;
        
        if (photoMetricHold == 1){
            for (int counter1 = 1; counter1 < 256; counter1++){
                if (arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter1] > histoMaxCount) histoMaxCount = arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter1];
            }
        }
        else if (photoMetricHold == 2){
            for (int counter1 = 1; counter1 < 256; counter1++){
                if (arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter1] > histoMaxCount) histoMaxCount = arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter1];
                if (arrayImageContrastAdjustHistogramG [loadImageFOVNo*256+counter1] > histoMaxCount) histoMaxCount = arrayImageContrastAdjustHistogramG [loadImageFOVNo*256+counter1];
                if (arrayImageContrastAdjustHistogramB [loadImageFOVNo*256+counter1] > histoMaxCount) histoMaxCount = arrayImageContrastAdjustHistogramB [loadImageFOVNo*256+counter1];
            }
        }
        
        if (histoMaxCount > 2000*loadImageFOVNo) histoMaxCount = 2000*loadImageFOVNo;
    }
    else if (processingFovNo != 0 && (processType == 2 || processType == 3 || processType == 4 || processType == 5)){
        if (photoMetricHold == 1){
            int lowCut2 = arrayImageRangeAdjustLMH [(processingFovNo-1)*3];
            int highCut2 = arrayImageRangeAdjustLMH [(processingFovNo-1)*3+2];
            
            highCut2 = highCut2-meanValueDisplay;
            
            if (highCut2 <= 0) highCut2 = 1;
            
            lowCut2 = meanValueDisplay-lowCut2;
            
            if (lowCut2 <= 0) lowCut2 = 1;
            
            double expansionFactor1 = 1;
            double expansionFactor2 = 1;
            
            expansionFactor1 = (highValueDisplay-meanValueDisplay)/(double)highCut2;
            expansionFactor2 = (meanValueDisplay-lowValueDisplay)/(double)lowCut2;
            
            int newPixValue = 0;
            
            for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                    newPixValue = 0;
                    
                    if (arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2] >= 0){
                        if (processType == 2 || processType == 3 || processType == 4){
                            if (arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2] > meanValueDisplay && expansionFactor1 != 1){
                                newPixValue = meanValueDisplay+(int)((arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2]-meanValueDisplay)*expansionFactor1);
                            }
                            else if (arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2] < meanValueDisplay && expansionFactor2 != 1){
                                newPixValue = meanValueDisplay-(int)((meanValueDisplay-arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2])*expansionFactor2);
                            }
                            else newPixValue = arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2];
                        }
                        
                        if (processType == 5){
                            if (arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2]-meanValueDisplay < 0 && arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2] >= 0) newPixValue = arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2]-(int)((meanValueDisplay-arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2])*contrastValueDisplay);
                            else if (arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2]-meanValueDisplay > 0 && arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2] <= 255) newPixValue = arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2]+(int)((arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2]-meanValueDisplay)*contrastValueDisplay);
                            else newPixValue = arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2];
                        }
                        
                        if (newPixValue < 0) newPixValue = 0;
                        if (newPixValue > 255) newPixValue = 255;
                        
                        if (processType == 2 || processType == 3 || processType == 4){
                            arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2] = newPixValue;
                            arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2] = newPixValue;
                        }
                        
                        if (processType == 5) arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2] = newPixValue;
                    }
                    else{
                        
                        if (processType == 2 || processType == 3 || processType == 4){
                            arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2] = -1;
                            arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2] = -1;
                        }
                        
                        if (processType == 5) arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2] = -1;
                    }
                }
            }
        }
        else if (photoMetricHold == 2){
            if (rgbDisplayStatus == 1){
                int lowCut2 = arrayImageRangeAdjustLMH [(processingFovNo-1)*3];
                int highCut2 = arrayImageRangeAdjustLMH [(processingFovNo-1)*3+2];
                
                highCut2 = highCut2-meanValueDisplay;
                
                if (highCut2 <= 0) highCut2 = 1;
                
                lowCut2 = meanValueDisplay-lowCut2;
                
                if (lowCut2 <= 0) lowCut2 = 1;
                
                double expansionFactor1 = 1;
                double expansionFactor2 = 1;
                
                expansionFactor1 = (highValueDisplay-meanValueDisplay)/(double)highCut2;
                expansionFactor2 = (meanValueDisplay-lowValueDisplay)/(double)lowCut2;
                
                int newPixValue = 0;
                
                for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                    for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                        newPixValue = 0;
                        
                        if (arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3] >= 0){
                            if (processType == 2 || processType == 3 || processType == 4){
                                if (arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3] > meanValueDisplay && expansionFactor1 != 1){
                                    newPixValue = meanValueDisplay+(int)((arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3]-meanValueDisplay)*expansionFactor1);
                                }
                                else if (arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3] < meanValueDisplay && expansionFactor2 != 1){
                                    newPixValue = meanValueDisplay-(int)((meanValueDisplay-arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3])*expansionFactor2);
                                }
                                else newPixValue = arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3];
                            }
                            
                            if (processType == 5){
                                if (arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3]-meanValueDisplay < 0 && arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3] >= 0) newPixValue = arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3]-(int)((meanValueDisplay-arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3])*contrastValueDisplay);
                                else if (arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3]-meanValueDisplay > 0 && arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3] <= 255) newPixValue = arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3]+(int)((arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3]-meanValueDisplay)*contrastValueDisplay);
                                else newPixValue = arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3];
                            }
                            
                            if (newPixValue < 0) newPixValue = 0;
                            if (newPixValue > 255) newPixValue = 255;
                            
                            if (processType == 2 || processType == 3 || processType == 4){
                                arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3] = newPixValue;
                                arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3] = newPixValue;
                            }
                            
                            if (processType == 5) arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3] = newPixValue;
                        }
                        else{
                            
                            if (processType == 2 || processType == 3 || processType == 4){
                                arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3] = -1;
                                arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3] = -1;
                            }
                            
                            if (processType == 5) arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3] = -1;
                        }
                    }
                }
            }
            else if (rgbDisplayStatus == 2){
                int lowCut2 = arrayImageRangeAdjustLMHG [(processingFovNo-1)*3];
                int highCut2 = arrayImageRangeAdjustLMHG [(processingFovNo-1)*3+2];
                
                highCut2 = highCut2-meanValueDisplayG;
                
                if (highCut2 <= 0) highCut2 = 1;
                
                lowCut2 = meanValueDisplayG-lowCut2;
                
                if (lowCut2 <= 0) lowCut2 = 1;
                
                double expansionFactor1 = 1;
                double expansionFactor2 = 1;
                
                expansionFactor1 = (highValueDisplayG-meanValueDisplayG)/(double)highCut2;
                expansionFactor2 = (meanValueDisplayG-lowValueDisplayG)/(double)lowCut2;
                
                int newPixValue = 0;
                
                for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                    for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                        newPixValue = 0;
                        
                        if (arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1] >= 0){
                            if (processType == 2 || processType == 3 || processType == 4){
                                if (arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1] > meanValueDisplayG && expansionFactor1 != 1){
                                    newPixValue = meanValueDisplayG+(int)((arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1]-meanValueDisplayG)*expansionFactor1);
                                }
                                else if (arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1] < meanValueDisplayG && expansionFactor2 != 1){
                                    newPixValue = meanValueDisplayG-(int)((meanValueDisplayG-arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1])*expansionFactor2);
                                }
                                else newPixValue = arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1];
                            }
                            
                            if (processType == 5){
                                if (arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1]-meanValueDisplayG < 0 && arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1] >= 0) newPixValue = arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1]-(int)((meanValueDisplayG-arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1])*contrastValueDisplayG);
                                else if (arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1]-meanValueDisplayG > 0 && arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1] <= 255) newPixValue = arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1]+(int)((arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1]-meanValueDisplayG)*contrastValueDisplayG);
                                else newPixValue = arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1];
                            }
                            
                            if (newPixValue < 0) newPixValue = 0;
                            if (newPixValue > 255) newPixValue = 255;
                            
                            if (processType == 2 || processType == 3 || processType == 4){
                                arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1] = newPixValue;
                                arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1] = newPixValue;
                            }
                            
                            if (processType == 5) arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1] = newPixValue;
                        }
                        else{
                            
                            if (processType == 2 || processType == 3 || processType == 4){
                                arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1] = -1;
                                arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1] = -1;
                            }
                            
                            if (processType == 5) arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1] = -1;
                        }
                    }
                }
            }
            else if (rgbDisplayStatus == 3){
                int lowCut2 = arrayImageRangeAdjustLMHB [(processingFovNo-1)*3];
                int highCut2 = arrayImageRangeAdjustLMHB [(processingFovNo-1)*3+2];
                
                highCut2 = highCut2-meanValueDisplayB;
                
                if (highCut2 <= 0) highCut2 = 1;
                
                lowCut2 = meanValueDisplayB-lowCut2;
                
                if (lowCut2 <= 0) lowCut2 = 1;
                
                double expansionFactor1 = 1;
                double expansionFactor2 = 1;
                
                expansionFactor1 = (highValueDisplayB-meanValueDisplayB)/(double)highCut2;
                expansionFactor2 = (meanValueDisplayB-lowValueDisplayB)/(double)lowCut2;
                
                int newPixValue = 0;
                
                for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                    for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                        newPixValue = 0;
                        
                        if (arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2] >= 0){
                            if (processType == 2 || processType == 3 || processType == 4){
                                if (arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2] > meanValueDisplayB && expansionFactor1 != 1){
                                    newPixValue = meanValueDisplayB+(int)((arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2]-meanValueDisplayB)*expansionFactor1);
                                }
                                else if (arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2] < meanValueDisplayB && expansionFactor2 != 1){
                                    newPixValue = meanValueDisplayB-(int)((meanValueDisplayB-arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2])*expansionFactor2);
                                }
                                else newPixValue = arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2];
                            }
                            
                            if (processType == 5){
                                if (arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2]-meanValueDisplayB < 0 && arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2] >= 0) newPixValue = arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1]-(int)((meanValueDisplayB-arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2])*contrastValueDisplayB);
                                else if (arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2]-meanValueDisplayB > 0 && arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2] <= 255) newPixValue = arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2]+(int)((arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2]-meanValueDisplayB)*contrastValueDisplayB);
                                else newPixValue = arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2];
                            }
                            
                            if (newPixValue < 0) newPixValue = 0;
                            if (newPixValue > 255) newPixValue = 255;
                            
                            if (processType == 2 || processType == 3 || processType == 4){
                                arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2] = newPixValue;
                                arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2] = newPixValue;
                            }
                            
                            if (processType == 5) arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2] = newPixValue;
                        }
                        else{
                            
                            if (processType == 2 || processType == 3 || processType == 4){
                                arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2] = -1;
                                arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2] = -1;
                            }
                            
                            if (processType == 5) arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2] = -1;
                        }
                    }
                }
            }
        }
        
        int *histogramTemp = new int [300];
        
        if (processType == 2 || processType == 3 || processType == 4){
            if (photoMetricHold == 1){
                for (int counter1 = 0; counter1 <= 255; counter1++) histogramTemp [counter1] = 0;
                
                for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                    for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                        if (arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2] >= 0){
                            histogramTemp [arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2]]++;
                        }
                    }
                }
                
                for (int counter1 = 0; counter1 < 256; counter1++){
                    arrayImageCutoffAdjustHistogram [(processingFovNo-1)*256+counter1] = histogramTemp [counter1];
                    arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1] = histogramTemp [counter1];
                }
            }
            else if (photoMetricHold == 2){
                if (rgbDisplayStatus == 1){
                    for (int counter1 = 0; counter1 <= 255; counter1++) histogramTemp [counter1] = 0;
                    
                    for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                        for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                            if (arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3] >= 0){
                                histogramTemp [arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3]]++;
                            }
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < 256; counter1++){
                        arrayImageCutoffAdjustHistogram [(processingFovNo-1)*256+counter1] = histogramTemp [counter1];
                        arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1] = histogramTemp [counter1];
                    }
                }
                else if (rgbDisplayStatus == 2){
                    for (int counter1 = 0; counter1 <= 255; counter1++) histogramTemp [counter1] = 0;
                    
                    for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                        for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                            if (arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1] >= 0){
                                histogramTemp [arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1]]++;
                            }
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < 256; counter1++){
                        arrayImageCutoffAdjustHistogramG [(processingFovNo-1)*256+counter1] = histogramTemp [counter1];
                        arrayImageContrastAdjustHistogramG [(processingFovNo-1)*256+counter1] = histogramTemp [counter1];
                    }
                }
                else if (rgbDisplayStatus == 3){
                    for (int counter1 = 0; counter1 <= 255; counter1++) histogramTemp [counter1] = 0;
                    
                    for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                        for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                            if (arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2] >= 0){
                                histogramTemp [arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2]]++;
                            }
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < 256; counter1++){
                        arrayImageCutoffAdjustHistogramB [(processingFovNo-1)*256+counter1] = histogramTemp [counter1];
                        arrayImageContrastAdjustHistogramB [(processingFovNo-1)*256+counter1] = histogramTemp [counter1];
                    }
                }
            }
        }
        
        if (processType == 5){
            if (photoMetricHold == 1){
                for (int counter1 = 0; counter1 <= 255; counter1++) histogramTemp [counter1] = 0;
                
                for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                    for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                        if (arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2] >= 0){
                            histogramTemp [arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2]]++;
                        }
                    }
                }
                
                for (int counter1 = 0; counter1 < 256; counter1++) arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1] = histogramTemp [counter1];
            }
            else if (photoMetricHold == 2){
                if (rgbDisplayStatus == 1){
                    for (int counter1 = 0; counter1 <= 255; counter1++) histogramTemp [counter1] = 0;
                    
                    for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                        for (int counter2 = 0; counter2 < imageDimensionX; counter2 = counter2+3){
                            if (arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3] >= 0){
                                histogramTemp [arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3]]++;
                            }
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < 256; counter1++) arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1] = histogramTemp [counter1];
                }
                else if (rgbDisplayStatus == 2){
                    for (int counter1 = 0; counter1 <= 255; counter1++) histogramTemp [counter1] = 0;
                    
                    for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                        for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                            if (arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1] >= 0){
                                histogramTemp [arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1]]++;
                            }
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < 256; counter1++) arrayImageContrastAdjustHistogramG [(processingFovNo-1)*256+counter1] = histogramTemp [counter1];
                }
                else if (rgbDisplayStatus == 3){
                    for (int counter1 = 0; counter1 <= 255; counter1++) histogramTemp [counter1] = 0;
                    
                    for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                        for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                            if (arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2] >= 0){
                                histogramTemp [arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2]]++;
                            }
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < 256; counter1++) arrayImageContrastAdjustHistogramB [(processingFovNo-1)*256+counter1] = histogramTemp [counter1];
                }
            }
        }
        
        delete [] histogramTemp;
        
        if (rgbDisplayStatus == 0 || rgbDisplayStatus == 1){
            if (processType == 2){
                autoContrastCorrectLMH [(processingFovNo-1)*3] = lowValueDisplay;
                autoContrastCorrectLMH2 [(processingFovNo-1)*3] = lowValueDisplay;
            }
            
            if (processType == 3){
                autoContrastCorrectLMH [(processingFovNo-1)*3+2] = highValueDisplay;
                autoContrastCorrectLMH2 [(processingFovNo-1)*3+2] = highValueDisplay;
            }
            
            if (processType == 4){
                autoContrastCorrectLMH [(processingFovNo-1)*3+1] = meanValueDisplay;
                autoContrastCorrectLMH2 [(processingFovNo-1)*3+1] = meanValueDisplay;
            }
        }
        else if (rgbDisplayStatus == 2){
            if (processType == 2){
                autoContrastCorrectLMHG [(processingFovNo-1)*3] = lowValueDisplayG;
                autoContrastCorrectLMH2G [(processingFovNo-1)*3] = lowValueDisplayG;
            }
            
            if (processType == 3){
                autoContrastCorrectLMHG [(processingFovNo-1)*3+2] = highValueDisplayG;
                autoContrastCorrectLMH2G [(processingFovNo-1)*3+2] = highValueDisplayG;
            }
            
            if (processType == 4){
                autoContrastCorrectLMHG [(processingFovNo-1)*3+1] = meanValueDisplayG;
                autoContrastCorrectLMH2G [(processingFovNo-1)*3+1] = meanValueDisplayG;
            }
        }
        else if (rgbDisplayStatus == 3){
            if (processType == 2){
                autoContrastCorrectLMHB [(processingFovNo-1)*3] = lowValueDisplayB;
                autoContrastCorrectLMH2B [(processingFovNo-1)*3] = lowValueDisplayB;
            }
            
            if (processType == 3){
                autoContrastCorrectLMHB [(processingFovNo-1)*3+2] = highValueDisplayB;
                autoContrastCorrectLMH2B [(processingFovNo-1)*3+2] = highValueDisplayB;
            }
            
            if (processType == 4){
                autoContrastCorrectLMHB [(processingFovNo-1)*3+1] = meanValueDisplayB;
                autoContrastCorrectLMH2B [(processingFovNo-1)*3+1] = meanValueDisplayB;
            }
        }
        
        int entryCount = 0;
        int writeStartFlag = 0;
        int contrastDoubleTemp = 0;
        int lowCut2 = 0;
        int meanValue2 = 0;
        int highCut2 = 0;
        
        double contrastDouble = 0;
        
        string stringData;
        string stringData2;
        string contrastString;
        
        if (rgbDisplayStatus == 0 || rgbDisplayStatus == 1){
            for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                if (arrayTableDisplay [counter1*5] == loadImageTreatName && arrayTableDisplay [counter1*5+2] != " "){
                    writeStartFlag = 1;
                    
                    lowCut2 = autoContrastCorrectLMH [entryCount*3];
                    meanValue2 = autoContrastCorrectLMH [entryCount*3+1];
                    highCut2 = autoContrastCorrectLMH [entryCount*3+2];
                    stringData = arrayTableDisplay [counter1*5+2];
                    stringData = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                    
                    if ((processingFovNo-1)*3 == entryCount*3){
                        contrastDoubleTemp = (int)(contrastValueDisplay*100);
                        contrastDouble = contrastDoubleTemp/(double)100;
                        
                        stringstream extension4;
                        extension4 << contrastDouble;
                        contrastString = extension4.str();
                    }
                    else{
                        
                        stringData2 = arrayTableDisplay [counter1*5+2];
                        
                        contrastString = stringData2.substr(stringData2.find("/")+1);
                        contrastString = contrastString.substr(contrastString.find("/")+1);
                        contrastString = contrastString.substr(contrastString.find("/")+1);
                        contrastString = contrastString.substr(0, contrastString.find(" "));
                    }
                    
                    arrayTableDisplay [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringData+"~0";
                    entryCount++;
                }
                else if (writeStartFlag == 1 && arrayTableDisplay [counter1*5] == " " && arrayTableDisplay [counter1*5+2] != " "){
                    lowCut2 = autoContrastCorrectLMH [entryCount*3];
                    meanValue2 = autoContrastCorrectLMH [entryCount*3+1];
                    highCut2 = autoContrastCorrectLMH [entryCount*3+2];
                    stringData = arrayTableDisplay [counter1*5+2];
                    stringData = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                    
                    if ((processingFovNo-1)*3 == entryCount*3){
                        contrastDoubleTemp = (int)(contrastValueDisplay*100);
                        contrastDouble = contrastDoubleTemp/(double)100;
                        
                        stringstream extension4;
                        extension4 << contrastDouble;
                        contrastString = extension4.str();
                    }
                    else{
                        
                        stringData2 = arrayTableDisplay [counter1*5+2];
                        
                        contrastString = stringData2.substr(stringData2.find("/")+1);
                        contrastString = contrastString.substr(contrastString.find("/")+1);
                        contrastString = contrastString.substr(contrastString.find("/")+1);
                        contrastString = contrastString.substr(0, contrastString.find(" "));
                    }
                    
                    arrayTableDisplay [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringData+"~0";
                    entryCount++;
                }
                else if (writeStartFlag == 1 && ((arrayTableDisplay [counter1*5] != " " && arrayTableDisplay [counter1*5+2] != " ") || (arrayTableDisplay [counter1*5] == " " && arrayTableDisplay [counter1*5+2] == " "))){
                    break;
                }
            }
        }
        else if (rgbDisplayStatus == 2){
            for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                if (arrayTableDisplayG [counter1*5] == loadImageTreatName && arrayTableDisplayG [counter1*5+2] != " "){
                    writeStartFlag = 1;
                    
                    lowCut2 = autoContrastCorrectLMHG [entryCount*3];
                    meanValue2 = autoContrastCorrectLMHG [entryCount*3+1];
                    highCut2 = autoContrastCorrectLMHG [entryCount*3+2];
                    stringData = arrayTableDisplayG [counter1*5+2];
                    stringData = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                    
                    if ((processingFovNo-1)*3 == entryCount*3){
                        contrastDoubleTemp = (int)(contrastValueDisplayG*100);
                        contrastDouble = contrastDoubleTemp/(double)100;
                        
                        stringstream extension4;
                        extension4 << contrastDouble;
                        contrastString = extension4.str();
                    }
                    else{
                        
                        stringData2 = arrayTableDisplayG [counter1*5+2];
                        
                        contrastString = stringData2.substr(stringData2.find("/")+1);
                        contrastString = contrastString.substr(contrastString.find("/")+1);
                        contrastString = contrastString.substr(contrastString.find("/")+1);
                        contrastString = contrastString.substr(0, contrastString.find(" "));
                    }
                    
                    arrayTableDisplayG [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringData+"~0";
                    entryCount++;
                }
                else if (writeStartFlag == 1 && arrayTableDisplayG [counter1*5] == " " && arrayTableDisplayG [counter1*5+2] != " "){
                    lowCut2 = autoContrastCorrectLMHG [entryCount*3];
                    meanValue2 = autoContrastCorrectLMHG [entryCount*3+1];
                    highCut2 = autoContrastCorrectLMHG [entryCount*3+2];
                    stringData = arrayTableDisplayG [counter1*5+2];
                    stringData = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                    
                    if ((processingFovNo-1)*3 == entryCount*3){
                        contrastDoubleTemp = (int)(contrastValueDisplayG*100);
                        contrastDouble = contrastDoubleTemp/(double)100;
                        
                        stringstream extension4;
                        extension4 << contrastDouble;
                        contrastString = extension4.str();
                    }
                    else{
                        
                        stringData2 = arrayTableDisplayG [counter1*5+2];
                        
                        contrastString = stringData2.substr(stringData2.find("/")+1);
                        contrastString = contrastString.substr(contrastString.find("/")+1);
                        contrastString = contrastString.substr(contrastString.find("/")+1);
                        contrastString = contrastString.substr(0, contrastString.find(" "));
                    }
                    
                    arrayTableDisplayG [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringData+"~0";
                    entryCount++;
                }
                else if (writeStartFlag == 1 && ((arrayTableDisplayG [counter1*5] != " " && arrayTableDisplayG [counter1*5+2] != " ") || (arrayTableDisplayG [counter1*5] == " " && arrayTableDisplayG [counter1*5+2] == " "))){
                    break;
                }
            }
        }
        else if (rgbDisplayStatus == 3){
            for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                if (arrayTableDisplayB [counter1*5] == loadImageTreatName && arrayTableDisplayB [counter1*5+2] != " "){
                    writeStartFlag = 1;
                    
                    lowCut2 = autoContrastCorrectLMHB [entryCount*3];
                    meanValue2 = autoContrastCorrectLMHB [entryCount*3+1];
                    highCut2 = autoContrastCorrectLMHB [entryCount*3+2];
                    stringData = arrayTableDisplayB [counter1*5+2];
                    stringData = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                    
                    if ((processingFovNo-1)*3 == entryCount*3){
                        contrastDoubleTemp = (int)(contrastValueDisplayB*100);
                        contrastDouble = contrastDoubleTemp/(double)100;
                        
                        stringstream extension4;
                        extension4 << contrastDouble;
                        contrastString = extension4.str();
                    }
                    else{
                        
                        stringData2 = arrayTableDisplayB [counter1*5+2];
                        
                        contrastString = stringData2.substr(stringData2.find("/")+1);
                        contrastString = contrastString.substr(contrastString.find("/")+1);
                        contrastString = contrastString.substr(contrastString.find("/")+1);
                        contrastString = contrastString.substr(0, contrastString.find(" "));
                    }
                    
                    arrayTableDisplayB [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringData+"~0";
                    entryCount++;
                }
                else if (writeStartFlag == 1 && arrayTableDisplayB [counter1*5] == " " && arrayTableDisplayB [counter1*5+2] != " "){
                    lowCut2 = autoContrastCorrectLMHB [entryCount*3];
                    meanValue2 = autoContrastCorrectLMHB [entryCount*3+1];
                    highCut2 = autoContrastCorrectLMHB [entryCount*3+2];
                    stringData = arrayTableDisplayB [counter1*5+2];
                    stringData = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                    
                    if ((processingFovNo-1)*3 == entryCount*3){
                        contrastDoubleTemp = (int)(contrastValueDisplayB*100);
                        contrastDouble = contrastDoubleTemp/(double)100;
                        
                        stringstream extension4;
                        extension4 << contrastDouble;
                        contrastString = extension4.str();
                    }
                    else{
                        
                        stringData2 = arrayTableDisplayB [counter1*5+2];
                        
                        contrastString = stringData2.substr(stringData2.find("/")+1);
                        contrastString = contrastString.substr(contrastString.find("/")+1);
                        contrastString = contrastString.substr(contrastString.find("/")+1);
                        contrastString = contrastString.substr(0, contrastString.find(" "));
                    }
                    
                    arrayTableDisplayB [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringData+"~0";
                    entryCount++;
                }
                else if (writeStartFlag == 1 && ((arrayTableDisplayB [counter1*5] != " " && arrayTableDisplayB [counter1*5+2] != " ") || (arrayTableDisplayB [counter1*5] == " " && arrayTableDisplayB [counter1*5+2] == " "))){
                    break;
                }
            }
        }
        
        if (rgbDisplayStatus == 0 || rgbDisplayStatus == 1){
            for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                contrastCurrentHold [counter1] = arrayTableDisplay [counter1*5+2];
            }
        }
        else if (rgbDisplayStatus == 2){
            for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                contrastCurrentHoldG [counter1] = arrayTableDisplayG [counter1*5+2];
            }
        }
        else if (rgbDisplayStatus == 3){
            for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                contrastCurrentHoldB [counter1] = arrayTableDisplayB [counter1*5+2];
            }
        }
        
        histoMaxCount = 0;
        
        if (photoMetricHold == 1){
            for (int counter1 = 1; counter1 < 256; counter1++){
                if (arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1] > histoMaxCount) histoMaxCount = arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1];
            }
        }
        else if (photoMetricHold == 2){
            for (int counter1 = 1; counter1 < 256; counter1++){
                if (arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1] > histoMaxCount) histoMaxCount = arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1];
                if (arrayImageContrastAdjustHistogramG [(processingFovNo-1)*256+counter1] > histoMaxCount) histoMaxCount = arrayImageContrastAdjustHistogramG [(processingFovNo-1)*256+counter1];
                if (arrayImageContrastAdjustHistogramB [(processingFovNo-1)*256+counter1] > histoMaxCount) histoMaxCount = arrayImageContrastAdjustHistogramB [(processingFovNo-1)*256+counter1];
            }
        }
        
        if (histoMaxCount > 2000) histoMaxCount = 2000;
        
        tableViewCall = 1;
    }
}

@end
