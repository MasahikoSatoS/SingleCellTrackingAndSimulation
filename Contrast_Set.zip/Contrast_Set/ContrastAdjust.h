//
//  ContrastAdjust.h
//  Contrast_Set
//
//  Created by Masahiko Sato on 2014-04-14.
//  Copyright Masahiko Sato 2014 All rights reserved.
//

#ifndef CONTRASTADJUST_H
#define CONTRASTADJUST_H
#import "Controller.h" 
#endif

@interface ContrastAdjust : NSObject {
}

-(void)contrastAdjustMain:(int)processType;

@end
