//
//  ImageDataSet.h
//  Contrast_Set
//
//  Created by Masahiko Sato on 2014-04-11.
//  Copyright Masahiko Sato 2014 All rights reserved.
//

#ifndef IMAGEDATASET_H
#define IMAGEDATASET_H
#import "Controller.h"
#endif

@interface ImageDataSet : NSObject {
    id ascIIconversion;
    id contrastAdjust;
    id objectMatch;
    id tiffFileRead;
}

-(void)imageDataSetProcess:(int)processType;

@end
