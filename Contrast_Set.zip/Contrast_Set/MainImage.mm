//
//  MainImage.m
//  Contrast_Set
//
//  Created by Masahiko Sato on 2014-04-07.
//
//

#import "MainImage.h"

NSString *notificationToMainImage = @"notificationExecuteMainImage";

@implementation MainImage

- (id)initWithFrame:(NSRect)frame{
    self = [super initWithFrame:frame];
    
    if (self) {
        mouseDragFlag = 0;
        mouseDownFlag = 0;
        xStartHold = 0;
        yStartHold = 0;
        
        mainImage = [[NSImage alloc] initWithContentsOfFile:@""];
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToMainImage object:nil];
    }
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    if (imageDataHoldStatus == 1){
        int imageSetSize = 0;
        int counterIncrement = 0;
        
        if (stitchImageDimension <= 1000){
            imageSetSize = stitchImageDimension;
            counterIncrement = 1;
        }
        else if (stitchImageDimension <= 4000){
            imageSetSize = stitchImageDimension/2;
            counterIncrement = 2;
        }
        else{
            
            imageSetSize = stitchImageDimension/4;
            counterIncrement = 4;
        }
        
        if (resolutionStatus == 0){
            imageSetSize = stitchImageDimension;
            counterIncrement = 1;
        }
        
        if (colorNameHold == "Gray" || fluorescentDisplayModeHold == 1){
            NSBitmapImageRep *bitmapReps;
            
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize pixelsHigh:imageSetSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageSetSize bitsPerPixel:8];
            
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            for (int counter1 = 0; counter1 < stitchImageDimension; counter1 = counter1+counterIncrement){
                for (int counter2 = 0; counter2 < stitchImageDimension; counter2 = counter2+counterIncrement) *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2];
            }
            
            mainImage = [[NSImage alloc] initWithSize:NSMakeSize(stitchImageDimension, stitchImageDimension)];
            [mainImage addRepresentation:bitmapReps];
        }
        else if (colorNameHold == "Color R" || colorNameHold == "Color G" || colorNameHold == "Color B"){
            NSBitmapImageRep *bitmapReps;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize pixelsHigh:imageSetSize bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageSetSize*4 bitsPerPixel:32];
            
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            for (int counter1 = 0; counter1 < stitchImageDimension; counter1 = counter1+counterIncrement){
                for (int counter2 = 0; counter2 < stitchImageDimension; counter2 = counter2+counterIncrement){
                    *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2*3];
                    *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2*3+1];
                    *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2*3+2];
                    *bitmapData++ = 0;
                }
            }
            
            mainImage = [[NSImage alloc] initWithSize:NSMakeSize(stitchImageDimension, stitchImageDimension)];
            [mainImage addRepresentation:bitmapReps];
        }
        else if (colorNameHold != "nil"){
            NSBitmapImageRep *bitmapReps;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize pixelsHigh:imageSetSize bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageSetSize*4 bitsPerPixel:32];
            
            int **imageDisplayArrayTemp = new int *[stitchImageDimension+2];
            
            for (int counter1 = 0; counter1 < stitchImageDimension+2; counter1++){
                imageDisplayArrayTemp [counter1] = new int [stitchImageDimension*3+2];
            }
            
            for (int counter2 = 0; counter2 < stitchImageDimension; counter2++){
                for (int counter3 = 0; counter3 < stitchImageDimension; counter3++){
                    if (colorNoHold == "1"){
                        imageDisplayArrayTemp [counter2][counter3*3] = 0;
                        imageDisplayArrayTemp [counter2][counter3*3+1] = 0;
                        imageDisplayArrayTemp [counter2][counter3*3+2] = imageDisplayArray [counter2][counter3];
                    }
                    else if (colorNoHold == "2"){
                        imageDisplayArrayTemp [counter2][counter3*3] = 0;
                        imageDisplayArrayTemp [counter2][counter3*3+1] = imageDisplayArray [counter2][counter3];
                        imageDisplayArrayTemp [counter2][counter3*3+2] = 0;
                    }
                    else if (colorNoHold == "3"){
                        imageDisplayArrayTemp [counter2][counter3*3] = imageDisplayArray [counter2][counter3];
                        imageDisplayArrayTemp [counter2][counter3*3+1] = imageDisplayArray [counter2][counter3];
                        imageDisplayArrayTemp [counter2][counter3*3+2] = 0;
                    }
                    else if (colorNoHold == "4"){
                        imageDisplayArrayTemp [counter2][counter3*3] = imageDisplayArray [counter2][counter3];
                        imageDisplayArrayTemp [counter2][counter3*3+1] = 0;
                        imageDisplayArrayTemp [counter2][counter3*3+2] = 0;
                    }
                    else if (colorNoHold == "5"){
                        imageDisplayArrayTemp [counter2][counter3*3] = imageDisplayArray [counter2][counter3];
                        imageDisplayArrayTemp [counter2][counter3*3+1] = 0;
                        imageDisplayArrayTemp [counter2][counter3*3+2] = imageDisplayArray [counter2][counter3];
                    }
                    else if (colorNoHold == "6"){
                        imageDisplayArrayTemp [counter2][counter3*3] = 0;
                        imageDisplayArrayTemp [counter2][counter3*3+1] = imageDisplayArray [counter2][counter3];
                        imageDisplayArrayTemp [counter2][counter3*3+2] = imageDisplayArray [counter2][counter3];
                    }
                    else if (colorNoHold == "7"){
                        imageDisplayArrayTemp [counter2][counter3*3] = imageDisplayArray [counter2][counter3];
                        imageDisplayArrayTemp [counter2][counter3*3+1] = (int)(imageDisplayArray [counter2][counter3]*(double)0.674);
                        imageDisplayArrayTemp [counter2][counter3*3+2] = 0;
                    }
                    else if (colorNoHold == "8"){
                        imageDisplayArrayTemp [counter2][counter3*3] = (int)(imageDisplayArray [counter2][counter3]*(double)0.627);
                        imageDisplayArrayTemp [counter2][counter3*3+1] = (int)(imageDisplayArray [counter2][counter3]*(double)0.125);
                        imageDisplayArrayTemp [counter2][counter3*3+2] = (int)(imageDisplayArray [counter2][counter3]*(double)0.941);
                    }
                    else if (colorNoHold == "9"){
                        imageDisplayArrayTemp [counter2][counter3*3] = (int)(imageDisplayArray [counter2][counter3]*(double)0.529);
                        imageDisplayArrayTemp [counter2][counter3*3+1] = (int)(imageDisplayArray [counter2][counter3]*(double)0.808);
                        imageDisplayArrayTemp [counter2][counter3*3+2] = (int)(imageDisplayArray [counter2][counter3]*(double)0.922);
                    }
                }
            }
            
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            for (int counter1 = 0; counter1 < stitchImageDimension; counter1 = counter1+counterIncrement){
                for (int counter2 = 0; counter2 < stitchImageDimension; counter2 = counter2+counterIncrement){
                    *bitmapData++ = (unsigned char)imageDisplayArrayTemp [counter1][counter2*3];
                    *bitmapData++ = (unsigned char)imageDisplayArrayTemp [counter1][counter2*3+1];
                    *bitmapData++ = (unsigned char)imageDisplayArrayTemp [counter1][counter2*3+2];
                    *bitmapData++ = 0;
                }
            }
            
            for (int counter1 = 0; counter1 < stitchImageDimension+2; counter1++){
                delete [] imageDisplayArrayTemp [counter1];
            }
            
            delete [] imageDisplayArrayTemp;
            
            mainImage = [[NSImage alloc] initWithSize:NSMakeSize(stitchImageDimension, stitchImageDimension)];
            [mainImage addRepresentation:bitmapReps];
        }
        
        if (imageFirstLoadFlagDisplay == 0){
            xPositionDisplay = 0;
            yPositionDisplay = 0;
            xPositionAdjustDisplay = 0;
            yPositionAdjustDisplay = 0;
            magnificationDisplay = 10;
            imageFirstLoadFlagDisplay = 1;
        }
        
        //-----Re-adjust window size and position-----
        int vertical = 450+78;
        int horizontal = 450;
        
        windowWidthDisplay = stitchImageDimension/(double)horizontal;
        windowHeightDisplay = stitchImageDimension/(double)(vertical-78);
        
        xPositionAdjustDisplay = (stitchImageDimension-stitchImageDimension/(double)(magnificationDisplay*0.1))/(double)2;
        yPositionAdjustDisplay = (stitchImageDimension-stitchImageDimension/(double)(magnificationDisplay*0.1))/(double)2;
        
        [self setNeedsDisplay:YES];
    }
}

-(void)mouseDown:(NSEvent *)event{
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDownDisplay = clickPoint.x;
        yPointDownDisplay = clickPoint.y;
        
        if (imageDataHoldStatus == 1){
            int xClickPositionMain = (int)(xPointDownDisplay*(double)windowWidthDisplay/(double)magnificationDisplay/(double)0.1+xPositionAdjustDisplay+xPositionDisplay);
            int yClickPositionMain = stitchImageDimension-(int)((yPointDownDisplay*(double)windowHeightDisplay/(double)magnificationDisplay/(double)0.1+yPositionAdjustDisplay+yPositionDisplay+windowHeightDisplay));
            
            if (xClickPositionMain > 0 && yClickPositionMain > 0){
                if (imageFLStatus == "Free"){
                    if (photoMetricHold == 1){
                        if (imagePositionMap [yClickPositionMain][xClickPositionMain] != 0){
                            processingFovNo = imagePositionMap [yClickPositionMain][xClickPositionMain];
                            
                            if (currentFOVNoHold == 0) currentFOVNoHold = processingFovNo;
                            else if (currentFOVNoHold != processingFovNo){
                                currentFOVNoHold = processingFovNo;
                                
                                if (currentFOVNoHold != -1) contrastValueDisplay = contrastValueHold [currentFOVNoHold];
                                else contrastValueDisplay = contrastValueHold [loadImageFOVNo+1];
                            }
                            
                            imageInfoDisplayCall = 1;
                            mouseDownFlag = 1;
                            histogramDisplayCall = 1;
                            contrastDisplayCall = 1;
                            
                            if (fovClickSide == 1){
                                fovFirstClick = imagePositionMap [yClickPositionMain][xClickPositionMain];
                                fovClickSide = 2;
                            }
                            else if (fovClickSide == 2){
                                fovSecondClick = imagePositionMap [yClickPositionMain][xClickPositionMain];
                                fovClickSide = 1;
                            }
                        }
                        else{
                            
                            processingFovNo = 0;
                            fovFirstClick = 0;
                            fovSecondClick = 0;
                            imageInfoDisplayCall = 1;
                        }
                    }
                    else if (photoMetricHold == 2){
                        if (imagePositionMap [yClickPositionMain][xClickPositionMain*3] != 0){
                            processingFovNo = imagePositionMap [yClickPositionMain][xClickPositionMain*3];
                            
                            if (currentFOVNoHold == 0) currentFOVNoHold = processingFovNo;
                            else if (currentFOVNoHold != processingFovNo){
                                currentFOVNoHold = processingFovNo;
                                
                                if (currentFOVNoHold != -1) contrastValueDisplay = contrastValueHold [currentFOVNoHold];
                                else contrastValueDisplay = contrastValueHold [loadImageFOVNo+1];
                                
                                if (currentFOVNoHold != -1) contrastValueDisplayG = contrastValueHoldG [currentFOVNoHold];
                                else contrastValueDisplayG = contrastValueHoldG [loadImageFOVNo+1];
                                
                                if (currentFOVNoHold != -1) contrastValueDisplayB = contrastValueHoldB [currentFOVNoHold];
                                else contrastValueDisplayB = contrastValueHoldB [loadImageFOVNo+1];
                            }
                            
                            imageInfoDisplayCall = 1;
                            mouseDownFlag = 1;
                            histogramDisplayCall = 1;
                            contrastDisplayCall = 1;
                            
                            if (fovClickSide == 1){
                                fovFirstClick = imagePositionMap [yClickPositionMain][xClickPositionMain*3];
                                fovClickSide = 2;
                            }
                            else if (fovClickSide == 2){
                                fovSecondClick = imagePositionMap [yClickPositionMain][xClickPositionMain*3];
                                fovClickSide = 1;
                            }
                        }
                        else{
                            
                            processingFovNo = 0;
                            fovFirstClick = 0;
                            fovSecondClick = 0;
                            imageInfoDisplayCall = 1;
                        }
                    }
                }
                else{
                    
                    if (photoMetricHold == 1){
                        if (currentFOVNoHold == 0) currentFOVNoHold = processingFovNo;
                        else if (currentFOVNoHold != processingFovNo){
                            currentFOVNoHold = processingFovNo;
                            
                            if (currentFOVNoHold != -1) contrastValueDisplay = contrastValueHold [currentFOVNoHold];
                            else contrastValueDisplay = contrastValueHold [loadImageFOVNo+1];
                        }
                    }
                    else if (photoMetricHold == 2){
                        if (currentFOVNoHold == 0) currentFOVNoHold = processingFovNo;
                        else if (currentFOVNoHold != processingFovNo){
                            currentFOVNoHold = processingFovNo;
                            
                            if (currentFOVNoHold != -1) contrastValueDisplay = contrastValueHold [currentFOVNoHold];
                            else contrastValueDisplay = contrastValueHold [loadImageFOVNo+1];
                            
                            if (currentFOVNoHold != -1) contrastValueDisplayG = contrastValueHoldG [currentFOVNoHold];
                            else contrastValueDisplayG = contrastValueHoldG [loadImageFOVNo+1];
                            
                            if (currentFOVNoHold != -1) contrastValueDisplayB = contrastValueHoldB [currentFOVNoHold];
                            else contrastValueDisplayB = contrastValueHoldB [loadImageFOVNo+1];
                        }
                    }
                    
                    contrastDisplayCall = 1;
                }
                
                [self setNeedsDisplay:YES];
            }
        }
    }
}

-(void)mouseUp:(NSEvent *)event{
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        xPositionDisplay = xPositionDisplay+xPositionMoveDisplay;
        yPositionDisplay = yPositionDisplay+yPositionMoveDisplay;
        xPositionMoveDisplay = 0;
        yPositionMoveDisplay = 0;
        mouseDragFlag = 0;
        mouseDownFlag = 0;
        
        [self setNeedsDisplay:YES];
    }
}

-(void)mouseDragged:(NSEvent *)event{
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDragDisplay = clickPoint.x;
        yPointDragDisplay = clickPoint.y;
        
        if (imageDataHoldStatus == 1){
            if (imageFLStatus == "Lock"){
                xPositionMoveDisplay = (xPointDownDisplay-xPointDragDisplay)*windowWidthDisplay/(double)(magnificationDisplay*0.1);
                yPositionMoveDisplay = (yPointDownDisplay-yPointDragDisplay)*windowHeightDisplay/(double)(magnificationDisplay*0.1);
            }
            else if (processingFovNo > 0){
                if (processMode == 2 || processMode == 8 || processMode == 10 || processMode == 3 || processMode == 9 || processMode == 11){
                    if (mouseDownFlag == 1){
                        xStartHold = arrayXYWritingPosition [processingFovNo*2];
                        yStartHold = arrayXYWritingPosition [processingFovNo*2+1];
                        mouseDownFlag = 2;
                    }
                    
                    int xStartCurrent = arrayXYWritingPosition [processingFovNo*2];
                    int yStartCurrent = arrayXYWritingPosition [processingFovNo*2+1];
                    int xMovePosition = (int)((xPointDownDisplay-xPointDragDisplay)*windowWidthDisplay/(double)(magnificationDisplay*0.1));
                    int yMovePosition = (int)((yPointDownDisplay-yPointDragDisplay)*windowHeightDisplay/(double)(magnificationDisplay*0.1));
                    
                    if (xStartHold-xMovePosition >= 0 && xStartHold-xMovePosition+imageDimensionX < stitchImageDimension && yStartHold+yMovePosition >= 0 && yStartHold+yMovePosition+imageDimensionY < stitchImageDimension){
                        arrayXYWritingPosition [processingFovNo*2] = xStartHold-xMovePosition;
                        arrayXYWritingPosition [processingFovNo*2+1] = yStartHold+yMovePosition;
                        
                        if (backgroundOADisplay == "Off"){
                            if (photoMetricHold == 1){
                                for (int counter1 = yStartCurrent+imageDimensionY-1; counter1 >= yStartCurrent; counter1--){
                                    for (int counter2 = xStartCurrent; counter2 < xStartCurrent+imageDimensionX; counter2++){
                                        if (counter2 >= 0 && counter2 < stitchImageDimension && counter1 >= 0 && counter1 < stitchImageDimension && imagePositionMap [counter1][counter2] == processingFovNo){
                                            if (colorNameHoldStatus == 0) imageDisplayArray [counter1][counter2] = 100;
                                            else imageDisplayArray [counter1][counter2] = 0;
                                            
                                            imagePositionMap [counter1][counter2] = 0;
                                        }
                                    }
                                }
                                
                                for (int counter1 = imageDimensionY-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                                        if (counter1+arrayXYWritingPosition [processingFovNo*2+1] >= 0 && counter1+arrayXYWritingPosition [processingFovNo*2+1] < stitchImageDimension && counter2+arrayXYWritingPosition [processingFovNo*2] >= 0 && counter2+arrayXYWritingPosition [processingFovNo*2] < stitchImageDimension){
                                            if (imagePositionMap [counter1+arrayXYWritingPosition [processingFovNo*2+1]][counter2+arrayXYWritingPosition [processingFovNo*2]] == 0){
                                                if (arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2] >= 0){
                                                    imageDisplayArray [counter1+arrayXYWritingPosition [processingFovNo*2+1]][counter2+arrayXYWritingPosition [processingFovNo*2]] = arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2];
                                                }
                                                else imageDisplayArray [counter1+arrayXYWritingPosition [processingFovNo*2+1]][counter2+arrayXYWritingPosition [processingFovNo*2]] = 0;
                                                
                                                imagePositionMap [counter1+arrayXYWritingPosition [processingFovNo*2+1]][counter2+arrayXYWritingPosition [processingFovNo*2]] = processingFovNo;
                                            }
                                        }
                                    }
                                }
                            }
                            else if (photoMetricHold == 2){
                                for (int counter1 = yStartCurrent+imageDimensionY-1; counter1 >= yStartCurrent; counter1--){
                                    for (int counter2 = xStartCurrent; counter2 < xStartCurrent+imageDimensionX; counter2++){
                                        if (counter2 >= 0 && counter2 < stitchImageDimension && counter1 >= 0 && counter1 < stitchImageDimension && imagePositionMap [counter1][counter2*3] == processingFovNo){
                                            if (colorNameHoldStatus == 0){
                                                imageDisplayArray [counter1][counter2*3] = 100;
                                                imageDisplayArray [counter1][counter2*3+1] = 100;
                                                imageDisplayArray [counter1][counter2*3+2] = 100;
                                            }
                                            else{
                                                
                                                imageDisplayArray [counter1][counter2*3] = 0;
                                                imageDisplayArray [counter1][counter2*3+1] = 0;
                                                imageDisplayArray [counter1][counter2*3+2] = 0;
                                            }
                                            
                                            imagePositionMap [counter1][counter2*3] = 0;
                                            imagePositionMap [counter1][counter2*3+1] = 0;
                                            imagePositionMap [counter1][counter2*3+2] = 0;
                                        }
                                    }
                                }
                                
                                for (int counter1 = imageDimensionY-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                                        if (counter1+arrayXYWritingPosition [processingFovNo*2+1] >= 0 && counter1+arrayXYWritingPosition [processingFovNo*2+1] < stitchImageDimension && counter2+arrayXYWritingPosition [processingFovNo*2] >= 0 && counter2+arrayXYWritingPosition [processingFovNo*2] < stitchImageDimension){
                                            if (imagePositionMap [counter1+arrayXYWritingPosition [processingFovNo*2+1]][(counter2+arrayXYWritingPosition [processingFovNo*2])*3] == 0){
                                                if (arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3] >= 0){
                                                    imageDisplayArray [counter1+arrayXYWritingPosition [processingFovNo*2+1]][(counter2+arrayXYWritingPosition [processingFovNo*2])*3] = arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3];
                                                    imageDisplayArray [counter1+arrayXYWritingPosition [processingFovNo*2+1]][(counter2+arrayXYWritingPosition [processingFovNo*2])*3+1] = arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1];
                                                    imageDisplayArray [counter1+arrayXYWritingPosition [processingFovNo*2+1]][(counter2+arrayXYWritingPosition [processingFovNo*2])*3+2] = arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2];
                                                }
                                                else{
                                                    
                                                    imageDisplayArray [counter1+arrayXYWritingPosition [processingFovNo*2+1]][(counter2+arrayXYWritingPosition [processingFovNo*2])*3] = 0;
                                                    imageDisplayArray [counter1+arrayXYWritingPosition [processingFovNo*2+1]][(counter2+arrayXYWritingPosition [processingFovNo*2])*3+1] = 0;
                                                    imageDisplayArray [counter1+arrayXYWritingPosition [processingFovNo*2+1]][(counter2+arrayXYWritingPosition [processingFovNo*2])*3+2] = 0;
                                                }
                                                
                                                imagePositionMap [counter1+arrayXYWritingPosition [processingFovNo*2+1]][(counter2+arrayXYWritingPosition [processingFovNo*2])*3] = processingFovNo;
                                                imagePositionMap [counter1+arrayXYWritingPosition [processingFovNo*2+1]][(counter2+arrayXYWritingPosition [processingFovNo*2])*3+1] = processingFovNo;
                                                imagePositionMap [counter1+arrayXYWritingPosition [processingFovNo*2+1]][(counter2+arrayXYWritingPosition [processingFovNo*2])*3+2] = processingFovNo;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else if (backgroundOADisplay == "On"){
                            for (int counter1 = yStartCurrent+imageDimensionY-1; counter1 >= yStartCurrent; counter1--){
                                for (int counter2 = xStartCurrent; counter2 < xStartCurrent+imageDimensionX; counter2++){
                                    if (counter2 >= 0 && counter2 < stitchImageDimension && counter1 >= 0 && counter1 < stitchImageDimension && imagePositionMap [counter1][counter2] == processingFovNo){
                                        if (colorNameHoldStatus == 0) imageDisplayArray [counter1][counter2] = 100;
                                        else imageDisplayArray [counter1][counter2] = 0;
                                        
                                        imagePositionMap [counter1][counter2] = 0;
                                    }
                                }
                            }
                            
                            for (int counter1 = imageDimensionY-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                                    if (counter1+arrayXYWritingPosition [processingFovNo*2+1] >= 0 && counter1+arrayXYWritingPosition [processingFovNo*2+1] < stitchImageDimension && counter2+arrayXYWritingPosition [processingFovNo*2] >= 0 && counter2+arrayXYWritingPosition [processingFovNo*2] < stitchImageDimension){
                                        if (imagePositionMap [counter1+arrayXYWritingPosition [processingFovNo*2+1]][counter2+arrayXYWritingPosition [processingFovNo*2]] == 0){
                                            if (arrayBackgroundDataHold [(processingFovNo-1)*imageDimensionY+counter1][counter2] >= 0){
                                                imageDisplayArray [counter1+arrayXYWritingPosition [processingFovNo*2+1]][counter2+arrayXYWritingPosition [processingFovNo*2]] = arrayBackgroundDataHold [(processingFovNo-1)*imageDimensionY+counter1][counter2];
                                            }
                                            else imageDisplayArray [counter1+arrayXYWritingPosition [processingFovNo*2+1]][counter2+arrayXYWritingPosition [processingFovNo*2]] = 0;
                                            
                                            imagePositionMap [counter1+arrayXYWritingPosition [processingFovNo*2+1]][counter2+arrayXYWritingPosition [processingFovNo*2]] = processingFovNo;
                                        }
                                    }
                                }
                            }
                        }
                        
                        int imageSetSize = 0;
                        int counterIncrement = 0;
                        
                        if (stitchImageDimension <= 1000){
                            imageSetSize = stitchImageDimension;
                            counterIncrement = 1;
                        }
                        else if (stitchImageDimension <= 4000){
                            imageSetSize = stitchImageDimension/2;
                            counterIncrement = 2;
                        }
                        else{
                            
                            imageSetSize = stitchImageDimension/4;
                            counterIncrement = 4;
                        }
                        
                        if (resolutionStatus == 0){
                            imageSetSize = stitchImageDimension;
                            counterIncrement = 1;
                        }
                        
                        if (colorNameHold == "Gray" || fluorescentDisplayModeHold == 1){
                            NSBitmapImageRep *bitmapReps;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize pixelsHigh:imageSetSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageSetSize bitsPerPixel:8];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (int counter1 = 0; counter1 < stitchImageDimension; counter1 = counter1+counterIncrement){
                                for (int counter2 = 0; counter2 < stitchImageDimension; counter2 = counter2+counterIncrement) *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2];
                            }
                            
                            mainImage = [[NSImage alloc] initWithSize:NSMakeSize(stitchImageDimension, stitchImageDimension)];
                            [mainImage addRepresentation:bitmapReps];
                        }
                        else if (colorNameHold == "Color R" || colorNameHold == "Color G" || colorNameHold == "Color B"){
                            NSBitmapImageRep *bitmapReps;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize pixelsHigh:imageSetSize bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageSetSize*4 bitsPerPixel:32];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (int counter1 = 0; counter1 < stitchImageDimension; counter1 = counter1+counterIncrement){
                                for (int counter2 = 0; counter2 < stitchImageDimension; counter2 = counter2+counterIncrement){
                                    *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2*3];
                                    *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2*3+1];
                                    *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2*3+2];
                                    *bitmapData++ = 0;
                                }
                            }
                            
                            mainImage = [[NSImage alloc] initWithSize:NSMakeSize(stitchImageDimension, stitchImageDimension)];
                            [mainImage addRepresentation:bitmapReps];
                        }
                        else if (colorNameHold != "nil"){
                            NSBitmapImageRep *bitmapReps;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize pixelsHigh:imageSetSize bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageSetSize*4 bitsPerPixel:32];
                            
                            int **imageDisplayArrayTemp = new int *[stitchImageDimension+2];
                            
                            for (int counter1 = 0; counter1 < stitchImageDimension+2; counter1++){
                                imageDisplayArrayTemp [counter1] = new int [stitchImageDimension*3+2];
                            }
                            
                            for (int counter2 = 0; counter2 < stitchImageDimension; counter2++){
                                for (int counter3 = 0; counter3 < stitchImageDimension; counter3++){
                                    if (colorNoHold == "1"){
                                        imageDisplayArrayTemp [counter2][counter3*3] = 0;
                                        imageDisplayArrayTemp [counter2][counter3*3+1] = 0;
                                        imageDisplayArrayTemp [counter2][counter3*3+2] = imageDisplayArray [counter2][counter3];
                                    }
                                    else if (colorNoHold == "2"){
                                        imageDisplayArrayTemp [counter2][counter3*3] = 0;
                                        imageDisplayArrayTemp [counter2][counter3*3+1] = imageDisplayArray [counter2][counter3];
                                        imageDisplayArrayTemp [counter2][counter3*3+2] = 0;
                                    }
                                    else if (colorNoHold == "3"){
                                        imageDisplayArrayTemp [counter2][counter3*3] = imageDisplayArray [counter2][counter3];
                                        imageDisplayArrayTemp [counter2][counter3*3+1] = imageDisplayArray [counter2][counter3];
                                        imageDisplayArrayTemp [counter2][counter3*3+2] = 0;
                                    }
                                    else if (colorNoHold == "4"){
                                        imageDisplayArrayTemp [counter2][counter3*3] = imageDisplayArray [counter2][counter3];
                                        imageDisplayArrayTemp [counter2][counter3*3+1] = 0;
                                        imageDisplayArrayTemp [counter2][counter3*3+2] = 0;
                                    }
                                    else if (colorNoHold == "5"){
                                        imageDisplayArrayTemp [counter2][counter3*3] = imageDisplayArray [counter2][counter3];
                                        imageDisplayArrayTemp [counter2][counter3*3+1] = 0;
                                        imageDisplayArrayTemp [counter2][counter3*3+2] = imageDisplayArray [counter2][counter3];
                                    }
                                    else if (colorNoHold == "6"){
                                        imageDisplayArrayTemp [counter2][counter3*3] = 0;
                                        imageDisplayArrayTemp [counter2][counter3*3+1] = imageDisplayArray [counter2][counter3];
                                        imageDisplayArrayTemp [counter2][counter3*3+2] = imageDisplayArray [counter2][counter3];
                                    }
                                    else if (colorNoHold == "7"){
                                        imageDisplayArrayTemp [counter2][counter3*3] = imageDisplayArray [counter2][counter3];
                                        imageDisplayArrayTemp [counter2][counter3*3+1] = (int)(imageDisplayArray [counter2][counter3]*(double)0.674);
                                        imageDisplayArrayTemp [counter2][counter3*3+2] = 0;
                                    }
                                    else if (colorNoHold == "8"){
                                        imageDisplayArrayTemp [counter2][counter3*3] = (int)(imageDisplayArray [counter2][counter3]*(double)0.627);
                                        imageDisplayArrayTemp [counter2][counter3*3+1] = (int)(imageDisplayArray [counter2][counter3]*(double)0.125);
                                        imageDisplayArrayTemp [counter2][counter3*3+2] = (int)(imageDisplayArray [counter2][counter3]*(double)0.941);
                                    }
                                    else if (colorNoHold == "9"){
                                        imageDisplayArrayTemp [counter2][counter3*3] = (int)(imageDisplayArray [counter2][counter3]*(double)0.529);
                                        imageDisplayArrayTemp [counter2][counter3*3+1] = (int)(imageDisplayArray [counter2][counter3]*(double)0.808);
                                        imageDisplayArrayTemp [counter2][counter3*3+2] = (int)(imageDisplayArray [counter2][counter3]*(double)0.922);
                                    }
                                }
                            }
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (int counter1 = 0; counter1 < stitchImageDimension; counter1 = counter1+counterIncrement){
                                for (int counter2 = 0; counter2 < stitchImageDimension; counter2 = counter2+counterIncrement){
                                    *bitmapData++ = (unsigned char)imageDisplayArrayTemp [counter1][counter2*3];
                                    *bitmapData++ = (unsigned char)imageDisplayArrayTemp [counter1][counter2*3+1];
                                    *bitmapData++ = (unsigned char)imageDisplayArrayTemp [counter1][counter2*3+2];
                                    *bitmapData++ = 0;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < stitchImageDimension+2; counter1++){
                                delete [] imageDisplayArrayTemp [counter1];
                            }
                            
                            delete [] imageDisplayArrayTemp;
                            
                            mainImage = [[NSImage alloc] initWithSize:NSMakeSize(stitchImageDimension, stitchImageDimension)];
                            [mainImage addRepresentation:bitmapReps];
                        }
                    }
                }
            }
            
            mouseDragFlag = 1;
            
            [self setNeedsDisplay:YES];
        }
    }
}

-(void)keyDown:(NSEvent *)event{
    int keyCode = [event keyCode];
    int proceedFlag = 0;
    
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        if (imageDataHoldStatus == 1){
            //----- Select contrast: it must be free; adjust one FOV, Save, then select another FOV and press C to apply the set contrast -----
            if (keyCode == 8){
                if (processingFovNo > 0){
                    if (backgroundOADisplay == "Off"){
                        contrastOADisplay = "On";
                        
                        contrastAdjust2 = [[ContrastAdjust2 alloc] init];
                        
                        int processType = 2;
                        int processResult = [contrastAdjust2 contrastAdjustMain2:processType];
                        
                        if (processResult == 1 && contrastValueDisplay != 0){
                            processType = 5;
                            [contrastAdjust2 contrastAdjustMain2:processType];
                        }
                        
                        imageInfoDisplayCall = 1;
                        histogramDisplayCall = 1;
                        contrastDisplayCall = 1;
                        proceedFlag = 2;
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Turn Off Background Mode To Proceed correction"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Release Image Lock"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            
            //-----Contrast All: Lock; the contrast set by C will be applied to all-----
            if (keyCode == 0){
                if (processingFovNo == -1){
                    if (backgroundOADisplay == "Off"){
                        contrastOADisplay = "On";
                        
                        contrastAdjust2 = [[ContrastAdjust2 alloc] init];
                        
                        int processType = 1;
                        int processResult = [contrastAdjust2 contrastAdjustMain2:processType];
                        
                        if (processResult == 1 && contrastValueDisplay != 0){
                            processType = 6;
                            [contrastAdjust2 contrastAdjustMain2:processType];
                        }
                        
                        imageInfoDisplayCall = 1;
                        histogramDisplayCall = 1;
                        contrastDisplayCall = 1;
                        proceedFlag = 2;
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Turn Off Background Mode To Proceed correction"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Image Locked"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            
            //-----Background correction On Off-----
            if (keyCode == 11){
                if (backgroundOADisplay == "Off"){
                    if (photoMetricHold == 1){
                        backgroundOADisplay = "On";
                        
                        int timeDataUse = 1;
                        string timeDetermine;
                        
                        for (int counter2 = 1; counter2 <= entryNumber; counter2++){
                            timeDetermine = arrayContrastData [0][counter2+2];
                            timeDetermine = timeDetermine.substr(1);
                            
                            if (autoType == 1 || autoType == 3){
                                if (atoi(timeDetermine.c_str()) < currentTimePoint+1) timeDataUse = counter2;
                            }
                            if (autoType == 2){
                                if (atoi(timeDetermine.c_str()) < loadImageNo+1) timeDataUse = counter2;
                            }
                            else if (atoi(timeDetermine.c_str()) < reprocessImageNo+1) timeDataUse = counter2;
                        }
                        
                        int treatFind = 0;
                        
                        string fovName2;
                        string balanceExtract;
                        
                        correctionValues = new double [treatmentNameDisplayCount+50];
                        
                        for (int counter2 = 0; counter2 < treatmentNameDisplayCount+50; counter2++) correctionValues [counter2] = -1;
                        
                        for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++){
                            fovName2 = arrayFOVNameDisplay [counter2];
                            
                            if (arrayTreatmentNameDisplay [counter2] == loadImageTreatName && fovName2 != "ND" && treatFind == 0){
                                treatFind = 1;
                                balanceExtract = arrayContrastData [counter2][timeDataUse+2].substr(arrayContrastData [counter2][timeDataUse+2].find("~")+1);
                            }
                            else if (arrayTreatmentNameDisplay [counter2] == "ND" && fovName2 != "ND" && treatFind == 1){
                                balanceExtract = arrayContrastData [counter2][timeDataUse+2].substr(arrayContrastData [counter2][timeDataUse+2].find("~")+1);
                            }
                            else if (((arrayTreatmentNameDisplay [counter2] != "ND" && fovName2 != "ND") || (arrayTreatmentNameDisplay [counter2] == "ND" && fovName2 == "ND")) && treatFind == 1){
                                treatFind = 2;
                            }
                        }
                        
                        double rangeLimitBase = 0;
                        double rangeLimitHorizontal = 0;
                        double rangeLimitVertical = 0;
                        
                        if ((int)balanceExtract.find("^") != -1){
                            rangeLimitBase = atof(balanceExtract.substr(0, balanceExtract.find("^")).c_str());
                            rangeLimitHorizontal = atof(balanceExtract.substr(balanceExtract.find("^")+1, balanceExtract.find("%")-balanceExtract.find("^")-1).c_str());
                            rangeLimitVertical = atof(balanceExtract.substr(balanceExtract.find("%")+1).c_str());
                        }
                        else rangeLimitBase = atof(balanceExtract.c_str());
                        
                        if (rangeLimitBase != 0 || rangeLimitHorizontal != 0 || rangeLimitVertical != 0){
                            ifstream fin;
                            
                            if (processMode == 5 || processMode == 13 || processMode == 7) fin.open(fovPositionTempPath.c_str(), ios::in);
                            else fin.open(fovPositionPath.c_str(), ios::in);
                            
                            if (fin.is_open()){
                                fin.close();
                                
                                int fovNoSet = loadImageFOVNo;
                                
                                balanceSet = [[BalanceSet alloc] init];
                                [balanceSet balanceSetMain:fovNoSet];
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < loadImageFOVNo; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                    if (correctionValues [counter2] != -1){
                                        if (arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4]/(double)correctionValues [counter2+1] > 255){
                                            arrayBackgroundDataHold [counter2*imageDimensionY+counter3][counter4] = 255;
                                        }
                                        else if (arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4]/(double)correctionValues [counter2+1] < 0){
                                            arrayBackgroundDataHold [counter2*imageDimensionY+counter3][counter4] = 0;
                                        }
                                        else arrayBackgroundDataHold [counter2*imageDimensionY+counter3][counter4] = (int)(arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4]/(double)correctionValues [counter2+1]);
                                    }
                                    else{
                                        
                                        arrayBackgroundDataHold [counter2*imageDimensionY+counter3][counter4] = arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4];
                                    }
                                }
                            }
                        }
                        
                        string treatNameTemp2;
                        string contrastDataTemp;
                        string backgroundRemoveLevel = "R";
                        
                        treatFind = 0;
                        
                        for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++){
                            treatNameTemp2 = arrayTreatmentNameDisplay [counter2];
                            fovName2 = arrayFOVNameDisplay [counter2];
                            
                            if (treatNameTemp2 == loadImageTreatName && fovName2 != "ND" && treatFind == 0){
                                contrastDataTemp = arrayTableDisplay [counter2*5+2];
                                backgroundRemoveLevel = contrastDataTemp.substr(contrastDataTemp.find(" ")+1, 1);
                                break;
                            }
                        }
                        
                        delete [] correctionValues;
                        
                        if (backgroundPatternFirstSet == 0){
                            string xDimensionString = to_string(imageDimensionX);
                            string yDimensionString = to_string(imageDimensionY);
                            
                            int numberOfBlock = (imageDimensionX/8)*(imageDimensionY/8)*250;
                            
                            backgroundPatternArrayStatus = 1;
                            
                            backgroundPatternArray = new int [numberOfBlock+50];
                            backgroundPatternArrayCount = 0;
                            
                            backgroundPatternModifyArray = new int [numberOfBlock+50];
                            backgroundPatternModifyArrayCount = 0;
                            
                            backgroundPatternName = new string [260];
                            
                            string patternPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/BKPattern"+"-"+xDimensionString+"&"+yDimensionString+".dat";
                            
                            ifstream fin;
                            
                            fin.open(patternPath.c_str(), ios::in);
                            
                            if (fin.is_open()){
                                string getString;
                                
                                do{
                                    
                                    getline(fin, getString);
                                    
                                    if (getString != "") backgroundPatternArray [backgroundPatternArrayCount] = atoi(getString.c_str()), backgroundPatternArrayCount++;
                                    
                                } while (getString != "");
                                
                                fin.close();
                                
                                backgroundPatternFirstSet = 1;
                                
                                patternPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/BKPatternModify"+"-"+xDimensionString+"&"+yDimensionString+".dat";
                                
                                fin.open(patternPath.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    do{
                                        
                                        getline(fin, getString);
                                        
                                        if (getString != "") backgroundPatternModifyArray [backgroundPatternModifyArrayCount] = atoi(getString.c_str()), backgroundPatternModifyArrayCount++;
                                        
                                    } while (getString != "");
                                    
                                    fin.close();
                                }
                                
                                patternPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/BKPatternName"+"-"+xDimensionString+"&"+yDimensionString+".dat";
                                
                                int backgroundPatternNameCount = 0;
                                
                                for (int counter1 = 0; counter1 < 250; counter1++) backgroundPatternName [counter1] = "nil";
                                
                                fin.open(patternPath.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    do{
                                        
                                        getline(fin, getString);
                                        
                                        if (getString != "") backgroundPatternName [backgroundPatternNameCount] = getString, backgroundPatternNameCount++;
                                        
                                    } while (getString != "");
                                    
                                    fin.close();
                                }
                            }
                            else{
                                
                                backgroundPatternArrayCount = 0;
                                backgroundPatternModifyArrayCount = 0;
                            }
                        }
                        
                        backgroundCorrectionCall = 1;
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Color Images Unsupported"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if (backgroundOADisplay == "On"){
                    backgroundOADisplay = "Off";
                    imageInfoDisplayCall = 1;
                    contrastDisplayCall = 1;
                    histogramDisplayCall = 1;
                    proceedFlag = 2;
                }
            }
            
            //-----Original position-----
            if (keyCode == 6){
                xPositionDisplay = 0;
                yPositionDisplay = 0;
                xPositionAdjustDisplay = 0;
                yPositionAdjustDisplay = 0;
                magnificationDisplay = 10;
                
                xPositionAdjustDisplay = (stitchImageDimension-stitchImageDimension/(double)(magnificationDisplay*0.1))/(double)2;
                yPositionAdjustDisplay = (stitchImageDimension-stitchImageDimension/(double)(magnificationDisplay*0.1))/(double)2;
                
                proceedFlag = 1;
            }
            
            //-----FOV Lock/Free-----
            if (keyCode == 34){
                if (imageFLStatus == "Lock"){
                    imageFLStatus = "Free";
                    processingFovNo = 0;
                    imageInfoDisplayCall = 1;
                }
                else if (imageFLStatus == "Free"){
                    imageFLStatus = "Lock";
                    processingFovNo = -1;
                    imageInfoDisplayCall = 1;
                    histogramDisplayCall = 1;
                    fovFirstClick = 0;
                    fovSecondClick = 0;
                }
                
                proceedFlag = 1;
            }
            
            //-----Resolution-----
            if (keyCode == 31){
                if (resolutionStatus == 0) resolutionStatus = 1;
                else if (resolutionStatus == 1) resolutionStatus = 0;
                
                proceedFlag = 1;
            }
            
            //-----Reorder-----
            if (keyCode == 15){
                if (photoMetricHold == 1){
                    for (int counter1 = 0; counter1 < stitchImageDimension; counter1++){
                        for (int counter2 = 0; counter2 < stitchImageDimension; counter2++){
                            if (colorNameHoldStatus == 0) imageDisplayArray [counter1][counter2] = 100;
                            else imageDisplayArray [counter1][counter2] = 0;
                            
                            imagePositionMap [counter1][counter2] = 0;
                        }
                    }
                }
                else if (photoMetricHold == 2){
                    for (int counter1 = 0; counter1 < stitchImageDimension; counter1++){
                        for (int counter2 = 0; counter2 < stitchImageDimension; counter2++){
                            if (colorNameHoldStatus == 0){
                                imageDisplayArray [counter1][counter2*3] = 100;
                                imageDisplayArray [counter1][counter2*3+1] = 100;
                                imageDisplayArray [counter1][counter2*3+2] = 100;
                            }
                            else{
                                
                                imageDisplayArray [counter1][counter2*3] = 0;
                                imageDisplayArray [counter1][counter2*3+1] = 0;
                                imageDisplayArray [counter1][counter2*3+2] = 0;
                            }
                            
                            imagePositionMap [counter1][counter2*3] = 0;
                            imagePositionMap [counter1][counter2*3+1] = 0;
                            imagePositionMap [counter1][counter2*3+2] = 0;
                        }
                    }
                }
                
                if (backgroundOADisplay == "Off"){
                    if (photoMetricHold == 1){
                        for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                            arrayXYWritingPosition [counter1*2] = xyPositionDataHold [counter1*2];
                            arrayXYWritingPosition [counter1*2+1] = xyPositionDataHold [counter1*2+1];
                            
                            for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                                for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                    if (counter2+xyPositionDataHold [counter1*2+1] >= 0 && counter2+xyPositionDataHold [counter1*2+1] < stitchImageDimension && counter3+xyPositionDataHold [counter1*2] >= 0 && counter3+xyPositionDataHold [counter1*2] < stitchImageDimension){
                                        if (arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3] >= 0){
                                            imageDisplayArray [counter2+xyPositionDataHold [counter1*2+1]][counter3+xyPositionDataHold [counter1*2]] = arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3];
                                        }
                                        else imageDisplayArray [counter2+xyPositionDataHold [counter1*2+1]][counter3+xyPositionDataHold [counter1*2]] = 0;
                                        
                                        imagePositionMap [counter2+xyPositionDataHold [counter1*2+1]][counter3+xyPositionDataHold [counter1*2]] = counter1;
                                    }
                                }
                            }
                        }
                    }
                    else if (photoMetricHold == 2){
                        for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                            arrayXYWritingPosition [counter1*2] = xyPositionDataHold [counter1*2];
                            arrayXYWritingPosition [counter1*2+1] = xyPositionDataHold [counter1*2+1];
                            
                            for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                                for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                    if (counter2+xyPositionDataHold [counter1*2+1] >= 0 && counter2+xyPositionDataHold [counter1*2+1] < stitchImageDimension && counter3+xyPositionDataHold [counter1*2] >= 0 && counter3+xyPositionDataHold [counter1*2] < stitchImageDimension){
                                        if (arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3] >= 0){
                                            imageDisplayArray [counter2+xyPositionDataHold [counter1*2+1]][(counter3+xyPositionDataHold [counter1*2])*3] = arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3];
                                            imageDisplayArray [counter2+xyPositionDataHold [counter1*2+1]][(counter3+xyPositionDataHold [counter1*2])*3+1] = arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3+1];
                                            imageDisplayArray [counter2+xyPositionDataHold [counter1*2+1]][(counter3+xyPositionDataHold [counter1*2])*3+2] = arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3+2];
                                        }
                                        else{
                                            
                                            imageDisplayArray [counter2+xyPositionDataHold [counter1*2+1]][(counter3+xyPositionDataHold [counter1*2])*3] = 0;
                                            imageDisplayArray [counter2+xyPositionDataHold [counter1*2+1]][(counter3+xyPositionDataHold [counter1*2])*3+1] = 0;
                                            imageDisplayArray [counter2+xyPositionDataHold [counter1*2+1]][(counter3+xyPositionDataHold [counter1*2])*3+2] = 0;
                                            
                                        }
                                        
                                        imagePositionMap [counter2+xyPositionDataHold [counter1*2+1]][(counter3+xyPositionDataHold [counter1*2])*3] = counter1;
                                        imagePositionMap [counter2+xyPositionDataHold [counter1*2+1]][(counter3+xyPositionDataHold [counter1*2])*3+1] = counter1;
                                        imagePositionMap [counter2+xyPositionDataHold [counter1*2+1]][(counter3+xyPositionDataHold [counter1*2])*3+2] = counter1;
                                    }
                                }
                            }
                        }
                    }
                }
                else if (backgroundOADisplay == "On"){
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        arrayXYWritingPosition [counter1*2] = xyPositionDataHold [counter1*2];
                        arrayXYWritingPosition [counter1*2+1] = xyPositionDataHold [counter1*2+1];
                        
                        for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                if (counter2+xyPositionDataHold [counter1*2+1] >= 0 && counter2+xyPositionDataHold [counter1*2+1] < stitchImageDimension && counter3+xyPositionDataHold [counter1*2] >= 0 && counter3+xyPositionDataHold [counter1*2] < stitchImageDimension){
                                    if (arrayBackgroundDataHold [(counter1-1)*imageDimensionY+counter2][counter3] >= 0){
                                        imageDisplayArray [counter2+xyPositionDataHold [counter1*2+1]][counter3+xyPositionDataHold [counter1*2]] = arrayBackgroundDataHold [(counter1-1)*imageDimensionY+counter2][counter3];
                                    }
                                    else imageDisplayArray [counter2+xyPositionDataHold [counter1*2+1]][counter3+xyPositionDataHold [counter1*2]] = 0;
                                    
                                    imagePositionMap [counter2+xyPositionDataHold [counter1*2+1]][counter3+xyPositionDataHold [counter1*2]] = counter1;
                                }
                            }
                        }
                    }
                }
                
                proceedFlag = 1;
            }
            
            if (keyCode == 124 && imageFLStatus == "Free" && processingFovNo != 0){
                processingFovNo++;
                
                if (loadImageFOVNo < processingFovNo) processingFovNo--;
                
                xPositionDisplay = arrayXYWritingPosition [processingFovNo*2]-stitchImageDimension/2+imageDimensionX/2;
                yPositionDisplay = (stitchImageDimension-(arrayXYWritingPosition [processingFovNo*2+1]+imageDimensionY/2))-stitchImageDimension/2;
                
                imageInfoDisplayCall = 1;
                proceedFlag = 1;
            }
            
            if (keyCode == 123 && imageFLStatus == "Free" && processingFovNo != 0){
                processingFovNo--;
                
                if (processingFovNo <= 0) processingFovNo = 1;
                
                xPositionDisplay = arrayXYWritingPosition [processingFovNo*2]-stitchImageDimension/2+imageDimensionX/2;
                yPositionDisplay = (stitchImageDimension-(arrayXYWritingPosition [processingFovNo*2+1]+imageDimensionY/2))-stitchImageDimension/2;
                
                imageInfoDisplayCall = 1;
                proceedFlag = 1;
            }
            
            //-----Magnification Magnify-----
            if (keyCode == 125){
                if (magnificationDisplay >= 10 && magnificationDisplay <= 490){
                    proceedFlag = 1;
                    
                    if (magnificationDisplay-10 < 10) magnificationDisplay = 10;
                    else magnificationDisplay = magnificationDisplay-10;
                    
                    xPositionAdjustDisplay = -1*(stitchImageDimension/(double)(magnificationDisplay*0.1)-stitchImageDimension)/(double)2;
                    yPositionAdjustDisplay = -1*(stitchImageDimension/(double)(magnificationDisplay*0.1)-stitchImageDimension)/(double)2;
                }
                else if (magnificationDisplay < 10) magnificationDisplay = 10;
            }
            
            //-----Magnification Reduction-----
            if (keyCode == 126){
                if (magnificationDisplay >= 10 && magnificationDisplay <= 490){
                    proceedFlag = 1;
                    
                    if (magnificationDisplay+10 > 490) magnificationDisplay = 490;
                    else magnificationDisplay = magnificationDisplay+10;
                    
                    xPositionAdjustDisplay = (stitchImageDimension-stitchImageDimension/(double)(magnificationDisplay*0.1))/(double)2;
                    yPositionAdjustDisplay = (stitchImageDimension-stitchImageDimension/(double)(magnificationDisplay*0.1))/(double)2;
                }
                else if (magnificationDisplay > 490) magnificationDisplay = 490;
            }
            
            //-----X direction set-----
            if (keyCode == 7){
                if (processMode == 2 || processMode == 8 || processMode == 10 || processMode == 3 || processMode == 9 || processMode == 11){
                    int orientationType = 1;
                    objectMatch = [[ObjectMatch alloc] init];
                    [objectMatch objectMatchMain:orientationType];
                    
                    proceedFlag = 2;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"XY Positions Cannot Be Changed"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            
            //-----Y direction set-----
            if (keyCode == 16){
                if (processMode == 2 || processMode == 8 || processMode == 10 || processMode == 3 || processMode == 9 || processMode == 11){
                    int orientationType = 2;
                    objectMatch = [[ObjectMatch alloc] init];
                    [objectMatch objectMatchMain:orientationType];
                    
                    proceedFlag = 2;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"XY Positions Cannot Be Changed"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            
            //-----XY status clear-----
            if (keyCode == 14){
                if (processMode == 2 || processMode == 8 || processMode == 10 || processMode == 3 || processMode == 9 || processMode == 11){
                    positionSetStatus = 0;
                    proceedFlag = 1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"XY Positions Cannot Be Changed"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            
            //-----Use previous setting-----
            if (keyCode == 32){
                if (fovFirstSetFlag == 1){
                    fovFirstClick = fovFirstClickOR1;
                    fovSecondClick = fovSecondClickOR1;
                    
                    int orientationType = 3;
                    objectMatch = [[ObjectMatch alloc] init];
                    [objectMatch objectMatchMain:orientationType];
                    
                    fovFirstClick = fovFirstClickOR2;
                    fovSecondClick = fovSecondClickOR2;
                    
                    orientationType = 4;
                    objectMatch = [[ObjectMatch alloc] init];
                    [objectMatch objectMatchMain:orientationType];
                    proceedFlag = 2;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"FOV (XY) Positions Not Adjusted"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            
            //-----Dimension set-----
            if (keyCode == 35){
                if (processMode == 2 || processMode == 8 || processMode == 10 || processMode == 3 || processMode == 9 || processMode == 11){
                    objectMatch = [[ObjectMatch alloc] init];
                    [objectMatch overlapCheck];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"XY Positions Cannot Be Changed"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            
            if (proceedFlag == 2){
                if (photoMetricHold == 1){
                    for (int counter1 = 0; counter1 < stitchImageDimension; counter1++){
                        for (int counter2 = 0; counter2 < stitchImageDimension; counter2++){
                            if (colorNameHoldStatus == 0) imageDisplayArray [counter1][counter2] = 100;
                            else imageDisplayArray [counter1][counter2] = 0;
                            
                            imagePositionMap [counter1][counter2] = 0;
                        }
                    }
                }
                else if (photoMetricHold == 2){
                    for (int counter1 = 0; counter1 < stitchImageDimension; counter1++){
                        for (int counter2 = 0; counter2 < stitchImageDimension; counter2++){
                            if (colorNameHoldStatus == 0){
                                imageDisplayArray [counter1][counter2*3] = 100;
                                imageDisplayArray [counter1][counter2*3+1] = 100;
                                imageDisplayArray [counter1][counter2*3+2] = 100;
                            }
                            else{
                                
                                imageDisplayArray [counter1][counter2*3] = 0;
                                imageDisplayArray [counter1][counter2*3+1] = 0;
                                imageDisplayArray [counter1][counter2*3+2] = 0;
                            }
                            
                            imagePositionMap [counter1][counter2*3] = 0;
                            imagePositionMap [counter1][counter2*3+1] = 0;
                            imagePositionMap [counter1][counter2*3+2] = 0;
                        }
                    }
                }
                
                if (backgroundOADisplay == "Off"){
                    if (photoMetricHold == 1){
                        for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                            for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                                for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                    if (counter2+arrayXYWritingPosition [counter1*2+1] >= 0 && counter2+arrayXYWritingPosition [counter1*2+1] < stitchImageDimension && counter3+arrayXYWritingPosition [counter1*2] >= 0 && counter3+arrayXYWritingPosition [counter1*2] < stitchImageDimension){
                                        if (arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3] >= 0){
                                            imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3];
                                        }
                                        else imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = 0;
                                        
                                        imagePositionMap [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = counter1;
                                    }
                                }
                            }
                        }
                    }
                    else if (photoMetricHold == 2){
                        for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                            for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                                for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                    if (counter2+arrayXYWritingPosition [counter1*2+1] >= 0 && counter2+arrayXYWritingPosition [counter1*2+1] < stitchImageDimension && counter3+arrayXYWritingPosition [counter1*2] >= 0 && counter3+arrayXYWritingPosition [counter1*2] < stitchImageDimension){
                                        if (arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3] >= 0){
                                            imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3] = arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3];
                                            imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3+1] = arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3+1];
                                            imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3+2] = arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3*3+2];
                                        }
                                        else{
                                            
                                            imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3] = 0;
                                            imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3+1] = 0;
                                            imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3+2] = 0;
                                        }
                                        
                                        imagePositionMap [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3] = counter1;
                                        imagePositionMap [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3+1] = counter1;
                                        imagePositionMap [counter2+arrayXYWritingPosition [counter1*2+1]][(counter3+arrayXYWritingPosition [counter1*2])*3+2] = counter1;
                                    }
                                }
                            }
                        }
                    }
                }
                else if (backgroundOADisplay == "On"){
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                if (counter2+arrayXYWritingPosition [counter1*2+1] >= 0 && counter2+arrayXYWritingPosition [counter1*2+1] < stitchImageDimension && counter3+arrayXYWritingPosition [counter1*2] >= 0 && counter3+arrayXYWritingPosition [counter1*2] < stitchImageDimension){
                                    if(arrayBackgroundDataHold [(counter1-1)*imageDimensionY+counter2][counter3] >= 0){
                                        imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = arrayBackgroundDataHold [(counter1-1)*imageDimensionY+counter2][counter3];
                                    }
                                    else imageDisplayArray [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = 0;
                                    
                                    imagePositionMap [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = counter1;
                                }
                            }
                        }
                    }
                }
                
                proceedFlag = 1;
            }
            
            if (proceedFlag == 1){
                int imageSetSize = 0;
                int counterIncrement = 0;
                
                if (stitchImageDimension <= 1000){
                    imageSetSize = stitchImageDimension;
                    counterIncrement = 1;
                }
                else if (stitchImageDimension <= 4000){
                    imageSetSize = stitchImageDimension/2;
                    counterIncrement = 2;
                }
                else{
                    
                    imageSetSize = stitchImageDimension/4;
                    counterIncrement = 4;
                }
                
                if (resolutionStatus == 0){
                    imageSetSize = stitchImageDimension;
                    counterIncrement = 1;
                }
                
                if (colorNameHold == "Gray" || fluorescentDisplayModeHold == 1){
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize pixelsHigh:imageSetSize bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageSetSize bitsPerPixel:8];
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter1 = 0; counter1 < stitchImageDimension; counter1 = counter1+counterIncrement){
                        for (int counter2 = 0; counter2 < stitchImageDimension; counter2 = counter2+counterIncrement) *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2];
                    }
                    
                    mainImage = [[NSImage alloc] initWithSize:NSMakeSize(stitchImageDimension, stitchImageDimension)];
                    [mainImage addRepresentation:bitmapReps];
                }
                else if (colorNameHold == "Color R" || colorNameHold == "Color G" || colorNameHold == "Color B"){
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize pixelsHigh:imageSetSize bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageSetSize*4 bitsPerPixel:32];
                    
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter1 = 0; counter1 < stitchImageDimension; counter1 = counter1+counterIncrement){
                        for (int counter2 = 0; counter2 < stitchImageDimension; counter2 = counter2+counterIncrement){
                            *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2*3];
                            *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2*3+1];
                            *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2*3+2];
                            *bitmapData++ = 0;
                        }
                    }
                    
                    mainImage = [[NSImage alloc] initWithSize:NSMakeSize(stitchImageDimension, stitchImageDimension)];
                    [mainImage addRepresentation:bitmapReps];
                }
                else if (colorNameHold != "nil"){
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize pixelsHigh:imageSetSize bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageSetSize*4 bitsPerPixel:32];
                    
                    int **imageDisplayArrayTemp = new int *[stitchImageDimension+2];
                    
                    for (int counter1 = 0; counter1 < stitchImageDimension+2; counter1++){
                        imageDisplayArrayTemp [counter1] = new int [stitchImageDimension*3+2];
                    }
                    
                    for (int counter2 = 0; counter2 < stitchImageDimension; counter2++){
                        for (int counter3 = 0; counter3 < stitchImageDimension; counter3++){
                            if (colorNoHold == "1"){
                                imageDisplayArrayTemp [counter2][counter3*3] = 0;
                                imageDisplayArrayTemp [counter2][counter3*3+1] = 0;
                                imageDisplayArrayTemp [counter2][counter3*3+2] = imageDisplayArray [counter2][counter3];
                            }
                            else if (colorNoHold == "2"){
                                imageDisplayArrayTemp [counter2][counter3*3] = 0;
                                imageDisplayArrayTemp [counter2][counter3*3+1] = imageDisplayArray [counter2][counter3];
                                imageDisplayArrayTemp [counter2][counter3*3+2] = 0;
                            }
                            else if (colorNoHold == "3"){
                                imageDisplayArrayTemp [counter2][counter3*3] = imageDisplayArray [counter2][counter3];
                                imageDisplayArrayTemp [counter2][counter3*3+1] = imageDisplayArray [counter2][counter3];
                                imageDisplayArrayTemp [counter2][counter3*3+2] = 0;
                            }
                            else if (colorNoHold == "4"){
                                imageDisplayArrayTemp [counter2][counter3*3] = imageDisplayArray [counter2][counter3];
                                imageDisplayArrayTemp [counter2][counter3*3+1] = 0;
                                imageDisplayArrayTemp [counter2][counter3*3+2] = 0;
                            }
                            else if (colorNoHold == "5"){
                                imageDisplayArrayTemp [counter2][counter3*3] = imageDisplayArray [counter2][counter3];
                                imageDisplayArrayTemp [counter2][counter3*3+1] = 0;
                                imageDisplayArrayTemp [counter2][counter3*3+2] = imageDisplayArray [counter2][counter3];
                            }
                            else if (colorNoHold == "6"){
                                imageDisplayArrayTemp [counter2][counter3*3] = 0;
                                imageDisplayArrayTemp [counter2][counter3*3+1] = imageDisplayArray [counter2][counter3];
                                imageDisplayArrayTemp [counter2][counter3*3+2] = imageDisplayArray [counter2][counter3];
                            }
                            else if (colorNoHold == "7"){
                                imageDisplayArrayTemp [counter2][counter3*3] = imageDisplayArray [counter2][counter3];
                                imageDisplayArrayTemp [counter2][counter3*3+1] = (int)(imageDisplayArray [counter2][counter3]*(double)0.674);
                                imageDisplayArrayTemp [counter2][counter3*3+2] = 0;
                            }
                            else if (colorNoHold == "8"){
                                imageDisplayArrayTemp [counter2][counter3*3] = (int)(imageDisplayArray [counter2][counter3]*(double)0.627);
                                imageDisplayArrayTemp [counter2][counter3*3+1] = (int)(imageDisplayArray [counter2][counter3]*(double)0.125);
                                imageDisplayArrayTemp [counter2][counter3*3+2] = (int)(imageDisplayArray [counter2][counter3]*(double)0.941);
                            }
                            else if (colorNoHold == "9"){
                                imageDisplayArrayTemp [counter2][counter3*3] = (int)(imageDisplayArray [counter2][counter3]*(double)0.529);
                                imageDisplayArrayTemp [counter2][counter3*3+1] = (int)(imageDisplayArray [counter2][counter3]*(double)0.808);
                                imageDisplayArrayTemp [counter2][counter3*3+2] = (int)(imageDisplayArray [counter2][counter3]*(double)0.922);
                            }
                        }
                    }
                    
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter1 = 0; counter1 < stitchImageDimension; counter1 = counter1+counterIncrement){
                        for (int counter2 = 0; counter2 < stitchImageDimension; counter2 = counter2+counterIncrement){
                            *bitmapData++ = (unsigned char)imageDisplayArrayTemp [counter1][counter2*3];
                            *bitmapData++ = (unsigned char)imageDisplayArrayTemp [counter1][counter2*3+1];
                            *bitmapData++ = (unsigned char)imageDisplayArrayTemp [counter1][counter2*3+2];
                            *bitmapData++ = 0;
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < stitchImageDimension+2; counter1++){
                        delete [] imageDisplayArrayTemp [counter1];
                    }
                    
                    delete [] imageDisplayArrayTemp;
                    
                    mainImage = [[NSImage alloc] initWithSize:NSMakeSize(stitchImageDimension, stitchImageDimension)];
                    [mainImage addRepresentation:bitmapReps];
                }
                
                [self setNeedsDisplay:YES];
            }
        }
    }
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)drawRect:(NSRect)rect{
    NSRect srcRect;
    
    srcRect.origin.x = xPositionDisplay+xPositionAdjustDisplay+xPositionMoveDisplay;
    srcRect.origin.y = yPositionDisplay+yPositionAdjustDisplay+yPositionMoveDisplay;
    srcRect.size.width = stitchImageDimension/(double)(magnificationDisplay*0.1);
    srcRect.size.height = stitchImageDimension/(double)(magnificationDisplay*0.1);
    
    [mainImage drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
    
    if (mouseDragFlag == 0 && imageDataHoldStatus == 1){
        double xPositionAdj = xPositionAdjustDisplay+xPositionDisplay;
        double yPositionAdj = yPositionAdjustDisplay+yPositionDisplay;
        double xCalValue = 1/(double)windowWidthDisplay*magnificationDisplay*0.1;
        double yCalValue = 1/(double)windowHeightDisplay*magnificationDisplay*0.1;
        double magnificationFont = magnificationDisplay*0.08*5.0*4992/(double)stitchImageDimension;
        
        NSPoint pointA;
        NSAttributedString *attrStrA;
        NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
        [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
        [attributesA setObject:[NSFont systemFontOfSize:magnificationFont] forKey:NSFontAttributeName];
        
        NSString *fovNumberDisplay;
        
        for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
            fovNumberDisplay = [NSString stringWithFormat:@"%d", counter1];
            
            attrStrA = [[NSAttributedString alloc] initWithString:fovNumberDisplay attributes:attributesA];
            
            pointA.x = (arrayXYWritingPosition [counter1*2]+imageDimensionX/2-xPositionAdj)*xCalValue;
            pointA.y = ((stitchImageDimension-(arrayXYWritingPosition [counter1*2+1]+imageDimensionY/2))-yPositionAdj)*yCalValue;
            [attrStrA drawAtPoint:pointA];
        }
        
        [attributesA setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
        [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
        [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
        
        string extension;
        
        if (processingFovNo != -1){
            string horizontalLine = "";
            string verticalLine = "";
            string stringTemp;
            string extractString1;
            
            int findFlag = 0;
            int terminationFlag = 0;
            
            for (int counter1 = 0; counter1 < horizontalLinkCount; counter1++){
                stringTemp = arrayHorizontalLink [counter1];
                findFlag = 0;
                
                do {
                    
                    terminationFlag = 0;
                    
                    if ((int)stringTemp.find ("/") == -1){
                        terminationFlag = 1;
                        
                        if (atoi(stringTemp.c_str()) == processingFovNo) findFlag = 1;
                    }
                    else{
                        
                        extractString1 = stringTemp.substr(0, stringTemp.find ("/"));
                        
                        if (atoi(extractString1.c_str()) == processingFovNo){
                            terminationFlag = 1;
                            findFlag = 1;
                        }
                        
                        stringTemp = stringTemp.substr(stringTemp.find ("/")+1);
                    }
                    
                } while (terminationFlag == 0);
                
                if (findFlag == 1){
                    horizontalLine = arrayHorizontalLink [counter1];
                    break;
                }
            }
            
            if (horizontalLine == "") horizontalLine = to_string(processingFovNo);
            
            for (int counter1 = 0; counter1 < verticalLinkCount; counter1++){
                stringTemp = arrayVerticalLink [counter1];
                findFlag = 0;
                
                do {
                    
                    terminationFlag = 0;
                    
                    if ((int)stringTemp.find ("/") == -1){
                        terminationFlag = 1;
                        if (atoi(stringTemp.c_str()) == processingFovNo) findFlag = 1;
                    }
                    else{
                        
                        extractString1 = stringTemp.substr(0, stringTemp.find ("/"));
                        
                        if (atoi(extractString1.c_str()) == processingFovNo){
                            terminationFlag = 1;
                            findFlag = 1;
                        }
                        
                        stringTemp = stringTemp.substr(stringTemp.find ("/")+1);
                    }
                    
                } while (terminationFlag == 0);
                
                if (findFlag == 1){
                    verticalLine = arrayVerticalLink [counter1];
                    break;
                }
            }
            
            if (verticalLine == "") verticalLine = to_string(processingFovNo);
            
            verticalLine = "Y FOV: "+verticalLine;
            horizontalLine = "X FOV: "+horizontalLine;
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(horizontalLine.c_str()) attributes:attributesA];
            pointA.x = 100;
            pointA.y = 432;
            [attrStrA drawAtPoint:pointA];
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(verticalLine.c_str()) attributes:attributesA];
            pointA.x = 100;
            pointA.y = 420;
            [attrStrA drawAtPoint:pointA];
            
            extension = "Fst  :"+to_string(fovFirstClick);
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributesA];
            pointA.x = 55;
            pointA.y = 432;
            [attrStrA drawAtPoint:pointA];
            
            extension = "Snd :"+to_string(fovSecondClick);
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributesA];
            pointA.x = 55;
            pointA.y = 420;
            [attrStrA drawAtPoint:pointA];
            
            if (positionSetStatus == 1){
                [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                extension = "Do Y set";
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributesA];
                pointA.x = 55;
                pointA.y = 406;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (positionSetStatus == 2){
                [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                extension = "Do X set";
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributesA];
                pointA.x = 55;
                pointA.y = 406;
                [attrStrA drawAtPoint:pointA];
            }
        }
        
        if (resolutionStatus == 0){
            [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
            extension = "Original";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributesA];
            pointA.x = 5;
            pointA.y = 432;
            [attrStrA drawAtPoint:pointA];
        }
        else if (resolutionStatus == 1){
            [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
            extension = "Reduced";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributesA];
            pointA.x = 5;
            pointA.y = 432;
            [attrStrA drawAtPoint:pointA];
        }
    }
    
    if (callFromHistogram == 1) callFromHistogram++;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToMainImage object:nil];
}

@end
