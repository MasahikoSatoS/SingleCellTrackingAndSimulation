//
//  SubProcesses.h
//  Contrast_Set
//
//  Created by Masahiko Sato on 2021-10-19.
//  Copyright Masahiko Sato 2021 All rights reserved.
//

#ifndef SUBPROCESSES_H
#define SUBPROCESSES_H
#import "Controller.h"
#endif

@interface SubProcesses : NSObject{
}

-(void)displayTableSetInit:(int)startingTimePoint :(int)rgbCheck :(int)mode;
-(void)displayTableSet:(int)startingTimePoint;
-(void)variableSave;

@end
