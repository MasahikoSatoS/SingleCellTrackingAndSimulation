//
//  SubProcesses.m
//  Contrast_Set
//
//  Created by ImagingB on 2021-10-19.
//

#import "SubProcesses.h"

@implementation SubProcesses
-(void)displayTableSetInit:(int)startingTimePoint :(int)rgbCheck :(int)mode{
    //-----Line One set-----
    arrayTableDisplay [tableDisplayCount] = "Name", tableDisplayCount++;
    arrayTableDisplay [tableDisplayCount] = "FOV", tableDisplayCount++;
    arrayTableDisplay [tableDisplayCount] = "Image Data", tableDisplayCount++;
    
    for (int counter1 = startingTimePoint; counter1 < startingTimePoint+2; counter1++){
        if (counter1 > entryNumber) arrayTableDisplay [tableDisplayCount] = "T*", tableDisplayCount++;
        else arrayTableDisplay [tableDisplayCount] = arrayContrastData [0][counter1+2], tableDisplayCount++;
    }
    
    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
        if (arrayTreatmentNameDisplay [counter1] != "ND") arrayTableDisplay [tableDisplayCount] = arrayTreatmentNameDisplay [counter1], tableDisplayCount++;
        else arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
        
        if (arrayFOVNameDisplay [counter1] != "ND") arrayTableDisplay [tableDisplayCount] = arrayFOVNameDisplay [counter1], tableDisplayCount++;
        else arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
        
        if (mode == 0){
            if (arrayFOVNameDisplay [counter1] != "ND") arrayTableDisplay [tableDisplayCount] = "nil", tableDisplayCount++;
            else arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
        }
        else if (mode == 1) arrayTableDisplay [tableDisplayCount] = arrayTableDisplay [tableDisplayCount], tableDisplayCount++;
        
        if (arrayFOVNameDisplay [counter1] != "ND"){
            for (int counter2 = startingTimePoint; counter2 < startingTimePoint+2; counter2++){
                if (counter2 > entryNumber) arrayTableDisplay [tableDisplayCount] = "0", tableDisplayCount++;
                else if (arrayContrastData [counter1][counter2+2] != "0") arrayTableDisplay [tableDisplayCount] = arrayContrastData [counter1][counter2+2], tableDisplayCount++;
                else arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
            }
        }
        else{
            
            for (int counter2 = 0; counter2 < 2; counter2++) arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
        }
    }
    
    if (rgbCheck == 1){
        //-----Line One set-----
        arrayTableDisplayG [tableDisplayCountG] = "Name", tableDisplayCountG++;
        arrayTableDisplayG [tableDisplayCountG] = "FOV", tableDisplayCountG++;
        arrayTableDisplayG [tableDisplayCountG] = "Image Data", tableDisplayCountG++;
        
        for (int counter1 = startingTimePoint; counter1 < startingTimePoint+2; counter1++){
            if (counter1 > entryNumber) arrayTableDisplayG [tableDisplayCountG] = "T*", tableDisplayCountG++;
            else arrayTableDisplayG [tableDisplayCountG] = arrayContrastDataG [0][counter1+2], tableDisplayCountG++;
        }
        
        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
            if (arrayTreatmentNameDisplay [counter1] != "ND") arrayTableDisplayG [tableDisplayCountG] = arrayTreatmentNameDisplay [counter1], tableDisplayCountG++;
            else arrayTableDisplayG [tableDisplayCountG] = " ", tableDisplayCountG++;
            
            if (arrayFOVNameDisplay [counter1] != "ND") arrayTableDisplayG [tableDisplayCountG] = arrayFOVNameDisplay [counter1], tableDisplayCountG++;
            else arrayTableDisplayG [tableDisplayCountG] = " ", tableDisplayCountG++;
            
            if (mode == 0){
                if (arrayFOVNameDisplay [counter1] != "ND") arrayTableDisplayG [tableDisplayCountG] = "nil", tableDisplayCountG++;
                else arrayTableDisplayG [tableDisplayCountG] = " ", tableDisplayCountG++;
            }
            else if (mode == 1) arrayTableDisplayG [tableDisplayCountG] = arrayTableDisplayG [tableDisplayCountG], tableDisplayCountG++;
            
            if (arrayFOVNameDisplay [counter1] != "ND"){
                for (int counter2 = startingTimePoint; counter2 < startingTimePoint+2; counter2++){
                    if (counter2 > entryNumber) arrayTableDisplayG [tableDisplayCountG] = "0", tableDisplayCountG++;
                    else if (arrayContrastDataG [counter1][counter2+2] != "0") arrayTableDisplayG [tableDisplayCountG] = arrayContrastDataG [counter1][counter2+2], tableDisplayCountG++;
                    else arrayTableDisplayG [tableDisplayCountG] = " ", tableDisplayCountG++;
                }
            }
            else{
                
                for (int counter2 = 0; counter2 < 2; counter2++) arrayTableDisplayG [tableDisplayCountG] = " ", tableDisplayCountG++;
            }
        }
        
        //-----Line One set-----
        arrayTableDisplayB [tableDisplayCountB] = "Name", tableDisplayCountB++;
        arrayTableDisplayB [tableDisplayCountB] = "FOV", tableDisplayCountB++;
        arrayTableDisplayB [tableDisplayCountB] = "Image Data", tableDisplayCountB++;
        
        for (int counter1 = startingTimePoint; counter1 < startingTimePoint+2; counter1++){
            if (counter1 > entryNumber) arrayTableDisplayB [tableDisplayCountB] = "T*", tableDisplayCountB++;
            else arrayTableDisplayB [tableDisplayCountB] = arrayContrastDataB [0][counter1+2], tableDisplayCountB++;
        }
        
        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
            if (arrayTreatmentNameDisplay [counter1] != "ND") arrayTableDisplayB [tableDisplayCountB] = arrayTreatmentNameDisplay [counter1], tableDisplayCountB++;
            else arrayTableDisplayB [tableDisplayCountB] = " ", tableDisplayCountB++;
            
            if (arrayFOVNameDisplay [counter1] != "ND") arrayTableDisplayB [tableDisplayCountB] = arrayFOVNameDisplay [counter1], tableDisplayCountB++;
            else arrayTableDisplayB [tableDisplayCountB] = " ", tableDisplayCountB++;
            
            if (mode == 0){
                if (arrayFOVNameDisplay [counter1] != "ND") arrayTableDisplayB [tableDisplayCountB] = "nil", tableDisplayCountB++;
                else arrayTableDisplayB [tableDisplayCountB] = " ", tableDisplayCountB++;
            }
            else if (mode == 1) arrayTableDisplayB [tableDisplayCountB] = arrayTableDisplayB [tableDisplayCountB], tableDisplayCountB++;
            
            if (arrayFOVNameDisplay [counter1] != "ND"){
                for (int counter2 = startingTimePoint; counter2 < startingTimePoint+2; counter2++){
                    if (counter2 > entryNumber) arrayTableDisplayB [tableDisplayCountB] = "0", tableDisplayCountB++;
                    else if (arrayContrastDataB [counter1][counter2+2] != "0") arrayTableDisplayB [tableDisplayCountB] = arrayContrastDataB [counter1][counter2+2], tableDisplayCountB++;
                    else arrayTableDisplayB [tableDisplayCountB] = " ", tableDisplayCountB++;
                }
            }
            else{
                
                for (int counter2 = 0; counter2 < 2; counter2++) arrayTableDisplayB [tableDisplayCountB] = " ", tableDisplayCountB++;
            }
        }
    }
}

-(void)displayTableSet:(int)startingTimePoint{
    tableDisplayCount = 0;
    
    string *imageDataTemp = new string [treatmentNameDisplayCount+1];
    
    for (int counter1 = 0; counter1 < treatmentNameDisplayCount+1; counter1++){
        imageDataTemp [counter1] = arrayTableDisplay [counter1*5+2];
    }
    
    //-----Line One set-----
    arrayTableDisplay [tableDisplayCount] = "Name", tableDisplayCount++;
    arrayTableDisplay [tableDisplayCount] = "FOV", tableDisplayCount++;
    arrayTableDisplay [tableDisplayCount] = "Image Data", tableDisplayCount++;
    
    for (int counter1 = startingTimePoint; counter1 < startingTimePoint+2; counter1++){
        if (counter1 > entryNumber) arrayTableDisplay [tableDisplayCount] = "T*", tableDisplayCount++;
        else arrayTableDisplay [tableDisplayCount] = arrayContrastData [0][counter1+2], tableDisplayCount++;
    }
    
    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
        if (arrayTreatmentNameDisplay [counter1] != "ND") arrayTableDisplay [tableDisplayCount] = arrayTreatmentNameDisplay [counter1], tableDisplayCount++;
        else arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
        
        if (arrayFOVNameDisplay [counter1] != "ND") arrayTableDisplay [tableDisplayCount] = arrayFOVNameDisplay [counter1], tableDisplayCount++;
        else arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
        
        arrayTableDisplay [tableDisplayCount] = imageDataTemp [counter1], tableDisplayCount++;
        
        if (arrayFOVNameDisplay [counter1] != "ND"){
            for (int counter2 = startingTimePoint; counter2 < startingTimePoint+2; counter2++){
                if (counter2 > entryNumber) arrayTableDisplay [tableDisplayCount] = "0", tableDisplayCount++;
                else if (arrayContrastData [counter1][counter2+2] != "0") arrayTableDisplay [tableDisplayCount] = arrayContrastData [counter1][counter2+2], tableDisplayCount++;
                else arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
            }
        }
        else{
            
            for (int counter2 = 0; counter2 < 2; counter2++) arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
        }
    }
    
    if (photoMetricHold == 2){
        tableDisplayCountG = 0;
        
        for (int counter1 = 0; counter1 < treatmentNameDisplayCount+1; counter1++){
            imageDataTemp [counter1] = arrayTableDisplayG [counter1*5+2];
        }
        
        //-----Line One set-----
        arrayTableDisplayG [tableDisplayCountG] = "Name", tableDisplayCountG++;
        arrayTableDisplayG [tableDisplayCountG] = "FOV", tableDisplayCountG++;
        arrayTableDisplayG [tableDisplayCountG] = "Image Data", tableDisplayCountG++;
        
        for (int counter1 = startingTimePoint; counter1 < startingTimePoint+2; counter1++){
            if (counter1 > entryNumber) arrayTableDisplayG [tableDisplayCountG] = "T*", tableDisplayCountG++;
            else arrayTableDisplayG [tableDisplayCountG] = arrayContrastDataG [0][counter1+2], tableDisplayCountG++;
        }
        
        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
            if (arrayTreatmentNameDisplay [counter1] != "ND") arrayTableDisplayG [tableDisplayCountG] = arrayTreatmentNameDisplay [counter1], tableDisplayCountG++;
            else arrayTableDisplayG [tableDisplayCountG] = " ", tableDisplayCountG++;
            
            if (arrayFOVNameDisplay [counter1] != "ND") arrayTableDisplayG [tableDisplayCountG] = arrayFOVNameDisplay [counter1], tableDisplayCountG++;
            else arrayTableDisplayG [tableDisplayCountG] = " ", tableDisplayCountG++;
            
            arrayTableDisplayG [tableDisplayCountG] = imageDataTemp [counter1], tableDisplayCountG++;
            
            if (arrayFOVNameDisplay [counter1] != "ND"){
                for (int counter2 = startingTimePoint; counter2 < startingTimePoint+2; counter2++){
                    if (counter2 > entryNumber) arrayTableDisplayG [tableDisplayCountG] = "0", tableDisplayCountG++;
                    else if (arrayContrastDataG [counter1][counter2+2] != "0") arrayTableDisplayG [tableDisplayCountG] = arrayContrastDataG [counter1][counter2+2], tableDisplayCountG++;
                    else arrayTableDisplayG [tableDisplayCountG] = " ", tableDisplayCountG++;
                }
            }
            else{
                
                for (int counter2 = 0; counter2 < 2; counter2++) arrayTableDisplayG [tableDisplayCountG] = " ", tableDisplayCountG++;
            }
        }
        
        tableDisplayCountB = 0;
        
        for (int counter1 = 0; counter1 < treatmentNameDisplayCount+1; counter1++){
            imageDataTemp [counter1] = arrayTableDisplayB [counter1*5+2];
        }
        
        //-----Line One set-----
        arrayTableDisplayB [tableDisplayCountB] = "Name", tableDisplayCountB++;
        arrayTableDisplayB [tableDisplayCountB] = "FOV", tableDisplayCountB++;
        arrayTableDisplayB [tableDisplayCountB] = "Image Data", tableDisplayCountB++;
        
        for (int counter1 = startingTimePoint; counter1 < startingTimePoint+2; counter1++){
            if (counter1 > entryNumber) arrayTableDisplayB [tableDisplayCountB] = "T*", tableDisplayCountB++;
            else arrayTableDisplayB [tableDisplayCountB] = arrayContrastDataB [0][counter1+2], tableDisplayCountB++;
        }
        
        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
            if (arrayTreatmentNameDisplay [counter1] != "ND") arrayTableDisplayB [tableDisplayCountB] = arrayTreatmentNameDisplay [counter1], tableDisplayCountB++;
            else arrayTableDisplayB [tableDisplayCountB] = " ", tableDisplayCountB++;
            
            if (arrayFOVNameDisplay [counter1] != "ND") arrayTableDisplayB [tableDisplayCountB] = arrayFOVNameDisplay [counter1], tableDisplayCountB++;
            else arrayTableDisplayB [tableDisplayCountB] = " ", tableDisplayCountB++;
            
            arrayTableDisplayB [tableDisplayCountB] = imageDataTemp [counter1], tableDisplayCountB++;
            
            if (arrayFOVNameDisplay [counter1] != "ND"){
                for (int counter2 = startingTimePoint; counter2 < startingTimePoint+2; counter2++){
                    if (counter2 > entryNumber) arrayTableDisplayB [tableDisplayCountB] = "0", tableDisplayCountB++;
                    else if (arrayContrastDataB [counter1][counter2+2] != "0") arrayTableDisplayB [tableDisplayCountB] = arrayContrastDataB [counter1][counter2+2], tableDisplayCountB++;
                    else arrayTableDisplayB [tableDisplayCountB] = " ", tableDisplayCountB++;
                }
            }
            else{
                
                for (int counter2 = 0; counter2 < 2; counter2++) arrayTableDisplayB [tableDisplayCountB] = " ", tableDisplayCountB++;
            }
        }
    }
    
    delete [] imageDataTemp;
}

-(void)variableSave{
    string contrastSettingParameterPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ContrastParameters";
    
    ofstream oin;
    
    oin.open(contrastSettingParameterPath.c_str(),ios::out);
    
    oin<<currentOriginalNo<<endl;
    oin<<backgroundDisplayPage<<endl;
    oin<<contrastCutOff1<<endl;
    oin<<contrastCutOff3<<endl;
    oin<<contrastCutOffAS<<endl;
    oin<<baseContrastSet1<<endl;
    oin<<baseContrastSet3<<endl;
    oin<<baseContrastSetAS<<endl;
    oin<<rangeLimitCurrent<<endl;
    oin<<rangeLimitCurrentHorizontal<<endl;
    oin<<rangeLimitCurrentVertical<<endl;
    oin<<expansionUPCurrent<<endl;
    oin<<expansionDownCurrent<<endl;
    oin<<expansionRightCurrent<<endl;
    oin<<expansionLeftCurrent<<endl;
    oin<<expansionUPPosition1<<endl;
    oin<<expansionUPPosition2<<endl;
    oin<<expansionDownPosition1<<endl;
    oin<<expansionDownPosition2<<endl;
    oin<<expansionRightPosition1<<endl;
    oin<<expansionRightPosition2<<endl;
    oin<<expansionLeftPosition1<<endl;
    oin<<expansionLeftPosition2<<endl;
    oin<<blurStatusHold<<endl;
    oin<<xOrientation<<endl;
    oin<<yOrientation<<endl;
    oin<<xyInvert<<endl;
    
    oin.close();
}

@end
