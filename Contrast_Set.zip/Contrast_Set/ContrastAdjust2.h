//
//  ContrastAdjust2.h
//  Contrast_Set
//
//  Created by Masahiko Sato on 2016-03-17.
//  Copyright Masahiko Sato 2016 All rights reserved.
//

#ifndef CONTRASTADJUST2_H
#define CONTRASTADJUST2_H
#import "MainImage.h" 
#endif

@interface ContrastAdjust2 : NSObject {
}

-(int)contrastAdjustMain2:(int)processType;

@end
