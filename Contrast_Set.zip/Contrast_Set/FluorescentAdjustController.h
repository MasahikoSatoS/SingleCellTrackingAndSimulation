//
//  FluorescentAdjustController.h
//  Contrast_Set
//
//  Created by Masahiko Sato on 2014-06-01.
//  Copyright Masahiko Sato 2014 All rights reserved.
//
//

#ifndef FLUORESCENTADJUSTCONTROLLER_H
#define FLUORESCENTADJUSTCONTROLLER_H
#import "Controller.h" 
#endif

@interface FluorescentAdjustController : NSObject {
    double sliderFluorescentMax; //Slider
    double sliderFluorescentMin; //Slider
    double sliderFluorescentDiff; //Slider
    double sliderBaseMax; //Slider
    double sliderBaseMin; //Slider
    double sliderBaseDiff; //Slider
    double sliderDICLevelMax; //Slider
    double sliderDICLevelMin; //Slider
    double sliderDICLevelDiff; //Slider
    double sliderDICContMax; //Slider
    double sliderDICContMin; //Slider
    double sliderDICContDiff; //Slider
    
    IBOutlet NSTextField *treatmentAdjust;
    IBOutlet NSTextField *channelAdjust;
    IBOutlet NSTextField *moveStatusDisplay;
    IBOutlet NSTextField *baseCutValueDisplay;
    IBOutlet NSTextField *fluorescentValueDisplay;
    IBOutlet NSTextField *dicLevelValueDisplay;
    IBOutlet NSTextField *dicContrastValueDisplay;
    IBOutlet NSTextField *channelValueX1;
    IBOutlet NSTextField *channelValueX2;
    IBOutlet NSTextField *channelValueX3;
    IBOutlet NSTextField *channelValueX4;
    IBOutlet NSTextField *channelValueX5;
    IBOutlet NSTextField *channelValueX6;
    IBOutlet NSTextField *channelValueY1;
    IBOutlet NSTextField *channelValueY2;
    IBOutlet NSTextField *channelValueY3;
    IBOutlet NSTextField *channelValueY4;
    IBOutlet NSTextField *channelValueY5;
    IBOutlet NSTextField *channelValueY6;
    
    IBOutlet NSWindow *adjustWindow;
    
    IBOutlet NSSlider *sliderFluorescent;
    IBOutlet NSSlider *sliderBase;
    IBOutlet NSSlider *sliderFluorescentCircle;
    IBOutlet NSSlider *sliderBaseCircle;
    IBOutlet NSSlider *sliderDICLevel;
    IBOutlet NSSlider *sliderDICCont;
    IBOutlet NSSlider *sliderDICLevelCircle;
    IBOutlet NSSlider *sliderDICContCircle;
    
    IBOutlet NSProgressIndicator *backSave;
    
    NSTimer *adjustTimer;
    NSTimer *adjustTimer2;
    
    NSWindowController *adjustWindController;
    
    id setData;
    id imageDataSet;
    id tiffFileRead;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;
-(void)display;

-(IBAction)closeWindow:(id)sender;
-(IBAction)savePosition:(id)sender;
-(IBAction)imageLoad:(id)sender;
-(IBAction)sliderAction:(id)sender;
-(IBAction)sliderActionBase:(id)sender;

-(IBAction)sliderActionCircle:(id)sender;
-(IBAction)sliderActionBaseCircle:(id)sender;

-(IBAction)sliderDICLevel:(id)sender;
-(IBAction)sliderDICCont:(id)sender;
-(IBAction)sliderDICLevelCircle:(id)sender;
-(IBAction)sliderDICContCircle:(id)sender;

-(IBAction)moveStatusSet:(id)sender;
-(IBAction)usePreviousValue:(id)sender;
-(IBAction)previousValueHold1:(id)sender;
-(IBAction)previousValueHold2:(id)sender;
-(IBAction)previousValueHold3:(id)sender;

-(IBAction)clearFluorescent:(id)sender;
-(IBAction)clearDIC:(id)sender;

@end
