//
//  BackgroundWindow.h
//  Contrast_Set
//
//  Created by Masahiko Sato on 4/7/16.
//  Copyright Masahiko Sato 2016 All rights reserved.
//
//

#ifndef BACKGROUNDWINDOW_H
#define BACKGROUNDWINDOW_H
#import "Controller.h"
#endif

@interface BackgroundWindow : NSView{
    int mouseDragFlag; //Display
    int mouseDownFlag; //Display
    int xStartHold; //Display
    int yStartHold; //Display
    int xClickHold; //Display
    int yClickHold; //Display
    int positionHold; //Display
    
    int clickValue; //Click position value
    int bkLine1; //Box for link setting 1
    int bkLine2; //Box for link setting 2
    
    double xPointDownDisplayBK; //Display
    double yPointDownDisplayBK; //Display
    double xPositionMoveDisplayBK; //Display
    double yPositionMoveDisplayBK; //Display
    double xPointDragDisplayBK; //Display
    double yPointDragDisplayBK; //Display
    double xPositionDisplayBK; //Display
    double yPositionDisplayBK; //Display
    double xPositionAdjustDisplayBK; //Display
    double yPositionAdjustDisplayBK; //Display
    double windowWidthDisplayBK; //Display
    double windowHeightDisplayBK; //Display
    
    int bkLineX1; //Box for link setting 1
    int bkLineX2; //Box for link setting 2
    int bkLineY1; //Box for link setting 1
    int bkLineY2; //Box for link setting 2
    int bkLineCenterX1; //Box for link setting 1
    int bkLineCenterY1; //Box for link setting 2
    int bkLineCenterX2; //Box for link setting 1
    int bkLineCenterY2; //Box for link setting 2
    
    IBOutlet NSImage *adjustImageBK;
    
    id subprocesses;
}

-(void)mouseDown:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)mouseDragged:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
