//
//  BackgroundController.h
//  Contrast_Set
//
//  Created by Masahiko Sato on 4/7/16.
//  Copyright Masahiko Sato 2016 All rights reserved.
//
//

#ifndef BACKGROUNDCONTROLLER_H
#define BACKGROUNDCONTROLLER_H
#import "Controller.h" 
#endif

@interface BackgroundController : NSObject {
    int timingCount; //Count timing
    
    double sliderUpMax; //Slider
    double sliderUpMin; //Slider
    double sliderUpDiff; //Slider
    double sliderDownMax; //Slider
    double sliderDownMin; //Slider
    double sliderDownDiff; //Slider
    double sliderGainMax; //Slider
    double sliderGainMin; //Slider
    double sliderGainDiff; //Slider
    
    double sliderExUpMax; //Slider
    double sliderExUpMin; //Slider
    double sliderExUpDiff; //Slider
    double sliderExDownMax; //Slider
    double sliderExDownMin; //Slider
    double sliderExDownDiff; //Slider
    double sliderExRightMax; //Slider
    double sliderExRightMin; //Slider
    double sliderExRightDiff; //Slider
    double sliderExLeftMax; //Slider
    double sliderExLeftMin; //Slider
    double sliderExLeftDiff; //Slider
    
    IBOutlet NSTextField *treatmentAdjust;
    IBOutlet NSTextField *inputField;
    IBOutlet NSTextField *areaLineDisplay;
    IBOutlet NSTextField *cutUpDisplay1;
    IBOutlet NSTextField *cutDownDisplay1;
    IBOutlet NSTextField *displayImageStatus;
    IBOutlet NSTextField *sliderValueDisplay1;
    IBOutlet NSTextField *sliderValueDisplay3;
    IBOutlet NSTextField *overlayStatusDisplay;
    IBOutlet NSTextField *addSubtractDisplay;
    IBOutlet NSTextField *gainDisplay;
    
    IBOutlet NSTextField *extensionUpDisplay;
    IBOutlet NSTextField *extensionDownDisplay;
    IBOutlet NSTextField *extensionRightDisplay;
    IBOutlet NSTextField *extensionLeftDisplay;
    
    IBOutlet NSTextField *extensionUpLine1;
    IBOutlet NSTextField *extensionUpLine2;
    IBOutlet NSTextField *extensionDownLine1;
    IBOutlet NSTextField *extensionDownLine2;
    IBOutlet NSTextField *extensionRightLine1;
    IBOutlet NSTextField *extensionRightLine2;
    IBOutlet NSTextField *extensionLeftLine1;
    IBOutlet NSTextField *extensionLeftLine2;
    
    IBOutlet NSSlider *sliderUp1;
    IBOutlet NSSlider *sliderDown1;
    IBOutlet NSSlider *sliderAddSubtract;
    
    IBOutlet NSSlider *sliderUpCircle;
    IBOutlet NSSlider *sliderDownCircle;
    IBOutlet NSSlider *sliderAddSubtractCircle;
    IBOutlet NSSlider *areaSet;
    
    IBOutlet NSSlider *sliderExtensionUp;
    IBOutlet NSSlider *sliderExtensionDown;
    IBOutlet NSSlider *sliderExtensionRight;
    IBOutlet NSSlider *sliderExtensionLeft;
    
    IBOutlet NSSlider *sliderExUpCircle;
    IBOutlet NSSlider *sliderExUpLineCircle1;
    IBOutlet NSSlider *sliderExUpLineCircle2;
    IBOutlet NSSlider *sliderExUpLineCircle3;
    IBOutlet NSSlider *sliderExUpLineCircle4;
    
    IBOutlet NSSlider *sliderExDownCircle;
    IBOutlet NSSlider *sliderExDownLineCircle1;
    IBOutlet NSSlider *sliderExDownLineCircle2;
    IBOutlet NSSlider *sliderExDownLineCircle3;
    IBOutlet NSSlider *sliderExDownLineCircle4;
    
    IBOutlet NSSlider *sliderExRightCircle;
    IBOutlet NSSlider *sliderExRightLineCircle1;
    IBOutlet NSSlider *sliderExRightLineCircle2;
    IBOutlet NSSlider *sliderExRightLineCircle3;
    IBOutlet NSSlider *sliderExRightLineCircle4;
    
    IBOutlet NSSlider *sliderExLeftCircle;
    IBOutlet NSSlider *sliderExLeftLineCircle1;
    IBOutlet NSSlider *sliderExLeftLineCircle2;
    IBOutlet NSSlider *sliderExLeftLineCircle3;
    IBOutlet NSSlider *sliderExLeftLineCircle4;
    
    IBOutlet NSCell *sliderUpKnob1;
    IBOutlet NSCell *sliderDownKnob1;
    IBOutlet NSCell *sliderAddSubtractKnob;
    
    IBOutlet NSCell *sliderExtensionKnobUp;
    IBOutlet NSCell *sliderExtensionKnobDown;
    IBOutlet NSCell *sliderExtensionKnobRight;
    IBOutlet NSCell *sliderExtensionKnobLeft;
    
    IBOutlet NSWindow *backgroundMainWindow;
    
    NSTimer *backgroundTimer;
    NSTimer *backgroundTimer2;
    
    NSWindowController *backgroundWindowController;
    
    id subprocesses;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;
-(void)display;
-(void)deleteBackgroundUnusedProcess;

-(IBAction)closeWindow:(id)sender;
-(IBAction)savePosition:(id)sender;
-(IBAction)saveAsPosition:(id)sender;
-(IBAction)imageOriginal:(id)sender;
-(IBAction)imageBackground:(id)sender;
-(IBAction)imageModify:(id)sender;
-(IBAction)imageAdjust:(id)sender;
-(IBAction)imageOverlaySelect:(id)sender;
-(IBAction)createBackground:(id)sender;
-(IBAction)deleteBackground:(id)sender;
-(IBAction)deleteBackgroundAll:(id)sender;
-(IBAction)deleteBackgroundUnused:(id)sender;
-(IBAction)backgroundJump:(id)sender;
-(IBAction)backgroundNameSet:(id)sender;
-(IBAction)findBestMatchBK:(id)sender;
-(IBAction)areaLineSW:(id)sender;
-(IBAction)sliderAreaSet:(id)sender;
-(IBAction)edgeSet:(id)sender;

-(IBAction)sliderUpKnobAction1:(id)sender;
-(IBAction)sliderDownKnobAction1:(id)sender;
-(IBAction)sliderAddSubtractAction:(id)sender;

-(IBAction)sliderUpKnobCircle:(id)sender;
-(IBAction)sliderDownKnobCircle:(id)sender;
-(IBAction)sliderAddSubtractKnobCircle:(id)sender;

-(IBAction)setCutUp1:(id)sender;
-(IBAction)setCutDown1:(id)sender;
-(IBAction)setAddSubtract:(id)sender;
-(IBAction)clearCutUp1:(id)sender;
-(IBAction)clearCutDown1:(id)sender;
-(IBAction)clearAddSubtract:(id)sender;

-(IBAction)areaSetUp:(id)sender;
-(IBAction)areaSetDown:(id)sender;

-(IBAction)sliderExtensionUpSet:(id)sender;
-(IBAction)sliderExtensionDownSet:(id)sender;
-(IBAction)sliderExtensionRightSet:(id)sender;
-(IBAction)sliderExtensionLeftSet:(id)sender;

-(IBAction)extensionUpClear:(id)sender;
-(IBAction)extensionDownClear:(id)sender;
-(IBAction)extensionRightClear:(id)sender;
-(IBAction)extensionLeftClear:(id)sender;

-(IBAction)extensionUpLineClear:(id)sender;
-(IBAction)extensionDownLineClear:(id)sender;
-(IBAction)extensionRightLineClear:(id)sender;
-(IBAction)extensionLeftLineClear:(id)sender;

-(IBAction)sliderExUpCircleSet:(id)sender;
-(IBAction)sliderExUpLineCircle1Set:(id)sender;
-(IBAction)sliderExUpLineCircle2Set:(id)sender;
-(IBAction)sliderExUpLineCircle3Set:(id)sender;
-(IBAction)sliderExUpLineCircle4Set:(id)sender;

-(IBAction)sliderExDownCircleSet:(id)sender;
-(IBAction)sliderExDownLineCircle1Set:(id)sender;
-(IBAction)sliderExDownLineCircle2Set:(id)sender;
-(IBAction)sliderExDownLineCircle3Set:(id)sender;
-(IBAction)sliderExDownLineCircle4Set:(id)sender;

-(IBAction)sliderExRightCircleSet:(id)sender;
-(IBAction)sliderExRightLineCircle1Set:(id)sender;
-(IBAction)sliderExRightLineCircle2Set:(id)sender;
-(IBAction)sliderExRightLineCircle3Set:(id)sender;
-(IBAction)sliderExRightLineCircle4Set:(id)sender;

-(IBAction)sliderExLeftCircleSet:(id)sender;
-(IBAction)sliderExLeftLineCircle1Set:(id)sender;
-(IBAction)sliderExLeftLineCircle2Set:(id)sender;
-(IBAction)sliderExLeftLineCircle3Set:(id)sender;
-(IBAction)sliderExLeftLineCircle4Set:(id)sender;

-(IBAction)bkFlipHorizontal:(id)sender;
-(IBAction)bkFlipVertical:(id)sender;

@end
