//
//  HistogramWindow.m
//  Contrast_Set
//
//  Created by Masahiko Sato on 2014-04-07.
//
//

#import "HistogramWindow.h"

NSString *notificationToHistogram = @"notificationExecuteHistogram";

@implementation HistogramWindow

- (id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    
    if (self){
        verticalMagnification = 1;
        verticalMagnificationStep = 1;
        
        histogramImage = [[NSImage alloc] initWithContentsOfFile:@""];
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToHistogram object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [self setNeedsDisplay:YES];
}

-(void)mouseDown:(NSEvent *)event{
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
        
        if (backgroundOADisplay == "Off" && processingFovNo != 0){
            xPointDownHisto = clickPoint.x;
            yPointDownHisto = clickPoint.y;
            selectProcessLine = 0;
            
            contrastOADisplay = "On";
            
            if (rgbDisplayStatus == 0 || rgbDisplayStatus == 1){
                if (lowValueDisplay > xPointDownHisto-10 && lowValueDisplay < xPointDownHisto+10 && yPointDownHisto < 99) selectProcessLine = 1;
                else if (highValueDisplay > xPointDownHisto-10 && highValueDisplay < xPointDownHisto+10 && yPointDownHisto < 99) selectProcessLine = 2;
                else if (meanValueDisplay > xPointDownHisto-10 && meanValueDisplay < xPointDownHisto+10 && yPointDownHisto < 130) selectProcessLine = 3;
            }
            else if (rgbDisplayStatus == 2){
                if (lowValueDisplayG > xPointDownHisto-10 && lowValueDisplayG < xPointDownHisto+10 && yPointDownHisto < 99) selectProcessLine = 1;
                else if (highValueDisplayG > xPointDownHisto-10 && highValueDisplayG < xPointDownHisto+10 && yPointDownHisto < 99) selectProcessLine = 2;
                else if (meanValueDisplayG > xPointDownHisto-10 && meanValueDisplayG < xPointDownHisto+10 && yPointDownHisto < 130) selectProcessLine = 3;
            }
            else if (rgbDisplayStatus == 3){
                if (lowValueDisplayB > xPointDownHisto-10 && lowValueDisplayB < xPointDownHisto+10 && yPointDownHisto < 99) selectProcessLine = 1;
                else if (highValueDisplayB > xPointDownHisto-10 && highValueDisplayB < xPointDownHisto+10 && yPointDownHisto < 99) selectProcessLine = 2;
                else if (meanValueDisplayB > xPointDownHisto-10 && meanValueDisplayB < xPointDownHisto+10 && yPointDownHisto < 130) selectProcessLine = 3;
            }
            
            if (selectProcessLine != 0 && contrastBarActivate == 1){
                int resetType = 1;
                [self resetData:resetType];
                
                contrastDisplayCall = 1;
            }
            
            if (processingFovNo == -1){
                currentFOVNoHold = processingFovNo;
                
                for (int counter1 = 0; counter1 <= loadImageFOVNo+1; counter1++){
                    contrastValueHold [counter1] = 0;
                    
                    if (photoMetricHold == 2){
                        contrastValueHoldG [counter1] = 0;
                        contrastValueHoldB [counter1] = 0;
                    }
                }
            }
            else if (processingFovNo > 0){
                contrastValueHold [processingFovNo] = 0;
                
                if (photoMetricHold == 2){
                    contrastValueHoldG [processingFovNo] = 0;
                    contrastValueHoldB [processingFovNo] = 0;
                }
            }
            
            [self setNeedsDisplay:YES];
        }
    }
}

-(void)mouseUp:(NSEvent *)event{
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
        
        if (backgroundOADisplay == "Off" && processingFovNo != 0){
            xPointDragHisto = clickPoint.x;
            
            if (rgbDisplayStatus == 0 || rgbDisplayStatus == 1){
                if (selectProcessLine == 1){
                    if (lowValueDisplay < meanValueDisplay && lowValueDisplay >= 0){
                        lowValueDisplay = (int)xPointDragHisto-4;
                        
                        if (lowValueDisplay < 0) lowValueDisplay = 0;
                        else if (lowValueDisplay >= meanValueDisplay-5){
                            lowValueDisplay = meanValueDisplay-6;
                            
                            if (lowValueDisplay < 0) lowValueDisplay = 0;
                        }
                        
                        int type = 2;
                        contrastAdjust = [[ContrastAdjust alloc] init];
                        [contrastAdjust contrastAdjustMain:type];
                        
                        callFromHistogram = 1;
                        mainImageDisplayCall = 1;
                    }
                }
                else if (selectProcessLine == 2){
                    if (highValueDisplay > meanValueDisplay && highValueDisplay < 256){
                        highValueDisplay = (int)xPointDragHisto-4;
                        
                        if (highValueDisplay >= 256) highValueDisplay = 255;
                        else if (highValueDisplay <= meanValueDisplay+5){
                            highValueDisplay = meanValueDisplay+6;
                            
                            if (highValueDisplay >= 256) highValueDisplay = 255;
                        }
                        
                        int type = 3;
                        contrastAdjust = [[ContrastAdjust alloc] init];
                        [contrastAdjust contrastAdjustMain:type];
                        
                        callFromHistogram = 1;
                        mainImageDisplayCall = 1;
                    }
                }
                else if (selectProcessLine == 3){
                    if (highValueDisplay-5 > meanValueDisplay && lowValueDisplay+5 < meanValueDisplay){
                        meanValueDisplay = (int)xPointDragHisto-4;
                        
                        if (highValueDisplay-5 <= meanValueDisplay) meanValueDisplay = highValueDisplay-6;
                        else if (lowValueDisplay+5 >= meanValueDisplay) meanValueDisplay = lowValueDisplay+6;
                        
                        int type = 4;
                        contrastAdjust = [[ContrastAdjust alloc] init];
                        [contrastAdjust contrastAdjustMain:type];
                        
                        callFromHistogram = 1;
                        mainImageDisplayCall = 1;
                    }
                }
            }
            else if (rgbDisplayStatus == 2){
                if (selectProcessLine == 1){
                    if (lowValueDisplayG < meanValueDisplayG && lowValueDisplayG >= 0){
                        lowValueDisplayG = (int)xPointDragHisto-4;
                        
                        if (lowValueDisplayG < 0) lowValueDisplayG = 0;
                        else if (lowValueDisplayG >= meanValueDisplayG-5){
                            lowValueDisplayG = meanValueDisplayG-6;
                            
                            if (lowValueDisplayG < 0) lowValueDisplayG = 0;
                        }
                        
                        int type = 2;
                        contrastAdjust = [[ContrastAdjust alloc] init];
                        [contrastAdjust contrastAdjustMain:type];
                        
                        callFromHistogram = 1;
                        mainImageDisplayCall = 1;
                    }
                }
                else if (selectProcessLine == 2){
                    if (highValueDisplayG > meanValueDisplayG && highValueDisplayG < 256){
                        highValueDisplayG = (int)xPointDragHisto-4;
                        
                        if (highValueDisplayG >= 256) highValueDisplayG = 255;
                        else if (highValueDisplayG <= meanValueDisplayG+5){
                            highValueDisplayG = meanValueDisplayG+6;
                            
                            if (highValueDisplayG >= 256) highValueDisplayG = 255;
                        }
                        
                        int type = 3;
                        contrastAdjust = [[ContrastAdjust alloc] init];
                        [contrastAdjust contrastAdjustMain:type];
                        
                        callFromHistogram = 1;
                        mainImageDisplayCall = 1;
                    }
                }
                else if (selectProcessLine == 3){
                    if (highValueDisplayG-5 > meanValueDisplayG && lowValueDisplayG+5 < meanValueDisplayG){
                        meanValueDisplayG = (int)xPointDragHisto-4;
                        
                        if (highValueDisplayG-5 <= meanValueDisplayG) meanValueDisplayG = highValueDisplayG-6;
                        else if (lowValueDisplayG+5 >= meanValueDisplayG) meanValueDisplayG = lowValueDisplayG+6;
                        
                        int type = 4;
                        contrastAdjust = [[ContrastAdjust alloc] init];
                        [contrastAdjust contrastAdjustMain:type];
                        
                        callFromHistogram = 1;
                        mainImageDisplayCall = 1;
                    }
                }
            }
            else if (rgbDisplayStatus == 3){
                if (selectProcessLine == 1){
                    if (lowValueDisplayB < meanValueDisplayB && lowValueDisplayB >= 0){
                        lowValueDisplayB = (int)xPointDragHisto-4;
                        
                        if (lowValueDisplayB < 0) lowValueDisplayB = 0;
                        else if (lowValueDisplayB >= meanValueDisplayB-5){
                            lowValueDisplayB = meanValueDisplayB-6;
                            
                            if (lowValueDisplayB < 0) lowValueDisplayB = 0;
                        }
                        
                        int type = 2;
                        contrastAdjust = [[ContrastAdjust alloc] init];
                        [contrastAdjust contrastAdjustMain:type];
                        
                        callFromHistogram = 1;
                        mainImageDisplayCall = 1;
                    }
                }
                else if (selectProcessLine == 2){
                    if (highValueDisplayB > meanValueDisplayB && highValueDisplayB < 256){
                        highValueDisplayB = (int)xPointDragHisto-4;
                        
                        if (highValueDisplayB >= 256) highValueDisplayB = 255;
                        else if (highValueDisplayB <= meanValueDisplayB+5){
                            highValueDisplayB = meanValueDisplayB+6;
                            
                            if (highValueDisplayB >= 256) highValueDisplayB = 255;
                        }
                        
                        int type = 3;
                        contrastAdjust = [[ContrastAdjust alloc] init];
                        [contrastAdjust contrastAdjustMain:type];
                        
                        callFromHistogram = 1;
                        mainImageDisplayCall = 1;
                    }
                }
                else if (selectProcessLine == 3){
                    if (highValueDisplayB-5 > meanValueDisplayB && lowValueDisplayB+5 < meanValueDisplayB){
                        meanValueDisplayB = (int)xPointDragHisto-4;
                        
                        if (highValueDisplayB-5 <= meanValueDisplayB) meanValueDisplayB = highValueDisplayB-6;
                        else if (lowValueDisplayB+5 >= meanValueDisplayB) meanValueDisplayB = lowValueDisplayB+6;
                        
                        int type = 4;
                        contrastAdjust = [[ContrastAdjust alloc] init];
                        [contrastAdjust contrastAdjustMain:type];
                        
                        callFromHistogram = 1;
                        mainImageDisplayCall = 1;
                    }
                }
            }
            
            [self setNeedsDisplay:YES];
        }
    }
}

-(void)mouseDragged:(NSEvent *)event{
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
        
        if (backgroundOADisplay == "Off" && processingFovNo != 0){
            xPointDragHisto = clickPoint.x;
            
            if (rgbDisplayStatus == 0 || rgbDisplayStatus == 1){
                if (selectProcessLine == 1){
                    if (lowValueDisplay < meanValueDisplay && lowValueDisplay >= 0){
                        lowValueDisplay = (int)xPointDragHisto-4;
                        
                        if (lowValueDisplay < 0) lowValueDisplay = 0;
                        else if (lowValueDisplay >= meanValueDisplay-5) lowValueDisplay = meanValueDisplay-6;
                        
                        int type = 2;
                        contrastAdjust = [[ContrastAdjust alloc] init];
                        [contrastAdjust contrastAdjustMain:type];
                        
                        callFromHistogram = 1;
                        mainImageDisplayCall = 1;
                    }
                }
                else if (selectProcessLine == 2){
                    if (highValueDisplay > meanValueDisplay && highValueDisplay < 256){
                        highValueDisplay = (int)xPointDragHisto-4;
                        
                        if (highValueDisplay >= 256) highValueDisplay = 255;
                        else if (highValueDisplay <= meanValueDisplay+5) highValueDisplay = meanValueDisplay+6;
                        
                        int type = 3;
                        contrastAdjust = [[ContrastAdjust alloc] init];
                        [contrastAdjust contrastAdjustMain:type];
                        
                        callFromHistogram = 1;
                        mainImageDisplayCall = 1;
                    }
                }
                else if (selectProcessLine == 3){
                    if (highValueDisplay-5 > meanValueDisplay && lowValueDisplay+5 < meanValueDisplay){
                        meanValueDisplay = (int)xPointDragHisto-4;
                        
                        if (highValueDisplay-5 <= meanValueDisplay) meanValueDisplay = highValueDisplay-6;
                        else if (lowValueDisplay+5 >= meanValueDisplay) meanValueDisplay = lowValueDisplay+6;
                        
                        int type = 4;
                        contrastAdjust = [[ContrastAdjust alloc] init];
                        [contrastAdjust contrastAdjustMain:type];
                        
                        callFromHistogram = 1;
                        mainImageDisplayCall = 1;
                    }
                }
            }
            else if (rgbDisplayStatus == 2){
                if (selectProcessLine == 1){
                    if (lowValueDisplayG < meanValueDisplayG && lowValueDisplayG >= 0){
                        lowValueDisplayG = (int)xPointDragHisto-4;
                        
                        if (lowValueDisplayG < 0) lowValueDisplayG = 0;
                        else if (lowValueDisplayG >= meanValueDisplayG-5) lowValueDisplayG = meanValueDisplayG-6;
                        
                        int type = 2;
                        contrastAdjust = [[ContrastAdjust alloc] init];
                        [contrastAdjust contrastAdjustMain:type];
                        
                        callFromHistogram = 1;
                        mainImageDisplayCall = 1;
                    }
                }
                else if (selectProcessLine == 2){
                    if (highValueDisplayG > meanValueDisplayG && highValueDisplayG < 256){
                        highValueDisplayG = (int)xPointDragHisto-4;
                        
                        if (highValueDisplayG >= 256) highValueDisplayG = 255;
                        else if (highValueDisplayG <= meanValueDisplayG+5) highValueDisplayG = meanValueDisplayG+6;
                        
                        int type = 3;
                        contrastAdjust = [[ContrastAdjust alloc] init];
                        [contrastAdjust contrastAdjustMain:type];
                        
                        callFromHistogram = 1;
                        mainImageDisplayCall = 1;
                    }
                }
                else if (selectProcessLine == 3){
                    if (highValueDisplayG-5 > meanValueDisplayG && lowValueDisplayG+5 < meanValueDisplayG){
                        meanValueDisplayG = (int)xPointDragHisto-4;
                        
                        if (highValueDisplayG-5 <= meanValueDisplayG) meanValueDisplayG = highValueDisplayG-6;
                        else if (lowValueDisplayG+5 >= meanValueDisplayG) meanValueDisplayG = lowValueDisplayG+6;
                        
                        int type = 4;
                        contrastAdjust = [[ContrastAdjust alloc] init];
                        [contrastAdjust contrastAdjustMain:type];
                        
                        callFromHistogram = 1;
                        mainImageDisplayCall = 1;
                    }
                }
            }
            else if (rgbDisplayStatus == 3){
                if (selectProcessLine == 1){
                    if (lowValueDisplayB < meanValueDisplayB && lowValueDisplayB >= 0){
                        lowValueDisplayB = (int)xPointDragHisto-4;
                        
                        if (lowValueDisplayB < 0) lowValueDisplayB = 0;
                        else if (lowValueDisplayB >= meanValueDisplayB-5) lowValueDisplayB = meanValueDisplayB-6;
                        
                        int type = 2;
                        contrastAdjust = [[ContrastAdjust alloc] init];
                        [contrastAdjust contrastAdjustMain:type];
                        
                        callFromHistogram = 1;
                        mainImageDisplayCall = 1;
                    }
                }
                else if (selectProcessLine == 2){
                    if (highValueDisplayB > meanValueDisplayB && highValueDisplayB < 256){
                        highValueDisplayB = (int)xPointDragHisto-4;
                        
                        if (highValueDisplayB >= 256) highValueDisplayB = 255;
                        else if (highValueDisplayB <= meanValueDisplayB+5) highValueDisplayB = meanValueDisplayB+6;
                        
                        int type = 3;
                        contrastAdjust = [[ContrastAdjust alloc] init];
                        [contrastAdjust contrastAdjustMain:type];
                        
                        callFromHistogram = 1;
                        mainImageDisplayCall = 1;
                    }
                }
                else if (selectProcessLine == 3){
                    if (highValueDisplayB-5 > meanValueDisplayB && lowValueDisplayB+5 < meanValueDisplayB){
                        meanValueDisplayB = (int)xPointDragHisto-4;
                        
                        if (highValueDisplayB-5 <= meanValueDisplayB) meanValueDisplayB = highValueDisplayB-6;
                        else if (lowValueDisplayB+5 >= meanValueDisplayB) meanValueDisplayB = lowValueDisplayB+6;
                        
                        int type = 4;
                        contrastAdjust = [[ContrastAdjust alloc] init];
                        [contrastAdjust contrastAdjustMain:type];
                        
                        callFromHistogram = 1;
                        mainImageDisplayCall = 1;
                    }
                }
            }
            
            [self setNeedsDisplay:YES];
        }
    }
}

-(void)keyDown:(NSEvent *)event{
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        int keyCode = [event keyCode];
        
        if (backgroundOADisplay == "Off"){
            if (keyCode == 9){
                int resetType = 2;
                [self resetData:resetType];
                
                contrastValueDisplay = 0;
                contrastDisplayCall = 1;
                
                [self setNeedsDisplay:YES];
            }
            
            if (keyCode == 126){
                if (verticalMagnificationStep <= 20){
                    verticalMagnificationStep++;
                    
                    if (verticalMagnificationStep > 20) verticalMagnificationStep = 20;
                    
                    verticalMagnification = verticalMagnificationStep;
                    
                    [self setNeedsDisplay:YES];
                }
            }
            
            if (keyCode == 125){
                if (verticalMagnificationStep > 0){
                    verticalMagnificationStep--;
                    
                    if (verticalMagnificationStep < 1) verticalMagnificationStep = 1;
                    
                    verticalMagnification = verticalMagnificationStep;
                    
                    [self setNeedsDisplay:YES];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Turn Off Background Mode To Proceed correction"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)drawRect:(NSRect)rect{
    [[NSColor lightGrayColor] set];
    
    NSBezierPath *path;
    path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 297, 137)];
    [path fill];
    
    [[NSColor blackColor] set];
    [NSBezierPath setDefaultLineWidth:0.8];
    
    NSPoint positionAA, positionBB;
    positionAA.x = 2;
    positionAA.y = 2;
    positionBB.x = 263;
    positionBB.y = 2;
    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
    
    if (imageDataHoldStatus == 1 && backgroundOADisplay == "Off"){
        if (processingFovNo == -1){
            [NSBezierPath setDefaultLineWidth:1];
            
            if (rgbDisplayStatus == 0){
                int maxCount = 0;
                
                for (int counter1 = 0; counter1 <= 255; counter1++){
                    if (arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter1] > maxCount){
                        maxCount = arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter1];
                    }
                }
                
                CGFloat maxValue = 0;
                [[NSColor blackColor] set];
                
                for (int counter1 = 0; counter1 <= 255; counter1++){
                    maxValue = (arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter1]/(double)maxCount)*137*verticalMagnification;
                    
                    if (maxValue > 137) maxValue = 137;
                    
                    positionAA.x = counter1+4;
                    positionAA.y = 3;
                    positionBB.x = counter1+4;
                    positionBB.y = maxValue;
                    
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
                
                [[NSColor redColor] set];
                [NSBezierPath setDefaultLineWidth:3.0];
                
                positionAA.x = lowValueDisplay+4;
                positionAA.y = 3;
                positionBB.x = lowValueDisplay+4;
                positionBB.y = 100;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                positionAA.x = highValueDisplay+4;
                positionAA.y = 3;
                positionBB.x = highValueDisplay+4;
                positionBB.y = 100;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                [[NSColor blueColor] set];
                positionAA.x = meanValueDisplay+4;
                positionAA.y = 3;
                positionBB.x = meanValueDisplay+4;
                positionBB.y = 130;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            }
            else{
                
                int maxCount = 0;
                
                for (int counter1 = 0; counter1 <= 255; counter1++){
                    if (arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter1] > maxCount){
                        maxCount = arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter1];
                    }
                    
                    if (arrayImageContrastAdjustHistogramG [loadImageFOVNo*256+counter1] > maxCount){
                        maxCount = arrayImageContrastAdjustHistogramG [loadImageFOVNo*256+counter1];
                    }
                    
                    if (arrayImageContrastAdjustHistogramB [loadImageFOVNo*256+counter1] > maxCount){
                        maxCount = arrayImageContrastAdjustHistogramB [loadImageFOVNo*256+counter1];
                    }
                }
                
                CGFloat maxValue = 0;
                
                if (rgbDisplayStatus == 1){
                    [[NSColor greenColor] set];
                    
                    for (int counter1 = 0; counter1 <= 255; counter1++){
                        maxValue = (arrayImageContrastAdjustHistogramG [loadImageFOVNo*256+counter1]/(double)maxCount)*137*verticalMagnification;
                        
                        if (maxValue > 137) maxValue = 137;
                        
                        positionAA.x = counter1+4;
                        positionAA.y = 3;
                        positionBB.x = counter1+4;
                        positionBB.y = maxValue;
                        
                        [[NSColor greenColor] set];
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        maxValue = (arrayImageContrastAdjustHistogramB [loadImageFOVNo*256+counter1]/(double)maxCount)*137*verticalMagnification;
                        
                        if (maxValue > 137) maxValue = 137;
                        
                        positionAA.x = counter1+4;
                        positionAA.y = 3;
                        positionBB.x = counter1+4;
                        positionBB.y = maxValue;
                        
                        [[NSColor blueColor] set];
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        maxValue = (arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter1]/(double)maxCount)*137*verticalMagnification;
                        
                        if (maxValue > 137) maxValue = 137;
                        
                        positionAA.x = counter1+4;
                        positionAA.y = 3;
                        positionBB.x = counter1+4;
                        positionBB.y = maxValue;
                        
                        [[NSColor redColor] set];
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    }
                }
                else if (rgbDisplayStatus == 2){
                    for (int counter1 = 0; counter1 <= 255; counter1++){
                        maxValue = (arrayImageContrastAdjustHistogramB [loadImageFOVNo*256+counter1]/(double)maxCount)*137*verticalMagnification;
                        
                        if (maxValue > 137) maxValue = 137;
                        
                        positionAA.x = counter1+4;
                        positionAA.y = 3;
                        positionBB.x = counter1+4;
                        positionBB.y = maxValue;
                        
                        [[NSColor blueColor] set];
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        maxValue = (arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter1]/(double)maxCount)*137*verticalMagnification;
                        
                        if (maxValue > 137) maxValue = 137;
                        
                        positionAA.x = counter1+4;
                        positionAA.y = 3;
                        positionBB.x = counter1+4;
                        positionBB.y = maxValue;
                        
                        [[NSColor redColor] set];
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        maxValue = (arrayImageContrastAdjustHistogramG [loadImageFOVNo*256+counter1]/(double)maxCount)*137*verticalMagnification;
                        
                        if (maxValue > 137) maxValue = 137;
                        
                        positionAA.x = counter1+4;
                        positionAA.y = 3;
                        positionBB.x = counter1+4;
                        positionBB.y = maxValue;
                        
                        [[NSColor greenColor] set];
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    }
                }
                else if (rgbDisplayStatus == 3){
                    for (int counter1 = 0; counter1 <= 255; counter1++){
                        maxValue = (arrayImageContrastAdjustHistogram [loadImageFOVNo*256+counter1]/(double)maxCount)*137*verticalMagnification;
                        
                        if (maxValue > 137) maxValue = 137;
                        
                        positionAA.x = counter1+4;
                        positionAA.y = 3;
                        positionBB.x = counter1+4;
                        positionBB.y = maxValue;
                        
                        [[NSColor redColor] set];
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        maxValue = (arrayImageContrastAdjustHistogramG [loadImageFOVNo*256+counter1]/(double)maxCount)*137*verticalMagnification;
                        
                        if (maxValue > 137) maxValue = 137;
                        
                        positionAA.x = counter1+4;
                        positionAA.y = 3;
                        positionBB.x = counter1+4;
                        positionBB.y = maxValue;
                        
                        [[NSColor greenColor] set];
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        maxValue = (arrayImageContrastAdjustHistogramB [loadImageFOVNo*256+counter1]/(double)maxCount)*137*verticalMagnification;
                        
                        if (maxValue > 137) maxValue = 137;
                        
                        positionAA.x = counter1+4;
                        positionAA.y = 3;
                        positionBB.x = counter1+4;
                        positionBB.y = maxValue;
                        
                        [[NSColor blueColor] set];
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    }
                }
                
                if (rgbDisplayStatus == 1){
                    [[NSColor yellowColor] set];
                    [NSBezierPath setDefaultLineWidth:3.0];
                    
                    positionAA.x = lowValueDisplay+4;
                    positionAA.y = 3;
                    positionBB.x = lowValueDisplay+4;
                    positionBB.y = 100;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    positionAA.x = highValueDisplay+4;
                    positionAA.y = 3;
                    positionBB.x = highValueDisplay+4;
                    positionBB.y = 100;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    [[NSColor blackColor] set];
                    positionAA.x = meanValueDisplay+4;
                    positionAA.y = 3;
                    positionBB.x = meanValueDisplay+4;
                    positionBB.y = 130;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
                else if (rgbDisplayStatus == 2){
                    [[NSColor yellowColor] set];
                    [NSBezierPath setDefaultLineWidth:3.0];
                    
                    positionAA.x = lowValueDisplayG+4;
                    positionAA.y = 3;
                    positionBB.x = lowValueDisplayG+4;
                    positionBB.y = 100;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    positionAA.x = highValueDisplayG+4;
                    positionAA.y = 3;
                    positionBB.x = highValueDisplayG+4;
                    positionBB.y = 100;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    [[NSColor blackColor] set];
                    positionAA.x = meanValueDisplayG+4;
                    positionAA.y = 3;
                    positionBB.x = meanValueDisplayG+4;
                    positionBB.y = 130;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
                else if (rgbDisplayStatus == 3){
                    [[NSColor yellowColor] set];
                    [NSBezierPath setDefaultLineWidth:3.0];
                    
                    positionAA.x = lowValueDisplayB+4;
                    positionAA.y = 3;
                    positionBB.x = lowValueDisplayB+4;
                    positionBB.y = 100;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    positionAA.x = highValueDisplayB+4;
                    positionAA.y = 3;
                    positionBB.x = highValueDisplayB+4;
                    positionBB.y = 100;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    [[NSColor blackColor] set];
                    positionAA.x = meanValueDisplayB+4;
                    positionAA.y = 3;
                    positionBB.x = meanValueDisplayB+4;
                    positionBB.y = 130;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
            }
        }
        else if (processingFovNo != 0){
            [[NSColor blackColor] set];
            [NSBezierPath setDefaultLineWidth:1];
            
            if (rgbDisplayStatus == 0){
                int maxCount = 0;
                
                for (int counter1 = 0; counter1 <= 255; counter1++){
                    if (arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1] > maxCount){
                        maxCount = arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1];
                    }
                }
                
                double maxValue = 0;
                
                for (int counter1 = 0; counter1 <= 255; counter1++){
                    maxValue = (arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1]/(double)maxCount)*137*verticalMagnification;
                    
                    if (maxValue > 137) maxValue = 137;
                    
                    positionAA.x = counter1+4;
                    positionAA.y = 3;
                    positionBB.x = counter1+4;
                    positionBB.y = maxValue;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
                
                [[NSColor redColor] set];
                [NSBezierPath setDefaultLineWidth:2.0];
                
                positionAA.x = lowValueDisplay+4;
                positionAA.y = 3;
                positionBB.x = lowValueDisplay+4;
                positionBB.y = 100;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                positionAA.x = highValueDisplay+4;
                positionAA.y = 3;
                positionBB.x = highValueDisplay+4;
                positionBB.y = 100;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                [[NSColor blueColor] set];
                positionAA.x = meanValueDisplay+4;
                positionAA.y = 3;
                positionBB.x = meanValueDisplay+4;
                positionBB.y = 130;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            }
            else{
                
                int maxCount = 0;
                
                for (int counter1 = 0; counter1 <= 255; counter1++){
                    if (arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1] > maxCount){
                        maxCount = arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1];
                    }
                    
                    if (arrayImageContrastAdjustHistogramG [(processingFovNo-1)*256+counter1] > maxCount){
                        maxCount = arrayImageContrastAdjustHistogramG [(processingFovNo-1)*256+counter1];
                    }
                    
                    if (arrayImageContrastAdjustHistogramB [(processingFovNo-1)*256+counter1] > maxCount){
                        maxCount = arrayImageContrastAdjustHistogramB [(processingFovNo-1)*256+counter1];
                    }
                }
                
                CGFloat maxValue = 0;
                
                if (rgbDisplayStatus == 1){
                    [[NSColor greenColor] set];
                    
                    for (int counter1 = 0; counter1 <= 255; counter1++){
                        maxValue = (arrayImageContrastAdjustHistogramG [(processingFovNo-1)*256+counter1]/(double)maxCount)*137*verticalMagnification;
                        
                        if (maxValue > 137) maxValue = 137;
                        
                        positionAA.x = counter1+4;
                        positionAA.y = 3;
                        positionBB.x = counter1+4;
                        positionBB.y = maxValue;
                        [[NSColor greenColor] set];
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        maxValue = (arrayImageContrastAdjustHistogramB [(processingFovNo-1)*256+counter1]/(double)maxCount)*137*verticalMagnification;
                        
                        if (maxValue > 137) maxValue = 137;
                        
                        positionAA.x = counter1+4;
                        positionAA.y = 3;
                        positionBB.x = counter1+4;
                        positionBB.y = maxValue;
                        [[NSColor blueColor] set];
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        maxValue = (arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1]/(double)maxCount)*137*verticalMagnification;
                        
                        if (maxValue > 137) maxValue = 137;
                        
                        positionAA.x = counter1+4;
                        positionAA.y = 3;
                        positionBB.x = counter1+4;
                        positionBB.y = maxValue;
                        [[NSColor redColor] set];
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    }
                }
                else if (rgbDisplayStatus == 2){
                    for (int counter1 = 0; counter1 <= 255; counter1++){
                        maxValue = (arrayImageContrastAdjustHistogramB [(processingFovNo-1)*256+counter1]/(double)maxCount)*137*verticalMagnification;
                        
                        if (maxValue > 137) maxValue = 137;
                        
                        positionAA.x = counter1+4;
                        positionAA.y = 3;
                        positionBB.x = counter1+4;
                        positionBB.y = maxValue;
                        
                        [[NSColor blueColor] set];
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        maxValue = (arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1]/(double)maxCount)*137*verticalMagnification;
                        
                        if (maxValue > 137) maxValue = 137;
                        
                        positionAA.x = counter1+4;
                        positionAA.y = 3;
                        positionBB.x = counter1+4;
                        positionBB.y = maxValue;
                        
                        [[NSColor redColor] set];
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        maxValue = (arrayImageContrastAdjustHistogramG [(processingFovNo-1)*256+counter1]/(double)maxCount)*137*verticalMagnification;
                        
                        if (maxValue > 137) maxValue = 137;
                        
                        positionAA.x = counter1+4;
                        positionAA.y = 3;
                        positionBB.x = counter1+4;
                        positionBB.y = maxValue;
                        
                        [[NSColor greenColor] set];
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    }
                }
                else if (rgbDisplayStatus == 3){
                    for (int counter1 = 0; counter1 <= 255; counter1++){
                        maxValue = (arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1]/(double)maxCount)*137*verticalMagnification;
                        
                        if (maxValue > 137) maxValue = 137;
                        
                        positionAA.x = counter1+4;
                        positionAA.y = 3;
                        positionBB.x = counter1+4;
                        positionBB.y = maxValue;
                        
                        [[NSColor redColor] set];
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        maxValue = (arrayImageContrastAdjustHistogramG [(processingFovNo-1)*256+counter1]/(double)maxCount)*137*verticalMagnification;
                        
                        if (maxValue > 137) maxValue = 137;
                        
                        positionAA.x = counter1+4;
                        positionAA.y = 3;
                        positionBB.x = counter1+4;
                        positionBB.y = maxValue;
                        
                        [[NSColor greenColor] set];
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        maxValue = (arrayImageContrastAdjustHistogramB [(processingFovNo-1)*256+counter1]/(double)maxCount)*137*verticalMagnification;
                        
                        if (maxValue > 137) maxValue = 137;
                        
                        positionAA.x = counter1+4;
                        positionAA.y = 3;
                        positionBB.x = counter1+4;
                        positionBB.y = maxValue;
                        
                        [[NSColor blueColor] set];
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    }
                }
                
                if (rgbDisplayStatus == 1){
                    [[NSColor yellowColor] set];
                    [NSBezierPath setDefaultLineWidth:2.0];
                    
                    positionAA.x = lowValueDisplay+4;
                    positionAA.y = 3;
                    positionBB.x = lowValueDisplay+4;
                    positionBB.y = 100;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    positionAA.x = highValueDisplay+4;
                    positionAA.y = 3;
                    positionBB.x = highValueDisplay+4;
                    positionBB.y = 100;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    [[NSColor blackColor] set];
                    positionAA.x = meanValueDisplay+4;
                    positionAA.y = 3;
                    positionBB.x = meanValueDisplay+4;
                    positionBB.y = 130;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
                else if (rgbDisplayStatus == 2){
                    [[NSColor yellowColor] set];
                    [NSBezierPath setDefaultLineWidth:2.0];
                    
                    positionAA.x = lowValueDisplayG+4;
                    positionAA.y = 3;
                    positionBB.x = lowValueDisplayG+4;
                    positionBB.y = 100;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    positionAA.x = highValueDisplayG+4;
                    positionAA.y = 3;
                    positionBB.x = highValueDisplayG+4;
                    positionBB.y = 100;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    [[NSColor blackColor] set];
                    positionAA.x = meanValueDisplayG+4;
                    positionAA.y = 3;
                    positionBB.x = meanValueDisplayG+4;
                    positionBB.y = 130;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
                else if (rgbDisplayStatus == 3){
                    [[NSColor yellowColor] set];
                    [NSBezierPath setDefaultLineWidth:2.0];
                    
                    positionAA.x = lowValueDisplayB+4;
                    positionAA.y = 3;
                    positionBB.x = lowValueDisplayB+4;
                    positionBB.y = 100;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    positionAA.x = highValueDisplayB+4;
                    positionAA.y = 3;
                    positionBB.x = highValueDisplayB+4;
                    positionBB.y = 100;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    [[NSColor blackColor] set];
                    positionAA.x = meanValueDisplayB+4;
                    positionAA.y = 3;
                    positionBB.x = meanValueDisplayB+4;
                    positionBB.y = 130;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
            }
        }
        
        int lowSetValue = 0;
        int meanSetValue = 0;
        int highSetValue = 0;
        
        if (rgbDisplayStatus == 0 || rgbDisplayStatus == 1){
            lowSetValue = lowValueDisplay;
            meanSetValue = meanValueDisplay;
            highSetValue = highValueDisplay;
        }
        else if (rgbDisplayStatus == 2){
            lowSetValue = lowValueDisplayG;
            meanSetValue = meanValueDisplayG;
            highSetValue = highValueDisplayG;
        }
        else if (rgbDisplayStatus == 3){
            lowSetValue = lowValueDisplayB;
            meanSetValue = meanValueDisplayB;
            highSetValue = highValueDisplayB;
        }
        
        NSAttributedString *attrStrA;
        NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
        
        string extension = to_string(lowSetValue);
        
        [attributesA setObject:[NSFont systemFontOfSize:12] forKey:NSFontAttributeName];
        [attributesA setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
        
        attrStrA = [[NSAttributedString alloc] initWithString:@"L:" attributes:attributesA];
        positionAA.x = 260;
        positionAA.y = 120;
        [attrStrA drawAtPoint:positionAA];
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributesA];
        positionAA.x = 275;
        positionAA.y = 120;
        [attrStrA drawAtPoint:positionAA];
        
        extension = to_string(meanSetValue);
        
        [attributesA setObject:[NSFont systemFontOfSize:12] forKey:NSFontAttributeName];
        [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        
        attrStrA = [[NSAttributedString alloc] initWithString:@"M:" attributes:attributesA];
        positionAA.x = 260;
        positionAA.y = 100;
        [attrStrA drawAtPoint:positionAA];
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributesA];
        positionAA.x = 275;
        positionAA.y = 100;
        [attrStrA drawAtPoint:positionAA];
        
        extension = to_string(highSetValue);
        
        [attributesA setObject:[NSFont systemFontOfSize:12] forKey:NSFontAttributeName];
        [attributesA setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
        
        attrStrA = [[NSAttributedString alloc] initWithString:@"H:" attributes:attributesA];
        positionAA.x = 260;
        positionAA.y = 80;
        [attrStrA drawAtPoint:positionAA];
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributesA];
        positionAA.x = 275;
        positionAA.y = 80;
        [attrStrA drawAtPoint:positionAA];
    }
}

-(void)resetData:(int)resetType{
    if (processingFovNo == -1){
        histoMaxCount = 0;
        lowValueDisplay = 0;
        meanValueDisplay = 0;
        highValueDisplay = 0;
        lowValueDisplayG = 0;
        meanValueDisplayG = 0;
        highValueDisplayG = 0;
        lowValueDisplayB = 0;
        meanValueDisplayB = 0;
        highValueDisplayB = 0;
        
        if (contrastOADisplay == "On" && backgroundOADisplay == "Off"){
            if (photoMetricHold == 1){
                for (int counter1 = 0; counter1 < loadImageFOVNo; counter1++){
                    for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            if (resetType == 1){
                                arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3] = arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3];
                            }
                            else{
                                
                                arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3] = arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3];
                                arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3] = arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3];
                            }
                        }
                    }
                }
            }
            else if (photoMetricHold == 2){
                if (rgbDisplayStatus == 1){
                    for (int counter1 = 0; counter1 < loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                if (resetType == 1){
                                    arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3*3] = arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3];
                                }
                                else{
                                    
                                    arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3] = arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3];
                                    arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3*3] = arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3];
                                }
                            }
                        }
                    }
                }
                else if (rgbDisplayStatus == 2){
                    for (int counter1 = 0; counter1 < loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                if (resetType == 1){
                                    arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3*3+1] = arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+1];
                                }
                                else{
                                    
                                    arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+1] = arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3+1];
                                    arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3*3+1] = arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3+1];
                                }
                            }
                        }
                    }
                }
                else if (rgbDisplayStatus == 3){
                    for (int counter1 = 0; counter1 < loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 < imageDimensionY; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                if (resetType == 1){
                                    arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3*3+2] = arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+2];
                                }
                                else{
                                    
                                    arrayImageCutoffAdjust [counter1*imageDimensionY+counter2][counter3*3+2] = arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3+2];
                                    arrayImageContrastAdjust [counter1*imageDimensionY+counter2][counter3*3+2] = arrayImageRangeAdjust [counter1*imageDimensionY+counter2][counter3*3+2];
                                }
                            }
                        }
                    }
                }
            }
            
            if (photoMetricHold == 1){
                for (int counter1 = 0; counter1 <= loadImageFOVNo; counter1++){
                    for (int counter2 = 0; counter2 <= 255; counter2++){
                        if (resetType == 1) arrayImageContrastAdjustHistogram [counter1*256+counter2] = arrayImageCutoffAdjustHistogram [counter1*256+counter2];
                        else{
                            
                            arrayImageCutoffAdjustHistogram [counter1*256+counter2] = arrayImageRangeAdjustHistogram [counter1*256+counter2];
                            arrayImageContrastAdjustHistogram [counter1*256+counter2] = arrayImageRangeAdjustHistogram [counter1*256+counter2];
                        }
                    }
                }
                
                for (int counter1 = 1; counter1 < 256; counter1++){
                    if (arrayImageCutoffAdjustHistogram [loadImageFOVNo*256+counter1] > histoMaxCount) histoMaxCount = arrayImageCutoffAdjustHistogram [loadImageFOVNo*256+counter1];
                }
            }
            else if (photoMetricHold == 2){
                if (rgbDisplayStatus == 1){
                    for (int counter1 = 0; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 <= 255; counter2++){
                            if (resetType == 1) arrayImageContrastAdjustHistogram [counter1*256+counter2] = arrayImageCutoffAdjustHistogram [counter1*256+counter2];
                            else{
                                
                                arrayImageCutoffAdjustHistogram [counter1*256+counter2] = arrayImageRangeAdjustHistogram [counter1*256+counter2];
                                arrayImageContrastAdjustHistogram [counter1*256+counter2] = arrayImageRangeAdjustHistogram [counter1*256+counter2];
                            }
                        }
                    }
                }
                else if (rgbDisplayStatus == 2){
                    for (int counter1 = 0; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 <= 255; counter2++){
                            if (resetType == 1) arrayImageContrastAdjustHistogramG [counter1*256+counter2] = arrayImageCutoffAdjustHistogramG [counter1*256+counter2];
                            else{
                                
                                arrayImageCutoffAdjustHistogramG [counter1*256+counter2] = arrayImageRangeAdjustHistogramG [counter1*256+counter2];
                                arrayImageContrastAdjustHistogramG [counter1*256+counter2] = arrayImageRangeAdjustHistogramG [counter1*256+counter2];
                            }
                        }
                    }
                }
                else if (rgbDisplayStatus == 3){
                    for (int counter1 = 0; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = 0; counter2 <= 255; counter2++){
                            if (resetType == 1) arrayImageContrastAdjustHistogramB [counter1*256+counter2] = arrayImageCutoffAdjustHistogramB [counter1*256+counter2];
                            else{
                                
                                arrayImageCutoffAdjustHistogramB [counter1*256+counter2] = arrayImageRangeAdjustHistogramB [counter1*256+counter2];
                                arrayImageContrastAdjustHistogramB [counter1*256+counter2] = arrayImageRangeAdjustHistogramB [counter1*256+counter2];
                            }
                        }
                    }
                }
                
                for (int counter1 = 1; counter1 < 256; counter1++){
                    if (arrayImageCutoffAdjustHistogram [loadImageFOVNo*256+counter1] > histoMaxCount) histoMaxCount = arrayImageCutoffAdjustHistogram [loadImageFOVNo*256+counter1];
                    if (arrayImageCutoffAdjustHistogramG [loadImageFOVNo*256+counter1] > histoMaxCount) histoMaxCount = arrayImageCutoffAdjustHistogramG [loadImageFOVNo*256+counter1];
                    if (arrayImageCutoffAdjustHistogramB [loadImageFOVNo*256+counter1] > histoMaxCount) histoMaxCount = arrayImageCutoffAdjustHistogramB [loadImageFOVNo*256+counter1];
                }
            }
            
            if (histoMaxCount > 2000*loadImageFOVNo) histoMaxCount = 2000*loadImageFOVNo;
            
            if (photoMetricHold == 1){
                for (int counter1 = 0; counter1 <= loadImageFOVNo; counter1++){
                    if (resetType == 1){
                        autoContrastCorrectLMH2 [counter1*3] = autoContrastCorrectLMH [counter1*3];
                        autoContrastCorrectLMH2 [counter1*3+1] = autoContrastCorrectLMH [counter1*3+1];
                        autoContrastCorrectLMH2 [counter1*3+2] = autoContrastCorrectLMH [counter1*3+2];
                    }
                    else{
                        
                        autoContrastCorrectLMH [counter1*3] = arrayImageRangeAdjustLMH [counter1*3];
                        autoContrastCorrectLMH [counter1*3+1] = arrayImageRangeAdjustLMH [counter1*3+1];
                        autoContrastCorrectLMH [counter1*3+2] = arrayImageRangeAdjustLMH [counter1*3+2];
                        
                        autoContrastCorrectLMH2 [counter1*3] = arrayImageRangeAdjustLMH [counter1*3];
                        autoContrastCorrectLMH2 [counter1*3+1] = arrayImageRangeAdjustLMH [counter1*3+1];
                        autoContrastCorrectLMH2 [counter1*3+2] = arrayImageRangeAdjustLMH [counter1*3+2];
                    }
                }
                
                lowValueDisplay = autoContrastCorrectLMH [loadImageFOVNo*3];
                meanValueDisplay = autoContrastCorrectLMH [loadImageFOVNo*3+1];
                highValueDisplay = autoContrastCorrectLMH [loadImageFOVNo*3+2];
            }
            else if (photoMetricHold == 2){
                if (rgbDisplayStatus == 1){
                    for (int counter1 = 0; counter1 <= loadImageFOVNo; counter1++){
                        if (resetType == 1){
                            autoContrastCorrectLMH2 [counter1*3] = autoContrastCorrectLMH [counter1*3];
                            autoContrastCorrectLMH2 [counter1*3+1] = autoContrastCorrectLMH [counter1*3+1];
                            autoContrastCorrectLMH2 [counter1*3+2] = autoContrastCorrectLMH [counter1*3+2];
                        }
                        else{
                            
                            autoContrastCorrectLMH [counter1*3] = arrayImageRangeAdjustLMH [counter1*3];
                            autoContrastCorrectLMH [counter1*3+1] = arrayImageRangeAdjustLMH [counter1*3+1];
                            autoContrastCorrectLMH [counter1*3+2] = arrayImageRangeAdjustLMH [counter1*3+2];
                            
                            autoContrastCorrectLMH2 [counter1*3] = arrayImageRangeAdjustLMH [counter1*3];
                            autoContrastCorrectLMH2 [counter1*3+1] = arrayImageRangeAdjustLMH [counter1*3+1];
                            autoContrastCorrectLMH2 [counter1*3+2] = arrayImageRangeAdjustLMH [counter1*3+2];
                        }
                    }
                    
                    lowValueDisplay = autoContrastCorrectLMH [loadImageFOVNo*3];
                    meanValueDisplay = autoContrastCorrectLMH [loadImageFOVNo*3+1];
                    highValueDisplay = autoContrastCorrectLMH [loadImageFOVNo*3+2];
                }
                else if (rgbDisplayStatus == 2){
                    for (int counter1 = 0; counter1 <= loadImageFOVNo; counter1++){
                        if (resetType == 1){
                            autoContrastCorrectLMH2G [counter1*3] = autoContrastCorrectLMHG [counter1*3];
                            autoContrastCorrectLMH2G [counter1*3+1] = autoContrastCorrectLMHG [counter1*3+1];
                            autoContrastCorrectLMH2G [counter1*3+2] = autoContrastCorrectLMHG [counter1*3+2];
                        }
                        else{
                            
                            autoContrastCorrectLMHG [counter1*3] = arrayImageRangeAdjustLMHG [counter1*3];
                            autoContrastCorrectLMHG [counter1*3+1] = arrayImageRangeAdjustLMHG [counter1*3+1];
                            autoContrastCorrectLMHG [counter1*3+2] = arrayImageRangeAdjustLMHG [counter1*3+2];
                            
                            autoContrastCorrectLMH2G [counter1*3] = arrayImageRangeAdjustLMHG [counter1*3];
                            autoContrastCorrectLMH2G [counter1*3+1] = arrayImageRangeAdjustLMHG [counter1*3+1];
                            autoContrastCorrectLMH2G [counter1*3+2] = arrayImageRangeAdjustLMHG [counter1*3+2];
                        }
                    }
                    
                    lowValueDisplayG = autoContrastCorrectLMHG [loadImageFOVNo*3];
                    meanValueDisplayG = autoContrastCorrectLMHG [loadImageFOVNo*3+1];
                    highValueDisplayG = autoContrastCorrectLMHG [loadImageFOVNo*3+2];
                }
                else if (rgbDisplayStatus == 3){
                    for (int counter1 = 0; counter1 <= loadImageFOVNo; counter1++){
                        if (resetType == 1){
                            autoContrastCorrectLMH2B [counter1*3] = autoContrastCorrectLMHB [counter1*3];
                            autoContrastCorrectLMH2B [counter1*3+1] = autoContrastCorrectLMHB [counter1*3+1];
                            autoContrastCorrectLMH2B [counter1*3+2] = autoContrastCorrectLMHB [counter1*3+2];
                        }
                        else{
                            
                            autoContrastCorrectLMHB [counter1*3] = arrayImageRangeAdjustLMHB [counter1*3];
                            autoContrastCorrectLMHB [counter1*3+1] = arrayImageRangeAdjustLMHB [counter1*3+1];
                            autoContrastCorrectLMHB [counter1*3+2] = arrayImageRangeAdjustLMHB [counter1*3+2];
                            
                            autoContrastCorrectLMH2B [counter1*3] = arrayImageRangeAdjustLMHB [counter1*3];
                            autoContrastCorrectLMH2B [counter1*3+1] = arrayImageRangeAdjustLMHB [counter1*3+1];
                            autoContrastCorrectLMH2B [counter1*3+2] = arrayImageRangeAdjustLMHB [counter1*3+2];
                        }
                    }
                    
                    lowValueDisplayB = autoContrastCorrectLMHB [loadImageFOVNo*3];
                    meanValueDisplayB = autoContrastCorrectLMHB [loadImageFOVNo*3+1];
                    highValueDisplayB = autoContrastCorrectLMHB [loadImageFOVNo*3+2];
                }
            }
            
            int entryCount = 0;
            int writeStartFlag = 0;
            int lowCut2 = 0;
            int meanValue2 = 0;
            int highCut2 = 0;
            int contrastTemp = 0;
            
            double contrastDouble = 0;
            
            string stringData;
            string stringExtract;
            string contrastString;
            
            if (rgbDisplayStatus == 0 || rgbDisplayStatus == 1){
                contrastValueDisplay = 0;
                
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    if (arrayTableDisplay [counter1*5] == loadImageTreatName && arrayTableDisplay [counter1*5+2] != " "){
                        writeStartFlag = 1;
                        
                        lowCut2 = autoContrastCorrectLMH [entryCount*3];
                        meanValue2 = autoContrastCorrectLMH [entryCount*3+1];
                        highCut2 = autoContrastCorrectLMH [entryCount*3+2];
                        
                        stringData = arrayTableDisplay [counter1*5+2];
                        stringExtract = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                        
                        contrastTemp = (int)(contrastValueDisplay*100);
                        contrastDouble = contrastTemp/(double)100;
                        
                        stringstream extension4;
                        extension4 << contrastDouble;
                        contrastString = extension4.str();
                        
                        arrayTableDisplay [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringExtract+"~0";
                        entryCount++;
                    }
                    else if (writeStartFlag == 1 && arrayTableDisplay [counter1*5] == " " && arrayTableDisplay [counter1*5+2] != " "){
                        lowCut2 = autoContrastCorrectLMH [entryCount*3];
                        meanValue2 = autoContrastCorrectLMH [entryCount*3+1];
                        highCut2 = autoContrastCorrectLMH [entryCount*3+2];
                        
                        stringData = arrayTableDisplay [counter1*5+2];
                        stringExtract = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                        
                        contrastTemp = (int)(contrastValueDisplay*100);
                        contrastDouble = contrastTemp/(double)100;
                        
                        stringstream extension4;
                        extension4 << contrastDouble;
                        contrastString = extension4.str();
                        
                        arrayTableDisplay [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringExtract+"~0";
                        entryCount++;
                    }
                    else if (writeStartFlag == 1 && ((arrayTableDisplay [counter1*5] != " " && arrayTableDisplay [counter1*5+2] != " ") || (arrayTableDisplay [counter1*5] == " " && arrayTableDisplay [counter1*5+2] == " "))){
                        break;
                    }
                }
            }
            else if (rgbDisplayStatus == 1){
                contrastValueDisplayG = 0;
                
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    if (arrayTableDisplayG [counter1*5] == loadImageTreatName && arrayTableDisplayG [counter1*5+2] != " "){
                        writeStartFlag = 1;
                        
                        lowCut2 = autoContrastCorrectLMHG [entryCount*3];
                        meanValue2 = autoContrastCorrectLMHG [entryCount*3+1];
                        highCut2 = autoContrastCorrectLMHG [entryCount*3+2];
                        
                        stringData = arrayTableDisplayG [counter1*5+2];
                        stringExtract = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                        
                        contrastTemp = (int)(contrastValueDisplayG*100);
                        contrastDouble = contrastTemp/(double)100;
                        
                        stringstream extension4;
                        extension4 << contrastDouble;
                        contrastString = extension4.str();
                        
                        arrayTableDisplayG [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringExtract+"~0";
                        entryCount++;
                    }
                    else if (writeStartFlag == 1 && arrayTableDisplayG [counter1*5] == " " && arrayTableDisplayG [counter1*5+2] != " "){
                        lowCut2 = autoContrastCorrectLMHG [entryCount*3];
                        meanValue2 = autoContrastCorrectLMHG [entryCount*3+1];
                        highCut2 = autoContrastCorrectLMHG [entryCount*3+2];
                        
                        stringData = arrayTableDisplayG [counter1*5+2];
                        stringExtract = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                        
                        contrastTemp = (int)(contrastValueDisplayG*100);
                        contrastDouble = contrastTemp/(double)100;
                        
                        stringstream extension4;
                        extension4 << contrastDouble;
                        contrastString = extension4.str();
                        
                        arrayTableDisplayG [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringExtract+"~0";
                        entryCount++;
                    }
                    else if (writeStartFlag == 1 && ((arrayTableDisplayG [counter1*5] != " " && arrayTableDisplayG [counter1*5+2] != " ") || (arrayTableDisplayG [counter1*5] == " " && arrayTableDisplayG [counter1*5+2] == " "))){
                        break;
                    }
                }
            }
            else if (rgbDisplayStatus == 2){
                contrastValueDisplayB = 0;
                
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    if (arrayTableDisplayB [counter1*5] == loadImageTreatName && arrayTableDisplayB [counter1*5+2] != " "){
                        writeStartFlag = 1;
                        
                        lowCut2 = autoContrastCorrectLMHB [entryCount*3];
                        meanValue2 = autoContrastCorrectLMHB [entryCount*3+1];
                        highCut2 = autoContrastCorrectLMHB [entryCount*3+2];
                        
                        stringData = arrayTableDisplayB [counter1*5+2];
                        stringExtract = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                        
                        contrastTemp = (int)(contrastValueDisplayB*100);
                        contrastDouble = contrastTemp/(double)100;
                        
                        stringstream extension4;
                        extension4 << contrastDouble;
                        contrastString = extension4.str();
                        
                        arrayTableDisplayB [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringExtract+"~0";
                        entryCount++;
                    }
                    else if (writeStartFlag == 1 && arrayTableDisplayB [counter1*5] == " " && arrayTableDisplayB [counter1*5+2] != " "){
                        lowCut2 = autoContrastCorrectLMHB [entryCount*3];
                        meanValue2 = autoContrastCorrectLMHB [entryCount*3+1];
                        highCut2 = autoContrastCorrectLMHB [entryCount*3+2];
                        
                        stringData = arrayTableDisplayB [counter1*5+2];
                        stringExtract = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                        
                        contrastTemp = (int)(contrastValueDisplayB*100);
                        contrastDouble = contrastTemp/(double)100;
                        
                        stringstream extension4;
                        extension4 << contrastDouble;
                        contrastString = extension4.str();
                        
                        arrayTableDisplayB [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringExtract+"~0";
                        entryCount++;
                    }
                    else if (writeStartFlag == 1 && ((arrayTableDisplayB [counter1*5] != " " && arrayTableDisplayB [counter1*5+2] != " ") || (arrayTableDisplayB [counter1*5] == " " && arrayTableDisplayB [counter1*5+2] == " "))){
                        break;
                    }
                }
            }
            
            if (rgbDisplayStatus == 0 || rgbDisplayStatus == 1){
                for (int counter1 = 0; counter1 <= loadImageFOVNo+1; counter1++) contrastValueHold [counter1] = 0;
                
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    contrastCurrentHold [counter1] = arrayTableDisplay [counter1*5+2];
                }
            }
            else if (rgbDisplayStatus == 2){
                for (int counter1 = 0; counter1 <= loadImageFOVNo+1; counter1++) contrastValueHoldG [counter1] = 0;
                
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    contrastCurrentHoldG [counter1] = arrayTableDisplayG [counter1*5+2];
                }
            }
            else if (rgbDisplayStatus == 3){
                for (int counter1 = 0; counter1 <= loadImageFOVNo+1; counter1++) contrastValueHoldB [counter1] = 0;
                
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    contrastCurrentHoldB [counter1] = arrayTableDisplayB [counter1*5+2];
                }
            }
            
            contrastValueDisplay = 0;
            contrastBarActivate = 0;
            tableViewCall = 1;
            imageInfoDisplayCall = 1;
            mainImageDisplayCall = 1;
            contrastDisplayCall = 1;
        }
    }
    else if (processingFovNo > 0){
        histoMaxCount = 0;
        lowValueDisplay = 0;
        meanValueDisplay = 0;
        highValueDisplay = 0;
        lowValueDisplayG = 0;
        meanValueDisplayG = 0;
        highValueDisplayG = 0;
        lowValueDisplayB = 0;
        meanValueDisplayB = 0;
        highValueDisplayB = 0;
        
        if (contrastOADisplay == "On" && backgroundOADisplay == "Off"){
            if (photoMetricHold == 1){
                for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                    for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                        if (resetType == 1){
                            arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2] = arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2];
                        }
                        else{
                            
                            arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2] = arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2];
                            arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2] = arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2];
                        }
                    }
                }
            }
            else if (photoMetricHold == 2){
                if (rgbDisplayStatus == 1){
                    for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                        for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                            if (resetType == 1){
                                arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3] = arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3];
                            }
                            else{
                                
                                arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3] = arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3];
                                arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3] = arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3];
                            }
                        }
                    }
                }
                else if (rgbDisplayStatus == 2){
                    for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                        for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                            if (resetType == 1){
                                arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1] = arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1];
                            }
                            else{
                                
                                arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1] = arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1];
                                arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1] = arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+1];
                            }
                        }
                    }
                }
                else if (rgbDisplayStatus == 3){
                    for (int counter1 = 0; counter1 < imageDimensionY; counter1++){
                        for (int counter2 = 0; counter2 < imageDimensionX; counter2++){
                            if (resetType == 1){
                                arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2] = arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2];
                            }
                            else{
                                
                                arrayImageCutoffAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2] = arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2];
                                arrayImageContrastAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2] = arrayImageRangeAdjust [(processingFovNo-1)*imageDimensionY+counter1][counter2*3+2];
                            }
                        }
                    }
                }
            }
            
            if (photoMetricHold == 1){
                for (int counter1 = 0; counter1 <= 255; counter1++){
                    if (resetType == 1) arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1] = arrayImageCutoffAdjustHistogram [(processingFovNo-1)*256+counter1];
                    else{
                        
                        arrayImageCutoffAdjustHistogram [(processingFovNo-1)*256+counter1] = arrayImageRangeAdjustHistogram [(processingFovNo-1)*256+counter1];
                        arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1] = arrayImageRangeAdjustHistogram [(processingFovNo-1)*256+counter1];
                    }
                }
                
                for (int counter1 = 1; counter1 < 256; counter1++){
                    if (arrayImageCutoffAdjustHistogram [(processingFovNo-1)*256+counter1] > histoMaxCount) histoMaxCount = arrayImageCutoffAdjustHistogram [(processingFovNo-1)*256+counter1];
                }
            }
            else if (photoMetricHold == 2){
                if (rgbDisplayStatus == 1){
                    for (int counter1 = 0; counter1 <= 255; counter1++){
                        if (resetType == 1) arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1] = arrayImageCutoffAdjustHistogram [(processingFovNo-1)*256+counter1];
                        else{
                            
                            arrayImageCutoffAdjustHistogram [(processingFovNo-1)*256+counter1] = arrayImageRangeAdjustHistogram [(processingFovNo-1)*256+counter1];
                            arrayImageContrastAdjustHistogram [(processingFovNo-1)*256+counter1] = arrayImageRangeAdjustHistogram [(processingFovNo-1)*256+counter1];
                        }
                    }
                    
                    for (int counter1 = 1; counter1 < 256; counter1++){
                        if (arrayImageCutoffAdjustHistogram [(processingFovNo-1)*256+counter1] > histoMaxCount) histoMaxCount = arrayImageCutoffAdjustHistogram [(processingFovNo-1)*256+counter1];
                    }
                }
                else if (rgbDisplayStatus == 2){
                    for (int counter1 = 0; counter1 <= 255; counter1++){
                        if (resetType == 1) arrayImageContrastAdjustHistogramG [(processingFovNo-1)*256+counter1] = arrayImageCutoffAdjustHistogramG [(processingFovNo-1)*256+counter1];
                        else{
                            
                            arrayImageCutoffAdjustHistogramG [(processingFovNo-1)*256+counter1] = arrayImageRangeAdjustHistogramG [(processingFovNo-1)*256+counter1];
                            arrayImageContrastAdjustHistogramG [(processingFovNo-1)*256+counter1] = arrayImageRangeAdjustHistogramG [(processingFovNo-1)*256+counter1];
                        }
                    }
                }
                else if (rgbDisplayStatus == 3){
                    for (int counter1 = 0; counter1 <= 255; counter1++){
                        if (resetType == 1) arrayImageContrastAdjustHistogramB [(processingFovNo-1)*256+counter1] = arrayImageCutoffAdjustHistogramB [(processingFovNo-1)*256+counter1];
                        else{
                            
                            arrayImageCutoffAdjustHistogramB [(processingFovNo-1)*256+counter1] = arrayImageRangeAdjustHistogramB [(processingFovNo-1)*256+counter1];
                            arrayImageContrastAdjustHistogramB [(processingFovNo-1)*256+counter1] = arrayImageRangeAdjustHistogramB [(processingFovNo-1)*256+counter1];
                        }
                    }
                }
                
                for (int counter1 = 1; counter1 < 256; counter1++){
                    if (arrayImageCutoffAdjustHistogram [(processingFovNo-1)*256+counter1] > histoMaxCount) histoMaxCount = arrayImageCutoffAdjustHistogram [(processingFovNo-1)*256+counter1];
                    if (arrayImageCutoffAdjustHistogramG [(processingFovNo-1)*256+counter1] > histoMaxCount) histoMaxCount = arrayImageCutoffAdjustHistogramG [(processingFovNo-1)*256+counter1];
                    if (arrayImageCutoffAdjustHistogramB [(processingFovNo-1)*256+counter1] > histoMaxCount) histoMaxCount = arrayImageCutoffAdjustHistogramB [(processingFovNo-1)*256+counter1];
                }
            }
            
            if (histoMaxCount > 2000) histoMaxCount = 2000;
            
            if (photoMetricHold == 1){
                if (resetType == 1){
                    autoContrastCorrectLMH2 [(processingFovNo-1)*3] = autoContrastCorrectLMH [(processingFovNo-1)*3];
                    autoContrastCorrectLMH2 [(processingFovNo-1)*3+1] = autoContrastCorrectLMH [(processingFovNo-1)*3+1];
                    autoContrastCorrectLMH2 [(processingFovNo-1)*3+2] = autoContrastCorrectLMH [(processingFovNo-1)*3+2];
                }
                else{
                    
                    autoContrastCorrectLMH [(processingFovNo-1)*3] = arrayImageRangeAdjustLMH [(processingFovNo-1)*3];
                    autoContrastCorrectLMH [(processingFovNo-1)*3+1] = arrayImageRangeAdjustLMH [(processingFovNo-1)*3+1];
                    autoContrastCorrectLMH [(processingFovNo-1)*3+2] = arrayImageRangeAdjustLMH [(processingFovNo-1)*3+2];
                    
                    autoContrastCorrectLMH2 [(processingFovNo-1)*3] = arrayImageRangeAdjustLMH [(processingFovNo-1)*3];
                    autoContrastCorrectLMH2 [(processingFovNo-1)*3+1] = arrayImageRangeAdjustLMH [(processingFovNo-1)*3+1];
                    autoContrastCorrectLMH2 [(processingFovNo-1)*3+2] = arrayImageRangeAdjustLMH [(processingFovNo-1)*3+2];
                }
                
                lowValueDisplay = autoContrastCorrectLMH [(processingFovNo-1)*3];
                meanValueDisplay = autoContrastCorrectLMH [(processingFovNo-1)*3+1];
                highValueDisplay = autoContrastCorrectLMH [(processingFovNo-1)*3+2];
            }
            else if (photoMetricHold == 2){
                if (rgbDisplayStatus == 1){
                    if (resetType == 1){
                        autoContrastCorrectLMH2 [(processingFovNo-1)*3] = autoContrastCorrectLMH [(processingFovNo-1)*3];
                        autoContrastCorrectLMH2 [(processingFovNo-1)*3+1] = autoContrastCorrectLMH [(processingFovNo-1)*3+1];
                        autoContrastCorrectLMH2 [(processingFovNo-1)*3+2] = autoContrastCorrectLMH [(processingFovNo-1)*3+2];
                    }
                    else{
                        
                        autoContrastCorrectLMH [(processingFovNo-1)*3] = arrayImageRangeAdjustLMH [(processingFovNo-1)*3];
                        autoContrastCorrectLMH [(processingFovNo-1)*3+1] = arrayImageRangeAdjustLMH [(processingFovNo-1)*3+1];
                        autoContrastCorrectLMH [(processingFovNo-1)*3+2] = arrayImageRangeAdjustLMH [(processingFovNo-1)*3+2];
                        
                        autoContrastCorrectLMH2 [(processingFovNo-1)*3] = arrayImageRangeAdjustLMH [(processingFovNo-1)*3];
                        autoContrastCorrectLMH2 [(processingFovNo-1)*3+1] = arrayImageRangeAdjustLMH [(processingFovNo-1)*3+1];
                        autoContrastCorrectLMH2 [(processingFovNo-1)*3+2] = arrayImageRangeAdjustLMH [(processingFovNo-1)*3+2];
                    }
                    
                    lowValueDisplay = autoContrastCorrectLMH [(processingFovNo-1)*3];
                    meanValueDisplay = autoContrastCorrectLMH [(processingFovNo-1)*3+1];
                    highValueDisplay = autoContrastCorrectLMH [(processingFovNo-1)*3+2];
                }
                else if (rgbDisplayStatus == 2){
                    if (resetType == 1){
                        autoContrastCorrectLMH2G [(processingFovNo-1)*3] = autoContrastCorrectLMHG [(processingFovNo-1)*3];
                        autoContrastCorrectLMH2G [(processingFovNo-1)*3+1] = autoContrastCorrectLMHG [(processingFovNo-1)*3+1];
                        autoContrastCorrectLMH2G [(processingFovNo-1)*3+2] = autoContrastCorrectLMHG [(processingFovNo-1)*3+2];
                    }
                    else{
                        
                        autoContrastCorrectLMHG [(processingFovNo-1)*3] = arrayImageRangeAdjustLMHG [(processingFovNo-1)*3];
                        autoContrastCorrectLMHG [(processingFovNo-1)*3+1] = arrayImageRangeAdjustLMHG [(processingFovNo-1)*3+1];
                        autoContrastCorrectLMHG [(processingFovNo-1)*3+2] = arrayImageRangeAdjustLMHG [(processingFovNo-1)*3+2];
                        
                        autoContrastCorrectLMH2G [(processingFovNo-1)*3] = arrayImageRangeAdjustLMHG [(processingFovNo-1)*3];
                        autoContrastCorrectLMH2G [(processingFovNo-1)*3+1] = arrayImageRangeAdjustLMHG [(processingFovNo-1)*3+1];
                        autoContrastCorrectLMH2G [(processingFovNo-1)*3+2] = arrayImageRangeAdjustLMHG [(processingFovNo-1)*3+2];
                    }
                    
                    lowValueDisplayG = autoContrastCorrectLMHG [(processingFovNo-1)*3];
                    meanValueDisplayG = autoContrastCorrectLMHG [(processingFovNo-1)*3+1];
                    highValueDisplayG = autoContrastCorrectLMHG [(processingFovNo-1)*3+2];
                }
                else if (rgbDisplayStatus == 3){
                    if (resetType == 1){
                        autoContrastCorrectLMH2B [(processingFovNo-1)*3] = autoContrastCorrectLMHB [(processingFovNo-1)*3];
                        autoContrastCorrectLMH2B [(processingFovNo-1)*3+1] = autoContrastCorrectLMHB [(processingFovNo-1)*3+1];
                        autoContrastCorrectLMH2B [(processingFovNo-1)*3+2] = autoContrastCorrectLMHB [(processingFovNo-1)*3+2];
                    }
                    else{
                        
                        autoContrastCorrectLMHB [(processingFovNo-1)*3] = arrayImageRangeAdjustLMHB [(processingFovNo-1)*3];
                        autoContrastCorrectLMHB [(processingFovNo-1)*3+1] = arrayImageRangeAdjustLMHB [(processingFovNo-1)*3+1];
                        autoContrastCorrectLMHB [(processingFovNo-1)*3+2] = arrayImageRangeAdjustLMHB [(processingFovNo-1)*3+2];
                        
                        autoContrastCorrectLMH2B [(processingFovNo-1)*3] = arrayImageRangeAdjustLMHB [(processingFovNo-1)*3];
                        autoContrastCorrectLMH2B [(processingFovNo-1)*3+1] = arrayImageRangeAdjustLMHB [(processingFovNo-1)*3+1];
                        autoContrastCorrectLMH2B [(processingFovNo-1)*3+2] = arrayImageRangeAdjustLMHB [(processingFovNo-1)*3+2];
                    }
                    
                    lowValueDisplayB = autoContrastCorrectLMHB [(processingFovNo-1)*3];
                    meanValueDisplayB = autoContrastCorrectLMHB [(processingFovNo-1)*3+1];
                    highValueDisplayB = autoContrastCorrectLMHB [(processingFovNo-1)*3+2];
                }
            }
            
            int entryCount = 0;
            int writeStartFlag = 0;
            int lowCut2 = 0;
            int meanValue2 = 0;
            int highCut2 = 0;
            
            string stringData;
            string stringExtract;
            string contrastString;
            string stringExtract2;
            
            if (rgbDisplayStatus == 0 || rgbDisplayStatus == 1){
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    if (arrayTableDisplay [counter1*5] == loadImageTreatName && arrayTableDisplay [counter1*5+2] != " "){
                        writeStartFlag = 1;
                        
                        lowCut2 = autoContrastCorrectLMH [entryCount*3];
                        meanValue2 = autoContrastCorrectLMH [entryCount*3+1];
                        highCut2 = autoContrastCorrectLMH [entryCount*3+2];
                        
                        stringData = arrayTableDisplay [counter1*5+2];
                        stringExtract = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                        
                        if ((processingFovNo-1)*3 == entryCount*3) contrastString = "0";
                        else{
                            
                            stringExtract2 = stringData.substr(stringData.find("/")+1);
                            stringExtract2 = stringExtract2.substr(stringExtract2.find("/")+1);
                            stringExtract2 = stringExtract2.substr(stringExtract2.find("/")+1);
                            contrastString = stringExtract2.substr(0, stringExtract2.find(" "));
                        }
                        
                        arrayTableDisplay [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringExtract+"~0";
                        entryCount++;
                    }
                    else if (writeStartFlag == 1 && arrayTableDisplay [counter1*5] == " " && arrayTableDisplay [counter1*5+2] != " "){
                        lowCut2 = autoContrastCorrectLMH [entryCount*3];
                        meanValue2 = autoContrastCorrectLMH [entryCount*3+1];
                        highCut2 = autoContrastCorrectLMH [entryCount*3+2];
                        
                        stringData = arrayTableDisplay [counter1*5+2];
                        stringExtract = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                        
                        if ((processingFovNo-1)*3 == entryCount*3) contrastString = "0";
                        else{
                            
                            stringExtract2 = stringData.substr(stringData.find("/")+1);
                            stringExtract2 = stringExtract2.substr(stringExtract2.find("/")+1);
                            stringExtract2 = stringExtract2.substr(stringExtract2.find("/")+1);
                            contrastString = stringExtract2.substr(0, stringExtract2.find(" "));
                        }
                        
                        arrayTableDisplay [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringExtract+"~0";
                        entryCount++;
                    }
                    else if (writeStartFlag == 1 && ((arrayTableDisplay [counter1*5] != " " && arrayTableDisplay [counter1*5+2] != " ") || (arrayTableDisplay [counter1*5] == " " && arrayTableDisplay [counter1*5+2] == " "))){
                        break;
                    }
                }
            }
            else if (rgbDisplayStatus == 2){
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    if (arrayTableDisplayG [counter1*5] == loadImageTreatName && arrayTableDisplayG [counter1*5+2] != " "){
                        writeStartFlag = 1;
                        
                        lowCut2 = autoContrastCorrectLMHG [entryCount*3];
                        meanValue2 = autoContrastCorrectLMHG [entryCount*3+1];
                        highCut2 = autoContrastCorrectLMHG [entryCount*3+2];
                        
                        stringData = arrayTableDisplayG [counter1*5+2];
                        stringExtract = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                        
                        if ((processingFovNo-1)*3 == entryCount*3) contrastString = "0";
                        else{
                            
                            stringExtract2 = stringData.substr(stringData.find("/")+1);
                            stringExtract2 = stringExtract2.substr(stringExtract2.find("/")+1);
                            stringExtract2 = stringExtract2.substr(stringExtract2.find("/")+1);
                            contrastString = stringExtract2.substr(0, stringExtract2.find(" "));
                        }
                        
                        arrayTableDisplayG [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringExtract+"~0";
                        entryCount++;
                    }
                    else if (writeStartFlag == 1 && arrayTableDisplayG [counter1*5] == " " && arrayTableDisplayG [counter1*5+2] != " "){
                        lowCut2 = autoContrastCorrectLMHG [entryCount*3];
                        meanValue2 = autoContrastCorrectLMHG [entryCount*3+1];
                        highCut2 = autoContrastCorrectLMHG [entryCount*3+2];
                        
                        stringData = arrayTableDisplayG [counter1*5+2];
                        stringExtract = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                        
                        if ((processingFovNo-1)*3 == entryCount*3) contrastString = "0";
                        else{
                            
                            stringExtract2 = stringData.substr(stringData.find("/")+1);
                            stringExtract2 = stringExtract2.substr(stringExtract2.find("/")+1);
                            stringExtract2 = stringExtract2.substr(stringExtract2.find("/")+1);
                            contrastString = stringExtract2.substr(0, stringExtract2.find(" "));
                        }
                        
                        arrayTableDisplayG [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringExtract+"~0";
                        entryCount++;
                    }
                    else if (writeStartFlag == 1 && ((arrayTableDisplayG [counter1*5] != " " && arrayTableDisplayG [counter1*5+2] != " ") || (arrayTableDisplayG [counter1*5] == " " && arrayTableDisplayG [counter1*5+2] == " "))){
                        break;
                    }
                }
            }
            else if (rgbDisplayStatus == 3){
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    if (arrayTableDisplayB [counter1*5] == loadImageTreatName && arrayTableDisplayB [counter1*5+2] != " "){
                        writeStartFlag = 1;
                        
                        lowCut2 = autoContrastCorrectLMHB [entryCount*3];
                        meanValue2 = autoContrastCorrectLMHB [entryCount*3+1];
                        highCut2 = autoContrastCorrectLMHB [entryCount*3+2];
                        
                        stringData = arrayTableDisplayB [counter1*5+2];
                        stringExtract = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                        
                        if ((processingFovNo-1)*3 == entryCount*3) contrastString = "0";
                        else{
                            
                            stringExtract2 = stringData.substr(stringData.find("/")+1);
                            stringExtract2 = stringExtract2.substr(stringExtract2.find("/")+1);
                            stringExtract2 = stringExtract2.substr(stringExtract2.find("/")+1);
                            contrastString = stringExtract2.substr(0, stringExtract2.find(" "));
                        }
                        
                        arrayTableDisplayB [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringExtract+"~0";
                        entryCount++;
                    }
                    else if (writeStartFlag == 1 && arrayTableDisplayB [counter1*5] == " " && arrayTableDisplayB [counter1*5+2] != " "){
                        lowCut2 = autoContrastCorrectLMHB [entryCount*3];
                        meanValue2 = autoContrastCorrectLMHB [entryCount*3+1];
                        highCut2 = autoContrastCorrectLMHB [entryCount*3+2];
                        
                        stringData = arrayTableDisplayB [counter1*5+2];
                        stringExtract = stringData.substr(stringData.find(" "), stringData.find("~")-stringData.find(" "));
                        
                        if ((processingFovNo-1)*3 == entryCount*3) contrastString = "0";
                        else{
                            
                            stringExtract2 = stringData.substr(stringData.find("/")+1);
                            stringExtract2 = stringExtract2.substr(stringExtract2.find("/")+1);
                            stringExtract2 = stringExtract2.substr(stringExtract2.find("/")+1);
                            contrastString = stringExtract2.substr(0, stringExtract2.find(" "));
                        }
                        
                        arrayTableDisplayB [counter1*5+2] = to_string(lowCut2)+"/"+to_string(meanValue2)+"/"+to_string(highCut2)+"/"+contrastString+stringExtract+"~0";
                        entryCount++;
                    }
                    else if (writeStartFlag == 1 && ((arrayTableDisplayB [counter1*5] != " " && arrayTableDisplayB [counter1*5+2] != " ") || (arrayTableDisplayB [counter1*5] == " " && arrayTableDisplayB [counter1*5+2] == " "))){
                        break;
                    }
                }
            }
            
            if (rgbDisplayStatus == 0 || rgbDisplayStatus == 1){
                contrastValueHold [processingFovNo] = 0;
                
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    contrastCurrentHold [counter1] = arrayTableDisplay [counter1*5+2];
                }
            }
            else if (rgbDisplayStatus == 2){
                contrastValueHoldG [processingFovNo] = 0;
                
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    contrastCurrentHoldG [counter1] = arrayTableDisplayG [counter1*5+2];
                }
            }
            else if (rgbDisplayStatus == 3){
                contrastValueHoldB [processingFovNo] = 0;
                
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    contrastCurrentHoldB [counter1] = arrayTableDisplayB [counter1*5+2];
                }
            }
            
            contrastValueDisplay = 0;
            contrastBarActivate = 0;
            tableViewCall = 1;
            imageInfoDisplayCall = 1;
            mainImageDisplayCall = 1;
            contrastDisplayCall = 1;
        }
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToHistogram object:nil];
}

@end
