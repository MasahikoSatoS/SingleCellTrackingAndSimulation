/*
 *  Autocontrast.m
 *  Contrast_Set
 *
 *  Created by Masahiko Sato on 01/01/10.
 *  Copyright Masahiko Sato 2010 All rights reserved.
 *
 */

#import "Autocontrast.h"

NSString *notificationToAutocontrast = @"notificationExecuteAutocontrast";

@implementation Autocontrast

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToAutocontrast object:nil];
    }
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        autoProcessingFlag = 1;
        
        string entry;
        string entry2;
        string productDataPath1;
        string productDataPath2;
        
        DIR *dir;
        struct dirent *dent;
        DIR *dir2;
        struct dirent *dent2;
        
        dir = opendir(productsStitchTempPath.c_str());
        fileDeleteCount = 0;
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                productDataPath1 = productsStitchTempPath+"/"+entry;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    dir2 = opendir(productDataPath1.c_str());
                    
                    if (dir2 != NULL){
                        while ((dent2 = readdir(dir2))){
                            entry2 = dent2 -> d_name;
                            
                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                            arrayFileDelete [fileDeleteCount] = productDataPath1+"/"+entry2, fileDeleteCount++;
                        }
                        
                        closedir(dir2);
                    }
                }
            }
            
            closedir(dir);
            
            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                remove (arrayFileDelete [counter1].c_str());
            }
        }
        
        string treatName;
        int treatNameCount = 0;
        
        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
            treatName = arrayTreatmentNameDisplay [counter1];
            
            if (treatName != "ND") treatNameCount++;
        }
        
        int processDone = 0;
        int progressCount = 1;
        int fovNumberCount = 0;
        int fileOpen = 0;
        int fovPositionHoldTempCount = 0;
        int stitchedImageAuto = 0;
        int treatFind = 0;
        int timeDataUse = 0;
        int cutOffTempCount = 0;
        int cutOffTempCountG = 0;
        int cutOffTempCountB = 0;
        int contrastTempCount = 0;
        int contrastTempCountG = 0;
        int contrastTempCountB = 0;
        int processStatusTempCount = 0;
        int imageDimensionCount = 0;
        int entryCount = 0;
        int numberOfPoint = 0;
        int lowestValueTemp = 0;
        int highestValueTemp = 0;
        int meanValueTemp = 0;
        int pixNo90 = 0;
        int valueAverage = 0;
        int totalPix = 0;
        int valueShift = 0;
        int newPixValue = 0;
        int extensionType = 0;
        int bcType = 2;
        
        unsigned long totalCount = 0;
        double expansionFactor1 = 0;
        double expansionFactor2 = 0;
        double rangeLimitBase = 0;
        double rangeLimitHorizontal = 0;
        double rangeLimitVertical = 0;
        
        //-----Tiff reading-----
        unsigned long stripFirstAddress = 0;
        unsigned long stripByteCountAddress = 0;
        unsigned long nextAddress = 0;
        unsigned long headPosition = 0;
        unsigned long stripEntry = 0;
        unsigned long ifDPreviousHold = 0;
        long sizeForCopy = 0;
        
        double xPosition = 0;
        double yPosition = 0;
        
        int imageWidth = 0;
        int imageHeight = 0;
        int imageBit = 0; // Check 8, 16
        int imageCompression = 0; // Check 1
        int photoMetric = 0;//check 0, 1, 2
        int imageDimensionTif = 0;
        int horizontalBmp = 0;
        int horizontalBmpEntry = 0;
        int endianType = 0;
        int samplePerPix = 0;
        int dataConversion [4];
        int mode = 0;
        int processTypeTif = 1;
        int numberOfLayers = 0;
        int photoMetricAuto = 0;
        int dimensionAdditionX = 0;
        int dimensionAdditionY = 0;
        int verticalBmp = 0;
        int backgroundPatternNameCount = 0;
        int numberOfBlock = 0;
        
        string fovName;
        string folderName;
        string getString;
        string treatString;
        string channelString;
        string extension;
        string timeString;
        string processFilePath;
        string processFilePath2;
        string colorName;
        string fovString;
        string timeDetermine;
        string cutOffData;
        string lowExtract;
        string meanExtract;
        string highExtract;
        string contrastExtract;
        string autoExtract;
        string rangeExtract;
        string treatNameTemp2;
        string fovName2;
        string colorNameNo;
        string balanceExtract;
        string processFilePathWithExt;
        string fileExtension;
        string patternPath;
        string xDimensionString;
        string yDimensionString;
        
        struct stat sizeOfFile;
        
        ifstream fin;
        
        progressValue = treatmentNameDisplayCount;
        progressTiming = 1;
        
        do usleep(10);
        while (progressTiming == 1);
        
        progressValue = 2;
        progressTiming = 3;
        
        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
            treatmentNameAuto = arrayTreatmentNameDisplay [counter1];
            progressValue = progressCount;
            progressTiming = 3;
            
            progressCount++;
            
            if (treatmentNameAuto != "ND"){
                if (treatmentNameAuto.substr(treatmentNameAuto.length()-3, 2) == "CH"){
                    treatString = treatmentNameAuto.substr(0, treatmentNameAuto.length()-3);
                    channelString = treatmentNameAuto.substr(treatmentNameAuto.length()-1, 1);
                }
                else{
                    
                    treatString = treatmentNameAuto;
                    channelString = "";
                }
                
                if (autoType == 1 || autoType == 3) extension = to_string(currentTimePoint+1);
                else if (autoType == 2) extension = to_string(loadImageNo);
                else if (autoType == 5) extension = to_string(reprocessImageNo);
                
                if (extension.length() == 1) timeString = "000"+extension;
                else if (extension.length() == 2) timeString = "00"+extension;
                else if (extension.length() == 3) timeString = "0"+extension;
                else if (extension.length() == 4) timeString = extension;
                
                fovNumberCount = 0;
                folderName = treatString+"~Sorted";
                processFilePath = productsFilesImagePath+"/"+treatString+"~Sorted";
                
                dir = opendir(processFilePath.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find("FOV") != -1) fovNumberCount++;
                        }
                    }
                    
                    closedir(dir);
                }
                
                if (fovNumberCount != 0){ //-----Check folder No.: proceed to the next step if no folder is found-----
                    fileOpen = 0;
                    autoImageSizeX = 0;
                    autoImageSizeY = 0;
                    
                    fileExtension = "";
                    
                    //-----Check for CH files; proceed to the next step if no CH files are found; obtain image size-----
                    for (int counter2 = 1; counter2 <= fovNumberCount; counter2++){
                        extension = to_string(counter2);
                        
                        if (extension.length() == 1) fovString = "FOV00"+extension;
                        else if (extension.length() == 2) fovString = "FOV0"+extension;
                        else if (extension.length() == 3) fovString = "FOV"+extension;
                        
                        processFilePath = "";
                        
                        if (channelString == ""){
                            if (autoType == 1 || autoType == 3){
                                if (currentTimePoint < lastImageNo){
                                    processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString;
                                }
                                else if (currentTimePoint == lastImageNo){
                                    processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString;
                                    processFilePath2 = processFilePath+".tif";
                                    
                                    fin.open(processFilePath2.c_str(), ios::in);
                                    
                                    if (!fin.is_open()){
                                        processFilePath2 = processFilePath+".bmp";
                                        
                                        fin.open(processFilePath2.c_str(), ios::in);
                                        
                                        if (fin.is_open()) fin.close();
                                        else processFilePath = productsFilesImagePath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+timeString+"-"+fovString;
                                    }
                                    else fin.close();
                                }
                            }
                            else processFilePath = productsFilesImagePath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+timeString+"-"+fovString;
                        }
                        else{
                            
                            if (channelString == "1"){
                                colorName = fluorescent1;
                                colorNameNo = fluorescentNo1;
                            }
                            else if (channelString == "2"){
                                colorName = fluorescent2;
                                colorNameNo = fluorescentNo2;
                            }
                            else if (channelString == "3"){
                                colorName = fluorescent3;
                                colorNameNo = fluorescentNo3;
                            }
                            else if (channelString == "4"){
                                colorName = fluorescent4;
                                colorNameNo = fluorescentNo4;
                            }
                            else if (channelString == "5"){
                                colorName = fluorescent5;
                                colorNameNo = fluorescentNo5;
                            }
                            else if (channelString == "6"){
                                colorName = fluorescent6;
                                colorNameNo = fluorescentNo6;
                            }
                            
                            if (autoType == 1 || autoType == 3){
                                if (currentTimePoint < lastImageNo){
                                    processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString+"_"+colorNameNo+"_"+colorName;
                                }
                                else if (currentTimePoint == lastImageNo){
                                    processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString+"_"+colorNameNo+"_"+colorName;
                                    processFilePath2 = processFilePath+".tif";
                                    
                                    fin.open(processFilePath2.c_str(), ios::in);
                                    
                                    if (!fin.is_open()){
                                        processFilePath2 = processFilePath+".bmp";
                                        
                                        fin.open(processFilePath2.c_str(), ios::in);
                                        
                                        if (fin.is_open()) fin.close();
                                        else processFilePath = productsFilesImagePath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+timeString+"-"+fovString+"_"+colorNameNo+"_"+colorName;
                                    }
                                    else fin.close();
                                }
                            }
                            else processFilePath = productsFilesImagePath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+timeString+"-"+fovString+"_"+colorNameNo+"_"+colorName;
                        }
                        
                        extensionType = 0;
                        
                        processFilePathWithExt = processFilePath+".tif";
                        
                        fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            extensionType = 1;
                            fileExtension = ".tif";
                            fin.close();
                        }
                        else{
                            
                            processFilePathWithExt = processFilePath+".bmp";
                            
                            fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                extensionType = 2;
                                fileExtension = ".bmp";
                                fin.close();
                            }
                        }
                        
                        if (extensionType == 1){
                            if (stat(processFilePathWithExt.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                fileReadArray = new uint8_t [sizeForCopy+4];
                                fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
                                
                                fin.read((char*)fileReadArray, sizeForCopy+4);
                                fin.close();
                                
                                dataConversion [0] = fileReadArray [0];
                                dataConversion [1] = fileReadArray [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = fileReadArray [7];
                                    dataConversion [1] = fileReadArray [6];
                                    dataConversion [2] = fileReadArray [5];
                                    dataConversion [3] = fileReadArray [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = fileReadArray [4];
                                    dataConversion [1] = fileReadArray [5];
                                    dataConversion [2] = fileReadArray [6];
                                    dataConversion [3] = fileReadArray [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                if (endianType == 1){
                                    self->tiffFileRead = [[TiffFileRead alloc] init];
                                    [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                }
                                else if (endianType == 0){
                                    self->tiffFileRead = [[TiffFileRead alloc] init];
                                    [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                }
                                
                                autoImageSizeX = imageWidth;
                                autoImageSizeY = imageHeight;
                                
                                if (photoMetric == 0) photoMetricAuto = 1;
                                else photoMetricAuto = photoMetric;
                                
                                delete [] fileReadArray;
                            }
                            else fileOpen = 1;
                        }
                        else if (extensionType == 2){
                            if (stat(processFilePathWithExt.c_str(), &sizeOfFile) == -1) fileOpen = 1;
                            else{
                                
                                fileOpen = 0;
                                
                                FILE *upLoad3 = fopen(processFilePathWithExt.c_str(), "rb");
                                fseek (upLoad3, 18, 0);
                                
                                dataConversion [0] = fgetc(upLoad3);
                                dataConversion [1] = fgetc(upLoad3);
                                dataConversion [2] = fgetc(upLoad3);
                                dataConversion [3] = fgetc(upLoad3);
                                autoImageSizeX = dataConversion [3]*16777216+dataConversion [2]*65536+dataConversion [1]*256+dataConversion [0];
                                autoImageSizeY = autoImageSizeX;
                                
                                photoMetricAuto = 1;
                                
                                fclose(upLoad3);
                                break;
                            }
                        }
                    }
                    
                    if (fileOpen == 0){ //----- If files are found, process the images-----
                        int *cutOffTemp = new int [treatmentNameDisplayCount*3+50];
                        int *cutOffTempG = new int [treatmentNameDisplayCount*3+50];
                        int *cutOffTempB = new int [treatmentNameDisplayCount*3+50];
                        
                        double *contrastTemp = new double [treatmentNameDisplayCount+50];
                        double *contrastTempG = new double [treatmentNameDisplayCount+50];
                        double *contrastTempB = new double [treatmentNameDisplayCount+50];
                        
                        int *processStatusTemp = new int [treatmentNameDisplayCount*2+50];
                        
                        int *arrayImageDataHistogramTemp = new int [(fovNumberCount+1)*256+50];
                        int *arrayImageDataHistogramTempG = new int [(fovNumberCount+1)*256+50];
                        int *arrayImageDataHistogramTempB = new int [(fovNumberCount+1)*256+50];
                        int *arrayImageRangeAdjustHistogramTemp = new int [(fovNumberCount+1)*256+50];
                        int *arrayImageCutoffAdjustHistogramTemp = new int [(fovNumberCount+1)*256+50];
                        
                        int *arrayImageDataTempLMH = new int [treatmentNameDisplayCount*3+50];
                        int *arrayImageDataTempLMHG = new int [treatmentNameDisplayCount*3+50];
                        int *arrayImageDataTempLMHB = new int [treatmentNameDisplayCount*3+50];
                        int *arrayImageRangeAdjustTempLMH = new int [treatmentNameDisplayCount*3+50];
                        int *arrayImageRangeAdjustTempLMHG = new int [treatmentNameDisplayCount*3+50];
                        int *arrayImageRangeAdjustTempLMHB = new int [treatmentNameDisplayCount*3+50];
                        
                        int *fovPositionHoldTemp = new int [treatmentNameDisplayCount*2+50];
                        correctionValues = new double [treatmentNameDisplayCount+50];
                        
                        //-----FOV information get-----
                        fovPositionHoldTempCount = 0;
                        stitchedImageAuto = 100;
                        
                        int fileOpenCheck = 0;
                        
                        if (processMode == 5 || processMode == 13 || processMode == 7){
                            fileOpenCheck = stat(fovPositionTempPath.c_str(), &sizeOfFile);
                        }
                        else{
                            
                            fileOpenCheck = stat(fovPositionPath.c_str(), &sizeOfFile);
                        }
                        
                        if (fileOpenCheck == 0){
                            treatFind = 0;
                            
                            if (processMode == 5 || processMode == 13 || processMode == 7) fin.open(fovPositionTempPath.c_str(), ios::in);
                            else fin.open(fovPositionPath.c_str(), ios::in);
                            
                            if (fin.is_open()){
                                do{
                                    
                                    getline(fin, getString);
                                    
                                    if (treatmentNameAuto == getString && treatFind == 0) treatFind = 1;
                                    else if (getString != "ND" && treatFind == 1){
                                        stitchedImageAuto = atoi(getString.c_str());
                                        treatFind = 2;
                                    }
                                    else if (getString != "ND" && treatFind == 2){
                                        fovPositionHoldTemp [fovPositionHoldTempCount] = atoi(getString.c_str()), fovPositionHoldTempCount++;
                                    }
                                    else if (getString == "ND" && treatFind == 2) treatFind = 3;
                                    
                                } while (getString != "");
                                
                                fin.close();
                            }
                            
                            //for (int counterA = 0; counterA < fovPositionHoldTempCount; counterA++){
                            //    cout<<" "<<fovPositionHoldTemp [counterA]<<" fovPositionHoldTemp "<<counterA+1<<endl;
                            //}
                            
                            //-----Determine data to be used for cutoff-----
                            timeDataUse = 1;
                            
                            for (int counter2 = 1; counter2 <= entryNumber; counter2++){
                                timeDetermine = arrayContrastData [0][counter2+2];
                                timeDetermine = timeDetermine.substr(1);
                                
                                if (autoType == 1 || autoType == 3){
                                    if (atoi(timeDetermine.c_str()) < currentTimePoint+1) timeDataUse = counter2;
                                }
                                if (autoType == 2){
                                    if (atoi(timeDetermine.c_str()) < loadImageNo+1) timeDataUse = counter2;
                                }
                                else if (atoi(timeDetermine.c_str()) < reprocessImageNo+1) timeDataUse = counter2;
                            }
                            
                            //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
                            //    for (int counterB = 0; counterB < entryNumber+3; counterB++) cout<<" "<<arrayContrastData [counterA][counterB];
                            //    cout<<"  arrayContrastData "<<counterA+1<<endl;
                            //}
                            
                            treatFind = 0;
                            cutOffTempCount = 0;
                            cutOffTempCountG = 0;
                            cutOffTempCountB = 0;
                            contrastTempCount = 0;
                            contrastTempCountG = 0;
                            contrastTempCountB = 0;
                            processStatusTempCount = 0;
                            
                            /*===Read Table data and set Cut off, Contrast and others to cutOffTemp, ContrastTemp, processStatusTemp. For Color processStatusTemp will not be set===*/
                            for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++){
                                treatNameTemp2 = arrayTreatmentNameDisplay [counter2];
                                fovName2 = arrayFOVNameDisplay [counter2];
                                
                                if (treatNameTemp2 == treatmentNameAuto && fovName2 != "ND" && treatFind == 0){
                                    treatFind = 1;
                                    
                                    cutOffData = arrayContrastData [counter2][timeDataUse+2];
                                    lowExtract = cutOffData.substr(0, cutOffData.find("/"));
                                    cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                    meanExtract = cutOffData.substr(0, cutOffData.find("/"));
                                    cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                    highExtract = cutOffData.substr(0, cutOffData.find("/"));
                                    cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                    contrastExtract = cutOffData.substr(0, cutOffData.find(" "));
                                    cutOffData = cutOffData.substr(cutOffData.find(" ")+1);
                                    autoExtract = cutOffData.substr(0, 1);
                                    cutOffData = cutOffData.substr(1);
                                    rangeExtract = cutOffData.substr(0, cutOffData.find(":"));
                                    balanceExtract = cutOffData.substr(cutOffData.find("~")+1);
                                    
                                    cutOffTemp [cutOffTempCount] = atoi(lowExtract.c_str()), cutOffTempCount++;
                                    cutOffTemp [cutOffTempCount] = atoi(meanExtract.c_str()), cutOffTempCount++;
                                    cutOffTemp [cutOffTempCount] = atoi(highExtract.c_str()), cutOffTempCount++;
                                    contrastTemp [contrastTempCount] = atof(contrastExtract.c_str()), contrastTempCount++;
                                    
                                    if (autoExtract == "A") processStatusTemp [processStatusTempCount] = 1, processStatusTempCount++;
                                    else if (autoExtract == "B") processStatusTemp [processStatusTempCount] = 2, processStatusTempCount++;
                                    else if (autoExtract == "C") processStatusTemp [processStatusTempCount] = 3, processStatusTempCount++;
                                    else if (autoExtract == "D") processStatusTemp [processStatusTempCount] = 4, processStatusTempCount++;
                                    else if (autoExtract == "E") processStatusTemp [processStatusTempCount] = 5, processStatusTempCount++;
                                    else if (autoExtract == "F") processStatusTemp [processStatusTempCount] = 6, processStatusTempCount++;
                                    else if (autoExtract == "G") processStatusTemp [processStatusTempCount] = 7, processStatusTempCount++;
                                    else processStatusTemp [processStatusTempCount] = 0, processStatusTempCount++;
                                    
                                    processStatusTemp [processStatusTempCount] = atoi(rangeExtract.c_str()), processStatusTempCount++;
                                    
                                    if (photoMetricAuto == 2){
                                        cutOffData = arrayContrastDataG [counter2][timeDataUse+2];
                                        lowExtract = cutOffData.substr(0, cutOffData.find("/"));
                                        cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                        meanExtract = cutOffData.substr(0, cutOffData.find("/"));
                                        cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                        highExtract = cutOffData.substr(0, cutOffData.find("/"));
                                        cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                        contrastExtract = cutOffData.substr(0, cutOffData.find(" "));
                                        cutOffData = cutOffData.substr(cutOffData.find(" ")+1);
                                        autoExtract = cutOffData.substr(0, 1);
                                        cutOffData = cutOffData.substr(1);
                                        rangeExtract = cutOffData.substr(0, cutOffData.find(":"));
                                        balanceExtract = cutOffData.substr(cutOffData.find("~")+1);
                                        
                                        cutOffTempG [cutOffTempCountG] = atoi(lowExtract.c_str()), cutOffTempCountG++;
                                        cutOffTempG [cutOffTempCountG] = atoi(meanExtract.c_str()), cutOffTempCountG++;
                                        cutOffTempG [cutOffTempCountG] = atoi(highExtract.c_str()), cutOffTempCountG++;
                                        contrastTempG [contrastTempCountG] = atof(contrastExtract.c_str()), contrastTempCountG++;
                                        
                                        cutOffData = arrayContrastDataB [counter2][timeDataUse+2];
                                        lowExtract = cutOffData.substr(0, cutOffData.find("/"));
                                        cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                        meanExtract = cutOffData.substr(0, cutOffData.find("/"));
                                        cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                        highExtract = cutOffData.substr(0, cutOffData.find("/"));
                                        cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                        contrastExtract = cutOffData.substr(0, cutOffData.find(" "));
                                        cutOffData = cutOffData.substr(cutOffData.find(" ")+1);
                                        autoExtract = cutOffData.substr(0, 1);
                                        cutOffData = cutOffData.substr(1);
                                        rangeExtract = cutOffData.substr(0, cutOffData.find(":"));
                                        balanceExtract = cutOffData.substr(cutOffData.find("~")+1);
                                        
                                        cutOffTempB [cutOffTempCountB] = atoi(lowExtract.c_str()), cutOffTempCountB++;
                                        cutOffTempB [cutOffTempCountB] = atoi(meanExtract.c_str()), cutOffTempCountB++;
                                        cutOffTempB [cutOffTempCountB] = atoi(highExtract.c_str()), cutOffTempCountB++;
                                        contrastTempB [contrastTempCountB] = atof(contrastExtract.c_str()), contrastTempCountB++;
                                    }
                                    
                                    //cout<<lowExtract<<" "<<meanExtract<<" "<<highExtract<<" "<<contrastExtract<<" "<<autoExtract<<" "<<backExtract <<" Info"<<endl;
                                }
                                else if (treatNameTemp2 == "ND" && fovName2 != "ND" && treatFind == 1){
                                    cutOffData = arrayContrastData [counter2][timeDataUse+2];
                                    lowExtract = cutOffData.substr(0, cutOffData.find("/"));
                                    cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                    meanExtract = cutOffData.substr(0, cutOffData.find("/"));
                                    cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                    highExtract = cutOffData.substr(0, cutOffData.find("/"));
                                    cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                    contrastExtract = cutOffData.substr(0, cutOffData.find(" "));
                                    cutOffData = cutOffData.substr(cutOffData.find(" ")+1);
                                    autoExtract = cutOffData.substr(0, 1);
                                    cutOffData = cutOffData.substr(1);
                                    rangeExtract = cutOffData.substr(0, cutOffData.find(":"));
                                    balanceExtract = cutOffData.substr(cutOffData.find("~")+1);
                                    
                                    cutOffTemp [cutOffTempCount] = atoi(lowExtract.c_str()), cutOffTempCount++;
                                    cutOffTemp [cutOffTempCount] = atoi(meanExtract.c_str()), cutOffTempCount++;
                                    cutOffTemp [cutOffTempCount] = atoi(highExtract.c_str()), cutOffTempCount++;
                                    contrastTemp [contrastTempCount] = atof(contrastExtract.c_str()), contrastTempCount++;
                                    
                                    if (autoExtract == "A") processStatusTemp [processStatusTempCount] = 1, processStatusTempCount++;
                                    else if (autoExtract == "B") processStatusTemp [processStatusTempCount] = 2, processStatusTempCount++;
                                    else if (autoExtract == "C") processStatusTemp [processStatusTempCount] = 3, processStatusTempCount++;
                                    else if (autoExtract == "D") processStatusTemp [processStatusTempCount] = 4, processStatusTempCount++;
                                    else if (autoExtract == "E") processStatusTemp [processStatusTempCount] = 5, processStatusTempCount++;
                                    else if (autoExtract == "F") processStatusTemp [processStatusTempCount] = 6, processStatusTempCount++;
                                    else if (autoExtract == "G") processStatusTemp [processStatusTempCount] = 7, processStatusTempCount++;
                                    else processStatusTemp [processStatusTempCount] = 0, processStatusTempCount++;
                                    
                                    processStatusTemp [processStatusTempCount] = atoi(rangeExtract.c_str()), processStatusTempCount++;
                                    
                                    if (photoMetricAuto == 2){
                                        cutOffData = arrayContrastDataG [counter2][timeDataUse+2];
                                        lowExtract = cutOffData.substr(0, cutOffData.find("/"));
                                        cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                        meanExtract = cutOffData.substr(0, cutOffData.find("/"));
                                        cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                        highExtract = cutOffData.substr(0, cutOffData.find("/"));
                                        cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                        contrastExtract = cutOffData.substr(0, cutOffData.find(" "));
                                        cutOffData = cutOffData.substr(cutOffData.find(" ")+1);
                                        autoExtract = cutOffData.substr(0, 1);
                                        cutOffData = cutOffData.substr(1);
                                        rangeExtract = cutOffData.substr(0, cutOffData.find(":"));
                                        balanceExtract = cutOffData.substr(cutOffData.find("~")+1);
                                        
                                        cutOffTempG [cutOffTempCountG] = atoi(lowExtract.c_str()), cutOffTempCountG++;
                                        cutOffTempG [cutOffTempCountG] = atoi(meanExtract.c_str()), cutOffTempCountG++;
                                        cutOffTempG [cutOffTempCountG] = atoi(highExtract.c_str()), cutOffTempCountG++;
                                        contrastTempG [contrastTempCountG] = atof(contrastExtract.c_str()), contrastTempCountG++;
                                        
                                        cutOffData = arrayContrastDataB [counter2][timeDataUse+2];
                                        lowExtract = cutOffData.substr(0, cutOffData.find("/"));
                                        cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                        meanExtract = cutOffData.substr(0, cutOffData.find("/"));
                                        cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                        highExtract = cutOffData.substr(0, cutOffData.find("/"));
                                        cutOffData = cutOffData.substr(cutOffData.find("/")+1);
                                        contrastExtract = cutOffData.substr(0, cutOffData.find(" "));
                                        cutOffData = cutOffData.substr(cutOffData.find(" ")+1);
                                        autoExtract = cutOffData.substr(0, 1);
                                        cutOffData = cutOffData.substr(1);
                                        rangeExtract = cutOffData.substr(0, cutOffData.find(":"));
                                        balanceExtract = cutOffData.substr(cutOffData.find("~")+1);
                                        
                                        cutOffTempB [cutOffTempCountB] = atoi(lowExtract.c_str()), cutOffTempCountB++;
                                        cutOffTempB [cutOffTempCountB] = atoi(meanExtract.c_str()), cutOffTempCountB++;
                                        cutOffTempB [cutOffTempCountB] = atoi(highExtract.c_str()), cutOffTempCountB++;
                                        contrastTempB [contrastTempCountB] = atof(contrastExtract.c_str()), contrastTempCountB++;
                                    }
                                }
                                else if (((treatNameTemp2 != "ND" && fovName2 != "ND") || (treatNameTemp2 == "ND" && fovName2 == "ND")) && treatFind == 1){
                                    treatFind = 2;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < contrastTempCount; counterA++){
                            //    cout<<" "<<contrastTemp [counterA]<< " contrastTemp "<<counterA+1<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < cutOffTempCount/3; counterA++){
                            //    cout<<" "<<cutOffTemp [counterA*3]<<" "<<cutOffTemp [counterA*3+1]<<" "<<cutOffTemp [counterA*3+2]<< " Cutoff "<<counterA+1<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < cutOffTempCount/3; counterA++){
                            //    cout<<" "<<cutOffTempG [counterA*3]<<" "<<cutOffTempG [counterA*3+1]<<" "<<cutOffTempG [counterA*3+2]<< " CutoffG "<<counterA+1<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < cutOffTempCount/3; counterA++){
                            //    cout<<" "<<cutOffTempB [counterA*3]<<" "<<cutOffTempB [counterA*3+1]<<" "<<cutOffTempB [counterA*3+2]<< " CutoffB "<<counterA+1<<endl;
                            //}
                            
                            int **arrayImageDataHoldTemp = new int *[autoImageSizeY*fovNumberCount+2];
                            int **arrayImageRangeAdjustTemp = new int *[autoImageSizeY*fovNumberCount+2];
                            int **arrayImageCutoffAdjustTemp = new int *[autoImageSizeY*fovNumberCount+2];
                            int **arrayImageContrastAdjustTemp = new int *[autoImageSizeY*fovNumberCount+2];
                            arrayBackgroundCorrectionData = new int *[autoImageSizeY*fovNumberCount+2];
                            
                            for (int counter2 = 0; counter2 < autoImageSizeY*fovNumberCount+2; counter2++){
                                arrayImageDataHoldTemp [counter2] = new int [autoImageSizeX*3+2];
                                arrayImageRangeAdjustTemp [counter2] = new int [autoImageSizeX*3+2];
                                arrayImageCutoffAdjustTemp [counter2] = new int [autoImageSizeX*3+2];
                                arrayImageContrastAdjustTemp [counter2] = new int [autoImageSizeX*3+2];
                                arrayBackgroundCorrectionData [counter2] = new int [autoImageSizeX+2];
                            }
                            
                            imageDimensionCount = 0;
                            
                            //=====Image data read=====
                            /*===Image data is stored in arrayImageDataHoldTemp, Histo data is in arrayImageDataHistogramTemp, and contrast info is arrayImageDataTempLMH===*/
                            /*===FOR color image, stored in arrayImageDataHistogramTemp, arrayImageDataTempLMH (R), arrayImageDataHistogramTempG, arrayImageDataTempLMHG, arrayImageDataHistogramTempB, arrayImageDataTempLMHB===*/
                            for (int counter2 = 1; counter2 <= fovNumberCount; counter2++){
                                extension = to_string(counter2);
                                
                                if (extension.length() == 1) fovString = "FOV00"+extension;
                                else if (extension.length() == 2) fovString = "FOV0"+extension;
                                else if (extension.length() == 3) fovString = "FOV"+extension;
                                
                                if (channelString == ""){
                                    if (autoType == 1 || autoType == 3){
                                        if (currentTimePoint < lastImageNo){
                                            processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString;
                                        }
                                        else if (currentTimePoint == lastImageNo){
                                            processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString;
                                            processFilePath2 = processFilePath+".tif";
                                            
                                            fin.open(processFilePath2.c_str(), ios::in);
                                            
                                            if (!fin.is_open()){
                                                processFilePath2 = processFilePath+".bmp";
                                                
                                                fin.open(processFilePath2.c_str(), ios::in);
                                                
                                                if (fin.is_open()) fin.close();
                                                else processFilePath = productsFilesImagePath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+timeString+"-"+fovString;
                                            }
                                            else fin.close();
                                        }
                                    }
                                    else processFilePath = productsFilesImagePath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+timeString+"-"+fovString;
                                }
                                else{
                                    
                                    if (channelString == "1"){
                                        colorName = fluorescent1;
                                        colorNameNo = fluorescentNo1;
                                    }
                                    else if (channelString == "2"){
                                        colorName = fluorescent2;
                                        colorNameNo = fluorescentNo2;
                                    }
                                    else if (channelString == "3"){
                                        colorName = fluorescent3;
                                        colorNameNo = fluorescentNo3;
                                    }
                                    else if (channelString == "4"){
                                        colorName = fluorescent4;
                                        colorNameNo = fluorescentNo4;
                                    }
                                    else if (channelString == "5"){
                                        colorName = fluorescent5;
                                        colorNameNo = fluorescentNo5;
                                    }
                                    else if (channelString == "6"){
                                        colorName = fluorescent6;
                                        colorNameNo = fluorescentNo6;
                                    }
                                    
                                    if (autoType == 1 || autoType == 3){
                                        if (currentTimePoint < lastImageNo){
                                            processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString+"_"+colorNameNo+"_"+colorName;
                                        }
                                        else if (currentTimePoint == lastImageNo){
                                            processFilePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString+"_"+colorNameNo+"_"+colorName;
                                            processFilePath2 = processFilePath+".tif";
                                            
                                            fin.open(processFilePath2.c_str(), ios::in);
                                            
                                            if (!fin.is_open()){
                                                processFilePath2 = processFilePath+".bmp";
                                                fin.open(processFilePath2.c_str(), ios::in);
                                                
                                                if (fin.is_open()) fin.close();
                                                else processFilePath = productsFilesImagePath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+timeString+"-"+fovString+"_"+colorNameNo+"_"+colorName;
                                            }
                                            else fin.close();
                                        }
                                    }
                                    else processFilePath = productsFilesImagePath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+timeString+"-"+fovString+"_"+colorNameNo+"_"+colorName;
                                }
                                
                                extensionType = 0;
                                
                                processFilePathWithExt = processFilePath+".tif";
                                
                                fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    extensionType = 1;
                                    fin.close();
                                }
                                else{
                                    
                                    processFilePathWithExt = processFilePath+".bmp";
                                    
                                    fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        extensionType = 2;
                                        fin.close();
                                    }
                                }
                                
                                if (extensionType == 1){
                                    if (stat(processFilePathWithExt.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                        
                                        fileReadArray = new uint8_t [sizeForCopy+4];
                                        fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
                                        
                                        fin.read((char*)fileReadArray, sizeForCopy+4);
                                        fin.close();
                                        
                                        dataConversion [0] = fileReadArray [0];
                                        dataConversion [1] = fileReadArray [1];
                                        
                                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                        else endianType = 0;
                                        
                                        headPosition = 0;
                                        
                                        if (endianType == 1){
                                            dataConversion [0] = fileReadArray [7];
                                            dataConversion [1] = fileReadArray [6];
                                            dataConversion [2] = fileReadArray [5];
                                            dataConversion [3] = fileReadArray [4];
                                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                        }
                                        else if (endianType == 0){
                                            dataConversion [0] = fileReadArray [4];
                                            dataConversion [1] = fileReadArray [5];
                                            dataConversion [2] = fileReadArray [6];
                                            dataConversion [3] = fileReadArray [7];
                                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                        }
                                        
                                        int *arrayExtractedImage3 = new int [100];
                                        
                                        if (endianType == 1){
                                            self->tiffFileRead = [[TiffFileRead alloc] init];
                                            [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                            
                                            if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                                if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                                else imageDimensionTif = imageHeight;
                                                
                                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                                delete [] arrayExtractedImage3;
                                                
                                                arrayExtractedImage3 = [self->tiffFileRead imageSetBigEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                            }
                                        }
                                        else if (endianType == 0){
                                            self->tiffFileRead = [[TiffFileRead alloc] init];
                                            [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                            
                                            if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                                if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                                else imageDimensionTif = imageHeight;
                                                
                                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                                delete [] arrayExtractedImage3;
                                                
                                                arrayExtractedImage3 = [self->tiffFileRead imageSetLittleEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                            }
                                        }
                                        
                                        //-----Multiply image dimensions by a factor of 8-----
                                        dimensionAdditionY = autoImageSizeY%8;
                                        
                                        if (dimensionAdditionY == 1) dimensionAdditionY = 7;
                                        else if (dimensionAdditionY == 2) dimensionAdditionY = 6;
                                        else if (dimensionAdditionY == 3) dimensionAdditionY = 5;
                                        else if (dimensionAdditionY == 4) dimensionAdditionY = 4;
                                        else if (dimensionAdditionY == 5) dimensionAdditionY = 3;
                                        else if (dimensionAdditionY == 6) dimensionAdditionY = 2;
                                        else if (dimensionAdditionY == 7) dimensionAdditionY = 1;
                                        
                                        autoImageSizeY = autoImageSizeY+dimensionAdditionY;
                                        
                                        dimensionAdditionX = autoImageSizeX%8;
                                        
                                        if (dimensionAdditionX == 1) dimensionAdditionX = 7;
                                        else if (dimensionAdditionX == 2) dimensionAdditionX = 6;
                                        else if (dimensionAdditionX == 3) dimensionAdditionX = 5;
                                        else if (dimensionAdditionX == 4) dimensionAdditionX = 4;
                                        else if (dimensionAdditionX == 5) dimensionAdditionX = 3;
                                        else if (dimensionAdditionX == 6) dimensionAdditionX = 2;
                                        else if (dimensionAdditionX == 7) dimensionAdditionX = 1;
                                        
                                        autoImageSizeX = autoImageSizeX+dimensionAdditionX;
                                        
                                        verticalBmp = 0;
                                        horizontalBmp = 0;
                                        horizontalBmpEntry = 0;
                                        
                                        for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                            if (verticalBmp < imageHeight){
                                                if (horizontalBmp < imageWidth){
                                                    if (photoMetric <= 1){
                                                        arrayImageDataHoldTemp [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3]), horizontalBmpEntry++;
                                                    }
                                                    else if (photoMetric == 2){
                                                        arrayImageDataHoldTemp [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3]), horizontalBmpEntry++;
                                                        arrayImageDataHoldTemp [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+1]), horizontalBmpEntry++;
                                                        arrayImageDataHoldTemp [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3*3+2]), horizontalBmpEntry++;
                                                    }
                                                    
                                                    horizontalBmp++;
                                                }
                                                
                                                if (horizontalBmp == imageWidth && imageWidth < autoImageSizeX){
                                                    for (int counter6 = 0; counter6 < autoImageSizeX-imageWidth; counter6++){
                                                        if (photoMetric <= 1){
                                                            arrayImageDataHoldTemp [imageDimensionCount][horizontalBmpEntry] = -1, horizontalBmpEntry++; //-----Fill blank part with -1
                                                        }
                                                        else if (photoMetric == 2){
                                                            arrayImageDataHoldTemp [imageDimensionCount][horizontalBmpEntry] = -1, horizontalBmpEntry++;
                                                            arrayImageDataHoldTemp [imageDimensionCount][horizontalBmpEntry] = -1, horizontalBmpEntry++;
                                                            arrayImageDataHoldTemp [imageDimensionCount][horizontalBmpEntry] = -1, horizontalBmpEntry++;
                                                        }
                                                    }
                                                }
                                                
                                                if (horizontalBmp == imageWidth){
                                                    horizontalBmp = 0;
                                                    horizontalBmpEntry = 0;
                                                    imageDimensionCount++;
                                                    verticalBmp++;
                                                }
                                            }
                                        }
                                        
                                        if (imageHeight < autoImageSizeY){
                                            for (int counter5 = imageHeight; counter5 < autoImageSizeY; counter5++){
                                                for (int counter6 = 0; counter6 < autoImageSizeX; counter6++){
                                                    if (photoMetric <= 1) arrayImageDataHoldTemp [counter5][counter6] = -1; //-----Fill blank part with -1
                                                    else if (photoMetric == 2){
                                                        arrayImageDataHoldTemp [counter5][counter6] = -1;
                                                        arrayImageDataHoldTemp [counter5][counter6] = -1;
                                                        arrayImageDataHoldTemp [counter5][counter6] = -1;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        delete [] fileReadArray;
                                        delete [] arrayExtractedImage3;
                                    }
                                }
                                else if (extensionType == 2){
                                    totalCount = 0;
                                    entryCount = 0;
                                    
                                    if (stat(processFilePathWithExt.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                        
                                        uint8_t *uploadTemp = new uint8_t [sizeForCopy];
                                        fin.open(processFilePathWithExt.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTemp, sizeForCopy+1);
                                            fin.close();
                                            
                                            for (int counter3 = autoImageSizeY-1; counter3 >= 0; counter3--){
                                                for (int counter4 = 0; counter4 < autoImageSizeX; counter4++){
                                                    if (uploadTemp [1078+counter3*autoImageSizeY+counter4] > 25 && uploadTemp [1078+counter3*autoImageSizeY+counter4] < 225) totalCount = totalCount+uploadTemp [1078+counter3*autoImageSizeY+counter4], entryCount++;
                                                    
                                                    arrayImageDataHoldTemp [imageDimensionCount][counter4] = uploadTemp [1078+counter3*autoImageSizeY+counter4];
                                                }
                                                
                                                imageDimensionCount++;
                                            }
                                        }
                                        
                                        delete [] uploadTemp;
                                    }
                                }
                            }
                            
                            int *histogramTemp = new int [300];
                            
                            if (photoMetricAuto == 1){
                                for (int counter2 = 1; counter2 <= fovNumberCount; counter2++){
                                    for (int counter3 = 0; counter3 <= 255; counter3++) histogramTemp [counter3] = 0;
                                    
                                    for (int counter3 = 0; counter3 < autoImageSizeY; counter3++){
                                        for (int counter4 = 0; counter4 < autoImageSizeX; counter4++){
                                            
                                            if (arrayImageDataHoldTemp [(counter2-1)*autoImageSizeY+counter3][counter4] >= 0 && arrayImageDataHoldTemp [(counter2-1)*autoImageSizeY+counter3][counter4] < 255){
                                                histogramTemp [arrayImageDataHoldTemp [(counter2-1)*autoImageSizeY+counter3][counter4]]++;
                                            }
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 <= 255; counter3++){
                                        arrayImageDataHistogramTemp [(counter2-1)*256+counter3] = histogramTemp [counter3];
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                                
                                for (int counter2 = 1; counter2 <= fovNumberCount; counter2++){
                                    for (int counter3 = 0; counter3 < 256; counter3++){
                                        histogramTemp [counter3] = histogramTemp [counter3]+arrayImageDataHistogramTemp [(counter2-1)*256+counter3];
                                    }
                                }
                                
                                for (int counter2 = 1; counter2 <= 255; counter2++) arrayImageDataHistogramTemp [fovNumberCount*256+counter2] = histogramTemp [counter2];
                                
                                for (int counter2 = 0; counter2 < fovNumberCount; counter2++){
                                    numberOfPoint = 0;
                                    totalCount = 0;
                                    lowestValueTemp = 0;
                                    highestValueTemp = 0;
                                    meanValueTemp = 0;
                                    
                                    for (int counter3 = 1; counter3 < 256; counter3++){
                                        numberOfPoint = numberOfPoint+arrayImageDataHistogramTemp [counter2*256+counter3];
                                        totalCount = totalCount+(unsigned long)(counter3*arrayImageDataHistogramTemp [counter2*256+counter3]);
                                    }
                                    
                                    if (numberOfPoint != 0) meanValueTemp = (int)(totalCount/(double)numberOfPoint);
                                    
                                    pixNo90 = arrayImageDataHistogramTemp [counter2*256+meanValueTemp];
                                    
                                    for (int counter3 = 1; counter3 < 256; counter3++){
                                        if (meanValueTemp-counter3 >= 0){
                                            pixNo90 = pixNo90+arrayImageDataHistogramTemp [counter2*256+meanValueTemp-counter3];
                                            lowestValueTemp = meanValueTemp-counter3;
                                        }
                                        
                                        if (meanValueTemp+counter3 <= 255){
                                            pixNo90 = pixNo90+arrayImageDataHistogramTemp [counter2*256+meanValueTemp+counter3];
                                            highestValueTemp = meanValueTemp+counter3;
                                        }
                                        
                                        if (pixNo90/(double)numberOfPoint > 0.8){
                                            break;
                                        }
                                    }
                                    
                                    arrayImageDataTempLMH [counter2*3] = lowestValueTemp;
                                    arrayImageDataTempLMH [counter2*3+1] = meanValueTemp;
                                    arrayImageDataTempLMH [counter2*3+2] = highestValueTemp;
                                }
                            }
                            else if (photoMetricAuto == 2){
                                //-----R Histo set-----
                                for (int counter2 = 1; counter2 <= fovNumberCount; counter2++){
                                    for (int counter3 = 0; counter3 <= 255; counter3++) histogramTemp [counter3] = 0;
                                    
                                    for (int counter3 = 0; counter3 < autoImageSizeY; counter3++){
                                        for (int counter4 = 0; counter4 < autoImageSizeX; counter4++){
                                            if (arrayImageDataHoldTemp [(counter2-1)*autoImageSizeY+counter3][counter4*3] > 0 && arrayImageDataHoldTemp [(counter2-1)*autoImageSizeY+counter3][counter4*3] < 255){
                                                histogramTemp [arrayImageDataHoldTemp [(counter2-1)*autoImageSizeY+counter3][counter4*3]]++;
                                            }
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 <= 255; counter3++){
                                        arrayImageDataHistogramTemp [(counter2-1)*256+counter3] = histogramTemp [counter3];
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                                
                                for (int counter2 = 1; counter2 <= fovNumberCount; counter2++){
                                    for (int counter3 = 0; counter3 < 256; counter3++){
                                        histogramTemp [counter3] = histogramTemp [counter3]+arrayImageDataHistogramTemp [(counter2-1)*256+counter3];
                                    }
                                }
                                
                                for (int counter2 = 1; counter2 <= 255; counter2++) arrayImageDataHistogramTemp [fovNumberCount*256+counter2] = histogramTemp [counter2];
                                
                                for (int counter2 = 0; counter2 < fovNumberCount; counter2++){
                                    numberOfPoint = 0;
                                    totalCount = 0;
                                    lowestValueTemp = 0;
                                    highestValueTemp = 0;
                                    meanValueTemp = 0;
                                    
                                    for (int counter3 = 1; counter3 < 256; counter3++){
                                        numberOfPoint = numberOfPoint+arrayImageDataHistogramTemp [counter2*256+counter3];
                                        totalCount = totalCount+(unsigned long)(counter3*arrayImageDataHistogramTemp [counter2*256+counter3]);
                                    }
                                    
                                    if (numberOfPoint != 0) meanValueTemp = (int)(totalCount/(double)numberOfPoint);
                                    
                                    pixNo90 = arrayImageDataHistogramTemp [counter2*256+meanValueTemp];
                                    
                                    for (int counter3 = 1; counter3 < 256; counter3++){
                                        if (meanValueTemp-counter3 >= 0){
                                            pixNo90 = pixNo90+arrayImageDataHistogramTemp [counter2*256+meanValueTemp-counter3];
                                            lowestValueTemp = meanValueTemp-counter3;
                                        }
                                        
                                        if (meanValueTemp+counter3 <= 255){
                                            pixNo90 = pixNo90+arrayImageDataHistogramTemp [counter2*256+meanValueTemp+counter3];
                                            highestValueTemp = meanValueTemp+counter3;
                                        }
                                        
                                        if (pixNo90/(double)numberOfPoint > 0.8){
                                            break;
                                        }
                                    }
                                    
                                    arrayImageDataTempLMH [counter2*3] = lowestValueTemp;
                                    arrayImageDataTempLMH [counter2*3+1] = meanValueTemp;
                                    arrayImageDataTempLMH [counter2*3+2] = highestValueTemp;
                                }
                                
                                //-----G Histo set-----
                                for (int counter2 = 1; counter2 <= fovNumberCount; counter2++){
                                    for (int counter3 = 0; counter3 <= 255; counter3++) histogramTemp [counter3] = 0;
                                    
                                    for (int counter3 = 0; counter3 < autoImageSizeY; counter3++){
                                        for (int counter4 = 0; counter4 < autoImageSizeX; counter4++){
                                            if (arrayImageDataHoldTemp [(counter2-1)*autoImageSizeY+counter3][counter4*3+1] >= 0 && arrayImageDataHoldTemp [(counter2-1)*autoImageSizeY+counter3][counter4*3+1] <255){
                                                histogramTemp [arrayImageDataHoldTemp [(counter2-1)*autoImageSizeY+counter3][counter4*3+1]]++;
                                            }
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 <= 255; counter3++){
                                        arrayImageDataHistogramTempG [(counter2-1)*256+counter3] = histogramTemp [counter3];
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                                
                                for (int counter2 = 1; counter2 <= fovNumberCount; counter2++){
                                    for (int counter3 = 0; counter3 < 256; counter3++){
                                        histogramTemp [counter3] = histogramTemp [counter3]+arrayImageDataHistogramTempG [(counter2-1)*256+counter3];
                                    }
                                }
                                
                                for (int counter2 = 1; counter2 <= 255; counter2++) arrayImageDataHistogramTempG [fovNumberCount*256+counter2] = histogramTemp [counter2];
                                
                                for (int counter2 = 0; counter2 < fovNumberCount; counter2++){
                                    numberOfPoint = 0;
                                    totalCount = 0;
                                    lowestValueTemp = 0;
                                    highestValueTemp = 0;
                                    meanValueTemp = 0;
                                    
                                    for (int counter3 = 1; counter3 < 256; counter3++){
                                        numberOfPoint = numberOfPoint+arrayImageDataHistogramTempG [counter2*256+counter3];
                                        totalCount = totalCount+(unsigned long)(counter3*arrayImageDataHistogramTempG [counter2*256+counter3]);
                                    }
                                    
                                    if (numberOfPoint != 0) meanValueTemp = (int)(totalCount/(double)numberOfPoint);
                                    
                                    pixNo90 = arrayImageDataHistogramTempG [counter2*256+meanValueTemp];
                                    
                                    for (int counter3 = 1; counter3 < 256; counter3++){
                                        if (meanValueTemp-counter3 >= 0){
                                            pixNo90 = pixNo90+arrayImageDataHistogramTempG [counter2*256+meanValueTemp-counter3];
                                            lowestValueTemp = meanValueTemp-counter3;
                                        }
                                        
                                        if (meanValueTemp+counter3 <= 255){
                                            pixNo90 = pixNo90+arrayImageDataHistogramTempG [counter2*256+meanValueTemp+counter3];
                                            highestValueTemp = meanValueTemp+counter3;
                                        }
                                        
                                        if (pixNo90/(double)numberOfPoint > 0.8){
                                            break;
                                        }
                                    }
                                    
                                    arrayImageDataTempLMHG [counter2*3] = lowestValueTemp;
                                    arrayImageDataTempLMHG [counter2*3+1] = meanValueTemp;
                                    arrayImageDataTempLMHG [counter2*3+2] = highestValueTemp;
                                }
                                
                                //-----B Histo set-----
                                for (int counter2 = 1; counter2 <= fovNumberCount; counter2++){
                                    for (int counter3 = 0; counter3 <= 255; counter3++) histogramTemp [counter3] = 0;
                                    
                                    for (int counter3 = 0; counter3 < autoImageSizeY; counter3++){
                                        for (int counter4 = 0; counter4 < autoImageSizeX; counter4++){
                                            if (arrayImageDataHoldTemp [(counter2-1)*autoImageSizeY+counter3][counter4*3+2] >= 0 && arrayImageDataHoldTemp [(counter2-1)*autoImageSizeY+counter3][counter4*3+2] < 255){
                                                histogramTemp [arrayImageDataHoldTemp [(counter2-1)*autoImageSizeY+counter3][counter4*3+2]]++;
                                            }
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 <= 255; counter3++){
                                        arrayImageDataHistogramTempB [(counter2-1)*256+counter3] = histogramTemp [counter3];
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                                
                                for (int counter2 = 1; counter2 <= fovNumberCount; counter2++){
                                    for (int counter3 = 0; counter3 < 256; counter3++){
                                        histogramTemp [counter3] = histogramTemp [counter3]+arrayImageDataHistogramTempB [(counter2-1)*256+counter3];
                                    }
                                }
                                
                                for (int counter2 = 1; counter2 <= 255; counter2++) arrayImageDataHistogramTempB [fovNumberCount*256+counter2] = histogramTemp [counter2];
                                
                                for (int counter2 = 0; counter2 < fovNumberCount; counter2++){
                                    numberOfPoint = 0;
                                    totalCount = 0;
                                    lowestValueTemp = 0;
                                    highestValueTemp = 0;
                                    meanValueTemp = 0;
                                    
                                    for (int counter3 = 1; counter3 < 256; counter3++){
                                        numberOfPoint = numberOfPoint+arrayImageDataHistogramTempB [counter2*256+counter3];
                                        totalCount = totalCount+(unsigned long)(counter3*arrayImageDataHistogramTempB [counter2*256+counter3]);
                                    }
                                    
                                    if (numberOfPoint != 0) meanValueTemp = (int)(totalCount/(double)numberOfPoint);
                                    
                                    pixNo90 = arrayImageDataHistogramTempB [counter2*256+meanValueTemp];
                                    
                                    for (int counter3 = 1; counter3 < 256; counter3++){
                                        if (meanValueTemp-counter3 >= 0){
                                            pixNo90 = pixNo90+arrayImageDataHistogramTempB [counter2*256+meanValueTemp-counter3];
                                            lowestValueTemp = meanValueTemp-counter3;
                                        }
                                        
                                        if (meanValueTemp+counter3 <= 255){
                                            pixNo90 = pixNo90+arrayImageDataHistogramTempB [counter2*256+meanValueTemp+counter3];
                                            highestValueTemp = meanValueTemp+counter3;
                                        }
                                        
                                        if (pixNo90/(double)numberOfPoint > 0.8){
                                            break;
                                        }
                                    }
                                    
                                    arrayImageDataTempLMHB [counter2*3] = lowestValueTemp;
                                    arrayImageDataTempLMHB [counter2*3+1] = meanValueTemp;
                                    arrayImageDataTempLMHB [counter2*3+2] = highestValueTemp;
                                }
                            }
                            
                            //========Range process=======
                            /*===Processed data will be stored in arrayImageRangeAdjustTemp, and identical data will be stored in arrayImageCutoffAdjustTemp and arrayImageContrastAdjustTemp===*/
                            /*===For gray scale image, identical data will be saved in arrayBackgroundCorrectionData===*/
                            /*===Histo data and Contrast data will also be stored in a same manner===*/
                            
                            /* ImageDataHold >> ImageRangeAdjust*/
                            if (photoMetricAuto == 1){
                                int *valueFrequency = new int [256];
                                
                                totalPix = autoImageSizeX*autoImageSizeY;
                                
                                for (int counter2 = 0; counter2 < fovNumberCount; counter2++){
                                    if (processStatusTemp [counter2*2+1] != 0){
                                        for (int counter3 = 0; counter3 <= 255; counter3++) valueFrequency [counter3] = 0;
                                        valueAverage = 0;
                                        
                                        for (int counter3 = 0; counter3 < autoImageSizeY; counter3++){
                                            for (int counter4 = 0; counter4 < autoImageSizeX; counter4++){
                                                if (arrayImageDataHoldTemp [counter2*autoImageSizeY+counter3][counter4] >= 0 && arrayImageDataHoldTemp [counter2*autoImageSizeY+counter3][counter4] < 255){
                                                    valueAverage = valueAverage+arrayImageDataHoldTemp [counter2*autoImageSizeY+counter3][counter4];
                                                    valueFrequency [arrayImageDataHoldTemp [counter2*autoImageSizeY+counter3][counter4]]++;
                                                }
                                            }
                                        }
                                        
                                        valueAverage = (int)(valueAverage/(double)totalPix);
                                        pixNo90 = valueFrequency [valueAverage];
                                        lowestValueTemp = 0;
                                        highestValueTemp = 0;
                                        
                                        for (int counter3 = 1; counter3 <= 255; counter3++){
                                            if (valueAverage-counter3 >= 0){
                                                pixNo90 = pixNo90+valueFrequency [valueAverage-counter3];
                                                lowestValueTemp = valueAverage-counter3;
                                            }
                                            
                                            if (valueAverage+counter3 <= 255){
                                                pixNo90 = pixNo90+valueFrequency [valueAverage+counter3];
                                                highestValueTemp = valueAverage+counter3;
                                            }
                                            
                                            if (pixNo90/(double)totalPix > 0.8){
                                                break;
                                            }
                                        }
                                        
                                        expansionFactor1 = processStatusTemp [counter2*2+1]/(double)(highestValueTemp-lowestValueTemp);
                                        valueShift = 100-valueAverage;
                                        
                                        for (int counter3 = 0; counter3 < autoImageSizeY; counter3++){
                                            for (int counter4 = 0; counter4 < autoImageSizeX; counter4++){
                                                if (arrayImageDataHoldTemp [counter2*autoImageSizeY+counter3][counter4] >= 0){
                                                    newPixValue = arrayImageDataHoldTemp [counter2*autoImageSizeY+counter3][counter4]+valueShift;
                                                    
                                                    if (newPixValue < 100) newPixValue = newPixValue-(int)(abs(100-newPixValue)*expansionFactor1);
                                                    else newPixValue = newPixValue+(int)(abs(100-newPixValue)*expansionFactor1);
                                                    
                                                    if (newPixValue < 0) newPixValue = 0;
                                                    if (newPixValue > 255) newPixValue = 255;
                                                    
                                                    arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4] = newPixValue;
                                                }
                                                else arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4] = -1;
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 <= 255; counter3++) histogramTemp [counter3] = 0;
                                        
                                        for (int counter3 = 0; counter3 < autoImageSizeY; counter3++){
                                            for (int counter4 = 0; counter4 < autoImageSizeX; counter4++){
                                                if (arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4] >= 0){
                                                    arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4] = arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4];
                                                    arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4] = arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4];
                                                    arrayBackgroundCorrectionData [counter2*autoImageSizeY+counter3][counter4] = arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4];
                                                    histogramTemp [arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4]]++;
                                                }
                                                else{
                                                    
                                                    arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4] = -1;
                                                    arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4] = -1;
                                                    arrayBackgroundCorrectionData [counter2*autoImageSizeY+counter3][counter4] = -1;
                                                }
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < 256; counter3++){
                                            arrayImageRangeAdjustHistogramTemp [counter2*256+counter3] = histogramTemp [counter3];
                                            arrayImageCutoffAdjustHistogramTemp [counter2*256+counter3] = histogramTemp [counter3];
                                        }
                                    }
                                    else{
                                        
                                        for (int counter3 = 0; counter3 < autoImageSizeY; counter3++){
                                            for (int counter4 = 0; counter4 < autoImageSizeX; counter4++){
                                                if (arrayImageDataHoldTemp [counter2*autoImageSizeY+counter3][counter4] >= 0){
                                                    arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4] = arrayImageDataHoldTemp [counter2*autoImageSizeY+counter3][counter4];
                                                    arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4] = arrayImageDataHoldTemp [counter2*autoImageSizeY+counter3][counter4];
                                                    arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4] = arrayImageDataHoldTemp [counter2*autoImageSizeY+counter3][counter4];
                                                    arrayBackgroundCorrectionData [counter2*autoImageSizeY+counter3][counter4] = arrayImageDataHoldTemp [counter2*autoImageSizeY+counter3][counter4];
                                                }
                                                else{
                                                    
                                                    arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4] = -1;
                                                    arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4] = -1;
                                                    arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4] = -1;
                                                    arrayBackgroundCorrectionData [counter2*autoImageSizeY+counter3][counter4] = -1;
                                                }
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < 256; counter3++){
                                            arrayImageRangeAdjustHistogramTemp [counter2*256+counter3] = arrayImageDataHistogramTemp [counter2*256+counter3];
                                            arrayImageCutoffAdjustHistogramTemp [counter2*256+counter3] = arrayImageDataHistogramTemp [counter2*256+counter3];
                                        }
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 <= 255; counter2++) histogramTemp [counter2] = 0;
                                
                                for (int counter2 = 1; counter2 <= fovNumberCount; counter2++){
                                    for (int counter3 = 0; counter3 < 256; counter3++){
                                        histogramTemp [counter3] = histogramTemp [counter3]+arrayImageRangeAdjustHistogramTemp [(counter2-1)*256+counter3];
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < 256; counter3++){
                                    arrayImageRangeAdjustHistogramTemp [fovNumberCount*256+counter3] = histogramTemp [counter3];
                                    arrayImageCutoffAdjustHistogramTemp [fovNumberCount*256+counter3] = histogramTemp [counter3];
                                }
                                
                                for (int counter2 = 0; counter2 <= fovNumberCount; counter2++){
                                    numberOfPoint = 0;
                                    totalCount = 0;
                                    lowestValueTemp = 0;
                                    highestValueTemp = 0;
                                    meanValueTemp = 0;
                                    
                                    for (int counter3 = 1; counter3 <= 255; counter3++){
                                        numberOfPoint = numberOfPoint+arrayImageRangeAdjustHistogramTemp [counter2*256+counter3];
                                        totalCount = totalCount+(unsigned long)(counter3*arrayImageRangeAdjustHistogramTemp [counter2*256+counter3]);
                                    }
                                    
                                    if (numberOfPoint != 0) meanValueTemp = (int)(totalCount/(double)numberOfPoint);
                                    
                                    pixNo90 = arrayImageRangeAdjustHistogramTemp [counter2*256+meanValueTemp];
                                    
                                    for (int counter4 = 1; counter4 <= 255; counter4++){
                                        if (meanValueTemp-counter4 >= 0){
                                            pixNo90 = pixNo90+arrayImageRangeAdjustHistogramTemp [counter2*256+meanValueTemp-counter4];
                                            lowestValueTemp = meanValueTemp-counter4;
                                        }
                                        
                                        if (meanValueTemp+counter4 <= 255){
                                            pixNo90 = pixNo90+arrayImageRangeAdjustHistogramTemp [counter2*256+meanValueTemp+counter4];
                                            highestValueTemp = meanValueTemp+counter4;
                                        }
                                        
                                        if (pixNo90/(double)numberOfPoint > 0.8){
                                            break;
                                        }
                                    }
                                    
                                    arrayImageRangeAdjustTempLMH [counter2*3] = lowestValueTemp;
                                    arrayImageRangeAdjustTempLMH [counter2*3+1] = meanValueTemp;
                                    arrayImageRangeAdjustTempLMH [counter2*3+2] = highestValueTemp;
                                }
                                
                                delete [] valueFrequency;
                            }
                            else if (photoMetricAuto == 2){
                                for (int counter2 = 0; counter2 < fovNumberCount; counter2++){
                                    for (int counter3 = 0; counter3 < autoImageSizeY; counter3++){
                                        for (int counter4 = 0; counter4 < autoImageSizeX; counter4++){
                                            if (arrayImageDataHoldTemp [counter2*autoImageSizeY+counter3][counter4*3] >= 0){
                                                arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3] = arrayImageDataHoldTemp [counter2*autoImageSizeY+counter3][counter4*3];
                                                arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3] = arrayImageDataHoldTemp [counter2*autoImageSizeY+counter3][counter4*3];
                                                arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3] = arrayImageDataHoldTemp [counter2*autoImageSizeY+counter3][counter4*3];
                                            }
                                            else {
                                                
                                                arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3] = -1;
                                                arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3] = -1;
                                                arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3] = -1;
                                            }
                                            
                                            if (arrayImageDataHoldTemp [counter2*autoImageSizeY+counter3][counter4*3+1] >= 0){
                                                arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1] = arrayImageDataHoldTemp [counter2*autoImageSizeY+counter3][counter4*3+1];
                                                arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1] = arrayImageDataHoldTemp [counter2*autoImageSizeY+counter3][counter4*3+1];
                                                arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1] = arrayImageDataHoldTemp [counter2*autoImageSizeY+counter3][counter4*3+1];
                                            }
                                            else{
                                                
                                                arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1] = -1;
                                                arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1] = -1;
                                                arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1] = -1;
                                            }
                                            
                                            if (arrayImageDataHoldTemp [counter2*autoImageSizeY+counter3][counter4*3+2] >= 0){
                                                arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2] = arrayImageDataHoldTemp [counter2*autoImageSizeY+counter3][counter4*3+2];
                                                arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2] = arrayImageDataHoldTemp [counter2*autoImageSizeY+counter3][counter4*3+2];
                                                arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2] = arrayImageDataHoldTemp [counter2*autoImageSizeY+counter3][counter4*3+2];
                                            }
                                            else{
                                                
                                                arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2] = -1;
                                                arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2] = -1;
                                                arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2] = -1;
                                            }
                                        }
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 <= fovNumberCount; counter2++){
                                    arrayImageRangeAdjustTempLMH [counter2*3] = arrayImageDataTempLMH [counter2*3];
                                    arrayImageRangeAdjustTempLMH [counter2*3+1] = arrayImageDataTempLMH [counter2*3+1];
                                    arrayImageRangeAdjustTempLMH [counter2*3+2] = arrayImageDataTempLMH [counter2*3+2];
                                    
                                    arrayImageRangeAdjustTempLMHG [counter2*3] = arrayImageDataTempLMHG [counter2*3];
                                    arrayImageRangeAdjustTempLMHG [counter2*3+1] = arrayImageDataTempLMHG [counter2*3+1];
                                    arrayImageRangeAdjustTempLMHG [counter2*3+2] = arrayImageDataTempLMHG [counter2*3+2];
                                    
                                    arrayImageRangeAdjustTempLMHB [counter2*3] = arrayImageDataTempLMHB [counter2*3];
                                    arrayImageRangeAdjustTempLMHB [counter2*3+1] = arrayImageDataTempLMHB [counter2*3+1];
                                    arrayImageRangeAdjustTempLMHB [counter2*3+2] = arrayImageDataTempLMHB [counter2*3+2];
                                }
                            }
                            
                            //==========Cut Off Process=======
                            /*===ImageRangeAdjust >> ImageCutoffAdjust===*/
                            if (photoMetricAuto == 1){
                                for (int counter2 = 0; counter2 < fovNumberCount; counter2++){
                                    if (cutOffTemp [counter2*3] != arrayImageRangeAdjustTempLMH [counter2*3] || cutOffTemp [counter2*3+1] != arrayImageRangeAdjustTempLMH [counter2*3+1] || cutOffTemp [counter2*3+2] != arrayImageRangeAdjustTempLMH [counter2*3+2]){
                                        highestValueTemp = arrayImageRangeAdjustTempLMH [counter2*3+2]-cutOffTemp [counter2*3+1];
                                        
                                        if (arrayImageRangeAdjustTempLMH [counter2*3+2]-cutOffTemp [counter2*3+1] <= 0) highestValueTemp = 1;
                                        
                                        lowestValueTemp = cutOffTemp [counter2*3+1]-arrayImageRangeAdjustTempLMH [counter2*3];
                                        
                                        if (cutOffTemp [counter2*3+1]-arrayImageRangeAdjustTempLMH [counter2*3] <= 0) lowestValueTemp = 1;
                                        
                                        expansionFactor1 = (cutOffTemp [counter2*3+2]-cutOffTemp [counter2*3+1])/(double)highestValueTemp;
                                        expansionFactor2 = (cutOffTemp [counter2*3+1]-cutOffTemp [counter2*3])/(double)lowestValueTemp;
                                        
                                        for (int counter3 = 0; counter3 < autoImageSizeY; counter3++){
                                            for (int counter4 = 0; counter4 < autoImageSizeX; counter4++){
                                                if (arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4] >= 0){
                                                    if (arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4] > cutOffTemp [counter2*3+1] && expansionFactor1 != 1) newPixValue = cutOffTemp [counter2*3+1]+(int)((arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4]-cutOffTemp [counter2*3+1])*expansionFactor1);
                                                    else if (arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4] < cutOffTemp [counter2*3+1] && expansionFactor2 != 1) newPixValue = cutOffTemp [counter2*3+1]-(int)((cutOffTemp [counter2*3+1]-arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4])*expansionFactor2);
                                                    else newPixValue = arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4];
                                                    
                                                    if (newPixValue < 0) newPixValue = 0;
                                                    else if (newPixValue > 255) newPixValue = 255;
                                                    
                                                    arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4] = newPixValue;
                                                    arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4] = newPixValue;
                                                    arrayBackgroundCorrectionData [counter2*autoImageSizeY+counter3][counter4] = newPixValue;
                                                }
                                                
                                                else{
                                                    
                                                    arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4] = -1;
                                                    arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4] = -1;
                                                    arrayBackgroundCorrectionData [counter2*autoImageSizeY+counter3][counter4] = -1;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else if (photoMetricAuto == 2){
                                //-----R SET-----
                                for (int counter2 = 0; counter2 < fovNumberCount; counter2++){
                                    if (cutOffTemp [counter2*3] != arrayImageRangeAdjustTempLMH [counter2*3] || cutOffTemp [counter2*3+1] != arrayImageRangeAdjustTempLMH [counter2*3+1] || cutOffTemp [counter2*3+2] != arrayImageRangeAdjustTempLMH [counter2*3+2]){
                                        highestValueTemp = arrayImageRangeAdjustTempLMH [counter2*3+2]-cutOffTemp [counter2*3+1];
                                        
                                        if (arrayImageRangeAdjustTempLMH [counter2*3+2]-cutOffTemp [counter2*3+1] <= 0) highestValueTemp = 1;
                                        
                                        lowestValueTemp = cutOffTemp [counter2*3+1]-arrayImageRangeAdjustTempLMH [counter2*3];
                                        
                                        if (cutOffTemp [counter2*3+1]-arrayImageRangeAdjustTempLMH [counter2*3] <= 0) lowestValueTemp = 1;
                                        
                                        expansionFactor1 = (cutOffTemp [counter2*3+2]-cutOffTemp [counter2*3+1])/(double)highestValueTemp;
                                        expansionFactor2 = (cutOffTemp [counter2*3+1]-cutOffTemp [counter2*3])/(double)lowestValueTemp;
                                        
                                        for (int counter3 = 0; counter3 < autoImageSizeY; counter3++){
                                            for (int counter4 = 0; counter4 < autoImageSizeX; counter4++){
                                                if (arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3] >= 0){
                                                    if (arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3] > cutOffTemp [counter2*3+1] && expansionFactor1 != 1) newPixValue = cutOffTemp [counter2*3+1]+(int)((arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3]-cutOffTemp [counter2*3+1])*expansionFactor1);
                                                    else if (arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3] < cutOffTemp [counter2*3+1] && expansionFactor2 != 1) newPixValue = cutOffTemp [counter2*3+1]-(int)((cutOffTemp [counter2*3+1]-arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3])*expansionFactor2);
                                                    else newPixValue = arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3];
                                                    
                                                    if (newPixValue < 0) newPixValue = 0;
                                                    else if (newPixValue > 255) newPixValue = 255;
                                                    
                                                    arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3] = newPixValue;
                                                    arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3] = newPixValue;
                                                }
                                                else{
                                                    
                                                    arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3] = -1;
                                                    arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3] = -1;
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                //-----G SET-----
                                for (int counter2 = 0; counter2 < fovNumberCount; counter2++){
                                    if (cutOffTempG [counter2*3] != arrayImageRangeAdjustTempLMHG [counter2*3] || cutOffTempG [counter2*3+1] != arrayImageRangeAdjustTempLMHG [counter2*3+1] || cutOffTempG [counter2*3+2] != arrayImageRangeAdjustTempLMHG [counter2*3+2]){
                                        highestValueTemp = arrayImageRangeAdjustTempLMHG [counter2*3+2]-cutOffTempG [counter2*3+1];
                                        
                                        if (arrayImageRangeAdjustTempLMHG [counter2*3+2]-cutOffTempG [counter2*3+1] <= 0) highestValueTemp = 1;
                                        
                                        lowestValueTemp = cutOffTempG [counter2*3+1]-arrayImageRangeAdjustTempLMHG [counter2*3];
                                        
                                        if (cutOffTempG [counter2*3+1]-arrayImageRangeAdjustTempLMHG [counter2*3] <= 0) lowestValueTemp = 1;
                                        
                                        expansionFactor1 = (cutOffTempG [counter2*3+2]-cutOffTempG [counter2*3+1])/(double)highestValueTemp;
                                        expansionFactor2 = (cutOffTempG [counter2*3+1]-cutOffTempG [counter2*3])/(double)lowestValueTemp;
                                        
                                        for (int counter3 = 0; counter3 < autoImageSizeY; counter3++){
                                            for (int counter4 = 0; counter4 < autoImageSizeX; counter4++){
                                                if (arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1] >= 0){
                                                    if (arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1] > cutOffTempG [counter2*3+1] && expansionFactor1 != 1) newPixValue = cutOffTempG [counter2*3+1]+(int)((arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1]-cutOffTempG [counter2*3+1])*expansionFactor1);
                                                    else if (arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1] < cutOffTempG [counter2*3+1] && expansionFactor2 != 1) newPixValue = cutOffTempG [counter2*3+1]-(int)((cutOffTempG [counter2*3+1]-arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1])*expansionFactor2);
                                                    else newPixValue = arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1];
                                                    
                                                    if (newPixValue < 0) newPixValue = 0;
                                                    else if (newPixValue > 255) newPixValue = 255;
                                                    
                                                    arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1] = newPixValue;
                                                    arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1] = newPixValue;
                                                }
                                                else{
                                                    
                                                    arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1] = -1;
                                                    arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1] = -1;
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                //-----B SET-----
                                for (int counter2 = 0; counter2 < fovNumberCount; counter2++){
                                    if (cutOffTempB [counter2*3] != arrayImageRangeAdjustTempLMHB [counter2*3] || cutOffTempB [counter2*3+1] != arrayImageRangeAdjustTempLMHB [counter2*3+1] || cutOffTempB [counter2*3+2] != arrayImageRangeAdjustTempLMHB [counter2*3+2]){
                                        highestValueTemp = arrayImageRangeAdjustTempLMHB [counter2*3+2]-cutOffTempB [counter2*3+1];
                                        
                                        if (arrayImageRangeAdjustTempLMHB [counter2*3+2]-cutOffTempB [counter2*3+1] <= 0) highestValueTemp = 1;
                                        
                                        lowestValueTemp = cutOffTempB [counter2*3+1]-arrayImageRangeAdjustTempLMHB [counter2*3];
                                        
                                        if (cutOffTempB [counter2*3+1]-arrayImageRangeAdjustTempLMHB [counter2*3] <= 0) lowestValueTemp = 1;
                                        
                                        expansionFactor1 = (cutOffTempB [counter2*3+2]-cutOffTempB [counter2*3+1])/(double)highestValueTemp;
                                        expansionFactor2 = (cutOffTempB [counter2*3+1]-cutOffTempB [counter2*3])/(double)lowestValueTemp;
                                        
                                        for (int counter3 = 0; counter3 < autoImageSizeY; counter3++){
                                            for (int counter4 = 0; counter4 < autoImageSizeX; counter4++){
                                                if (arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2] >= 0){
                                                    if (arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2] > cutOffTempB [counter2*3+1] && expansionFactor1 != 1) newPixValue = cutOffTempB [counter2*3+1]+(int)((arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2]-cutOffTempB [counter2*3+1])*expansionFactor1);
                                                    else if (arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2] < cutOffTempB [counter2*3+1] && expansionFactor2 != 1) newPixValue = cutOffTempB [counter2*3+1]-(int)((cutOffTempB [counter2*3+1]-arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2])*expansionFactor2);
                                                    else newPixValue = arrayImageRangeAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2];
                                                    
                                                    if (newPixValue < 0) newPixValue = 0;
                                                    else if (newPixValue > 255) newPixValue = 255;
                                                    
                                                    arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2] = newPixValue;
                                                    arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2] = newPixValue;
                                                }
                                                else{
                                                    
                                                    arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2] = -1;
                                                    arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2] = -1;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            
                            //=========Contrast Set============
                            /*===ImageCutoffAdjust >> ImageContrastAdjust===*/
                            if (photoMetricAuto == 1){
                                for (int counter2 = 0; counter2 < fovNumberCount; counter2++){
                                    if (contrastTemp [counter2] != 0){
                                        for (int counter3 = 0; counter3 < autoImageSizeY; counter3++){
                                            for (int counter4 = 0; counter4 < autoImageSizeX; counter4++){
                                                if (arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4] >= 0){
                                                    if (arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4]-cutOffTemp [counter2*3+1] < 0 && arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4] >= 0){
                                                        newPixValue = arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4]-(int)((cutOffTemp [counter2*3+1]-arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4])*contrastTemp [counter2]);
                                                    }
                                                    else if (arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4]-cutOffTemp [counter2*3+1] > 0 && arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4] <= 255){
                                                        newPixValue = arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4]+(int)((arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4]-cutOffTemp [counter2*3+1])*contrastTemp [counter2]);
                                                    }
                                                    
                                                    else newPixValue = arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4];
                                                    
                                                    if (newPixValue < 0) newPixValue = 0;
                                                    else if (newPixValue > 255) newPixValue = 255;
                                                    
                                                    arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4] = newPixValue;
                                                    arrayBackgroundCorrectionData [counter2*autoImageSizeY+counter3][counter4] = newPixValue;
                                                }
                                                else{
                                                    
                                                    arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4] = -1;
                                                    arrayBackgroundCorrectionData [counter2*autoImageSizeY+counter3][counter4] = -1;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else if (photoMetricAuto == 2){
                                for (int counter2 = 0; counter2 < fovNumberCount; counter2++){
                                    if (contrastTemp [counter2] != 0){
                                        for (int counter3 = 0; counter3 < autoImageSizeY; counter3++){
                                            for (int counter4 = 0; counter4 < autoImageSizeX; counter4++){
                                                if (arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3] >= 0){
                                                    if (arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3]-cutOffTemp [counter2*3+1] < 0 && arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3] >= 0){
                                                        newPixValue = arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3]-(int)((cutOffTemp [counter2*3+1]-arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3])*contrastTemp [counter2]);
                                                    }
                                                    else if (arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3]-cutOffTemp [counter2*3+1] > 0 && arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3] <= 255){
                                                        newPixValue = arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3]+(int)((arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3]-cutOffTemp [counter2*3+1])*contrastTemp [counter2]);
                                                    }
                                                    
                                                    else newPixValue = arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3];
                                                    
                                                    if (newPixValue < 0) newPixValue = 0;
                                                    else if (newPixValue > 255) newPixValue = 255;
                                                    
                                                    arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3] = newPixValue;
                                                }
                                                else arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3] = -1;
                                            }
                                        }
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < fovNumberCount; counter2++){
                                    if (contrastTemp [counter2] != 0){
                                        for (int counter3 = 0; counter3 < autoImageSizeY; counter3++){
                                            for (int counter4 = 0; counter4 < autoImageSizeX; counter4++){
                                                if (arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1] >= 0){
                                                    if (arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1]-cutOffTempG [counter2*3+1] < 0 && arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1] >= 0){
                                                        newPixValue = arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1]-(int)((cutOffTempG [counter2*3+1]-arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1])*contrastTempG [counter2]);
                                                    }
                                                    else if (arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1]-cutOffTempG [counter2*3+1] > 0 && arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1] <= 255){
                                                        newPixValue = arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1]+(int)((arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1]-cutOffTempG [counter2*3+1])*contrastTempG [counter2]);
                                                    }
                                                    
                                                    else newPixValue = arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1];
                                                    
                                                    if (newPixValue < 0) newPixValue = 0;
                                                    else if (newPixValue > 255) newPixValue = 255;
                                                    
                                                    arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1] = newPixValue;
                                                }
                                                else arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1] = -1;
                                            }
                                        }
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < fovNumberCount; counter2++){
                                    if (contrastTemp [counter2] != 0){
                                        for (int counter3 = 0; counter3 < autoImageSizeY; counter3++){
                                            for (int counter4 = 0; counter4 < autoImageSizeX; counter4++){
                                                if (arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2] >= 0){
                                                    if (arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2]-cutOffTempB [counter2*3+1] < 0 && arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2] >= 0){
                                                        newPixValue = arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2]-(int)((cutOffTempB [counter2*3+1]-arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2])*contrastTempB [counter2]);
                                                    }
                                                    else if (arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2]-cutOffTempB [counter2*3+1] > 0 && arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2] <= 255){
                                                        newPixValue = arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2]+(int)((arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2]-cutOffTempB [counter2*3+1])*contrastTempB [counter2]);
                                                    }
                                                    
                                                    else newPixValue = arrayImageCutoffAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2];
                                                    
                                                    if (newPixValue < 0) newPixValue = 0;
                                                    else if (newPixValue > 255) newPixValue = 255;
                                                    
                                                    arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2] = newPixValue;
                                                }
                                                else arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2] = -1;
                                            }
                                        }
                                    }
                                }
                            }
                            
                            //========Balance Correction=============
                            /*===For Gray scale image, ImageContrastAdjust >> BackgroundCorrectionData===*/
                            if (photoMetricAuto == 1){
                                rangeLimitHorizontal = 0;
                                rangeLimitVertical = 0;
                                
                                if ((int)balanceExtract.find("^") != -1){
                                    rangeLimitBase = atof(balanceExtract.substr(0, balanceExtract.find("^")).c_str());
                                    rangeLimitHorizontal = atof(balanceExtract.substr(balanceExtract.find("^")+1, balanceExtract.find("%")-balanceExtract.find("^")-1).c_str());
                                    rangeLimitVertical = atof(balanceExtract.substr(balanceExtract.find("%")+1).c_str());
                                }
                                else rangeLimitBase = atof(balanceExtract.c_str());
                                
                                if (rangeLimitBase != 0 || rangeLimitHorizontal != 0 || rangeLimitVertical != 0){
                                    if (processMode == 5 || processMode == 13 || processMode == 7) fin.open(fovPositionTempPath.c_str(), ios::in);
                                    else fin.open(fovPositionPath.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        fin.close();
                                        
                                        self->balanceSet = [[BalanceSet alloc] init];
                                        [self->balanceSet balanceSetAuto:fovNumberCount];
                                        
                                        for (int counter2 = 0; counter2 < fovNumberCount; counter2++){
                                            for (int counter3 = 0; counter3 < autoImageSizeY; counter3++){
                                                for (int counter4 = 0; counter4 < autoImageSizeX; counter4++){
                                                    if (arrayBackgroundCorrectionData [counter2*autoImageSizeY+counter3][counter4]/(double)correctionValues [counter2+1] > 255){
                                                        arrayBackgroundCorrectionData [counter2*autoImageSizeY+counter3][counter4] = 255;
                                                    }
                                                    else if (arrayBackgroundCorrectionData [counter2*autoImageSizeY+counter3][counter4]/(double)correctionValues [counter2+1] < 0){
                                                        arrayBackgroundCorrectionData [counter2*autoImageSizeY+counter3][counter4] = 0;
                                                    }
                                                    else arrayBackgroundCorrectionData [counter2*autoImageSizeY+counter3][counter4] = (int)(arrayBackgroundCorrectionData [counter2*autoImageSizeY+counter3][counter4]/(double)correctionValues [counter2+1]);
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                //=========Background correction=========
                                if (autoImageSizeY > 0){
                                    if (backgroundPatternFirstSet == 0){
                                        xDimensionString = to_string(autoImageSizeX);
                                        yDimensionString = to_string(autoImageSizeY);
                                        
                                        numberOfBlock = (autoImageSizeX/8)*(autoImageSizeY/8)*250;
                                        
                                        backgroundPatternArrayStatus = 1;
                                        
                                        backgroundPatternArray = new int [numberOfBlock+50];
                                        backgroundPatternArrayCount = 0;
                                        
                                        backgroundPatternModifyArray = new int [numberOfBlock+50];
                                        backgroundPatternModifyArrayCount = 0;
                                        
                                        backgroundPatternName = new string [260];
                                        
                                        patternPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/BKPattern"+"-"+xDimensionString+"&"+yDimensionString+".dat";
                                        
                                        fin.open(patternPath.c_str(), ios::in);
                                        
                                        if (fin.is_open()){
                                            do{
                                                
                                                getline(fin, getString);
                                                
                                                if (getString != "") backgroundPatternArray [backgroundPatternArrayCount] = atoi(getString.c_str()), backgroundPatternArrayCount++;
                                                
                                            } while (getString != "");
                                            
                                            fin.close();
                                            
                                            backgroundPatternFirstSet = 1;
                                            
                                            patternPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/BKPatternModify"+"-"+xDimensionString+"&"+yDimensionString+".dat";
                                            
                                            fin.open(patternPath.c_str(), ios::in);
                                            
                                            if (fin.is_open()){
                                                do{
                                                    
                                                    getline(fin, getString);
                                                    
                                                    if (getString != "") backgroundPatternModifyArray [backgroundPatternModifyArrayCount] = atoi(getString.c_str()), backgroundPatternModifyArrayCount++;
                                                    
                                                } while (getString != "");
                                                
                                                fin.close();
                                            }
                                            
                                            patternPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/BKPatternName"+"-"+xDimensionString+"&"+yDimensionString+".dat";
                                            
                                            backgroundPatternNameCount = 0;
                                            
                                            for (int counter2 = 0; counter2 < 250; counter2++) backgroundPatternName [counter2] = "nil";
                                            
                                            fin.open(patternPath.c_str(), ios::in);
                                            
                                            if (fin.is_open()){
                                                do{
                                                    
                                                    getline(fin, getString);
                                                    
                                                    if (getString != "") backgroundPatternName [backgroundPatternNameCount] = getString, backgroundPatternNameCount++;
                                                    
                                                } while (getString != "");
                                                
                                                fin.close();
                                            }
                                        }
                                        else{
                                            
                                            backgroundPatternArrayCount = 0;
                                            backgroundPatternModifyArrayCount = 0;
                                        }
                                    }
                                    
                                    self->backgroundCorrection = [[BackgroundCorrection alloc] init];
                                    [self->backgroundCorrection backgroundImageSub:bcType:fovNumberCount:autoImageSizeX:autoImageSizeY];
                                }
                            }
                            
                            delete [] histogramTemp;
                            
                            //-----Stitch image set-----
                            arrayImageFileSave = new int *[stitchedImageAuto+1];
                            
                            for (int counter3 = 0; counter3 < stitchedImageAuto+1; counter3++){
                                arrayImageFileSave [counter3] = new int [stitchedImageAuto*3+1];
                            }
                            
                            if (channelString == ""){
                                if (photoMetricAuto == 1){
                                    for (int counter2 = 0; counter2 < stitchedImageAuto; counter2++){
                                        for (int counter3 = 0; counter3 < stitchedImageAuto; counter3++) arrayImageFileSave [counter2][counter3] = 100;
                                    }
                                }
                                else if (photoMetricAuto == 2){
                                    for (int counter2 = 0; counter2 < stitchedImageAuto; counter2++){
                                        for (int counter3 = 0; counter3 < stitchedImageAuto; counter3++){
                                            arrayImageFileSave [counter2][counter3*3] = 0;
                                            arrayImageFileSave [counter2][counter3*3+1] = 0;
                                            arrayImageFileSave [counter2][counter3*3+2] = 0;
                                        }
                                    }
                                }
                            }
                            else{
                                
                                for (int counter2 = 0; counter2 < stitchedImageAuto; counter2++){
                                    for (int counter3 = 0; counter3 < stitchedImageAuto; counter3++) arrayImageFileSave [counter2][counter3] = 0;
                                }
                            }
                            
                            if (photoMetricAuto == 1){
                                for (int counter2 = 0; counter2 < fovNumberCount; counter2++){
                                    for (int counter3 = 0; counter3 < autoImageSizeY; counter3++){
                                        for (int counter4 = 0; counter4 < autoImageSizeX; counter4++){
                                            if (counter3+fovPositionHoldTemp [counter2*2+1] >= 0 && counter3+fovPositionHoldTemp [counter2*2+1] < stitchedImageAuto && counter4+fovPositionHoldTemp [counter2*2] >= 0 && counter4+fovPositionHoldTemp [counter2*2] < stitchedImageAuto){
                                                if (channelString == "" && arrayBackgroundCorrectionData [counter2*autoImageSizeY+counter3][counter4] >= 95 && arrayBackgroundCorrectionData [counter2*autoImageSizeY+counter3][counter4] < 105){
                                                    arrayImageFileSave [counter3+fovPositionHoldTemp [counter2*2+1]][counter4+fovPositionHoldTemp [counter2*2]] = 100;
                                                }
                                                else if (channelString != "" && arrayBackgroundCorrectionData [counter2*autoImageSizeY+counter3][counter4] == 0){
                                                    arrayImageFileSave [counter3+fovPositionHoldTemp [counter2*2+1]][counter4+fovPositionHoldTemp [counter2*2]] = 1;
                                                }
                                                else if (channelString != "" && arrayBackgroundCorrectionData [counter2*autoImageSizeY+counter3][counter4] <= 0){
                                                    arrayImageFileSave [counter3+fovPositionHoldTemp [counter2*2+1]][counter4+fovPositionHoldTemp [counter2*2]] = 0;
                                                }
                                                else{
                                                    
                                                    arrayImageFileSave [counter3+fovPositionHoldTemp [counter2*2+1]][counter4+fovPositionHoldTemp [counter2*2]] = arrayBackgroundCorrectionData [counter2*autoImageSizeY+counter3][counter4];
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else{
                                
                                for (int counter2 = 0; counter2 < fovNumberCount; counter2++){
                                    for (int counter3 = 0; counter3 < autoImageSizeY; counter3++){
                                        for (int counter4 = 0; counter4 < autoImageSizeX; counter4++){
                                            if (counter3+fovPositionHoldTemp [counter2*2+1] >= 0 && counter3+fovPositionHoldTemp [counter2*2+1] < stitchedImageAuto && counter4+fovPositionHoldTemp [counter2*2] >= 0 && counter4+fovPositionHoldTemp [counter2*2] < stitchedImageAuto){
                                                if (arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3] >= 0 || arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1] >= 0 || arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2] >= 0){
                                                    arrayImageFileSave [counter3+fovPositionHoldTemp [counter2*2+1]][(counter4+fovPositionHoldTemp [counter2*2])*3] = arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3];
                                                    arrayImageFileSave [counter3+fovPositionHoldTemp [counter2*2+1]][(counter4+fovPositionHoldTemp [counter2*2])*3+1] = arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+1];
                                                    arrayImageFileSave [counter3+fovPositionHoldTemp [counter2*2+1]][(counter4+fovPositionHoldTemp [counter2*2])*3+2] = arrayImageContrastAdjustTemp [counter2*autoImageSizeY+counter3][counter4*3+2];
                                                }
                                                else{
                                                    
                                                    arrayImageFileSave [counter3+fovPositionHoldTemp [counter2*2+1]][(counter4+fovPositionHoldTemp [counter2*2])*3] = 0;
                                                    arrayImageFileSave [counter3+fovPositionHoldTemp [counter2*2+1]][(counter4+fovPositionHoldTemp [counter2*2])*3+1] = 0;
                                                    arrayImageFileSave [counter3+fovPositionHoldTemp [counter2*2+1]][(counter4+fovPositionHoldTemp [counter2*2])*3+2] = 0;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            
                            //-----Image save-----
                            if (channelString == ""){
                                if (autoType == 1 || autoType == 3) fileSavePathHold = productsStitchTempPath+"/"+treatString+"_Stitch/"+"STimage "+timeString+fileExtension;
                                else if (batchImageBodyName == "nil"){
                                    fileSavePathHold = stitchedFolderPath+"/"+treatString+"_Stitch/"+"STimage "+timeString+fileExtension;
                                }
                                else fileSavePathHold = stitchedFolderImagePath+"/"+treatString+"_Stitch/"+"STimage "+timeString+fileExtension;
                            }
                            else{
                                
                                if (autoType == 1 || autoType == 3){
                                    fileSavePathHold = productsStitchTempPath+"/"+treatString+"_Stitch/"+"STimage "+timeString+"_"+colorNameNo+"_"+colorName+fileExtension;
                                }
                                else if (batchImageBodyName == "nil"){
                                    fileSavePathHold = stitchedFolderPath+"/"+treatString+"_Stitch/"+"STimage "+timeString+"_"+colorNameNo+"_"+colorName+fileExtension;
                                }
                                else fileSavePathHold = stitchedFolderImagePath+"/"+treatString+"_Stitch/"+"STimage "+timeString+"_"+colorNameNo+"_"+colorName+fileExtension;
                            }
                            
                            mode = 0;
                            
                            if (xPosition == -1) xPosition = 100;
                            if (yPosition == -1) yPosition = 100;
                            
                            self->singleTiffSave = [[SingleTiffSave alloc] init];
                            [self->singleTiffSave singleTiffLayerSave:stitchedImageAuto:stitchedImageAuto:imageBit:photoMetricAuto:samplePerPix:xPosition:yPosition:mode:ifDPreviousHold];
                            
                            for (int counter3 = 0; counter3 < stitchedImageAuto+1; counter3++){
                                delete [] arrayImageFileSave [counter3];
                            }
                            
                            delete [] arrayImageFileSave;
                            
                            for (int counter2 = 0; counter2 < autoImageSizeY*fovNumberCount+2; counter2++){
                                delete [] arrayImageDataHoldTemp [counter2];
                                delete [] arrayImageRangeAdjustTemp [counter2];
                                delete [] arrayImageCutoffAdjustTemp [counter2];
                                delete [] arrayImageContrastAdjustTemp [counter2];
                                delete [] arrayBackgroundCorrectionData [counter2];
                            }
                            
                            delete [] arrayImageDataHoldTemp;
                            delete [] arrayImageRangeAdjustTemp;
                            delete [] arrayImageCutoffAdjustTemp;
                            delete [] arrayImageContrastAdjustTemp;
                            delete [] arrayBackgroundCorrectionData;
                            
                            processDone = 1;
                            timePointDisplayCall = 1;
                        }
                        
                        delete [] cutOffTemp;
                        delete [] cutOffTempG;
                        delete [] cutOffTempB;
                        
                        delete [] contrastTemp;
                        delete [] contrastTempG;
                        delete [] contrastTempB;
                        delete [] processStatusTemp;
                        
                        delete [] arrayImageDataHistogramTemp;
                        delete [] arrayImageDataHistogramTempG;
                        delete [] arrayImageDataHistogramTempB;
                        delete [] arrayImageRangeAdjustHistogramTemp;
                        delete [] arrayImageCutoffAdjustHistogramTemp;
                        
                        delete [] arrayImageDataTempLMH;
                        delete [] arrayImageDataTempLMHG;
                        delete [] arrayImageDataTempLMHB;
                        delete [] arrayImageRangeAdjustTempLMH;
                        delete [] arrayImageRangeAdjustTempLMHG;
                        delete [] arrayImageRangeAdjustTempLMHB;
                        
                        delete [] fovPositionHoldTemp;
                        delete [] correctionValues;
                    }
                }
            }
        }
        
        if (processDone == 1){
            stringstream extension1;
            extension1 << currentTimePoint+1;
            extension = extension1.str();
        }
        
        if (processDone == 1 && (autoType == 1 || autoType == 3)){
            currentTimePoint++;
            
            if (processMode != 5 && processMode != 13 && processMode != 7){
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            
            timePointRequest = 1;
        }
        
        remove (instructionCSPath.c_str());
        
        if ((processMode == 5 || processMode == 13 || processMode == 7 || processMode == 3 || processMode == 9 || processMode == 11 || processMode == 2 || processMode == 8 || processMode == 10) && processDone == 1){
            ofstream oin;
            
            for (int counter1 = 0; counter1 < 10; counter1++){
                oin.open(instructionAPPath.c_str(), ios::out);
                
                if (oin.is_open()){
                    oin<<"Done"<<endl;
                    oin.close();
                    
                    remove(loadingCompletePath.c_str());
                    break;
                }
            }
        }
        
        progressTiming = 5;
        
        do usleep(10);
        while (progressTiming == 5);
        
        progressTiming = 7;
        
        if (autoType == 2 || autoType == 3){
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        
        if ((processMode == 5 || processMode == 13 || processMode == 7 || processMode == 3 || processMode == 9 || processMode == 11 || processMode == 2 || processMode == 8 || processMode == 10) && processDone == 1){
            imageProcessTiming = 1;
        }
        
        if (processMode == 4 || processMode == 6 || processMode == 12) reprocessStartFlag = 4;
        
        autoProcessingFlag = 0;
    });
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToAutocontrast object:nil];
}

@end
