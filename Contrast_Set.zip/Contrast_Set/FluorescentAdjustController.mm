//
//  FluorescentAdjustController.m
//  Contrast_Set
//
//  Created by Masahiko Sato on 2014-06-01.
//
//

#import "FluorescentAdjustController.h"

NSString *notificationToAdjustController = @"notificationExecuteAdjustController";

@implementation FluorescentAdjustController

-(id)init{
    self = [super init];
    
    if (self != nil){
        sliderFluorescentMax = 20;
        sliderFluorescentMin = 0.01;
        sliderFluorescentDiff = 19.99;
        sliderBaseMax = 255;
        sliderBaseMin = 0;
        sliderBaseDiff = 255;
        sliderDICLevelMax = 255;
        sliderDICLevelMin = 0;
        sliderDICLevelDiff = 255;
        sliderDICContMax = 20;
        sliderDICContMin = 0.01;
        sliderDICContDiff = 19.99;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToAdjustController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    adjustWindController = [[NSWindowController alloc] initWithWindowNibName:@"FluorescentWindow"];
    [adjustWindController showWindow:self];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentAdjust object:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [adjustWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [adjustWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    int baseCutInt = (int)(baseCut*1000);
    double baseCutDouble = baseCutInt/(double)1000;
    int fluorescentEnhanceInt = (int)(fluorescentEnhance*1000);
    double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
    
    int dicLevelHoldInt = (int)(dicLevelHold*1000);
    double dicLevelHoldDouble = dicLevelHoldInt/(double)1000;
    int dicContrastHoldInt = (int)(dicContrastHold*1000);
    double dicContrastHoldDouble = dicContrastHoldInt/(double)1000;
    
    [baseCutValueDisplay setDoubleValue:baseCutDouble];
    [fluorescentValueDisplay setDoubleValue:fluorescentEnhanceDouble];
    
    [dicLevelValueDisplay setDoubleValue:dicLevelHoldDouble];
    [dicContrastValueDisplay setDoubleValue:dicContrastHoldDouble];
    
    [channelValueX1 setIntegerValue:channelAdjustHoldX1];
    [channelValueX2 setIntegerValue:channelAdjustHoldX2];
    [channelValueX3 setIntegerValue:channelAdjustHoldX3];
    [channelValueX4 setIntegerValue:channelAdjustHoldX4];
    [channelValueX5 setIntegerValue:channelAdjustHoldX5];
    [channelValueX6 setIntegerValue:channelAdjustHoldX6];
    [channelValueY1 setIntegerValue:channelAdjustHoldY1];
    [channelValueY2 setIntegerValue:channelAdjustHoldY2];
    [channelValueY3 setIntegerValue:channelAdjustHoldY3];
    [channelValueY4 setIntegerValue:channelAdjustHoldY4];
    [channelValueY5 setIntegerValue:channelAdjustHoldY5];
    [channelValueY6 setIntegerValue:channelAdjustHoldY6];
    
    [sliderFluorescent setDoubleValue:1];
    [sliderBase setDoubleValue:50];
    [sliderFluorescentCircle setDoubleValue:1];
    [sliderBaseCircle setDoubleValue:1];
    [sliderDICLevel setDoubleValue:50];
    [sliderDICCont setDoubleValue:1];
    [sliderDICLevelCircle setDoubleValue:1];
    [sliderDICContCircle setDoubleValue:1];
    
    adjustTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
}

-(void)display{
    if (progressTimingB == 1){
        [backSave startAnimation:self];
        
        if (backSave) progressTimingB = 0;
    }
    else if (progressTimingB == 2){
        [backSave stopAnimation:self];
        
        if (backSave) progressTimingB = 0;
    }
}

-(IBAction)savePosition:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (positionAdjustFlag == 1){
                for (int counter1 = 0; counter1 < loadImageFOVNo; counter1++){
                    arrayXYWritingPosition [(counter1+1)*2] = arrayXYWritingPosition [(counter1+1)*2]-xMovePositionHoldMain;
                    arrayXYWritingPosition [(counter1+1)*2+1] = arrayXYWritingPosition [(counter1+1)*2+1]+yMovePositionHoldMain;
                }
                
                string treatString = loadImageTreatName.substr(0, loadImageTreatName.length()-3);
                string channelString = loadImageTreatName.substr(loadImageTreatName.length()-1, 1);
                
                if (channelString == "1" && channelAdjustFirstSet1 == 0){
                    channelAdjustHoldX1 = arrayXYWritingPositionBase [0]-arrayXYWritingPosition [2];
                    channelAdjustHoldY1 = arrayXYWritingPosition [3]-arrayXYWritingPositionBase [1];
                    channelAdjustFirstSet1 = 1;
                    
                    [channelValueX1 setIntegerValue:channelAdjustHoldX1];
                    [channelValueY1 setIntegerValue:channelAdjustHoldY1];
                }
                else if (channelString == "2" && channelAdjustFirstSet2 == 0){
                    channelAdjustHoldX2 = arrayXYWritingPositionBase [0]-arrayXYWritingPosition [2];
                    channelAdjustHoldY2 = arrayXYWritingPosition [3]-arrayXYWritingPositionBase [1];
                    channelAdjustFirstSet2 = 1;
                    
                    [channelValueX2 setIntegerValue:channelAdjustHoldX2];
                    [channelValueY2 setIntegerValue:channelAdjustHoldY2];
                }
                else if (channelString == "3" && channelAdjustFirstSet3 == 0){
                    channelAdjustHoldX3 = arrayXYWritingPositionBase [0]-arrayXYWritingPosition [2];
                    channelAdjustHoldY3 = arrayXYWritingPosition [3]-arrayXYWritingPositionBase [1];
                    channelAdjustFirstSet3 = 1;
                    
                    [channelValueX3 setIntegerValue:channelAdjustHoldX3];
                    [channelValueY3 setIntegerValue:channelAdjustHoldY3];
                }
                else if (channelString == "4" && channelAdjustFirstSet4 == 0){
                    channelAdjustHoldX4 = arrayXYWritingPositionBase [0]-arrayXYWritingPosition [2];
                    channelAdjustHoldY4 = arrayXYWritingPosition [3]-arrayXYWritingPositionBase [1];
                    channelAdjustFirstSet4 = 1;
                    
                    [channelValueX4 setIntegerValue:channelAdjustHoldX4];
                    [channelValueY4 setIntegerValue:channelAdjustHoldY4];
                }
                else if (channelString == "5" && channelAdjustFirstSet5 == 0){
                    channelAdjustHoldX5 = arrayXYWritingPositionBase [0]-arrayXYWritingPosition [2];
                    channelAdjustHoldY5 = arrayXYWritingPosition [3]-arrayXYWritingPositionBase [1];
                    channelAdjustFirstSet5 = 1;
                    
                    [channelValueX5 setIntegerValue:channelAdjustHoldX5];
                    [channelValueY5 setIntegerValue:channelAdjustHoldY5];
                }
                else if (channelString == "6" && channelAdjustFirstSet6 == 0){
                    channelAdjustHoldX6 = arrayXYWritingPositionBase [0]-arrayXYWritingPosition [2];
                    channelAdjustHoldY6 = arrayXYWritingPosition [3]-arrayXYWritingPositionBase [1];
                    channelAdjustFirstSet6 = 1;
                    
                    [channelValueX6 setIntegerValue:channelAdjustHoldX6];
                    [channelValueY6 setIntegerValue:channelAdjustHoldY6];
                }
                
                setData = [[SetData alloc] init];
                [setData setDataMain];
                
                int processType = 3;
                imageDataSet = [[ImageDataSet alloc] init];
                [imageDataSet imageDataSetProcess:processType];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)moveStatusSet:(id)sender{
    if (loadImageTreatName != ""){
        if (positionAdjustFlag == 1){
            if (imageMoveStatus == 1){
                imageMoveStatus = 0;
                [moveStatusDisplay setStringValue:@"Both"];
            }
            else if (imageMoveStatus == 0){
                imageMoveStatus = 1;
                [moveStatusDisplay setStringValue:@"Fluo"];
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Fluorescent Mode Off"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageLoad:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            string extractString = loadImageTreatName.substr(loadImageTreatName.length()-3, 2);
            
            if (extractString == "CH"){
                if (positionAdjustFlag == 0){
                    positionAdjustFlag = 1;
                    
                    string treatString = loadImageTreatName.substr(0, loadImageTreatName.length()-3);
                    string channelString = loadImageTreatName.substr(loadImageTreatName.length()-1, 1);
                    string colorName;
                    
                    if (channelString == "1"){
                        colorName = fluorescent1;
                        zImageColorSet = fluorescentNo1;
                    }
                    else if (channelString == "2"){
                        colorName = fluorescent2;
                        zImageColorSet = fluorescentNo2;
                    }
                    else if (channelString == "3"){
                        colorName = fluorescent3;
                        zImageColorSet = fluorescentNo3;
                    }
                    else if (channelString == "4"){
                        colorName = fluorescent4;
                        zImageColorSet = fluorescentNo4;
                    }
                    else if (channelString == "5"){
                        colorName = fluorescent5;
                        zImageColorSet = fluorescentNo5;
                    }
                    else if (channelString == "6"){
                        colorName = fluorescent6;
                        zImageColorSet = fluorescentNo6;
                    }
                    
                    baseTreatmentName = treatString;
                    
                    ifstream fin;
                    
                    int fovPositionHoldTempCount = 0;
                    int treatFind = 0;
                    
                    if (processMode == 5 || processMode == 13 || processMode == 7) fin.open(fovPositionTempPath.c_str(), ios::in);
                    else fin.open(fovPositionPath.c_str(), ios::in);
                    
                    string getString;
                    
                    if (fin.is_open()){
                        do{
                            
                            getline(fin, getString);
                            
                            if (baseTreatmentName == getString && treatFind == 0) treatFind = 1;
                            else if (getString != "ND" && treatFind == 1) treatFind = 2;
                            else if (getString != "ND" && treatFind == 2){
                                arrayXYWritingPositionBase [fovPositionHoldTempCount] = atoi(getString.c_str()), fovPositionHoldTempCount++;
                            }
                            else if (getString == "ND" && treatFind == 2) treatFind = 3;
                            
                        } while (getString != "");
                        
                        fin.close();
                        
                        if (treatFind != 0){
                            fovPositionHoldTempCount = 0;
                            treatFind = 0;
                            
                            if (processMode == 5 || processMode == 13 || processMode == 7) fin.open(fovPositionTempPath.c_str(), ios::in);
                            else fin.open(fovPositionPath.c_str(), ios::in);
                            
                            if (fin.is_open()){
                                do{
                                    
                                    getline(fin, getString);
                                    
                                    if (loadImageTreatName == getString && treatFind == 0) treatFind = 1;
                                    else if (getString != "ND" && treatFind == 1) treatFind = 2;
                                    else if (getString != "ND" && treatFind == 2){
                                        arrayXYWritingPositionFluorescent [fovPositionHoldTempCount] = atoi(getString.c_str());
                                        fovPositionHoldTempCount++;
                                    }
                                    else if (getString == "ND" && treatFind == 2) treatFind = 3;
                                    
                                } while (getString != "");
                                
                                fin.close();
                                
                                string folderName = treatString+"~Sorted";
                                string extension;
                                string fovString;
                                string processFileBasePath;
                                string processFileBasePath2;
                                
                                int imageDimensionCount = 0;
                                int extensionType = 0;
                                int dimensionAdditionY = 0;
                                int dimensionAdditionX = 0;
                                int imageDimensionFluorescentY = 0;
                                int imageDimensionFluorescentX = 0;
                                int verticalBmp = 0;
                                int horizontalBmpEntry = 0;
                                long sizeForCopy = 0;
                                
                                //-----Tiff reading-----
                                unsigned long stripFirstAddress = 0;
                                unsigned long stripByteCountAddress = 0;
                                unsigned long nextAddress = 0;
                                unsigned long headPosition = 0;
                                unsigned long stripEntry = 0;
                                
                                double xPosition = 0;
                                double yPosition = 0;
                                
                                int imageWidth = 0;
                                int imageHeight = 0;
                                int imageBit = 0; // Check 8, 16
                                int imageCompression = 0; // Check 1
                                int photoMetric = 0;//check 0, 1, 2
                                int imageDimensionTif = 0;
                                int horizontalBmp = 0;
                                int endianType = 0;
                                int samplePerPix = 0;
                                int dataConversion [4];
                                int processTypeTif = 1;
                                int numberOfLayers = 0;
                                
                                struct stat sizeOfFile;
                                
                                for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                                    extension = to_string(counter1);
                                    
                                    if (extension.length() == 1) fovString = "FOV00"+extension;
                                    else if (extension.length() == 2) fovString = "FOV0"+extension;
                                    else if (extension.length() == 3) fovString = "FOV"+extension;
                                    
                                    processFileBasePath = productsFilesTempPath+"/"+folderName+"/"+fovString+"/"+treatString+"_"+fileNoStringTemp+"-"+fovString;
                                    processFileBasePath2 = processFileBasePath+".tif";
                                    
                                    extensionType = 0;
                                    
                                    fin.open(processFileBasePath2.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        extensionType = 1;
                                        fin.close();
                                    }
                                    else{
                                        
                                        processFileBasePath2 = processFileBasePath+".bmp";
                                        
                                        fin.open(processFileBasePath2.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            extensionType = 2;
                                            fin.close();
                                        }
                                    }
                                    
                                    if (extensionType == 1){
                                        if (stat(processFileBasePath2.c_str(), &sizeOfFile) == 0){
                                            sizeForCopy = sizeOfFile.st_size;
                                            
                                            fileReadArray = new uint8_t [sizeForCopy+4];
                                            fin.open(processFileBasePath2.c_str(), ios::in | ios::binary);
                                            
                                            fin.read((char*)fileReadArray, sizeForCopy+4);
                                            fin.close();
                                            
                                            dataConversion [0] = fileReadArray [0];
                                            dataConversion [1] = fileReadArray [1];
                                            
                                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                            else endianType = 0;
                                            
                                            int *arrayExtractedImage3 = new int [100];
                                            
                                            headPosition = 0;
                                            
                                            if (endianType == 1){
                                                dataConversion [0] = fileReadArray [7];
                                                dataConversion [1] = fileReadArray [6];
                                                dataConversion [2] = fileReadArray [5];
                                                dataConversion [3] = fileReadArray [4];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            else if (endianType == 0){
                                                dataConversion [0] = fileReadArray [4];
                                                dataConversion [1] = fileReadArray [5];
                                                dataConversion [2] = fileReadArray [6];
                                                dataConversion [3] = fileReadArray [7];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            
                                            if (endianType == 1){
                                                tiffFileRead = [[TiffFileRead alloc] init];
                                                [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                                
                                                
                                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                                    if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                                    else imageDimensionTif = imageHeight;
                                                    
                                                    tiffFileRead = [[TiffFileRead alloc] init];
                                                    delete [] arrayExtractedImage3;
                                                    
                                                    arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                                    
                                                }
                                            }
                                            else if (endianType == 0){
                                                tiffFileRead = [[TiffFileRead alloc] init];
                                                [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                                
                                                
                                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                                    if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                                    else imageDimensionTif = imageHeight;
                                                    
                                                    tiffFileRead = [[TiffFileRead alloc] init];
                                                    delete [] arrayExtractedImage3;
                                                    
                                                    arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                                    
                                                }
                                            }
                                            
                                            //-----Multiply image dimensions by a factor of 8-----
                                            dimensionAdditionY = imageWidth%8;
                                            
                                            if (dimensionAdditionY == 1) dimensionAdditionY = 7;
                                            else if (dimensionAdditionY == 2) dimensionAdditionY = 6;
                                            else if (dimensionAdditionY == 3) dimensionAdditionY = 5;
                                            else if (dimensionAdditionY == 4) dimensionAdditionY = 4;
                                            else if (dimensionAdditionY == 5) dimensionAdditionY = 3;
                                            else if (dimensionAdditionY == 6) dimensionAdditionY = 2;
                                            else if (dimensionAdditionY == 7) dimensionAdditionY = 1;
                                            
                                            imageDimensionFluorescentY = imageWidth+dimensionAdditionY;
                                            
                                            dimensionAdditionX = imageHeight%8;
                                            
                                            if (dimensionAdditionX == 1) dimensionAdditionX = 7;
                                            else if (dimensionAdditionX == 2) dimensionAdditionX = 6;
                                            else if (dimensionAdditionX == 3) dimensionAdditionX = 5;
                                            else if (dimensionAdditionX == 4) dimensionAdditionX = 4;
                                            else if (dimensionAdditionX == 5) dimensionAdditionX = 3;
                                            else if (dimensionAdditionX == 6) dimensionAdditionX = 2;
                                            else if (dimensionAdditionX == 7) dimensionAdditionX = 1;
                                            
                                            imageDimensionFluorescentX = imageHeight+dimensionAdditionX;
                                            
                                            verticalBmp = 0;
                                            horizontalBmp = 0;
                                            horizontalBmpEntry = 0;
                                            
                                            for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                                if (verticalBmp < imageHeight){
                                                    if (horizontalBmp < imageWidth){
                                                        arrayBackgroundDataHold [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3]), horizontalBmpEntry++;
                                                    }
                                                    
                                                    if (horizontalBmpEntry == imageWidth && imageWidth < imageDimensionFluorescentX){
                                                        for (int counter6 = 0; counter6 < imageDimensionFluorescentX-imageWidth; counter6++){
                                                            arrayBackgroundDataHold [imageDimensionCount][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter3]), horizontalBmpEntry++;
                                                        }
                                                    }
                                                    
                                                    if (horizontalBmpEntry == imageWidth){
                                                        horizontalBmpEntry = 0;
                                                        imageDimensionCount++;
                                                        verticalBmp++;
                                                    }
                                                }
                                            }
                                            
                                            if (imageHeight < imageDimensionFluorescentY){
                                                for (int counter5 = imageHeight; counter5 < imageDimensionFluorescentY; counter5++){
                                                    for (int counter6 = 0; counter6 < imageDimensionFluorescentX; counter6++){
                                                        arrayBackgroundDataHold [counter5][counter6] = -1;
                                                    }
                                                }
                                            }
                                            
                                            delete [] fileReadArray;
                                            delete [] arrayExtractedImage3;
                                        }
                                    }
                                    else if (extensionType == 2){
                                        if (stat(processFileBasePath2.c_str(), &sizeOfFile) == 0){
                                            sizeForCopy = sizeOfFile.st_size;
                                            
                                            uint8_t *uploadTemp = new uint8_t [sizeForCopy];
                                            fin.open(processFileBasePath2.c_str(), ios::in | ios::binary);
                                            
                                            if (fin.is_open()){
                                                fin.read((char*)uploadTemp, sizeForCopy+1);
                                                fin.close();
                                                
                                                for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                                                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                                        arrayBackgroundDataHold [imageDimensionCount][counter3] = uploadTemp [1078+counter2*imageDimensionY+counter3];
                                                    }
                                                    
                                                    imageDimensionCount++;
                                                }
                                            }
                                            
                                            delete [] uploadTemp;
                                        }
                                    }
                                }
                            }
                            
                            xMovePositionHoldMain = 0;
                            yMovePositionHoldMain = 0;
                            
                            for (int counter1 = 0; counter1 < stitchImageDimension; counter1++){
                                for (int counter2 = 0; counter2 < stitchImageDimension; counter2++){
                                    imageDisplayBaseArray [counter1][counter2] = 100;
                                    imageDisplayFluorescentArray [counter1][counter2] = -300;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < loadImageFOVNo; counter1++){
                                for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                        if (counter2+arrayXYWritingPositionBase [counter1*2+1] >= 0 && counter2+arrayXYWritingPositionBase [counter1*2+1] < stitchImageDimension && counter3+arrayXYWritingPositionBase [counter1*2] >= 0 && counter3+arrayXYWritingPositionBase [counter1*2] < stitchImageDimension){
                                            imageDisplayBaseArray [counter2+arrayXYWritingPositionBase [counter1*2+1]][counter3+arrayXYWritingPositionBase [counter1*2]] = arrayBackgroundDataHold [counter1*imageDimensionY+counter2][counter3];
                                        }
                                        
                                        if (counter2+arrayXYWritingPositionFluorescent [counter1*2+1] >= 0 && counter2+arrayXYWritingPositionFluorescent [counter1*2+1] < stitchImageDimension && counter3+arrayXYWritingPositionFluorescent [counter1*2] >= 0 && counter3+arrayXYWritingPositionFluorescent [counter1*2] < stitchImageDimension){
                                            if (arrayImageDataHold [counter1*imageDimensionY+counter2][counter3] >= 0){
                                                imageDisplayFluorescentArray [counter2+arrayXYWritingPositionFluorescent [counter1*2+1]][counter3+arrayXYWritingPositionFluorescent [counter1*2]] = arrayImageDataHold [counter1*imageDimensionY+counter2][counter3];
                                            }
                                            else imageDisplayFluorescentArray [counter2+arrayXYWritingPositionFluorescent [counter1*2+1]][counter3+arrayXYWritingPositionFluorescent [counter1*2]] = 0;
                                        }
                                    }
                                }
                            }
                            
                            fluorescentStitchDimension = stitchImageDimension;
                            
                            [treatmentAdjust setStringValue:@(loadImageTreatName.c_str())];
                            [channelAdjust setStringValue:@(colorName.c_str())];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                            
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentAdjust object:self];
                        }
                        else{
                            
                            positionAdjustFlag = 0;
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"FOV Position File Missing"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        positionAdjustFlag = 0;
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"FOV Position File Missing"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Fluorescent Channel Detected"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderAction:(id)sender{
    if (positionAdjustFlag == 1){
        fluorescentEnhance = [sliderFluorescent doubleValue];
        
        int fluorescentEnhanceInt = (int)(fluorescentEnhance*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [fluorescentValueDisplay setDoubleValue:fluorescentEnhanceDouble];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentAdjust object:self];
    }
}

-(IBAction)sliderActionBase:(id)sender{
    if (positionAdjustFlag == 1){
        baseCut = [sliderBase doubleValue];
        
        int baseCutInt = (int)(baseCut*1000);
        double baseCutDouble = baseCutInt/(double)1000;
        
        [baseCutValueDisplay setDoubleValue:baseCutDouble];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentAdjust object:self];
    }
}

-(IBAction)usePreviousValue:(id)sender{
    if (positionAdjustFlag == 1){
        if (autoProcessingFlag == 0){
            string extractString = loadImageTreatName.substr(loadImageTreatName.length()-3, 2);
            
            if (extractString == "CH"){
                string treatString = loadImageTreatName.substr(0, loadImageTreatName.length()-3);
                string channelString = loadImageTreatName.substr(loadImageTreatName.length()-1, 1);
                
                int adjustX = 0;
                int adjustY = 0;
                
                if (channelString == "1"){
                    adjustX = channelAdjustHoldX1;
                    adjustY = channelAdjustHoldY1;
                }
                else if (channelString == "2"){
                    adjustX = channelAdjustHoldX2;
                    adjustY = channelAdjustHoldY2;
                }
                else if (channelString == "3"){
                    adjustX = channelAdjustHoldX3;
                    adjustY = channelAdjustHoldY3;
                }
                else if (channelString == "4"){
                    adjustX = channelAdjustHoldX4;
                    adjustY = channelAdjustHoldY4;
                }
                else if (channelString == "5"){
                    adjustX = channelAdjustHoldX5;
                    adjustY = channelAdjustHoldY5;
                }
                else if (channelString == "6"){
                    adjustX = channelAdjustHoldX6;
                    adjustY = channelAdjustHoldY6;
                }
                
                xMovePositionHoldMain = adjustX;
                yMovePositionHoldMain = adjustY;
                
                ifstream fin;
                
                int fovPositionHoldTempCount = 0;
                int treatFind = 0;
                
                string getString;
                
                if (processMode == 5 || processMode == 13 || processMode == 7) fin.open(fovPositionTempPath.c_str(), ios::in);
                else fin.open(fovPositionPath.c_str(), ios::in);
                
                if (fin.is_open()){
                    do{
                        
                        getline(fin, getString);
                        
                        if (treatString == getString && treatFind == 0) treatFind = 1;
                        else if (getString != "ND" && treatFind == 1) treatFind = 2;
                        else if (getString != "ND" && treatFind == 2){
                            arrayXYWritingPositionFluorescent [fovPositionHoldTempCount] = atoi(getString.c_str());
                            fovPositionHoldTempCount++;
                        }
                        else if (getString == "ND" && treatFind == 2) treatFind = 3;
                        
                    } while (getString != "");
                    
                    fin.close();
                }
                
                for (int counter1 = 0; counter1 < stitchImageDimension; counter1++){
                    for (int counter2 = 0; counter2 < stitchImageDimension; counter2++){
                        imageDisplayFluorescentArray [counter1][counter2] = -300;
                    }
                }
                
                for (int counter1 = 0; counter1 < loadImageFOVNo; counter1++){
                    for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                        for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                            if (counter2+arrayXYWritingPositionFluorescent [counter1*2+1]+adjustY >= 0 && counter2+arrayXYWritingPositionFluorescent [counter1*2+1]+adjustY < stitchImageDimension && counter3+arrayXYWritingPositionFluorescent [counter1*2]-adjustX >= 0 && counter3+arrayXYWritingPositionFluorescent [counter1*2]-adjustX < stitchImageDimension){
                                if (arrayImageDataHold [counter1*imageDimensionY+counter2][counter3] >= 0){
                                    imageDisplayFluorescentArray [counter2+arrayXYWritingPositionFluorescent [counter1*2+1]+adjustY][counter3+arrayXYWritingPositionFluorescent [counter1*2]-adjustX] = arrayImageDataHold [counter1*imageDimensionY+counter2][counter3];
                                }
                                else  imageDisplayFluorescentArray [counter2+arrayXYWritingPositionFluorescent [counter1*2+1]+adjustY][counter3+arrayXYWritingPositionFluorescent [counter1*2]-adjustX] = 0;
                            }
                        }
                    }
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentAdjust object:self];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)previousValueHold1:(id)sender{
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        if (positionAdjustFlag == 1){
            channelAdjustHoldX1 = 0;
            channelAdjustHoldY1 = 0;
            channelAdjustFirstSet1 = 0;
            
            [channelValueX1 setIntegerValue:channelAdjustHoldX1];
            [channelValueY1 setIntegerValue:channelAdjustHoldY1];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Processing Image. Please Wait"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)previousValueHold2:(id)sender{
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        if (positionAdjustFlag == 1){
            channelAdjustHoldX2 = 0;
            channelAdjustHoldY2 = 0;
            channelAdjustFirstSet2 = 0;
            
            [channelValueX2 setIntegerValue:channelAdjustHoldX2];
            [channelValueY2 setIntegerValue:channelAdjustHoldY2];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Processing Image. Please Wait"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)previousValueHold3:(id)sender{
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        if (positionAdjustFlag == 1){
            channelAdjustHoldX3 = 0;
            channelAdjustHoldY3 = 0;
            channelAdjustFirstSet3 = 0;
            
            [channelValueX3 setIntegerValue:channelAdjustHoldX3];
            [channelValueY3 setIntegerValue:channelAdjustHoldY3];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Processing Image. Please Wait"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)previousValueHold4:(id)sender{
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        if (positionAdjustFlag == 1){
            channelAdjustHoldX4 = 0;
            channelAdjustHoldY4 = 0;
            channelAdjustFirstSet4 = 0;
            
            [channelValueX4 setIntegerValue:channelAdjustHoldX4];
            [channelValueY4 setIntegerValue:channelAdjustHoldY4];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Processing Image. Please Wait"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)previousValueHold5:(id)sender{
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        if (positionAdjustFlag == 1){
            channelAdjustHoldX5 = 0;
            channelAdjustHoldY5 = 0;
            channelAdjustFirstSet5 = 0;
            
            [channelValueX5 setIntegerValue:channelAdjustHoldX5];
            [channelValueY5 setIntegerValue:channelAdjustHoldY5];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Processing Image. Please Wait"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)previousValueHold6:(id)sender{
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        if (positionAdjustFlag == 1){
            channelAdjustHoldX6 = 0;
            channelAdjustHoldY6 = 0;
            channelAdjustFirstSet6 = 0;
            
            [channelValueX6 setIntegerValue:channelAdjustHoldX6];
            [channelValueY6 setIntegerValue:channelAdjustHoldY6];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Processing Image. Please Wait"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderActionCircle:(id)sender{
    if (positionAdjustFlag == 1){
        double sliderCircleValue = sliderFluorescentMax*[sliderFluorescentCircle doubleValue];
        double sliderCircleValue2 = sliderFluorescentMin/[sliderFluorescentCircle doubleValue];
        double sliderValue = [sliderFluorescent doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderFluorescentDiff;
        
        sliderCircleValue = sliderValue+(sliderFluorescentMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderFluorescentMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderFluorescent setMaxValue:sliderCircleValue];
        [sliderFluorescent setMinValue:sliderCircleValue2];
        
        int fluorescentEnhanceInt = (int)([sliderFluorescent doubleValue]*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [fluorescentValueDisplay setDoubleValue:fluorescentEnhanceDouble];
    }
}

-(IBAction)sliderActionBaseCircle:(id)sender{
    if (positionAdjustFlag == 1){
        double sliderCircleValue = sliderBaseMax*[sliderBaseCircle doubleValue];
        double sliderCircleValue2 = sliderBaseMin/[sliderBaseCircle doubleValue];
        double sliderValue = [sliderBase doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderBaseDiff;
        
        sliderCircleValue = sliderValue+(sliderBaseMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderBaseMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderBase setMaxValue:sliderCircleValue];
        [sliderBase setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderBase doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [baseCutValueDisplay setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)sliderDICLevel:(id)sender{
    if (positionAdjustFlag == 1){
        dicLevelHold = [sliderDICLevel doubleValue];
        
        int dicLevelHoldInt = (int)(dicLevelHold*1000);
        double dicLevelHoldDouble = dicLevelHoldInt/(double)1000;
        
        [dicLevelValueDisplay setDoubleValue:dicLevelHoldDouble];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentAdjust object:self];
    }
}

-(IBAction)sliderDICCont:(id)sender{
    if (positionAdjustFlag == 1){
        dicContrastHold = [sliderDICCont doubleValue];
        
        int dicContrastHoldInt = (int)(dicContrastHold*1000);
        double dicContrastHoldDouble = dicContrastHoldInt/(double)1000;
        
        [dicContrastValueDisplay setDoubleValue:dicContrastHoldDouble];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentAdjust object:self];
    }
}

-(IBAction)sliderDICLevelCircle:(id)sender{
    if (positionAdjustFlag == 1){
        double sliderCircleValue = sliderDICLevelMax*[sliderDICLevelCircle doubleValue];
        double sliderCircleValue2 = sliderDICLevelMin/[sliderDICLevelCircle doubleValue];
        double sliderValue = [sliderDICLevel doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderDICLevelDiff;
        
        sliderCircleValue = sliderValue+(sliderDICLevelMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderDICLevelMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderDICLevel setMaxValue:sliderCircleValue];
        [sliderDICLevel setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderDICLevel doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [dicLevelValueDisplay setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)sliderDICContCircle:(id)sender{
    if (positionAdjustFlag == 1){
        double sliderCircleValue = sliderDICContMax*[sliderDICContCircle doubleValue];
        double sliderCircleValue2 = sliderDICContMin/[sliderDICContCircle doubleValue];
        double sliderValue = [sliderDICCont doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderDICContDiff;
        
        sliderCircleValue = sliderValue+(sliderDICContMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderDICContMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderDICCont setMaxValue:sliderCircleValue];
        [sliderDICCont setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderDICCont doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [dicContrastValueDisplay setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)clearFluorescent:(id)sender{
    if (positionAdjustFlag == 1){
        baseCut = 50;
        fluorescentEnhance = 1;
        
        int baseCutInt = (int)(baseCut*1000);
        double baseCutDouble = baseCutInt/(double)1000;
        int fluorescentEnhanceInt = (int)(fluorescentEnhance*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [baseCutValueDisplay setDoubleValue:baseCutDouble];
        [fluorescentValueDisplay setDoubleValue:fluorescentEnhanceDouble];
        
        [sliderFluorescent setDoubleValue:1];
        [sliderBase setDoubleValue:50];
        [sliderFluorescentCircle setDoubleValue:1];
        [sliderBaseCircle setDoubleValue:1];
        
        [sliderFluorescent setMaxValue:sliderFluorescentMax];
        [sliderFluorescent setMinValue:sliderFluorescentMin];
        
        [sliderBase setMaxValue:sliderBaseMax];
        [sliderBase setMinValue:sliderBaseMin];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentAdjust object:self];
    }
}

-(IBAction)clearDIC:(id)sender{
    if (positionAdjustFlag == 1){
        dicLevelHold = 50;
        dicContrastHold = 1;
        
        int dicLevelHoldInt = (int)(dicLevelHold*1000);
        double dicLevelHoldDouble = dicLevelHoldInt/(double)1000;
        int dicContrastHoldInt = (int)(dicContrastHold*1000);
        double dicContrastHoldDouble = dicContrastHoldInt/(double)1000;
        
        [dicLevelValueDisplay setDoubleValue:dicLevelHoldDouble];
        [dicContrastValueDisplay setDoubleValue:dicContrastHoldDouble];
        
        [sliderDICLevel setDoubleValue:50];
        [sliderDICCont setDoubleValue:1];
        [sliderDICLevelCircle setDoubleValue:1];
        [sliderDICContCircle setDoubleValue:1];
        
        [sliderDICLevel setMaxValue:sliderDICLevelMax];
        [sliderDICLevel setMinValue:sliderDICLevelMin];
        
        [sliderDICCont setMaxValue:sliderDICContMax];
        [sliderDICCont setMinValue:sliderDICContMin];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentAdjust object:self];
    }
}

-(IBAction)closeWindow:(id)sender{
    [adjustWindow orderOut:self];
    positionAdjustOperation = 2;
    adjustTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (positionAdjustOperation == 3){
        [adjustWindow makeKeyAndOrderFront:self];
        positionAdjustOperation = 1;
        [adjustTimer invalidate];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToAdjustController object:nil];
    if (adjustTimer) [adjustTimer invalidate];
    if (adjustTimer2) [adjustTimer2 invalidate];
}

@end
