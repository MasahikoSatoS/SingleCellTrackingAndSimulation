//
//  FluorescentAdjust.h
//  Contrast_Set
//
//  Created by Masahiko Sato on 2014-05-26.
//  Copyright Masahiko Sato 2014 All rights reserved.
//
//

#ifndef FLUOROADJUST_H
#define FLUOROADJUST_H
#import "Controller.h"
#endif

@interface FluorescentAdjust : NSView{
    int mouseDragFlag; //Display operation
    int mouseDownFlag; //Display operation
    int xStartHold; //X start
    int yStartHold; //Y start
    
    double xPointDownDisplayFlu; //Display operation
    double yPointDownDisplayFlu; //Display operation
    double xPositionMoveDisplayFlu; //Display operation
    double yPositionMoveDisplayFlu; //Display operation
    double xPointDragDisplayFlu; //Display operation
    double yPointDragDisplayFlu; //Display operation
    double xPositionDisplayFlu; //Display operation
    double yPositionDisplayFlu; //Display operation
    double xPositionAdjustDisplayFlu; //Display operation
    double yPositionAdjustDisplayFlu; //Display operation
    double windowWidthDisplayFlu; //Display operation
    double windowHeightDisplayFlu; //Display operation
    
    int xMovePositionHold; //Display operation
    int yMovePositionHold; //Display operation
    int dragHoldFlag; //Display operation
    int dragControl; //Display operation
    
    IBOutlet NSImage *adjustImage;
}

-(void)mouseDown:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)mouseDragged:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
