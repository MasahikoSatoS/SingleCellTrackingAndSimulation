//
//  HistogramWindow.h
//  Contrast_Set
//
//  Created by Masahiko Sato on 2014-04-07.
//  Copyright Masahiko Sato 2014 All rights reserved.
//

#ifndef HISTOGRAMWINDOW_H
#define HISTOGRAMWINDOW_H
#import "Controller.h" 
#endif

@interface HistogramWindow : NSView{
    int verticalMagnification; //Vertical magnification
    int verticalMagnificationStep; //Vertical magnification step
    int selectProcessLine; //Select line
    double xPointDownHisto; //Histo
    double yPointDownHisto; //Histo
    double xPointDragHisto; //Histo
    
    IBOutlet NSImage *histogramImage;
    
    id contrastAdjust;
}

-(void)mouseDown:(NSEvent *)event;
-(void)mouseDragged:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)resetData:(int)resetType;
-(void)dealloc;

@end
