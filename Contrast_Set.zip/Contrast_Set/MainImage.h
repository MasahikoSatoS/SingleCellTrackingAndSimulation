//
//  MainImage.h
//  Contrast_Set
//
//  Created by Masahiko Sato on 2014-04-07.
//  Copyright Masahiko Sato 2014 All rights reserved.
//

#ifndef MAINIMAGE_H
#define MAINIMAGE_H
#import "Controller.h"
#import "ContrastAdjust2.h" 
#endif

@interface MainImage : NSView{
    int mouseDragFlag; //Display operation
    int mouseDownFlag; //Display operation
    int xStartHold; //X position start
    int yStartHold; //Y position start
    double xPointDownDisplay; //Display operation
    double yPointDownDisplay; //Display operation
    double xPositionMoveDisplay; //Display operation
    double yPositionMoveDisplay; //Display operation
    double xPointDragDisplay; //Display operation
    double yPointDragDisplay; //Display operation
    double xPositionDisplay; //Display operation
    double yPositionDisplay; //Display operation
    double xPositionAdjustDisplay; //Display operation
    double yPositionAdjustDisplay; //Display operation
    
    id objectMatch;
    id contrastAdjust2;
    id balanceSet;
    
    IBOutlet NSImage *mainImage;
}

-(void)mouseDown:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)mouseDragged:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
