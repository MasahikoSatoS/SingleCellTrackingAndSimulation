//
//  BackgroundCorrection.h
//  Contrast_Set
//
//  Created by Masahiko Sato on 05/05/12.
//  Copyright 2012 Masahiko Sato All rights reserved.
//

#ifndef BACKGROUNDCORRECTION_H
#define BACKGROUNDCORRECTION_H
#import "Controller.h" 
#endif

@interface BackgroundCorrection : NSObject {
}

-(void)backgroundImageSub:(int)bcType :(int)fovNoSet :(int)imageDimensionBackgroundX :(int)imageDimensionBackgroundY;

@end
