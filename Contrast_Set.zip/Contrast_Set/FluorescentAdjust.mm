//
//  FluorescentAdjust.m
//  Contrast_Set
//
//  Created by Masahiko Sato on 2014-05-26.
//
//

#import "FluorescentAdjust.h"

NSString *notificationToFluorescentAdjust = @"notificationExecuteFluorescentAdjust";

@implementation FluorescentAdjust

- (id)initWithFrame:(NSRect)frame{
    self = [super initWithFrame:frame];
    
    if (self) {
        adjustImage = [[NSImage alloc] initWithContentsOfFile:@""];
        
        mouseDragFlag = 0;
        mouseDownFlag = 0;
        xStartHold = 0;
        yStartHold = 0;
        dragControl = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToFluorescentAdjust object:nil];
    }
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    if (positionAdjustFlag == 1){
        progressTimingB = 1;
        
        int imageSetSize = 0;
        int counterIncrement = 0;
        
        if (fluorescentStitchDimension <= 1000){
            imageSetSize = fluorescentStitchDimension;
            counterIncrement = 1;
        }
        else if (fluorescentStitchDimension <= 4000){
            imageSetSize = fluorescentStitchDimension/2;
            counterIncrement = 2;
        }
        else{
            
            imageSetSize = fluorescentStitchDimension/4;
            counterIncrement = 4;
        }
        
        NSBitmapImageRep *bitmapReps;
        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize pixelsHigh:imageSetSize bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageSetSize*4 bitsPerPixel:32];
        
        unsigned char *bitmapData = [bitmapReps bitmapData];
        
        int readDataTemp = 0;
        int readDataTemp2 = 0;
        
        if (zImageColorSet == "1"){
            for (int counterY = 0; counterY < fluorescentStitchDimension; counterY = counterY+counterIncrement){
                for (int counterX = 0; counterX < fluorescentStitchDimension; counterX = counterX+counterIncrement){
                    readDataTemp = imageDisplayBaseArray [counterY][counterX];
                    
                    if (readDataTemp >= 0 && readDataTemp < dicLevelHold){
                        readDataTemp = readDataTemp-(int)((dicLevelHold-readDataTemp)*dicContrastHold);
                        
                        if (readDataTemp < 0) readDataTemp = 0;
                    }
                    else{
                        
                        readDataTemp = readDataTemp+(int)((readDataTemp-dicLevelHold)*dicContrastHold);
                        
                        if (readDataTemp > 255) readDataTemp = 255;
                    }
                    
                    readDataTemp2 = imageDisplayFluorescentArray [counterY][counterX];
                    
                    if (readDataTemp2 != -300){
                        if (readDataTemp2 >= 0 && readDataTemp2 < baseCut) readDataTemp2 = -1;
                        else{
                            
                            readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCut)*fluorescentEnhance);
                            
                            if (readDataTemp2 > 255) readDataTemp2 = 255;
                        }
                    }
                    
                    if (readDataTemp2 <= 0){
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = 0;
                    }
                    else{
                        
                        *bitmapData++ = 0;
                        *bitmapData++ = 0;
                        *bitmapData++ = (unsigned char)readDataTemp2;
                        *bitmapData++ = 0;
                    }
                }
            }
        }
        else if (zImageColorSet == "2"){
            for (int counterY = 0; counterY < fluorescentStitchDimension; counterY = counterY+counterIncrement){
                for (int counterX = 0; counterX < fluorescentStitchDimension; counterX = counterX+counterIncrement){
                    readDataTemp = imageDisplayBaseArray [counterY][counterX];
                    
                    if (readDataTemp >= 0 && readDataTemp < dicLevelHold){
                        readDataTemp = readDataTemp-(int)((dicLevelHold-readDataTemp)*dicContrastHold);
                        
                        if (readDataTemp < 0) readDataTemp = 0;
                    }
                    else{
                        
                        readDataTemp = readDataTemp+(int)((readDataTemp-dicLevelHold)*dicContrastHold);
                        
                        if (readDataTemp > 255) readDataTemp = 255;
                    }
                    
                    readDataTemp2 = imageDisplayFluorescentArray [counterY][counterX];
                    
                    if (readDataTemp2 != -300){
                        if (readDataTemp2 >= 0 && readDataTemp2 < baseCut) readDataTemp2 = 0;
                        else{
                            
                            readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCut)*fluorescentEnhance);
                            
                            if (readDataTemp2 > 255) readDataTemp2 = 255;
                        }
                    }
                    
                    if (readDataTemp2 <= 0){
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = 0;
                    }
                    else{
                        
                        *bitmapData++ = 0;
                        *bitmapData++ = (unsigned char)readDataTemp2;
                        *bitmapData++ = 0;
                        *bitmapData++ = 0;
                    }
                }
            }
        }
        else if (zImageColorSet == "3"){
            for (int counterY = 0; counterY < fluorescentStitchDimension; counterY = counterY+counterIncrement){
                for (int counterX = 0; counterX < fluorescentStitchDimension; counterX = counterX+counterIncrement){
                    readDataTemp = imageDisplayBaseArray [counterY][counterX];
                    
                    if (readDataTemp >= 0 && readDataTemp < dicLevelHold){
                        readDataTemp = readDataTemp-(int)((dicLevelHold-readDataTemp)*dicContrastHold);
                        
                        if (readDataTemp < 0) readDataTemp = 0;
                    }
                    else{
                        
                        readDataTemp = readDataTemp+(int)((readDataTemp-dicLevelHold)*dicContrastHold);
                        
                        if (readDataTemp > 255) readDataTemp = 255;
                    }
                    
                    readDataTemp2 = imageDisplayFluorescentArray [counterY][counterX];
                    
                    if (readDataTemp2 != -300){
                        if (readDataTemp2 >= 0 && readDataTemp2 < baseCut) readDataTemp2 = 0;
                        else{
                            
                            readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCut)*fluorescentEnhance);
                            
                            if (readDataTemp2 > 255) readDataTemp2 = 255;
                        }
                    }
                    
                    if (readDataTemp2 <= 0){
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = 0;
                    }
                    else{
                        
                        *bitmapData++ = (unsigned char)readDataTemp2;
                        *bitmapData++ = (unsigned char)readDataTemp2;
                        *bitmapData++ = 0;
                        *bitmapData++ = 0;
                    }
                }
            }
        }
        else if (zImageColorSet == "4"){
            for (int counterY = 0; counterY < fluorescentStitchDimension; counterY = counterY+counterIncrement){
                for (int counterX = 0; counterX < fluorescentStitchDimension; counterX = counterX+counterIncrement){
                    readDataTemp = imageDisplayBaseArray [counterY][counterX];
                    
                    if (readDataTemp >= 0 && readDataTemp < dicLevelHold){
                        readDataTemp = readDataTemp-(int)((dicLevelHold-readDataTemp)*dicContrastHold);
                        
                        if (readDataTemp < 0) readDataTemp = 0;
                    }
                    else{
                        
                        readDataTemp = readDataTemp+(int)((readDataTemp-dicLevelHold)*dicContrastHold);
                        
                        if (readDataTemp > 255) readDataTemp = 255;
                    }
                    
                    readDataTemp2 = imageDisplayFluorescentArray [counterY][counterX];
                    
                    if (readDataTemp2 != -300){
                        if (readDataTemp2 >= 0 && readDataTemp2 < baseCut) readDataTemp2 = 0;
                        else{
                            
                            readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCut)*fluorescentEnhance);
                            
                            if (readDataTemp2 > 255) readDataTemp2 = 255;
                        }
                    }
                    
                    if (readDataTemp2 <= 0){
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = 0;
                    }
                    else{
                        
                        *bitmapData++ = (unsigned char)readDataTemp2;
                        *bitmapData++ = 0;
                        *bitmapData++ = 0;
                        *bitmapData++ = 0;
                    }
                }
            }
        }
        else if (zImageColorSet == "5"){
            for (int counterY = 0; counterY < fluorescentStitchDimension; counterY = counterY+counterIncrement){
                for (int counterX = 0; counterX < fluorescentStitchDimension; counterX = counterX+counterIncrement){
                    readDataTemp = (int)((imageDisplayBaseArray [counterY][counterX]+dicLevelHold)*(double)dicContrastHold);
                    
                    if (readDataTemp >= 0 && readDataTemp < dicLevelHold){
                        readDataTemp = readDataTemp-(int)((dicLevelHold-readDataTemp)*dicContrastHold);
                        
                        if (readDataTemp < 0) readDataTemp = 0;
                    }
                    else{
                        
                        readDataTemp = readDataTemp+(int)((readDataTemp-dicLevelHold)*dicContrastHold);
                        
                        if (readDataTemp > 255) readDataTemp = 255;
                    }
                    
                    readDataTemp2 = imageDisplayFluorescentArray [counterY][counterX];
                    
                    if (readDataTemp2 != -300){
                        if (readDataTemp2 >= 0 && readDataTemp2 < baseCut) readDataTemp2 = 0;
                        else{
                            
                            readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCut)*fluorescentEnhance);
                            
                            if (readDataTemp2 > 255) readDataTemp2 = 255;
                        }
                    }
                    
                    if (readDataTemp2 <= 0){
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = 0;
                    }
                    else{
                        
                        *bitmapData++ = (unsigned char)readDataTemp2;
                        *bitmapData++ = 0;
                        *bitmapData++ = (unsigned char)readDataTemp2;
                        *bitmapData++ = 0;
                    }
                }
            }
        }
        else if (zImageColorSet == "6"){
            for (int counterY = 0; counterY < fluorescentStitchDimension; counterY = counterY+counterIncrement){
                for (int counterX = 0; counterX < fluorescentStitchDimension; counterX = counterX+counterIncrement){
                    readDataTemp = (int)((imageDisplayBaseArray [counterY][counterX]+dicLevelHold)*(double)dicContrastHold);
                    
                    if (readDataTemp >= 0 && readDataTemp < dicLevelHold){
                        readDataTemp = readDataTemp-(int)((dicLevelHold-readDataTemp)*dicContrastHold);
                        
                        if (readDataTemp < 0) readDataTemp = 0;
                    }
                    else{
                        
                        readDataTemp = readDataTemp+(int)((readDataTemp-dicLevelHold)*dicContrastHold);
                        
                        if (readDataTemp > 255) readDataTemp = 255;
                    }
                    
                    readDataTemp2 = imageDisplayFluorescentArray [counterY][counterX];
                    
                    if (readDataTemp2 != -300){
                        if (readDataTemp2 >= 0 && readDataTemp2 < baseCut) readDataTemp2 = 0;
                        else{
                            
                            readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCut)*fluorescentEnhance);
                            
                            if (readDataTemp2 > 255) readDataTemp2 = 255;
                        }
                    }
                    
                    if (readDataTemp2 <= 0){
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = 0;
                    }
                    else{
                        
                        *bitmapData++ = 0;
                        *bitmapData++ = (unsigned char)readDataTemp2;
                        *bitmapData++ = (unsigned char)readDataTemp2;
                        *bitmapData++ = 0;
                    }
                }
            }
        }
        else if (zImageColorSet == "7"){
            for (int counterY = 0; counterY < fluorescentStitchDimension; counterY = counterY+counterIncrement){
                for (int counterX = 0; counterX < fluorescentStitchDimension; counterX = counterX+counterIncrement){
                    readDataTemp = (int)((imageDisplayBaseArray [counterY][counterX]+dicLevelHold)*(double)dicContrastHold);
                    
                    if (readDataTemp >= 0 && readDataTemp < dicLevelHold){
                        readDataTemp = readDataTemp-(int)((dicLevelHold-readDataTemp)*dicContrastHold);
                        
                        if (readDataTemp < 0) readDataTemp = 0;
                    }
                    else{
                        
                        readDataTemp = readDataTemp+(int)((readDataTemp-dicLevelHold)*dicContrastHold);
                        
                        if (readDataTemp > 255) readDataTemp = 255;
                    }
                    
                    readDataTemp2 = imageDisplayFluorescentArray [counterY][counterX];
                    
                    if (readDataTemp2 != -300){
                        if (readDataTemp2 >= 0 && readDataTemp2 < baseCut) readDataTemp2 = 0;
                        else{
                            
                            readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCut)*fluorescentEnhance);
                            
                            if (readDataTemp2 > 255) readDataTemp2 = 255;
                        }
                    }
                    
                    if (readDataTemp2 <= 0){
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = 0;
                    }
                    else{
                        
                        *bitmapData++ = (unsigned char)readDataTemp2;
                        *bitmapData++ = (unsigned char)((int)readDataTemp2*(double)0.674);
                        *bitmapData++ = 0;
                        *bitmapData++ = 0;
                    }
                }
            }
        }
        else if (zImageColorSet == "8"){
            for (int counterY = 0; counterY < fluorescentStitchDimension; counterY = counterY+counterIncrement){
                for (int counterX = 0; counterX < fluorescentStitchDimension; counterX = counterX+counterIncrement){
                    readDataTemp = (int)((imageDisplayBaseArray [counterY][counterX]+dicLevelHold)*(double)dicContrastHold);
                    
                    if (readDataTemp >= 0 && readDataTemp < dicLevelHold){
                        readDataTemp = readDataTemp-(int)((dicLevelHold-readDataTemp)*dicContrastHold);
                        
                        if (readDataTemp < 0) readDataTemp = 0;
                    }
                    else{
                        
                        readDataTemp = readDataTemp+(int)((readDataTemp-dicLevelHold)*dicContrastHold);
                        
                        if (readDataTemp > 255) readDataTemp = 255;
                    }
                    
                    readDataTemp2 = imageDisplayFluorescentArray [counterY][counterX];
                    
                    if (readDataTemp2 != -300){
                        if (readDataTemp2 >= 0 && readDataTemp2 < baseCut) readDataTemp2 = 0;
                        else{
                            
                            readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCut)*fluorescentEnhance);
                            
                            if (readDataTemp2 > 255) readDataTemp2 = 255;
                        }
                    }
                    
                    if (readDataTemp2 <= 0){
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = 0;
                    }
                    else{
                        
                        *bitmapData++ = (unsigned char)((int)readDataTemp2*(double)0.627);
                        *bitmapData++ = (unsigned char)((int)readDataTemp2*(double)0.125);
                        *bitmapData++ = (unsigned char)((int)readDataTemp2*(double)0.941);
                        *bitmapData++ = 0;
                    }
                }
            }
        }
        else if (zImageColorSet == "9"){
            for (int counterY = 0; counterY < fluorescentStitchDimension; counterY = counterY+counterIncrement){
                for (int counterX = 0; counterX < fluorescentStitchDimension; counterX = counterX+counterIncrement){
                    readDataTemp = (int)((imageDisplayBaseArray [counterY][counterX]+dicLevelHold)*(double)dicContrastHold);
                    
                    if (readDataTemp >= 0 && readDataTemp < dicLevelHold){
                        readDataTemp = readDataTemp-(int)((dicLevelHold-readDataTemp)*dicContrastHold);
                        
                        if (readDataTemp < 0) readDataTemp = 0;
                    }
                    else{
                        
                        readDataTemp = readDataTemp+(int)((readDataTemp-dicLevelHold)*dicContrastHold);
                        
                        if (readDataTemp > 255) readDataTemp = 255;
                    }
                    
                    readDataTemp2 = imageDisplayFluorescentArray [counterY][counterX];
                    
                    if (readDataTemp2 != -300){
                        if (readDataTemp2 >= 0 && readDataTemp2 < baseCut) readDataTemp2 = 0;
                        else{
                            
                            readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCut)*fluorescentEnhance);
                            
                            if (readDataTemp2 > 255) readDataTemp2 = 255;
                        }
                    }
                    
                    if (readDataTemp2 <= 0){
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = 0;
                    }
                    else{
                        
                        *bitmapData++ = (unsigned char)((int)readDataTemp2*(double)0.529);
                        *bitmapData++ = (unsigned char)((int)readDataTemp2*(double)0.808);
                        *bitmapData++ = (unsigned char)((int)readDataTemp2*(double)0.922);
                        *bitmapData++ = 0;
                    }
                }
            }
        }
        
        adjustImage = [[NSImage alloc] initWithSize:NSMakeSize(fluorescentStitchDimension, fluorescentStitchDimension)];
        [adjustImage addRepresentation:bitmapReps];
        
        progressTimingB = 2;
        
        if (imageFirstLoadFlagDisplayFluorescent == 0){
            xPositionDisplayFlu = 0;
            yPositionDisplayFlu = 0;
            xPositionAdjustDisplayFlu = 0;
            yPositionAdjustDisplayFlu = 0;
            magnificationDisplayFluorescent = 10;
            imageFirstLoadFlagDisplayFluorescent = 1;
        }
        
        //-----Re-adjust window size and position-----
        int vertical = 500+78;
        int horizontal = 500;
        
        windowWidthDisplayFlu = stitchImageDimension/(double)horizontal;
        windowHeightDisplayFlu = stitchImageDimension/(double)(vertical-78);
        
        xPositionAdjustDisplayFlu = (fluorescentStitchDimension-fluorescentStitchDimension/(double)(magnificationDisplayFluorescent*0.1))/(double)2;
        yPositionAdjustDisplayFlu = (fluorescentStitchDimension-fluorescentStitchDimension/(double)(magnificationDisplayFluorescent*0.1))/(double)2;
    }
    
    [self setNeedsDisplay:YES];
}

-(void)mouseDown:(NSEvent *)event{
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDownDisplayFlu = clickPoint.x;
        yPointDownDisplayFlu = clickPoint.y;
        
        xMovePositionHold = 0;
        yMovePositionHold = 0;
        dragHoldFlag = 0;
    }
}

-(void)mouseUp:(NSEvent *)event{
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        xPositionDisplayFlu = xPositionDisplayFlu+xPositionMoveDisplayFlu;
        yPositionDisplayFlu = yPositionDisplayFlu+yPositionMoveDisplayFlu;
        
        xPositionMoveDisplayFlu = 0;
        yPositionMoveDisplayFlu = 0;
        mouseDragFlag = 0;
        mouseDownFlag = 0;
        
        if (dragHoldFlag == 1){
            xMovePositionHoldMain = xMovePositionHold;
            yMovePositionHoldMain = yMovePositionHold;
        }
        
        [self setNeedsDisplay:YES];
    }
}

-(void)mouseDragged:(NSEvent *)event{
    if (autoProcessingFlag == 0 && imageFindFlag == 0){
        NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDragDisplayFlu = clickPoint.x;
        yPointDragDisplayFlu = clickPoint.y;
        
        if (imageMoveStatus == 0 && positionAdjustFlag == 1){
            xPositionMoveDisplayFlu = (xPointDownDisplayFlu-xPointDragDisplayFlu)*windowWidthDisplayFlu/(double)(magnificationDisplayFluorescent*0.1);
            yPositionMoveDisplayFlu = (yPointDownDisplayFlu-yPointDragDisplayFlu)*windowHeightDisplayFlu/(double)(magnificationDisplayFluorescent*0.1);
        }
        else if (imageMoveStatus == 1 && positionAdjustFlag == 1 && dragControl == 0){
            dragControl = 1;
            dragHoldFlag = 1;
            
            int xMovePosition = xMovePositionHoldMain+(int)((xPointDownDisplayFlu-xPointDragDisplayFlu)*windowWidthDisplayFlu/(double)(magnificationDisplayFluorescent*0.1));
            int yMovePosition = yMovePositionHoldMain+(int)((yPointDownDisplayFlu-yPointDragDisplayFlu)*windowHeightDisplayFlu/(double)(magnificationDisplayFluorescent*0.1));
            
            for (int counter1 = 0; counter1 < stitchImageDimension; counter1++){
                for (int counter2 = 0; counter2 < stitchImageDimension; counter2++){
                    imageDisplayFluorescentArray [counter1][counter2] = -300;
                }
            }
            
            xMovePositionHold = xMovePosition;
            yMovePositionHold = yMovePosition;
            
            int xPositionCal = 0;
            int yPositionCal = 0;
            
            for (int counter1 = 0; counter1 < loadImageFOVNo; counter1++){
                xPositionCal = arrayXYWritingPositionFluorescent [counter1*2]-xMovePosition;
                yPositionCal = arrayXYWritingPositionFluorescent [counter1*2+1]+yMovePosition;
                
                for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        if (counter2+yPositionCal >= 0 && counter2+yPositionCal < stitchImageDimension && counter3+xPositionCal >= 0 && counter3+xPositionCal < stitchImageDimension){
                            if (arrayImageDataHold [counter1*imageDimensionY+counter2][counter3] >= 0){
                                imageDisplayFluorescentArray [counter2+yPositionCal][counter3+xPositionCal] = arrayImageDataHold [counter1*imageDimensionY+counter2][counter3];
                            }
                            else imageDisplayFluorescentArray [counter2+yPositionCal][counter3+xPositionCal] = 0;
                        }
                    }
                }
            }
            
            int imageSetSize = 0;
            int counterIncrement = 0;
            
            if (fluorescentStitchDimension <= 1000){
                imageSetSize = fluorescentStitchDimension;
                counterIncrement = 1;
            }
            else if (fluorescentStitchDimension <= 4000){
                imageSetSize = fluorescentStitchDimension/2;
                counterIncrement = 2;
            }
            else{
                
                imageSetSize = fluorescentStitchDimension/4;
                counterIncrement = 4;
            }
            
            NSBitmapImageRep *bitmapReps;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize pixelsHigh:imageSetSize bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageSetSize*4 bitsPerPixel:32];
            
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            int readDataTemp = 0;
            int readDataTemp2 = 0;
            
            if (zImageColorSet == "1"){
                for (int counterY = 0; counterY < fluorescentStitchDimension; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < fluorescentStitchDimension; counterX = counterX+counterIncrement){
                        readDataTemp = imageDisplayBaseArray [counterY][counterX];
                        
                        if (readDataTemp >= 0 && readDataTemp < dicLevelHold){
                            readDataTemp = readDataTemp-(int)((dicLevelHold-readDataTemp)*dicContrastHold);
                            
                            if (readDataTemp < 0) readDataTemp = 0;
                        }
                        else{
                            
                            readDataTemp = readDataTemp+(int)((readDataTemp-dicLevelHold)*dicContrastHold);
                            
                            if (readDataTemp > 255) readDataTemp = 255;
                        }
                        
                        readDataTemp2 = imageDisplayFluorescentArray [counterY][counterX];
                        
                        if (readDataTemp2 != -300){
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCut) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCut)*fluorescentEnhance);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (zImageColorSet == "2"){
                for (int counterY = 0; counterY < fluorescentStitchDimension; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < fluorescentStitchDimension; counterX = counterX+counterIncrement){
                        readDataTemp = imageDisplayBaseArray [counterY][counterX];
                        
                        if (readDataTemp >= 0 && readDataTemp < dicLevelHold){
                            readDataTemp = readDataTemp-(int)((dicLevelHold-readDataTemp)*dicContrastHold);
                            
                            if (readDataTemp < 0) readDataTemp = 0;
                        }
                        else{
                            
                            readDataTemp = readDataTemp+(int)((readDataTemp-dicLevelHold)*dicContrastHold);
                            
                            if (readDataTemp > 255) readDataTemp = 255;
                        }
                        
                        readDataTemp2 = imageDisplayFluorescentArray [counterY][counterX];
                        
                        if (readDataTemp2 != -300){
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCut) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCut)*fluorescentEnhance);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = 0;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (zImageColorSet == "3"){
                for (int counterY = 0; counterY < fluorescentStitchDimension; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < fluorescentStitchDimension; counterX = counterX+counterIncrement){
                        readDataTemp = imageDisplayBaseArray [counterY][counterX];
                        
                        if (readDataTemp >= 0 && readDataTemp < dicLevelHold){
                            readDataTemp = readDataTemp-(int)((dicLevelHold-readDataTemp)*dicContrastHold);
                            
                            if (readDataTemp < 0) readDataTemp = 0;
                        }
                        else{
                            
                            readDataTemp = readDataTemp+(int)((readDataTemp-dicLevelHold)*dicContrastHold);
                            
                            if (readDataTemp > 255) readDataTemp = 255;
                        }
                        
                        readDataTemp2 = imageDisplayFluorescentArray [counterY][counterX];
                        
                        if (readDataTemp2 != -300){
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCut) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCut)*fluorescentEnhance);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (zImageColorSet == "4"){
                for (int counterY = 0; counterY < fluorescentStitchDimension; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < fluorescentStitchDimension; counterX = counterX+counterIncrement){
                        readDataTemp = imageDisplayBaseArray [counterY][counterX];
                        
                        if (readDataTemp >= 0 && readDataTemp < dicLevelHold){
                            readDataTemp = readDataTemp-(int)((dicLevelHold-readDataTemp)*dicContrastHold);
                            
                            if (readDataTemp < 0) readDataTemp = 0;
                        }
                        else{
                            
                            readDataTemp = readDataTemp+(int)((readDataTemp-dicLevelHold)*dicContrastHold);
                            
                            if (readDataTemp > 255) readDataTemp = 255;
                        }
                        
                        readDataTemp2 = imageDisplayFluorescentArray [counterY][counterX];
                        
                        if (readDataTemp2 != -300){
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCut) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCut)*fluorescentEnhance);
                                
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (zImageColorSet == "5"){
                for (int counterY = 0; counterY < fluorescentStitchDimension; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < fluorescentStitchDimension; counterX = counterX+counterIncrement){
                        readDataTemp = imageDisplayBaseArray [counterY][counterX];
                        
                        if (readDataTemp >= 0 && readDataTemp < dicLevelHold){
                            readDataTemp = readDataTemp-(int)((dicLevelHold-readDataTemp)*dicContrastHold);
                            
                            if (readDataTemp < 0) readDataTemp = 0;
                        }
                        else{
                            
                            readDataTemp = readDataTemp+(int)((readDataTemp-dicLevelHold)*dicContrastHold);
                            
                            if (readDataTemp > 255) readDataTemp = 255;
                        }
                        
                        readDataTemp2 = imageDisplayFluorescentArray [counterY][counterX];
                        
                        if (readDataTemp2 != -300){
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCut) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCut)*fluorescentEnhance);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (zImageColorSet == "6"){
                for (int counterY = 0; counterY < fluorescentStitchDimension; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < fluorescentStitchDimension; counterX = counterX+counterIncrement){
                        readDataTemp = imageDisplayBaseArray [counterY][counterX];
                        
                        if (readDataTemp >= 0 && readDataTemp < dicLevelHold){
                            readDataTemp = readDataTemp-(int)((dicLevelHold-readDataTemp)*dicContrastHold);
                            
                            if (readDataTemp < 0) readDataTemp = 0;
                        }
                        else{
                            
                            readDataTemp = readDataTemp+(int)((readDataTemp-dicLevelHold)*dicContrastHold);
                            
                            if (readDataTemp > 255) readDataTemp = 255;
                        }
                        
                        readDataTemp2 = imageDisplayFluorescentArray [counterY][counterX];
                        
                        if (readDataTemp2 != -300){
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCut) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCut)*fluorescentEnhance);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = 0;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (zImageColorSet == "7"){
                for (int counterY = 0; counterY < fluorescentStitchDimension; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < fluorescentStitchDimension; counterX = counterX+counterIncrement){
                        readDataTemp = imageDisplayBaseArray [counterY][counterX];
                        
                        if (readDataTemp >= 0 && readDataTemp < dicLevelHold){
                            readDataTemp = readDataTemp-(int)((dicLevelHold-readDataTemp)*dicContrastHold);
                            
                            if (readDataTemp < 0) readDataTemp = 0;
                        }
                        else{
                            
                            readDataTemp = readDataTemp+(int)((readDataTemp-dicLevelHold)*dicContrastHold);
                            
                            if (readDataTemp > 255) readDataTemp = 255;
                        }
                        
                        readDataTemp2 = imageDisplayFluorescentArray [counterY][counterX];
                        
                        if (readDataTemp2 != -300){
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCut) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCut)*fluorescentEnhance);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = (unsigned char)((int)readDataTemp2*(double)0.674);
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (zImageColorSet == "8"){
                for (int counterY = 0; counterY < fluorescentStitchDimension; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < fluorescentStitchDimension; counterX = counterX+counterIncrement){
                        readDataTemp = imageDisplayBaseArray [counterY][counterX];
                        
                        if (readDataTemp >= 0 && readDataTemp < dicLevelHold){
                            readDataTemp = readDataTemp-(int)((dicLevelHold-readDataTemp)*dicContrastHold);
                            
                            if (readDataTemp < 0) readDataTemp = 0;
                        }
                        else{
                            
                            readDataTemp = readDataTemp+(int)((readDataTemp-dicLevelHold)*dicContrastHold);
                            
                            if (readDataTemp > 255) readDataTemp = 255;
                        }
                        
                        readDataTemp2 = imageDisplayFluorescentArray [counterY][counterX];
                        
                        if (readDataTemp2 != -300){
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCut) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCut)*fluorescentEnhance);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)((int)readDataTemp2*(double)0.627);
                            *bitmapData++ = (unsigned char)((int)readDataTemp2*(double)0.125);
                            *bitmapData++ = (unsigned char)((int)readDataTemp2*(double)0.941);
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (zImageColorSet == "9"){
                for (int counterY = 0; counterY < fluorescentStitchDimension; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < fluorescentStitchDimension; counterX = counterX+counterIncrement){
                        readDataTemp = imageDisplayBaseArray [counterY][counterX];
                        
                        if (readDataTemp >= 0 && readDataTemp < dicLevelHold){
                            readDataTemp = readDataTemp-(int)((dicLevelHold-readDataTemp)*dicContrastHold);
                            
                            if (readDataTemp < 0) readDataTemp = 0;
                        }
                        else{
                            
                            readDataTemp = readDataTemp+(int)((readDataTemp-dicLevelHold)*dicContrastHold);
                            
                            if (readDataTemp > 255) readDataTemp = 255;
                        }
                        
                        readDataTemp2 = imageDisplayFluorescentArray [counterY][counterX];
                        
                        if (readDataTemp2 != -300){
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCut) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCut)*fluorescentEnhance);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)((int)readDataTemp2*(double)0.529);
                            *bitmapData++ = (unsigned char)((int)readDataTemp2*(double)0.808);
                            *bitmapData++ = (unsigned char)((int)readDataTemp2*(double)0.922);
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            
            adjustImage = [[NSImage alloc] initWithSize:NSMakeSize(fluorescentStitchDimension, fluorescentStitchDimension)];
            [adjustImage addRepresentation:bitmapReps];
        }
        
        mouseDragFlag = 1;
        
        [self setNeedsDisplay:YES];
    }
}

-(void)keyDown:(NSEvent *)event{
    int keyCode = [event keyCode];
    
    if (imageFindFlag == 0){
        //-----Magnification Magnify-----
        if (keyCode == 125){
            if (magnificationDisplayFluorescent >= 10 && magnificationDisplayFluorescent <= 490){
                if (magnificationDisplayFluorescent-10 < 10) magnificationDisplayFluorescent = 10;
                else magnificationDisplayFluorescent = magnificationDisplayFluorescent-10;
                
                xPositionAdjustDisplayFlu = -1*(fluorescentStitchDimension/(double)(magnificationDisplayFluorescent*0.1)-fluorescentStitchDimension)/(double)2;
                yPositionAdjustDisplayFlu = -1*(fluorescentStitchDimension/(double)(magnificationDisplayFluorescent*0.1)-fluorescentStitchDimension)/(double)2;
            }
            else if (magnificationDisplayFluorescent < 10) magnificationDisplayFluorescent = 10;
        }
        
        //-----Magnification Reduction-----
        if (keyCode == 126){
            if (magnificationDisplayFluorescent >= 10 && magnificationDisplayFluorescent <= 490){
                if (magnificationDisplayFluorescent+10 > 490) magnificationDisplayFluorescent = 490;
                else magnificationDisplayFluorescent = magnificationDisplayFluorescent+10;
                
                xPositionAdjustDisplayFlu = (fluorescentStitchDimension-fluorescentStitchDimension/(double)(magnificationDisplayFluorescent*0.1))/(double)2;
                yPositionAdjustDisplayFlu = (fluorescentStitchDimension-fluorescentStitchDimension/(double)(magnificationDisplayFluorescent*0.1))/(double)2;
            }
            else if (magnificationDisplayFluorescent > 490) magnificationDisplayFluorescent = 490;
        }
        
        [self setNeedsDisplay:YES];
    }
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)drawRect:(NSRect)rect{
    NSRect srcRect;
    srcRect.origin.x = xPositionDisplayFlu+xPositionAdjustDisplayFlu+xPositionMoveDisplayFlu;
    srcRect.origin.y = yPositionDisplayFlu+yPositionAdjustDisplayFlu+yPositionMoveDisplayFlu;
    srcRect.size.width = stitchImageDimension/(double)(magnificationDisplayFluorescent*0.1);
    srcRect.size.height = stitchImageDimension/(double)(magnificationDisplayFluorescent*0.1);
    
    [adjustImage drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
    
    dragControl = 0;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToFluorescentAdjust object:nil];
}

@end
