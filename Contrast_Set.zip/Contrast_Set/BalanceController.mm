//
//  BalanceController.m
//  Contrast_Set
//
//  Created by Masahiko Sato on 6/8/16.
//
//

#import "BalanceController.h"

NSString *notificationToBalanceController = @"notificationToExecuteBalanceController";

@implementation BalanceController

-(id)init{
    self = [super init];
    
    if (self != nil){
        rangeSetFlag = 0;
        backgroundLoadFlag = 0;
        
        sliderBalanceMax = 2;
        sliderBalanceMin = -2;
        sliderBalanceDiff = 4;
        
        sliderBalanceMaxHorizontal = 2;
        sliderBalanceMinHorizontal = -2;
        sliderBalanceDiffHorizontal = 4;
        
        sliderBalanceMaxVertical = 2;
        sliderBalanceMinVertical = -2;
        sliderBalanceDiffVertical = 4;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToBalanceController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    balanceWindController = [[NSWindowController alloc] initWithWindowNibName:@"BalanceSet"];
    [balanceWindController showWindow:self];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBalanceWindow object:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [balanceWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [balanceWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    string treatNameTemp2;
    string fovName2;
    string contrastDataTemp;
    string balanceExtract;
    
    int treatFind = 0;
    
    for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++){
        treatNameTemp2 = arrayTreatmentNameDisplay [counter2];
        fovName2 = arrayFOVNameDisplay [counter2];
        
        if (treatNameTemp2 == loadImageTreatName && fovName2 != "ND" && treatFind == 0){
            treatFind = 1;
            
            contrastDataTemp = arrayTableDisplay [counter2*5+2];
            balanceExtract = contrastDataTemp.substr(contrastDataTemp.find("~")+1);
        }
        else if (treatNameTemp2 == "ND" && fovName2 != "ND" && treatFind == 1){
            contrastDataTemp = arrayTableDisplay [counter2*5+2];
        }
        else if (((treatNameTemp2 != "ND" && fovName2 != "ND") || (treatNameTemp2 == "ND" && fovName2 == "ND")) && treatFind == 1){
            treatFind = 2;
        }
    }
    
    [tretmentBalance setStringValue:@(loadImageTreatName.c_str())];
    
    double rangeLimitBalance = atof(balanceExtract.c_str());
    int rangeLimitTemp = (int)(rangeLimitBalance*1000);
    double rangeLimitTemp2 = rangeLimitTemp/(double)1000;
    
    [balanceLimitDisplay setDoubleValue:rangeLimitTemp2];
    [calculationRange setStringValue:@"nil"];
    
    rangeLimitTemp = (int)(rangeLimitCurrent*1000);
    rangeLimitTemp2 = rangeLimitTemp/(double)1000;
    
    [currentLimitValue setDoubleValue:rangeLimitTemp2];
    [sliderRangeLimitKnob setDoubleValue:rangeLimitCurrent];
    
    rangeLimitTemp = (int)(rangeLimitCurrentHorizontal*1000);
    rangeLimitTemp2 = rangeLimitTemp/(double)1000;
    
    [currentLimitValueHorizontal setDoubleValue:rangeLimitTemp2];
    [sliderRangeLimitKnobHorizontal setDoubleValue:rangeLimitCurrentHorizontal];
    
    rangeLimitTemp = (int)(rangeLimitCurrentVertical*1000);
    rangeLimitTemp2 = rangeLimitTemp/(double)1000;
    
    [currentLimitValueVertical setDoubleValue:rangeLimitTemp2];
    [sliderRangeLimitKnobVertical setDoubleValue:rangeLimitCurrentVertical];
    
    balanceTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
}

-(void)display{
    if (progressTimingC == 1){
        [backSave startAnimation:self];
        
        if (backSave) progressTimingC = 0;
    }
    else if (progressTimingC == 2){
        [backSave stopAnimation:self];
        
        if (backSave) progressTimingC = 0;
    }
}

-(IBAction)sliderRangeSet:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (balanceImageLoadFlag == 1){
                if (rangeSetFlag == 1){
                    rangeLimitCurrent = [sliderRangeLimit doubleValue];
                    
                    int fovNoSend = 0;
                    correctionValues = new double [treatmentNameDisplayCount+50];
                    
                    balanceSet = [[BalanceSet alloc] init];
                    [balanceSet balanceSetMain:fovNoSend];
                    
                    for (int counter1 = 0; counter1 < stitchImageDimension; counter1++){
                        for (int counter2 = 0; counter2 < stitchImageDimension; counter2++){
                            arrayBalanceDataHold [counter1][counter2] = 100;
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < loadImageFOVNo; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                            for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                if (arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4]/(double)correctionValues [counter2+1] > 255){
                                    arrayBalanceBaseData [counter2*imageDimensionY+counter3][counter4] = 255;
                                }
                                else if (arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4]/(double)correctionValues [counter2+1] < 0){
                                    arrayBalanceBaseData [counter2*imageDimensionY+counter3][counter4] = 0;
                                }
                                else arrayBalanceBaseData [counter2*imageDimensionY+counter3][counter4] = (int)(arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4]/(double)correctionValues [counter2+1]);
                            }
                        }
                    }
                    
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                if (counter2+arrayXYWritingPosition [counter1*2+1] >= 0 && counter2+arrayXYWritingPosition [counter1*2+1] < stitchImageDimension && counter3+arrayXYWritingPosition [counter1*2] >= 0 && counter3+arrayXYWritingPosition [counter1*2] < stitchImageDimension){
                                    arrayBalanceDataHold [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = arrayBalanceBaseData [(counter1-1)*imageDimensionY+counter2][counter3];
                                }
                            }
                        }
                    }
                    
                    delete [] correctionValues;
                    
                    int rangeLimitTemp = (int)(rangeLimitCurrent*1000);
                    double rangeLimitTemp2 = rangeLimitTemp/(double)1000;
                    
                    [currentLimitValue setDoubleValue:rangeLimitTemp2];
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    backgroundLoadFlag = 0;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBalanceWindow object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Perform Calculation"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Balance Image Loaded"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderRangeSetCircle:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (balanceImageLoadFlag == 1){
                if (rangeSetFlag == 1){
                    double sliderCircleValue = sliderBalanceMax*[sliderRangeLimitCircle doubleValue];
                    double sliderCircleValue2 = sliderBalanceMin/[sliderRangeLimitCircle doubleValue];
                    double sliderValue = [sliderRangeLimit doubleValue];
                    
                    double range2 = sliderCircleValue-sliderCircleValue2;
                    range2 = range2/sliderBalanceDiff;
                    
                    sliderCircleValue = sliderValue+(sliderBalanceMax-sliderValue)/range2;
                    sliderCircleValue2 = sliderValue-(sliderValue-sliderBalanceMin)/range2;
                    
                    if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
                    
                    [sliderRangeLimit setMaxValue:sliderCircleValue];
                    [sliderRangeLimit setMinValue:sliderCircleValue2];
                    
                    int baseEnhanceInt = (int)([sliderRangeLimit doubleValue]*1000);
                    double baseEnhanceDouble = baseEnhanceInt/(double)1000;
                    
                    [currentLimitValue setDoubleValue:baseEnhanceDouble];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Perform Calculation"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Balance Image Loaded"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)saveData:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (balanceImageLoadFlag == 1){
                if (rangeSetFlag == 1){
                    string treatNameTemp2;
                    string fovName2;
                    string contrastDataTemp;
                    string extract1;
                    string extract2;
                    string fovPosition;
                    
                    if ((int)loadImageTreatName.find("CH") != -1){
                        fovPosition = loadImageTreatName.substr(loadImageTreatName.find("CH"))+"-"+to_string(currentOriginalNo);
                    }
                    else fovPosition = "FOV"+to_string(currentOriginalNo);
                    
                    stringstream extension1;
                    extension1 << rangeLimitCurrent;
                    string rangeTemp = extension1.str();
                    
                    if (rangeLimitCurrentHorizontal != 0 || rangeLimitCurrentVertical != 0){
                        stringstream extension2;
                        extension2 << rangeLimitCurrentHorizontal;
                        rangeTemp = rangeTemp+"^"+extension2.str();
                        
                        stringstream extension3;
                        extension3 << rangeLimitCurrentVertical;
                        rangeTemp = rangeTemp+"%"+extension3.str();
                    }
                    
                    int treatFind = 0;
                    
                    for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++){
                        treatNameTemp2 = arrayTreatmentNameDisplay [counter2];
                        fovName2 = arrayFOVNameDisplay [counter2];
                        
                        if (treatNameTemp2 == loadImageTreatName && fovName2 != "ND" && treatFind == 0){
                            treatFind = 1;
                            
                            contrastDataTemp = arrayTableDisplay [counter2*5+2];
                            extract1 = contrastDataTemp.substr(0, contrastDataTemp.find("~"));
                            extract1 = extract1+"~"+rangeTemp;
                            arrayTableDisplay [counter2*5+2] = extract1;
                        }
                        else if (treatNameTemp2 == "ND" && fovName2 != "ND" && treatFind == 1){
                            contrastDataTemp = arrayTableDisplay [counter2*5+2];
                            extract1 = contrastDataTemp.substr(0, contrastDataTemp.find("~"));
                            extract1 = extract1+"~"+rangeTemp;
                            arrayTableDisplay [counter2*5+2] = extract1;
                        }
                        else if (((treatNameTemp2 != "ND" && fovName2 != "ND") || (treatNameTemp2 == "ND" && fovName2 == "ND")) && treatFind == 1){
                            treatFind = 2;
                        }
                    }
                    
                    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                        contrastCurrentHold [counter1] = arrayTableDisplay [counter1*5+2];
                    }
                    
                    int rangeLimitTemp = (int)(rangeLimitCurrent*100);
                    double rangeLimitTemp2 = rangeLimitTemp/(double)100;
                    
                    [balanceLimitDisplay setDoubleValue:rangeLimitTemp2];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    tableViewCall = 1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"No Modification Have Been Made"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Balance Image Loaded"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)calcRangeLimit:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (balanceImageLoadFlag == 1){
                ifstream fin;
                
                if (processMode == 5 || processMode == 13 || processMode == 7) fin.open(fovPositionTempPath.c_str(), ios::in);
                else fin.open(fovPositionPath.c_str(), ios::in);
                
                if (fin.is_open()){
                    string getString;
                    int findDimension = 0;
                    int treatFind = 0;
                    
                    do{
                        
                        getline(fin, getString);
                        
                        if (loadImageTreatName == getString && treatFind == 0) treatFind = 1;
                        else if (getString != "ND" && treatFind == 1){
                            treatFind = 2;
                        }
                        else if (getString != "ND" && treatFind == 2){
                            findDimension = 1;
                        }
                        else if (getString == "ND" && treatFind == 2) treatFind = 3;
                        
                    } while (getString != "");
                    
                    fin.close();
                    
                    if (findDimension == 1){
                        int fovNoSend = 0;
                        rangeLimitCurrent = -1;
                        
                        correctionValues = new double [treatmentNameDisplayCount+50];
                        
                        balanceSet = [[BalanceSet alloc] init];
                        [balanceSet balanceSetMain:fovNoSend];
                        
                        for (int counter1 = 0; counter1 < stitchImageDimension; counter1++){
                            for (int counter2 = 0; counter2 < stitchImageDimension; counter2++){
                                arrayBalanceDataHold [counter1][counter2] = 100;
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < loadImageFOVNo; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                                for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                    if (arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4]/(double)correctionValues [counter2+1] > 255){
                                        arrayBalanceBaseData [counter2*imageDimensionY+counter3][counter4] = 255;
                                    }
                                    else if (arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4]/(double)correctionValues [counter2+1] < 0){
                                        arrayBalanceBaseData [counter2*imageDimensionY+counter3][counter4] = 0;
                                    }
                                    else arrayBalanceBaseData [counter2*imageDimensionY+counter3][counter4] = (int)(arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4]/(double)correctionValues [counter2+1]);
                                }
                            }
                        }
                        
                        for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                            for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                                for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                    if (counter2+arrayXYWritingPosition [counter1*2+1] >= 0 && counter2+arrayXYWritingPosition [counter1*2+1] < stitchImageDimension && counter3+arrayXYWritingPosition [counter1*2] >= 0 && counter3+arrayXYWritingPosition [counter1*2] < stitchImageDimension){
                                        arrayBalanceDataHold [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = arrayBalanceBaseData [(counter1-1)*imageDimensionY+counter2][counter3];
                                    }
                                }
                            }
                        }
                        
                        delete [] correctionValues;
                        
                        int rangeLimitTemp = (int)(rangeLimitCurrent*1000);
                        double rangeLimitTemp2 = rangeLimitTemp/(double)1000;
                        
                        [calculationRange setDoubleValue:rangeLimitTemp2];
                        [currentLimitValue setDoubleValue:rangeLimitTemp2];
                        [sliderRangeLimitKnob setDoubleValue:rangeLimitCurrent];
                        
                        rangeLimitCurrentHorizontal = 0;
                        rangeLimitCurrentVertical = 0;
                        
                        rangeLimitTemp = (int)(rangeLimitCurrentHorizontal*1000);
                        rangeLimitTemp2 = rangeLimitTemp/(double)1000;
                        
                        [currentLimitValueHorizontal setDoubleValue:rangeLimitTemp2];
                        [sliderRangeLimitKnobHorizontal setDoubleValue:rangeLimitCurrentHorizontal];
                        
                        [sliderRangeLimitHorizontal setDoubleValue:rangeLimitCurrentHorizontal];
                        [sliderRangeLimitHorizontal setMaxValue:sliderBalanceMaxHorizontal];
                        [sliderRangeLimitHorizontal setMinValue:sliderBalanceMinHorizontal];
                        
                        [sliderRangeLimitCircleHorizontal setDoubleValue:1];
                        
                        rangeLimitTemp = (int)(rangeLimitCurrentVertical*1000);
                        rangeLimitTemp2 = rangeLimitTemp/(double)1000;
                        
                        [currentLimitValueVertical setDoubleValue:rangeLimitTemp2];
                        [sliderRangeLimitKnobVertical setDoubleValue:rangeLimitCurrentVertical];
                        
                        [sliderRangeLimitVertical setDoubleValue:rangeLimitCurrentVertical];
                        [sliderRangeLimitVertical setMaxValue:sliderBalanceMaxVertical];
                        [sliderRangeLimitVertical setMinValue:sliderBalanceMinVertical];
                        
                        [sliderRangeLimitCircleVertical setDoubleValue:1];
                        
                        rangeSetFlag = 1;
                        backgroundLoadFlag = 0;
                        
                        subprocesses = [[SubProcesses alloc] init];
                        [subprocesses variableSave];
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBalanceWindow object:self];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Perform Set Condition Before Setting Balance"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Perform Set Condition Before Setting Balance"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Balance Image Loaded"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clearRangeLimit:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (balanceImageLoadFlag == 1){
                if (rangeSetFlag == 1){
                    for (int counter1 = 0; counter1 < stitchImageDimension; counter1++){
                        for (int counter2 = 0; counter2 < stitchImageDimension; counter2++){
                            arrayBalanceDataHold [counter1][counter2] = 100;
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < loadImageFOVNo; counter1++){
                        for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                            for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                if (arrayImageContrastAdjust [counter1*imageDimensionY+counter3][counter4] >= 0){
                                    arrayBalanceBaseData [counter1*imageDimensionY+counter3][counter4] = arrayImageContrastAdjust [counter1*imageDimensionY+counter3][counter4];
                                }
                                else arrayBalanceBaseData [counter1*imageDimensionY+counter3][counter4] = 0;
                                
                                arrayBalanceBaseModify [counter1*imageDimensionY+counter3][counter4] = arrayImageContrastAdjust [counter1*imageDimensionY+counter3][counter4];
                            }
                        }
                    }
                    
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                if (counter2+arrayXYWritingPosition [counter1*2+1] >= 0 && counter2+arrayXYWritingPosition [counter1*2+1] < stitchImageDimension && counter3+arrayXYWritingPosition [counter1*2] >= 0 && counter3+arrayXYWritingPosition [counter1*2] < stitchImageDimension){
                                    
                                    if (arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3] >= 0){
                                        arrayBalanceDataHold [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3];
                                    }
                                    else arrayBalanceDataHold [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = 0;
                                }
                            }
                        }
                    }
                    
                    rangeLimitCurrent = 0;
                    rangeLimitCurrentHorizontal = 0;
                    rangeLimitCurrentVertical = 0;
                    
                    sliderBalanceMax = 2;
                    sliderBalanceMin = -2;
                    sliderBalanceDiff = 4;
                    
                    sliderBalanceMaxHorizontal = 2;
                    sliderBalanceMinHorizontal = -2;
                    sliderBalanceDiffHorizontal = 4;
                    
                    sliderBalanceMaxVertical = 2;
                    sliderBalanceMinVertical = -2;
                    sliderBalanceDiffVertical = 4;
                    
                    int rangeLimitTemp = (int)(rangeLimitCurrent*1000);
                    double rangeLimitTemp2 = rangeLimitTemp/(double)1000;
                    
                    [currentLimitValue setDoubleValue:rangeLimitTemp2];
                    [sliderRangeLimitKnob setDoubleValue:rangeLimitCurrent];
                    
                    [sliderRangeLimit setDoubleValue:rangeLimitCurrent];
                    [sliderRangeLimit setMaxValue:sliderBalanceMax];
                    [sliderRangeLimit setMinValue:sliderBalanceMin];
                    
                    [sliderRangeLimitCircle setDoubleValue:1];
                    
                    rangeLimitTemp = (int)(rangeLimitCurrentHorizontal*1000);
                    rangeLimitTemp2 = rangeLimitTemp/(double)1000;
                    
                    [currentLimitValueHorizontal setDoubleValue:rangeLimitTemp2];
                    [sliderRangeLimitKnobHorizontal setDoubleValue:rangeLimitCurrentHorizontal];
                    
                    [sliderRangeLimitHorizontal setDoubleValue:rangeLimitCurrentHorizontal];
                    [sliderRangeLimitHorizontal setMaxValue:sliderBalanceMaxHorizontal];
                    [sliderRangeLimitHorizontal setMinValue:sliderBalanceMinHorizontal];
                    
                    [sliderRangeLimitCircleHorizontal setDoubleValue:1];
                    
                    rangeLimitTemp = (int)(rangeLimitCurrentVertical*1000);
                    rangeLimitTemp2 = rangeLimitTemp/(double)1000;
                    
                    [currentLimitValueVertical setDoubleValue:rangeLimitTemp2];
                    [sliderRangeLimitKnobVertical setDoubleValue:rangeLimitCurrentVertical];
                    
                    [sliderRangeLimitVertical setDoubleValue:rangeLimitCurrentVertical];
                    [sliderRangeLimitVertical setMaxValue:sliderBalanceMaxVertical];
                    [sliderRangeLimitVertical setMinValue:sliderBalanceMinVertical];
                    
                    [sliderRangeLimitCircleVertical setDoubleValue:1];
                    
                    backgroundLoadFlag = 0;
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBalanceWindow object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Perform Calculation"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Balance Image Loaded"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageLoad:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            for (int counter1 = 0; counter1 < stitchImageDimension; counter1++){
                for (int counter2 = 0; counter2 < stitchImageDimension; counter2++){
                    arrayBalanceDataHold [counter1][counter2] = 100;
                }
            }
            
            for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                    for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                        if (counter2+arrayXYWritingPosition [counter1*2+1] >= 0 && counter2+arrayXYWritingPosition [counter1*2+1] < stitchImageDimension && counter3+arrayXYWritingPosition [counter1*2] >= 0 && counter3+arrayXYWritingPosition [counter1*2] < stitchImageDimension){
                            if (arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3] >= 0){
                                arrayBalanceDataHold [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3];
                            }
                            else arrayBalanceDataHold [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = 0;
                        }
                    }
                }
            }
            
            string treatNameTemp2;
            string fovName2;
            string contrastDataTemp;
            string balanceExtract;
            
            int treatFind = 0;
            
            for (int counter2 = 1; counter2 < treatmentNameDisplayCount; counter2++){
                treatNameTemp2 = arrayTreatmentNameDisplay [counter2];
                fovName2 = arrayFOVNameDisplay [counter2];
                
                if (treatNameTemp2 == loadImageTreatName && fovName2 != "ND" && treatFind == 0){
                    treatFind = 1;
                    
                    contrastDataTemp = arrayTableDisplay [counter2*5+2];
                    balanceExtract = contrastDataTemp.substr(contrastDataTemp.find("~")+1);
                }
                else if (treatNameTemp2 == "ND" && fovName2 != "ND" && treatFind == 1){
                    contrastDataTemp = arrayTableDisplay [counter2*5+2];
                    balanceExtract = contrastDataTemp.substr(contrastDataTemp.find("~")+1);
                }
                else if (((treatNameTemp2 != "ND" && fovName2 != "ND") || (treatNameTemp2 == "ND" && fovName2 == "ND")) && treatFind == 1){
                    treatFind = 2;
                }
            }
            
            balanceImageLoadFlag = 1;
            
            [tretmentBalance setStringValue:@(loadImageTreatName.c_str())];
            
            double rangeLimitBalance = atof(balanceExtract.c_str());
            int rangeLimitTemp = (int)(rangeLimitBalance*1000);
            double rangeLimitTemp2 = rangeLimitTemp/(double)1000;
            
            [balanceLimitDisplay setDoubleValue:rangeLimitTemp2];
            [calculationRange setStringValue:@"nil"];
            
            rangeLimitCurrent = 0;
            rangeLimitCurrentHorizontal = 0;
            rangeLimitCurrentVertical = 0;
            
            sliderBalanceMax = 2;
            sliderBalanceMin = -2;
            sliderBalanceDiff = 4;
            
            sliderBalanceMaxHorizontal = 2;
            sliderBalanceMinHorizontal = -2;
            sliderBalanceDiffHorizontal = 4;
            
            sliderBalanceMaxVertical = 2;
            sliderBalanceMinVertical = -2;
            sliderBalanceDiffVertical = 4;
            
            rangeLimitTemp = (int)(rangeLimitCurrent*1000);
            rangeLimitTemp2 = rangeLimitTemp/(double)1000;
            
            [currentLimitValue setDoubleValue:rangeLimitTemp2];
            [sliderRangeLimitKnob setDoubleValue:rangeLimitCurrent];
            
            rangeLimitTemp = (int)(rangeLimitCurrentHorizontal*1000);
            rangeLimitTemp2 = rangeLimitTemp/(double)1000;
            
            [currentLimitValueHorizontal setDoubleValue:rangeLimitTemp2];
            [sliderRangeLimitKnobHorizontal setDoubleValue:rangeLimitCurrentHorizontal];
            
            rangeLimitTemp = (int)(rangeLimitCurrentVertical*1000);
            rangeLimitTemp2 = rangeLimitTemp/(double)1000;
            
            [currentLimitValueVertical setDoubleValue:rangeLimitTemp2];
            [sliderRangeLimitKnobVertical setDoubleValue:rangeLimitCurrentVertical];
            
            subprocesses = [[SubProcesses alloc] init];
            [subprocesses variableSave];
            
            rangeSetFlag = 0;
            backgroundLoadFlag = 0;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBalanceWindow object:self];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)backgroundLoad:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (balanceImageLoadFlag == 1){
                if (rangeSetFlag == 1){
                    if (backgroundOADisplay == "Off"){
                        int bcType = 3;
                        int fovNoSend = 0;
                        
                        progressTimingC = 1;
                        
                        backgroundCorrection = [[BackgroundCorrection alloc] init];
                        [backgroundCorrection backgroundImageSub:bcType:fovNoSend:imageDimensionX:imageDimensionY];
                        
                        for (int counter1 = 0; counter1 < stitchImageDimension; counter1++){
                            for (int counter2 = 0; counter2 < stitchImageDimension; counter2++){
                                arrayBalanceDataHold [counter1][counter2] = 100;
                            }
                        }
                        
                        for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                            for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                                for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                    if (counter2+arrayXYWritingPosition [counter1*2+1] >= 0 && counter2+arrayXYWritingPosition [counter1*2+1] < stitchImageDimension && counter3+arrayXYWritingPosition [counter1*2] >= 0 && counter3+arrayXYWritingPosition [counter1*2] < stitchImageDimension){
                                        arrayBalanceDataHold [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = arrayBackgroundDataHold2 [(counter1-1)*imageDimensionY+counter2][counter3];
                                    }
                                }
                            }
                        }
                        
                        backgroundLoadFlag = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        progressTimingC = 2;
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBalanceWindow object:self];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Turn Off Background Mode To Proceed correction"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Perform Calculation"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Balance Image Loaded"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderRangeHorizontalSet:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (balanceImageLoadFlag == 1){
                if (rangeSetFlag == 1 && rangeLimitCurrent != 0){
                    rangeLimitCurrentHorizontal = [sliderRangeLimitHorizontal doubleValue];
                    
                    int fovNoSend = 0;
                    correctionValues = new double [treatmentNameDisplayCount+50];
                    
                    balanceSet = [[BalanceSet alloc] init];
                    [balanceSet balanceSetMain:fovNoSend];
                    
                    for (int counter1 = 0; counter1 < stitchImageDimension; counter1++){
                        for (int counter2 = 0; counter2 < stitchImageDimension; counter2++){
                            arrayBalanceDataHold [counter1][counter2] = 100;
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < loadImageFOVNo; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                            for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                if (arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4]/(double)correctionValues [counter2+1] > 255){
                                    arrayBalanceBaseData [counter2*imageDimensionY+counter3][counter4] = 255;
                                }
                                else if (arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4]/(double)correctionValues [counter2+1] < 0){
                                    arrayBalanceBaseData [counter2*imageDimensionY+counter3][counter4] = 0;
                                }
                                else arrayBalanceBaseData [counter2*imageDimensionY+counter3][counter4] = (int)(arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4]/(double)correctionValues [counter2+1]);
                            }
                        }
                    }
                    
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                if (counter2+arrayXYWritingPosition [counter1*2+1] >= 0 && counter2+arrayXYWritingPosition [counter1*2+1] < stitchImageDimension && counter3+arrayXYWritingPosition [counter1*2] >= 0 && counter3+arrayXYWritingPosition [counter1*2] < stitchImageDimension){
                                    arrayBalanceDataHold [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = arrayBalanceBaseData [(counter1-1)*imageDimensionY+counter2][counter3];
                                }
                            }
                        }
                    }
                    
                    delete [] correctionValues;
                    
                    int rangeLimitTemp = (int)(rangeLimitCurrentHorizontal*1000);
                    double rangeLimitTemp2 = rangeLimitTemp/(double)1000;
                    
                    [currentLimitValueHorizontal setDoubleValue:rangeLimitTemp2];
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    backgroundLoadFlag = 0;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBalanceWindow object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Perform Calculation/No. Of FOV < 9"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Balance Image Loaded"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderRangeSetHorizontalCircle:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (balanceImageLoadFlag == 1){
                if (rangeSetFlag == 1 && rangeLimitCurrent != 0){
                    double sliderCircleValue = sliderBalanceMaxVertical*[sliderRangeLimitCircleHorizontal doubleValue];
                    double sliderCircleValue2 = sliderBalanceMinVertical/[sliderRangeLimitCircleHorizontal doubleValue];
                    double sliderValue = [sliderRangeLimitHorizontal doubleValue];
                    
                    double range2 = sliderCircleValue-sliderCircleValue2;
                    range2 = range2/sliderBalanceDiffHorizontal;
                    
                    sliderCircleValue = sliderValue+(sliderBalanceMaxHorizontal-sliderValue)/range2;
                    sliderCircleValue2 = sliderValue-(sliderValue-sliderBalanceMinHorizontal)/range2;
                    
                    if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
                    
                    [sliderRangeLimitHorizontal setMaxValue:sliderCircleValue];
                    [sliderRangeLimitHorizontal setMinValue:sliderCircleValue2];
                    
                    int baseEnhanceInt = (int)([sliderRangeLimitHorizontal doubleValue]*1000);
                    double baseEnhanceDouble = baseEnhanceInt/(double)1000;
                    
                    [currentLimitValueHorizontal setDoubleValue:baseEnhanceDouble];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Perform Calculation/No. Of FOV < 9"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Balance Image Loaded"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clearHorizontalRangeLimit:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (balanceImageLoadFlag == 1){
                if (rangeSetFlag == 1 && rangeLimitCurrent != 0){
                    for (int counter1 = 0; counter1 < stitchImageDimension; counter1++){
                        for (int counter2 = 0; counter2 < stitchImageDimension; counter2++){
                            arrayBalanceDataHold [counter1][counter2] = 100;
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < loadImageFOVNo; counter1++){
                        for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                            for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                if (arrayImageContrastAdjust [counter1*imageDimensionY+counter3][counter4] >= 0){
                                    arrayBalanceBaseData [counter1*imageDimensionY+counter3][counter4] = arrayImageContrastAdjust [counter1*imageDimensionY+counter3][counter4];
                                }
                                else arrayBalanceBaseData [counter1*imageDimensionY+counter3][counter4] = 0;
                                
                                arrayBalanceBaseModify [counter1*imageDimensionY+counter3][counter4] = arrayImageContrastAdjust [counter1*imageDimensionY+counter3][counter4];
                            }
                        }
                    }
                    
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                if (counter2+arrayXYWritingPosition [counter1*2+1] >= 0 && counter2+arrayXYWritingPosition [counter1*2+1] < stitchImageDimension && counter3+arrayXYWritingPosition [counter1*2] >= 0 && counter3+arrayXYWritingPosition [counter1*2] < stitchImageDimension){
                                    if (arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3] >= 0){
                                        arrayBalanceDataHold [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3];
                                    }
                                    else arrayBalanceDataHold [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = 0;
                                }
                            }
                        }
                    }
                    
                    rangeLimitCurrentHorizontal = 0;
                    
                    sliderBalanceMaxHorizontal = 2;
                    sliderBalanceMinHorizontal = -2;
                    sliderBalanceDiffHorizontal = 4;
                    
                    int rangeLimitTemp = (int)(rangeLimitCurrentHorizontal*1000);
                    double rangeLimitTemp2 = rangeLimitTemp/(double)1000;
                    
                    [currentLimitValueHorizontal setDoubleValue:rangeLimitTemp2];
                    [sliderRangeLimitKnobHorizontal setDoubleValue:rangeLimitCurrentHorizontal];
                    
                    [sliderRangeLimitHorizontal setDoubleValue:rangeLimitCurrentHorizontal];
                    [sliderRangeLimitHorizontal setMaxValue:sliderBalanceMaxHorizontal];
                    [sliderRangeLimitHorizontal setMinValue:sliderBalanceMinHorizontal];
                    
                    [sliderRangeLimitCircleHorizontal setDoubleValue:1];
                    
                    backgroundLoadFlag = 0;
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBalanceWindow object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Perform Calculation/No. Of FOV < 9"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Balance Image Loaded"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderRangeVerticalSet:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (balanceImageLoadFlag == 1){
                if (rangeSetFlag == 1 && rangeLimitCurrent != 0){
                    rangeLimitCurrentVertical = [sliderRangeLimitVertical doubleValue];
                    
                    int fovNoSend = 0;
                    correctionValues = new double [treatmentNameDisplayCount+50];
                    
                    balanceSet = [[BalanceSet alloc] init];
                    [balanceSet balanceSetMain:fovNoSend];
                    
                    for (int counter1 = 0; counter1 < stitchImageDimension; counter1++){
                        for (int counter2 = 0; counter2 < stitchImageDimension; counter2++){
                            arrayBalanceDataHold [counter1][counter2] = 100;
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < loadImageFOVNo; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                            for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                if (arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4]/(double)correctionValues [counter2+1] > 255){
                                    arrayBalanceBaseData [counter2*imageDimensionY+counter3][counter4] = 255;
                                }
                                else if (arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4]/(double)correctionValues [counter2+1] < 0){
                                    arrayBalanceBaseData [counter2*imageDimensionY+counter3][counter4] = 0;
                                }
                                else arrayBalanceBaseData [counter2*imageDimensionY+counter3][counter4] = (int)(arrayImageContrastAdjust [counter2*imageDimensionY+counter3][counter4]/(double)correctionValues [counter2+1]);
                            }
                        }
                    }
                    
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                if (counter2+arrayXYWritingPosition [counter1*2+1] >= 0 && counter2+arrayXYWritingPosition [counter1*2+1] < stitchImageDimension && counter3+arrayXYWritingPosition [counter1*2] >= 0 && counter3+arrayXYWritingPosition [counter1*2] < stitchImageDimension){
                                    arrayBalanceDataHold [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = arrayBalanceBaseData [(counter1-1)*imageDimensionY+counter2][counter3];
                                }
                            }
                        }
                    }
                    
                    delete [] correctionValues;
                    
                    int rangeLimitTemp = (int)(rangeLimitCurrentVertical*1000);
                    double rangeLimitTemp2 = rangeLimitTemp/(double)1000;
                    
                    [currentLimitValueVertical setDoubleValue:rangeLimitTemp2];
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    backgroundLoadFlag = 0;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBalanceWindow object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Perform Calculation/No. Of FOV < 9"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Balance Image Loaded"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderRangeSetVerticalCircle:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (balanceImageLoadFlag == 1){
                if (rangeSetFlag == 1 && rangeLimitCurrent != 0){
                    double sliderCircleValue = sliderBalanceMaxVertical*[sliderRangeLimitCircleVertical doubleValue];
                    double sliderCircleValue2 = sliderBalanceMinVertical/[sliderRangeLimitCircleVertical doubleValue];
                    double sliderValue = [sliderRangeLimitVertical doubleValue];
                    
                    double range2 = sliderCircleValue-sliderCircleValue2;
                    range2 = range2/sliderBalanceDiffVertical;
                    
                    sliderCircleValue = sliderValue+(sliderBalanceMaxVertical-sliderValue)/range2;
                    sliderCircleValue2 = sliderValue-(sliderValue-sliderBalanceMinVertical)/range2;
                    
                    if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
                    
                    [sliderRangeLimitVertical setMaxValue:sliderCircleValue];
                    [sliderRangeLimitVertical setMinValue:sliderCircleValue2];
                    
                    int baseEnhanceInt = (int)([sliderRangeLimitVertical doubleValue]*1000);
                    double baseEnhanceDouble = baseEnhanceInt/(double)1000;
                    
                    [currentLimitValueVertical setDoubleValue:baseEnhanceDouble];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Perform Calculation/No. Of FOV < 9"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Balance Image Loaded"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clearVerticalRangeLimit:(id)sender{
    if (loadImageTreatName != ""){
        if (autoProcessingFlag == 0 && imageFindFlag == 0){
            if (balanceImageLoadFlag == 1){
                if (rangeSetFlag == 1 && rangeLimitCurrent != 0){
                    for (int counter1 = 0; counter1 < stitchImageDimension; counter1++){
                        for (int counter2 = 0; counter2 < stitchImageDimension; counter2++){
                            arrayBalanceDataHold [counter1][counter2] = 100;
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < loadImageFOVNo; counter1++){
                        for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
                            for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
                                arrayBalanceBaseData [counter1*imageDimensionY+counter3][counter4] = arrayImageContrastAdjust [counter1*imageDimensionY+counter3][counter4];
                                arrayBalanceBaseModify [counter1*imageDimensionY+counter3][counter4] = arrayImageContrastAdjust [counter1*imageDimensionY+counter3][counter4];
                            }
                        }
                    }
                    
                    for (int counter1 = 1; counter1 <= loadImageFOVNo; counter1++){
                        for (int counter2 = imageDimensionY-1; counter2 >= 0; counter2--){
                            for (int counter3 = 0; counter3 < imageDimensionX; counter3++){
                                if (counter2+arrayXYWritingPosition [counter1*2+1] >= 0 && counter2+arrayXYWritingPosition [counter1*2+1] < stitchImageDimension && counter3+arrayXYWritingPosition [counter1*2] >= 0 && counter3+arrayXYWritingPosition [counter1*2] < stitchImageDimension){
                                    if (arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3] >= 0){
                                        arrayBalanceDataHold [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = arrayImageContrastAdjust [(counter1-1)*imageDimensionY+counter2][counter3];
                                    }
                                    else arrayBalanceDataHold [counter2+arrayXYWritingPosition [counter1*2+1]][counter3+arrayXYWritingPosition [counter1*2]] = 0;
                                }
                            }
                        }
                    }
                    
                    rangeLimitCurrentVertical = 0;
                    
                    sliderBalanceMaxVertical = 2;
                    sliderBalanceMinVertical = -2;
                    sliderBalanceDiffVertical = 4;
                    
                    int rangeLimitTemp = (int)(rangeLimitCurrentVertical*1000);
                    double rangeLimitTemp2 = rangeLimitTemp/(double)1000;
                    
                    [currentLimitValueVertical setDoubleValue:rangeLimitTemp2];
                    [sliderRangeLimitKnobVertical setDoubleValue:rangeLimitCurrentVertical];
                    
                    [sliderRangeLimitVertical setDoubleValue:rangeLimitCurrentVertical];
                    [sliderRangeLimitVertical setMaxValue:sliderBalanceMaxVertical];
                    [sliderRangeLimitVertical setMinValue:sliderBalanceMinVertical];
                    
                    [sliderRangeLimitCircleVertical setDoubleValue:1];
                    
                    backgroundLoadFlag = 0;
                    
                    subprocesses = [[SubProcesses alloc] init];
                    [subprocesses variableSave];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBalanceWindow object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Perform Calculation/No. Of FOV < 9"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Balance Image Loaded"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Treatment Not Selected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)closeWindow:(id)sender{
    [balanceWindow orderOut:self];
    positionBalanceOperation = 2;
    balanceTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (positionBalanceOperation == 3){
        [balanceWindow makeKeyAndOrderFront:self];
        positionBalanceOperation = 1;
        [balanceTimer invalidate];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToBalanceController object:nil];
    if (balanceTimer) [balanceTimer invalidate];
    if (balanceTimer2) [balanceTimer2 invalidate];
}

@end
