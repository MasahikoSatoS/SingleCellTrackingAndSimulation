//
//  IFReloadOperation.m
//  Contrast_Set
//
//  Created by Masahiko Sato on 11/17/16.
//
//

#import "IFReloadOperation.h"

NSString *notificationToIFReloadOperation = @"notificationToIFReloadOperation";

@implementation IFReloadOperation

-(id)init{
    self = [super init];
    
    if (self != nil){
        tableCallReloadCount = 0;
        rowIndexHoldReload = 0;
        tableCurrentRowHoldReload = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToIFReloadOperation object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    string sourceBodyName = bodyName.substr(0, bodyName.length()-(unsigned long)2);
    string productsFilesInfoPathIF = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+sourceBodyName+"_Products";
    
    ifReloadCount = 0;
    
    if (ifReloadStatus == 0){
        ifReloadStatus = 1;
        arrayIfReload = new int [100];
    }
    
    DIR *dir;
    struct dirent *dent;
    
    string entry;
    
    dir = opendir(productsFilesInfoPathIF.c_str());
    
    if (dir != NULL){
        while ((dent = readdir(dir))){
            entry = dent -> d_name;
            
            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                if (entry.substr(0, 2) == "IF"){
                    
                    if (ifReloadCount < 100) arrayIfReload [ifReloadCount] = atoi(entry.substr(2, 2).c_str()), ifReloadCount++;
                }
            }
        }
        
        closedir(dir);
    }
    
    [timeViewReload setDataSource:self];
    [timeViewReload reloadData];
    
    reLoadOperationTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
}

-(void)display{
    //-----Table View for search-----
    if (tableCallReloadCount == 1){
        tableCallReloadCount = 0;
        rowIndexHoldReload = tableCurrentRowHoldReload;
    }
    
    if (tableCallReloadCount > 1) tableCallReloadCount = 0;
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = ifReloadCount;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    string displayData1 = "IF Round "+to_string(arrayIfReload [rowIndex]);
    
    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
    [attributes setObject:[NSFont boldSystemFontOfSize:10] forKey:NSFontAttributeName];
    
    if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
    }
    else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    tableCallReloadCount++;
    tableCurrentRowHoldReload = rowIndex;
    
    if (tableCallReloadCount == 2){
        if (autoProcessingFlag == 0){
            tableCurrentRowHoldReload = rowIndexHoldReload;
            [timeViewReload reloadData];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (autoProcessingFlag == 0){
            tableCurrentRowHoldReload = rowIndex;
            [timeViewReload reloadData];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Image. Please Wait"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    
    return YES;
}

-(IBAction)setContrastData:(id)sender{
    if (autoProcessingFlag == 0){
        if (ifReloadCount != 0){
            string roundNo = "";
            
            if (arrayIfReload [tableCurrentRowHoldReload] < 10) roundNo = "0"+to_string(arrayIfReload [tableCurrentRowHoldReload]);
            else roundNo = to_string(arrayIfReload [tableCurrentRowHoldReload]);
            
            string sourceBodyName = bodyName.substr(0, bodyName.length()-(unsigned long)2);
            string focalPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+sourceBodyName+"_Products/"+"IF"+roundNo+"_Analysis_Information/CT-ContrastData";
            string focalPathG = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+sourceBodyName+"_Products/"+"IF"+roundNo+"_Analysis_Information/CT-ContrastDataG";
            string focalPathB = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+sourceBodyName+"_Products/"+"IF"+roundNo+"_Analysis_Information/CT-ContrastDataB";
            
            ifstream fin;
            
            string currentTimePath;
            string getString;
            
            for (int counter1 = 0; counter1 < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100; counter1++){
                delete [] arrayContrastData [counter1];
                delete [] arrayContrastDataG [counter1];
                delete [] arrayContrastDataB [counter1];
            }
            
            delete [] arrayContrastData;
            delete [] arrayContrastDataG;
            delete [] arrayContrastDataB;
            
            int entryCount = 0;
            
            fin.open(focalPath.c_str(), ios::in);
            
            if (fin.is_open()){
                do{
                    
                    getline(fin, getString);
                    
                    if ((int)getString.find("T") != -1) entryCount++;
                    
                } while (getString != "");
                
                fin.close();
            }
            
            entryNumber = 1;
            contrastDataEntry = entryNumber+50;
            
            arrayContrastData = new string *[totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
            arrayContrastDataG = new string *[totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
            arrayContrastDataB = new string *[totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
            
            contrastDataLimit = entryNumber+50;
            
            for (int counter1 = 0; counter1 < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100; counter1++){
                arrayContrastData [counter1] = new string [entryNumber+50];
                arrayContrastDataG [counter1] = new string [entryNumber+50];
                arrayContrastDataB [counter1] = new string [entryNumber+50];
            }
            
            string **contrastTemp = new string *[totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
            for (int counter1 = 0; counter1 < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100; counter1++) contrastTemp [counter1] = new string [entryCount+50];
            
            int lineCount = 0;
            int rgbCheck = 0;
            
            fin.open(focalPath.c_str(), ios::in);
            
            if (fin.is_open()){
                do{
                    
                    getline(fin, getString);
                    
                    if (getString != ""){
                        contrastTemp [lineCount][0] = "0";
                        getline(fin, getString);
                        contrastTemp [lineCount][1] = "0";
                        getline(fin, getString);
                        contrastTemp [lineCount][2] = "0";
                        
                        for (int counter1 = 0; counter1 < entryCount; counter1++) getline(fin, getString), contrastTemp [lineCount][counter1+3] = getString;
                        
                        lineCount++;
                    }
                    
                } while (getString != "");
                
                fin.close();
                
                for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                    for (int counter2 = 0; counter2 < entryNumber+3; counter2++){
                        arrayContrastData [counter1][counter2] = contrastTemp [counter1][counter2];
                    }
                }
            }
            
            fin.open(focalPathG.c_str(), ios::in);
            
            if (fin.is_open()){
                lineCount = 0;
                rgbCheck = 1;
                
                do{
                    
                    getline(fin, getString);
                    
                    if (getString != ""){
                        contrastTemp [lineCount][0] = "0";
                        getline(fin, getString);
                        contrastTemp [lineCount][1] = "0";
                        getline(fin, getString);
                        contrastTemp [lineCount][2] = "0";
                        
                        for (int counter1 = 0; counter1 < entryCount; counter1++) getline(fin, getString), contrastTemp [lineCount][counter1+3] = getString;
                        
                        lineCount++;
                    }
                    
                } while (getString != "");
                
                fin.close();
                
                for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                    for (int counter2 = 0; counter2 < entryNumber+3; counter2++){
                        arrayContrastDataG [counter1][counter2] = contrastTemp [counter1][counter2];
                    }
                }
            }
            
            fin.open(focalPathB.c_str(), ios::in);
            
            if (fin.is_open()){
                lineCount = 0;
                
                do{
                    
                    getline(fin, getString);
                    
                    if (getString != ""){
                        contrastTemp [lineCount][0] = "0";
                        getline(fin, getString);
                        contrastTemp [lineCount][1] = "0";
                        getline(fin, getString);
                        contrastTemp [lineCount][2] = "0";
                        
                        for (int counter1 = 0; counter1 < entryCount; counter1++) getline(fin, getString), contrastTemp [lineCount][counter1+3] = getString;
                        
                        lineCount++;
                    }
                    
                } while (getString != "");
                
                fin.close();
                
                for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                    for (int counter2 = 0; counter2 < entryNumber+3; counter2++){
                        arrayContrastDataB [counter1][counter2] = contrastTemp [counter1][counter2];
                    }
                }
            }
            
            for (int counter1 = 0; counter1 < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100; counter1++){
                delete [] contrastTemp [counter1];
            }
            
            delete [] contrastTemp;
            
            int xBlockNo = 1;
            int yBlockNo = 1;
            
            if (imageDimensionX > 0) xBlockNo = imageDimensionX/8;
            if (imageDimensionY > 0) yBlockNo = imageDimensionY/8;
            
            int backgroundPageMax = backgroundPatternArrayCount/(xBlockNo*yBlockNo);
            string contrastDataTemp;
            string bkNumberExtract;
            string bkNumberFront;
            string bkNumberBack;
            
            for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                for (int counter3 = 0; counter3 < entryNumber+3; counter3++){
                    if (arrayContrastData [counter2][counter3] != ""){
                        contrastDataTemp = arrayContrastData [counter2][counter3];
                        
                        if ((int)contrastDataTemp.find(":") != -1 && (int)contrastDataTemp.find("~") != -1){
                            bkNumberExtract = contrastDataTemp.substr(contrastDataTemp.find(":")+1, contrastDataTemp.find("~")-contrastDataTemp.find(":")-1);
                            
                            if (atoi(bkNumberExtract.c_str()) > backgroundPageMax){
                                bkNumberFront = contrastDataTemp.substr(0, contrastDataTemp.find(":")+1);
                                bkNumberBack = contrastDataTemp.substr(contrastDataTemp.find("~"));
                                arrayContrastData [counter2][counter3] = bkNumberFront+"0"+bkNumberBack;
                            }
                        }
                    }
                }
            }
            
            if (photoMetricHold == 2){
                for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                    for (int counter3 = 0; counter3 < entryNumber+3; counter3++){
                        if (arrayContrastDataG [counter2][counter3] != ""){
                            contrastDataTemp = arrayContrastDataG [counter2][counter3];
                            
                            if ((int)contrastDataTemp.find(":") != -1 && (int)contrastDataTemp.find("~") != -1){
                                bkNumberExtract = contrastDataTemp.substr(contrastDataTemp.find(":")+1, contrastDataTemp.find("~")-contrastDataTemp.find(":")-1);
                                
                                if (atoi(bkNumberExtract.c_str()) > backgroundPageMax){
                                    bkNumberFront = contrastDataTemp.substr(0, contrastDataTemp.find(":")+1);
                                    bkNumberBack = contrastDataTemp.substr(contrastDataTemp.find("~"));
                                    arrayContrastDataG [counter2][counter3] = bkNumberFront+"0"+bkNumberBack;
                                }
                            }
                        }
                    }
                }
                
                for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                    for (int counter3 = 0; counter3 < entryNumber+3; counter3++){
                        if (arrayContrastDataB [counter2][counter3] != ""){
                            contrastDataTemp = arrayContrastDataB [counter2][counter3];
                            
                            if ((int)contrastDataTemp.find(":") != -1 && (int)contrastDataTemp.find("~") != -1){
                                bkNumberExtract = contrastDataTemp.substr(contrastDataTemp.find(":")+1, contrastDataTemp.find("~")-contrastDataTemp.find(":")-1);
                                
                                if (atoi(bkNumberExtract.c_str()) > backgroundPageMax){
                                    bkNumberFront = contrastDataTemp.substr(0, contrastDataTemp.find(":")+1);
                                    bkNumberBack = contrastDataTemp.substr(contrastDataTemp.find("~"));
                                    arrayContrastDataB [counter2][counter3] = bkNumberFront+"0"+bkNumberBack;
                                }
                            }
                        }
                    }
                }
            }
            
            //-----Table Set-----
            int startingTimePoint = 1;
            
            tableDisplayCount = 0;
            tableDisplayCountG = 0;
            tableDisplayCountB = 0;
            
            string timeDetermine;
            
            for (int counter1 = 1; counter1 <= entryNumber; counter1++){
                timeDetermine = arrayContrastData [0][counter1+2];
                timeDetermine = timeDetermine.substr(1);
                
                if (atoi(timeDetermine.c_str()) < currentTimePoint+1) startingTimePoint = counter1;
            }
            
            int mode = 1;
            
            subprocesses = [[SubProcesses alloc] init];
            [subprocesses displayTableSetInit:startingTimePoint:rgbCheck:mode];
            
            tableViewCall = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Empty"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Processing Image. Please Wait"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToIFReloadOperation object:nil];
}

@end
