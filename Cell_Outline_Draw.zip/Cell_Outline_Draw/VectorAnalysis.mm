//
// VectorAnalysis.mm
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 11/11/09.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#import "VectorAnalysis.h"

@implementation VectorAnalysis

-(void)vectorAngle:(int)arrayNumber{
    //------Data loading, determine largestVectorNumber, positionNumber [*][5] is for processing flag------
    int *positionNumber = new int [vectorSegmentationCount/5*6+50];
    
    double *lengthAngle = new double [vectorSegmentationCount/5*2+50];
    
    int largestVectorNumber = 0;
    
    for (int counter1 = 0; counter1 < vectorSegmentationCount/5; counter1++){
        positionNumber [counter1*6] = arrayVectorSegmentation [counter1*5];
        positionNumber [counter1*6+1] = arrayVectorSegmentation [counter1*5+1];
        positionNumber [counter1*6+2] = arrayVectorSegmentation [counter1*5+2];
        positionNumber [counter1*6+3] = arrayVectorSegmentation [counter1*5+3];
        positionNumber [counter1*6+4] = arrayVectorSegmentation [counter1*5+4];
        positionNumber [counter1*6+5] = 0;
        
        if (positionNumber [counter1*6] > largestVectorNumber) largestVectorNumber = positionNumber [counter1*6];
    }
    
    for (int counter1 = 0; counter1 < vectorSegmentationCount/5; counter1++){
        lengthAngle [counter1*2] = arrayVectorSegmentationLength [counter1*2];
        lengthAngle [counter1*2+1] = arrayVectorSegmentationLength [counter1*2+1];
    }
    
    //------Exclude if the number of points is less than 4, then check the angle of outline vectors. if the angle is +- 20 of next outline vector, combined both vector------
    int *numberOfVector = new int [largestVectorNumber+2];
    
    for (int counter1 = 0; counter1 <= largestVectorNumber; counter1++) numberOfVector [counter1] = 0;
    
    int *arrayRelationShip = new int [5000];
    int relationShipCount = 0;
    int relationShipLimit = 5000;
    double *arrayRelationShip2 = new double [2500];
    int relationShipCount2 = 0;
    int relationShipLimit2 = 2500;
    
    int vectorNumber = 0;
    int pointCount = 0;
    int terminationFlag = 0;
    int terminationFlag2 = 0;
    int longestLineNumber = 0;
    int startLongestX = 0;
    int startLongestY = 0;
    int endLongestX = 0;
    int endLongestY = 0;
    int countNumber = 0;
    int extensionFindFlag = 0;
    int caseType = 0;
    int caseType2 = 0;
    int startXAd = 0;
    int startYAd = 0;
    int endXAd = 0;
    int endYAd = 0;
    int valueXRefAd1 = 0;
    int valueYRefAd1 = 0;
    int valueXRefAd2 = 0;
    int valueYRefAd2 = 0;
    int overlapFlag = 0;
    
    double angleLongest = 0;
    double angleSubject = 0;
    double angleExtension = 0;
    double angleCompare = 0;
    double cutOff1 = 0;
    double cutOff2 = 0;
    double cutOff3 = 0;
    double cutOff4 = 0;
    double cutOff5 = 0;
    double constA = 0;
    double constB = 0;
    double distanceAd = 0;
    double crossX1 = 0;
    double crossY1 = 0;
    double crossX2 = 0;
    double crossY2 = 0;
    double percentOverlap = 0;
    
    for (int counter1 = 0; counter1 < largestVectorNumber; counter1++){
        vectorNumber = counter1+1;
        pointCount = 0;
        
        for (int counter2 = 0; counter2 < vectorSegmentationCount/5; counter2++){
            if (vectorNumber == positionNumber [counter2*6]) pointCount++;
        }
        
        if (pointCount > 4){
            do {
                
                terminationFlag = 0;
                longestLineNumber = 0;
                angleLongest = 0;
                countNumber = 0;
                
                //------Find longest outline vector------
                for (int counter2 = 0; counter2 < vectorSegmentationCount/5; counter2++){
                    if (positionNumber [counter2*6] == vectorNumber && positionNumber [counter2*6+5] == 0){
                        if (lengthAngle [counter2*2] > longestLineNumber){
                            longestLineNumber = (int)lengthAngle [counter2*2];
                            angleLongest = lengthAngle [counter2*2+1];
                            countNumber = counter2;
                            terminationFlag = 1;
                        }
                    }
                }
                
                //------Set longest vector info, in positionNumber [countNumber][5], put 2------
                startLongestX = positionNumber [countNumber*6+1];
                startLongestY = positionNumber [countNumber*6+2];
                endLongestX = positionNumber [countNumber*6+3];
                endLongestY = positionNumber [countNumber*6+4];
                positionNumber [countNumber*6+5] = 2;
                
                //cout<<"LGLN "<<longestLineNumber<<" AGLG "<<angleLongest<<" STX "<<startLongestX<<" STY "<<startLongestY<<" EDX "<<endLongestX<<" EDY "<<endLongestY<<" XYInfo"<<endl;
                
                if (terminationFlag == 1){
                    extensionFindFlag = 0;
                    cutOff1 = 0;
                    cutOff2 = 0;
                    cutOff3 = 0;
                    caseType = 0;
                    
                    if (angleLongest < 160 && angleLongest > -160){
                        cutOff1 = angleLongest-20;
                        cutOff2 = angleLongest+20;
                        cutOff3 = 0;
                        caseType = 1;
                    }
                    else if (angleLongest >= 160){
                        cutOff1 = angleLongest-20;
                        cutOff2 = 180;
                        cutOff3 = (180-(angleLongest+20-180))*-1;
                        caseType = 2;
                    }
                    else if (angleLongest <= -160){
                        cutOff1 = 180-(((angleLongest-20)+180)*-1);
                        cutOff2 = 180;
                        cutOff3 = angleLongest+20;
                        caseType = 2;
                    }
                    else if (angleLongest == 180){
                        cutOff1 = 160;
                        cutOff2 = 180;
                        cutOff3 = -160;
                        caseType = 2;
                    }
                    
                    //cout<<"C1 "<<cutOff1<<" C2 "<<cutOff2<<" C3 "<<cutOff3<<" ST"<<caseType<<" CutOff"<<endl;
                    
                    //------Check all vectors, if extension is found, update X-Y info and put 1 (already extended, will not be processed afterward) to positionNumber [counter4][5]------
                    //------positionNumber [counter4][5] = 2 remained to be active. positionNumber [counter4][5] = 0 remains to be processed. After this step, positionNumber [counter4][5]------
                    //------will contains either 1 or 2------
                    
                    do{
                        
                        terminationFlag2 = 0;
                        
                        for (int counter2 = 0; counter2 < vectorSegmentationCount/5; counter2++){
                            if (positionNumber [counter2*6] == vectorNumber && positionNumber [counter2*6+5] == 0){
                                if (positionNumber [counter2*6+3] == startLongestX && positionNumber [counter2*6+4] == startLongestY){
                                    angleSubject = lengthAngle [counter2*2+1];
                                    
                                    if ((angleSubject >= cutOff1 && angleSubject <= cutOff2 && caseType == 1) || (((angleSubject >= cutOff1 && angleSubject <= cutOff2) || (angleSubject > cutOff2*-1 && angleSubject <= cutOff3)) && caseType == 2)){
                                        startLongestX = positionNumber [counter2*6+1];
                                        startLongestY = positionNumber [counter2*6+2];
                                        positionNumber [counter2*6+5] = 1;
                                        extensionFindFlag = 1;
                                        terminationFlag2 = 1;
                                        break;
                                    }
                                }
                                else if (positionNumber [counter2*6+1] == endLongestX && positionNumber [counter2*6+2] == endLongestY){
                                    angleSubject = lengthAngle [counter2*2+1];
                                    
                                    if ((angleSubject >= cutOff1 && angleSubject <= cutOff2 && caseType == 1) || (((angleSubject >= cutOff1 && angleSubject <= cutOff2) || (angleSubject > cutOff2*-1 && angleSubject <= cutOff3)) && caseType == 2)){
                                        endLongestX = positionNumber [counter2*6+3];
                                        endLongestY = positionNumber [counter2*6+4];
                                        positionNumber [counter2*6+5] = 1;
                                        extensionFindFlag = 1;
                                        terminationFlag2 = 1;
                                        break;
                                    }
                                }
                            }
                        }
                        
                    } while (terminationFlag2 == 1);
                    
                    //cout<<longestLineNumber<<" "<<extensionFindFlag<<" "<<startLongestX<<" "<<startLongestY<<" "<<endLongestX<<" "<<endLongestY<<" XYPositionInfo"<<endl;
                    
                    //------ If extension is found recalculate length and angle------
                    if (extensionFindFlag == 1){
                        positionNumber [countNumber*6+1] = startLongestX;
                        positionNumber [countNumber*6+2] = startLongestY;
                        positionNumber [countNumber*6+3] = endLongestX;
                        positionNumber [countNumber*6+4] = endLongestY;
                        lengthAngle [countNumber*2] = sqrt(pow((endLongestX-startLongestX), 2)+pow((endLongestY-startLongestY), 2));
                        
                        angleExtension = 0;
                        
                        if (endLongestX-startLongestX == 0 && endLongestY-startLongestY > 0) angleExtension = 90;
                        if (endLongestX-startLongestX == 0 && endLongestY-startLongestY < 0) angleExtension = -90;
                        if (endLongestY-startLongestY == 0 && endLongestX-startLongestX > 0) angleExtension = 0;
                        if (endLongestY-startLongestY == 0 && endLongestX-startLongestX < 0) angleExtension = 180;
                        if (endLongestY-startLongestY != 0){
                            angleExtension = (atan(abs(endLongestY-startLongestY)/(double)abs(endLongestX-startLongestX)))*180/3.14;
                            
                            if (endLongestX-startLongestX > 0 && endLongestY-startLongestY < 0) angleExtension = angleExtension*-1;
                            if (endLongestX-startLongestX < 0 && endLongestY-startLongestY > 0) angleExtension = 180-angleExtension;
                            if (endLongestX-startLongestX < 0 && endLongestY-startLongestY < 0) angleExtension = (180-angleExtension)*-1;
                        }
                        
                        lengthAngle [countNumber*2+1] = angleExtension;
                    }
                }
                
            } while (terminationFlag == 1);
            
            //for (int counterA = 0; counterA < vectorSegmentationCount/5; counterA++){
            //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<positionNumber [counterA*5+counterB];
            //	cout<<" positionNumber "<<counterA<<endl;
            //}
            
            //------Find reverse vector pair, Vector A: determine revers angle, find possible partners, determine cross point (point that tart and end point of subject vector cross the Vector A at ------
            //------90 degree. If the cross points are outside of start and end point of Vector A, cross points are set at the Start or end point of Vector A. Then determine overlap %. If Vector A------
            //------shorter than paired vector, it is 1.0. If it is longer, it will be below 1.0. Eliminate if the overlap % is less than 0.1------
            
            for (int counter2 = 0; counter2 < vectorSegmentationCount/5; counter2++){
                if (positionNumber [counter2*6] == vectorNumber && positionNumber [counter2*6+5] == 2){
                    angleCompare = lengthAngle [counter2*2+1];
                    cutOff4 = 0;
                    cutOff5 = 0;
                    caseType2 = 0;
                    
                    if (angleCompare == 0){
                        cutOff4 = 160;
                        cutOff5 = -160;
                        caseType2 = 2;
                    }
                    else if (angleCompare > 0){
                        cutOff4 = (180-angleCompare)*-1-20;
                        cutOff5 = (180-angleCompare)*-1+20;
                        caseType2 = 1;
                        
                        if (cutOff4 < -180){
                            cutOff4 = 180-(cutOff4+180)*-1;
                            caseType2 = 2;
                        }
                    }
                    else if (angleCompare < 0){
                        cutOff4 = 180+angleCompare-20;
                        cutOff5 = 180+angleCompare+20;
                        caseType2 = 1;
                        
                        if (cutOff5 > 180){
                            cutOff5 = (180-(cutOff5-180))*-1;
                            caseType2 = 2;
                        }
                    }
                    
                    startXAd = positionNumber [counter2*6+1];
                    startYAd = positionNumber [counter2*6+2];
                    endXAd = positionNumber [counter2*6+3];
                    endYAd = positionNumber [counter2*6+4];
                    
                    if (endXAd-startXAd == 0) constA = 0;
                    else constA = (endYAd-startYAd)/(double)(endXAd-startXAd);
                    
                    constB = startYAd-constA*startXAd;
                    distanceAd = sqrt((startXAd-endXAd)*(startXAd-endXAd)+(startYAd-endYAd)*(startYAd-endYAd));
                    
                    //------Determine the overlap length of two vectors------
                    for (int counter3 = 0; counter3 < vectorSegmentationCount/5; counter3++){
                        if (positionNumber [counter3*6] == vectorNumber && positionNumber [counter3*6+5] == 2){
                            if ((caseType2 == 1 && lengthAngle [counter3*2+1] <= cutOff5 && lengthAngle [counter3*2+1] >= cutOff4) || (caseType2 == 2 && ((lengthAngle [counter3*2+1] <= cutOff5 && lengthAngle [counter3*2+1] > -180) || (lengthAngle [counter3*2+1] >= cutOff4 && lengthAngle [counter3*2+1] <= 180)))){
                                valueXRefAd1 = positionNumber [counter3*6+1];
                                valueYRefAd1 = positionNumber [counter3*6+2];
                                valueXRefAd2 = positionNumber [counter3*6+3];
                                valueYRefAd2 = positionNumber [counter3*6+4];
                                overlapFlag = 0;
                                
                                crossX1 = 0;
                                crossY1 = 0;
                                crossX2 = 0;
                                crossY2 = 0;
                                
                                //cout<<startXAd<<" "<<startYAd<<" "<<endXAd<<" "<<endYAd<<" "<<valueXRefAd1<<" "<<valueYRefAd1<<" "<<valueXRefAd2<<" "<<valueYRefAd2<<" "<<crossX1<<" "<<crossY1<<" "<<crossX2<<" "<<crossY2<<" CrossXY"<<endl;
                                
                                if (endXAd-startXAd == 0){
                                    crossY1 = valueYRefAd1;
                                    crossY2 = valueYRefAd2;
                                    
                                    if (startYAd < endYAd && crossY1 > endYAd){
                                        if (startYAd < endYAd && crossY2 > endYAd) overlapFlag = 1;
                                        else crossY1 = endYAd;
                                    }
                                    
                                    if (startYAd > endYAd && crossY1 < endYAd){
                                        if (startYAd > endYAd && crossY2 < endYAd) overlapFlag = 1;
                                        else crossY1 = endYAd;
                                    }
                                    
                                    if (startYAd < endYAd && crossY2 < startYAd){
                                        if (startYAd < endYAd && crossY1 < startYAd) overlapFlag = 1;
                                        else crossY2 = startYAd;
                                    }
                                    
                                    if (startYAd > endYAd && crossY2 > startYAd){
                                        if (startYAd > endYAd && crossY1 > startYAd) overlapFlag = 1;
                                        else crossY2 = startYAd;
                                    }
                                }
                                else if (constA == 0){
                                    crossX1 = valueXRefAd1;
                                    crossX2 = valueXRefAd2;
                                    
                                    if (startXAd > endXAd && crossX1 < endXAd){
                                        if (startXAd > endXAd && crossX2 < endXAd) overlapFlag = 1;
                                        else crossX1 = endXAd;
                                    }
                                    
                                    if (startXAd < endXAd && crossX1 > endXAd){
                                        if (startXAd < endXAd && crossX2 > endXAd) overlapFlag = 1;
                                        else crossX1 = endXAd;
                                    }
                                    
                                    if (startXAd > endXAd && crossX2 > startXAd){
                                        if (startXAd > endXAd && crossX1 > startXAd) overlapFlag = 1;
                                        else crossX2 = startXAd;
                                    }
                                    
                                    if (startXAd < endXAd && crossX2 < startXAd){
                                        if (startXAd < endXAd && crossX1 < startXAd) overlapFlag = 1;
                                        else crossX2 = startXAd;
                                    }
                                }
                                else{
                                    
                                    crossX1 = (valueYRefAd1-(-1/constA)*valueXRefAd1-constB)/(double)(constA+1/constA);
                                    crossY1 = constA*crossX1+constB;
                                    crossX2 = (valueYRefAd2-(-1/constA)*valueXRefAd2-constB)/(double)(constA+1/constA);
                                    crossY2 = constA*crossX2+constB;
                                    
                                    //cout<<startXAd<<" "<<startYAd<<" "<<endXAd<<" "<<endYAd<<" "<<valueXRefAd1<<" "<<valueYRefAd1<<" "<<valueXRefAd2<<" "<<valueYRefAd2<<" "<<crossX1<<" "<<crossY1<<" "<<crossX2<<" "<<crossY2<<" CrossXY2"<<endl;
                                    
                                    if (startXAd > endXAd && startYAd < endYAd && crossX1 < endXAd && crossY1 > endYAd){
                                        if (startXAd > endXAd && startYAd < endYAd && crossX2 < endXAd && crossY2 > endYAd) overlapFlag = 1;
                                        else{
                                            
                                            crossX1 = endXAd;
                                            crossY1 = endYAd;
                                        }
                                    }
                                    
                                    if (startXAd > endXAd && startYAd > endYAd && crossX1 < endXAd && crossY1 < endYAd){
                                        if (startXAd > endXAd && startYAd > endYAd && crossX2 < endXAd && crossY2 < endYAd) overlapFlag = 1;
                                        else{
                                            
                                            crossX1 = endXAd;
                                            crossY1 = endYAd;
                                        }
                                    }
                                    
                                    if (startXAd < endXAd && startYAd > endYAd && crossX1 > endXAd && crossY1 < endYAd){
                                        if (startXAd < endXAd && startYAd > endYAd && crossX2 > endXAd && crossY2 < endYAd) overlapFlag = 1;
                                        else{
                                            
                                            crossX1 = endXAd;
                                            crossY1 = endYAd;
                                        }
                                    }
                                    
                                    if (startXAd < endXAd && startYAd < endYAd && crossX1 > endXAd && crossY1 > endYAd){
                                        if (startXAd < endXAd && startYAd < endYAd && crossX2 > endXAd && crossY2 > endYAd) overlapFlag = 1;
                                        else{
                                            
                                            crossX1 = endXAd;
                                            crossY1 = endYAd;
                                        }
                                    }
                                    
                                    if (startXAd > endXAd && startYAd < endYAd && crossX2 > startXAd && crossY2 < startYAd){
                                        if (startXAd > endXAd && startYAd < endYAd && crossX1 > startXAd && crossY1 < startYAd) overlapFlag = 1;
                                        else{
                                            
                                            crossX2 = startXAd;
                                            crossY2 = startYAd;
                                        }
                                    }
                                    
                                    if (startXAd > endXAd && startYAd > endYAd && crossX2 > startXAd && crossY2 > startYAd){
                                        if (startXAd > endXAd && startYAd > endYAd && crossX1 > startXAd && crossY1 > startYAd) overlapFlag = 1;
                                        else{
                                            
                                            crossX2 = startXAd;
                                            crossY2 = startYAd;
                                        }
                                    }
                                    
                                    if (startXAd < endXAd && startYAd > endYAd && crossX2 < startXAd && crossY2 > startYAd){
                                        if (startXAd < endXAd && startYAd > endYAd && crossX1 < startXAd && crossY1 > startYAd) overlapFlag = 1;
                                        else{
                                            
                                            crossX2 = startXAd;
                                            crossY2 = startYAd;
                                        }
                                    }
                                    
                                    if (startXAd < endXAd && startYAd < endYAd && crossX2 < startXAd && crossY2 < startYAd){
                                        if (startXAd < endXAd && startYAd < endYAd && crossX1 < startXAd && crossY1 < startYAd) overlapFlag = 1;
                                        else{
                                            
                                            crossX2 = startXAd;
                                            crossY2 = startYAd;
                                        }
                                    }
                                }
                                
                                //cout<<startXAd<<" "<<startYAd<<" "<<endXAd<<" "<<endYAd<<"  "<<crossX1<<" "<<crossY1<<" "<<crossX2<<" "<<crossY2<<" CrossXY3"<<endl;
                                
                                if (overlapFlag != 1){
                                    percentOverlap = sqrt((crossX1-crossX2)*(crossX1-crossX2)+(crossY1-crossY2)*(crossY1-crossY2))/(double)distanceAd;
                                }
                                else percentOverlap = 0;
                                
                                if (percentOverlap >= 0.1){
                                    if (relationShipCount+11 > relationShipLimit){
                                        int *arraySourceTemp = new int [relationShipCount+50];
                                        for (int counter4 = 0; counter4 < relationShipCount; counter4++) arraySourceTemp [counter4] = arrayRelationShip [counter4];
                                        
                                        delete [] arrayRelationShip;
                                        arrayRelationShip = new int [relationShipLimit+5000];
                                        relationShipLimit = relationShipLimit+5000;
                                        
                                        for (int counter4 = 0; counter4 < relationShipCount; counter4++) arrayRelationShip [counter4] = arraySourceTemp [counter4];
                                        delete [] arraySourceTemp;
                                    }
                                    
                                    arrayRelationShip [relationShipCount] = vectorNumber, relationShipCount++;
                                    arrayRelationShip [relationShipCount] = counter2, relationShipCount++;
                                    arrayRelationShip [relationShipCount] = positionNumber [counter2*6+1], relationShipCount++;
                                    arrayRelationShip [relationShipCount] = positionNumber [counter2*6+2], relationShipCount++;
                                    arrayRelationShip [relationShipCount] = positionNumber [counter2*6+3], relationShipCount++;
                                    arrayRelationShip [relationShipCount] = positionNumber [counter2*6+4], relationShipCount++;
                                    arrayRelationShip [relationShipCount] = counter3, relationShipCount++;
                                    arrayRelationShip [relationShipCount] = positionNumber [counter3*6+1], relationShipCount++;
                                    arrayRelationShip [relationShipCount] = positionNumber [counter3*6+2], relationShipCount++;
                                    arrayRelationShip [relationShipCount] = positionNumber [counter3*6+3], relationShipCount++;
                                    arrayRelationShip [relationShipCount] = positionNumber [counter3*6+4], relationShipCount++;
                                    
                                    if (relationShipCount2+9 > relationShipLimit2){
                                        double *arraySourceTemp = new double [relationShipLimit2+50];
                                        for (int counter4 = 0; counter4 < relationShipCount2; counter4++) arraySourceTemp [counter4] = arrayRelationShip2 [counter4];
                                        
                                        delete [] arrayRelationShip2;
                                        arrayRelationShip2 = new double [relationShipLimit2+2500];
                                        relationShipLimit2 = relationShipLimit2+2500;
                                        
                                        for (int counter4 = 0; counter4 < relationShipCount2; counter4++) arrayRelationShip2 [counter4] = arraySourceTemp [counter4];
                                        delete [] arraySourceTemp;
                                    }
                                    
                                    arrayRelationShip2 [relationShipCount2] = lengthAngle [counter2*2], relationShipCount2++;
                                    arrayRelationShip2 [relationShipCount2] = lengthAngle [counter2*2+1], relationShipCount2++;
                                    arrayRelationShip2 [relationShipCount2] = lengthAngle [counter3*2], relationShipCount2++;
                                    arrayRelationShip2 [relationShipCount2] = lengthAngle [counter3*2+1], relationShipCount2++;
                                    arrayRelationShip2 [relationShipCount2] = percentOverlap, relationShipCount2++;
                                    arrayRelationShip2 [relationShipCount2] = crossX1, relationShipCount2++;
                                    arrayRelationShip2 [relationShipCount2] = crossY1, relationShipCount2++;
                                    arrayRelationShip2 [relationShipCount2] = crossX2, relationShipCount2++;
                                    arrayRelationShip2 [relationShipCount2] = crossY2, relationShipCount2++;
                                    
                                    numberOfVector [vectorNumber]++; //------Store the number of pairs per vector------
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    delete [] positionNumber;
    delete [] lengthAngle;
    
    //------Determine the cell angle and length based on paired vector, Square or triangle can not be find.------
    
    int numberOfData = 0;
    int contentCounter = 0;
    int firstLine = 0;
    int secondLine = 9;
    int findFlag = 0;
    int componentCount = 0;
    int componentNumber = 0;
    int remainingPointCount = 0;
    int remainingPointCountNumber = 0;
    int numberA = 0;
    int numberB = 0;
    int latestPoint = 0;
    int matchFlag = 0;
    int longestCount = 0;
    int numberOfPair = 0;
    int firstDataFlag = 0;
    int subComponentNumber = 0;
    int closestLineNumber = 0;
    int closestCount = 0;
    int smallestLineNumber = 0;
    int smallestCount = 0;
    int flagForFwBc = 0;
    int totalCount = 0;
    int highestNumber = 0;
    int highestNumberCount = 0;
    int longestLineNumber2 = 0;
    int startX1 = 0;
    int startY1 = 0;
    int endX2 = 0;
    int endY2 = 0;
    int longestLineCount3 = 0;
    int xPositionCenter = 0;
    int yPositionCenter = 0;
    int xPositionCenter2 = 0;
    int yPositionCenter2 = 0;
    
    double longestLineLength = 0;
    double distanceEnd = 0;
    double distanceStart = 0;
    double angle = 0;
    double longestLine3 = 0;
    
    for (int counter1 = 1; counter1 <= largestVectorNumber; counter1++){
        if (numberOfVector [counter1] != 0){
            numberOfData = numberOfVector [counter1];
            
            int *vectorMatchNumber = new int [numberOfVector [counter1]*6+50];
            int *dataPosition1 = new int [numberOfVector [counter1]*4+50];
            int *dataPosition2 = new int [numberOfVector [counter1]*4+50];
            double *crossPoint1 = new double [numberOfVector [counter1]*4+50];
            double *crossPoint2 = new double [numberOfVector [counter1]*4+50];
            double *dataOverlap = new double [numberOfVector [counter1]*2+50];
            double *dataLengthAngle1 = new double [numberOfVector [counter1]*2+50];
            double *dataLengthAngle2 = new double [numberOfVector [counter1]*2+50];
            double *crossPositionResult = new double [numberOfVector [counter1]*6+50];
            
            for (int counter2 = 0; counter2 < numberOfVector [counter1]; counter2++){
                vectorMatchNumber [counter2*6] = -1;
                vectorMatchNumber [counter2*6+1] = -1;
                vectorMatchNumber [counter2*6+2] = -1;
                vectorMatchNumber [counter2*6+3] = -1;
                vectorMatchNumber [counter2*6+4] = 0;
                vectorMatchNumber [counter2*6+5] = 0;
                
                dataPosition1 [counter2*4] = -1;
                dataPosition1 [counter2*4+1] = -1;
                dataPosition1 [counter2*4+2] = -1;
                dataPosition1 [counter2*4+3] = -1;
                
                dataPosition2 [counter2*4] = -1;
                dataPosition2 [counter2*4+1] = -1;
                dataPosition2 [counter2*4+2] = -1;
                dataPosition2 [counter2*4+3] = -1;
                
                crossPoint1 [counter2*4] = -1;
                crossPoint1 [counter2*4+1] = -1;
                crossPoint1 [counter2*4+2] = -1;
                crossPoint1 [counter2*4+3] = -1;
                
                crossPoint2 [counter2*4] = -1;
                crossPoint2 [counter2*4+1] = -1;
                crossPoint2 [counter2*4+2] = -1;
                crossPoint2 [counter2*4+3] = -1;
                
                dataOverlap [counter2*2] = -1;
                dataOverlap [counter2*2+1] = -1;
                
                dataLengthAngle1 [counter2*2] = -1;
                dataLengthAngle1 [counter2*2+1] = -1;
                
                dataLengthAngle2 [counter2*2] = -1;
                dataLengthAngle2 [counter2*2+1] = -1;
            }
            
            //------Data up-loading------
            contentCounter = 0;
            
            for (int counter2 = 0; counter2 < relationShipCount/11; counter2++){
                if (counter1 == arrayRelationShip [counter2*11]){
                    vectorMatchNumber [contentCounter*6] = arrayRelationShip [counter2*11+1];
                    vectorMatchNumber [contentCounter*6+1] = arrayRelationShip [counter2*11+6];
                    vectorMatchNumber [contentCounter*6+2] = 0;
                    vectorMatchNumber [contentCounter*6+3] = 0;
                    vectorMatchNumber [contentCounter*6+4] = 0;
                    vectorMatchNumber [contentCounter*6+5] = 0;
                    
                    crossPoint1 [contentCounter*4] = arrayRelationShip2 [counter2*9+5];
                    crossPoint1 [contentCounter*4+1] = arrayRelationShip2 [counter2*9+6];
                    crossPoint1 [contentCounter*4+2] = 0;
                    crossPoint1 [contentCounter*4+3] = 0;
                    
                    crossPoint2 [contentCounter*4] = arrayRelationShip2 [counter2*9+7];
                    crossPoint2 [contentCounter*4+1] = arrayRelationShip2 [counter2*9+8];
                    crossPoint2 [contentCounter*4+2] = 0;
                    crossPoint2 [contentCounter*4+3] = 0;
                    
                    dataOverlap [contentCounter*2] = arrayRelationShip2 [counter2*9+4];
                    dataOverlap [contentCounter*2+1] = 0;
                    
                    dataPosition1 [contentCounter*4] = arrayRelationShip [counter2*11+2];
                    dataPosition1 [contentCounter*4+1] = arrayRelationShip [counter2*11+3];
                    dataPosition1 [contentCounter*4+2] = arrayRelationShip [counter2*11+4];
                    dataPosition1 [contentCounter*4+3] = arrayRelationShip [counter2*11+5];
                    
                    dataPosition2 [contentCounter*4] = arrayRelationShip [counter2*11+7];
                    dataPosition2 [contentCounter*4+1] = arrayRelationShip [counter2*11+8];
                    dataPosition2 [contentCounter*4+2] = arrayRelationShip [counter2*11+9];
                    dataPosition2 [contentCounter*4+3] = arrayRelationShip [counter2*11+10];
                    
                    dataLengthAngle1 [contentCounter*2] = arrayRelationShip2 [counter2*9];
                    dataLengthAngle1 [contentCounter*2+1] = arrayRelationShip2 [counter2*9+1];
                    
                    dataLengthAngle2 [contentCounter*2] = arrayRelationShip2 [counter2*9+2];
                    dataLengthAngle2 [contentCounter*2+1] = arrayRelationShip2 [counter2*9+3];
                    
                    contentCounter++;
                }
            }
            
            //------If % of overlap meet the requirement, data is moved to crossPoint1 [*][2], crossPoint1 [*][3] etc, put vectorMatchNumber [*][2] = 1 (no longer processed) or = 2 (allow to process)------
            for (int counter2 = 0; counter2 < numberOfData-1; counter2++){
                firstLine = vectorMatchNumber [counter2*6];
                secondLine = vectorMatchNumber [counter2*6+1];
                findFlag = 0;
                
                for (int counter3 = counter2+1; counter3 < numberOfData; counter3++){
                    if (vectorMatchNumber [counter3*6+2] == 0){
                        if (firstLine == vectorMatchNumber [counter3*6+1] && secondLine == vectorMatchNumber [counter3*6]){
                            if (dataOverlap [counter2*2] < 0.3 && dataOverlap [counter3*2] == 1){
                                vectorMatchNumber [counter3*6+2] = 1;
                                vectorMatchNumber [counter2*6+2] = 2;
                                dataOverlap [counter2*2+1] = dataOverlap [counter3*2];
                                crossPoint1 [counter2*4+2] = crossPoint1 [counter3*4];
                                crossPoint1 [counter2*4+3] = crossPoint1 [counter3*4+1];
                                crossPoint2 [counter2*4+2] = crossPoint2 [counter3*4];
                                crossPoint2 [counter2*4+3] = crossPoint2 [counter3*4+1];
                                findFlag = 1;
                            }
                            else if (dataOverlap [counter2*2] == 1 && dataOverlap [counter3*2] < 0.3){
                                vectorMatchNumber [counter3*6+2] = 1;
                                vectorMatchNumber [counter2*6+2] = 2;
                                dataOverlap [counter2*2+1] = dataOverlap [counter3*2];
                                crossPoint1 [counter2*4+2] = crossPoint1 [counter3*4];
                                crossPoint1 [counter2*4+3] = crossPoint1 [counter3*4+1];
                                crossPoint2 [counter2*4+2] = crossPoint2 [counter3*4];
                                crossPoint2 [counter2*4+3] = crossPoint2 [counter3*4+1];
                                findFlag = 1;
                            }
                            else if (dataOverlap [counter2*2] >= 0.3 && dataOverlap [counter3*2] >= 0.3){
                                vectorMatchNumber [counter3*6+2] = 1;
                                vectorMatchNumber [counter2*6+2] = 2;
                                dataOverlap [counter2*2+1] = dataOverlap [counter3*2];
                                crossPoint1 [counter2*4+2] = crossPoint1 [counter3*4];
                                crossPoint1 [counter2*4+3] = crossPoint1 [counter3*4+1];
                                crossPoint2 [counter2*4+2] = crossPoint2 [counter3*4];
                                crossPoint2 [counter2*4+3] = crossPoint2 [counter3*4+1];
                                findFlag = 1;
                            }
                            else if (dataLengthAngle1 [counter3*2]/(double)dataLengthAngle1 [counter2*2] > 0.4){
                                vectorMatchNumber [counter3*6+2] = 1;
                                vectorMatchNumber [counter2*6+2] = 2;
                                dataOverlap [counter2*2+1] = dataOverlap [counter3*2];
                                crossPoint1 [counter2*4+2] = crossPoint1 [counter3*4];
                                crossPoint1 [counter2*4+3] = crossPoint1 [counter3*4+1];
                                crossPoint2 [counter2*4+2] = crossPoint2 [counter3*4];
                                crossPoint2 [counter2*4+3] = crossPoint2 [counter3*4+1];
                                findFlag = 1;
                            }
                            else{
                                
                                vectorMatchNumber [counter3*6+2] = 1;
                                vectorMatchNumber [counter2*6+2] = 1;
                            }
                        }
                    }
                }
                
                if (findFlag == 0) vectorMatchNumber [counter2*6+2] = 1; //------Orphans Vector------
            }
            
            //for (int counterA = 0; counterA < numberOfData; counterA++){
            //	cout<<" "<<vectorMatchNumber [counterA][0]<<" "<<vectorMatchNumber [counterA][1]<<" "<<vectorMatchNumber [counterA][2]<<" "<<dataOverlap [counterA][0]<<" "<<dataOverlap [counterA][1]<<" MatchNo"<<endl;
            //}
            
            componentCount = 1;
            componentNumber = 0;
            
            for (int counter2 = 0; counter2 < numberOfData-1; counter2++){
                if (vectorMatchNumber [counter2*6+2] == 2){
                    firstLine = vectorMatchNumber [counter2*6];
                    secondLine = vectorMatchNumber [counter2*6+1];
                    
                    //------If only one pair exist, put number 8 in vectorMatchNumber [**6+2]. If multiple pair exist e.g. 1-3, 3-4, 3-5, 5-6, these set are marked vectorMatchNumber [**6+2] = 3------
                    //------componentCount is the total number of set------
                    
                    do {
                        
                        terminationFlag = 0;
                        
                        for (int counter3 = counter2; counter3 < numberOfData; counter3++){
                            if (counter3 != counter2 && vectorMatchNumber [counter3*6+2] == 2){
                                
                                //------When the set was found, set vectorMatchNumber [**6+2] = 3 and rest of pair will have number 4------
                                if (firstLine == vectorMatchNumber [counter3*6] || secondLine == vectorMatchNumber [counter3*6+1] || firstLine == vectorMatchNumber [counter3*6+1] || secondLine == vectorMatchNumber [counter3*6]){
                                    vectorMatchNumber [counter3*6+2] = 4;
                                    vectorMatchNumber [counter2*6+2] = 3;
                                    terminationFlag = 1;
                                    componentCount++;
                                }
                            }
                        }
                        
                        //------When 4 is found, go through vector again and put 3 if additional pair is found. In this step, 3 is put and after the step, number in all pair is 3------
                        for (int counter3 = counter2; counter3 < numberOfData; counter3++){
                            if (vectorMatchNumber [counter3*6+2] == 4){
                                firstLine = vectorMatchNumber [counter3*6];
                                secondLine = vectorMatchNumber [counter3*6+1];
                                vectorMatchNumber [counter3*6+2] = 3;
                                terminationFlag = 1;
                                break;
                            }
                        }
                        
                        if (vectorMatchNumber [counter2*6+2] == 2) vectorMatchNumber [counter2*6+2] = 8; //------Number 8 (single pair) is put to distinguish multiple pair------
                        
                    } while (terminationFlag == 1);
                    
                    //------Of the component number is 1, set component number in vectorMatchNumber [*][3] = componentNumber. If more than two component exist go to the following process------
                    if (componentCount != 1){
                        //------In this step, the longest vector, which has pair with multiple vectors, is first extracted. then determine the distance of the end of paired vector to the longest vector------
                        //------Cross points are used to determine the distance. Then, find second paired vector. If the distance is larger than 1.5 fold or smaller than 0.6, the second vector is considered as------
                        //------not continuous vector of the first one. If it is find as continuous, two vectors are combined. When vectors are processed during Do-While, vectorMatchNumber [*][2] = 1------
                        //------is set (exclude from the processing) and put component number in vectorMatchNumber [*][3]------
                        
                        do{
                            
                            terminationFlag = 0;
                            remainingPointCount = 0;
                            remainingPointCountNumber = 0;
                            
                            for (int counter3 = 0; counter3 < numberOfData; counter3++){
                                if (vectorMatchNumber [counter3*6+2] == 3){
                                    remainingPointCount++;
                                    remainingPointCountNumber = counter3;
                                }
                            }
                            
                            //------If the remaining number of pair is 1, go to Else------
                            if (remainingPointCount > 1){
                                terminationFlag = 1;
                                latestPoint = 0;
                                
                                int *multipleCrossOver = new int [numberOfData*2];
                                
                                for (int counter3 = 0; counter3 < numberOfData*2; counter3++) multipleCrossOver [counter3] = -1;
                                
                                //------In this step, Vectors, which have pair with multiple other vectors, are find. The number is stored in multipleCrossOver [*], latestPoint hold total number of such vectors------
                                for (int counter3 = 0; counter3 < numberOfData; counter3++){
                                    if (vectorMatchNumber [counter3*6+2] == 3){
                                        numberA = vectorMatchNumber [counter3*6];
                                        numberB = vectorMatchNumber [counter3*6+1];
                                        
                                        for (int counter4 = 0; counter4 < numberOfData; counter4++){
                                            if (counter4 != counter3 && vectorMatchNumber [counter4*6+2] == 3){
                                                if (numberA == vectorMatchNumber [counter4*6] || numberA == vectorMatchNumber [counter4*6+1]){
                                                    matchFlag = 0;
                                                    
                                                    for (int counter5 = 0; counter5 < numberOfData; counter5++){
                                                        if (multipleCrossOver [counter5] == numberA) matchFlag = 1;
                                                    }
                                                    
                                                    if (matchFlag == 0){
                                                        multipleCrossOver [latestPoint] = numberA;
                                                        latestPoint++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        for (int counter4 = 0; counter4 < numberOfData; counter4++){
                                            if (counter4 != counter3 && vectorMatchNumber [counter4*6+2] == 3){
                                                if (numberB == vectorMatchNumber [counter4*6] || numberB == vectorMatchNumber [counter4*6+1]){
                                                    matchFlag = 0;
                                                    
                                                    for (int counter5 = 0; counter5 < numberOfData; counter5++){
                                                        if (multipleCrossOver [counter5] == numberB) matchFlag = 1;
                                                    }
                                                    
                                                    if (matchFlag == 0){
                                                        multipleCrossOver [latestPoint] = numberB;
                                                        latestPoint++;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                //------If no multi pair vectors are found go to Else------
                                if (latestPoint != 0){
                                    longestLineNumber = 0;
                                    longestLineLength = 0;
                                    longestCount = 0;
                                    numberOfPair = 0;
                                    
                                    //------Among the multi pair vectors, find longest one------
                                    for (int counter3 = 0; counter3 < numberOfData; counter3++){
                                        if (vectorMatchNumber [counter3*6+2] == 3){
                                            matchFlag = 0;
                                            
                                            for (int counter4 = 0; counter4 < latestPoint; counter4++){
                                                if (multipleCrossOver [counter4] == vectorMatchNumber [counter3*6]) matchFlag = 1;
                                                
                                                if (multipleCrossOver [counter4] == vectorMatchNumber [counter3*6+1]) matchFlag = 2;
                                            }
                                            
                                            if (matchFlag == 1){
                                                if (longestLineLength < dataLengthAngle1 [counter3*2]){
                                                    longestLineLength = dataLengthAngle1 [counter3*2];
                                                    longestLineNumber = vectorMatchNumber [counter3*6];
                                                    longestCount = counter3;
                                                }
                                            }
                                            
                                            if (matchFlag == 2){
                                                if (longestLineLength < dataLengthAngle2 [counter3*2]){
                                                    longestLineLength = dataLengthAngle2 [counter3*2];
                                                    longestLineNumber = vectorMatchNumber [counter3*6+1];
                                                    longestCount = counter3;
                                                }
                                            }
                                        }
                                    }
                                    
                                    vectorMatchNumber [longestCount*6+2] = 5;
                                    numberOfPair++;
                                    
                                    //------Set 5 into vectorMatchNumber [**6+2] of vector pair------
                                    for (int counter3 = 0; counter3 < numberOfData; counter3++){
                                        if (vectorMatchNumber [counter3*6+2] == 3 && (vectorMatchNumber [counter3*6] == longestLineNumber || vectorMatchNumber [counter3*6+1] == longestLineNumber)){
                                            vectorMatchNumber [counter3*6+2] = 5;
                                            numberOfPair++;
                                        }
                                    }
                                    
                                    firstDataFlag = 0;
                                    distanceEnd = 0;
                                    distanceStart = 0;
                                    subComponentNumber = 0;
                                    
                                    //------Find Vector pair, which contains nearest Next of the end of multi paired vector. When such vector set is found, set subComponentNumber into vectorMatchNumber [**6+4]------
                                    //------If the componentNumber is 1, subComponentNumber is 1, 2, 3 etc------
                                    
                                    do{
                                        
                                        terminationFlag = 0;
                                        closestLineNumber = 10000;
                                        closestCount = 0;
                                        smallestLineNumber = 10000;
                                        smallestCount = 0;
                                        flagForFwBc = 0;
                                        
                                        for (int counter3 = 0; counter3 < numberOfData; counter3++){
                                            if (vectorMatchNumber [counter3*6+2] == 5){
                                                if (smallestLineNumber > vectorMatchNumber [counter3*6+1] && vectorMatchNumber [counter3*6+1] != longestLineNumber){
                                                    smallestLineNumber = vectorMatchNumber [counter3*6+1];
                                                    smallestCount = counter3;
                                                    flagForFwBc = 2;
                                                }
                                                
                                                if (smallestLineNumber > vectorMatchNumber [counter3*6] && vectorMatchNumber [counter3*6] != longestLineNumber){
                                                    smallestLineNumber = vectorMatchNumber [counter3*6];
                                                    smallestCount = counter3;
                                                    flagForFwBc = 1;
                                                }
                                                
                                                if (vectorMatchNumber [counter3*6] == longestLineNumber){
                                                    if (vectorMatchNumber [counter3*6+1]-longestLineNumber > 1){
                                                        if (closestLineNumber > vectorMatchNumber [counter3*6+1]){
                                                            closestLineNumber = vectorMatchNumber [counter3*6+1];
                                                            closestCount = counter3;
                                                            flagForFwBc = 2;
                                                            firstDataFlag++;
                                                            terminationFlag = 1;
                                                        }
                                                    }
                                                }
                                                
                                                if (vectorMatchNumber [counter3*6+1] == longestLineNumber){
                                                    if (vectorMatchNumber [counter3*6]-longestLineNumber > 1){
                                                        if (closestLineNumber > vectorMatchNumber [counter3*6]){
                                                            closestLineNumber = vectorMatchNumber [counter3*6];
                                                            closestCount = counter3;
                                                            flagForFwBc = 1;
                                                            firstDataFlag++;
                                                            terminationFlag = 1;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (closestLineNumber == 10000 && smallestLineNumber != 10000){
                                            closestCount = smallestCount;
                                            terminationFlag = 1;
                                            firstDataFlag++;
                                        }
                                        
                                        //------When first set is found, vectorMatchNumber [*][5] = longestLineNumber is set------
                                        if (terminationFlag == 1){
                                            if (firstDataFlag == 1){
                                                componentNumber++;
                                                vectorMatchNumber [closestCount*6+3] = componentNumber;
                                                vectorMatchNumber [closestCount*6+2] = 1;
                                                subComponentNumber++;
                                                vectorMatchNumber [closestCount*6+4] = subComponentNumber;
                                                vectorMatchNumber [closestCount*6+5] = longestLineNumber;
                                                
                                                if (flagForFwBc == 1){
                                                    distanceEnd = sqrt((crossPoint1 [closestCount*4]-dataPosition2 [closestCount*4+2])*(crossPoint1 [closestCount*4]-dataPosition2 [closestCount*4+2])+(crossPoint1 [closestCount*4+1]-dataPosition2 [closestCount*4+3])*(crossPoint1 [closestCount*4+1]-dataPosition2 [closestCount*4+3]));
                                                }
                                                
                                                if (flagForFwBc == 2){
                                                    distanceEnd = sqrt((crossPoint2 [closestCount*4]-dataPosition1 [closestCount*4+2])*(crossPoint2 [closestCount*4]-dataPosition1 [closestCount*4+2])+(crossPoint2 [closestCount*4+1]-dataPosition1 [closestCount*4+3])*(crossPoint2 [closestCount*4+1]-dataPosition1 [closestCount*4+3]));
                                                }
                                            }
                                            else{
                                                
                                                if (flagForFwBc == 1){
                                                    distanceStart = sqrt((crossPoint1 [closestCount*4]-dataPosition2 [closestCount*4])*(crossPoint1 [closestCount*4]-dataPosition2 [closestCount*4])+(crossPoint1 [closestCount*4+1]-dataPosition2 [closestCount*4+1])*(crossPoint1 [closestCount*4+1]-dataPosition2 [closestCount*4+1]));
                                                }
                                                
                                                if (flagForFwBc == 2){
                                                    distanceStart = sqrt((crossPoint2 [closestCount*4]-dataPosition1 [closestCount*4])*(crossPoint2 [closestCount*4]-dataPosition1 [closestCount*4])+(crossPoint2 [closestCount*4+1]-dataPosition1 [closestCount*4+1])*(crossPoint2 [closestCount*4+1]-dataPosition1 [closestCount*4+1]));
                                                }
                                            }
                                            
                                            if ((distanceStart < distanceEnd*0.6 || distanceStart > distanceEnd*1.5) && firstDataFlag > 1){
                                                vectorMatchNumber [closestCount*6+3] = componentNumber;
                                                vectorMatchNumber [closestCount*6+2] = 1;
                                                subComponentNumber++;
                                                vectorMatchNumber [closestCount*6+4] = subComponentNumber;
                                                
                                                if (flagForFwBc == 1){
                                                    distanceEnd = sqrt((crossPoint1 [closestCount*4]-dataPosition2 [closestCount*4+2])*(crossPoint1 [closestCount*4]-dataPosition2 [closestCount*4+2])+(crossPoint1 [closestCount*4+1]-dataPosition2 [closestCount*4+3])*(crossPoint1 [closestCount*4+1]-dataPosition2 [closestCount*4+3]));
                                                }
                                                
                                                if (flagForFwBc == 2){
                                                    distanceEnd = sqrt((crossPoint2 [closestCount*4]-dataPosition1 [closestCount*4+2])*(crossPoint2 [closestCount*4]-dataPosition1 [closestCount*4+2])+(crossPoint2 [closestCount*4+1]-dataPosition1 [closestCount*4+3])*(crossPoint2 [closestCount*4+1]-dataPosition1 [closestCount*4+3]));
                                                }
                                            }
                                            else if ( firstDataFlag > 1){
                                                componentNumber++;
                                                vectorMatchNumber [closestCount*6+3] = componentNumber;
                                                vectorMatchNumber [closestCount*6+2] = 1;
                                            }
                                        }
                                        
                                    } while (terminationFlag == 1);
                                }
                                else{
                                    //------Else for latestPoint = 0------
                                    for (int counter3 = 0; counter3 < numberOfData; counter3++){
                                        if (vectorMatchNumber [counter3*6+2] == 5){
                                            if (dataOverlap [counter3*2] < 0.4 || dataOverlap [counter3*2] < 0.4) vectorMatchNumber [counter3*6+2] = 1;
                                            else{
                                                
                                                componentNumber++;
                                                vectorMatchNumber [counter3*6+3] = componentNumber;
                                                vectorMatchNumber [counter3*6+2] = 1;
                                            }
                                        }
                                        else vectorMatchNumber [counter3*6+2] = 1;
                                    }
                                }
                                
                                delete [] multipleCrossOver;
                            }
                            else{
                                //------Else for remainingPointCount = 1------
                                if (dataOverlap [remainingPointCountNumber*2] < 0.4 || dataOverlap [remainingPointCountNumber*2] < 0.4) vectorMatchNumber [remainingPointCountNumber*6+2] = 1;
                                else{
                                    
                                    componentNumber++;
                                    vectorMatchNumber [remainingPointCountNumber*6+3] = componentNumber;
                                    vectorMatchNumber [remainingPointCountNumber*6+2] = 1;
                                }
                            }
                            
                        } while (terminationFlag == 1);
                    }
                    else{
                        
                        componentNumber++;
                        vectorMatchNumber [counter2*6+3] = componentNumber;
                        vectorMatchNumber [counter2*6+2] = 1; //------In the case that component number is 1------
                    }
                }
            }
            
            //------Determine the Mid pint of two cross point to draw cell orientation line------
            //------Cross Point Rule, Vector A (ST ED) are the points of paired B
            
            totalCount = 0;
            
            for (int counter2 = 0; counter2 < numberOfData; counter2++){
                crossPositionResult [counter2*6] = -1;
                crossPositionResult [counter2*6+1] = -1;
                crossPositionResult [counter2*6+2] = -1;
                crossPositionResult [counter2*6+3] = -1;
                crossPositionResult [counter2*6+4] = 0;
                crossPositionResult [counter2*6+5] = 200;
            }
            
            for (int counter2 = 0; counter2 < numberOfData; counter2++){
                if (vectorMatchNumber [counter2*6+3] != 0 && (vectorMatchNumber [counter2*6+4] == 0 || vectorMatchNumber [counter2*6+4] == 1)){
                    if (vectorMatchNumber [counter2*6+4] == 1){
                        highestNumber = 1;
                        highestNumberCount = counter2;
                        longestLineNumber2 = vectorMatchNumber [counter2*6+5];
                        
                        if (vectorMatchNumber [counter2*6] == longestLineNumber2){
                            crossPositionResult [totalCount*6] = (crossPoint1 [counter2*4]+crossPoint2 [counter2*4+2])/(double)2;
                            crossPositionResult [totalCount*6+1] = (crossPoint1 [counter2*4+1]+crossPoint2 [counter2*4+3])/(double)2;
                        }
                        else if (vectorMatchNumber [counter2*6+1] == longestLineNumber2){
                            crossPositionResult [totalCount*6] = (crossPoint1 [counter2*4+2]+crossPoint2 [counter2*4])/(double)2;
                            crossPositionResult [totalCount*6+1] = (crossPoint1 [counter2*4+3]+crossPoint2 [counter2*4+1])/(double)2;
                        }
                        
                        for (int counter3 = 0; counter3 < numberOfData; counter3++){
                            if ((vectorMatchNumber [counter3*6] == longestLineNumber2 || vectorMatchNumber [counter3*6+1] == longestLineNumber2) && vectorMatchNumber [counter2*6+3] == vectorMatchNumber [counter3*6+3] && vectorMatchNumber [counter3*6+4] > 1){
                                if (highestNumber < vectorMatchNumber [counter3*6+4]){
                                    highestNumber = vectorMatchNumber [counter3*6+4];
                                    highestNumberCount = counter3;
                                }
                            }
                        }
                        
                        if (vectorMatchNumber [highestNumberCount*6] == longestLineNumber2){
                            crossPositionResult [totalCount*6+2] = (crossPoint1 [highestNumberCount*4+2]+crossPoint2 [highestNumberCount*4])/(double)2;
                            crossPositionResult [totalCount*6+3] = (crossPoint1 [highestNumberCount*4+3]+crossPoint2 [highestNumberCount*4+1])/(double)2;
                        }
                        else if (vectorMatchNumber [highestNumberCount*6+1] == longestLineNumber2){
                            crossPositionResult [totalCount*6+2] = (crossPoint1 [highestNumberCount*4]+crossPoint2 [highestNumberCount*4+2])/(double)2;
                            crossPositionResult [totalCount*6+3] = (crossPoint1 [highestNumberCount*4+1]+crossPoint2 [highestNumberCount*4+3])/(double)2;
                        }
                        
                        startX1 = (int)crossPositionResult [totalCount*6];
                        startY1 = (int)crossPositionResult [totalCount*6+1];
                        endX2 = (int)crossPositionResult [totalCount*6+2];
                        endY2 = (int)crossPositionResult [totalCount*6+3];
                        crossPositionResult [totalCount*6+4] = sqrt(pow((endX2-startX1), 2)+pow((endY2-startY1), 2));
                        
                        if (endX2-startX1 == 0 && endY2-startY1 > 0) crossPositionResult [totalCount*6+5] = 90;
                        if (endX2-startX1 == 0 && endY2-startY1 < 0) crossPositionResult [totalCount*6+5] = -90;
                        if (endY2-startY1 == 0 && endX2-startX1 > 0) crossPositionResult [totalCount*6+5] = 0;
                        if (endY2-startY1 == 0 && endX2-startX1 < 0) crossPositionResult [totalCount*6+5] = 180;
                        if (endY2-startY1 != 0){
                            angle = (atan(abs(endY2-startY1)/(double)abs(endX2-startX1)))*180/3.14;
                            
                            if (endX2-startX1 > 0 && endY2-startY1 < 0) crossPositionResult [totalCount*6+5] = angle*-1;
                            if (endX2-startX1 < 0 && endY2-startY1 > 0) crossPositionResult [totalCount*6+5] = 180-angle;
                            if (endX2-startX1 < 0 && endY2-startY1 < 0) crossPositionResult [totalCount*6+5] = (180-angle)*-1;
                        }
                        
                        totalCount++;
                    }
                    else{
                        
                        crossPositionResult [totalCount*6] = (crossPoint1 [counter2*4]+crossPoint2 [counter2*4+2])/(double)2;
                        crossPositionResult [totalCount*6+1] = (crossPoint1 [counter2*4+1]+crossPoint2 [counter2*4+3])/(double)2;
                        crossPositionResult [totalCount*6+2] = (crossPoint1 [counter2*4+2]+crossPoint2 [counter2*4])/(double)2;
                        crossPositionResult [totalCount*6+3] = (crossPoint1 [counter2*4+3]+crossPoint2 [counter2*4+1])/(double)2;
                        
                        startX1 = (int)crossPositionResult [totalCount*6];
                        startY1 = (int)crossPositionResult [totalCount*6+1];
                        endX2 = (int)crossPositionResult [totalCount*6+2];
                        endY2 = (int)crossPositionResult [totalCount*6+3];
                        crossPositionResult [totalCount*6+4] = sqrt(pow((endX2-startX1), 2)+pow((endY2-startY1), 2));
                        
                        if (endX2-startX1 == 0 && endY2-startY1 > 0) crossPositionResult [totalCount*6+5] = 90;
                        if (endX2-startX1 == 0 && endY2-startY1 < 0) crossPositionResult [totalCount*6+5] = -90;
                        if (endY2-startY1 == 0 && endX2-startX1 > 0) crossPositionResult [totalCount*6+5] = 0;
                        if (endY2-startY1 == 0 && endX2-startX1 < 0) crossPositionResult [totalCount*6+5] = 180;
                        if (endY2-startY1 != 0){
                            angle = (atan(abs(endY2-startY1)/(double)abs(endX2-startX1)))*180/3.14;
                            
                            if (endX2-startX1 > 0 && endY2-startY1 < 0) crossPositionResult [totalCount*6+5] = angle*-1;
                            if (endX2-startX1 < 0 && endY2-startY1 > 0) crossPositionResult [totalCount*6+5] = 180-angle;
                            if (endX2-startX1 < 0 && endY2-startY1 < 0) crossPositionResult [totalCount*6+5] = (180-angle)*-1;
                        }
                        
                        totalCount++;
                    }
                }
            }
            
            //------Eliminate data point with no length------
            for (int counter2 = 0; counter2 < totalCount; counter2++){
                if (crossPositionResult [counter2*6] != -1 && crossPositionResult [counter2*6+2] != 0 && crossPositionResult [counter2*6+4] == 0){
                    crossPositionResult [counter2*6] = -1;
                    crossPositionResult [counter2*6+1] = -1;
                    crossPositionResult [counter2*6+2] = -1;
                    crossPositionResult [counter2*6+3] = -1;
                    crossPositionResult [counter2*6+4] = 0;
                    crossPositionResult [counter2*6+5] = 200;
                }
            }
            
            //------Eliminate data point of which length is 0.3 of longest point------
            for (int counter2 = 0; counter2 < totalCount; counter2++){
                if (totalCount > 1){
                    longestLine3 = 0;
                    longestLineCount3 = 0;
                    
                    for (int counter3 = 0; counter3 < totalCount; counter3++){
                        if (longestLine3 < crossPositionResult [counter3*6+4]){
                            longestLine3 = crossPositionResult [counter3*6+4];
                            longestLineCount3 = counter3;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < totalCount; counter3++){
                        if (longestLineCount3 != counter3){
                            if (crossPositionResult [counter3*6+4]/(double)longestLine3 < 0.3){
                                crossPositionResult [counter3*6] = -1;
                                crossPositionResult [counter3*6+1] = -1;
                                crossPositionResult [counter3*6+2] = -1;
                                crossPositionResult [counter3*6+3] = -1;
                                crossPositionResult [counter3*6+4] = 0;
                                crossPositionResult [counter3*6+5] = 200;
                            }
                        }
                    }
                }
            }
            
            if (arrayNumber == 2){
                if (analysisResultStatus1 == 1) delete [] arrayAnalysisResult1;
                arrayAnalysisResult1 = new int [totalCount*4+500], analysisResultCount1 = 0, analysisResultStatus1 = 1;
            }
            
            if (arrayNumber == 3){
                if (analysisResultStatus2 == 1) delete [] arrayAnalysisResult2;
                arrayAnalysisResult2 = new int [totalCount*4+500], analysisResultCount2 = 0, analysisResultStatus2 = 1;
            }
            
            if (arrayNumber == 4){
                if (analysisResultStatus3 == 1) delete [] arrayAnalysisResult3;
                arrayAnalysisResult3 = new int [totalCount*4+500], analysisResultCount3 = 0, analysisResultStatus3 = 1;
            }
            
            for (int counter2 = 0; counter2 < totalCount; counter2++){
                if (crossPositionResult [counter2*6] != -1){
                    xPositionCenter = (int)crossPositionResult [counter2*6];
                    yPositionCenter = (int)crossPositionResult [counter2*6+1];
                    xPositionCenter2 = (int)crossPositionResult [counter2*6+2];
                    yPositionCenter2 = (int)crossPositionResult [counter2*6+3];
                    
                    if (arrayNumber == 2){
                        arrayAnalysisResult1 [analysisResultCount1] = counter1, analysisResultCount1++;
                        arrayAnalysisResult1 [analysisResultCount1] = xPositionCenter, analysisResultCount1++;
                        arrayAnalysisResult1 [analysisResultCount1] = yPositionCenter, analysisResultCount1++;
                        arrayAnalysisResult1 [analysisResultCount1] = xPositionCenter2, analysisResultCount1++;
                        arrayAnalysisResult1 [analysisResultCount1] = yPositionCenter2, analysisResultCount1++;
                    }
                    
                    if (arrayNumber == 3){
                        arrayAnalysisResult2 [analysisResultCount2] = counter1, analysisResultCount2++;
                        arrayAnalysisResult2 [analysisResultCount2] = xPositionCenter, analysisResultCount2++;
                        arrayAnalysisResult2 [analysisResultCount2] = yPositionCenter, analysisResultCount2++;
                        arrayAnalysisResult2 [analysisResultCount2] = xPositionCenter2, analysisResultCount2++;
                        arrayAnalysisResult2 [analysisResultCount2] = yPositionCenter2, analysisResultCount2++;
                    }
                    
                    if (arrayNumber == 4){
                        arrayAnalysisResult3 [analysisResultCount3] = counter1, analysisResultCount3++;
                        arrayAnalysisResult3 [analysisResultCount3] = xPositionCenter, analysisResultCount3++;
                        arrayAnalysisResult3 [analysisResultCount3] = yPositionCenter, analysisResultCount3++;
                        arrayAnalysisResult3 [analysisResultCount3] = xPositionCenter2, analysisResultCount3++;
                        arrayAnalysisResult3 [analysisResultCount3] = yPositionCenter2, analysisResultCount3++;
                    }
                }
            }
            
            delete [] vectorMatchNumber;
            delete [] crossPoint1;
            delete [] crossPoint2;
            delete [] dataOverlap;
            delete [] dataPosition1;
            delete [] dataPosition2;
            delete [] dataLengthAngle1;
            delete [] dataLengthAngle2;
            delete [] crossPositionResult;
        }
    }
    
    delete [] numberOfVector;
    delete [] arrayRelationShip;
    delete [] arrayRelationShip2;
}

@end
