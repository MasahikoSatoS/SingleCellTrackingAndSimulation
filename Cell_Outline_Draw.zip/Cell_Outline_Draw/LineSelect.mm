
// LineSelect.mm
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 24/11/12.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#import "LineSelect.h"

@implementation LineSelect

-(void)lineCombine:(int)typeDefine :(int)lineSet{
    int lineFirstPointTemp = 0;
    int lineSecondPointTemp = 0;
    
    if (lineSet == 1){
        lineFirstPointTemp = lineOneCount/6;
        lineSecondPointTemp = lineFiveCount/6;
    }
    if (lineSet == 3){
        lineFirstPointTemp = lineThreeCount/6;
        lineSecondPointTemp = lineSevenCount/6;
    }
    
    int lineFirstPointTempHold = lineFirstPointTemp;
    int lineSecondPointTempHold = lineSecondPointTemp;
    
    int **lineFirstTemp = new int *[lineFirstPointTempHold+5];
    
    for (int counter1 = 0; counter1 < lineFirstPointTempHold+5; counter1++) lineFirstTemp [counter1] = new int [7];
    
    int **lineSecondTemp = new int *[lineSecondPointTempHold+5];
    for (int counter1 = 0; counter1 < lineSecondPointTempHold+5; counter1++) lineSecondTemp [counter1] = new int [7];
    
    int *arrayLinesDataTemp = new int [(lineFirstPointTempHold+lineSecondPointTempHold)*4+1];
    int *arrayLinkBlockData = new int [(lineFirstPointTempHold+lineSecondPointTempHold)*5+1];
    
    int terminationFlag = 0;
    int arrayLinesDataTempCount = 0;
    int arrayLinkBlockDataCount = 0;
    int latestChoice = 0;
    int overlapCount = 0;
    int lineSecondTempX = 0;
    int lineSecondTempY = 0;
    int mainOrientation = 0;
    int crossPosition1 = 0;
    int crossPosition2 = 0;
    int crossPositionOrientation1 = 0;
    int crossPositionOrientation2 = 0;
    int hitCount = 0;
    int lineFirstTempX = 0;
    int lineFirstTempY = 0;
    int lineBlockSecondTemp = 0;
    int largerNumberSecondFind = 0;
    int lineBlockFirstTemp = 0;
    int largerNumberFirstFind = 0;
    int lineBlockFirst = 0;
    int lineBlockSecond = 0;
    int lineBlockSecondStartCount = 0;
    int lineBlockSecondEndCount = 0;
    int lineBlockFirstEndCount = 0;
    int lineBlockLastNumber = 0;
    int processStartLock = 0;
    int lineSecondTempValue = 0;
    int lineFirstCount = 0;
    int firstLineBlockStartCount = 0;
    int lineFirstTempValue = 0;
    int lineSecondTempBeforeX = 0;
    int lineSecondTempBeforeY = 0;
    int lineFirstTempBeforeX = 0;
    int lineFirstTempBeforeY = 0;
    int outsideLine = 0;
    int lengthFromStartFirst = 0;
    int lengthFromStartSecond = 0;
    int finalChoice = 0;
    int tailLengthCount = 0;
    int lastOverlapFirstX = 0;
    int lastOverlapFirstY = 0;
    int lastOverlapFirstValue = 0;
    int lastOverFirstCount = 0;
    int lengthToEndFirst = 0;
    int lengthToEndSecond = 0;
    int crossWithOtherSecond = 0;
    int blockNumberGet = 0;
    int blockEntry = 0;
    int crossWithOtherFirst = 0;
    int startOverlapNumber = 0;
    int startCount = 0;
    int endOverlapNumber = 0;
    int endCount = 0;
    int startCount2 = 0;
    int endCount2 = 0;
    int lengthShorter = 0;
    int beforeLineOne = 0;
    int beforeLineOneSelected = 0;
    int beforeLineOneLineNumber = 0;
    int beforeLineOneLinkingNumber = 0;
    int findFlagBeforeOne = 0;
    int findFlagBeforeOneLength = 0;
    int afterLineOne = 0;
    int afterLineOneSelected = 0;
    int afterLineOneLineNumber = 0;
    int afterLineOneLinkingNumber = 0;
    int findFlagAfterOne = 0;
    int findFlagAfterOneLength = 0;
    int afterLineTwo = 0;
    int afterLineTwoSelected = 0;
    int afterLineTwoLineNumber = 0;
    int afterLineTwoLinkingNumber = 0;
    int findFlagAfterTwo = 0;
    int findFlagAfterTwoLength = 0;
    int maxFirstLineBlock = 0;
    int maxSecondLineBlock = 0;
    int counterpartBlockNumber1 = 0;
    int counterpartLine1 = 0;
    int counterpartBlockNumber2 = 0;
    int counterpartLine2 = 0;
    int counterpartBlockNumber3 = 0;
    int counterpartLine3 = 0;
    int reviveCont = 0;
    int junctionPoint = 0;
    int counterpartBlockNumber = 0;
    int counterpartLine = 0;
    int arrayLineTempCount1 = 0;
    int arrayLineTempCount2 = 0;
    int blockCountAdjust = 0;
    int blockCountRecord = 0;
    
    do{
        
        arrayLinesDataTempCount = 0;
        arrayLinkBlockDataCount = 0;
        latestChoice = 0;
        terminationFlag = 0;
        lineFirstPointTemp = 0;
        lineSecondPointTemp = 0;
        
        if (lineSet == 1){
            for (int counter1 = 0; counter1 < lineFirstPointTemp; counter1++){
                lineFirstTemp [counter1][0] = arrayLineOne [counter1*6];
                lineFirstTemp [counter1][1] = arrayLineOne [counter1*6+1];
                lineFirstTemp [counter1][2] = arrayLineOne [counter1*6+2];
                lineFirstTemp [counter1][3] = arrayLineOne [counter1*6+3];
                lineFirstTemp [counter1][4] = arrayLineOne [counter1*6+4];
                lineFirstTemp [counter1][5] = 0;
            }
            
            for (int counter1 = 0; counter1 < lineSecondPointTemp; counter1++){
                lineSecondTemp [counter1][0] = arrayLineFive [counter1*6];
                lineSecondTemp [counter1][1] = arrayLineFive [counter1*6+1];
                lineSecondTemp [counter1][2] = arrayLineFive [counter1*6+2];
                lineSecondTemp [counter1][3] = arrayLineFive [counter1*6+3];
                lineSecondTemp [counter1][4] = arrayLineFive [counter1*6+4];
                lineSecondTemp [counter1][5] = 0;
            }
        }
        else if (lineSet == 3){
            for (int counter1 = 0; counter1 < lineFirstPointTemp; counter1++){
                lineFirstTemp [counter1][0] = arrayLineThree [counter1*6];
                lineFirstTemp [counter1][1] = arrayLineThree [counter1*6+1];
                lineFirstTemp [counter1][2] = arrayLineThree [counter1*6+2];
                lineFirstTemp [counter1][3] = arrayLineThree [counter1*6+3];
                lineFirstTemp [counter1][4] = arrayLineThree [counter1*6+4];
                lineFirstTemp [counter1][5] = 0;
            }
            
            for (int counter1 = 0; counter1 < lineSecondPointTemp; counter1++){
                lineSecondTemp [counter1][0] = arrayLineSeven [counter1*6];
                lineSecondTemp [counter1][1] = arrayLineSeven [counter1*6+1];
                lineSecondTemp [counter1][2] = arrayLineSeven [counter1*6+2];
                lineSecondTemp [counter1][3] = arrayLineSeven [counter1*6+3];
                lineSecondTemp [counter1][4] = arrayLineSeven [counter1*6+4];
                lineSecondTemp [counter1][5] = 0;
            }
        }
        
        //for (int counterA = 0; counterA < lineFirstPointTemp; counterA++){
        //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<lineFirstTemp [counterA][counterB];
        //	cout<<" lineFirstTemp "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < lineSecondPointTemp; counterA++){
        //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<lineSecondTemp [counterA][counterB];
        //	cout<<" lineSecondTemp "<<counterA<<endl;
        //}
        
        //==========CROS POINT FIND==========
        //------Within Block, number must be lower to higher------
        overlapCount = 0;
        
        for (int counter1 = 0; counter1 < lineSecondPointTemp; counter1++){
            lineSecondTempX = lineSecondTemp [counter1][0];
            lineSecondTempY = lineSecondTemp [counter1][1];
            
            mainOrientation = 0;
            crossPosition1 = 0;
            crossPosition2 = 0;
            crossPositionOrientation1 = 0;
            crossPositionOrientation2 = 0;
            hitCount = -1;
            
            if (typeDefine == 1){
                if (counter1 != lineSecondPointTemp-1){
                    if (lineSecondTempX-1 == lineSecondTemp [counter1+1][0] && lineSecondTempY-1 == lineSecondTemp [counter1+1][1]) mainOrientation = 1;
                    if (lineSecondTempX+1 == lineSecondTemp [counter1+1][0] && lineSecondTempY-1 == lineSecondTemp [counter1+1][1]) mainOrientation = 2;
                }
            }
            if (typeDefine == 3){
                if (counter1 != lineSecondPointTemp-1){
                    if (lineSecondTempX-1 == lineSecondTemp [counter1+1][0] && lineSecondTempY+1 == lineSecondTemp [counter1+1][1]) mainOrientation = 1;
                    if (lineSecondTempX+1 == lineSecondTemp [counter1+1][0] && lineSecondTempY+1 == lineSecondTemp [counter1+1][1]) mainOrientation = 2;
                }
            }
            
            for (int counter2 = 0; counter2 < lineFirstPointTemp; counter2++){
                lineFirstTempX = lineFirstTemp [counter2][0];
                lineFirstTempY = lineFirstTemp [counter2][1];
                
                if (lineSecondTempX == lineFirstTempX && lineSecondTempY == lineFirstTempY){
                    lineBlockSecondTemp = lineSecondTemp [counter1][3];
                    largerNumberSecondFind = 0;
                    lineBlockFirstTemp = lineFirstTemp [counter2][3];
                    largerNumberFirstFind = 0;
                    
                    for (int counter3 = counter1; counter3 < lineSecondPointTemp; counter3++){
                        if (lineSecondTemp [counter3][3] == lineBlockSecondTemp && lineSecondTemp [counter3][5] != 0){
                            largerNumberSecondFind = 1;
                            break;
                        }
                    }
                    
                    for (int counter3 = counter2; counter3 < lineFirstPointTemp; counter3++){
                        if (lineFirstTemp [counter3][3] == lineBlockFirstTemp && lineFirstTemp [counter3][5] != 0){
                            largerNumberFirstFind = 1;
                            break;
                        }
                    }
                    
                    if (largerNumberSecondFind == 0 && largerNumberFirstFind == 0){
                        overlapCount++;
                        lineSecondTemp [counter1][5] = overlapCount;
                        lineFirstTemp [counter2][5] = overlapCount;
                        break;
                    }
                }
                else{
                    //------Cross Point 1 2 -- 2 1------2: Tracking line (type 1), upwards, check line one occupy 1 positions, check incoming direction, from up, matching point is bottom ------
                    //------ 2 1 ---1 2------
                    
                    //------Cross Point 1 2 -- 2 1------2: Tracking line (type 2), downwards, check line one occupy 1 positions, check incoming direction, from up, matching point is bottom ------
                    //------ 2 1 ---1 2------
                    
                    if (typeDefine == 1){
                        if (hitCount == -1){
                            if (lineSecondTempX-1 == lineFirstTempX && lineSecondTempY == lineFirstTempY){
                                crossPosition1 = counter2;
                                crossPositionOrientation1 = 1;
                                hitCount = counter2;
                            }
                            
                            if (lineSecondTempX == lineFirstTempX && lineSecondTempY-1 == lineFirstTempY){
                                crossPosition1 = counter2;
                                crossPositionOrientation1 = 2;
                                hitCount = counter2;
                            }
                            
                            if (lineSecondTempX+1 == lineFirstTempX && lineSecondTempY == lineFirstTempY){
                                crossPosition1 = counter2;
                                crossPositionOrientation1 = 3;
                                hitCount = counter2;
                            }
                        }
                        else{
                            
                            if (lineSecondTempX-1 == lineFirstTempX && lineSecondTempY == lineFirstTempY){
                                crossPosition2 = counter2;
                                crossPositionOrientation2 = 1;
                            }
                            
                            if (lineSecondTempX == lineFirstTempX && lineSecondTempY-1 == lineFirstTempY){
                                crossPosition2 = counter2;
                                crossPositionOrientation2 = 2;
                            }
                            
                            if (lineSecondTempX+1 == lineFirstTempX && lineSecondTempY == lineFirstTempY){
                                crossPosition2 = counter2;
                                crossPositionOrientation2 = 3;
                            }
                        }
                    }
                    
                    if (typeDefine == 3){
                        if (hitCount == -1){
                            if (lineSecondTempX-1 == lineFirstTempX && lineSecondTempY == lineFirstTempY){
                                crossPosition1 = counter2;
                                crossPositionOrientation1 = 1;
                                hitCount = counter2;
                            }
                            
                            if (lineSecondTempX == lineFirstTempX && lineSecondTempY+1 == lineFirstTempY){
                                crossPosition1 = counter2;
                                crossPositionOrientation1 = 2;
                                hitCount = counter2;
                            }
                            
                            if (lineSecondTempX+1 == lineFirstTempX && lineSecondTempY == lineFirstTempY){
                                crossPosition1 = counter2;
                                crossPositionOrientation1 = 3;
                                hitCount = counter2;
                            }
                        }
                        else{
                            
                            if (lineSecondTempX-1 == lineFirstTempX && lineSecondTempY == lineFirstTempY){
                                crossPosition2 = counter2;
                                crossPositionOrientation2 = 1;
                            }
                            
                            if (lineSecondTempX == lineFirstTempX && lineSecondTempY+1 == lineFirstTempY){
                                crossPosition2 = counter2;
                                crossPositionOrientation2 = 2;
                            }
                            
                            if (lineSecondTempX+1 == lineFirstTempX && lineSecondTempY == lineFirstTempY){
                                crossPosition2 = counter2;
                                crossPositionOrientation2 = 3;
                            }
                        }
                    }
                    if (counter2 == hitCount+1){
                        if (crossPosition1 != -1 && crossPosition2 != -1){
                            if (mainOrientation == 1 && crossPositionOrientation1 == 1 && crossPositionOrientation2 == 2){
                                lineBlockSecondTemp = lineSecondTemp [counter1+1][3];
                                largerNumberSecondFind = 0;
                                lineBlockFirstTemp = lineFirstTemp [crossPosition2][3];
                                largerNumberFirstFind = 0;
                                
                                for (int counter3 = counter1+1; counter3 < lineSecondPointTemp; counter3++){
                                    if (lineSecondTemp [counter3][3] == lineBlockSecondTemp && lineSecondTemp [counter3][5] != 0){
                                        largerNumberSecondFind = 1;
                                        break;
                                    }
                                }
                                
                                for (int counter3 = crossPosition2; counter3 < lineFirstPointTemp; counter3++){
                                    if (lineFirstTemp [counter3][3] == lineBlockFirstTemp && lineFirstTemp [counter3][5] != 0){
                                        largerNumberFirstFind = 1;
                                        break;
                                    }
                                }
                                
                                if (largerNumberSecondFind == 0 && largerNumberFirstFind == 0){
                                    overlapCount++;
                                    lineSecondTemp [counter1+1][5] = overlapCount;
                                    lineFirstTemp [crossPosition2][5] = overlapCount;
                                    break;
                                }
                            }
                            if (mainOrientation == 1 && crossPositionOrientation1 == 2 && crossPositionOrientation2 == 1){
                                lineBlockSecondTemp = lineSecondTemp [counter1][3];
                                largerNumberSecondFind = 0;
                                lineBlockFirstTemp = lineFirstTemp [crossPosition1][3];
                                largerNumberFirstFind = 0;
                                
                                for (int counter3 = counter1+1; counter3 < lineSecondPointTemp; counter3++){
                                    if (lineSecondTemp [counter3][3] == lineBlockSecondTemp && lineSecondTemp [counter3][5] != 0){
                                        largerNumberSecondFind = 1;
                                        break;
                                    }
                                }
                                
                                for (int counter3 = crossPosition2; counter3 < lineFirstPointTemp; counter3++){
                                    if (lineFirstTemp [counter3][3] == lineBlockFirstTemp && lineFirstTemp [counter3][5] != 0){
                                        largerNumberFirstFind = 1;
                                        break;
                                    }
                                }
                                
                                if (largerNumberSecondFind == 0 && largerNumberFirstFind == 0){
                                    overlapCount++;
                                    lineSecondTemp [counter1][5] = overlapCount;
                                    lineFirstTemp [crossPosition1][5] = overlapCount;
                                    break;
                                }
                            }
                            if (mainOrientation == 2 && crossPositionOrientation1 == 3 && crossPositionOrientation2 == 2){
                                lineBlockSecondTemp = lineSecondTemp [counter1+1][3];
                                largerNumberSecondFind = 0;
                                lineBlockFirstTemp = lineFirstTemp [crossPosition1][3];
                                largerNumberFirstFind = 0;
                                
                                for (int counter3 = counter1+1; counter3 < lineSecondPointTemp; counter3++){
                                    if (lineSecondTemp [counter3][3] == lineBlockSecondTemp && lineSecondTemp [counter3][5] != 0){
                                        largerNumberSecondFind = 1;
                                        break;
                                    }
                                }
                                
                                for (int counter3 = crossPosition2; counter3 < lineFirstPointTemp; counter3++){
                                    if (lineFirstTemp [counter3][3] == lineBlockFirstTemp && lineFirstTemp [counter3][5] != 0){
                                        largerNumberFirstFind = 1;
                                        break;
                                    }
                                }
                                
                                if (largerNumberSecondFind == 0 && largerNumberFirstFind == 0){
                                    overlapCount++;
                                    lineSecondTemp [counter1+1][5] = overlapCount;
                                    lineFirstTemp [crossPosition1][5] = overlapCount;
                                    break;
                                }
                            }
                            
                            if (mainOrientation == 2 && crossPositionOrientation1 == 2 && crossPositionOrientation2 == 3){
                                lineBlockSecondTemp = lineSecondTemp [counter1][3];
                                largerNumberSecondFind = 0;
                                lineBlockFirstTemp = lineFirstTemp [crossPosition2][3];
                                largerNumberFirstFind = 0;
                                
                                for (int counter3 = counter1+1; counter3 < lineSecondPointTemp; counter3++){
                                    if (lineSecondTemp [counter3][3] == lineBlockSecondTemp && lineSecondTemp [counter3][5] != 0){
                                        largerNumberSecondFind = 1;
                                        break;
                                    }
                                }
                                
                                for (int counter3 = crossPosition2; counter3 < lineFirstPointTemp; counter3++){
                                    if (lineFirstTemp [counter3][3] == lineBlockFirstTemp && lineFirstTemp [counter3][5] != 0){
                                        largerNumberFirstFind = 1;
                                        break;
                                    }
                                }
                                
                                if (largerNumberSecondFind == 0 && largerNumberFirstFind == 0){
                                    overlapCount++;
                                    lineSecondTemp [counter1][5] = overlapCount;
                                    lineFirstTemp [crossPosition2][5] = overlapCount;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
        
        //for (int counterA = 0; counterA < lineFirstPointTemp; counterA++){
        //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<lineFirstTemp [counterA][counterB];
        //	cout<<"lineFirstTemp "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < lineSecondPointTemp; counterA++){
        //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<lineSecondTemp [counterA][counterB];
        //	cout<<"lineSecondTemp "<<counterA<<endl;
        //}
        
        //==========Process Start==========
        if (overlapCount != 0){
            lineBlockFirst = 0;
            lineBlockSecond = lineSecondTemp [0][3];
            lineBlockSecondStartCount = 0;
            lineBlockSecondEndCount = 0;
            lineBlockFirstEndCount = 0;
            lineBlockLastNumber = -1;
            processStartLock = 0;
            
            for (int counter1 = 0; counter1 < lineSecondPointTemp; counter1++){
                lineSecondTempX = lineSecondTemp [counter1][0];
                lineSecondTempY = lineSecondTemp [counter1][1];
                lineSecondTempValue = lineSecondTemp [counter1][2];
                
                if (lineBlockSecond != lineSecondTemp [counter1][3] && processStartLock == 0){
                    lineBlockSecond = lineSecondTemp [counter1][3];
                    lineBlockSecondStartCount = counter1;
                }
                
                //==========Cross Point NO 1 Find: Line before the NO 1 Point Process (Line START-Cross Point-1)==========
                if (lineSecondTemp [counter1][5] == 1){
                    lineFirstCount = 0;
                    
                    for (int counter2 = lineBlockSecondStartCount; counter2 < lineSecondPointTemp; counter2++){
                        if (lineSecondTemp [counter2][3] == lineBlockSecond) lineBlockSecondEndCount = counter2;
                        else{
                            
                            break;
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < lineFirstPointTemp; counter2++){
                        if (lineFirstTemp [counter2][5] == 1){
                            lineBlockFirst = lineFirstTemp [counter2][3];
                            lineFirstCount = counter2;
                            break;
                        }
                    }
                    
                    firstLineBlockStartCount = 0;
                    
                    for (int counter2 = 0; counter2 < lineFirstPointTemp; counter2++){
                        if (lineFirstTemp [counter2][3] == lineBlockFirst){
                            firstLineBlockStartCount = counter2;
                            break;
                        }
                    }
                    
                    for (int counter2 = firstLineBlockStartCount; counter2 < lineFirstPointTemp; counter2++){
                        if (lineFirstTemp [counter2][3] == lineBlockFirst) lineBlockFirstEndCount = counter2;
                        else{
                            
                            break;
                        }
                    }
                    
                    lineBlockLastNumber = 1;
                    
                    for (int counter2 = 0; counter2 < lineSecondPointTemp; counter2++){
                        if (lineSecondTemp [counter2][5] > 1){
                            if (lineBlockSecond == lineSecondTemp [counter2][3]){
                                for (int counter3 = 0; counter3 < lineFirstPointTemp; counter3++){
                                    if (lineFirstTemp [counter3][5] == lineSecondTemp [counter2][5]){
                                        if (lineFirstTemp [counter3][3] == lineBlockFirst){
                                            lineBlockLastNumber++;
                                            lineFirstTemp [counter3][5] = lineBlockLastNumber;
                                            lineSecondTemp [counter2][5] = lineBlockLastNumber;
                                        }
                                        else{
                                            
                                            lineFirstTemp [counter3][5] = lineFirstTemp [counter3][5]*-10;
                                            lineSecondTemp [counter2][5] = lineSecondTemp [counter2][5]*-10;
                                        }
                                        
                                        break;
                                    }
                                }
                            }
                            else{
                                
                                for (int counter3 = 0; counter3 < lineFirstPointTemp; counter3++){
                                    if (lineFirstTemp [counter3][5] == lineSecondTemp [counter2][5]) lineFirstTemp [counter3][5] = lineFirstTemp [counter3][5]*-10;
                                }
                                
                                lineSecondTemp [counter2][5] = lineSecondTemp [counter2][5]*-10;
                            }
                        }
                    }
                    
                    if (lineFirstCount == firstLineBlockStartCount && counter1 != lineBlockSecondStartCount){
                        latestChoice = 2;
                        
                        for (int counter2 = lineBlockSecondStartCount; counter2 < counter1; counter2++){
                            lineSecondTempX = lineSecondTemp [counter2][0];
                            lineSecondTempY = lineSecondTemp [counter2][1];
                            lineSecondTempValue = lineSecondTemp [counter2][2];
                            
                            arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempX, arrayLinesDataTempCount++;
                            arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempY, arrayLinesDataTempCount++;
                            arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempValue, arrayLinesDataTempCount++;
                            lineSecondTemp [counter2][5] = -1;
                        }
                    }
                    
                    if (lineFirstCount != firstLineBlockStartCount && counter1 == lineBlockSecondStartCount){
                        latestChoice = 1;
                        
                        for (int counter2 = firstLineBlockStartCount; counter2 < lineFirstCount; counter2++){
                            lineFirstTempX = lineFirstTemp [counter2][0];
                            lineFirstTempY = lineFirstTemp [counter2][1];
                            lineFirstTempValue = lineFirstTemp [counter2][2];
                            
                            arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTempX, arrayLinesDataTempCount++;
                            arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTempY, arrayLinesDataTempCount++;
                            arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTempValue, arrayLinesDataTempCount++;
                            
                            if (lineFirstTemp [counter2][5] < -3){
                                arrayLinkBlockData [arrayLinkBlockDataCount] = 0, arrayLinkBlockDataCount++; //------Start: 0, End: 1------
                                arrayLinkBlockData [arrayLinkBlockDataCount] = 0, arrayLinkBlockDataCount++; //------Selected: 0, Non-selected: 1, Tail length indication (Only for non-selected): 2------
                                arrayLinkBlockData [arrayLinkBlockDataCount] = 1, arrayLinkBlockDataCount++; //------Line number------
                                arrayLinkBlockData [arrayLinkBlockDataCount] = lineFirstTemp [counter2][5], arrayLinkBlockDataCount++;
                            }
                            
                            lineFirstTemp [counter2][5] = -1;
                        }
                    }
                    
                    if (lineFirstCount != firstLineBlockStartCount && counter1 != lineBlockSecondStartCount){
                        lineSecondTempBeforeX = lineSecondTemp [counter1-1][0];
                        lineSecondTempBeforeY = lineSecondTemp [counter1-1][1];
                        lineFirstTempBeforeX = lineFirstTemp [lineFirstCount-1][0];
                        lineFirstTempBeforeY = lineFirstTemp [lineFirstCount-1][1];
                        outsideLine = 0;
                        
                        if (typeDefine == 1){
                            if (lineFirstTempBeforeX > lineSecondTempBeforeX) outsideLine = 2;
                            else if (lineFirstTempBeforeX < lineSecondTempBeforeX) outsideLine = 1;
                            else if (lineSecondTempBeforeY > lineFirstTempBeforeY) outsideLine = 1;
                            else outsideLine = 2;
                        }
                        
                        if (typeDefine == 3){
                            if (lineFirstTempBeforeX > lineSecondTempBeforeX) outsideLine = 1;
                            else if (lineFirstTempBeforeX < lineSecondTempBeforeX) outsideLine = 2;
                            else if (lineSecondTempBeforeY > lineFirstTempBeforeY) outsideLine = 2;
                            else outsideLine = 1;
                        }
                        
                        lengthFromStartFirst = lineFirstCount-firstLineBlockStartCount+1;
                        lengthFromStartSecond = counter1-lineBlockSecondStartCount+1;
                        finalChoice = 0;
                        
                        if (typeDefine == 1 && lengthFromStartFirst >= 7 && lengthFromStartSecond >= 7 && lengthFromStartFirst > lengthFromStartSecond+5) finalChoice = 1;
                        else if (typeDefine == 1 && lengthFromStartFirst >= 7 && lengthFromStartSecond >= 7 && lengthFromStartFirst < lengthFromStartSecond+5) finalChoice = 2;
                        else if (typeDefine == 1 && lengthFromStartFirst < 7 && lengthFromStartFirst >= 3 && lengthFromStartSecond >= 7) finalChoice = 2;
                        else if (typeDefine == 1 && lengthFromStartFirst < 3 && lengthFromStartSecond >= 7) finalChoice = 2;
                        else if (typeDefine == 1 && lengthFromStartFirst >= 7 && lengthFromStartSecond < 7 && lengthFromStartSecond >= 5) finalChoice = 1;
                        else if (typeDefine == 1 && lengthFromStartFirst >= 7 && lengthFromStartSecond < 5 && lengthFromStartSecond >= 3) finalChoice = 2;
                        else if (typeDefine == 1 && lengthFromStartFirst >= 7 && lengthFromStartSecond < 3) finalChoice = 1;
                        else if (typeDefine == 1 && lengthFromStartFirst < 7 && lengthFromStartFirst >= 3 && lengthFromStartSecond < 7 && lengthFromStartSecond >= 3) finalChoice = 1;
                        else if (typeDefine == 1 && lengthFromStartFirst < 7 && lengthFromStartFirst >= 3 && lengthFromStartSecond < 3) finalChoice = 1;
                        else if (typeDefine == 1 && lengthFromStartFirst < 3 && lengthFromStartSecond < 7 && lengthFromStartSecond >= 3) finalChoice = 2;
                        else if (typeDefine == 1 && lengthFromStartFirst < 3 && lengthFromStartSecond < 3) finalChoice = 1;
                        else if (typeDefine == 3 && outsideLine == 1 && lengthFromStartFirst >= 7 && lengthFromStartSecond >= 7 && lengthFromStartFirst >= lengthFromStartSecond) finalChoice = 1;
                        else if (typeDefine == 3 && outsideLine == 1 && lengthFromStartFirst >= 7 && lengthFromStartSecond >= 7 && lengthFromStartFirst < lengthFromStartSecond) finalChoice = 2;
                        else if (typeDefine == 3 && outsideLine == 1 && lengthFromStartFirst < 7 && lengthFromStartFirst >= 3 && lengthFromStartSecond >= 7) finalChoice = 2;
                        else if (typeDefine == 3 && outsideLine == 1 && lengthFromStartFirst < 3 && lengthFromStartSecond >= 7) finalChoice = 2;
                        else if (typeDefine == 3 && outsideLine == 1 && lengthFromStartFirst >= 7 && lengthFromStartSecond < 7 && lengthFromStartSecond >= 3) finalChoice = 1;
                        else if (typeDefine == 3 && outsideLine == 1 && lengthFromStartFirst >= 7 && lengthFromStartSecond < 3) finalChoice = 1;
                        else if (typeDefine == 3 && outsideLine == 1 && lengthFromStartFirst < 7 && lengthFromStartFirst >= 3 && lengthFromStartSecond < 7 && lengthFromStartSecond >= 3) finalChoice = 1;
                        else if (typeDefine == 3 && outsideLine == 1 && lengthFromStartFirst < 7 && lengthFromStartFirst >= 3 && lengthFromStartSecond < 3) finalChoice = 1;
                        else if (typeDefine == 3 && outsideLine == 1 && lengthFromStartFirst < 3 && lengthFromStartSecond < 7 && lengthFromStartSecond >= 3) finalChoice = 2;
                        else if (typeDefine == 3 && outsideLine == 1 && lengthFromStartFirst < 3 && lengthFromStartSecond < 3) finalChoice = 1;
                        else if (typeDefine == 3 && outsideLine == 2 && lengthFromStartFirst >= 7 && lengthFromStartSecond >= 7 && lengthFromStartFirst > lengthFromStartSecond) finalChoice = 1;
                        else if (typeDefine == 3 && outsideLine == 2 && lengthFromStartFirst >= 7 && lengthFromStartSecond >= 7 && lengthFromStartFirst <= lengthFromStartSecond) finalChoice = 2;
                        else if (typeDefine == 3 && outsideLine == 2 && lengthFromStartFirst < 7 && lengthFromStartFirst >= 3 && lengthFromStartSecond >= 7) finalChoice = 2;
                        else if (typeDefine == 3 && outsideLine == 2 && lengthFromStartFirst < 3 && lengthFromStartSecond >= 7) finalChoice = 2;
                        else if (typeDefine == 3 && outsideLine == 2 && lengthFromStartFirst >= 7 && lengthFromStartSecond < 7 && lengthFromStartSecond >= 3) finalChoice = 1;
                        else if (typeDefine == 3 && outsideLine == 2 && lengthFromStartFirst >= 7 && lengthFromStartSecond < 3) finalChoice = 1;
                        else if (typeDefine == 3 && outsideLine == 2 && lengthFromStartFirst < 7 && lengthFromStartFirst >= 3 && lengthFromStartSecond < 7 && lengthFromStartSecond >= 3) finalChoice = 2;
                        else if (typeDefine == 3 && outsideLine == 2 && lengthFromStartFirst < 7 && lengthFromStartFirst >= 3 && lengthFromStartSecond < 3) finalChoice = 1;
                        else if (typeDefine == 3 && outsideLine == 2 && lengthFromStartFirst < 3 && lengthFromStartSecond < 7 && lengthFromStartSecond >= 3) finalChoice = 2;
                        else if (typeDefine == 3 && outsideLine == 2 && lengthFromStartFirst < 3 && lengthFromStartSecond < 3) finalChoice = 2;
                        
                        //cout<<finalChoice<<" "<<outsideLine<<" "<<lengthFromStartSecond<<" "<<lengthFromStartFirst<<" Choice_First"<<endl;
                        
                        if (finalChoice == 1){
                            latestChoice = 1;
                            
                            for (int counter2 = firstLineBlockStartCount; counter2 < lineFirstCount; counter2++){
                                lineFirstTempX = lineFirstTemp [counter2][0];
                                lineFirstTempY = lineFirstTemp [counter2][1];
                                lineFirstTempValue = lineFirstTemp [counter2][2];
                                
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTempX, arrayLinesDataTempCount++;
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTempY, arrayLinesDataTempCount++;
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTempValue, arrayLinesDataTempCount++;
                                
                                if (lineFirstTemp [counter2][5] < -3){
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = 0, arrayLinkBlockDataCount++; //------Start: 0, End: 1------
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = 0, arrayLinkBlockDataCount++; //------Selected: 0, Non-selected: 1------
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = 1, arrayLinkBlockDataCount++; //------Line number------
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = lineFirstTemp [counter2][5], arrayLinkBlockDataCount++;
                                }
                                
                                lineFirstTemp [counter2][5] = -1;
                            }
                            
                            tailLengthCount = 0;
                            
                            for (int counter2 = lineBlockSecondStartCount; counter2 < counter1; counter2++){
                                tailLengthCount++;
                                lineSecondTemp [counter2][5] = -2;
                            }
                            
                            arrayLinkBlockData [arrayLinkBlockDataCount] = 0, arrayLinkBlockDataCount++; //------Start: 0, End: 1------
                            arrayLinkBlockData [arrayLinkBlockDataCount] = 2, arrayLinkBlockDataCount++; //------Selected: 0, Non-selected: 1, Tail length indication (Only for non-selected): 2------
                            arrayLinkBlockData [arrayLinkBlockDataCount] = 2, arrayLinkBlockDataCount++; //------Line number------
                            arrayLinkBlockData [arrayLinkBlockDataCount] = tailLengthCount, arrayLinkBlockDataCount++;
                        }
                        
                        if (finalChoice == 2){
                            latestChoice = 2;
                            tailLengthCount = 0;
                            
                            for (int counter2 = firstLineBlockStartCount; counter2 < lineFirstCount; counter2++){
                                if (lineFirstTemp [counter2][5] < -3){
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = 0, arrayLinkBlockDataCount++; //------Start: 0, End: 1------
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = 1, arrayLinkBlockDataCount++; //------Selected: 0, Non-selected: 1------
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = 1, arrayLinkBlockDataCount++; //------Line number------
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = lineFirstTemp [counter2][5], arrayLinkBlockDataCount++;
                                }
                                
                                tailLengthCount++;
                                lineFirstTemp [counter2][5] = -2;
                            }
                            
                            arrayLinkBlockData [arrayLinkBlockDataCount] = 0, arrayLinkBlockDataCount++; //------Start: 0, End: 1------
                            arrayLinkBlockData [arrayLinkBlockDataCount] = 2, arrayLinkBlockDataCount++; //------Selected: 0, Non-selected: 1, Tail length indication (Only for non-selected): 2------
                            arrayLinkBlockData [arrayLinkBlockDataCount] = 1, arrayLinkBlockDataCount++; //------Line number------
                            arrayLinkBlockData [arrayLinkBlockDataCount] = tailLengthCount, arrayLinkBlockDataCount++;
                            
                            for (int counter2 = lineBlockSecondStartCount; counter2 < counter1; counter2++){
                                lineSecondTempX = lineSecondTemp [counter2][0];
                                lineSecondTempY = lineSecondTemp [counter2][1];
                                lineSecondTempValue = lineSecondTemp [counter2][2];
                                
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempX, arrayLinesDataTempCount++;
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempY, arrayLinesDataTempCount++;
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempValue, arrayLinesDataTempCount++;
                                lineSecondTemp [counter2][5] = -1;
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineFirstPointTemp; counterA++){
                    //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<lineFirstTemp [counterA][counterB];
                    //	cout<<"lineFirstTemp "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < lineSecondPointTemp; counterA++){
                    //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<lineSecondTemp [counterA][counterB];
                    //	cout<<"lineSecondTemp "<<counterA<<endl;
                    //}
                }
                
                //==========Cross Point LAST Find: If Cross point NO 1 is the LAST one, Process (Cross Point LAST (or 1)-Line End)==========
                if (lineSecondTemp [counter1][5] == lineBlockLastNumber || lineBlockLastNumber == 1){
                    lastOverlapFirstX = 0;
                    lastOverlapFirstY = 0;
                    lastOverlapFirstValue = 0;
                    lastOverFirstCount = 0;
                    
                    for (int counter2 = 0; counter2 < lineFirstPointTemp; counter2++){
                        if (lineFirstTemp [counter2][5] == lineBlockLastNumber){
                            lastOverlapFirstX = lineFirstTemp [counter2][0];
                            lastOverlapFirstY = lineFirstTemp [counter2][1];
                            lastOverlapFirstValue = lineFirstTemp [counter2][2];
                            lastOverFirstCount = counter2;
                            break;
                        }
                    }
                    
                    if (latestChoice == 2 || latestChoice == 0){
                        arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempX, arrayLinesDataTempCount++;
                        arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempY, arrayLinesDataTempCount++;
                        arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempValue, arrayLinesDataTempCount++;
                        
                        lineFirstTemp [lastOverFirstCount][5] = -3;
                        lineSecondTemp [counter1][5] = -3;
                    }
                    else{
                        
                        arrayLinesDataTemp [arrayLinesDataTempCount] = lastOverlapFirstX, arrayLinesDataTempCount++;
                        arrayLinesDataTemp [arrayLinesDataTempCount] = lastOverlapFirstY, arrayLinesDataTempCount++;
                        arrayLinesDataTemp [arrayLinesDataTempCount] = lastOverlapFirstValue, arrayLinesDataTempCount++;
                        
                        lineFirstTemp [lastOverFirstCount][5] = -3;
                        lineSecondTemp [counter1][5] = -3;
                    }
                    
                    if (counter1 == lineBlockSecondEndCount && lastOverFirstCount != lineBlockFirstEndCount){
                        for (int counter2 = lastOverFirstCount+1; counter2 <= lineBlockFirstEndCount; counter2++){
                            lineFirstTempX = lineFirstTemp [counter2][0];
                            lineFirstTempY = lineFirstTemp [counter2][1];
                            lineFirstTempValue = lineFirstTemp [counter2][2];
                            
                            arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTempX, arrayLinesDataTempCount++;
                            arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTempY, arrayLinesDataTempCount++;
                            arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTempValue, arrayLinesDataTempCount++;
                            
                            if (lineFirstTemp [counter2][5] < -3){
                                arrayLinkBlockData [arrayLinkBlockDataCount] = 1, arrayLinkBlockDataCount++; //------Start: 0, End: 1------
                                arrayLinkBlockData [arrayLinkBlockDataCount] = 0, arrayLinkBlockDataCount++; //------Selected: 0, Non-selected: 1------
                                arrayLinkBlockData [arrayLinkBlockDataCount] = 1, arrayLinkBlockDataCount++; //------Line number------
                                arrayLinkBlockData [arrayLinkBlockDataCount] = lineFirstTemp [counter2][5], arrayLinkBlockDataCount++;
                            }
                            
                            lineFirstTemp [counter2][5] = -1;
                        }
                    }
                    
                    if (counter1 != lineBlockSecondEndCount && lastOverFirstCount == lineBlockFirstEndCount){
                        for (int counter2 = counter1+1; counter2 <= lineBlockSecondEndCount; counter2++){
                            lineSecondTempX = lineSecondTemp [counter2][0];
                            lineSecondTempY = lineSecondTemp [counter2][1];
                            lineSecondTempValue = lineSecondTemp [counter2][2];
                            
                            arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempX, arrayLinesDataTempCount++;
                            arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempY, arrayLinesDataTempCount++;
                            arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempValue, arrayLinesDataTempCount++;
                            
                            if (lineSecondTemp [counter2][5] < -3){
                                arrayLinkBlockData [arrayLinkBlockDataCount] = 1, arrayLinkBlockDataCount++; //------Start: 0, End: 1------
                                arrayLinkBlockData [arrayLinkBlockDataCount] = 0, arrayLinkBlockDataCount++; //------Selected: 0, Non-selected: 1------
                                arrayLinkBlockData [arrayLinkBlockDataCount] = 2, arrayLinkBlockDataCount++; //------Line number------
                                arrayLinkBlockData [arrayLinkBlockDataCount] = lineSecondTemp [counter2][5], arrayLinkBlockDataCount++;
                            }
                            
                            lineSecondTemp [counter2][5] = -1;
                        }
                    }
                    
                    if (counter1 != lineBlockSecondEndCount && lastOverFirstCount != lineBlockFirstEndCount){
                        outsideLine = 0;
                        
                        if (typeDefine == 1){
                            if (lineFirstTemp [lastOverFirstCount+1][0] > lineSecondTemp [counter1+1][0]) outsideLine = 2;
                            else if (lineFirstTemp [lastOverFirstCount+1][0] < lineSecondTemp [counter1+1][0]) outsideLine = 1;
                            else if (lineSecondTemp [counter1+1][1] > lineFirstTemp [lastOverFirstCount+1][1]) outsideLine = 1;
                            else outsideLine = 2;
                        }
                        
                        if (typeDefine == 3){
                            if (lineFirstTemp [lastOverFirstCount+1][0] > lineSecondTemp [counter1+1][0]) outsideLine = 1;
                            else if (lineFirstTemp [lastOverFirstCount+1][0] < lineSecondTemp [counter1+1][0]) outsideLine = 2;
                            else if (lineSecondTemp [counter1+1][1] > lineFirstTemp [lastOverFirstCount+1][1]) outsideLine = 2;
                            else outsideLine = 1;
                        }
                        
                        lengthToEndFirst = lineBlockFirstEndCount-lastOverFirstCount+1;
                        lengthToEndSecond = lineBlockSecondEndCount-counter1+1;
                        crossWithOtherSecond = 0;
                        
                        for (int counter2 = counter1+1; counter2 <= lineBlockSecondEndCount; counter2++){
                            if (lineSecondTemp [counter2][5] < 0){
                                blockNumberGet = 0;
                                blockEntry = 0;
                                
                                for (int counter3 = 0; counter3 < lineFirstPointTemp; counter3++){
                                    if (lineSecondTemp [counter2][5] == lineFirstTemp [counter3][5]){
                                        blockNumberGet = lineFirstTemp [counter3][3];
                                        break;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < lineFirstPointTemp; counter3++){
                                    if (blockNumberGet == lineFirstTemp [counter3][3] && lineFirstTemp [counter3][5] == 0) blockEntry++;
                                }
                                
                                if (crossWithOtherSecond < blockEntry) crossWithOtherSecond++;
                            }
                        }
                        
                        crossWithOtherFirst = 0;
                        
                        for (int counter2 = lastOverFirstCount+1; counter2 <= lineBlockFirstEndCount; counter2++){
                            if (lineFirstTemp [counter2][5] < 0){
                                blockNumberGet = 0;
                                blockEntry = 0;
                                
                                for (int counter3 = 0; counter3 < lineSecondPointTemp; counter3++){
                                    if (lineFirstTemp [counter2][5] == lineSecondTemp [counter3][5]){
                                        blockNumberGet = lineSecondTemp [counter3][3];
                                        break;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < lineSecondPointTemp; counter3++){
                                    if (blockNumberGet == lineSecondTemp [counter3][3] && lineSecondTemp [counter3][5] == 0) blockEntry++;
                                }
                                
                                if (crossWithOtherFirst < blockEntry) crossWithOtherFirst++;
                            }
                        }
                        
                        if (outsideLine == 2 && lengthToEndFirst-lengthToEndSecond > 5 && crossWithOtherFirst > crossWithOtherSecond) finalChoice = 1;
                        else if (outsideLine == 1 && lengthToEndSecond-lengthToEndFirst > 5 && crossWithOtherFirst < crossWithOtherSecond) finalChoice = 2;
                        else if (outsideLine == 2 && lengthToEndFirst-lengthToEndSecond <= 5 && crossWithOtherFirst > crossWithOtherSecond) finalChoice = 1;
                        else if (outsideLine == 1 && lengthToEndSecond-lengthToEndFirst <= 5 && crossWithOtherFirst < crossWithOtherSecond) finalChoice = 2;
                        else if (outsideLine == 2 && lengthToEndFirst-lengthToEndSecond > 5 && crossWithOtherFirst == crossWithOtherSecond) finalChoice = 1;
                        else if (outsideLine == 1 && lengthToEndSecond-lengthToEndFirst > 5 && crossWithOtherFirst == crossWithOtherSecond) finalChoice = 2;
                        else if (typeDefine == 1 && outsideLine == 1 && lengthToEndSecond-lengthToEndFirst <= 5 && crossWithOtherFirst == crossWithOtherSecond) finalChoice = 2;
                        else if (typeDefine == 1 && outsideLine == 2 && lengthToEndSecond-lengthToEndFirst <= 5 && crossWithOtherFirst == crossWithOtherSecond) finalChoice = 1;
                        else if (typeDefine == 3 && outsideLine == 1 && lengthToEndSecond-lengthToEndFirst <= 5 && crossWithOtherFirst == crossWithOtherSecond) finalChoice = 1;
                        else if (typeDefine == 3 && outsideLine == 2 && lengthToEndSecond-lengthToEndFirst <= 5 && crossWithOtherFirst == crossWithOtherSecond) finalChoice = 2;
                        else finalChoice = 2;
                        
                        //cout<<finalChoice<<" "<<outsideLine<<" "<<lengthToEndSecond<<" "<<lengthToEndFirst<<" Choice_Last"<<endl;
                        
                        if (finalChoice == 1){
                            for (int counter2 = lastOverFirstCount+1; counter2 <= lineBlockFirstEndCount; counter2++){
                                lineFirstTempX = lineFirstTemp [counter2][0];
                                lineFirstTempY = lineFirstTemp [counter2][1];
                                lineFirstTempValue = lineFirstTemp [counter2][2];
                                
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTempX, arrayLinesDataTempCount++;
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTempY, arrayLinesDataTempCount++;
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTempValue, arrayLinesDataTempCount++;
                                
                                if (lineFirstTemp [counter2][5] < -3){
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = 1, arrayLinkBlockDataCount++; //------Start: 0, End: 1------
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = 0, arrayLinkBlockDataCount++; //------Selected: 0, Non-selected: 1------
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = 1, arrayLinkBlockDataCount++; //------Line number------
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = lineFirstTemp [counter2][5], arrayLinkBlockDataCount++;
                                }
                                
                                lineFirstTemp [counter2][5] = -1;
                            }
                            
                            tailLengthCount = 0;
                            
                            for (int counter2 = counter1+1; counter2 <= lineBlockSecondEndCount; counter2++){
                                if (lineSecondTemp [counter2][5] < -3){
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = 1, arrayLinkBlockDataCount++; //------Start: 0, End: 1------
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = 1, arrayLinkBlockDataCount++; //------Selected: 0, Non-selected: 1------
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = 2, arrayLinkBlockDataCount++; //------Line number------
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = lineSecondTemp [counter2][5], arrayLinkBlockDataCount++;
                                }
                                
                                tailLengthCount++;
                                lineSecondTemp [counter2][5] = -2;
                            }
                            
                            arrayLinkBlockData [arrayLinkBlockDataCount] = 1, arrayLinkBlockDataCount++; //------Start: 0, End: 1------
                            arrayLinkBlockData [arrayLinkBlockDataCount] = 2, arrayLinkBlockDataCount++; //------Selected: 0, Non-selected: 1, Tail length indication (Only for non-selected): 2------
                            arrayLinkBlockData [arrayLinkBlockDataCount] = 2, arrayLinkBlockDataCount++; //------Line number------
                            arrayLinkBlockData [arrayLinkBlockDataCount] = tailLengthCount, arrayLinkBlockDataCount++;
                        }
                        
                        if (finalChoice == 2){
                            tailLengthCount = 0;
                            
                            for (int counter2 = lastOverFirstCount+1; counter2 <= lineBlockFirstEndCount; counter2++){
                                if (lineFirstTemp [counter2][5] < -3){
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = 1, arrayLinkBlockDataCount++; //------Start: 0, End: 1------
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = 1, arrayLinkBlockDataCount++; //------Selected: 0, Non-selected: 1------
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = 1, arrayLinkBlockDataCount++; //------Line number------
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = lineFirstTemp [counter2][5], arrayLinkBlockDataCount++;
                                }
                                
                                tailLengthCount++;
                                lineFirstTemp [counter2][5] = -2;
                            }
                            
                            arrayLinkBlockData [arrayLinkBlockDataCount] = 1, arrayLinkBlockDataCount++; //------Start: 0, End: 1------
                            arrayLinkBlockData [arrayLinkBlockDataCount] = 2, arrayLinkBlockDataCount++; //------Selected: 0, Non-selected: 1, Tail length indication (Only for non-selected): 2------
                            arrayLinkBlockData [arrayLinkBlockDataCount] = 1, arrayLinkBlockDataCount++; //------Line number------
                            arrayLinkBlockData [arrayLinkBlockDataCount] = tailLengthCount, arrayLinkBlockDataCount++;
                            
                            for (int counter2 = counter1+1; counter2 <= lineBlockSecondEndCount; counter2++){
                                lineSecondTempX = lineSecondTemp [counter2][0];
                                lineSecondTempY = lineSecondTemp [counter2][1];
                                lineSecondTempValue = lineSecondTemp [counter2][2];
                                
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempX, arrayLinesDataTempCount++;
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempY, arrayLinesDataTempCount++;
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempValue, arrayLinesDataTempCount++;
                                
                                if (lineSecondTemp [counter2][5] < -3){
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = 1, arrayLinkBlockDataCount++; //------Start: 0, End: 1------
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = 0, arrayLinkBlockDataCount++; //------Selected: 0, Non-selected: 1------
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = 2, arrayLinkBlockDataCount++; //------Line number------
                                    arrayLinkBlockData [arrayLinkBlockDataCount] = lineSecondTemp [counter2][5], arrayLinkBlockDataCount++;
                                }
                                
                                lineSecondTemp [counter2][5] = -1;
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineFirstPointTemp; counterA++){
                    //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<lineFirstTemp [counterA][counterB];
                    //	cout<<"lineFirstTemp "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < lineSecondPointTemp; counterA++){
                    //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<lineSecondTemp [counterA][counterB];
                    //	cout<<"lineSecondTemp "<<counterA<<endl;
                    //}
                    
                    break;
                }
                
                //==========Cross Point INTERNAL (Cross Point A (Start from 1)-Cross Point B-1)==========
                if (lineSecondTemp [counter1][5] >= 1 && lineSecondTemp [counter1][5] < lineBlockLastNumber && lineSecondTemp [counter1][5] != 0){
                    startOverlapNumber = 0;
                    startCount = -1;
                    endOverlapNumber = 0;
                    endCount = -1;
                    
                    if (lineSecondTemp [counter1][5] >= 1 && lineBlockLastNumber > 1){
                        startOverlapNumber = lineSecondTemp [counter1][5];
                        startCount = counter1;
                        
                        for (int counter2 = counter1+1; counter2 < lineSecondPointTemp; counter2++){
                            if (lineSecondTemp [counter2][5] == startOverlapNumber+1){
                                endOverlapNumber = lineSecondTemp [counter2][5];
                                endCount = counter2;
                                break;
                            }
                        }
                    }
                    
                    startCount2 = -1;
                    endCount2 = -1;
                    
                    for (int counter2 = 0; counter2 < lineFirstPointTemp; counter2++){
                        if (lineFirstTemp [counter2][5] == startOverlapNumber) startCount2 = counter2;
                        
                        if (lineFirstTemp [counter2][5] == endOverlapNumber) endCount2 = counter2;
                    }
                    
                    if (endCount-startCount == 1){
                        if (latestChoice == 2){
                            arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempX, arrayLinesDataTempCount++;
                            arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempY, arrayLinesDataTempCount++;
                            arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempValue, arrayLinesDataTempCount++;
                            
                            lineSecondTemp [counter1][5] = -3;
                            lineFirstTemp [startCount2][5] = -3;
                        }
                        else{
                            
                            arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTemp [startCount2][0], arrayLinesDataTempCount++;
                            arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTemp [startCount2][1], arrayLinesDataTempCount++;
                            arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTemp [startCount2][2], arrayLinesDataTempCount++;
                            
                            lineSecondTemp [counter1][5] = -3;
                            lineFirstTemp [startCount2][5] = -3;
                        }
                        
                        if (endCount2-startCount2 > 1){
                            for (int counter2 = startCount2+1; counter2 < endCount2; counter2++) lineFirstTemp [counter2][5] = -3;
                        }
                        else lineFirstTemp [startCount2][5] = -3;
                        
                        latestChoice = 2;
                    }
                    
                    if (endCount-startCount > 1){
                        lengthShorter = 0;
                        
                        if (endCount-startCount > endCount2-startCount2) lengthShorter = 1;
                        else if (endCount-startCount < endCount2-startCount2) lengthShorter = 2;
                        
                        outsideLine = 0;
                        
                        if (typeDefine == 1){
                            if (lineFirstTemp [startCount2][0] > lineSecondTemp [startCount][0]) outsideLine = 2;
                            else if (lineFirstTemp [startCount2][0] < lineSecondTemp [startCount][0]) outsideLine = 1;
                            else if (lineFirstTemp [startCount2][1] > lineSecondTemp [startCount][1]) outsideLine = 1;
                            else outsideLine = 2;
                        }
                        
                        if (typeDefine == 3){
                            if (lineFirstTemp [startCount2][0] > lineSecondTemp [startCount][0]) outsideLine = 1;
                            else if (lineFirstTemp [startCount2][0] < lineSecondTemp [startCount][0]) outsideLine = 2;
                            else if (lineFirstTemp [startCount2][1] > lineSecondTemp [startCount][1]) outsideLine = 2;
                            else outsideLine = 1;
                        }
                        
                        finalChoice = 0;
                        
                        if (typeDefine == 1 && outsideLine == 1 && lengthShorter == 1) finalChoice = 1;
                        else if (typeDefine == 1 && outsideLine == 1 && lengthShorter == 2) finalChoice = 2;
                        else if (typeDefine == 1 && outsideLine == 2 && lengthShorter == 1) finalChoice = 1;
                        else if (typeDefine == 1 && outsideLine == 2 && lengthShorter == 2) finalChoice = 2;
                        else if (typeDefine == 1 && outsideLine == 1 && lengthShorter == 0) finalChoice = 2;
                        else if (typeDefine == 1 && outsideLine == 2 && lengthShorter == 0) finalChoice = 2;
                        else if (typeDefine == 3 && outsideLine == 1 && lengthShorter == 1) finalChoice = 1;
                        else if (typeDefine == 3 && outsideLine == 1 && lengthShorter == 2) finalChoice = 1;
                        else if (typeDefine == 3 && outsideLine == 2 && lengthShorter == 1) finalChoice = 1;
                        else if (typeDefine == 3 && outsideLine == 2 && lengthShorter == 2) finalChoice = 2;
                        else if (typeDefine == 3 && outsideLine == 1 && lengthShorter == 0) finalChoice = 1;
                        else if (typeDefine == 3 && outsideLine == 2 && lengthShorter == 0) finalChoice = 1;
                        
                        if (finalChoice == 1){
                            if (latestChoice == 2){
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempX, arrayLinesDataTempCount++;
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempY, arrayLinesDataTempCount++;
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempValue, arrayLinesDataTempCount++;
                                
                                lineSecondTemp [counter1][5] = -3;
                                lineFirstTemp [startCount2][5] = -3;
                            }
                            else{
                                
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTemp [startCount2][0], arrayLinesDataTempCount++;
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTemp [startCount2][1], arrayLinesDataTempCount++;
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTemp [startCount2][2], arrayLinesDataTempCount++;
                                
                                lineSecondTemp [counter1][5] = -3;
                                lineFirstTemp [startCount2][5] = -3;
                            }
                            
                            for (int counter2 = startCount2+1; counter2 < endCount2; counter2++){
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTemp [counter2][0], arrayLinesDataTempCount++;
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTemp [counter2][1], arrayLinesDataTempCount++;
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTemp [counter2][2], arrayLinesDataTempCount++;
                                lineFirstTemp [counter2][5] = -1;
                            }
                            
                            for (int counter2 = startCount+1; counter2 < endCount; counter2++) lineSecondTemp [counter2][5] = -2;
                            
                            latestChoice = 1;
                        }
                        
                        if (finalChoice == 2){
                            if (latestChoice == 2){
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempX, arrayLinesDataTempCount++;
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempY, arrayLinesDataTempCount++;
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempValue, arrayLinesDataTempCount++;
                                lineSecondTemp [counter1][5] = -3;
                                lineFirstTemp [startCount2][5] = -3;
                            }
                            else{
                                
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTemp [startCount2][0], arrayLinesDataTempCount++;
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTemp [startCount2][1], arrayLinesDataTempCount++;
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineFirstTemp [startCount2][2], arrayLinesDataTempCount++;
                                
                                lineSecondTemp [counter1][5] = -3;
                                lineFirstTemp [startCount2][5] = -3;
                            }
                            
                            for (int counter2 = startCount2+1; counter2 < endCount2; counter2++) lineFirstTemp [counter2][5] = -2;
                            
                            for (int counter2 = startCount+1; counter2 < endCount; counter2++){
                                lineSecondTempX = lineSecondTemp [counter2][0];
                                lineSecondTempY = lineSecondTemp [counter2][1];
                                lineSecondTempValue = lineSecondTemp [counter2][2];
                                
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempX, arrayLinesDataTempCount++;
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempY, arrayLinesDataTempCount++;
                                arrayLinesDataTemp [arrayLinesDataTempCount] = lineSecondTempValue, arrayLinesDataTempCount++;
                                
                                lineSecondTemp [counter2][5] = -1;
                            }
                            
                            latestChoice = 2;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineFirstPointTemp; counterA++){
                    //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<lineFirstTemp [counterA][counterB];
                    //	cout<<"lineFirstTemp "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < lineSecondPointTemp; counterA++){
                    //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<lineSecondTemp [counterA][counterB];
                    //	cout<<"lineSecondTemp "<<counterA<<endl;
                    //}
                }
            }
        }
        
        //for (int counterA = 0; counterA < arrayLinesDataTempCount/3; counterA++){
        //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayLinesDataTemp [counterA*3+counterB];
        //	cout<<" arrayLinesDataTemp "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < arrayLinkBlockDataCount/4; counterA++){
        //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLinkBlockData [counterA*4+counterB];
        //	cout<<" arrayLinkBlockData "<<counterA<<endl;
        //}
        
        //==========Array Up-date==========
        if (arrayLinesDataTempCount != 0){
            beforeLineOne = -1;
            beforeLineOneSelected = -1;
            beforeLineOneLineNumber = -1;
            beforeLineOneLinkingNumber = -1;
            findFlagBeforeOne = 0;
            findFlagBeforeOneLength = 0;
            afterLineOne = -1;
            afterLineOneSelected = -1;
            afterLineOneLineNumber = -1;
            afterLineOneLinkingNumber = -1;
            findFlagAfterOne = 0;
            findFlagAfterOneLength = 0;
            afterLineTwo = -1;
            afterLineTwoSelected = -1;
            afterLineTwoLineNumber = -1;
            afterLineTwoLinkingNumber = -1;
            findFlagAfterTwo = 0;
            findFlagAfterTwoLength = 0;
            
            for (int counter1 = 0; counter1 < arrayLinkBlockDataCount/4; counter1++){ //------Non selected/selected line check------
                if (arrayLinkBlockData [counter1*4] == 0 && arrayLinkBlockData [counter1*4+1] != 2 && arrayLinkBlockData [counter1*4+2] == 1 && findFlagBeforeOne == 0){
                    beforeLineOne = 0;
                    beforeLineOneSelected = arrayLinkBlockData [counter1*4+1];
                    beforeLineOneLineNumber = 1;
                    beforeLineOneLinkingNumber = arrayLinkBlockData [counter1*4+3];
                    findFlagBeforeOne = 1;
                }
                
                if (arrayLinkBlockData [counter1*4] == 0 && arrayLinkBlockData [counter1*4+1] == 2 && arrayLinkBlockData [counter1*4+2] == 1) findFlagBeforeOneLength = arrayLinkBlockData [counter1*4+3];
                
                if (arrayLinkBlockData [counter1*4] == 1 && arrayLinkBlockData [counter1*4+1] != 2 && arrayLinkBlockData [counter1*4+2] == 1 && findFlagAfterOne == 0){
                    afterLineOne = 1;
                    afterLineOneSelected = arrayLinkBlockData [counter1*4+1];
                    afterLineOneLineNumber = 1;
                    afterLineOneLinkingNumber = arrayLinkBlockData [counter1*4+3];
                    findFlagAfterOne = 1;
                }
                
                if (arrayLinkBlockData [counter1*4] == 1 && arrayLinkBlockData [counter1*4+1] == 2 && arrayLinkBlockData [counter1*4+2] == 1) findFlagAfterOneLength = arrayLinkBlockData [counter1*4+3];
                
                if (arrayLinkBlockData [counter1*4] == 1 && arrayLinkBlockData [counter1*4+1] != 2 && arrayLinkBlockData [counter1*4+2] == 2 && findFlagAfterTwo == 0){
                    afterLineTwo = 1;
                    afterLineTwoSelected = arrayLinkBlockData [counter1*4+1];
                    afterLineTwoLineNumber = 2;
                    afterLineTwoLinkingNumber = arrayLinkBlockData [counter1*4+3];
                    findFlagAfterTwo = 1;
                }
                
                if (arrayLinkBlockData [counter1*4] == 1 && arrayLinkBlockData [counter1*4+1] == 2 && arrayLinkBlockData [counter1*4+2] == 2) findFlagAfterTwoLength = arrayLinkBlockData [counter1*4+3];
            }
            
            maxFirstLineBlock = 0; //------Max block number of line 1------
            
            for (int counter1 = 0; counter1 < lineFirstPointTemp; counter1++){
                if (lineFirstTemp [counter1][3] > maxFirstLineBlock) maxFirstLineBlock = lineFirstTemp [counter1][3];
            }
            
            maxSecondLineBlock = 0; //------Max block number of line 2------
            
            for (int counter1 = 0; counter1 < lineSecondPointTemp; counter1++){
                if (lineFirstTemp [counter1][3] > maxSecondLineBlock) maxSecondLineBlock = lineSecondTemp [counter1][3];
            }
            
            counterpartBlockNumber1 = 0;
            counterpartLine1 = 0;
            counterpartBlockNumber2 = 0;
            counterpartLine2 = 0;
            counterpartBlockNumber3 = 0;
            counterpartLine3 = 0;
            
            if ((beforeLineOne == 0 && beforeLineOneLineNumber == 1) || (findFlagBeforeOneLength != 0 && findFlagBeforeOne == 0)){ //------Zero to the first junction, line number 1------
                reviveCont = 0;
                junctionPoint = 0;
                
                for (int counter1 = 0; counter1 < lineFirstPointTemp; counter1++){ //------Marker check------
                    if (lineFirstTemp [counter1][5] == -2) reviveCont++;
                    
                    if (lineFirstTemp [counter1][5] == -3){
                        junctionPoint = counter1;
                        break;
                    }
                }
                
                if (beforeLineOne == 0 && beforeLineOneLineNumber == 1 && reviveCont >= 2){ //------if length is longer than 2, line process is backed to 0, Block number: put largest------
                    maxFirstLineBlock++;
                    
                    for (int counter1 = junctionPoint-reviveCont; counter1 < junctionPoint-2; counter1++){
                        lineFirstTemp [counter1][3] = maxFirstLineBlock;
                        lineFirstTemp [counter1][5] = 0;
                    }
                }
                
                if (findFlagBeforeOneLength != 0 && findFlagBeforeOne == 0 && reviveCont >= 7){ //------Non-Linked line, if length ie longer than 7, keep------
                    maxFirstLineBlock++;
                    
                    for (int counter1 = junctionPoint-reviveCont; counter1 < junctionPoint-2; counter1++){
                        lineFirstTemp [counter1][3] = maxFirstLineBlock;
                        lineFirstTemp [counter1][5] = 0;
                    }
                }
            }
            
            if ((afterLineOne == 1 && afterLineOneLineNumber == 1 && afterLineOneSelected == 1) || (findFlagAfterOneLength != 0 && findFlagAfterOne == 0)){ //------After the last junction, line number 1------
                reviveCont = 0;
                junctionPoint = 0;
                
                for (int counter1 = lineFirstPointTemp-1; counter1 >= 0; counter1 = counter1-1){
                    if (lineFirstTemp [counter1][5] == -2) reviveCont++;
                    
                    if (lineFirstTemp [counter1][5] == -3){
                        junctionPoint = counter1;
                        break;
                    }
                }
                
                if (afterLineOne == 1 && afterLineOneLineNumber == 1 && afterLineOneSelected == 1 && reviveCont >= 2){
                    maxFirstLineBlock++;
                    
                    for (int counter1 = junctionPoint+3; counter1 < junctionPoint+reviveCont; counter1++){
                        lineFirstTemp [counter1][3] = maxFirstLineBlock;
                        lineFirstTemp [counter1][5] = 0;
                    }
                }
                
                if (findFlagAfterOneLength != 0 && findFlagAfterOne == 0 && reviveCont >= 7){ //------Non-Linked line------
                    maxFirstLineBlock++;
                    
                    for (int counter1 = junctionPoint+3; counter1 < junctionPoint+reviveCont; counter1++){
                        lineFirstTemp [counter1][3] = maxFirstLineBlock;
                        lineFirstTemp [counter1][5] = 0;
                    }
                }
            }
            
            if ((afterLineTwo == 1 && afterLineTwoSelected == 1 && afterLineTwoLineNumber == 2) || (findFlagAfterTwoLength != 0 && findFlagAfterTwo == 0)){ //------After the lst junction, line number 2------
                reviveCont = 0;
                junctionPoint = 0;
                
                for (int counter1 = lineSecondPointTemp-1; counter1 >= 0; counter1 = counter1-1){
                    if (lineSecondTemp [counter1][5] == -2) reviveCont++;
                    
                    if (lineSecondTemp [counter1][5] == -3){
                        junctionPoint = counter1;
                        break;
                    }
                }
                
                if (afterLineTwo == 1 && afterLineTwoSelected == 1 && afterLineTwoLineNumber == 2 && reviveCont >= 2){
                    maxSecondLineBlock++;
                    
                    for (int counter1 = junctionPoint+3; counter1 < junctionPoint+reviveCont; counter1++){
                        lineSecondTemp [counter1][3] = maxSecondLineBlock;
                        lineSecondTemp [counter1][5] = 0;
                    }
                }
                
                if (findFlagAfterTwoLength != 0 && findFlagAfterTwo == 0 && reviveCont >= 7){
                    maxSecondLineBlock++;
                    
                    for (int counter1 = junctionPoint+3; counter1 < junctionPoint+reviveCont; counter1++){
                        lineSecondTemp [counter1][3] = maxSecondLineBlock;
                        lineSecondTemp [counter1][5] = 0;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < lineFirstPointTemp; counterA++){
            //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<lineFirstTemp [counterA][counterB];
            //	cout<<"lineFirstTemp "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < lineSecondPointTemp; counterA++){
            //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<lineSecondTemp [counterA][counterB];
            //	cout<<"lineSecondTemp "<<counterA<<endl;
            //}
            
            if (beforeLineOne == 0 && beforeLineOneSelected == 0 && beforeLineOneLineNumber == 1){ //------Selected lines------
                //------Find linked line number with removed line, if it is line one, ------
                //Combined line will be put to the top of line 2 array and the linked bock will be the top of array one------
                
                for (int counter1 = 0; counter1 < lineSecondPointTemp; counter1++){
                    if (beforeLineOneLinkingNumber == lineSecondTemp [counter1][5]){
                        counterpartBlockNumber1 = lineSecondTemp [counter1][3];
                        counterpartLine1 = 2;
                        break;
                    }
                }
            }
            
            if (afterLineOne == 1 && afterLineOneSelected == 0 && afterLineOneLineNumber == 1){
                for (int counter1 = 0; counter1 < lineSecondPointTemp; counter1++){
                    if (afterLineOneLinkingNumber == lineSecondTemp [counter1][5]){
                        counterpartBlockNumber2 = lineSecondTemp [counter1][3];
                        counterpartLine2 = 2;
                        break;
                    }
                }
            }
            
            if (afterLineTwo == 1 && afterLineTwoSelected == 0 && afterLineTwoLineNumber == 2){
                for (int counter1 = 0; counter1 < lineFirstPointTemp; counter1++){
                    if (afterLineTwoLinkingNumber == lineFirstTemp [counter1][5]){
                        counterpartBlockNumber3 = lineFirstTemp [counter1][3];
                        counterpartLine3 = 1;
                    }
                }
            }
            
            counterpartBlockNumber = 0;
            counterpartLine = 0;
            
            if (counterpartLine1 == 2){
                counterpartBlockNumber = counterpartBlockNumber1;
                counterpartLine = counterpartLine1;
            }
            else if (counterpartLine2 == 2){
                counterpartBlockNumber = counterpartBlockNumber2;
                counterpartLine = counterpartLine2;
            }
            else if (counterpartLine3 == 1){
                counterpartBlockNumber = counterpartBlockNumber3;
                counterpartLine = counterpartLine3;
            }
            
            int *arrayLineTemp1 = new int [lineFirstPointTemp*7+1];
            int *arrayLineTemp2 = new int [lineSecondPointTemp*7+1];
            
            arrayLineTempCount1 = 0;
            arrayLineTempCount2 = 0;
            
            if (counterpartLine == 1){
                for (int counter1 = 0; counter1 < lineFirstPointTemp; counter1++){
                    if (counterpartBlockNumber == lineFirstTemp [counter1][3]){ //------linked block------
                        arrayLineTemp1 [arrayLineTempCount1] = lineFirstTemp [counter1][0], arrayLineTempCount1++; //------X Position------
                        arrayLineTemp1 [arrayLineTempCount1] = lineFirstTemp [counter1][1], arrayLineTempCount1++; //------Y Position------
                        arrayLineTemp1 [arrayLineTempCount1] = lineFirstTemp [counter1][2], arrayLineTempCount1++; //------Value------
                        arrayLineTemp1 [arrayLineTempCount1] = 1, arrayLineTempCount1++; //------Block Number------
                        arrayLineTemp1 [arrayLineTempCount1] = lineFirstTemp [counter1][4], arrayLineTempCount1++; //------Combined Line: 1, not combined 0------
                        arrayLineTemp1 [arrayLineTempCount1] = 0, arrayLineTempCount1++; //------Blank------
                    }
                }
                
                blockCountAdjust = 1;
                blockCountRecord = 0;
                
                for (int counter1 = 0; counter1 < lineFirstPointTemp; counter1++){ //------Remaining block------
                    if (counterpartBlockNumber != lineFirstTemp [counter1][3] && lineFirstTemp [counter1][5] != -1 && lineFirstTemp [counter1][5] != -2 && lineFirstTemp [counter1][5] != -3){
                        if (blockCountRecord != lineFirstTemp [counter1][3]) blockCountRecord = lineFirstTemp [counter1][3], blockCountAdjust++;
                        
                        arrayLineTemp1 [arrayLineTempCount1] = lineFirstTemp [counter1][0], arrayLineTempCount1++;
                        arrayLineTemp1 [arrayLineTempCount1] = lineFirstTemp [counter1][1], arrayLineTempCount1++;
                        arrayLineTemp1 [arrayLineTempCount1] = lineFirstTemp [counter1][2], arrayLineTempCount1++;
                        arrayLineTemp1 [arrayLineTempCount1] = blockCountAdjust, arrayLineTempCount1++;
                        arrayLineTemp1 [arrayLineTempCount1] = lineFirstTemp [counter1][4], arrayLineTempCount1++;
                        arrayLineTemp1 [arrayLineTempCount1] = 0, arrayLineTempCount1++;
                    }
                }
                
                for (int counter1 = 0; counter1 < arrayLinesDataTempCount/3; counter1++){
                    arrayLineTemp2 [arrayLineTempCount2] = arrayLinesDataTemp [counter1*3], arrayLineTempCount2++;
                    arrayLineTemp2 [arrayLineTempCount2] = arrayLinesDataTemp [counter1*3+1], arrayLineTempCount2++;
                    arrayLineTemp2 [arrayLineTempCount2] = arrayLinesDataTemp [counter1*3+2], arrayLineTempCount2++;
                    arrayLineTemp2 [arrayLineTempCount2] = 1, arrayLineTempCount2++;
                    arrayLineTemp2 [arrayLineTempCount2] = 1, arrayLineTempCount2++;
                    arrayLineTemp2 [arrayLineTempCount2] = 0, arrayLineTempCount2++;
                }
                
                blockCountAdjust = 1;
                blockCountRecord = 0;
                
                for (int counter1 = 0; counter1 < lineSecondPointTemp; counter1++){
                    if (lineSecondTemp [counter1][5] != -1 && lineSecondTemp [counter1][5] != -2 && lineSecondTemp [counter1][5] != -3){
                        if (blockCountRecord != lineSecondTemp [counter1][3]) blockCountRecord = lineSecondTemp [counter1][3], blockCountAdjust++;
                        
                        arrayLineTemp2 [arrayLineTempCount2] = lineSecondTemp [counter1][0], arrayLineTempCount2++;
                        arrayLineTemp2 [arrayLineTempCount2] = lineSecondTemp [counter1][1], arrayLineTempCount2++;
                        arrayLineTemp2 [arrayLineTempCount2] = lineSecondTemp [counter1][2], arrayLineTempCount2++;
                        arrayLineTemp2 [arrayLineTempCount2] = blockCountAdjust, arrayLineTempCount2++;
                        arrayLineTemp2 [arrayLineTempCount2] = lineSecondTemp [counter1][4], arrayLineTempCount2++;
                        arrayLineTemp2 [arrayLineTempCount2] = 0, arrayLineTempCount2++;
                    }
                }
            }
            
            if (counterpartLine == 2){
                for (int counter1 = 0; counter1 < lineSecondPointTemp; counter1++){
                    if (counterpartBlockNumber == lineSecondTemp [counter1][3]){
                        arrayLineTemp2 [arrayLineTempCount2] = lineSecondTemp [counter1][0], arrayLineTempCount2++;
                        arrayLineTemp2 [arrayLineTempCount2] = lineSecondTemp [counter1][1], arrayLineTempCount2++;
                        arrayLineTemp2 [arrayLineTempCount2] = lineSecondTemp [counter1][2], arrayLineTempCount2++;
                        arrayLineTemp2 [arrayLineTempCount2] = 1, arrayLineTempCount2++;
                        arrayLineTemp2 [arrayLineTempCount2] = lineSecondTemp [counter1][4], arrayLineTempCount2++;
                        arrayLineTemp2 [arrayLineTempCount2] = 0, arrayLineTempCount2++;
                    }
                }
                
                blockCountAdjust = 1;
                blockCountRecord = 0;
                
                for (int counter1 = 0; counter1 < lineSecondPointTemp; counter1++){
                    if (counterpartBlockNumber != lineSecondTemp [counter1][3] && lineSecondTemp [counter1][5] != -1 && lineSecondTemp [counter1][5] != -2 && lineSecondTemp [counter1][5] != -3){
                        if (blockCountRecord != lineSecondTemp [counter1][3]) blockCountRecord = lineSecondTemp [counter1][3], blockCountAdjust++;
                        
                        arrayLineTemp2 [arrayLineTempCount2] = lineSecondTemp [counter1][0], arrayLineTempCount2++;
                        arrayLineTemp2 [arrayLineTempCount2] = lineSecondTemp [counter1][1], arrayLineTempCount2++;
                        arrayLineTemp2 [arrayLineTempCount2] = lineSecondTemp [counter1][2], arrayLineTempCount2++;
                        arrayLineTemp2 [arrayLineTempCount2] = blockCountAdjust, arrayLineTempCount2++;
                        arrayLineTemp2 [arrayLineTempCount2] = lineSecondTemp [counter1][4], arrayLineTempCount2++;
                        arrayLineTemp2 [arrayLineTempCount2] = 0, arrayLineTempCount2++;
                    }
                }
                
                for (int counter1 = 0; counter1 < arrayLinesDataTempCount/3; counter1++){
                    arrayLineTemp1 [arrayLineTempCount1] = arrayLinesDataTemp [counter1*3], arrayLineTempCount1++;
                    arrayLineTemp1 [arrayLineTempCount1] = arrayLinesDataTemp [counter1*3+1], arrayLineTempCount1++;
                    arrayLineTemp1 [arrayLineTempCount1] = arrayLinesDataTemp [counter1*3+2], arrayLineTempCount1++;
                    arrayLineTemp1 [arrayLineTempCount1] = 1, arrayLineTempCount1++;
                    arrayLineTemp1 [arrayLineTempCount1] = 1, arrayLineTempCount1++;
                    arrayLineTemp1 [arrayLineTempCount1] = 0, arrayLineTempCount1++;
                }
                
                blockCountAdjust = 1;
                blockCountRecord = 0;
                
                for (int counter1 = 0; counter1 < lineFirstPointTemp; counter1++){
                    if (lineFirstTemp [counter1][5] != -1 && lineFirstTemp [counter1][5] != -2 && lineFirstTemp [counter1][5] != -3){
                        if (blockCountRecord != lineFirstTemp [counter1][3]) blockCountRecord = lineFirstTemp [counter1][3], blockCountAdjust++;
                        
                        arrayLineTemp1 [arrayLineTempCount1] = lineFirstTemp [counter1][0], arrayLineTempCount1++;
                        arrayLineTemp1 [arrayLineTempCount1] = lineFirstTemp [counter1][1], arrayLineTempCount1++;
                        arrayLineTemp1 [arrayLineTempCount1] = lineFirstTemp [counter1][2], arrayLineTempCount1++;
                        arrayLineTemp1 [arrayLineTempCount1] = blockCountAdjust, arrayLineTempCount1++;
                        arrayLineTemp1 [arrayLineTempCount1] = lineFirstTemp [counter1][4], arrayLineTempCount1++;
                        arrayLineTemp1 [arrayLineTempCount1] = 0, arrayLineTempCount1++;
                    }
                }
            }
            
            if (counterpartLine == 0){
                blockCountAdjust = 0;
                blockCountRecord = 0;
                
                for (int counter1 = 0; counter1 < lineFirstPointTemp; counter1++){
                    if (lineFirstTemp [counter1][5] != -1 && lineFirstTemp [counter1][5] != -2 && lineFirstTemp [counter1][5] != -3){
                        if (blockCountRecord != lineFirstTemp [counter1][3]) blockCountRecord = lineFirstTemp [counter1][3], blockCountAdjust++;
                        
                        arrayLineTemp1 [arrayLineTempCount1] = lineFirstTemp [counter1][0], arrayLineTempCount1++;
                        arrayLineTemp1 [arrayLineTempCount1] = lineFirstTemp [counter1][1], arrayLineTempCount1++;
                        arrayLineTemp1 [arrayLineTempCount1] = lineFirstTemp [counter1][2], arrayLineTempCount1++;
                        arrayLineTemp1 [arrayLineTempCount1] = blockCountAdjust, arrayLineTempCount1++;
                        arrayLineTemp1 [arrayLineTempCount1] = lineFirstTemp [counter1][4], arrayLineTempCount1++;
                        arrayLineTemp1 [arrayLineTempCount1] = 0, arrayLineTempCount1++;
                    }
                }
                
                for (int counter1 = 0; counter1 < arrayLinesDataTempCount/3; counter1++){
                    arrayLineTemp2 [arrayLineTempCount2] = arrayLinesDataTemp [counter1*3], arrayLineTempCount2++;
                    arrayLineTemp2 [arrayLineTempCount2] = arrayLinesDataTemp [counter1*3+1], arrayLineTempCount2++;
                    arrayLineTemp2 [arrayLineTempCount2] = arrayLinesDataTemp [counter1*3+2], arrayLineTempCount2++;
                    arrayLineTemp2 [arrayLineTempCount2] = 1, arrayLineTempCount2++;
                    arrayLineTemp2 [arrayLineTempCount2] = 1, arrayLineTempCount2++;
                    arrayLineTemp2 [arrayLineTempCount2] = 0, arrayLineTempCount2++;
                }
                
                blockCountAdjust = 1;
                blockCountRecord = 0;
                
                for (int counter1 = 0; counter1 < lineSecondPointTemp; counter1++){
                    if (lineSecondTemp [counter1][5] != -1 && lineSecondTemp [counter1][5] != -2 && lineSecondTemp [counter1][5] != -3){
                        if (blockCountRecord != lineSecondTemp [counter1][3]) blockCountRecord = lineSecondTemp [counter1][3], blockCountAdjust++;
                        
                        arrayLineTemp2 [arrayLineTempCount2] = lineSecondTemp [counter1][0], arrayLineTempCount2++;
                        arrayLineTemp2 [arrayLineTempCount2] = lineSecondTemp [counter1][1], arrayLineTempCount2++;
                        arrayLineTemp2 [arrayLineTempCount2] = lineSecondTemp [counter1][2], arrayLineTempCount2++;
                        arrayLineTemp2 [arrayLineTempCount2] = blockCountAdjust, arrayLineTempCount2++;
                        arrayLineTemp2 [arrayLineTempCount2] = lineSecondTemp [counter1][4], arrayLineTempCount2++;
                        arrayLineTemp2 [arrayLineTempCount2] = 0, arrayLineTempCount2++;
                    }
                }
            }
            
            if (lineSet == 1){
                lineOneCount = 0;
                
                for (int counter1 = 0; counter1 < arrayLineTempCount1/6; counter1++){
                    arrayLineOne [lineOneCount] = arrayLineTemp1 [counter1*6], lineOneCount++;
                    arrayLineOne [lineOneCount] = arrayLineTemp1 [counter1*6+1], lineOneCount++;
                    arrayLineOne [lineOneCount] = arrayLineTemp1 [counter1*6+2], lineOneCount++;
                    arrayLineOne [lineOneCount] = arrayLineTemp1 [counter1*6+3], lineOneCount++;
                    arrayLineOne [lineOneCount] = arrayLineTemp1 [counter1*6+4], lineOneCount++;
                    arrayLineOne [lineOneCount] = arrayLineTemp1 [counter1*6+5], lineOneCount++;
                }
                
                lineFiveCount = 0;
                
                for (int counter1 = 0; counter1 < arrayLineTempCount2/6; counter1++){
                    arrayLineFive [lineFiveCount] = arrayLineTemp2 [counter1*6], lineFiveCount++;
                    arrayLineFive [lineFiveCount] = arrayLineTemp2 [counter1*6+1], lineFiveCount++;
                    arrayLineFive [lineFiveCount] = arrayLineTemp2 [counter1*6+2], lineFiveCount++;
                    arrayLineFive [lineFiveCount] = arrayLineTemp2 [counter1*6+3], lineFiveCount++;
                    arrayLineFive [lineFiveCount] = arrayLineTemp2 [counter1*6+4], lineFiveCount++;
                    arrayLineFive [lineFiveCount] = arrayLineTemp2 [counter1*6+5], lineFiveCount++;
                }
            }
            
            if (lineSet == 3){
                lineThreeCount = 0;
                
                for (int counter1 = 0; counter1 < arrayLineTempCount1/6; counter1++){
                    arrayLineThree [lineThreeCount] = arrayLineTemp1 [counter1*6], lineThreeCount++;
                    arrayLineThree [lineThreeCount] = arrayLineTemp1 [counter1*6+1], lineThreeCount++;
                    arrayLineThree [lineThreeCount] = arrayLineTemp1 [counter1*6+2], lineThreeCount++;
                    arrayLineThree [lineThreeCount] = arrayLineTemp1 [counter1*6+3], lineThreeCount++;
                    arrayLineThree [lineThreeCount] = arrayLineTemp1 [counter1*6+4], lineThreeCount++;
                    arrayLineThree [lineThreeCount] = arrayLineTemp1 [counter1*6+5], lineThreeCount++;
                }
                
                lineSevenCount = 0;
                
                for (int counter1 = 0; counter1 < arrayLineTempCount2/6; counter1++){
                    arrayLineSeven [lineSevenCount] = arrayLineTemp2 [counter1*6], lineSevenCount++;
                    arrayLineSeven [lineSevenCount] = arrayLineTemp2 [counter1*6+1], lineSevenCount++;
                    arrayLineSeven [lineSevenCount] = arrayLineTemp2 [counter1*6+2], lineSevenCount++;
                    arrayLineSeven [lineSevenCount] = arrayLineTemp2 [counter1*6+3], lineSevenCount++;
                    arrayLineSeven [lineSevenCount] = arrayLineTemp2 [counter1*6+4], lineSevenCount++;
                    arrayLineSeven [lineSevenCount] = arrayLineTemp2 [counter1*6+5], lineSevenCount++;
                }
            }
            
            delete [] arrayLineTemp1;
            delete [] arrayLineTemp2;
            
            terminationFlag = 1;
        }
        
    } while (terminationFlag == 1);
    
    for (int counter1 = 0; counter1 < lineFirstPointTempHold+5; counter1++) delete [] lineFirstTemp [counter1];
    delete [] lineFirstTemp;
    
    for (int counter1 = 0; counter1 < lineSecondPointTempHold+5; counter1++) delete [] lineSecondTemp [counter1];
    delete [] lineSecondTemp;
    
    delete [] arrayLinesDataTemp;
    delete [] arrayLinkBlockData;
}

@end
