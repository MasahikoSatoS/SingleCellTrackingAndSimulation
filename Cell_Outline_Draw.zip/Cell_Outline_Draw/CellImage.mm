//
// CellImage.mm
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 14/02/07.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#import "CellImage.h"

NSString *notificationToCellImage = @"notificationExecuteCellImage";

@implementation CellImage

- (id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    
    if (self) {
        cellOriginal = [[NSImage alloc] initWithContentsOfFile:@""];
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToCellImage object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    //------Source Image loading------
    NSBitmapImageRep *bitmapReps;
    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageWidth pixelsHigh:imageHeight bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageHeight bitsPerPixel:8];
    unsigned char *bitmapData = [bitmapReps bitmapData];
    
    for (int counter1 = 0; counter1 < imageWidth; counter1++){
        for (int counter2 = 0; counter2 < imageHeight; counter2++) *bitmapData++ = (unsigned char)arrayExtractedImage [counter1][counter2];
    }
    
    cellOriginal = [[NSImage alloc] initWithSize:NSMakeSize(imageWidth, imageHeight)];
    [cellOriginal addRepresentation:bitmapReps];
    
    if (imageFirstLoadFlagCell == 0){
        xPositionCell = 0;
        yPositionCell = 0;
        xPositionAdjustCell = 0;
        yPositionAdjustCell = 0;
        magnificationCell = 10;
        imageFirstLoadFlagCell = 1;
    }
    
    //------Window size and Position re-adjust------
    int vertical = 350+78;
    int horizontal = 350;
    
    windowWidthCell = imageWidth/(double)horizontal;
    windowHeightCell = imageWidth/(double)(vertical-78);
    
    xPositionAdjustCell = (imageWidth-imageHeight/(double)(magnificationCell*0.1))/(double)2;
    yPositionAdjustCell = (imageWidth-imageHeight/(double)(magnificationCell*0.1))/(double)2;
    
    [self setNeedsDisplay:YES];
}

-(void)mouseDown:(NSEvent *)event{
    NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
    xPointDownCell = clickPoint.x;
    yPointDownCell = clickPoint.y;
    
    [self setNeedsDisplay:YES];
}

-(void)mouseUp:(NSEvent *)event{
    xPositionCell = xPositionCell+xPositionMoveCell;
    yPositionCell = yPositionCell+yPositionMoveCell;
    xPositionMoveCell = 0;
    yPositionMoveCell = 0;
    mouseDragFlag = 0;
    
    [self setNeedsDisplay:YES];
}

- (void)mouseDragged:(NSEvent *)event{
    NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
    xPointDragCell = clickPoint.x;
    yPointDragCell = clickPoint.y;
    xPositionMoveCell = (xPointDownCell-xPointDragCell)*windowWidthCell/(double)(magnificationCell*0.1);
    yPositionMoveCell = (yPointDownCell-yPointDragCell)*windowHeightCell/(double)(magnificationCell*0.1);
    
    mouseDragFlag = 1;
    [self setNeedsDisplay:YES];
}

-(void)keyDown:(NSEvent *)event{
    int keyCode = [event keyCode];
    int proceedFlag = 0;
    
    //------Original size------
    if (keyCode == 6){
        proceedFlag = 1;
        xPositionCell = 0;
        yPositionCell = 0;
        xPositionAdjustCell = 0;
        yPositionAdjustCell = 0;
        magnificationCell = 10;
    }
    
    //------Magnification Magnify------
    if (keyCode == 125){
        if (magnificationCell >= 12 && magnificationCell <= 350){
            proceedFlag = 1;
            if (magnificationCell-10 < 12) magnificationCell = 12;
            else magnificationCell = magnificationCell-10;
            
            xPositionAdjustCell = -1*(imageHeight/(double)(magnificationCell*0.1)-imageHeight)/(double)2;
            yPositionAdjustCell = -1*(imageHeight/(double)(magnificationCell*0.1)-imageHeight)/(double)2;
        }
    }
    
    //------Magnification Reduction------
    if (keyCode == 126){
        if (magnificationCell >= 10 && magnificationCell <= 498){
            proceedFlag = 1;
            
            if (magnificationCell+10 > 498) magnificationCell = 498;
            else magnificationCell = magnificationCell+10;
            
            xPositionAdjustCell = (imageHeight-imageHeight/(double)(magnificationCell*0.1))/(double)2;
            yPositionAdjustCell = (imageHeight-imageHeight/(double)(magnificationCell*0.1))/(double)2;
        }
    }
    
    //------Magnification Reduction------
    if (keyCode == 49){
        proceedFlag = 1;
        magnificationCell = (int)(200/((double)(50/(double)imageHeight)*350)*10);
        xPositionAdjustCell = (imageHeight-imageHeight/(double)(magnificationCell*0.1))/(double)2;
        yPositionAdjustCell = (imageHeight-imageHeight/(double)(magnificationCell*0.1))/(double)2;
    }
    
    if ((keyCode == 124 || keyCode == 123) && autoRunStatus == 0){
        int imageMoveFlag = 0;
        
        if (processSequenceFlag < 20 || allRunFlag != 1){
            if (lineDataForDisplayCount6 != 0 && lineDataForDisplayCount7 != 0 && lineDataForDisplayCount8 != 0 && lineDataForDisplayCount9 != 0){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert addButtonWithTitle:@"Cancel"];
                [alert setMessageText:@"New Image Load: Outline Won't Redisplay"];
                [alert setAlertStyle:NSAlertStyleWarning];
                
                if ([alert runModal] == NSAlertFirstButtonReturn) imageMoveFlag = 1;
                
            }
            else imageMoveFlag = 1;
        }
        
        if (imageMoveFlag == 1){
            if (keyCode == 124){
                proceedFlag = 1;
                displayImageNumber++;
                
                if (displayImageNumber > imageNameFileListCount) displayImageNumber = displayImageNumber-1;
                
                lineDataForDisplayCount6 = 0;
                lineDataForDisplayCount7 = 0;
                lineDataForDisplayCount8 = 0;
                lineDataForDisplayCount9 = 0;
                toControllerDisplay1 = 1;
            }
            if (keyCode == 123){
                proceedFlag = 1;
                displayImageNumber = displayImageNumber-1;
                
                if (displayImageNumber < 1) displayImageNumber = 1;
                
                lineDataForDisplayCount6 = 0;
                lineDataForDisplayCount7 = 0;
                lineDataForDisplayCount8 = 0;
                lineDataForDisplayCount9 = 0;
                toControllerDisplay1 = 1;
            }
            
            string imageNumberString = to_string(displayImageNumber);
            
            if (imageNumberString.length() == 1) imageNumberString = "000"+imageNumberString;
            else if (imageNumberString.length() == 2) imageNumberString = "00"+imageNumberString;
            else if (imageNumberString.length() == 3) imageNumberString = "0"+imageNumberString;
            
            int tifBmpType = 0;
            
            ifstream fin;
            
            string imageDataPath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Stitch/"+"STimage "+imageNumberString+".tif";
            
            fin.open(imageDataPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                tifBmpType = 0;
                fin.close();
            }
            else{
                
                imageDataPath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Stitch/"+"STimage "+imageNumberString+".bmp";
                tifBmpType = 1;
            }
            
            if (tifBmpType == 0){
                //------Tiff reading------
                unsigned long stripFirstAddress = 0;
                unsigned long stripByteCountAddress = 0;
                unsigned long nextAddress = 0;
                unsigned long headPosition = 0;
                unsigned long stripEntry = 0;
                long sizeForCopy = 0;
                
                double xPosition = 0;
                double yPosition = 0;
                
                int imageWidthTif = 0;
                int imageHeightTif = 0;
                int imageBit = 0; // check 8, 16
                int imageCompression = 0; // check 1
                int photoMetric = 0; //check 0, 1, 2
                int imageDimension = 0;
                int verticalBmp = 0;
                int horizontalBmp = 0;
                int endianType = 0;
                int samplePerPix = 0;
                int dataConversion [4];
                int processType = 1;
                int numberOfLayers = 0;
                
                struct stat sizeOfFile;
                
                if (stat(imageDataPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    fileReadArray = new uint8_t [sizeForCopy+4];
                    fin.open(imageDataPath.c_str(), ios::in | ios::binary);
                    
                    fin.read((char*)fileReadArray, sizeForCopy+4);
                    fin.close();
                    
                    dataConversion [0] = fileReadArray [0];
                    dataConversion [1] = fileReadArray [1];
                    
                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                    else endianType = 0;
                    
                    int *arrayExtractedImage3 = new int [100];
                    
                    headPosition = 0;
                    
                    if (endianType == 1){
                        dataConversion [0] = fileReadArray [7];
                        dataConversion [1] = fileReadArray [6];
                        dataConversion [2] = fileReadArray [5];
                        dataConversion [3] = fileReadArray [4];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    else if (endianType == 0){
                        dataConversion [0] = fileReadArray [4];
                        dataConversion [1] = fileReadArray [5];
                        dataConversion [2] = fileReadArray [6];
                        dataConversion [3] = fileReadArray [7];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    
                    if (endianType == 1){
                        tiffFileRead = [[TiffFileRead alloc] init];
                        [tiffFileRead tiffReadLargeEndian: headPosition:&imageWidthTif:&imageHeightTif:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                        
                        
                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                            if (imageWidthTif > imageHeightTif) imageDimension = imageWidthTif;
                            else imageDimension = imageHeightTif;
                            
                            tiffFileRead = [[TiffFileRead alloc] init];
                            delete [] arrayExtractedImage3;
                            
                            arrayExtractedImage3 = [tiffFileRead imageSetLargeEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                            
                        }
                    }
                    else if (endianType == 0){
                        tiffFileRead = [[TiffFileRead alloc] init];
                        [tiffFileRead tiffReadSmallEndian: headPosition:&imageWidthTif:&imageHeightTif:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                        
                        
                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                            if (imageWidth > imageHeightTif) imageDimension = imageWidthTif;
                            else imageDimension = imageHeightTif;
                            
                            tiffFileRead = [[TiffFileRead alloc] init];
                            delete [] arrayExtractedImage3;
                            
                            arrayExtractedImage3 = [tiffFileRead imageSetSmallEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                            
                        }
                    }
                    
                    imageWidth = imageWidthTif;
                    imageHeight = imageHeightTif;
                    
                    horizontalBmp = 0;
                    verticalBmp = 0;
                    
                    for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                        if (horizontalBmp < imageWidth){
                            if (arrayExtractedImage3 [counter3] >= cutOffLevel && arrayExtractedImage3 [counter3] != 100) imageForDisplay1 [verticalBmp][horizontalBmp] = 220;
                            else imageForDisplay1 [verticalBmp][horizontalBmp] = 0;
                            
                            if (arrayExtractedImage3 [counter3] >= cutOffLevel2 && arrayExtractedImage3 [counter3] != 100) imageForDisplay2 [verticalBmp][horizontalBmp] = 220;
                            else imageForDisplay2 [verticalBmp][horizontalBmp] = 0;
                            
                            if (arrayExtractedImage3 [counter3] >= cutOffLevel3 && arrayExtractedImage3 [counter3] != 100) imageForDisplay3 [verticalBmp][horizontalBmp] = 220;
                            else imageForDisplay3 [verticalBmp][horizontalBmp] = 0;
                            
                            if (arrayExtractedImage3 [counter3] >= cutOffLevel4 && arrayExtractedImage3 [counter3] != 100) imageForDisplay4 [verticalBmp][horizontalBmp] = 220;
                            else imageForDisplay4 [verticalBmp][horizontalBmp] = 0;
                            
                            arrayExtractedImage [verticalBmp][horizontalBmp] = arrayExtractedImage3 [counter3];
                            
                            horizontalBmp++;
                        }
                        
                        if (horizontalBmp == imageWidth){
                            horizontalBmp = 0;
                            verticalBmp++;
                        }
                    }
                    
                    delete [] fileReadArray;
                    delete [] arrayExtractedImage3;
                }
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSourceImage object:self];
                
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageWidth pixelsHigh:imageHeight bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageHeight bitsPerPixel:8];
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                for (int counter1 = 0; counter1 < imageWidth; counter1++){
                    for (int counter2 = 0; counter2 < imageHeight; counter2++) *bitmapData++ = (unsigned char)arrayExtractedImage [counter1][counter2];
                }
                
                cellOriginal = [[NSImage alloc] initWithSize:NSMakeSize(imageWidth, imageHeight)];
                [cellOriginal addRepresentation:bitmapReps];
            }
            else if (tifBmpType == 1){
                int bitData = 0;
                
                long sizeForCopy = 0;
                int imageDimensionCount = 0;
                
                struct stat sizeOfFile;
                
                if (stat(imageDataPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+4];
                    fin.open(imageDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+1);
                        fin.close();
                        
                        for (int counter1 = imageHeight-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                bitData = uploadTemp [1078+counter1*imageHeight+counter2];
                                
                                if (bitData >= cutOffLevel && bitData != 100) imageForDisplay1 [imageDimensionCount][counter2] = 220;
                                else imageForDisplay1 [imageDimensionCount][counter2] = 0;
                                
                                if (bitData >= cutOffLevel2 && bitData != 100) imageForDisplay2 [imageDimensionCount][counter2] = 220;
                                else imageForDisplay2 [imageDimensionCount][counter2] = 0;
                                
                                if (bitData >= cutOffLevel3 && bitData != 100) imageForDisplay3 [imageDimensionCount][counter2] = 220;
                                else imageForDisplay3 [imageDimensionCount][counter2] = 0;
                                
                                if (bitData >= cutOffLevel4 && bitData != 100) imageForDisplay4 [imageDimensionCount][counter2] = 220;
                                else imageForDisplay4 [imageDimensionCount][counter2] = 0;
                                
                                arrayExtractedImage [imageDimensionCount][counter2] = bitData;
                            }
                            
                            imageDimensionCount++;
                        }
                    }
                    
                    delete [] uploadTemp;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSourceImage object:self];
                    
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageWidth pixelsHigh:imageHeight bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageHeight bitsPerPixel:8];
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter1 = 0; counter1 < imageWidth; counter1++){
                        for (int counter2 = 0; counter2 < imageHeight; counter2++) *bitmapData++ = (unsigned char)arrayExtractedImage [counter1][counter2];
                    }
                    
                    cellOriginal = [[NSImage alloc] initWithSize:NSMakeSize(imageWidth, imageHeight)];
                    [cellOriginal addRepresentation:bitmapReps];
                }
            }
        }
    }
    
    if (proceedFlag == 1) [self setNeedsDisplay:YES];
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)drawRect:(NSRect)rect {
    if (imageFirstLoadFlagCell == 1){
        NSRect srcRect;
        srcRect.origin.x = xPositionCell+xPositionAdjustCell+xPositionMoveCell;
        srcRect.origin.y = yPositionCell+yPositionAdjustCell+yPositionMoveCell;
        srcRect.size.width = imageHeight/(double)(magnificationCell*0.1);
        srcRect.size.height = imageHeight/(double)(magnificationCell*0.1);
        
        [cellOriginal drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
        
        cellImageDisplayCheck++;
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToCellImage object:nil];
}

@end
