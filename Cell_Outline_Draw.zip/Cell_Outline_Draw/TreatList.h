//
//  TreatList.h
//  Cell_Outline_Draw
//
//  Created by Masahiko Sato on 11/22/16.
//
//

#ifndef TREATLIST_H
#define TREATLIST_H
#import "Controller.h"
#endif

@interface TreatList : NSObject <NSTableViewDataSource>{
    int treatListCallCount; //Table operation
    int tableCurrentRowHold; //Table operation
    int rowIndexHold; //Table operation
    
    IBOutlet NSTableView *treatListView;
    
    NSTimer *treatListTimer;
}

-(id)init;
-(void)dealloc;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

@end
