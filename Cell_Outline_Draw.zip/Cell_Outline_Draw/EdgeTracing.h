//
// EdgeTracing.h
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 07/07/12.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#ifndef EDGETRACING_H
#define EDGETRACING_H
#import "Controller.h"
#endif

@interface EdgeTracing : NSObject {
}

-(void)edgeTrace:(int)subjectArray;

@end
