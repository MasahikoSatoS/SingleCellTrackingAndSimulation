

//
// shapeAdjust.mm
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 25/12/12.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#import "ShapeAdjust.h"

@implementation ShapeAdjust

-(void)shapeAdjustMain:(int)maxPointDimX :(int)maxPointDimY :(int)minPointDimX :(int)minPointDimY :(int)linkedLinePair :(int)counter{
    if (linkedLineCount == 0){
        int firstFlag = 0;
        
        delete [] arrayLinkedLine;
        arrayLinkedLine = new int [5000], linkedLineCount = 0, linkedLineLimit = 5000;
        
        maxPointDimX = 0;
        maxPointDimY = 0;
        minPointDimX = 100000;
        minPointDimY = 100000;
        
        for (int counter1 = 0; counter1 < outlineVectorSourceCount0/3; counter1++){
            if (arrayOutlineVectorSource0 [counter1*3] == counter){
                if (linkedLineCount+10 > linkedLineLimit){
                    int *arrayGapUpDate = new int [linkedLineCount+10];
                    for (int counter2 = 0; counter2 < linkedLineCount; counter2++) arrayGapUpDate [counter2] = arrayLinkedLine [counter2];
                    
                    delete [] arrayLinkedLine;
                    arrayLinkedLine = new int [linkedLineLimit+10000];
                    linkedLineLimit = linkedLineLimit+10000;
                    
                    for (int counter2 = 0; counter2 < linkedLineCount; counter2++) arrayLinkedLine [counter2] = arrayGapUpDate [counter2];
                    delete [] arrayGapUpDate;
                }
                
                arrayLinkedLine [linkedLineCount] = arrayOutlineVectorSource0 [counter1*3+1], linkedLineCount++; //------X position------0
                arrayLinkedLine [linkedLineCount] = arrayOutlineVectorSource0 [counter1*3+2], linkedLineCount++; //------Y position------1
                arrayLinkedLine [linkedLineCount] = arrayExtractedImage [arrayOutlineVectorSource0 [counter1*3+2]][arrayOutlineVectorSource0 [counter1*3+1]], linkedLineCount++; //------Pix Value------2
                arrayLinkedLine [linkedLineCount] = 0, linkedLineCount++; //------Line number (cell humber)------3
                
                if (firstFlag == 0) firstFlag = 1, arrayLinkedLine [linkedLineCount] = 1, linkedLineCount++; //------Start-End position------4
                else arrayLinkedLine [linkedLineCount] = 0, linkedLineCount++;
                
                if (maxPointDimX < arrayOutlineVectorSource0 [counter1*3+1]) maxPointDimX = arrayOutlineVectorSource0 [counter1*3+1];
                if (minPointDimX > arrayOutlineVectorSource0 [counter1*3+1]) minPointDimX = arrayOutlineVectorSource0 [counter1*3+1];
                if (maxPointDimY < arrayOutlineVectorSource0 [counter1*3+2]) maxPointDimY = arrayOutlineVectorSource0 [counter1*3+2];
                if (minPointDimY > arrayOutlineVectorSource0 [counter1*3+2]) minPointDimY = arrayOutlineVectorSource0 [counter1*3+2];
            }
        }
        
        arrayLinkedLine [linkedLineCount-1] = 2;
    }
    else{
        
        for (int counter1 = 0; counter1 < outlineVectorSourceCount0/3; counter1++){
            if (arrayOutlineVectorSource0 [counter1*3] == counter){
                if (maxPointDimX < arrayOutlineVectorSource0 [counter1*3+1]) maxPointDimX = arrayOutlineVectorSource0 [counter1*3+1];
                if (minPointDimX > arrayOutlineVectorSource0 [counter1*3+1]) minPointDimX = arrayOutlineVectorSource0 [counter1*3+1];
                if (maxPointDimY < arrayOutlineVectorSource0 [counter1*3+2]) maxPointDimY = arrayOutlineVectorSource0 [counter1*3+2];
                if (minPointDimY > arrayOutlineVectorSource0 [counter1*3+2]) minPointDimY = arrayOutlineVectorSource0 [counter1*3+2];
            }
        }
        
        for (int counter1 = 0; counter1 < linkedLineCount/5; counter1++){
            if (maxPointDimX < arrayLinkedLine [counter1*5]) maxPointDimX = arrayLinkedLine [counter1*5];
            if (minPointDimX > arrayLinkedLine [counter1*5]) minPointDimX = arrayLinkedLine [counter1*5];
            if (maxPointDimY < arrayLinkedLine [counter1*5+1]) maxPointDimY = arrayLinkedLine [counter1*5+1];
            if (minPointDimY > arrayLinkedLine [counter1*5+1]) minPointDimY = arrayLinkedLine [counter1*5+1];
        }
        
        int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
        int verticalLength = (maxPointDimY-minPointDimY)/2*2;
        int dimension = 0;
        
        if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
        if (horizontalLength < verticalLength) dimension = verticalLength+30;
        
        dimension = (dimension/2)*2;
        
        int horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
        int verticalStart = minPointDimY-(dimension-verticalLength)/2;
        
        int **outlineCheck = new int *[dimension+4]; //------Matrix, Over 200, A3 holds final results------
        for (int counter1 = 0; counter1 < dimension+4; counter1++) outlineCheck [counter1] = new int [dimension+4];
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++) outlineCheck [counterY][counterX] = 0;
        }
        
        for (int counter1 = 0; counter1 < outlineVectorSourceCount0/3; counter1++){
            if (arrayOutlineVectorSource0 [counter1*3] == counter){
                outlineCheck [arrayOutlineVectorSource0 [counter1*3+2]-verticalStart][arrayOutlineVectorSource0 [counter1*3+1]-horizontalStart] = 1;
            }
        }
        
        for (int counter1 = 0; counter1 < linkedLineCount/5; counter1++){
            outlineCheck [arrayLinkedLine [counter1*5+1]-verticalStart][arrayLinkedLine [counter1*5]-horizontalStart] = 1;
        }
        
        //------Connectivity analysis, For Zero------
        int *connectAnalysisX = new int [(dimension+4)*4];
        int *connectAnalysisY = new int [(dimension+4)*4];
        int *connectAnalysisTempX = new int [(dimension+4)*4];
        int *connectAnalysisTempY = new int [(dimension+4)*4];
        
        int connectivityNumber = -3;
        int terminationFlag = 0;
        int connectAnalysisCount = 0;
        int connectAnalysisTempCount = 0;
        int xSource = 0;
        int ySource = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (outlineCheck [counterY][counterX] == 0){
                    connectivityNumber = connectivityNumber+2;
                    outlineCheck [counterY][counterX] = connectivityNumber;
                    
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && outlineCheck [counterY-1][counterX] == 0){
                        outlineCheck [counterY-1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension && outlineCheck [counterY][counterX+1] == 0){
                        outlineCheck [counterY][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && outlineCheck [counterY+1][counterX] == 0){
                        outlineCheck [counterY+1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && outlineCheck [counterY][counterX-1] == 0){
                        outlineCheck [counterY][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && outlineCheck [ySource-1][xSource] == 0){
                                    outlineCheck [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension && outlineCheck [ySource][xSource+1] == 0){
                                    outlineCheck [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && outlineCheck [ySource+1][xSource] == 0){
                                    outlineCheck [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && outlineCheck [ySource][xSource-1] == 0){
                                    outlineCheck [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //------Remove connectivity groups, which attach edge, extract inner part of Linked Line------
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (outlineCheck [counterY][counterX] == -1) outlineCheck [counterY][counterX] = 0;
                else outlineCheck [counterY][counterX] = 1;
            }
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<outlineCheck [counterA][counterB];
        //    cout<<" outlineCheck "<<counterA<<endl;
        //}
        
        //-------Internal Zero Find and Fill-------
        int **connectivityUpdate5 = new int *[dimension+4];
        
        for (int counter1 = 0; counter1 < dimension+4; counter1++) connectivityUpdate5 [counter1] = new int [dimension+4];
        
        for (int counterX = 0; counterX < dimension+2; counterX++){
            for (int counterY = 0; counterY < dimension+2; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++) connectivityUpdate5 [counterY+1][counterX+1] = outlineCheck [counterY][counterX];
        }
        
        connectivityNumber = 0;
        
        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                if (connectivityUpdate5 [counterY2][counterX2] == 0){
                    connectivityNumber--;
                    connectAnalysisCount = 0;
                    
                    connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                    
                    if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                        connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                    }
                    if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                        connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                    }
                    if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                        connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                    }
                    if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                        connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                    connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                    connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                    connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                    connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //for (int counterA = 0; counterA < dimension+2; counterA++){
        //	for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
        //	cout<<" connectivityUpdate5 "<<counterA<<endl;
        //}
        
        if (connectivityNumber < -1){
            int *connectCheckArray = new int [connectivityNumber*-1*2+5];
            
            for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
            
            int connectTemp2 = 0;
            
            for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                    connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                    
                    if (connectTemp2 < -1){
                        connectTemp2 = connectTemp2*-1;
                        
                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2-1 >= 0 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2+1 < dimension+2 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2+1 < dimension+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                    }
                }
            }
            
            int zeroFillFlag = 0;
            
            for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
            }
            
            if (zeroFillFlag == 1){
                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                        connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                        
                        if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                    }
                }
                
                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                        if (connectivityUpdate5 [counterY2][counterX2] > 0) outlineCheck [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                    }
                }
            }
            
            delete [] connectCheckArray;
        }
        
        for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] connectivityUpdate5 [counter1];
        
        delete [] connectivityUpdate5;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (outlineCheck [counterY][counterX] != 0){
                    if (counterX+1 < dimension && outlineCheck [counterY][counterX+1] == 0) outlineCheck [counterY][counterX] = -1;
                    else if (counterY+1 < dimension && outlineCheck [counterY+1][counterX] == 0) outlineCheck [counterY][counterX] = -1;
                    else if (counterX-1 >= 0 && outlineCheck [counterY][counterX-1] == 0) outlineCheck [counterY][counterX] = -1;
                    else if (counterY-1 >= 0 && outlineCheck [counterY-1][counterX] == 0) outlineCheck [counterY][counterX] = -1;
                }
            }
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (outlineCheck [counterY][counterX] > 0) outlineCheck [counterY][counterX] = 0;
                
                if (outlineCheck [counterY][counterX] < 0) outlineCheck [counterY][counterX] = 1;
            }
        }
        
        connectivityNumber = 0;
        
        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                if (outlineCheck [counterY2][counterX2] == 0){
                    connectivityNumber--;
                    connectAnalysisCount = 0;
                    
                    outlineCheck [counterY2][counterX2] = connectivityNumber;
                    
                    if (counterY2-1 >= 0 && outlineCheck [counterY2-1][counterX2] == 0){
                        outlineCheck [counterY2-1][counterX2] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                    }
                    if (counterX2+1 < dimension && outlineCheck [counterY2][counterX2+1] == 0){
                        outlineCheck [counterY2][counterX2+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                    }
                    if (counterY2+1 < dimension && outlineCheck [counterY2+1][counterX2] == 0){
                        outlineCheck [counterY2+1][counterX2] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                    }
                    if (counterX2-1 >= 0 && outlineCheck [counterY2][counterX2-1] == 0){
                        outlineCheck [counterY2][counterX2-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && outlineCheck [ySource-1][xSource] == 0){
                                    outlineCheck [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension && outlineCheck [ySource][xSource+1] == 0){
                                    outlineCheck [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && outlineCheck [ySource+1][xSource] == 0){
                                    outlineCheck [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && outlineCheck [ySource][xSource-1] == 0){
                                    outlineCheck [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        delete [] connectAnalysisX;
        delete [] connectAnalysisY;
        delete [] connectAnalysisTempX;
        delete [] connectAnalysisTempY;
        
        //------Determine number of pixels------
        connectivityNumber = connectivityNumber*-1;
        
        int *connectedPix = new int [connectivityNumber+50];
        for (int counter1 = 0; counter1 <= connectivityNumber; counter1++) connectedPix [counter1] = 0;
        
        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                if (outlineCheck [counterY2][counterX2] < -1) connectedPix [outlineCheck [counterY2][counterX2]*-1]++;
            }
        }
        
        int **newConnectivityMapTemp = new int *[dimension+4];
        for (int counter1 = 0; counter1 < dimension+4; counter1++) newConnectivityMapTemp [counter1] = new int [dimension+4];
        
        for (int counterY = 0; counterY < dimension+4; counterY++){
            for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
        }
        
        int firstProcess = 0;
        int largestConnect = 0;
        int largestConnectNo = 0;
        int removeFlag = 0;
        
        for (int counter1 = 2; counter1 <= connectivityNumber; counter1++){
            largestConnect = 0;
            largestConnectNo = 0;
            
            for (int counter2 = 2; counter2 <= connectivityNumber; counter2++){
                if (connectedPix [counter2] > largestConnect){
                    largestConnect = connectedPix [counter2];
                    largestConnectNo = counter2;
                }
            }
            
            connectedPix [largestConnectNo] = 0;
            
            removeFlag = 0;
            
            if (firstProcess == 1){
                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                        if (outlineCheck [counterY2][counterX2] == largestConnectNo*-1){
                            if (counterY2-1 >= 0 && counterX2-1 >= 0 && outlineCheck [counterY2-1][counterX2-1] == 0) removeFlag = 1;
                            if (counterY2-1 >= 0 && outlineCheck [counterY2-1][counterX2] == 0) removeFlag = 1;
                            if (counterY2-1 >= 0 && counterX2+1 < dimension && outlineCheck [counterY2-1][counterX2+1] == 0) removeFlag = 1;
                            if (counterX2+1 < dimension && outlineCheck [counterY2][counterX2+1] == 0) removeFlag = 1;
                            if (counterY2+1 < dimension && counterX2+1 < dimension && outlineCheck [counterY2+1][counterX2+1] == 0) removeFlag = 1;
                            if (counterY2+1 < dimension && outlineCheck [counterY2+1][counterX2] == 0) removeFlag = 1;
                            if (counterY2+1 < dimension && counterX2-1 >= 0 && outlineCheck [counterY2+1][counterX2-1] == 0) removeFlag = 1;
                            if (counterX2-1 >= 0 && outlineCheck [counterY2][counterX2-1] == 0) removeFlag = 1;
                        }
                    }
                }
            }
            
            if (removeFlag == 0){
                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                        if (outlineCheck [counterY2][counterX2] == largestConnectNo*-1){
                            if (counterY2-1 >= 0 && counterX2-1 >= 0 && outlineCheck [counterY2-1][counterX2-1] == 1){
                                newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                                outlineCheck [counterY2-1][counterX2-1] = 0;
                            }
                            if (counterY2-1 >= 0 && outlineCheck [counterY2-1][counterX2] == 1){
                                newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                                outlineCheck [counterY2-1][counterX2] = 0;
                            }
                            if (counterY2-1 >= 0 && counterX2+1 < dimension && outlineCheck [counterY2-1][counterX2+1] == 1){
                                newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                                outlineCheck [counterY2-1][counterX2+1] = 0;
                            }
                            if (counterX2+1 < dimension && outlineCheck [counterY2][counterX2+1] == 1){
                                newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                                outlineCheck [counterY2][counterX2+1] = 0;
                            }
                            if (counterY2+1 < dimension && counterX2+1 < dimension && outlineCheck [counterY2+1][counterX2+1] == 1){
                                newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                                outlineCheck [counterY2+1][counterX2+1] = 0;
                            }
                            if (counterY2+1 < dimension && outlineCheck [counterY2+1][counterX2] == 1){
                                newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                                outlineCheck [counterY2+1][counterX2] = 0;
                            }
                            if (counterY2+1 < dimension && counterX2-1 >= 0 && outlineCheck [counterY2+1][counterX2-1] == 1){
                                newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                                outlineCheck [counterY2+1][counterX2-1] = 0;
                            }
                            if (counterX2-1 >= 0 && outlineCheck [counterY2][counterX2-1] == 1){
                                newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                                outlineCheck [counterY2][counterX2-1] = 0;
                            }
                        }
                    }
                }
            }
            
            if (removeFlag == 1){
                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                        if (outlineCheck [counterY2][counterX2] == largestConnectNo*-1){
                            if (counterY2-1 >= 0 && counterX2-1 >= 0 && outlineCheck [counterY2-1][counterX2-1] == 1){
                                newConnectivityMapTemp [counterY2-1][counterX2-1] = 2;
                                outlineCheck [counterY2-1][counterX2-1] = 0;
                            }
                            if (counterY2-1 >= 0 && outlineCheck [counterY2-1][counterX2] == 1){
                                newConnectivityMapTemp [counterY2-1][counterX2] = 2;
                                outlineCheck [counterY2-1][counterX2] = 0;
                            }
                            if (counterY2-1 >= 0 && counterX2+1 < dimension && outlineCheck [counterY2-1][counterX2+1] == 1){
                                newConnectivityMapTemp [counterY2-1][counterX2+1] = 2;
                                outlineCheck [counterY2-1][counterX2+1] = 0;
                            }
                            if (counterX2+1 < dimension && outlineCheck [counterY2][counterX2+1] == 1){
                                newConnectivityMapTemp [counterY2][counterX2+1] = 2;
                                outlineCheck [counterY2][counterX2+1] = 0;
                            }
                            if (counterY2+1 < dimension && counterX2+1 < dimension && outlineCheck [counterY2+1][counterX2+1] == 1){
                                newConnectivityMapTemp [counterY2+1][counterX2+1] = 2;
                                outlineCheck [counterY2+1][counterX2+1] = 0;
                            }
                            if (counterY2+1 < dimension && outlineCheck [counterY2+1][counterX2] == 1){
                                newConnectivityMapTemp [counterY2+1][counterX2] = 2;
                                outlineCheck [counterY2+1][counterX2] = 0;
                            }
                            if (counterY2+1 < dimension && counterX2-1 >= 0 && outlineCheck [counterY2+1][counterX2-1] == 1){
                                newConnectivityMapTemp [counterY2+1][counterX2-1] = 2;
                                outlineCheck [counterY2+1][counterX2-1] = 0;
                            }
                            if (counterX2-1 >= 0 && outlineCheck [counterY2][counterX2-1] == 1){
                                newConnectivityMapTemp [counterY2][counterX2-1] = 2;
                                outlineCheck [counterY2][counterX2-1] = 0;
                            }
                        }
                    }
                }
            }
            
            if (firstProcess == 0) firstProcess = 1;
        }
        
        delete [] connectedPix;
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3 [counterA][counterB];
        //    cout<<" previousMap3 "<<counterA<<endl;
        // }
        
        int xPositionTempStart = 0;
        int yPositionTempStart = 0;
        int lineSize = 0;
        
        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                    outlineCheck [counterY2][counterX2] = 1;
                    xPositionTempStart = counterX2;
                    yPositionTempStart = counterY2;
                    lineSize++;
                }
                else outlineCheck [counterY2][counterX2] = 0;
            }
        }
        
        for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] newConnectivityMapTemp [counter1];
        delete [] newConnectivityMapTemp;
        
        int constructedLineCount = 0;
        int findFlag = 0;
        
        int *arrayNewLines = new int [lineSize*2+50];
        
        outlineCheck [yPositionTempStart][xPositionTempStart] = -1;
        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
        
        do{
            
            findFlag = 0;
            terminationFlag = 0;
            
            if (xPositionTempStart+1 < dimension){
                if (outlineCheck [yPositionTempStart][xPositionTempStart+1] == 1){
                    outlineCheck [yPositionTempStart][xPositionTempStart+1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                }
            }
            
            if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                if (outlineCheck [yPositionTempStart+1][xPositionTempStart+1] == 1){
                    outlineCheck [yPositionTempStart+1][xPositionTempStart+1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                }
            }
            
            if (yPositionTempStart+1 < dimension && findFlag == 0){
                if (outlineCheck [yPositionTempStart+1][xPositionTempStart] == 1){
                    outlineCheck [yPositionTempStart+1][xPositionTempStart] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                    yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                }
            }
            
            if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                if (outlineCheck [yPositionTempStart+1][xPositionTempStart-1] == 1){
                    outlineCheck [yPositionTempStart+1][xPositionTempStart-1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                }
            }
            
            if (xPositionTempStart-1 >= 0 && findFlag == 0){
                if (outlineCheck [yPositionTempStart][xPositionTempStart-1] == 1){
                    outlineCheck [yPositionTempStart][xPositionTempStart-1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                }
            }
            
            if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                if (outlineCheck [yPositionTempStart-1][xPositionTempStart-1] == 1){
                    outlineCheck [yPositionTempStart-1][xPositionTempStart-1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                }
            }
            
            if (yPositionTempStart-1 >= 0 && findFlag == 0){
                if (outlineCheck [yPositionTempStart-1][xPositionTempStart] == 1){
                    outlineCheck [yPositionTempStart-1][xPositionTempStart] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                    yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                }
            }
            
            if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                if (outlineCheck [yPositionTempStart-1][xPositionTempStart+1] == 1){
                    outlineCheck [yPositionTempStart-1][xPositionTempStart+1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                }
            }
            
        } while (terminationFlag == 1);
        
        delete [] arrayLinkedLine;
        arrayLinkedLine = new int [constructedLineCount*3+500], linkedLineCount = 0, linkedLineLimit = constructedLineCount*3+500;
        
        maxPointDimX = 0;
        maxPointDimY = 0;
        minPointDimX = 100000;
        minPointDimY = 100000;
        
        if (constructedLineCount != 0){
            int firstFlag = 0;
            int pixValue = 0;
            
            for (int counter1 = 0; counter1 < constructedLineCount/2; counter1++){
                pixValue = 110;
                
                if (arrayNewLines [counter1*2] >= 0 && arrayNewLines [counter1*2] < imageWidth && arrayNewLines [counter1*2+1] >= 0 && arrayNewLines [counter1*2+1] < imageWidth) pixValue = arrayExtractedImage [arrayNewLines [counter1*2+1]][arrayNewLines [counter1*2]];
                
                arrayLinkedLine [linkedLineCount] = arrayNewLines [counter1*2], linkedLineCount++; //------X position------0
                arrayLinkedLine [linkedLineCount] = arrayNewLines [counter1*2+1], linkedLineCount++; //------Y position------1
                arrayLinkedLine [linkedLineCount] = pixValue, linkedLineCount++; //------Pix Value------2
                arrayLinkedLine [linkedLineCount] = 0, linkedLineCount++; //------Line number (cell humber)------3
                
                if (firstFlag == 0){
                    firstFlag = 1;
                    arrayLinkedLine [linkedLineCount] = 1, linkedLineCount++; //------Start-End position------4
                }
                else arrayLinkedLine [linkedLineCount] = 0, linkedLineCount++;
                
                if (maxPointDimX < arrayNewLines [counter1*2]) maxPointDimX = arrayNewLines [counter1*2];
                if (minPointDimX > arrayNewLines [counter1*2]) minPointDimX = arrayNewLines [counter1*2];
                if (maxPointDimY < arrayNewLines [counter1*2+1]) maxPointDimY = arrayNewLines [counter1*2+1];
                if (minPointDimY > arrayNewLines [counter1*2+1]) minPointDimY = arrayNewLines [counter1*2+1];
            }
            
            arrayLinkedLine [linkedLineCount-1] = 2;
        }
        
        for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] outlineCheck [counter1];
        delete [] outlineCheck;
        
        delete [] arrayNewLines;
    }
    
    if (maxPointDimX != 0 && maxPointDimY != 0 && minPointDimX != 10000 && minPointDimY != 10000){
        int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
        int verticalLength = (maxPointDimY-minPointDimY)/2*2;
        int dimension = 0;
        
        if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
        if (horizontalLength < verticalLength) dimension = verticalLength+30;
        
        dimension = (dimension/2)*2;
        
        int horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
        int verticalStart = minPointDimY-(dimension-verticalLength)/2;
        
        //==========Data set to Matrix==========
        int *array200Line = new int [outlineVectorSourceCount1*3+500], line200Count = 0;
        int *array220Line = new int [outlineVectorSourceCount2*3+500], line220Count = 0;
        int *array240Line = new int [outlineVectorSourceCount3*3+500], line240Count = 0;
        
        int **vectorSourceA1 = new int *[dimension+4]; //------Matrix, Over 200, A3 holds final results------
        int **vectorSourceB1 = new int *[dimension+4]; //------Matrix, Over 220, B3 holds final results------
        int **vectorSourceC1 = new int *[dimension+4]; //------Matrix, Over 240, C3 holds final results------
        int **linkedConnectivityMatrix1 = new int *[dimension+4]; //------Matrix, linked Line data, 3 holds final results------
        
        for (int counter1 = 0; counter1 < dimension+4; counter1++){
            vectorSourceA1 [counter1] = new int [dimension+4];
            vectorSourceB1 [counter1] = new int [dimension+4];
            vectorSourceC1 [counter1] = new int [dimension+4];
            linkedConnectivityMatrix1 [counter1] = new int [dimension+4];
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                vectorSourceA1 [counterY][counterX] = 0;
                vectorSourceB1 [counterY][counterX] = 0;
                vectorSourceC1 [counterY][counterX] = 0;
                linkedConnectivityMatrix1 [counterY][counterX] = 0;
            }
        }
        
        //------Data Set into Matrix Array------
        int outsideRange = 0;
        int vectorNumberTemp = 0;
        int pixValue = 0;
        
        if (outlineVectorSourceCount1 != 0){
            outsideRange = 0;
            vectorNumberTemp = arrayOutlineVectorSource1 [0];
            
            for (int counter1 = 0; counter1 < outlineVectorSourceCount1/3; counter1++){
                if (vectorNumberTemp != arrayOutlineVectorSource1 [counter1*3] || counter1 == outlineVectorSourceCount1/3-1){
                    if (outsideRange == 0){
                        for (int counter2 = 0; counter2 < outlineVectorSourceCount1/3; counter2++){
                            if (arrayOutlineVectorSource1 [counter2*3] == vectorNumberTemp){
                                if (arrayOutlineVectorSource1 [counter2*3+2] >= 0 && arrayOutlineVectorSource1 [counter2*3+2] < imageWidth && arrayOutlineVectorSource1 [counter2*3+1]-horizontalStart >= 0 && arrayOutlineVectorSource1 [counter2*3+1] < imageWidth){
                                    pixValue = arrayExtractedImage [arrayOutlineVectorSource1 [counter2*3+2]][arrayOutlineVectorSource1 [counter2*3+1]];
                                }
                                else pixValue = 100;
                                
                                array200Line [line200Count] = vectorNumberTemp, line200Count++;
                                array200Line [line200Count] = arrayOutlineVectorSource1 [counter2*3+1]-horizontalStart, line200Count++;
                                array200Line [line200Count] = arrayOutlineVectorSource1 [counter2*3+2]-verticalStart, line200Count++;
                                array200Line [line200Count] = pixValue, line200Count++;
                                array200Line [line200Count] = 0, line200Count++;
                                array200Line [line200Count] = 0, line200Count++;
                                
                                vectorSourceA1 [arrayOutlineVectorSource1 [counter2*3+2]-verticalStart][arrayOutlineVectorSource1 [counter2*3+1]-horizontalStart] = vectorNumberTemp;
                            }
                        }
                    }
                    
                    vectorNumberTemp = arrayOutlineVectorSource1 [counter1*3];
                    outsideRange = 0;
                    
                    if (arrayOutlineVectorSource1 [counter1*3+1]-horizontalStart < 0 || arrayOutlineVectorSource1 [counter1*3+1]-horizontalStart > dimension || arrayOutlineVectorSource1 [counter1*3+2]-verticalStart < 0 || arrayOutlineVectorSource1 [counter1*3+2]-verticalStart > dimension) outsideRange = 1;
                }
                else if (vectorNumberTemp == arrayOutlineVectorSource1 [counter1*3]){
                    if (arrayOutlineVectorSource1 [counter1*3+1]-horizontalStart < 0 || arrayOutlineVectorSource1 [counter1*3+1]-horizontalStart > dimension || arrayOutlineVectorSource1 [counter1*3+2]-verticalStart < 0 || arrayOutlineVectorSource1 [counter1*3+2]-verticalStart > dimension) outsideRange = 1;
                }
            }
        }
        
        if (outlineVectorSourceCount2 != 0){
            outsideRange = 0;
            vectorNumberTemp = arrayOutlineVectorSource2 [0];
            
            for (int counter1 = 0; counter1 < outlineVectorSourceCount2/3; counter1++){
                if (vectorNumberTemp != arrayOutlineVectorSource2 [counter1*3] || counter1 == outlineVectorSourceCount2/3-1){
                    if (outsideRange == 0){
                        for (int counter2 = 0; counter2 < outlineVectorSourceCount2/3; counter2++){
                            if (arrayOutlineVectorSource2 [counter2*3] == vectorNumberTemp){
                                if (arrayOutlineVectorSource2 [counter2*3+2] >= 0 && arrayOutlineVectorSource2 [counter2*3+2] < imageWidth && arrayOutlineVectorSource2 [counter2*3+1] >= 0 && arrayOutlineVectorSource2 [counter2*3+1] < imageWidth){
                                    pixValue = arrayExtractedImage [arrayOutlineVectorSource2 [counter2*3+2]][arrayOutlineVectorSource2 [counter2*3+1]];
                                }
                                else pixValue = 100;
                                
                                array220Line [line220Count] = vectorNumberTemp, line220Count++;
                                array220Line [line220Count] = arrayOutlineVectorSource2 [counter2*3+1]-horizontalStart, line220Count++;
                                array220Line [line220Count] = arrayOutlineVectorSource2 [counter2*3+2]-verticalStart, line220Count++;
                                array220Line [line220Count] = pixValue, line220Count++;
                                array220Line [line220Count] = 0, line220Count++;
                                array220Line [line220Count] = 0, line220Count++;
                                
                                vectorSourceB1 [arrayOutlineVectorSource2 [counter2*3+2]-verticalStart][arrayOutlineVectorSource2 [counter2*3+2]-verticalStart] = vectorNumberTemp;
                            }
                        }
                    }
                    
                    vectorNumberTemp = arrayOutlineVectorSource2 [counter1*3];
                    outsideRange = 0;
                    
                    if (arrayOutlineVectorSource2 [counter1*3+1]-horizontalStart < 0 || arrayOutlineVectorSource2 [counter1*3+1]-horizontalStart > dimension || arrayOutlineVectorSource2 [counter1*3+2]-verticalStart < 0 || arrayOutlineVectorSource2 [counter1*3+2]-verticalStart > dimension) outsideRange = 1;
                }
                else if (vectorNumberTemp == arrayOutlineVectorSource2 [counter1*3]){
                    if (arrayOutlineVectorSource2 [counter1*3+1]-horizontalStart < 0 || arrayOutlineVectorSource2 [counter1*3+1]-horizontalStart > dimension || arrayOutlineVectorSource2 [counter1*3+2]-verticalStart < 0 || arrayOutlineVectorSource2 [counter1*3+2]-verticalStart > dimension) outsideRange = 1;
                }
            }
        }
        
        if (outlineVectorSourceCount3 != 0){
            outsideRange = 0;
            vectorNumberTemp = arrayOutlineVectorSource3 [0];
            
            for (int counter1 = 0; counter1 < outlineVectorSourceCount3/3; counter1++){
                if (vectorNumberTemp != arrayOutlineVectorSource3 [counter1*3] || counter1 == outlineVectorSourceCount3/3-1){
                    if (outsideRange == 0){
                        for (int counter2 = 0; counter2 < outlineVectorSourceCount3/3; counter2++){
                            if (arrayOutlineVectorSource3 [counter2*3] == vectorNumberTemp){
                                if (arrayOutlineVectorSource3 [counter2*3+2] >= 0 && arrayOutlineVectorSource3 [counter2*3+2] < imageWidth && arrayOutlineVectorSource3 [counter2*3+1] >= 0 && arrayOutlineVectorSource3 [counter2*3+1] < imageWidth){
                                    pixValue = arrayExtractedImage [arrayOutlineVectorSource3 [counter2*3+2]][arrayOutlineVectorSource3 [counter2*3+1]];
                                }
                                else pixValue = 100;
                                
                                array240Line [line240Count] = vectorNumberTemp, line240Count++;
                                array240Line [line240Count] = arrayOutlineVectorSource3 [counter2*3+1]-horizontalStart, line240Count++;
                                array240Line [line240Count] = arrayOutlineVectorSource3 [counter2*3+2]-verticalStart, line240Count++;
                                array240Line [line240Count] = pixValue, line240Count++;
                                array240Line [line240Count] = 0, line240Count++;
                                array240Line [line240Count] = 0, line240Count++;
                                
                                vectorSourceC1 [arrayOutlineVectorSource3 [counter2*3+2]-verticalStart][arrayOutlineVectorSource3 [counter2*3+1]-horizontalStart] = vectorNumberTemp;
                            }
                        }
                    }
                    
                    vectorNumberTemp = arrayOutlineVectorSource3 [counter1*3];
                    outsideRange = 0;
                    
                    if (arrayOutlineVectorSource3 [counter1*3+1]-horizontalStart < 0 || arrayOutlineVectorSource3 [counter1*3+1]-horizontalStart > dimension || arrayOutlineVectorSource3 [counter1*3+2]-verticalStart < 0 || arrayOutlineVectorSource3 [counter1*3+2]-verticalStart > dimension) outsideRange = 1;
                }
                else if (vectorNumberTemp == arrayOutlineVectorSource3 [counter1*3]){
                    if (arrayOutlineVectorSource3 [counter1*3+1]-horizontalStart < 0 || arrayOutlineVectorSource3 [counter1*3+1]-horizontalStart > dimension || arrayOutlineVectorSource3 [counter1*3+2]-verticalStart < 0 || arrayOutlineVectorSource3 [counter1*3+2]-verticalStart > dimension) outsideRange = 1;
                }
            }
        }
        
        vectorNumberTemp = 1;
        int valueDimensionX = 0;
        int valueDimensionY = 0;
        
        for (int counter1 = 0; counter1 < linkedLineCount/5; counter1++){
            valueDimensionX = arrayLinkedLine [counter1*5]-horizontalStart;
            valueDimensionY = arrayLinkedLine [counter1*5+1]-verticalStart;
            
            if (valueDimensionX < 0) valueDimensionX = 0;
            else if (valueDimensionX >= dimension) valueDimensionX = dimension-1;
            
            if (valueDimensionY < 0) valueDimensionY = 0;
            else if (valueDimensionY >= dimension) valueDimensionY = dimension-1;
            
            linkedConnectivityMatrix1 [valueDimensionY][valueDimensionX] = vectorNumberTemp;
            
            if (arrayLinkedLine [counter1*5+4] == 2) vectorNumberTemp++;
        }
        
        int connectivityNumber = 0;
        int terminationFlag = 0;
        int connectAnalysisCount = 0;
        int connectAnalysisTempCount = 0;
        int xSource = 0;
        int ySource = 0;
        
        for (int counter1 = 0; counter1 < 4; counter1++){
            int **connectivityTempMatrix1 = new int *[dimension+4];
            
            for (int counter2 = 0; counter2 < dimension+4; counter2++) connectivityTempMatrix1 [counter2] = new int [dimension+4];
            
            if (counter1 == 0){
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++) connectivityTempMatrix1 [counterY][counterX] = vectorSourceA1 [counterY][counterX];
                }
            }
            
            if (counter1 == 1){
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++) connectivityTempMatrix1 [counterY][counterX] = vectorSourceB1 [counterY][counterX];
                }
            }
            
            if (counter1 == 2){
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++) connectivityTempMatrix1 [counterY][counterX] = vectorSourceC1 [counterY][counterX];
                }
            }
            
            if (counter1 == 3){
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++) connectivityTempMatrix1 [counterY][counterX] = linkedConnectivityMatrix1 [counterY][counterX];
                }
            }
            
            //------Connectivity analysis, For Zero------
            int *connectAnalysisX = new int [dimension*4];
            int *connectAnalysisY = new int [dimension*4];
            int *connectAnalysisTempX = new int [dimension*4];
            int *connectAnalysisTempY = new int [dimension*4];
            
            connectivityNumber = -3;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityTempMatrix1 [counterY][counterX] == 0){
                        connectivityNumber = connectivityNumber+2;
                        
                        if (connectivityNumber >= 1){
                            if (counterY-1 >= 0 && connectivityTempMatrix1 [counterY-1][counterX] != -1 && connectivityTempMatrix1 [counterY-1][counterX] != 0){
                                connectivityNumber = connectivityTempMatrix1 [counterY-1][counterX], connectivityTempMatrix1 [counterY-1][counterX] = connectivityNumber;
                            }
                            if (counterX+1 < dimension+2 && connectivityTempMatrix1 [counterY][counterX+1] != -1 && connectivityTempMatrix1 [counterY][counterX+1] != 0){
                                connectivityNumber = connectivityTempMatrix1 [counterY][counterX+1], connectivityTempMatrix1 [counterY][counterX+1] = connectivityNumber;
                            }
                            if (counterY+1 < dimension+2 && connectivityTempMatrix1 [counterY+1][counterX] != -1 && connectivityTempMatrix1 [counterY+1][counterX] != 0){
                                connectivityNumber = connectivityTempMatrix1 [counterY+1][counterX], connectivityTempMatrix1 [counterY+1][counterX] = connectivityNumber;
                            }
                            if (counterX-1 >= 0 && connectivityTempMatrix1 [counterY][counterX-1] != -1 && connectivityTempMatrix1 [counterY][counterX-1] != 0){
                                connectivityNumber = connectivityTempMatrix1 [counterY][counterX-1], connectivityTempMatrix1 [counterY][counterX-1] = connectivityNumber;
                            }
                        }
                        
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && connectivityTempMatrix1 [counterY-1][counterX] == 0){
                            connectivityTempMatrix1 [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension && connectivityTempMatrix1 [counterY][counterX+1] == 0){
                            connectivityTempMatrix1 [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && connectivityTempMatrix1 [counterY+1][counterX] == 0){
                            connectivityTempMatrix1 [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && connectivityTempMatrix1 [counterY][counterX-1] == 0){
                            connectivityTempMatrix1 [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                    xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                    
                                    if (ySource-1 >= 0 && connectivityTempMatrix1 [ySource-1][xSource] == 0){
                                        connectivityTempMatrix1 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && connectivityTempMatrix1 [ySource][xSource+1] == 0){
                                        connectivityTempMatrix1 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && connectivityTempMatrix1 [ySource+1][xSource] == 0){
                                        connectivityTempMatrix1 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityTempMatrix1 [ySource][xSource-1] == 0){
                                        connectivityTempMatrix1 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                    connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            delete [] connectAnalysisX;
            delete [] connectAnalysisY;
            delete [] connectAnalysisTempX;
            delete [] connectAnalysisTempY;
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityTempMatrix1 [counterA][counterB];
            //	cout<<" connectivityTempMatrix1 "<<counterA<<endl;
            //}
            
            //------Remove connectivity groups, which attach edge, extract inner part of Linked Line------
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityTempMatrix1 [counterY][counterX] == -1) connectivityTempMatrix1 [counterY][counterX] = 0;
                }
            }
            
            if (counter1 == 0){
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++) vectorSourceA1 [counterY][counterX] = connectivityTempMatrix1 [counterY][counterX];
                }
            }
            
            if (counter1 == 1){
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++) vectorSourceB1 [counterY][counterX] = connectivityTempMatrix1 [counterY][counterX];
                }
            }
            
            if (counter1 == 2){
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++) vectorSourceC1 [counterY][counterX] = connectivityTempMatrix1 [counterY][counterX];
                }
            }
            
            if (counter1 == 3){
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++) linkedConnectivityMatrix1 [counterY][counterX] = connectivityTempMatrix1 [counterY][counterX];
                }
            }
            
            for (int counter2 = 0; counter2 < dimension+4; counter2++) delete [] connectivityTempMatrix1 [counter2];
            delete [] connectivityTempMatrix1;
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<vectorSourceA1 [counterA][counterB];
        //    cout<<" vectorSourceA1 "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<vectorSourceB1 [counterA][counterB];
        //    cout<<" vectorSourceB1 "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<vectorSourceC1 [counterA][counterB];
        //    cout<<" vectorSourceC1 "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<linkedConnectivityMatrix1 [counterA][counterB];
        //    cout<<" linkedConnectivityMatrix1 "<<counterA<<endl;
        //}
        
        //==========Select 200, 220, 240 Lines, which are contained by linked Line and over 190==========
        int *array200Line2 = new int [outlineVectorSourceCount1*3+500], line200Count2 = 0;
        int *array220Line2 = new int [outlineVectorSourceCount2*3+500], line220Count2 = 0;
        int *array240Line2 = new int [outlineVectorSourceCount3*3+500], line240Count2 = 0;
        int *arrayLinkLineTemp2 = new int [linkedLineCount*2+500], lineLinkCountTemp2 = 0;
        
        int *array200LineNumber = new int [line200Count+500], lineNumber200Count = 0;
        int *array220LineNumber = new int [line220Count+500], lineNumber220Count = 0;
        int *array240LineNumber = new int [line240Count+500], lineNumber240Count = 0;
        
        int sizeOfArrayTemp = 0;
        int over200TempCount = 0;
        int lineNumberTempCount = 0;
        int matchFlag = 0;
        int vectorNumber = 0;
        int maxPointX = 0;
        int maxPointY = 0;
        int minPointX = 0;
        int minPointY = 0;
        int maxPointCountX = 0;
        int maxPointCountY = 0;
        int minPointCountX = 0;
        int minPointCountY = 0;
        int pointCounter = 0;
        int twoHundredAttachCount = 0;
        int twoHundredAttachTempCount2 = 0;
        int positionOne = 0;
        int positionTwo = 0;
        int findFlag = 0;
        
        for (int counter1 = 0; counter1 < 4; counter1++){
            sizeOfArrayTemp = 0;
            
            if (counter1 == 0) sizeOfArrayTemp = line200Count;
            else if (counter1 == 1) sizeOfArrayTemp = line220Count;
            else if (counter1 == 2) sizeOfArrayTemp = line240Count;
            else if (counter1 == 3) sizeOfArrayTemp = linkedLineCount*3;
            
            int *arrayOver200Temp = new int [sizeOfArrayTemp+50];
            over200TempCount = 0;
            int *arrayLineNumberTemp = new int [sizeOfArrayTemp+50];
            lineNumberTempCount = 0;
            
            if (counter1 == 0 && line200Count != 0){
                for (int counter2 = 0; counter2 < line200Count/6; counter2++){
                    arrayOver200Temp [over200TempCount] = array200Line [counter2*6], over200TempCount++;
                    arrayOver200Temp [over200TempCount] = array200Line [counter2*6+1], over200TempCount++;
                    arrayOver200Temp [over200TempCount] = array200Line [counter2*6+2], over200TempCount++;
                    arrayOver200Temp [over200TempCount] = array200Line [counter2*6+3], over200TempCount++;
                    arrayOver200Temp [over200TempCount] = array200Line [counter2*6+4], over200TempCount++;
                    arrayOver200Temp [over200TempCount] = array200Line [counter2*6+5], over200TempCount++;
                }
            }
            
            if (counter1 == 1 && line220Count != 0){
                for (int counter2 = 0; counter2 < line220Count/6; counter2++){
                    arrayOver200Temp [over200TempCount] = array220Line [counter2*6], over200TempCount++;
                    arrayOver200Temp [over200TempCount] = array220Line [counter2*6+1], over200TempCount++;
                    arrayOver200Temp [over200TempCount] = array220Line [counter2*6+2], over200TempCount++;
                    arrayOver200Temp [over200TempCount] = array220Line [counter2*6+3], over200TempCount++;
                    arrayOver200Temp [over200TempCount] = array220Line [counter2*6+4], over200TempCount++;
                    arrayOver200Temp [over200TempCount] = array220Line [counter2*6+5], over200TempCount++;
                }
            }
            
            if (counter1 == 2 && line240Count != 0){
                for (int counter2 = 0; counter2 < line240Count/6; counter2++){
                    arrayOver200Temp [over200TempCount] = array240Line [counter2*6], over200TempCount++;
                    arrayOver200Temp [over200TempCount] = array240Line [counter2*6+1], over200TempCount++;
                    arrayOver200Temp [over200TempCount] = array240Line [counter2*6+2], over200TempCount++;
                    arrayOver200Temp [over200TempCount] = array240Line [counter2*6+3], over200TempCount++;
                    arrayOver200Temp [over200TempCount] = array240Line [counter2*6+4], over200TempCount++;
                    arrayOver200Temp [over200TempCount] = array240Line [counter2*6+5], over200TempCount++;
                }
            }
            
            if (counter1 == 3 && linkedLineCount != 0){
                for (int counter2 = 0; counter2 < linkedLineCount/5; counter2++){
                    arrayOver200Temp [over200TempCount] = arrayLinkedLine [counter2*5+3], over200TempCount++;
                    arrayOver200Temp [over200TempCount] = arrayLinkedLine [counter2*5]-horizontalStart, over200TempCount++;
                    arrayOver200Temp [over200TempCount] = arrayLinkedLine [counter2*5+1]-verticalStart, over200TempCount++;
                    arrayOver200Temp [over200TempCount] = arrayLinkedLine [counter2*5+2], over200TempCount++;
                    arrayOver200Temp [over200TempCount] = 0, over200TempCount++;
                    arrayOver200Temp [over200TempCount] = 0, over200TempCount++;
                }
            }
            
            if (over200TempCount != 0){
                do{
                    
                    terminationFlag = 1;
                    matchFlag = 0;
                    vectorNumber = 0;
                    
                    for (int counter2 = 0; counter2 < over200TempCount/6; counter2++){
                        vectorNumber = arrayOver200Temp [counter2*6];
                        
                        if (arrayOver200Temp [counter2*6+1] >= 0 && arrayOver200Temp [counter2*6+2] >= 0 && arrayOver200Temp [counter2*6+1] < dimension && arrayOver200Temp [counter2*6+2] < dimension){
                            if ((linkedConnectivityMatrix1 [arrayOver200Temp [counter2*6+2]][arrayOver200Temp [counter2*6+1]] != 0) && arrayOver200Temp [counter2*6+5] == 0){
                                matchFlag = 1;
                                break;
                            }
                        }
                    }
                    
                    if (matchFlag == 0) terminationFlag = 0;
                    else{
                        
                        arrayLineNumberTemp [lineNumberTempCount] = vectorNumber, lineNumberTempCount++;
                        
                        //------Find Min/Max XY to set Point 1 and 2------
                        maxPointX = -1;
                        maxPointY = -1;
                        minPointX = 10000;
                        minPointY = 10000;
                        maxPointCountX = -1;
                        maxPointCountY = -1;
                        minPointCountX = -1;
                        minPointCountY = -1;
                        pointCounter = 0;
                        
                        int *arrayTwoHundredAttach = new int [over200TempCount+500];
                        twoHundredAttachCount = 0;
                        
                        for (int counter2 = 0; counter2 < over200TempCount/6; counter2++){
                            if (vectorNumber == arrayOver200Temp [counter2*6]){
                                if (arrayOver200Temp [counter2*6+2]+verticalStart >= 0 && arrayOver200Temp [counter2*6+2]+verticalStart < imageWidth && arrayOver200Temp [counter2*6+1]+horizontalStart >= 0 && arrayOver200Temp [counter2*6+1]+horizontalStart < imageWidth){
                                    pixValue = arrayExtractedImage [arrayOver200Temp [counter2*6+2]+verticalStart][arrayOver200Temp [counter2*6+1]+horizontalStart];
                                }
                                else pixValue = 100;
                                
                                arrayTwoHundredAttach [twoHundredAttachCount] = arrayOver200Temp [counter2*6+1], twoHundredAttachCount++;
                                arrayTwoHundredAttach [twoHundredAttachCount] = arrayOver200Temp [counter2*6+2], twoHundredAttachCount++;
                                arrayTwoHundredAttach [twoHundredAttachCount] = pixValue, twoHundredAttachCount++;
                                arrayTwoHundredAttach [twoHundredAttachCount] = vectorNumber, twoHundredAttachCount++;
                                arrayTwoHundredAttach [twoHundredAttachCount] = 0, twoHundredAttachCount++;
                                
                                if (maxPointX < arrayOver200Temp [counter2*6+1]) maxPointX = arrayOver200Temp [counter2*6+1], maxPointCountX = pointCounter;
                                if (minPointX > arrayOver200Temp [counter2*6+1]) minPointX = arrayOver200Temp [counter2*6+1], minPointCountX = pointCounter;
                                if (maxPointY < arrayOver200Temp [counter2*6+2]) maxPointY = arrayOver200Temp [counter2*6+2], maxPointCountY = pointCounter;
                                if (minPointY > arrayOver200Temp [counter2*6+2]) minPointY = arrayOver200Temp [counter2*6+2], minPointCountY = pointCounter;
                                
                                arrayOver200Temp [counter2*6+5] = 1;
                                pointCounter++;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < twoHundredAttachCount/5; counterA++){
                        //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayTwoHundredAttach [counterA*5+counterB];
                        //	cout<<" arrayTwoHundredAttach "<<counterA<<endl;
                        //}
                        
                        //cout<<maxPointX<<" "<<minPointX<<" "<<maxPointY<<" "<<minPointY<<" "<<maxPointCountX<<" "<<minPointCountX<<" "<<maxPointCountY<<" "<<minPointCountY<<" max/min"<<endl;
                        
                        //------Set Point 1 and 2, 1: Max X or Y, 2: Min X or Y------
                        if (maxPointX-minPointX > maxPointY-minPointY){
                            arrayTwoHundredAttach [maxPointCountX*5+4] = 1;
                            arrayTwoHundredAttach [minPointCountX*5+4] = 2;
                            positionOne = maxPointCountX;
                            positionTwo = minPointCountX;
                        }
                        else{
                            
                            arrayTwoHundredAttach [maxPointCountY*5+4] = 2;
                            arrayTwoHundredAttach [minPointCountY*5+4] = 1;
                            positionTwo = maxPointCountY;
                            positionOne = minPointCountY;
                        }
                        
                        //=======================if Equal set top and end (Check if error occurs, if not no need to set)================================================
                        
                        //------ReOrganize line data------
                        int *arrayTwoHundredAttachTemp2 = new int [over200TempCount+500];
                        twoHundredAttachTempCount2 = 0;
                        
                        if (twoHundredAttachCount/5 >= 3){
                            if (positionOne > positionTwo){
                                for (int counter2 = positionTwo+1; counter2 <= positionOne; counter2++){
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+1], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+2], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+3], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+4], twoHundredAttachTempCount2++;
                                }
                                
                                for (int counter2 = positionOne+1; counter2 < twoHundredAttachCount/5; counter2++){
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+1], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+2], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+3], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+4], twoHundredAttachTempCount2++;
                                }
                                
                                for (int counter2 = 0; counter2 <= positionTwo; counter2++){
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+1], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+2], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+3], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+4], twoHundredAttachTempCount2++;
                                }
                            }
                            else{
                                
                                for (int counter2 = positionTwo+1; counter2 < twoHundredAttachCount/5; counter2++){
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+1], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+2], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+3], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+4], twoHundredAttachTempCount2++;
                                }
                                
                                for (int counter2 = 0; counter2 <= positionOne; counter2++){
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+1], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+2], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+3], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+4], twoHundredAttachTempCount2++;
                                }
                                
                                for (int counter2 = positionOne+1; counter2 <= positionTwo; counter2++){
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+1], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+2], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+3], twoHundredAttachTempCount2++;
                                    arrayTwoHundredAttachTemp2 [twoHundredAttachTempCount2] = arrayTwoHundredAttach [counter2*5+4], twoHundredAttachTempCount2++;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < twoHundredAttachTempCount2/5; counterA++){
                            //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayTwoHundredAttachTemp2 [counterA*5+counterB];
                            //	cout<<" arrayTwoHundredAttachTemp2 "<<counterA<<endl;
                            //}
                            
                            if (counter1 == 0){
                                for (int counter2 = 0; counter2 < twoHundredAttachTempCount2/5; counter2++){
                                    array200Line2 [line200Count2] = arrayTwoHundredAttachTemp2 [counter2*5+3], line200Count2++;
                                    array200Line2 [line200Count2] = arrayTwoHundredAttachTemp2 [counter2*5], line200Count2++;
                                    array200Line2 [line200Count2] = arrayTwoHundredAttachTemp2 [counter2*5+1], line200Count2++;
                                    array200Line2 [line200Count2] = arrayTwoHundredAttachTemp2 [counter2*5+2], line200Count2++;
                                    array200Line2 [line200Count2] = arrayTwoHundredAttachTemp2 [counter2*5+4], line200Count2++;
                                    array200Line2 [line200Count2] = 0, line200Count2++;
                                }
                            }
                            
                            if (counter1 == 1){
                                for (int counter2 = 0; counter2 < twoHundredAttachTempCount2/5; counter2++){
                                    array220Line2 [line220Count2] = arrayTwoHundredAttachTemp2 [counter2*5+3], line220Count2++;
                                    array220Line2 [line220Count2] = arrayTwoHundredAttachTemp2 [counter2*5], line220Count2++;
                                    array220Line2 [line220Count2] = arrayTwoHundredAttachTemp2 [counter2*5+1], line220Count2++;
                                    array220Line2 [line220Count2] = arrayTwoHundredAttachTemp2 [counter2*5+2], line220Count2++;
                                    array220Line2 [line220Count2] = arrayTwoHundredAttachTemp2 [counter2*5+4], line220Count2++;
                                    array220Line2 [line220Count2] = 0, line220Count2++;
                                }
                            }
                            
                            if (counter1 == 2){
                                for (int counter2 = 0; counter2 < twoHundredAttachTempCount2/5; counter2++){
                                    array240Line2 [line240Count2] = arrayTwoHundredAttachTemp2 [counter2*5+3], line240Count2++;
                                    array240Line2 [line240Count2] = arrayTwoHundredAttachTemp2 [counter2*5], line240Count2++;
                                    array240Line2 [line240Count2] = arrayTwoHundredAttachTemp2 [counter2*5+1], line240Count2++;
                                    array240Line2 [line240Count2] = arrayTwoHundredAttachTemp2 [counter2*5+2], line240Count2++;
                                    array240Line2 [line240Count2] = arrayTwoHundredAttachTemp2 [counter2*5+4], line240Count2++;
                                    array240Line2 [line240Count2] = 0, line240Count2++;
                                }
                            }
                            
                            if (counter1 == 3){
                                for (int counter2 = 0; counter2 < twoHundredAttachTempCount2/5; counter2++){
                                    arrayLinkLineTemp2 [lineLinkCountTemp2] = arrayTwoHundredAttachTemp2 [counter2*5+3], lineLinkCountTemp2++;
                                    arrayLinkLineTemp2 [lineLinkCountTemp2] = arrayTwoHundredAttachTemp2 [counter2*5], lineLinkCountTemp2++;
                                    arrayLinkLineTemp2 [lineLinkCountTemp2] = arrayTwoHundredAttachTemp2 [counter2*5+1], lineLinkCountTemp2++;
                                    arrayLinkLineTemp2 [lineLinkCountTemp2] = arrayTwoHundredAttachTemp2 [counter2*5+2], lineLinkCountTemp2++;
                                    arrayLinkLineTemp2 [lineLinkCountTemp2] = arrayTwoHundredAttachTemp2 [counter2*5+4], lineLinkCountTemp2++;
                                    arrayLinkLineTemp2 [lineLinkCountTemp2] = 0, lineLinkCountTemp2++;
                                }
                            }
                        }
                        
                        delete [] arrayTwoHundredAttach;
                        delete [] arrayTwoHundredAttachTemp2;
                    }
                    
                } while (terminationFlag == 1);
                
                //for (int counterA = 0; counterA < line200Count2/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<array200Line2 [counterA*6+counterB];
                //	cout<<" line200Count2 "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < line220Count2/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<array220Line2 [counterA*6+counterB];
                //	cout<<" line220Count2 "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < line240Count2/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<array240Line2 [counterA*6+counterB];
                //	cout<<" line240Count2 "<<counterA<<endl;
                //}
                
                if (counter1 == 0 && line200Count2 != 0){
                    for (int counter2 = 0; counter2 < lineNumberTempCount; counter2++) array200LineNumber [lineNumber200Count] = arrayLineNumberTemp [counter2], lineNumber200Count++;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (vectorSourceA1 [counterY][counterX] != 0){
                                findFlag = 0;
                                
                                for (int counter2 = 0; counter2 < line200Count2/6; counter2++){
                                    if (array200Line2 [counter2*6] == vectorSourceA1 [counterY][counterX]){
                                        findFlag = 1;
                                        break;
                                    }
                                }
                                
                                if (findFlag == 0) vectorSourceA1 [counterY][counterX] = 0;
                            }
                        }
                    }
                }
                else if (counter1 == 0 && line200Count2 == 0){
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) vectorSourceA1 [counterY][counterX] = 0;
                    }
                }
                
                if (counter1 == 1 && line220Count2 != 0){
                    for (int counter2 = 0; counter2 < lineNumberTempCount; counter2++) array220LineNumber [lineNumber220Count] = arrayLineNumberTemp [counter2], lineNumber220Count++;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (vectorSourceB1 [counterY][counterX] != 0){
                                findFlag = 0;
                                
                                for (int counter2 = 0; counter2 < line220Count2/6; counter2++){
                                    if (array220Line2 [counter2*6] == vectorSourceB1 [counterY][counterX]){
                                        findFlag = 1;
                                        break;
                                    }
                                }
                                
                                if (findFlag == 0) vectorSourceB1 [counterY][counterX] = 0;
                            }
                        }
                    }
                }
                else if (counter1 == 1 && line220Count2 == 0){
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) vectorSourceB1 [counterY][counterX] = 0;
                    }
                }
                
                if (counter1 == 2 && line240Count2 != 0){
                    for (int counter2 = 0; counter2 < lineNumberTempCount; counter2++) array240LineNumber [lineNumber240Count] = arrayLineNumberTemp [counter2], lineNumber220Count++;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (vectorSourceC1 [counterY][counterX] != 0){
                                findFlag = 0;
                                
                                for (int counter2 = 0; counter2 < line240Count2/6; counter2++){
                                    if (array240Line2 [counter2*6] == vectorSourceC1 [counterY][counterX]){
                                        findFlag = 1;
                                        break;
                                    }
                                }
                                
                                if (findFlag == 0) vectorSourceC1 [counterY][counterX] = 0;
                            }
                        }
                    }
                }
                else if (counter1 == 2 && line240Count2 == 0){
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) vectorSourceC1 [counterY][counterX] = 0;
                    }
                }
            }
            
            delete [] arrayOver200Temp;
            delete [] arrayLineNumberTemp;
        }
        
        delete [] array200Line;
        delete [] array220Line;
        delete [] array240Line;
        
        linkedLineCount = 0;
        
        for (int counter1 = 0; counter1 < lineLinkCountTemp2/6; counter1++){
            arrayLinkedLine [linkedLineCount] = arrayLinkLineTemp2 [counter1*6+1]+horizontalStart, linkedLineCount++;
            arrayLinkedLine [linkedLineCount] = arrayLinkLineTemp2 [counter1*6+2]+verticalStart, linkedLineCount++;
            arrayLinkedLine [linkedLineCount] = arrayLinkLineTemp2 [counter1*6+3], linkedLineCount++;
            arrayLinkedLine [linkedLineCount] = arrayLinkLineTemp2 [counter1*6], linkedLineCount++;
            arrayLinkedLine [linkedLineCount] = arrayLinkLineTemp2 [counter1*6+4], linkedLineCount++;
        }
        
        delete [] arrayLinkLineTemp2;
        
        //------Connectivity Number information Set------
        int vectorNumberGroupA1 = lineNumber200Count;
        int *vectorNumberMatchA1 = new int [vectorNumberGroupA1+4];
        
        if (vectorNumberGroupA1 != 0){
            for (int counter1 = 0; counter1 < vectorNumberGroupA1; counter1++) vectorNumberMatchA1 [counter1] = array200LineNumber [counter1];
        }
        
        int vectorNumberGroupB1 = lineNumber220Count;
        int *vectorNumberMatchB1 = new int [vectorNumberGroupB1+4];
        
        if (vectorNumberGroupB1 != 0){
            for (int counter1 = 0; counter1 < vectorNumberGroupB1; counter1++) vectorNumberMatchB1 [counter1] = array220LineNumber [counter1];
        }
        
        int vectorNumberGroupC1 = lineNumber220Count;
        int *vectorNumberMatchC1 = new int [vectorNumberGroupC1+4];
        
        if (vectorNumberGroupC1 != 0){
            for (int counter1 = 0; counter1 < vectorNumberGroupC1; counter1++) vectorNumberMatchC1 [counter1] = array240LineNumber [counter1];
        }
        
        delete [] array200LineNumber;
        delete [] array220LineNumber;
        delete [] array240LineNumber;
        
        //------Get Center Line Data, find lines, which are inside of connect and over 5 length------
        int linearLineResultContentA = 0;
        int linearLineResultContentB = 0;
        int linearLineResultContentC = 0;
        int analysisResultCountTemp = 0;
        int valueTempX = 0;
        int valueTempY = 0;
        int valueTempX2 = 0;
        int valueTempY2 = 0;
        int vectorNumberTemp1 = 0;
        int vectorNumberTemp2 = 0;
        
        for (int counter1 = 0; counter1 < 3; counter1++){
            analysisResultCountTemp = 0;
            
            if (counter1 == 0) analysisResultCountTemp = analysisResultCount1/5;
            
            if (counter1 == 1) analysisResultCountTemp = analysisResultCount2/5;
            
            if (counter1 == 2) analysisResultCountTemp = analysisResultCount3/5;
            
            if (analysisResultCountTemp != 0){
                int **linearLineResult1 = new int *[analysisResultCountTemp+5];
                for (int counter2 = 0; counter2 < analysisResultCountTemp+5; counter2++) linearLineResult1 [counter2] = new int [6];
                
                double *linearLineDistance1 = new double [analysisResultCountTemp+5];
                
                for (int counter2 = 0; counter2 < analysisResultCountTemp; counter2++){
                    for (int counter3 = 0; counter3 < 5; counter3++) linearLineResult1 [counter2][counter3] = 0;
                    
                    linearLineDistance1 [counter2] = 0;
                }
                
                for (int counter2 = 0; counter2 < analysisResultCountTemp; counter2++){
                    valueTempX = 0;
                    valueTempY = 0;
                    valueTempX2 = 0;
                    valueTempY2 = 0;
                    
                    if (counter1 == 0){
                        valueTempX = arrayAnalysisResult1 [counter2*5+1]-horizontalStart;
                        valueTempY = arrayAnalysisResult1 [counter2*5+2]-verticalStart;
                        valueTempX2 = arrayAnalysisResult1 [counter2*5+3]-horizontalStart;
                        valueTempY2 = arrayAnalysisResult1 [counter2*5+4]-verticalStart;
                    }
                    
                    if (counter1 == 1){
                        valueTempX = arrayAnalysisResult2 [counter2*5+1]-horizontalStart;
                        valueTempY = arrayAnalysisResult2 [counter2*5+2]-verticalStart;
                        valueTempX2 = arrayAnalysisResult2 [counter2*5+3]-horizontalStart;
                        valueTempY2 = arrayAnalysisResult2 [counter2*5+4]-verticalStart;
                    }
                    
                    if (counter1 == 2){
                        valueTempX = arrayAnalysisResult3 [counter2*5+1]-horizontalStart;
                        valueTempY = arrayAnalysisResult3 [counter2*5+2]-verticalStart;
                        valueTempX2 = arrayAnalysisResult3 [counter2*5+3]-horizontalStart;
                        valueTempY2 = arrayAnalysisResult3 [counter2*5+4]-verticalStart;
                    }
                    
                    //cout<<valueTempX<<" "<<valueTempY<<" "<<valueTempX2<<" "<<valueTempY2<<" Value"<<endl;
                    
                    if (valueTempX >= 0 && valueTempX < dimension && valueTempY >= 0 && valueTempY < dimension && valueTempX2 >= 0 && valueTempX2 < dimension && valueTempY2 >= 0 && valueTempY2 < dimension){
                        linearLineResult1 [counter2][0] = valueTempX;
                        linearLineResult1 [counter2][1] = valueTempY;
                        linearLineResult1 [counter2][2] = valueTempX2;
                        linearLineResult1 [counter2][3] = valueTempY2;
                        
                        vectorNumberTemp1 = linkedConnectivityMatrix1 [valueTempY][valueTempX];
                        vectorNumberTemp2 = linkedConnectivityMatrix1 [valueTempY2][valueTempX2];
                        
                        if (vectorNumberTemp1 == 0 && vectorNumberTemp2 == 0) linearLineResult1 [counter2][4] = 0;
                        else if (vectorNumberTemp1 == 0 && vectorNumberTemp2 != 0) linearLineResult1 [counter2][4] = vectorNumberTemp2;
                        else linearLineResult1 [counter2][4] = vectorNumberTemp1;
                        
                        if (linearLineResult1 [counter2][4] != 0){
                            linearLineDistance1 [counter2] = sqrt((valueTempX-valueTempX2)*(valueTempX-valueTempX2)+(valueTempY-valueTempY2)*(valueTempY-valueTempY2));
                            
                            if (linearLineDistance1 [counter2] > 5){
                                if (counter1 == 0) linearLineResultContentA++;
                                
                                if (counter1 == 1) linearLineResultContentB++;
                                
                                if (counter1 == 2) linearLineResultContentC++;
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < analysisResultCountTemp; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<linearLineResult1 [counterA*6+counterB];
                //    cout<<" linearLineResult1 "<<counterA<<" "<<counter<<endl;
                //}
                
                for (int counter2 = 0; counter2 < analysisResultCountTemp+5; counter2++) delete [] linearLineResult1 [counter2];
                delete [] linearLineResult1;
                
                delete [] linearLineDistance1;
            }
        }
        
        //------Determine Total Pix count------
        int linkedTotalCount = 0;
        int linkedOver220 = 0;
        int linkedOver200 = 0;
        int overlap220 = 0;
        int total220 = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (linkedConnectivityMatrix1 [counterY][counterX] != 0) linkedTotalCount++;
                
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageWidth && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageWidth && arrayExtractedImage [counterY+verticalStart][counterX+horizontalStart] >= 220 && linkedConnectivityMatrix1 [counterY][counterX] != 0){
                    linkedOver220++;
                }
                
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageWidth && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageWidth && arrayExtractedImage [counterY+verticalStart][counterX+horizontalStart] >= 200 && linkedConnectivityMatrix1 [counterY][counterX] != 0){
                    linkedOver200++;
                }
                
                if (linkedConnectivityMatrix1 [counterY][counterX] != 0 && vectorSourceB1 [counterY][counterX] != 0) overlap220++;
                
                if (vectorSourceB1 [counterY][counterX] != 0) total220++;
            }
        }
        
        //------Cell dimension determination, For linked and 220: longer number increase------
        int cellDimension200 = 0;
        int numberOfLine = 0;
        int numberOfLineCount = 0;
        int startEndFlag2 = 0;
        int startEndStatusTemp = 0;
        int midPosition1 = 0;
        int midPosition2 = 0;
        int midPosition3 = 0;
        int midPosition4 = 0;
        int longestCross = 0;
        
        double cellDimensionLine = 0;
        double crossAxe1 = 0;
        double crossAxe2 = 0;
        double cellDimension = 0;
        
        for (int counter1 = 0; counter1 < 2; counter1++){
            sizeOfArrayTemp = 0;
            
            if (counter1 == 0) sizeOfArrayTemp = linkedLineCount;
            if (counter1 == 1) sizeOfArrayTemp = line200Count2;
            
            int *arrayDimensionTemp = new int [sizeOfArrayTemp*2+500];
            int dimensionTempCount = 0;
            
            if (counter1 == 0){
                for (int counter2 = 0; counter2 < linkedLineCount/5; counter2++){
                    arrayDimensionTemp [dimensionTempCount] = arrayLinkedLine [counter2*5], dimensionTempCount++;
                    arrayDimensionTemp [dimensionTempCount] = arrayLinkedLine [counter2*5+1], dimensionTempCount++;
                    arrayDimensionTemp [dimensionTempCount] = arrayLinkedLine [counter2*5+4], dimensionTempCount++;
                }
            }
            else if (counter1 == 1){
                for (int counter2 = 0; counter2 < line200Count2/6; counter2++){
                    arrayDimensionTemp [dimensionTempCount] = array200Line2 [counter2*6+1], dimensionTempCount++;
                    arrayDimensionTemp [dimensionTempCount] = array200Line2 [counter2*6+2], dimensionTempCount++;
                    arrayDimensionTemp [dimensionTempCount] = array200Line2 [counter2*6+4], dimensionTempCount++;
                }
            }
            
            numberOfLine = 0;
            
            for (int counter2 = 0; counter2 < dimensionTempCount/3; counter2++){
                if (arrayDimensionTemp [counter2*3+2] == 1) numberOfLine++;
            }
            
            int **dataPosition = new int *[numberOfLine+5];
            for (int counter2 = 0; counter2 < numberOfLine+5; counter2++) dataPosition [counter2] = new int [8];
            
            double **crossLength = new double *[numberOfLine+5];
            for (int counter2 = 0; counter2 < numberOfLine+5; counter2++) crossLength [counter2] = new double [5];
            
            for (int counter2 = 0; counter2 < numberOfLine+5; counter2++){
                dataPosition [counter2][0] = 0;
                dataPosition [counter2][1] = 0;
                dataPosition [counter2][2] = 0;
                dataPosition [counter2][3] = 0;
                dataPosition [counter2][4] = 0;
                dataPosition [counter2][5] = 0;
                dataPosition [counter2][6] = 0;
            }
            
            numberOfLineCount = 0;
            startEndFlag2 = 0;
            
            for (int counter2 = 0; counter2 < dimensionTempCount/3; counter2++){
                startEndStatusTemp = arrayDimensionTemp [counter2*3+2];
                
                if (counter1 == 0){
                    valueTempX = arrayDimensionTemp [counter2*3]-horizontalStart;
                    valueTempY = arrayDimensionTemp [counter2*3+1]-verticalStart;
                }
                else{
                    
                    valueTempX = arrayDimensionTemp [counter2*3];
                    valueTempY = arrayDimensionTemp [counter2*3+1];
                }
                
                if (valueTempX < 0) valueTempX = 0;
                else if (valueTempX >= dimension) valueTempX = dimension-1;
                
                if (valueTempY < 0) valueTempY = 0;
                else if (valueTempY >= dimension) valueTempY = dimension-1;
                
                if (startEndStatusTemp == 0 && startEndFlag2 == 0){
                    startEndFlag2 = 1;
                    dataPosition [numberOfLineCount][0] = valueTempX;
                    dataPosition [numberOfLineCount][1] = valueTempY;
                    dataPosition [numberOfLineCount][2] = counter2;
                }
                else if (startEndStatusTemp == 1 && startEndFlag2 == 1){
                    dataPosition [numberOfLineCount][3] = valueTempX;
                    dataPosition [numberOfLineCount][4] = valueTempY;
                    dataPosition [numberOfLineCount][5] = counter2;
                }
                else if (startEndStatusTemp == 2 && startEndFlag2 == 1){
                    dataPosition [numberOfLineCount][6] = counter2;
                    startEndFlag2 = 0;
                    numberOfLineCount++;
                }
            }
            
            for (int counter2 = 0; counter2 < numberOfLine; counter2++){
                valueTempX = dataPosition [counter2][0];
                valueTempY = dataPosition [counter2][1];
                valueTempX2 = dataPosition [counter2][3];
                valueTempY2 = dataPosition [counter2][4];
                
                crossLength [counter2][0] = sqrt((valueTempX-valueTempX2)*(valueTempX-valueTempX2)+(valueTempY-valueTempY2)*(valueTempY-valueTempY2));
                
                midPosition1 = (int)((dataPosition [counter2][2]+dataPosition [counter2][5])/(double)2);
                midPosition2 = (int)((dataPosition [counter2][5]+dataPosition [counter2][6])/(double)2);
                
                if (counter1 == 0){
                    valueTempX = arrayDimensionTemp [midPosition1*3]-horizontalStart;
                    valueTempY = arrayDimensionTemp [midPosition1*3+1]-verticalStart;
                    valueTempX2 = arrayDimensionTemp [midPosition2*3]-horizontalStart;
                    valueTempY2 = arrayDimensionTemp [midPosition2*3+1]-verticalStart;
                }
                else{
                    
                    valueTempX = arrayDimensionTemp [midPosition1*3];
                    valueTempY = arrayDimensionTemp [midPosition1*3+1];
                    valueTempX2 = arrayDimensionTemp [midPosition2*3];
                    valueTempY2 = arrayDimensionTemp [midPosition2*3+1];
                }
                
                if (valueTempX < 0) valueTempX = 0;
                else if (valueTempX >= dimension) valueTempX = dimension-1;
                
                if (valueTempY < 0) valueTempY = 0;
                else if (valueTempY >= dimension) valueTempY = dimension-1;
                
                if (valueTempX2 < 0) valueTempX2 = 0;
                else if (valueTempX2 >= dimension) valueTempX2 = dimension-1;
                
                if (valueTempY2 < 0) valueTempY2 = 0;
                else if (valueTempY2 >= dimension) valueTempY2 = dimension-1;
                
                crossLength [counter2][1] = sqrt((valueTempX-valueTempX2)*(valueTempX-valueTempX2)+(valueTempY-valueTempY2)*(valueTempY-valueTempY2));
                
                midPosition3 = (int)((dataPosition [counter2][2]+midPosition1)/(double)2);
                midPosition4 = (int)((dataPosition [counter2][6]+midPosition2)/(double)2);
                
                if (counter1 == 0){
                    valueTempX = arrayDimensionTemp [midPosition3*3]-horizontalStart;
                    valueTempY = arrayDimensionTemp [midPosition3*3+1]-verticalStart;
                    valueTempX2 = arrayDimensionTemp [midPosition4*3]-horizontalStart;
                    valueTempY2 = arrayDimensionTemp [midPosition4*3+1]-verticalStart;
                }
                else{
                    
                    valueTempX = arrayDimensionTemp [midPosition3*3];
                    valueTempY = arrayDimensionTemp [midPosition3*3+1];
                    valueTempX2 = arrayDimensionTemp [midPosition4*3];
                    valueTempY2 = arrayDimensionTemp [midPosition4*3+1];
                }
                
                if (valueTempX < 0) valueTempX = 0;
                else if (valueTempX >= dimension) valueTempX = dimension-1;
                
                if (valueTempY < 0) valueTempY = 0;
                else if (valueTempY >= dimension) valueTempY = dimension-1;
                
                if (valueTempX2 < 0) valueTempX2 = 0;
                else if (valueTempX2 >= dimension) valueTempX2 = dimension-1;
                
                if (valueTempY2 < 0) valueTempY2 = 0;
                else if (valueTempY2 >= dimension) valueTempY2 = dimension-1;
                
                crossLength [counter2][2] = sqrt((valueTempX-valueTempX2)*(valueTempX-valueTempX2)+(valueTempY-valueTempY2)*(valueTempY-valueTempY2));
                
                if (crossLength [counter2][2] > crossLength [counter2][1]-5 || crossLength [counter2][2] > crossLength [counter2][1]-5) crossLength [counter2][2] = 0;
                
                midPosition3 = (int)((dataPosition [counter2][5]+midPosition1)/(double)2);
                midPosition4 = (int)((dataPosition [counter2][5]+midPosition2)/(double)2);
                
                if (counter1 == 0){
                    valueTempX = arrayDimensionTemp [midPosition3*3]-horizontalStart;
                    valueTempY = arrayDimensionTemp [midPosition3*3+1]-verticalStart;
                    valueTempX2 = arrayDimensionTemp [midPosition4*3]-horizontalStart;
                    valueTempY2 = arrayDimensionTemp [midPosition4*3+1]-verticalStart;
                }
                else{
                    
                    valueTempX = arrayDimensionTemp [midPosition3*3];
                    valueTempY = arrayDimensionTemp [midPosition3*3+1];
                    valueTempX2 = arrayDimensionTemp [midPosition4*3];
                    valueTempY2 = arrayDimensionTemp [midPosition4*3+1];
                }
                
                if (valueTempX < 0) valueTempX = 0;
                else if (valueTempX >= dimension) valueTempX = dimension-1;
                
                if (valueTempY < 0) valueTempY = 0;
                else if (valueTempY >= dimension) valueTempY = dimension-1;
                
                if (valueTempX2 < 0) valueTempX2 = 0;
                else if (valueTempX2 >= dimension) valueTempX2 = dimension-1;
                
                if (valueTempY2 < 0) valueTempY2 = 0;
                else if (valueTempY2 >= dimension) valueTempY2 = dimension-1;
                
                crossLength [counter2][3] = sqrt((valueTempX-valueTempX2)*(valueTempX-valueTempX2)+(valueTempY-valueTempY2)*(valueTempY-valueTempY2));
                
                if (crossLength [counter2][3] > crossLength [counter2][1]-5 || crossLength [counter2][3] > crossLength [counter2][1]-5) crossLength [counter2][3] = 0;
            }
            
            longestCross = 0;
            
            double *crossLength2 = new double [4];
            crossLength2 [0] = 0;
            crossLength2 [1] = 0;
            crossLength2 [2] = 0;
            crossLength2 [3] = 0;
            
            for (int counter2 = 0; counter2 < numberOfLine; counter2++){
                if (crossLength [counter2][0] > longestCross){
                    longestCross = (int)crossLength [counter2][0];
                    crossLength2 [0] = crossLength [counter2][0];
                    crossLength2 [1] = crossLength [counter2][1];
                    crossLength2 [2] = crossLength [counter2][2];
                    crossLength2 [3] = crossLength [counter2][3];
                }
            }
            
            crossAxe1 = crossLength2 [0];
            crossAxe2 = 0;
            
            for (int counter2 = 1; counter2 < 3; counter2++){
                if (crossLength2 [counter2] > crossAxe2) crossAxe2 = crossLength2 [counter2];
            }
            
            cellDimension = 0;
            
            if (crossAxe1 > crossAxe2){
                if (crossAxe2 != 0 && crossAxe2 >= 1) cellDimension = crossAxe1/(double)crossAxe2;
            }
            else if (crossAxe1 != 0 && crossAxe1 >= 1) cellDimension = crossAxe2/(double)crossAxe1;
            
            if (counter1 == 0) cellDimensionLine = cellDimension;
            
            if (counter1 == 1) cellDimension200 = (int)cellDimension;
            
            delete [] arrayDimensionTemp;
            
            for (int counter2 = 0; counter2 < numberOfLine+5; counter2++){
                delete [] dataPosition [counter2];
                delete [] crossLength [counter2];
            }
            
            delete [] dataPosition;
            delete [] crossLength;
            delete [] crossLength2;
        }
        
        //==========ProcessType 1: no change, processType 2: add source vector line 200, processType 3: replace to source vector line 200, process 4: replace to source vector line 220==========
        
        int processType = 0;
        
        if (linkedLineCount/5 > 20){
            if (linkedOver220/(double)linkedTotalCount < 0.2){
                if (line220Count2 != 0 && total220 > 100 && overlap220/(double)total220 < 0.1 && total220 < 200) processType = 2;
                else if (line220Count2 != 0 && total220 > 100 && overlap220/(double)total220 < 0.1 && total220 >= 200) processType = 3;
                else processType = 1;
            }
            
            if (linkedOver220/(double)linkedTotalCount >= 0.2 && linkedOver220/(double)linkedTotalCount < 0.5){
                if (linkedOver220 > 450 && line220Count2 != 0) processType = 4;
                else if (linkedOver220 > 450 && line200Count2 != 0){
                    processType = 3;
                }
                else if (linearLineResultContentA > 1 && linearLineResultContentB >= 1){
                    if (line220Count2 != 0 && cellDimensionLine <= 3) processType = 3;
                    else processType = 1;
                }
                else if (linearLineResultContentA > 1 && linearLineResultContentB == 0){
                    if (cellDimensionLine > 3) processType = 1;
                    else if (line220Count2 != 0) processType = 3;
                    else processType = 1;
                }
                else if (linearLineResultContentA == 1){
                    if (total220-overlap220 > 100 && overlap220 > total220*0.1){
                        if (line220Count2 != 0) processType = 3;
                        else processType = 1;
                    }
                    else if (cellDimensionLine > 3) processType = 1;
                    else if (cellDimension200 > 3) processType = 1;
                    else if (line200Count2 != 0) processType = 3;
                    else processType = 1;
                }
                else if (cellDimensionLine > 3) processType = 1;
                else if (cellDimension200 > 3) processType = 1;
                else if (line200Count2 != 0) processType = 3;
                else processType = 1;
                
                if (processType == 1){
                    if (line220Count2 != 0){
                        if (total220 > 100){
                            if (total220-overlap220 > 90) processType = 5;
                        }
                        else if (total220 > 50){
                            if (total220-overlap220 > 45) processType = 5;
                        }
                    }
                }
            }
            
            if (linkedOver220/(double)linkedTotalCount >= 0.5 && linkedOver220/(double)linkedTotalCount < 0.7){
                if (linkedOver220 > 450 && line220Count2 != 0) processType = 4;
                else if (linkedOver220 > 450 && line200Count2 != 0) processType = 3;
                else if (linearLineResultContentA > 1 && linearLineResultContentB >= 1){
                    if (line220Count2 != 0 && cellDimensionLine <= 3) processType = 4;
                    else processType = 1;
                }
                else if (linearLineResultContentA > 1 && linearLineResultContentB == 0){
                    if (cellDimensionLine > 3) processType = 1;
                    else if (line220Count2 != 0) processType = 4;
                    else processType = 1;
                }
                else if (linearLineResultContentA == 1){
                    if (total220-overlap220 > 100 && overlap220 > total220*0.1){
                        if (line220Count2 != 0) processType = 4;
                        else processType = 1;
                    }
                    else if (cellDimensionLine > 3) processType = 1;
                    else if (cellDimension200 > 3) processType = 1;
                    else if (line200Count2 != 0) processType = 4;
                    else processType = 1;
                }
                else if (cellDimensionLine > 3) processType = 1;
                else if (cellDimension200 > 3) processType = 1;
                else if (line200Count2 != 0) processType = 4;
                else processType = 1;
                
                if (processType == 1){
                    if (line220Count2 != 0){
                        if (total220 > 100){
                            if (total220-overlap220 > 90) processType = 5;
                        }
                        else if (total220 > 50){
                            if (total220-overlap220 > 45) processType = 5;
                        }
                    }
                }
            }
            
            if (linkedOver220/(double)linkedTotalCount >= 0.7){
                if (cellDimensionLine > 4){
                    if (linearLineResultContentA >= 1){
                        if (line220Count2 != 0) processType = 4;
                        else processType = 1;
                    }
                    else if (total220-overlap220 > 100 && overlap220 > total220*0.1){
                        if (line220Count2 != 0) processType = 4;
                        else processType = 1;
                    }
                    else processType = 1;
                }
                else if (line220Count2 != 0) processType = 4;
                else processType = 1;
                
                if (processType == 1){
                    if (line220Count2 != 0){
                        if (total220 > 100){
                            if (linearLineResultContentA >= 1) processType = 4;
                            else if (total220-overlap220 > 90) processType = 5;
                        }
                        else if (total220 > 50){
                            if (linearLineResultContentA >= 1) processType = 4;
                            else if (total220-overlap220 > 45) processType = 5;
                        }
                    }
                }
            }
        }
        else if (line220Count2 != 0){
            if (total220 > 100){
                if (total220-overlap220 > 90) processType = 5;
            }
            else if (total220 > 50){
                if (total220-overlap220 > 45) processType = 5;
            }
        }
        
        int startEndTemp = 0;
        
        if (processType == 2){
            if (linkedLineCount+line200Count2 > linkedLineLimit){
                int *arraySourceTemp = new int [linkedLineCount+50];
                for (int counter1 = 0; counter1 < linkedLineCount; counter1++) arraySourceTemp [counter1] = arrayLinkedLine [counter1];
                
                delete [] arrayLinkedLine;
                arrayLinkedLine = new int [linkedLineLimit+line200Count2+5000];
                linkedLineLimit = linkedLineLimit+line200Count2+5000;
                
                for (int counter1 = 0; counter1 < linkedLineCount; counter1++) arrayLinkedLine [counter1] = arraySourceTemp [counter1];
                delete [] arraySourceTemp;
            }
            
            for (int counter1 = 0; counter1 < line200Count2/6; counter1++){
                startEndTemp = array200Line2 [counter1*6+4];
                
                if (startEndTemp == 1) startEndTemp = 3;
                if (startEndTemp == 2) startEndTemp = 4;
                
                arrayLinkedLine [linkedLineCount] = array200Line2 [counter1*6+1]+horizontalStart, linkedLineCount++;
                arrayLinkedLine [linkedLineCount] = array200Line2 [counter1*6+2]+verticalStart, linkedLineCount++;
                arrayLinkedLine [linkedLineCount] = array200Line2 [counter1*6+3], linkedLineCount++;
                arrayLinkedLine [linkedLineCount] = array200Line2 [counter1*6+5], linkedLineCount++;
                arrayLinkedLine [linkedLineCount] = startEndTemp, linkedLineCount++;
            }
        }
        
        if (processType == 3){
            if (line200Count2 > linkedLineLimit){
                delete [] arrayLinkedLine;
                arrayLinkedLine = new int [line200Count2+5000], linkedLineLimit = line200Count2+5000;
            }
            
            linkedLineCount = 0;
            
            for (int counter1 = 0; counter1 < line200Count2/6; counter1++){
                startEndTemp = array200Line2 [counter1*6+4];
                
                if (startEndTemp == 1) startEndTemp = 3;
                if (startEndTemp == 2) startEndTemp = 4;
                
                arrayLinkedLine [linkedLineCount] = array200Line2 [counter1*6+1]+horizontalStart, linkedLineCount++;
                arrayLinkedLine [linkedLineCount] = array200Line2 [counter1*6+2]+verticalStart, linkedLineCount++;
                arrayLinkedLine [linkedLineCount] = array200Line2 [counter1*6+3], linkedLineCount++;
                arrayLinkedLine [linkedLineCount] = array200Line2 [counter1*6+5], linkedLineCount++;
                arrayLinkedLine [linkedLineCount] = startEndTemp, linkedLineCount++;
            }
        }
        
        if (processType == 4){
            if (line220Count2 > linkedLineLimit){
                delete [] arrayLinkedLine;
                arrayLinkedLine = new int [line220Count2+5000];
                linkedLineLimit = line220Count2+5000;
            }
            
            linkedLineCount = 0;
            
            for (int counter1 = 0; counter1 < line220Count2/6; counter1++){
                startEndTemp = array220Line2 [counter1*6+4];
                
                if (startEndTemp == 1) startEndTemp = 3;
                if (startEndTemp == 2) startEndTemp = 4;
                
                arrayLinkedLine [linkedLineCount] = array220Line2 [counter1*6+1]+horizontalStart, linkedLineCount++;
                arrayLinkedLine [linkedLineCount] = array220Line2 [counter1*6+2]+verticalStart, linkedLineCount++;
                arrayLinkedLine [linkedLineCount] = array220Line2 [counter1*6+3], linkedLineCount++;
                arrayLinkedLine [linkedLineCount] = array220Line2 [counter1*6+5], linkedLineCount++;
                arrayLinkedLine [linkedLineCount] = startEndTemp, linkedLineCount++;
            }
        }
        
        if (processType == 5){
            if (linkedLineCount+line220Count2 > linkedLineLimit){
                int *arraySourceTemp = new int [linkedLineCount+50];
                for (int counter2 = 0; counter2 < linkedLineCount; counter2++) arraySourceTemp [counter2] = arrayLinkedLine [counter2];
                
                delete [] arrayLinkedLine;
                arrayLinkedLine = new int [linkedLineLimit+line220Count2+5000];
                linkedLineLimit = linkedLineLimit+line220Count2+5000;
                
                for (int counter2 = 0; counter2 < linkedLineCount; counter2++) arrayLinkedLine [counter2] = arraySourceTemp [counter2];
                delete [] arraySourceTemp;
            }
            
            for (int counter1 = 0; counter1 < line220Count2/6; counter1++){
                startEndTemp = array220Line2 [counter1*6+4];
                
                if (startEndTemp == 1) startEndTemp = 3;
                if (startEndTemp == 2) startEndTemp = 4;
                
                arrayLinkedLine [linkedLineCount] = array220Line2 [counter1*6+1]+horizontalStart, linkedLineCount++;
                arrayLinkedLine [linkedLineCount] = array220Line2 [counter1*6+2]+verticalStart, linkedLineCount++;
                arrayLinkedLine [linkedLineCount] = array220Line2 [counter1*6+3], linkedLineCount++;
                arrayLinkedLine [linkedLineCount] = array220Line2 [counter1*6+5], linkedLineCount++;
                arrayLinkedLine [linkedLineCount] = startEndTemp, linkedLineCount++;
            }
        }
        
        delete [] array200Line2;
        delete [] array220Line2;
        delete [] array240Line2;
        
        //------Fill Line 1 and Line 2 marks------
        int startEndFlag = 0;
        
        for (int counter1 = 0; counter1 < linkedLineCount/5; counter1++){
            startEndStatusTemp = arrayLinkedLine [counter1*5+4];
            
            if (startEndStatusTemp == 0 && startEndFlag == 0){
                startEndFlag = 1;
                arrayLinkedLine [counter1*5+3] = 1;
            }
            else if (startEndStatusTemp == 0 && startEndFlag == 1) arrayLinkedLine [counter1*5+3] = 1;
            else if ((startEndStatusTemp == 1 || startEndStatusTemp == 3) && startEndFlag == 1){
                startEndFlag = 2;
                arrayLinkedLine [counter1*5+3] = 1;
            }
            else if (startEndStatusTemp == 0 && startEndFlag == 2){
                startEndFlag = 2;
                arrayLinkedLine [counter1*5+3] = 2;
            }
            else if ((startEndStatusTemp == 2 || startEndStatusTemp == 4) && startEndFlag == 2){
                startEndFlag = 1;
                arrayLinkedLine [counter1*5+3] = 2;
            }
        }
        
        // cout<<processType<<" ProcessType "<<endl;
        
        //==========Outline pattern analysis, For segmentation of two closely located cells==========
        int numberOfContent = 0;
        
        for (int counter1 = 0; counter1 < linkedLineCount/5; counter1++){
            if (arrayLinkedLine [counter1*5+4] == 2 || arrayLinkedLine [counter1*5+4] == 4) numberOfContent++;
        }
        
        int **startEndPosition = new int *[numberOfContent+4];
        
        for (int counter1 = 0; counter1 < numberOfContent+4; counter1++) startEndPosition [counter1] = new int [4];
        
        int startEndCount = 0;
        
        for (int counter1 = 0; counter1 < linkedLineCount/5; counter1++){
            if (arrayLinkedLine [counter1*5+4] == 2 || arrayLinkedLine [counter1*5+4] == 4){
                startEndPosition [startEndCount][1] = counter1;
                
                if (arrayLinkedLine [counter1*5+4] == 2) startEndPosition [startEndCount][2] = 1;
                else startEndPosition [startEndCount][2] = 2;
                
                startEndCount++;
            }
        }
        
        for (int counter1 = 0; counter1 < numberOfContent; counter1++){
            if (counter1 == 0) startEndPosition [counter1][0] = 0;
            else startEndPosition [counter1][0] = startEndPosition [counter1-1][1]+1;
        }
        
        // NSLog(@"%@", [NSThread callStackSymbols]);
        
        int valueTempX3 = 0;
        int valueTempY3 = 0;
        int valueTempXIn = 0;
        int valueTempYIn = 0;
        int valueTempXOut = 0;
        int valueTempYOut = 0;
        int valueIn = 0;
        int valueOut = 0;
        int inFlag = 0;
        int valueTempYInOut = 0;
        int valueTempXInOut = 0;
        int peakCount = 0;
        int longestCount = 0;
        int bottomCount1 = 0;
        int bottomMinPosition1 = 0;
        int bottomMinPosition2 = 0;
        int removeFlag = 0;
        int firstMark = 0;
        int numberOfPeaks = 0;
        int firstPeakNumber = 0;
        int lastPeakNumber = 0;
        int numberOfPeaksCount = 0;
        int peakFront = 0;
        int peakBehind = 0;
        int valueTempXL2 = 0;
        int valueTempYL2 = 0;
        int valueTempXL3 = 0;
        int valueTempYL3 = 0;
        int changePointCount = 0;
        int valueTempXS2 = 0;
        int valueTempYS2 = 0;
        int valueTempXS3 = 0;
        int valueTempYS3 = 0;
        int shortestCount1 = 0;
        int shortestCount2 = 0;
        int countOne = 0;
        int countTwo = 0;
        int positionXYCount = 0;
        int aheadDistanceCount = 0;
        int behindDistanceCount = 0;
        int outsideFlag = 0;
        int valueStart = 0;
        int valueEnd = 0;
        int loopLength1 = 0;
        int loopLength2 = 0;
        int positionA = 0;
        int positionB = 0;
        int checkLengthOut = 0;
        int checkLengthIn = 0;
        int smallLoop = 0;
        int smallLoopLength = 0;
        int loopBulgeFind = 0;
        int incrementPosition = 0;
        int changePointNumber = 0;
        int setIn = 0;
        int setOut = 0;
        int countSet = 0;
        int countPosition = 0;
        int nextFind = 0;
        int minIn = 0;
        int maxIn = 0;
        int minOut = 0;
        int maxOut = 0;
        int inCenter = 0;
        int outCenter = 0;
        int shortest = 0;
        int shortestCountIn = 0;
        int shortestCountOut = 0;
        int valueTempCurrent = 0;
        int valueTempNext = 0;
        int valueTempCurrent2 = 0;
        int valueTempNext2 = 0;
        int valueTempXNext = 0;
        int valueTempYNext = 0;
        int breakFlag = 0;
        int lengthA = 0;
        int lengthB = 0;
        int totalLoopLength = 0;
        int loopLengthA = 0;
        int loopLengthB = 0;
        int loopDirection = 0;
        int inShortestCount = 0;
        int outShortestCount = 0;
        int loopLengthA2 = 0;
        int loopLengthB2 = 0;
        int unCutStatus = 0;
        int numberOfConnectivityGroup = 0;
        int vectorNumberMatchCount = 0;
        int matchCorrespond = 0;
        int eliminationFlag = 0;
        int eliminationFlag2 = 0;
        int eliminationFlag3 = 0;
        int noZeroFlag = 0;
        int cutEnter = 0;
        int vectorNumberMatchEnter = 0;
        int noZeroFind1 = 0;
        int noZeroFind2 = 0;
        int noZeroFind3 = 0;
        int noZeroFind4 = 0;
        int noZeroFind5 = 0;
        int noZeroFind6 = 0;
        int noZeroFind7 = 0;
        int noZeroFind8 = 0;
        int noZeroFind9 = 0;
        int remainingCount = 0;
        int loopLength2A = 0;
        int loopLength2B = 0;
        int loopLength2C = 0;
        int loopLength2D = 0;
        int removeLine = 0;
        int lengthCenterA = 0;
        int lengthCenterB = 0;
        int lowestPosition = 0;
        int lowestCount = 0;
        int lowestOrientation = 0;
        int countTempC = 0;
        int countTempD = 0;
        int countTempCMinusX = 0;
        int countTempCMinusY = 0;
        int countTempDPlusX = 0;
        int countTempDPlusY = 0;
        int countTempCPlusX = 0;
        int countTempCPlusY = 0;
        int countTempDMinusX = 0;
        int countTempDMinusY = 0;
        int lineLengthLimit = 0;
        int changePointCount9A = 0;
        int changePointCount9B = 0;
        int breakFlagA = 0;
        int breakFlagB = 0;
        int checkOverlap = 0;
        
        double constAd = 0;
        double constBd = 0;
        double longestPoint = 0;
        double bottomPoint1 = 0;
        double bottomPoint2 = 0;
        double bottomMin1 = 0;
        double bottomMin2 = 0;
        double shortest1 = 0;
        double shortest2 = 0;
        double lineOneDistanceTemp = 0;
        double selectedPointDistance = 0;
        double distanceTemp1 = 0;
        double cutOff = 0;
        double constA3 = 0;
        double constA4 = 0;
        double differenceConst = 0;
        double distanceTemp2 = 0;
        double inShortest = 0;
        double outShortest = 0;
        double constA = 0;
        double constB = 0;
        
        for (int counter1 = 0; counter1 < numberOfContent; counter1++){
            int *arrayLinkedLineOneTemp = new int [linkedLineCount+500], linkedLineOneTempCount = 0;
            int *arrayLinkedLineTwoTemp = new int [linkedLineCount+500], linkedLineTwoTempCount = 0;
            int *arrayLinkedLineSource = new int [linkedLineCount+500], linkedLineSourceCount = 0;
            
            //++++++++++Approach 1, draw linear line, determine cross points, division points+++++++++++
            
            int *valueStartEnd = new int [4];
            valueStartEnd [0] = -1; //valueStartTempX
            valueStartEnd [1] = -1; //valueStartTempY
            valueStartEnd [2] = -1; //valueEndTempX
            valueStartEnd [3] = -1; //valueEndTempY
            
            //------Set Line One, Line Two and Full length------
            for (int counter2 = startEndPosition [counter1][0]; counter2 <= startEndPosition [counter1][1]; counter2++){
                arrayLinkedLineSource [linkedLineSourceCount] = arrayLinkedLine [counter2*5], linkedLineSourceCount++;
                arrayLinkedLineSource [linkedLineSourceCount] = arrayLinkedLine [counter2*5+1], linkedLineSourceCount++;
                arrayLinkedLineSource [linkedLineSourceCount] = arrayLinkedLine [counter2*5+2], linkedLineSourceCount++;
                
                if (arrayLinkedLine [counter2*5+3] == 1){
                    arrayLinkedLineOneTemp [linkedLineOneTempCount] = arrayLinkedLine [counter2*5], linkedLineOneTempCount++;
                    arrayLinkedLineOneTemp [linkedLineOneTempCount] = arrayLinkedLine [counter2*5+1], linkedLineOneTempCount++;
                    arrayLinkedLineOneTemp [linkedLineOneTempCount] = arrayLinkedLine [counter2*5+2], linkedLineOneTempCount++;
                    valueStartEnd [2] = arrayLinkedLine [counter2*5]-horizontalStart;
                    valueStartEnd [3] = arrayLinkedLine [counter2*5+1]-verticalStart;
                    
                    if (valueStartEnd [2] < 0) valueStartEnd [2] = 0;
                    else if (valueStartEnd [2] >= dimension) valueStartEnd [2] = dimension-1;
                    
                    if (valueStartEnd [3] < 0) valueStartEnd [3] = 0;
                    else if (valueStartEnd [3] >= dimension) valueStartEnd [3] = dimension-1;
                }
                
                if (arrayLinkedLine [counter2*5+3] == 2){
                    arrayLinkedLineTwoTemp [linkedLineTwoTempCount] = arrayLinkedLine [counter2*5], linkedLineTwoTempCount++;
                    arrayLinkedLineTwoTemp [linkedLineTwoTempCount] = arrayLinkedLine [counter2*5+1], linkedLineTwoTempCount++;
                    arrayLinkedLineTwoTemp [linkedLineTwoTempCount] = arrayLinkedLine [counter2*5+2], linkedLineTwoTempCount++;
                    valueStartEnd [0] = arrayLinkedLine [counter2*5]-horizontalStart;
                    valueStartEnd [1] = arrayLinkedLine [counter2*5+1]-verticalStart;
                    
                    if (valueStartEnd [0] < 0) valueStartEnd [0] = 0;
                    else if (valueStartEnd [0] >= dimension) valueStartEnd [0] = dimension-1;
                    
                    if (valueStartEnd [1] < 0) valueStartEnd [1] = 0;
                    else if (valueStartEnd [1] >= dimension) valueStartEnd [1] = dimension-1;
                }
            }
            
            //------Determine Line Formula, which pass start and End of Line One and Two------
            if (valueStartEnd [0]-valueStartEnd [2] != 0) constA = (valueStartEnd [1]-valueStartEnd [3])/(double)(valueStartEnd [0]-valueStartEnd [2]);
            else constA = 0;
            
            constB = valueStartEnd [1]-valueStartEnd [0]*constA;
            
            int **combinedMatrixA2 = new int *[dimension+4];
            
            for (int counter2 = 0; counter2 < dimension+4; counter2++) combinedMatrixA2 [counter2] = new int [dimension+4];
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++) combinedMatrixA2 [counterY][counterX] = 0;
            }
            
            for (int counter2 = startEndPosition [counter1][0]; counter2 <= startEndPosition [counter1][1]; counter2++){
                int *valueTempXYL = new int [2];
                valueTempXYL [0] = arrayLinkedLine [counter2*5]-horizontalStart;
                valueTempXYL [1] = arrayLinkedLine [counter2*5+1]-verticalStart;
                
                if (valueTempXYL [0] < 0) valueTempXYL [0] = 0;
                else if (valueTempXYL [0] >= dimension) valueTempXYL [0] = dimension-1;
                
                if (valueTempXYL [1] < 0) valueTempXYL [1] = 0;
                else if (valueTempXYL [1] >= dimension) valueTempXYL [1] = dimension-1;
                
                combinedMatrixA2 [valueTempXYL [1]][valueTempXYL [0]] = 1;
                
                delete [] valueTempXYL;
            }
            
            //------Connectivity analysis, Zero------
            int *connectAnalysisX = new int [dimension*4];
            int *connectAnalysisY = new int [dimension*4];
            int *connectAnalysisTempX = new int [dimension*4];
            int *connectAnalysisTempY = new int [dimension*4];
            
            connectivityNumber = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (combinedMatrixA2 [counterY][counterX] == 0){
                        connectivityNumber++;
                        combinedMatrixA2 [counterY][counterX] = connectivityNumber;
                        
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && combinedMatrixA2 [counterY-1][counterX] == 0){
                            combinedMatrixA2 [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension && combinedMatrixA2 [counterY][counterX+1] == 0){
                            combinedMatrixA2 [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && combinedMatrixA2 [counterY+1][counterX] == 0){
                            combinedMatrixA2 [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && combinedMatrixA2 [counterY][counterX-1] == 0){
                            combinedMatrixA2 [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                    xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                    
                                    if (ySource-1 >= 0 && combinedMatrixA2 [ySource-1][xSource] == 0){
                                        combinedMatrixA2 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && combinedMatrixA2 [ySource][xSource+1] == 0){
                                        combinedMatrixA2 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && combinedMatrixA2 [ySource+1][xSource] == 0){
                                        combinedMatrixA2 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && combinedMatrixA2 [ySource][xSource-1] == 0){
                                        combinedMatrixA2 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                    connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            delete [] connectAnalysisX;
            delete [] connectAnalysisY;
            delete [] connectAnalysisTempX;
            delete [] connectAnalysisTempY;
            
            //------Remove pixels, which attach edge------
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (combinedMatrixA2 [counterY][counterX] == 1) combinedMatrixA2 [counterY][counterX] = 0;
                }
            }
            
            //------Change all numbers to 1------
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (combinedMatrixA2 [counterY][counterX] != 0) combinedMatrixA2 [counterY][counterX] = 1;
                }
            }
            
            //------Add outline, 2------
            for (int counter2 = startEndPosition [counter1][0]; counter2 <= startEndPosition [counter1][1]; counter2++){
                int *valueTempXYL = new int [2];
                valueTempXYL [0] = arrayLinkedLine [counter2*5]-horizontalStart;
                valueTempXYL [1] = arrayLinkedLine [counter2*5+1]-verticalStart;
                
                if (valueTempXYL [0] < 0) valueTempXYL [0] = 0;
                else if (valueTempXYL [0] >= dimension) valueTempXYL [0] = dimension-1;
                
                if (valueTempXYL [1] < 0) valueTempXYL [1] = 0;
                else if (valueTempXYL [1] >= dimension) valueTempXYL [1] = dimension-1;
                
                combinedMatrixA2 [valueTempXYL [1]][valueTempXYL [0]] = 2;
                
                delete [] valueTempXYL;
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<combinedMatrixA2 [counterA][counterB];
            //	cout<<" combinedMatrixA2 "<<counterA<<endl;
            //}
            
            //------Determine Vertical Cross line and enter XY points, which cross 2 (IN and OUT points)------
            int *arrayInOutData = new int [dimension*dimension*5], inOutDataCount = 0;
            
            if (valueStartEnd [1]-valueStartEnd [3] == 0){
                for (int counter2 = 0; counter2 < dimension; counter2++){
                    valueTempX3 = counter2;
                    valueTempXIn = -1;
                    valueTempYIn = -1;
                    valueIn = -1;
                    valueTempXOut = -1;
                    valueTempYOut = -1;
                    valueOut = -1;
                    inFlag = 0;
                    
                    for (int counter3 = 0; counter3 < dimension; counter3++){
                        if ((combinedMatrixA2 [counter3][valueTempX3] == 1 || combinedMatrixA2 [counter3][valueTempX3] == 2) && inFlag == 0){
                            valueTempXIn = valueTempX3;
                            valueTempYIn = counter3;
                            valueIn = combinedMatrixA2 [counter3][valueTempX3];
                            inFlag = 1;
                        }
                        
                        if (combinedMatrixA2 [counter3][valueTempX3] == 1 || combinedMatrixA2 [counter3][valueTempX3] == 2){
                            valueTempXOut = valueTempX3;
                            valueTempYOut = counter3;
                            valueOut = combinedMatrixA2 [counter3][valueTempX3];
                        }
                    }
                    
                    //------In the event that line is IN or OUT at "1", find nearest "2"------
                    if (valueIn == 1){
                        for (int counter3 = 0; counter3 < linkedLineOneTempCount/3; counter3++){
                            int *valueTempXYL = new int [2];
                            valueTempXYL [0] = arrayLinkedLineOneTemp [counter3*3]-horizontalStart;
                            valueTempXYL [1] = arrayLinkedLineOneTemp [counter3*3+1]-verticalStart;
                            
                            
                            if (valueTempXYL [0] < 0) valueTempXYL [0] = 0;
                            else if ( valueTempXYL [0] >= dimension) valueTempXYL [0] = dimension-1;
                            
                            if (valueTempXYL [1] < 0) valueTempXYL [1] = 0;
                            else if (valueTempXYL [1] >= dimension) valueTempXYL [1] = dimension-1;
                            
                            if (valueTempXIn-1 == valueTempXYL [0] && valueTempYIn-1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn-1;
                                valueTempYIn = valueTempYIn-1;
                                break;
                            }
                            
                            if (valueTempXIn == valueTempXYL [0] && valueTempYIn-1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn;
                                valueTempYIn = valueTempYIn-1;
                                break;
                            }
                            
                            if (valueTempXIn+1 == valueTempXYL [0] && valueTempYIn-1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn+1;
                                valueTempYIn = valueTempYIn-1;
                                break;
                            }
                            
                            if (valueTempXIn+1 == valueTempXYL [0] && valueTempYIn == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn+1;
                                valueTempYIn = valueTempYIn;
                                break;
                            }
                            
                            if (valueTempXIn+1 == valueTempXYL [0] && valueTempYIn+1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn+1;
                                valueTempYIn = valueTempYIn+1;
                                break;
                            }
                            
                            if (valueTempXIn == valueTempXYL [0] && valueTempYIn+1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn;
                                valueTempYIn = valueTempYIn+1;
                                break;
                            }
                            
                            if (valueTempXIn+1 == valueTempXYL [0] && valueTempYIn+1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn+1;
                                valueTempYIn = valueTempYIn+1;
                                break;
                            }
                            
                            if (valueTempXIn-1 == valueTempXYL [0] && valueTempYIn == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn-1;
                                valueTempYIn = valueTempYIn;
                                break;
                            }
                            
                            delete [] valueTempXYL;
                        }
                    }
                    
                    if (valueOut == 1){
                        for (int counter3 = 0; counter3 < linkedLineTwoTempCount/3; counter3++){
                            int *valueTempXYL = new int [2];
                            valueTempXYL [0] = arrayLinkedLineTwoTemp [counter3*3]-horizontalStart;
                            valueTempXYL [1] = arrayLinkedLineTwoTemp [counter3*3+1]-verticalStart;
                            
                            if (valueTempXYL [0] < 0) valueTempXYL [0] = 0;
                            else if (valueTempXYL [0] >= dimension) valueTempXYL [0] = dimension-1;
                            
                            if (valueTempXYL [1] < 0) valueTempXYL [1] = 0;
                            else if (valueTempXYL [1] >= dimension) valueTempXYL [1] = dimension-1;
                            
                            if (valueTempXOut-1 == valueTempXYL [0] && valueTempYOut == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut-1;
                                valueTempYOut = valueTempYOut;
                                break;
                            }
                            
                            if (valueTempXOut+1 == valueTempXYL [0] && valueTempYOut+1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut+1;
                                valueTempYOut = valueTempYOut+1;
                                break;
                            }
                            
                            if (valueTempXOut == valueTempXYL [0] && valueTempYOut+1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut;
                                valueTempYOut = valueTempYOut+1;
                                break;
                            }
                            
                            if (valueTempXOut+1 == valueTempXYL [0] && valueTempYOut+1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut+1;
                                valueTempYOut = valueTempYOut+1;
                                break;
                            }
                            
                            if (valueTempXOut+1 == valueTempXYL [0] && valueTempYOut == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut+1;
                                valueTempYOut = valueTempYOut;
                                break;
                            }
                            
                            if (valueTempXOut+1 == valueTempXYL [0] && valueTempYOut-1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut+1;
                                valueTempYOut = valueTempYOut-1;
                                break;
                            }
                            
                            if (valueTempXOut == valueTempXYL [0] && valueTempYOut-1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut;
                                valueTempYOut = valueTempYOut-1;
                                break;
                            }
                            
                            if (valueTempXOut-1 == valueTempXYL [0] && valueTempYOut-1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut-1;
                                valueTempYOut = valueTempYOut-1;
                                break;
                            }
                            
                            delete [] valueTempXYL;
                        }
                    }
                    
                    if (valueTempXIn != -1 && valueTempXOut != -1){
                        arrayInOutData [inOutDataCount] = valueTempXIn, inOutDataCount++;
                        arrayInOutData [inOutDataCount] = valueTempYIn, inOutDataCount++;
                        arrayInOutData [inOutDataCount] = valueTempXOut, inOutDataCount++;
                        arrayInOutData [inOutDataCount] = valueTempYOut, inOutDataCount++;
                        arrayInOutData [inOutDataCount] = 0, inOutDataCount++;
                    }
                }
            }
            
            if (constA != 0 && (constA > 1 || constA < -1)){
                for (int counter2 = 0; counter2 < dimension; counter2++){
                    valueTempY3 = counter2;
                    valueTempX3 = (int)((valueTempY3-constB)/(double)constA);
                    constAd = 1/(double)constA*-1;
                    constBd = valueTempY3-constAd*valueTempX3;
                    valueTempXIn = -1;
                    valueTempYIn = -1;
                    valueIn = -1;
                    valueTempXOut = -1;
                    valueTempYOut = -1;
                    valueOut = -1;
                    inFlag = 0;
                    
                    for (int counter3 = 0; counter3 < dimension; counter3++){
                        valueTempYInOut = (int)(constAd*counter3+constBd);
                        
                        if (valueTempYInOut >= 0 && valueTempYInOut < dimension && counter3 >= 0 && counter3 < dimension){
                            if ((combinedMatrixA2 [valueTempYInOut][counter3] == 1 || combinedMatrixA2 [valueTempYInOut][counter3] == 2) && inFlag == 0){
                                valueTempXIn = counter3;
                                valueTempYIn = valueTempYInOut;
                                valueIn = combinedMatrixA2 [valueTempYInOut][counter3];
                                inFlag = 1;
                            }
                            
                            if (combinedMatrixA2 [valueTempYInOut][counter3] == 1 || combinedMatrixA2 [valueTempYInOut][counter3] == 2){
                                valueTempXOut = counter3;
                                valueTempYOut = valueTempYInOut;
                                valueOut = combinedMatrixA2 [valueTempYInOut][counter3];
                            }
                        }
                    }
                    
                    if (valueIn == 1){
                        for (int counter3 = 0; counter3 < linkedLineOneTempCount/3; counter3++){
                            int *valueTempXYL = new int [2];
                            valueTempXYL [0] = arrayLinkedLineOneTemp [counter3*3]-horizontalStart;
                            valueTempXYL [1] = arrayLinkedLineOneTemp [counter3*3]-horizontalStart;
                            
                            if (valueTempXYL [0] < 0) valueTempXYL [0] = 0;
                            else if (valueTempXYL [0] >= dimension) valueTempXYL [0] = dimension-1;
                            
                            if (valueTempXYL [1] < 0) valueTempXYL [1] = 0;
                            else if (valueTempXYL [1] >= dimension) valueTempXYL [1] = dimension-1;
                            
                            if (valueTempXIn-1 == valueTempXYL [0] && valueTempYIn-1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn-1;
                                valueTempYIn = valueTempYIn-1;
                                break;
                            }
                            
                            if (valueTempXIn == valueTempXYL [0] && valueTempYIn-1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn;
                                valueTempYIn = valueTempYIn-1;
                                break;
                            }
                            
                            if (valueTempXIn+1 == valueTempXYL [0] && valueTempYIn-1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn+1;
                                valueTempYIn = valueTempYIn-1;
                                break;
                            }
                            
                            if (valueTempXIn+1 == valueTempXYL [0] && valueTempYIn == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn+1;
                                valueTempYIn = valueTempYIn;
                                break;
                            }
                            
                            if (valueTempXIn+1 == valueTempXYL [0] && valueTempYIn+1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn+1;
                                valueTempYIn = valueTempYIn+1;
                                break;
                            }
                            
                            if (valueTempXIn == valueTempXYL [0] && valueTempYIn+1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn;
                                valueTempYIn = valueTempYIn+1;
                                break;
                            }
                            
                            if (valueTempXIn+1 == valueTempXYL [0] && valueTempYIn+1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn+1;
                                valueTempYIn = valueTempYIn+1;
                                break;
                            }
                            
                            if (valueTempXIn-1 == valueTempXYL [0] && valueTempYIn == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn-1;
                                valueTempYIn = valueTempYIn;
                                break;
                            }
                            
                            delete [] valueTempXYL;
                        }
                    }
                    if (valueOut == 1){
                        for (int counter3 = 0; counter3 < linkedLineTwoTempCount/3; counter3++){
                            int *valueTempXYL = new int [2];
                            valueTempXYL [0] = arrayLinkedLineTwoTemp [counter3*3]-horizontalStart;
                            valueTempXYL [1] = arrayLinkedLineTwoTemp [counter3*3+1]-verticalStart;
                            
                            if (valueTempXYL [0] < 0) valueTempXYL [0] = 0;
                            else if (valueTempXYL [0] >= dimension) valueTempXYL [0] = dimension-1;
                            
                            if (valueTempXYL [1] < 0) valueTempXYL [1] = 0;
                            else if (valueTempXYL [1] >= dimension) valueTempXYL [1] = dimension-1;
                            
                            if (valueTempXOut-1 == valueTempXYL [0] && valueTempYOut == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut-1;
                                valueTempYOut = valueTempYOut;
                                break;
                            }
                            
                            if (valueTempXOut+1 == valueTempXYL [0] && valueTempYOut+1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut+1;
                                valueTempYOut = valueTempYOut+1;
                                break;
                            }
                            
                            if (valueTempXOut == valueTempXYL [0] && valueTempYOut+1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut;
                                valueTempYOut = valueTempYOut+1;
                                break;
                            }
                            
                            if (valueTempXOut+1 == valueTempXYL [0] && valueTempYOut+1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut+1;
                                valueTempYOut = valueTempYOut+1;
                                break;
                            }
                            
                            if (valueTempXOut+1 == valueTempXYL [0] && valueTempYOut == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut+1;
                                valueTempYOut = valueTempYOut;
                                break;
                            }
                            
                            if (valueTempXOut+1 == valueTempXYL [0] && valueTempYOut-1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut+1;
                                valueTempYOut = valueTempYOut-1;
                                break;
                            }
                            
                            if (valueTempXOut == valueTempXYL [0] && valueTempYOut-1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut;
                                valueTempYOut = valueTempYOut-1;
                                break;
                            }
                            
                            if (valueTempXOut-1 == arrayLinkedLineTwoTemp [counter3*3+1]-verticalStart && valueTempYOut-1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut-1;
                                valueTempYOut = valueTempYOut-1;
                                break;
                            }
                            
                            delete [] valueTempXYL;
                        }
                    }
                    if (valueTempXIn != -1 && valueTempXOut != -1){
                        arrayInOutData [inOutDataCount] = valueTempXIn, inOutDataCount++;
                        arrayInOutData [inOutDataCount] = valueTempYIn, inOutDataCount++;
                        arrayInOutData [inOutDataCount] = valueTempXOut, inOutDataCount++;
                        arrayInOutData [inOutDataCount] = valueTempYOut, inOutDataCount++;
                        arrayInOutData [inOutDataCount] = 0, inOutDataCount++;
                    }
                }
            }
            if (valueStartEnd [0]-valueStartEnd [2] == 0){
                for (int counter2 = 0; counter2 < dimension; counter2++){
                    valueTempY3 = counter2;
                    valueTempXIn = -1;
                    valueTempYIn = -1;
                    valueIn = -1;
                    valueTempXOut = -1;
                    valueTempYOut = -1;
                    valueOut = -1;
                    inFlag = 0;
                    
                    for (int counter3 = 0; counter3 < dimension; counter3++){
                        if ((combinedMatrixA2 [valueTempY3][counter3] == 1 || combinedMatrixA2 [valueTempY3][counter3] == 2) && inFlag == 0){
                            valueTempXIn = counter3;
                            valueTempYIn = valueTempY3;
                            valueIn = combinedMatrixA2 [valueTempY3][counter3];
                            inFlag = 1;
                        }
                        
                        if (combinedMatrixA2 [valueTempY3][counter3] == 1 || combinedMatrixA2 [valueTempY3][counter3] == 2){
                            valueTempXOut = counter3;
                            valueTempYOut = valueTempY3;
                            valueOut = combinedMatrixA2 [valueTempY3][counter3];
                        }
                    }
                    
                    if (valueIn == 1){
                        for (int counter3 = 0; counter3 < linkedLineOneTempCount/3; counter3++){
                            int *valueTempXYL = new int [2];
                            valueTempXYL [0] = arrayLinkedLineOneTemp [counter3*3]-horizontalStart;
                            valueTempXYL [1] = arrayLinkedLineOneTemp [counter3*3+1]-verticalStart;
                            
                            if (valueTempXYL [0] < 0) valueTempXYL [0] = 0;
                            else if (valueTempXYL [0] >= dimension) valueTempXYL [0] = dimension-1;
                            
                            if (valueTempXYL [1] < 0) valueTempXYL [1] = 0;
                            else if (valueTempXYL [1] >= dimension) valueTempXYL [1] = dimension-1;
                            
                            if (valueTempXIn-1 == valueTempXYL [0] && valueTempYIn-1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn-1;
                                valueTempYIn = valueTempYIn-1;
                                break;
                            }
                            
                            if (valueTempXIn == valueTempXYL [0] && valueTempYIn-1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn;
                                valueTempYIn = valueTempYIn-1;
                                break;
                            }
                            
                            if (valueTempXIn+1 == valueTempXYL [0] && valueTempYIn-1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn+1;
                                valueTempYIn = valueTempYIn-1;
                                break;
                            }
                            
                            if (valueTempXIn+1 == valueTempXYL [0] && valueTempYIn == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn+1;
                                valueTempYIn = valueTempYIn;
                                break;
                            }
                            
                            if (valueTempXIn+1 == valueTempXYL [0] && valueTempYIn+1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn+1;
                                valueTempYIn = valueTempYIn+1;
                                break;
                            }
                            
                            if (valueTempXIn == valueTempXYL [0] && valueTempYIn+1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn;
                                valueTempYIn = valueTempYIn+1;
                                break;
                            }
                            
                            if (valueTempXIn+1 == valueTempXYL [0] && valueTempYIn+1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn+1;
                                valueTempYIn = valueTempYIn+1;
                                break;
                            }
                            
                            if (valueTempXIn-1 == arrayLinkedLineOneTemp [counter3*3+1]-verticalStart && valueTempYIn == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn-1;
                                valueTempYIn = valueTempYIn;
                                break;
                            }
                            
                            delete [] valueTempXYL;
                        }
                    }
                    
                    if (valueOut == 1){
                        for (int counter3 = 0; counter3 < linkedLineTwoTempCount/3; counter3++){
                            int *valueTempXYL = new int [2];
                            valueTempXYL [0] = arrayLinkedLineTwoTemp [counter3*3]-horizontalStart;
                            valueTempXYL [1] = arrayLinkedLineTwoTemp [counter3*3+1]-verticalStart;
                            
                            if (valueTempXYL [0] < 0) valueTempXYL [0] = 0;
                            else if (valueTempXYL [0] >= dimension) valueTempXYL [0] = dimension-1;
                            
                            if (valueTempXYL [1] < 0) valueTempXYL [1] = 0;
                            else if (valueTempXYL [1] >= dimension) valueTempXYL [1] = dimension-1;
                            
                            if (valueTempXOut-1 == valueTempXYL [0] && valueTempYOut == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut-1;
                                valueTempYOut = valueTempYOut;
                                break;
                            }
                            
                            if (valueTempXOut+1 == valueTempXYL [0] && valueTempYOut+1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut+1;
                                valueTempYOut = valueTempYOut+1;
                                break;
                            }
                            
                            if (valueTempXOut == valueTempXYL [0] && valueTempYOut+1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut;
                                valueTempYOut = valueTempYOut+1;
                                break;
                            }
                            
                            if (valueTempXOut+1 == valueTempXYL [0] && valueTempYOut+1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut+1;
                                valueTempYOut = valueTempYOut+1;
                                break;
                            }
                            
                            if (valueTempXOut+1 == valueTempXYL [0] && valueTempYOut == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut+1;
                                valueTempYOut = valueTempYOut;
                                break;
                            }
                            
                            if (valueTempXOut+1 == valueTempXYL [0] && valueTempYOut-1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut+1;
                                valueTempYOut = valueTempYOut-1;
                                break;
                            }
                            
                            if (valueTempXOut == valueTempXYL [0] && valueTempYOut-1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut;
                                valueTempYOut = valueTempYOut-1;
                                break;
                            }
                            
                            if (valueTempXOut-1 == valueTempXYL [0] && valueTempYOut-1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut-1;
                                valueTempYOut = valueTempYOut-1;
                                break;
                            }
                            
                            delete [] valueTempXYL;
                        }
                    }
                    
                    if (valueTempXIn != -1 && valueTempXOut != -1){
                        arrayInOutData [inOutDataCount] = valueTempXIn, inOutDataCount++;
                        arrayInOutData [inOutDataCount] = valueTempYIn, inOutDataCount++;
                        arrayInOutData [inOutDataCount] = valueTempXOut, inOutDataCount++;
                        arrayInOutData [inOutDataCount] = valueTempYOut, inOutDataCount++;
                        arrayInOutData [inOutDataCount] = 0, inOutDataCount++;
                    }
                }
            }
            if (constA != 0 && constA <= 1 && constA >= -1){
                for (int counter2 = 0; counter2 < dimension; counter2++){
                    valueTempX3 = counter2;
                    valueTempY3 = (int)(constA*valueTempX3+constB);
                    constAd = 1/(double)constA*-1;
                    constBd = valueTempY3-constAd*valueTempX3;
                    valueTempXIn = -1;
                    valueTempYIn = -1;
                    valueIn = -1;
                    valueTempXOut = -1;
                    valueTempYOut = -1;
                    valueOut = -1;
                    inFlag = 0;
                    
                    for (int counter3 = 0; counter3 < dimension; counter3++){
                        valueTempXInOut = (int)((counter3-constBd)/(double)constAd);
                        
                        if (counter3 >= 0 && counter3 < dimension && valueTempXInOut >= 0 && valueTempXInOut < dimension){
                            if ((combinedMatrixA2 [counter3][valueTempXInOut] == 1 || combinedMatrixA2 [counter3][valueTempXInOut] == 2) && inFlag == 0){
                                valueTempXIn = valueTempXInOut;
                                valueTempYIn = counter3;
                                valueIn = combinedMatrixA2 [counter3][valueTempXInOut];
                                inFlag = 1;
                            }
                            
                            if (combinedMatrixA2 [counter3][valueTempXInOut] == 1 || combinedMatrixA2 [counter3][valueTempXInOut] == 2){
                                valueTempXOut = valueTempXInOut;
                                valueTempYOut = counter3;
                                valueOut = combinedMatrixA2 [counter3][valueTempXInOut];
                            }
                        }
                    }
                    
                    if (valueIn == 1){
                        for (int counter3 = 0; counter3 < linkedLineOneTempCount/3; counter3++){
                            int *valueTempXYL = new int [2];
                            valueTempXYL [0] = arrayLinkedLineOneTemp [counter3*3]-horizontalStart;
                            valueTempXYL [1] = arrayLinkedLineOneTemp [counter3*3+1]-verticalStart;
                            
                            if (valueTempXYL [0] < 0) valueTempXYL [0] = 0;
                            else if (valueTempXYL [0] >= dimension) valueTempXYL [0] = dimension-1;
                            
                            if (valueTempXYL [1] < 0) valueTempXYL [1] = 0;
                            else if (valueTempXYL [1] >= dimension) valueTempXYL [1] = dimension-1;
                            
                            if (valueTempXIn-1 == valueTempXYL [0] && valueTempYIn-1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn-1;
                                valueTempYIn = valueTempYIn-1;
                                break;
                            }
                            
                            if (valueTempXIn == valueTempXYL [0] && valueTempYIn-1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn;
                                valueTempYIn = valueTempYIn-1;
                                break;
                            }
                            
                            if (valueTempXIn+1 == valueTempXYL [0] && valueTempYIn-1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn+1;
                                valueTempYIn = valueTempYIn-1;
                                break;
                            }
                            
                            if (valueTempXIn+1 == valueTempXYL [0] && valueTempYIn == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn+1;
                                valueTempYIn = valueTempYIn;
                                break;
                            }
                            
                            if (valueTempXIn+1 == valueTempXYL [0] && valueTempYIn+1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn+1;
                                valueTempYIn = valueTempYIn+1;
                                break;
                            }
                            
                            if (valueTempXIn == valueTempXYL [0] && valueTempYIn+1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn;
                                valueTempYIn = valueTempYIn+1;
                                break;
                            }
                            
                            if (valueTempXIn+1 == valueTempXYL [0] && valueTempYIn+1 == valueTempXYL [1]){
                                valueTempXIn = valueTempXIn+1;
                                valueTempYIn = valueTempYIn+1;
                                break;
                            }
                            
                            if (valueTempXIn-1 == valueTempXYL [0] && valueTempYIn == valueTempXYL [0]){
                                valueTempXIn = valueTempXIn-1;
                                valueTempYIn = valueTempYIn;
                                break;
                            }
                            
                            delete [] valueTempXYL;
                        }
                    }
                    
                    if (valueOut == 1){
                        for (int counter3 = 0; counter3 < linkedLineTwoTempCount/3; counter3++){
                            int *valueTempXYL = new int [2];
                            valueTempXYL [0] = arrayLinkedLineTwoTemp [counter3*3]-horizontalStart;
                            valueTempXYL [1] = arrayLinkedLineTwoTemp [counter3*3+1]-verticalStart;
                            
                            if (valueTempXYL [0] < 0) valueTempXYL [0] = 0;
                            else if (valueTempXYL [0] >= dimension) valueTempXYL [0] = dimension-1;
                            
                            if (valueTempXYL [1] < 0) valueTempXYL [1] = 0;
                            else if (valueTempXYL [1] >= dimension) valueTempXYL [1] = dimension-1;
                            
                            if (valueTempXOut-1 == valueTempXYL [0] && valueTempYOut == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut-1;
                                valueTempYOut = valueTempYOut;
                                break;
                            }
                            
                            if (valueTempXOut+1 == valueTempXYL [0] && valueTempYOut+1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut+1;
                                valueTempYOut = valueTempYOut+1;
                                break;
                            }
                            
                            if (valueTempXOut == valueTempXYL [0] && valueTempYOut+1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut;
                                valueTempYOut = valueTempYOut+1;
                                break;
                            }
                            
                            if (valueTempXOut+1 == valueTempXYL [0] && valueTempYOut+1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut+1;
                                valueTempYOut = valueTempYOut+1;
                                break;
                            }
                            
                            if (valueTempXOut+1 == valueTempXYL [0] && valueTempYOut == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut+1;
                                valueTempYOut = valueTempYOut;
                                break;
                            }
                            
                            if (valueTempXOut+1 == valueTempXYL [0] && valueTempYOut-1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut+1;
                                valueTempYOut = valueTempYOut-1;
                                break;
                            }
                            
                            if (valueTempXOut == valueTempXYL [0] && valueTempYOut-1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut;
                                valueTempYOut = valueTempYOut-1;
                                break;
                            }
                            
                            if (valueTempXOut-1 == valueTempXYL [0] && valueTempYOut-1 == valueTempXYL [1]){
                                valueTempXOut = valueTempXOut-1;
                                valueTempYOut = valueTempYOut-1;
                                break;
                            }
                            
                            delete [] valueTempXYL;
                        }
                    }
                    
                    if (valueTempXIn != -1 && valueTempXOut != -1){
                        arrayInOutData [inOutDataCount] = valueTempXIn, inOutDataCount++;
                        arrayInOutData [inOutDataCount] = valueTempYIn, inOutDataCount++;
                        arrayInOutData [inOutDataCount] = valueTempXOut, inOutDataCount++;
                        arrayInOutData [inOutDataCount] = valueTempYOut, inOutDataCount++;
                        arrayInOutData [inOutDataCount] = 0, inOutDataCount++;
                    }
                }
            }
            
            delete [] valueStartEnd;
            
            //------Determine distance between In and Out points------
            double *distanceCal = new double [inOutDataCount/5+5];
            int *changePoint = new int [inOutDataCount/5+5];
            
            for (int counter2 = 0; counter2 < inOutDataCount/5; counter2++){
                distanceCal [counter2] = 0;
                changePoint [counter2] = 0;
            }
            
            for (int counter2 = 0; counter2 < inOutDataCount/5; counter2++){
                distanceCal [counter2] = sqrt((arrayInOutData [counter2*5]-arrayInOutData [counter2*5+2])*(arrayInOutData [counter2*5]-arrayInOutData [counter2*5+2])+(arrayInOutData [counter2*5+1]-arrayInOutData [counter2*5+3])*(arrayInOutData [counter2*5+1]-arrayInOutData [counter2*5+3]));
            }
            
            //------If linear line points, Line One, Line Two are less than 10 in length, Go to save data, else check dividing points------
            if (inOutDataCount/5 > 10 && linkedLineOneTempCount/3 > 10 && linkedLineTwoTempCount/3 > 10){ //------Set Peak, Limit Front and Behind------
                double *distanceCal2 = new double [inOutDataCount/5+4];
                
                for (int counter2 = 0; counter2 < inOutDataCount/5; counter2++) distanceCal2 [counter2] = distanceCal [counter2];
                
                peakCount = 0;
                
                do{
                    
                    terminationFlag = 1;
                    longestPoint = -1;
                    longestCount = -1;
                    
                    for (int counter2 = 0; counter2 < inOutDataCount/5; counter2++){
                        if (longestPoint < distanceCal2 [counter2] && distanceCal2 [counter2] != -1){
                            longestPoint = distanceCal2 [counter2];
                            longestCount = counter2;
                        }
                    }
                    
                    if (longestCount != -1){
                        if (longestCount == inOutDataCount/5-1) distanceCal2 [inOutDataCount/5-1] = -1;
                        else{
                            
                            if (longestCount == 0) distanceCal2 [0] = -1;
                            else{
                                
                                peakCount++;
                                bottomPoint1 = longestPoint;
                                bottomPoint2 = longestPoint;
                                bottomCount1 = -1;
                                distanceCal2 [longestCount] = -1;
                                changePoint [longestCount] = peakCount*10;
                                bottomMin1 = -1;
                                bottomMinPosition1 = -1;
                                bottomMin2 = -1;
                                bottomMinPosition2 = -1;
                                removeFlag = 0;
                                firstMark = 0;
                                
                                for (int counter2 = longestCount+1; counter2 < inOutDataCount/5; counter2++){
                                    if (distanceCal2 [counter2] == -1){
                                        if (counter2 == longestCount+1){
                                            changePoint [counter2-1] = 0;
                                            removeFlag = 1;
                                        }
                                        else{
                                            
                                            changePoint [counter2-1] = peakCount*10+1;
                                            bottomCount1 = counter2-1;
                                        }
                                        
                                        break;
                                    }
                                    
                                    if (bottomPoint1 >= distanceCal2 [counter2] && bottomPoint1-2 < distanceCal2 [counter2] && counter2 != inOutDataCount/5-1 && firstMark == 0){
                                        bottomMin1 = distanceCal2 [counter2];
                                        bottomMinPosition1 = counter2;
                                        bottomPoint1 = distanceCal2 [counter2];
                                        distanceCal2 [counter2] = -1;
                                    }
                                    else if (bottomPoint1 < distanceCal2 [counter2] && distanceCal2 [counter2]-bottomMin1 <= 1.5 && counter2 != inOutDataCount/5-1 && firstMark == 0){
                                        distanceCal2 [counter2] = -1;
                                    }
                                    else if (bottomPoint1 < distanceCal2 [counter2] && distanceCal2 [counter2]-bottomMin1 > 1.5 && firstMark == 0){
                                        changePoint [bottomMinPosition1] = peakCount*10+1;
                                        
                                        for (int counter3 = bottomMinPosition1+1; counter3 <= counter2; counter3++) distanceCal2 [counter3] = distanceCal [counter3];
                                        
                                        bottomCount1 = counter2;
                                        break;
                                    }
                                    else if (bottomPoint1-2 >= distanceCal2 [counter2] && counter2 != inOutDataCount/5-1 && firstMark == 0){
                                        bottomPoint1 = distanceCal2 [counter2];
                                        distanceCal2 [counter2] = -1;
                                        firstMark = 1;
                                    }
                                    else if (bottomPoint1-2 >= distanceCal2 [counter2] && counter2 != inOutDataCount/5-1 && firstMark == 1){
                                        bottomPoint1 = distanceCal2 [counter2];
                                        distanceCal2 [counter2] = -1;
                                    }
                                    else if (bottomPoint1-2 < distanceCal2 [counter2] && firstMark == 1){
                                        distanceCal2 [counter2-1] = -1;
                                        changePoint [counter2-1] = peakCount*10+1;
                                        bottomCount1 = counter2-1;
                                        break;
                                    }
                                    else if (counter2 == inOutDataCount/5-1){
                                        changePoint [counter2] = peakCount*10+1;
                                        distanceCal2 [counter2] = -1;
                                        bottomCount1 = counter2;
                                    }
                                }
                                
                                if (removeFlag == 0){
                                    firstMark = 0;
                                    
                                    for (int counter2 = longestCount-1; counter2 >= 0; counter2 = counter2-1){
                                        if (distanceCal2 [counter2] == -1){
                                            if (counter2 == longestCount-1){
                                                changePoint [counter2+1] = 0;
                                                changePoint [bottomCount1] = 0;
                                            }
                                            else changePoint [counter2+1] = peakCount*10-1;
                                            
                                            break;
                                        }
                                        
                                        if (bottomPoint2 >= distanceCal2 [counter2] && bottomPoint2-2 < distanceCal2 [counter2] && counter2 != 0 && firstMark == 0){
                                            bottomMin2 = distanceCal2 [counter2];
                                            bottomMinPosition2 = counter2;
                                            bottomPoint2 = distanceCal2 [counter2];
                                            distanceCal2 [counter2] = -1;
                                        }
                                        else if (bottomPoint2 < distanceCal2 [counter2] && distanceCal2 [counter2]-bottomMin2 <= 1.5 && counter2 != 0 && firstMark == 0) distanceCal2 [counter2] = -1;
                                        else if (bottomPoint2 < distanceCal2 [counter2] && distanceCal2 [counter2]-bottomMin2 > 1.5 && firstMark == 0){
                                            changePoint [bottomMinPosition2] = peakCount*10-1;
                                            
                                            for (int counter3 = bottomMinPosition2-1; counter3 >= counter2; counter3 = counter3-1) distanceCal2 [counter3] = distanceCal [counter3];
                                            
                                            break;
                                        }
                                        else if (bottomPoint2-2 >= distanceCal2 [counter2] && counter2 != 0 && firstMark == 0){
                                            bottomPoint2 = distanceCal2 [counter2];
                                            distanceCal2 [counter2] = -1;
                                            firstMark = 1;
                                        }
                                        else if (bottomPoint2-2 >= distanceCal2 [counter2] && counter2 != 0 && firstMark == 1){
                                            bottomPoint2 = distanceCal2 [counter2];
                                            distanceCal2 [counter2] = -1;
                                        }
                                        else if (bottomPoint2-2 < distanceCal2 [counter2] && firstMark == 1){
                                            distanceCal2 [counter2+1] = -1;
                                            changePoint [counter2+1] = peakCount*10-1;
                                            break;
                                        }
                                        else if (counter2 == 0){
                                            changePoint [counter2] = peakCount*10-1;
                                            distanceCal2 [counter2] = -1;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                //for (int counterA = 0; counterA < inOutDataCount/5; counterA++){
                //	cout<< counterA<<" "<<distanceCal [counterA]<<" "<<distanceCal2 [counterA]<<" "<<changePoint [counterA]<<" Distance"<<endl;
                //}
                
                //------Find Peak, remove Front or Behind if points are set within 4 points from Start or End------
                int *checkPointList = new int [inOutDataCount/5+4];
                
                for (int counter2 = 0; counter2 < inOutDataCount/5; counter2++) checkPointList [counter2] = 0;
                
                numberOfPeaks = 0;
                
                for (int counter2 = 0; counter2 < inOutDataCount/5; counter2++){
                    if (changePoint [counter2] != 0 && changePoint [counter2]%10 == 0) numberOfPeaks++;
                }
                
                //------First and Last peak number get------
                firstPeakNumber = 0;
                lastPeakNumber = 0;
                numberOfPeaksCount = 1;
                
                for (int counter2 = 0; counter2 < inOutDataCount/5; counter2++){
                    if (changePoint [counter2] != 0 && changePoint [counter2]%10 == 0){
                        if (numberOfPeaksCount == 1) firstPeakNumber = changePoint [counter2];
                        
                        if (numberOfPeaksCount == numberOfPeaks) lastPeakNumber = changePoint [counter2];
                        
                        numberOfPeaksCount++;
                    }
                }
                
                peakFront = 0;
                peakBehind = 0;
                
                for (int counter2 = 0; counter2 < inOutDataCount/5; counter2++){
                    if (changePoint [counter2] == firstPeakNumber-1){
                        peakFront = counter2+1;
                        break;
                    }
                }
                
                for (int counter2 = inOutDataCount/5-1; counter2 >= 0; counter2 = counter2-1){
                    if (changePoint [counter2] == lastPeakNumber+1){
                        peakBehind = (inOutDataCount/5-1)-counter2+1;
                        break;
                    }
                }
                
                //cout<<firstPeakNumber<<" "<<lastPeakNumber<<" "<<peakFront<<" "<<peakBehind<<" Peak"<<endl;
                
                //------Remove points < 5 from checkPointList------
                for (int counter2 = 0; counter2 < inOutDataCount/5; counter2++){
                    if (changePoint [counter2]%10 != 0 && changePoint [counter2] != firstPeakNumber-1 && changePoint [counter2] != lastPeakNumber+1) checkPointList [counter2] = 1;
                    
                    if (changePoint [counter2] == firstPeakNumber-1 && peakFront > 5) checkPointList [counter2] = 1;
                    
                    if (changePoint [counter2] == lastPeakNumber+1 && peakBehind > 5) checkPointList [counter2] = 1;
                }
                
                //------IN and OUT XY check and remove points if those are < 5 of line One or Two from Start/End------
                valueTempXL2 = 0;
                valueTempYL2 = 0;
                valueTempXL3 = 0;
                valueTempYL3 = 0;
                
                for (int counter2 = 0; counter2 < inOutDataCount/5; counter2++){
                    removeFlag = 0;
                    
                    if (checkPointList [counter2] == 1){
                        valueTempXL2 = arrayInOutData [counter2*5]+horizontalStart;
                        valueTempYL2 = arrayInOutData [counter2*5+1]+verticalStart;
                        valueTempXL3 = arrayInOutData [counter2*5+2]+horizontalStart;
                        valueTempYL3 = arrayInOutData [counter2*5+3]+verticalStart;
                        
                        for (int counter3 = 0; counter3 < 5; counter3++){
                            if (arrayLinkedLineOneTemp [counter3*3] == valueTempXL2 && arrayLinkedLineOneTemp [counter3*3+1] == valueTempYL2) removeFlag = 1;
                        }
                        
                        for (int counter3 = linkedLineOneTempCount/3-5; counter3 < linkedLineOneTempCount/3; counter3++){
                            if (arrayLinkedLineOneTemp [counter3*3] == valueTempXL2 && arrayLinkedLineOneTemp [counter3*3+1] == valueTempYL2) removeFlag = 1;
                        }
                        
                        for (int counter3 = 0; counter3 < 5; counter3++){
                            if (arrayLinkedLineTwoTemp [counter3*3] == valueTempXL3 && arrayLinkedLineTwoTemp [counter3*3+1] == valueTempYL3) removeFlag = 1;
                        }
                        
                        for (int counter3 = linkedLineTwoTempCount/3-5; counter3 < linkedLineTwoTempCount/3; counter3++){
                            if (arrayLinkedLineTwoTemp [counter3*3] == valueTempXL3 && arrayLinkedLineTwoTemp [counter3*3+1] == valueTempYL3) removeFlag = 1;
                        }
                    }
                    
                    if (removeFlag == 1) checkPointList [counter2] = 0;
                }
                
                //------Point position adjust, to nearest, point on Line ONE >> line Two, points line TWO >> line One------
                int *arrayChangePoint = new int [inOutDataCount/5*7+4];
                changePointCount = 0;
                
                for (int counter2 = 0; counter2 < inOutDataCount/5; counter2++){
                    if (checkPointList [counter2] == 1){
                        valueTempXL2 = arrayInOutData [counter2*5]+horizontalStart;
                        valueTempYL2 = arrayInOutData [counter2*5+1]+verticalStart;
                        valueTempXL3 = arrayInOutData [counter2*5+2]+horizontalStart;
                        valueTempYL3 = arrayInOutData [counter2*5+3]+verticalStart;
                        valueTempXS2 = 0;
                        valueTempYS2 = 0;
                        valueTempXS3 = 0;
                        valueTempYS3 = 0;
                        shortest1 = 10000;
                        shortestCount1 = 0;
                        shortest2 = 10000;
                        shortestCount2 = 0;
                        
                        for (int counter3 = 4; counter3 < linkedLineTwoTempCount/3-5; counter3++){
                            lineOneDistanceTemp = sqrt((valueTempXL2-arrayLinkedLineTwoTemp [counter3*3])*(valueTempXL2-arrayLinkedLineTwoTemp [counter3*3])+(valueTempYL2-arrayLinkedLineTwoTemp [counter3*3+1])*(valueTempYL2-arrayLinkedLineTwoTemp [counter3*3+1]));
                            
                            if (lineOneDistanceTemp < shortest1){
                                shortest1 = lineOneDistanceTemp;
                                shortestCount1 = counter3;
                                valueTempXS2 = arrayLinkedLineTwoTemp [counter3*3];
                                valueTempYS2 = arrayLinkedLineTwoTemp [counter3*3+1];
                            }
                        }
                        
                        for (int counter3 = 4; counter3 < linkedLineOneTempCount/3-5; counter3++){
                            lineOneDistanceTemp = sqrt((valueTempXL3-arrayLinkedLineOneTemp [counter3*3])*(valueTempXL3-arrayLinkedLineOneTemp [counter3*3])+(valueTempYL3-arrayLinkedLineOneTemp [counter3*3+1])*(valueTempYL3-arrayLinkedLineOneTemp [counter3*3+1]));
                            
                            if (lineOneDistanceTemp < shortest2){
                                shortest2 = lineOneDistanceTemp;
                                shortestCount2 = counter3;
                                valueTempXS3 = arrayLinkedLineOneTemp [counter3*3];
                                valueTempYS3 = arrayLinkedLineOneTemp [counter3*3+1];
                            }
                        }
                        
                        valueTempXIn = 0;
                        valueTempYIn = 0;
                        valueTempXOut = 0;
                        valueTempYOut = 0;
                        countOne = 0;
                        countTwo = 0;
                        
                        if (shortest1 > shortest2){
                            valueTempXIn = valueTempXS3;
                            valueTempYIn = valueTempYS3;
                            valueTempXOut = valueTempXL3;
                            valueTempYOut = valueTempYL3;
                            
                            for (int counter3 = 0; counter3 < linkedLineTwoTempCount/3; counter3++){
                                if (valueTempXOut == arrayLinkedLineTwoTemp [counter3*3] && valueTempYOut == arrayLinkedLineTwoTemp [counter3*3+1]){
                                    countTwo = counter3;
                                    break;
                                }
                            }
                            
                            countOne = shortestCount2;
                        }
                        
                        if (shortest1 <= shortest2){
                            valueTempXIn = valueTempXL2;
                            valueTempYIn = valueTempYL2;
                            valueTempXOut = valueTempXS2;
                            valueTempYOut = valueTempYS2;
                            
                            for (int counter3 = 0; counter3 < linkedLineOneTempCount/3; counter3++){
                                if (valueTempXIn == arrayLinkedLineOneTemp [counter3*3] && valueTempYIn == arrayLinkedLineOneTemp [counter3*3+1]){
                                    countOne = counter3;
                                    break;
                                }
                            }
                            
                            countTwo = shortestCount1;
                        }
                        
                        arrayChangePoint [changePointCount] = valueTempXIn, changePointCount++;
                        arrayChangePoint [changePointCount] = valueTempYIn, changePointCount++;
                        arrayChangePoint [changePointCount] = countOne, changePointCount++;
                        arrayChangePoint [changePointCount] = valueTempXOut, changePointCount++;
                        arrayChangePoint [changePointCount] = valueTempYOut, changePointCount++;
                        arrayChangePoint [changePointCount] = countTwo, changePointCount++;
                        arrayChangePoint [changePointCount] = 0, changePointCount++;
                    }
                }
                
                //++++++++++Approach 2, Find nearest points, within +- 10 pix of a Pix+++++++++++
                double *distanceList = new double [linkedLineSourceCount/3+4];
                int *positionCounterpart = new int [linkedLineSourceCount/3+4];
                
                int **positionXYList = new int *[linkedLineSourceCount/3+4];
                int **positionXYList2 = new int *[linkedLineSourceCount/3+4];
                
                for (int counter2 = 0; counter2 < linkedLineSourceCount/3+4; counter2++){
                    positionXYList [counter2] = new int [4];
                    positionXYList2 [counter2] = new int [4];
                }
                
                for (int counter2 = 0; counter2 < linkedLineSourceCount/3; counter2++){
                    distanceList [counter2] = 0;
                    positionCounterpart [counter2] = 0;
                    positionXYList [counter2][0] = 0;
                    positionXYList [counter2][1] = 0;
                }
                
                for (int counter2 = 0; counter2 < linkedLineSourceCount/3; counter2++){
                    positionXYList [counter2][0] = arrayLinkedLineSource [counter2*3];
                    positionXYList [counter2][1] = arrayLinkedLineSource [counter2*3+1];
                }
                
                positionXYCount = 10;
                
                for (int counter2 = 0; counter2 < linkedLineSourceCount/3; counter2++){
                    shortest1 = 10000;
                    valueTempX3 = 0;
                    valueTempY3 = 0;
                    
                    for (int counter3 = 21; counter3 < linkedLineSourceCount/3; counter3++){
                        lineOneDistanceTemp = sqrt((positionXYList [10][0]-positionXYList [counter3][0])*(positionXYList [10][0]-positionXYList [counter3][0])+(positionXYList [10][1]-positionXYList [counter3][1])*(positionXYList [10][1]-positionXYList [counter3][1]));
                        
                        if (lineOneDistanceTemp < shortest1){
                            shortest1 = lineOneDistanceTemp;
                            valueTempX3 = positionXYList [counter3][0];
                            valueTempY3 = positionXYList [counter3][1];
                        }
                    }
                    
                    distanceList [positionXYCount] = shortest1;
                    
                    for (int counter3 = 0; counter3 < linkedLineSourceCount/3; counter3++){
                        if (valueTempX3 == arrayLinkedLineSource [counter3*3] && valueTempY3 == arrayLinkedLineSource [counter3*3+1]){
                            positionCounterpart [positionXYCount] = counter3;
                            break;
                        }
                    }
                    
                    if (positionXYCount == linkedLineSourceCount/3-1) positionXYCount = 0;
                    else positionXYCount++;
                    
                    positionXYList2 [linkedLineSourceCount/3-1][0] = positionXYList [0][0];
                    positionXYList2 [linkedLineSourceCount/3-1][1] = positionXYList [0][1];
                    
                    for (int counter3 = 0; counter3 < linkedLineSourceCount/3-1; counter3++){
                        positionXYList2 [counter3][0] = positionXYList [counter3+1][0];
                        positionXYList2 [counter3][1] = positionXYList [counter3+1][1];
                    }
                    
                    for (int counter3 = 0; counter3 < linkedLineSourceCount/3; counter3++){
                        positionXYList [counter3][0] = positionXYList2 [counter3][0];
                        positionXYList [counter3][1] = positionXYList2 [counter3][1];
                    }
                }
                
                for (int counter2 = 0; counter2 < linkedLineSourceCount/3+4; counter2++){
                    delete [] positionXYList [counter2];
                    delete [] positionXYList2 [counter2];
                }
                
                delete [] positionXYList;
                delete [] positionXYList2;
                
                int *changePoint2 = new int [linkedLineSourceCount/3+4];
                
                for (int counter2 = 0; counter2 < linkedLineSourceCount/3; counter2++) changePoint2 [counter2] = 0;
                
                int *positionAB = new int [6];
                positionAB [0] = 0;
                positionAB [1] = 0;
                positionAB [2] = 0;
                positionAB [3] = 0;
                positionAB [4] = 0;
                positionAB [5] = 0;
                
                for (int counter2 = 0; counter2 < linkedLineSourceCount/3; counter2++){
                    if (positionAB [1] == 0) positionAB [0] = linkedLineSourceCount/3-1;
                    else if (counter2 == 0) positionAB [0] = linkedLineSourceCount/3-1;
                    else positionAB [0] = counter2-1;
                    
                    positionAB [1] = counter2;
                    
                    if (positionAB [1] == linkedLineSourceCount/3-1) positionAB [2] = 0;
                    else if (counter2 == linkedLineSourceCount/3-1) positionAB [2] = 0;
                    else positionAB [2] = counter2+1;
                    
                    if (positionAB [4] == 0) positionAB [3] = linkedLineSourceCount/3-1;
                    else if (positionCounterpart [counter2] == 0) positionAB [3] = linkedLineSourceCount/3-1;
                    else positionAB [3] = positionCounterpart [counter2]-1;
                    
                    positionAB [4] = positionCounterpart [counter2];
                    
                    if (positionAB [4] == linkedLineSourceCount/3-1) positionAB [5] = 0;
                    else if (positionCounterpart [counter2] == linkedLineSourceCount/3-1) positionAB [5] = linkedLineSourceCount/3-1;
                    else positionAB [5] = positionCounterpart [counter2]+1;
                    
                    if (positionCounterpart [positionAB [3]] == positionAB [0] || positionCounterpart [positionAB [3]] == positionAB [1] || positionCounterpart [positionAB [3]] == positionAB [2]){
                        changePoint2 [counter2] = 1;
                        changePoint2 [positionAB [3]] = 1;
                    }
                    
                    if (positionCounterpart [positionAB [4]] == positionAB [0] || positionCounterpart [positionAB [4]] == positionAB [1] || positionCounterpart [positionAB [4]] == positionAB [2]){
                        changePoint2 [counter2] = 1;
                        changePoint2 [positionAB [4]] = 1;
                    }
                    
                    if (positionCounterpart [positionAB [5]] == positionAB [0] || positionCounterpart [positionAB [5]] == positionAB [1] || positionCounterpart [positionAB [5]] == positionAB [2]){
                        changePoint2 [counter2] = 1;
                        changePoint2 [positionAB [5]] = 1;
                    }
                }
                
                for (int counter2 = 0; counter2 < linkedLineSourceCount/3; counter2++){
                    if (changePoint2 [counter2] == 1){
                        selectedPointDistance = distanceList [counter2];
                        aheadDistanceCount = 0;
                        behindDistanceCount = 0;
                        
                        double *aheadDistance = new double [5];
                        double *behindDistance = new double [5];
                        
                        for (int counter3 = 0; counter3 < 5; counter3++){
                            if (counter2-(aheadDistanceCount+1) < 0) aheadDistance [aheadDistanceCount] = distanceList [linkedLineSourceCount/3-(aheadDistanceCount+1)], aheadDistanceCount++;
                            else aheadDistance [aheadDistanceCount] = distanceList [counter2-(aheadDistanceCount+1)], aheadDistanceCount++;
                        }
                        
                        for (int counter3 = 0; counter3 < 5; counter3++){
                            if (counter2+behindDistanceCount+1 >= linkedLineSourceCount/3-1) behindDistance [behindDistanceCount] = distanceList [behindDistanceCount], behindDistanceCount++;
                            else behindDistance [behindDistanceCount] = distanceList [counter2+(behindDistanceCount+1)], behindDistanceCount++;
                        }
                        
                        //for (int counterA = 0; counterA < 5; counterA++){
                        //	cout<<aheadDistance [counterA]<<" "<<behindDistance [counterA]<<selectedPointDistance-0.3<<" Distance"<<endl;
                        //}
                        
                        for (int counter3 = 4; counter3 >= 0; counter3 = counter3-1){
                            if (aheadDistance [counter3] < selectedPointDistance-0.3){
                                changePoint2 [counter2] = 0;
                                break;
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < 5; counter3++){
                            if (behindDistance [counter3] < selectedPointDistance-0.3){
                                changePoint2 [counter2] = 0;
                                break;
                            }
                        }
                        
                        delete [] aheadDistance;
                        delete [] behindDistance;
                    }
                }
                
                delete [] distanceList;
                
                //==========Combine the results of Approach 1 and 2==========
                int *arrayChangePointTemp2 = new int [changePointCount+linkedLineSourceCount/3*7+50], changePointTempCount2 = 0;
                
                for (int counter2 = 0; counter2 < changePointCount/7; counter2++){
                    arrayChangePointTemp2 [changePointTempCount2] = arrayChangePoint [counter2*7], changePointTempCount2++;
                    arrayChangePointTemp2 [changePointTempCount2] = arrayChangePoint [counter2*7+1], changePointTempCount2++;
                    arrayChangePointTemp2 [changePointTempCount2] = arrayChangePoint [counter2*7+2], changePointTempCount2++;
                    arrayChangePointTemp2 [changePointTempCount2] = arrayChangePoint [counter2*7+3], changePointTempCount2++;
                    arrayChangePointTemp2 [changePointTempCount2] = arrayChangePoint [counter2*7+4], changePointTempCount2++;
                    arrayChangePointTemp2 [changePointTempCount2] = arrayChangePoint [counter2*7+5]+linkedLineOneTempCount/3, changePointTempCount2++;
                    arrayChangePointTemp2 [changePointTempCount2] = 0, changePointTempCount2++;
                }
                
                delete [] arrayChangePoint;
                
                for (int counter2 = 0; counter2 < linkedLineSourceCount/3; counter2++){
                    if (changePoint2 [counter2] == 1){
                        arrayChangePointTemp2 [changePointTempCount2] = arrayLinkedLineSource [counter2*3], changePointTempCount2++;
                        arrayChangePointTemp2 [changePointTempCount2] = arrayLinkedLineSource [counter2*3+1], changePointTempCount2++;
                        arrayChangePointTemp2 [changePointTempCount2] = counter2, changePointTempCount2++;
                        arrayChangePointTemp2 [changePointTempCount2] = arrayLinkedLineSource [positionCounterpart [counter2]*3], changePointTempCount2++;
                        arrayChangePointTemp2 [changePointTempCount2] = arrayLinkedLineSource [positionCounterpart [counter2]*3+1], changePointTempCount2++;
                        arrayChangePointTemp2 [changePointTempCount2] = positionCounterpart [counter2], changePointTempCount2++;
                        arrayChangePointTemp2 [changePointTempCount2] = 0, changePointTempCount2++;
                    }
                }
                
                delete [] positionCounterpart;
                delete [] changePoint2;
                
                //------Remove points, which through outside of connectivity pixeles------
                if (changePointTempCount2 != 0){
                    int *arrayChangePoint2 = new int [changePointTempCount2+50], changePointCount2 = 0;
                    
                    for (int counter2 = 0; counter2 < changePointTempCount2/7; counter2++){
                        valueTempXL2 = arrayChangePointTemp2 [counter2*7]-horizontalStart;
                        valueTempYL2 = arrayChangePointTemp2 [counter2*7+1]-verticalStart;
                        valueTempXL3 = arrayChangePointTemp2 [counter2*7+3]-horizontalStart;
                        valueTempYL3 = arrayChangePointTemp2 [counter2*7+4]-verticalStart;
                        
                        if (valueTempXL2 < 0) valueTempXL2 = 0;
                        else if (valueTempXL2 >= dimension) valueTempXL2 = dimension-1;
                        
                        if (valueTempYL2 < 0) valueTempYL2 = 0;
                        else if (valueTempYL2 >= dimension) valueTempYL2 = dimension-1;
                        
                        if (valueTempXL3 < 0) valueTempXL3 = 0;
                        else if (valueTempXL3 >= dimension) valueTempXL3 = dimension-1;
                        
                        if (valueTempYL3 < 0) valueTempYL3 = 0;
                        else if (valueTempYL3 >= dimension) valueTempYL3 = dimension-1;
                        
                        if (valueTempXL2-valueTempXL3 != 0) constA = (valueTempYL2-valueTempYL3)/(double)(valueTempXL2-valueTempXL3);
                        else constA = 0;
                        
                        constB = valueTempYL2-valueTempXL2*constA;
                        outsideFlag = 0;
                        
                        if (valueTempXL2-valueTempXL3 == 0){
                            for (int counter3 = valueTempYL2; counter3 <= valueTempYL3; counter3++){
                                if (combinedMatrixA2 [counter3][valueTempXL2] == 0){
                                    outsideFlag = 1;
                                    break;
                                }
                                
                                if (counter3 != valueTempYL2 && counter3 != valueTempYL3 && combinedMatrixA2 [counter3][valueTempXL2] == 2){
                                    outsideFlag = 1;
                                    break;
                                }
                            }
                        }
                        else if (valueTempYL2-valueTempYL3 == 0){
                            for (int counter3 = valueTempXL2; counter3 <= valueTempXL3; counter3++){
                                if (combinedMatrixA2 [valueTempYL2][counter3] == 0){
                                    outsideFlag = 1;
                                    break;
                                }
                                
                                if (counter3 != valueTempXL2 && counter3 != valueTempXL3 && combinedMatrixA2 [valueTempYL2][counter3] == 2){
                                    outsideFlag = 1;
                                    break;
                                }
                            }
                        }
                        else if (abs(valueTempXL2-valueTempXL3) > abs(valueTempYL2-valueTempYL3)){
                            if (valueTempXL2 > valueTempXL3){
                                valueStart = valueTempXL3;
                                valueEnd = valueTempXL2;
                            }
                            else{
                                
                                valueStart = valueTempXL2;
                                valueEnd = valueTempXL3;
                            }
                            
                            for (int counter3 = valueStart; counter3 <= valueEnd; counter3++){
                                valueTempYInOut = (int)(constA*counter3+constB);
                                
                                if (counter3 != valueTempXL2 && counter3 != valueTempXL3 && combinedMatrixA2 [valueTempYInOut][counter3] == 0) outsideFlag = 1;
                                
                                if (counter3 != valueTempXL2 && counter3 != valueTempXL3 && combinedMatrixA2 [valueTempYInOut][counter3] == 2) outsideFlag = 1;
                            }
                        }
                        else{
                            
                            if (valueTempYL2 > valueTempYL3){
                                valueStart = valueTempYL3;
                                valueEnd = valueTempYL2;
                            }
                            else{
                                
                                valueStart = valueTempYL2;
                                valueEnd = valueTempYL3;
                            }
                            
                            for (int counter3 = valueStart; counter3 <= valueEnd; counter3++){
                                valueTempYInOut = (int)((counter3-constB)/(double)constA);
                                
                                if (counter3 != valueTempYL2 && counter3 != valueTempYL3 && combinedMatrixA2 [counter3][valueTempYInOut] == 0) outsideFlag = 1;
                                
                                if (counter3 != valueTempYL2 && counter3 != valueTempYL3 && combinedMatrixA2 [counter3][valueTempYInOut] == 2) outsideFlag = 1;
                            }
                        }
                        
                        if (outsideFlag == 1) arrayChangePointTemp2 [counter2*7+6] = 1;
                    }
                    
                    
                    //for (int counterA = 0; counterA < changePointCount2/7; counterA++){
                    //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayChangePoint2 [counterA*7+counterB];
                    //    cout<<" arrayChangePoint2 "<<counterA<<endl;
                    // }
                    
                    for (int counter2 = 0; counter2 < changePointTempCount2/7; counter2++){
                        if (arrayChangePointTemp2 [counter2*7+6] == 0){
                            arrayChangePoint2 [changePointCount2] = arrayChangePointTemp2 [counter2*7], changePointCount2++;
                            arrayChangePoint2 [changePointCount2] = arrayChangePointTemp2 [counter2*7+1], changePointCount2++;
                            arrayChangePoint2 [changePointCount2] = arrayChangePointTemp2 [counter2*7+2], changePointCount2++;
                            arrayChangePoint2 [changePointCount2] = arrayChangePointTemp2 [counter2*7+3], changePointCount2++;
                            arrayChangePoint2 [changePointCount2] = arrayChangePointTemp2 [counter2*7+4], changePointCount2++;
                            arrayChangePoint2 [changePointCount2] = arrayChangePointTemp2 [counter2*7+5], changePointCount2++;
                            arrayChangePoint2 [changePointCount2] = 0, changePointCount2++;
                        }
                    }
                    
                    //------Find bulges, which are formed within Line One or Line Two------
                    if (changePointCount2 != 0){
                        int *arrayChangePoint3 = new int [changePointCount2*3+50], changePointCount3 = 0;
                        
                        for (int counter2 = 0; counter2 < changePointCount2/7; counter2++){
                            distanceTemp1 = sqrt((arrayChangePoint2 [counter2*7]-arrayChangePoint2 [counter2*7+3])*(arrayChangePoint2 [counter2*7]-arrayChangePoint2 [counter2*7+3])+(arrayChangePoint2 [counter2*7+1]-arrayChangePoint2 [counter2*7+4])*(arrayChangePoint2 [counter2*7+1]-arrayChangePoint2 [counter2*7+4]));
                            
                            if (arrayChangePoint2 [counter2*7+2] > arrayChangePoint2 [counter2*7+5]){
                                loopLength1 = arrayChangePoint2 [counter2*7+5]+(linkedLineSourceCount/3-arrayChangePoint2 [counter2*7+2]); //--In
                                loopLength2 = arrayChangePoint2 [counter2*7+2]-arrayChangePoint2 [counter2*7+5]; //--Out
                                positionA = arrayChangePoint2 [counter2*7+5];
                                positionB = arrayChangePoint2 [counter2*7+2];
                            }
                            else{
                                
                                loopLength1 = arrayChangePoint2 [counter2*7+2]+(linkedLineSourceCount/3-arrayChangePoint2 [counter2*7+5]);
                                loopLength2 = arrayChangePoint2 [counter2*7+5]-arrayChangePoint2 [counter2*7+2];
                                positionA = arrayChangePoint2 [counter2*7+2];
                                positionB = arrayChangePoint2 [counter2*7+5];
                            }
                            
                            checkLengthOut = (loopLength1-2)/2;
                            checkLengthIn = (loopLength2-2)/2;
                            
                            if (loopLength1 > loopLength2){
                                smallLoop = 2;
                                smallLoopLength = loopLength2;
                            }
                            else{
                                
                                smallLoop = 1;
                                smallLoopLength = loopLength1;
                            }
                            
                            if (smallLoopLength < 9) arrayChangePoint2 [counter2*7+6] = 1;
                            else{
                                
                                double *loopOutDistance = new double [checkLengthOut+4];
                                double *loopInDistance = new double [checkLengthIn+4];
                                
                                for (int counter3 = 0; counter3 < checkLengthOut; counter3++) loopOutDistance [counter3] = 0;
                                for (int counter3 = 0; counter3 < checkLengthIn; counter3++) loopInDistance [counter3] = 0;
                                
                                positionAB [0] = positionA;
                                positionAB [3] = positionB;
                                positionAB [1] = positionA;
                                positionAB [4] = positionB;
                                
                                for (int counter3 = 0; counter3 < checkLengthOut; counter3++){
                                    if (positionAB [0] == 0) positionAB [0] = linkedLineSourceCount/3-1;
                                    else positionAB [0] = positionAB [0]-1;
                                    
                                    if (positionAB [3] == linkedLineSourceCount/3-1) positionAB [3] = 0;
                                    else positionAB [3]++;
                                    
                                    loopOutDistance [counter3] = sqrt((arrayLinkedLineSource [positionAB [0]*3]-arrayLinkedLineSource [positionAB [3]*3])*(arrayLinkedLineSource [positionAB [0]*3]-arrayLinkedLineSource [positionAB [3]*3])+(arrayLinkedLineSource [positionAB [0]*3+1]-arrayLinkedLineSource [positionAB [3]*3+1])*(arrayLinkedLineSource [positionAB [0]*3+1]-arrayLinkedLineSource [positionAB [3]*3+1]));
                                }
                                
                                //for (int counterA = 0; counterA < checkLengthOut; counterA++){
                                //	cout<<counterA<<" "<<loopOutDistance [counterA]<<" loopOutDistance"<<endl;
                                //}
                                
                                for (int counter3 = 0; counter3 < checkLengthIn; counter3++){
                                    if (positionAB [1] == linkedLineSourceCount/3-1) positionAB [1] = 0;
                                    else positionAB [1]++;
                                    
                                    if (positionAB [4] == 0) positionAB [4] = linkedLineSourceCount/3-1;
                                    else positionAB [4] = positionAB [4]-1;
                                    loopInDistance [counter3] = sqrt((arrayLinkedLineSource [positionAB [1]*3]-arrayLinkedLineSource [positionAB [4]*3])*(arrayLinkedLineSource [positionAB [1]*3]-arrayLinkedLineSource [positionAB [4]*3])+(arrayLinkedLineSource [positionAB [1]*3+1]-arrayLinkedLineSource [positionAB [4]*3+1])*(arrayLinkedLineSource [positionAB [1]*3+1]-arrayLinkedLineSource [positionAB [4]*3+1]));
                                }
                                
                                //for (int counterA = 0; counterA < checkLengthIn; counterA++){
                                //	cout<<counterA<<" "<<loopInDistance [counterA]<<" loopOutDistance"<<endl;
                                //}
                                
                                loopBulgeFind = 0;
                                incrementPosition = -1;
                                
                                if (smallLoop == 1){
                                    if (distanceTemp1 <= 2) cutOff = distanceTemp1+2;
                                    else cutOff = distanceTemp1*1.5;
                                    
                                    for (int counter3 = 0; counter3 < checkLengthOut; counter3++){
                                        if (loopOutDistance [counter3] > cutOff) loopBulgeFind = 1;
                                    }
                                    
                                    if (loopBulgeFind == 0){
                                        for (int counter3 = 1; counter3 < checkLengthIn; counter3++){
                                            double incrementCheck = loopInDistance [counter3]-loopInDistance [counter3-1];
                                            
                                            if (incrementCheck > 1.5 && loopInDistance [counter3] > distanceTemp1*2.5){
                                                incrementPosition = counter3;
                                                break;
                                            }
                                        }
                                    }
                                }
                                
                                if (smallLoop == 2){
                                    if (distanceTemp1 <= 2) cutOff = distanceTemp1+2;
                                    else cutOff = distanceTemp1*1.5;
                                    
                                    for (int counter3 = 0; counter3 < checkLengthIn; counter3++){
                                        if (loopInDistance [counter3] > cutOff) loopBulgeFind = 1;
                                    }
                                    
                                    if (loopBulgeFind == 0){
                                        for (int counter3 = 1; counter3 < checkLengthOut; counter3++){
                                            double incrementCheck = loopOutDistance [counter3]-loopOutDistance [counter3-1];
                                            
                                            if (incrementCheck > 1.5 && loopOutDistance [counter3] > distanceTemp1*2.5){
                                                incrementPosition = counter3;
                                                break;
                                            }
                                        }
                                    }
                                }
                                
                                if (loopBulgeFind == 0 && incrementPosition == -1) arrayChangePoint2 [counter2*7+6] = 1;
                                else if (loopBulgeFind == 0 && incrementPosition > 7) arrayChangePoint2 [counter2*7+6] = 1;
                                
                                delete [] loopOutDistance;
                                delete [] loopInDistance;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < changePointCount2/7; counterA++){
                        //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayChangePoint2 [counterA*7+counterB];
                        //    cout<<" arrayChangePoint2 "<<counterA<<endl;
                        //}
                        
                        for (int counter2 = 0; counter2 < changePointCount2/7; counter2++){
                            if (arrayChangePoint2 [counter2*7+6] == 0){
                                arrayChangePoint3 [changePointCount3] = arrayChangePoint2 [counter2*7], changePointCount3++;
                                arrayChangePoint3 [changePointCount3] = arrayChangePoint2 [counter2*7+1], changePointCount3++;
                                arrayChangePoint3 [changePointCount3] = arrayChangePoint2 [counter2*7+2], changePointCount3++;
                                arrayChangePoint3 [changePointCount3] = arrayChangePoint2 [counter2*7+3], changePointCount3++;
                                arrayChangePoint3 [changePointCount3] = arrayChangePoint2 [counter2*7+4], changePointCount3++;
                                arrayChangePoint3 [changePointCount3] = arrayChangePoint2 [counter2*7+5], changePointCount3++;
                                arrayChangePoint3 [changePointCount3] = 0, changePointCount3++;
                            }
                        }
                        
                        //------IN and Out data alignment, if In is on the Line Two, and Out is on Line one Flip One<>Two: Then remove lines of which distance is less than 1.5------
                        if (changePointCount3 != 0){
                            if (changePointCount3/7 > 1){
                                changePointNumber = changePointCount3/7;
                                
                                int **changePointData = new int *[changePointNumber+4];
                                int **changePointData2 = new int *[changePointNumber+4];
                                
                                for (int counter2 = 0; counter2 < changePointNumber+4; counter2++){
                                    changePointData [counter2] = new int [10];
                                    changePointData2 [counter2] = new int [10];
                                }
                                
                                for (int counter2 = 0; counter2 < changePointNumber; counter2++){
                                    changePointData [counter2][0] = arrayChangePoint3 [counter2*7];
                                    changePointData [counter2][1] = arrayChangePoint3 [counter2*7+1];
                                    changePointData [counter2][2] = arrayChangePoint3 [counter2*7+2];
                                    changePointData [counter2][3] = arrayChangePoint3 [counter2*7+3];
                                    changePointData [counter2][4] = arrayChangePoint3 [counter2*7+4];
                                    changePointData [counter2][5] = arrayChangePoint3 [counter2*7+5];
                                    changePointData [counter2][6] = arrayChangePoint3 [counter2*7+6];
                                    changePointData [counter2][7] = 0;
                                }
                                
                                //for (int counterA = 0; counterA < changePointNumber/6; counterA++){
                                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<changePointData [counterA*6+counterB];
                                //	cout<<" changePointData "<<counterA<<" "<<counter1<<endl;
                                //}
                                
                                for (int counter2 = 0; counter2 < changePointNumber; counter2++){
                                    if (changePointData [counter2][0] != 0){
                                        for (int counter3 = 0; counter3 < changePointNumber; counter3++){
                                            for (int counter4 = 0; counter4 < 8; counter4++) changePointData2 [counter3][counter4] = 0;
                                        }
                                        
                                        setIn = changePointData [counter2][2];
                                        setOut = changePointData [counter2][5];
                                        countSet = 0;
                                        countPosition = counter2;
                                        
                                        do{
                                            
                                            terminationFlag = 1;
                                            
                                            for (int counter3 = 0; counter3 < changePointNumber; counter3++){
                                                if (counter2 != counter3 && changePointData [counter3][0] != 0){
                                                    if (setIn == changePointData [counter3][2] || setIn == changePointData [counter3][2]-1 || setIn == changePointData [counter3][2]-2 || setIn == changePointData [counter3][2]+1 || setIn == changePointData [counter3][2]+2){
                                                        changePointData [counter3][7] = 1;
                                                    }
                                                }
                                            }
                                            
                                            for (int counter3 = 0; counter3 < changePointNumber; counter3++){
                                                if (counter2 != counter3 && changePointData [counter3][0] != 0){
                                                    if (setIn == changePointData [counter3][5] || setIn == changePointData [counter3][5]-1 || setIn == changePointData [counter3][5]-2 || setIn == changePointData [counter3][5]+1 || setIn == changePointData [counter3][5]+2){
                                                        changePointData [counter3][7] = 1;
                                                    }
                                                }
                                            }
                                            
                                            for (int counter3 = 0; counter3 < changePointNumber; counter3++){
                                                if (counter2 != counter3 && changePointData [counter3][0] != 0){
                                                    if (setOut == changePointData [counter3][2] || setOut == changePointData [counter3][2]-1 || setOut == changePointData [counter3][2]-2 || setOut == changePointData [counter3][2]+1 || setOut == changePointData [counter3][2]+2){
                                                        changePointData [counter3][7] = 1;
                                                    }
                                                }
                                            }
                                            
                                            for (int counter3 = 0; counter3 < changePointNumber; counter3++){
                                                if (counter2 != counter3 && changePointData [counter3][0] != 0){
                                                    if (setOut == changePointData [counter3][5] || setOut == changePointData [counter3][5]-1 || setOut == changePointData [counter3][5]-2 || setOut == changePointData [counter3][5]+1 || setOut == changePointData [counter3][5]+2){
                                                        changePointData [counter3][7] = 1;
                                                    }
                                                }
                                            }
                                            
                                            if (changePointData [countPosition][2] > changePointData [countPosition][5]){
                                                changePointData2 [countSet][0] = changePointData [countPosition][3];
                                                changePointData2 [countSet][1] = changePointData [countPosition][4];
                                                changePointData2 [countSet][2] = changePointData [countPosition][5];
                                                changePointData2 [countSet][3] = changePointData [countPosition][0];
                                                changePointData2 [countSet][4] = changePointData [countPosition][1];
                                                changePointData2 [countSet][5] = changePointData [countPosition][2];
                                                changePointData2 [countSet][6] = changePointData [countPosition][6];
                                                changePointData2 [countSet][7] = countPosition;
                                            }
                                            else{
                                                
                                                changePointData2 [countSet][0] = changePointData [countPosition][0];
                                                changePointData2 [countSet][1] = changePointData [countPosition][1];
                                                changePointData2 [countSet][2] = changePointData [countPosition][2];
                                                changePointData2 [countSet][3] = changePointData [countPosition][3];
                                                changePointData2 [countSet][4] = changePointData [countPosition][4];
                                                changePointData2 [countSet][5] = changePointData [countPosition][5];
                                                changePointData2 [countSet][6] = changePointData [countPosition][6];
                                                changePointData2 [countSet][7] = countPosition;
                                            }
                                            
                                            changePointData [countPosition][0] = 0;
                                            changePointData [countPosition][1] = 0;
                                            changePointData [countPosition][2] = 0;
                                            changePointData [countPosition][3] = 0;
                                            changePointData [countPosition][4] = 0;
                                            changePointData [countPosition][5] = 0;
                                            changePointData [countPosition][6] = 0;
                                            changePointData [countPosition][7] = 0;
                                            
                                            countSet++;
                                            nextFind = 0;
                                            
                                            for (int counter3 = 0; counter3 < changePointNumber; counter3++){
                                                if (changePointData [counter3][7] == 1){
                                                    setIn = changePointData [counter3][2];
                                                    setOut = changePointData [counter3][5];
                                                    countPosition = counter3;
                                                    nextFind = 1;
                                                    break;
                                                }
                                            }
                                            
                                            if (nextFind == 0) terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                        
                                        if (countSet > 1){
                                            minIn = 10000;
                                            maxIn = 0;
                                            minOut = 10000;
                                            maxOut = 0;
                                            
                                            for (int counter3 = 0; counter3 < countSet; counter3++){
                                                if (changePointData2 [counter3][2] > maxIn) maxIn = changePointData2 [counter3][2];
                                                
                                                if (changePointData2 [counter3][2] < minIn) minIn = changePointData2 [counter3][2];
                                                
                                                if (changePointData2 [counter3][5] > maxOut) maxOut = changePointData2 [counter3][5];
                                                
                                                if (changePointData2 [counter3][5] < minOut) minOut = changePointData2 [counter3][5];
                                            }
                                            
                                            inCenter = (int)((maxIn+minIn)/(double)2);
                                            outCenter = (int)((maxOut+minOut)/(double)2);
                                            
                                            shortest = 10000;
                                            shortestCountIn = 0;
                                            shortestCountOut = 0;
                                            
                                            for (int counter3 = minIn; counter3 < maxIn; counter3++){
                                                for (int counter4 = minOut; counter4 < maxOut; counter4++){
                                                    distanceTemp2 = sqrt((arrayLinkedLineSource [counter3*3]-arrayLinkedLineSource [counter4*3])*(arrayLinkedLineSource [counter3*3]-arrayLinkedLineSource [counter4*3])+(arrayLinkedLineSource [counter3*3+1]-arrayLinkedLineSource [counter4*3+1])*(arrayLinkedLineSource [counter3*3+1]-arrayLinkedLineSource [counter4*3+1]));
                                                    
                                                    if (shortest > distanceTemp2){
                                                        shortest = (int)distanceTemp2;
                                                        shortestCountIn = counter3;
                                                        shortestCountOut = counter3;
                                                    }
                                                }
                                            }
                                            
                                            if (arrayLinkedLineSource [minIn*3]-arrayLinkedLineSource [maxOut*3] != 0) constA3 = (arrayLinkedLineSource [minIn*3+1]-arrayLinkedLineSource [maxOut*3+1])/(double)(arrayLinkedLineSource [minIn*3]-arrayLinkedLineSource [maxOut*3]);
                                            else constA3 = 0;
                                            
                                            if (arrayLinkedLineSource [maxIn*3]-arrayLinkedLineSource [minOut*3] != 0) constA4 = (arrayLinkedLineSource [maxIn*3+1]-arrayLinkedLineSource [minOut*3+1])/(double)(arrayLinkedLineSource [maxIn*3]-arrayLinkedLineSource [minOut*3]);
                                            else constA4 = 0;
                                            
                                            if (constA3 > constA4) differenceConst = constA3-constA4;
                                            else differenceConst = constA4-constA3;
                                            
                                            if (differenceConst > 1.5 || shortest == 10000){
                                                arrayChangePoint3 [changePointCount3] = arrayLinkedLineSource [inCenter*3], changePointCount3++;
                                                arrayChangePoint3 [changePointCount3] = arrayLinkedLineSource [inCenter*3+1], changePointCount3++;
                                                arrayChangePoint3 [changePointCount3] = inCenter, changePointCount3++;
                                                arrayChangePoint3 [changePointCount3] = arrayLinkedLineSource [outCenter*3], changePointCount3++;
                                                arrayChangePoint3 [changePointCount3] = arrayLinkedLineSource [outCenter*3+1], changePointCount3++;
                                                arrayChangePoint3 [changePointCount3] = outCenter, changePointCount3++;
                                                arrayChangePoint3 [changePointCount3] = 5, changePointCount3++;
                                            }
                                            else{
                                                
                                                arrayChangePoint3 [changePointCount3] = arrayLinkedLineSource [shortestCountIn*3], changePointCount3++;
                                                arrayChangePoint3 [changePointCount3] = arrayLinkedLineSource [shortestCountIn*3+1], changePointCount3++;
                                                arrayChangePoint3 [changePointCount3] = shortestCountIn, changePointCount3++;
                                                arrayChangePoint3 [changePointCount3] = arrayLinkedLineSource [shortestCountOut*3], changePointCount3++;
                                                arrayChangePoint3 [changePointCount3] = arrayLinkedLineSource [shortestCountOut*3+1], changePointCount3++;
                                                arrayChangePoint3 [changePointCount3] = shortestCountOut, changePointCount3++;
                                                arrayChangePoint3 [changePointCount3] = 5, changePointCount3++;
                                            }
                                            
                                            for (int counter3 = 0; counter3 < countSet; counter3++){
                                                int countPosition2 = changePointData2 [counter3][7];
                                                arrayChangePoint3 [countPosition2*7+6] = 3;
                                            }
                                        }
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < changePointNumber+4; counter2++){
                                    delete [] changePointData [counter2];
                                    delete [] changePointData2 [counter2];
                                }
                                
                                delete [] changePointData;
                                delete [] changePointData2;
                            }
                            
                            int *arrayChangePoint4 = new int [changePointCount3+linkedLineSourceCount*3+50], changePointCount4 = 0;
                            
                            for (int counter2 = 0; counter2 < changePointCount3/7; counter2++){
                                if (arrayChangePoint3 [counter2*7+6] == 0 || arrayChangePoint3 [counter2*7+6] == 2 || arrayChangePoint3 [counter2*7+6] == 5){
                                    arrayChangePoint4 [changePointCount4] = arrayChangePoint3 [counter2*7], changePointCount4++;
                                    arrayChangePoint4 [changePointCount4] = arrayChangePoint3 [counter2*7+1], changePointCount4++;
                                    arrayChangePoint4 [changePointCount4] = arrayChangePoint3 [counter2*7+2], changePointCount4++;
                                    arrayChangePoint4 [changePointCount4] = arrayChangePoint3 [counter2*7+3], changePointCount4++;
                                    arrayChangePoint4 [changePointCount4] = arrayChangePoint3 [counter2*7+4], changePointCount4++;
                                    arrayChangePoint4 [changePointCount4] = arrayChangePoint3 [counter2*7+5], changePointCount4++;
                                    arrayChangePoint4 [changePointCount4] = 0, changePointCount4++;
                                }
                            }
                            
                            //------Find Two set of IN/OUT then check whether gap exist. If this is the case, reset In /Out in a way to segment the gap------
                            if (changePointCount4/7 != 0){
                                if (changePointCount4/7 > 1){
                                    for (int counter2 = 0; counter2 < linkedLineSourceCount/3-1; counter2++){
                                        valueTempCurrent = 0;
                                        valueTempNext = 0;
                                        valueTempCurrent2 = 0;
                                        valueTempNext2 = 0;
                                        valueTempXNext = 0;
                                        valueTempYNext = 0;
                                        
                                        for (int counter3 = 0; counter3 < changePointCount4/7; counter3++){
                                            if (arrayChangePoint4 [counter3*7+6] == 0){
                                                if (arrayLinkedLineSource [counter2*3] == arrayChangePoint4 [counter3*7] && arrayLinkedLineSource [counter2*3+1] == arrayChangePoint4 [counter3*7+1]){
                                                    valueTempCurrent = counter3;
                                                    valueTempNext = 1;
                                                    valueTempXNext = arrayChangePoint4 [counter3*7+3];
                                                    valueTempYNext = arrayChangePoint4 [counter3*7+4];
                                                }
                                                
                                                if (arrayLinkedLineSource [counter2*3] == arrayChangePoint4 [counter3*7+3] && arrayLinkedLineSource [counter2*3+1] == arrayChangePoint4 [counter3*7+4]){
                                                    valueTempCurrent = counter3;
                                                    valueTempNext = 2;
                                                    valueTempXNext = arrayChangePoint4 [counter3*7];
                                                    valueTempYNext = arrayChangePoint4 [counter3*7+1];
                                                }
                                            }
                                        }
                                        
                                        if (valueTempXNext != 0){
                                            breakFlag = 0;
                                            
                                            for (int counter3 = counter2+1; counter3 < linkedLineSourceCount/3; counter3++){
                                                if (arrayLinkedLineSource [counter3*3] == valueTempXNext && arrayLinkedLineSource [counter3*3+1] == valueTempYNext){
                                                    arrayChangePoint4 [valueTempCurrent*7+6] = 1;
                                                    break;
                                                }
                                                else{
                                                    
                                                    for (int counter4 = 0; counter4 < changePointCount4/7; counter4++){
                                                        if (arrayChangePoint4 [counter4*7+6] == 0){
                                                            if (arrayLinkedLineSource [counter3*3] == arrayChangePoint4 [counter4*7] && arrayLinkedLineSource [counter3*3+1] == arrayChangePoint4 [counter4*7+1]){
                                                                valueTempCurrent2 = counter4;
                                                                valueTempNext2 = 1;
                                                                breakFlag = 1;
                                                                break;
                                                            }
                                                            
                                                            if (arrayLinkedLineSource [counter3*3] == arrayChangePoint4 [counter4*7+3] && arrayLinkedLineSource [counter3*3+1] == arrayChangePoint4 [counter4*7+4]){
                                                                valueTempCurrent2 = counter4;
                                                                valueTempNext2 = 2;
                                                                breakFlag = 1;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (breakFlag == 1){
                                                        break;
                                                    }
                                                }
                                            }
                                            
                                            if (breakFlag == 1){
                                                if (valueTempNext == 1 && valueTempNext2 == 1){
                                                    lengthA = arrayChangePoint4 [valueTempCurrent2*7+2]-arrayChangePoint4 [valueTempCurrent*7+2];
                                                    lengthB = arrayChangePoint4 [valueTempCurrent*7+5]-arrayChangePoint4 [valueTempCurrent2*7+5];
                                                    
                                                    if (lengthA > lengthB*4){
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7+1], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7+2], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7+1], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7+2], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = 5, changePointCount4++;
                                                        
                                                        arrayChangePoint4 [valueTempCurrent*7+6] = 2;
                                                        arrayChangePoint4 [valueTempCurrent2*7+6] = 2;
                                                    }
                                                    else if (lengthB > lengthA*4){
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7+3], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7+4], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7+5], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7+3], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7+4], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7+5], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = 5, changePointCount4++;
                                                        
                                                        arrayChangePoint4 [valueTempCurrent*7+6] = 2;
                                                        arrayChangePoint4 [valueTempCurrent2*7+6] = 2;
                                                    }
                                                    else arrayChangePoint4 [valueTempCurrent*7+6] = 1;
                                                }
                                                
                                                if (valueTempNext == 1 && valueTempNext2 == 2){
                                                    lengthA = arrayChangePoint4 [valueTempCurrent2*7+5]-arrayChangePoint4 [valueTempCurrent*7+2];
                                                    lengthB = arrayChangePoint4 [valueTempCurrent*7+5]-arrayChangePoint4 [valueTempCurrent2*7+2];
                                                    
                                                    if (lengthA > lengthB*4){
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7+3], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7+4], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7+5], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7+1], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7+2], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = 5, changePointCount4++;
                                                        
                                                        arrayChangePoint4 [valueTempCurrent*7+6] = 2;
                                                        arrayChangePoint4 [valueTempCurrent2*7+6] = 2;
                                                    }
                                                    else if (lengthB > lengthA*4){
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7+1], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7+2], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7+3], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7+4], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7+5], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = 5, changePointCount4++;
                                                        
                                                        arrayChangePoint4 [valueTempCurrent*7+6] = 2;
                                                        arrayChangePoint4 [valueTempCurrent2*7+6] = 2;
                                                    }
                                                    else arrayChangePoint4 [valueTempCurrent*7+6] = 1;
                                                }
                                                
                                                if (valueTempNext == 2 && valueTempNext2 == 1){
                                                    lengthA = arrayChangePoint4 [valueTempCurrent2*7+2]-arrayChangePoint4 [valueTempCurrent*7+5];
                                                    lengthB = arrayChangePoint4 [valueTempCurrent*7+2]-arrayChangePoint4 [valueTempCurrent2*7+5];
                                                    
                                                    if (lengthA > lengthB*4){
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7+1], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7+2], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7+3], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7+4], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7+5], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = 5, changePointCount4++;
                                                        
                                                        arrayChangePoint4 [valueTempCurrent*7+6] = 2;
                                                        arrayChangePoint4 [valueTempCurrent2*7+6] = 2;
                                                    }
                                                    else if (lengthB > lengthA*4){
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7+3], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7+4], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7+5], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7+1], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7+2], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = 5, changePointCount4++;
                                                        
                                                        arrayChangePoint4 [valueTempCurrent*7+6] = 2;
                                                        arrayChangePoint4 [valueTempCurrent2*7+6] = 2;
                                                    }
                                                    else arrayChangePoint4 [valueTempCurrent*7+6] = 1;
                                                }
                                                
                                                if (valueTempNext == 2 && valueTempNext2 == 2){
                                                    lengthA = arrayChangePoint4 [valueTempCurrent2*7+5]-arrayChangePoint4 [valueTempCurrent*7+5];
                                                    lengthB = arrayChangePoint4 [valueTempCurrent*7+2]-arrayChangePoint4 [valueTempCurrent2*7+2];
                                                    
                                                    if (lengthA > lengthB*4){
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7+3], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7+4], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7+5], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7+3], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7+4], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7+5], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = 5, changePointCount4++;
                                                        
                                                        arrayChangePoint4 [valueTempCurrent*7+6] = 2;
                                                        arrayChangePoint4 [valueTempCurrent2*7+6] = 2;
                                                    }
                                                    else if (lengthB > lengthA*4){
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7+1], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent2*7+2], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7+1], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = arrayChangePoint4 [valueTempCurrent*7+2], changePointCount4++;
                                                        arrayChangePoint4 [changePointCount4] = 5, changePointCount4++;
                                                        
                                                        arrayChangePoint4 [valueTempCurrent*7+6] = 2;
                                                        arrayChangePoint4 [valueTempCurrent2*7+6] = 2;
                                                    }
                                                    else arrayChangePoint4 [valueTempCurrent*7+6] = 1;
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                //------Remove point, which create short loops------
                                int *arrayChangePoint5 = new int [changePointCount4*3+50], changePointCount5 = 0;
                                
                                for (int counter2 = 0; counter2 < changePointCount4/7; counter2++){
                                    if (arrayChangePoint4 [counter2*7+6] == 0 || arrayChangePoint4 [counter2*7+6] == 1 || arrayChangePoint4 [counter2*7+6] == 5){
                                        arrayChangePoint5 [changePointCount5] = arrayChangePoint4 [counter2*7], changePointCount5++;
                                        arrayChangePoint5 [changePointCount5] = arrayChangePoint4 [counter2*7+1], changePointCount5++;
                                        arrayChangePoint5 [changePointCount5] = arrayChangePoint4 [counter2*7+2], changePointCount5++;
                                        arrayChangePoint5 [changePointCount5] = arrayChangePoint4 [counter2*7+3], changePointCount5++;
                                        arrayChangePoint5 [changePointCount5] = arrayChangePoint4 [counter2*7+4], changePointCount5++;
                                        arrayChangePoint5 [changePointCount5] = arrayChangePoint4 [counter2*7+5], changePointCount5++;
                                        
                                        if (arrayChangePoint4 [counter2*7+6] == 5) arrayChangePoint5 [changePointCount5] = 5, changePointCount5++;
                                        else arrayChangePoint5 [changePointCount5] = 0, changePointCount5++;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < changePointCount5/7; counterA++){
                                //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayChangePoint5 [counterA*7+counterB];
                                //    cout<<" arrayChangePoint5 "<<counterA<<endl;
                                //}
                                
                                if (changePointCount5/7 != 0){
                                    for (int counter2 = 0; counter2 < changePointCount5/7; counter2++){
                                        if (arrayChangePoint5 [counter2*7+6] != 5){
                                            totalLoopLength = linkedLineSourceCount/3;
                                            loopLengthA = arrayChangePoint5 [counter2*7+5]-arrayChangePoint5 [counter2*7+2];
                                            loopLengthB = arrayChangePoint5 [counter2*7+2]+totalLoopLength-arrayChangePoint5 [counter2*7+5];
                                            
                                            if (totalLoopLength < 50) arrayChangePoint5 [counter2*7+6] = 1;
                                            else{
                                                
                                                if (loopLengthA > loopLengthB) loopDirection = 1;
                                                else loopDirection = 2;
                                                
                                                inShortest = 10000;
                                                inShortestCount = -1;
                                                outShortest = 10000;
                                                outShortestCount = -1;
                                                
                                                if (loopDirection == 1){
                                                    if (arrayChangePoint5 [counter2*7+2]+7 > linkedLineSourceCount/3-1){
                                                        for (int counter3 = arrayChangePoint5 [counter2*7+2]; counter3 < linkedLineSourceCount/3; counter3++){
                                                            distanceTemp1 = sqrt((arrayChangePoint5 [counter2*7+3]-arrayLinkedLineSource [counter3*3])*(arrayChangePoint5 [counter2*7+3]-arrayLinkedLineSource [counter3*3])+(arrayChangePoint5 [counter2*7+4]-arrayLinkedLineSource [counter3*3+1])*(arrayChangePoint5 [counter2*7+4]-arrayLinkedLineSource [counter3*3+1]));
                                                            
                                                            if (inShortest > distanceTemp1){
                                                                inShortest = distanceTemp1;
                                                                inShortestCount = counter3;
                                                                valueTempXL2 = arrayLinkedLineSource [counter3*3];
                                                                valueTempYL2 = arrayLinkedLineSource [counter3*3+1];
                                                            }
                                                        }
                                                        
                                                        for (int counter3 = 0; counter3 < arrayChangePoint5 [counter2*7+2]+7-(linkedLineSourceCount/3-1); counter3++){
                                                            distanceTemp1 = sqrt((arrayChangePoint5 [counter2*7+3]-arrayLinkedLineSource [counter3*3])*(arrayChangePoint5 [counter2*7+3]-arrayLinkedLineSource [counter3*3])+(arrayChangePoint5 [counter2*7+4]-arrayLinkedLineSource [counter3*3+1])*(arrayChangePoint5 [counter2*7+4]-arrayLinkedLineSource [counter3*3+1]));
                                                            
                                                            if (inShortest > distanceTemp1){
                                                                inShortest = distanceTemp1;
                                                                inShortestCount = counter3;
                                                                valueTempXL2 = arrayLinkedLineSource [counter3*3];
                                                                valueTempYL2 = arrayLinkedLineSource [counter3*3+1];
                                                            }
                                                        }
                                                    }
                                                    else{
                                                        
                                                        for (int counter3 = arrayChangePoint5 [counter2*7+2]; counter3 <= arrayChangePoint5 [counter2*7+2]+7; counter3++){
                                                            distanceTemp1 = sqrt((arrayChangePoint5 [counter2*7+3]-arrayLinkedLineSource [counter3*3])*(arrayChangePoint5 [counter2*7+3]-arrayLinkedLineSource [counter3*3])+(arrayChangePoint5 [counter2*7+4]-arrayLinkedLineSource [counter3*3+1])*(arrayChangePoint5 [counter2*7+4]-arrayLinkedLineSource [counter3*3+1]));
                                                            
                                                            if (inShortest > distanceTemp1){
                                                                inShortest = distanceTemp1;
                                                                inShortestCount = counter3;
                                                                valueTempXL2 = arrayLinkedLineSource [counter3*3];
                                                                valueTempYL2 = arrayLinkedLineSource [counter3*3+1];
                                                            }
                                                        }
                                                    }
                                                    if (arrayChangePoint5 [counter2*7+5]-7 < 0){
                                                        for (int counter3 = linkedLineSourceCount/3-1+(arrayChangePoint5 [counter2*7+5]-7); counter3 < linkedLineSourceCount/3; counter3++){
                                                            distanceTemp1 = sqrt((arrayChangePoint5 [counter2*7]-arrayLinkedLineSource [counter3*3])*(arrayChangePoint5 [counter2*7]-arrayLinkedLineSource [counter3*3])+(arrayChangePoint5 [counter2*7+1]-arrayLinkedLineSource [counter3*3+1])*(arrayChangePoint5 [counter2*7+1]-arrayLinkedLineSource [counter3*3+1]));
                                                            
                                                            if (outShortest > distanceTemp1){
                                                                outShortest = distanceTemp1;
                                                                outShortestCount = counter3;
                                                                valueTempXL3 = arrayLinkedLineSource [counter3*3];
                                                                valueTempYL3 = arrayLinkedLineSource [counter3*3+1];
                                                            }
                                                        }
                                                        
                                                        for (int counter3 = 0; counter3 <= arrayChangePoint5 [counter2*7+5]; counter3++){
                                                            distanceTemp1 = sqrt((arrayChangePoint5 [counter2*7]-arrayLinkedLineSource [counter3*3])*(arrayChangePoint5 [counter2*7]-arrayLinkedLineSource [counter3*3])+(arrayChangePoint5 [counter2*7+1]-arrayLinkedLineSource [counter3*3+1])*(arrayChangePoint5 [counter2*7+1]-arrayLinkedLineSource [counter3*3+1]));
                                                            
                                                            if (outShortest > distanceTemp1){
                                                                outShortest = distanceTemp1;
                                                                outShortestCount = counter3;
                                                                valueTempXL3 = arrayLinkedLineSource [counter3*3];
                                                                valueTempYL3 = arrayLinkedLineSource [counter3*3+1];
                                                            }
                                                        }
                                                    }
                                                    else{
                                                        
                                                        for (int counter3 = arrayChangePoint5 [counter2*7+5]-7; counter3 <= arrayChangePoint5 [counter2*7+5]; counter3++){
                                                            distanceTemp1 = sqrt((arrayChangePoint5 [counter2*7]-arrayLinkedLineSource [counter3*3])*(arrayChangePoint5 [counter2*7]-arrayLinkedLineSource [counter3*3])+(arrayChangePoint5 [counter2*7+1]-arrayLinkedLineSource [counter3*3+1])*(arrayChangePoint5 [counter2*7+1]-arrayLinkedLineSource [counter3*3+1]));
                                                            
                                                            if (outShortest > distanceTemp1){
                                                                outShortest = distanceTemp1;
                                                                outShortestCount = counter3;
                                                                valueTempXL3 = arrayLinkedLineSource [counter3*3];
                                                                valueTempYL3 = arrayLinkedLineSource [counter3*3+1];
                                                            }
                                                        }
                                                    }
                                                }
                                                if (loopDirection == 2){
                                                    if (arrayChangePoint5 [counter2*7+2]-7 < 0){
                                                        for (int counter3 = linkedLineSourceCount/3+(arrayChangePoint5 [counter2*7+2]-7); counter3 < linkedLineSourceCount/3; counter3++){
                                                            distanceTemp1 = sqrt((arrayChangePoint5 [counter2*7+3]-arrayLinkedLineSource [counter3*3])*(arrayChangePoint5 [counter2*7+3]-arrayLinkedLineSource [counter3*3])+(arrayChangePoint5 [counter2*7+4]-arrayLinkedLineSource [counter3*3+1])*(arrayChangePoint5 [counter2*7+4]-arrayLinkedLineSource [counter3*3+1]));
                                                            
                                                            if (inShortest > distanceTemp1){
                                                                inShortest = distanceTemp1;
                                                                inShortestCount = counter3;
                                                                valueTempXL2 = arrayLinkedLineSource [counter3*3];
                                                                valueTempYL2 = arrayLinkedLineSource [counter3*3+1];
                                                            }
                                                        }
                                                        
                                                        for (int counter3 = 0; counter3 <= arrayChangePoint5 [counter2*7+2]; counter3++){
                                                            distanceTemp1 = sqrt((arrayChangePoint5 [counter2*7+3]-arrayLinkedLineSource [counter3*3])*(arrayChangePoint5 [counter2*7+3]-arrayLinkedLineSource [counter3*3])+(arrayChangePoint5 [counter2*7+4]-arrayLinkedLineSource [counter3*3+1])*(arrayChangePoint5 [counter2*7+4]-arrayLinkedLineSource [counter3*3+1]));
                                                            
                                                            if (inShortest > distanceTemp1){
                                                                inShortest = distanceTemp1;
                                                                inShortestCount = counter3;
                                                                valueTempXL2 = arrayLinkedLineSource [counter3*3];
                                                                valueTempYL2 = arrayLinkedLineSource [counter3*3+1];
                                                            }
                                                        }
                                                    }
                                                    else{
                                                        
                                                        for (int counter3 = arrayChangePoint5 [counter2*7+2]-7; counter3 <= arrayChangePoint5 [counter2*7+2]; counter3++){
                                                            distanceTemp1 = sqrt((arrayChangePoint5 [counter2*7+3]-arrayLinkedLineSource [counter3*3])*(arrayChangePoint5 [counter2*7+3]-arrayLinkedLineSource [counter3*3])+(arrayChangePoint5 [counter2*7+4]-arrayLinkedLineSource [counter3*3+1])*(arrayChangePoint5 [counter2*7+4]-arrayLinkedLineSource [counter3*3+1]));
                                                            
                                                            if (inShortest > distanceTemp1){
                                                                inShortest = distanceTemp1;
                                                                inShortestCount = counter3;
                                                                valueTempXL2 = arrayLinkedLineSource [counter3*3];
                                                                valueTempYL2 = arrayLinkedLineSource [counter3*3+1];
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (arrayChangePoint5 [counter2*7+5]+7 > linkedLineSourceCount/3-1){
                                                        for (int counter3 = arrayChangePoint5 [counter2*7+5]; counter3 < linkedLineSourceCount/3; counter3++){
                                                            distanceTemp1 = sqrt((arrayChangePoint5 [counter2*7]-arrayLinkedLineSource [counter3*3])*(arrayChangePoint5 [counter2*7]-arrayLinkedLineSource [counter3*3])+(arrayChangePoint5 [counter2*7+1]-arrayLinkedLineSource [counter3*3+1])*(arrayChangePoint5 [counter2*7+1]-arrayLinkedLineSource [counter3*3+1]));
                                                            
                                                            if (outShortest > distanceTemp1){
                                                                outShortest = distanceTemp1;
                                                                outShortestCount = counter3;
                                                                valueTempXL3 = arrayLinkedLineSource [counter3*3];
                                                                valueTempYL3 = arrayLinkedLineSource [counter3*3+1];
                                                            }
                                                        }
                                                        
                                                        for (int counter3 = 0; counter3 <= arrayChangePoint5 [counter2*7+5]+7-(linkedLineSourceCount/3-1); counter3++){
                                                            distanceTemp1 = sqrt((arrayChangePoint5 [counter2*7]-arrayLinkedLineSource [counter3*3])*(arrayChangePoint5 [counter2*7]-arrayLinkedLineSource [counter3*3])+(arrayChangePoint5 [counter2*7+1]-arrayLinkedLineSource [counter3*3+1])*(arrayChangePoint5 [counter2*7+1]-arrayLinkedLineSource [counter3*3+1]));
                                                            
                                                            if (outShortest > distanceTemp1){
                                                                outShortest = distanceTemp1;
                                                                outShortestCount = counter3;
                                                                valueTempXL3 = arrayLinkedLineSource [counter3*3];
                                                                valueTempYL3 = arrayLinkedLineSource [counter3*3+1];
                                                            }
                                                        }
                                                    }
                                                    else{
                                                        
                                                        for (int counter3 = arrayChangePoint5 [counter2*7+5]; counter3 <= arrayChangePoint5 [counter2*7+5]+7; counter3++){
                                                            distanceTemp1 = sqrt((arrayChangePoint5 [counter2*7]-arrayLinkedLineSource [counter3*3])*(arrayChangePoint5 [counter2*7]-arrayLinkedLineSource [counter3*3])+(arrayChangePoint5 [counter2*7+1]-arrayLinkedLineSource [counter3*3+1])*(arrayChangePoint5 [counter2*7+1]-arrayLinkedLineSource [counter3*3+1]));
                                                            
                                                            if (outShortest > distanceTemp1){
                                                                outShortest = distanceTemp1;
                                                                outShortestCount = counter3;
                                                                valueTempXL3 = arrayLinkedLineSource [counter3*3];
                                                                valueTempYL3 = arrayLinkedLineSource [counter3*3+1];
                                                            }
                                                        }
                                                    }
                                                }
                                                
                                                if (inShortest < outShortest){
                                                    loopLengthA2 = arrayChangePoint5 [counter2*7+5]-inShortestCount;
                                                    loopLengthB2 = inShortestCount+totalLoopLength-arrayChangePoint5 [counter2*7+5];
                                                    
                                                    if (loopLengthA2 < 15 || loopLengthB2 < 15) arrayChangePoint5 [counter2*7+6] = 1;
                                                    else{
                                                        
                                                        arrayChangePoint5 [counter2*7] = valueTempXL2;
                                                        arrayChangePoint5 [counter2*7+1] = valueTempYL2;
                                                        arrayChangePoint5 [counter2*7+2] = inShortestCount;
                                                        arrayChangePoint5 [counter2*7+3] = arrayChangePoint5 [counter2*7+3];
                                                        arrayChangePoint5 [counter2*7+4] = arrayChangePoint5 [counter2*7+4];
                                                        arrayChangePoint5 [counter2*7+5] = arrayChangePoint5 [counter2*7+5];
                                                        arrayChangePoint5 [changePointCount5] = 0, changePointCount5++;
                                                    }
                                                }
                                                
                                                if (inShortest >= outShortest){
                                                    loopLengthA2 = outShortestCount-arrayChangePoint5 [counter2*7+2];
                                                    loopLengthB2 = arrayChangePoint5 [counter2*7+2]+totalLoopLength-outShortestCount;
                                                    
                                                    if (loopLengthA2 < 15 || loopLengthB2 < 15) arrayChangePoint5 [counter2*7+6] = 1;
                                                    else{
                                                        
                                                        arrayChangePoint5 [counter2*7] = arrayChangePoint5 [counter2*7];
                                                        arrayChangePoint5 [counter2*7+1] = arrayChangePoint5 [counter2*7+1];
                                                        arrayChangePoint5 [counter2*7+2] = arrayChangePoint5 [counter2*7+2];
                                                        arrayChangePoint5 [counter2*7+3] = valueTempXL3;
                                                        arrayChangePoint5 [counter2*7+4] = valueTempYL3;
                                                        arrayChangePoint5 [counter2*7+5] = outShortestCount;
                                                        arrayChangePoint5 [changePointCount5] = 0, changePointCount5++;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
                                    // for (int counterA = 0; counterA < changePointCount5/7; counterA++){
                                    //     for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayChangePoint5 [counterA*7+counterB];
                                    //     cout<<" arrayChangePoint5 "<<counterA<<endl;
                                    //}
                                    
                                    int *arrayChangePoint6 = new int [changePointCount5+50], changePointCount6 = 0;
                                    
                                    for (int counter2 = 0; counter2 < changePointCount5/7; counter2++){
                                        if (arrayChangePoint5 [counter2*7+6] == 0 || arrayChangePoint5 [counter2*7+6] == 5){
                                            arrayChangePoint6 [changePointCount6] = arrayChangePoint5 [counter2*7], changePointCount6++;
                                            arrayChangePoint6 [changePointCount6] = arrayChangePoint5 [counter2*7+1], changePointCount6++;
                                            arrayChangePoint6 [changePointCount6] = arrayChangePoint5 [counter2*7+2], changePointCount6++;
                                            arrayChangePoint6 [changePointCount6] = arrayChangePoint5 [counter2*7+3], changePointCount6++;
                                            arrayChangePoint6 [changePointCount6] = arrayChangePoint5 [counter2*7+4], changePointCount6++;
                                            arrayChangePoint6 [changePointCount6] = arrayChangePoint5 [counter2*7+5], changePointCount6++;
                                            
                                            if (arrayChangePoint5 [counter2*7+6] == 5) arrayChangePoint6 [changePointCount6] = 5, changePointCount6++;
                                            else arrayChangePoint6 [changePointCount6] = 0, changePointCount6++;
                                        }
                                    }
                                    
                                    //------Check whether In/Out line could create two individual connect groups, First carry out Connect analysis------
                                    //------Then overlay A200, A220 and A240. If process Type 1 and all connect groups are disappeared by A220,------
                                    //------Remove In/Out line. If two connect groups appear, goto A220. If process Type is 2/3/4/5, start from------
                                    //------either A220 or 240. In connect groups are not separated by A240, keep the IN/OUT line------
                                    
                                    if (changePointCount6/7 != 0){
                                        unCutStatus = 0;
                                        
                                        for (int counter2 = 0; counter2 < changePointCount6/7; counter2++){
                                            valueTempXL2 = arrayChangePoint6 [counter2*7]-horizontalStart;
                                            valueTempYL2 = arrayChangePoint6 [counter2*7+1]-verticalStart;
                                            valueTempXL3 = arrayChangePoint6 [counter2*7+3]-horizontalStart;
                                            valueTempYL3 = arrayChangePoint6 [counter2*7+4]-verticalStart;
                                            
                                            if (valueTempXL2 < 0) valueTempXL2 = 0;
                                            else if (valueTempXL2 >= dimension) valueTempXL2 = dimension-1;
                                            
                                            if (valueTempYL2 < 0) valueTempYL2 = 0;
                                            else if (valueTempYL2 >= dimension) valueTempYL2 = dimension-1;
                                            
                                            if (valueTempXL3 < 0) valueTempXL3 = 0;
                                            else if (valueTempXL3 >= dimension) valueTempXL3 = dimension-1;
                                            
                                            if (valueTempYL3 < 0) valueTempYL3 = 0;
                                            else if (valueTempYL3 >= dimension) valueTempYL3 = dimension-1;
                                            
                                            int **cutMatrix2 = new int *[dimension+4];
                                            for (int counter3 = 0; counter3 < dimension+4; counter3++) cutMatrix2 [counter3] = new int [dimension+4];
                                            
                                            for (int counterY = 0; counterY < dimension; counterY++){
                                                for (int counterX = 0; counterX < dimension; counterX++){
                                                    cutMatrix2 [counterY][counterX] = combinedMatrixA2 [counterY][counterX]*-1;
                                                }
                                            }
                                            
                                            cutMatrix2 [valueTempYL2][valueTempXL2] = 0;
                                            cutMatrix2 [valueTempYL3][valueTempXL3] = 0;
                                            
                                            gapFill = [[GapFill alloc] init];
                                            [gapFill gapFilling:valueTempXL2:valueTempYL2:valueTempXL3:valueTempYL3];
                                            
                                            for (int counter3 = 0; counter3 < gapDataCount/2; counter3++){
                                                cutMatrix2 [arrayGapData [counter3*2+1]][arrayGapData [counter3*2]] = 0;
                                            }
                                            
                                            connectAnalysisX = new int [dimension*4];
                                            connectAnalysisY = new int [dimension*4];
                                            connectAnalysisTempX = new int [dimension*4];
                                            connectAnalysisTempY = new int [dimension*4];
                                            
                                            connectivityNumber = 0;
                                            
                                            for (int counterY = 0; counterY < dimension; counterY++){
                                                for (int counterX = 0; counterX < dimension; counterX++){
                                                    if (cutMatrix2 [counterY][counterX] < 0){
                                                        connectivityNumber++;
                                                        cutMatrix2 [counterY][counterX] = connectivityNumber;
                                                        connectAnalysisCount = 0;
                                                        
                                                        if (counterY-1 >= 0 && cutMatrix2 [counterY-1][counterX] < 0){
                                                            cutMatrix2 [counterY-1][counterX] = connectivityNumber;
                                                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                        }
                                                        if (counterX+1 < dimension && cutMatrix2 [counterY][counterX+1] < 0){
                                                            cutMatrix2 [counterY][counterX+1] = connectivityNumber;
                                                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                        }
                                                        if (counterY+1 < dimension && cutMatrix2 [counterY+1][counterX] < 0){
                                                            cutMatrix2 [counterY+1][counterX] = connectivityNumber;
                                                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                        }
                                                        if (counterX-1 >= 0 && cutMatrix2 [counterY][counterX-1] < 0){
                                                            cutMatrix2 [counterY][counterX-1] = connectivityNumber;
                                                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                        }
                                                        
                                                        if (connectAnalysisCount != 0){
                                                            do{
                                                                
                                                                terminationFlag = 1;
                                                                connectAnalysisTempCount = 0;
                                                                
                                                                for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                                    xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                                    
                                                                    if (ySource-1 >= 0 && cutMatrix2 [ySource-1][xSource] < 0){
                                                                        cutMatrix2 [ySource-1][xSource] = connectivityNumber;
                                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                    }
                                                                    if (xSource+1 < dimension && cutMatrix2 [ySource][xSource+1] < 0){
                                                                        cutMatrix2 [ySource][xSource+1] = connectivityNumber;
                                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                    }
                                                                    if (ySource+1 < dimension && cutMatrix2 [ySource+1][xSource] < 0){
                                                                        cutMatrix2 [ySource+1][xSource] = connectivityNumber;
                                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                    }
                                                                    if (xSource-1 >= 0 && cutMatrix2 [ySource][xSource-1] < 0){
                                                                        cutMatrix2 [ySource][xSource-1] = connectivityNumber;
                                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                    }
                                                                }
                                                                
                                                                for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                                    connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                                                }
                                                                
                                                                connectAnalysisCount = connectAnalysisTempCount;
                                                                
                                                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                                                
                                                            } while (terminationFlag == 1);
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            delete [] connectAnalysisX;
                                            delete [] connectAnalysisY;
                                            delete [] connectAnalysisTempX;
                                            delete [] connectAnalysisTempY;
                                            
                                            int *connectMatch = new int [connectivityNumber+4];
                                            
                                            for (int counter3 = 0; counter3 < connectivityNumber+1; counter3++) connectMatch [counter3] = 0;
                                            
                                            for (int counterY = 0; counterY < dimension; counterY++){
                                                for (int counterX = 0; counterX < dimension; counterX++){
                                                    if (cutMatrix2 [counterY][counterX] != 0) connectMatch [cutMatrix2 [counterY][counterX]]++;
                                                }
                                            }
                                            
                                            numberOfConnectivityGroup = 0;
                                            
                                            for (int counter3 = 1; counter3 < connectivityNumber+1; counter3++){
                                                if (connectMatch [counter3] != 0) numberOfConnectivityGroup++;
                                            }
                                            
                                            vectorNumberMatchCount = 0;
                                            int *connectMatch2 = new int [connectivityNumber+1];
                                            
                                            for (int counter3 = 1; counter3 < connectivityNumber+1; counter3++) connectMatch2 [counter3] = 0;
                                            
                                            for (int counter3 = 1; counter3 < connectivityNumber+1; counter3++){
                                                if (connectMatch [counter3] != 0) connectMatch2 [vectorNumberMatchCount] = counter3, vectorNumberMatchCount++;
                                            }
                                            
                                            delete [] connectMatch;
                                            
                                            if (arrayChangePoint6 [counter2*7+6] == 5){
                                                int *totalPoint = new int [vectorNumberMatchCount+4];
                                                double *averageValue = new double [vectorNumberMatchCount+4];
                                                
                                                for (int counter3 = 0; counter3 < vectorNumberMatchCount; counter3++){
                                                    totalPoint [counter3] = 0;
                                                    averageValue [counter3] = 0;
                                                }
                                                
                                                for (int counterY = 0; counterY < dimension; counterY++){
                                                    for (int counterX = 0; counterX < dimension; counterX++){
                                                        if (cutMatrix2 [counterY][counterX] != 0){
                                                            matchCorrespond = 0;
                                                            
                                                            for (int counter3 = 0; counter3 < vectorNumberMatchCount; counter3++){
                                                                if (connectMatch2 [counter3] == cutMatrix2 [counterY][counterX]){
                                                                    matchCorrespond = counter3;
                                                                    break;
                                                                }
                                                            }
                                                            
                                                            totalPoint [matchCorrespond]++;
                                                            
                                                            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageWidth && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageWidth){
                                                                averageValue [matchCorrespond] = averageValue [matchCorrespond]+arrayExtractedImage [counterY+verticalStart][counterX+horizontalStart];
                                                            }
                                                        }
                                                    }
                                                }
                                                
                                                for (int counter3 = 0; counter3 < vectorNumberMatchCount; counter3++){
                                                    if (totalPoint [counter3] != 0) averageValue [counter3] = averageValue [counter3]/(double)totalPoint [counter3];
                                                    else averageValue [counter3] = 0;
                                                }
                                                
                                                eliminationFlag = 0;
                                                noZeroFlag = 0;
                                                
                                                for (int counter3 = 0; counter3 < vectorNumberMatchCount; counter3++){
                                                    if (totalPoint [counter3] < 50) noZeroFlag = 1;
                                                }
                                                
                                                if (noZeroFlag == 1) eliminationFlag = 1;
                                                else if (vectorNumberMatchCount != 2) eliminationFlag = 1;
                                                else if (totalPoint [0] > totalPoint [1]){
                                                    if (averageValue [1] < 200) eliminationFlag = 1;
                                                }
                                                
                                                if (totalPoint [0] < totalPoint [1]){
                                                    if (averageValue [0] < 200) eliminationFlag = 1;
                                                }
                                                
                                                if (eliminationFlag == 1) arrayChangePoint6 [counter2*7+6] = 1;
                                                else arrayChangePoint6 [counter2*7+6] = 5;
                                                
                                                delete [] totalPoint;
                                                delete [] averageValue;
                                            }
                                            else if (numberOfConnectivityGroup != 2) arrayChangePoint6 [counter2*7+6] = 1;
                                            else{
                                                
                                                eliminationFlag = 0;
                                                
                                                if (processType == 1 || (processType == 2 && startEndPosition [counter1][2] == 1) || (processType == 5 && startEndPosition [counter1][2] == 1)){
                                                    int **pixNumberCount200 = new int *[3];
                                                    for (int counter3 = 0; counter3 < 3; counter3++) pixNumberCount200 [counter3] = new int [vectorNumberGroupA1+4];
                                                    
                                                    for (int counter3 = 0; counter3 < 2; counter3++){
                                                        for (int counter4 = 0; counter4 < vectorNumberGroupA1; counter4++) pixNumberCount200 [counter3][counter4] = 0;
                                                    }
                                                    
                                                    for (int counterY = 0; counterY < dimension; counterY++){
                                                        for (int counterX = 0; counterX < dimension; counterX++){
                                                            if (cutMatrix2 [counterY][counterX] != 0){
                                                                if (connectMatch2 [0] == cutMatrix2 [counterY][counterX]) cutEnter = 0;
                                                                else cutEnter = 1;
                                                                
                                                                if (vectorSourceA1 [counterY][counterX] != 0){
                                                                    vectorNumberMatchEnter = 0;
                                                                    
                                                                    for (int counter3 = 0; counter3 < vectorNumberGroupA1; counter3++){
                                                                        if (vectorNumberMatchA1 [counter3] == vectorSourceA1 [counterY][counterX]) vectorNumberMatchEnter = counter3;
                                                                    }
                                                                    
                                                                    pixNumberCount200 [cutEnter][vectorNumberMatchEnter]++;
                                                                }
                                                            }
                                                        }
                                                    }
                                                    
                                                    noZeroFind1 = 0;
                                                    noZeroFind2 = 0;
                                                    noZeroFind3 = 0;
                                                    
                                                    for (int counter3 = 0; counter3 < vectorNumberGroupA1; counter3++){
                                                        if (pixNumberCount200 [0][counter3] >= 10) noZeroFind1 = 1;
                                                        
                                                        if (pixNumberCount200 [1][counter3] >= 10) noZeroFind2 = 1;
                                                        
                                                        if (pixNumberCount200 [0][counter3] >= 10 && pixNumberCount200 [1][counter3] >= 10) noZeroFind3 = 1;
                                                    }
                                                    
                                                    if (noZeroFind1 == 0 || noZeroFind2 == 0) eliminationFlag = 1;
                                                    else if (noZeroFind3 == 1) eliminationFlag = 2;
                                                    else{
                                                        
                                                        noZeroFind1 = 0;
                                                        
                                                        for (int counter3 = 0; counter3 < vectorNumberGroupA1; counter3++){
                                                            if (pixNumberCount200 [0][counter3] >= 10){
                                                                for (int counter4 = 0; counter4 < vectorNumberGroupA1; counter4++){
                                                                    if (counter3 != counter4){
                                                                        if (pixNumberCount200 [1][counter4] >= 10) noZeroFind1 = 1;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        
                                                        if (noZeroFind1 == 1) eliminationFlag = 5;
                                                    }
                                                    
                                                    for (int counter3 = 0; counter3 < 3; counter3++) delete [] pixNumberCount200 [counter3];
                                                    delete [] pixNumberCount200;
                                                }
                                                
                                                if (eliminationFlag == 1) arrayChangePoint6 [counter2*7+6] = 1;
                                                
                                                eliminationFlag2 = 0;
                                                
                                                if (processType == 3 || (processType == 2 && startEndPosition [counter1][2] == 2) || eliminationFlag == 2 || eliminationFlag == 5){
                                                    int **pixNumberCount220 = new int *[3];
                                                    for (int counter3 = 0; counter3 < 3; counter3++) pixNumberCount220 [counter3] = new int [vectorNumberGroupB1+4];
                                                    
                                                    for (int counterY = 0; counterY < 2; counterY++){
                                                        for (int counterX = 0; counterX < vectorNumberGroupB1; counterX++) pixNumberCount220 [counterY][counterX] = 0;
                                                    }
                                                    
                                                    for (int counterY = 0; counterY < dimension; counterY++){
                                                        for (int counterX = 0; counterX < dimension; counterX++){
                                                            if (cutMatrix2 [counterY][counterX] != 0){
                                                                if (connectMatch2 [0] == cutMatrix2 [counterY][counterX]) cutEnter = 0;
                                                                else cutEnter = 1;
                                                                
                                                                if (vectorSourceB1 [counterY][counterX] != 0){
                                                                    vectorNumberMatchEnter = 0;
                                                                    
                                                                    for (int counter3 = 0; counter3 < vectorNumberGroupB1; counter3++){
                                                                        if (vectorNumberMatchB1 [counter3] == vectorSourceB1 [counterY][counterX]) vectorNumberMatchEnter = counter3;
                                                                    }
                                                                    
                                                                    pixNumberCount220 [cutEnter][vectorNumberMatchEnter]++;
                                                                }
                                                            }
                                                        }
                                                    }
                                                    
                                                    noZeroFind4 = 0;
                                                    noZeroFind5 = 0;
                                                    noZeroFind6 = 0;
                                                    
                                                    for (int counter3 = 0; counter3 < vectorNumberGroupB1; counter3++){
                                                        if (pixNumberCount220 [0][counter3] >= 10) noZeroFind4 = 1;
                                                        
                                                        if (pixNumberCount220 [1][counter3] >= 10) noZeroFind5 = 1;
                                                        
                                                        if (pixNumberCount220 [0][counter3] >= 10 && pixNumberCount220 [1][counter3] >= 10) noZeroFind6 = 1;
                                                    }
                                                    
                                                    if (noZeroFind4 == 0 || noZeroFind5 == 0) eliminationFlag2 = 1;
                                                    else if (noZeroFind6 == 1) eliminationFlag2 = 2;
                                                    else{
                                                        
                                                        noZeroFind4 = 0;
                                                        
                                                        for (int counter3 = 0; counter3 < vectorNumberGroupB1; counter3++){
                                                            if (pixNumberCount220 [0][counter3] >= 10){
                                                                for (int counter4 = 0; counter4 < vectorNumberGroupB1; counter4++){
                                                                    if (counter3 != counter4){
                                                                        if (pixNumberCount220 [1][counter4] >= 10) noZeroFind4 = 1;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        
                                                        if (noZeroFind4 == 1) eliminationFlag2 = 5;
                                                    }
                                                    
                                                    for (int counter3 = 0; counter3 < 3; counter3++) delete [] pixNumberCount220 [counter3];
                                                    delete [] pixNumberCount220;
                                                }
                                                
                                                if (eliminationFlag2 == 1) arrayChangePoint6 [counter2*7+6] = 1;
                                                else if (eliminationFlag == 5 && eliminationFlag2 == 5) arrayChangePoint6 [counter2*7+6] = 5;
                                                else if (eliminationFlag != 5 && eliminationFlag2 == 5) eliminationFlag2 = 6;
                                                
                                                eliminationFlag3 = 0;
                                                
                                                if (processType == 4 || (processType == 5 && startEndPosition [counter1][2] == 2) || eliminationFlag2 == 2 || eliminationFlag2 == 6){
                                                    int **pixNumberCount240 = new int *[3];
                                                    for (int counter3 = 0; counter3 < 3; counter3++) pixNumberCount240 [counter3] = new int [vectorNumberGroupC1+4];
                                                    
                                                    for (int counterY = 0; counterY < 2; counterY++){
                                                        for (int counterX = 0; counterX < vectorNumberGroupC1; counterX++) pixNumberCount240 [counterY][counterX] = 0;
                                                    }
                                                    
                                                    for (int counterY = 0; counterY < dimension; counterY++){
                                                        for (int counterX = 0; counterX < dimension; counterX++){
                                                            if (cutMatrix2 [counterY][counterX] != 0){
                                                                if (connectMatch2 [0] == cutMatrix2 [counterY][counterX]) cutEnter = 0;
                                                                else cutEnter = 1;
                                                                
                                                                if (vectorSourceC1 [counterY][counterX] != 0){
                                                                    vectorNumberMatchEnter = 0;
                                                                    
                                                                    for (int counter3 = 0; counter3 < vectorNumberGroupC1; counter3++){
                                                                        if (vectorNumberMatchC1 [counter3] == vectorSourceC1 [counterY][counterX]) vectorNumberMatchEnter = counter3;
                                                                    }
                                                                    
                                                                    pixNumberCount240 [cutEnter][vectorNumberMatchEnter]++;
                                                                }
                                                            }
                                                        }
                                                    }
                                                    
                                                    noZeroFind7 = 0;
                                                    noZeroFind8 = 0;
                                                    noZeroFind9 = 0;
                                                    
                                                    for (int counter3 = 0; counter3 < vectorNumberGroupC1; counter3++){
                                                        if (pixNumberCount240 [0][counter3] >= 10) noZeroFind7 = 1;
                                                        if (pixNumberCount240 [1][counter3] >= 10) noZeroFind8 = 1;
                                                        if (pixNumberCount240 [0][counter3] >= 10 && pixNumberCount240 [1][counter3] >= 10) noZeroFind9 = 1;
                                                    }
                                                    
                                                    if (noZeroFind7 == 0 || noZeroFind8 == 0) eliminationFlag3 = 1;
                                                    else if (noZeroFind9 == 1){
                                                        eliminationFlag3 = 2;
                                                        unCutStatus = 2; //------un cut 240------
                                                    }
                                                    else{
                                                        
                                                        noZeroFind7 = 0;
                                                        
                                                        for (int counter3 = 0; counter3 < vectorNumberGroupC1; counter3++){
                                                            if (pixNumberCount240 [0][counter3] >= 10){
                                                                for (int counter4 = 0; counter4 < vectorNumberGroupC1; counter4++){
                                                                    if (counter3 != counter4){
                                                                        if (pixNumberCount240 [1][counter4] >= 10) noZeroFind7 = 1;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        
                                                        if (noZeroFind7 == 1){
                                                            eliminationFlag3 = 5;
                                                            unCutStatus = 1; //------cut 240------
                                                        }
                                                    }
                                                    
                                                    for (int counter3 = 0; counter3 < 3; counter3++) delete [] pixNumberCount240 [counter3];
                                                    delete [] pixNumberCount240;
                                                    
                                                }
                                                
                                                if (eliminationFlag3 == 1) arrayChangePoint6 [counter2*7+6] = 1;
                                                else if (eliminationFlag2 == 6 && eliminationFlag3 == 5) arrayChangePoint6 [counter2*7+6] = 5;
                                            }
                                            
                                            for (int counter3 = 0; counter3 < dimension+4; counter3++) delete [] cutMatrix2 [counter3];
                                            delete [] cutMatrix2;
                                            
                                            delete [] connectMatch2;
                                        }
                                        
                                        int *arrayChangePoint7 = new int [changePointCount6+50], changePointCount7 = 0;
                                        
                                        for (int counter2 = 0; counter2 < changePointCount6/7; counter2++){
                                            if (arrayChangePoint6 [counter2*7+6] == 0 || arrayChangePoint6 [counter2*7+6] == 5){
                                                arrayChangePoint7 [changePointCount7] = arrayChangePoint6 [counter2*7], changePointCount7++;
                                                arrayChangePoint7 [changePointCount7] = arrayChangePoint6 [counter2*7+1], changePointCount7++;
                                                arrayChangePoint7 [changePointCount7] = arrayChangePoint6 [counter2*7+2], changePointCount7++;
                                                arrayChangePoint7 [changePointCount7] = arrayChangePoint6 [counter2*7+3], changePointCount7++;
                                                arrayChangePoint7 [changePointCount7] = arrayChangePoint6 [counter2*7+4], changePointCount7++;
                                                arrayChangePoint7 [changePointCount7] = arrayChangePoint6 [counter2*7+5], changePointCount7++;
                                                arrayChangePoint7 [changePointCount7] = 0, changePointCount7++;
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < changePointCount7/7; counterA++){
                                        //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayChangePoint7 [counterA*7+counterB];
                                        //    cout<<" arrayChangePoint7 "<<counterA<<endl;
                                        //}
                                        
                                        //------If still multiple IN/OUT lines remain, check whether distance of Line One (A-B) and Line two (A-B). If these are close, get middle points------
                                        if (changePointCount7/7 != 0){
                                            if (changePointCount7/7 > 1){
                                                do{
                                                    
                                                    terminationFlag = 1;
                                                    valueTempCurrent = 0;
                                                    valueTempNext = 0;
                                                    valueTempCurrent2 = 0;
                                                    valueTempNext2 = 0;
                                                    breakFlag = 0;
                                                    
                                                    for (int counter2 = 0; counter2 < linkedLineSourceCount/3-1; counter2++){
                                                        valueTempCurrent = 0;
                                                        valueTempNext = 0;
                                                        valueTempCurrent2 = 0;
                                                        valueTempNext2 = 0;
                                                        valueTempXNext = 0;
                                                        valueTempYNext = 0;
                                                        
                                                        for (int counter3 = 0; counter3 < changePointCount7/7; counter3++){
                                                            if (arrayChangePoint7 [counter3*7+6] == 0){
                                                                if (arrayLinkedLineSource [counter2*3] == arrayChangePoint7 [counter3*7] && arrayLinkedLineSource [counter2*3+1] == arrayChangePoint7 [counter3*7+1]){
                                                                    valueTempCurrent = counter3;
                                                                    valueTempNext = 1;
                                                                    valueTempXNext = arrayChangePoint7 [counter3*7+3];
                                                                    valueTempYNext = arrayChangePoint7 [counter3*7+4];
                                                                }
                                                                
                                                                if (arrayLinkedLineSource [counter2*3] == arrayChangePoint7 [counter3*7+3] && arrayLinkedLineSource [counter2*3+1] == arrayChangePoint7 [counter3*7+4]){
                                                                    valueTempCurrent = counter3;
                                                                    valueTempNext = 2;
                                                                    valueTempXNext = arrayChangePoint7 [counter3*7];
                                                                    valueTempYNext = arrayChangePoint7 [counter3*7+1];
                                                                }
                                                            }
                                                        }
                                                        
                                                        if (valueTempXNext != 0){
                                                            breakFlag = 0;
                                                            
                                                            for (int counter3 = counter2+1; counter3 < linkedLineSourceCount/3; counter3++){
                                                                if (arrayLinkedLineSource [counter3*3] == valueTempXNext && arrayLinkedLineSource [counter3*3+1] == valueTempYNext){
                                                                    arrayChangePoint7 [valueTempCurrent*7+6] = 1;
                                                                    breakFlag = 2;
                                                                    break;
                                                                }
                                                                else{
                                                                    
                                                                    for (int counter4 = 0; counter4 < changePointCount7/7; counter4++){
                                                                        if (arrayChangePoint7 [counter4*7+6] == 0){
                                                                            if (arrayLinkedLineSource [counter3*3] == arrayChangePoint7 [counter4*7] && arrayLinkedLineSource [counter3*3+1] == arrayChangePoint7 [counter4*7+1]){
                                                                                valueTempCurrent2 = counter4;
                                                                                valueTempNext2 = 1;
                                                                                breakFlag = 1;
                                                                                break;
                                                                            }
                                                                            
                                                                            if (arrayLinkedLineSource [counter3*3] == arrayChangePoint7 [counter4*7+3] && arrayLinkedLineSource [counter3*3+1] == arrayChangePoint7 [counter4*7+4]){
                                                                                valueTempCurrent2 = counter4;
                                                                                valueTempNext2 = 2;
                                                                                breakFlag = 1;
                                                                                break;
                                                                            }
                                                                        }
                                                                    }
                                                                    
                                                                    if (breakFlag == 1 || breakFlag == 2){
                                                                        break;
                                                                    }
                                                                }
                                                            }
                                                            
                                                            if (breakFlag == 1 || breakFlag == 2){
                                                                break;
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (breakFlag == 1){
                                                        lengthA = 0;
                                                        lengthB = 0;
                                                        lengthCenterA = 0;
                                                        lengthCenterB = 0;
                                                        
                                                        distanceTemp1 = sqrt((arrayChangePoint7 [valueTempCurrent*7]-arrayChangePoint7 [valueTempCurrent*7+3])*(arrayChangePoint7 [valueTempCurrent*7]-arrayChangePoint7 [valueTempCurrent*7+3])+(arrayChangePoint7 [valueTempCurrent*7+1]-arrayChangePoint7 [valueTempCurrent*7+4])*(arrayChangePoint7 [valueTempCurrent*7+1]-arrayChangePoint7 [valueTempCurrent*7+4]));
                                                        
                                                        totalLoopLength = linkedLineSourceCount/3;
                                                        loopLength2A = arrayChangePoint7 [valueTempCurrent*7+5]-arrayChangePoint7 [valueTempCurrent*7+2];
                                                        loopLength2B = arrayChangePoint7 [valueTempCurrent*7+2]+totalLoopLength-arrayChangePoint7 [valueTempCurrent*7+5];
                                                        
                                                        distanceTemp2 = sqrt((arrayChangePoint7 [valueTempCurrent2*7]-arrayChangePoint7 [valueTempCurrent2*7+3])*(arrayChangePoint7 [valueTempCurrent2*7]-arrayChangePoint7 [valueTempCurrent2*7+3])+(arrayChangePoint7 [valueTempCurrent2*7+1]-arrayChangePoint7 [valueTempCurrent2*7+4])*(arrayChangePoint7 [valueTempCurrent2*7+1]-arrayChangePoint7 [valueTempCurrent2*7+4]));
                                                        
                                                        loopLength2C = arrayChangePoint7 [valueTempCurrent2*7+5]-arrayChangePoint7 [valueTempCurrent2*7+2];
                                                        loopLength2D = arrayChangePoint7 [valueTempCurrent2*7+2]+totalLoopLength-arrayChangePoint7 [valueTempCurrent2*7+5];
                                                        
                                                        if (valueTempNext == 1 && valueTempNext2 == 1){
                                                            lengthA = arrayChangePoint7 [valueTempCurrent2*7+2]-arrayChangePoint7 [valueTempCurrent*7+2];
                                                            lengthB = arrayChangePoint7 [valueTempCurrent*7+5]-arrayChangePoint7 [valueTempCurrent2*7+5];
                                                            lengthCenterA = (int)((arrayChangePoint7 [valueTempCurrent2*7+2]+arrayChangePoint7 [valueTempCurrent*7+2])/(double)2);
                                                            lengthCenterB = (int)((arrayChangePoint7 [valueTempCurrent*7+5]+arrayChangePoint7 [valueTempCurrent2*7+5])/(double)2);
                                                        }
                                                        
                                                        if (valueTempNext == 1 && valueTempNext2 == 2){
                                                            lengthA = arrayChangePoint7 [valueTempCurrent2*7+5]-arrayChangePoint7 [valueTempCurrent*7+2];
                                                            lengthB = arrayChangePoint7 [valueTempCurrent*7+5]-arrayChangePoint7 [valueTempCurrent2*7+2];
                                                            lengthCenterA = (int)((arrayChangePoint7 [valueTempCurrent2*7+5]+arrayChangePoint7 [valueTempCurrent*7+2])/(double)2);
                                                            lengthCenterB = (int)((arrayChangePoint7 [valueTempCurrent*7+5]+arrayChangePoint7 [valueTempCurrent2*7+2])/(double)2);
                                                        }
                                                        
                                                        if (valueTempNext == 2 && valueTempNext2 == 1){
                                                            lengthA = arrayChangePoint7 [valueTempCurrent2*7+2]-arrayChangePoint7 [valueTempCurrent*7+5];
                                                            lengthB = arrayChangePoint7 [valueTempCurrent*7+2]-arrayChangePoint7 [valueTempCurrent2*7+5];
                                                            lengthCenterA = (int)((arrayChangePoint7 [valueTempCurrent2*7+2]+arrayChangePoint7 [valueTempCurrent*7+5])/(double)2);
                                                            lengthCenterB = (int)((arrayChangePoint7 [valueTempCurrent*7+2]+arrayChangePoint7 [valueTempCurrent2*7+5])/(double)2);
                                                        }
                                                        
                                                        if (valueTempNext == 1 && valueTempNext2 == 2){
                                                            lengthA = arrayChangePoint7 [valueTempCurrent2*7+5]-arrayChangePoint7 [valueTempCurrent*7+2];
                                                            lengthB = arrayChangePoint7 [valueTempCurrent*7+5]-arrayChangePoint7 [valueTempCurrent2*7+2];
                                                            lengthCenterA = (int)((arrayChangePoint7 [valueTempCurrent2*7+5]+arrayChangePoint7 [valueTempCurrent*7+2])/(double)2);
                                                            lengthCenterB = (int)((arrayChangePoint7 [valueTempCurrent*7+5]+arrayChangePoint7 [valueTempCurrent2*7+2])/(double)2);
                                                        }
                                                        
                                                        removeLine = 0;
                                                        
                                                        if (abs(lengthA-lengthB) < 7){
                                                            if (distanceTemp1-distanceTemp2 > 5) removeLine = 1;
                                                            else if (distanceTemp2-distanceTemp1 > 5) removeLine = 2;
                                                            else if (abs(loopLength2A-loopLength2B) > abs(loopLength2C-loopLength2D)+10) removeLine = 1;
                                                            else if (abs(loopLength2A-loopLength2B)+10 < abs(loopLength2C-loopLength2D)) removeLine = 2;
                                                            else removeLine = 3;
                                                        }
                                                        
                                                        if (removeLine == 1) arrayChangePoint7 [valueTempCurrent*7+6] = 1;
                                                        else if (removeLine == 2) arrayChangePoint7 [valueTempCurrent2*7+6] = 1;
                                                        else if (removeLine == 3){
                                                            arrayChangePoint7 [valueTempCurrent2*7] = arrayLinkedLineSource [lengthCenterA*3];
                                                            arrayChangePoint7 [valueTempCurrent2*7+1] = arrayLinkedLineSource [lengthCenterA*3+1];
                                                            arrayChangePoint7 [valueTempCurrent2*7+2] = lengthCenterA;
                                                            arrayChangePoint7 [valueTempCurrent2*7+3] = arrayLinkedLineSource [lengthCenterB*3];
                                                            arrayChangePoint7 [valueTempCurrent2*7+4] = arrayLinkedLineSource [lengthCenterB*3+1];
                                                            arrayChangePoint7 [valueTempCurrent2*7+5] = lengthCenterB;
                                                            arrayChangePoint7 [valueTempCurrent2*7+6] = 0;
                                                            arrayChangePoint7 [valueTempCurrent*7+6] = 1;
                                                        }
                                                        else arrayChangePoint7 [valueTempCurrent2*7+6] = 5;
                                                    }
                                                    
                                                    //for (int counterA = 0; counterA < changePointCount7/7; counterA++){
                                                    //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayChangePoint7 [counterA*7+counterB];
                                                    //	cout<<" arrayChangePoint7 "<<counterA<<endl;
                                                    //}
                                                    
                                                    remainingCount = 0;
                                                    
                                                    for (int counter2 = 0; counter2 < changePointCount7/7; counter2++){
                                                        if (arrayChangePoint7 [counter2*7+6] == 0) remainingCount++;
                                                    }
                                                    
                                                    if (remainingCount == 1) terminationFlag = 0;
                                                    
                                                } while (terminationFlag == 1);
                                            }
                                            
                                            int *arrayChangePoint8 = new int [changePointCount7+50], changePointCount8 = 0;
                                            
                                            for (int counter2 = 0; counter2 < changePointCount7/7; counter2++){
                                                if (arrayChangePoint7 [counter2*7+6] != 1){
                                                    arrayChangePoint8 [changePointCount8] = arrayChangePoint7 [counter2*7], changePointCount8++;
                                                    arrayChangePoint8 [changePointCount8] = arrayChangePoint7 [counter2*7+1], changePointCount8++;
                                                    arrayChangePoint8 [changePointCount8] = arrayChangePoint7 [counter2*7+2], changePointCount8++;
                                                    arrayChangePoint8 [changePointCount8] = arrayChangePoint7 [counter2*7+3], changePointCount8++;
                                                    arrayChangePoint8 [changePointCount8] = arrayChangePoint7 [counter2*7+4], changePointCount8++;
                                                    arrayChangePoint8 [changePointCount8] = arrayChangePoint7 [counter2*7+5], changePointCount8++;
                                                    arrayChangePoint8 [changePointCount8] = 0, changePointCount8++;
                                                }
                                            }
                                            
                                            checkOverlap = 0;
                                            
                                            for (int counter2 = 0; counter2 < changePointCount8/7; counter2++){
                                                if (arrayChangePoint8 [counter2*7] == arrayChangePoint8 [counter2*7+3]){
                                                    checkOverlap = 1;
                                                }
                                                
                                                if (arrayChangePoint8 [counter2*7+1] == arrayChangePoint8 [counter2*7+4]){
                                                    checkOverlap = 1;
                                                }
                                            }
                                            
                                            //------Set New Line data------
                                            if (changePointCount8/7 != 0 && linkedLineSourceCount/3 > 50 && checkOverlap == 0){
                                                //for (int counterA = 0; counterA < changePointCount8/7; counterA++){
                                                //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayChangePoint8 [counterA*7+counterB];
                                                //    cout<<" arrayChangePoint8 "<<counterA<<endl;
                                                //}
                                                
                                                //for (int counterA = 0; counterA < linkedLineSourceCount/3; counterA++){
                                                //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayLinkedLineSource [counterA*3+counterB];
                                                //    cout<<" arrayLinkedLineSource "<<counterA<<endl;
                                                //}
                                                
                                                do{
                                                    
                                                    terminationFlag = 1;
                                                    lowestPosition = 10000;
                                                    lowestCount = 0;
                                                    lowestOrientation = 0;
                                                    
                                                    for (int counter2 = 0; counter2 < changePointCount8/7; counter2++){
                                                        if (arrayChangePoint8 [counter2*7+6] == 0){
                                                            if (lowestPosition > arrayChangePoint8 [counter2*7+2]){
                                                                lowestPosition = arrayChangePoint8 [counter2*7+2];
                                                                lowestCount = counter2;
                                                                lowestOrientation = 1;
                                                            }
                                                            
                                                            if (lowestPosition > arrayChangePoint8 [counter2*7+5]){
                                                                lowestPosition = arrayChangePoint8 [counter2*7+5];
                                                                lowestCount = counter2;
                                                                lowestOrientation = 2;
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestPosition == 10000) terminationFlag = 0;
                                                    else{
                                                        
                                                        arrayChangePoint8 [lowestCount*7+6] = 1;
                                                        
                                                        countTempC = 0;
                                                        countTempD = 0;
                                                        
                                                        if (lowestOrientation == 1){
                                                            countTempC = arrayChangePoint8 [lowestCount*7+2];
                                                            countTempD = arrayChangePoint8 [lowestCount*7+5];
                                                        }
                                                        
                                                        if (lowestOrientation == 2){
                                                            countTempC = arrayChangePoint8 [lowestCount*7+5];
                                                            countTempD = arrayChangePoint8 [lowestCount*7+2];
                                                        }
                                                        
                                                        if (countTempC == 0){
                                                            countTempCMinusX = arrayLinkedLineSource [(linkedLineSourceCount/3-1)*3];
                                                            countTempCMinusY = arrayLinkedLineSource [(linkedLineSourceCount/3-1)*3+1];
                                                            countTempCPlusX = arrayLinkedLineSource [3];
                                                            countTempCPlusY = arrayLinkedLineSource [4];
                                                        }
                                                        else if (countTempC == linkedLineSourceCount/3-1){
                                                            countTempCMinusX = arrayLinkedLineSource [(countTempC-1)*3];
                                                            countTempCMinusY = arrayLinkedLineSource [(countTempC-1)*3+1];
                                                            countTempCPlusX = arrayLinkedLineSource [0];
                                                            countTempCPlusY = arrayLinkedLineSource [1];
                                                        }
                                                        else{
                                                            
                                                            countTempCMinusX = arrayLinkedLineSource [(countTempC-1)*3];
                                                            countTempCMinusY = arrayLinkedLineSource [(countTempC-1)*3+1];
                                                            countTempCPlusX = arrayLinkedLineSource [(countTempC+1)*3];
                                                            countTempCPlusY = arrayLinkedLineSource [(countTempC+1)*3+1];
                                                        }
                                                        
                                                        if (countTempD == 0){
                                                            countTempDPlusX = arrayLinkedLineSource [3];
                                                            countTempDPlusY = arrayLinkedLineSource [4];
                                                            countTempDMinusX = arrayLinkedLineSource [(linkedLineSourceCount/3-1)*3];
                                                            countTempDMinusY = arrayLinkedLineSource [(linkedLineSourceCount/3-1)*3+1];
                                                        }
                                                        else if (countTempD == linkedLineSourceCount/3-1){
                                                            countTempDPlusX = arrayLinkedLineSource [0];
                                                            countTempDPlusY = arrayLinkedLineSource [1];
                                                            countTempDMinusX = arrayLinkedLineSource [(countTempD-1)*3];
                                                            countTempDMinusY = arrayLinkedLineSource [(countTempD-1)*3+1];
                                                        }
                                                        else{
                                                            
                                                            countTempDPlusX = arrayLinkedLineSource [(countTempD+1)*3];
                                                            countTempDPlusY = arrayLinkedLineSource [(countTempD+1)*3+1];
                                                            countTempDMinusX = arrayLinkedLineSource [(countTempD-1)*3];
                                                            countTempDMinusY = arrayLinkedLineSource [(countTempD-1)*3+1];
                                                        }
                                                        
                                                        gapFill = [[GapFill alloc] init];
                                                        [gapFill gapFilling:countTempCMinusX:countTempCMinusY:countTempDPlusX:countTempDPlusY];
                                                        
                                                        lineLengthLimit = ((countTempC-1)+gapDataCount/2+linkedLineSourceCount/3)*4+50;
                                                        int *arrayChangePoint9A = new int [lineLengthLimit];
                                                        changePointCount9A = 0;
                                                        
                                                        lineLengthLimit = ((countTempD-1)+gapDataCount/2)*4+50;
                                                        int *arrayChangePoint9B = new int [lineLengthLimit];
                                                        changePointCount9B = 0;
                                                        
                                                        for (int counter2 = 0; counter2 <= countTempC-1; counter2++){
                                                            arrayChangePoint9A [changePointCount9A] = arrayLinkedLineSource [counter2*3], changePointCount9A++;
                                                            arrayChangePoint9A [changePointCount9A] = arrayLinkedLineSource [counter2*3+1], changePointCount9A++;
                                                            arrayChangePoint9A [changePointCount9A] = arrayLinkedLineSource [counter2*3+2], changePointCount9A++;
                                                            arrayChangePoint9A [changePointCount9A] = counter2, changePointCount9A++;
                                                        }
                                                        
                                                        for (int counter2 = 0; counter2 < gapDataCount/2; counter2++){
                                                            arrayChangePoint9A [changePointCount9A] = arrayGapData [counter2*2], changePointCount9A++;
                                                            arrayChangePoint9A [changePointCount9A] = arrayGapData [counter2*2+1], changePointCount9A++;
                                                            arrayChangePoint9A [changePointCount9A] = arrayExtractedImage [arrayGapData [counter2*2+1]][arrayGapData [counter2*2]], changePointCount9A++;
                                                            arrayChangePoint9A [changePointCount9A] = -1, changePointCount9A++;
                                                        }
                                                        
                                                        for (int counter2 = countTempD+1; counter2 < linkedLineSourceCount/3; counter2++){
                                                            arrayChangePoint9A [changePointCount9A] = arrayLinkedLineSource [counter2*3], changePointCount9A++;
                                                            arrayChangePoint9A [changePointCount9A] = arrayLinkedLineSource [counter2*3+1], changePointCount9A++;
                                                            arrayChangePoint9A [changePointCount9A] = arrayLinkedLineSource [counter2*3+2], changePointCount9A++;
                                                            arrayChangePoint9A [changePointCount9A] = counter2, changePointCount9A++;
                                                        }
                                                        
                                                        gapFill = [[GapFill alloc] init];
                                                        [gapFill gapFilling:countTempDMinusX:countTempDMinusY:countTempCPlusX:countTempCPlusY];
                                                        
                                                        for (int counter2 = countTempC+1; counter2 <= countTempD-1; counter2++){
                                                            arrayChangePoint9B [changePointCount9B] = arrayLinkedLineSource [counter2*3], changePointCount9B++;
                                                            arrayChangePoint9B [changePointCount9B] = arrayLinkedLineSource [counter2*3+1], changePointCount9B++;
                                                            arrayChangePoint9B [changePointCount9B] = arrayLinkedLineSource [counter2*3+2], changePointCount9B++;
                                                            arrayChangePoint9B [changePointCount9B] = counter2, changePointCount9B++;
                                                        }
                                                        
                                                        for (int counter2 = 0; counter2 < gapDataCount/2; counter2++){
                                                            arrayChangePoint9B [changePointCount9B] = arrayGapData [counter2*2], changePointCount9B++;
                                                            arrayChangePoint9B [changePointCount9B] = arrayGapData [counter2*2+1], changePointCount9B++;
                                                            arrayChangePoint9B [changePointCount9B] = arrayExtractedImage [arrayGapData [counter2*2+1]][arrayGapData [counter2*2]], changePointCount9B++;
                                                            arrayChangePoint9B [changePointCount9B] = -1, changePointCount9B++;
                                                        }
                                                        
                                                        breakFlagA = 0;
                                                        breakFlagB = 0;
                                                        
                                                        for (int counter2 = 0; counter2 < changePointCount9A/4; counter2++){
                                                            for (int counter3 = 0; counter3 < changePointCount8/7; counter3++){
                                                                if (arrayChangePoint8 [counter3*7+6] != 1){
                                                                    if (arrayChangePoint9A [counter2*4+3] == arrayChangePoint8 [counter3*7+2] || arrayChangePoint9A [counter2*4+3] == arrayChangePoint8 [counter3*7+5]) breakFlagA = 1;
                                                                }
                                                            }
                                                        }
                                                        
                                                        for (int counter2 = 0; counter2 < changePointCount9B/4; counter2++){
                                                            for (int counter3 = 0; counter3 < changePointCount8/7; counter3++){
                                                                if (arrayChangePoint8 [counter3*7+6] != 1){
                                                                    if (arrayChangePoint9B [counter2*4+3] == arrayChangePoint8 [counter3*7+2] || arrayChangePoint9B [counter2*4+3] == arrayChangePoint8 [counter3*7+5]) breakFlagB = 1;
                                                                }
                                                            }
                                                        }
                                                        
                                                        //for (int counterA = 0; counterA < changePointCount9A/4; counterA++){
                                                        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayChangePoint9A [counterA*4+counterB];
                                                        //    cout<<" arrayChangePoint9A "<<counterA<<endl;
                                                        //}
                                                        
                                                        //for (int counterA = 0; counterA < changePointCount9B/4; counterA++){
                                                        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayChangePoint9B [counterA*4+counterB];
                                                        //    cout<<" arrayChangePoint9B "<<counterA<<endl;
                                                        //}
                                                        
                                                        if (breakFlagA == 0){
                                                            for (int counter2 = 0; counter2 < changePointCount9A/4; counter2++){
                                                                if (linkedLineUpdateCount+5 > linkedLineUpdateLimit) [self linkedLineSizeUpDate];
                                                                
                                                                arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayChangePoint9A [counter2*4], linkedLineUpdateCount++;
                                                                arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayChangePoint9A [counter2*4+1], linkedLineUpdateCount++;
                                                                arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayChangePoint9A [counter2*4+2], linkedLineUpdateCount++;
                                                                arrayLinkedLineUpdate [linkedLineUpdateCount] = linkedLineMainCount, linkedLineUpdateCount++;
                                                                
                                                                if (counter2 == 0) arrayLinkedLineUpdate [linkedLineUpdateCount] = 1, linkedLineUpdateCount++;
                                                                else if (counter2 == changePointCount9A/4-1) arrayLinkedLineUpdate [linkedLineUpdateCount] = 2, linkedLineUpdateCount++;
                                                                else arrayLinkedLineUpdate [linkedLineUpdateCount] = 0, linkedLineUpdateCount++;
                                                            }
                                                            
                                                            if (linkedLineUpdateAssCount+6 > linkedLineUpdateAssLimit) [self linkedLineAssSizeUpDate];
                                                            
                                                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = linkedLineMainCount, linkedLineUpdateAssCount++;
                                                            
                                                            if (processType == 1 || (processType == 2 && startEndPosition [counter1][2] == 1) || (processType == 5 && startEndPosition [counter1][2] == 1)){
                                                                arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 1, linkedLineUpdateAssCount++;
                                                            }
                                                            else arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 2, linkedLineUpdateAssCount++;
                                                            
                                                            if (unCutStatus == 0) arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                                                            else if (unCutStatus == 1) arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 1, linkedLineUpdateAssCount++;
                                                            else arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 2, linkedLineUpdateAssCount++;
                                                            
                                                            if (unCutStatus == 2) arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = linkedLinePair, linkedLineUpdateAssCount++;
                                                            else arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                                                            
                                                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = (int)cellDimensionLine, linkedLineUpdateAssCount++;
                                                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                                                            
                                                            linkedLineMainCount++;
                                                        }
                                                        
                                                        if (breakFlagB == 0){
                                                            for (int counter2 = 0; counter2 < changePointCount9B/4; counter2++){
                                                                if (linkedLineUpdateCount+5 > linkedLineUpdateLimit) [self linkedLineSizeUpDate];
                                                                
                                                                arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayChangePoint9B [counter2*4], linkedLineUpdateCount++;
                                                                arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayChangePoint9B [counter2*4+1], linkedLineUpdateCount++;
                                                                arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayChangePoint9B [counter2*4+2], linkedLineUpdateCount++;
                                                                arrayLinkedLineUpdate [linkedLineUpdateCount] = linkedLineMainCount, linkedLineUpdateCount++;
                                                                
                                                                if (counter2 == 0) arrayLinkedLineUpdate [linkedLineUpdateCount] = 1, linkedLineUpdateCount++;
                                                                else if (counter2 == changePointCount9B/4-1) arrayLinkedLineUpdate [linkedLineUpdateCount] = 2, linkedLineUpdateCount++;
                                                                else arrayLinkedLineUpdate [linkedLineUpdateCount] = 0, linkedLineUpdateCount++;
                                                            }
                                                            
                                                            if (linkedLineUpdateAssCount+6 > linkedLineUpdateAssLimit) [self linkedLineAssSizeUpDate];
                                                            
                                                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = linkedLineMainCount, linkedLineUpdateAssCount++;
                                                            
                                                            if (processType == 1 || (processType == 2 && startEndPosition [counter1][2] == 1) || (processType == 5 && startEndPosition [counter1][2] == 1)){
                                                                arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 1, linkedLineUpdateAssCount++;
                                                            }
                                                            else arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 2, linkedLineUpdateAssCount++;
                                                            
                                                            if (unCutStatus == 0) arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                                                            else if (unCutStatus == 1) arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 1, linkedLineUpdateAssCount++;
                                                            else arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 2, linkedLineUpdateAssCount++;
                                                            
                                                            if (unCutStatus == 2) arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = linkedLinePair, linkedLineUpdateAssCount++;
                                                            else arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                                                            
                                                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = (int)cellDimensionLine, linkedLineUpdateAssCount++;
                                                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                                                            
                                                            linkedLineMainCount++;
                                                        }
                                                        
                                                        if (breakFlagA == 1 && breakFlagB == 0){
                                                            for (int counter2 = 0; counter2 < changePointCount8/7; counter2++){
                                                                if (arrayChangePoint8 [counter2*7+6] == 0){
                                                                    for (int counter3 = 0; counter3 < changePointCount9A/4; counter3++){
                                                                        countTempC = arrayChangePoint9A [counter3*4+3];
                                                                        
                                                                        if (countTempC == arrayChangePoint8 [counter2*7+2]) arrayChangePoint8 [counter2*7+2] = counter3;
                                                                        if (countTempC == arrayChangePoint8 [counter2*7+5]) arrayChangePoint8 [counter2*7+2] = counter3;
                                                                    }
                                                                }
                                                            }
                                                            
                                                            linkedLineSourceCount = 0;
                                                            
                                                            for (int counter2 = 0; counter2 < changePointCount9A/4; counter2++){
                                                                arrayLinkedLineSource [linkedLineSourceCount] = arrayChangePoint9A [counter2*4], linkedLineSourceCount++;
                                                                arrayLinkedLineSource [linkedLineSourceCount] = arrayChangePoint9A [counter2*4+1], linkedLineSourceCount++;
                                                                arrayLinkedLineSource [linkedLineSourceCount] = arrayChangePoint9A [counter2*4+2], linkedLineSourceCount++;
                                                            }
                                                        }
                                                        
                                                        if (breakFlagA == 0 && breakFlagB == 1){
                                                            for (int counter2 = 0; counter2 < changePointCount8/7; counter2++){
                                                                if (arrayChangePoint8 [counter2*7+6] == 0){
                                                                    for (int counter3 = 0; counter3 < changePointCount9B/4; counter3++){
                                                                        countTempC = arrayChangePoint9A [counter3*4+3];
                                                                        
                                                                        if (countTempC == arrayChangePoint8 [counter2*7+2]) arrayChangePoint8 [counter2*7+2] = counter3;
                                                                        if (countTempC == arrayChangePoint8 [counter2*7+5]) arrayChangePoint8 [counter2*7+5] = counter3;
                                                                    }
                                                                }
                                                            }
                                                            
                                                            linkedLineSourceCount = 0;
                                                            
                                                            for (int counter2 = 0; counter2 < changePointCount9B/4; counter2++){
                                                                arrayLinkedLineSource [linkedLineSourceCount] = arrayChangePoint9B [counter2*4], linkedLineSourceCount++;
                                                                arrayLinkedLineSource [linkedLineSourceCount] = arrayChangePoint9B [counter2*4+1], linkedLineSourceCount++;
                                                                arrayLinkedLineSource [linkedLineSourceCount] = arrayChangePoint9B [counter2*4+2], linkedLineSourceCount++;
                                                            }
                                                        }
                                                        
                                                        delete [] arrayChangePoint9A;
                                                        delete [] arrayChangePoint9B;
                                                    }
                                                    
                                                } while (terminationFlag == 1);
                                                
                                                if (unCutStatus == 2) linkedLinePair++;
                                            }
                                            else{
                                                
                                                for (int counter2 = 0; counter2 < linkedLineSourceCount/3; counter2++){
                                                    if (linkedLineUpdateCount+5 > linkedLineUpdateLimit) [self linkedLineSizeUpDate];
                                                    
                                                    arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3], linkedLineUpdateCount++;
                                                    arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3+1], linkedLineUpdateCount++;
                                                    arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3+2], linkedLineUpdateCount++;
                                                    arrayLinkedLineUpdate [linkedLineUpdateCount] = linkedLineMainCount, linkedLineUpdateCount++;
                                                    
                                                    if (counter2 == 0) arrayLinkedLineUpdate [linkedLineUpdateCount] = 1, linkedLineUpdateCount++;
                                                    else if (counter2 == linkedLineSourceCount/3-1) arrayLinkedLineUpdate [linkedLineUpdateCount] = 2, linkedLineUpdateCount++;
                                                    else arrayLinkedLineUpdate [linkedLineUpdateCount] = 0, linkedLineUpdateCount++;
                                                }
                                                
                                                if (linkedLineUpdateAssCount+6 > linkedLineUpdateAssLimit) [self linkedLineAssSizeUpDate];
                                                
                                                arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = linkedLineMainCount, linkedLineUpdateAssCount++;
                                                
                                                if (processType == 1 || (processType == 2 && startEndPosition [counter1][2] == 1) || (processType == 5 && startEndPosition [counter1][2] == 1)){
                                                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 1, linkedLineUpdateAssCount++;
                                                }
                                                else arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 2, linkedLineUpdateAssCount++;
                                                
                                                arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                                                arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                                                arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = (int)cellDimensionLine, linkedLineUpdateAssCount++;
                                                arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                                                
                                                linkedLineMainCount++;
                                            }
                                            
                                            delete [] arrayChangePoint8;
                                        }
                                        else{
                                            
                                            for (int counter2 = 0; counter2 < linkedLineSourceCount/3; counter2++){
                                                if (linkedLineUpdateCount+5 > linkedLineUpdateLimit) [self linkedLineSizeUpDate];
                                                
                                                arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3], linkedLineUpdateCount++;
                                                arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3+1], linkedLineUpdateCount++;
                                                arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3+2], linkedLineUpdateCount++;
                                                arrayLinkedLineUpdate [linkedLineUpdateCount] = linkedLineMainCount, linkedLineUpdateCount++;
                                                
                                                if (counter2 == 0) arrayLinkedLineUpdate [linkedLineUpdateCount] = 1, linkedLineUpdateCount++;
                                                else if (counter2 == linkedLineSourceCount/3-1) arrayLinkedLineUpdate [linkedLineUpdateCount] = 2, linkedLineUpdateCount++;
                                                else arrayLinkedLineUpdate [linkedLineUpdateCount] = 0, linkedLineUpdateCount++;
                                            }
                                            
                                            if (linkedLineUpdateAssCount+6 > linkedLineUpdateAssLimit) [self linkedLineAssSizeUpDate];
                                            
                                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = linkedLineMainCount, linkedLineUpdateAssCount++;
                                            
                                            if (processType == 1 || (processType == 2 && startEndPosition [counter1][2] == 1) || (processType == 5 && startEndPosition [counter1][2] == 1)){
                                                arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 1, linkedLineUpdateAssCount++;
                                            }
                                            else arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 2, linkedLineUpdateAssCount++;
                                            
                                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = (int)cellDimensionLine, linkedLineUpdateAssCount++;
                                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                                            
                                            linkedLineMainCount++;
                                        }
                                        
                                        delete [] arrayChangePoint7;
                                    }
                                    else{
                                        
                                        for (int counter2 = 0; counter2 < linkedLineSourceCount/3; counter2++){
                                            if (linkedLineUpdateCount+5 > linkedLineUpdateLimit) [self linkedLineSizeUpDate];
                                            
                                            arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3], linkedLineUpdateCount++;
                                            arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3+1], linkedLineUpdateCount++;
                                            arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3+2], linkedLineUpdateCount++;
                                            arrayLinkedLineUpdate [linkedLineUpdateCount] = linkedLineMainCount, linkedLineUpdateCount++;
                                            
                                            if (counter2 == 0) arrayLinkedLineUpdate [linkedLineUpdateCount] = 1, linkedLineUpdateCount++;
                                            else if (counter2 == linkedLineSourceCount/3-1) arrayLinkedLineUpdate [linkedLineUpdateCount] = 2, linkedLineUpdateCount++;
                                            else arrayLinkedLineUpdate [linkedLineUpdateCount] = 0, linkedLineUpdateCount++;
                                        }
                                        
                                        if (linkedLineUpdateAssCount+6 > linkedLineUpdateAssLimit) [self linkedLineAssSizeUpDate];
                                        
                                        arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = linkedLineMainCount, linkedLineUpdateAssCount++;
                                        
                                        if (processType == 1 || (processType == 2 && startEndPosition [counter1][2] == 1) || (processType == 5 && startEndPosition [counter1][2] == 1)){
                                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 1, linkedLineUpdateAssCount++;
                                        }
                                        else arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 2, linkedLineUpdateAssCount++;
                                        
                                        arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                                        arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                                        arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = (int)cellDimensionLine, linkedLineUpdateAssCount++;
                                        arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                                        
                                        linkedLineMainCount++;
                                    }
                                    
                                    delete [] arrayChangePoint6;
                                }
                                else{
                                    
                                    for (int counter2 = 0; counter2 < linkedLineSourceCount/3; counter2++){
                                        if (linkedLineUpdateCount+5 > linkedLineUpdateLimit) [self linkedLineSizeUpDate];
                                        
                                        arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3], linkedLineUpdateCount++;
                                        arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3+1], linkedLineUpdateCount++;
                                        arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3+2], linkedLineUpdateCount++;
                                        arrayLinkedLineUpdate [linkedLineUpdateCount] = linkedLineMainCount, linkedLineUpdateCount++;
                                        
                                        if (counter2 == 0) arrayLinkedLineUpdate [linkedLineUpdateCount] = 1, linkedLineUpdateCount++;
                                        else if (counter2 == linkedLineSourceCount/3-1) arrayLinkedLineUpdate [linkedLineUpdateCount] = 2, linkedLineUpdateCount++;
                                        else arrayLinkedLineUpdate [linkedLineUpdateCount] = 0, linkedLineUpdateCount++;
                                    }
                                    
                                    if (linkedLineUpdateAssCount+6 > linkedLineUpdateAssLimit) [self linkedLineAssSizeUpDate];
                                    
                                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = linkedLineMainCount, linkedLineUpdateAssCount++;
                                    
                                    if (processType == 1 || (processType == 2 && startEndPosition [counter1][2] == 1) || (processType == 5 && startEndPosition [counter1][2] == 1)){
                                        arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 1, linkedLineUpdateAssCount++;
                                    }
                                    else arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 2, linkedLineUpdateAssCount++;
                                    
                                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = (int)cellDimensionLine, linkedLineUpdateAssCount++;
                                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                                    
                                    linkedLineMainCount++;
                                }
                                
                                delete [] arrayChangePoint5;
                            }
                            else{
                                
                                for (int counter2 = 0; counter2 < linkedLineSourceCount/3; counter2++){
                                    if (linkedLineUpdateCount+5 > linkedLineUpdateLimit) [self linkedLineSizeUpDate];
                                    
                                    arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3], linkedLineUpdateCount++;
                                    arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3+1], linkedLineUpdateCount++;
                                    arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3+2], linkedLineUpdateCount++;
                                    arrayLinkedLineUpdate [linkedLineUpdateCount] = linkedLineMainCount, linkedLineUpdateCount++;
                                    
                                    if (counter2 == 0) arrayLinkedLineUpdate [linkedLineUpdateCount] = 1, linkedLineUpdateCount++;
                                    else if (counter2 == linkedLineSourceCount/3-1) arrayLinkedLineUpdate [linkedLineUpdateCount] = 2, linkedLineUpdateCount++;
                                    else arrayLinkedLineUpdate [linkedLineUpdateCount] = 0, linkedLineUpdateCount++;
                                }
                                
                                if (linkedLineUpdateAssCount+6 > linkedLineUpdateAssLimit) [self linkedLineAssSizeUpDate];
                                
                                arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = linkedLineMainCount, linkedLineUpdateAssCount++;
                                
                                if (processType == 1 || (processType == 2 && startEndPosition [counter1][2] == 1) || (processType == 5 && startEndPosition [counter1][2] == 1)){
                                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 1, linkedLineUpdateAssCount++;
                                }
                                else arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 2, linkedLineUpdateAssCount++;
                                
                                arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                                arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                                arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = (int)cellDimensionLine, linkedLineUpdateAssCount++;
                                arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                                
                                linkedLineMainCount++;
                            }
                            
                            delete [] arrayChangePoint4;
                        }
                        else{
                            
                            for (int counter2 = 0; counter2 < linkedLineSourceCount/3; counter2++){
                                if (linkedLineUpdateCount+5 > linkedLineUpdateLimit) [self linkedLineSizeUpDate];
                                
                                arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3], linkedLineUpdateCount++;
                                arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3+1], linkedLineUpdateCount++;
                                arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3+2], linkedLineUpdateCount++;
                                arrayLinkedLineUpdate [linkedLineUpdateCount] = linkedLineMainCount, linkedLineUpdateCount++;
                                
                                if (counter2 == 0) arrayLinkedLineUpdate [linkedLineUpdateCount] = 1, linkedLineUpdateCount++;
                                else if (counter2 == linkedLineSourceCount/3-1) arrayLinkedLineUpdate [linkedLineUpdateCount] = 2, linkedLineUpdateCount++;
                                else arrayLinkedLineUpdate [linkedLineUpdateCount] = 0, linkedLineUpdateCount++;
                            }
                            
                            if (linkedLineUpdateAssCount+6 > linkedLineUpdateAssLimit) [self linkedLineAssSizeUpDate];
                            
                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = linkedLineMainCount, linkedLineUpdateAssCount++;
                            
                            if (processType == 1 || (processType == 2 && startEndPosition [counter1][2] == 1) || (processType == 5 && startEndPosition [counter1][2] == 1)){
                                arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 1, linkedLineUpdateAssCount++;
                            }
                            else arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 2, linkedLineUpdateAssCount++;
                            
                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = (int)cellDimensionLine, linkedLineUpdateAssCount++;
                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                            
                            linkedLineMainCount++;
                        }
                        
                        delete [] arrayChangePoint3;
                    }
                    else{
                        
                        for (int counter2 = 0; counter2 < linkedLineSourceCount/3; counter2++){
                            if (linkedLineUpdateCount+5 > linkedLineUpdateLimit) [self linkedLineSizeUpDate];
                            
                            arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3], linkedLineUpdateCount++;
                            arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3+1], linkedLineUpdateCount++;
                            arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3+2], linkedLineUpdateCount++;
                            arrayLinkedLineUpdate [linkedLineUpdateCount] = linkedLineMainCount, linkedLineUpdateCount++;
                            
                            if (counter2 == 0) arrayLinkedLineUpdate [linkedLineUpdateCount] = 1, linkedLineUpdateCount++;
                            else if (counter2 == linkedLineSourceCount/3-1) arrayLinkedLineUpdate [linkedLineUpdateCount] = 2, linkedLineUpdateCount++;
                            else arrayLinkedLineUpdate [linkedLineUpdateCount] = 0, linkedLineUpdateCount++;
                        }
                        
                        if (linkedLineUpdateAssCount+6 > linkedLineUpdateAssLimit) [self linkedLineAssSizeUpDate];
                        
                        arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = linkedLineMainCount, linkedLineUpdateAssCount++;
                        
                        if (processType == 1 || (processType == 2 && startEndPosition [counter1][2] == 1) || (processType == 5 && startEndPosition [counter1][2] == 1)){
                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 1, linkedLineUpdateAssCount++;
                        }
                        else arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 2, linkedLineUpdateAssCount++;
                        
                        arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                        arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                        arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = (int)cellDimensionLine, linkedLineUpdateAssCount++;
                        arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                        
                        linkedLineMainCount++;
                    }
                    
                    delete [] arrayChangePoint2;
                }
                else{
                    
                    for (int counter2 = 0; counter2 < linkedLineSourceCount/3; counter2++){
                        if (linkedLineUpdateCount+5 > linkedLineUpdateLimit) [self linkedLineSizeUpDate];
                        
                        arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3], linkedLineUpdateCount++;
                        arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3+1], linkedLineUpdateCount++;
                        arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3+2], linkedLineUpdateCount++;
                        arrayLinkedLineUpdate [linkedLineUpdateCount] = linkedLineMainCount, linkedLineUpdateCount++;
                        
                        if (counter2 == 0) arrayLinkedLineUpdate [linkedLineUpdateCount] = 1, linkedLineUpdateCount++;
                        else if (counter2 == linkedLineSourceCount/3-1) arrayLinkedLineUpdate [linkedLineUpdateCount] = 2, linkedLineUpdateCount++;
                        else arrayLinkedLineUpdate [linkedLineUpdateCount] = 0, linkedLineUpdateCount++;
                    }
                    
                    if (linkedLineUpdateAssCount+6 > linkedLineUpdateAssLimit) [self linkedLineAssSizeUpDate];
                    
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = linkedLineMainCount, linkedLineUpdateAssCount++;
                    
                    if (processType == 1 || (processType == 2 && startEndPosition [counter1][2] == 1) || (processType == 5 && startEndPosition [counter1][2] == 1)){
                        arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 1, linkedLineUpdateAssCount++;
                    }
                    else arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 2, linkedLineUpdateAssCount++;
                    
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = (int)cellDimensionLine, linkedLineUpdateAssCount++;
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                    
                    linkedLineMainCount++;
                }
                
                delete [] positionAB;
                
                delete [] arrayChangePointTemp2;
                delete [] distanceCal2;
                delete [] checkPointList;
            }
            else{
                
                for (int counter2 = 0; counter2 < linkedLineSourceCount/3; counter2++){
                    if (linkedLineUpdateCount+5 > linkedLineUpdateLimit) [self linkedLineSizeUpDate];
                    
                    arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3], linkedLineUpdateCount++; //------X position------0
                    arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3+1], linkedLineUpdateCount++; //------Y position------1
                    arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayLinkedLineSource [counter2*3+2], linkedLineUpdateCount++; //------Pix Value------2
                    arrayLinkedLineUpdate [linkedLineUpdateCount] = linkedLineMainCount, linkedLineUpdateCount++; //------Line number (cell humber)------3
                    
                    if (counter2 == 0) arrayLinkedLineUpdate [linkedLineUpdateCount] = 1, linkedLineUpdateCount++; //------Start-End position------4
                    else if (counter2 == linkedLineSourceCount/3-1) arrayLinkedLineUpdate [linkedLineUpdateCount] = 2, linkedLineUpdateCount++;
                    else arrayLinkedLineUpdate [linkedLineUpdateCount] = 0, linkedLineUpdateCount++;
                }
                
                if (linkedLineUpdateAssCount+6 > linkedLineUpdateAssLimit) [self linkedLineAssSizeUpDate];
                
                arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = linkedLineMainCount, linkedLineUpdateAssCount++;
                
                if (processType == 1 || (processType == 2 && startEndPosition [counter1][2] == 1) || (processType == 5 && startEndPosition [counter1][2] == 1)){
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 1, linkedLineUpdateAssCount++; //------Process Type: 1: use drawn lines, 2: use replaced line over 200------0
                }
                else arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 2, linkedLineUpdateAssCount++;
                
                arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++; //------Cut type: 0: No Cut, 1: Cut, 2: Cut line Set, but it was not cut at 240------1
                arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++; //------Pair Number------2
                arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = (int)cellDimensionLine, linkedLineUpdateAssCount++; //------Cell Dimension------3
                arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                
                linkedLineMainCount++;
            }
            
            delete [] arrayInOutData;
            delete [] arrayLinkedLineOneTemp;
            delete [] arrayLinkedLineTwoTemp;
            delete [] arrayLinkedLineSource;
            
            for (int counter2 = 0; counter2 < dimension+4; counter2++) delete [] combinedMatrixA2 [counter2];
            delete [] combinedMatrixA2;
            
            delete [] distanceCal;
            delete [] changePoint;
        }
        
        for (int counter1 = 0; counter1 < dimension+4; counter1++){
            delete [] vectorSourceA1 [counter1];
            delete [] vectorSourceB1 [counter1];
            delete [] vectorSourceC1 [counter1];
            delete [] linkedConnectivityMatrix1 [counter1];
        }
        
        delete [] vectorSourceA1;
        delete [] vectorSourceB1;
        delete [] vectorSourceC1;
        delete [] linkedConnectivityMatrix1;
        
        delete [] vectorNumberMatchA1;
        delete [] vectorNumberMatchB1;
        delete [] vectorNumberMatchC1;
        
        for (int counter1 = 0; counter1 < numberOfContent+4; counter1++) delete [] startEndPosition [counter1];
        delete [] startEndPosition;
    }
    
    //NSLog(@"%@", [NSThread callStackSymbols]);
}

-(void)linkedLineSizeUpDate{
    int *arrayUpDate = new int [linkedLineUpdateCount+10];
    for (int counter1 = 0; counter1 < linkedLineUpdateCount; counter1++) arrayUpDate [counter1] = arrayLinkedLineUpdate [counter1];
    
    delete [] arrayLinkedLineUpdate;
    arrayLinkedLineUpdate = new int [linkedLineUpdateLimit+5000];
    linkedLineUpdateLimit = linkedLineUpdateLimit+5000;
    
    for (int counter1 = 0; counter1 < linkedLineUpdateCount; counter1++) arrayLinkedLineUpdate [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)linkedLineAssSizeUpDate{
    int *arrayUpDate = new int [linkedLineUpdateAssCount+10];
    for (int counter1 = 0; counter1 < linkedLineUpdateAssCount; counter1++) arrayUpDate [counter1] = arrayLinkedLineUpdateAss [counter1];
    
    delete [] arrayLinkedLineUpdateAss;
    arrayLinkedLineUpdateAss = new int [linkedLineUpdateAssLimit+5000];
    linkedLineUpdateAssLimit = linkedLineUpdateAssLimit+5000;
    
    for (int counter1 = 0; counter1 < linkedLineUpdateAssCount; counter1++) arrayLinkedLineUpdateAss [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

@end
