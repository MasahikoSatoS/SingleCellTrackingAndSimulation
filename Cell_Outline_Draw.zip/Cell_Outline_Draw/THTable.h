//
//  THTable.h
//  Cell_Outline_Draw
//
//  Created by Masahiko Sato on 9/8/16.
//
//

#ifndef THTABLE_H
#define THTABLE_H
#import "Controller.h"
#endif

@interface THTable : NSObject <NSTableViewDataSource>{
    int tableCallCount; //Table call count
    int tableCurrentRowHold; //Table operation
    int rowIndexHold; //Table operation
    int tableViewCall; //Table operation
    
    IBOutlet NSTableView *thViewList;
    
    NSTimer *thTableTimer;
}

-(id)init;
-(void)dealloc;
-(void)thTableUpDate;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;
-(void)tableView:(NSTableView *)aTableView setObjectValue:(id)anObject forTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;

-(IBAction)setTHValue:(id)sender;
-(IBAction)removeEntry:(id)sender;
-(IBAction)clearEnter:(id)sender;

@end
