//
// LinkPoint.mm
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 24/11/12.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#import "LinkPoint.h"

@implementation LinkPoint

-(void)lineEndAdjust{
    int positionMap [3][3];
    int positionMap2 [3][3];
    
    int arrayTempOneCount = 0;
    int arrayTempTwoCount = 0;
    int arrayTempOneAdjustCount = 0;
    int startEndXTemp = 0;
    int startEndYTemp = 0;
    int breakFlag = 0;
    int startEndXTemp2 = 0;
    int startEndYTemp2 = 0;
    int addPointX = 0;
    int addPointY = 0;
    int addValue = 0;
    int positionMark = 0;
    
    for (int counter1 = 0; counter1 < 4; counter1++){
        arrayTempOneCount = 0;
        arrayTempTwoCount = 0;
        arrayTempOneAdjustCount = 0;
        
        int *arrayTempOne;
        int *arrayTempTwo;
        int *arrayTempOneAdjust;
        
        if (counter1 == 0){
            arrayTempOne = new int [lineOneCount*2+1];
            arrayTempTwo = new int [lineFiveCount*2+1];
            arrayTempOneAdjust = new int [lineOneCount*2+1];
            
            for (int counter2 = 0; counter2 < lineOneCount; counter2++) arrayTempOne [counter2] = arrayLineOne [counter2], arrayTempOneCount++;
            for (int counter2 = 0; counter2 < lineFiveCount; counter2++) arrayTempTwo [counter2] = arrayLineFive [counter2], arrayTempTwoCount++;
        }
        
        if (counter1 == 1){
            arrayTempOne = new int [lineThreeCount*2+1];
            arrayTempTwo = new int [lineSevenCount*2+1];
            arrayTempOneAdjust = new int [lineThreeCount*2+1];
            
            for (int counter2 = 0; counter2 < lineThreeCount; counter2++) arrayTempOne [counter2] = arrayLineThree [counter2], arrayTempOneCount++;
            for (int counter2 = 0; counter2 < lineSevenCount; counter2++) arrayTempTwo [counter2] = arrayLineSeven [counter2], arrayTempTwoCount++;
        }
        
        if (counter1 == 2){
            arrayTempOne = new int [lineFiveCount*2+1];
            arrayTempTwo = new int [lineOneCount*2+1];
            arrayTempOneAdjust = new int [lineFiveCount*2+1];
            
            for (int counter2 = 0; counter2 < lineFiveCount; counter2++) arrayTempOne [counter2] = arrayLineFive [counter2], arrayTempOneCount++;
            for (int counter2 = 0; counter2 < lineOneCount; counter2++) arrayTempTwo [counter2] = arrayLineOne [counter2], arrayTempTwoCount++;
        }
        
        if (counter1 == 3){
            arrayTempOne = new int [lineSevenCount*2+1];
            arrayTempTwo = new int [lineThreeCount*2+1];
            arrayTempOneAdjust = new int [lineSevenCount*2+1];
            
            for (int counter2 = 0; counter2 < lineSevenCount; counter2++) arrayTempOne [counter2] = arrayLineSeven [counter2], arrayTempOneCount++;
            for (int counter2 = 0; counter2 < lineThreeCount; counter2++) arrayTempTwo [counter2] = arrayLineThree [counter2], arrayTempTwoCount++;
        }
        
        for (int counter2 = 0; counter2 < arrayTempOneCount/6; counter2++){
            if (arrayTempOne [counter2*6+5] == 1 || arrayTempOne [counter2*6+5] == 2){
                startEndXTemp = arrayTempOne [counter2*6];
                startEndYTemp = arrayTempOne [counter2*6+1];
                breakFlag = 0;
                
                for (int counter3 = 0; counter3 < 3; counter3++){
                    for (int counter4 = 0; counter4 < 3; counter4++){
                        positionMap [counter3][counter4] = -1;
                        positionMap2 [counter3][counter4] = -1;
                    }
                }
                
                for (int counter3 = 0; counter3 < arrayTempTwoCount/6; counter3++){
                    startEndXTemp2 = arrayTempTwo [counter3*6];
                    startEndYTemp2 = arrayTempTwo [counter3*6+1];
                    
                    if (startEndXTemp2 == startEndXTemp && startEndYTemp2 == startEndYTemp){
                        breakFlag = 1;
                        break;
                    }
                    else{
                        
                        if (startEndXTemp2 == startEndXTemp-1 && startEndYTemp2 == startEndYTemp-1) positionMap [0][0] = arrayTempTwo [counter3*6+2];
                        if (startEndXTemp2 == startEndXTemp && startEndYTemp2 == startEndYTemp-1) positionMap [0][1] = arrayTempTwo [counter3*6+2];
                        if (startEndXTemp2 == startEndXTemp+1 && startEndYTemp2 == startEndYTemp-1) positionMap [0][2] = arrayTempTwo [counter3*6+2];
                        if (startEndXTemp2 == startEndXTemp+1 && startEndYTemp2 == startEndYTemp) positionMap [1][2] = arrayTempTwo [counter3*6+2];
                        if (startEndXTemp2 == startEndXTemp+1 && startEndYTemp2 == startEndYTemp+1) positionMap [2][2] = arrayTempTwo [counter3*6+2];
                        if (startEndXTemp2 == startEndXTemp && startEndYTemp2 == startEndYTemp+1) positionMap [2][1] = arrayTempTwo [counter3*6+2];
                        if (startEndXTemp2 == startEndXTemp-1 && startEndYTemp2 == startEndYTemp+1) positionMap [2][0] = arrayTempTwo [counter3*6+2];
                        if (startEndXTemp2 == startEndXTemp-1 && startEndYTemp2 == startEndYTemp) positionMap [1][0] = arrayTempTwo [counter3*6+2];
                    }
                }
                
                for (int counter3 = 0; counter3 < arrayTempOneCount/6; counter3++){
                    startEndXTemp2 = arrayTempOne [counter3*6];
                    startEndYTemp2 = arrayTempOne [counter3*6+1];
                    
                    if (startEndXTemp2 == startEndXTemp && startEndYTemp2 == startEndYTemp-1) positionMap2 [0][1] = arrayTempOne [counter3*6+2];
                    if (startEndXTemp2 == startEndXTemp+1 && startEndYTemp2 == startEndYTemp) positionMap2 [1][2] = arrayTempOne [counter3*6+2];
                    if (startEndXTemp2 == startEndXTemp && startEndYTemp2 == startEndYTemp+1) positionMap2 [2][1] = arrayTempOne [counter3*6+2];
                    if (startEndXTemp2 == startEndXTemp-1 && startEndYTemp2 == startEndYTemp) positionMap2 [1][0] = arrayTempOne [counter3*6+2];
                }
                
                //------positionMap [0][0]: 1, positionMap [0][1]: 2, positionMap [0][2], 3, positionMap [1][2]: 4, positionMap [2][2]:5, positionMap [2][1]------
                //------:6, positionMap [2][0]:7, positionMap [1][0]:8------
                
                positionMark = -1;
                
                if (breakFlag == 0){
                    if (arrayTempOne [counter2*6+5] == 1 && counter1 == 0 && positionMap2 [2][1] == -1 && positionMap2 [0][1] != -1){
                        if (positionMap [2][2] != -1) positionMark = 7;
                        else if (positionMap [2][0] != -1) positionMark = 5;
                        else if (positionMap [2][1] != -1) positionMark = 6;
                        else if (positionMap [1][0] != -1) positionMark = 8;
                        else if (positionMap [1][2] != -1) positionMark = 4;
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 1 && counter1 == 0 && positionMap2 [2][1] != -1 && positionMap2 [0][1] == -1){
                        if (positionMap [0][0] != -1) positionMark = 1;
                        else if (positionMap [0][2] != -1) positionMark = 3;
                        else if (positionMap [0][1] != -1) positionMark = 2;
                        else if (positionMap [1][0] != -1) positionMark = 8;
                        else if (positionMap [1][2] != -1) positionMark = 4;
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 1 && counter1 == 0 && positionMap2 [2][1] == -1 && positionMap2 [0][1] == -1){
                        if (positionMap [2][0] != -1) positionMark = 7;
                        else if (positionMap [0][0] != -1) positionMark = 1;
                        else if (positionMap [1][0] != -1) positionMark = 8;
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 1 && counter1 == 1 && positionMap2 [2][1] == -1 && positionMap2 [0][1] != -1){
                        if (positionMap [2][0] != -1) positionMark = 7;
                        else if (positionMap [2][2] != -1) positionMark = 5;
                        else if (positionMap [2][1] != -1) positionMark = 6;
                        else if (positionMap [1][2] != -1) positionMark = 4;
                        else if (positionMap [1][0] != -1) positionMark = 8;
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 1 && counter1 == 1 && positionMap2 [2][1] != -1 && positionMap2 [0][1] == -1){
                        if (positionMap [0][2] != -1) positionMark = 3;
                        else if (positionMap [0][0] != -1) positionMark = 1;
                        else if (positionMap [0][1] != -1) positionMark = 2;
                        else if (positionMap [1][2] != -1) positionMark = 4;
                        else if (positionMap [1][0] != -1) positionMark = 8;
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 1 && counter1 == 1 && positionMap2 [2][1] == -1 && positionMap2 [0][1] == -1){
                        if (positionMap [0][2] != -1) positionMark = 3;
                        else if (positionMap [2][2] != -1) positionMark = 5;
                        else if (positionMap [1][2] != -1) positionMark = 4;
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 2 && counter1 == 0 && positionMap2 [2][1] == -1 && positionMap2 [0][1] != -1){
                        if (positionMap [2][0] != -1) positionMark = 7;
                        else if (positionMap [2][2] != -1) positionMark = 5;
                        else if (positionMap [2][1] != -1) positionMark = 6;
                        else if (positionMap [1][2] != -1) positionMark = 4;
                        else if (positionMap [1][0] != -1) positionMark = 8;
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 2 && counter1 == 0 && positionMap2 [2][1] != -1 && positionMap2 [0][1] == -1){
                        if (positionMap [0][2] != -1) positionMark = 3;
                        else if (positionMap [0][0] != -1) positionMark = 1;
                        else if (positionMap [0][1] != -1) positionMark = 2;
                        else if (positionMap [1][2] != -1) positionMark = 4;
                        else if (positionMap [1][0] != -1) positionMark = 8;
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 2 && counter1 == 0 && positionMap2 [2][1] == -1 && positionMap2 [0][1] == -1){
                        if (positionMap [2][2] != -1) positionMark = 5;
                        else if (positionMap [0][2] != -1) positionMark = 3;
                        else if (positionMap [1][2] != -1) positionMark = 4;
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 2 && counter1 == 1 && positionMap2 [2][1] == -1 && positionMap2 [0][1] != -1){
                        if (positionMap [2][0] != -1) positionMark = 7;
                        else if (positionMap [2][2] != -1) positionMark = 5;
                        else if (positionMap [2][1] != -1) positionMark = 6;
                        else if (positionMap [1][2] != -1) positionMark = 4;
                        else if (positionMap [1][0] != -1) positionMark = 8;
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 2 && counter1 == 1 && positionMap2 [2][1] != -1 && positionMap2 [0][1] == -1){
                        if (positionMap [0][2] != -1) positionMark = 3;
                        else if (positionMap [0][0] != -1) positionMark = 1;
                        else if (positionMap [0][1] != -1) positionMark = 2;
                        else if (positionMap [1][2] != -1) positionMark = 4;
                        else if (positionMap [1][0] != -1) positionMark = 8;
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 2 && counter1 == 1 && positionMap2 [2][1] == -1 && positionMap2 [0][1] == -1){
                        if (positionMap [0][0] != -1) positionMark = 1;
                        else if (positionMap [2][0] != -1) positionMark = 7;
                        else if (positionMap [1][0] != -1) positionMark = 8;
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 2 && counter1 == 2 && positionMap2 [1][2] == -1 && positionMap2 [1][0] != -1){
                        if (positionMap [2][2] != -1) positionMark = 5;
                        else if (positionMap [0][2] != -1) positionMark = 3;
                        else if (positionMap [1][2] != -1) positionMark = 4;
                        else if (positionMap [2][1] != -1) positionMark = 6;
                        else if (positionMap [0][1] != -1) positionMark = 2;
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 2 && counter1 == 2 && positionMap2 [1][2] != -1 && positionMap2 [1][0] == -1){
                        if (positionMap [2][0] != -1) positionMark = 7;
                        else if (positionMap [0][0] != -1) positionMark = 1;
                        else if (positionMap [1][0] != -1) positionMark = 8;
                        else if (positionMap [2][1] != -1) positionMark = 6;
                        else if (positionMap [0][1] != -1) positionMark = 2;
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 2 && counter1 == 2 && positionMap2 [1][2] == -1 && positionMap2 [1][0] == -1){
                        if (positionMap [2][2] != -1) positionMark = 5;
                        else if (positionMap [2][0] != -1) positionMark = 7;
                        else if (positionMap [2][1] != -1) positionMark = 6;
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 1 && counter1 == 3 && positionMap2 [1][2] == -1 && positionMap2 [1][0] != -1){
                        if (positionMap [0][2] != -1) positionMark = 3;
                        else if (positionMap [2][2] != -1) positionMark = 4;
                        else if (positionMap [1][2] != -1) positionMark = 4;
                        else if (positionMap [2][1] != -1) positionMark = 6;
                        else if (positionMap [0][1] != -1) positionMark = 2;
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 1 && counter1 == 3 && positionMap2 [1][2] != -1 && positionMap2 [1][0] == -1){
                        if (positionMap [0][0] != -1) positionMark = 1;
                        else if (positionMap [2][0] != -1) positionMark = 7;
                        else if (positionMap [1][0] != -1) positionMark = 8;
                        else if (positionMap [2][1] != -1) positionMark = 6;
                        else if (positionMap [0][1] != -1) positionMark = 2;
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 1 && counter1 == 3 && positionMap2 [1][2] == -1 && positionMap2 [1][0] == -1){
                        if (positionMap [0][0] != -1) positionMark = 1;
                        else if (positionMap [0][2] != -1) positionMark = 3;
                        else if (positionMap [0][1] != -1) positionMark = 2;
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 2 && counter1 == 2 && positionMap2 [1][2] == -1 && positionMap2 [1][0] != -1){
                        if (positionMap [2][2] != -1) positionMark = 5;
                        else if (positionMap [0][2] != -1) positionMark = 3;
                        else if (positionMap [1][2] != -1) positionMark = 4;
                        else if (positionMap [0][1] != -1) positionMark = 2;
                        else if (positionMap [2][1] != -1) positionMark = 6;
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 2 && counter1 == 2 && positionMap2 [1][2] != -1 && positionMap2 [1][0] == -1){
                        if (positionMap [0][0] != -1) positionMark = 1;
                        else if (positionMap [2][0] != -1) positionMark = 7;
                        else if (positionMap [0][1] != -1) positionMark = 2;
                        else if (positionMap [2][1] != -1) positionMark = 6;
                        else if (positionMap [0][1] != -1) positionMark = 2;
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 2 && counter1 == 2 && positionMap2 [1][2] == -1 && positionMap2 [1][0] == -1){
                        if (positionMap [0][2] != -1) positionMark = 3;
                        else if (positionMap [0][0] != -1) positionMark = 1;
                        else if (positionMap [0][1] != -1) positionMark = 2;
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 2 && counter1 == 3 && positionMap2 [1][2] != -1 && positionMap2 [1][0] == -1){
                        if (positionMap [2][2] != -1) positionMark = 5;
                        else if (positionMap [0][2] != -1) positionMark = 3;
                        else if (positionMap [1][2] != -1) positionMark = 4;
                        else if (positionMap [2][1] != -1) positionMark = 6;
                        else if (positionMap [0][1] != -1) positionMark = 2;
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 2 && counter1 == 3 && positionMap2 [1][2] == -1 && positionMap2 [1][0] != -1){
                        if (positionMap [2][0] != -1) positionMark = 7;
                        else if (positionMap [0][0] != -1) positionMark = 1;
                        else if (positionMap [1][0] != -1) positionMark = 8;
                        else if (positionMap [2][1] != -1) positionMark = 6;
                        else if (positionMap [0][1] != -1) positionMark = 2;
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 2 && counter1 == 3 && positionMap2 [1][2] == -1 && positionMap2 [1][0] == -1){
                        if (positionMap [2][0] != -1) positionMark = 7;
                        else if (positionMap [2][2] != -1) positionMark = 5;
                        else if (positionMap [2][1] != -1) positionMark = 6;
                    }
                }
                
                if (positionMark == -1 || breakFlag == 1){
                    if (arrayTempOne [counter2*6+5] == 1){
                        for (int counter3 = counter2; counter3 < arrayTempOneCount/6; counter3++){
                            if (arrayTempOne [counter3*6+5] == 2){
                                break;
                            }
                            else{
                                
                                arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter3*6], arrayTempOneAdjustCount++;
                                arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter3*6+1], arrayTempOneAdjustCount++;
                                arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter3*6+2], arrayTempOneAdjustCount++;
                                arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter3*6+3], arrayTempOneAdjustCount++;
                                arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter3*6+4], arrayTempOneAdjustCount++;
                                arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter3*6+5], arrayTempOneAdjustCount++;
                            }
                        }
                    }
                    else{
                        
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter2*6], arrayTempOneAdjustCount++;
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter2*6+1], arrayTempOneAdjustCount++;
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter2*6+2], arrayTempOneAdjustCount++;
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter2*6+3], arrayTempOneAdjustCount++;
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter2*6+4], arrayTempOneAdjustCount++;
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter2*6+5], arrayTempOneAdjustCount++;
                    }
                }
                else{
                    
                    addPointX = -1;
                    addPointY = -1;
                    addValue = 0;
                    
                    if (positionMark == 1){
                        addPointX = startEndXTemp-1;
                        addPointY = startEndYTemp-1;
                        addValue = positionMap [0][0];
                    }
                    
                    if (positionMark == 2){
                        addPointX = startEndXTemp;
                        addPointY = startEndYTemp-1;
                        addValue = positionMap [0][1];
                    }
                    
                    if (positionMark == 3){
                        addPointX = startEndXTemp+1;
                        addPointY = startEndYTemp-1;
                        addValue = positionMap [0][2];
                    }
                    
                    if (positionMark == 4){
                        addPointX = startEndXTemp+1;
                        addPointY = startEndYTemp;
                        addValue = positionMap [1][2];
                    }
                    
                    if (positionMark == 5){
                        addPointX = startEndXTemp+1;
                        addPointY = startEndYTemp+1;
                        addValue = positionMap [2][2];
                    }
                    
                    if (positionMark == 6){
                        addPointX = startEndXTemp;
                        addPointY = startEndYTemp+1;
                        addValue = positionMap [2][1];
                    }
                    
                    if (positionMark == 7){
                        addPointX = startEndXTemp-1;
                        addPointY = startEndYTemp+1;
                        addValue = positionMap [2][0];
                    }
                    
                    if (positionMark == 8){
                        addPointX = startEndXTemp-1;
                        addPointY = startEndYTemp;
                        addValue = positionMap [1][0];
                    }
                    
                    if (arrayTempOne [counter2*6+5] == 1){
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = addPointX, arrayTempOneAdjustCount++;
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = addPointY, arrayTempOneAdjustCount++;
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = addValue, arrayTempOneAdjustCount++;
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter2*6+3], arrayTempOneAdjustCount++;
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter2*6+4], arrayTempOneAdjustCount++;
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = 3, arrayTempOneAdjustCount++;
                        
                        for (int counter3 = counter2; counter3 < arrayTempOneCount/6; counter3++){
                            if (arrayTempOne [counter3*6+5] == 2){
                                break;
                            }
                            else{
                                
                                arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter3*6], arrayTempOneAdjustCount++;
                                arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter3*6+1], arrayTempOneAdjustCount++;
                                arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter3*6+2], arrayTempOneAdjustCount++;
                                arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter3*6+3], arrayTempOneAdjustCount++;
                                arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter3*6+4], arrayTempOneAdjustCount++;
                                arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter3*6+5], arrayTempOneAdjustCount++;
                            }
                        }
                    }
                    else{
                        
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter2*6], arrayTempOneAdjustCount++;
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter2*6+1], arrayTempOneAdjustCount++;
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter2*6+2], arrayTempOneAdjustCount++;
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter2*6+3], arrayTempOneAdjustCount++;
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter2*6+4], arrayTempOneAdjustCount++;
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter2*6+5], arrayTempOneAdjustCount++;
                        
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = addPointX, arrayTempOneAdjustCount++;
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = addPointY, arrayTempOneAdjustCount++;
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = addValue, arrayTempOneAdjustCount++;
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter2*6+3], arrayTempOneAdjustCount++;
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = arrayTempOne [counter2*6+4], arrayTempOneAdjustCount++;
                        arrayTempOneAdjust [arrayTempOneAdjustCount] = 3, arrayTempOneAdjustCount++;
                    }
                }
            }
        }
        
        if (counter1 == 0){
            lineOneCount = 0;
            for (int counter2 = 0; counter2 < arrayTempOneAdjustCount; counter2++) arrayLineOne [counter2] = arrayTempOneAdjust [counter2], lineOneCount++;
            
            delete [] arrayTempOne;
            delete [] arrayTempTwo;
            delete [] arrayTempOneAdjust;
        }
        
        if (counter1 == 1){
            lineThreeCount = 0;
            for (int counter2 = 0; counter2 < arrayTempOneAdjustCount; counter2++) arrayLineThree [counter2] = arrayTempOneAdjust [counter2], lineThreeCount++;
            
            delete [] arrayTempOne;
            delete [] arrayTempTwo;
            delete [] arrayTempOneAdjust;
        }
        
        if (counter1 == 2){
            lineFiveCount = 0;
            for (int counter2 = 0; counter2 < arrayTempOneAdjustCount; counter2++) arrayLineFive [counter2] = arrayTempOneAdjust [counter2], lineFiveCount++;
            
            delete [] arrayTempOne;
            delete [] arrayTempTwo;
            delete [] arrayTempOneAdjust;
        }
        
        if (counter1 == 3){
            lineSevenCount = 0;
            for (int counter2 = 0; counter2 < arrayTempOneAdjustCount; counter2++) arrayLineSeven [counter2] = arrayTempOneAdjust [counter2], lineSevenCount++;
            
            delete [] arrayTempOne;
            delete [] arrayTempTwo;
            delete [] arrayTempOneAdjust;
        }
    }
}

@end
