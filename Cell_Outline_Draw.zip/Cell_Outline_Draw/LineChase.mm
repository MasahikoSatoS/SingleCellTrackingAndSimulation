//
// LineChase.mm
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 24/07/11.
// Modified by Masahiko Sato on 18/10/12.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#import "LineChase.h"

@implementation LineChase

-(void)lineChaseProcess:(int)typeSubArray{
    //clock_t time1, time2, time3, time4, time5, time6, time7, time8, time9, time10, time11, time12, time13, time14, time15;
    
    if (edgeTraceCount != 0){
        //------Read original image data------
        int maxConnectivityNumber = arrayEdgeTrace [edgeTraceCount-6];
        linkedLineMainCount = 1; //------Equivalent to cell number------
        int linkedLinePair = 1; //------Pair number------
        
        int edgeDataStart = 0;
        int edgeDataEnd = 0;
        int edgeDimension = 0;
        int edgeTempEntry = 0;
        int maxPointDimX = 0;
        int maxPointDimY = 0;
        int minPointDimX = 0;
        int minPointDimY = 0;
        int minValue = 0;
        int startEndStatus = 0;
        int lineLengthTemp = 0;
        int lineNumberTemp = 0;
        int lineNumberTemp2 = 0;
        int horizontalLength = 0;
        int verticalLength = 0;
        int horizontalStart = 0;
        int verticalStart = 0;
        int attachCount = 0;
        int lineCombineCount = 0;
        int lineCombineLimit = 0;
        int lowestPoint = 0;
        int highestPoint = 0;
        int lineDataTempCount = 0;
        int firstPosition = 0;
        int lineStartSet = 0;
        int flagXY = 0;
        int removedLineNumberListCount = 0;
        int removeTemp = 0;
        int removeCountTemp = 0;
        int reconstructionTempCount = 0;
        int reconstructionTempLimit = 0;
        int jumpX = 0;
        int jumpY = 0;
        int newBlockFind = 0;
        int jumpX2 = 0;
        int jumpY2 = 0;
        int secondPosition = 0;
        int secondLinLengthCount = 0;
        int secondEndPosition = 0;
        int chaseResult = 0;
        int skipFlag = 0;
        int terminationFlag2 = 0;
        int linePointCount = 0;
        int lineTrimmingX = 0;
        int lineTrimmingY = 0;
        int shortestTemp = 0;
        int shortestLineNumber = 0;
        int shortestCountTemp = 0;
        int processCount = 0;
        int positionTemp = 0;
        int attachPoint = 0;
        int countSave = 0;
        int lineTrimmingX2 = 0;
        int lineTrimmingY2 = 0;
        int lineLoopCount = 0;
        int skipPoint = 0;
        int lineLoopReconstructCount = 0;
        int lineLoopReconstructLimit = 0;
        int blockNumberFollow = 0;
        int blockNumberCount = 0;
        int newBlockNumber = 0;
        int blockNumberTemp = 0;
        int startFindFlag = 0;
        int counterLast = 0;
        int beforeSkip = 0;
        int startDataX = 0;
        int endDataX = 0;
        int startDataY = 0;
        int endDataY = 0;
        int startCount = 0;
        int endCount = 0;
        int enterFlag = 0;
        int blockCount1 = 0;
        int blockCount3 = 0;
        int blockCount5 = 0;
        int blockCount7 = 0;
        int latestBlockNumber = 0;
        int latestBlockNumberTemp = 0;
        int typeDefine = 0;
        int lineSet = 0;
        int findCombined = 0;
        int findNumberOfBlocksFive = 0;
        int blocksCountFive = 0;
        int longestFive = 0;
        int longestCountFive = 0;
        int findNumberOfBlocksSeven = 0;
        int blocksCountSeven = 0;
        int longestSeven = 0;
        int longestCountSeven = 0;
        int numberOfContent = 0;
        int startEndCount = 0;
        int findMatch = 0;
        int valueTempX = 0;
        int valueTempY = 0;
        int valueTempX2 = 0;
        int valueTempY2 = 0;
        int overlapFind = 0;
        int continuityCount = 0;
        int continuityCountSave = 0;
        int continuityStart = 0;
        int continuityStartSave = 0;
        int continuityEndSave = 0;
        int valueTempXRef = 0;
        int valueTempYRef = 0;
        int maxPointX = 0;
        int maxPointY = 0;
        int minPointX = 10000;
        int minPointY = 10000;
        int maxPointCountX = -1;
        int maxPointCountY = -1;
        int minPointCountX = -1;
        int minPointCountY = -1;
        int pointCounter = 0;
        int positionOne = 0;
        int positionTwo = 0;
        int breakFlag = 0;
        int findFlag = 0;
        
        //cout<<maxConnectivityNumber<<" StartEnd"<<endl;
        
        for (int counter1 = 1; counter1 <= maxConnectivityNumber; counter1++){
            //time1 = clock();
            
            for (int counter2 = 0; counter2 < edgeTraceStartEndCount/3; counter2++){
                if (arrayEdgeTraceStartEnd [counter2*3] == counter1){
                    edgeDataStart = arrayEdgeTraceStartEnd [counter2*3+1];
                    edgeDataEnd = arrayEdgeTraceStartEnd [counter2*3+2];
                    break;
                }
            }
            
            int *arrayEdgeTemp = new int [(edgeDataEnd-edgeDataStart)*9+90];
            
            //------Reading Edge Trace data------
            edgeTempEntry = 0;
            maxPointDimX = 0;
            maxPointDimY = 0;
            minPointDimX = 100000;
            minPointDimY = 100000;
            
            for (int counter2 = edgeDataStart; counter2 <= edgeDataEnd; counter2++){
                //------LineNumberTemp: Original line number, 1 or > 101, lineNumberTemp2: Line number, 1,2,3,4,5,6,7,8------
                startEndStatus = 0;
                lineNumberTemp2 = 0;
                
                if (arrayEdgeTrace [counter2*6+4] < 0 && arrayEdgeTrace [counter2*6+5] < 0) startEndStatus = 3; //------Single point------
                if (arrayEdgeTrace [counter2*6+4] > 0 && arrayEdgeTrace [counter2*6+5] < 0) startEndStatus = 1; //------Start------
                if (arrayEdgeTrace [counter2*6+4] < 0 && arrayEdgeTrace [counter2*6+5] > 0) startEndStatus = 2; //------End------
                
                if (arrayEdgeTrace [counter2*6+4] < 0) lineLengthTemp = arrayEdgeTrace [counter2*6+4]*-1; //------Line length, convert minus to plus------
                else lineLengthTemp = arrayEdgeTrace [counter2*6+4];
                
                if (arrayEdgeTrace [counter2*6+5] < 0) lineNumberTemp = arrayEdgeTrace [counter2*6+5]*-1; //------Line number, convert minus to plus------
                else lineNumberTemp = arrayEdgeTrace [counter2*6+5];
                
                if (arrayEdgeTrace [counter2*6+1] == 1 && lineNumberTemp <= 100) lineNumberTemp2 = 1;
                else if (arrayEdgeTrace [counter2*6+1] == 2 && lineNumberTemp <= 100) lineNumberTemp2 = 2;
                else if (arrayEdgeTrace [counter2*6+1] == 3 && lineNumberTemp <= 100) lineNumberTemp2 = 3;
                else if (arrayEdgeTrace [counter2*6+1] == 4 && lineNumberTemp <= 100) lineNumberTemp2 = 4;
                
                arrayEdgeTemp [edgeTempEntry] = arrayEdgeTrace [counter2*6+1], edgeTempEntry++; //------Orientation Number------0
                arrayEdgeTemp [edgeTempEntry] = arrayEdgeTrace [counter2*6+2], edgeTempEntry++; //------X position------1
                arrayEdgeTemp [edgeTempEntry] = arrayEdgeTrace [counter2*6+3], edgeTempEntry++; //------Y position------2
                arrayEdgeTemp [edgeTempEntry] = lineLengthTemp, edgeTempEntry++; //------Line length, at startEndStatus = 2, full length------3
                arrayEdgeTemp [edgeTempEntry] = lineNumberTemp, edgeTempEntry++; //------Line Number Original------4
                arrayEdgeTemp [edgeTempEntry] = lineNumberTemp2, edgeTempEntry++; //------Line Number------5
                arrayEdgeTemp [edgeTempEntry] = startEndStatus, edgeTempEntry++; //------Start/End status, 1: Start, 2: End, 3: one point------6
                arrayEdgeTemp [edgeTempEntry] = arrayExtractedImage [arrayEdgeTrace [counter2*6+3]][arrayEdgeTrace [counter2*6+2]], edgeTempEntry++; //------Original Pix Value------7
                arrayEdgeTemp [edgeTempEntry] = 0, edgeTempEntry++; //------DoneFlag------8
                
                if (maxPointDimX < arrayEdgeTrace [counter2*6+2]) maxPointDimX = arrayEdgeTrace [counter2*6+2];
                if (minPointDimX > arrayEdgeTrace [counter2*6+2]) minPointDimX = arrayEdgeTrace [counter2*6+2];
                if (maxPointDimY < arrayEdgeTrace [counter2*6+3]) maxPointDimY = arrayEdgeTrace [counter2*6+3];
                if (minPointDimY > arrayEdgeTrace [counter2*6+3]) minPointDimY = arrayEdgeTrace [counter2*6+3];
            }
            
            horizontalLength = (maxPointDimX-minPointDimX)/2*2;
            verticalLength = (maxPointDimY-minPointDimY)/2*2;
            edgeDimension = 0;
            
            if (horizontalLength >= verticalLength) edgeDimension = horizontalLength+30;
            if (horizontalLength < verticalLength) edgeDimension = verticalLength+30;
            
            edgeDimension = (edgeDimension/2)*2;
            
            horizontalStart = minPointDimX-(edgeDimension-horizontalLength)/2;
            verticalStart = minPointDimY-(edgeDimension-verticalLength)/2;
            
            //for (int counterA = 0; counterA < edgeTempEntry/9; counterA++){
            //	for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayEdgeTemp [counterA*9+counterB];
            //	cout<<" arrayEdgeTemp "<<counterA<<endl;
            //}
            
            int **sourceMatrix = new int *[edgeDimension+4]; //------Map hold edge point number, 1, 2, 3, 4, .... etc
            int **sourceMatrix2 = new int *[edgeDimension+4]; //------Map line number------
            
            for (int counter2 = 0; counter2 < edgeDimension+4; counter2++){
                sourceMatrix [counter2] = new int [edgeDimension+4];
                sourceMatrix2 [counter2] = new int [edgeDimension+4];
            }
            
            for (int counterY = 0; counterY < edgeDimension+4; counterY++){
                for (int counterX = 0; counterX < edgeDimension+4; counterX++){
                    sourceMatrix [counterY][counterX] = -1;
                    sourceMatrix2 [counterY][counterX] = 0;
                }
            }
            
            for (int counter2 = 0; counter2 < edgeTempEntry/9; counter2++){
                if (arrayEdgeTemp [counter2*9+1]-horizontalStart >= 0 && arrayEdgeTemp [counter2*9+1]-horizontalStart < edgeDimension && arrayEdgeTemp [counter2*9+2]-verticalStart >= 0 && arrayEdgeTemp [counter2*9+2]-verticalStart < edgeDimension){
                    sourceMatrix [arrayEdgeTemp [counter2*9+2]-verticalStart][arrayEdgeTemp [counter2*9+1]-horizontalStart] = counter2;
                    sourceMatrix2 [arrayEdgeTemp [counter2*9+2]-verticalStart][arrayEdgeTemp [counter2*9+1]-horizontalStart] = arrayEdgeTemp [counter2*9+5];
                }
            }
            
            //for (int counterA = 0; counterA < edgeDimension; counterA++){
            //	for (int counterB = 0; counterB < edgeDimension; counterB++) cout<<" "<<sourceMatrix [counterA][counterB];
            //	cout<<" sourceMatrix "<<counterA<<endl;
            //}
            
            //------Remove isolated single points------
            for (int counterY = 0; counterY < edgeDimension; counterY++){
                for (int counterX = 0; counterX < edgeDimension; counterX++){
                    if (sourceMatrix2 [counterY][counterX] > 0){
                        attachCount = 0;
                        
                        for (int counterY2 = counterY-1; counterY2 <= counterY+1; counterY2++){
                            for (int counterX2 = counterX-1; counterX2 <= counterX+1; counterX2++){
                                if (counterX2 >= 0 && counterX2 < edgeDimension && counterY2 >= 0 && counterY2 < edgeDimension){
                                    if (counterY2 == counterY && counterX2 == counterX);
                                    else{
                                        
                                        if (sourceMatrix2 [counterY][counterX] == 1 && (sourceMatrix2 [counterY2][counterX2] == 1 || sourceMatrix2 [counterY2][counterX2] == 3)) attachCount++;
                                        if (sourceMatrix2 [counterY][counterX] == 2 && (sourceMatrix2 [counterY2][counterX2] == 2 || sourceMatrix2 [counterY2][counterX2] == 4)) attachCount++;
                                        if (sourceMatrix2 [counterY][counterX] == 3 && (sourceMatrix2 [counterY2][counterX2] == 3 || sourceMatrix2 [counterY2][counterX2] == 1)) attachCount++;
                                        if (sourceMatrix2 [counterY][counterX] == 4 && (sourceMatrix2 [counterY2][counterX2] == 4 || sourceMatrix2 [counterY2][counterX2] == 2)) attachCount++;
                                    }
                                }
                            }
                        }
                        
                        if (attachCount == 0){
                            if (arrayEdgeTemp [sourceMatrix [counterY][counterX]*9+6] == 3) arrayEdgeTemp [sourceMatrix [counterY][counterX]*9+8] = 1; //------Write "1" to the isolated points------
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < edgeTempEntry/9; counterA++){
            //	for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayEdgeTemp [counterA*9+counterB];
            //	cout<<" arrayEdgeTemp "<<counterA<<endl;
            //}
            
            int *arrayLineCombine = new int [600];
            lineCombineCount = 0;
            lineCombineLimit = 600;
            
            for (int counter2 = 0; counter2 < 4; counter2++){
                //------Reading line info into arrayLineDataTemp, determin minX-maxX, minY-maxY------
                int *arrayLineDataTemp = new int [edgeTempEntry+50];
                
                lowestPoint = 10000;
                highestPoint = 0;
                lineDataTempCount = 0;
                
                for (int counter3 = 0; counter3 < edgeTempEntry/9; counter3++){
                    if (arrayEdgeTemp [counter3*9+5] == counter2+1 && arrayEdgeTemp [counter3*9+8] == 0){
                        arrayLineDataTemp [lineDataTempCount] = arrayEdgeTemp [counter3*9], lineDataTempCount++; //------Orientation------0
                        arrayLineDataTemp [lineDataTempCount] = arrayEdgeTemp [counter3*9+1], lineDataTempCount++; //------X position------1
                        arrayLineDataTemp [lineDataTempCount] = arrayEdgeTemp [counter3*9+2], lineDataTempCount++; //------Y position------2
                        arrayLineDataTemp [lineDataTempCount] = arrayEdgeTemp [counter3*9+3], lineDataTempCount++; //------Length------3
                        arrayLineDataTemp [lineDataTempCount] = arrayEdgeTemp [counter3*9+4], lineDataTempCount++; //------Line Original Number------4
                        arrayLineDataTemp [lineDataTempCount] = arrayEdgeTemp [counter3*9+5], lineDataTempCount++; //------Line number------5
                        arrayLineDataTemp [lineDataTempCount] = arrayEdgeTemp [counter3*9+6], lineDataTempCount++; //------Status------6
                        arrayLineDataTemp [lineDataTempCount] = arrayEdgeTemp [counter3*9+7], lineDataTempCount++; //------Pix Value------7
                        
                        if (counter2+1 == 1 || counter2+1 == 2){
                            if (arrayEdgeTemp [counter3*9+1] > highestPoint) highestPoint = arrayEdgeTemp [counter3*9+1];
                            if (arrayEdgeTemp [counter3*9+1] < lowestPoint) lowestPoint = arrayEdgeTemp [counter3*9+1];
                        }
                        if (counter2+1 == 3 || counter2+1 == 4){
                            if (arrayEdgeTemp [counter3*9+2] > highestPoint) highestPoint = arrayEdgeTemp [counter3*9+2];
                            if (arrayEdgeTemp [counter3*9+2] < lowestPoint) lowestPoint = arrayEdgeTemp [counter3*9+2];
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < lineDataTempCount/8; counterA++){
                //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineDataTemp [counterA*8+counterB];
                //	cout<<" arrayLineDataTemp "<<counterA<<endl;
                //}
                
                //cout<<lineDataTempCount<<" lineDataCount"<<endl;
                //cout<<lowestPoint<<" "<<highestPoint<<" LOWHIGH"<<endl;
                
                if (lowestPoint != 10000 && highestPoint != 0){ //------Line length rewriting, each point contains line length from 1, after this step, info in each point are full length------
                    lineStartSet = 0;
                    
                    for (int counter3 = 0; counter3 < lineDataTempCount/8; counter3++){
                        if (arrayLineDataTemp [counter3*8+6] == 1) lineStartSet = counter3;
                        if (arrayLineDataTemp [counter3*8+6] == 2){
                            for (int counter4 = lineStartSet; counter4 < counter3; counter4++) arrayLineDataTemp [counter4*8+3] = arrayLineDataTemp [counter3*8+3];
                        }
                    }
                    
                    int *overlapCheckMap = new int [highestPoint-lowestPoint+1]; //------Line overlap map------
                    int *countRecord = new int [highestPoint-lowestPoint+1]; //------Position in the array------
                    int *removedLineNumberList = new int [highestPoint-lowestPoint+1];
                    
                    flagXY = 0;
                    
                    for (int counter3 = 0; counter3 < highestPoint-lowestPoint+1; counter3++){
                        overlapCheckMap [counter3] = 0;
                        countRecord [counter3] = -1;
                        removedLineNumberList [counter3] = -1;
                    }
                    
                    //------Read data into "overlapCheckMap" and "countRecord"------
                    for (int counter3 = 0; counter3 < lineDataTempCount/8; counter3++){
                        if (arrayLineDataTemp [counter3*8+5] == 1 || arrayLineDataTemp [counter3*8+5] == 2){
                            overlapCheckMap [arrayLineDataTemp [counter3*8+1]-lowestPoint]++;
                            countRecord [arrayLineDataTemp [counter3*8+1]-lowestPoint] = counter3;
                            flagXY = 1;
                        }
                        if (arrayLineDataTemp [counter3*8+5] == 3 || arrayLineDataTemp [counter3*8+5] == 4){
                            overlapCheckMap [arrayLineDataTemp [counter3*8+2]-lowestPoint]++;
                            countRecord [arrayLineDataTemp [counter3*8+2]-lowestPoint] = counter3;
                            flagXY = 2;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < highestPoint-lowestPoint+1; counterA++){
                    //	cout<<overlapCheckMap [counterA]<<" "<<countRecord [counterA]<<" "<<highestPoint-lowestPoint+1<<" OverlapCheck"<<endl;
                    //}
                    
                    //==========Line ends connection (Line 1, 2, 3, 4)=========
                    removedLineNumberListCount = 0;
                    
                    //------Remove overlap lines, if lines are overlapped, remove shorter ones------
                    for (int counter3 = 0; counter3 < highestPoint-lowestPoint+1; counter3++){
                        if (overlapCheckMap [counter3] > 1){
                            removeTemp = overlapCheckMap [counter3];
                            removeCountTemp = 0;
                            
                            int **removeLine = new int *[removeTemp+1];
                            for (int counter4 = 0; counter4 < removeTemp+1; counter4++) removeLine [counter4] = new int [4];
                            
                            //------Get X, Y data of overlap points------
                            for (int counter4 = 0; counter4 < lineDataTempCount/8; counter4++){
                                if (flagXY == 1){
                                    if (arrayLineDataTemp [counter4*8+1] == counter3+lowestPoint){
                                        skipFlag = 0;
                                        
                                        for (int counter5 = 0; counter5 < removedLineNumberListCount; counter5++){
                                            if (removedLineNumberList [counter5] == arrayLineDataTemp [counter4*8+4]) skipFlag = 1;
                                        }
                                        
                                        if (skipFlag == 0){
                                            removeLine [removeCountTemp][0] = arrayLineDataTemp [counter4*8+3];
                                            removeLine [removeCountTemp][1] = arrayLineDataTemp [counter4*8+4];
                                            removeCountTemp++;
                                        }
                                    }
                                }
                                if (flagXY == 2){
                                    if (arrayLineDataTemp [counter4*8+2] == counter3+lowestPoint){
                                        skipFlag = 0;
                                        
                                        for (int counter5 = 0; counter5 < removedLineNumberListCount; counter5++){
                                            if (removedLineNumberList [counter5] == arrayLineDataTemp [counter4*8+4]) skipFlag = 1;
                                        }
                                        
                                        if (skipFlag == 0){
                                            removeLine [removeCountTemp][0] = arrayLineDataTemp [counter4*8+3];
                                            removeLine [removeCountTemp][1] = arrayLineDataTemp [counter4*8+4];
                                            removeCountTemp++;
                                        }
                                    }
                                }
                            }
                            
                            //------Remove from shorter ones, repeat until it become 1------
                            do{
                                
                                terminationFlag2 = 1;
                                shortestTemp = 10000;
                                shortestLineNumber = 0;
                                shortestCountTemp = 0;
                                processCount = removeTemp;
                                
                                for (int counter4 = 0; counter4 < removeTemp; counter4++){
                                    if (shortestTemp > removeLine [counter4][0] && removeLine [counter4][0] != -1){
                                        shortestTemp = removeLine [counter4][0];
                                        shortestLineNumber = removeLine [counter4][1];
                                        shortestCountTemp = counter4;
                                    }
                                }
                                
                                removedLineNumberList [removedLineNumberListCount] = shortestLineNumber;
                                removedLineNumberListCount++;
                                removeLine [shortestCountTemp][0] = -1;
                                removeLine [shortestCountTemp][1] = -1;
                                processCount = processCount-1;
                                
                                for (int counter4 = 0; counter4 < lineDataTempCount/8; counter4++){
                                    if (shortestLineNumber == arrayLineDataTemp [counter4*8+4]){
                                        if (flagXY == 1){
                                            overlapCheckMap [arrayLineDataTemp [counter4*8+1]-lowestPoint] = overlapCheckMap [arrayLineDataTemp [counter4*8+1]-lowestPoint]-1;
                                            
                                            if (overlapCheckMap [arrayLineDataTemp [counter4*8+1]-lowestPoint] == 0) countRecord [arrayLineDataTemp [counter4*8+1]-lowestPoint] = -1;
                                        }
                                        if (flagXY == 2){
                                            overlapCheckMap [arrayLineDataTemp [counter4*8+2]-lowestPoint] = overlapCheckMap [arrayLineDataTemp [counter4*8+2]-lowestPoint]-1;
                                            
                                            if (overlapCheckMap [arrayLineDataTemp [counter4*8+2]-lowestPoint] == 0) countRecord [arrayLineDataTemp [counter4*8+2]-lowestPoint] = -1;
                                        }
                                    }
                                }
                                
                                if (processCount == 1){ //------Re-set position data in the array------
                                    terminationFlag2 = 1;
                                    shortestLineNumber = 0;
                                    
                                    for (int counter4 = 0; counter4 < removeTemp; counter4++){
                                        if (removeLine [counter4][0] != -1) shortestLineNumber = removeLine [counter4][1];
                                    }
                                    
                                    for (int counter4 = 0; counter4 < lineDataTempCount/8; counter4++){
                                        if (shortestLineNumber == arrayLineDataTemp [counter4*8+4]){
                                            if (flagXY == 1) countRecord [arrayLineDataTemp [counter4*8+1]-lowestPoint] = counter4;
                                            if (flagXY == 2) countRecord [arrayLineDataTemp [counter4*8+2]-lowestPoint] = counter4;
                                        }
                                    }
                                }
                                
                            } while (terminationFlag2 == 0);
                            
                            for (int counter4 = 0; counter4 < removeTemp+1; counter4++) delete [] removeLine [counter4];
                            delete [] removeLine;
                        }
                    }
                    
                    delete [] removedLineNumberList;
                    
                    //for (int counterA = 0; counterA < highestPoint-lowestPoint+1; counterA++){
                    //	cout<<overlapCheckMap [counterA]<<" "<<countRecord [counterA]<<" OverlapCheck2"<<endl;
                    //}
                    
                    //------Line connection------
                    firstPosition = 0;
                    
                    for (int counter3 = 0; counter3 < highestPoint-lowestPoint+1; counter3++){
                        if (countRecord [counter3] != 0){
                            firstPosition = countRecord [counter3];
                            break;
                        }
                    }
                    
                    if (firstPosition != -1){
                        int *arrayReconstructionTemp = new int [arrayLineDataTemp [firstPosition*8+3]*6+60];
                        reconstructionTempCount = 0;
                        reconstructionTempLimit = arrayLineDataTemp [firstPosition*8+3]*6+60;
                        
                        jumpX = 0;
                        jumpY = 0;
                        
                        //------Save First Line fragment into arrayReconstructionTemp------
                        for (int counter3 = 0; counter3 < arrayLineDataTemp [firstPosition*8+3]; counter3++){
                            positionTemp = countRecord [counter3];
                            arrayReconstructionTemp [reconstructionTempCount] = arrayLineDataTemp [positionTemp*8+1], reconstructionTempCount++;
                            arrayReconstructionTemp [reconstructionTempCount] = arrayLineDataTemp [positionTemp*8+2], reconstructionTempCount++;
                            arrayReconstructionTemp [reconstructionTempCount] = arrayLineDataTemp [positionTemp*8+7], reconstructionTempCount++;
                            arrayReconstructionTemp [reconstructionTempCount] = counter2, reconstructionTempCount++;
                            arrayReconstructionTemp [reconstructionTempCount] = 1, reconstructionTempCount++;
                            arrayReconstructionTemp [reconstructionTempCount] = 0, reconstructionTempCount++;
                            
                            countRecord [counter3] = -1;
                            jumpX = arrayLineDataTemp [positionTemp*8+1];
                            jumpY = arrayLineDataTemp [positionTemp*8+2];
                        }
                        
                        //------Line connection------
                        newBlockFind = 1;
                        
                        do{
                            
                            terminationFlag2 = 1;
                            jumpX2 = -1;
                            jumpY2 = -1;
                            secondPosition = 0;
                            
                            //------Read start X, Y of next line fragment------
                            for (int counter3 = 0; counter3 < highestPoint-lowestPoint+1; counter3++){
                                if (countRecord [counter3] != -1){
                                    secondPosition = countRecord [counter3];
                                    jumpX2 = arrayLineDataTemp [secondPosition*8+1];
                                    jumpY2 = arrayLineDataTemp [secondPosition*8+2];
                                    break;
                                }
                            }
                            
                            if (jumpX2 == -1) terminationFlag2 = 0;
                            else{ //------Length of next line fragment------
                                
                                secondLinLengthCount = 0;
                                secondEndPosition = 0;
                                
                                for (int counter3 = 0; counter3 < highestPoint-lowestPoint+1; counter3++){
                                    if (countRecord [counter3] != -1 && secondLinLengthCount < arrayLineDataTemp [secondPosition*8+3]){
                                        secondEndPosition = counter3;
                                        secondLinLengthCount++;
                                    }
                                }
                                
                                //------Gap link by pix chase------
                                gapChase = [[GapChase alloc] init];
                                chaseResult = [gapChase gapChaseing1:jumpX:jumpY:jumpX2:jumpY2:counter2];
                                
                                if (chaseResult == 0){ //------If it is successful, save data------
                                    for (int counter3 = 0; counter3 < gapChaseCount/3; counter3++){
                                        if (reconstructionTempCount+7 > reconstructionTempLimit){
                                            int *arrayUpDate = new int [reconstructionTempCount+10];
                                            
                                            for (int counter4 = 0; counter4 < reconstructionTempCount; counter4++) arrayUpDate [counter4] = arrayReconstructionTemp [counter4];
                                            
                                            delete [] arrayReconstructionTemp;
                                            arrayReconstructionTemp = new int [reconstructionTempLimit+500];
                                            reconstructionTempLimit = reconstructionTempLimit+500;
                                            
                                            for (int counter4 = 0; counter4 < reconstructionTempCount; counter4++) arrayReconstructionTemp [counter4] = arrayUpDate [counter4];
                                            delete [] arrayUpDate;
                                        }
                                        
                                        arrayReconstructionTemp [reconstructionTempCount] = arrayGapChase [counter3*3], reconstructionTempCount++;
                                        arrayReconstructionTemp [reconstructionTempCount] = arrayGapChase [counter3*3+1], reconstructionTempCount++;
                                        arrayReconstructionTemp [reconstructionTempCount] = arrayGapChase [counter3*3+2], reconstructionTempCount++;
                                        arrayReconstructionTemp [reconstructionTempCount] = counter2, reconstructionTempCount++;
                                        arrayReconstructionTemp [reconstructionTempCount] = newBlockFind, reconstructionTempCount++;
                                        arrayReconstructionTemp [reconstructionTempCount] = 1, reconstructionTempCount++; //------Vertical mark------
                                    }
                                }
                                else newBlockFind++; //------Not linked------
                                
                                //------Next line data entry, set XY position of next line end------
                                for (int counter3 = 0; counter3 < highestPoint-lowestPoint+1; counter3++){
                                    if (countRecord [counter3] != -1 && secondEndPosition >= counter3){
                                        if (reconstructionTempCount+7 > reconstructionTempLimit){
                                            int *arrayUpDate = new int [reconstructionTempCount+10];
                                            
                                            for (int counter4 = 0; counter4 < reconstructionTempCount; counter4++) arrayUpDate [counter4] = arrayReconstructionTemp [counter4];
                                            
                                            delete [] arrayReconstructionTemp;
                                            arrayReconstructionTemp = new int [reconstructionTempLimit+500];
                                            reconstructionTempLimit = reconstructionTempLimit+500;
                                            
                                            for (int counter4 = 0; counter4 < reconstructionTempCount; counter4++) arrayReconstructionTemp [counter4] = arrayUpDate [counter4];
                                            delete [] arrayUpDate;
                                        }
                                        
                                        positionTemp = countRecord [counter3];
                                        arrayReconstructionTemp [reconstructionTempCount] = arrayLineDataTemp [positionTemp*8+1], reconstructionTempCount++;
                                        arrayReconstructionTemp [reconstructionTempCount] = arrayLineDataTemp [positionTemp*8+2], reconstructionTempCount++;
                                        arrayReconstructionTemp [reconstructionTempCount] = arrayLineDataTemp [positionTemp*8+7], reconstructionTempCount++;
                                        arrayReconstructionTemp [reconstructionTempCount] = counter2, reconstructionTempCount++;
                                        arrayReconstructionTemp [reconstructionTempCount] = newBlockFind, reconstructionTempCount++;
                                        arrayReconstructionTemp [reconstructionTempCount] = 0, reconstructionTempCount++;
                                        
                                        countRecord [counter3] = -1;
                                        jumpX = arrayLineDataTemp [positionTemp*8+1];
                                        jumpY = arrayLineDataTemp [positionTemp*8+2];
                                    }
                                }
                            }
                            
                        } while (terminationFlag2 == 1);
                        
                        //for (int counterA = 0; counterA < reconstructionTempCount/6; counterA++){
                        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayReconstructionTemp [counterA*6+counterB];
                        //	cout<<" arrayReconstructionTemp "<<counterA<<endl;
                        //}
                        
                        //------Line cleaning------
                        if (reconstructionTempCount != 0){
                            linePointCount = reconstructionTempCount/6;
                            
                            int *lineTrimmingValue = new int [linePointCount+1];
                            int **lineTrimmingXY = new int *[linePointCount+1];
                            for (int counter3 = 0; counter3 < linePointCount+1; counter3++) lineTrimmingXY [counter3] = new int [3];
                            
                            for (int counter3 = 0; counter3 < linePointCount; counter3++){
                                lineTrimmingValue [counter3] = arrayReconstructionTemp [counter3*6+2];
                                lineTrimmingXY [counter3][0] = arrayReconstructionTemp [counter3*6];
                                lineTrimmingXY [counter3][1] = arrayReconstructionTemp [counter3*6+1];
                            }
                            
                            for (int counter3 = 0; counter3 < linePointCount-1; counter3++){
                                lineTrimmingX = lineTrimmingXY [counter3][0];
                                lineTrimmingY = lineTrimmingXY [counter3][1];
                                lineTrimmingXY [counter3][0] = -1;
                                lineTrimmingXY [counter3][1] = -1;
                                
                                if (lineTrimmingX != -1){
                                    attachPoint = 0;
                                    countSave = 0;
                                    
                                    for (int counter4 = counter3+1; counter4 < linePointCount; counter4++){
                                        lineTrimmingX2 = lineTrimmingXY [counter4][0];
                                        lineTrimmingY2 = lineTrimmingXY [counter4][1];
                                        
                                        for (int counterY = lineTrimmingY-1; counterY <= lineTrimmingY+1; counterY++){
                                            for (int counterX = lineTrimmingX-1; counterX <= lineTrimmingX+1; counterX++){
                                                if (counterX == lineTrimmingX2 && counterY == lineTrimmingY2){
                                                    attachPoint++;
                                                    
                                                    if (attachPoint == 1) countSave = counter4;
                                                    if (attachPoint > 1){
                                                        for (int counter5 = countSave; counter5 < counter4; counter5++){
                                                            lineTrimmingXY [counter5][0] = -1;
                                                            lineTrimmingXY [counter5][1] = -1;
                                                            lineTrimmingValue [counter5] = -1;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < linePointCount+1; counter3++) delete [] lineTrimmingXY [counter3];
                            delete [] lineTrimmingXY;
                            
                            //------Set cleaned line data------
                            int *arrayLineLoop = new int [linePointCount*6+60];
                            lineLoopCount = 0;
                            
                            for (int counter3 = 0; counter3 < linePointCount; counter3++){
                                if (lineTrimmingValue [counter3] != -1){
                                    arrayLineLoop [lineLoopCount] = arrayReconstructionTemp [counter3*6], lineLoopCount++;
                                    arrayLineLoop [lineLoopCount] = arrayReconstructionTemp [counter3*6+1], lineLoopCount++;
                                    arrayLineLoop [lineLoopCount] = arrayReconstructionTemp [counter3*6+2], lineLoopCount++;
                                    arrayLineLoop [lineLoopCount] = arrayReconstructionTemp [counter3*6+3], lineLoopCount++;
                                    arrayLineLoop [lineLoopCount] = arrayReconstructionTemp [counter3*6+4], lineLoopCount++;
                                    arrayLineLoop [lineLoopCount] = arrayReconstructionTemp [counter3*6+5], lineLoopCount++;
                                }
                            }
                            
                            delete [] lineTrimmingValue;
                            
                            //for (int counterA = 0; counterA < lineLoopCount/6; counterA++){
                            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayLineLoop [counterA*6+counterB];
                            //	cout<<" arrayLineLoop "<<counterA<<endl;
                            //}
                            
                            //------Remove line loops------
                            skipPoint = -1;
                            
                            int *arrayLineLoopReconstruction = new int [lineLoopCount+60];
                            lineLoopReconstructCount = 0;
                            lineLoopReconstructLimit = lineLoopCount+60;
                            
                            for (int counter3 = 0; counter3 < lineLoopCount/6; counter3++){
                                if (counter3 > skipPoint){ //------Find parallel lines------
                                    if (arrayLineLoop [counter3*6+5] == 1 && counter3 <= lineLoopCount/6-2){
                                        breakFlag = 0;
                                        
                                        for (int counter4 = counter3+1; counter4 < lineLoopCount/6; counter4++){
                                            findFlag = 0;
                                            
                                            if (counter2+1 == 1 || counter2+1 == 2){
                                                if (arrayLineLoop [counter3*6+4] == arrayLineLoop [counter4*6+4] && arrayLineLoop [counter3*6]+5 >= arrayLineLoop [counter4*6] && arrayLineLoop [counter3*6]+2 <= arrayLineLoop [counter4*6] && arrayLineLoop [counter3*6+1] == arrayLineLoop [counter4*6+1] && arrayLineLoop [counter4*6+5] == 1 && counter4-counter3 > 5){
                                                    findFlag = 1;
                                                }
                                            }
                                            
                                            if (counter2+1 == 3 ||counter2+1 == 4){
                                                if (arrayLineLoop [counter3*6+4] == arrayLineLoop [counter4*6+4] && arrayLineLoop [counter3*6+1]+5 >= arrayLineLoop [counter4*6+1] && arrayLineLoop [counter3*6+1]+2 <= arrayLineLoop [counter4*6+1] && arrayLineLoop [counter3*6] == arrayLineLoop [counter4*6] && arrayLineLoop [counter4*6+5] == 1 && counter4-counter3 > 5){
                                                    findFlag = 1;
                                                }
                                            }
                                            
                                            //------Connect root of parallel lines------
                                            if (findFlag == 1){
                                                gapChase = [[GapChase alloc] init];
                                                chaseResult = [gapChase gapChaseing1:arrayLineLoop [counter3*6]:arrayLineLoop [counter3*6+1]:arrayLineLoop [counter4*6]:arrayLineLoop [counter4*6+1]:counter2];
                                                
                                                if (chaseResult == 0){ //------If chase is successful------
                                                    if (lineLoopReconstructCount+12+gapChaseCount*3 > lineLoopReconstructLimit){
                                                        int *arrayUpDate = new int [lineLoopReconstructCount+10];
                                                        
                                                        for (int counter5 = 0; counter5 < lineLoopReconstructCount; counter5++) arrayUpDate [counter5] = arrayLineLoopReconstruction [counter5];
                                                        
                                                        delete [] arrayLineLoopReconstruction;
                                                        arrayLineLoopReconstruction = new int [lineLoopReconstructCount+12+gapChaseCount*3+500];
                                                        lineLoopReconstructLimit = lineLoopReconstructCount+12+gapChaseCount*3+500;
                                                        
                                                        for (int counter5 = 0; counter5 < lineLoopReconstructCount; counter5++) arrayLineLoopReconstruction [counter5] = arrayUpDate [counter5];
                                                        delete [] arrayUpDate;
                                                    }
                                                    
                                                    arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter3*6], lineLoopReconstructCount++;
                                                    arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter3*6+1], lineLoopReconstructCount++;
                                                    arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter3*6+2], lineLoopReconstructCount++;
                                                    arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter3*6+3], lineLoopReconstructCount++;
                                                    arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter3*6+4], lineLoopReconstructCount++;
                                                    arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter3*6+5], lineLoopReconstructCount++;
                                                    
                                                    for (int counter5 = 0; counter5 < gapChaseCount/3; counter5++){
                                                        arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayGapChase [counter5*3], lineLoopReconstructCount++;
                                                        arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayGapChase [counter5*3+1], lineLoopReconstructCount++;
                                                        arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayGapChase [counter5*3+2], lineLoopReconstructCount++;
                                                        arrayLineLoopReconstruction [lineLoopReconstructCount] = counter2, lineLoopReconstructCount++;
                                                        arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter3*6+4], lineLoopReconstructCount++;
                                                        arrayLineLoopReconstruction [lineLoopReconstructCount] = 1, lineLoopReconstructCount++;
                                                    }
                                                    
                                                    arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter4*6], lineLoopReconstructCount++;
                                                    arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter4*6+1], lineLoopReconstructCount++;
                                                    arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter4*6+2], lineLoopReconstructCount++;
                                                    arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter4*6+3], lineLoopReconstructCount++;
                                                    arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter4*6+4], lineLoopReconstructCount++;
                                                    arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter4*6+5], lineLoopReconstructCount++;
                                                    
                                                    breakFlag = 1;
                                                    skipPoint = counter4; //------Set skip point, read through loop points------
                                                    break;
                                                }
                                            }
                                        }
                                        
                                        if (breakFlag == 0){ //------If no loop formed, enter data into the array------
                                            if (lineLoopReconstructCount+6 > lineLoopReconstructLimit){
                                                int *arrayUpDate = new int [lineLoopReconstructCount+10];
                                                
                                                for (int counter5 = 0; counter5 < lineLoopReconstructCount; counter5++) arrayUpDate [counter5] = arrayLineLoopReconstruction [counter5];
                                                
                                                delete [] arrayLineLoopReconstruction;
                                                arrayLineLoopReconstruction = new int [lineLoopReconstructLimit+500];
                                                lineLoopReconstructLimit = lineLoopReconstructLimit+500;
                                                
                                                for (int counter5 = 0; counter5 < lineLoopReconstructCount; counter5++) arrayLineLoopReconstruction [counter5] = arrayUpDate [counter5];
                                                delete [] arrayUpDate;
                                            }
                                            
                                            arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter3*6], lineLoopReconstructCount++;
                                            arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter3*6+1], lineLoopReconstructCount++;
                                            arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter3*6+2], lineLoopReconstructCount++;
                                            arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter3*6+3], lineLoopReconstructCount++;
                                            arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter3*6+4], lineLoopReconstructCount++;
                                            arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter3*6+5], lineLoopReconstructCount++;
                                        }
                                    }
                                    else{ //------If it is not a vertical pix, enter data------
                                        
                                        if (lineLoopReconstructCount+6 > lineLoopReconstructLimit){
                                            int *arrayUpDate = new int [lineLoopReconstructCount+10];
                                            
                                            for (int counter5 = 0; counter5 < lineLoopReconstructCount; counter5++) arrayUpDate [counter5] = arrayLineLoopReconstruction [counter5];
                                            
                                            delete [] arrayLineLoopReconstruction;
                                            arrayLineLoopReconstruction = new int [lineLoopReconstructLimit+500];
                                            lineLoopReconstructLimit = lineLoopReconstructLimit+500;
                                            
                                            for (int counter5 = 0; counter5 < lineLoopReconstructCount; counter5++) arrayLineLoopReconstruction [counter5] = arrayUpDate [counter5];
                                            delete [] arrayUpDate;
                                        }
                                        
                                        arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter3*6], lineLoopReconstructCount++;
                                        arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter3*6+1], lineLoopReconstructCount++;
                                        arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter3*6+2], lineLoopReconstructCount++;
                                        arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter3*6+3], lineLoopReconstructCount++;
                                        arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter3*6+4], lineLoopReconstructCount++;
                                        arrayLineLoopReconstruction [lineLoopReconstructCount] = arrayLineLoop [counter3*6+5], lineLoopReconstructCount++;
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < lineLoopReconstructCount/6; counterA++){
                            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayLineLoopReconstruction [counterA*6+counterB];
                            //	cout<<" arrayLineLoopReconstruction "<<counterA<<endl;
                            //}
                            
                            //------Line cleaning------
                            linePointCount = lineLoopReconstructCount/6;
                            
                            int *lineTrimmingValue2 = new int [linePointCount+1];
                            int *lineBlockNumber2 = new int [linePointCount+1];
                            int *blockStartEnd2 = new int [linePointCount+1];
                            
                            int **lineTrimmingXY2 = new int *[linePointCount+1];
                            for (int counter3 = 0; counter3 < linePointCount+1; counter3++) lineTrimmingXY2 [counter3] = new int [4];
                            
                            for (int counter3 = 0; counter3 < linePointCount; counter3++){
                                lineTrimmingValue2 [counter3] = arrayLineLoopReconstruction [counter3*6+2];
                                lineTrimmingXY2 [counter3][0] = arrayLineLoopReconstruction [counter3*6];
                                lineTrimmingXY2 [counter3][1] = arrayLineLoopReconstruction [counter3*6+1];
                                lineTrimmingXY2 [counter3][2] = arrayLineLoopReconstruction [counter3*6+4];
                                lineBlockNumber2 [counter3] = 0;
                                blockStartEnd2 [counter3] = 0;
                            }
                            
                            for (int counter3 = 0; counter3 < linePointCount-1; counter3++){
                                lineTrimmingX = lineTrimmingXY2 [counter3][0];
                                lineTrimmingY = lineTrimmingXY2 [counter3][1];
                                lineTrimmingXY2 [counter3][0] = -1;
                                lineTrimmingXY2 [counter3][1] = -1;
                                
                                if (lineTrimmingX != -1){
                                    attachPoint = 0;
                                    countSave = 0;
                                    
                                    for (int counter4 = counter3+1; counter4 < linePointCount; counter4++){
                                        lineTrimmingX2 = lineTrimmingXY2 [counter4][0];
                                        lineTrimmingY2 = lineTrimmingXY2 [counter4][1];
                                        
                                        for (int counterY = lineTrimmingY-1; counterY <= lineTrimmingY+1; counterY++){
                                            for (int counterX = lineTrimmingX-1; counterX <= lineTrimmingX+1; counterX++){
                                                if (counterX == lineTrimmingX2 && counterY == lineTrimmingY2){
                                                    attachPoint++;
                                                    
                                                    if (attachPoint == 1) countSave = counter4;
                                                    if (attachPoint > 1){
                                                        for (int counter5 = countSave; counter5 < counter4; counter5++){
                                                            lineTrimmingXY2 [counter5][0] = -1;
                                                            lineTrimmingXY2 [counter5][1] = -1;
                                                            lineTrimmingValue2 [counter5] = -1;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            
                            //------Remove single point block and block renumber------
                            blockNumberFollow = 0;
                            blockNumberCount = 0;
                            newBlockNumber = 0;
                            
                            for (int counter3 = 0; counter3 < linePointCount; counter3++){
                                if (blockNumberFollow != lineTrimmingXY2 [counter3][2] && blockNumberCount == 0){
                                    blockNumberCount = 1;
                                    blockNumberFollow = lineTrimmingXY2 [counter3][2];
                                    newBlockNumber = 1;
                                    lineBlockNumber2 [counter3] = 1;
                                }
                                else if (blockNumberFollow != lineTrimmingXY2 [counter3][2] && blockNumberCount != 0){
                                    if (blockNumberCount == 1){
                                        lineTrimmingXY2 [counter3-1][0] = -1;
                                        lineTrimmingXY2 [counter3-1][1] = -1;
                                        lineTrimmingValue2 [counter3-1] = -1;
                                        lineBlockNumber2 [counter3-1] = -1;
                                        lineBlockNumber2 [counter3] = newBlockNumber;
                                    }
                                    else{
                                        
                                        newBlockNumber++;
                                        lineBlockNumber2 [counter3] = newBlockNumber;
                                    }
                                    
                                    blockNumberFollow = lineTrimmingXY2 [counter3][2];
                                    blockNumberCount = 1;
                                }
                                else{
                                    
                                    blockNumberCount++;
                                    lineBlockNumber2 [counter3] = newBlockNumber;
                                }
                            }
                            
                            if (blockNumberCount == 1){
                                lineTrimmingXY2 [linePointCount-1][0] = -1;
                                lineTrimmingXY2 [linePointCount-1][1] = -1;
                                lineTrimmingValue2 [linePointCount-1] = -1;
                                lineBlockNumber2 [linePointCount-1] = -1;
                            }
                            
                            //------Start end mark------
                            blockNumberTemp = 0;
                            startFindFlag = 0;
                            counterLast = 0;
                            
                            for (int counter3 = 0; counter3 < linePointCount; counter3++){
                                if (lineBlockNumber2 [counter3] != -1){
                                    counterLast = counter3;
                                    
                                    if (blockNumberTemp != lineBlockNumber2 [counter3] && startFindFlag == 0){
                                        blockNumberTemp = lineBlockNumber2 [counter3];
                                        blockStartEnd2 [counter3] = 1;
                                        startFindFlag = 1;
                                    }
                                    else if (blockNumberTemp != lineBlockNumber2 [counter3] && startFindFlag == 1){
                                        blockNumberTemp = lineBlockNumber2 [counter3];
                                        beforeSkip = -1;
                                        
                                        if (lineBlockNumber2 [counter3-1] == -1){
                                            for (int counter4 = counter3-1; counter4 >= 0; counter4 = counter4-1){
                                                if (lineBlockNumber2 [counter4] != -1){
                                                    beforeSkip = counter4;
                                                    break;
                                                }
                                            }
                                        }
                                        if (beforeSkip == -1) blockStartEnd2 [counter3-1] = 2;
                                        else blockStartEnd2 [beforeSkip] = 2;
                                        
                                        blockStartEnd2 [counter3] = 1;
                                    }
                                }
                            }
                            if (blockStartEnd2 [counterLast] == 0) blockStartEnd2 [counterLast] = 2;
                            
                            //------Enter data into arrayLineCombine------
                            for (int counter3 = 0; counter3 < lineLoopReconstructCount/6; counter3++){
                                if (lineTrimmingValue2 [counter3] != -1){
                                    if (lineCombineCount+8 > lineCombineLimit){
                                        int *arrayUpDate = new int [lineCombineCount+10];
                                        
                                        for (int counter5 = 0; counter5 < lineCombineCount; counter5++) arrayUpDate [counter5] = arrayLineCombine [counter5];
                                        
                                        delete [] arrayLineCombine;
                                        arrayLineCombine = new int [lineCombineLimit+500];
                                        lineCombineLimit = lineCombineLimit+500;
                                        
                                        for (int counter5 = 0; counter5 < lineCombineCount; counter5++) arrayLineCombine [counter5] = arrayUpDate [counter5];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    arrayLineCombine [lineCombineCount] = arrayLineLoopReconstruction [counter3*6], lineCombineCount++; //------ X position------0
                                    arrayLineCombine [lineCombineCount] = arrayLineLoopReconstruction [counter3*6+1], lineCombineCount++; //------Y position------1
                                    arrayLineCombine [lineCombineCount] = arrayLineLoopReconstruction [counter3*6+2], lineCombineCount++; //------PixValue------2
                                    arrayLineCombine [lineCombineCount] = arrayLineLoopReconstruction [counter3*6+3], lineCombineCount++; //------Line number------3
                                    arrayLineCombine [lineCombineCount] = lineBlockNumber2 [counter3], lineCombineCount++; //------Block number------4
                                    arrayLineCombine [lineCombineCount] = arrayLineLoopReconstruction [counter3*6+5], lineCombineCount++; //------Vertical mark------5
                                    arrayLineCombine [lineCombineCount] = blockStartEnd2 [counter3], lineCombineCount++; //------Start End mark------6
                                }
                            }
                            
                            delete [] lineTrimmingValue2;
                            delete [] lineBlockNumber2;
                            delete [] blockStartEnd2;
                            delete [] arrayLineLoop;
                            delete [] arrayLineLoopReconstruction;
                            
                            for (int counter3 = 0; counter3 < linePointCount+1; counter3++) delete [] lineTrimmingXY2 [counter3];
                            delete [] lineTrimmingXY2;
                        }
                        
                        delete [] arrayReconstructionTemp;
                    }
                    
                    delete [] overlapCheckMap;
                    delete [] countRecord;
                }
                
                delete [] arrayLineDataTemp;
            }
            
            delete [] arrayEdgeTemp;
            
            //for (int counterA = 0; counterA < lineCombineCount/7; counterA++){
            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayLineCombine [counterA*7+counterB];
            //	cout<<" arrayLineCombine "<<counterA<<endl;
            //}
            
            //time2 = clock();
            
            //------Number of data point find------
            arrayLineOne = new int [lineCombineCount*2+1];
            lineOneCount = 0;
            arrayLineThree = new int [lineCombineCount*2+1];
            lineThreeCount = 0;
            arrayLineFive = new int [lineCombineCount*2+1];
            lineFiveCount = 0;
            arrayLineSeven = new int [lineCombineCount*2+1];
            lineSevenCount = 0;
            
            startDataX = 0;
            startDataY = 0;
            startCount = -1;
            enterFlag = 0;
            blockCount1 = 0;
            blockCount3 = 0;
            blockCount5 = 0;
            blockCount7 = 0;
            
            for (int counter2 = 0; counter2 < lineCombineCount/7; counter2++){
                if (arrayLineCombine [counter2*7+6] == 1 && enterFlag == 0){
                    startCount = counter2;
                    startDataX = arrayLineCombine [counter2*7];
                    startDataY = arrayLineCombine [counter2*7+1];
                    enterFlag = 1;
                }
                else if (arrayLineCombine [counter2*7+6] == 2 && enterFlag == 1){
                    endCount = counter2;
                    endDataX = arrayLineCombine [counter2*7];
                    endDataY = arrayLineCombine [counter2*7+1];
                    enterFlag = 0;
                    
                    if (arrayLineCombine [counter2*7+3] == 0){
                        blockCount1++;
                        
                        if (startDataX > endDataX){
                            for (int counter3 = endCount; counter3 >= startCount; counter3 = counter3-1){
                                arrayLineOne [lineOneCount] = arrayLineCombine [counter3*7], lineOneCount++; //------X position------0
                                arrayLineOne [lineOneCount] = arrayLineCombine [counter3*7+1], lineOneCount++; //------Y position------1
                                arrayLineOne [lineOneCount] = arrayLineCombine [counter3*7+2], lineOneCount++;
                                arrayLineOne [lineOneCount] = blockCount1, lineOneCount++; //------Block------3
                                arrayLineOne [lineOneCount] = 0, lineOneCount++; //------For combined line mark------4
                                
                                if (counter3 == endCount) arrayLineOne [lineOneCount] = 0, lineOneCount++; //------Start end------5
                                else if (counter3 == startCount) arrayLineOne [lineOneCount] = 2, lineOneCount++;
                                else arrayLineOne [lineOneCount] = 0, lineOneCount++;
                            }
                        }
                        if (startDataX < endDataX){
                            for (int counter3 = startCount; counter3 <= endCount; counter3++){
                                arrayLineOne [lineOneCount] = arrayLineCombine [counter3*7], lineOneCount++;
                                arrayLineOne [lineOneCount] = arrayLineCombine [counter3*7+1], lineOneCount++;
                                arrayLineOne [lineOneCount] = arrayLineCombine [counter3*7+2], lineOneCount++;
                                arrayLineOne [lineOneCount] = blockCount1, lineOneCount++;
                                arrayLineOne [lineOneCount] = 0, lineOneCount++;
                                
                                if (counter3 == startCount) arrayLineOne [lineOneCount] = 1, lineOneCount++;
                                else if (counter3 == endCount) arrayLineOne [lineOneCount] = 2, lineOneCount++;
                                else arrayLineOne [lineOneCount] = 0, lineOneCount++;
                            }
                        }
                    }
                    if (arrayLineCombine [counter2*7+3] == 1){
                        blockCount3++;
                        
                        if (startDataX < endDataX){
                            for (int counter3 = endCount; counter3 >= startCount; counter3 = counter3-1){
                                arrayLineThree [lineThreeCount] = arrayLineCombine [counter3*7], lineThreeCount++;
                                arrayLineThree [lineThreeCount] = arrayLineCombine [counter3*7+1], lineThreeCount++;
                                arrayLineThree [lineThreeCount] = arrayLineCombine [counter3*7+2], lineThreeCount++;
                                arrayLineThree [lineThreeCount] = blockCount3, lineThreeCount++;
                                arrayLineThree [lineThreeCount] = 0, lineThreeCount++;
                                
                                if (counter3 == endCount) arrayLineThree [lineThreeCount] = 1, lineThreeCount++;
                                else if (counter3 == startCount) arrayLineThree [lineThreeCount] = 2, lineThreeCount++;
                                else arrayLineThree [lineThreeCount] = 0, lineThreeCount++;
                            }
                        }
                        if (startDataX > endDataX){
                            for (int counter3 = startCount; counter3 <= endCount; counter3++){
                                arrayLineThree [lineThreeCount] = arrayLineCombine [counter3*7], lineThreeCount++;
                                arrayLineThree [lineThreeCount] = arrayLineCombine [counter3*7+1], lineThreeCount++;
                                arrayLineThree [lineThreeCount] = arrayLineCombine [counter3*7+2], lineThreeCount++;
                                arrayLineThree [lineThreeCount] = blockCount3, lineThreeCount++;
                                arrayLineThree [lineThreeCount] = 0, lineThreeCount++;
                                
                                if (counter3 == startCount) arrayLineThree [lineThreeCount] = 1, lineThreeCount++;
                                else if (counter3 == endCount) arrayLineThree [lineThreeCount] = 2, lineThreeCount++;
                                else arrayLineThree [lineThreeCount] = 0, lineThreeCount++;
                            }
                        }
                    }
                    if (arrayLineCombine [counter2*7+3] == 2){
                        blockCount5++;
                        
                        if (startDataY < endDataY){
                            for (int counter3 = endCount; counter3 >= startCount; counter3= counter3-1){
                                arrayLineFive [lineFiveCount] = arrayLineCombine [counter3*7], lineFiveCount++;
                                arrayLineFive [lineFiveCount] = arrayLineCombine [counter3*7+1], lineFiveCount++;
                                arrayLineFive [lineFiveCount] = arrayLineCombine [counter3*7+2], lineFiveCount++;
                                arrayLineFive [lineFiveCount] = blockCount5, lineFiveCount++;
                                arrayLineFive [lineFiveCount] = 0, lineFiveCount++;
                                
                                if (counter3 == endCount) arrayLineFive [lineFiveCount] = 1, lineFiveCount++;
                                else if (counter3 == startCount) arrayLineFive [lineFiveCount] = 2, lineFiveCount++;
                                else arrayLineFive [lineFiveCount] = 0, lineFiveCount++;
                            }
                        }
                        if (startDataY > endDataY){
                            for (int counter3 = startCount; counter3 <= endCount; counter3++){
                                arrayLineFive [lineFiveCount] = arrayLineCombine [counter3*7], lineFiveCount++;
                                arrayLineFive [lineFiveCount] = arrayLineCombine [counter3*7+1], lineFiveCount++;
                                arrayLineFive [lineFiveCount] = arrayLineCombine [counter3*7+2], lineFiveCount++;
                                arrayLineFive [lineFiveCount] = blockCount5, lineFiveCount++;
                                arrayLineFive [lineFiveCount] = 0, lineFiveCount++;
                                
                                if (counter3 == startCount) arrayLineFive [lineFiveCount] = 1, lineFiveCount++;
                                else if (counter3 == endCount) arrayLineFive [lineFiveCount] = 2, lineFiveCount++;
                                else arrayLineFive [lineFiveCount] = 0, lineFiveCount++;
                            }
                        }
                    }
                    if (arrayLineCombine [counter2*7+3] == 3){
                        blockCount7++;
                        
                        if (startDataY > endDataY){
                            for (int counter3 = endCount; counter3 >= startCount; counter3 = counter3-1){
                                arrayLineSeven [lineSevenCount] = arrayLineCombine [counter3*7], lineSevenCount++;
                                arrayLineSeven [lineSevenCount] = arrayLineCombine [counter3*7+1], lineSevenCount++;
                                arrayLineSeven [lineSevenCount] = arrayLineCombine [counter3*7+2], lineSevenCount++;
                                arrayLineSeven [lineSevenCount] = blockCount7, lineSevenCount++;
                                arrayLineSeven [lineSevenCount] = 0, lineSevenCount++;
                                
                                if (counter3 == endCount) arrayLineSeven [lineSevenCount] = 1, lineSevenCount++;
                                else if (counter3 == startCount) arrayLineSeven [lineSevenCount] = 2, lineSevenCount++;
                                else arrayLineSeven [lineSevenCount] = 0, lineSevenCount++;
                            }
                        }
                        if (startDataY <= endDataY){
                            for (int counter3 = startCount; counter3 <= endCount; counter3++){
                                arrayLineSeven [lineSevenCount] = arrayLineCombine [counter3*7], lineSevenCount++;
                                arrayLineSeven [lineSevenCount] = arrayLineCombine [counter3*7+1], lineSevenCount++;
                                arrayLineSeven [lineSevenCount] = arrayLineCombine [counter3*7+2], lineSevenCount++;
                                arrayLineSeven [lineSevenCount] = blockCount7, lineSevenCount++;
                                arrayLineSeven [lineSevenCount] = 0, lineSevenCount++;
                                
                                if (counter3 == startCount) arrayLineSeven [lineSevenCount] = 1, lineSevenCount++;
                                else if (counter3 == endCount) arrayLineSeven [lineSevenCount] = 2, lineSevenCount++;
                                else arrayLineSeven [lineSevenCount] = 0, lineSevenCount++;
                            }
                        }
                    }
                }
            }
            
            delete [] arrayLineCombine;
            
            //------LinkPoint setting------
            linkPoint = [[LinkPoint alloc] init];
            [linkPoint lineEndAdjust];
            
            //==================ONE FIVE================
            //for (int counterA = 0; counterA < lineOneCount/6; counterA++){
            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayLineOne [counterA*6+counterB];
            //	cout<<" arrayLineOne "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < lineFiveCount/6; counterA++){
            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayLineFive [counterA*6+counterB];
            //	cout<<" arrayLineFive "<<counterA<<endl;
            //}
            
            if (lineOneCount != 0 && lineFiveCount != 0){
                typeDefine = 1;
                lineSet = 1;
                lineSelect = [[LineSelect alloc] init];
                [lineSelect lineCombine:typeDefine:lineSet]; //------Start End marks were removed------
            }
            
            if (lineOneCount != 0){ //------Combine Five with One------
                if (lineFiveCount != 0){
                    latestBlockNumber = arrayLineFive [(lineFiveCount/6-1)*6+3];
                }
                else latestBlockNumber = 0;
                
                latestBlockNumberTemp = 0;
                
                for (int counter2 = 0; counter2 < lineOneCount/6; counter2++){
                    if (latestBlockNumberTemp != arrayLineOne [counter2*6+3]){
                        latestBlockNumberTemp = arrayLineOne [counter2*6+3];
                        latestBlockNumber++;
                        
                        arrayLineFive [lineFiveCount] = arrayLineOne [counter2*6], lineFiveCount++; //------X Position------0
                        arrayLineFive [lineFiveCount] = arrayLineOne [counter2*6+1], lineFiveCount++; //------Y position------1
                        arrayLineFive [lineFiveCount] = arrayLineOne [counter2*6+2], lineFiveCount++; //------Value------2
                        arrayLineFive [lineFiveCount] = latestBlockNumber, lineFiveCount++; //------Block------3
                        arrayLineFive [lineFiveCount] = arrayLineOne [counter2*6+4], lineFiveCount++; //------Combine------4
                        arrayLineFive [lineFiveCount] = arrayLineOne [counter2*6+5], lineFiveCount++; //------Status------
                    }
                    else{
                        
                        arrayLineFive [lineFiveCount] = arrayLineOne [counter2*6], lineFiveCount++;
                        arrayLineFive [lineFiveCount] = arrayLineOne [counter2*6+1], lineFiveCount++;
                        arrayLineFive [lineFiveCount] = arrayLineOne [counter2*6+2], lineFiveCount++;
                        arrayLineFive [lineFiveCount] = latestBlockNumber, lineFiveCount++;
                        arrayLineFive [lineFiveCount] = arrayLineOne [counter2*6+4], lineFiveCount++;
                        arrayLineFive [lineFiveCount] = arrayLineOne [counter2*6+5], lineFiveCount++;
                    }
                }
            }
            
            delete [] arrayLineOne;
            
            //time3 = clock();
            
            if (lineFiveCount != 0){
                lineSet = 1;
                
                arrayModification = [[ArrayModification alloc] init];
                [arrayModification lineFlip:lineSet];
                [arrayModification lineLengthTwoRemove:lineSet];
                
                lineConnect = [[LineConnect alloc] init];
                [lineConnect lineConnectSameType:lineSet];
                
                // cout<<"LineChaseTime6 "<<time2-time1<<endl;
                
                //for (int counterA = 0; counterA < lineFiveCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayLineFive [counterA*6+counterB];
                //	cout<<" arrayLineFive "<<counterA<<endl;
                //}
                
                findCombined = 0;
                findNumberOfBlocksFive = 0;
                blocksCountFive = 0;
                longestFive = 0;
                longestCountFive = 0;
                
                for (int counter2 = 0; counter2 < lineFiveCount/6; counter2++){
                    if (arrayLineFive [counter2*6+4] == 1){
                        findCombined = 1;
                        break;
                    }
                    if (arrayLineFive [counter2*6+5] == 1) findNumberOfBlocksFive = counter2, blocksCountFive++;
                    else if (arrayLineFive [counter2*6+5] == 2){
                        if (longestCountFive < blocksCountFive){
                            longestFive = findNumberOfBlocksFive;
                            longestCountFive = blocksCountFive+1;
                        }
                        
                        blocksCountFive = 0;
                    }
                    else blocksCountFive++;
                }
                
                if (findCombined == 0){
                    for (int counter2 = longestFive; counter2 < lineFiveCount/6; counter2++){
                        if (arrayLineFive [counter2*6+5] == 2){
                            arrayLineFive [counter2*6+4] = 1;
                            arrayLineFive [counter2*6+3] = 1;
                            break;
                        }
                        else{
                            
                            arrayLineFive [counter2*6+4] = 1;
                            arrayLineFive [counter2*6+3] = 1;
                        }
                    }
                }
            }
            
            //==================THREE SEVEN================
            //for (int counterA = 0; counterA < lineThreeCount/6; counterA++){
            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayLineThree [counterA*6+counterB];
            //	cout<<" arrayLineThree "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < lineSevenCount/6; counterA++){
            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayLineSeven [counterA*6+counterB];
            //	cout<<" arrayLineSeven "<<counterA<<endl;
            //}
            
            if (lineThreeCount != 0 && lineFiveCount != 0){
                typeDefine = 3;
                lineSet = 3;
                lineSelect = [[LineSelect alloc] init];
                [lineSelect lineCombine:typeDefine:lineSet];
            }
            
            if (lineThreeCount != 0 ){
                if (lineSevenCount != 0){
                    latestBlockNumber = arrayLineSeven [(lineSevenCount/6-1)*6+3];
                }
                else latestBlockNumber = 0;
                
                latestBlockNumberTemp = 0;
                
                for (int counter2 = 0; counter2 < lineThreeCount/6; counter2++){
                    if (latestBlockNumberTemp != arrayLineThree [counter2*6+3]){
                        latestBlockNumberTemp = arrayLineThree [counter2*6+3];
                        latestBlockNumber++;
                        
                        arrayLineSeven [lineSevenCount] = arrayLineThree [counter2*6], lineSevenCount++; //------X Position------0
                        arrayLineSeven [lineSevenCount] = arrayLineThree [counter2*6+1], lineSevenCount++; //------Y position------1
                        arrayLineSeven [lineSevenCount] = arrayLineThree [counter2*6+2], lineSevenCount++; //------Value------2
                        arrayLineSeven [lineSevenCount] = latestBlockNumber, lineSevenCount++; //------Block------3
                        arrayLineSeven [lineSevenCount] = arrayLineThree [counter2*6+4], lineSevenCount++; //------Combine------4
                        arrayLineSeven [lineSevenCount] = arrayLineThree [counter2*6+5], lineSevenCount++; //------Status------
                    }
                    else{
                        
                        arrayLineSeven [lineSevenCount] = arrayLineThree [counter2*6], lineSevenCount++; //------X Position------0
                        arrayLineSeven [lineSevenCount] = arrayLineThree [counter2*6+1], lineSevenCount++; //------Y position------1
                        arrayLineSeven [lineSevenCount] = arrayLineThree [counter2*6+2], lineSevenCount++; //------Value------2
                        arrayLineSeven [lineSevenCount] = latestBlockNumber, lineSevenCount++; //------Block------3
                        arrayLineSeven [lineSevenCount] = arrayLineThree [counter2*6+4], lineSevenCount++; //------Combine------4
                        arrayLineSeven [lineSevenCount] = arrayLineThree [counter2*6+5], lineSevenCount++; //------Status------
                    }
                }
            }
            
            delete [] arrayLineThree;
            
            if (lineSevenCount != 0){
                lineSet = 3;
                arrayModification = [[ArrayModification alloc] init];
                [arrayModification lineFlip:lineSet];
                [arrayModification lineLengthTwoRemove:lineSet];
                
                lineConnect = [[LineConnect alloc] init];
                [lineConnect lineConnectSameType:lineSet];
                
                findCombined = 0;
                findNumberOfBlocksSeven = 0;
                blocksCountSeven = 0;
                longestSeven = 0;
                longestCountSeven = 0;
                
                for (int counter2 = 0; counter2 < lineSevenCount/6; counter2++){
                    if (arrayLineSeven [counter2*6+4] == 1){
                        findCombined = 1;
                        break;
                    }
                    if (arrayLineSeven [counter2*6+5] == 1) findNumberOfBlocksSeven = counter2, blocksCountSeven++;
                    else if (arrayLineSeven [counter2*6+5] == 2){
                        if (longestCountSeven < blocksCountSeven){
                            longestSeven = findNumberOfBlocksSeven;
                            longestCountSeven = blocksCountSeven+1;
                        }
                        
                        blocksCountSeven = 0;
                    }
                    else blocksCountSeven++;
                }
                if (findCombined == 0){
                    for (int counter2 = longestSeven; counter2 < lineSevenCount/6; counter2++){
                        if (arrayLineSeven [counter2*6+5] == 2){
                            arrayLineSeven [counter2*6+4] = 1;
                            arrayLineSeven [counter2*6+3] = 1;
                            break;
                        }
                        else{
                            
                            arrayLineSeven [counter2*6+4] = 1;
                            arrayLineSeven [counter2*6+3] = 1;
                        }
                    }
                }
            }
            
            //------Edge Link------
            maxPointDimX = 0;
            maxPointDimY = 0;
            minPointDimX = 100000;
            minPointDimY = 100000;
            minValue = 10000;
            
            for (int counter2 = 0; counter2 < lineFiveCount/6; counter2++){
                if (maxPointDimX < arrayLineFive [counter2*6]) maxPointDimX = arrayLineFive [counter2*6];
                if (minPointDimX > arrayLineFive [counter2*6]) minPointDimX = arrayLineFive [counter2*6];
                if (maxPointDimY < arrayLineFive [counter2*6+1]) maxPointDimY = arrayLineFive [counter2*6+1];
                if (minPointDimY > arrayLineFive [counter2*6+1]) minPointDimY = arrayLineFive [counter2*6+1];
                if (minValue > arrayLineFive [counter2*6+2]) minValue = arrayLineFive [counter2*6+2];
            }
            
            for (int counter2 = 0; counter2 < lineSevenCount/6; counter2++){
                if (maxPointDimX < arrayLineSeven [counter2*6]) maxPointDimX = arrayLineSeven [counter2*6];
                if (minPointDimX > arrayLineSeven [counter2*6]) minPointDimX = arrayLineSeven [counter2*6];
                if (maxPointDimY < arrayLineSeven [counter2*6+1]) maxPointDimY = arrayLineSeven [counter2*6+1];
                if (minPointDimY > arrayLineSeven [counter2*6+1]) minPointDimY = arrayLineSeven [counter2*6+1];
                if (minValue > arrayLineSeven [counter2*6+2]) minValue = arrayLineSeven [counter2*6+2];
            }
            
            //for (int counterA = 0; counterA < linkedLineCount/5; counterA++){
            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayLinkedLine [counterA*5+counterB];
            //    cout<<" arrayLinkedLine "<<counterA<<" "<<counter1<<endl;
            //}
            
            linkedLineCount = 0;
            
            //time4 = clock();
            
            //------END LINK------
            if (lineFiveCount != 0 && lineSevenCount != 0){
                endlink = [[EndLink alloc] init];
                [endlink endLinkProcess:maxPointDimX:maxPointDimY:minPointDimX:minPointDimY:minValue];
                
                numberOfContent = 0;
                
                for (int counter2 = 0; counter2 < linkedLineCount/5; counter2++){
                    if (arrayLinkedLine [counter2*5+4] == 1) numberOfContent++;
                    if (arrayLinkedLine [counter2*5+4] == 2) numberOfContent++;
                }
                
                if (numberOfContent != 2) linkedLineCount = 0;
            }
            
            //time5 = clock();
            
            //for (int counterA = 0; counterA < lineSevenCount/6; counterA++){
            //		for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayLineSeven [counterA*6+counterB];
            //		cout<<" arrayLineSeven "<<counterA<<" "<<counter1<<endl;
            //	}
            //}
            
            delete [] arrayLineFive;
            delete [] arrayLineSeven;
            
            //------Line Gap Check and Fill------
            if (linkedLineCount != 0){
                numberOfContent = 0;
                
                for (int counter2 = 0; counter2 < linkedLineCount/5; counter2++){
                    if (arrayLinkedLine [counter2*5+4] == 2) numberOfContent++;
                }
                
                int **startEndPosition = new int *[numberOfContent+50];
                for (int counter2 = 0; counter2 < numberOfContent+50; counter2++) startEndPosition [counter2] = new int [3];
                
                startEndCount = 0;
                
                for (int counter2 = 0; counter2 < linkedLineCount/5; counter2++){
                    if (arrayLinkedLine [counter2*5+4] == 2){
                        startEndPosition [startEndCount][1] = counter2;
                        startEndCount++;
                    }
                }
                
                for (int counter2 = 0; counter2 < numberOfContent; counter2++){
                    if (counter2 == 0) startEndPosition [counter2][0] = 0;
                    else startEndPosition [counter2][0] = startEndPosition [counter2-1][1]+1;
                }
                
                int *arrayLinkedLineSaveTemp = new int [linkedLineCount*2+500], linkedLineSaveTempCount = 0;
                
                for (int counter2 = 0; counter2 < numberOfContent; counter2++){
                    int *arrayLinkedLineTemp = new int [linkedLineCount*2+500], linkedLineTempCount = 0;
                    valueTempX = arrayLinkedLine [startEndPosition [counter2][0]*5];
                    valueTempY = arrayLinkedLine [startEndPosition [counter2][0]*5+1];
                    
                    for (int counter3 = startEndPosition [counter2][0]; counter3 <= startEndPosition [counter2][1]; counter3++){
                        if (counter3 != startEndPosition [counter2][1]){
                            valueTempX2 = arrayLinkedLine [(counter3+1)*5];
                            valueTempY2 = arrayLinkedLine [(counter3+1)*5+1];
                        }
                        else{
                            
                            valueTempX2 = arrayLinkedLine [startEndPosition [counter2][0]*5];
                            valueTempY2 = arrayLinkedLine [startEndPosition [counter2][0]*5+1];
                        }
                        
                        findMatch = 0;
                        
                        for (int counterY2 = valueTempY-1; counterY2 <= valueTempY+1; counterY2++){
                            for (int counterX2 = valueTempX-1; counterX2 <= valueTempX+1; counterX2++){
                                if (counterY2 == valueTempY2 && counterX2 == valueTempX2) findMatch = 1;
                            }
                        }
                        
                        if (findMatch == 0){
                            arrayLinkedLineTemp [linkedLineTempCount] = arrayLinkedLine [counter3*5], linkedLineTempCount++;
                            arrayLinkedLineTemp [linkedLineTempCount] = arrayLinkedLine [counter3*5+1], linkedLineTempCount++;
                            arrayLinkedLineTemp [linkedLineTempCount] = arrayLinkedLine [counter3*5+2], linkedLineTempCount++;
                            arrayLinkedLineTemp [linkedLineTempCount] = arrayLinkedLine [counter3*5+3], linkedLineTempCount++;
                            
                            if (counter3 != startEndPosition [counter2][1]) arrayLinkedLineTemp [linkedLineTempCount] = arrayLinkedLine [counter3*5+4], linkedLineTempCount++;
                            else arrayLinkedLineTemp [linkedLineTempCount] = 0, linkedLineTempCount++;
                            
                            gapFill = [[GapFill alloc] init];
                            [gapFill gapFilling:valueTempX:valueTempY:valueTempX2:valueTempY2];
                            
                            for (int counter4 = 0; counter4 < gapDataCount/2; counter4++){
                                arrayLinkedLineTemp [linkedLineTempCount] = arrayGapData [counter4*2], linkedLineTempCount++;
                                arrayLinkedLineTemp [linkedLineTempCount] = arrayGapData [counter4*2+1], linkedLineTempCount++;
                                arrayLinkedLineTemp [linkedLineTempCount] = arrayExtractedImage [arrayGapData [counter4*2+1]][arrayGapData [counter4*2]], linkedLineTempCount++;
                                arrayLinkedLineTemp [linkedLineTempCount] = 0, linkedLineTempCount++;
                                
                                if (counter3 != startEndPosition [counter2][1]) arrayLinkedLineTemp [linkedLineTempCount] = 0, linkedLineTempCount++;
                                else arrayLinkedLineTemp [linkedLineTempCount] = 2, linkedLineTempCount++;
                            }
                        }
                        else{
                            
                            arrayLinkedLineTemp [linkedLineTempCount] = arrayLinkedLine [counter3*5], linkedLineTempCount++;
                            arrayLinkedLineTemp [linkedLineTempCount] = arrayLinkedLine [counter3*5+1], linkedLineTempCount++;
                            arrayLinkedLineTemp [linkedLineTempCount] = arrayLinkedLine [counter3*5+2], linkedLineTempCount++;
                            arrayLinkedLineTemp [linkedLineTempCount] = arrayLinkedLine [counter3*5+3], linkedLineTempCount++;
                            arrayLinkedLineTemp [linkedLineTempCount] = arrayLinkedLine [counter3*5+4], linkedLineTempCount++;
                        }
                        
                        valueTempX = valueTempX2;
                        valueTempY = valueTempY2;
                    }
                    
                    //------Line cleaning------
                    linePointCount = linkedLineTempCount/5;
                    
                    int **lineTrimmingXY0 = new int *[linePointCount+50];
                    int **lineTrimmingXY1 = new int *[linePointCount+50];
                    
                    for (int counter3 = 0; counter3 < linePointCount+50; counter3++){
                        lineTrimmingXY0 [counter3] = new int [3];
                        lineTrimmingXY1 [counter3] = new int [3];
                    }
                    
                    for (int counter3 = 0; counter3 < linePointCount; counter3++){
                        lineTrimmingXY0 [counter3][0] = arrayLinkedLineTemp [counter3*5];
                        lineTrimmingXY0 [counter3][1] = arrayLinkedLineTemp [counter3*5+1];
                        lineTrimmingXY1 [counter3][0] = 0;
                        lineTrimmingXY1 [counter3][1] = 0;
                    }
                    
                    for (int counter3 = 0; counter3 < linePointCount; counter3++){
                        lineTrimmingX = lineTrimmingXY0 [counter3][0];
                        lineTrimmingY = lineTrimmingXY0 [counter3][1];
                        attachPoint = 0;
                        
                        for (int counter4 = 0; counter4 < linePointCount; counter4++){
                            if (counter3 != counter4){
                                lineTrimmingX2 = lineTrimmingXY0 [counter4][0];
                                lineTrimmingY2 = lineTrimmingXY0 [counter4][1];
                                
                                for (int counterY = lineTrimmingY-1; counterY <= lineTrimmingY+1; counterY++){
                                    for (int counterX = lineTrimmingX-1; counterX <= lineTrimmingX+1; counterX++){
                                        if (counterX == lineTrimmingX2 && counterY == lineTrimmingY2) attachPoint++;
                                    }
                                }
                            }
                        }
                        
                        if (attachPoint > 2){
                            lineTrimmingXY1 [counter3][0] = -1;
                            lineTrimmingXY1 [counter3][1] = -1;
                        }
                        else{
                            
                            lineTrimmingXY1 [counter3][0] = lineTrimmingXY0 [counter3][0];
                            lineTrimmingXY1 [counter3][1] = lineTrimmingXY0 [counter3][1];
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < linePointCount+50; counter3++) delete [] lineTrimmingXY0 [counter3];
                    delete [] lineTrimmingXY0;
                    
                    overlapFind = 0;
                    continuityCount = 0;
                    continuityCountSave = 0;
                    continuityStart = 0;
                    continuityStartSave = 0;
                    continuityEndSave = 0;
                    
                    for (int counter3 = 0; counter3 < linePointCount; counter3++){
                        if (lineTrimmingXY1 [counter3][0] != -1 && overlapFind == 0){
                            overlapFind = 1;
                            continuityStart = counter3;
                            continuityCount++;
                        }
                        else if (lineTrimmingXY1 [counter3][0] != -1 && overlapFind == 1) continuityCount++;
                        else if (lineTrimmingXY1 [counter3][0] == -1 && overlapFind == 1){
                            if (continuityCount > continuityCountSave){
                                continuityCountSave = continuityCount;
                                continuityStartSave = continuityStart;
                                continuityEndSave = counter3-1;
                            }
                            
                            overlapFind = 0;
                            continuityCount = 0;
                        }
                        else if (counter3 == linePointCount-1 && overlapFind == 1){
                            if (continuityCount > continuityCountSave){
                                continuityCountSave = continuityCount;
                                continuityStartSave = continuityStart;
                                continuityEndSave = counter3;
                            }
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < linePointCount+50; counter3++) delete [] lineTrimmingXY1 [counter3];
                    delete [] lineTrimmingXY1;
                    
                    int *arrayLinkedLineTemp2 = new int [linkedLineCount*2+500], linkedLineTempCount2 = 0;
                    
                    startCount = (int)((continuityStartSave+continuityEndSave)/(double)2);
                    
                    for (int counter3 = startCount; counter3 < linePointCount; counter3++){
                        arrayLinkedLineTemp2 [linkedLineTempCount2] = arrayLinkedLineTemp [counter3*5], linkedLineTempCount2++;
                        arrayLinkedLineTemp2 [linkedLineTempCount2] = arrayLinkedLineTemp [counter3*5+1], linkedLineTempCount2++;
                        arrayLinkedLineTemp2 [linkedLineTempCount2] = arrayLinkedLineTemp [counter3*5+2], linkedLineTempCount2++;
                        arrayLinkedLineTemp2 [linkedLineTempCount2] = arrayLinkedLineTemp [counter3*5+3], linkedLineTempCount2++;
                        arrayLinkedLineTemp2 [linkedLineTempCount2] = arrayLinkedLineTemp [counter3*5+4], linkedLineTempCount2++;
                    }
                    
                    for (int counter3 = 0; counter3 < startCount; counter3++){
                        arrayLinkedLineTemp2 [linkedLineTempCount2] = arrayLinkedLineTemp [counter3*5], linkedLineTempCount2++;
                        arrayLinkedLineTemp2 [linkedLineTempCount2] = arrayLinkedLineTemp [counter3*5+1], linkedLineTempCount2++;
                        arrayLinkedLineTemp2 [linkedLineTempCount2] = arrayLinkedLineTemp [counter3*5+2], linkedLineTempCount2++;
                        arrayLinkedLineTemp2 [linkedLineTempCount2] = arrayLinkedLineTemp [counter3*5+3], linkedLineTempCount2++;
                        arrayLinkedLineTemp2 [linkedLineTempCount2] = arrayLinkedLineTemp [counter3*5+4], linkedLineTempCount2++;
                    }
                    
                    int *lineTrimmingValue2 = new int [linePointCount+50];
                    int **lineTrimmingXY2 = new int *[linePointCount+50];
                    
                    for (int counter3 = 0; counter3 < linePointCount+50; counter3++) lineTrimmingXY2 [counter3] = new int [4];
                    
                    for (int counter3 = 0; counter3 < linePointCount; counter3++){
                        lineTrimmingXY2 [counter3][0] = arrayLinkedLineTemp2 [counter3*5];
                        lineTrimmingXY2 [counter3][1] = arrayLinkedLineTemp2 [counter3*5+1];
                        lineTrimmingValue2 [counter3] = arrayLinkedLineTemp2 [counter3*5+2];
                    }
                    
                    delete [] arrayLinkedLineTemp;
                    
                    for (int counter3 = 1; counter3 < linePointCount-1; counter3++){
                        lineTrimmingX = lineTrimmingXY2 [counter3][0];
                        lineTrimmingY = lineTrimmingXY2 [counter3][1];
                        lineTrimmingXY2 [counter3][0] = -1;
                        lineTrimmingXY2 [counter3][1] = -1;
                        
                        if (lineTrimmingX != -1){
                            attachPoint = 0;
                            countSave = 0;
                            
                            for (int counter4 = counter3+1; counter4 < linePointCount; counter4++){
                                lineTrimmingX2 = lineTrimmingXY2 [counter4][0];
                                lineTrimmingY2 = lineTrimmingXY2 [counter4][1];
                                
                                for (int counterY = lineTrimmingY-1; counterY <= lineTrimmingY+1; counterY++){
                                    for (int counterX = lineTrimmingX-1; counterX <= lineTrimmingX+1; counterX++){
                                        if (counterX == lineTrimmingX2 && counterY == lineTrimmingY2){
                                            attachPoint++;
                                            
                                            if (attachPoint == 1) countSave = counter4;
                                            if (attachPoint > 1){
                                                for (int counter5 = countSave; counter5 < counter4; counter5++){
                                                    lineTrimmingXY2 [counter5][0] = -1;
                                                    lineTrimmingXY2 [counter5][1] = -1;
                                                    lineTrimmingValue2 [counter5] = -1;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < linePointCount+50; counter3++) delete [] lineTrimmingXY2 [counter3];
                    delete [] lineTrimmingXY2;
                    
                    int *arrayLinkedLineDuplicate = new int [linkedLineCount*2+500], linkedLineDuplicateCount = 0;
                    
                    for (int counter3 = 0; counter3 < linePointCount; counter3++){
                        if (lineTrimmingValue2 [counter3] != -1){
                            arrayLinkedLineDuplicate [linkedLineDuplicateCount] = arrayLinkedLineTemp2 [counter3*5], linkedLineDuplicateCount++;
                            arrayLinkedLineDuplicate [linkedLineDuplicateCount] = arrayLinkedLineTemp2 [counter3*5+1], linkedLineDuplicateCount++;
                            arrayLinkedLineDuplicate [linkedLineDuplicateCount] = arrayLinkedLineTemp2 [counter3*5+2], linkedLineDuplicateCount++;
                            arrayLinkedLineDuplicate [linkedLineDuplicateCount] = arrayLinkedLineTemp2 [counter3*5+3], linkedLineDuplicateCount++;
                            arrayLinkedLineDuplicate [linkedLineDuplicateCount] = 0, linkedLineDuplicateCount++;
                        }
                    }
                    
                    delete [] arrayLinkedLineTemp2;
                    delete [] lineTrimmingValue2;
                    
                    //for (int counterA = 0; counterA < linkedLineDuplicateCount/5; counterA++){
                    //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayLinkedLineDuplicate [counterA*5+counterB];
                    //	cout<<" arrayLinkedLineDuplicate "<<counterA<<endl;
                    //}
                    
                    if (linkedLineDuplicateCount/5 > 5){
                        valueTempXRef = arrayLinkedLineDuplicate [0];
                        valueTempYRef = arrayLinkedLineDuplicate [1];
                        
                        for (int counter3 = 1; counter3 < linkedLineDuplicateCount/5; counter3++){
                            if (counter3 != linkedLineDuplicateCount/5-1){
                                if (valueTempXRef == arrayLinkedLineDuplicate [counter3*5] && valueTempYRef == arrayLinkedLineDuplicate [counter3*5+1]) arrayLinkedLineDuplicate [counter3*5+4] = 1;
                                else{
                                    
                                    valueTempXRef = arrayLinkedLineDuplicate [counter3*5];
                                    valueTempYRef = arrayLinkedLineDuplicate [counter3*5+1];
                                }
                            }
                            else if (valueTempXRef == arrayLinkedLineDuplicate [counter3*5] && valueTempYRef == arrayLinkedLineDuplicate [counter3*5+1]) arrayLinkedLineDuplicate [counter3*5+4] = 1;
                            else{
                                
                                valueTempXRef = arrayLinkedLineDuplicate [counter3*5];
                                valueTempYRef = arrayLinkedLineDuplicate [counter3*5+1];
                            }
                            
                            if (valueTempXRef == arrayLinkedLineDuplicate [0] && valueTempYRef == arrayLinkedLineDuplicate [1]) arrayLinkedLineDuplicate [4] = 1;
                        }
                        
                        int *arrayLinkedLineTemp3 = new int [linkedLineCount*2+500], linkedLineTempCount3 = 0;
                        
                        for (int counter3 = 0; counter3 < linkedLineDuplicateCount/5; counter3++){
                            if (arrayLinkedLineDuplicate [counter3*5+4] != 1){
                                arrayLinkedLineTemp3 [linkedLineTempCount3] = arrayLinkedLineDuplicate [counter3*5], linkedLineTempCount3++;
                                arrayLinkedLineTemp3 [linkedLineTempCount3] = arrayLinkedLineDuplicate [counter3*5+1], linkedLineTempCount3++;
                                arrayLinkedLineTemp3 [linkedLineTempCount3] = arrayLinkedLineDuplicate [counter3*5+2], linkedLineTempCount3++;
                                arrayLinkedLineTemp3 [linkedLineTempCount3] = arrayLinkedLineDuplicate [counter3*5+3], linkedLineTempCount3++;
                                arrayLinkedLineTemp3 [linkedLineTempCount3] = 0, linkedLineTempCount3++;
                            }
                        }
                        
                        //------Point 1 and 2 determination------
                        maxPointX = 0;
                        maxPointY = 0;
                        minPointX = 10000;
                        minPointY = 10000;
                        maxPointCountX = -1;
                        maxPointCountY = -1;
                        minPointCountX = -1;
                        minPointCountY = -1;
                        pointCounter = 0;
                        
                        for (int counter3 = 0; counter3 < linkedLineTempCount3/5; counter3++){
                            valueTempX = arrayLinkedLineTemp3 [counter3*5];
                            valueTempY = arrayLinkedLineTemp3 [counter3*5+1];
                            
                            if (maxPointX < valueTempX){
                                maxPointX = valueTempX;
                                maxPointCountX = pointCounter;
                            }
                            if (minPointX > valueTempX){
                                minPointX = valueTempX;
                                minPointCountX = pointCounter;
                            }
                            if (maxPointY < valueTempY){
                                maxPointY = valueTempY;
                                maxPointCountY = pointCounter;
                            }
                            if (minPointY > valueTempY){
                                minPointY = valueTempY;
                                minPointCountY = pointCounter;
                            }
                            
                            pointCounter++;
                        }
                        
                        //cout<<maxPointX<<" "<<minPointX<<" "<<maxPointY<<" "<<minPointY<<" "<<maxPointCountX<<" "<<minPointCountX<<" "<<maxPointCountY<<" "<<minPointCountY<<" max/min"<<endl;
                        
                        //------Set Point 1 and 2, 1: Max X or Y, 2: Min X or Y------
                        if (maxPointX-minPointX > maxPointY-minPointY){
                            arrayLinkedLineTemp3 [maxPointCountX*5+4] = 1;
                            arrayLinkedLineTemp3 [minPointCountX*5+4] = 2;
                            positionOne = maxPointCountX;
                            positionTwo = minPointCountX;
                        }
                        else{
                            
                            arrayLinkedLineTemp3 [maxPointCountY*5+4] = 2;
                            arrayLinkedLineTemp3 [minPointCountY*5+4] = 1;
                            positionTwo = maxPointCountY;
                            positionOne = minPointCountY;
                        }
                        
                        //------Reorganize line data------
                        int *arrayLinkedLineTemp4 = new int [linkedLineCount*2+500], linkedLineTempCount4 = 0;
                        
                        if (linkedLineTempCount3/5 >= 3){
                            if (positionOne > positionTwo){
                                for (int counter3 = positionTwo+1; counter3 <= positionOne; counter3++){
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+1], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+2], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+3], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+4], linkedLineTempCount4++;
                                }
                                
                                for (int counter3 = positionOne+1; counter3 < linkedLineTempCount3/5; counter3++){
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+1], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+2], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+3], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+4], linkedLineTempCount4++;
                                }
                                
                                for (int counter3 = 0; counter3 <= positionTwo; counter3++){
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+1], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+2], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+3], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+4], linkedLineTempCount4++;
                                }
                            }
                            else{
                                
                                for (int counter3 = positionTwo+1; counter3 < linkedLineTempCount3/5; counter3++){
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+1], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+2], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+3], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+4], linkedLineTempCount4++;
                                }
                                
                                for (int counter3 = 0; counter3 <= positionOne; counter3++){
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+1], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+2], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+3], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+4], linkedLineTempCount4++;
                                }
                                
                                for (int counter3 = positionOne+1; counter3 <= positionTwo; counter3++){
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+1], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+2], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+3], linkedLineTempCount4++;
                                    arrayLinkedLineTemp4 [linkedLineTempCount4] = arrayLinkedLineTemp3 [counter3*5+4], linkedLineTempCount4++;
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < linkedLineTempCount4/5; counter3++){
                                arrayLinkedLineSaveTemp [linkedLineSaveTempCount] = arrayLinkedLineTemp4 [counter3*5], linkedLineSaveTempCount++;
                                arrayLinkedLineSaveTemp [linkedLineSaveTempCount] = arrayLinkedLineTemp4 [counter3*5+1], linkedLineSaveTempCount++;
                                arrayLinkedLineSaveTemp [linkedLineSaveTempCount] = arrayLinkedLineTemp4 [counter3*5+2], linkedLineSaveTempCount++;
                                arrayLinkedLineSaveTemp [linkedLineSaveTempCount] = arrayLinkedLineTemp4 [counter3*5+3], linkedLineSaveTempCount++;
                                arrayLinkedLineSaveTemp [linkedLineSaveTempCount] = arrayLinkedLineTemp4 [counter3*5+4], linkedLineSaveTempCount++;
                            }
                        }
                        
                        delete [] arrayLinkedLineTemp3;
                        delete [] arrayLinkedLineTemp4;
                    }
                    
                    delete [] arrayLinkedLineDuplicate;
                }
                
                for (int counter2 = 0; counter2 < numberOfContent+50; counter2++) delete [] startEndPosition [counter2];
                delete [] startEndPosition;
                
                if (linkedLineSaveTempCount != 0){
                    if (linkedLineSaveTempCount > linkedLineLimit){
                        delete [] arrayLinkedLine;
                        arrayLinkedLine = new int [linkedLineSaveTempCount+5000], linkedLineLimit = linkedLineSaveTempCount+5000;
                    }
                    
                    linkedLineCount = 0;
                    
                    for (int counter2 = 0; counter2 < linkedLineSaveTempCount/5; counter2++){
                        arrayLinkedLine [linkedLineCount] = arrayLinkedLineSaveTemp [counter2*5], linkedLineCount++;
                        arrayLinkedLine [linkedLineCount] = arrayLinkedLineSaveTemp [counter2*5+1], linkedLineCount++;
                        arrayLinkedLine [linkedLineCount] = arrayLinkedLineSaveTemp [counter2*5+2], linkedLineCount++;
                        arrayLinkedLine [linkedLineCount] = arrayLinkedLineSaveTemp [counter2*5+3], linkedLineCount++;
                        arrayLinkedLine [linkedLineCount] = arrayLinkedLineSaveTemp [counter2*5+4], linkedLineCount++;
                    }
                }
                
                delete [] arrayLinkedLineSaveTemp;
            }
            
            //time5 = clock();
            
            //------Shape Adjust------
            if (typeSubArray == 1){
                shapeAdjust = [[ShapeAdjust alloc] init];
                [shapeAdjust shapeAdjustMain:maxPointDimX:maxPointDimY:minPointDimX:minPointDimY:linkedLinePair:counter1];
            }
            
            if (typeSubArray != 1){
                upDateLine = [[UpDateLine alloc] init];
                [upDateLine upDateLineMain:counter1];
            }
            
            for (int counter2 = 0; counter2 < edgeDimension+4; counter2++){
                delete [] sourceMatrix2 [counter2];
                delete [] sourceMatrix [counter2];
            }
            
            delete [] sourceMatrix2;
            delete [] sourceMatrix;
            
            //time6 = clock();
            
            //cout<<" A "<<time2-time1<<endl;
            //cout<<" B "<<time3-time2<<endl;
            //cout<<" C "<<time4-time3<<endl;
            //cout<<" D "<<time5-time4<<endl;
            //cout<<" E "<<time6-time5<<endl;
        }
        
        //time7 = clock();
        
        forNextConnectivityCount = 0;
        forNextConnectivityAssCount = 0;
        overlapCheck = [[OverlapCheck alloc] init];
        [overlapCheck overlapCheckMain:typeSubArray];
        
        //time8 = clock();
        
        //for (int counterA = 0; counterA < forNextConnectivityCount/5; counterA++){
        //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayForNextConnectivity [counterA*5+counterB];
        //	cout<<" arrayForNextConnectivity "<<counterA<<" "<<counter1<<endl;
        //}
        
        //for (int counterA = 0; counterA < forNextConnectivityAssCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayForNextConnectivityAss [counterA*6+counterB];
        //	cout<<" arrayForNextConnectivityAss "<<counterA<<" "<<counter1<<endl;
        //}
        
        int *arrayForNextConnectivityTemp = new int [forNextConnectivityCount+5000], forNextConnectivityTempCount = 0;
        int *arrayForNextConnectivityTemp2 = new int [forNextConnectivityCount+5000], forNextConnectivityTempCount2 = 0;
        int *arrayForNextConnectivityAssTemp2 = new int [forNextConnectivityAssCount+500], forNextConnectivityAssTempCount2 = 0;
        
        int lineNumberCount = 1;
        
        for (int counter1 = 0; counter1 < forNextConnectivityCount/5; counter1++){
            if (arrayForNextConnectivity [counter1*5+3] != lineNumberCount || counter1 == forNextConnectivityCount/5-1){
                if (counter1 == forNextConnectivityCount/5-1){
                    arrayForNextConnectivityTemp [forNextConnectivityTempCount] = arrayForNextConnectivity [counter1*5], forNextConnectivityTempCount++;
                    arrayForNextConnectivityTemp [forNextConnectivityTempCount] = arrayForNextConnectivity [counter1*5+1], forNextConnectivityTempCount++;
                    arrayForNextConnectivityTemp [forNextConnectivityTempCount] = arrayForNextConnectivity [counter1*5+2], forNextConnectivityTempCount++;
                    arrayForNextConnectivityTemp [forNextConnectivityTempCount] = arrayForNextConnectivity [counter1*5+3], forNextConnectivityTempCount++;
                    arrayForNextConnectivityTemp [forNextConnectivityTempCount] = arrayForNextConnectivity [counter1*5+4], forNextConnectivityTempCount++;
                }
                
                if (forNextConnectivityTempCount/5 >= 4){
                    if (arrayForNextConnectivityTemp [4] == 1 && arrayForNextConnectivityTemp [(forNextConnectivityTempCount/5-1)*5+4] == 2){
                        for (int counter2 = 0; counter2 < forNextConnectivityTempCount/5; counter2++){
                            arrayForNextConnectivityTemp2 [forNextConnectivityTempCount2] = arrayForNextConnectivityTemp [counter2*5], forNextConnectivityTempCount2++;
                            arrayForNextConnectivityTemp2 [forNextConnectivityTempCount2] = arrayForNextConnectivityTemp [counter2*5+1], forNextConnectivityTempCount2++;
                            arrayForNextConnectivityTemp2 [forNextConnectivityTempCount2] = arrayForNextConnectivityTemp [counter2*5+2], forNextConnectivityTempCount2++;
                            arrayForNextConnectivityTemp2 [forNextConnectivityTempCount2] = lineNumberCount, forNextConnectivityTempCount2++;
                            arrayForNextConnectivityTemp2 [forNextConnectivityTempCount2] = arrayForNextConnectivityTemp [counter2*5+4], forNextConnectivityTempCount2++;
                        }
                        
                        for (int counter2 = 0; counter2 < forNextConnectivityAssCount/6; counter2++){
                            if ((arrayForNextConnectivity [counter1*5+3]-1 == arrayForNextConnectivityAss [counter2*6] && counter1 != forNextConnectivityCount/5-1) || (arrayForNextConnectivity [counter1*5+3] == arrayForNextConnectivityAss [counter2*6] && counter1 == forNextConnectivityCount/5-1)){
                                arrayForNextConnectivityAssTemp2 [forNextConnectivityAssTempCount2] = lineNumberCount, forNextConnectivityAssTempCount2++;
                                arrayForNextConnectivityAssTemp2 [forNextConnectivityAssTempCount2] = arrayForNextConnectivityAss [counter2*6+1], forNextConnectivityAssTempCount2++;
                                arrayForNextConnectivityAssTemp2 [forNextConnectivityAssTempCount2] = arrayForNextConnectivityAss [counter2*6+2], forNextConnectivityAssTempCount2++;
                                arrayForNextConnectivityAssTemp2 [forNextConnectivityAssTempCount2] = arrayForNextConnectivityAss [counter2*6+3], forNextConnectivityAssTempCount2++;
                                arrayForNextConnectivityAssTemp2 [forNextConnectivityAssTempCount2] = arrayForNextConnectivityAss [counter2*6+4], forNextConnectivityAssTempCount2++;
                                arrayForNextConnectivityAssTemp2 [forNextConnectivityAssTempCount2] = arrayForNextConnectivityAss [counter2*6+5], forNextConnectivityAssTempCount2++;
                                break;
                            }
                        }
                    }
                }
                
                lineNumberCount = arrayForNextConnectivity [counter1*5+3];
                forNextConnectivityTempCount = 0;
                
                arrayForNextConnectivityTemp [forNextConnectivityTempCount] = arrayForNextConnectivity [counter1*5], forNextConnectivityTempCount++;
                arrayForNextConnectivityTemp [forNextConnectivityTempCount] = arrayForNextConnectivity [counter1*5+1], forNextConnectivityTempCount++;
                arrayForNextConnectivityTemp [forNextConnectivityTempCount] = arrayForNextConnectivity [counter1*5+2], forNextConnectivityTempCount++;
                arrayForNextConnectivityTemp [forNextConnectivityTempCount] = arrayForNextConnectivity [counter1*5+3], forNextConnectivityTempCount++;
                arrayForNextConnectivityTemp [forNextConnectivityTempCount] = arrayForNextConnectivity [counter1*5+4], forNextConnectivityTempCount++;
            }
            else{
                
                arrayForNextConnectivityTemp [forNextConnectivityTempCount] = arrayForNextConnectivity [counter1*5], forNextConnectivityTempCount++;
                arrayForNextConnectivityTemp [forNextConnectivityTempCount] = arrayForNextConnectivity [counter1*5+1], forNextConnectivityTempCount++;
                arrayForNextConnectivityTemp [forNextConnectivityTempCount] = arrayForNextConnectivity [counter1*5+2], forNextConnectivityTempCount++;
                arrayForNextConnectivityTemp [forNextConnectivityTempCount] = arrayForNextConnectivity [counter1*5+3], forNextConnectivityTempCount++;
                arrayForNextConnectivityTemp [forNextConnectivityTempCount] = arrayForNextConnectivity [counter1*5+4], forNextConnectivityTempCount++;
            }
        }
        
        forNextConnectivityCount = 0;
        forNextConnectivityAssCount = 0;
        
        for (int counter1 = 0; counter1 < forNextConnectivityTempCount2/5; counter1++){
            arrayForNextConnectivity [forNextConnectivityCount] = arrayForNextConnectivityTemp2 [counter1*5], forNextConnectivityCount++;
            arrayForNextConnectivity [forNextConnectivityCount] = arrayForNextConnectivityTemp2 [counter1*5+1], forNextConnectivityCount++;
            arrayForNextConnectivity [forNextConnectivityCount] = arrayForNextConnectivityTemp2 [counter1*5+2], forNextConnectivityCount++;
            arrayForNextConnectivity [forNextConnectivityCount] = arrayForNextConnectivityTemp2 [counter1*5+3], forNextConnectivityCount++;
            arrayForNextConnectivity [forNextConnectivityCount] = arrayForNextConnectivityTemp2 [counter1*5+4], forNextConnectivityCount++;
        }
        
        for (int counter1 = 0; counter1 < forNextConnectivityAssTempCount2/6; counter1++){
            arrayForNextConnectivityAss [forNextConnectivityAssCount] = arrayForNextConnectivityAssTemp2 [counter1*6], forNextConnectivityAssCount++;
            arrayForNextConnectivityAss [forNextConnectivityAssCount] = arrayForNextConnectivityAssTemp2 [counter1*6+1], forNextConnectivityAssCount++;
            arrayForNextConnectivityAss [forNextConnectivityAssCount] = arrayForNextConnectivityAssTemp2 [counter1*6+2], forNextConnectivityAssCount++;
            arrayForNextConnectivityAss [forNextConnectivityAssCount] = arrayForNextConnectivityAssTemp2 [counter1*6+3], forNextConnectivityAssCount++;
            arrayForNextConnectivityAss [forNextConnectivityAssCount] = arrayForNextConnectivityAssTemp2 [counter1*6+4], forNextConnectivityAssCount++;
            arrayForNextConnectivityAss [forNextConnectivityAssCount] = arrayForNextConnectivityAssTemp2 [counter1*6+5], forNextConnectivityAssCount++;
        }
        
        delete [] arrayForNextConnectivityTemp;
        delete [] arrayForNextConnectivityTemp2;
        delete [] arrayForNextConnectivityAssTemp2;
        
        //for (int counterA = 0; counterA < forNextConnectivityCount/5; counterA++){
        //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayForNextConnectivity [counterA*5+counterB];
        //	cout<<" arrayForNextConnectivity "<<counterA<<" "<<counter1<<endl;
        //}
        
        //for (int counterA = 0; counterA < forNextConnectivityAssCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayForNextConnectivityAss [counterA*6+counterB];
        //	cout<<" arrayForNextConnectivityAss "<<counterA<<" "<<counter1<<endl;
        //}
        
        if (typeSubArray == 1){
            if (lineDataForDisplayStatus9 == 1) delete [] arrayLineDataForDisplay9;
            arrayLineDataForDisplay9 = new int [forNextConnectivityCount+50], lineDataForDisplayCount9 = 0, lineDataForDisplayStatus9 = 1;
            
            for (int counter1 = 0; counter1 < forNextConnectivityCount/5; counter1++){
                arrayLineDataForDisplay9 [lineDataForDisplayCount9] = arrayForNextConnectivity [counter1*5], lineDataForDisplayCount9++; //------X Position------0
                arrayLineDataForDisplay9 [lineDataForDisplayCount9] = arrayForNextConnectivity [counter1*5+1], lineDataForDisplayCount9++; //------Y position------1
                arrayLineDataForDisplay9 [lineDataForDisplayCount9] = 1, lineDataForDisplayCount9++;
            }
        }
        
        if (typeSubArray == 2){
            if (lineDataForDisplayStatus8 == 1) delete [] arrayLineDataForDisplay8;
            arrayLineDataForDisplay8 = new int [forNextConnectivityCount+outlineAdditionCount+outlineExistCount+50], lineDataForDisplayCount8 = 0, lineDataForDisplayStatus8 = 1;
            
            for (int counter1 = 0; counter1 < outlineAdditionCount/5; counter1++){
                arrayLineDataForDisplay8 [lineDataForDisplayCount8] = arrayOutlineAddition [counter1*5+1], lineDataForDisplayCount8++; //------X Position------0
                arrayLineDataForDisplay8 [lineDataForDisplayCount8] = arrayOutlineAddition [counter1*5+2], lineDataForDisplayCount8++; //------Y position------1
                arrayLineDataForDisplay8 [lineDataForDisplayCount8] = 2, lineDataForDisplayCount8++;
            }
            
            for (int counter1 = 0; counter1 < outlineExistCount/3; counter1++){
                arrayLineDataForDisplay8 [lineDataForDisplayCount8] = arrayOutlineExist [counter1*3+1], lineDataForDisplayCount8++; //------X Position------0
                arrayLineDataForDisplay8 [lineDataForDisplayCount8] = arrayOutlineExist [counter1*3+2], lineDataForDisplayCount8++; //------Y position------1
                arrayLineDataForDisplay8 [lineDataForDisplayCount8] = 1, lineDataForDisplayCount8++;
            }
            
            for (int counter1 = 0; counter1 < forNextConnectivityCount/5; counter1++){
                arrayLineDataForDisplay8 [lineDataForDisplayCount8] = arrayForNextConnectivity [counter1*5], lineDataForDisplayCount8++; //------X Position------0
                arrayLineDataForDisplay8 [lineDataForDisplayCount8] = arrayForNextConnectivity [counter1*5+1], lineDataForDisplayCount8++; //------Y position------1
                arrayLineDataForDisplay8 [lineDataForDisplayCount8] = 3, lineDataForDisplayCount8++;
            }
        }
        
        if (typeSubArray == 3){
            if (lineDataForDisplayStatus7 == 1) delete [] arrayLineDataForDisplay7;
            arrayLineDataForDisplay7 = new int [forNextConnectivityCount+outlineAdditionCount+outlineExistCount+50], lineDataForDisplayCount7 = 0, lineDataForDisplayStatus7 = 1;
            
            for (int counter1 = 0; counter1 < outlineAdditionCount/5; counter1++){
                arrayLineDataForDisplay7 [lineDataForDisplayCount7] = arrayOutlineAddition [counter1*5+1], lineDataForDisplayCount7++; //------X Position------0
                arrayLineDataForDisplay7 [lineDataForDisplayCount7] = arrayOutlineAddition [counter1*5+2], lineDataForDisplayCount7++; //------Y position------1
                arrayLineDataForDisplay7 [lineDataForDisplayCount7] = 2, lineDataForDisplayCount7++;
            }
            
            for (int counter1 = 0; counter1 < outlineExistCount/3; counter1++){
                arrayLineDataForDisplay7 [lineDataForDisplayCount7] = arrayOutlineExist [counter1*3+1], lineDataForDisplayCount7++; //------X Position------0
                arrayLineDataForDisplay7 [lineDataForDisplayCount7] = arrayOutlineExist [counter1*3+2], lineDataForDisplayCount7++; //------Y position------1
                arrayLineDataForDisplay7 [lineDataForDisplayCount7] = 1, lineDataForDisplayCount7++;
            }
            
            for (int counter1 = 0; counter1 < forNextConnectivityCount/5; counter1++){
                arrayLineDataForDisplay7 [lineDataForDisplayCount7] = arrayForNextConnectivity [counter1*5], lineDataForDisplayCount7++; //------X Position------0
                arrayLineDataForDisplay7 [lineDataForDisplayCount7] = arrayForNextConnectivity [counter1*5+1], lineDataForDisplayCount7++; //------Y position------1
                arrayLineDataForDisplay7 [lineDataForDisplayCount7] = 3, lineDataForDisplayCount7++;
            }
        }
        
        if (typeSubArray == 4){
            if (lineDataForDisplayStatus6 == 1) delete [] arrayLineDataForDisplay6;
            arrayLineDataForDisplay6 = new int [forNextConnectivityCount+outlineAdditionCount+outlineExistCount+50], lineDataForDisplayCount6 = 0, lineDataForDisplayStatus6 = 1;
            
            for (int counter1 = 0; counter1 < outlineAdditionCount/5; counter1++){
                arrayLineDataForDisplay6 [lineDataForDisplayCount6] = arrayOutlineAddition [counter1*5+1], lineDataForDisplayCount6++; //------X Position------0
                arrayLineDataForDisplay6 [lineDataForDisplayCount6] = arrayOutlineAddition [counter1*5+2], lineDataForDisplayCount6++; //------Y position------1
                arrayLineDataForDisplay6 [lineDataForDisplayCount6] = 2, lineDataForDisplayCount6++;
            }
            
            for (int counter1 = 0; counter1 < outlineExistCount/3; counter1++){
                arrayLineDataForDisplay6 [lineDataForDisplayCount6] = arrayOutlineExist [counter1*3+1], lineDataForDisplayCount6++; //------X Position------0
                arrayLineDataForDisplay6 [lineDataForDisplayCount6] = arrayOutlineExist [counter1*3+2], lineDataForDisplayCount6++; //------Y position------1
                arrayLineDataForDisplay6 [lineDataForDisplayCount6] = 1, lineDataForDisplayCount6++;
            }
            
            for (int counter1 = 0; counter1 < forNextConnectivityCount/5; counter1++){
                arrayLineDataForDisplay6 [lineDataForDisplayCount6] = arrayForNextConnectivity [counter1*5], lineDataForDisplayCount6++; //------X Position------0
                arrayLineDataForDisplay6 [lineDataForDisplayCount6] = arrayForNextConnectivity [counter1*5+1], lineDataForDisplayCount6++; //------Y position------1
                arrayLineDataForDisplay6 [lineDataForDisplayCount6] = 3, lineDataForDisplayCount6++;
            }
        }
    }
}

@end
