//
//  Communication.h
//  Cell_Outline_Draw
//
//  Created by Masahiko Sato on 2014-05-14.
//
//

#ifndef COMMUNICATION_H
#define COMMUNICATION_H
#import "Controller.h"
#endif

@interface Communication : NSObject {
    int firstCommunication; //First communication flag
    
    NSTimer *communicationTimer;
}

-(id)init;
-(void)dealloc;
-(void)processControl;

@end
