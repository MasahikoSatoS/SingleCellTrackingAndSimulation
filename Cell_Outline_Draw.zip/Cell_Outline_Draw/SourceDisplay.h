//
// SourceDisplay.h
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 10/07/11.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#ifndef SOURCEDISPLAY_H
#define SOURCEDISPLAY_H
#import "Controller.h"
#endif

@interface SourceDisplay : NSView {
    double xPositionDisplay; //X Position Image Origin
    double yPositionDisplay; //Y Position Image Origin
    double xPositionAdjustDisplay; //X Position Magnification Adjust
    double yPositionAdjustDisplay; //Y Position Magnification Adjust
    double xPointDownDisplay; //X Position Mouse Down
    double yPointDownDisplay; //Y Position Mouse Down
    double xPointDragDisplay; //X Position Mouse drag
    double yPointDragDisplay; //Y Position mouse drag
    double xPositionMoveDisplay; //X Position Total Move by Drag
    double yPositionMoveDisplay; //Y Position Total Move by Drag
    int mouseDragFlag; //Window operation
    
    NSImage *cellImageOutline;
    IBOutlet NSWindow *sourceDisplayWindow;
}

-(void)mouseDown:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)mouseDragged:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
