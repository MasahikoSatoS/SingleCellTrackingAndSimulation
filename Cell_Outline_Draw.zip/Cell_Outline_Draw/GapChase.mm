//
// GapChase.mm
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 26/11/12.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#import "GapChase.h"

@implementation GapChase

-(int)gapChaseing1:(int)originX :(int)originY :(int)destinationX :(int)destinationY :(int)lineType{
    int horizontalLength = (abs(originX-destinationX))/2*2;
    int verticalLength = (abs(originY-destinationY))/2*2;
    int dimension = 0;
    int cutOffValue = 0;
    
    if (arrayExtractedImage [originY][originX] > arrayExtractedImage [destinationY][destinationX]) cutOffValue = (int)(arrayExtractedImage [destinationY][destinationX]*0.7);
    else cutOffValue = (int)(arrayExtractedImage [originY][originX]*0.7);
    
    if (horizontalLength >= verticalLength) dimension = horizontalLength*2+30;
    if (horizontalLength < verticalLength) dimension = verticalLength*2+30;
    
    dimension = (dimension/2)*2;
    
    int horizontalStart = 0;
    int verticalStart = 0;
    
    if (originX >= destinationX) horizontalStart = destinationX-(dimension-horizontalLength)/2;
    else horizontalStart = originX-(dimension-horizontalLength)/2;
    
    if (originY >= destinationY) verticalStart = destinationY-(dimension-verticalLength)/2;
    else verticalStart = originY-(dimension-verticalLength)/2;
    
    
    double linearDistance = sqrt ((originX-destinationX)*(originX-destinationX)+(originY-destinationY)*(originY-destinationY));
    
    //cout<<linearDistance<<" "<<dimension<<" Distance/dimension"<<endl;
    
    int matchFlag = 0;
    
    if (linearDistance < 50 && linearDistance > 0 && dimension > 0 && dimension < 1000){
        int **gapFillMatrix = new int *[dimension+1]; //------0/1 map------
        int **gapFillMatrix2 = new int *[dimension+1]; //------Connectivity map------
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++){
            gapFillMatrix [counter1] = new int [dimension+1];
            gapFillMatrix2 [counter1] = new int [dimension+1];
        }
        
        for (int counterY = 0; counterY < dimension+1; counterY++){
            for (int counterX = 0; counterX < dimension+1; counterX++){
                gapFillMatrix [counterY][counterX] = 0;
                gapFillMatrix2 [counterY][counterX] = 0;
            }
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageHeight && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageHeight){
                    if (arrayExtractedImage [counterY+verticalStart][counterX+horizontalStart] == 100 || arrayExtractedImage [counterY+verticalStart][counterX+horizontalStart] < 50 || arrayExtractedImage [counterY+verticalStart][counterX+horizontalStart] < cutOffValue){
                        gapFillMatrix [counterY][counterX] = 0;
                    }
                    else gapFillMatrix [counterY][counterX] = 1;
                }
                else gapFillMatrix [counterY][counterX] = 0;
            }
        }
        
        int neighbourCount = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (gapFillMatrix [counterY][counterX] != 0){
                    if (counterY-1 >= 0 && counterX-1 >= 0 && gapFillMatrix [counterY-1][counterX-1] != 0) neighbourCount++;
                    if (counterY-1 >= 0 && gapFillMatrix [counterY-1][counterX] != 0) neighbourCount++;
                    if (counterY-1 >= 0 && counterX+1 < dimension && gapFillMatrix [counterY-1][counterX+1] != 0) neighbourCount++;
                    if (counterX+1 < dimension && gapFillMatrix [counterY][counterX+1] != 0) neighbourCount++;
                    if (counterY+1 < dimension && counterX+1 < dimension && gapFillMatrix [counterY+1][counterX+1] != 0) neighbourCount++;
                    if (counterY+1 < dimension && gapFillMatrix [counterY+1][counterX] != 0) neighbourCount++;
                    if (counterY+1 < dimension && counterX-1 >= 0 && gapFillMatrix [counterY+1][counterX-1] != 0) neighbourCount++;
                    if (counterX-1 >= 0 && gapFillMatrix [counterY][counterX-1] != 0) neighbourCount++;
                    if (gapFillMatrix [counterY][counterX] != 0) neighbourCount++;
                    
                    if (neighbourCount <= 2){
                        if ((counterY == originY-verticalStart && counterX == originX-horizontalStart) || (counterY == destinationY-verticalStart && counterX == destinationX-horizontalStart));
                        else gapFillMatrix [counterY][counterX] = 0;
                    }
                    
                    neighbourCount = 0;
                }
            }
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //	for (int counterB = 0; counterB < 50; counterB++) cout<<" "<<gapFillMatrix [counterA][counterB];
        //	cout<<" gapFillMatrix "<<counterA<<endl;
        //}
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (gapFillMatrix [counterY][counterX] == 1) gapFillMatrix2 [counterY][counterX] = -1;
                else gapFillMatrix2 [counterY][counterX] = 0;
            }
        }
        
        int *connectAnalysisX = new int [dimension*4+1];
        int *connectAnalysisY = new int [dimension*4+1];
        int *connectAnalysisTempX = new int [dimension*4+1];
        int *connectAnalysisTempY = new int [dimension*4+1];
        
        int connectivityNumber = 0;
        int connectAnalysisCount = 0;
        int terminationFlag = 0;
        int connectAnalysisTempCount = 0;
        int xSource = 0;
        int ySource = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (gapFillMatrix2 [counterY][counterX] == -1){
                    connectivityNumber++;
                    gapFillMatrix2 [counterY][counterX] = connectivityNumber;
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && gapFillMatrix2 [counterY-1][counterX] == -1){
                        gapFillMatrix2 [counterY-1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension && gapFillMatrix2 [counterY][counterX+1] == -1){
                        gapFillMatrix2 [counterY][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && gapFillMatrix2 [counterY+1][counterX] == 1){
                        gapFillMatrix2 [counterY+1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && gapFillMatrix2 [counterY][counterX-1] == -1){
                        gapFillMatrix2 [counterY][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && gapFillMatrix2 [ySource-1][xSource] == -1){
                                    gapFillMatrix2 [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension && gapFillMatrix2 [ySource][xSource+1] == -1){
                                    gapFillMatrix2 [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && gapFillMatrix2 [ySource+1][xSource] == -1){
                                    gapFillMatrix2 [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && gapFillMatrix2 [ySource][xSource-1] == -1){
                                    gapFillMatrix2 [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<gapFillMatrix2 [counterA][counterB];
        //	cout<<" gapFillMatrix2 "<<counterA<<endl;
        //}
        
        matchFlag = 0;
        
        if (originY-verticalStart >= 0 && originY-verticalStart < dimension && originX-horizontalStart >= 0 && originX-horizontalStart < dimension && gapFillMatrix2 [originY-verticalStart][originX-horizontalStart] == gapFillMatrix2 [destinationY-verticalStart][destinationX-horizontalStart]){
            connectivityNumber = gapFillMatrix2 [originY-verticalStart][originX-horizontalStart];
            int originYMap = originY-verticalStart;
            int originXMap = originX-horizontalStart;
            int destinationYMap2 = destinationY-verticalStart;
            int destinationXMap2 = destinationX-horizontalStart;
            gapFillMatrix2 [originYMap][originXMap] = -10;
            gapFillMatrix2 [destinationYMap2][destinationXMap2] = -10;
            
            //cout<<connectivityNumber<<" "<< originYMap<<" "<<originXMap<<" "<<destinationYMap2<<" "<<destinationXMap2<<" "<<lineType<<" Start_End"<<endl;
            
            int midStartYMap2 = originYMap;
            int midStartXMap2 = originXMap;
            int midEndYMap2 = destinationYMap2;
            int midEndXMap2 = destinationXMap2;
            int chaseResult2 = 0;
            int zeroFindFlag = 0;
            
            if (dimension*dimension+5 > mapDataLimit){
                delete [] arrayMapData;
                arrayMapData = new int [dimension*dimension+500], mapDataLimit = dimension*dimension+500;
            }
            
            mapDataCount = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (gapFillMatrix2 [counterY][counterX] == connectivityNumber) arrayMapData [mapDataCount] = gapFillMatrix2 [counterY][counterX], mapDataCount++;
                    else arrayMapData [mapDataCount] = 0, mapDataCount++;
                }
            }
            
            gapFill = [[GapFill alloc] init];
            int chaseResult = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
            
            //------Determine gap position------
            gapFill = [[GapFill alloc] init];
            [gapFill gapFilling:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2];
            
            for (int counter1 = 0; counter1 < gapDataCount/2; counter1++){
                if (gapFillMatrix2 [arrayGapData [counter1*2+1]][arrayGapData [counter1*2]] == 0) zeroFindFlag = 1;
            }
            
            int proceedingFlag = 0;
            
            if (chaseResult == 0 && zeroFindFlag == 0) zeroFindFlag = 2;
            
            if (chaseResult == 0 && zeroFindFlag == 1) proceedingFlag = 1;
            
            if (chaseResult == 1 && zeroFindFlag == 0){
                chaseResult = 0;
                zeroFindFlag = 2;
            }
            
            if (chaseResult == 1 && zeroFindFlag == 1){
                if (gapDataCount/2*1.5 <= returnDataCount/2){
                    chaseResult = 0;
                    proceedingFlag = 1;
                }
            }
            
            numberOfFill = 0;
            fillLimit = 100;
            
            arrayGapDataTemp = new int [100];
            
            if (proceedingFlag == 1){
                int **zeroTraceMap = new int *[dimension+3]; //------Source MAP, retain only relevant connect number, start, end -10------
                for (int counter1 = 0; counter1 < dimension+3; counter1++) zeroTraceMap [counter1] = new int [dimension+3];
                
                int **zeroTraceMap2 = new int *[dimension+1]; //------Connectivity MAP for ZERO, Connect check, UP/Down/Right/Left only------
                int **zeroTraceMap3 = new int *[dimension+1]; //------Retain connectivity MAP, attaches Linear line------
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    zeroTraceMap2 [counter1] = new int [dimension+1];
                    zeroTraceMap3 [counter1] = new int [dimension+1];
                }
                
                for (int counterY = 0; counterY < dimension+2; counterY++){ //------Map set------
                    for (int counterX = 0; counterX < dimension+2; counterX++) zeroTraceMap [counterY][counterX] = 0;
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){ //------Map set------
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (gapFillMatrix2 [counterY][counterX] == connectivityNumber) zeroTraceMap [counterY+1][counterX+1] = -1;
                        else if (gapFillMatrix2 [counterY][counterX] == -10) zeroTraceMap [counterY+1][counterX+1] = -10;
                        
                        zeroTraceMap2 [counterY][counterX] = 0;
                        zeroTraceMap3 [counterY][counterX] = 0;
                    }
                }
                
                for (int counter1 = 0; counter1 < gapDataCount/2; counter1++){ //------Linear line, enter into zeroTrace MAP as 1------
                    zeroTraceMap [arrayGapData [counter1*2+1]+1][arrayGapData [counter1*2]+1] = -1;
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<zeroTraceMap [counterA][counterB];
                //	cout<<" zeroTraceMap "<<counterA<<endl;
                //}
                
                connectivityNumber = 0;
                
                for (int counterY = 0; counterY < dimension+2; counterY++){
                    for (int counterX = 0; counterX < dimension+2; counterX++){
                        if (zeroTraceMap [counterY][counterX] == -1){
                            connectivityNumber++;
                            zeroTraceMap [counterY][counterX] = connectivityNumber;
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && zeroTraceMap [counterY-1][counterX] == -1){
                                zeroTraceMap [counterY-1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < dimension+2 && zeroTraceMap [counterY][counterX+1] == -1){
                                zeroTraceMap [counterY][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension+2 && zeroTraceMap [counterY+1][counterX] == -1){
                                zeroTraceMap [counterY+1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && zeroTraceMap [counterY][counterX-1] == -1){
                                zeroTraceMap [counterY][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                        xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                        
                                        if (ySource-1 >= 0 && zeroTraceMap [ySource-1][xSource] == -1){
                                            zeroTraceMap [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension+2 && zeroTraceMap [ySource][xSource+1] == -1){
                                            zeroTraceMap [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension+2 && zeroTraceMap [ySource+1][xSource] == -1){
                                            zeroTraceMap [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && zeroTraceMap [ySource][xSource-1] == -1){
                                            zeroTraceMap [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                        connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                for (int counterY = 0; counterY < dimension+2; counterY++){
                    for (int counterX = 0; counterX < dimension+2; counterX++){
                        if (zeroTraceMap [counterY][counterX] > 0) zeroTraceMap2 [counterY-1][counterX-1] = zeroTraceMap [counterY][counterX];
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<zeroTraceMap2 [counterA][counterB];
                //	cout<<" zeroTraceMap2 "<<counterA<<endl;
                //}
                
                int **numberOfPointList = new int *[connectivityNumber+1];
                for (int counter1 = 0; counter1 < connectivityNumber+1; counter1++) numberOfPointList [counter1] = new int [3];
                
                for (int counter1 = 0; counter1 < connectivityNumber+1; counter1++){
                    numberOfPointList [counter1][0] = 0;
                    numberOfPointList [counter1][1] = 0;
                }
                
                for (int counter1 = 0; counter1 < gapDataCount/2; counter1++){ //------Write linear line as -1 into zeroTraceMap2------
                    zeroTraceMap2 [arrayGapData [counter1*2+1]][arrayGapData [counter1*2]] = -1;
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){ //------Remove connectivity group, which attached edges------
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if ((counterY == 0 || counterY == dimension-1 || counterX == 0 || counterX == dimension-1) && zeroTraceMap2 [counterY][counterX] > 0){
                            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                    if (zeroTraceMap2 [counterY2][counterX2] == zeroTraceMap2 [counterY][counterX]) zeroTraceMap2 [counterY2][counterX2] = 0;
                                }
                            }
                        }
                    }
                }
                
                int numberOfPoint = 0;
                
                for (int counterY = 0; counterY < dimension; counterY++){ //------Write Connectivity group, which attach with linear line, into zeroTraceMap3, count number of pix------
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (zeroTraceMap2 [counterY][counterX] > 0){
                            for (int counterY2 = counterY-1; counterY2 <= counterY+1; counterY2++){
                                for (int counterX2 = counterX-1; counterX2 <= counterX+1; counterX2++){
                                    if (zeroTraceMap2 [counterY2][counterX2] == -1){
                                        if (numberOfPointList [zeroTraceMap2 [counterY][counterX]][0] == 0){
                                            numberOfPoint = 0;
                                            
                                            for (int counterY3 = 0; counterY3 < dimension; counterY3++){
                                                for (int counterX3 = 0; counterX3 < dimension; counterX3++){
                                                    if (zeroTraceMap2 [counterY3][counterX3] == zeroTraceMap2 [counterY][counterX]){
                                                        zeroTraceMap3 [counterY3][counterX3] = zeroTraceMap2 [counterY][counterX];
                                                        numberOfPoint++;
                                                    }
                                                }
                                            }
                                            
                                            numberOfPointList [zeroTraceMap2 [counterY][counterX]][0] = numberOfPoint; //------0: for number of pix, 2: orientation------
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<zeroTraceMap3 [counterA][counterB];
                //	cout<<" zeroTraceMap3 "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA <= connectivityNumber2; counterA++){
                //	cout<<" numberOfPointList "<<counterA<<" "<<numberOfPointList [counterA][0]<<" "<<numberOfPointList [counterA][1]<<endl;
                //}
                
                int lineFirstX = arrayGapData [0];
                int lineFirstY = arrayGapData [1];
                int gapDataTemp1 = (gapDataCount/2-1)*2;
                int gapDataTemp2 = (gapDataCount/2-1)*2+1;
                int lineLastX = arrayGapData [gapDataTemp1];
                int lineLastY = arrayGapData [gapDataTemp2];
                
                int traceType = 0;
                
                if (abs(lineFirstX-lineLastX) > abs(lineFirstY-lineLastY)){ //------Determine line orientation------
                    if (lineFirstX < lineLastX) traceType = 1; //------Left to right, X------
                    else traceType = 2; //------Right to Left, X------
                }
                else if (lineFirstY < lineLastY) traceType = 3; //------Up to bottom, Y------
                else traceType = 4; //------Bottom to Up, Y------
                
                //cout<<"TRACE_A "<<traceType<<endl;
                
                int lineTempX = 0;
                int lineTempY = 0;
                
                for (int counter1 = 0; counter1 < gapDataCount/2; counter1++){ //------Determine connectivity group orientation------
                    lineTempX = arrayGapData [counter1*2];
                    lineTempY = arrayGapData [counter1*2+1];
                    
                    if (gapFillMatrix2 [lineTempY][lineTempX] == 0){
                        if (traceType == 1 || traceType == 2){
                            for (int counter2 = lineTempY+1; counter2 < dimension; counter2++){ //------X, down------
                                if (zeroTraceMap3 [counter2][lineTempX] > 0) numberOfPointList [zeroTraceMap3 [counter2][lineTempX]][1] = 1;
                            }
                            
                            for (int counter2 = lineTempY-1; counter2 >= 0; counter2 = counter2-1){ //------X, Up------
                                if (zeroTraceMap3 [counter2][lineTempX] > 0) numberOfPointList [zeroTraceMap3 [counter2][lineTempX]][1] = 2;
                            }
                        }
                        if (traceType == 3 || traceType == 4){
                            for (int counter2 = lineTempX+1; counter2 < dimension; counter2++){ //------Y, Right------
                                if (zeroTraceMap3 [lineTempY][counter2] > 0) numberOfPointList [zeroTraceMap3 [lineTempY][counter2]][1] = 1;
                            }
                            
                            for (int counter2 = lineTempX-1; counter2 >= 0; counter2 = counter2-1){ //------Y, Left------
                                if (zeroTraceMap3 [lineTempY][counter2] > 0) numberOfPointList [zeroTraceMap3 [lineTempY][counter2]][1] = 2;
                            }
                        }
                    }
                }
                
                int findGapPix1 = 0;
                int findGapPix2 = 0;
                
                for (int counter1 = 1; counter1 <= connectivityNumber; counter1++){ //------Pix number------
                    if (numberOfPointList [counter1][1] == 1) findGapPix1 = findGapPix1+numberOfPointList [counter1][0];
                    
                    if (numberOfPointList [counter1][1] == 2) findGapPix2 = findGapPix2+numberOfPointList [counter1][0];
                }
                
                int trackOrder = 0;
                int selectedPix = 0;
                
                if (traceType != 1){ //------Box, 1: bottom side, 2: Left side, 3: up side, 4: Right side------
                    if (findGapPix1 == 0){
                        trackOrder = 2;
                        selectedPix = 1; //------Order: 2,1,4------
                    }
                }
                
                if (traceType == 2){ //------Box, 1: bottom side, 2: Left side, 3: up side, 4: Right side------
                    if (findGapPix2 != 0){
                        trackOrder = 3;
                        selectedPix = 2; //------Order: 4,3,2------
                    }
                }
                
                if (traceType == 3){ //------Box, 1: bottom side, 2: Left side, 3: up side, 4: Right side------
                    if (findGapPix2 != 0){
                        trackOrder = 5;
                        selectedPix = 2; //------Order: 3,2,1------
                    }
                }
                
                if (traceType == 4){ //------Box, 1: bottom side, 2: Left side, 3: up side, 4: Right side------
                    if (findGapPix1 != 0){
                        trackOrder = 8;
                        selectedPix = 1; //------Order: 1,4,3------
                    }
                }
                
                if (trackOrder != 0){
                    int maxPointX [2];
                    int maxPointY [2];
                    int minPointX [2];
                    int minPointY [2];
                    
                    maxPointX [0] = -1;
                    maxPointX [1] = -1;
                    maxPointY [0] = -1;
                    maxPointY [1] = -1;
                    minPointX [0] = 10000;
                    minPointX [1] = -1;
                    minPointY [0] = -1;
                    minPointY [1] = 10000;
                    
                    for (int counter1 = 1; counter1 <= connectivityNumber; counter1++){ //------Determine Box dimension------
                        if (numberOfPointList [counter1][1] == selectedPix){
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (zeroTraceMap3 [counterY][counterX] == counter1){
                                        if (maxPointX [0] < counterX){
                                            maxPointX [0] = counterX;
                                            maxPointX [1] = counterY; //------Side 4------
                                        }
                                        
                                        if (minPointX [0] > counterX){
                                            minPointX [0] = counterX;
                                            minPointX [1] = counterY; //------Side 2------
                                        }
                                        
                                        if (maxPointY [1] < counterY){
                                            maxPointY [0] = counterX;
                                            maxPointY [1] = counterY; //------Side 1------
                                        }
                                        
                                        if (minPointY [1] > counterY){
                                            minPointY [0] = counterX;
                                            minPointY [1] = counterY; //------Side 3------
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    if (maxPointX [0] == -1 || minPointX [0] == 10000 || maxPointY [0] == -1 || minPointY [0] == 10000) matchFlag = 1;
                    
                    if (matchFlag == 0){
                        int markerOrderX1 = -1;
                        int markerOrderY1 = -1;
                        int markerOrderX2 = -1;
                        int markerOrderY2 = -1;
                        int markerOrderX3 = -1;
                        int markerOrderY3 = -1;
                        int markerOrderX4 = -1;
                        int markerOrderY4 = -1;
                        
                        for (int counter1 = maxPointX [0]+1; counter1 < dimension; counter1++){ //------Find pixels on Connectivity Number------
                            if (gapFillMatrix2 [maxPointX [1]][counter1] == connectivityNumber){
                                markerOrderX4 = counter1;
                                markerOrderY4 = maxPointX [1];
                                break;
                            }
                        }
                        
                        for (int counter1 = minPointX [0]-1; counter1 >= 0; counter1 = counter1-1){
                            if (gapFillMatrix2 [minPointX [1]][counter1] == connectivityNumber){
                                markerOrderX2 = counter1;
                                markerOrderY2 = minPointX [1];
                                break;
                            }
                        }
                        
                        for (int counter1 = minPointY [1]-1; counter1 >= 0; counter1 = counter1-1){
                            if (gapFillMatrix2 [counter1][minPointY [0]] == connectivityNumber){
                                markerOrderX3 = minPointY [0];
                                markerOrderY3 = counter1;
                                break;
                            }
                        }
                        
                        for (int counter1 = maxPointY [1]+1; counter1 < dimension; counter1++){
                            if (gapFillMatrix2 [counter1][maxPointY [0]] == connectivityNumber){
                                markerOrderX1 = maxPointY [0];
                                markerOrderY1 = counter1;
                                break;
                            }
                        }
                        
                        //cout<<"MarkerOrder_A "<<markerOrderX1<<" "<<markerOrderY1<<" "<<markerOrderX2<<" "<<markerOrderY2<<" "<<markerOrderX3<<" "<<markerOrderY3<<" "<<markerOrderX4 <<" "<<markerOrderY4<<endl;
                        
                        for (int counter1 = 1; counter1 <= connectivityNumber; counter1++){
                            if (numberOfPointList [counter1][1] == selectedPix){
                                for (int counterY = 0; counterY < dimension; counterY++){
                                    for (int counterX = 0; counterX < dimension; counterX++){
                                        if (zeroTraceMap3 [counterY][counterX] == numberOfPointList [counter1][0]) zeroTraceMap3 [counterY][counterX] = -1;
                                    }
                                }
                            }
                        }
                        
                        int markerCornerX1 = minPointX [0];
                        int markerCornerY1 = maxPointY [1];
                        int markerCornerX2 = minPointX [0];
                        int markerCornerY2 = minPointY [1];
                        int markerCornerX3 = maxPointX [0];
                        int markerCornerY3 = minPointY [1];
                        int markerCornerX4 = maxPointX [0];
                        int markerCornerY4 = maxPointY [1];
                        
                        int markerPoint [5][2];
                        
                        for (int counter1 = 0; counter1 < 5; counter1++){
                            markerPoint [counter1][0] = -1;
                            markerPoint [counter1][1] = -1;
                        }
                        
                        if (trackOrder == 2){ //------Order: 2,1,4------
                            if (abs(originYMap-markerOrderY2) == 1 && abs(originXMap-markerOrderX2) == 1);
                            else{
                                
                                markerPoint [0][0] = markerOrderX2;
                                markerPoint [0][1] = markerOrderY2;
                            }
                            
                            if (abs(markerOrderY2-markerCornerY1) == 1 && abs(markerOrderX2-markerCornerX1) == 1);
                            else{
                                
                                markerPoint [1][0] = markerCornerX1;
                                markerPoint [1][1] = markerCornerY1;
                            }
                            
                            if (abs(markerCornerY1-markerOrderY1) == 1 && abs(markerCornerX1-markerOrderX1) == 1){
                                markerPoint [1][0] = -1;
                                markerPoint [1][1] = -1;
                                markerPoint [2][0] = markerOrderX1;
                                markerPoint [2][1] = markerOrderY1;
                            }
                            else{
                                
                                markerPoint [2][0] = markerOrderX1;
                                markerPoint [2][1] = markerOrderY1;
                            }
                            
                            if (abs(markerOrderY1-markerCornerY4) == 1 && abs(markerOrderX1-markerCornerX4) == 1);
                            else{
                                
                                markerPoint [3][0] = markerCornerX4;
                                markerPoint [3][1] = markerCornerY4;
                            }
                            
                            if (abs(markerCornerY4-markerOrderY4) == 1 && abs(markerCornerX4-markerOrderX4) == 1){
                                markerPoint [3][0] = -1;
                                markerPoint [3][1] = -1;
                                markerPoint [4][0] = markerOrderX4;
                                markerPoint [4][1] = markerOrderY4;
                            }
                            else{
                                
                                markerPoint [4][0] = markerOrderX4;
                                markerPoint [4][1] = markerOrderY4;
                            }
                            
                            if (abs(markerOrderY4-destinationYMap2) == 1 && abs(markerOrderX4-destinationXMap2) == 1){
                                markerPoint [4][0] = -1;
                                markerPoint [4][1] = -1;
                                
                                if (abs(markerOrderY1-markerCornerY4) == 1 && abs(markerOrderX1-markerCornerX4) == 1);
                                else{
                                    
                                    markerPoint [3][0] = markerCornerX4;
                                    markerPoint [3][1] = markerCornerY4;
                                }
                            }
                        }
                        if (trackOrder == 3){ //------Order: 4,3,2------
                            if (abs(originYMap-markerOrderY4) == 1 && abs(originXMap-markerOrderX4) == 1);
                            else{
                                
                                markerPoint [0][0] = markerOrderX4;
                                markerPoint [0][1] = markerOrderY4;
                            }
                            
                            if (abs(markerOrderY4-markerCornerY3) == 1 && abs(markerOrderX4-markerCornerX3) == 1);
                            else{
                                
                                markerPoint [1][0] = markerCornerX3;
                                markerPoint [1][1] = markerCornerY3;
                            }
                            
                            if (abs(markerCornerY3-markerOrderY3) == 1 && abs(markerCornerX3-markerOrderX3) == 1){
                                markerPoint [1][0] = -1;
                                markerPoint [1][1] = -1;
                                markerPoint [2][0] = markerOrderX3;
                                markerPoint [2][1] = markerOrderY3;
                            }
                            else{
                                
                                markerPoint [2][0] = markerOrderX3;
                                markerPoint [2][1] = markerOrderY3;
                            }
                            
                            if (abs(markerOrderY3-markerCornerY2) == 1 && abs(markerOrderX3-markerCornerX2) == 1);
                            else{
                                
                                markerPoint [3][0] = markerCornerX2;
                                markerPoint [3][1] = markerCornerY2;
                            }
                            
                            if (abs(markerCornerY2-markerOrderY2) == 1 && abs(markerCornerX2-markerOrderX2) == 1){
                                markerPoint [3][0] = -1;
                                markerPoint [3][1] = -1;
                                markerPoint [4][0] = markerOrderX2;
                                markerPoint [4][1] = markerOrderY2;
                            }
                            else{
                                
                                markerPoint [4][0] = markerOrderX2;
                                markerPoint [4][1] = markerOrderY2;
                            }
                            
                            if (abs(markerOrderY2-destinationYMap2) == 1 && abs(markerOrderX2-destinationXMap2) == 1){
                                markerPoint [4][0] = -1;
                                markerPoint [4][1] = -1;
                                
                                if (abs(markerOrderY3-markerCornerY2) == 1 && abs(markerOrderX3-markerCornerX2) == 1);
                                else{
                                    
                                    markerPoint [3][0] = markerCornerX2;
                                    markerPoint [3][1] = markerCornerY2;
                                }
                            }
                        }
                        
                        if (trackOrder == 5){ //------Order: 3,2,1------
                            if (abs(originYMap-markerOrderY3) == 1 && abs(originXMap-markerOrderX3) == 1);
                            else{
                                
                                markerPoint [0][0] = markerOrderX3;
                                markerPoint [0][1] = markerOrderY3;
                            }
                            
                            if (abs(markerOrderY3-markerCornerY2) == 1 && abs(markerOrderX3-markerCornerX2) == 1);
                            else{
                                
                                markerPoint [1][0] = markerCornerX2;
                                markerPoint [1][1] = markerCornerY2;
                            }
                            
                            if (abs(markerCornerY2-markerOrderY2) == 1 && abs(markerCornerX2-markerOrderX2) == 1){
                                markerPoint [1][0] = -1;
                                markerPoint [1][1] = -1;
                                markerPoint [2][0] = markerOrderX2;
                                markerPoint [2][1] = markerOrderY2;
                            }
                            else{
                                
                                markerPoint [2][0] = markerOrderX2;
                                markerPoint [2][1] = markerOrderY2;
                            }
                            
                            if (abs(markerOrderY2-markerCornerY1) == 1 && abs(markerOrderX2-markerCornerX1) == 1);
                            else{
                                
                                markerPoint [3][0] = markerCornerX1;
                                markerPoint [3][1] = markerCornerY1;
                            }
                            
                            if (abs(markerCornerY1-markerOrderY1) == 1 && abs(markerCornerX1-markerOrderX1) == 1){
                                markerPoint [3][0] = -1;
                                markerPoint [3][1] = -1;
                                markerPoint [4][0] = markerOrderX1;
                                markerPoint [4][1] = markerOrderY1;
                            }
                            else{
                                
                                markerPoint [4][0] = markerOrderX1;
                                markerPoint [4][1] = markerOrderY1;
                            }
                            
                            if (abs(markerOrderY1-destinationYMap2) == 1 && abs(markerOrderX1-destinationXMap2) == 1){
                                markerPoint [4][0] = -1;
                                markerPoint [4][1] = -1;
                                
                                if (abs(markerOrderY2-markerCornerY1) == 1 && abs(markerOrderX2-markerCornerX1) == 1);
                                else{
                                    
                                    markerPoint [3][0] = markerCornerX1;
                                    markerPoint [3][1] = markerCornerY1;
                                }
                            }
                        }
                        
                        if (trackOrder == 8){ //------Order: 1,4,3------
                            if (abs(originYMap-markerOrderY1) == 1 && abs(originXMap-markerOrderX1) == 1);
                            else{
                                
                                markerPoint [0][0] = markerOrderX1;
                                markerPoint [0][1] = markerOrderY1;
                            }
                            
                            if (abs(markerOrderY1-markerCornerY4) == 1 && abs(markerOrderX1-markerCornerX4) == 1);
                            else{
                                
                                markerPoint [1][0] = markerCornerX4;
                                markerPoint [1][1] = markerCornerY4;
                            }
                            
                            if (abs(markerCornerY4-markerOrderY4) == 1 && abs(markerCornerX4-markerOrderX4) == 1){
                                markerPoint [1][0] = -1;
                                markerPoint [1][1] = -1;
                                markerPoint [2][0] = markerOrderX4;
                                markerPoint [2][1] = markerOrderY4;
                            }
                            else{
                                
                                markerPoint [2][0] = markerOrderX4;
                                markerPoint [2][1] = markerOrderY4;
                            }
                            
                            if (abs(markerOrderY4-markerCornerY3) == 1 && abs(markerOrderX4-markerCornerX3) == 1);
                            else{
                                
                                markerPoint [3][0] = markerCornerX3;
                                markerPoint [3][1] = markerCornerY3;
                            }
                            
                            if (abs(markerCornerY3-markerOrderY3) == 1 && abs(markerCornerX3-markerOrderX3) == 1){
                                markerPoint [3][0] = -1;
                                markerPoint [3][1] = -1;
                                markerPoint [4][0] = markerOrderX3;
                                markerPoint [4][1] = markerOrderY3;
                            }
                            else{
                                
                                markerPoint [4][0] = markerOrderX3;
                                markerPoint [4][1] = markerOrderY3;
                            }
                            
                            if (abs(markerOrderY3-destinationYMap2) == 1 && abs(markerOrderX3-destinationXMap2) == 1){
                                markerPoint [4][0] = -1;
                                markerPoint [4][1] = -1;
                                
                                if (abs(markerOrderY4-markerCornerY3) == 1 && abs(markerOrderX4-markerCornerX3) == 1);
                                else{
                                    
                                    markerPoint [3][0] = markerCornerX3;
                                    markerPoint [3][1] = markerCornerY3;
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < 5; counterA++){
                        //	cout<<" markerPoint "<<markerPoint [counterA][0]<<" "<<markerPoint [counterA][1]<<endl;
                        //}
                        
                        //zeroTraceMap3 [markerOrderY1][markerOrderX1] = -11; //------For CHECK------
                        //zeroTraceMap3 [markerOrderY2][markerOrderX2] = -12;
                        //zeroTraceMap3 [markerOrderY3][markerOrderX3] = -13;
                        //zeroTraceMap3 [markerOrderY4][markerOrderX4] = -14;
                        //zeroTraceMap3 [markerCornerY1][markerCornerX1] = -21;
                        //zeroTraceMap3 [markerCornerY2][markerCornerX2] = -22;
                        //zeroTraceMap3 [markerCornerY3][markerCornerX3] = -23;
                        //zeroTraceMap3 [markerCornerY4][markerCornerX4] = -24;
                        
                        midStartXMap2 = originXMap;
                        midStartYMap2 = originYMap;
                        
                        if (markerPoint [0][0] != -1){
                            midEndXMap2 = markerPoint [0][0];
                            midEndYMap2 = markerPoint [0][1];
                            
                            gapFill = [[GapFill alloc] init];
                            chaseResult = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                            
                            if (chaseResult == 1){
                                if (numberOfFill+returnDataCount+2 > fillLimit){
                                    fillAddition = returnDataCount+2;
                                    [self gapFillUpdate];
                                }
                                
                                for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                    arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                    arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                }
                                
                                arrayGapDataTemp [numberOfFill] = midEndXMap2, numberOfFill++;
                                arrayGapDataTemp [numberOfFill] = midEndYMap2, numberOfFill++;
                                
                                midStartXMap2 = midEndXMap2;
                                midStartYMap2 = midEndYMap2;
                                midEndXMap2 = markerPoint [2][0];
                                midEndYMap2 = markerPoint [2][1];
                                
                                gapFill = [[GapFill alloc] init];
                                chaseResult = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                
                                if (chaseResult == 1){
                                    if (numberOfFill+returnDataCount > fillLimit){
                                        fillAddition = returnDataCount+2;
                                        [self gapFillUpdate];
                                    }
                                    
                                    for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                        arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                        arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                    }
                                }
                                else if (markerPoint [1][0] == -1) matchFlag = 1;
                                else{
                                    
                                    midEndXMap2 = markerPoint [1][0];
                                    midEndYMap2 = markerPoint [1][1];
                                    
                                    gapFill = [[GapFill alloc] init];
                                    chaseResult = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                    
                                    if (chaseResult == 1){
                                        if (numberOfFill+returnDataCount+2 > fillLimit){
                                            fillAddition = returnDataCount+2;
                                            [self gapFillUpdate];
                                        }
                                        
                                        for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                            arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                            arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                        }
                                        
                                        arrayGapDataTemp [numberOfFill] = midEndXMap2, numberOfFill++;
                                        arrayGapDataTemp [numberOfFill] = midEndYMap2, numberOfFill++;
                                        
                                        midStartXMap2 = midEndXMap2;
                                        midStartYMap2 = midEndYMap2;
                                        midEndXMap2 = markerPoint [2][0];
                                        midEndYMap2 = markerPoint [2][1];
                                        
                                        gapFill = [[GapFill alloc] init];
                                        chaseResult = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                        
                                        if (chaseResult == 1){
                                            if (numberOfFill+returnDataCount > fillLimit){
                                                fillAddition = returnDataCount+2;
                                                [self gapFillUpdate];
                                            }
                                            
                                            for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                                arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                                arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                            }
                                        }
                                        else matchFlag = 1;
                                    }
                                    else matchFlag = 1;
                                }
                            }
                            else matchFlag = 1;
                        }
                        
                        if (markerPoint [0][0] == -1){
                            midEndXMap2 = markerPoint [2][0];
                            midEndYMap2 = markerPoint [2][1];
                            
                            gapFill = [[GapFill alloc] init];
                            chaseResult = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                            
                            if (chaseResult == 1){
                                if (numberOfFill+returnDataCount > fillLimit){
                                    fillAddition = returnDataCount+2;
                                    [self gapFillUpdate];
                                }
                                
                                for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                    arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                    arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                }
                            }
                            else if (markerPoint [2][0] == 0) matchFlag = 1;
                            else{
                                
                                midEndXMap2 = markerPoint [1][0];
                                midEndYMap2 = markerPoint [1][1];
                                
                                gapFill = [[GapFill alloc] init];
                                chaseResult = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                
                                if (chaseResult == 1){
                                    if (numberOfFill+returnDataCount+2 > fillLimit){
                                        fillAddition = returnDataCount+2;
                                        [self gapFillUpdate];
                                    }
                                    
                                    for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                        arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                        arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                    }
                                    
                                    arrayGapDataTemp [numberOfFill] = midEndXMap2, numberOfFill++;
                                    arrayGapDataTemp [numberOfFill] = midEndYMap2, numberOfFill++;
                                    
                                    midStartXMap2 = midEndXMap2;
                                    midStartYMap2 = midEndYMap2;
                                    midEndXMap2 = markerPoint [2][0];
                                    midEndYMap2 = markerPoint [2][1];
                                    
                                    gapFill = [[GapFill alloc] init];
                                    chaseResult = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                    
                                    if (chaseResult == 1){
                                        if (numberOfFill+returnDataCount > fillLimit){
                                            fillAddition = returnDataCount+2;
                                            [self gapFillUpdate];
                                        }
                                        
                                        for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                            arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                            arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                        }
                                    }
                                    else matchFlag = 1;
                                }
                                else matchFlag = 1;
                            }
                        }
                        
                        if (matchFlag == 0){
                            midStartXMap2 = markerPoint [2][0];
                            midStartYMap2 = markerPoint [2][1];
                            
                            if (markerPoint [4][0] != -1){
                                midEndXMap2 = markerPoint [4][0];
                                midEndYMap2 = markerPoint [4][1];
                                
                                gapFill = [[GapFill alloc] init];
                                chaseResult = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                
                                if (chaseResult == 1){
                                    if (numberOfFill+returnDataCount+2 > fillLimit){
                                        fillAddition = returnDataCount+2;
                                        [self gapFillUpdate];
                                    }
                                    
                                    for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                        arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                        arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                    }
                                    
                                    arrayGapDataTemp [numberOfFill] = midEndXMap2, numberOfFill++;
                                    arrayGapDataTemp [numberOfFill] = midEndYMap2, numberOfFill++;
                                    
                                    midStartXMap2 = midEndXMap2;
                                    midStartYMap2 = midEndYMap2;
                                    midEndXMap2 = destinationXMap2;
                                    midEndYMap2 = destinationYMap2;
                                    
                                    gapFill = [[GapFill alloc] init];
                                    chaseResult = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                    
                                    if (chaseResult == 1){
                                        if (numberOfFill+returnDataCount > fillLimit){
                                            fillAddition = returnDataCount+2;
                                            [self gapFillUpdate];
                                        }
                                        
                                        for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                            arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                            arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                        }
                                    }
                                    else matchFlag = 1;
                                }
                                else if (markerPoint [3][0] == 0) matchFlag = 1;
                                else{
                                    
                                    midEndXMap2 = markerPoint [3][0];
                                    midEndYMap2 = markerPoint [3][1];
                                    
                                    gapFill = [[GapFill alloc] init];
                                    chaseResult = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                    
                                    if (chaseResult == 1){
                                        if (numberOfFill+returnDataCount+2 > fillLimit){
                                            fillAddition = returnDataCount+2;
                                            [self gapFillUpdate];
                                        }
                                        
                                        for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                            arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                            arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                        }
                                        
                                        arrayGapDataTemp [numberOfFill] = midEndXMap2, numberOfFill++;
                                        arrayGapDataTemp [numberOfFill] = midEndYMap2, numberOfFill++;
                                        
                                        midStartXMap2 = midEndXMap2;
                                        midStartYMap2 = midEndYMap2;
                                        midEndXMap2 = markerPoint [4][0];
                                        midEndYMap2 = markerPoint [4][1];
                                        
                                        gapFill = [[GapFill alloc] init];
                                        chaseResult = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                        
                                        if (chaseResult == 1){
                                            if (numberOfFill+returnDataCount+2 > fillLimit){
                                                fillAddition = returnDataCount+2;
                                                [self gapFillUpdate];
                                            }
                                            
                                            for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                                arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                                arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                            }
                                            
                                            arrayGapDataTemp [numberOfFill] = midEndXMap2, numberOfFill++;
                                            arrayGapDataTemp [numberOfFill] = midEndYMap2, numberOfFill++;
                                            
                                            midStartXMap2 = midEndXMap2;
                                            midStartYMap2 = midEndYMap2;
                                            midEndXMap2 = destinationXMap2;
                                            midEndYMap2 = destinationYMap2;
                                            
                                            gapFill = [[GapFill alloc] init];
                                            chaseResult = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                            
                                            if (chaseResult == 1){
                                                if (numberOfFill+returnDataCount > fillLimit){
                                                    fillAddition = returnDataCount+2;
                                                    [self gapFillUpdate];
                                                }
                                                
                                                for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                                    arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                                    arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                                }
                                            }
                                            else matchFlag = 1;
                                        }
                                        else matchFlag = 1;
                                    }
                                    else matchFlag = 1;
                                }
                            }
                            
                            if (markerPoint [4][0] == -1){
                                midEndXMap2 = destinationXMap2;
                                midEndYMap2 = destinationYMap2;
                                
                                gapFill = [[GapFill alloc] init];
                                chaseResult = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                
                                if (chaseResult == 1){
                                    if (numberOfFill+returnDataCount+2 > fillLimit){
                                        fillAddition = returnDataCount+2;
                                        [self gapFillUpdate];
                                    }
                                    
                                    for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                        arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                        arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                    }
                                }
                                else if (markerPoint [2][0] == 0) matchFlag = 1;
                                else{
                                    
                                    midEndXMap2 = markerPoint [3][0];
                                    midEndYMap2 = markerPoint [3][1];
                                    
                                    gapFill = [[GapFill alloc] init];
                                    chaseResult = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                    
                                    if (chaseResult == 1){
                                        if (numberOfFill+returnDataCount+2 > fillLimit){
                                            fillAddition = returnDataCount+2;
                                            [self gapFillUpdate];
                                        }
                                        
                                        for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                            arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                            arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                        }
                                        
                                        arrayGapDataTemp [numberOfFill] = midEndXMap2, numberOfFill++;
                                        arrayGapDataTemp [numberOfFill] = midEndYMap2, numberOfFill++;
                                        
                                        midStartXMap2 = midEndXMap2;
                                        midStartYMap2 = midEndYMap2;
                                        midEndXMap2 = destinationXMap2;
                                        midEndYMap2 = destinationYMap2;
                                        
                                        gapFill = [[GapFill alloc] init];
                                        chaseResult = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                        
                                        if (chaseResult == 1){
                                            if (numberOfFill+returnDataCount+2 > fillLimit){
                                                fillAddition = returnDataCount+2;
                                                [self gapFillUpdate];
                                            }
                                            
                                            for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                                arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                                arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                            }
                                        }
                                        else matchFlag = 1;
                                    }
                                    else matchFlag = 1;
                                }
                            }
                        }
                        
                        if (matchFlag == 0) chaseResult2 = 1;
                    }
                }
                else matchFlag = 1;
                
                for (int counter1 = 0; counter1 < dimension+3; counter1++) delete [] zeroTraceMap [counter1];
                delete [] zeroTraceMap;
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    delete [] zeroTraceMap2 [counter1];
                    delete [] zeroTraceMap3 [counter1];
                }
                
                delete [] zeroTraceMap2;
                delete [] zeroTraceMap3;
                
                for (int counter1 = 0; counter1 < connectivityNumber+1; counter1++) delete [] numberOfPointList [counter1];
                delete [] numberOfPointList;
            }
            
            if (matchFlag == 0){
                if (chaseResult == 1 || chaseResult2 == 1 || zeroFindFlag == 2){
                    int pixValueValue = 0;
                    
                    if (chaseResult == 1){
                        if (returnDataCount*2 > gapChaseLimit){
                            delete [] arrayGapChase;
                            arrayGapChase = new int [returnDataCount*2+500], gapChaseLimit = returnDataCount*2+500;
                        }
                        
                        gapChaseCount = 0;
                        
                        for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                            if (arrayReturnData [counter1*2+1]+verticalStart >= 0 && arrayReturnData [counter1*2+1]+verticalStart < imageWidth && arrayReturnData [counter1*2]+horizontalStart >= 0 && arrayReturnData [counter1*2]+horizontalStart < imageWidth){
                                pixValueValue = arrayExtractedImage[arrayReturnData [counter1*2+1]+verticalStart][arrayReturnData [counter1*2]+horizontalStart];
                            }
                            else pixValueValue = 100;
                            
                            arrayGapChase [gapChaseCount] = arrayReturnData [counter1*2]+horizontalStart, gapChaseCount++;
                            arrayGapChase [gapChaseCount] = arrayReturnData [counter1*2+1]+verticalStart, gapChaseCount++;
                            arrayGapChase [gapChaseCount] = pixValueValue, gapChaseCount++;
                        }
                    }
                    if (chaseResult2 == 1){
                        if (numberOfFill*2 > gapChaseLimit){
                            delete [] arrayGapChase;
                            arrayGapChase = new int [numberOfFill*2+500], gapChaseLimit = numberOfFill*2+500;
                        }
                        
                        gapChaseCount = 0;
                        
                        for (int counter1 = 0; counter1 < numberOfFill/2; counter1++){
                            if (arrayGapDataTemp [counter1*2+1]+verticalStart >= 0 && arrayGapDataTemp [counter1*2+1]+verticalStart < imageWidth && arrayGapDataTemp [counter1*2]+horizontalStart >= 0 && arrayGapDataTemp [counter1*2]+horizontalStart < imageWidth){
                                pixValueValue = arrayExtractedImage[arrayGapDataTemp [counter1*2+1]+verticalStart][arrayGapDataTemp [counter1*2]+horizontalStart];
                            }
                            else pixValueValue = 100;
                            
                            arrayGapChase [gapChaseCount] = arrayGapDataTemp [counter1*2]+horizontalStart, gapChaseCount++;
                            arrayGapChase [gapChaseCount] = arrayGapDataTemp [counter1*2+1]+verticalStart, gapChaseCount++;
                            arrayGapChase [gapChaseCount] = pixValueValue, gapChaseCount++;
                        }
                    }
                    if (zeroFindFlag == 2){
                        if (gapDataCount*2 > gapChaseLimit){
                            delete [] arrayGapChase;
                            arrayGapChase = new int [gapDataCount*2+500], gapChaseLimit = gapDataCount*2+500;
                        }
                        
                        gapChaseCount = 0;
                        
                        for (int counter1 = 0; counter1 < gapDataCount/2; counter1++){
                            if (arrayGapData [counter1*2+1]+verticalStart >= 0 && arrayGapData [counter1*2+1]+verticalStart < imageWidth && arrayGapData [counter1*2]+horizontalStart >= 0 && arrayGapData [counter1*2]+horizontalStart < imageWidth){
                                pixValueValue = arrayExtractedImage[arrayGapData [counter1*2+1]+verticalStart][arrayGapData [counter1*2]+horizontalStart];
                            }
                            else pixValueValue = 100;
                            
                            arrayGapChase [gapChaseCount] = arrayGapData [counter1*2]+horizontalStart, gapChaseCount++;
                            arrayGapChase [gapChaseCount] = arrayGapData [counter1*2+1]+verticalStart, gapChaseCount++;
                            arrayGapChase [gapChaseCount] = pixValueValue, gapChaseCount++;
                        }
                    }
                    
                    int findOverTwohundred = 0;
                    int valueTempX = 0;
                    int valueTempY = 0;
                    int find200 = 0;
                    
                    for (int counter1 = 0; counter1 < gapChaseCount/3; counter1++){
                        valueTempX = arrayGapChase [counter1*3];
                        valueTempY = arrayGapChase [counter1*3+1];
                        find200 = 0;
                        
                        if (arrayExtractedImage [valueTempY][valueTempX] >= 200){
                            if (lineType == 0){
                                if (valueTempY-1 >= 0 && arrayExtractedImage [valueTempY-1][valueTempX] >= 200) find200++;
                                if (valueTempY-1 >= 0 && valueTempX+1 < imageHeight && arrayExtractedImage [valueTempY-1][valueTempX+1] >= 200) find200++;
                                if (valueTempX+1 < imageHeight && arrayExtractedImage [valueTempY][valueTempX+1] >= 200) find200++;
                                if (valueTempY+1 < imageHeight && valueTempX+1 < imageHeight && arrayExtractedImage [valueTempY+1][valueTempX+1] >= 200) find200++;
                            }
                            
                            if (lineType == 1){
                                if (valueTempY-1 >= 0 && valueTempX-1 >= 0 && arrayExtractedImage [valueTempY-1][valueTempX-1] >= 200) find200++;
                                if (arrayExtractedImage [valueTempY][valueTempX-1] >= 200) find200++;
                                if (valueTempY+1 < imageHeight && valueTempX-1 >= 0 && arrayExtractedImage [valueTempY+1][valueTempX-1] >= 200) find200++;
                                if (valueTempY+1 < imageHeight && arrayExtractedImage [valueTempY+1][valueTempX] >= 200) find200++;
                            }
                            
                            if (lineType == 2){
                                if (valueTempY-1 >= 0 && valueTempX-1 >= 0 && arrayExtractedImage [valueTempY-1][valueTempX-1] >= 200) find200++;
                                if (valueTempY-1 >= 0 && arrayExtractedImage [valueTempY-1][valueTempX] >= 200) find200++;
                                if (valueTempY-1 >= 0 && valueTempX+1 < imageHeight && arrayExtractedImage [valueTempY-1][valueTempX+1] >= 200) find200++;
                                if (valueTempX-1 >= 0 && arrayExtractedImage [valueTempY][valueTempX-1] >= 200) find200++;
                            }
                            
                            if (lineType == 3){
                                if (valueTempY+1 < imageHeight && valueTempX-1 >= 0 && arrayExtractedImage [valueTempY+1][valueTempX-1] >= 200) find200++;
                                if (valueTempY+1 < imageHeight && arrayExtractedImage [valueTempY+1][valueTempX] >= 200) find200++;
                                if (valueTempY+1 < imageHeight && valueTempX+1 < imageHeight && arrayExtractedImage [valueTempY+1][valueTempX+1] >= 200) find200++;
                                if (valueTempX+1 < imageHeight && arrayExtractedImage [valueTempY][valueTempX+1] >= 200) find200++;
                            }
                            
                            if (find200 >= 2) findOverTwohundred++;
                        }
                    }
                    
                    if (findOverTwohundred >= 3) matchFlag = 1;
                }
            }
            
            delete [] arrayGapDataTemp;
        }
        else matchFlag = 1;
        
        delete [] connectAnalysisX;
        delete [] connectAnalysisY;
        delete [] connectAnalysisTempX;
        delete [] connectAnalysisTempY;
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++){
            delete [] gapFillMatrix [counter1];
            delete [] gapFillMatrix2 [counter1];
        }
        
        delete [] gapFillMatrix;
        delete [] gapFillMatrix2;
    }
    else matchFlag = 1;
    
    return matchFlag;
}

-(void)gapFillUpdate{
    int *arrayGapUpDate = new int [numberOfFill+10];
    for (int counter1 = 0; counter1 < numberOfFill; counter1++) arrayGapUpDate [counter1] = arrayGapDataTemp [counter1];
    
    delete [] arrayGapDataTemp;
    arrayGapDataTemp = new int [fillLimit+fillAddition+100];
    fillLimit = fillLimit+fillAddition+100;
    
    for (int counter1 = 0; counter1 < numberOfFill; counter1++) arrayGapDataTemp [counter1] = arrayGapUpDate [counter1];
    delete [] arrayGapUpDate;
}

@end
