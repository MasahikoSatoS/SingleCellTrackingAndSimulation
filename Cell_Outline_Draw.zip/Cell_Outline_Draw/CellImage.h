//
// CellImage.h
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 14/02/07.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#ifndef CELLIMAGE_H
#define CELLIMAGE_H
#import "Controller.h"
#endif

@interface CellImage : NSView {
    double xPositionCell; //X Position Image Origin
    double yPositionCell; //Y Position Image Origin
    double xPositionAdjustCell; //X Position Magnification Adjust
    double yPositionAdjustCell; //Y Position Magnification Adjust
    double xPointDownCell; //X Position Mouse Down
    double yPointDownCell; //Y Position Mouse Down
    double xPointDragCell; //X Position Mouse drag
    double yPointDragCell; //Y Position mouse drag
    double xPositionMoveCell; //X Position Total Move by Drag
    double yPositionMoveCell; //Y Position Total Move by Drag
    int mouseDragFlag; //Window operation
    
    NSImage *cellOriginal;
    IBOutlet NSWindow *cellImageDisplay;
    
    id tiffFileRead;
}

-(void)mouseDown:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)mouseDragged:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
