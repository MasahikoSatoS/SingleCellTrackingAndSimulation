//
// GapChase3.mm
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 21/12/12.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#import "GapChase3.h"

@implementation GapChase3

-(int)gapChaseing3:(int)originX :(int)originY :(int)destinationX :(int)destinationY :(int)lineSet :(int)maxPointDimX :(int)maxPointDimY :(int)minPointDimX :(int)minPointDimY :(int)minValue{
    int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
    int verticalLength = (maxPointDimY-minPointDimY)/2*2;
    int dimension = 0;
    int cutOffValue = (int)(minValue*0.8);
    
    if (horizontalLength >= verticalLength) dimension = horizontalLength*4+30;
    if (horizontalLength < verticalLength) dimension = verticalLength*4+30;
    
    dimension = (dimension/2)*2;
    
    int horizontalStart = 0;
    int verticalStart = 0;
    
    horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
    verticalStart = minPointDimY-(dimension-verticalLength)/2;
    
    double linearDistance = sqrt ((originX-destinationX)*(originX-destinationX)+(originY-destinationY)*(originY-destinationY));
    
    int matchFlag = 0;
    
    if (linearDistance < 50 && dimension < 200 && linearDistance > 0 && dimension > 0){
        int **gapFillMatrix = new int *[dimension+1]; //------0/1 map------
        int **gapFillMatrix2 = new int *[dimension+1]; //------Connectivity map------
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++){
            gapFillMatrix [counter1] = new int [dimension+1];
            gapFillMatrix2 [counter1] = new int [dimension+1];
        }
        
        for (int counterY = 0; counterY < dimension+1; counterY++){
            for (int counterX = 0; counterX < dimension+1; counterX++){
                gapFillMatrix [counterY][counterX] = 0;
                gapFillMatrix2 [counterY][counterX] = 0;
            }
        }
        
        for (int counter1 = 0; counter1 < dimension; counter1++){
            for (int counter2 = 0; counter2 < dimension; counter2++){
                gapFillMatrix2 [counter1][counter2] = 0;
                
                if (counter1+verticalStart >= 0 && counter1+verticalStart < imageHeight && counter2+horizontalStart >= 0 && counter2+horizontalStart < imageHeight){
                    if (arrayExtractedImage [counter1+verticalStart][counter2+horizontalStart] == 100 || arrayExtractedImage [counter1+verticalStart][counter2+horizontalStart] < 50 || arrayExtractedImage [counter1+verticalStart][counter2+horizontalStart] < cutOffValue){
                        gapFillMatrix [counter1][counter2] = 0;
                    }
                    else gapFillMatrix [counter1][counter2] = 1;
                }
                else gapFillMatrix [counter1][counter2] = -1;
            }
        }
        
        int neighbourCount = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (gapFillMatrix [counterY][counterX] != 0 || gapFillMatrix [counterY][counterX] != -1){
                    if (counterY-1 >= 0 && counterX-1 >= 0 && (gapFillMatrix [counterY-1][counterX-1] != 0 || gapFillMatrix [counterY-1][counterX-1] != -1)) neighbourCount++;
                    if (counterY-1 >= 0 && (gapFillMatrix [counterY-1][counterX] != 0 || gapFillMatrix [counterY-1][counterX] != -1)) neighbourCount++;
                    if (counterY-1 >= 0 && counterX+1 < dimension && (gapFillMatrix [counterY-1][counterX+1] != 0 || gapFillMatrix [counterY-1][counterX+1] != -1)) neighbourCount++;
                    if (counterX+1 < dimension && (gapFillMatrix [counterY][counterX+1] != 0 || gapFillMatrix [counterY][counterX+1] != -1)) neighbourCount++;
                    if (counterY+1 < dimension && counterX+1 < dimension && (gapFillMatrix [counterY+1][counterX+1] != 0 || gapFillMatrix [counterY+1][counterX+1] != -1)) neighbourCount++;
                    if (counterY+1 < dimension && gapFillMatrix [counterY+1][counterX] != 0) neighbourCount++;
                    if (counterY+1 < dimension && counterX-1 >= 0 && (gapFillMatrix [counterY+1][counterX-1] != 0 || gapFillMatrix [counterY+1][counterX-1] != -1)) neighbourCount++;
                    if (counterX-1 >= 0 && (gapFillMatrix [counterY][counterX-1] != 0 || gapFillMatrix [counterY][counterX-1] != -1)) neighbourCount++;
                    if ((gapFillMatrix [counterY][counterX] != 0 || gapFillMatrix [counterY][counterX] != -1)) neighbourCount++;
                    
                    if (neighbourCount <= 2){
                        if ((counterY == originY-verticalStart && counterX == originX-horizontalStart) || (counterY == destinationY-verticalStart && counterX == destinationX-horizontalStart));
                        else gapFillMatrix [counterY][counterX] = 0;
                    }
                    
                    neighbourCount = 0;
                }
            }
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<gapFillMatrix [counterA][counterB];
        //	cout<<" gapFillMatrix "<<counterA<<endl;
        //}
        
        for (int counter1 = 0; counter1 < dimension; counter1++){
            for (int counter2 = 0; counter2 < dimension; counter2++){
                if (gapFillMatrix [counter1][counter2] == 1) gapFillMatrix2 [counter1][counter2] = -1;
                else gapFillMatrix2 [counter1][counter2] = 0;
            }
        }
        
        int *connectAnalysisX = new int [dimension*4+1];
        int *connectAnalysisY = new int [dimension*4+1];
        int *connectAnalysisTempX = new int [dimension*4+1];
        int *connectAnalysisTempY = new int [dimension*4+1];
        
        int connectivityNumber = 0;
        int connectAnalysisCount = 0;
        int terminationFlag = 1;
        int connectAnalysisTempCount = 0;
        int xSource = 0;
        int ySource = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (gapFillMatrix2 [counterY][counterX] == -1){
                    connectivityNumber++;
                    gapFillMatrix2 [counterY][counterX] = connectivityNumber;
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && gapFillMatrix2 [counterY-1][counterX] == -1){
                        gapFillMatrix2 [counterY-1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension && gapFillMatrix2 [counterY][counterX+1] == -1){
                        gapFillMatrix2 [counterY][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && gapFillMatrix2 [counterY+1][counterX] == 1){
                        gapFillMatrix2 [counterY+1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && gapFillMatrix2 [counterY][counterX-1] == -1){
                        gapFillMatrix2 [counterY][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && gapFillMatrix2 [ySource-1][xSource] == -1){
                                    gapFillMatrix2 [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension && gapFillMatrix2 [ySource][xSource+1] == -1){
                                    gapFillMatrix2 [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && gapFillMatrix2 [ySource+1][xSource] == -1){
                                    gapFillMatrix2 [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && gapFillMatrix2 [ySource][xSource-1] == -1){
                                    gapFillMatrix2 [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        for (int counter1 = 0; counter1 < dimension; counter1++){
            for (int counter2 = 0; counter2 < dimension; counter2++){
                if (gapFillMatrix [counter1][counter2] == -1) gapFillMatrix2 [counter1][counter2] = -5; //------Outside of frame------
            }
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<gapFillMatrix2 [counterA][counterB];
        //	cout<<" gapFillMatrix2 "<<counterA<<endl;
        //}
        
        matchFlag = 0;
        int boarderFlag = 0;
        
        if (originY-verticalStart >= 0 && originY-verticalStart < dimension && originX-horizontalStart >= 0 && originX-horizontalStart < dimension && gapFillMatrix2 [originY-verticalStart][originX-horizontalStart] == gapFillMatrix2 [destinationY-verticalStart][destinationX-horizontalStart]){
            connectivityNumber = gapFillMatrix2 [originY-verticalStart][originX-horizontalStart];
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (gapFillMatrix2 [counterY][counterX] != connectivityNumber && gapFillMatrix2 [counterY][counterX] != 0 && gapFillMatrix2 [counterY][counterX] != -5) gapFillMatrix2 [counterY][counterX] = 0;
                    else if (counterY+verticalStart < 0 || counterY+verticalStart >= imageWidth || counterX+horizontalStart < 0 || counterX+horizontalStart >= imageWidth) gapFillMatrix2 [counterY][counterX] = 0;
                    else if (gapFillMatrix2 [counterY][counterX] == connectivityNumber && arrayExtractedImage [counterY+verticalStart][counterX+horizontalStart] >= 200){
                        boarderFlag = 0;
                        
                        if (counterY-1 >= 0 && counterX-1 >= 0 && gapFillMatrix2 [counterY-1][counterX-1] == 0) boarderFlag = 1;
                        if (counterY-1 >= 0 && gapFillMatrix2 [counterY-1][counterX] == 0) boarderFlag = 1;
                        if (counterY-1 >= 0 && counterX+1 < dimension && gapFillMatrix2 [counterY-1][counterX+1] == 0) boarderFlag = 1;
                        if (counterX+1 < dimension && gapFillMatrix2 [counterY][counterX+1] == 0) neighbourCount++;
                        if (counterY+1 < dimension && counterX+1 < dimension && gapFillMatrix2 [counterY+1][counterX+1] == 0) boarderFlag = 1;
                        if (counterY+1 < dimension && gapFillMatrix2 [counterY+1][counterX] == 0) boarderFlag = 1;
                        if (counterY+1 < dimension && counterX-1 >= 0 && gapFillMatrix2 [counterY+1][counterX-1] == 0) boarderFlag = 1;
                        if (counterX-1 >= 0 && gapFillMatrix2 [counterY][counterX-1] == 0) boarderFlag = 1;
                        if (gapFillMatrix2 [counterY][counterX] == 0) boarderFlag = 1;
                        if (boarderFlag == 0) gapFillMatrix2 [counterY][counterX] = connectivityNumber+1;
                    }
                }
            }
            
            for (int counter1 = 0; counter1 < gapChaseCount/3; counter1++){
                if (arrayGapChase [counter1*3+2] == 1){
                    if (arrayGapChase [counter1*3]-horizontalStart >= 0 && arrayGapChase [counter1*3]-horizontalStart < dimension && arrayGapChase [counter1*3+1]-verticalStart >= 0 && arrayGapChase [counter1*3+1]-verticalStart < dimension){
                        if (gapFillMatrix2 [arrayGapChase [counter1*3+1]-verticalStart][arrayGapChase [counter1*3]-horizontalStart] != -5) gapFillMatrix2 [arrayGapChase [counter1*3+1]-verticalStart][arrayGapChase [counter1*3]-horizontalStart] = connectivityNumber+2; //------Line source------
                    }
                }
                
                if (arrayGapChase [counter1*3+2] == 2){
                    if (arrayGapChase [counter1*3]-horizontalStart >= 0 && arrayGapChase [counter1*3]-horizontalStart < dimension && arrayGapChase [counter1*3+1]-verticalStart >= 0 && arrayGapChase [counter1*3+1]-verticalStart < dimension){
                        if (gapFillMatrix2 [arrayGapChase [counter1*3+1]-verticalStart][arrayGapChase [counter1*3]-horizontalStart] != -5) gapFillMatrix2 [arrayGapChase [counter1*3+1]-verticalStart][arrayGapChase [counter1*3]-horizontalStart] = connectivityNumber+3; //------Line destination------
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<gapFillMatrix2 [counterA][counterB];
            //	cout<<" gapFillMatrix2 "<<counterA<<endl;
            //}
            
            int originYMap = originY-verticalStart;
            int originXMap = originX-horizontalStart;
            int destinationYMap2 = destinationY-verticalStart;
            int destinationXMap2 = destinationX-horizontalStart;
            gapFillMatrix2 [originYMap][originXMap] = -10;
            gapFillMatrix2 [destinationYMap2][destinationXMap2] = -10;
            
            int midStartYMap2 = originYMap;
            int midStartXMap2 = originXMap;
            int midEndYMap2 = destinationYMap2;
            int midEndXMap2 = destinationXMap2;
            int chaseResult2 = 0;
            int zeroFindFlag = 0;
            
            int gapChaseStatus = 0; //------If all attempt fail, connect line, flag for chase, 0: fail, 1; success, 2: success, 200 fail------
            
            if (dimension*dimension+5 > mapDataLimit){
                delete [] arrayMapData;
                arrayMapData = new int [dimension*dimension+500], mapDataLimit = dimension*dimension+500;
            }
            
            mapDataCount = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++) arrayMapData [mapDataCount] = gapFillMatrix2 [counterY][counterX], mapDataCount++;
            }
            
            //cout<<midStartXMap2<<" "<<midStartYMap2<<" "<<midEndXMap2<<" "<<midEndYMap2<<" "<<dimension<<" "<<connectivityNumber<<" XYPosition"<<endl;
            
            gapFill = [[GapFill alloc] init];
            int chaseResult = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
            
            if (chaseResult == 1){
                int findOverTwohundred = 0;
                int find200 = 0;
                int valueTempX = 0;
                int valueTempY = 0;
                
                for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                    valueTempX = arrayReturnData [counter1*2]+horizontalStart;
                    valueTempY = arrayReturnData [counter1*2+1]+verticalStart;
                    find200 = 0;
                    
                    if (arrayExtractedImage [valueTempY][valueTempX] >= 200 && gapFillMatrix2 [arrayReturnData [counter1*2+1]][arrayReturnData [counter1*2]] == connectivityNumber+1){
                        if (lineSet == 1){
                            if (valueTempY-1 >= 0 && valueTempX-1 >= 0 && arrayExtractedImage [valueTempY-1][valueTempX-1] >= 200) find200++;
                            if (valueTempY-1 >= 0 && arrayExtractedImage [valueTempY-1][valueTempX] >= 200) find200++;
                            if (valueTempY-1 >= 0 && valueTempX+1 < imageHeight && arrayExtractedImage [valueTempY-1][valueTempX+1] >= 200) find200++;
                            if (valueTempX+1 < imageHeight && arrayExtractedImage [valueTempY][valueTempX+1] >= 200) find200++;
                            if (valueTempY+1 < imageHeight && valueTempX+1 < imageHeight && arrayExtractedImage [valueTempY+1][valueTempX+1] >= 200) find200++;
                        }
                        
                        if (lineSet == 3){
                            if (valueTempY+1 < imageHeight && valueTempX+1 < imageHeight && arrayExtractedImage [valueTempY+1][valueTempX+1] >= 200) find200++;
                            if (valueTempY+1 < imageHeight && arrayExtractedImage [valueTempY+1][valueTempX] >= 200) find200++;
                            if (valueTempY+1 < imageHeight && valueTempX-1 >= 0 && arrayExtractedImage [valueTempY+1][valueTempX-1] >= 200) find200++;
                            if (valueTempX-1 >= 0 && arrayExtractedImage [valueTempY][valueTempX-1] >= 200) find200++;
                            if (valueTempY-1 >= 0 && valueTempX-1 >= 0 && arrayExtractedImage [valueTempY-1][valueTempX-1] >= 200) find200++;
                        }
                        
                        if (find200 >= 4) findOverTwohundred++;
                    }
                }
                
                if (findOverTwohundred > 4){
                    chaseResult = 0;
                }
            }
            
            gapFill = [[GapFill alloc] init];
            [gapFill gapFilling:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2];
            
            for (int counter1 = 0; counter1 < gapDataCount/2; counter1++){
                if (gapFillMatrix2 [arrayGapData [counter1*2+1]][arrayGapData [counter1*2]] == 0) zeroFindFlag = 1;
            }
            
            if (zeroFindFlag == 0){
                int findOverTwohundred = 0;
                int find200 = 0;
                int valueTempX = 0;
                int valueTempY = 0;
                
                for (int counter1 = 0; counter1 < gapDataCount/2; counter1++){
                    valueTempX = arrayGapData [counter1*2]+horizontalStart;
                    valueTempY = arrayGapData [counter1*2+1]+verticalStart;
                    find200 = 0;
                    
                    if (arrayExtractedImage [valueTempY][valueTempX] >= 200 && gapFillMatrix2 [arrayGapData [counter1*2+1]][arrayGapData [counter1*2]] == connectivityNumber+1){
                        if (lineSet == 1){
                            if (valueTempY-1 >= 0 && valueTempX-1 >= 0 && arrayExtractedImage [valueTempY-1][valueTempX-1] >= 200) find200++;
                            if (valueTempY-1 >= 0 && arrayExtractedImage [valueTempY-1][valueTempX] >= 200) find200++;
                            if (valueTempY-1 >= 0 && valueTempX+1 < imageHeight && arrayExtractedImage [valueTempY-1][valueTempX+1] >= 200) find200++;
                            if (valueTempX+1 < imageHeight && arrayExtractedImage [valueTempY][valueTempX+1] >= 200) find200++;
                            if (valueTempY+1 < imageHeight && valueTempX+1 < imageHeight && arrayExtractedImage [valueTempY+1][valueTempX+1] >= 200) find200++;
                        }
                        
                        if (lineSet == 3){
                            if (valueTempY+1 < imageHeight && valueTempX+1 < imageHeight && arrayExtractedImage [valueTempY+1][valueTempX+1] >= 200) find200++;
                            if (valueTempY+1 < imageHeight && arrayExtractedImage [valueTempY+1][valueTempX] >= 200) find200++;
                            if (valueTempY+1 < imageHeight && valueTempX-1 >= 0 && arrayExtractedImage [valueTempY+1][valueTempX-1] >= 200) find200++;
                            if (valueTempX-1 >= 0 && arrayExtractedImage [valueTempY][valueTempX-1] >= 200) find200++;
                            if (valueTempY-1 >= 0 && valueTempX-1 >= 0 && arrayExtractedImage [valueTempY-1][valueTempX-1] >= 200) find200++;
                        }
                        
                        if (find200 >= 4) findOverTwohundred++;
                    }
                }
                
                if (findOverTwohundred > 4) zeroFindFlag = 1;
            }
            
            int proceedingFlag = 0;
            
            if (chaseResult == 0 && zeroFindFlag == 0) zeroFindFlag = 2; //------If gap can link by linear, go data entry------
            
            if (chaseResult == 0 && zeroFindFlag == 1) proceedingFlag = 1; //------If gap can link by linear, go data entry------
            
            if (chaseResult == 1 && zeroFindFlag == 0){
                chaseResult = 0;
                zeroFindFlag = 2; //------If gap can link by linear, go data entry------
            }
            
            if (chaseResult == 1 && zeroFindFlag == 1){ //------If gap can link by linear, go data entry------
                if (gapDataCount/2*1.5 <= returnDataCount/2){
                    chaseResult = 0;
                    proceedingFlag = 1;
                }
            }
            
            numberOfFill = 0;
            fillLimit = 100;
            
            arrayGapDataTemp = new int [100];
            
            if (proceedingFlag == 1){
                int **zeroTraceMap = new int *[dimension+3]; //------Source MAP, retain only relevant connect number, start, end -10------
                int **zeroTraceMapA = new int *[dimension+3];
                
                for (int counter1 = 0; counter1 < dimension+3; counter1++){
                    zeroTraceMap [counter1] = new int [dimension+3];
                    zeroTraceMapA [counter1] = new int [dimension+3];
                }
                
                int **zeroTraceMap2 = new int *[dimension+1]; //------Connectivity MAP for ZERO, Connect check, UP/Down/Right/Left only------
                int **zeroTraceMap3 = new int *[dimension+1]; //------Retain connectivity MAP, attaches Linear line------
                int **twoHundredTraceMap = new int *[dimension+1]; //------Source MAP, retain only relevant connect number, start, end -10------
                int **twoHundredTraceMap2 = new int *[dimension+1]; //------Connectivity MAP for Two hundred, Connect check, UP/Down/Right/Left only------
                int **twoHundredTraceMap3 = new int *[dimension+1]; //------Retain connectivity MAP, attaches Linear line------
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    zeroTraceMap2 [counter1] = new int [dimension+1];
                    zeroTraceMap3 [counter1] = new int [dimension+1];
                    twoHundredTraceMap [counter1] = new int [dimension+1];
                    twoHundredTraceMap2 [counter1] = new int [dimension+1];
                    twoHundredTraceMap3 [counter1] = new int [dimension+1];
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){ //------Map set------
                    for (int counterX = 0; counterX < dimension; counterX++) zeroTraceMapA [counterY][counterX] = 0;
                }
                
                //------Map Set Zero------
                for (int counterY = 0; counterY < dimension; counterY++){ //------Map set------
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (gapFillMatrix2 [counterY][counterX] == connectivityNumber){
                            zeroTraceMap [counterY][counterX] = 1;
                            zeroTraceMapA [counterY+1][counterX+1] = -1;
                        }
                        else if (gapFillMatrix2 [counterY][counterX] == connectivityNumber+1){
                            zeroTraceMap [counterY][counterX] = 2;
                            zeroTraceMapA [counterY+1][counterX+1] = -1;
                        }
                        else if (gapFillMatrix2 [counterY][counterX] == connectivityNumber+2){
                            zeroTraceMap [counterY][counterX] = 3;
                            zeroTraceMapA [counterY+1][counterX+1] = -1;
                        }
                        else if (gapFillMatrix2 [counterY][counterX] == connectivityNumber+3){
                            zeroTraceMap [counterY][counterX] = 4;
                            zeroTraceMapA [counterY+1][counterX+1] = -1;
                        }
                        else if (gapFillMatrix2 [counterY][counterX] == -10){
                            zeroTraceMap [counterY][counterX] = -10;
                            zeroTraceMapA [counterY+1][counterX+1] = -1;
                        }
                        else{
                            
                            zeroTraceMap [counterY][counterX] = 0;
                            zeroTraceMapA [counterY+1][counterX+1] = 0;
                        }
                        
                        zeroTraceMap2 [counterY][counterX] = 0;
                        zeroTraceMap3 [counterY][counterX] = 0;
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<zeroTraceMap [counterA][counterB];
                //	cout<<" zeroTraceMap "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < gapDataCount/2; counter1++){ //------Linear line, enter into zeroTrace MAP as 1------
                    zeroTraceMap [arrayGapData [counter1*2+1]][arrayGapData [counter1*2]] = 1;
                    zeroTraceMapA [arrayGapData [counter1*2+1]+1][arrayGapData [counter1*2]+1] = -1;
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<zeroTraceMap [counterA][counterB];
                //	cout<<" zeroTraceMap "<<counterA<<endl;
                //}
                
                //------Map set two hundred------
                for (int counterY = 0; counterY < dimension; counterY++){ //------Map set------
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (gapFillMatrix2 [counterY][counterX] == connectivityNumber){
                            twoHundredTraceMap [counterY][counterX] = 1;
                            twoHundredTraceMap2 [counterY][counterX] = 0;
                        }
                        else if (gapFillMatrix2 [counterY][counterX] == connectivityNumber+1){
                            twoHundredTraceMap [counterY][counterX] = 2;
                            twoHundredTraceMap2 [counterY][counterX] = 2;
                        }
                        else if (gapFillMatrix2 [counterY][counterX] == connectivityNumber+2){
                            twoHundredTraceMap [counterY][counterX] = 3;
                            twoHundredTraceMap2 [counterY][counterX] = 0;
                        }
                        else if (gapFillMatrix2 [counterY][counterX] == connectivityNumber+3){
                            twoHundredTraceMap [counterY][counterX] = 4;
                            twoHundredTraceMap2 [counterY][counterX] = 0;
                        }
                        else if (gapFillMatrix2 [counterY][counterX] == -10){
                            twoHundredTraceMap [counterY][counterX] = -10;
                            twoHundredTraceMap2 [counterY][counterX] = 0;
                        }
                        else if (gapFillMatrix2 [counterY][counterX] == -5){
                            twoHundredTraceMap [counterY][counterX] = -5;
                            twoHundredTraceMap2 [counterY][counterX] = 0;
                        }
                        else{
                            
                            twoHundredTraceMap [counterY][counterX] = 0;
                            twoHundredTraceMap2 [counterY][counterX] = 0;
                        }
                        
                        twoHundredTraceMap2 [counterY][counterX] = 0;
                        twoHundredTraceMap3 [counterY][counterX] = 0;
                    }
                }
                
                for (int counter1 = 0; counter1 < gapDataCount/2; counter1++){ //------Linear line, enter into Two hundredTrace MAP as 1------
                    twoHundredTraceMap [arrayGapData [counter1*2+1]][arrayGapData [counter1*2]] = 1;
                    twoHundredTraceMap2 [arrayGapData [counter1*2+1]][arrayGapData [counter1*2]] = 0;
                }
                
                //------Zero connectivity------
                int connectivityNumber2 = 0;
                
                for (int counterY = 0; counterY < dimension+2; counterY++){
                    for (int counterX = 0; counterX < dimension+2; counterX++){
                        if (zeroTraceMapA [counterY][counterX] == 0){
                            connectivityNumber2++;
                            zeroTraceMapA [counterY][counterX] = connectivityNumber2;
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && zeroTraceMapA [counterY-1][counterX] == 0){
                                zeroTraceMapA [counterY-1][counterX] = connectivityNumber2;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < dimension+2 && zeroTraceMapA [counterY][counterX+1] == 0){
                                zeroTraceMapA [counterY][counterX+1] = connectivityNumber2;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension+2 && zeroTraceMapA [counterY+1][counterX] == 0){
                                zeroTraceMapA [counterY+1][counterX] = connectivityNumber2;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && zeroTraceMapA [counterY][counterX-1] == 0){
                                zeroTraceMapA [counterY][counterX-1] = connectivityNumber2;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                        xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                        
                                        if (ySource-1 >= 0 && zeroTraceMapA [ySource-1][xSource] == 0){
                                            zeroTraceMapA [ySource-1][xSource] = connectivityNumber2;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension+2 && zeroTraceMapA [ySource][xSource+1] == 0){
                                            zeroTraceMapA [ySource][xSource+1] = connectivityNumber2;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension+2 && zeroTraceMapA [ySource+1][xSource] == 0){
                                            zeroTraceMapA [ySource+1][xSource] = connectivityNumber2;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && zeroTraceMapA [ySource][xSource-1] == 0){
                                            zeroTraceMapA [ySource][xSource-1] = connectivityNumber2;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                        connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                for (int counterY = 1; counterY < dimension+1; counterY++){
                    for (int counterX = 1; counterX < dimension+1; counterX++){
                        if (zeroTraceMapA [counterY][counterX] > 0) zeroTraceMap2 [counterY-1][counterX-1] = zeroTraceMapA [counterY][counterX];
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<zeroTraceMap2 [counterA][counterB];
                //	cout<<" zeroTraceMap2 "<<counterA<<endl;
                //}
                
                //------Two hundred connectivity------
                int connectivityNumber3 = 0;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (twoHundredTraceMap2 [counterY][counterX] == 2){
                            connectivityNumber3++;
                            twoHundredTraceMap2 [counterY][counterX] = connectivityNumber3;
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && counterX-1 >= 0 && twoHundredTraceMap2 [counterY-1][counterX-1] == 2){
                                twoHundredTraceMap2 [counterY-1][counterX-1] = connectivityNumber3;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && twoHundredTraceMap2 [counterY-1][counterX] == 2){
                                twoHundredTraceMap2 [counterY-1][counterX] = connectivityNumber3;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && counterX+1 < dimension && twoHundredTraceMap2 [counterY-1][counterX+1] == 2){
                                twoHundredTraceMap2 [counterY-1][counterX+1] = connectivityNumber3;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < dimension && twoHundredTraceMap2 [counterY][counterX+1] == 2){
                                twoHundredTraceMap2 [counterY][counterX+1] = connectivityNumber3;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && counterX+1 < dimension && twoHundredTraceMap2 [counterY+1][counterX+1] == 2){
                                twoHundredTraceMap2 [counterY+1][counterX+1] = connectivityNumber3;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && twoHundredTraceMap2 [counterY+1][counterX] == 2){
                                twoHundredTraceMap2 [counterY+1][counterX] = connectivityNumber3;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && counterX-1 >= 0 && twoHundredTraceMap2 [counterY+1][counterX-1] == 2){
                                twoHundredTraceMap2 [counterY+1][counterX-1] = connectivityNumber3;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && twoHundredTraceMap2 [counterY][counterX-1] == 2){
                                twoHundredTraceMap2 [counterY][counterX-1] = connectivityNumber3;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                        xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                        
                                        if (ySource-1 >= 0 && xSource-1 >= 0 && twoHundredTraceMap2 [ySource-1][xSource-1] == 2){
                                            twoHundredTraceMap2 [ySource-1][xSource-1] = connectivityNumber3;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && twoHundredTraceMap2 [ySource-1][xSource] == 2){
                                            twoHundredTraceMap2 [ySource-1][xSource] = connectivityNumber3;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && xSource+1 < dimension && twoHundredTraceMap2 [ySource-1][xSource+1] == 2){
                                            twoHundredTraceMap2 [ySource-1][xSource+1] = connectivityNumber3;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension && twoHundredTraceMap2 [ySource][xSource+1] == 2){
                                            twoHundredTraceMap2 [ySource][xSource+1] = connectivityNumber3;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 > dimension && xSource+1 < dimension && twoHundredTraceMap2 [ySource+1][xSource+1] == 2){
                                            twoHundredTraceMap2 [ySource+1][xSource+1] = connectivityNumber3;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && twoHundredTraceMap2 [ySource+1][xSource] == 2){
                                            twoHundredTraceMap2 [ySource+1][xSource] = connectivityNumber3;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && xSource-1 >= 0 && twoHundredTraceMap2 [ySource+1][xSource-1] == 2){
                                            twoHundredTraceMap2 [ySource+1][xSource-1] = connectivityNumber3;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && twoHundredTraceMap2 [ySource][xSource-1] == 2){
                                            twoHundredTraceMap2 [ySource][xSource-1] = connectivityNumber3;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                        connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<twoHundredTraceMap2 [counterA][counterB];
                //	cout<<" twoHundredTraceMap2 "<<counterA<<endl;
                //}
                
                //------List for Zero------
                int **numberOfPointList = new int *[connectivityNumber2+2];
                
                for (int counter1 = 0; counter1 < connectivityNumber2+2; counter1++) numberOfPointList [counter1] = new int [3];
                
                for (int counter1 = 0; counter1 < connectivityNumber2+1; counter1++){
                    numberOfPointList [counter1][0] = 0;
                    numberOfPointList [counter1][1] = 0;
                }
                
                //------List for Two hundred------
                int **numberOfPointList2 = new int *[connectivityNumber3+2];
                
                for (int counter1 = 0; counter1 < connectivityNumber3+2; counter1++) numberOfPointList2 [counter1] = new int [3];
                
                for (int counter1 = 0; counter1 < connectivityNumber3+1; counter1++){
                    numberOfPointList2 [counter1][0] = 0;
                    numberOfPointList2 [counter1][1] = 0;
                }
                
                for (int counter1 = 0; counter1 < gapDataCount/2; counter1++){ //------Write linear line as -1 into zeroTraceMap2------
                    zeroTraceMap [arrayGapData [counter1*2+1]][arrayGapData [counter1*2]] = -1;
                    zeroTraceMap2 [arrayGapData [counter1*2+1]][arrayGapData [counter1*2]] = -1;
                    twoHundredTraceMap [arrayGapData [counter1*2+1]][arrayGapData [counter1*2]] = -1;
                    twoHundredTraceMap2 [arrayGapData [counter1*2+1]][arrayGapData [counter1*2]] = -1;
                }
                
                //------Zero extract connectivity group, which attaches line------
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if ((counterY == 0 || counterY == dimension-1 || counterX == 0 || counterX == dimension-1) && zeroTraceMap2 [counterY][counterX] > 0){
                            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                    if (zeroTraceMap2 [counterY2][counterX2] == zeroTraceMap2 [counterY][counterX]) zeroTraceMap2 [counterY2][counterX2] = 0;
                                }
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<zeroTraceMap2 [counterA][counterB];
                //	cout<<" zeroTraceMap2 "<<counterA<<endl;
                //}
                
                int numberOfPoint = 0;
                
                for (int counterY = 0; counterY < dimension; counterY++){ //------Write Connectivity group, which attach with linear line, into zeroTraceMap3, count number of pix------
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (zeroTraceMap2 [counterY][counterX] > 0){
                            for (int counterY2 = counterY-1; counterY2 <= counterY+1; counterY2++){
                                for (int counterX2 = counterX-1; counterX2 <= counterX+1; counterX2++){
                                    if (zeroTraceMap2 [counterY2][counterX2] == -1){
                                        if (numberOfPointList [zeroTraceMap2 [counterY][counterX]][0] == 0){
                                            numberOfPoint = 0;
                                            
                                            for (int counterY3 = 0; counterY3 < dimension; counterY3++){
                                                for (int counterX3 = 0; counterX3 < dimension; counterX3++){
                                                    if (zeroTraceMap2 [counterY3][counterX3] == zeroTraceMap2 [counterY][counterX]){
                                                        zeroTraceMap3 [counterY3][counterX3] = zeroTraceMap2 [counterY][counterX];
                                                        numberOfPoint++;
                                                    }
                                                }
                                            }
                                            
                                            numberOfPointList [zeroTraceMap2 [counterY][counterX]][0] = numberOfPoint; //------0: for number of pix, 2: orientation------
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<zeroTraceMap3 [counterA][counterB];
                //	cout<<" zeroTraceMap3 "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA <= connectivityNumber2; counterA++){
                //	cout<<"PointList_B "<<counterA<<" "<<numberOfPointList [counterA][0]<<" "<<numberOfPointList [counterA][1]<<endl;
                //}
                
                //------Two hundred extract connectivity group, which attaches line------
                for (int counterY = 0; counterY < dimension; counterY++){ //------Remove connectivity group, which attached edges------
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (twoHundredTraceMap2 [counterY][counterX] == -5){
                            for (int counterY2 = counterY-1; counterY2 <= counterY+1; counterY2++){
                                for (int counterX2 = counterX-1; counterX2 <= counterX+1; counterX2++){
                                    if (counterX2 >= 0 && counterX2 < dimension && counterY2 >= 0 && counterY2 < dimension){
                                        if (twoHundredTraceMap2 [counterY2][counterX2] != -5) twoHundredTraceMap2 [counterY2][counterX2] = 0;
                                        
                                        if (gapFillMatrix2 [counterY2][counterX2] == connectivityNumber+1) gapFillMatrix2 [counterY2][counterX2] = connectivityNumber;
                                    }
                                }
                            }
                        }
                    }
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){ //------Remove connectivity group, which attached edges------
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if ((counterY == 0 || counterY == dimension-1 || counterX == 0 || counterX == dimension-1) && twoHundredTraceMap2 [counterY][counterX] > 0){
                            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                    if (twoHundredTraceMap2 [counterY2][counterX2] == twoHundredTraceMap2 [counterY][counterX]) twoHundredTraceMap2 [counterY2][counterX2] = 0;
                                }
                            }
                        }
                    }
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){ //------Write Connectivity group, which attach with linear line, into zeroTraceMap3, count number of pix------
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (twoHundredTraceMap2 [counterY][counterX] > 0){
                            for (int counterY2 = counterY-1; counterY2 <= counterY+1; counterY2++){
                                for (int counterX2 = counterX-1; counterX2 <= counterX+1; counterX2++){
                                    if (twoHundredTraceMap2 [counterY2][counterX2] == -1){
                                        if (numberOfPointList2 [twoHundredTraceMap2 [counterY][counterX]][0] == 0){
                                            numberOfPoint = 0;
                                            
                                            for (int counterY3 = 0; counterY3 < dimension; counterY3++){
                                                for (int counterX3 = 0; counterX3 < dimension; counterX3++){
                                                    if (twoHundredTraceMap2 [counterY3][counterX3] == twoHundredTraceMap2 [counterY][counterX]){
                                                        twoHundredTraceMap3 [counterY3][counterX3] = twoHundredTraceMap2 [counterY][counterX];
                                                        numberOfPoint++;
                                                    }
                                                }
                                            }
                                            
                                            numberOfPointList2 [twoHundredTraceMap2 [counterY][counterX]][0] = numberOfPoint; //------0: for number of pix, 2: orientation------
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<twoHundredTraceMap3 [counterA][counterB];
                //	cout<<" twoHundredTraceMap3 "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA <= connectivityNumber3; counterA++){
                //	cout<<" numberOfPointList2 "<<counterA<<" "<<numberOfPointList2 [counterA][0]<<" "<<numberOfPointList2 [counterA][1]<<endl;
                //}
                
                int lineFirstX = arrayGapData [0];
                int lineFirstY = arrayGapData [1];
                int gapDataTemp1 = (gapDataCount/2-1)*2;
                int gapDataTemp2 = (gapDataCount/2-1)*2+1;
                int lineLastX = arrayGapData [gapDataTemp1];
                int lineLastY = arrayGapData [gapDataTemp2];
                
                int traceType = 0;
                
                if (abs(lineFirstX-lineLastX) > abs(lineFirstY-lineLastY)){ //------Determine line orientation------
                    if (lineFirstX < lineLastX) traceType = 1; //------Left to right, X------
                    else traceType = 2; //------Right to Left, X------
                }
                else if (lineFirstY < lineLastY) traceType = 3; //------Up to bottom, Y------
                else traceType = 4; //------Bottom to Up, Y------
                
                for (int counter1 = 0; counter1 < gapDataCount/2; counter1++){ //------Determine connectivity group orientation For zero------
                    if (gapFillMatrix2 [arrayGapData [counter1*2+1]][arrayGapData [counter1*2]] == 0){
                        if (traceType == 1 || traceType == 2){
                            for (int counter2 = arrayGapData [counter1*2+1]+1; counter2 < dimension; counter2++){ //------X, Down------
                                if (zeroTraceMap3 [counter2][arrayGapData [counter1*2]] > 0) numberOfPointList [zeroTraceMap3 [counter2][arrayGapData [counter1*2]]][1] = 1;
                            }
                            
                            for (int counter2 = arrayGapData [counter1*2+1]-1; counter2 >= 0; counter2 = counter2-1){ //------X, Up------
                                if (zeroTraceMap3 [counter2][arrayGapData [counter1*2]] > 0) numberOfPointList [zeroTraceMap3 [counter2][arrayGapData [counter1*2]]][1] = 2;
                            }
                        }
                        
                        if (traceType == 3 || traceType == 4){
                            for (int counter2 = arrayGapData [counter1*2]+1; counter2 < dimension; counter2++){ //------Y, Right------
                                if (zeroTraceMap3 [arrayGapData [counter1*2+1]][counter2] > 0) numberOfPointList [zeroTraceMap3 [arrayGapData [counter1*2+1]][counter2]][1] = 1;
                            }
                            
                            for (int counter2 = arrayGapData [counter1*2]-1; counter2 >= 0; counter2 = counter2-1){ //------Y, Left------
                                if (zeroTraceMap3 [arrayGapData [counter1*2+1]][counter2] > 0) numberOfPointList [zeroTraceMap3 [arrayGapData [counter1*2+1]][counter2]][1] = 2;
                            }
                        }
                    }
                }
                
                for (int counter1 = 0; counter1 < gapDataCount/2; counter1++){ //------Determine connectivity group orientation For two hundred------
                    if (gapFillMatrix2 [arrayGapData [counter1*2+1]][arrayGapData [counter1*2]] > 200){
                        if (traceType == 1 || traceType == 2){
                            for (int counter2 = arrayGapData [counter1*2+1]+1; counter2 < dimension; counter2++){ //------X, down------
                                if (twoHundredTraceMap3 [counter2][arrayGapData [counter1*2]] > 0) numberOfPointList2 [twoHundredTraceMap3 [counter2][arrayGapData [counter1*2]]][1] = 1;
                            }
                            
                            for (int counter2 = arrayGapData [counter1*2+1]-1; counter2 >= 0; counter2 = counter2-1){ //------X, Up------
                                if (twoHundredTraceMap3 [counter2][arrayGapData [counter1*2]] > 0) numberOfPointList2 [twoHundredTraceMap3 [counter2][arrayGapData [counter1*2]]][1] = 2;
                            }
                        }
                        
                        if (traceType == 3 || traceType == 4){
                            for (int counter2 = arrayGapData [counter1*2]+1; counter2 < dimension; counter2++){ //------Y, Right------
                                if (twoHundredTraceMap3 [arrayGapData [counter1*2+1]][counter2] > 0) numberOfPointList2 [twoHundredTraceMap3 [arrayGapData [counter1*2+1]][counter2]][1] = 1;
                            }
                            
                            for (int counter2 = arrayGapData [counter1*2]-1; counter2 >= 0; counter2 = counter2-1){ //------Y, Left------
                                if (twoHundredTraceMap3 [arrayGapData [counter1*2+1]][counter2] > 0) numberOfPointList2 [twoHundredTraceMap3 [arrayGapData [counter1*2+1]][counter2]][1] = 2;
                            }
                        }
                    }
                }
                
                int findGapPix1 = 0;
                int findGapPix2 = 0;
                
                for (int counter1 = 1; counter1 <= connectivityNumber2; counter1++){ //------Pix number------
                    if (numberOfPointList [counter1][1] == 1) findGapPix1 = findGapPix1+numberOfPointList [counter1][0];
                    if (numberOfPointList [counter1][1] == 2) findGapPix2 = findGapPix2+numberOfPointList [counter1][0];
                }
                
                int findGapPix3 = 0;
                int findGapPix4 = 0;
                
                for (int counter1 = 1; counter1 <= connectivityNumber3; counter1++){ //------Pix number------
                    if (numberOfPointList2 [counter1][1] == 1) findGapPix3 = findGapPix3+numberOfPointList2 [counter1][0];
                    if (numberOfPointList2 [counter1][1] == 2) findGapPix4 = findGapPix4+numberOfPointList2 [counter1][0];
                }
                
                int trackOrder = 0;
                int selectedPix = 0;
                
                if (traceType == 1){ //------Box, 1: bottom side, 2: Left side, 3: up side, 4: Right side------
                    if (findGapPix1 != 0){
                        trackOrder = 2;
                        selectedPix = 1; //------Order: 2,1,4------
                    }
                }
                
                if (traceType == 2){ //------Box, 1: bottom side, 2: Left side, 3: up side, 4: Right side------
                    if (findGapPix2 != 0){
                        trackOrder = 3;
                        selectedPix = 2; //------Order: 4,3,2------
                    }
                }
                
                if (traceType == 3){ //------Box, 1: bottom side, 2: Left side, 3: up side, 4: Right side------
                    if (findGapPix2 != 0){
                        trackOrder = 5;
                        selectedPix = 2; //------Order: 3,2,1------
                    }
                }
                
                if (traceType == 4){ //------Box, 1: bottom side, 2: Left side, 3: up side, 4: Right side------
                    if (findGapPix1 != 0){
                        trackOrder = 8;
                        selectedPix = 1; //------Order: 1,4,3------
                    }
                }
                
                if (trackOrder == 0){
                    if (traceType == 1){ //------Box, 1: bottom side, 2: Left side, 3: up side, 4: Right side------
                        if (findGapPix3 == 0 && findGapPix4 != 0){
                            trackOrder = 1;
                            selectedPix = 2; //------Order: 2,3,4------
                        }
                        
                        if (findGapPix3 != 0 && findGapPix4 == 0){
                            trackOrder = 2;
                            selectedPix = 1; //------Order: 2,1,4------
                        }
                        
                        if (findGapPix3 != 0 && findGapPix4 != 0){
                            if (findGapPix3 >= findGapPix4){
                                trackOrder = 1;
                                selectedPix = 2;
                            }
                            else{
                                
                                trackOrder = 2;
                                selectedPix = 1;
                            }
                        }
                    }
                    if (traceType == 2){
                        if (findGapPix3 == 0 && findGapPix4 != 0){
                            trackOrder = 3;
                            selectedPix = 2; //------Order: 4,3,2------
                        }
                        
                        if (findGapPix3 != 0 && findGapPix4 == 0){
                            trackOrder = 4;
                            selectedPix = 1; //------Order: 4,1,2------
                        }
                        
                        if (findGapPix3 != 0 && findGapPix4 != 0){
                            if (findGapPix3 >= findGapPix4){
                                trackOrder = 3;
                                selectedPix = 2;
                            }
                            else{
                                
                                trackOrder = 4;
                                selectedPix = 1;
                            }
                        }
                    }
                    
                    if (traceType == 3){
                        if (findGapPix3 == 0 && findGapPix4 != 0){
                            trackOrder = 5;
                            selectedPix = 2; //------Order: 3,2,1------
                        }
                        else if (findGapPix3 != 0 && findGapPix4 == 0){
                            trackOrder = 6;
                            selectedPix = 1; //------Order: 3,4,1------
                        }
                        else if (findGapPix3 != 0 && findGapPix4 != 0){
                            if (findGapPix3 >= findGapPix4){
                                trackOrder = 5;
                                selectedPix = 2;
                            }
                            else{
                                
                                trackOrder = 6;
                                selectedPix = 1;
                            }
                        }
                    }
                    if (traceType == 4){
                        if (findGapPix3 == 0 && findGapPix4 != 0){
                            trackOrder = 7;
                            selectedPix = 2; //------Order: 1,2,3------
                        }
                        else if (findGapPix3 != 0 && findGapPix4 == 0){
                            trackOrder = 8;
                            selectedPix = 1; //------Order: 1,4,3------
                        }
                        else if (findGapPix3 != 0 && findGapPix4 != 0){
                            if (findGapPix3 >= findGapPix4){
                                trackOrder = 7;
                                selectedPix = 2;
                            }
                            else{
                                
                                trackOrder = 8;
                                selectedPix = 1;
                            }
                        }
                    }
                }
                if (trackOrder != 0){
                    int maxPointX [2];
                    int maxPointY [2];
                    int minPointX [2];
                    int minPointY [2];
                    int markerPoint [5][2];
                    
                    maxPointX [0] = -1;
                    maxPointX [1] = -1;
                    maxPointY [0] = -1;
                    maxPointY [1] = -1;
                    minPointX [0] = 10000;
                    minPointX [1] = -1;
                    minPointY [0] = -1;
                    minPointY [1] = 10000;
                    
                    for (int counter1 = 1; counter1 <= connectivityNumber2; counter1++){ //------Determine Box dimension------
                        if (numberOfPointList [counter1][1] == selectedPix){
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (zeroTraceMap3 [counterY][counterX] == counter1){
                                        if (maxPointX [0] < counterX){
                                            maxPointX [0] = counterX;
                                            maxPointX [1] = counterY; //------Side 4------
                                        }
                                        
                                        if (minPointX [0] > counterX){
                                            minPointX [0] = counterX;
                                            minPointX [1] = counterY; //------Side 2------
                                        }
                                        
                                        if (maxPointY [1] < counterY){
                                            maxPointY [0] = counterX;
                                            maxPointY [1] = counterY; //------Side 1------
                                        }
                                        
                                        if (minPointY [1] > counterY){
                                            minPointY [0] = counterX;
                                            minPointY [1] = counterY; //------Side 3------
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    for (int counter1 = 1; counter1 <= connectivityNumber3; counter1++){ //------Determine Box dimension------
                        if (numberOfPointList2 [counter1][1] == selectedPix){
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (twoHundredTraceMap3 [counterY][counterX] == counter1){
                                        if (maxPointX [0] < counterX){
                                            maxPointX [0] = counterX;
                                            maxPointX [1] = counterY; //------Side 4------
                                        }
                                        
                                        if (minPointX [0] > counterX){
                                            minPointX [0] = counterX;
                                            minPointX [1] = counterY; //------Side 2------
                                        }
                                        
                                        if (maxPointY [1] < counterY){
                                            maxPointY [0] = counterX;
                                            maxPointY [1] = counterY; //------Side 1------
                                        }
                                        
                                        if (minPointY [1] > counterY){
                                            minPointY [0] = counterX;
                                            minPointY [1] = counterY; //------Side 3------
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    if (maxPointX [0] == -1 || minPointX [0] == 10000 || maxPointY [0] == -1 || minPointY [0] == 10000) matchFlag = 2;
                    
                    if (matchFlag == 0){
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (zeroTraceMap [counterY][counterX] == -1 || zeroTraceMap [counterY][counterX] == 3 || zeroTraceMap [counterY][counterX] == 4 || zeroTraceMap [counterY][counterX] == -10){
                                    if ((traceType == 1 || traceType == 2) && selectedPix == 1){
                                        for (int counter2 = 0; counter2 < dimension; counter2++){
                                            if (zeroTraceMap [counter2][counterX] == -1 || zeroTraceMap [counter2][counterX] == 3 || zeroTraceMap [counter2][counterX] == 4 || zeroTraceMap [counter2][counterX] == -10){
                                                break;
                                            }
                                            else gapFillMatrix2 [counter2][counterX] = 0;
                                        }
                                    }
                                    if ((traceType == 1 || traceType == 2) && selectedPix == 2){
                                        for (int counter2 = dimension-1; counter2 >= 0; counter2 = counter2-1){
                                            if (zeroTraceMap [counter2][counterX] == -1 || zeroTraceMap [counter2][counterX] == 3 || zeroTraceMap [counter2][counterX] == 4 || zeroTraceMap [counter2][counterX] == -10){
                                                break;
                                            }
                                            else gapFillMatrix2 [counter2][counterX] = 0;
                                        }
                                    }
                                    if ((traceType == 3 || traceType == 4) && selectedPix == 1){
                                        for (int counter2 = 0; counter2 < dimension; counter2++){
                                            if (zeroTraceMap [counterY][counter2] == -1 || zeroTraceMap [counterY][counter2] == 3 || zeroTraceMap [counterY][counter2] == 4 || zeroTraceMap [counterY][counter2] == -10){
                                                break;
                                            }
                                            else gapFillMatrix2 [counterY][counter2] = 0;
                                        }
                                    }
                                    if ((traceType == 3 || traceType == 4) && selectedPix == 2){
                                        for (int counter2 = dimension; counter2 >= 0; counter2 = counter2-1){
                                            if (zeroTraceMap [counterY][counter2] == -1 || zeroTraceMap [counterY][counter2] == 3 || zeroTraceMap [counterY][counter2] == 4 || zeroTraceMap [counterY][counter2] == -10){
                                                break;
                                            }
                                            else gapFillMatrix2 [counterY][counter2] = 0;
                                        }
                                    }
                                }
                            }
                        }
                        
                        if (dimension*dimension+5 > mapDataLimit){
                            delete [] arrayMapData;
                            arrayMapData = new int [dimension*dimension+500], mapDataLimit = dimension*dimension+500;
                        }
                        
                        mapDataCount = 0;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++) arrayMapData [mapDataCount] = gapFillMatrix2 [counterY][counterX], mapDataCount++;
                        }
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<gapFillMatrix2 [counterA][counterB];
                        //	cout<<" gapFillMatrix2 "<<counterA<<endl;
                        //}
                        
                        int markerOrderX1 = -1;
                        int markerOrderY1 = -1;
                        int markerOrderX2 = -1;
                        int markerOrderY2 = -1;
                        int markerOrderX3 = -1;
                        int markerOrderY3 = -1;
                        int markerOrderX4 = -1;
                        int markerOrderY4 = -1;
                        
                        int markerYTemp = 0;
                        
                        for (int counter1 = maxPointX [0]; counter1 < dimension; counter1++){ //------Find pix on Connectivity Number------
                            markerYTemp = maxPointX [1];
                            
                            if (gapFillMatrix2 [markerYTemp][counter1] == connectivityNumber){
                                markerOrderX4 = counter1;
                                markerOrderY4 = markerYTemp;
                                break;
                            }
                            
                            if (gapFillMatrix2 [markerYTemp][counter1] == connectivityNumber+1){
                                markerOrderX4 = counter1;
                                markerOrderY4 = markerYTemp;
                                break;
                            }
                        }
                        
                        for (int counter1 = minPointX [0]; counter1 >= 0; counter1 = counter1-1){
                            markerYTemp = minPointX [1];
                            
                            if (gapFillMatrix2 [markerYTemp][counter1] == connectivityNumber){
                                markerOrderX2 = counter1;
                                markerOrderY2 = markerYTemp;
                                break;
                            }
                            
                            if (gapFillMatrix2 [markerYTemp][counter1] == connectivityNumber+1){
                                markerOrderX2 = counter1;
                                markerOrderY2 = markerYTemp;
                                break;
                            }
                        }
                        
                        int markerXTemp = 0;
                        
                        for (int counter1 = minPointY [1]; counter1 >= 0; counter1 = counter1-1){
                            markerXTemp = minPointY [0];
                            
                            if (gapFillMatrix2 [counter1][markerXTemp] == connectivityNumber){
                                markerOrderX3 = markerXTemp;
                                markerOrderY3 = counter1;
                                break;
                            }
                            
                            if (gapFillMatrix2 [counter1][markerXTemp] == connectivityNumber+1){
                                markerOrderX3 = markerXTemp;
                                markerOrderY3 = counter1;
                                break;
                            }
                        }
                        
                        for (int counter1 = maxPointY [1]; counter1 < dimension; counter1++){
                            markerXTemp = maxPointY [0];
                            
                            if (gapFillMatrix2 [counter1][markerXTemp] == connectivityNumber){
                                markerOrderX1 = markerXTemp;
                                markerOrderY1 = counter1;
                                break;
                            }
                            
                            if (gapFillMatrix2 [counter1][markerXTemp] == connectivityNumber+1){
                                markerOrderX1 = markerXTemp;
                                markerOrderY1 = counter1;
                                break;
                            }
                        }
                        
                        for (int counter1 = 1; counter1 <= connectivityNumber2; counter1++){
                            if (numberOfPointList [counter1][1] == selectedPix){
                                for (int counterY = 0; counterY < dimension; counterY++){
                                    for (int counterX = 0; counterX < dimension; counterX++){
                                        if (zeroTraceMap3 [counterY][counterX] == counter1) zeroTraceMap3 [counterY][counterX] = -1;
                                    }
                                }
                            }
                        }
                        
                        for (int counter1 = 1; counter1 <= connectivityNumber3; counter1++){
                            if (numberOfPointList2 [counter1][1] == selectedPix){
                                for (int counterY = 0; counterY < dimension; counterY++){
                                    for (int counterX = 0; counterX < dimension; counterX++){
                                        if (twoHundredTraceMap3 [counterY][counterX] == counter1) zeroTraceMap3 [counterY][counterX] = -1;
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<zeroTraceMap3 [counterA][counterB];
                        //	cout<<" zeroTraceMap3 "<<counterA<<endl;
                        //}
                        
                        int markerCornerX1 = minPointX [0];
                        int markerCornerY1 = maxPointY [1];
                        int markerCornerX2 = minPointX [0];
                        int markerCornerY2 = minPointY [1];
                        int markerCornerX3 = maxPointX [0];
                        int markerCornerY3 = minPointY [1];
                        int markerCornerX4 = maxPointX [0];
                        int markerCornerY4 = maxPointY [1];
                        
                        for (int counter1 = 0; counter1 < 5; counter1++){
                            markerPoint [counter1][0] = -1;
                            markerPoint [counter1][1] = -1;
                        }
                        
                        if (trackOrder == 1){ //------Order: 2,3,4------
                            if (abs(originYMap-markerOrderY2) == 1 && abs(originXMap-markerOrderX2) == 1);
                            else{
                                
                                markerPoint [0][0] = markerOrderX2;
                                markerPoint [0][1] = markerOrderY2;
                            }
                            
                            if (abs(markerOrderY2-markerCornerY2) == 1 && abs(markerOrderX2-markerCornerX2) == 1);
                            else{
                                
                                markerPoint [1][0] = markerCornerX2;
                                markerPoint [1][1] = markerCornerY2;
                            }
                            
                            if (abs(markerCornerY2-markerOrderY3) == 1 && abs(markerCornerX2-markerOrderX3) == 1){
                                markerPoint [1][0] = -1;
                                markerPoint [1][1] = -1;
                                markerPoint [2][0] = markerOrderX3;
                                markerPoint [2][1] = markerOrderY3;
                            }
                            else{
                                
                                markerPoint [2][0] = markerOrderX3;
                                markerPoint [2][1] = markerOrderY3;
                            }
                            
                            if (abs(markerOrderY3-markerCornerY3) == 1 && abs(markerOrderX3-markerCornerX3) == 1);
                            else{
                                
                                markerPoint [3][0] = markerCornerX3;
                                markerPoint [3][1] = markerCornerY3;
                            }
                            
                            if (abs(markerCornerY3-markerOrderY4) == 1 && abs(markerCornerX3-markerOrderX4) == 1){
                                markerPoint [3][0] = -1;
                                markerPoint [3][1] = -1;
                                markerPoint [4][0] = markerOrderX4;
                                markerPoint [4][1] = markerOrderY4;
                            }
                            else{
                                
                                markerPoint [4][0] = markerOrderX4;
                                markerPoint [4][1] = markerOrderY4;
                            }
                            
                            if (abs(markerOrderY4-destinationYMap2) == 1 && abs(markerOrderX4-destinationXMap2) == 1){
                                markerPoint [4][0] = -1;
                                markerPoint [4][1] = -1;
                                
                                if (abs(markerOrderY3-markerCornerY3) == 1 && abs(markerOrderX3-markerCornerX3) == 1);
                                else{
                                    
                                    markerPoint [3][0] = markerCornerX3;
                                    markerPoint [3][1] = markerCornerY3;
                                }
                            }
                        }
                        
                        if (trackOrder == 2){ //------Order: 2,1,4------
                            if (abs(originYMap-markerOrderY2) == 1 && abs(originXMap-markerOrderX2) == 1);
                            else{
                                
                                markerPoint [0][0] = markerOrderX2;
                                markerPoint [0][1] = markerOrderY2;
                            }
                            
                            if (abs(markerOrderY2-markerCornerY1) == 1 && abs(markerOrderX2-markerCornerX1) == 1);
                            else{
                                
                                markerPoint [1][0] = markerCornerX1;
                                markerPoint [1][1] = markerCornerY1;
                            }
                            
                            if (abs(markerCornerY1-markerOrderY1) == 1 && abs(markerCornerX1-markerOrderX1) == 1){
                                markerPoint [1][0] = -1;
                                markerPoint [1][1] = -1;
                                markerPoint [2][0] = markerOrderX1;
                                markerPoint [2][1] = markerOrderY1;
                            }
                            else{
                                
                                markerPoint [2][0] = markerOrderX1;
                                markerPoint [2][1] = markerOrderY1;
                            }
                            
                            if (abs(markerOrderY1-markerCornerY4) == 1 && abs(markerOrderX1-markerCornerX4) == 1);
                            else{
                                
                                markerPoint [3][0] = markerCornerX4;
                                markerPoint [3][1] = markerCornerY4;
                            }
                            
                            if (abs(markerCornerY4-markerOrderY4) == 1 && abs(markerCornerX4-markerOrderX4) == 1){
                                markerPoint [3][0] = -1;
                                markerPoint [3][1] = -1;
                                markerPoint [4][0] = markerOrderX4;
                                markerPoint [4][1] = markerOrderY4;
                            }
                            else{
                                
                                markerPoint [4][0] = markerOrderX4;
                                markerPoint [4][1] = markerOrderY4;
                            }
                            
                            if (abs(markerOrderY4-destinationYMap2) == 1 && abs(markerOrderX4-destinationXMap2) == 1){
                                markerPoint [4][0] = -1;
                                markerPoint [4][1] = -1;
                                
                                if (abs(markerOrderY1-markerCornerY4) == 1 && abs(markerOrderX1-markerCornerX4) == 1);
                                else{
                                    
                                    markerPoint [3][0] = markerCornerX4;
                                    markerPoint [3][1] = markerCornerY4;
                                }
                            }
                        }
                        
                        if (trackOrder == 3){ //------Order: 4,3,2------
                            if (abs(originYMap-markerOrderY4) == 1 && abs(originXMap-markerOrderX4) == 1);
                            else{
                                markerPoint [0][0] = markerOrderX4;
                                markerPoint [0][1] = markerOrderY4;
                            }
                            
                            if (abs(markerOrderY4-markerCornerY3) == 1 && abs(markerOrderX4-markerCornerX3) == 1);
                            else{
                                
                                markerPoint [1][0] = markerCornerX3;
                                markerPoint [1][1] = markerCornerY3;
                            }
                            
                            if (abs(markerCornerY3-markerOrderY3) == 1 && abs(markerCornerX3-markerOrderX3) == 1){
                                markerPoint [1][0] = -1;
                                markerPoint [1][1] = -1;
                                markerPoint [2][0] = markerOrderX3;
                                markerPoint [2][1] = markerOrderY3;
                            }
                            else{
                                
                                markerPoint [2][0] = markerOrderX3;
                                markerPoint [2][1] = markerOrderY3;
                            }
                            
                            if (abs(markerOrderY3-markerCornerY2) == 1 && abs(markerOrderX3-markerCornerX2) == 1);
                            else{
                                
                                markerPoint [3][0] = markerCornerX2;
                                markerPoint [3][1] = markerCornerY2;
                            }
                            
                            if (abs(markerCornerY2-markerOrderY2) == 1 && abs(markerCornerX2-markerOrderX2) == 1){
                                markerPoint [3][0] = -1;
                                markerPoint [3][1] = -1;
                                markerPoint [4][0] = markerOrderX2;
                                markerPoint [4][1] = markerOrderY2;
                            }
                            else{
                                
                                markerPoint [4][0] = markerOrderX2;
                                markerPoint [4][1] = markerOrderY2;
                            }
                            
                            if (abs(markerOrderY2-destinationYMap2) == 1 && abs(markerOrderX2-destinationXMap2) == 1){
                                markerPoint [4][0] = -1;
                                markerPoint [4][1] = -1;
                                
                                if (abs(markerOrderY3-markerCornerY2) == 1 && abs(markerOrderX3-markerCornerX2) == 1);
                                else{
                                    
                                    markerPoint [3][0] = markerCornerX2;
                                    markerPoint [3][1] = markerCornerY2;
                                }
                            }
                        }
                        
                        if (trackOrder == 4){ //------Order: 4,1,2------
                            if (abs(originYMap-markerOrderY4) == 1 && abs(originXMap-markerOrderX4) == 1);
                            else{
                                
                                markerPoint [0][0] = markerOrderX4;
                                markerPoint [0][1] = markerOrderY4;
                            }
                            
                            if (abs(markerOrderY4-markerCornerY4) == 1 && abs(markerOrderX4-markerCornerX4) == 1);
                            else{
                                
                                markerPoint [1][0] = markerCornerX4;
                                markerPoint [1][1] = markerCornerY4;
                            }
                            
                            if (abs(markerCornerY4-markerOrderY1) == 1 && abs(markerCornerX4-markerOrderX1) == 1){
                                markerPoint [1][0] = -1;
                                markerPoint [1][1] = -1;
                                markerPoint [2][0] = markerOrderX1;
                                markerPoint [2][1] = markerOrderY1;
                            }
                            else{
                                
                                markerPoint [2][0] = markerOrderX1;
                                markerPoint [2][1] = markerOrderY1;
                            }
                            
                            if (abs(markerOrderY1-markerCornerY1) == 1 && abs(markerOrderX1-markerCornerX1) == 1);
                            else{
                                
                                markerPoint [3][0] = markerCornerX1;
                                markerPoint [3][1] = markerCornerY1;
                            }
                            
                            if (abs(markerCornerY1-markerOrderY2) == 1 && abs(markerCornerX1-markerOrderX2) == 1){
                                markerPoint [3][0] = -1;
                                markerPoint [3][1] = -1;
                                markerPoint [4][0] = markerOrderX2;
                                markerPoint [4][1] = markerOrderY2;
                            }
                            else{
                                
                                markerPoint [4][0] = markerOrderX2;
                                markerPoint [4][1] = markerOrderY2;
                            }
                            
                            if (abs(markerOrderY2-destinationYMap2) == 1 && abs(markerOrderX2-destinationXMap2) == 1){
                                markerPoint [4][0] = -1;
                                markerPoint [4][1] = -1;
                                
                                if (abs(markerOrderY1-markerCornerY1) == 1 && abs(markerOrderX1-markerCornerX1) == 1);
                                else{
                                    
                                    markerPoint [3][0] = markerCornerX1;
                                    markerPoint [3][1] = markerCornerY1;
                                }
                            }
                        }
                        
                        if (trackOrder == 5){ //------Order: 3,2,1------
                            if (abs(originYMap-markerOrderY3) == 1 && abs(originXMap-markerOrderX3) == 1);
                            else{
                                
                                markerPoint [0][0] = markerOrderX3;
                                markerPoint [0][1] = markerOrderY3;
                            }
                            
                            if (abs(markerOrderY3-markerCornerY2) == 1 && abs(markerOrderX3-markerCornerX2) == 1);
                            else{
                                
                                markerPoint [1][0] = markerCornerX2;
                                markerPoint [1][1] = markerCornerY2;
                            }
                            
                            if (abs(markerCornerY2-markerOrderY2) == 1 && abs(markerCornerX2-markerOrderX2) == 1){
                                markerPoint [1][0] = -1;
                                markerPoint [1][1] = -1;
                                markerPoint [2][0] = markerOrderX2;
                                markerPoint [2][1] = markerOrderY2;
                            }
                            else{
                                
                                markerPoint [2][0] = markerOrderX2;
                                markerPoint [2][1] = markerOrderY2;
                            }
                            
                            if (abs(markerOrderY2-markerCornerY1) == 1 && abs(markerOrderX2-markerCornerX1) == 1);
                            else{
                                
                                markerPoint [3][0] = markerCornerX1;
                                markerPoint [3][1] = markerCornerY1;
                            }
                            
                            if (abs(markerCornerY1-markerOrderY1) == 1 && abs(markerCornerX1-markerOrderX1) == 1){
                                markerPoint [3][0] = -1;
                                markerPoint [3][1] = -1;
                                markerPoint [4][0] = markerOrderX1;
                                markerPoint [4][1] = markerOrderY1;
                            }
                            else{
                                
                                markerPoint [4][0] = markerOrderX1;
                                markerPoint [4][1] = markerOrderY1;
                            }
                            
                            if (abs(markerOrderY1-destinationYMap2) == 1 && abs(markerOrderX1-destinationXMap2) == 1){
                                markerPoint [4][0] = -1;
                                markerPoint [4][1] = -1;
                                
                                if (abs(markerOrderY2-markerCornerY1) == 1 && abs(markerOrderX2-markerCornerX1) == 1);
                                else{
                                    
                                    markerPoint [3][0] = markerCornerX1;
                                    markerPoint [3][1] = markerCornerY1;
                                }
                            }
                        }
                        if (trackOrder == 6){ //------Order: 3,4,1------
                            if (abs(originYMap-markerOrderY3) == 1 && abs(originXMap-markerOrderX3) == 1);
                            else{
                                
                                markerPoint [0][0] = markerOrderX3;
                                markerPoint [0][1] = markerOrderY3;
                            }
                            
                            if (abs(markerOrderY3-markerCornerY3) == 1 && abs(markerOrderX3-markerCornerX3) == 1);
                            else{
                                
                                markerPoint [1][0] = markerCornerX3;
                                markerPoint [1][1] = markerCornerY3;
                            }
                            
                            if (abs(markerCornerY3-markerOrderY4) == 1 && abs(markerCornerX3-markerOrderX4) == 1){
                                markerPoint [1][0] = -1;
                                markerPoint [1][1] = -1;
                                markerPoint [2][0] = markerOrderX4;
                                markerPoint [2][1] = markerOrderY4;
                            }
                            else{
                                
                                markerPoint [2][0] = markerOrderX4;
                                markerPoint [2][1] = markerOrderY4;
                            }
                            
                            if (abs(markerOrderY4-markerCornerY4) == 1 && abs(markerOrderX4-markerCornerX4) == 1);
                            else{
                                
                                markerPoint [3][0] = markerCornerX4;
                                markerPoint [3][1] = markerCornerY4;
                            }
                            
                            if (abs(markerCornerY4-markerOrderY1) == 1 && abs(markerCornerX4-markerOrderX1) == 1){
                                markerPoint [3][0] = -1;
                                markerPoint [3][1] = -1;
                                markerPoint [4][0] = markerOrderX1;
                                markerPoint [4][1] = markerOrderY1;
                            }
                            else{
                                
                                markerPoint [4][0] = markerOrderX1;
                                markerPoint [4][1] = markerOrderY1;
                            }
                            
                            if (abs(markerOrderY1-destinationYMap2) == 1 && abs(markerOrderX1-destinationXMap2) == 1){
                                markerPoint [4][0] = -1;
                                markerPoint [4][1] = -1;
                                
                                if (abs(markerOrderY4-markerCornerY4) == 1 && abs(markerOrderX4-markerCornerX4) == 1);
                                else{
                                    
                                    markerPoint [3][0] = markerCornerX4;
                                    markerPoint [3][1] = markerCornerY4;
                                }
                            }
                        }
                        
                        if (trackOrder == 7){ //------Order: 1,2,3------
                            if (abs(originYMap-markerOrderY1) == 1 && abs(originXMap-markerOrderX1) == 1);
                            else{
                                
                                markerPoint [0][0] = markerOrderX1;
                                markerPoint [0][1] = markerOrderY1;
                            }
                            
                            if (abs(markerOrderY1-markerCornerY1) == 1 && abs(markerOrderX1-markerCornerX1) == 1);
                            else{
                                
                                markerPoint [1][0] = markerCornerX1;
                                markerPoint [1][1] = markerCornerY1;
                            }
                            
                            if (abs(markerCornerY1-markerOrderY2) == 1 && abs(markerCornerX1-markerOrderX2) == 1){
                                markerPoint [1][0] = -1;
                                markerPoint [1][1] = -1;
                                markerPoint [2][0] = markerOrderX2;
                                markerPoint [2][1] = markerOrderY2;
                            }
                            else{
                                
                                markerPoint [2][0] = markerOrderX2;
                                markerPoint [2][1] = markerOrderY2;
                            }
                            
                            if (abs(markerOrderY2-markerCornerY2) == 1 && abs(markerOrderX2-markerCornerX2) == 1);
                            else{
                                
                                markerPoint [3][0] = markerCornerX2;
                                markerPoint [3][1] = markerCornerY2;
                            }
                            
                            if (abs(markerCornerY2-markerOrderY3) == 1 && abs(markerCornerX2-markerOrderX3) == 1){
                                markerPoint [3][0] = -1;
                                markerPoint [3][1] = -1;
                                markerPoint [4][0] = markerOrderX3;
                                markerPoint [4][1] = markerOrderY3;
                            }
                            else{
                                
                                markerPoint [4][0] = markerOrderX3;
                                markerPoint [4][1] = markerOrderY3;
                            }
                            
                            if (abs(markerOrderY3-destinationYMap2) == 1 && abs(markerOrderX3-destinationXMap2) == 1){
                                markerPoint [4][0] = -1;
                                markerPoint [4][1] = -1;
                                
                                if (abs(markerOrderY2-markerCornerY2) == 1 && abs(markerOrderX2-markerCornerX2) == 1);
                                else{
                                    
                                    markerPoint [3][0] = markerCornerX2;
                                    markerPoint [3][1] = markerCornerY2;
                                }
                            }
                        }
                        if (trackOrder == 8){ //------Order: 1,4,3------
                            if (abs(originYMap-markerOrderY1) == 1 && abs(originXMap-markerOrderX1) == 1);
                            else{
                                
                                markerPoint [0][0] = markerOrderX1;
                                markerPoint [0][1] = markerOrderY1;
                            }
                            
                            if (abs(markerOrderY1-markerCornerY4) == 1 && abs(markerOrderX1-markerCornerX4) == 1);
                            else{
                                
                                markerPoint [1][0] = markerCornerX4;
                                markerPoint [1][1] = markerCornerY4;
                            }
                            
                            if (abs(markerCornerY4-markerOrderY4) == 1 && abs(markerCornerX4-markerOrderX4) == 1){
                                markerPoint [1][0] = -1;
                                markerPoint [1][1] = -1;
                                markerPoint [2][0] = markerOrderX4;
                                markerPoint [2][1] = markerOrderY4;
                            }
                            else{
                                
                                markerPoint [2][0] = markerOrderX4;
                                markerPoint [2][1] = markerOrderY4;
                            }
                            
                            if (abs(markerOrderY4-markerCornerY3) == 1 && abs(markerOrderX4-markerCornerX3) == 1);
                            else{
                                
                                markerPoint [3][0] = markerCornerX3;
                                markerPoint [3][1] = markerCornerY3;
                            }
                            
                            if (abs(markerCornerY3-markerOrderY3) == 1 && abs(markerCornerX3-markerOrderX3) == 1){
                                markerPoint [3][0] = -1;
                                markerPoint [3][1] = -1;
                                markerPoint [4][0] = markerOrderX3;
                                markerPoint [4][1] = markerOrderY3;
                            }
                            else{
                                
                                markerPoint [4][0] = markerOrderX3;
                                markerPoint [4][1] = markerOrderY3;
                            }
                            
                            if (abs(markerOrderY3-destinationYMap2) == 1 && abs(markerOrderX3-destinationXMap2) == 1){
                                markerPoint [4][0] = -1;
                                markerPoint [4][1] = -1;
                                
                                if (abs(markerOrderY4-markerCornerY3) == 1 && abs(markerOrderX4-markerCornerX3) == 1);
                                else{
                                    
                                    markerPoint [3][0] = markerCornerX3;
                                    markerPoint [3][1] = markerCornerY3;
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < 5; counterA++){
                        //	cout<<"markerPoint "<<markerPoint [counterA][0]<<" "<<markerPoint [counterA][1]<<endl;
                        //}
                        
                        //zeroTraceMap3 [markerOrderY1][markerOrderX1] = -11; //------For CHECK------
                        //zeroTraceMap3 [markerOrderY2][markerOrderX2] = -12;
                        //zeroTraceMap3 [markerOrderY3][markerOrderX3] = -13;
                        //zeroTraceMap3 [markerOrderY4][markerOrderX4] = -14;
                        //zeroTraceMap3 [markerCornerY1][markerCornerX1] = -21;
                        //zeroTraceMap3 [markerCornerY2][markerCornerX2] = -22;
                        //zeroTraceMap3 [markerCornerY3][markerCornerX3] = -23;
                        //zeroTraceMap3 [markerCornerY4][markerCornerX4] = -24;
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<zeroTraceMap3 [counterA][counterB];
                        //	cout<<" zeroTraceMap3 "<<counterA<<endl;
                        //}
                        
                        midStartXMap2 = originXMap;
                        midStartYMap2 = originYMap;
                        
                        if (markerPoint [0][0] != -1){
                            midEndXMap2 = markerPoint [0][0];
                            midEndYMap2 = markerPoint [0][1];
                            
                            gapFill = [[GapFill alloc] init];
                            int chaseResult3 = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                            
                            if (chaseResult3 == 1){
                                if (numberOfFill+returnDataCount+2 > fillLimit){
                                    fillAddition = returnDataCount+2;
                                    [self gapFillUpdate];
                                }
                                
                                for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                    arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                    arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                }
                                
                                arrayGapDataTemp [numberOfFill] = midEndXMap2, numberOfFill++;
                                arrayGapDataTemp [numberOfFill] = midEndYMap2, numberOfFill++;
                                
                                midStartXMap2 = midEndXMap2;
                                midStartYMap2 = midEndYMap2;
                                midEndXMap2 = markerPoint [2][0];
                                midEndYMap2 = markerPoint [2][1];
                                
                                gapFill = [[GapFill alloc] init];
                                chaseResult3 = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                
                                if (chaseResult3 == 1){
                                    if (numberOfFill+returnDataCount+2 > fillLimit){
                                        fillAddition = returnDataCount+2;
                                        [self gapFillUpdate];
                                    }
                                    
                                    for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                        arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                        arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                    }
                                }
                                else if (markerPoint [1][0] == -1) matchFlag = 2;
                                else{
                                    
                                    midEndXMap2 = markerPoint [1][0];
                                    midEndYMap2 = markerPoint [1][1];
                                    
                                    gapFill = [[GapFill alloc] init];
                                    chaseResult3 = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                    
                                    if (chaseResult3 == 1){
                                        if (numberOfFill+returnDataCount+2 > fillLimit){
                                            fillAddition = returnDataCount+2;
                                            [self gapFillUpdate];
                                        }
                                        
                                        for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                            arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                            arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                        }
                                        
                                        arrayGapDataTemp [numberOfFill] = midEndXMap2, numberOfFill++;
                                        arrayGapDataTemp [numberOfFill] = midEndYMap2, numberOfFill++;
                                        
                                        midStartXMap2 = midEndXMap2;
                                        midStartYMap2 = midEndYMap2;
                                        midEndXMap2 = markerPoint [2][0];
                                        midEndYMap2 = markerPoint [2][1];
                                        
                                        gapFill = [[GapFill alloc] init];
                                        chaseResult3 = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                        
                                        if (chaseResult3 == 1){
                                            if (numberOfFill+returnDataCount+2 > fillLimit){
                                                fillAddition = returnDataCount+2;
                                                [self gapFillUpdate];
                                            }
                                            
                                            for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                                arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                                arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                            }
                                        }
                                        else matchFlag = 2;
                                    }
                                    else matchFlag = 2;
                                }
                            }
                            else matchFlag = 2;
                        }
                        
                        if (markerPoint [0][0] == -1){
                            midEndXMap2 = markerPoint [2][0];
                            midEndYMap2 = markerPoint [2][1];
                            
                            gapFill = [[GapFill alloc] init];
                            int chaseResult3 = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                            
                            if (chaseResult3 == 1){
                                if (numberOfFill+returnDataCount+2 > fillLimit){
                                    fillAddition = returnDataCount+2;
                                    [self gapFillUpdate];
                                }
                                
                                for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                    arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                    arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                }
                            }
                            else if (markerPoint [2][0] == 0) matchFlag = 2;
                            else{
                                
                                midEndXMap2 = markerPoint [1][0];
                                midEndYMap2 = markerPoint [1][1];
                                
                                gapFill = [[GapFill alloc] init];
                                chaseResult3 = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                
                                if (chaseResult3 == 1){
                                    if (numberOfFill+returnDataCount+2 > fillLimit){
                                        fillAddition = returnDataCount+2;
                                        [self gapFillUpdate];
                                    }
                                    
                                    for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                        arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                        arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                    }
                                    
                                    arrayGapDataTemp [numberOfFill] = midEndXMap2, numberOfFill++;
                                    arrayGapDataTemp [numberOfFill] = midEndYMap2, numberOfFill++;
                                    
                                    midStartXMap2 = midEndXMap2;
                                    midStartYMap2 = midEndYMap2;
                                    midEndXMap2 = markerPoint [2][0];
                                    midEndYMap2 = markerPoint [2][1];
                                    
                                    gapFill = [[GapFill alloc] init];
                                    chaseResult3 = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                    
                                    if (chaseResult3 == 1){
                                        if (numberOfFill+returnDataCount+2 > fillLimit){
                                            fillAddition = returnDataCount+2;
                                            [self gapFillUpdate];
                                        }
                                        
                                        for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                            arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                            arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                        }
                                    }
                                    else matchFlag = 2;
                                }
                                else matchFlag = 2;
                            }
                        }
                        if (matchFlag == 0){
                            midStartXMap2 = markerPoint [2][0];
                            midStartYMap2 = markerPoint [2][1];
                            
                            if (markerPoint [4][0] != -1){
                                midEndXMap2 = markerPoint [4][0];
                                midEndYMap2 = markerPoint [4][1];
                                
                                gapFill = [[GapFill alloc] init];
                                int chaseResult3 = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                
                                if (chaseResult3 == 1){
                                    if (numberOfFill+returnDataCount+2 > fillLimit){
                                        fillAddition = returnDataCount+2;
                                        [self gapFillUpdate];
                                    }
                                    
                                    for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                        arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                        arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                    }
                                    
                                    arrayGapDataTemp [numberOfFill] = midEndXMap2, numberOfFill++;
                                    arrayGapDataTemp [numberOfFill] = midEndYMap2, numberOfFill++;
                                    
                                    midStartXMap2 = midEndXMap2;
                                    midStartYMap2 = midEndYMap2;
                                    midEndXMap2 = destinationXMap2;
                                    midEndYMap2 = destinationYMap2;
                                    
                                    gapFill = [[GapFill alloc] init];
                                    chaseResult3 = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                    
                                    if (chaseResult3 == 1){
                                        if (numberOfFill+returnDataCount+2 > fillLimit){
                                            fillAddition = returnDataCount+2;
                                            [self gapFillUpdate];
                                        }
                                        
                                        for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                            arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                            arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                        }
                                    }
                                    else matchFlag = 2;
                                }
                                else if (markerPoint [3][0] == 0) matchFlag = 2;
                                else{
                                    
                                    midEndXMap2 = markerPoint [3][0];
                                    midEndYMap2 = markerPoint [3][1];
                                    
                                    gapFill = [[GapFill alloc] init];
                                    chaseResult3 = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                    
                                    if (chaseResult3 == 1){
                                        if (numberOfFill+returnDataCount+2 > fillLimit){
                                            fillAddition = returnDataCount+2;
                                            [self gapFillUpdate];
                                        }
                                        
                                        for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                            arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                            arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                        }
                                        
                                        arrayGapDataTemp [numberOfFill] = midEndXMap2, numberOfFill++;
                                        arrayGapDataTemp [numberOfFill] = midEndYMap2, numberOfFill++;
                                        
                                        midStartXMap2 = midEndXMap2;
                                        midStartYMap2 = midEndYMap2;
                                        midEndXMap2 = markerPoint [4][0];
                                        midEndYMap2 = markerPoint [4][1];
                                        
                                        gapFill = [[GapFill alloc] init];
                                        chaseResult3 = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                        
                                        if (chaseResult3 == 1){
                                            if (numberOfFill+returnDataCount+2 > fillLimit){
                                                fillAddition = returnDataCount+2;
                                                [self gapFillUpdate];
                                            }
                                            
                                            for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                                arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                                arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                            }
                                            
                                            arrayGapDataTemp [numberOfFill] = midEndXMap2, numberOfFill++;
                                            arrayGapDataTemp [numberOfFill] = midEndYMap2, numberOfFill++;
                                            
                                            midStartXMap2 = midEndXMap2;
                                            midStartYMap2 = midEndYMap2;
                                            midEndXMap2 = destinationXMap2;
                                            midEndYMap2 = destinationYMap2;
                                            
                                            gapFill = [[GapFill alloc] init];
                                            chaseResult3 = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                            
                                            if (chaseResult3 == 1){
                                                if (numberOfFill+returnDataCount+2 > fillLimit){
                                                    fillAddition = returnDataCount+2;
                                                    [self gapFillUpdate];
                                                }
                                                
                                                for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                                    arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                                    arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                                }
                                            }
                                            else matchFlag = 2;
                                        }
                                        else matchFlag = 2;
                                    }
                                    else matchFlag = 2;
                                }
                            }
                            if (markerPoint [4][0] == -1){
                                midEndXMap2 = destinationXMap2;
                                midEndYMap2 = destinationYMap2;
                                
                                gapFill = [[GapFill alloc] init];
                                int chaseResult3 = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                
                                if (chaseResult3 == 1){
                                    if (numberOfFill+returnDataCount+2 > fillLimit){
                                        fillAddition = returnDataCount+2;
                                        [self gapFillUpdate];
                                    }
                                    
                                    for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                        arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                        arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                    }
                                }
                                else if (markerPoint [2][0] == 0) matchFlag = 2;
                                else{
                                    
                                    midEndXMap2 = markerPoint [3][0];
                                    midEndYMap2 = markerPoint [3][1];
                                    
                                    gapFill = [[GapFill alloc] init];
                                    chaseResult3 = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                    
                                    if (chaseResult3 == 1){
                                        if (numberOfFill+returnDataCount+2 > fillLimit){
                                            fillAddition = returnDataCount+2;
                                            [self gapFillUpdate];
                                        }
                                        
                                        for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                            arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                            arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                        }
                                        
                                        arrayGapDataTemp [numberOfFill] = midEndXMap2, numberOfFill++;
                                        arrayGapDataTemp [numberOfFill] = midEndYMap2, numberOfFill++;
                                        
                                        midStartXMap2 = midEndXMap2;
                                        midStartYMap2 = midEndYMap2;
                                        midEndXMap2 = destinationXMap2;
                                        midEndYMap2 = destinationYMap2;
                                        
                                        gapFill = [[GapFill alloc] init];
                                        chaseResult3 = [gapFill gapChaseingMain:midStartXMap2:midStartYMap2:midEndXMap2:midEndYMap2:dimension:connectivityNumber];
                                        
                                        if (chaseResult3 == 1){
                                            if (numberOfFill+returnDataCount+2 > fillLimit){
                                                fillAddition = returnDataCount+2;
                                                [self gapFillUpdate];
                                            }
                                            
                                            for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                                                arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2], numberOfFill++;
                                                arrayGapDataTemp [numberOfFill] = arrayReturnData [counter1*2+1], numberOfFill++;
                                            }
                                        }
                                        else matchFlag = 2;
                                    }
                                    else matchFlag = 2;
                                }
                            }
                        }
                        if (matchFlag == 0) chaseResult2 = 1;
                    }
                }
                else matchFlag = 2;
                
                for (int counter1 = 0; counter1 < dimension+3; counter1++){
                    delete [] zeroTraceMap [counter1];
                    delete [] zeroTraceMapA [counter1];
                }
                
                delete [] zeroTraceMap;
                delete [] zeroTraceMapA;
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    delete [] zeroTraceMap2 [counter1];
                    delete [] zeroTraceMap3 [counter1];
                    delete [] twoHundredTraceMap [counter1];
                    delete [] twoHundredTraceMap2 [counter1];
                    delete [] twoHundredTraceMap3 [counter1];
                }
                
                delete [] zeroTraceMap2;
                delete [] zeroTraceMap3;
                delete [] twoHundredTraceMap;
                delete [] twoHundredTraceMap2;
                delete [] twoHundredTraceMap3;
                
                for (int counter1 = 0; counter1 < connectivityNumber2+2; counter1++) delete [] numberOfPointList [counter1];
                delete [] numberOfPointList;
                
                for (int counter1 = 0; counter1 < connectivityNumber3+2; counter1++) delete [] numberOfPointList2 [counter1];
                delete [] numberOfPointList2;
            }
            if (matchFlag == 0){
                if (chaseResult == 1 || chaseResult2 == 1 || zeroFindFlag == 2){
                    if (chaseResult == 1){
                        if (returnDataCount*2+500 > gapChaseLimit){
                            delete [] arrayGapChase;
                            arrayGapChase = new int [returnDataCount*2+500], gapChaseLimit = returnDataCount*2+500;
                        }
                        
                        gapChaseCount = 0;
                        
                        int pixValueValue = 0;
                        
                        for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                            if (arrayReturnData [counter1*2+1]+verticalStart >= 0 && arrayReturnData [counter1*2+1]+verticalStart < imageWidth && arrayReturnData [counter1*2]+horizontalStart >= 0 && arrayReturnData [counter1*2]+horizontalStart < imageWidth){
                                pixValueValue = arrayExtractedImage[arrayReturnData [counter1*2+1]+verticalStart][arrayReturnData [counter1*2]+horizontalStart];
                            }
                            else pixValueValue = 100;
                            
                            arrayGapChase [gapChaseCount] = arrayReturnData [counter1*2]+horizontalStart, gapChaseCount++;
                            arrayGapChase [gapChaseCount] = arrayReturnData [counter1*2+1]+verticalStart, gapChaseCount++;
                            arrayGapChase [gapChaseCount] = pixValueValue, gapChaseCount++;
                        }
                    }
                    if (chaseResult2 == 1){
                        if (numberOfFill*2+500 > gapChaseLimit){
                            delete [] arrayGapChase;
                            arrayGapChase = new int [numberOfFill*2+500], gapChaseLimit = numberOfFill*2+500;
                        }
                        
                        gapChaseCount = 0;
                        
                        int pixValueValue = 0;
                        
                        for (int counter1 = 0; counter1 < numberOfFill/2; counter1++){
                            if (arrayGapDataTemp [counter1*2+1]+verticalStart >= 0 && arrayGapDataTemp [counter1*2+1]+verticalStart < imageWidth && arrayGapDataTemp [counter1*2]+horizontalStart >= 0 && arrayGapDataTemp [counter1*2]+horizontalStart < imageWidth){
                                pixValueValue = arrayExtractedImage[arrayGapDataTemp [counter1*2+1]+verticalStart][arrayGapDataTemp [counter1*2]+horizontalStart];
                            }
                            else pixValueValue = 100;
                            
                            arrayGapChase [gapChaseCount] = arrayGapDataTemp [counter1*2]+horizontalStart, gapChaseCount++;
                            arrayGapChase [gapChaseCount] = arrayGapDataTemp [counter1*2+1]+verticalStart, gapChaseCount++;
                            arrayGapChase [gapChaseCount] = pixValueValue, gapChaseCount++;
                        }
                    }
                    if (zeroFindFlag == 2){
                        if (gapDataCount*2+500 > gapChaseLimit){
                            delete [] arrayGapChase;
                            arrayGapChase = new int [gapDataCount*2+500], gapChaseLimit = gapDataCount*2+500;
                        }
                        
                        gapChaseCount = 0;
                        
                        int pixValueValue = 0;
                        
                        for (int counter1 = 0; counter1 < gapDataCount/2; counter1++){
                            if (arrayGapData [counter1*2+1]+verticalStart >= 0 && arrayGapData [counter1*2+1]+verticalStart < imageWidth && arrayGapData [counter1*2]+horizontalStart >= 0 && arrayGapData [counter1*2]+horizontalStart < imageWidth){
                                pixValueValue = arrayExtractedImage[arrayGapData [counter1*2+1]+verticalStart][arrayGapData [counter1*2]+horizontalStart];
                            }
                            else pixValueValue = 100;
                            
                            arrayGapChase [gapChaseCount] = arrayGapData [counter1*2]+horizontalStart, gapChaseCount++;
                            arrayGapChase [gapChaseCount] = arrayGapData [counter1*2+1]+verticalStart, gapChaseCount++;
                            arrayGapChase [gapChaseCount] = pixValueValue, gapChaseCount++;
                        }
                    }
                }
                else matchFlag = 1;
            }
            
            if (matchFlag == 2){
                matchFlag = 0;
                
                if (gapChaseStatus == 2){
                    gapFill = [[GapFill alloc] init];
                    int chaseResult4 = [gapFill gapChaseingMain:originXMap:originYMap:destinationXMap2:destinationYMap2:dimension:connectivityNumber];
                    
                    if (chaseResult4 == 1){
                        if (returnDataCount*2+500 > gapChaseLimit){
                            delete [] arrayGapChase;
                            arrayGapChase = new int [returnDataCount*2+500], gapChaseLimit = returnDataCount*2+500;
                        }
                        
                        gapChaseCount = 0;
                        
                        int pixValueValue = 0;
                        
                        for (int counter1 = 0; counter1 < returnDataCount/2; counter1++){
                            if (arrayReturnData [counter1*2+1]+verticalStart >= 0 && arrayReturnData [counter1*2+1]+verticalStart < imageWidth && arrayReturnData [counter1*2]+horizontalStart >= 0 && arrayReturnData [counter1*2]+horizontalStart < imageWidth){
                                pixValueValue = arrayExtractedImage[arrayReturnData [counter1*2+1]+verticalStart][arrayReturnData [counter1*2]+horizontalStart];
                            }
                            else pixValueValue = 100;
                            
                            arrayGapChase [gapChaseCount] = arrayReturnData [counter1*2]+horizontalStart, gapChaseCount++;
                            arrayGapChase [gapChaseCount] = arrayReturnData [counter1*2+1]+verticalStart, gapChaseCount++;
                            arrayGapChase [gapChaseCount] = pixValueValue, gapChaseCount++;
                        }
                    }
                }
                else{
                    
                    gapFill = [[GapFill alloc] init];
                    [gapFill gapFilling:originXMap:originYMap:destinationXMap2:destinationYMap2];
                    
                    if (returnDataCount*2+500 > gapChaseLimit){
                        delete [] arrayGapChase;
                        arrayGapChase = new int [returnDataCount*2+500], gapChaseLimit = returnDataCount*2+500;
                    }
                    
                    gapChaseCount = 0;
                    
                    int pixValueValue = 0;
                    
                    for (int counter1 = 0; counter1 < gapDataCount/2; counter1++){
                        if (arrayGapData [counter1*2+1]+verticalStart >= 0 && arrayGapData [counter1*2+1]+verticalStart < imageWidth && arrayGapData [counter1*2]+horizontalStart >= 0 && arrayGapData [counter1*2]+horizontalStart < imageWidth){
                            pixValueValue = arrayExtractedImage[arrayGapData [counter1*2+1]+verticalStart][arrayGapData [counter1*2]+horizontalStart];
                        }
                        else pixValueValue = 100;
                        
                        arrayGapChase [gapChaseCount] = arrayGapData [counter1*2]+horizontalStart, gapChaseCount++;
                        arrayGapChase [gapChaseCount] = arrayGapData [counter1*2+1]+verticalStart, gapChaseCount++;
                        arrayGapChase [gapChaseCount] = pixValueValue, gapChaseCount++;
                    }
                }
            }
            
            delete [] arrayGapDataTemp;
        }
        else matchFlag = 1;
        
        delete [] connectAnalysisX;
        delete [] connectAnalysisY;
        delete [] connectAnalysisTempX;
        delete [] connectAnalysisTempY;
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++){
            delete [] gapFillMatrix [counter1];
            delete [] gapFillMatrix2 [counter1];
        }
        
        delete [] gapFillMatrix;
        delete [] gapFillMatrix2;
    }
    else matchFlag = 1;
    
    if (matchFlag == 1) gapChaseCount = 0;
    
    return matchFlag;
}

-(void)gapFillUpdate{
    int *arrayGapUpDate = new int [numberOfFill+10];
    for (int counter1 = 0; counter1 < numberOfFill; counter1++) arrayGapUpDate [counter1] = arrayGapDataTemp [counter1];
    
    delete [] arrayGapDataTemp;
    arrayGapDataTemp = new int [fillLimit+fillAddition+100];
    fillLimit = fillLimit+fillAddition+100;
    
    for (int counter1 = 0; counter1 < numberOfFill; counter1++) arrayGapDataTemp [counter1] = arrayGapUpDate [counter1];
    delete [] arrayGapUpDate;
}

@end
