//
//  TreatList.m
//  Cell_Outline_Draw
//
//  Created by Masahiko Sato on 11/22/16.
//
//

#import "TreatList.h"

NSString *notificationToTreatList = @"notificationExecuteTreatList";

@implementation TreatList

-(id)init{
    self = [super init];
    
    if (self != nil){
        treatListCallCount = 0;
        tableCurrentRowHold = 0;
        rowIndexHold = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToTreatList object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    treatListTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
    
    [treatListView setDataSource:self];
    [treatListView reloadData];
}

-(void)display{
    if (treatListCallCount == 1){
        treatListCallCount = 0;
        rowIndexHold = tableCurrentRowHold;
    }
    
    if (treatListCallCount > 1) treatListCallCount = 0;
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = treatmentSelectListCount/2;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    
    if (initialArraySet == 1){
        string displayData1 = "";
        string displayData2 = treatmentSelectList [rowIndex*2+1];
        
        if (treatmentSelectList [rowIndex*2] == "1") displayData1 = displayData1+"<";
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        [attributes setObject:[NSFont boldSystemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
            [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else{
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    treatListCallCount++;
    tableCurrentRowHold = rowIndex;
    
    if (treatListCallCount == 2){
        tableCurrentRowHold = rowIndexHold;
        
        if (treatmentSelectList [tableCurrentRowHold*2] == "0"){
            treatmentSelectList [tableCurrentRowHold*2] = "1";
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (treatmentSelectList [tableCurrentRowHold*2] != "0"){
            treatmentSelectList [tableCurrentRowHold*2] = "0";
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        
        [treatListView reloadData];
    }
    else{
        
        tableCurrentRowHold = rowIndex;
        
        if (treatmentSelectList [tableCurrentRowHold*2] == "0"){
            treatmentSelectList [tableCurrentRowHold*2] = "1";
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (treatmentSelectList [tableCurrentRowHold*2] != "0"){
            treatmentSelectList [tableCurrentRowHold*2] = "0";
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        
        [treatListView reloadData];
    }
    
    return YES;
}

-(void)dealloc{
    if (treatListTimer) [treatListTimer invalidate];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToTreatList object:nil];
}

@end
