//
// VectorAnalysis.h
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 11/11/09.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#ifndef VECTORANALYSIS_H
#define VECTORANALYSIS_H
#import "Controller.h"
#endif

@interface VectorAnalysis : NSObject {
}

-(void)vectorAngle:(int)arrayNumber;

@end
