//
// arrayModification.h
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 03/12/12.
// Copyright 2012 Masahiko Sato. All rights reserved.
//

#ifndef ARRAYMODIFICATION_H
#define ARRAYMODIFICATION_H
#import "Controller.h"
#endif

@interface ArrayModification : NSObject {
}

-(void)lineFlip:(int)lineSet;
-(void)lineLengthTwoRemove:(int)lineSet;

@end
