//
// VectorSegmentation.mm
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 11/10/04.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#import "VectorSegmentation.h"

@implementation VectorSegmentation

-(void)vectorReconstraction{
    int vectorNumber = 0;
    int arrayCount = 0;
    
    if (outlineVectorSegmentCount != 0){
        vectorNumber = arrayOutlineVectorSegment [0];
        arrayCount = outlineVectorSegmentCount;
    }
    
    if (arrayCount != 0){
        int *arrayVectorSegmentationTemp = new int [outlineVectorSegmentCount+5000], vectorSegmentationTempCount = 0;
        int *arrayVectorSegmentationTemp2 = new int [outlineVectorSegmentCount*3+5000], vectorSegmentationTempCount2 = 0;
        int *arrayVectorSegmentationTemp3 = new int [outlineVectorSegmentCount*3+5000], vectorSegmentationTempCount3 = 0;
        
        int counterTemp = 0;
        int startX = 0;
        int startY = 0;
        int endX = 0;
        int endY = 0;
        int endX2 = 0;
        int endY2 = 0;
        int caseType = 0;
        int countStart = 0;
        int countEnd = 0;
        int countEndSecondFlag = 0;
        int processLine = 0;
        int maxHitPoint = 0;
        int startLocation = 0;
        int endLocation = 0;
        int countStart2 = 0;
        int countEnd2 = 0;
        int countEndSecondFlag2 = 0;
        int startFind = 0;
        int endFind = 0;
        int startLocal = 0;
        int endLocal = 0;
        int defMap = 0;
        int startX2 = 0;
        int startY2 = 0;
        int endX2Position = 0;
        int endXY2Position = 0;
        int endX3 = 0;
        int endY3 = 0;
        int totalPointCount = 0;
        int zeroAppearedPosition = 0;
        int terminationFlag = 0;
        int noZeroFlag = 0;
        int countStart1 = 0;
        int countEnd1 = 0;
        int countEndFirstFlag = 0;
        int countStart2Temp1 = 0;
        int countStart2Temp2 = 0;
        int gapStart = 0;
        int gapEnd = 0;
        int gapFlag = 0;
        int contStart = 0;
        int contEnd = 0;
        int contFlag = 0;
        int startReset = 0;
        int endReset = 0;
        int completionFlag = 0;
        int continueFlag = 0;
        int totalDeletion = 0;
        int interruptionTemp = 0;
        int firstCont = 0;
        int gapFirst = 0;
        int coreStart = 0;
        int firstCont2 = 0;
        int gapFirst2 = 0;
        int processON = 0;
        int startSubject = 0;
        int startRef2 = 0;
        int defTempMap = 0;
        int noMatchFlag = 0;
        int caseType2 = 0;
        int firstAppear2 = 0;
        int lastAppear3 = 0;
        int endSubject = 0;
        int first2 = 0;
        int second2 = 0;
        int veryFirst2 = 0;
        int veryFirst2Flag = 0;
        int firstLineEnd = 0;
        int secondLineStart = 0;
        int adjustedContactPoint = 0;
        int first2Flag = 0;
        int startXAd = 0;
        int startYAd = 0;
        int endXAd = 0;
        int endYAd = 0;
        int distanceOverCount = 0;
        int crossXMax = 0;
        int crossYMax = 0;
        int startEndFlag = 0;
        int valueXRefAd = 0;
        int valueYRefAd = 0;
        int crossX = 0;
        int crossY = 0;
        int firstSortEndX = 0;
        int firstSortEndY = 0;
        int vectorHoldTempCount = 0;
        int vectorHoldTempCount2 = 0;
        int counterMax = 0;
        int interruptSet = 0;
        int lineInformationCount = 0;
        int onePointUp = 0;
        int onePointDown = 0;
        
        double firstAngle = 0;
        double length = 0;
        double angle = 0;
        double cutOff1 = 0;
        double cutOff2 = 0;
        double cutOff3 = 0;
        double angleWrite = 0;
        double firstLength = 0;
        double lengthRef = 0;
        double lengthRef2 = 0;
        double lengthRef3 = 0;
        double angleWrite2 = 0;
        double angleWrite3 = 0;
        double angleTemp = 0;
        double angleOV = 0;
        double angleRef = 0;
        double cutOffA = 0;
        double cutOffB = 0;
        double cutOffC = 0;
        double distanceMax = 0;
        double constA = 0;
        double constB = 0;
        double distance = 0;
        double constC = 0;
        double angle2 = 0;
        
        for (int counter1 = 0; counter1 < arrayCount+3; counter1 = counter1+3){
            if (counter1 < arrayCount) counterTemp = arrayOutlineVectorSegment [counter1];
            else counterTemp = -1;
            
            //------Array structure Point1, Point2, ---- Point End, Point 1------
            if (vectorNumber == counterTemp && counterTemp != -1){
                arrayVectorSegmentationTemp [vectorSegmentationTempCount] = arrayOutlineVectorSegment [counter1+1], vectorSegmentationTempCount++;
                arrayVectorSegmentationTemp [vectorSegmentationTempCount] = arrayOutlineVectorSegment [counter1+2], vectorSegmentationTempCount++;
            }
            else{
                
                if (vectorSegmentationTempCount == 6){ //------Number of Point = 2, 2x2 points + 2 = 6------
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = vectorNumber, vectorSegmentationTempCount2++;
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [0], vectorSegmentationTempCount2++;
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [1], vectorSegmentationTempCount2++;
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [2], vectorSegmentationTempCount2++;
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [3], vectorSegmentationTempCount2++;
                    
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = vectorNumber, vectorSegmentationTempCount2++;
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [2], vectorSegmentationTempCount2++;
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [3], vectorSegmentationTempCount2++;
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [4], vectorSegmentationTempCount2++;
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [5], vectorSegmentationTempCount2++;
                    
                    vectorSegmentationTempCount = 0;
                }
                
                //------Number of Point = 3------
                if (vectorSegmentationTempCount == 8){
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = vectorNumber, vectorSegmentationTempCount2++;
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [0], vectorSegmentationTempCount2++;
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [1], vectorSegmentationTempCount2++;
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [2], vectorSegmentationTempCount2++;
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [3], vectorSegmentationTempCount2++;
                    
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = vectorNumber, vectorSegmentationTempCount2++;
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [2], vectorSegmentationTempCount2++;
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [3], vectorSegmentationTempCount2++;
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [4], vectorSegmentationTempCount2++;
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [5], vectorSegmentationTempCount2++;
                    
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = vectorNumber, vectorSegmentationTempCount2++;
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [4], vectorSegmentationTempCount2++;
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [5], vectorSegmentationTempCount2++;
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [6], vectorSegmentationTempCount2++;
                    arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [7], vectorSegmentationTempCount2++;
                    
                    vectorSegmentationTempCount = 0;
                }
                
                //------Number of Point = 4-9------
                if (vectorSegmentationTempCount >= 10 && vectorSegmentationTempCount <= 20){
                    double **angleMap = new double *[vectorSegmentationTempCount+4];
                    int **startMap = new int *[vectorSegmentationTempCount+4];
                    int **endMap = new int *[vectorSegmentationTempCount+4];
                    int **totalMap = new int *[vectorSegmentationTempCount+4];
                    
                    for (int counter2 = 0; counter2 < vectorSegmentationTempCount+4; counter2++){
                        angleMap [counter2] = new double [vectorSegmentationTempCount+4];
                        startMap [counter2] = new int [vectorSegmentationTempCount+4];
                        endMap [counter2] = new int [vectorSegmentationTempCount+4];
                        totalMap [counter2] = new int [vectorSegmentationTempCount+4];
                    }
                    
                    for (int counter2 = 0; counter2 < (vectorSegmentationTempCount-2)/2; counter2++){
                        for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-2)/2; counter3++){
                            angleMap [counter2][counter3] = 300;
                            startMap [counter2][counter3] = 0;
                            endMap [counter2][counter3] = 0;
                            totalMap [counter2][counter3] = 0;
                        }
                    }
                    
                    firstAngle = 0;
                    angle = 0;
                    cutOff1 = 0;
                    cutOff2 = 0;
                    cutOff3 = 0;
                    caseType = 0;
                    
                    for (int counter2 = 0; counter2 < (vectorSegmentationTempCount-2)/2; counter2++){
                        //------totalMap, start point = 2------
                        angleMap [counter2][counter2] = 2;
                        totalMap [counter2][counter2] = 2;
                        startMap [counter2][counter2] = 1;
                        
                        if (counter2+1 < (vectorSegmentationTempCount-2)/2){
                            angleMap [counter2][counter2+1] = 1;
                            totalMap [counter2][counter2+1] = 1;
                        }
                        else{
                            
                            angleMap [counter2][0] = 1;
                            totalMap [counter2][0] = 1;
                        }
                        
                        //------Add one set of point to the end, Point 1, Point 2, --- Point End, Point 1, Point 2------
                        startX = arrayVectorSegmentationTemp [counter2*2];
                        startY = arrayVectorSegmentationTemp [counter2*2+1];
                        endX = arrayVectorSegmentationTemp [(counter2+1)*2];
                        endY = arrayVectorSegmentationTemp [(counter2+1)*2+1];
                        firstLength = sqrt(pow((endX-startX), 2)+pow((endY-startY), 2)); //------Angle determination, based on two Position------
                        
                        if (endX-startX == 0 && endY-startY > 0) firstAngle = 90;
                        else if (endX-startX == 0 && endY-startY < 0) firstAngle = -90;
                        else if (endY-startY == 0 && endX-startX > 0) firstAngle = 0;
                        else if (endY-startY == 0 && endX-startX < 0) firstAngle = 180;
                        else if (endX-startX != 0){
                            firstAngle = (atan(abs(endY-startY)/(double)abs(endX-startX)))*180/3.14;
                            
                            if (endX-startX > 0 && endY-startY < 0) firstAngle = firstAngle*-1;
                            else if (endX-startX < 0 && endY-startY > 0) firstAngle = 180-firstAngle;
                            else if (endX-startX < 0 && endY-startY < 0) firstAngle = (180-firstAngle)*-1;
                        }
                        
                        angleWrite = firstAngle;
                        
                        //------Extend point to point, Point 1-Point 2 >> Point 3, Point 4.... Forward extension------
                        for (int counter3 = counter2+2; counter3 < vectorSegmentationTempCount/2; counter3++){
                            endX2 = arrayVectorSegmentationTemp [counter3*2];
                            endY2 = arrayVectorSegmentationTemp [counter3*2+1];
                            length = sqrt(pow((endX2-startX), 2)+pow((endY2-startY), 2));
                            
                            if (endX2-startX == 0 && endY2-startY > 0) angle = 90;
                            else if (endX2-startX == 0 && endY2-startY < 0) angle = -90;
                            else if (endY2-startY == 0 && endX2-startX > 0) angle = 0;
                            else if (endY2-startY == 0 && endX2-startX < 0) angle = 180;
                            else if (endY2-startY != 0){
                                angle = (atan(abs(endY2-startY)/(double)abs(endX2-startX)))*180/3.14;
                                
                                if (endX2-startX > 0 && endY2-startY < 0) angle = angle*-1;
                                else if (endX2-startX < 0 && endY2-startY > 0) angle = 180-angle;
                                else if (endX2-startX < 0 && endY2-startY < 0) angle = (180-angle)*-1;
                            }
                            
                            if (length > firstLength){
                                if (firstAngle < 160 && firstAngle > -160){
                                    cutOff1 = firstAngle-10;
                                    cutOff2 = firstAngle+10;
                                    cutOff3 = 0;
                                    caseType = 1;
                                }
                                else if (firstAngle >= 160){
                                    cutOff1 = firstAngle-10;
                                    cutOff2 = 180;
                                    cutOff3 = (180-(firstAngle+10-180))*-1;
                                    caseType = 2;
                                }
                                else if (firstAngle <= -160){
                                    cutOff1 = 180-(((firstAngle-10)+180)*-1);
                                    cutOff2 = 180;
                                    cutOff3 = firstAngle+10;
                                    caseType = 2;
                                }
                                else if (firstAngle == 180){
                                    cutOff1 = 160;
                                    cutOff2 = 180;
                                    cutOff3 = -160;
                                    caseType = 2;
                                }
                                
                                if ((angle >= cutOff1 && angle <= cutOff2 && caseType == 1) || (((angle >= cutOff1 && angle <= cutOff2) || (angle > cutOff2*-1 && angle <= cutOff3)) && caseType == 2)){
                                    //------If angle is within +- 10 degree, mark 1 to total and angle Map------
                                    if (counter3 == vectorSegmentationTempCount/2-1){
                                        angleMap [counter2][0] = 1;
                                        totalMap [counter2][0] = 1;
                                    }
                                    else{
                                        
                                        angleMap [counter2][counter3] = 1;
                                        totalMap [counter2][counter3] = 1;
                                    }
                                    
                                    angleWrite = angle;
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < defMap; counterA++){
                        //    for (int counterB = 0; counterB < defMap; counterB++) cout<<" "<<totalMap [counterA][counterB];
                        //    cout<<" totalMap "<<counterA<<endl;
                        //}
                        
                        //------Extend point to point, Point 1-Point 2 >> Point -1, Point -1.... Reverse extension------
                        for (int counter3 = counter2-1; counter3 >= 1; counter3 = counter3-1){
                            endX2 = arrayVectorSegmentationTemp [counter3*2];
                            endY2 = arrayVectorSegmentationTemp [counter3*2+1];
                            length = sqrt(pow((endX2-startX), 2)+pow((endY2-startY), 2));
                            
                            if (endX2-startX == 0 && endY2-startY > 0) angle = 90;
                            else if (endX2-startX == 0 && endY2-startY < 0) angle = -90;
                            else if (endY2-startY == 0 && endX2-startX > 0) angle = 0;
                            else if (endY2-startY == 0 && endX2-startX < 0) angle = 180;
                            else if (endY2-startY != 0){
                                angle = (atan(abs(endY2-startY)/(double)abs(endX2-startX)))*180/3.14;
                                
                                if (endX2-startX > 0 && endY2-startY < 0) angle = angle*-1;
                                else if (endX2-startX < 0 && endY2-startY > 0) angle = 180-angle;
                                else if (endX2-startX < 0 && endY2-startY < 0) angle = (180-angle)*-1;
                            }
                            
                            if (length > firstLength){
                                if (firstAngle < 160 && firstAngle > -160){
                                    cutOff1 = firstAngle-10;
                                    cutOff2 = firstAngle+10;
                                    cutOff3 = 0;
                                    caseType = 1;
                                }
                                else if (firstAngle >= 160){
                                    cutOff1 = firstAngle-0;
                                    cutOff2 = 180;
                                    cutOff3 = (180-(firstAngle+10-180))*-1;
                                    caseType = 2;
                                }
                                else if (firstAngle <= -160){
                                    cutOff1 = 180-(((firstAngle-10)+180)*-1);
                                    cutOff2 = 180;
                                    cutOff3 = firstAngle+10;
                                    caseType = 2;
                                }
                                else if (firstAngle == 180){
                                    cutOff1 = 160;
                                    cutOff2 = 180;
                                    cutOff3 = -160;
                                    caseType = 2;
                                }
                                
                                if ((angle >= cutOff1 && angle <= cutOff2 && caseType == 1) || (((angle >= cutOff1 && angle <= cutOff2) || (angle > cutOff2*-1 && angle <= cutOff3)) && caseType == 2)){
                                    angleMap [counter2][counter3] = 1;
                                    totalMap [counter2][counter3] = 1;
                                    angleWrite = angle;
                                }
                            }
                        }
                        
                        //------Write angle data into angleMap------
                        for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-2)/2; counter3++){
                            if (angleMap [counter2][counter3] != 300) angleMap [counter2][counter3] = angleWrite;
                        }
                    }
                    
                    //------Mapping position initialize, store start, end and length------
                    int **mappingPosition = new int *[(vectorSegmentationTempCount-2)/2+50];
                    for (int counter2 = 0; counter2 < (vectorSegmentationTempCount-2)/2; counter2++) mappingPosition [counter2] = new int [4];
                    
                    for (int counter2 = 0; counter2 < (vectorSegmentationTempCount-2)/2; counter2++){
                        for (int counter3 = 0; counter3 < 3; counter3++) mappingPosition [counter2][counter3] = -1;
                    }
                    
                    //------End point find, end point writing, length determination------
                    for (int counter2 = 0; counter2 < (vectorSegmentationTempCount-2)/2; counter2++){
                        countStart = -1;
                        countEnd = -1;
                        countEndSecondFlag = 0;
                        
                        for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-2)/2; counter3++){
                            if (totalMap [counter2][counter3] == 2) countStart = counter3;
                            else if (countStart != -1 && countEndSecondFlag == 0){
                                if (totalMap [counter2][counter3] != 0) countEnd = counter3;
                            }
                            else if (countStart == -1){
                                if (totalMap [counter2][counter3] != 0){
                                    countEnd = counter3;
                                    countEndSecondFlag = 1;
                                }
                            }
                        }
                        
                        totalMap [counter2][countEnd] = 3;
                        endMap [counter2][countEnd] = 1;
                        mappingPosition [counter2][0] = countStart;
                        mappingPosition [counter2][1] = countEnd;
                        
                        if (countStart == -1 || countEnd == -1){
                            for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-2)/2; counter3++) totalMap [counter2][counter3] = 0;
                            
                            mappingPosition [counter2][0] = -1;
                            mappingPosition [counter2][1] = -1;
                            mappingPosition [counter2][2] = -1;
                        }
                        else if (countStart < countEnd) mappingPosition [counter2][2] = countEnd-countStart;
                        else mappingPosition [counter2][2] = (vectorSegmentationTempCount-2)/2-countStart+countEnd;
                    }
                    
                    //for (int counterA = 0; counterA < (vectorSegmentationTempCount-2)/2; counterA++){
                    //	for (int counterB = 0; counterB < 21; counterB++) cout<<" "<<angleMap [counterA][counterB];
                    //	cout<<" angleMap "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < (vectorSegmentationTempCount-2)/2; counterA++){
                    //	for (int counterB = 0; counterB < 21; counterB++) cout<<" "<<totalMap [counterA][counterB];
                    //	cout<<" angleMap "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < defPoint; counterA++){
                    //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<mappingPosition [counterA][counterB];
                    //	cout<<" mappingPosition "<<counterA<<endl;
                    //}
                    
                    //------Data processing------
                    int *arrayLineInformation = new int [outlineVectorSegmentCount*2+5000];
                    lineInformationCount = 0;
                    
                    do{
                        
                        processLine = -1;
                        maxHitPoint = 0;
                        
                        //------Longest line find, if processLine == -1, get out from the loop------
                        for (int counter2 = 0; counter2 < (vectorSegmentationTempCount-2)/2; counter2++){
                            if (maxHitPoint < mappingPosition [counter2][2]){
                                maxHitPoint = mappingPosition [counter2][2];
                                processLine = counter2;
                            }
                        }
                        
                        //------If length = 1 (2 points), go for maxHitPoint == 1------
                        
                        //for (int counterA = 0; counterA < defPoint; counterA++){
                        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<mappingPosition [counterA][counterB];
                        //    cout<<" mappingPosition "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < defMap; counterA++){
                        //    for (int counterB = 0; counterB < defMap; counterB++) cout<<" "<<totalMap [counterA][counterB];
                        //    cout<<" totalMap "<<counterA<<endl;
                        //}
                        
                        if (maxHitPoint == 1){
                            startLocation = mappingPosition [processLine][0];
                            endLocation = mappingPosition [processLine][1];
                            
                            arrayLineInformation [lineInformationCount] = arrayVectorSegmentationTemp [startLocation*2], lineInformationCount++;
                            arrayLineInformation [lineInformationCount] = arrayVectorSegmentationTemp [startLocation*2+1], lineInformationCount++;
                            arrayLineInformation [lineInformationCount] = arrayVectorSegmentationTemp [endLocation*2], lineInformationCount++;
                            arrayLineInformation [lineInformationCount] = arrayVectorSegmentationTemp [endLocation*2+1], lineInformationCount++;
                            
                            mappingPosition [processLine][0] = -1;
                            mappingPosition [processLine][1] = -1;
                            mappingPosition [processLine][2] = -1;
                            
                            //for (int counterA = 0; counterA < defPoint; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<mappingPosition [counterA][counterB];
                            //    cout<<" mappingPosition "<<counterA<<endl;
                            //}
                            
                            angleMap [processLine][startLocation] = 300;
                            angleMap [processLine][endLocation] = 300;
                            totalMap [processLine][startLocation] = 0;
                            totalMap [processLine][endLocation] = 0;
                            startMap [processLine][startLocation] = 0;
                            endMap [processLine][endLocation] = 0;
                        }
                        else if (maxHitPoint >= 2){ //------If length > 2 (3 points), go for maxHitPoint == 2------
                            //------Compare angle of process line with ones of others, if angle is over +- 10, remove point from process line (except starting point)------
                            
                            for (int counter2 = 0; counter2 < (vectorSegmentationTempCount-2)/2; counter2++){
                                if (totalMap [processLine][counter2] == 1 || totalMap [processLine][counter2] == 3){
                                    for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-2)/2; counter3++){
                                        if (counter2 != counter3){
                                            if (angleMap [counter3][counter2] != 300){
                                                if (angleMap [counter3][counter2] <= angleMap [processLine][counter2]-10 || angleMap [counter3][counter2] >= angleMap [processLine][counter2]+10){
                                                    totalMap [processLine][counter3] = 0;
                                                    angleMap [processLine][counter3] = 300;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < defMap; counterA++){
                            //	for (int counterB = 0; counterB < defMap; counterB++) cout<<" "<<totalMap [counterA][counterB];
                            //	cout<<" totalMap "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < defPoint; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<mappingPosition [counterA][counterB];
                            //    cout<<" mappingPosition "<<counterA<<endl;
                            //}
                            
                            //------Start point of Process line determination------
                            countStart2 = -1;
                            
                            for (int counter2 = 0; counter2 < (vectorSegmentationTempCount-2)/2; counter2++){
                                if (totalMap [processLine][counter2] == 2) countStart2 = counter2;
                            }
                            
                            //------End point of Process line determination------
                            countEnd2 = -1;
                            countEndSecondFlag2 = 0;
                            
                            if (countStart2+1 != (vectorSegmentationTempCount-2)/2-1){
                                for (int counter2 = countStart2+1; counter2 < (vectorSegmentationTempCount-2)/2; counter2++){
                                    if (totalMap [processLine][counter2] != 0 && countEndSecondFlag2 == 0){
                                        countEnd2 = counter2;
                                        totalMap [processLine][counter2] = 1;
                                        endMap [processLine][counter2] = 0;
                                    }
                                    
                                    if (totalMap [processLine][counter2] == 0 && counter2-1 == countStart2 && countEndSecondFlag2 == 0){
                                        countEnd2 = counter2;
                                        totalMap [processLine][counter2] = 3;
                                        endMap [processLine][counter2] = 1;
                                        countEndSecondFlag2 = 1;
                                    }
                                    
                                    if (totalMap [processLine][counter2] == 0 && counter2-1 != countStart2 && countEndSecondFlag2 == 0){
                                        countEnd2 = counter2-1;
                                        totalMap [processLine][counter2-1] = 3;
                                        endMap [processLine][counter2-1] = 1;
                                        countEndSecondFlag2 = 1;
                                    }
                                    
                                    if (countEndSecondFlag2 == 1){
                                        totalMap [processLine][counter2] = 0;
                                        endMap [processLine][counter2] = 0;
                                        countEndSecondFlag2 = 1;
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < defPoint; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<mappingPosition [counterA][counterB];
                            //    cout<<" mappingPosition "<<counterA<<endl;
                            //}
                            
                            if (countStart2 >= 0){
                                for (int counter2 = 0; counter2 < countStart2-1; counter2++){
                                    if (totalMap [processLine][counter2] != 0 && countEndSecondFlag2 == 0){
                                        countEnd2 = counter2;
                                        totalMap [processLine][counter2] = 1;
                                        endMap [processLine][counter2] = 0;
                                    }
                                    
                                    if (totalMap [processLine][counter2] == 0 && counter2-1 == countStart2 && counter2-1 != -1 && countEndSecondFlag2 == 0){
                                        countEnd2 = counter2;
                                        totalMap [processLine][counter2] = 3;
                                        endMap [processLine][counter2] = 1;
                                        countEndSecondFlag2 = 1;
                                    }
                                    
                                    if (totalMap [processLine][counter2] == 0 && (vectorSegmentationTempCount-2)/2-1 == countStart2 && counter2-1 == -1 && countEndSecondFlag2 == 0){
                                        countEnd2 = 0;
                                        totalMap [processLine][0] = 3;
                                        endMap [processLine][0] = 1;
                                        countEndSecondFlag2 = 1;
                                    }
                                    
                                    if (totalMap [processLine][counter2] == 0 && counter2-1 != countStart2 && counter2-1 != -1 && countEndSecondFlag2 == 0){
                                        countEnd2 = counter2-1;
                                        totalMap [processLine][counter2-1] = 3;
                                        endMap [processLine][counter2-1] = 1;
                                        countEndSecondFlag2 = 1;
                                    }
                                    
                                    if (totalMap [processLine][counter2] == 0 && counter2-1 != countStart2 && counter2-1 == -1 && countEndSecondFlag2 == 0){
                                        countEnd2 = (vectorSegmentationTempCount-2)/2-1;
                                        totalMap [processLine][(vectorSegmentationTempCount-2)/2-1] = 3;
                                        endMap [processLine][(vectorSegmentationTempCount-2)/2-1] = 1;
                                        countEndSecondFlag2 = 1;
                                    }
                                    
                                    if (countEndSecondFlag2 == 1){
                                        totalMap [processLine][counter2] = 0;
                                        endMap [processLine][counter2] = 0;
                                        countEndSecondFlag2 = 1;
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < defMap; counterA++){
                            //	for (int counterB = 0; counterB < defMap; counterB++) cout<<" "<<totalMap [counterA][counterB];
                            //	cout<<" totalMap "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < defPoint; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<mappingPosition [counterA][counterB];
                            //    cout<<" mappingPosition "<<counterA<<endl;
                            //}
                            
                            //------Data writing------
                            totalMap [processLine][countEnd2] = 3;
                            endMap [processLine][countEnd2] = 1;
                            mappingPosition [processLine][0] = countStart2;
                            mappingPosition [processLine][1] = countEnd2;
                            
                            if (countStart2 == -1 || countEnd2 == -1){
                                for (int counter2 = 0; counter2 < (vectorSegmentationTempCount-2)/2; counter2++) totalMap [processLine][counter2] = 0;
                                
                                mappingPosition [processLine][0] = -1;
                                mappingPosition [processLine][1] = -1;
                                mappingPosition [processLine][2] = -1;
                            }
                            else if (countStart2 < countEnd2) mappingPosition [processLine][2] = countEnd2-countStart2;
                            else mappingPosition [processLine][2] = (vectorSegmentationTempCount-2)/2-countStart2+countEnd2;
                            
                            //for (int counterA = 0; counterA < defPoint; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<mappingPosition [counterA][counterB];
                            //    cout<<" mappingPosition "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < defMap; counterA++){
                            //	for (int counterB = 0; counterB < defMap; counterB++) cout<<" "<<totalMap [counterA][counterB];
                            //	cout<<" totalMap "<<counterA<<endl;
                            //}
                            
                            //------If length of Process line become 1 (2 points), skip following steps and back to the beginning------
                            if (mappingPosition [processLine][2] > 1){
                                startLocation = mappingPosition [processLine][0];
                                endLocation = mappingPosition [processLine][1];
                                
                                //------Store Process line data into arrayLineInformation------
                                arrayLineInformation [lineInformationCount] = arrayVectorSegmentationTemp [startLocation*2];
                                arrayLineInformation [lineInformationCount] = arrayVectorSegmentationTemp [startLocation*2+1];
                                arrayLineInformation [lineInformationCount] = arrayVectorSegmentationTemp [endLocation*2];
                                arrayLineInformation [lineInformationCount] = arrayVectorSegmentationTemp [endLocation*2+1];
                                
                                //------Readjust overlapped point of remaining lines, add 4 into totalMap of process line------
                                if (startLocation < endLocation){
                                    for (int counter2 = startLocation; counter2 <= endLocation; counter2++) totalMap [processLine][counter2] = 4;
                                }
                                else{
                                    
                                    for (int counter2 = startLocation; counter2 < (vectorSegmentationTempCount-2)/2; counter2++) totalMap [processLine][counter2] = 4;
                                    for (int counter2 = 0; counter2 <= endLocation; counter2++) totalMap [processLine][counter2] = 4;
                                }
                                
                                //------Overlapped point processing------
                                for (int counter2 = 0; counter2 < (vectorSegmentationTempCount-2)/2; counter2++){
                                    if (counter2 != processLine){
                                        
                                        //------Overlapped points removal------
                                        for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-2)/2; counter3++){
                                            if (totalMap [counter2][counter3] == 2){
                                                if (totalMap [processLine][counter3] == 4){
                                                    if (startMap [processLine][counter3] == 1 || endMap [processLine][counter3] == 0) totalMap [counter2][counter3] = 0;
                                                }
                                            }
                                            
                                            if (totalMap [counter2][counter3] == 1){
                                                if (totalMap [processLine][counter3] == 4) totalMap [counter2][counter3] = 0;
                                            }
                                            
                                            if (totalMap [counter2][counter3] == 3){
                                                if (totalMap [processLine][counter3] == 4){
                                                    if (endMap [processLine][counter3] == 1 || startMap [processLine][counter3] == 0) totalMap [counter2][counter3] = 0;
                                                }
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < defPoint; counterA++){
                                        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<mappingPosition [counterA][counterB];
                                        //    cout<<" mappingPosition "<<counterA<<endl;
                                        //}
                                        
                                        //for (int counterA = 0; counterA < defMap; counterA++){
                                        //    for (int counterB = 0; counterB < defMap; counterB++) cout<<" "<<totalMap [counterA][counterB];
                                        //    cout<<" totalMap "<<counterA<<endl;
                                        //}
                                        
                                        //------Find start and end points------
                                        startFind = 0;
                                        endFind = 0;
                                        
                                        for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-2)/2; counter3++){
                                            if (totalMap [counter2][counter3] == 2) startFind = 1;
                                            
                                            if (totalMap [counter2][counter3] == 3) endFind = 1;
                                        }
                                        
                                        //------If No end is find, create end point------
                                        if (startFind == 1 && endFind == 0){
                                            totalMap [counter2][startLocation] = 3;
                                            startLocal = -1;
                                            endLocal = -1;
                                            
                                            for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-2)/2; counter3++){
                                                if (totalMap [counter2][counter3] == 2) startLocal = counter3;
                                                
                                                if (totalMap [counter2][counter3] == 3) endLocal = counter3;
                                            }
                                            
                                            if (startLocal < endLocal){
                                                for (int counter3 = 0; counter3 < startLocal; counter3++){
                                                    angleMap [counter2][counter3] = 300;
                                                    totalMap [counter2][counter3] = 0;
                                                    startMap [counter2][counter3] = 0;
                                                    endMap [counter2][counter3] = 0;
                                                }
                                                
                                                for (int counter3 = endLocal+1; counter3 < (vectorSegmentationTempCount-2)/2; counter3++){
                                                    angleMap [counter2][counter3] = 300;
                                                    totalMap [counter2][counter3] = 0;
                                                    startMap [counter2][counter3] = 0;
                                                    endMap [counter2][counter3] = 0;
                                                }
                                            }
                                            
                                            if (startLocal > endLocal){
                                                for (int counter3 = endLocal+1; counter3 < startLocal; counter3++){
                                                    angleMap [counter2][counter3] = 300;
                                                    totalMap [counter2][counter3] = 0;
                                                    startMap [counter2][counter3] = 0;
                                                    endMap [counter2][counter3] = 0;
                                                }
                                            }
                                            
                                            mappingPosition [counter2][0] = startLocal;
                                            mappingPosition [counter2][1] = endLocal;
                                            
                                            if (startLocal == -1 || endLocal == -1){
                                                for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-2)/2; counter3++) totalMap [counter2][counter3] = 0;
                                                
                                                mappingPosition [counter2][0] = -1;
                                                mappingPosition [counter2][1] = -1;
                                                mappingPosition [counter2][2] = -1;
                                            }
                                            else if (startLocal < endLocal) mappingPosition [counter2][2] = endLocal-startLocal;
                                            else mappingPosition [counter2][2] = (vectorSegmentationTempCount-2)/2-startLocal+endLocal;
                                            
                                            //for (int counterA = 0; counterA < defPoint; counterA++){
                                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<mappingPosition [counterA][counterB];
                                            //    cout<<" mappingPosition "<<counterA<<endl;
                                            //}
                                        }
                                        
                                        //------If No Start is find, create start point------
                                        if (startFind == 0 && endFind == 1){
                                            totalMap [counter2][endLocation] = 2;
                                            startLocal = -1;
                                            endLocal = -1;
                                            
                                            for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-2)/2; counter3++){
                                                if (totalMap [counter2][counter3] == 2) startLocal = counter3;
                                                if (totalMap [counter2][counter3] == 3) endLocal = counter3;
                                            }
                                            
                                            if (startLocal < endLocal){
                                                for (int counter3 = 0; counter3 < startLocal; counter3++){
                                                    angleMap [counter2][counter3] = 300;
                                                    totalMap [counter2][counter3] = 0;
                                                    startMap [counter2][counter3] = 0;
                                                    endMap [counter2][counter3] = 0;
                                                }
                                                
                                                for (int counter3 = endLocal+1; counter3 < (vectorSegmentationTempCount-2)/2; counter3++){
                                                    angleMap [counter2][counter3] = 300;
                                                    totalMap [counter2][counter3] = 0;
                                                    startMap [counter2][counter3] = 0;
                                                    endMap [counter2][counter3] = 0;
                                                }
                                            }
                                            
                                            if (startLocal > endLocal){
                                                for (int counter3 = endLocal+1; counter3 < startLocal; counter3++){
                                                    angleMap [counter2][counter3] = 300;
                                                    totalMap [counter2][counter3] = 0;
                                                    startMap [counter2][counter3] = 0;
                                                    endMap [counter2][counter3] = 0;
                                                }
                                            }
                                            
                                            mappingPosition [counter2][0] = startLocal;
                                            mappingPosition [counter2][1] = endLocal;
                                            
                                            if (startLocal == -1 || endLocal == -1){
                                                for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-2)/2; counter3++) totalMap [counter2][counter3] = 0;
                                                
                                                mappingPosition [counter2][0] = -1;
                                                mappingPosition [counter2][1] = -1;
                                                mappingPosition [counter2][2] = -1;
                                            }
                                            else if (startLocal < endLocal) mappingPosition [counter2][2] = endLocal-startLocal;
                                            else mappingPosition [counter2][2] = (vectorSegmentationTempCount-2)/2-startLocal+endLocal;
                                            
                                            //for (int counterA = 0; counterA < defPoint; counterA++){
                                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<mappingPosition [counterA][counterB];
                                            //    cout<<" mappingPosition "<<counterA<<endl;
                                            //}
                                            
                                            //for (int counterA = 0; counterA < defMap; counterA++){
                                            //    for (int counterB = 0; counterB < defMap; counterB++) cout<<" "<<totalMap [counterA][counterB];
                                            //    cout<<" totalMap "<<counterA<<endl;
                                            //}
                                        }
                                        
                                        //------If No end and start is find, remove all other data------
                                        if (startFind == 0 && endFind == 0){
                                            for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-2)/2; counter3++){
                                                angleMap [counter2][counter3] = 300;
                                                startMap [counter2][counter3] = 0;
                                                endMap [counter2][counter3] = 0;
                                            }
                                            
                                            mappingPosition [counter2][0] = -1;
                                            mappingPosition [counter2][1] = -1;
                                            mappingPosition [counter2][2] = -1;
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < (vectorSegmentationTempCount-2)/2; counterA++){
                                //	for (int counterB = 0; counterB < 21; counterB++) cout<<" "<<totalMap [counterA][counterB];
                                //	cout<<" totalMap "<<counterA<<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < (vectorSegmentationTempCount-2)/2; counterA++){
                                //	for (int counterB = 0; counterB < 21; counterB++) cout<<" "<<angleMap [counterA][counterB];
                                //	cout<<" angleMap "<<counterA<<endl;
                                //}
                                
                                //------Clear Process line data------
                                mappingPosition [processLine][0] = -1;
                                mappingPosition [processLine][1] = -1;
                                mappingPosition [processLine][2] = -1;
                                
                                for (int counter2 = 0; counter2 < (vectorSegmentationTempCount-2)/2; counter2++){
                                    angleMap [processLine][counter2] = 300;
                                    totalMap [processLine][counter2] = 0;
                                    startMap [processLine][counter2] = 0;
                                    endMap [processLine][counter2] = 0;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < defMap; counterA++){
                            //	for (int counterB = 0; counterB < defMap; counterB++) cout<<" "<<totalMap [counterA][counterB];
                            //	cout<<" totalMap "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < defPoint; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<mappingPosition [counterA][counterB];
                            //    cout<<" mappingPosition "<<counterA<<endl;
                            //}
                        }
                        
                    } while (processLine != -1);
                    
                    for (int counter2 = 0; counter2 < lineInformationCount; counter2 = counter2+4){
                        arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = vectorNumber, vectorSegmentationTempCount2++;
                        arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayLineInformation [counter2], vectorSegmentationTempCount2++;
                        arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayLineInformation [counter2+1], vectorSegmentationTempCount2++;
                        arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayLineInformation [counter2+2], vectorSegmentationTempCount2++;
                        arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayLineInformation [counter2+3], vectorSegmentationTempCount2++;
                    }
                    
                    //for (int counterA = 0; counterA < vectorSegmentationTempCount2/5; counterA++){
                    //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayVectorSegmentationTemp2 [counterA*5+counterB];
                    //	cout<<" vectorSegmentationTemp2 "<<counterA<<endl;
                    //}
                    
                    delete [] arrayLineInformation;
                    
                    for (int counter2 = 0; counter2 < vectorSegmentationTempCount+4; counter2++){
                        delete [] angleMap [counter2];
                        delete [] startMap [counter2];
                        delete [] endMap [counter2];
                        delete [] totalMap [counter2];
                    }
                    
                    delete [] angleMap;
                    delete [] startMap;
                    delete [] endMap;
                    delete [] totalMap;
                    
                    for (int counter2 = 0; counter2 < (vectorSegmentationTempCount-2)/2; counter2++) delete [] mappingPosition [counter2];
                    delete [] mappingPosition;
                    
                    vectorSegmentationTempCount = 0;
                }
                
                //------Number of Point >= 10------
                if (vectorSegmentationTempCount >= 22){
                    defMap = vectorSegmentationTempCount+4;
                    
                    double **angleMap = new double *[defMap];
                    int **startEndMap = new int *[defMap];
                    int **totalMap = new int *[defMap];
                    
                    for (int counter2 = 0; counter2 < defMap; counter2++){
                        angleMap [counter2] = new double [defMap];
                        startEndMap [counter2] = new int [defMap];
                        totalMap [counter2] = new int [defMap];
                    }
                    
                    for (int counter2 = 0; counter2 < (vectorSegmentationTempCount-2)/2; counter2++){
                        for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-2)/2; counter3++){
                            angleMap [counter2][counter3] = 300;
                            startEndMap [counter2][counter3] = 0;
                            totalMap [counter2][counter3] = 0;
                        }
                    }
                    
                    //------Add extra 2 data to the end of array, Point 1, Point 2, ---Point End, Point 1, Point 2, Point 3------
                    arrayVectorSegmentationTemp [vectorSegmentationTempCount] = arrayVectorSegmentationTemp [2], vectorSegmentationTempCount++;
                    arrayVectorSegmentationTemp [vectorSegmentationTempCount] = arrayVectorSegmentationTemp [3], vectorSegmentationTempCount++;
                    arrayVectorSegmentationTemp [vectorSegmentationTempCount] = arrayVectorSegmentationTemp [4], vectorSegmentationTempCount++;
                    arrayVectorSegmentationTemp [vectorSegmentationTempCount] = arrayVectorSegmentationTemp [5], vectorSegmentationTempCount++;
                    
                    firstAngle = 0;
                    angle = 0;
                    cutOff1 = 0;
                    cutOff2 = 0;
                    cutOff3 = 0;
                    caseType = 0;
                    angleWrite2 = -200;
                    angleWrite3 = -200;
                    
                    //------Initial angle and length determination, Point1-Point4------
                    for (int counter2 = 0; counter2 < (vectorSegmentationTempCount-6)/2; counter2++){
                        angleMap [counter2][counter2] = 2;
                        totalMap [counter2][counter2] = 2;
                        
                        if (counter2+3 < (vectorSegmentationTempCount-6)/2){
                            angleMap [counter2][counter2+1] = 1;
                            totalMap [counter2][counter2+1] = 1;
                            angleMap [counter2][counter2+2] = 1;
                            totalMap [counter2][counter2+2] = 1;
                            angleMap [counter2][counter2+3] = 1;
                            totalMap [counter2][counter2+3] = 1;
                        }
                        else if (counter2+3 == (vectorSegmentationTempCount-6)/2){
                            angleMap [counter2][counter2+1] = 1;
                            totalMap [counter2][counter2+1] = 1;
                            angleMap [counter2][counter2+2] = 1;
                            totalMap [counter2][counter2+2] = 1;
                            angleMap [counter2][0] = 1;
                            totalMap [counter2][0] = 1;
                        }
                        else if (counter2+2 == (vectorSegmentationTempCount-6)/2){
                            angleMap [counter2][counter2+1] = 1;
                            totalMap [counter2][counter2+1] = 1;
                            angleMap [counter2][0] = 1;
                            totalMap [counter2][0] = 1;
                            angleMap [counter2][1] = 1;
                            totalMap [counter2][1] = 1;
                        }
                        else if (counter2+1 == (vectorSegmentationTempCount-6)/2){
                            angleMap [counter2][0] = 1;
                            totalMap [counter2][0] = 1;
                            angleMap [counter2][1] = 1;
                            totalMap [counter2][1] = 1;
                            angleMap [counter2][2] = 1;
                            totalMap [counter2][2] = 1;
                        }
                        
                        //------Angle and length extension, Angle Map creation------
                        startX = arrayVectorSegmentationTemp [counter2*2];
                        startY = arrayVectorSegmentationTemp [counter2*2+1];
                        endX = arrayVectorSegmentationTemp [(counter2+3)*2];
                        endY = arrayVectorSegmentationTemp [(counter2+3)*2+1];
                        firstLength = sqrt(pow((endX-startX), 2)+pow((endY-startY), 2));
                        lengthRef = firstLength;
                        
                        if (endX-startX == 0 && endY-startY > 0) firstAngle = 90;
                        else if (endX-startX == 0 && endY-startY < 0) firstAngle = -90;
                        else if (endY-startY == 0 && endX-startX > 0) firstAngle = 0;
                        else if (endY-startY == 0 && endX-startX < 0) firstAngle = 180;
                        else if (endX-startX != 0){
                            firstAngle = (atan(abs(endY-startY)/(double)abs(endX-startX)))*180/3.14;
                            
                            if (endX-startX > 0 && endY-startY < 0) firstAngle = firstAngle*-1;
                            else if (endX-startX < 0 && endY-startY > 0) firstAngle = 180-firstAngle;
                            else if (endX-startX < 0 && endY-startY < 0) firstAngle = (180-firstAngle)*-1;
                        }
                        
                        angleWrite = firstAngle;
                        endX2Position = endX;
                        endXY2Position = endY;
                        
                        //------Advance Forward, till the end of line------
                        for (int counter3 = counter2+4; counter3 < (vectorSegmentationTempCount-4)/2; counter3++){
                            endX2 = arrayVectorSegmentationTemp [counter3*2];
                            endY2 = arrayVectorSegmentationTemp [counter3*2+1];
                            length = sqrt(pow((endX2-startX), 2)+pow((endY2-startY), 2));
                            
                            if (endX2-startX == 0 && endY2-startY > 0) angle = 90;
                            else if (endX2-startX == 0 && endY2-startY < 0) angle = -90;
                            else if (endY2-startY == 0 && endX2-startX > 0) angle = 0;
                            else if (endY2-startY == 0 && endX2-startX < 0) angle = 180;
                            else if (endY2-startY != 0){
                                angle = (atan(abs(endY2-startY)/(double)abs(endX2-startX)))*180/3.14;
                                
                                if (endX2-startX > 0 && endY2-startY < 0) angle = angle*-1;
                                if (endX2-startX < 0 && endY2-startY > 0) angle = 180-angle;
                                if (endX2-startX < 0 && endY2-startY < 0) angle = (180-angle)*-1;
                            }
                            
                            if (length > lengthRef){
                                if (firstAngle < 160 && firstAngle > -160){
                                    cutOff1 = firstAngle-10;
                                    cutOff2 = firstAngle+10;
                                    cutOff3 = 0;
                                    caseType = 1;
                                }
                                else if (firstAngle >= 160){
                                    cutOff1 = firstAngle-10;
                                    cutOff2 = 180;
                                    cutOff3 = (180-(firstAngle+10-180))*-1;
                                    caseType = 2;
                                }
                                else if (firstAngle <= -160){
                                    cutOff1 = 180-(((firstAngle-10)+180)*-1);
                                    cutOff2 = 180;
                                    cutOff3 = firstAngle+10;
                                    caseType = 2;
                                }
                                else if (firstAngle == 180){
                                    cutOff1 = 160;
                                    cutOff2 = 180;
                                    cutOff3 = -160;
                                    caseType = 2;
                                }
                                
                                if ((angle >= cutOff1 && angle <= cutOff2 && caseType == 1) || (((angle >= cutOff1 && angle <= cutOff2) || (angle > cutOff2*-1 && angle <= cutOff3)) && caseType == 2)){
                                    if (counter3 == (vectorSegmentationTempCount-6)/2){
                                        angleMap [counter2][0] = 1;
                                        totalMap [counter2][0] = 1;
                                        angleWrite = angle;
                                        lengthRef = length;
                                    }
                                    else{
                                        
                                        angleMap [counter2][counter3] = 1;
                                        totalMap [counter2][counter3] = 1;
                                        angleWrite = angle;
                                        lengthRef = length;
                                        endX2Position = counter3;
                                        endXY2Position = counter3;
                                    }
                                }
                            }
                        }
                        
                        endX3 = endX2Position;
                        endY3 = endXY2Position;
                        lengthRef2 = lengthRef;
                        
                        //------Advance Reverse, till 0------
                        for (int counter3 = counter2-1; counter3 >= 0; counter3 = counter3-1){
                            startX2 = arrayVectorSegmentationTemp [counter3*2];
                            startY2 = arrayVectorSegmentationTemp [counter3*2+1];
                            length = sqrt(pow((endX3-startX2), 2)+pow((endY3-startY2), 2));
                            
                            if (endX3-startX2 == 0 && endY3-startY2 > 0) angle = 90;
                            else if (endX3-startX2 == 0 && endY3-startY2 < 0) angle = -90;
                            else if (endY3-startY2 == 0 && endX3-startX2 > 0) angle = 0;
                            else if (endY3-startY2 == 0 && endX3-startX2 < 0) angle = 180;
                            else if (endY3-startY2 != 0){
                                angle = (atan(abs(endY3-startY2)/(double)abs(endX3-startX2)))*180/3.14;
                                
                                if (endX3-startX2 > 0 && endY3-startY2 < 0) angle = angle*-1;
                                if (endX3-startX2 < 0 && endY3-startY2 > 0) angle = 180-angle;
                                if (endX3-startX2 < 0 && endY3-startY2 < 0) angle = (180-angle)*-1;
                            }
                            
                            if (length > lengthRef2){
                                if (firstAngle < 160 && firstAngle > -160){
                                    cutOff1 = firstAngle-5;
                                    cutOff2 = firstAngle+5;
                                    cutOff3 = 0;
                                    caseType = 1;
                                }
                                else if (firstAngle >= 160){
                                    cutOff1 = firstAngle-0;
                                    cutOff2 = 180;
                                    cutOff3 = (180-(firstAngle+5-180))*-1;
                                    caseType = 2;
                                }
                                else if (firstAngle <= -160){
                                    cutOff1 = 180-(((firstAngle-5)+180)*-1);
                                    cutOff2 = 180;
                                    cutOff3 = firstAngle+5;
                                    caseType = 2;
                                }
                                else if (firstAngle == 180){
                                    cutOff1 = 160;
                                    cutOff2 = 180;
                                    cutOff3 = -160;
                                    caseType = 2;
                                }
                                
                                if ((angle >= cutOff1 && angle <= cutOff2 && caseType == 1) || (((angle >= cutOff1 && angle <= cutOff2) || (angle > cutOff2*-1 && angle <= cutOff3)) && caseType == 2)){
                                    angleMap [counter2][counter3] = 1;
                                    totalMap [counter2][counter3] = 1;
                                    angleWrite2 = angle;
                                    lengthRef2 = length;
                                }
                            }
                        }
                        
                        lengthRef3 = lengthRef;
                        
                        //------Advance froward2, from 0 to before counter2, Reverse and froward2 may check same points------
                        for (int counter3 = 0; counter3 < counter2; counter3++){
                            endX3 = arrayVectorSegmentationTemp [counter3*2];
                            endY3 = arrayVectorSegmentationTemp [counter3*2+1];
                            length = sqrt(pow((endX3-startX), 2)+pow((endY3-startY), 2));
                            
                            if (endX3-startX == 0 && endY3-startY > 0) angle = 90;
                            else if (endX3-startX == 0 && endY3-startY < 0) angle = -90;
                            else if (endY3-startY == 0 && endX3-startX > 0) angle = 0;
                            else if (endY3-startY == 0 && endX3-startX < 0) angle = 180;
                            else if (endY3-startY != 0){
                                angle = (atan(abs(endY3-startY)/(double)abs(endX3-startX)))*180/3.14;
                                
                                if (endX3-startX > 0 && endY3-startY < 0) angle = angle*-1;
                                if (endX3-startX < 0 && endY3-startY > 0) angle = 180-angle;
                                if (endX3-startX < 0 && endY3-startY < 0) angle = (180-angle)*-1;
                            }
                            
                            if (length > lengthRef3){
                                if (firstAngle < 160 && firstAngle > -160){
                                    cutOff1 = firstAngle-5;
                                    cutOff2 = firstAngle+5;
                                    cutOff3 = 0;
                                    caseType = 1;
                                }
                                else if (firstAngle >= 160){
                                    cutOff1 = firstAngle-0;
                                    cutOff2 = 180;
                                    cutOff3 = (180-(firstAngle+5-180))*-1;
                                    caseType = 2;
                                }
                                else if (firstAngle <= -160){
                                    cutOff1 = 180-(((firstAngle-5)+180)*-1);
                                    cutOff2 = 180;
                                    cutOff3 = firstAngle+5;
                                    caseType = 2;
                                }
                                else if (firstAngle == 180){
                                    cutOff1 = 160;
                                    cutOff2 = 180;
                                    cutOff3 = -160;
                                    caseType = 2;
                                }
                                
                                if ((angle >= cutOff1 && angle <= cutOff2 && caseType == 1) || (((angle >= cutOff1 && angle <= cutOff2) || (angle > cutOff2*-1 && angle <= cutOff3)) && caseType == 2)){
                                    angleMap [counter2][counter3] = 1;
                                    totalMap [counter2][counter3] = 1;
                                    angleWrite3 = angle;
                                    lengthRef3 = length;
                                }
                            }
                        }
                        
                        //------If angle is within +- 5 degree, and length is longer than previous one, write data------
                        if (lengthRef2 > lengthRef && lengthRef3 == lengthRef) angleWrite = angleWrite2;
                        else if (lengthRef3 > lengthRef && lengthRef2 == lengthRef) angleWrite = angleWrite3;
                        else if (lengthRef2 > lengthRef && lengthRef3 > lengthRef){
                            if (lengthRef2 > lengthRef3) angleWrite = angleWrite2;
                            
                            if (lengthRef2 <= lengthRef3) angleWrite = angleWrite3;
                        }
                        
                        //------Total point check. if marked points are over 50% of total points, remove marked point untill it become below 50%------
                        totalPointCount = 0;
                        
                        //------Determine the total marked points------
                        for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-6)/2; counter3++){
                            if (totalMap [counter2][counter3] != 0) totalPointCount++;
                        }
                        
                        //------Determine the firs Zero point, search from counter 3 toward 0------
                        if (totalPointCount/(double)((vectorSegmentationTempCount-6)/2-1) > 0.5){
                            zeroAppearedPosition = -2;
                            
                            for (int counter3 = counter2-1; counter3 >= 0; counter3--){
                                if (totalMap [counter2][counter3] == 0){
                                    zeroAppearedPosition = counter3;
                                    break;
                                }
                            }
                            
                            //------If the first Zero is not find, search from the end of line------
                            if (zeroAppearedPosition == -2){
                                for (int counter3 = (vectorSegmentationTempCount-6)/2-1; counter3 >= counter2+4; counter3--){
                                    if (totalMap [counter2][counter3] == 0){
                                        zeroAppearedPosition = counter3;
                                        break;
                                    }
                                }
                            }
                            
                            //------If the first Zero is not find, set counter2-1, if counter2-1 is minus, set the end of line------
                            if (zeroAppearedPosition == -2){
                                zeroAppearedPosition = counter2-1;
                                
                                if (zeroAppearedPosition == -1)zeroAppearedPosition = (vectorSegmentationTempCount-6)/2-1;
                            }
                            
                            //------Marked point removal, after removal of a point, then check the percentage------
                            do{
                                
                                terminationFlag = 1;
                                noZeroFlag = 0;
                                
                                //------In the case First Zero is smaller than counter2------
                                if (zeroAppearedPosition < counter2){
                                    for (int counter3 = zeroAppearedPosition; counter3 >= 0; counter3--){
                                        if (totalMap [counter2][counter3] == 1){
                                            totalMap [counter2][counter3] = 0;
                                            angleMap [counter2][counter3] = 300;
                                            noZeroFlag = 1;
                                            totalPointCount = totalPointCount-1;
                                            break;
                                        }
                                    }
                                    
                                    if (noZeroFlag == 0){
                                        for (int counter3 = (vectorSegmentationTempCount-6)/2-1; counter3 >= counter2+4; counter3--){
                                            if (totalMap [counter2][counter3] == 1){
                                                totalMap [counter2][counter3] = 0;
                                                angleMap [counter2][counter3] = 300;
                                                totalPointCount = totalPointCount-1;
                                                noZeroFlag = 1;
                                                break;
                                            }
                                        }
                                    }
                                    
                                    if (noZeroFlag == 0){
                                        for (int counter3 = zeroAppearedPosition; counter3 < counter2; counter3++){
                                            if (totalMap [counter2][counter3] == 1){
                                                totalMap [counter2][counter3] = 0;
                                                angleMap [counter2][counter3] = 300;
                                                totalPointCount = totalPointCount-1;
                                                noZeroFlag = 1;
                                                break;
                                            }
                                        }
                                        
                                        if (noZeroFlag == 0) terminationFlag = 0;
                                    }
                                }
                                
                                //------In the case First Zero is larger than counter2------
                                if (zeroAppearedPosition > counter2){
                                    for (int counter3 = zeroAppearedPosition; counter3 >= counter2+4; counter3--){
                                        if (totalMap [counter2][counter3] == 1){
                                            totalMap [counter2][counter3] = 0;
                                            angleMap [counter2][counter3] = 300;
                                            totalPointCount = totalPointCount-1;
                                            noZeroFlag = 1;
                                            break;
                                        }
                                    }
                                    
                                    if (noZeroFlag == 0){
                                        for (int counter3 = 0; counter3 < counter2; counter3++){
                                            if (totalMap [counter2][counter3] == 1){
                                                totalMap [counter2][counter3] = 0;
                                                angleMap [counter2][counter3] = 300;
                                                totalPointCount = totalPointCount-1;
                                                noZeroFlag = 1;
                                                break;
                                            }
                                        }
                                        
                                        if (noZeroFlag == 0) terminationFlag = 0;
                                    }
                                }
                                
                                if (totalPointCount/(double)((vectorSegmentationTempCount-6)/2-1) < 0.5) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                        
                        //------Angle Data writing------
                        for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-6)/2; counter3++){
                            if (angleMap [counter2][counter3] != 300) angleMap [counter2][counter3] = angleWrite;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < (vectorSegmentationTempCount-6)/2; counterA++){
                    //	for (int counterB = 0; counterB < 21; counterB++) cout<<" "<<totalMap [counterA][counterB];
                    //	cout<<" totalMap "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < (vectorSegmentationTempCount-6)/2; counterA++){
                    //	for (int counterB = 0; counterB < 21; counterB++) cout<<" "<<angleMap [counterA][counterB];
                    //	cout<<" angleMap "<<counterA<<endl;
                    //}
                    
                    //------Start and End point writing, if RV extension is found, adjust the starting point------
                    int **mappingPosition = new int *[(vectorSegmentationTempCount-6)/2+4];
                    for (int counter2 = 0; counter2 < (vectorSegmentationTempCount-6)/2+4; counter2++) mappingPosition [counter2] = new int [4];
                    
                    for (int counter2 = 0; counter2 < (vectorSegmentationTempCount-6)/2; counter2++){
                        for (int counter3 = 0; counter3 < 3; counter3++) mappingPosition [counter2][counter3] = -1;
                    }
                    
                    for (int counter2 = 0; counter2 < (vectorSegmentationTempCount-6)/2; counter2++){
                        countStart1 = -1;
                        countEnd1 = -1;
                        countEnd2 = -1;
                        countEndFirstFlag = 0;
                        countStart2Temp2 = -1;
                        
                        //------Set countStart1, point that is marked, 2------
                        for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-6)/2; counter3++){
                            if (totalMap [counter2][counter3] == 2) countStart1 = counter3;
                        }
                        
                        //------Set countEnd1, the end of continuous block containing 2------
                        for (int counter3 = countStart1+1; counter3 < (vectorSegmentationTempCount-6)/2; counter3++){
                            if (totalMap [counter2][counter3] != 0) countEnd1 = counter3;
                        }
                        
                        if (countEnd1 == -1) countEnd1 = countStart1;
                        
                        //------Set countStart2, if RV extension occurs, line is extended toward 0 from marked point 2, this search the point------
                        countStart2 = countStart1;
                        
                        if (countStart1 == 1){
                            if (totalMap [counter2][0] != 0) countStart2 = 0;
                        }
                        if (countStart1 == 2){
                            if (totalMap [counter2][1] != 0) countStart2 = 1;
                            
                            if (totalMap [counter2][0] != 0) countStart2 = 0;
                        }
                        if (countStart1 == 3){
                            if (totalMap [counter2][2] != 0) countStart2 = 2;
                            
                            if (totalMap [counter2][1] != 0) countStart2 = 1;
                            
                            if (totalMap [counter2][0] != 0) countStart2 = 0;
                        }
                        
                        if (countStart1 >= 3){
                            for (int counter3 = countStart1-1; counter3 >= 0; counter3--){
                                if (counter3 == 0){
                                    if (totalMap [counter2][counter3] != 0 && countEndFirstFlag == 1){
                                        if (counter3 >= countStart1-(counter3+1)+1 || (vectorSegmentationTempCount-6)/2-countEnd1+counter3 >= countEnd1-(counter3+1)+1){
                                            countStart2Temp1 = 0;
                                            countStart2Temp2 = countStart2Temp1;
                                            countEndFirstFlag = 0;
                                        }
                                    }
                                    else if (totalMap [counter2][counter3] == 0 && countEndFirstFlag == 1){
                                        if (counter3 >= countStart1-(counter3+1)+1 || (vectorSegmentationTempCount-6)/2-countEnd1+counter3 >= countEnd1-(counter3+1)+1){
                                            countStart2Temp1 = 1;
                                            countStart2Temp2 = countStart2Temp1;
                                            countEndFirstFlag = 0;
                                        }
                                    }
                                }
                                else if (totalMap [counter2][counter3] != 0 && countEndFirstFlag == 0) countEndFirstFlag = 1;
                                else if (totalMap [counter2][counter3] == 0 && countEndFirstFlag == 1){
                                    if (counter3 >= countStart1-(counter3+1)+1 || (vectorSegmentationTempCount-6)/2-countEnd1+counter3 >= countEnd1-(counter3+1)+1){
                                        countStart2Temp1 = counter3+1;
                                        countStart2Temp2 = countStart2Temp1;
                                        countEndFirstFlag = 0;
                                    }
                                    else{
                                        
                                        break;
                                    }
                                }
                            }
                        }
                        
                        if (countStart2Temp2 != -1) countStart2 = countStart2Temp2;
                        
                        //------Set countEnd2, end of point, which is not the same block containing 2------
                        for (int counter3 = 0; counter3 < countStart2; counter3++){
                            if (totalMap [counter2][counter3] != 0) countEnd2 = counter3;
                        }
                        
                        if (countStart2 < countStart1){
                            mappingPosition [counter2][0] = countStart2;
                            totalMap [counter2][countStart1] = 1;
                            totalMap [counter2][countStart2] = 2;
                        }
                        else mappingPosition [counter2][0] = countStart1;
                        
                        if (countEnd2 != -1){
                            mappingPosition [counter2][1] = countEnd2;
                            totalMap [counter2][countEnd2] = 3;
                        }
                        else{
                            
                            mappingPosition [counter2][1] = countEnd1;
                            totalMap [counter2][countEnd1] = 3;
                        }
                        
                        if (mappingPosition [counter2][0] < mappingPosition [counter2][1]) mappingPosition [counter2][2] = mappingPosition [counter2][1]-mappingPosition [counter2][0]+1;
                        else mappingPosition [counter2][2] = ((vectorSegmentationTempCount-6)/2)-mappingPosition [counter2][0]+mappingPosition [counter2][1]+1;
                    }
                    
                    //------Gap, Continuity Map creation, create a map into interruptionCount and continuityCount, number of Gaps and continued block are written------
                    //------If the starting or end point is e.g. 0001000, 1 is ignored. But if gap exist, gap number is written------
                    
                    for (int counter2 = 0; counter2 < (vectorSegmentationTempCount-6)/2; counter2++){
                        int *interruptionCount = new int [(vectorSegmentationTempCount-6)/2+4];
                        int *continuityCount = new int [(vectorSegmentationTempCount-6)/2+4];
                        
                        for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-6)/2; counter3++){
                            interruptionCount [counter3] = 0;
                            continuityCount [counter3] = 0;
                        }
                        
                        gapStart = -1;
                        gapEnd = -1;
                        gapFlag = 0;
                        contStart = -1;
                        contEnd = -1;
                        contFlag = 0;
                        
                        if (mappingPosition [counter2][0] < mappingPosition [counter2][1]){
                            for (int counter3 = mappingPosition [counter2][0]; counter3 <= mappingPosition [counter2][1]+1; counter3++){
                                if (counter3 == mappingPosition [counter2][1]+1){
                                    if (gapFlag == 1){
                                        for (int counter4 = gapStart; counter4 <= gapEnd; counter4++) interruptionCount [counter4] = gapEnd-gapStart+1;
                                        
                                        gapStart = -1;
                                        gapEnd = -1;
                                        gapFlag = 0;
                                    }
                                    if (contFlag == 1){
                                        for (int counter4 = contStart; counter4 <= contEnd; counter4++) continuityCount [counter4] = contEnd-contStart+1;
                                        
                                        contStart = -1;
                                        contEnd = -1;
                                        contFlag = 0;
                                    }
                                }
                                else if (angleMap [counter2][counter3] == 300 && gapFlag == 0){
                                    gapFlag = 1;
                                    gapStart = counter3;
                                }
                                else if (angleMap [counter2][counter3] == 300 && gapFlag == 1) gapEnd = counter3;
                                else if (angleMap [counter2][counter3] != 300 && gapFlag == 1){
                                    for (int counter4 = gapStart; counter4 <= gapEnd; counter4++) interruptionCount [counter4] = gapEnd-gapStart+1;
                                    
                                    gapStart = -1;
                                    gapEnd = -1;
                                    gapFlag = 0;
                                }
                                
                                if (angleMap [counter2][counter3] != 300 && contFlag == 0){
                                    contFlag = 1;
                                    contStart = counter3;
                                }
                                else if (angleMap [counter2][counter3] != 300 && contFlag == 1) contEnd = counter3;
                                else if (angleMap [counter2][counter3] == 300 && contFlag == 1){
                                    for (int counter4 = contStart; counter4 <= contEnd; counter4++) continuityCount [counter4] = contEnd-contStart+1;
                                    
                                    contStart = -1;
                                    contEnd = -1;
                                    contFlag = 0;
                                }
                            }
                        }
                        
                        gapStart = -1;
                        gapEnd = -1;
                        gapFlag = 0;
                        contStart = -1;
                        contEnd = -1;
                        contFlag = 0;
                        
                        if (mappingPosition [counter2][0] > mappingPosition [counter2][1]){
                            for (int counter3 = mappingPosition [counter2][0]; counter3 < (vectorSegmentationTempCount-6)/2; counter3++){
                                if (angleMap [counter2][counter3] == 300 && gapFlag == 0){
                                    gapFlag = 1;
                                    gapStart = counter3;
                                }
                                else if (angleMap [counter2][counter3] == 300 && gapFlag == 1) gapEnd = counter3;
                                else if (angleMap [counter2][counter3] != 300 && gapFlag == 1){
                                    for (int counter4 = gapStart; counter4 <= gapEnd; counter4++) interruptionCount [counter4] = gapEnd-gapStart+1;
                                    
                                    gapStart = -1;
                                    gapEnd = -1;
                                    gapFlag = 0;
                                }
                                
                                if (angleMap [counter2][counter3] != 300 && contFlag == 0){
                                    contFlag = 1;
                                    contStart = counter3;
                                }
                                else if (angleMap [counter2][counter3] != 300 && contFlag == 1) contEnd = counter3;
                                else if (angleMap [counter2][counter3] == 300 && contFlag == 1){
                                    for (int counter4 = contStart; counter4 <= contEnd; counter4++) continuityCount [counter4] = contEnd-contStart+1;
                                    
                                    contStart = -1;
                                    contEnd = -1;
                                    contFlag = 0;
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < (vectorSegmentationTempCount-2)/2; counterA++){
                        //	cout<<" "<<interruptionCount [counterA];
                        //}
                        
                        //for (int counterA = 0; counterA < (vectorSegmentationTempCount-2)/2; counterA++){
                        //	cout<<" "<<continuityCount [counterA];
                        //}
                        
                        for (int counter3 = 0; counter3 <= mappingPosition [counter2][1]+1; counter3++){
                            if (counter3 == mappingPosition [counter2][1]+1){
                                if (gapFlag == 1){
                                    if (gapEnd > gapStart){
                                        for (int counter4 = gapStart; counter4 <= gapEnd; counter4++) interruptionCount [counter4] = gapEnd-gapStart+1;
                                    }
                                    
                                    if (gapEnd < gapStart && gapEnd != -1){
                                        for (int counter4 = gapStart; counter4 < (vectorSegmentationTempCount-6)/2; counter4++) interruptionCount [counter4] = ((vectorSegmentationTempCount-6)/2)-gapStart+gapEnd+1;
                                        for (int counter4 = 0; counter4 <= gapEnd; counter4++) interruptionCount [counter4] = ((vectorSegmentationTempCount-6)/2)-gapStart+gapEnd+1;
                                    }
                                }
                                
                                if (contFlag == 1){
                                    if (contEnd > contStart){
                                        for (int counter4 = contStart; counter4 <= contEnd; counter4++) continuityCount [counter4] = contEnd-contStart+1;
                                    }
                                    
                                    if (contEnd < contStart && contEnd != -1){
                                        for (int counter4 = contStart; counter4 < (vectorSegmentationTempCount-6)/2; counter4++) continuityCount [counter4] = ((vectorSegmentationTempCount-6)/2)-contStart+contEnd+1;
                                        for (int counter4 = 0; counter4 <= contEnd; counter4++) continuityCount [counter4] = ((vectorSegmentationTempCount-6)/2)-contStart+contEnd+1;
                                    }
                                }
                            }
                            else if (angleMap [counter2][counter3] == 300 && gapFlag == 0){
                                gapFlag = 1;
                                gapStart = counter3;
                            }
                            else if (angleMap [counter2][counter3] == 300 && gapFlag == 1) gapEnd = counter3;
                            else if (angleMap [counter2][counter3] != 300 && gapFlag == 1){
                                if (gapEnd > gapStart){
                                    for (int counter4 = gapStart; counter4 <= gapEnd; counter4++) interruptionCount [counter4] = gapEnd-gapStart+1;
                                }
                                
                                if (gapEnd < gapStart && gapEnd != -1){
                                    for (int counter4 = gapStart; counter4 < (vectorSegmentationTempCount-6)/2; counter4++) interruptionCount [counter4] = ((vectorSegmentationTempCount-6)/2)-gapStart+gapEnd+1;
                                    for (int counter4 = 0; counter4 <= gapEnd; counter4++) interruptionCount [counter4] = ((vectorSegmentationTempCount-6)/2)-gapStart+gapEnd+1;
                                }
                                
                                gapStart = -1;
                                gapEnd = -1;
                                gapFlag = 0;
                            }
                            
                            if (angleMap [counter2][counter3] != 300 && contFlag == 0){
                                contFlag = 1;
                                contStart = counter3;
                            }
                            else if (angleMap [counter2][counter3] != 300 && contFlag == 1) contEnd = counter3;
                            else if (angleMap [counter2][counter3] == 300 && contFlag == 1){
                                if (contEnd > contStart){
                                    for (int counter4 = contStart; counter4 <= contEnd; counter4++) continuityCount [counter4] = contEnd-contStart+1;
                                }
                                
                                if (contEnd < contStart && contEnd != -1){
                                    for (int counter4 = contStart; counter4 < (vectorSegmentationTempCount-6)/2; counter4++) continuityCount [counter4] = ((vectorSegmentationTempCount-6)/2)-contStart+contEnd+1;
                                    for (int counter4 = 0; counter4 <= contEnd; counter4++) continuityCount [counter4] = ((vectorSegmentationTempCount-6)/2)-contStart+contEnd+1;
                                }
                                
                                contStart = -1;
                                contEnd = -1;
                                contFlag = 0;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < (vectorSegmentationTempCount-2)/2; counterA++){
                        //	cout<<" "<<interruptionCount [counterA];
                        //}
                        
                        //for (int counterA = 0; counterA < (vectorSegmentationTempCount-2)/2; counterA++){
                        //	cout<<" "<<continuityCount [counterA];
                        //}
                        
                        //------Remove end without Continuity, gap extension without first or last continuous block will be trimmed------
                        gapStart = -1;
                        gapEnd = -1;
                        gapFlag = 0;
                        contEnd = -1;
                        contFlag = 0;
                        
                        startReset = mappingPosition [counter2][0];
                        endReset = mappingPosition [counter2][1];
                        
                        if (mappingPosition [counter2][0] < mappingPosition [counter2][1]){
                            for (int counter3 = mappingPosition [counter2][0]; counter3 <= mappingPosition [counter2][1]; counter3++){
                                if (interruptionCount [counter3] != 0 && gapFlag == 0){
                                    gapStart = counter3;
                                    gapFlag = 1;
                                }
                                else if (interruptionCount [counter3] != 0 && gapFlag == 1) gapEnd = counter3;
                                
                                if (continuityCount [counter3] != 0 && contFlag == 0){
                                    contStart = counter3;
                                    contFlag = 1;
                                }
                                else if (continuityCount [counter3] != 0 && contFlag == 1) contEnd = counter3;
                            }
                            
                            if (gapEnd > contEnd && gapEnd != -1){
                                for (int counter3 = contEnd+1; counter3 <= gapEnd; counter3++){
                                    interruptionCount [counter3] = 0;
                                    continuityCount [counter3] = 0;
                                }
                            }
                            
                            if (gapStart < contStart && gapStart != -1){
                                for (int counter3 = gapStart; counter3 < contStart; counter3++){
                                    interruptionCount [counter3] = 0;
                                    continuityCount [counter3] = 0;
                                }
                            }
                            
                            startReset = contStart;
                            endReset = contEnd;
                        }
                        if (mappingPosition [counter2][0] > mappingPosition [counter2][1]){
                            for (int counter3 = mappingPosition [counter2][0]; counter3 < (vectorSegmentationTempCount-6)/2; counter3++){
                                if (interruptionCount [counter3] != 0 && gapFlag == 0){
                                    gapStart = counter3;
                                    gapFlag = 1;
                                }
                                else if (interruptionCount [counter3] != 0 && gapFlag == 1) gapEnd = counter3;
                                
                                if (continuityCount [counter3] != 0 && contFlag == 0){
                                    contStart = counter3;
                                    contFlag = 1;
                                }
                                else if (continuityCount [counter3] != 0 && contFlag == 1) contEnd = counter3;
                            }
                            
                            for (int counter3 = 0; counter3 <= mappingPosition [counter2][1]; counter3++){
                                if (interruptionCount [counter3] != 0 && gapFlag == 0){
                                    gapStart = counter3;
                                    gapFlag = 1;
                                }
                                else if (interruptionCount [counter3] != 0 && gapFlag == 1) gapEnd = counter3;
                                
                                if (continuityCount [counter3] != 0 && contFlag == 0){
                                    contStart = counter3;
                                    contFlag = 1;
                                }
                                else if (continuityCount [counter3] != 0 && contFlag == 1) contEnd = counter3;
                            }
                            
                            if (gapEnd < (vectorSegmentationTempCount-6)/2 && gapEnd > mappingPosition [counter2][0] && contEnd < (vectorSegmentationTempCount-6)/2 && contEnd > mappingPosition [counter2][0] && gapEnd > contEnd){
                                for (int counter3 = contEnd+1; counter3 <= gapEnd; counter3++){
                                    interruptionCount [counter3] = 0;
                                    continuityCount [counter3] = 0;
                                }
                                
                                endReset = contEnd;
                            }
                            if (gapEnd >= 0 && gapEnd < mappingPosition [counter2][0] && contEnd < (vectorSegmentationTempCount-6)/2 && contEnd > mappingPosition [counter2][0]){
                                for (int counter3 = contEnd+1; counter3 < (vectorSegmentationTempCount-6)/2; counter3++){
                                    interruptionCount [counter3] = 0;
                                    continuityCount [counter3] = 0;
                                }
                                
                                for (int counter3 = 0; counter3 <= gapEnd; counter3++){
                                    interruptionCount [counter3] = 0;
                                    continuityCount [counter3] = 0;
                                }
                                
                                endReset = contEnd;
                            }
                            if (gapEnd >= 0 && gapEnd < mappingPosition [counter2][0] && contEnd >= 0 && contEnd < mappingPosition [counter2][0] && gapEnd > contEnd){
                                for (int counter3 = contEnd+1; counter3 <= mappingPosition [counter2][1]; counter3++){
                                    interruptionCount [counter3] = 0;
                                    continuityCount [counter3] = 0;
                                }
                                
                                endReset = contEnd;
                            }
                            
                            if (gapStart > mappingPosition [counter2][0] && contStart > mappingPosition [counter2][0] && gapStart < contStart){
                                for (int counter3 = gapStart; counter3 < contStart; counter3++){
                                    interruptionCount [counter3] = 0;
                                    continuityCount [counter3] = 0;
                                }
                                
                                startReset = contStart;
                            }
                        }
                        
                        mappingPosition [counter2][0] = startReset;
                        mappingPosition [counter2][1] = endReset;
                        
                        
                        //for (int counterA = 0; counterA < (vectorSegmentationTempCount-2)/2; counterA++){
                        //	cout<<" "<<interruptionCount [counterA];
                        //}
                        
                        //for (int counterA = 0; counterA < (vectorSegmentationTempCount-2)/2; counterA++){
                        //	cout<<" "<<continuityCount [counterA];
                        //}
                        
                        //cout<<mappingPosition [counter2][0] <<" "<<mappingPosition [counter2][1] <<" MapPosition"<<endl;
                        
                        //------One point Gap removal, if a gap without continuity or gap is find within the line, fill the point, 1000------
                        if (mappingPosition [counter2][0] < mappingPosition [counter2][1]){
                            for (int counter3 = mappingPosition [counter2][0]; counter3 <= mappingPosition [counter2][1]; counter3++){
                                if (continuityCount [counter3] != 0){
                                    mappingPosition [counter2][0] = counter3;
                                    break;
                                }
                            }
                            
                            for (int counter3 = mappingPosition [counter2][1]; counter3 >= mappingPosition [counter2][0]; counter3 = counter3-1){
                                if (continuityCount [counter3] != 0){
                                    mappingPosition [counter2][1] = counter3;
                                    break;
                                }
                            }
                        }
                        
                        if (mappingPosition [counter2][0] > mappingPosition [counter2][1]){
                            continueFlag = 0;
                            
                            for (int counter3 = mappingPosition [counter2][0]; counter3 < (vectorSegmentationTempCount-6)/2; counter3++){
                                if (continuityCount [counter3] != 0){
                                    mappingPosition [counter2][0] = counter3;
                                    continueFlag = 1;
                                    break;
                                }
                            }
                            
                            if (continueFlag == 0){
                                for (int counter3 = 0; counter3 < mappingPosition [counter2][1]; counter3++){
                                    if (continuityCount [counter3] != 0){
                                        mappingPosition [counter2][0] = counter3;
                                        break;
                                    }
                                }
                            }
                            
                            continueFlag = 0;
                            
                            for (int counter3 = mappingPosition [counter2][1]; counter3 >= 0; counter3 = counter3-1){
                                if (continuityCount [counter3] != 0){
                                    mappingPosition [counter2][1] = counter3;
                                    continueFlag = 1;
                                    break;
                                }
                            }
                            
                            if (continueFlag == 0){
                                for (int counter3 = (vectorSegmentationTempCount-6)/2-1; counter3 >= mappingPosition [counter2][0]; counter3 = counter3-1){
                                    if (continuityCount [counter3] != 0){
                                        mappingPosition [counter2][1] = counter3;
                                        break;
                                    }
                                }
                            }
                        }
                        
                        if (mappingPosition [counter2][0] < mappingPosition [counter2][1]){
                            for (int counter3 = mappingPosition [counter2][0]; counter3 <= mappingPosition [counter2][1]; counter3++){
                                if (interruptionCount [counter3] == 0 && continuityCount [counter3] == 0){
                                    if (continuityCount [counter3-1] == 0 && continuityCount [counter3+1] == 0) interruptionCount [counter3] = 1000;
                                    else continuityCount [counter3] = 1000;
                                }
                            }
                        }
                        
                        if (mappingPosition [counter2][0] > mappingPosition [counter2][1]){
                            for (int counter3 = mappingPosition [counter2][0]; counter3 < (vectorSegmentationTempCount-6)/2; counter3++){
                                if (interruptionCount [counter3] == 0 && continuityCount [counter3] == 0){
                                    onePointUp = counter3+1;
                                    onePointDown = counter3-1;
                                    
                                    if (onePointUp == (vectorSegmentationTempCount-6)/2) onePointUp = 0;
                                    if (continuityCount [onePointDown] == 0 && continuityCount [onePointUp] == 0) interruptionCount [counter3] = 1000;
                                    else continuityCount [counter3] = 1000;
                                }
                            }
                            
                            for (int counter3 = 0; counter3 <= mappingPosition [counter2][1]; counter3++){
                                if (interruptionCount [counter3] == 0 && continuityCount [counter3] == 0){
                                    onePointUp = counter3+1;
                                    onePointDown = counter3-1;
                                    
                                    if (onePointDown == -1) onePointDown = (vectorSegmentationTempCount-6)/2-1;
                                    
                                    if (continuityCount [onePointDown] == 0 && continuityCount [onePointUp] == 0) interruptionCount [counter3] = 1000;
                                    else continuityCount [counter3] = 1000;
                                }
                            }
                        }
                        
                        //------Map re-Number, gap and continuity number are re-numbered------
                        gapStart = -1;
                        gapEnd = 0;
                        gapFlag = 0;
                        contEnd = -1;
                        contFlag = 0;
                        
                        if (mappingPosition [counter2][0] < mappingPosition [counter2][1]){
                            for (int counter3 = mappingPosition [counter2][0]; counter3 <= mappingPosition [counter2][1]+1; counter3++){
                                if (counter3 == mappingPosition [counter2][1]+1){
                                    if (contFlag == 1){
                                        for (int counter4 = contStart; counter4 <= contEnd; counter4++) continuityCount [counter4] = contEnd-contStart+1;
                                        
                                        contStart = -1;
                                        contEnd = -1;
                                        contFlag = 0;
                                    }
                                }
                                else if (interruptionCount [counter3] != 0 && gapFlag == 0){
                                    gapFlag = 1;
                                    gapStart = counter3;
                                }
                                else if (interruptionCount [counter3] != 0 && gapFlag == 1) gapEnd = counter3;
                                else if (interruptionCount [counter3] == 0 && gapFlag == 1){
                                    for (int counter4 = gapStart; counter4 <= gapEnd; counter4++) interruptionCount [counter4] = gapEnd-gapStart+1;
                                    
                                    gapStart = -1;
                                    gapEnd = -1;
                                    gapFlag = 0;
                                }
                                
                                if (continuityCount [counter3] != 0 && contFlag == 0){
                                    contFlag = 1;
                                    contStart = counter3;
                                }
                                else if (continuityCount [counter3] != 0 && contFlag == 1) contEnd = counter3;
                                else if (continuityCount [counter3] == 0 && contFlag == 1){
                                    for (int counter4 = contStart; counter4 <= contEnd; counter4++) continuityCount [counter4] = contEnd-contStart+1;
                                    
                                    contStart = -1;
                                    contEnd = -1;
                                    contFlag = 0;
                                }
                            }
                        }
                        if (mappingPosition [counter2][0] > mappingPosition [counter2][1]){
                            for (int counter3 = mappingPosition [counter2][0]; counter3 < (vectorSegmentationTempCount-6)/2; counter3++){
                                if (interruptionCount [counter3] != 0 && gapFlag == 0){
                                    gapFlag = 1;
                                    gapStart = counter3;
                                }
                                else if (interruptionCount [counter3] != 0 && gapFlag == 1) gapEnd = counter3;
                                else if (interruptionCount [counter3] == 0 && gapFlag == 1){
                                    for (int counter4 = gapStart; counter4 <= gapEnd; counter4++) interruptionCount [counter4] = gapEnd-gapStart+1;
                                    
                                    gapStart = -1;
                                    gapEnd = -1;
                                    gapFlag = 0;
                                }
                                
                                if (continuityCount [counter3] != 0 && contFlag == 0){
                                    contFlag = 1;
                                    contStart = counter3;
                                }
                                else if (continuityCount [counter3] != 0 && contFlag == 1) contEnd = counter3;
                                else if (continuityCount [counter3] == 0 && contFlag == 1){
                                    for (int counter4 = contStart; counter4 <= contEnd; counter4++) continuityCount [counter4] = contEnd-contStart+1;
                                    
                                    contStart = -1;
                                    contEnd = -1;
                                    contFlag = 0;
                                }
                            }
                            
                            for (int counter3 = 0; counter3 <= mappingPosition [counter2][1]+1; counter3++){
                                if (counter3 == mappingPosition [counter2][1]+1){
                                    if (contFlag == 1){
                                        if (contEnd > contStart){
                                            for (int counter4 = contStart; counter4 <= contEnd; counter4++) continuityCount [counter4] = contEnd-contStart+1;
                                        }
                                        
                                        if (contEnd < contStart && contEnd != -1){
                                            for (int counter4 = contStart; counter4 < (vectorSegmentationTempCount-6)/2; counter4++) continuityCount [counter4] = ((vectorSegmentationTempCount-6)/2)-contStart+contEnd+1;
                                            for (int counter4 = 0; counter4 <= contEnd; counter4++) continuityCount [counter4] = ((vectorSegmentationTempCount-6)/2)-contStart+contEnd+1;
                                        }
                                    }
                                }
                                else if (interruptionCount [counter3] != 0 && gapFlag == 0){
                                    gapFlag = 1;
                                    gapStart = counter3;
                                }
                                else if (interruptionCount [counter3] != 0 && gapFlag == 1) gapEnd = counter3;
                                else if (interruptionCount [counter3] == 0 && gapFlag == 1){
                                    if (gapEnd > gapStart){
                                        for (int counter4 = gapStart; counter4 <= gapEnd; counter4++) interruptionCount [counter4] = gapEnd-gapStart+1;
                                        
                                        gapStart = -1;
                                        gapEnd = -1;
                                        gapFlag = 0;
                                    }
                                    
                                    if (gapEnd < gapStart && gapEnd != -1){
                                        for (int counter4 = gapStart; counter4 < (vectorSegmentationTempCount-6)/2; counter4++) interruptionCount [counter4] = ((vectorSegmentationTempCount-6)/2)-gapStart+gapEnd+1;
                                        for (int counter4 = 0; counter4 <= gapEnd; counter4++) interruptionCount [counter4] = ((vectorSegmentationTempCount-6)/2)-gapStart+gapEnd+1;
                                        
                                        gapStart = -1;
                                        gapEnd = -1;
                                        gapFlag = 0;
                                    }
                                }
                                
                                if (continuityCount [counter3] != 0 && contFlag == 0){
                                    contFlag = 1;
                                    contStart = counter3;
                                }
                                else if (continuityCount [counter3] != 0 && contFlag == 1) contEnd = counter3;
                                else if (continuityCount [counter3] == 0 && contFlag == 1){
                                    if (contEnd > contStart){
                                        for (int counter4 = contStart; counter4 <= contEnd; counter4++) continuityCount [counter4] = contEnd-contStart+1;
                                        
                                        contStart = -1;
                                        contEnd = -1;
                                        contFlag = 0;
                                    }
                                    
                                    if (contEnd < contStart && contEnd != -1){
                                        for (int counter4 = contStart; counter4 < (vectorSegmentationTempCount-6)/2; counter4++) continuityCount [counter4] = ((vectorSegmentationTempCount-6)/2)-contStart+contEnd+1;
                                        for (int counter4 = 0; counter4 <= contEnd; counter4++) continuityCount [counter4] = ((vectorSegmentationTempCount-6)/2)-contStart+contEnd+1;
                                        
                                        contStart = -1;
                                        contEnd = -1;
                                        contFlag = 0;
                                    }
                                }
                            }
                        }
                        
                        for (int counter3 = 0; counter3 <= (vectorSegmentationTempCount-6)/2; counter3++){
                            if (continuityCount [counter3] == 1000) continuityCount [counter3] = 1;
                        }
                        
                        //for (int counterA = 0; counterA < (vectorSegmentationTempCount-2)/2; counterA++){
                        //	cout<<" "<<interruptionCount [counterA];
                        //}
                        
                        //for (int counterA = 0; counterA < (vectorSegmentationTempCount-2)/2; counterA++){
                        //	cout<<" "<<continuityCount [counterA];
                        //}
                        
                        //cout<<mappingPosition [counter2][0]<<" "<<mappingPosition [counter2][1]<<" MapPosition"<<endl;
                        
                        //------End less than 3 continuity, over 4 gaps remove, if there are start or end blocks with continuity of less than 3, these will be removed------
                        if (mappingPosition [counter2][0] < mappingPosition [counter2][1]){
                            do{
                                
                                completionFlag = 0;
                                
                                if (continuityCount [mappingPosition [counter2][0]] == 2 && interruptionCount [mappingPosition [counter2][0]+2] > 4){
                                    interruptSet = interruptionCount [mappingPosition [counter2][0]+2];
                                    
                                    for (int counter3 = mappingPosition [counter2][0]; counter3 <= mappingPosition [counter2][0]+2+interruptSet-1; counter3++){
                                        continuityCount [counter3] = 0;
                                        interruptionCount [counter3] = 0;
                                    }
                                    
                                    mappingPosition [counter2][0] = mappingPosition [counter2][0]+2+interruptSet;
                                    completionFlag = 1;
                                }
                                else if (continuityCount [mappingPosition [counter2][0]] == 3 && interruptionCount [mappingPosition [counter2][0]+3] > 4){
                                    interruptSet = interruptionCount [mappingPosition [counter2][0]+3];
                                    
                                    for (int counter3 = mappingPosition [counter2][0]; counter3 <= mappingPosition [counter2][0]+3+interruptSet-1; counter3++){
                                        continuityCount [counter3] = 0;
                                        interruptionCount [counter3] = 0;
                                    }
                                    
                                    mappingPosition [counter2][0] = mappingPosition [counter2][0]+3+interruptSet;
                                    completionFlag = 1;
                                }
                                
                                if (continuityCount [mappingPosition [counter2][1]] == 2 && interruptionCount [mappingPosition [counter2][1]-2] > 4){
                                    interruptSet = interruptionCount [mappingPosition [counter2][1]-2];
                                    
                                    for (int counter3 = mappingPosition [counter2][1]; counter3 >= mappingPosition [counter2][1]-1-interruptSet; counter3 = counter3-1){
                                        continuityCount [counter3] = 0;
                                        interruptionCount [counter3] = 0;
                                    }
                                    
                                    mappingPosition [counter2][1] = mappingPosition [counter2][1]-2-interruptSet;
                                    completionFlag = 1;
                                }
                                else if (continuityCount [mappingPosition [counter2][1]] == 3 && interruptionCount [mappingPosition [counter2][1]-3] > 4){
                                    interruptSet = interruptionCount [mappingPosition [counter2][1]-3];
                                    
                                    for (int counter3 = mappingPosition [counter2][1]; counter3 >= mappingPosition [counter2][1]-2-interruptSet; counter3 = counter3-1){
                                        continuityCount [counter3] = 0;
                                        interruptionCount [counter3] = 0;
                                    }
                                    
                                    mappingPosition [counter2][1] = mappingPosition [counter2][1]-3-interruptSet;
                                    completionFlag = 1;
                                }
                                
                            } while (completionFlag == 1);
                        }
                        else if (mappingPosition [counter2][0] > mappingPosition [counter2][1]){
                            do{
                                
                                completionFlag = 0;
                                interruptionTemp = 0;
                                
                                if (continuityCount [mappingPosition [counter2][0]] == 2 && interruptionCount [mappingPosition [counter2][0]+2] > 4){
                                    interruptSet = interruptionCount [mappingPosition [counter2][0]+2];
                                    
                                    for (int counter3 = mappingPosition [counter2][0]; counter3 <= mappingPosition [counter2][0]+2+interruptSet-1; counter3++){
                                        continuityCount [counter3] = 0;
                                        interruptionCount [counter3] = 0;
                                    }
                                    
                                    mappingPosition [counter2][0] = mappingPosition [counter2][0]+2+interruptSet;
                                    completionFlag = 1;
                                }
                                else if (continuityCount [mappingPosition [counter2][0]] == 3 && interruptionCount [mappingPosition [counter2][0]+3] > 4){
                                    interruptSet = interruptionCount [mappingPosition [counter2][0]+3];
                                    
                                    for (int counter3 = mappingPosition [counter2][0]; counter3 <= mappingPosition [counter2][0]+3+interruptSet-1; counter3++){
                                        continuityCount [counter3] = 0;
                                        interruptionCount [counter3] = 0;
                                    }
                                    
                                    mappingPosition [counter2][0] = mappingPosition [counter2][0]+3+interruptSet;
                                    completionFlag = 1;
                                }
                                
                                if (continuityCount [mappingPosition [counter2][1]] == 2){
                                    if (mappingPosition [counter2][1]-2 >= 0) interruptionTemp = interruptionCount [mappingPosition [counter2][1]-2];
                                    
                                    if (mappingPosition [counter2][1]-2 == -1) interruptionTemp = interruptionCount [(vectorSegmentationTempCount-6)/2-1];
                                    
                                    if (mappingPosition [counter2][1]-2 == -2) interruptionTemp = interruptionCount [(vectorSegmentationTempCount-6)/2-2];
                                    
                                    if (interruptionTemp > 4){
                                        totalDeletion = 2+interruptionTemp;
                                        
                                        if (mappingPosition [counter2][1]-(totalDeletion-1) >= 0){
                                            for (int counter3 = mappingPosition [counter2][1]; counter3 >= mappingPosition [counter2][1]-(totalDeletion-1); counter3 = counter3-1){
                                                continuityCount [counter3] = 0;
                                                interruptionCount [counter3] = 0;
                                            }
                                            
                                            completionFlag = 1;
                                            
                                            if (mappingPosition [counter2][1]-(totalDeletion-1) > 0) mappingPosition [counter2][1] = mappingPosition [counter2][1]-2-interruptionTemp;
                                            else if (mappingPosition [counter2][1]-(totalDeletion-1) == 0) mappingPosition [counter2][1] = (vectorSegmentationTempCount-6)/2-1;
                                        }
                                        else if ((totalDeletion-1)-mappingPosition [counter2][1] < 0){
                                            for (int counter3 = mappingPosition [counter2][1]; counter3 >= 0; counter3 = counter3-1){
                                                continuityCount [counter3] = 0;
                                                interruptionCount [counter3] = 0;
                                            }
                                            for (int counter3 = (vectorSegmentationTempCount-6)/2-1; counter3 > (vectorSegmentationTempCount-6)/2-1-(totalDeletion-(mappingPosition [counter2][1]+1)); counter3 = counter3-1){
                                                continuityCount [counter3] = 0;
                                                interruptionCount [counter3] = 0;
                                            }
                                            
                                            int positionTemp = (vectorSegmentationTempCount-6)/2-1-(totalDeletion-(mappingPosition [counter2][1]+1));
                                            completionFlag = 1;
                                            mappingPosition [counter2][1] = positionTemp;
                                        }
                                    }
                                }
                                else if (continuityCount [mappingPosition [counter2][1]] == 3){
                                    if (mappingPosition [counter2][1]-3 >= 0) interruptionTemp = interruptionCount [mappingPosition [counter2][1]-3];
                                    
                                    if (mappingPosition [counter2][1]-3 == -1) interruptionTemp = interruptionCount [(vectorSegmentationTempCount-6)/2-1];
                                    
                                    if (mappingPosition [counter2][1]-3 == -2) interruptionTemp = interruptionCount [(vectorSegmentationTempCount-6)/2-2];
                                    
                                    if (mappingPosition [counter2][1]-3 == -3) interruptionTemp = interruptionCount [(vectorSegmentationTempCount-6)/2-3];
                                    
                                    if (interruptionTemp > 4){
                                        totalDeletion = 3+interruptionTemp;
                                        
                                        if (mappingPosition [counter2][1]-(totalDeletion-1) >= 0){
                                            for (int counter3 = mappingPosition [counter2][1]; counter3 >= mappingPosition [counter2][1]-(totalDeletion-1); counter3 = counter3-1){
                                                continuityCount [counter3] = 0;
                                                interruptionCount [counter3] = 0;
                                            }
                                            
                                            completionFlag = 1;
                                            
                                            if (mappingPosition [counter2][1]-(totalDeletion-1) > 0) mappingPosition [counter2][1] = mappingPosition [counter2][1]-3-interruptionTemp;
                                            else if (mappingPosition [counter2][1]-(totalDeletion-1) == 0) mappingPosition [counter2][1] = (vectorSegmentationTempCount-6)/2-1;
                                        }
                                        else if ((totalDeletion-1)-mappingPosition [counter2][1] < 0){
                                            for (int counter3 = mappingPosition [counter2][1]; counter3 >= 0; counter3 = counter3-1){
                                                continuityCount [counter3] = 0;
                                                interruptionCount [counter3] = 0;
                                            }
                                            for (int counter3 = (vectorSegmentationTempCount-6)/2-1; counter3 > (vectorSegmentationTempCount-6)/2-1-(totalDeletion-(mappingPosition [counter2][1]+1)); counter3 = counter3-1){
                                                continuityCount [counter3] = 0;
                                                interruptionCount [counter3] = 0;
                                            }
                                            
                                            int positionTemp = (vectorSegmentationTempCount-6)/2-1-(totalDeletion-(mappingPosition [counter2][1]+1));
                                            completionFlag = 1;
                                            mappingPosition [counter2][1] = positionTemp;
                                        }
                                    }
                                }
                                
                            } while (completionFlag == 1);
                        }
                        
                        //for (int counterA = 0; counterA < (vectorSegmentationTempCount-2)/2; counterA++){
                        //	cout<<" "<<interruptionCount [counterA];
                        //}
                        
                        //for (int counterA = 0; counterA < (vectorSegmentationTempCount-2)/2; counterA++){
                        //	cout<<" "<<continuityCount [counterA];
                        //}
                        
                        //cout<<mappingPosition [counter2][0]<<" "<<mappingPosition [counter2][1]<<" MapPosition"<<endl;
                        
                        //for (int counterA = 0; counterA < (vectorSegmentationTempCount-2)/2; counterA++){
                        //	for (int counterB = 0; counterB < 21; counterB++) cout<<" "<<totalMap [counterA][counterB];
                        //	cout<<" totalMap "<<counterA<<endl;
                        //}
                        
                        //------Internal Gap Check, if internal gap exist, and it is larger than 6, up or down stream blocks of gaps (core block is the centre), will be removed ------
                        if (mappingPosition [counter2][0] < mappingPosition [counter2][1]){
                            do{
                                
                                completionFlag = 0;
                                coreStart = counter2;
                                
                                for (int counter3 = counter2; counter3 >= mappingPosition [counter2][0]; counter3 = counter3-1){
                                    if (continuityCount [counter3] != 0) coreStart = counter3;
                                    else{
                                        
                                        completionFlag = 0;
                                        break;
                                    }
                                }
                                
                                for (int counter3 = mappingPosition [counter2][0]; counter3 <= mappingPosition [counter2][1]; counter3++){
                                    firstCont = continuityCount [counter3];
                                    
                                    if (counter3+firstCont > mappingPosition [counter2][1]){
                                        completionFlag = 0;
                                        break;
                                    }
                                    
                                    gapFirst = interruptionCount [counter3+firstCont];
                                    completionFlag = 1;
                                    
                                    if (gapFirst >= 4){
                                        if ((counter3 == coreStart && firstCont <= gapFirst) || (counter3 == coreStart && gapFirst >= 6)){
                                            for (int counter4 = counter3+firstCont; counter4 <= mappingPosition [counter2][1]; counter4++){
                                                continuityCount [counter4] = 0;
                                                interruptionCount [counter4] = 0;
                                            }
                                            
                                            mappingPosition [counter2][1] = counter3+firstCont-1;
                                            completionFlag = 0;
                                            break;
                                        }
                                        else if ((counter3 < coreStart && gapFirst >= 6) || (counter3 < coreStart && gapFirst < 6 && firstCont <= gapFirst)){
                                            for (int counter4 = counter3; counter4 <= counter3+firstCont+gapFirst-1; counter4++){
                                                continuityCount [counter4] = 0;
                                                interruptionCount [counter4] = 0;
                                            }
                                            
                                            mappingPosition [counter2][0] = counter3+firstCont+gapFirst;
                                            counter3 = counter3+firstCont+gapFirst-1;
                                        }
                                        else if ((counter3 > coreStart && gapFirst >= 6) || (counter3 > coreStart && gapFirst < 6 && firstCont <= gapFirst)){
                                            for (int counter4 = counter3+firstCont+gapFirst; counter4 <= mappingPosition [counter2][1]; counter4++){
                                                continuityCount [counter4] = 0;
                                                interruptionCount [counter4] = 0;
                                            }
                                            
                                            mappingPosition [counter2][1] = counter3+firstCont-1;
                                            completionFlag = 0;
                                            break;
                                        }
                                        else{
                                            
                                            counter3 = counter3+firstCont+gapFirst-1;
                                            
                                            if (counter3 >= mappingPosition [counter2][1]) completionFlag = 0;
                                        }
                                    }
                                    else{
                                        
                                        counter3 = counter3+firstCont+gapFirst-1;
                                        
                                        if (counter3 >= mappingPosition [counter2][1]) completionFlag = 0;
                                    }
                                }
                                
                            } while (completionFlag == 1);
                        }
                        
                        //for (int counterA = 0; counterA < (vectorSegmentationTempCount-2)/2; counterA++){
                        //	cout<<" "<<interruptionCount [counterA];
                        //}
                        
                        if (mappingPosition [counter2][0] > mappingPosition [counter2][1]){
                            do{
                                
                                completionFlag = 0;
                                gapFirst = 0;
                                coreStart = counter2;
                                
                                for (int counter3 = counter2-1; counter3 >= mappingPosition [counter2][0]; counter3 = counter3-1){
                                    if (continuityCount [counter3] != 0){
                                        coreStart = counter3;
                                        completionFlag = 0;
                                    }
                                    else{
                                        
                                        completionFlag = 0;
                                        break;
                                    }
                                }
                                
                                for (int counter3 = mappingPosition [counter2][0]; counter3 < (vectorSegmentationTempCount-6)/2; counter3++){
                                    firstCont = continuityCount [counter3];
                                    
                                    if ((counter3+firstCont >= (vectorSegmentationTempCount-6)/2 && firstCont-(((vectorSegmentationTempCount-6)/2-1)-counter3+1) > mappingPosition [counter2][1]) || (counter3+firstCont > mappingPosition [counter2][0] && counter3+firstCont < mappingPosition [counter2][1])){
                                        completionFlag = 0;
                                        break;
                                    }
                                    
                                    if (counter3+firstCont < (vectorSegmentationTempCount-6)/2) gapFirst = interruptionCount [counter3+firstCont];
                                    
                                    if (counter3+firstCont >= (vectorSegmentationTempCount-6)/2) gapFirst = interruptionCount [firstCont-(((vectorSegmentationTempCount-6)/2-1)-counter3+1)];
                                    
                                    completionFlag = 1;
                                    
                                    if (gapFirst >= 4){
                                        if ((counter3 == coreStart && firstCont <= gapFirst) || (counter3 == coreStart && gapFirst >= 6)){
                                            for (int counter4 = counter3+firstCont; counter4 < (vectorSegmentationTempCount-6)/2; counter4++){
                                                continuityCount [counter4] = 0;
                                                interruptionCount [counter4] = 0;
                                            }
                                            
                                            for (int counter4 = 0; counter4 <= mappingPosition [counter2][1]; counter4++){
                                                continuityCount [counter4] = 0;
                                                interruptionCount [counter4] = 0;
                                            }
                                            
                                            if (counter3+firstCont < (vectorSegmentationTempCount-6)/2){
                                                mappingPosition [counter2][1] = counter3+firstCont-1;
                                                completionFlag = 0;
                                                break;
                                            }
                                            
                                            if (counter3+firstCont >= (vectorSegmentationTempCount-6)/2){
                                                int positionTemp = firstCont-(((vectorSegmentationTempCount-6)/2-1)-counter3+1)-1;
                                                
                                                if (positionTemp < 0) mappingPosition [counter2][1] = (vectorSegmentationTempCount-6)/2-(positionTemp*-1);
                                                else mappingPosition [counter2][1] = positionTemp;
                                                
                                                completionFlag = 0;
                                                break;
                                            }
                                        }
                                        else if ((counter3 < coreStart && coreStart >= mappingPosition [counter2][0] && gapFirst >= 6) || (counter3 < coreStart && coreStart >= mappingPosition [counter2][0] && gapFirst < 6 && firstCont <= gapFirst)){
                                            for (int counter4 = counter3; counter4 <= counter3+firstCont+gapFirst-1; counter4++){
                                                continuityCount [counter4] = 0;
                                                interruptionCount [counter4] = 0;
                                            }
                                            
                                            mappingPosition [counter2][0] = counter3+firstCont+gapFirst;
                                            counter3 = counter3+firstCont+gapFirst-1;
                                        }
                                        else if ((counter3 > coreStart && coreStart < (vectorSegmentationTempCount-6)/2 && gapFirst >= 6) || (counter3 > coreStart && coreStart < (vectorSegmentationTempCount-6)/2 && gapFirst < 6 && firstCont <= gapFirst)){
                                            if (counter3+firstCont < (vectorSegmentationTempCount-6)/2){
                                                for (int counter4 = counter3+firstCont; counter4 < (vectorSegmentationTempCount-6)/2; counter4++){
                                                    continuityCount [counter4] = 0;
                                                    interruptionCount [counter4] = 0;
                                                }
                                                
                                                for (int counter4 = 0; counter4 <= mappingPosition [counter2][1]; counter4++){
                                                    continuityCount [counter4] = 0;
                                                    interruptionCount [counter4] = 0;
                                                }
                                                
                                                if (counter3+firstCont-1 < 0) mappingPosition [counter2][1] = (vectorSegmentationTempCount-6)/2-((counter3+firstCont-1)*-1);
                                                else mappingPosition [counter2][1] = counter3+firstCont-1;
                                                
                                                completionFlag = 0;
                                                break;
                                            }
                                            else if (counter3+firstCont >= (vectorSegmentationTempCount-6)/2){
                                                for (int counter4 = firstCont-(((vectorSegmentationTempCount-6)/2-1)-counter3+1); counter4 <= mappingPosition [counter2][1]; counter4++){
                                                    continuityCount [counter4] = 0;
                                                    interruptionCount [counter4] = 0;
                                                }
                                                
                                                if (firstCont-(((vectorSegmentationTempCount-6)/2-1)-counter3+1)-1 < 0) mappingPosition [counter2][1] = (vectorSegmentationTempCount-6)/2-((firstCont-(((vectorSegmentationTempCount-6)/2-1)-counter3+1)-1)*-1);
                                                else mappingPosition [counter2][1] = firstCont-(((vectorSegmentationTempCount-6)/2-1)-counter3+1)-1;
                                                
                                                completionFlag = 0;
                                                break;
                                            }
                                        }
                                        else{
                                            
                                            counter3 = counter3+firstCont+gapFirst-1;
                                            
                                            if (counter3+1 >= (vectorSegmentationTempCount-6)/2){
                                                for (int counter4 = (counter3+1)-(vectorSegmentationTempCount-6)/2; counter4 < mappingPosition [counter2][1]; counter4++){
                                                    firstCont2 = continuityCount [counter4];
                                                    
                                                    if (counter4+firstCont2 > mappingPosition [counter2][1]){
                                                        completionFlag = 0;
                                                        break;
                                                    }
                                                    
                                                    gapFirst2 = interruptionCount [counter4+firstCont2];
                                                    
                                                    if (gapFirst2 >= 4){
                                                        if ((counter4 == coreStart && firstCont2 <= gapFirst2) || (counter4 == coreStart && gapFirst2 >= 6)){
                                                            for (int counter5 = counter4+firstCont2; counter5 <= mappingPosition [counter2][1]; counter5++){
                                                                continuityCount [counter5] = 0;
                                                                interruptionCount [counter5] = 0;
                                                            }
                                                            
                                                            if (counter4+firstCont2-1 < 0) mappingPosition [counter2][1] = (vectorSegmentationTempCount-6)/2-((counter4+firstCont2-1)*-1);
                                                            else mappingPosition [counter2][1] = counter4+firstCont2-1;
                                                            
                                                            completionFlag = 0;
                                                            break;
                                                        }
                                                        else if ((counter4 > coreStart && coreStart < mappingPosition [counter2][1] && gapFirst >= 6) || (counter4 > coreStart && coreStart < mappingPosition [counter2][1] && gapFirst2 < 6 && firstCont2 <= gapFirst2)){
                                                            for (int counter5 = counter4+firstCont2+gapFirst2; counter5 <= mappingPosition [counter2][1]; counter5++){
                                                                continuityCount [counter5] = 0;
                                                                interruptionCount [counter5] = 0;
                                                            }
                                                            
                                                            if (counter4+firstCont2-1 < 0) mappingPosition [counter2][1] = (vectorSegmentationTempCount-6)/2-((counter4+firstCont2-1)*-1);
                                                            else mappingPosition [counter2][1] = counter4+firstCont2-1;
                                                            
                                                            completionFlag = 0;
                                                            break;
                                                        }
                                                        else{
                                                            
                                                            counter4 = counter4+firstCont2+gapFirst2-1;
                                                            
                                                            if (counter4 > mappingPosition [counter2][1]) completionFlag = 0;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else{
                                        
                                        counter3 = counter3+firstCont+gapFirst-1;
                                        
                                        if (counter3+1 >= (vectorSegmentationTempCount-6)/2){
                                            for (int counter4 = (counter3+1)-(vectorSegmentationTempCount-6)/2; counter4 < mappingPosition [counter2][1]; counter4++){
                                                firstCont2 = continuityCount [counter4];
                                                
                                                if (counter4+firstCont2 > mappingPosition [counter2][1]){
                                                    completionFlag = 0;
                                                    break;
                                                }
                                                
                                                gapFirst2 = interruptionCount [counter4+firstCont2];
                                                
                                                if (gapFirst2 >= 4){
                                                    if ((counter4 == coreStart && firstCont2 <= gapFirst2) || (counter4 == coreStart && gapFirst2 >= 6)){
                                                        for (int counter5 = counter4+firstCont2; counter5 <= mappingPosition [counter2][1]; counter5++){
                                                            continuityCount [counter5] = 0;
                                                            interruptionCount [counter5] = 0;
                                                        }
                                                        
                                                        if (counter4+firstCont2-1 < 0) mappingPosition [counter2][1] = (vectorSegmentationTempCount-6)/2-((counter4+firstCont2-1)*-1);
                                                        else mappingPosition [counter2][1] = counter4+firstCont2-1;
                                                        
                                                        completionFlag = 0;
                                                        break;
                                                    }
                                                    else if ((counter4 > coreStart && coreStart < mappingPosition [counter2][1] && gapFirst >= 6) || (counter4 > coreStart && coreStart < mappingPosition [counter2][1] && gapFirst2 < 6 && firstCont2 <= gapFirst2)){
                                                        for (int counter5 = counter4+firstCont2+gapFirst2; counter5 <= mappingPosition [counter2][1]; counter5++){
                                                            continuityCount [counter5] = 0;
                                                            interruptionCount [counter5] = 0;
                                                        }
                                                        
                                                        if (counter4+firstCont2-1 < 0) mappingPosition [counter2][1] = (vectorSegmentationTempCount-6)/2-((counter4+firstCont2-1)*-1);
                                                        else mappingPosition [counter2][1] = counter4+firstCont2-1;
                                                        
                                                        completionFlag = 0;
                                                        break;
                                                    }
                                                    else{
                                                        
                                                        counter4 = counter4+firstCont2+gapFirst2-1;
                                                        
                                                        if (counter4 >= mappingPosition [counter2][1]) completionFlag = 0;
                                                    }
                                                }
                                                else{
                                                    
                                                    counter4 = counter4+firstCont2+gapFirst2-1;
                                                    
                                                    if (counter4 >= mappingPosition [counter2][1]) completionFlag = 0;
                                                }
                                            }
                                        }
                                    }
                                }
                                
                            } while (completionFlag == 1);
                        }
                        
                        //for (int counterA = 0; counterA < (vectorSegmentationTempCount-2)/2; counterA++){
                        //	cout<<" "<<interruptionCount [counterA];
                        //}
                        //	cout<<" interruptionCount "<<endl;
                        
                        //for (int counterA = 0; counterA < (vectorSegmentationTempCount-2)/2; counterA++){
                        //	cout<<" "<<continuityCount [counterA];
                        //}
                        //	cout<<" continuityCount "<<endl;
                        
                        //cout<<mappingPosition [counter2][0]<<" "<<mappingPosition [counter2][1]<<" MapPosition"<<endl;
                        
                        //------Linear line creation, fill all gaps------
                        angleTemp = 0;
                        processON = 0;
                        
                        if (mappingPosition [counter2][0] < mappingPosition [counter2][1]){
                            for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-6)/2; counter3++){
                                if (counter3 == mappingPosition [counter2][0]){
                                    angleTemp = angleMap [counter2][counter3];
                                    totalMap [counter2][counter3] = 2;
                                    processON = 1;
                                }
                                else if (counter3 == mappingPosition [counter2][1]){
                                    angleMap [counter2][counter3] = angleTemp;
                                    totalMap [counter2][counter3] = 3;
                                    processON = 0;
                                }
                                else{
                                    
                                    if (processON == 1){
                                        angleMap [counter2][counter3] = angleTemp;
                                        totalMap [counter2][counter3] = 1;
                                    }
                                    
                                    if (processON == 0){
                                        angleMap [counter2][counter3] = 300;
                                        totalMap [counter2][counter3] = 0;
                                    }
                                }
                            }
                        }
                        if (mappingPosition [counter2][0] > mappingPosition [counter2][1]){
                            angleTemp = angleMap [counter2][counter2];
                            
                            for (int counter3 = mappingPosition [counter2][0]; counter3 < (vectorSegmentationTempCount-6)/2; counter3++){
                                if (counter3 == mappingPosition [counter2][0]){
                                    angleMap [counter2][counter3] = angleTemp;
                                    totalMap [counter2][counter3] = 2;
                                    processON = 1;
                                }
                                else if (processON == 1){
                                    angleMap [counter2][counter3] = angleTemp;
                                    totalMap [counter2][counter3] = 1;
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < mappingPosition [counter2][0]-1; counter3++){
                                if (counter3 == mappingPosition [counter2][1]){
                                    angleMap [counter2][counter3] = angleTemp;
                                    totalMap [counter2][counter3] = 3;
                                    processON = 0;
                                }
                                else{
                                    
                                    if (processON == 1){
                                        angleMap [counter2][counter3] = angleTemp;
                                        totalMap [counter2][counter3] = 1;
                                    }
                                    
                                    if (processON == 0){
                                        angleMap [counter2][counter3] = 300;
                                        totalMap [counter2][counter3] = 0;
                                    }
                                }
                            }
                        }
                        
                        delete [] interruptionCount;
                        delete [] continuityCount;
                    }
                    
                    //for (int counterA = 0; counterA < (vectorSegmentationTempCount-2)/2; counterA++){
                    //	for (int counterB = 0; counterB < 21; counterB++) cout<<" "<<totalMap [counterA][counterB];
                    //	cout<<" totalMap "<<counterA<<endl;
                    //}
                    
                    //------Angle Match, angle of each line will be checked, if the angle is within -+ 5 degree, combined lines------
                    startSubject = -1;
                    startRef2 = -1;
                    
                    defTempMap = (vectorSegmentationTempCount-6)/2;
                    int *tempMap = new int [defTempMap];
                    
                    for (int counter2 = 0; counter2 < (vectorSegmentationTempCount-6)/2; counter2++) tempMap [counter2] = 0;
                    
                    for (int counter2 = 0; counter2 < (vectorSegmentationTempCount-6)/2; counter2++){
                        if (totalMap [counter2][0] != -1){
                            for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-6)/2; counter3++){
                                if (totalMap [counter2][counter3] == 2) startSubject = counter3;
                                
                                tempMap [counter3] = totalMap [counter2][counter3];
                            }
                            
                            angleOV = angleMap [counter2][startSubject];
                            
                            for (int counter3 = counter2; counter3 < (vectorSegmentationTempCount-6)/2; counter3++){
                                if (counter3 != counter2 && totalMap [counter3][0] != -1){
                                    noMatchFlag = 0;
                                    cutOffA = 0;
                                    cutOffB = 0;
                                    cutOffC = 0;
                                    caseType2 = 0;
                                    
                                    for (int counter4 = 0; counter4 < (vectorSegmentationTempCount-6)/2; counter4++){
                                        if (totalMap [counter3][counter4] == 2) startRef2 = counter4;
                                        
                                        if (tempMap [counter4] != 0 && totalMap [counter3][counter4] != 0) noMatchFlag = 1;
                                    }
                                    
                                    angleRef = angleMap [counter3][startRef2];
                                    
                                    if (noMatchFlag == 1){
                                        if (angleOV < 160 && angleOV > -160){
                                            cutOffA = angleOV-5;
                                            cutOffB = angleOV+5;
                                            cutOffC = 0;
                                            caseType2 = 1;
                                        }
                                        else if (angleOV >= 160){
                                            cutOffA = angleOV-5;
                                            cutOffB = 180;
                                            cutOffC = (180-(angleOV+5-180))*-1;
                                            caseType2 = 2;
                                        }
                                        else if (angleOV <= -160){
                                            cutOffA = 180-(((angleOV-5)+180)*-1);
                                            cutOffB = 180;
                                            cutOffC = angleOV+5;
                                            caseType2 = 2;
                                        }
                                        else if (angleOV == 180){
                                            cutOffA = 160;
                                            cutOffB = 180;
                                            cutOffC = -160;
                                            caseType2 = 2;
                                        }
                                        
                                        if ((angleRef >= cutOffA && angleRef <= cutOffB && caseType2 == 1) || (((angleRef >= cutOffA && angleRef <= cutOffB) || (angleRef > cutOffB*-1 && angleRef <= cutOffC)) && caseType2 == 2)){
                                            firstAppear2 = 0;
                                            lastAppear3 = 0;
                                            
                                            for (int counter4 = 0; counter4 < (vectorSegmentationTempCount-6)/2; counter4++){
                                                if (totalMap [counter3][counter4] != 0) totalMap [counter2][counter4] = totalMap [counter3][counter4];
                                                
                                                if (counter4 == 0){
                                                    totalMap [counter3][counter4] = -1;
                                                    angleMap [counter3][counter4] = 300;
                                                }
                                                else{
                                                    
                                                    totalMap [counter3][counter4] = 0;
                                                    angleMap [counter3][counter4] = 300;
                                                }
                                            }
                                            
                                            if (totalMap [counter2][(vectorSegmentationTempCount-6)/2-1] != 0 && totalMap [counter2][0] != 0){
                                                for (int counter4 = (vectorSegmentationTempCount-6)/2-1; counter4 >= 0; counter4 = counter4-1){
                                                    if (totalMap [counter2][counter4] == 0 && firstAppear2 == 0){
                                                        totalMap [counter2][counter4+1] = 2;
                                                        firstAppear2 = 1;
                                                        break;
                                                    }
                                                    else if (totalMap [counter2][counter4] != 0 && firstAppear2 == 0) totalMap [counter2][counter4] = 1;
                                                }
                                                
                                                if (firstAppear2 == 0) totalMap [counter2][0] = 2;
                                                
                                                for (int counter4 = 0; counter4 < (vectorSegmentationTempCount-6)/2; counter4++){
                                                    if (totalMap [counter2][counter4] == 0 && lastAppear3 == 0){
                                                        totalMap [counter2][counter4-1] = 3;
                                                        lastAppear3 = 1;
                                                        break;
                                                    }
                                                    else if (totalMap [counter2][counter4] != 0 && lastAppear3 == 0) totalMap [counter2][counter4] = 1;
                                                }
                                                
                                                if (lastAppear3 == 0) totalMap [counter2][(vectorSegmentationTempCount-6)/2-1] = 2;
                                            }
                                            else{
                                                
                                                for (int counter4 = 0; counter4 < (vectorSegmentationTempCount-6)/2; counter4++){
                                                    if (totalMap [counter2][counter4] != 0 && firstAppear2 == 0){
                                                        totalMap [counter2][counter4] = 2;
                                                        firstAppear2 = 1;
                                                    }
                                                    else if (totalMap [counter2][counter4] != 0 && firstAppear2 == 1) totalMap [counter2][counter4] = 1;
                                                    else if (totalMap [counter2][counter4] == 0 && firstAppear2 == 1){
                                                        totalMap [counter2][counter4-1] = 3;
                                                        lastAppear3 = 1;
                                                        break;
                                                    }
                                                }
                                                
                                                if (lastAppear3 == 0) totalMap [counter2][(vectorSegmentationTempCount-6)/2-1] = 3;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    delete [] tempMap;
                    
                    //for (int counterA = 0; counterA < (vectorSegmentationTempCount-2)/2; counterA++){
                    //	for (int counterB = 0; counterB < 21; counterB++) cout<<" "<<totalMap [counterA][counterB];
                    //	cout<<" totalMap "<<counterA<<endl;
                    //}
                    
                    //------OverLap removal, if one line is completely overlapped with others, these will be removed, removed lines are marked -1 (position 0)------
                    startSubject = -1;
                    endSubject = -1;
                    
                    for (int counter2 = 0; counter2 < (vectorSegmentationTempCount-6)/2; counter2++){
                        if (totalMap [counter2][0] != -1){
                            for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-6)/2; counter3++){
                                if (totalMap [counter2][counter3] == 2) startSubject = counter3;
                                
                                if (totalMap [counter2][counter3] == 3) endSubject = counter3;
                            }
                            
                            for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-6)/2; counter3++){
                                if (startSubject < endSubject && counter3 != counter2){
                                    noMatchFlag = 0;
                                    
                                    for (int counter4 = startSubject; counter4 <= endSubject; counter4++){
                                        if (totalMap [counter3][counter4] == 0) noMatchFlag = 1;
                                    }
                                    
                                    if (noMatchFlag == 0){
                                        for (int counter4 = startSubject; counter4 <= endSubject; counter4++) totalMap [counter2][counter4] = 0;
                                        
                                        totalMap [counter2][0] = -1;
                                        break;
                                    }
                                }
                                
                                if (startSubject > endSubject && counter3 != counter2){
                                    noMatchFlag = 0;
                                    
                                    for (int counter4 = startSubject; counter4 < (vectorSegmentationTempCount-6)/2; counter4++){
                                        if (totalMap [counter3][counter4] == 0) noMatchFlag = 1;
                                    }
                                    
                                    for (int counter4 = 0; counter4 <= endSubject; counter4++){
                                        if (totalMap [counter3][counter4] == 0) noMatchFlag = 1;
                                    }
                                    
                                    if (noMatchFlag == 0){
                                        for (int counter4 = startSubject; counter4 < (vectorSegmentationTempCount-6)/2; counter4++) totalMap [counter2][counter4] = 0;
                                        for (int counter4 = 0; counter4 <= endSubject; counter4++) totalMap [counter2][counter4] = 0;
                                        
                                        totalMap [counter2][0] = -1;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < (vectorSegmentationTempCount-2)/2; counterA++){
                    //	for (int counterB = 0; counterB < 21; counterB++) cout<<" "<<totalMap [counterA][counterB];
                    //	cout<<" totalMap "<<counterA<<endl;
                    //}
                    
                    //------Start and End determination, starting and end point are determined, overlapped points will be identified, then centre is calculated to determine the start and end points------
                    first2 = 0;
                    veryFirst2 = 0;
                    veryFirst2Flag = 0;
                    firstLineEnd = -1;
                    secondLineStart = -1;
                    first2Flag = 0;
                    
                    for (int counter2 = 0; counter2 <= (vectorSegmentationTempCount-6)/2; counter2++){
                        for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-6)/2; counter3++){
                            if (totalMap [counter3][counter2] == 2 && first2Flag == 0){
                                first2 = counter3;
                                first2Flag = 1;
                                
                                if (veryFirst2Flag == 0){
                                    veryFirst2Flag = 1;
                                    veryFirst2 = counter3;
                                }
                            }
                            else{
                                
                                if (counter2 == (vectorSegmentationTempCount-6)/2) counter3 = veryFirst2;
                                
                                if ((totalMap [counter3][counter2] == 2 && first2Flag == 1) || counter2 == (vectorSegmentationTempCount-6)/2){
                                    second2 = counter3;
                                    
                                    for (int counter4 = 0; counter4 < (vectorSegmentationTempCount-6)/2; counter4++){
                                        if (totalMap [first2][counter4] == 3){
                                            firstLineEnd = counter4;
                                            break;
                                        }
                                    }
                                    
                                    for (int counter4 = 0; counter4 < (vectorSegmentationTempCount-6)/2; counter4++){
                                        if (totalMap [second2][counter4] == 2){
                                            secondLineStart = counter4;
                                            break;
                                        }
                                    }
                                    
                                    if (firstLineEnd > secondLineStart){
                                        adjustedContactPoint = secondLineStart+(firstLineEnd-secondLineStart)/2;
                                        startEndMap [first2][adjustedContactPoint] = 3;
                                        startEndMap [second2][adjustedContactPoint] = 2;
                                    }
                                    
                                    if (firstLineEnd < secondLineStart){
                                        adjustedContactPoint = secondLineStart+((((vectorSegmentationTempCount-6)/2-1)-secondLineStart)+firstLineEnd)/2;
                                        
                                        if (adjustedContactPoint > (vectorSegmentationTempCount-6)/2-1){
                                            adjustedContactPoint = adjustedContactPoint-((vectorSegmentationTempCount-6)/2-1)-1;
                                            startEndMap [first2][adjustedContactPoint] = 3;
                                            startEndMap [second2][adjustedContactPoint] = 2;
                                        }
                                        
                                        if (adjustedContactPoint <= (vectorSegmentationTempCount-6)/2-1){
                                            startEndMap [first2][adjustedContactPoint] = 3;
                                            startEndMap [second2][adjustedContactPoint] = 2;
                                        }
                                    }
                                    
                                    first2 = second2;
                                    break;
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < (vectorSegmentationTempCount-6)/2; counterA++){
                    //	for (int counterB = 0; counterB < 21; counterB++) cout<<" "<<startEndMap [counterA][counterB];
                    //	cout<<" startEndMap "<<counterA<<endl;
                    //}
                    
                    //------Data writing into the array------
                    for (int counter2 = 0; counter2 < (vectorSegmentationTempCount-6)/2; counter2++){
                        startSubject = -1;
                        endSubject = -1;
                        
                        for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-6)/2; counter3++){
                            if (startEndMap [counter2][counter3] == 2) startSubject = counter3;
                            if (startEndMap [counter2][counter3] == 3) endSubject = counter3;
                        }
                        
                        if (startSubject != -1 && endSubject != -1){
                            arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = vectorNumber, vectorSegmentationTempCount2++;
                            arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [startSubject*2], vectorSegmentationTempCount2++;
                            arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [startSubject*2+1], vectorSegmentationTempCount2++;
                            arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [endSubject*2], vectorSegmentationTempCount2++;
                            arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = arrayVectorSegmentationTemp [endSubject*2+1], vectorSegmentationTempCount2++;
                        }
                    }
                    
                    //------Re-adjustment: If linear line is away from actual vector, adjust position------
                    countEnd = vectorSegmentationTempCount2;
                    
                    for (int counter2 = 0; counter2 < countEnd; counter2 = counter2+5){
                        startXAd = arrayVectorSegmentationTemp2 [counter2+1];
                        startYAd = arrayVectorSegmentationTemp2 [counter2+2];
                        endXAd = arrayVectorSegmentationTemp2 [counter2+3];
                        endYAd = arrayVectorSegmentationTemp2 [counter2+4];
                        
                        distanceOverCount = 0;
                        distanceMax = 0;
                        crossXMax = 0;
                        crossYMax = 0;
                        startEndFlag = 0;
                        
                        if (endXAd-startXAd == 0) constA = 0;
                        else constA = (endYAd-startYAd)/(double)(endXAd-startXAd);
                        
                        constB = startYAd-constA*startXAd;
                        
                        for (int counter3 = 0; counter3 < (vectorSegmentationTempCount-6)/2; counter3++){
                            if (arrayVectorSegmentationTemp [counter3*2] == startXAd && arrayVectorSegmentationTemp [counter3*2+1] == startYAd && startEndFlag == 0) startEndFlag = 1;
                            else if (arrayVectorSegmentationTemp [counter3*2] == endXAd && arrayVectorSegmentationTemp [counter3*2+1] == endYAd && startEndFlag == 1){
                                break;
                            }
                            else if (startEndFlag == 1){
                                valueXRefAd = arrayVectorSegmentationTemp [counter3*2];
                                valueYRefAd = arrayVectorSegmentationTemp [counter3*2+1];
                                
                                if (endXAd-startXAd == 0) distance = sqrt((startXAd-valueXRefAd)*(startXAd-valueXRefAd));
                                else if (constA == 0) distance = sqrt((startYAd-valueYRefAd)*(startYAd-valueYRefAd));
                                else{
                                    
                                    constC = valueYRefAd-(-1/constA)*valueXRefAd;
                                    crossX = (int)((constC-constB)/(double)(constA+1/constA));
                                    crossY = (int)(constA*crossX+constB);
                                    distance = sqrt((valueXRefAd-crossX)*(valueXRefAd-crossX)+(valueYRefAd-crossY)*(valueYRefAd-crossY));
                                }
                                
                                if (distance >= 6) distanceOverCount++;
                                
                                if (distance > distanceMax){
                                    distanceMax = distance;
                                    crossXMax = valueXRefAd;
                                    crossYMax = valueYRefAd;
                                }
                            }
                            
                            if (counter3 == (vectorSegmentationTempCount-6)/2-1 && startEndFlag == 1){
                                for (int counter4 = 0; counter4 < (vectorSegmentationTempCount-6)/2; counter4++){
                                    if (arrayVectorSegmentationTemp [counter4*2] == endXAd && arrayVectorSegmentationTemp [counter4*2+1] == endYAd && startEndFlag == 1){
                                        startEndFlag = 2;
                                        break;
                                    }
                                    else if (startEndFlag == 1){
                                        valueXRefAd = arrayVectorSegmentationTemp [counter4*2];
                                        valueYRefAd = arrayVectorSegmentationTemp [counter4*2+1];
                                        
                                        if (endXAd-startXAd == 0) distance = sqrt((startXAd-valueXRefAd)*(startXAd-valueXRefAd));
                                        else if (constA == 0) distance = sqrt((startYAd-valueYRefAd)*(startYAd-valueYRefAd));
                                        else{
                                            
                                            constC = valueYRefAd-(-1/constA)*valueXRefAd;
                                            crossX = (int)((constC-constB)/(double)(constA+1/constA));
                                            crossY = (int)(constA*crossX+constB);
                                            distance = sqrt((valueXRefAd-crossX)*(valueXRefAd-crossX)+(valueYRefAd-crossY)*(valueYRefAd-crossY));
                                        }
                                        
                                        if (distance >= 6) distanceOverCount++;
                                        
                                        if (distance > distanceMax){
                                            distanceMax = distance;
                                            crossXMax = valueXRefAd;
                                            crossYMax = valueYRefAd;
                                        }
                                    }
                                }
                            }
                        }
                        
                        if (distanceMax > 6 && distanceOverCount > 1){
                            arrayVectorSegmentationTemp2 [counter2+3] = crossXMax;
                            arrayVectorSegmentationTemp2 [counter2+4] = crossYMax;
                            
                            arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = vectorNumber, vectorSegmentationTempCount2++;
                            arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = crossXMax, vectorSegmentationTempCount2++;
                            arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = crossYMax, vectorSegmentationTempCount2++;
                            arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = endXAd, vectorSegmentationTempCount2++;
                            arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = endYAd, vectorSegmentationTempCount2++;
                            
                            //for (int counterA = 0; counterA < vectorSegmentationTempCount2/5; counterA++){
                            //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayVectorSegmentationTemp2 [counterA*5+counterB];
                            //	cout<<" vectorSegmentationTemp2 "<<counterA<<endl;
                            //}
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < defMap; counter2++){
                        delete [] angleMap [counter2];
                        delete [] startEndMap [counter2];
                        delete [] totalMap [counter2];
                    }
                    
                    delete [] angleMap;
                    delete [] startEndMap;
                    delete [] totalMap;
                    
                    for (int counter2 = 0; counter2 < (vectorSegmentationTempCount-6)/2+4; counter2++) delete [] mappingPosition [counter2];
                    delete [] mappingPosition;
                    
                    vectorSegmentationTempCount = 0;
                }
                
                //------Array Sorting------
                //for (int counterA = 0; counterA < vectorSegmentationTempCount2/5; counterA++){
                //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayVectorSegmentationTemp2 [counterA*5+counterB];
                //	cout<<" vectorSegmentationTemp2 "<<counterA<<endl;
                //}
                
                firstSortEndX = arrayVectorSegmentationTemp2 [3];
                firstSortEndY = arrayVectorSegmentationTemp2 [4];
                
                arrayVectorSegmentationTemp3 [vectorSegmentationTempCount3] = arrayVectorSegmentationTemp2 [0], vectorSegmentationTempCount3++;
                arrayVectorSegmentationTemp3 [vectorSegmentationTempCount3] = arrayVectorSegmentationTemp2 [1], vectorSegmentationTempCount3++;
                arrayVectorSegmentationTemp3 [vectorSegmentationTempCount3] = arrayVectorSegmentationTemp2 [2], vectorSegmentationTempCount3++;
                arrayVectorSegmentationTemp3 [vectorSegmentationTempCount3] = arrayVectorSegmentationTemp2 [3], vectorSegmentationTempCount3++;
                arrayVectorSegmentationTemp3 [vectorSegmentationTempCount3] = arrayVectorSegmentationTemp2 [4], vectorSegmentationTempCount3++;
                
                int *vectorHoldTemp = new int [vectorSegmentationTempCount2+50];
                vectorHoldTempCount = 0;
                
                for (int counter2 = 5; counter2 < vectorSegmentationTempCount2; counter2++) vectorHoldTemp [vectorHoldTempCount] = arrayVectorSegmentationTemp2 [counter2], vectorHoldTempCount++;
                
                vectorSegmentationTempCount2 = 0;
                for (int counter2 = 0; counter2 < vectorHoldTempCount; counter2++) arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = vectorHoldTemp [counter2], vectorSegmentationTempCount2++;
                
                delete [] vectorHoldTemp;
                
                //for (int counterA = 0; counterA < vectorSegmentationTempCount2/5; counterA++){
                //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayVectorSegmentationTemp2 [counterA*5+counterB];
                //	cout<<" vectorSegmentationTemp2 "<<counterA<<endl;
                //}
                
                do{
                    
                    terminationFlag = 0;
                    counterMax = vectorSegmentationTempCount2;
                    
                    for (int counter2 = 0; counter2 < counterMax; counter2 = counter2+5){
                        if (firstSortEndX == arrayVectorSegmentationTemp2 [counter2+1] && firstSortEndY == arrayVectorSegmentationTemp2 [counter2+2]){
                            arrayVectorSegmentationTemp3 [vectorSegmentationTempCount3] = arrayVectorSegmentationTemp2 [counter2], vectorSegmentationTempCount3++;
                            arrayVectorSegmentationTemp3 [vectorSegmentationTempCount3] = arrayVectorSegmentationTemp2 [counter2+1], vectorSegmentationTempCount3++;
                            arrayVectorSegmentationTemp3 [vectorSegmentationTempCount3] = arrayVectorSegmentationTemp2 [counter2+2], vectorSegmentationTempCount3++;
                            arrayVectorSegmentationTemp3 [vectorSegmentationTempCount3] = arrayVectorSegmentationTemp2 [counter2+3], vectorSegmentationTempCount3++;
                            arrayVectorSegmentationTemp3 [vectorSegmentationTempCount3] = arrayVectorSegmentationTemp2 [counter2+4], vectorSegmentationTempCount3++;
                            
                            firstSortEndX = arrayVectorSegmentationTemp2 [counter2+3];
                            firstSortEndY = arrayVectorSegmentationTemp2 [counter2+4];
                            
                            int *vectorHoldTemp2 = new int [vectorSegmentationTempCount2+50];
                            vectorHoldTempCount2 = 0;
                            
                            for (int counter3 = 0; counter3 < counter2; counter3++) vectorHoldTemp2 [vectorHoldTempCount2] = arrayVectorSegmentationTemp2 [counter3], vectorHoldTempCount2++;
                            for (int counter3 = counter2+5; counter3 < vectorSegmentationTempCount2; counter3++) vectorHoldTemp2 [vectorHoldTempCount2] = arrayVectorSegmentationTemp2 [counter3], vectorHoldTempCount2++;
                            
                            vectorSegmentationTempCount2 = 0;
                            for (int counter3 = 0; counter3 < vectorHoldTempCount2; counter3++) arrayVectorSegmentationTemp2 [vectorSegmentationTempCount2] = vectorHoldTemp2 [counter3], vectorSegmentationTempCount2++;
                            
                            delete [] vectorHoldTemp2;
                            
                            terminationFlag = 1;
                            break;
                        }
                    }
                    
                } while (terminationFlag == 1);
                
                //for (int counterA = 0; counterA < vectorSegmentationTempCount2/5; counterA++){
                //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayVectorSegmentationTemp2 [counterA*5+counterB];
                //	cout<<" vectorSegmentationTemp2 "<<counterA<<endl;
                //}
                
                //------Determine the angle and length of each lines------
                for (int counter2 = 0; counter2 < vectorSegmentationTempCount3; counter2 = counter2+5){
                    startX2 = arrayVectorSegmentationTemp3 [counter2+1];
                    startY2 = arrayVectorSegmentationTemp3 [counter2+2];
                    endX2 = arrayVectorSegmentationTemp3 [counter2+3];
                    endY2 = arrayVectorSegmentationTemp3 [counter2+4];
                    
                    if (endX2-startX2 == 0){
                        if (endY2-startY2 > 0) angle2 = 90;
                        else angle2 = -90;
                    }
                    else if (endY2-startY2 == 0){
                        if (endX2-startX2 > 0) angle2 = 0;
                        else angle2 = 180;
                    }
                    else{
                        
                        angle2 = (atan(abs(endY2-startY2)/(double)abs(endX2-startX2)))*180/3.14;
                        
                        if (endX2-startX2 > 0 && endY2-startY2 < 0) angle2 = angle2*-1;
                        else if (endX2-startX2 < 0 && endY2-startY2 > 0) angle2 = 180-angle2;
                        else if (endX2-startX2 < 0 && endY2-startY2 < 0) angle2 = (180-angle2)*-1;
                    }
                    
                    //------Data writing into the arrayVectorSegmentation------
                    if (vectorSegmentationCount+5 > vectorSegmentationLimit){
                        int *arraySourceTemp = new int [vectorSegmentationCount+50];
                        for (int counter3 = 0; counter3 < vectorSegmentationCount; counter3++) arraySourceTemp [counter3] = arrayVectorSegmentation [counter3];
                        
                        delete [] arrayVectorSegmentation;
                        arrayVectorSegmentation = new int [vectorSegmentationLimit+5000];
                        vectorSegmentationLimit = vectorSegmentationLimit+5000;
                        
                        for (int counter3 = 0; counter3 < vectorSegmentationCount; counter3++) arrayVectorSegmentation [counter3] = arraySourceTemp [counter3];
                        delete [] arraySourceTemp;
                    }
                    
                    if (vectorSegmentationLengthCount+2 > vectorSegmentationLengthLimit){
                        double *arraySourceTemp = new double [vectorSegmentationLengthCount+50];
                        for (int counter3 = 0; counter3 < vectorSegmentationLengthCount; counter3++) arraySourceTemp [counter3] = arrayVectorSegmentationLength [counter3];
                        
                        delete [] arrayVectorSegmentationLength;
                        arrayVectorSegmentationLength = new double [vectorSegmentationLengthLimit+2500];
                        vectorSegmentationLengthLimit = vectorSegmentationLengthLimit+2500;
                        
                        for (int counter3 = 0; counter3 < vectorSegmentationLengthCount; counter3++) arrayVectorSegmentationLength [counter3] = arraySourceTemp [counter3];
                        delete [] arraySourceTemp;
                    }
                    
                    arrayVectorSegmentation [vectorSegmentationCount] = arrayVectorSegmentationTemp3 [counter2], vectorSegmentationCount++;
                    arrayVectorSegmentation [vectorSegmentationCount] = startX2, vectorSegmentationCount++;
                    arrayVectorSegmentation [vectorSegmentationCount] = startY2, vectorSegmentationCount++;
                    arrayVectorSegmentation [vectorSegmentationCount] = endX2, vectorSegmentationCount++;
                    arrayVectorSegmentation [vectorSegmentationCount] = endY2, vectorSegmentationCount++;
                    arrayVectorSegmentationLength [vectorSegmentationLengthCount] = sqrt(pow((endX2-startX2), 2)+pow((endY2-startY2), 2)), vectorSegmentationLengthCount++;
                    arrayVectorSegmentationLength [vectorSegmentationLengthCount] = angle2, vectorSegmentationLengthCount++;
                    
                    //cout<<vectorNumberTemp<<" "<<startX2<<" "<<startY2<<" "<<endX2<<" "<<endY2<<" "<<length2<<" "<<angle2<<" Results"<<endl;
                }
                
                vectorSegmentationTempCount2 = 0;
                vectorSegmentationTempCount3 = 0;
                
                //------Set first point of next line------
                if (counterTemp != -1){
                    vectorNumber = arrayOutlineVectorSegment [counter1];
                    
                    arrayVectorSegmentationTemp [vectorSegmentationTempCount] = arrayOutlineVectorSegment [counter1+1], vectorSegmentationTempCount++;
                    arrayVectorSegmentationTemp [vectorSegmentationTempCount] = arrayOutlineVectorSegment [counter1+2], vectorSegmentationTempCount++;
                    
                    //cout<<startX<<" "<<startY<<" "<<vectorSegmentationTempCount<<" NextPosition"<<endl;
                }
            }
        }
        
        delete [] arrayVectorSegmentationTemp;
        delete [] arrayVectorSegmentationTemp2;
        delete [] arrayVectorSegmentationTemp3;
    }
}

@end
