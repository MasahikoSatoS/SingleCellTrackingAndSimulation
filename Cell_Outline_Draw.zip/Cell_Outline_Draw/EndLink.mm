//
// EndLink.mm
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 30/11/12.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#import "EndLink.h"

@implementation EndLink

-(void)endLinkProcess:(int)maxPointDimX :(int)maxPointDimY :(int)minPointDimX :(int)minPointDimY :(int)minValue{
    //------Read original image data------
    
    int *arraySelectedReference = new int [lineFiveCount+500], selectedReferenceCount = 0;
    
    int blockCount = 0;
    int blockHold = 0;
    
    for (int counter1 = 0; counter1 < lineFiveCount/6; counter1++){
        if (arrayLineFive [counter1*6+4] == 1){
            if (blockCount != arrayLineFive [counter1*6+3]){
                blockHold++;
                blockCount = arrayLineFive [counter1*6+3];
            }
            
            arraySelectedReference [selectedReferenceCount] = arrayLineFive [counter1*6], selectedReferenceCount++; //------X Position------0
            arraySelectedReference [selectedReferenceCount] = arrayLineFive [counter1*6+1], selectedReferenceCount++; //------Y position------1
            arraySelectedReference [selectedReferenceCount] = arrayLineFive [counter1*6+2], selectedReferenceCount++; //------Value------2
            arraySelectedReference [selectedReferenceCount] = arrayLineFive [counter1*6+3], selectedReferenceCount++; //------Block------3
            arraySelectedReference [selectedReferenceCount] = arrayLineFive [counter1*6+4], selectedReferenceCount++; //------Combine------4
            arraySelectedReference [selectedReferenceCount] = arrayLineFive [counter1*6+5], selectedReferenceCount++; //------Status------5
        }
    }
    
    //for (int counterA = 0; counterA < selectedReferenceCount/6; counterA++){
    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arraySelectedReference [counterA*6+counterB];
    //	cout<<" selectedReference "<<counterA<<endl;
    //}
    
    int *arraySelectedSubject = new int [lineSevenCount+500], selectedSubjectCount = 0;
    
    for (int counter1 = 0; counter1 < lineSevenCount/6; counter1++){
        if (arrayLineSeven [counter1*6+4] == 1){
            arraySelectedSubject [selectedSubjectCount] = arrayLineSeven [counter1*6], selectedSubjectCount++;
            arraySelectedSubject [selectedSubjectCount] = arrayLineSeven [counter1*6+1], selectedSubjectCount++;
            arraySelectedSubject [selectedSubjectCount] = arrayLineSeven [counter1*6+2], selectedSubjectCount++;
            arraySelectedSubject [selectedSubjectCount] = arrayLineSeven [counter1*6+3], selectedSubjectCount++;
            arraySelectedSubject [selectedSubjectCount] = arrayLineSeven [counter1*6+4], selectedSubjectCount++;
            arraySelectedSubject [selectedSubjectCount] = arrayLineSeven [counter1*6+5], selectedSubjectCount++;
        }
    }
    
    int maxPointDimX2 = 0;
    int maxPointDimY2 = 0;
    int minPointDimX2 = 100000;
    int minPointDimY2 = 100000;
    
    for (int counter1 = 0; counter1 < selectedReferenceCount/6; counter1++){
        if (maxPointDimX2 < arraySelectedReference [counter1*6]) maxPointDimX2 = arraySelectedReference [counter1*6];
        if (minPointDimX2 > arraySelectedReference [counter1*6]) minPointDimX2 = arraySelectedReference [counter1*6];
        if (maxPointDimY2 < arraySelectedReference [counter1*6+1]) maxPointDimY2 = arraySelectedReference [counter1*6+1];
        if (minPointDimY2 > arraySelectedReference [counter1*6+1]) minPointDimY2 = arraySelectedReference [counter1*6+1];
    }
    
    for (int counter1 = 0; counter1 < selectedSubjectCount/6; counter1++){
        if (maxPointDimX2 < arraySelectedSubject [counter1*6]) maxPointDimX2 = arraySelectedSubject [counter1*6];
        if (minPointDimX2 > arraySelectedSubject [counter1*6]) minPointDimX2 = arraySelectedSubject [counter1*6];
        if (maxPointDimY2 < arraySelectedSubject [counter1*6+1]) maxPointDimY2 = arraySelectedSubject [counter1*6+1];
        if (minPointDimY2 > arraySelectedSubject [counter1*6+1]) minPointDimY2 = arraySelectedSubject [counter1*6+1];
    }
    
    int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
    int verticalLength = (maxPointDimY-minPointDimY)/2*2;
    int dimension2 = 0;
    
    if (horizontalLength >= verticalLength) dimension2 = horizontalLength+30;
    if (horizontalLength < verticalLength) dimension2 = verticalLength+30;
    
    dimension2 = (dimension2/2)*2;
    
    int horizontalStart2 = minPointDimX-(dimension2-horizontalLength)/2;
    int verticalStart2 = minPointDimY-(dimension2-verticalLength)/2;
    
    //------Read original image data------
    int **sourceMapFive = new int *[dimension2+4];
    int **sourceMapSeven = new int *[dimension2+4];
    
    for (int counter1 = 0; counter1 < dimension2+4; counter1++){
        sourceMapFive [counter1] = new int [dimension2+4];
        sourceMapSeven [counter1] = new int [dimension2+4];
    }
    
    for (int counterY = 0; counterY < dimension2; counterY++){
        for (int counterX = 0; counterX < dimension2; counterX++){
            if (counterY-verticalStart2 >= 0 && counterY-verticalStart2 < imageWidth && counterX-horizontalStart2 >= 0 && counterX-horizontalStart2 < imageWidth){
                sourceMapFive [counterY][counterX] = -1;
                sourceMapSeven [counterY][counterX] = -1;
            }
            else{
                
                sourceMapFive [counterY][counterX] = 0;
                sourceMapSeven [counterY][counterX] = 0;
            }
        }
    }
    
    int fiveBlock = 0;
    int sevenBlock = 0;
    int fiveX = 0;
    int fiveY = 0;
    
    for (int counter1 = 0; counter1 < selectedReferenceCount/6; counter1++){
        fiveX = arraySelectedReference [counter1*6]-horizontalStart2;
        fiveY = arraySelectedReference [counter1*6+1]-verticalStart2;
        
        sourceMapFive [fiveY][fiveX] = arraySelectedReference [counter1*6+3];
        
        if (arraySelectedReference [counter1*6+5] == 1) fiveBlock++;
    }
    
    int sevenX = 0;
    int sevenY = 0;
    
    for (int counter1 = 0; counter1 < selectedSubjectCount/6; counter1++){
        sevenX = arraySelectedSubject [counter1*6]-horizontalStart2;
        sevenY = arraySelectedSubject [counter1*6+1]-verticalStart2;
        
        sourceMapFive [sevenY][sevenX] = arraySelectedSubject [counter1*6+3];
        
        if (arraySelectedSubject [counter1*6+5] == 1) sevenBlock++;
    }
    
    //for (int counterA = 0; counterA < selectedSubjectCount/6; counterA++){
    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arraySelectedSubject [counterA*6+counterB];
    //	cout<<" arraySelectedSubject "<<counterA<<endl;
    //}
    
    //cout<<fiveBlock<<" "<<sevenBlock<<" Five_SevenBlock"<<endl;
    
    int *arrayReferenceListX = new int [selectedReferenceCount*3+500], referenceListCountX = 0;
    
    int entryFlag = 0;
    
    for (int counter1 = 0; counter1 < selectedReferenceCount/6; counter1++){
        fiveX = arraySelectedReference [counter1*6]-horizontalStart2;
        entryFlag = 0;
        
        for (int counter2 = arraySelectedReference [counter1*6+1]; counter2 < imageWidth; counter2++){
            if (counter2-verticalStart2 >= 0 && counter2-verticalStart2 < dimension2 && sourceMapFive [counter2-verticalStart2][fiveX] != -1){
                if (arrayExtractedImage [counter2][arraySelectedReference [counter1*6]] == 100 || arrayExtractedImage [counter2][arraySelectedReference [counter1*6]] < 50 || (sourceMapFive [counter2-verticalStart2][fiveX] != arraySelectedReference [counter1*6+3] && sourceMapFive [counter2-verticalStart2][fiveX] != 0)){
                    arrayReferenceListX [referenceListCountX] = 0, referenceListCountX++; //------counterpart line number------0
                    arrayReferenceListX [referenceListCountX] = arraySelectedReference [counter1*6+3], referenceListCountX++; //------Line Number ref------1
                    arrayReferenceListX [referenceListCountX] = 0, referenceListCountX++;
                    entryFlag = 1;
                    break;
                }
                else if (sourceMapSeven [counter2-verticalStart2][fiveX] != 0){
                    arrayReferenceListX [referenceListCountX] = sourceMapSeven [counter2-verticalStart2][fiveX], referenceListCountX++;
                    arrayReferenceListX [referenceListCountX] = arraySelectedReference [counter1*6+3], referenceListCountX++;
                    arrayReferenceListX [referenceListCountX] = 0, referenceListCountX++; //------Distance------
                    entryFlag = 1;
                    break;
                }
            }
            else{
                
                break;
            }
        }
        
        if (entryFlag == 0){
            arrayReferenceListX [referenceListCountX] = 0, referenceListCountX++;
            arrayReferenceListX [referenceListCountX] = 0, referenceListCountX++;
            arrayReferenceListX [referenceListCountX] = 0, referenceListCountX++;
        }
    }
    
    //for (int counterA = 0; counterA < referenceListCountX/3; counterA++){
    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayReferenceListX [counterA*3+counterB];
    //	cout<<" arrayReferenceListX "<<counterA<<endl;
    //}
    
    int *arrayReferenceListY = new int [selectedReferenceCount*3+500], referenceListCountY = 0;
    
    for (int counter1 = 0; counter1 < selectedReferenceCount/6; counter1++){
        fiveY = arraySelectedReference [counter1*6+1]-verticalStart2;
        entryFlag = 0;
        
        for (int counter2 = arraySelectedReference [counter1*6]; counter2 < imageWidth; counter2++){
            if (counter2-horizontalStart2 >= 0 && counter2-horizontalStart2 < dimension2 && sourceMapFive [fiveY][counter2-horizontalStart2] != -1){
                if (arrayExtractedImage [arraySelectedReference [counter1*6+1]][counter2] == 100 || arrayExtractedImage [arraySelectedReference [counter1*6+1]][counter2] < 50 || (sourceMapFive [fiveY][counter2-horizontalStart2] != arraySelectedReference [counter1*6+3] && sourceMapFive [fiveY][counter2-horizontalStart2] != 0)){
                    arrayReferenceListY [referenceListCountY] = 0, referenceListCountY++;
                    arrayReferenceListY [referenceListCountY] = arraySelectedReference [counter1*6+3], referenceListCountY++;
                    arrayReferenceListY [referenceListCountY] = 0, referenceListCountY++;
                    entryFlag = 1;
                    break;
                }
                else if (sourceMapSeven [fiveY][counter2-horizontalStart2] != 0){
                    arrayReferenceListY [referenceListCountY] = sourceMapSeven [fiveY][counter2-horizontalStart2], referenceListCountY++;
                    arrayReferenceListY [referenceListCountY] = arraySelectedReference [counter1*6+3], referenceListCountY++;
                    arrayReferenceListY [referenceListCountY] = 0, referenceListCountY++;
                    entryFlag = 1;
                    break;
                }
            }
            else{
                
                break;
            }
        }
        
        if (entryFlag == 0){
            arrayReferenceListY [referenceListCountY] = 0, referenceListCountY++;
            arrayReferenceListY [referenceListCountY] = 0, referenceListCountY++;
            arrayReferenceListY [referenceListCountY] = 0, referenceListCountY++;
        }
    }
    
    //for (int counterA = 0; counterA < referenceListCountY/3; counterA++){
    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayReferenceListY [counterA*3+counterB];
    //	cout<<" arrayReferenceListY "<<counterA<<endl;
    //}
    
    int *arraySubjectListX = new int [selectedSubjectCount*3+500], subjectListCountX = 0;
    
    for (int counter1 = 0; counter1 < selectedSubjectCount/6; counter1++){
        sevenX = arraySelectedSubject [counter1*6]-horizontalStart2;
        entryFlag = 0;
        
        for (int counter2 = arraySelectedSubject [counter1*6+1]; counter2 >= 0; counter2--){
            if (counter2-verticalStart2 >= 0 && counter2-verticalStart2 < dimension2 && sourceMapSeven [counter2-verticalStart2][sevenX] != -1){
                if (arrayExtractedImage [counter2][arraySelectedSubject [counter1*6]] == 100 || arrayExtractedImage [counter2][arraySelectedSubject [counter1*6]] < 50 || (sourceMapSeven [counter2-verticalStart2][sevenX] != arraySelectedSubject [counter1*6+3] && sourceMapSeven [counter2-verticalStart2][sevenX] != 0)){
                    arraySubjectListX [subjectListCountX] = 0, subjectListCountX++;
                    arraySubjectListX [subjectListCountX] = arraySelectedSubject [counter1*6+3], subjectListCountX++;
                    arraySubjectListX [subjectListCountX] = 0, subjectListCountX++;
                    entryFlag = 1;
                    break;
                }
                else if (sourceMapFive [counter2-verticalStart2][sevenX] != 0){
                    arraySubjectListX [subjectListCountX] = sourceMapFive [counter2-verticalStart2][sevenX], subjectListCountX++;
                    arraySubjectListX [subjectListCountX] = arraySelectedSubject [counter1*6+3], subjectListCountX++;
                    arraySubjectListX [subjectListCountX] = 0, subjectListCountX++;
                    entryFlag = 1;
                    break;
                }
            }
            else{
                
                break;
            }
        }
        
        if (entryFlag == 0){
            arraySubjectListX [subjectListCountX] = 0, subjectListCountX++;
            arraySubjectListX [subjectListCountX] = 0, subjectListCountX++;
            arraySubjectListX [subjectListCountX] = 0, subjectListCountX++;
        }
    }
    
    //for (int counterA = 0; counterA < subjectListCountX/3; counterA++){
    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arraySubjectListX [counterA*3+counterB];
    //	cout<<" arraySubjectListX "<<counterA<<endl;
    //}
    
    int *arraySubjectListY = new int [selectedSubjectCount*3+500], subjectListCountY = 0;
    
    for (int counter1 = 0; counter1 < selectedSubjectCount/6; counter1++){
        sevenY = arraySelectedSubject [counter1*6+1]-verticalStart2;
        entryFlag = 0;
        
        for (int counter2 = arraySelectedSubject [counter1*6]; counter2 >= 0; counter2 = counter2-1){
            if (counter2-horizontalStart2 >= 0 && counter2-horizontalStart2 < dimension2 && sourceMapSeven [sevenY][counter2-horizontalStart2] != -1){
                if (arrayExtractedImage [arraySelectedSubject [counter1*6+1]][counter2] == 100 || arrayExtractedImage [arraySelectedSubject [counter1*6+1]][counter2] < 50 || (sourceMapSeven [sevenY][counter2-horizontalStart2] != arraySelectedSubject [counter1*6+3] && sourceMapSeven [sevenY][counter2-horizontalStart2] != 0)){
                    arraySubjectListY [subjectListCountY] = 0, subjectListCountY++;
                    arraySubjectListY [subjectListCountY] = arraySelectedSubject [counter1*6+3], subjectListCountY++;
                    arraySubjectListY [subjectListCountY] = 0, subjectListCountY++;
                    entryFlag = 1;
                    break;
                }
                else if (sourceMapFive [sevenY][counter2-horizontalStart2] != 0){
                    arraySubjectListY [subjectListCountY] = sourceMapFive [sevenY][counter2-horizontalStart2], subjectListCountY++;
                    arraySubjectListY [subjectListCountY] = arraySelectedSubject [counter1*6+3], subjectListCountY++;
                    arraySubjectListY [subjectListCountY] = 0, subjectListCountY++;
                    entryFlag = 1;
                    break;
                }
            }
            else{
                
                break;
            }
        }
        
        if (entryFlag == 0){
            arraySubjectListY [subjectListCountY] = 0, subjectListCountY++;
            arraySubjectListY [subjectListCountY] = 0, subjectListCountY++;
            arraySubjectListY [subjectListCountY] = 0, subjectListCountY++;
        }
    }
    
    for (int counter1 = 0; counter1 < dimension2+4; counter1++){
        delete [] sourceMapFive [counter1];
        delete [] sourceMapSeven [counter1];
    }
    
    delete [] sourceMapFive;
    delete [] sourceMapSeven;
    
    //for (int counterA = 0; counterA < subjectListCountY/3; counterA++){
    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arraySubjectListY [counterA*3+counterB];
    //	cout<<" arrayReferenceListY "<<counterA<<endl;
    //}
    
    int *arrayReferenceList;
    int referenceListCount = 0;
    int referenceListStatus = 0;
    int *arraySubjectList;
    int subjectListCount = 0;
    int subjectListStatus = 0;
    int terminationFlag = 0;
    int lineStart = 0;
    int lineEnd = 0;
    int findFlag = 0;
    int hitCheck = 0;
    int majorMatch = 0;
    int positionRecord = 0;
    int blockNumber = 0;
    int regionInfoStart = 0;
    int regionInfoEnd = 0;
    int counterpartNumber = 0;
    int refStartX = 0;
    int refStartY = 0;
    int blockStart = 0;
    int refEndX = 0;
    int refEndY = 0;
    int blockEnd = 0;
    int subStartX = 0;
    int subStartY = 0;
    int subStartCount = 0;
    int subEndX = 0;
    int subEndY = 0;
    int subEndCount = 0;
    int refStartXTemp = 0;
    int refStartYTemp = 0;
    int blockStartTemp = 0;
    int refEndXTemp = 0;
    int refEndYTemp = 0;
    int blockEndTemp = 0;
    int blockFlag = 0;
    int pointCount = 0;
    int pointMax = 0;
    int subStartXTemp = 0;
    int subStartYTemp = 0;
    int subStartCountTemp = 0;
    int subEndXTemp = 0;
    int subEndYTemp = 0;
    int subEndCountTemp = 0;
    int fiveEndCount = 0;
    int fiveEndX = 0;
    int fiveEndY = 0;
    int subjectEndCount2 = 0;
    int sevenStartCount = 0;
    int sevenStartX = 0;
    int sevenStartY = 0;
    int fiveStartCount = 0;
    int fiveStartX = 0;
    int fiveStartY = 0;
    int sevenEndCount = 0;
    int sevenEndX = 0;
    int sevenEndY = 0;
    int endGapFlag = 0;
    int startGapFlag = 0;
    int attachX = 0;
    int attachY = 0;
    int attachCount = 0;
    int attachStatus = 0;
    int refEndFinalX = 0;
    int refEndFinalY = 0;
    int refEndFinalCount = 0;
    int subStartFinalX = 0;
    int subStartFinalY = 0;
    int subStartFinalCount = 0;
    int refStartFinalX = 0;
    int refStartFinalY = 0;
    int refStartFinalCount = 0;
    int subEndFinalX = 0;
    int subEndFinalY = 0;
    int subEndFinalCount = 0;
    int gapDataEndCount = 0;
    int gapDataEndLimit = 0;
    int gapDataStartCount = 0;
    int gapDataStartLimit = 0;
    int failCheckFlag1 = 0;
    int lineSet = 1;
    int chaseResult = 0;
    int failCheckFlag2 = 0;
    
    double fiveEndScan = 0;
    double shortestDistanceTemp = 0;
    double sevenStartScan = 0;
    double fiveStartScan = 0;
    double sevenEndScan = 0;
    
    do{
        
        terminationFlag = 1;
        referenceListCount = 0;
        lineStart = 0;
        findFlag = 0;
        
        for (int counter1 = 0; counter1 < selectedReferenceCount/6; counter1++){
            if (arraySelectedReference [counter1*6+5] == 1 && findFlag == 0){
                lineStart = counter1;
                findFlag = 1;
            }
            else if (arraySelectedReference [counter1*6+5] == 2 && findFlag == 1){
                lineEnd = counter1;
                findFlag = 0;
                
                int *lineRangeList = new int [sevenBlock*2+50];
                int *lineRangeHit = new int [sevenBlock+50];
                
                for (int counter2 = 0; counter2 < sevenBlock; counter2++){
                    lineRangeList [counter2*2] = 10000;
                    lineRangeList [counter2*2+1] = -1;
                    lineRangeHit [counter2] = 0;
                }
                
                for (int counter2 = lineStart; counter2 <= lineEnd; counter2++){
                    hitCheck = 0;
                    
                    if (arrayReferenceListX [counter2*3] > 0){
                        lineRangeHit [arrayReferenceListX [counter2*3]-1]++;
                        hitCheck = 1;
                        
                        if (lineRangeList [(arrayReferenceListX [counter2*3]-1)*2] > counter2) lineRangeList [(arrayReferenceListX [counter2*3]-1)*2] = counter2;
                        
                        if (lineRangeList [(arrayReferenceListX [counter2*3]-1)*2+1] < counter2) lineRangeList [(arrayReferenceListX [counter2*3]-1)*2+1] = counter2;
                    }
                    
                    if (arrayReferenceListY [counter2*3] > 0){
                        if (hitCheck == 0) lineRangeHit [arrayReferenceListY [counter2*3]-1]++;
                        
                        if (lineRangeList [(arrayReferenceListY [counter2*3]-1)*2] > counter2) lineRangeList [(arrayReferenceListY [counter2*3]-1)*2] = counter2;
                        
                        if (lineRangeList [(arrayReferenceListY [counter2*3]-1)*2+1] < counter2) lineRangeList [(arrayReferenceListY [counter2*3]-1)*2+1] = counter2;
                    }
                }
                
                for (int counter2 = 0; counter2 < sevenBlock; counter2++){
                    if (lineRangeList [counter2*2] == 10000){
                        lineRangeList [counter2*2] = -1;
                        lineRangeList [counter2*2+1] = -1;
                    }
                    
                    if (lineRangeList [counter2*2+1] == -1){
                        lineRangeList [counter2*2] = -1;
                        lineRangeList [counter2*2+1] = -1;
                    }
                }
                
                if (referenceListStatus != 0){
                    delete [] arrayReferenceList;
                }
                
                arrayReferenceList = new int [sevenBlock*5+500];
                referenceListCount = 0;
                referenceListStatus = 1;
                
                for (int counter2 = 0; counter2 < sevenBlock; counter2++){
                    if (lineRangeList [counter2*2] != -1){
                        arrayReferenceList [referenceListCount] = arraySelectedReference [lineStart*6+3], referenceListCount++; //------ref line number
                        arrayReferenceList [referenceListCount] = lineRangeList [counter2*2], referenceListCount++; //------counter line start
                        arrayReferenceList [referenceListCount] = lineRangeList [counter2*2+1], referenceListCount++; //------counter line end
                        arrayReferenceList [referenceListCount] = counter2+1, referenceListCount++; //------counter line number
                        arrayReferenceList [referenceListCount] = lineRangeHit [counter2], referenceListCount++; //------counter line number
                    }
                }
                
                delete [] lineRangeList;
                delete [] lineRangeHit;
            }
        }
        
        //for (int counterA = 0; counterA < referenceListCount/5; counterA++){
        //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayReferenceList [counterA*5+counterB];
        //	cout<<" arrayReferenceList "<<counterA<<endl;
        //}
        
        lineStart = 0;
        findFlag = 0;
        
        for (int counter1 = 0; counter1 < selectedSubjectCount/6; counter1++){
            if (arraySelectedSubject [counter1*6+5] == 1 && findFlag == 0){
                lineStart = counter1;
                findFlag = 1;
            }
            else if (arraySelectedSubject [counter1*6+5] == 2 && findFlag == 1){
                lineEnd = counter1;
                findFlag = 0;
                
                int **lineRangeList = new int *[fiveBlock+50];
                for (int counter2 = 0; counter2 < fiveBlock+50; counter2++) lineRangeList [counter2] = new int [3];
                
                int *lineRangeHit = new int[fiveBlock+50];
                
                for (int counter2 = 0; counter2 < fiveBlock; counter2++){
                    lineRangeList [counter2][0] = 10000;
                    lineRangeList [counter2][1] = -1;
                    lineRangeHit [counter2] = 0;
                }
                
                for (int counter2 = lineStart; counter2 <= lineEnd; counter2++){
                    hitCheck = 0;
                    
                    if (arraySubjectListX [counter2*3] > 0){
                        lineRangeHit [arraySubjectListX [counter2*3]-1]++;
                        hitCheck = 1;
                        
                        if (lineRangeList [arraySubjectListX [counter2*3]-1][0] > counter2) lineRangeList [arraySubjectListX [counter2*3]-1][0] = counter2;
                        
                        if (lineRangeList [arraySubjectListX [counter2*3]-1][1] < counter2) lineRangeList [arraySubjectListX [counter2*3]-1][1] = counter2;
                    }
                    
                    if (arraySubjectListY [counter2*3] > 0){
                        if (hitCheck == 0) lineRangeHit [arraySubjectListY [counter2*3]-1]++;
                        
                        if (lineRangeList [arraySubjectListY [counter2*3]-1][0] > counter2) lineRangeList [arraySubjectListY [counter2*3]-1][0] = counter2;
                        
                        if (lineRangeList [arraySubjectListY [counter2*3]-1][1] < counter2) lineRangeList [arraySubjectListY [counter2*3]-1][1] = counter2;
                    }
                }
                
                for (int counter2 = 0; counter2 < fiveBlock; counter2++){
                    if (lineRangeList [counter2][0] == 10000){
                        lineRangeList [counter2][0] = -1;
                        lineRangeList [counter2][1] = -1;
                    }
                    
                    if (lineRangeList [counter2][1] == -1){
                        lineRangeList [counter2][0] = -1;
                        lineRangeList [counter2][1] = -1;
                    }
                }
                
                if (subjectListStatus != 0){
                    delete [] arraySubjectList;
                }
                
                arraySubjectList = new int [fiveBlock*5+500];
                subjectListCount = 0;
                subjectListStatus = 1;
                
                for (int counter2 = 0; counter2 < fiveBlock; counter2++){
                    if (lineRangeList [counter2][0] != -1){
                        arraySubjectList [subjectListCount] = arraySelectedSubject [lineStart*6+3], subjectListCount++;
                        arraySubjectList [subjectListCount] = lineRangeList [counter2][0], subjectListCount++;
                        arraySubjectList [subjectListCount] = lineRangeList [counter2][1], subjectListCount++;
                        arraySubjectList [subjectListCount] = counter2+1, subjectListCount++;
                        arraySubjectList [subjectListCount] = lineRangeHit [counter2], subjectListCount++; //------counter line number
                    }
                }
                
                for (int counter2 = 0; counter2 < fiveBlock+50; counter2++) delete [] lineRangeList [counter2];
                delete [] lineRangeList;
                
                delete [] lineRangeHit;
            }
        }
        
        //for (int counterA = 0; counterA < subjectListCount/5; counterA++){
        //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arraySubjectList [counterA*5+counterB];
        //	cout<<" arraySubjectList "<<counterA<<endl;
        //}
        
        majorMatch = 0;
        positionRecord = -1;
        
        for (int counter1 = 0; counter1 < referenceListCount/5; counter1++){
            if (arrayReferenceList [counter1*5+4] > majorMatch && arrayReferenceList [counter1*5] != -1){
                majorMatch = arrayReferenceList [counter1*5+4];
                positionRecord = counter1;
            }
        }
        
        if (positionRecord == -1) terminationFlag = 0;
        else{
            
            blockNumber = arrayReferenceList [positionRecord*5];
            regionInfoStart = arrayReferenceList [positionRecord*5+1];
            regionInfoEnd = arrayReferenceList [positionRecord*5+2];
            counterpartNumber = arrayReferenceList [positionRecord*5+3];
            
            refStartX = 0;
            refStartY = 0;
            blockStart = -1;
            refEndX = 0;
            refEndY = 0;
            blockEnd = -1;
            subStartX = 0;
            subStartY = 0;
            subStartCount = -1;
            subEndX = 0;
            subEndY = 0;
            subEndCount = -1;
            refStartXTemp = 0;
            refStartYTemp = 0;
            blockStartTemp = 0;
            blockFlag = 0;
            pointCount = 0;
            pointMax = 0;
            
            for (int counter1 = regionInfoStart; counter1 <= regionInfoEnd; counter1++){
                if ((counter1 == regionInfoStart && arraySelectedReference [counter1*6+5] != 3) || (arraySelectedReference [counter1*6+5] == 1 && blockFlag == 0)){
                    blockFlag = 1;
                    pointCount++;
                    refStartXTemp = arraySelectedReference [counter1*6];
                    refStartYTemp = arraySelectedReference [counter1*6+1];
                    blockStartTemp = counter1;
                    
                    if (counter1 == regionInfoStart && arraySelectedReference [counter1*6+5] != 3){
                        for (int counter2 = regionInfoStart; counter2 >= 0; counter2 = counter2-1){
                            if (arraySelectedReference [counter2*6+5] == 1){
                                refStartXTemp = arraySelectedReference [counter2*6];
                                refStartYTemp = arraySelectedReference [counter2*6+1];
                                blockStartTemp = counter2;
                                break;
                            }
                        }
                    }
                }
                else if (counter1 == regionInfoEnd || (arraySelectedReference [counter1*6] == 2 && blockFlag == 1)){
                    blockFlag = 1;
                    pointCount++;
                    refEndXTemp = arraySelectedReference [counter1*6];
                    refEndYTemp = arraySelectedReference [counter1*6+1];
                    blockEndTemp = counter1;
                    
                    if (counter1 == regionInfoEnd && arraySelectedReference [counter1*6+5] != 3){
                        for (int counter2 = regionInfoEnd; counter2 <= selectedReferenceCount/6; counter2++){
                            if (arraySelectedReference [counter2*6+5] == 2){
                                refEndXTemp = arraySelectedReference [counter2*6];
                                refEndYTemp = arraySelectedReference [counter2*6+1];
                                blockEndTemp = counter2;
                                break;
                            }
                        }
                    }
                    
                    if (pointMax < pointCount){
                        refStartX = refStartXTemp;
                        refStartY = refStartYTemp;
                        blockStart = blockStartTemp;
                        refEndX = refEndXTemp;
                        refEndY = refEndYTemp;
                        blockEnd = blockEndTemp;
                    }
                }
                else if ((arrayReferenceListX [counter1*3] == counterpartNumber) || (arrayReferenceListY [counter1*3] == counterpartNumber)) pointCount++;
            }
            
            //cout<<blockStart<<" "<<refStartX<<" "<<refStartY<<" "<<blockEnd<<" "<<refEndX<<" "<<refEndY<<" Start-End info Ref"<<endl;
            
            regionInfoStart = 0;
            regionInfoEnd = 0;
            
            for (int counter1 = 0; counter1 < subjectListCount/5; counter1++){
                if (arraySubjectList [counter1*5] == counterpartNumber && arraySubjectList [counter1*5+3] == blockNumber){
                    regionInfoStart = arraySubjectList [counter1*5+1];
                    regionInfoEnd = arraySubjectList [counter1*5+2];
                    arraySubjectList [counter1*5] = -1;
                    break;
                }
            }
            
            subStartXTemp = 0;
            subStartYTemp = 0;
            subStartCountTemp = 0;
            blockFlag = 0;
            pointCount = 0;
            pointMax = 0;
            
            for (int counter1 = regionInfoStart; counter1 <= regionInfoEnd; counter1++){
                if ((counter1 == regionInfoStart && arraySelectedSubject [counter1*6+5] != 3) || (arraySelectedSubject [counter1*6+5] == 1 && blockFlag == 0)){
                    blockFlag = 1;
                    pointCount++;
                    subStartXTemp = arraySelectedSubject [counter1*6];
                    subStartYTemp = arraySelectedSubject [counter1*6+1];
                    subStartCountTemp = counter1;
                    
                    if (counter1 == regionInfoStart && arraySelectedSubject [counter1*6+5] != 3){
                        for (int counter2 = regionInfoStart; counter2 >= 0; counter2 = counter2-1){
                            if (arraySelectedSubject [counter2*6+5] == 1){
                                subStartXTemp = arraySelectedSubject [counter2*6];
                                subStartYTemp = arraySelectedSubject [counter2*6+1];
                                subStartCountTemp = counter2;
                                break;
                            }
                        }
                    }
                }
                else if (counter1 == regionInfoEnd || (arraySelectedSubject [counter1*6] == 2 && blockFlag == 1)){
                    blockFlag = 1;
                    pointCount++;
                    subEndXTemp = arraySelectedSubject [counter1*6];
                    subEndYTemp = arraySelectedSubject [counter1*6+1];
                    subEndCountTemp = counter1;
                    
                    if (counter1 == regionInfoEnd && arraySelectedSubject [counter1*6+5] != 3){
                        for (int counter2 = regionInfoEnd; counter2 <= selectedSubjectCount/6; counter2++){
                            if (arraySelectedSubject [counter2*6+5] == 2){
                                subEndXTemp = arraySelectedSubject [counter2*6];
                                subEndYTemp = arraySelectedSubject [counter2*6+1];
                                subEndCountTemp = counter2;
                                break;
                            }
                        }
                    }
                    
                    if (pointMax < pointCount){
                        subStartX = subStartXTemp;
                        subStartY = subStartYTemp;
                        subStartCount = subStartCountTemp;
                        subEndX = subEndXTemp;
                        subEndY = subEndYTemp;
                        subEndCount = subEndCountTemp;
                    }
                }
                else if ((arraySubjectListX [counter1*3] == blockNumber) ||(arraySubjectListY [counter1*3] == blockNumber)) pointCount++;
            }
            
            //cout<<subStartCount<<" "<<subStartX<<" "<<subStartY<<" "<<subEndCount<<" "<<subEndX<<" "<<subEndY<<" Start-End info Sub"<<endl;
            
            if ((blockStart == -1 && blockEnd == -1) || (subStartCount == -1 && subEndCount == -1)) terminationFlag = 0;
            else{
                
                //------FiveEnd >>> SevenStart
                fiveEndScan = 10000;
                fiveEndCount = 0;
                fiveEndX = 0;
                fiveEndY = 0;
                subjectEndCount2 = subEndCount-(int)((subEndCount-subStartCount)*0.2);
                
                for (int counter1 = subStartCount; counter1 <= subjectEndCount2; counter1++){
                    shortestDistanceTemp = sqrt((refEndX-arraySelectedSubject [counter1*6])*(refEndX-arraySelectedSubject [counter1*6])+(refEndY-arraySelectedSubject [counter1*6+1])*(refEndY-arraySelectedSubject [counter1*6+1]));
                    
                    //cout<<fiveEndX<<" "<<fiveEndY<<" "<<dataXTemp<<" "<<dataYTemp<<" "<<shortestDistanceTemp<<" "<<subjectEndCount2 <<" RefEd>>SubSt"<<endl;
                    
                    if (fiveEndScan > shortestDistanceTemp){
                        fiveEndX = arraySelectedSubject [counter1*6];
                        fiveEndY = arraySelectedSubject [counter1*6+1];
                        fiveEndCount = counter1;
                        fiveEndScan = shortestDistanceTemp;
                    }
                }
                
                //------SevenStart >>> FiveEnd
                sevenStartScan = 10000;
                sevenStartCount = 0;
                sevenStartX = 0;
                sevenStartY = 0;
                subjectEndCount2 = blockStart+(int)((blockEnd-blockStart)*0.2);
                
                for (int counter1 = blockEnd; counter1 >= subjectEndCount2; counter1 = counter1-1){
                    shortestDistanceTemp = sqrt((subStartX-arraySelectedReference [counter1*6])*(subStartX-arraySelectedReference [counter1*6])+(subStartY-arraySelectedReference [counter1*6+1])*(subStartY-arraySelectedReference [counter1*6+1]));
                    
                    //cout<<sevenStartX<<" "<<sevenStartY<<" "<<dataXTemp<<" "<<dataYTemp<<" "<<shortestDistanceTemp<<" "<<subjectEndCount2 <<" RefSt>>SubEd"<<endl;
                    
                    if (sevenStartScan > shortestDistanceTemp){
                        sevenStartX = arraySelectedReference [counter1*6];
                        sevenStartY = arraySelectedReference [counter1*6+1];
                        sevenStartCount = counter1;
                        sevenStartScan = shortestDistanceTemp;
                    }
                }
                
                //------FiveStart >>> SevenEnd
                fiveStartScan = 10000;
                fiveStartCount = 0;
                fiveStartX = 0;
                fiveStartY = 0;
                subjectEndCount2 = subStartCount+(int)((subEndCount-subStartCount)*0.2);
                
                for (int counter1 = subEndCount; counter1 >= subjectEndCount2; counter1 = counter1-1){
                    shortestDistanceTemp = sqrt((refStartX-arraySelectedSubject [counter1*6])*(refStartX-arraySelectedSubject [counter1*6])+(refStartY-arraySelectedSubject [counter1*6+1])*(refStartY-arraySelectedSubject [counter1*6+1]));
                    
                    //cout<<fiveStartX<<" "<<fiveStartY<<" "<<dataXTemp<<" "<<dataYTemp<<" "<<shortestDistanceTemp<<" "<<subjectEndCount2<<" RefSt>>SubEd"<<endl;
                    
                    if (fiveStartScan > shortestDistanceTemp){
                        fiveStartX = arraySelectedSubject [counter1*6];
                        fiveStartY = arraySelectedSubject [counter1*6+1];
                        fiveStartCount = counter1;
                        fiveStartScan = shortestDistanceTemp;
                    }
                }
                
                //------SubEnd >>> RefStart
                sevenEndScan = 10000;
                sevenEndCount = 0;
                sevenEndX = 0;
                sevenEndY = 0;
                subjectEndCount2 = blockEnd-(int)((blockEnd-blockStart)*0.2);
                
                for (int counter1 = blockStart; counter1 <= subjectEndCount2; counter1++){
                    shortestDistanceTemp = sqrt((subEndX-arraySelectedReference [counter1*6])*(subEndX-arraySelectedReference [counter1*6])+(subEndY-arraySelectedReference [counter1*6+1])*(subEndY-arraySelectedReference [counter1*6+1]));
                    
                    //cout<<sevenEndX<<" "<<sevenEndY<<" "<<dataXTemp<<" "<<dataYTemp<<" "<<shortestDistanceTemp<<" "<<subjectEndCount2<<" SunEd>>RefSt"<<endl;
                    
                    if (sevenEndScan > shortestDistanceTemp){
                        sevenEndX = arraySelectedReference [counter1*6];
                        sevenEndY = arraySelectedReference [counter1*6+1];
                        sevenEndCount = counter1;
                        sevenEndScan = shortestDistanceTemp;
                    }
                }
                
                //cout<<fiveEndX<<" "<<fiveEndY<<" "<<fiveEndCount <<" "<<fiveEndScan<<" 2RefEd>>SubSt"<<endl;
                //cout<<sevenStartX<<" "<<sevenStartY<<" "<<sevenStartCount <<" "<<sevenStartScan <<" 2RefSt>>SubEd"<<endl;
                //cout<<fiveStartX<<" "<<fiveStartY<<" "<<fiveStartCount<<" "<<fiveStartScan<<" RefSt>>SubEd"<<endl;
                //cout<<sevenEndX<<" "<<sevenEndY<<" "<<sevenEndCount<<" "<<sevenEndScan<<" 2SunEd>>RefSt"<<endl;
                
                endGapFlag = 0;
                startGapFlag = 0;
                attachX = -1;
                attachY = -1;
                attachCount = -1;
                attachStatus = 0;
                
                for (int counter1 = subStartCount; counter1 <= subEndCount; counter1++){
                    if (arraySelectedSubject [counter1*6] == refEndX && arraySelectedSubject [counter1*6+1] == refEndY){
                        attachX = arraySelectedSubject [counter1*6];
                        attachY = arraySelectedSubject [counter1*6+1];
                        attachCount = counter1;
                        attachStatus = 1;
                        break;
                    }
                    else{
                        
                        if (refEndX == arraySelectedSubject [counter1*6] && refEndY+1 == arraySelectedSubject [counter1*6+1]){
                            attachX = arraySelectedSubject [counter1*6];
                            attachY = arraySelectedSubject [counter1*6+1];
                            attachCount = counter1;
                            attachStatus = 2;
                        }
                        
                        if (refEndX-1 == arraySelectedSubject [counter1*6] && refEndY+1 == arraySelectedSubject [counter1*6+1]){
                            attachX = arraySelectedSubject [counter1*6];
                            attachY = arraySelectedSubject [counter1*6+1];
                            attachCount = counter1;
                            attachStatus = 2;
                        }
                        
                        if (refEndX+1 == arraySelectedSubject [counter1*6] && refEndY+1 == arraySelectedSubject [counter1*6+1]){
                            attachX = arraySelectedSubject [counter1*6];
                            attachY = arraySelectedSubject [counter1*6+1];
                            attachCount = counter1;
                            attachStatus = 2;
                        }
                        
                        if (refEndX+1 == arraySelectedSubject [counter1*6] && refEndY == arraySelectedSubject [counter1*6+1]){
                            attachX = arraySelectedSubject [counter1*6];
                            attachY = arraySelectedSubject [counter1*6+1];
                            attachCount = counter1;
                            attachStatus = 2;
                        }
                        
                        if (refEndX-1 == arraySelectedSubject [counter1*6] && refEndY == arraySelectedSubject [counter1*6+1]){
                            attachX = arraySelectedSubject [counter1*6];
                            attachY = arraySelectedSubject [counter1*6+1];
                            attachCount = counter1;
                            attachStatus = 2;
                        }
                    }
                }
                
                //cout<<attachX<<" "<<attachY<<" "<<attachCount<<" "<<attachStatus<<" AttachEnd"<<endl;
                
                if (attachStatus == 1){
                    refEndFinalX = refEndX;
                    refEndFinalY = refEndY;
                    refEndFinalCount = blockEnd;
                    subStartFinalX = arraySelectedSubject [attachCount*6];
                    subStartFinalY = arraySelectedSubject [attachCount*6+1];
                    subStartFinalCount = attachCount+1;
                }
                else if (attachStatus == 2){
                    refEndFinalX = refEndX;
                    refEndFinalY = refEndY;
                    refEndFinalCount = blockEnd;
                    subStartFinalX = attachX;
                    subStartFinalY = attachY;
                    subStartFinalCount = attachCount;
                }
                else if (fiveEndScan > sevenStartScan){
                    refEndFinalX = sevenStartX;
                    refEndFinalY = sevenStartY;
                    refEndFinalCount = sevenStartCount;
                    subStartFinalX = subStartX;
                    subStartFinalY = subStartY;
                    subStartFinalCount = subStartCount;
                    endGapFlag = 1;
                }
                else{
                    
                    refEndFinalX = refEndX;
                    refEndFinalY = refEndY;
                    refEndFinalCount = blockEnd;
                    subStartFinalX = fiveEndX;
                    subStartFinalY = fiveEndY;
                    subStartFinalCount = fiveEndCount;
                    endGapFlag = 1;
                }
                
                attachX = -1;
                attachY = -1;
                attachCount = -1;
                attachStatus = 0;
                
                for (int counter1 = subEndCount; counter1 >= subStartCount; counter1 = counter1-1){
                    if (arraySelectedSubject [counter1*6] == refStartX && arraySelectedSubject [counter1*6+1] == refStartY){
                        attachX = arraySelectedSubject [counter1*6];
                        attachY = arraySelectedSubject [counter1*6+1];
                        attachCount = counter1;
                        attachStatus = 1;
                        break;
                    }
                    else{
                        
                        if (refStartX == arraySelectedSubject [counter1*6] && refStartY-1 == arraySelectedSubject [counter1*6+1]){
                            attachX = arraySelectedSubject [counter1*6];
                            attachY = arraySelectedSubject [counter1*6+1];
                            attachCount = counter1;
                            attachStatus = 2;
                        }
                        
                        if (refStartX-1 == arraySelectedSubject [counter1*6] && refStartY-1 == arraySelectedSubject [counter1*6+1]){
                            attachX = arraySelectedSubject [counter1*6];
                            attachY = arraySelectedSubject [counter1*6+1];
                            attachCount = counter1;
                            attachStatus = 2;
                        }
                        
                        if (refStartX+1 == arraySelectedSubject [counter1*6] && refStartY-1 == arraySelectedSubject [counter1*6+1]){
                            attachX = arraySelectedSubject [counter1*6];
                            attachY = arraySelectedSubject [counter1*6+1];
                            attachCount = counter1;
                            attachStatus = 2;
                        }
                        
                        if (refStartX-1 == arraySelectedSubject [counter1*6] && refStartY == arraySelectedSubject [counter1*6+1]){
                            attachX = arraySelectedSubject [counter1*6];
                            attachY = arraySelectedSubject [counter1*6+1];
                            attachCount = counter1;
                            attachStatus = 2;
                        }
                        
                        if (refStartX+1 == arraySelectedSubject [counter1*6] && refStartY == arraySelectedSubject [counter1*6+1]){
                            attachX = arraySelectedSubject [counter1*6];
                            attachY = arraySelectedSubject [counter1*6+1];
                            attachCount = counter1;
                            attachStatus = 2;
                        }
                    }
                }
                
                //cout<<attachX<<" "<<attachY<<" "<<attachCount<<" "<<attachStatus<<" AttachStart"<<endl;
                
                if (attachStatus == 1){
                    refStartFinalX = refStartX;
                    refStartFinalY = refStartY;
                    refStartFinalCount = blockStart;
                    subEndFinalX = arraySelectedSubject [attachCount*6];
                    subEndFinalY = arraySelectedSubject [attachCount*6+1];
                    subEndFinalCount = attachCount-1;
                }
                else if (attachStatus == 2){
                    refStartFinalX = refStartX;
                    refStartFinalY = refStartY;
                    refStartFinalCount = blockStart;
                    subEndFinalX = attachX;
                    subEndFinalY = attachY;
                    subEndFinalCount = attachCount;
                }
                else if (fiveStartScan > sevenEndScan){
                    refStartFinalX = sevenEndX;
                    refStartFinalY = sevenEndY;
                    refStartFinalCount = sevenEndCount;
                    subEndFinalX = subEndX;
                    subEndFinalY = subEndY;
                    subEndFinalCount = subEndCount;
                    startGapFlag = 1;
                }
                else{
                    
                    refStartFinalX = refStartX;
                    refStartFinalY = refStartY;
                    refStartFinalCount = blockStart;
                    subEndFinalX = fiveStartX;
                    subEndFinalY = fiveStartY;
                    subEndFinalCount = fiveStartCount;
                    startGapFlag = 1;
                }
                
                //cout<<refEndFinalX<<" "<<refEndFinalY<<" "<<refEndFinalCount<<" "<<subStartFinalX<<" "<<subStartFinalY<<" "<<subStartFinalCount<<" Ref_Final"<<endl;
                //cout<<refStartFinalX<<" "<<refStartFinalY<<" "<<refStartFinalCount<<" "<<subEndFinalX<<" "<<subEndFinalY<<" "<<subEndFinalCount <<" Sub_Final"<<endl;
                
                int *arrayGapDataEnd = new int [500];
                gapDataEndCount = 0;
                gapDataEndLimit = 500;
                
                int *arrayGapDataStart = new int [500];
                gapDataStartCount = 0;
                gapDataStartLimit = 500;
                
                failCheckFlag1 = 0;
                
                if (endGapFlag == 1){
                    //cout<<jumpX1<<" "<<jumpY1<<" "<< jumpX2<<" "<<jumpY2<<" Jump_1"<<endl;
                    
                    gapChaseCount = 0;
                    
                    for (int counter1 = blockStart; counter1 <= blockEnd; counter1++){
                        if (gapChaseCount+5 > gapChaseLimit) [self gapChaseUpdate];
                        
                        arrayGapChase [gapChaseCount] = arraySelectedReference [counter1*6], gapChaseCount++;
                        arrayGapChase [gapChaseCount] = arraySelectedReference [counter1*6+1], gapChaseCount++;
                        arrayGapChase [gapChaseCount] = 1, gapChaseCount++;
                    }
                    
                    for (int counter1 = subStartCount; counter1 <= subEndCount; counter1++){
                        if (gapChaseCount+5 > gapChaseLimit) [self gapChaseUpdate];
                        
                        arrayGapChase [gapChaseCount] = arraySelectedSubject [counter1*6], gapChaseCount++;
                        arrayGapChase [gapChaseCount] = arraySelectedSubject [counter1*6+1], gapChaseCount++;
                        arrayGapChase [gapChaseCount] = 2, gapChaseCount++;
                    }
                    
                    lineSet = 1;
                    gapChase3 = [[GapChase3 alloc] init];
                    chaseResult = [gapChase3 gapChaseing3:refEndFinalX:refEndFinalY:subStartFinalX:subStartFinalY:lineSet:maxPointDimX:maxPointDimY:minPointDimX:minPointDimY:minValue];
                    
                    if (chaseResult == 0){ //------If it is successful, save data------
                        if (gapChaseCount+gapDataEndCount+5 > gapDataEndLimit){
                            int *arraySourceTemp = new int [gapDataEndCount+50];
                            for (int counter1 = 0; counter1 < gapDataEndCount; counter1++) arraySourceTemp [counter1] = arrayGapDataEnd [counter1];
                            
                            delete [] arrayGapDataEnd;
                            arrayGapDataEnd = new int [gapChaseCount+gapDataEndCount+500];
                            
                            for (int counter1 = 0; counter1 < gapDataEndCount; counter1++) arrayGapDataEnd [counter1] = arraySourceTemp [counter1];
                            delete [] arraySourceTemp;
                        }
                        
                        for (int counter1 = 0; counter1 < gapChaseCount/3; counter1++){
                            arrayGapDataEnd [gapDataEndCount] = arrayGapChase [counter1*3], gapDataEndCount++;
                            arrayGapDataEnd [gapDataEndCount] = arrayGapChase [counter1*3+1], gapDataEndCount++;
                            arrayGapDataEnd [gapDataEndCount] = arrayGapChase [counter1*3+2], gapDataEndCount++;
                        }
                    }
                    else failCheckFlag1 = 1;
                }
                
                if (failCheckFlag1 == 1){
                    for (int counter1 = 0; counter1 < referenceListCountX/3; counter1++){
                        if (arrayReferenceListX [counter1*3] == counterpartNumber && arrayReferenceListX [counter1*3+1] == blockNumber) arrayReferenceListX [counter1*3] = 0;
                    }
                    
                    for (int counter1 = 0; counter1 < referenceListCountY/3; counter1++){
                        if (arrayReferenceListY [counter1*3] == counterpartNumber && arrayReferenceListY [counter1*3+1] == blockNumber) arrayReferenceListY [counter1*3] = 0;
                    }
                    
                    for (int counter1 = 0; counter1 < subjectListCountX/3; counter1++){
                        if (arraySubjectListX [counter1*3] == blockNumber && arraySubjectListX [counter1*3+1] == counterpartNumber) arraySubjectListX [counter1*3] = 0;
                    }
                    
                    for (int counter1 = 0; counter1 < subjectListCountY/3; counter1++){
                        if (arraySubjectListY [counter1*3] == blockNumber && arraySubjectListY [counter1*3+1] == counterpartNumber) arraySubjectListY [counter1*3] =0;
                    }
                }
                else{
                    
                    failCheckFlag2 = 0;
                    
                    if (startGapFlag == 1){
                        //cout<<jumpX1<<" "<<jumpY1<<" "<< jumpX2<<" "<<jumpY2<<" Jump_2"<<endl;
                        
                        gapChaseCount = 0;
                        
                        for (int counter1 = subStartCount; counter1 <= subEndCount; counter1++){
                            if (gapChaseCount+5 > gapChaseLimit) [self gapChaseUpdate];
                            
                            arrayGapChase [gapChaseCount] = arraySelectedSubject [counter1*6], gapChaseCount++;
                            arrayGapChase [gapChaseCount] = arraySelectedSubject [counter1*6+1], gapChaseCount++;
                            arrayGapChase [gapChaseCount] = 1, gapChaseCount++;
                        }
                        
                        for (int counter1 = blockStart; counter1 <= blockEnd; counter1++){
                            if (gapChaseCount+5 > gapChaseLimit) [self gapChaseUpdate];
                            
                            arrayGapChase [gapChaseCount] = arraySelectedReference [counter1*6], gapChaseCount++;
                            arrayGapChase [gapChaseCount] = arraySelectedReference [counter1*6+1], gapChaseCount++;
                            arrayGapChase [gapChaseCount] = 2, gapChaseCount++;
                        }
                        
                        lineSet = 2;
                        gapChase3 = [[GapChase3 alloc] init];
                        chaseResult = [gapChase3 gapChaseing3:subEndFinalX:subEndFinalY:refStartFinalX:refStartFinalY:lineSet:maxPointDimX:maxPointDimY:minPointDimX:minPointDimY:minValue];
                        
                        if (chaseResult == 0){ //------If it is successful, save data------
                            if (gapChaseCount+gapDataStartCount+5 > gapDataStartLimit){
                                int *arraySourceTemp = new int [gapDataStartCount+50];
                                for (int counter1 = 0; counter1 < gapDataStartCount; counter1++) arraySourceTemp [counter1] = arrayGapDataStart [counter1];
                                
                                delete [] arrayGapDataStart;
                                arrayGapDataStart = new int [gapChaseCount+gapDataStartCount+500];
                                
                                for (int counter1 = 0; counter1 < gapDataStartCount; counter1++) arrayGapDataStart [counter1] = arraySourceTemp [counter1];
                                delete [] arraySourceTemp;
                            }
                            
                            for (int counter1 = 0; counter1 < gapChaseCount/3; counter1++){
                                arrayGapDataStart [gapDataStartCount] = arrayGapChase [counter1*3], gapDataStartCount++;
                                arrayGapDataStart [gapDataStartCount] = arrayGapChase [counter1*3+1], gapDataStartCount++;
                                arrayGapDataStart [gapDataStartCount] = arrayGapChase [counter1*3+2], gapDataStartCount++;
                            }
                        }
                        else failCheckFlag2 = 1;
                    }
                    
                    if (failCheckFlag2 == 1){
                        for (int counter1 = 0; counter1 < referenceListCountX/3; counter1++){
                            if (arrayReferenceListX [counter1*3] == counterpartNumber && arrayReferenceListX [counter1*3+1] == blockNumber) arrayReferenceListX [counter1*3] = 0;
                        }
                        
                        for (int counter1 = 0; counter1 < referenceListCountY/3; counter1++){
                            if (arrayReferenceListY [counter1*3] == counterpartNumber && arrayReferenceListY [counter1*3+1] == blockNumber) arrayReferenceListY [counter1*3] = 0;
                        }
                        
                        for (int counter1 = 0; counter1 < subjectListCountX/3; counter1++){
                            if (arraySubjectListX [counter1*3] == blockNumber && arraySubjectListX [counter1*3+1] == counterpartNumber) arraySubjectListX [counter1*3] = 0;
                        }
                        
                        for (int counter1 = 0; counter1 < subjectListCountY/3; counter1++){
                            if (arraySubjectListY [counter1*3] == blockNumber && arraySubjectListY [counter1*3+1] == counterpartNumber) arraySubjectListY [counter1*3] = 0;
                        }
                    }
                    else{
                        
                        linkedLineCount = 0;
                        
                        for (int counter1 = refStartFinalCount; counter1 <= refEndFinalCount; counter1++){
                            if (linkedLineCount+10 > linkedLineLimit) [self linkedLineUpDate];
                            
                            arrayLinkedLine [linkedLineCount] = arraySelectedReference [counter1*6], linkedLineCount++; //------X position------
                            arrayLinkedLine [linkedLineCount] = arraySelectedReference [counter1*6+1], linkedLineCount++; //------Y position------
                            arrayLinkedLine [linkedLineCount] = arraySelectedReference [counter1*6+2], linkedLineCount++; //------Value------
                            arrayLinkedLine [linkedLineCount] = 0, linkedLineCount++; //------Connected part------
                            
                            if ((endGapFlag == 0 || gapDataEndCount == 0) && counter1 == refEndFinalCount) arrayLinkedLine [linkedLineCount] = 1, linkedLineCount++;
                            else arrayLinkedLine [linkedLineCount] = 0, linkedLineCount++;
                        }
                        
                        if (endGapFlag == 1 && gapDataEndCount != 0){
                            for (int counter1 = 0; counter1 < gapDataEndCount/3; counter1++){
                                if (linkedLineCount+10 > linkedLineLimit) [self linkedLineUpDate];
                                
                                arrayLinkedLine [linkedLineCount] = arrayGapDataEnd [counter1*3], linkedLineCount++;
                                arrayLinkedLine [linkedLineCount] = arrayGapDataEnd [counter1*3+1], linkedLineCount++;
                                arrayLinkedLine [linkedLineCount] = arrayGapDataEnd [counter1*3+2], linkedLineCount++;
                                arrayLinkedLine [linkedLineCount] = 1, linkedLineCount++;
                                
                                if (counter1 == gapDataEndCount/3-1) arrayLinkedLine [linkedLineCount] = 1, linkedLineCount++;
                                else arrayLinkedLine [linkedLineCount] = 0, linkedLineCount++;
                            }
                        }
                        
                        for (int counter1 = subStartFinalCount; counter1 <= subEndFinalCount; counter1++){
                            if (linkedLineCount+10 > linkedLineLimit) [self linkedLineUpDate];
                            
                            arrayLinkedLine [linkedLineCount] = arraySelectedSubject [counter1*6], linkedLineCount++;
                            arrayLinkedLine [linkedLineCount] = arraySelectedSubject [counter1*6+1], linkedLineCount++;
                            arrayLinkedLine [linkedLineCount] = arraySelectedSubject [counter1*6+2], linkedLineCount++;
                            arrayLinkedLine [linkedLineCount] = 0, linkedLineCount++;
                            
                            if ((startGapFlag == 0 || gapDataStartCount == 0) && counter1 == subEndFinalCount) arrayLinkedLine [linkedLineCount] = 2, linkedLineCount++;
                            else arrayLinkedLine [linkedLineCount] = 0, linkedLineCount++;
                        }
                        
                        if (startGapFlag == 1 && gapDataStartCount != 0){
                            for (int counter1 = 0; counter1 < gapDataStartCount/3; counter1++){
                                if (linkedLineCount+10 > linkedLineLimit) [self linkedLineUpDate];
                                
                                arrayLinkedLine [linkedLineCount] = arrayGapDataStart [counter1*3], linkedLineCount++;
                                arrayLinkedLine [linkedLineCount] = arrayGapDataStart [counter1*3+1], linkedLineCount++;
                                arrayLinkedLine [linkedLineCount] = arrayGapDataStart [counter1*3+2], linkedLineCount++;
                                arrayLinkedLine [linkedLineCount] = 1, linkedLineCount++;
                                
                                if (counter1 == gapDataStartCount/3-1) arrayLinkedLine [linkedLineCount] = 2, linkedLineCount++;
                                else arrayLinkedLine [linkedLineCount] = 0, linkedLineCount++;
                            }
                        }
                        
                        for (int counter1 = refStartFinalCount; counter1 <= refEndFinalCount; counter1++){
                            arrayReferenceListX [counter1*3+2] = 3;
                            arraySelectedReference [counter1*6+5] = 3;
                        }
                        
                        for (int counter1 = 0; counter1 < referenceListCountX/3; counter1++){
                            if (arrayReferenceListX [counter1*3] == counterpartNumber && arrayReferenceListX [counter1*3+1] == blockNumber) arrayReferenceListX [counter1*3] = 3;
                        }
                        
                        for (int counter1 = refStartFinalCount; counter1 < referenceListCountY/3; counter1++) arrayReferenceListY [counter1*3+2] = 3;
                        
                        for (int counter1 = 0; counter1 < referenceListCountY/3; counter1++){
                            if (arrayReferenceListY [counter1*3] == counterpartNumber && arrayReferenceListY [counter1*3+1] == blockNumber) arrayReferenceListY [counter1*3] = 0;
                        }
                        
                        if (refStartFinalCount > blockStart+3) arraySelectedReference [(refStartFinalCount-1)*6+5] = 2;
                        
                        if (refStartFinalCount == blockStart+2){
                            arraySelectedReference [(refStartFinalCount-1)*6+5] = 3;
                            arraySelectedReference [(refStartFinalCount-2)*6+5] = 3;
                            arrayReferenceListX [(refStartFinalCount-1)*3] = 0;
                            arrayReferenceListX [(refStartFinalCount-2)*3] = 0;
                            arrayReferenceListX [(refStartFinalCount-1)*3+2] = 3;
                            arrayReferenceListX [(refStartFinalCount-2)*3+2] = 3;
                            arrayReferenceListY [(refStartFinalCount-1)*3] = 0;
                            arrayReferenceListY [(refStartFinalCount-2)*3] = 0;
                            arrayReferenceListY [(refStartFinalCount-1)*3+2] = 3;
                            arrayReferenceListY [(refStartFinalCount-2)*3+2] = 3;
                        }
                        
                        if (refStartFinalCount == blockStart+1){
                            arraySelectedReference [(refStartFinalCount-1)*6+5] = 3;
                            arrayReferenceListX [(refStartFinalCount-1)*3] = 0;
                            arrayReferenceListX [(refStartFinalCount-1)*3+2] = 3;
                            arrayReferenceListY [(refStartFinalCount-1)*3] = 0;
                            arrayReferenceListY [(refStartFinalCount-1)*3+2] = 3;
                        }
                        
                        if (refEndFinalCount < blockEnd-3) arraySelectedReference [(refEndFinalCount+1)*6+5] = 1;
                        
                        if (refEndFinalCount == blockEnd-2){
                            arraySelectedReference [(refEndFinalCount+1)*6+5] = 3;
                            arraySelectedReference [(refEndFinalCount+2)*6+5] = 3;
                            arrayReferenceListX [(refEndFinalCount+1)*3] = 0;
                            arrayReferenceListX [(refEndFinalCount+2)*3] = 0;
                            arrayReferenceListX [(refEndFinalCount+1)*3+2] = 3;
                            arrayReferenceListX [(refEndFinalCount+2)*3+2] = 3;
                            arrayReferenceListY [(refEndFinalCount+1)*3] = 0;
                            arrayReferenceListY [(refEndFinalCount+2)*3] = 0;
                            arrayReferenceListY [(refEndFinalCount+1)*3+2] = 0;
                            arrayReferenceListY [(refEndFinalCount+2)*3+2] = 0;
                        }
                        
                        if (refEndFinalCount == blockEnd-1){
                            arraySelectedReference [(refEndFinalCount+1)*6+5] = 3;
                            arrayReferenceListX [(refEndFinalCount+1)*3] = 0;
                            arrayReferenceListX [(refEndFinalCount+1)*3+2] = 3;
                            arrayReferenceListY [(refEndFinalCount+1)*3] = 0;
                            arrayReferenceListY [(refEndFinalCount+1)*3+2] = 3;
                        }
                        
                        //for (int counterA = 0; counterA < selectedReferenceCount/6; counterA++){
                        //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arraySelectedReference [counterA*6+counterB];
                        //	cout<<" arraySelectedReference "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < referenceListCountX/3; counterA++){
                        //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayReferenceListX [counterA*3+counterB];
                        //	cout<<" arrayReferenceListX "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < referenceListCountY/3; counterA++){
                        //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayReferenceListY [counterA*3+counterB];
                        //	cout<<" arrayReferenceListY "<<counterA<<endl;
                        //}
                        
                        for (int counter1 = subStartFinalCount; counter1 <= subEndFinalCount; counter1++){
                            arraySubjectListX [counter1*3+2] = 3;
                            arraySelectedSubject [counter1*6+5] = 3;
                        }
                        
                        for (int counter1 = 0; counter1 < subjectListCountX/3; counter1++){
                            if (arraySubjectListX [counter1*3] == blockNumber && arraySubjectListX [counter1*3+1] == counterpartNumber) arraySubjectListX [counter1*3] = 0;
                        }
                        
                        for (int counter1 = subStartFinalCount; counter1 <= subEndFinalCount; counter1++) arraySubjectListY [counter1*3+2] = 3;
                        
                        for (int counter1 = 0; counter1 < subjectListCountY/3; counter1++){
                            if (arraySubjectListY [counter1*3] == blockNumber && arraySubjectListY [counter1*3+1] == counterpartNumber) arraySubjectListY [counter1*3] = 0;
                        }
                        
                        if (subStartFinalCount > subStartCount+3) arraySelectedSubject [(subStartFinalCount-1)*6+5] = 2;
                        
                        if (subStartFinalCount == subStartCount+2){
                            arraySelectedSubject [(subStartFinalCount-1)*6+5] = 3;
                            arraySelectedSubject [(subStartFinalCount-2)*6+5] = 3;
                            arraySubjectListX [(subStartFinalCount-1)*3] = 0;
                            arraySubjectListX [(subStartFinalCount-2)*3] = 0;
                            arraySubjectListX [(subStartFinalCount-1)*3+2] = 3;
                            arraySubjectListX [(subStartFinalCount-2)*3+2] = 3;
                            arraySubjectListY [(subStartFinalCount-1)*3] = 0;
                            arraySubjectListY [(subStartFinalCount-2)*3] = 0;
                            arraySubjectListY [(subStartFinalCount-1)*3+2] = 3;
                            arraySubjectListY [(subStartFinalCount-2)*3+2] = 3;
                        }
                        
                        if (subStartFinalCount == subStartCount+1){
                            arraySelectedSubject [(subStartFinalCount-1)*6+5] = 3;
                            arraySubjectListX [(subStartFinalCount-1)*3] = 0;
                            arraySubjectListX [(subStartFinalCount-1)*3+2] = 3;
                            arraySubjectListY [(subStartFinalCount-1)*3] = 0;
                            arraySubjectListY [(subStartFinalCount-1)*3+2] = 3;
                        }
                        
                        if (subEndFinalCount < subEndCount-3) arraySelectedSubject [(subEndFinalCount+1)*6+5] = 1;
                        
                        if (subEndFinalCount == subEndCount-2){
                            arraySelectedSubject [(subEndFinalCount+1)*6+5] = 3;
                            arraySelectedSubject [(subEndFinalCount+2)*6+5] = 3;
                            arraySubjectListX [(subEndFinalCount+1)*3] = 0;
                            arraySubjectListX [(subEndFinalCount+2)*3] = 0;
                            arraySubjectListX [(subEndFinalCount+1)*3+2] = 3;
                            arraySubjectListX [(subEndFinalCount+2)*3+2] = 3;
                            arraySubjectListY [(subEndFinalCount+1)*3] = 0;
                            arraySubjectListY [(subEndFinalCount+2)*3] = 0;
                            arraySubjectListY [(subEndFinalCount+1)*3+2] = 3;
                            arraySubjectListY [(subEndFinalCount+2)*3+2] = 3;
                        }
                        
                        if (subEndFinalCount == subEndCount-1){
                            arraySelectedSubject [(subEndFinalCount+1)*6+5] = 3;
                            arraySubjectListX [(subEndFinalCount+1)*3] = 0;
                            arraySubjectListX [(subEndFinalCount+1)*3+2] = 3;
                            arraySubjectListY [(subEndFinalCount+1)*3] = 0;
                            arraySubjectListY [(subEndFinalCount+1)*3+2]= 3;
                        }
                        
                        //for (int counterA = 0; counterA < selectedSubjectCount/6; counterA++){
                        //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arraySelectedSubject [counterA*6+counterB];
                        //	cout<<" arraySelectedSubject "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < subjectListCountX/3; counterA++){
                        //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arraySubjectListX [counterA*3+counterB];
                        //	cout<<" arraySubjectListX "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < subjectListCountY/3; counterA++){
                        //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arraySubjectListY [counterA*3+counterB];
                        //	cout<<" arraySubjectListY "<<counterA<<endl;
                        //}
                    }
                }
                
                delete [] arrayGapDataEnd;
                delete [] arrayGapDataStart;
            }
        }
        
    } while (terminationFlag == 1);
    
    delete [] arraySelectedReference;
    delete [] arraySelectedSubject;
    delete [] arrayReferenceListX;
    delete [] arrayReferenceListY;
    delete [] arraySubjectListX;
    delete [] arraySubjectListY;
    
    if (referenceListStatus == 1) delete [] arrayReferenceList;
    if (subjectListStatus == 1) delete [] arraySubjectList;
}

-(void)gapChaseUpdate{
    int *arrayGapUpDate = new int [gapChaseCount+10];
    for (int counter1 = 0; counter1 < gapChaseCount; counter1++) arrayGapUpDate [counter1] = arrayGapChase [counter1];
    
    delete [] arrayGapChase;
    arrayGapChase = new int [gapChaseLimit+500];
    gapChaseLimit = gapChaseLimit+500;
    
    for (int counter1 = 0; counter1 < gapChaseCount; counter1++) arrayGapChase [counter1] = arrayGapUpDate [counter1];
    delete [] arrayGapUpDate;
}

-(void)linkedLineUpDate{
    int *arrayUpDate = new int [linkedLineCount+10];
    
    for (int counter1 = 0; counter1 < linkedLineCount; counter1++) arrayUpDate [counter1] = arrayLinkedLine [counter1];
    
    delete [] arrayLinkedLine;
    arrayLinkedLine = new int [linkedLineLimit+1000];
    linkedLineLimit = linkedLineLimit+1000;
    
    for (int counter1 = 0; counter1 < linkedLineCount; counter1++) arrayLinkedLine [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

@end
