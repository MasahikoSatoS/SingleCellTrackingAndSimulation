//
// EdgeTracing.mm
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 07/07/12.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#import "EdgeTracing.h"

@implementation EdgeTracing

-(void)edgeTrace:(int)subjectArray{
    int *arrayLimitType;
    int *arrayCutType;
    int *arrayDimensionType;
    
    int vectorNumberCheck = 0;
    
    if (subjectArray != 1 && forNextConnectivityCount != 0){
        for (int counter1 = 0; counter1 < forNextConnectivityCount/5; counter1++){
            if (arrayForNextConnectivity [counter1*5+3] > vectorNumberCheck) vectorNumberCheck = arrayForNextConnectivity [counter1*5+3];
        }
        
        int *limitInformationTemp = new int [vectorNumberCheck+1];
        int *cutInformationTemp = new int [vectorNumberCheck+1];
        int *cellDimensionTemp = new int [vectorNumberCheck+1];
        
        for (int counter1 = 0; counter1 < vectorNumberCheck+1; counter1++){
            limitInformationTemp [counter1] = 0;
            cutInformationTemp [counter1] = 0;
            cellDimensionTemp [counter1] = 0;
        }
        
        for (int counter1 = 0; counter1 < forNextConnectivityAssCount/6; counter1++){
            int valueTemp = arrayForNextConnectivityAss [counter1*6];
            limitInformationTemp [valueTemp] = arrayForNextConnectivityAss [counter1*6+1];
            cutInformationTemp [valueTemp] = arrayForNextConnectivityAss [counter1*6+2];
            cellDimensionTemp [valueTemp] = arrayForNextConnectivityAss [counter1*6+4];
        }
        
        arrayLimitType = new int [vectorNumberCheck+1];
        arrayCutType = new int [vectorNumberCheck+1];
        arrayDimensionType = new int [vectorNumberCheck+1];
        
        for (int counter1 = 0; counter1 < vectorNumberCheck+1; counter1++){
            arrayLimitType [counter1] = 0;
            arrayCutType [counter1] = 0;
            arrayDimensionType [counter1] = 0;
        }
        
        for (int counter1 = 1; counter1 < vectorNumberCheck+1; counter1++){
            arrayLimitType [counter1] = limitInformationTemp [counter1];
            arrayCutType [counter1] = cutInformationTemp [counter1];
            arrayDimensionType [counter1] = cellDimensionTemp [counter1];
        }
        
        delete [] limitInformationTemp;
        delete [] cutInformationTemp;
        delete [] cellDimensionTemp;
    }
    
    int **connectivityMap = new int *[imageHeight];
    int **connectivityMap2 = new int *[imageHeight];
    
    for (int counter1 = 0; counter1 < imageHeight; counter1++){
        connectivityMap [counter1] = new int [imageHeight];
        connectivityMap2 [counter1] = new int [imageHeight];
    }
    
    int maxConnectivityNumber = 0;
    
    //------Connectivity Map data read, maxConnectivityNumber holds largest connectivity number, connectivityMap2 contains original map------
    for (int counterY = 0; counterY < imageHeight; counterY++){
        for (int counterX = 0; counterX < imageHeight; counterX++){
            connectivityMap2 [counterY][counterX] = arrayImageConnectivity [counterY][counterX];
            connectivityMap [counterY][counterX] = 0;
            
            if (connectivityMap2 [counterY][counterX] > maxConnectivityNumber) maxConnectivityNumber = connectivityMap2 [counterY][counterX];
        }
    }
    
    //for (int counterA = 1500; counterA < 1620; counterA++){
    //	for (int counterB = 350; counterB < 450; counterB++) cout<<" "<<connectivityMap2 [counterA][counterB];
    //	cout<<" connectivityMap2 "<<counterA<<endl;
    //}
    
    //cout<<maxConnectivityNumber<<" EdgeMaxConnectNo"<<endl;
    
    //------Draw connectivity Map into connectivityMap, keep connectivity number at the outline, internal parts are -1------
    int neighbourCount = 0;
    int connectivityNumber = 0;
    
    for (int counterY = 0; counterY < imageHeight; counterY++){
        for (int counterX = 0; counterX < imageHeight; counterX++){
            connectivityNumber = connectivityMap2 [counterY][counterX];
            
            if (connectivityMap2 [counterY][counterX] != 0){
                if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMap2 [counterY-1][counterX-1] == connectivityNumber) neighbourCount++;
                if (counterY-1 >= 0 && connectivityMap2 [counterY-1][counterX] == connectivityNumber) neighbourCount++;
                if (counterY-1 >= 0 && counterX+1 < imageHeight && connectivityMap2 [counterY-1][counterX+1] == connectivityNumber) neighbourCount++;
                if (counterX+1 < imageHeight && connectivityMap2 [counterY][counterX+1] == connectivityNumber) neighbourCount++;
                if (counterY+1 < imageHeight && counterX+1 < imageHeight && connectivityMap2 [counterY+1][counterX+1] == connectivityNumber) neighbourCount++;
                if (counterY+1 < imageHeight && connectivityMap2 [counterY+1][counterX] == connectivityNumber) neighbourCount++;
                if (counterY+1 < imageHeight && counterX-1 >= 0 && connectivityMap2 [counterY+1][counterX-1] == connectivityNumber) neighbourCount++;
                if (counterX-1 >= 0 && connectivityMap2 [counterY][counterX-1] == connectivityNumber) neighbourCount++;
                if (connectivityMap2 [counterY][counterX] == connectivityNumber) neighbourCount++;
                if (neighbourCount != 9) connectivityMap [counterY][counterX] = connectivityNumber;
                else if (neighbourCount == 9) connectivityMap [counterY][counterX] = -1;
                
                neighbourCount = 0;
            }
        }
    }
    
    //------Average Intensity determination, only for the first round------
    int *averageIntensity = new int [maxConnectivityNumber+2];
    
    if (subjectArray == 1){
        int *numberOfPointConnect = new int [maxConnectivityNumber+2];
        for (int counter1 = 0; counter1 <= maxConnectivityNumber; counter1++){
            numberOfPointConnect [counter1] = 0;
            averageIntensity [counter1] = 0;
        }
        
        for (int counterY = 0; counterY < imageHeight; counterY++){
            for (int counterX = 0; counterX < imageHeight; counterX++){
                int valueTemp = connectivityMap2 [counterY][counterX];
                numberOfPointConnect [valueTemp]++;
                averageIntensity [valueTemp] = averageIntensity [valueTemp]+arrayExtractedImage [counterY][counterX];
            }
        }
        
        for (int counter1 = 1; counter1 <= maxConnectivityNumber; counter1++){
            if (numberOfPointConnect [counter1] != 0) averageIntensity [counter1] = (int)(averageIntensity [counter1]/(double)numberOfPointConnect [counter1]);
            else averageIntensity [counter1] = -1;
        }
        
        delete [] numberOfPointConnect;
    }
    
    //------Edge finding, Up, Down, Right and Left------
    int edgeTraceEntryCount = 0;
    
    for (int counterY = 0; counterY < imageHeight; counterY++){
        for (int counterX = 0; counterX < imageHeight; counterX++){
            if (connectivityMap [counterY][counterX] > 0) edgeTraceEntryCount++;
        }
    }
    
    int *arrayEdgeTraceValue1 = new int [edgeTraceEntryCount*2+1];
    int *arrayEdgeTraceX1 = new int [edgeTraceEntryCount*2+1];
    int *arrayEdgeTraceY1 = new int [edgeTraceEntryCount*2+1];
    int *arrayEdgeTraceValue2 = new int [edgeTraceEntryCount*2+1];
    int *arrayEdgeTraceX2 = new int [edgeTraceEntryCount*2+1];
    int *arrayEdgeTraceY2 = new int [edgeTraceEntryCount*2+1];
    int *arrayEdgeTraceValue3 = new int [edgeTraceEntryCount*2+1];
    int *arrayEdgeTraceX3 = new int [edgeTraceEntryCount*2+1];
    int *arrayEdgeTraceY3 = new int [edgeTraceEntryCount*2+1];
    int *arrayEdgeTraceValue4 = new int [edgeTraceEntryCount*2+1];
    int *arrayEdgeTraceX4 = new int [edgeTraceEntryCount*2+1];
    int *arrayEdgeTraceY4 = new int [edgeTraceEntryCount*2+1];
    
    for (int counter1 = 0; counter1 < edgeTraceEntryCount*2; counter1++){
        arrayEdgeTraceValue1 [counter1] = 0;
        arrayEdgeTraceX1 [counter1] = 0;
        arrayEdgeTraceY1 [counter1] = 0;
        arrayEdgeTraceValue2 [counter1] = 0;
        arrayEdgeTraceX2 [counter1] = 0;
        arrayEdgeTraceY2 [counter1] = 0;
        arrayEdgeTraceValue3 [counter1] = 0;
        arrayEdgeTraceX3 [counter1] = 0;
        arrayEdgeTraceY3 [counter1] = 0;
        arrayEdgeTraceValue4 [counter1] = 0;
        arrayEdgeTraceX4 [counter1] = 0;
        arrayEdgeTraceY4 [counter1] = 0;
    }
    
    int edgeTraceEntry1 = 0;
    int edgeTraceEntry2 = 0;
    int edgeTraceEntry3 = 0;
    int edgeTraceEntry4 = 0;
    int lineData [4][21];
    
    int valueTemp = 0;
    int lineCount = 0;
    int limitCase = 0;
    int limitCount = 0;
    int processType = 0;
    int cutType = 0;
    int cellDimension = 0;
    int boarderX = 0;
    int boarderY = 0;
    int selfCheck = 0;
    int outOfFrame = 0;
    int outOfFrameFlag = 0;
    int lowestValue = 0;
    int lowestPoint = 0;
    int lowestFix = 0;
    int differenceValue1 = 0;
    int differenceValue2 = 0;
    int differenceValue3 = 0;
    int secondPeakValue = 0;
    int secondPeakFlag = 0;
    int hundredEncounterPoint = 0;
    int hundredEncounterFlag = 0;
    int lowerFifteen = 0;
    int lowerFifteenFlag = 0;
    int internalPoint = 0;
    int firstPointValue = 0;
    int doneFlag = 0;
    int terminationFlag = 0;
    
    for (int counterY = 0; counterY < imageHeight; counterY++){
        for (int counterX = 0; counterX < imageHeight; counterX++){
            
            //------Read pix value, 0-21 pix from the center------
            if (connectivityMap [counterY][counterX] > 0){
                valueTemp = connectivityMap [counterY][counterX];
                
                if (subjectArray == 1){
                    lineCount = 1;
                    lineData [0][0] = arrayExtractedImage [counterY][counterX];
                    
                    for (int counter1 = counterY-1; counter1 >= counterY-20; counter1--){
                        if (counter1 >= 0){
                            if (valueTemp == connectivityMap [counter1][counterX] || connectivityMap [counter1][counterX] == -1) lineData [0][lineCount] = -1;
                            else lineData [0][lineCount] = arrayExtractedImage [counter1][counterX];
                        }
                        else lineData [0][lineCount] = -3;
                        
                        lineCount++;
                    }
                    
                    lineCount = 1;
                    lineData [1][0] = arrayExtractedImage [counterY][counterX];
                    
                    for (int counter1 = counterY+1; counter1 <= counterY+20; counter1++){
                        if (counter1 < imageHeight){
                            if (valueTemp == connectivityMap [counter1][counterX] || connectivityMap [counter1][counterX] == -1) lineData [1][lineCount] = -1;
                            else lineData [1][lineCount] = arrayExtractedImage [counter1][counterX];
                        }
                        else lineData [1][lineCount] = -3;
                        
                        lineCount++;
                    }
                    
                    lineCount = 1;
                    lineData [2][0] = arrayExtractedImage [counterY][counterX];
                    
                    for (int counter1 = counterX-1; counter1 >= counterX-20; counter1--){
                        if (counter1 >= 0){
                            if (valueTemp == connectivityMap [counterY][counter1] || connectivityMap [counterY][counter1] == -1) lineData [2][lineCount] = -1;
                            else lineData [2][lineCount] = arrayExtractedImage [counterY][counter1];
                        }
                        else lineData [2][lineCount] = -3;
                        
                        lineCount++;
                    }
                    
                    lineCount = 1;
                    lineData [3][0] = arrayExtractedImage [counterY][counterX];
                    
                    for (int counter1 = counterX+1; counter1 <= counterX+20; counter1++){
                        if (counter1 < imageHeight){
                            if (valueTemp == connectivityMap [counterY][counter1] || connectivityMap [counterY][counter1] == -1) lineData [3][lineCount] = -1;
                            else lineData [3][lineCount] = arrayExtractedImage [counterY][counter1];
                        }
                        else lineData [3][lineCount] = -3;
                        
                        lineCount++;
                    }
                }
                
                if (subjectArray != 1){
                    limitCase = 0;
                    limitCount = 0;
                    
                    if (valueTemp <= vectorNumberCheck){
                        processType = arrayLimitType [valueTemp];
                        cutType = arrayCutType [valueTemp];
                        cellDimension = arrayDimensionType [valueTemp];
                        
                        if (processType == 2 && cellDimension < 4){
                            limitCase = 2;
                            limitCount = 1;
                        }
                        else if (processType == 2 && cellDimension >= 4 && cutType == 1){
                            limitCase = 2;
                            limitCount = 1;
                        }
                        else if (processType == 2 && cellDimension >= 4 && cutType == 2){
                            limitCase = 2;
                            limitCount = 5;
                        }
                    }
                    
                    lineCount = 1;
                    lineData [0][0] = arrayExtractedImage [counterY][counterX];
                    
                    for (int counter1 = counterY-1; counter1 >= counterY-20; counter1--){
                        if (counter1 >= 0){
                            if (limitCase == 2 && lineCount > limitCount) lineData [0][lineCount] = -1;
                            else if (valueTemp == connectivityMap [counter1][counterX] || connectivityMap [counter1][counterX] == -1) lineData [0][lineCount] = -1;
                            else lineData [0][lineCount] = arrayExtractedImage [counter1][counterX];
                        }
                        else lineData [0][lineCount] = -3;
                        
                        lineCount++;
                    }
                    
                    lineCount = 1;
                    lineData [1][0] = arrayExtractedImage [counterY][counterX];
                    
                    for (int counter1 = counterY+1; counter1 <= counterY+20; counter1++){
                        if (counter1 < imageHeight){
                            if (limitCase == 2 && lineCount > limitCount) lineData [1][lineCount] = -1;
                            else if (valueTemp == connectivityMap [counter1][counterX] || connectivityMap [counter1][counterX] == -1) lineData [1][lineCount] = -1;
                            else lineData [1][lineCount] = arrayExtractedImage [counter1][counterX];
                        }
                        else lineData [1][lineCount] = -3;
                        
                        lineCount++;
                    }
                    
                    lineCount = 1;
                    lineData [2][0] = arrayExtractedImage [counterY][counterX];
                    
                    for (int counter1 = counterX-1; counter1 >= counterX-20; counter1--){
                        if (counter1 >= 0){
                            if (limitCase == 2 && lineCount > limitCount) lineData [2][lineCount] = -1;
                            else if (valueTemp == connectivityMap [counterY][counter1] || connectivityMap [counterY][counter1] == -1) lineData [2][lineCount] = -1;
                            else lineData [2][lineCount] = arrayExtractedImage [counterY][counter1];
                        }
                        else lineData [2][lineCount] = -3;
                        
                        lineCount++;
                    }
                    
                    lineCount = 1;
                    lineData [3][0] = arrayExtractedImage [counterY][counterX];
                    
                    for (int counter1 = counterX+1; counter1 <= counterX+20; counter1++){
                        if (counter1 < imageHeight){
                            if (limitCase == 2 && lineCount > limitCount) lineData [3][lineCount] = -1;
                            else if (valueTemp == connectivityMap [counterY][counter1] || connectivityMap [counterY][counter1] == -1) lineData [3][lineCount] = -1;
                            else lineData [3][lineCount] = arrayExtractedImage [counterY][counter1];
                        }
                        else lineData [3][lineCount] = -3;
                        
                        lineCount++;
                    }
                }
                
                //------Evaluation of determination parameters------
                for (int counter1 = 0; counter1 < 4; counter1++){
                    boarderX = counterX;
                    boarderY = counterY;
                    selfCheck = 0;
                    outOfFrame = -1;
                    outOfFrameFlag = 0;
                    lowestValue = 255;
                    lowestPoint = -1;
                    lowestFix = 0;
                    differenceValue1 = -1;
                    differenceValue2 = -1;
                    differenceValue3 = -1;
                    secondPeakValue = -1;
                    secondPeakFlag = 0;
                    hundredEncounterPoint = -1;
                    hundredEncounterFlag = 0;
                    lowerFifteen = -1;
                    lowerFifteenFlag = 0;
                    internalPoint = 0;
                    
                    if (subjectArray == 1 && averageIntensity [valueTemp] != -1) firstPointValue = (averageIntensity [valueTemp]+lineData [counter1][0])/2;
                    else firstPointValue = lineData [counter1][0];
                    
                    if (lineData [counter1][1] >= 0) differenceValue1 = firstPointValue-lineData [counter1][1]; //------Determine difference between the firstPoint-point two: differenceValue1, if firstPoint-point three is > 20: differenceValue2, if firstPoint-point four is > 20: differenceValue3------
                    if (lineData [counter1][1] >= 0 && lineData [counter1][2] >= 0 && firstPointValue-lineData [counter1][2] > 20) differenceValue2 = firstPointValue-lineData [counter1][2];
                    if (lineData [counter1][1] >= 0 && lineData [counter1][2] >= 0 && lineData [counter1][3] >= 0 && firstPointValue-lineData [counter1][3] > 20) differenceValue3 = firstPointValue-lineData [counter1][3];
                    if (lineData [counter1][1] == -1) selfCheck = 1;
                    
                    for (int counter2 = 1; counter2 < 21; counter2++){
                        if (lineData [counter1][counter2] == -3 && outOfFrameFlag == 0){
                            outOfFrame = counter2;
                            outOfFrameFlag = 1; //------Out of frame, write -3------
                        }
                        if (lineData [counter1][counter2] != 100){
                            if (hundredEncounterFlag == 1){
                                hundredEncounterPoint = 0;
                                hundredEncounterFlag = 0; //------If 100 continues more than two, set this flag------
                            }
                            if (lineData [counter1][counter2] == -1) internalPoint = 1; //------If point two is -1, line enters into internal part of connectivity pixels. Set this flag------
                            if (lineData [counter1][counter2] < 50 && lowerFifteenFlag == 0 && lowestFix == 0 && internalPoint == 0){
                                lowerFifteen = counter2;
                                lowerFifteenFlag = 1; //------If pix value < 50, set this flag------
                            }
                            if (lowestValue > lineData [counter1][counter2] && lineData [counter1][counter2] >= 0 && lowestFix == 0 && internalPoint == 0){ //------Lowest point and value find------
                                lowestValue = lineData [counter1][counter2];
                                lowestPoint = counter2;
                            }
                            if (lineData [counter1][counter2] >= 0 && lineData [counter1][counter2]-lowestValue > 20 && lowestFix == 0 && internalPoint == 0){ //------The second peak find------
                                secondPeakValue = lineData [counter1][counter2];
                                lowestFix = 1;
                            }
                            if (secondPeakValue <= lineData [counter1][counter2] && lineData [counter1][counter2] >= 0 && lowestFix == 1 && secondPeakFlag == 0 && internalPoint == 0){
                                secondPeakValue = lineData [counter1][counter2];
                            }
                            if (secondPeakValue-lineData [counter1][counter2] > 20 && lineData [counter1][counter2] >= 0 && lowestFix == 1 && secondPeakFlag == 0 && internalPoint == 0) secondPeakFlag = 1;
                        }
                        else if (lineData [counter1][counter2] == 100 && hundredEncounterFlag == 0){
                            hundredEncounterPoint = counter2;
                            hundredEncounterFlag = 1;
                        }
                        else if (lineData [counter1][counter2] == 100 && hundredEncounterFlag == 1){
                            lowestFix = 1;
                            secondPeakFlag = 1;
                        }
                    }
                    
                    //------Lowest value validation------
                    if (secondPeakValue == -1 && lowestValue >= 110 && lowestPoint != 20){
                        for (int counter2 = lowestPoint+1; counter2 < 21; counter2++){
                            if (lineData [counter1][counter2]-lowestPoint <= 5 && lineData [counter1][counter2] >= 115){
                                lowestValue = lineData [counter1][counter2];
                                lowestPoint = counter2;
                            }
                        }
                    }
                    if (secondPeakValue == -1 && lowestValue < 100 && lowestPoint != 20){
                        for (int counter2 = lowestPoint+1; counter2 < 21; counter2++){
                            if (lineData [counter1][counter2]-lowestPoint <= 5 && lineData [counter1][counter2] < 100 && lineData [counter1][counter2] >= 0){
                                lowestValue = lineData [counter1][counter2];
                                lowestPoint = counter2;
                            }
                        }
                    }
                    if (secondPeakValue == -1 && (lowestValue < 110 && lowestValue >= 100) && lowestPoint >= 3){
                        for (int counter2 = lowestPoint-1; counter2 >= 1; counter2 = counter2-1){
                            if (lineData [counter1][counter2] < 110 && lineData [counter1][counter2] >= 100){
                                lowestValue = lineData [counter1][counter2];
                                lowestPoint = counter2;
                            }
                        }
                    }
                    
                    //------Edge position set------
                    doneFlag = 0;
                    
                    if (selfCheck == 1){
                        boarderX = -1;
                        boarderY = -1;
                        doneFlag = 1;
                    }
                    
                    if (counter1 == 0){ //------Up------
                        if (firstPointValue >= 200 && doneFlag == 0){
                            if (differenceValue1 != -1 && differenceValue1 >= 80){
                                boarderY = counterY;
                                doneFlag = 1;
                            }
                            if (differenceValue2 != -1 && differenceValue2 >= 80 && doneFlag == 0){
                                boarderY = counterY-1;
                                doneFlag = 1;
                            }
                            if (differenceValue3 != -1 && differenceValue3 >= 80 && doneFlag == 0){
                                boarderY = counterY-2;
                                doneFlag = 1;
                            }
                        }
                        if (firstPointValue < 255 && doneFlag == 0){
                            if (lowestValue != 255 && secondPeakValue == -1){
                                if (lowerFifteen != -1 && lowestPoint != -1 && lowerFifteen <= lowestPoint){
                                    boarderY = counterY-lowerFifteen+1;
                                    doneFlag = 1;
                                }
                                if (lowestPoint != -1 && hundredEncounterPoint != -1 && (lowestPoint+1 == hundredEncounterPoint || lowestPoint+2 == hundredEncounterPoint) && doneFlag == 0){
                                    boarderY = counterY-hundredEncounterPoint+1;
                                    doneFlag = 1;
                                }
                                if (lowestPoint != -1 && outOfFrame != -1 && (lowestPoint+1 == outOfFrame || lowestPoint+2 == outOfFrame) && doneFlag == 0){
                                    boarderY = counterY-outOfFrame+1;
                                    doneFlag = 1;
                                }
                                if (doneFlag == 0){
                                    boarderY = counterY-lowestPoint;
                                    doneFlag = 1;
                                }
                            }
                            if (lowestValue != 255 && secondPeakValue != -1){
                                if (lowerFifteen != -1 && lowestPoint != -1 && lowerFifteen <= lowestPoint){
                                    boarderY = counterY-lowerFifteen+1;
                                    doneFlag = 1;
                                }
                                if (secondPeakValue-lowestValue >= 50 && doneFlag == 0){
                                    boarderY = counterY-lowestPoint;
                                    doneFlag = 1;
                                }
                                if (doneFlag == 0){
                                    boarderY = counterY-lowestPoint;
                                    doneFlag = 1;
                                }
                            }
                        }
                        
                        //cout<<" LP "<<lowestValue<<" LV "<<lowestPoint<<" D1 "<<differenceValue1<<" D2 "<< differenceValue2<<" D3 "<<differenceValue3<<" SV "<<secondPeakValue<<" SP "<<secondPeakPoint<<" HD "<<hundredEncounterPoint<<" LF "<<lowerFifteen<<" "<<endl;
                        
                        if (boarderX != -1 && boarderY != -1){
                            do{ //------100, < 50 verification------
                                
                                terminationFlag = 1;
                                
                                if (boarderY == counterY) terminationFlag = 0;
                                if (boarderY >= imageHeight){
                                    boarderY--;
                                    terminationFlag = 0;
                                }
                                else if (arrayExtractedImage [boarderY][boarderX] == 100 || arrayExtractedImage [boarderY][boarderX] < 50) boarderY = boarderY+1;
                                else terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                            
                            //------For Line 1, Connectivity Number, X position, Y position------
                            arrayEdgeTraceValue1 [edgeTraceEntry1] = valueTemp;
                            arrayEdgeTraceX1 [edgeTraceEntry1] = boarderX;
                            arrayEdgeTraceY1 [edgeTraceEntry1] = boarderY;
                            edgeTraceEntry1++;
                        }
                    }
                    if (counter1 == 1){ //------Down------
                        if (firstPointValue >= 200 && doneFlag == 0){
                            if (differenceValue1 != -1 && differenceValue1 >= 80){
                                boarderY = counterY;
                                doneFlag = 1;
                            }
                            if (differenceValue2 != -1 && differenceValue2 >= 80 && doneFlag == 0){
                                boarderY = counterY+1;
                                doneFlag = 1;
                            }
                            if (differenceValue3 != -1 && differenceValue3 >= 80 && doneFlag == 0){
                                boarderY = counterY+2;
                                doneFlag = 1;
                            }
                        }
                        if (firstPointValue < 255 && doneFlag == 0){
                            if (lowestValue != 255 && secondPeakValue == -1){
                                if (lowerFifteen != -1 && lowestPoint != -1 && lowerFifteen <= lowestPoint){
                                    boarderY = counterY+lowerFifteen-1;
                                    doneFlag = 1;
                                }
                                if (lowestPoint != -1 && hundredEncounterPoint != -1 && (lowestPoint-1 == hundredEncounterPoint || lowestPoint-2 == hundredEncounterPoint) && doneFlag == 0){
                                    boarderY = counterY+hundredEncounterPoint-1;
                                    doneFlag = 1;
                                }
                                if (lowestPoint != -1 && outOfFrame != -1 && (lowestPoint-1 == outOfFrame || lowestPoint-2 == outOfFrame) && doneFlag == 0){
                                    boarderY = counterY+outOfFrame-1;
                                    doneFlag = 1;
                                }
                                if (doneFlag == 0){
                                    boarderY = counterY+lowestPoint;
                                    doneFlag = 1;
                                }
                            }
                            if (lowestValue != 255 && secondPeakValue != -1){
                                if (lowerFifteen != -1 && lowestPoint != -1 && lowerFifteen <= lowestPoint){
                                    boarderY = counterY+lowerFifteen-1;
                                    doneFlag = 1;
                                }
                                if (secondPeakValue-lowestValue >= 50 && doneFlag == 0){
                                    boarderY = counterY+lowestPoint;
                                    doneFlag = 1;
                                }
                                if (doneFlag == 0){
                                    boarderY = counterY+lowestPoint;
                                    doneFlag = 1;
                                }
                            }
                        }
                        if (boarderX != -1 && boarderY != -1){
                            do{ //------100, < 50 verification------
                                
                                terminationFlag = 1;
                                
                                if (boarderY == counterY) terminationFlag = 0;
                                else if (boarderY < 0){
                                    boarderY++;
                                    terminationFlag = 0;
                                }
                                else if (arrayExtractedImage [boarderY][boarderX] == 100 || arrayExtractedImage [boarderY][boarderX] < 50) boarderY = boarderY-1;
                                else terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                            
                            //------For Line 2, Connectivity Number, X position, Y position------
                            arrayEdgeTraceValue2 [edgeTraceEntry2] = valueTemp;
                            arrayEdgeTraceX2 [edgeTraceEntry2] = boarderX;
                            arrayEdgeTraceY2 [edgeTraceEntry2] = boarderY;
                            edgeTraceEntry2++;
                        }
                    }
                    if (counter1 == 2){ //------Left------
                        if (firstPointValue >= 200 && doneFlag == 0){
                            if (differenceValue1 != -1 && differenceValue1 >= 80){
                                boarderX = counterX;
                                doneFlag = 1;
                            }
                            if (differenceValue2 != -1 && differenceValue2 >= 80 && doneFlag == 0){
                                boarderX = counterX-1;
                                doneFlag = 1;
                            }
                            if (differenceValue3 != -1 && differenceValue3 >= 80 && doneFlag == 0){
                                boarderX = counterX-2;
                                doneFlag = 1;
                            }
                        }
                        if (firstPointValue < 255 && doneFlag == 0){
                            if (lowestValue != 255 && secondPeakValue == -1){
                                if (lowerFifteen != -1 && lowestPoint != -1 && lowerFifteen <= lowestPoint){
                                    boarderX = counterX-lowerFifteen+1;
                                    doneFlag = 1;
                                }
                                if (lowestPoint != -1 && hundredEncounterPoint != -1 && (lowestPoint+1 == hundredEncounterPoint || lowestPoint+2 == hundredEncounterPoint) && doneFlag == 0){
                                    boarderX = counterX-hundredEncounterPoint+1;
                                    doneFlag = 1;
                                }
                                if (lowestPoint != -1 && outOfFrame != -1 && (lowestPoint+1 == outOfFrame || lowestPoint+2 == outOfFrame) && doneFlag == 0){
                                    boarderX = counterX-outOfFrame+1;
                                    doneFlag = 1;
                                }
                                if (doneFlag == 0) boarderX = counterX-lowestPoint;
                                doneFlag = 1;
                            }
                            if (lowestValue != 255 && secondPeakValue != -1){
                                if (lowerFifteen != -1 && lowestPoint != -1 && lowerFifteen <= lowestPoint){
                                    boarderX = counterX-lowerFifteen+1;
                                    doneFlag = 1;
                                }
                                if (secondPeakValue-lowestValue >= 50 && doneFlag == 0){
                                    boarderX = counterX-lowestPoint;
                                    doneFlag = 1;
                                }
                                if (doneFlag == 0){
                                    boarderX = counterX-lowestPoint;
                                    doneFlag = 1;
                                }
                            }
                        }
                        if (boarderX != -1 && boarderY != -1){
                            do{ //------100, < 50 verification------
                                
                                terminationFlag = 1;
                                
                                if (boarderX == counterX) terminationFlag = 0;
                                else if (boarderX >= imageHeight){
                                    boarderX--;
                                    terminationFlag = 0;
                                }
                                else if (arrayExtractedImage [boarderY][boarderX] == 100 || arrayExtractedImage [boarderY][boarderX] < 50) boarderX = boarderX+1;
                                else terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                            
                            //------For Line 3, Connectivity Number, X position, Y position------
                            arrayEdgeTraceValue3 [edgeTraceEntry3] = valueTemp;
                            arrayEdgeTraceX3 [edgeTraceEntry3] = boarderX;
                            arrayEdgeTraceY3 [edgeTraceEntry3] = boarderY;
                            edgeTraceEntry3++;
                        }
                    }
                    if (counter1 == 3){ //------Right------
                        if (firstPointValue >= 200 && doneFlag == 0){
                            if (differenceValue1 != -1 && differenceValue1 >= 80){
                                boarderX = counterX;
                                doneFlag = 1;
                            }
                            if (differenceValue2 != -1 && differenceValue2 >= 80 && doneFlag == 0){
                                boarderX = counterX+1;
                                doneFlag = 1;
                            }
                            if (differenceValue3 != -1 && differenceValue3 >= 80 && doneFlag == 0){
                                boarderX = counterX+2;
                                doneFlag = 1;
                            }
                        }
                        if (firstPointValue < 255 && doneFlag == 0){
                            if (lowestValue != 255 && secondPeakValue == -1){
                                if (lowerFifteen != -1 && lowestPoint != -1 && lowerFifteen <= lowestPoint){
                                    boarderX = counterX+lowerFifteen-1;
                                    doneFlag = 1;
                                }
                                if (lowestPoint != -1 && hundredEncounterPoint != -1 && (lowestPoint-1 == hundredEncounterPoint || lowestPoint-2 == hundredEncounterPoint) && doneFlag == 0){
                                    boarderX = counterX+hundredEncounterPoint-1;
                                    doneFlag = 1;
                                }
                                if (lowestPoint != -1 && outOfFrame != -1 && (lowestPoint-1 == outOfFrame || lowestPoint-2 == outOfFrame) && doneFlag == 0){
                                    boarderX = counterX+outOfFrame-1;
                                    doneFlag = 1;
                                }
                                if (doneFlag == 0){
                                    boarderX = counterX+lowestPoint;
                                    doneFlag = 1;
                                }
                            }
                            if (lowestValue != 255 && secondPeakValue != -1){
                                if (lowerFifteen != -1 && lowestPoint != -1 && lowerFifteen <= lowestPoint){
                                    boarderX = counterX+lowerFifteen-1;
                                    doneFlag = 1;
                                }
                                if (secondPeakValue-lowestValue >= 50 && doneFlag == 0){
                                    boarderX = counterX+lowestPoint;
                                    doneFlag = 1;
                                }
                                if (doneFlag == 0){
                                    boarderX = counterX+lowestPoint;
                                }
                            }
                        }
                        if (boarderX != -1 && boarderY != -1){
                            do{ //------100, < 50 verification------
                                
                                terminationFlag = 1;
                                
                                if (boarderX == counterX) terminationFlag = 0;
                                else if (boarderX < 0){
                                    boarderX++;
                                    terminationFlag = 0;
                                }
                                else if (arrayExtractedImage [boarderY][boarderX] == 100 || arrayExtractedImage [boarderY][boarderX] < 50) boarderX = boarderX-1;
                                else terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                            
                            //------For Line 4, Connectivity Number, X position, Y position------
                            arrayEdgeTraceValue4 [edgeTraceEntry4] = valueTemp;
                            arrayEdgeTraceX4 [edgeTraceEntry4] = boarderX;
                            arrayEdgeTraceY4 [edgeTraceEntry4] = boarderY;
                            edgeTraceEntry4++;
                        }
                    }
                }
            }
        }
    }
    
    //cout<<edgeTraceEntryCount<<" "<<edgeTraceEntry1<<" "<<edgeTraceEntry2<<" "<<edgeTraceEntry3<<" "<<edgeTraceEntry4<<" EntryNumbers"<<endl;
    
    if (subjectArray != 1 && forNextConnectivityCount != 0){
        delete [] arrayLimitType;
        delete [] arrayCutType;
        delete [] arrayDimensionType;
    }
    
    for (int counter1 = 0; counter1 < imageHeight; counter1++){
        delete [] connectivityMap [counter1];
        delete [] connectivityMap2 [counter1];
    }
    
    delete [] connectivityMap;
    delete [] connectivityMap2;
    
    delete [] averageIntensity;
    
    int totalTraceEntry = edgeTraceEntry1+edgeTraceEntry2+edgeTraceEntry3+edgeTraceEntry4;
    
    int xLowest = 0;
    int xLargest = 0;
    int yLowest = 0;
    int yLargest = 0;
    int xDimension = 0;
    int yDimension = 0;
    int attachCount = 0;
    int lineTrackingCount = 0;
    int lineNumberEdge = 0;
    int lineLength = 0;
    int xPositionNext = 0;
    int yPositionNext = 0;
    int xPositionNext2 = 0;
    int yPositionNext2 = 0;
    int terminationFlag1 = 0;
    int attachCount2 = 0;
    int entryCount = 1;
    int terminationFlag2 = 0;
    int longestLine = 0;
    int lineNumber1 = 0;
    int lineNumber2 = 0;
    int xStart1 = -1;
    int yStart1 = -1;
    int xStart2 = -1;
    int yStart2 = -1;
    int xEnd1 = -1;
    int yEnd1 = -1;
    int arrayStartPosition1 = 0;
    int arrayStartPosition2 = 0;
    int arrayEndPosition1 = 0;
    int xPositionTrack1 = 0;
    int yPositionTrack1 = 0;
    int xPositionTrack2 = 0;
    int yPositionTrack2 = 0;
    int xPositionTrack3 = 0;
    int yPositionTrack3 = 0;
    int pixData = 0;
    int pixData2 = 0;
    int xPositionTrack4 = 0;
    int yPositionTrack4 = 0;
    int attachedFind = 0;
    int limitEdgeY = 0;
    int limitEdgeX = 0;
    int pixData3 = 0;
    int xPositionTrackStart = 0;
    int yPositionTrackStart = 0;
    int xPositionTrackEnd = 0;
    int yPositionTrackEnd = 0;
    int startValue = 0;
    int endValue = 0;
    int startPermission = 0;
    int endPermission = 0;
    int fillFlagA1 = 0;
    int fillFlagA2 = 0;
    int fillFlagB1 = 0;
    int fillFlagB2 = 0;
    int fillFlagB3 = 0;
    int fillFlagB4 = 0;
    int fillFlagC1 = 0;
    int fillFlagC2 = 0;
    int fillFlagD1 = 0;
    int fillFlagD2 = 0;
    int fillFlagD3 = 0;
    int fillFlagD4 = 0;
    int xAddress1 = 0;
    int yAddress1 = 0;
    int xAddress2 = 0;
    int yAddress2 = 0;
    int lineLength2 = 0;
    int xPositionTrackStart2 = 0;
    int yPositionTrackStart2 = 0;
    int xPositionTrackEnd2 = 0;
    int yPositionTrackEnd2 = 0;
    int startValue2 = 0;
    int endValue2 = 0;
    int startPermission2 = 0;
    int endPermission2 = 0;
    int nextX = 0;
    int nextY = 0;
    int nextX1 = 0;
    int nextY1 = 0;
    int yStart = 0;
    int numberOfPoint = 0;
    int xPosition1 = 0;
    int yPosition1 = 0;
    int xPosition2 = 0;
    int yPosition2 = 0;
    int lowestValue2 = 0;
    int lowestPoint2 = 0;
    int hundredEncounterPoint2 = 0;
    int hundredEncounterFlag2 = 0;
    int lowerFifteenFlag2 = 0;
    int xStart = 0;
    int lineNumberSave = 0;
    int startCountContinuous = 0;
    int originalLine = 0;
    int additionalLine = 0;
    int startCountFix = 0;
    int additionalFlag = 0;
    int lineOneToFourCount = 0;
    
    if (totalTraceEntry != 0){
        for (int counter1 = 1; counter1 <= maxConnectivityNumber; counter1++){
            xLowest = 10000;
            xLargest = -1;
            yLowest = 10000;
            yLargest = -1;
            
            //------Dimension check------
            for (int counter2 = 0; counter2 < edgeTraceEntry1; counter2++){
                if (arrayEdgeTraceValue1 [counter2] == counter1){
                    if (arrayEdgeTraceX1 [counter2] < xLowest) xLowest = arrayEdgeTraceX1 [counter2];
                    if (arrayEdgeTraceX1 [counter2] > xLargest) xLargest = arrayEdgeTraceX1 [counter2];
                    if (arrayEdgeTraceY1 [counter2] < yLowest) yLowest = arrayEdgeTraceY1 [counter2];
                    if (arrayEdgeTraceY1 [counter2] > yLargest) yLargest = arrayEdgeTraceY1 [counter2];
                }
            }
            
            for (int counter2 = 0; counter2 < edgeTraceEntry2; counter2++){
                if (arrayEdgeTraceValue2 [counter2] == counter1){
                    if (arrayEdgeTraceX2 [counter2] < xLowest) xLowest = arrayEdgeTraceX2 [counter2];
                    if (arrayEdgeTraceX2 [counter2] > xLargest) xLargest = arrayEdgeTraceX2 [counter2];
                    if (arrayEdgeTraceY2 [counter2] < yLowest) yLowest = arrayEdgeTraceY2 [counter2];
                    if (arrayEdgeTraceY2 [counter2] > yLargest) yLargest = arrayEdgeTraceY2 [counter2];
                }
            }
            
            for (int counter2 = 0; counter2 < edgeTraceEntry3; counter2++){
                if (arrayEdgeTraceValue3 [counter2] == counter1){
                    if (arrayEdgeTraceX3 [counter2] < xLowest) xLowest = arrayEdgeTraceX3 [counter2];
                    if (arrayEdgeTraceX3 [counter2] > xLargest) xLargest = arrayEdgeTraceX3 [counter2];
                    if (arrayEdgeTraceY3 [counter2] < yLowest) yLowest = arrayEdgeTraceY3 [counter2];
                    if (arrayEdgeTraceY3 [counter2] > yLargest) yLargest = arrayEdgeTraceY3 [counter2];
                }
            }
            
            for (int counter2 = 0; counter2 < edgeTraceEntry4; counter2++){
                if (arrayEdgeTraceValue4 [counter2] == counter1){
                    if (arrayEdgeTraceX4 [counter2] < xLowest) xLowest = arrayEdgeTraceX4 [counter2];
                    if (arrayEdgeTraceX4 [counter2] > xLargest) xLargest = arrayEdgeTraceX4 [counter2];
                    if (arrayEdgeTraceY4 [counter2] < yLowest) yLowest = arrayEdgeTraceY4 [counter2];
                    if (arrayEdgeTraceY4 [counter2] > yLargest) yLargest = arrayEdgeTraceY4 [counter2];
                }
            }
            
            //cout<<counter1<<" "<<xLowest<<" "<<yLowest<<" "<<xLargest<<" "<<yLargest<<" LowHigh"<<endl;
            
            if (xLowest != 10000 && xLargest != -1 && yLowest != 10000 && yLargest != -1 && xLargest-xLowest != 0 && yLargest-yLowest != 0){
                xDimension = xLargest-xLowest+1;
                yDimension = yLargest-yLowest+1;
                
                int **sourceMatrix = new int *[yDimension*2+1];
                int **pointLinkMap = new int *[yDimension*2+1];
                
                for (int counter2 = 0; counter2 < yDimension*2+1; counter2++){
                    sourceMatrix [counter2] = new int [xDimension*2+1];
                    pointLinkMap [counter2] = new int [xDimension*2+1];
                }
                
                int *arrayLineOneToFour = new int [totalTraceEntry*10+1];
                lineOneToFourCount = 0;
                
                int *arrayLineTracking = new int [xDimension*yDimension*5+1];
                
                //------Extract required pix info------
                for (int counter2 = 0; counter2 < 4; counter2++){
                    for (int counterY = 0; counterY < yLargest-yLowest+1; counterY++){
                        for (int counterX = 0; counterX < xLargest-xLowest+1; counterX++) sourceMatrix [counterY][counterX] = 0;
                    }
                    
                    if (counter2 == 0){
                        for (int counter3 = 0; counter3 < edgeTraceEntry1; counter3++){
                            if (arrayEdgeTraceValue1 [counter3] == counter1){
                                sourceMatrix [arrayEdgeTraceY1 [counter3]-yLowest][arrayEdgeTraceX1 [counter3]-xLowest] = 1;
                            }
                        }
                    }
                    if (counter2 == 1){
                        for (int counter3 = 0; counter3 < edgeTraceEntry2; counter3++){
                            if (arrayEdgeTraceValue2 [counter3] == counter1){
                                sourceMatrix [arrayEdgeTraceY2 [counter3]-yLowest][arrayEdgeTraceX2 [counter3]-xLowest] = 1;
                            }
                        }
                    }
                    if (counter2 == 2){
                        for (int counter3 = 0; counter3 < edgeTraceEntry3; counter3++){
                            if (arrayEdgeTraceValue3 [counter3] == counter1){
                                sourceMatrix [arrayEdgeTraceY3 [counter3]-yLowest][arrayEdgeTraceX3 [counter3]-xLowest] = 1;
                            }
                        }
                    }
                    if (counter2 == 3){
                        for (int counter3 = 0; counter3 < edgeTraceEntry4; counter3++){
                            if (arrayEdgeTraceValue4 [counter3] == counter1){
                                sourceMatrix [arrayEdgeTraceY4 [counter3]-yLowest][arrayEdgeTraceX4 [counter3]-xLowest] = 1;
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < yDimension*2; counterA++){
                    //	for (int counterB = 0; counterB < xDimension*2; counterB++) cout<<" "<<sourceMatrix [counterA][counterB];
                    //	cout<<" sourceMatrix "<<counterA<<endl;
                    //}
                    
                    //------Remove line pix, which attached more than 3 pixels, no junctions------
                    if (counter2 == 0){
                        for (int counterY = 0; counterY < yLargest-yLowest+1; counterY++){
                            for (int counterX = 0; counterX < xLargest-xLowest+1; counterX++){
                                if (sourceMatrix [counterY][counterX] == 1){
                                    attachCount = 0;
                                    lineCount = 0;
                                    
                                    for (int counterX2 = counterX-1; counterX2 <= counterX+1; counterX2++){
                                        for (int counterY2 = counterY-1; counterY2 <= counterY+1; counterY2++){
                                            lineCount++;
                                            
                                            if (counterX2 >= 0 && counterX2 < xLargest-xLowest+1 && counterY2 >= 0 && counterY2 < yLargest-yLowest+1){
                                                if (sourceMatrix [counterY2][counterX2] == 1){
                                                    attachCount++;
                                                    
                                                    if (attachCount == 2){
                                                        sourceMatrix [counterY2][counterX2] = 0;
                                                        attachCount = 1;
                                                    }
                                                }
                                            }
                                            if (lineCount == 3){
                                                lineCount = 0;
                                                attachCount = 0;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    if (counter2 == 1){
                        for (int counterY = yLargest-yLowest; counterY >= 0; counterY = counterY-1){
                            for (int counterX = 0; counterX < xLargest-xLowest+1; counterX++){
                                if (sourceMatrix [counterY][counterX] == 1){
                                    attachCount = 0;
                                    lineCount = 0;
                                    
                                    for (int counterX2 = counterX-1; counterX2 <= counterX+1; counterX2++){
                                        for (int counterY2 = counterY+1; counterY2 >= counterY+1; counterY2 = counterY2-1){
                                            lineCount++;
                                            
                                            if (counterX2 >= 0 && counterX2 < xLargest-xLowest+1 && counterY2 >= 0 && counterY2 < yLargest-yLowest+1){
                                                if (sourceMatrix [counterY2][counterX2] == 1){
                                                    attachCount++;
                                                    
                                                    if (attachCount == 2){
                                                        sourceMatrix [counterY2][counterX2] = 0;
                                                        attachCount = 1;
                                                    }
                                                }
                                            }
                                            
                                            if (lineCount == 3){
                                                lineCount = 0;
                                                attachCount = 0;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    if (counter2 == 2){
                        for (int counterX = 0; counterX < xLargest-xLowest+1; counterX++){
                            for (int counterY = 0; counterY < yLargest-yLowest+1; counterY++){
                                if (sourceMatrix [counterY][counterX] == 1){
                                    attachCount = 0;
                                    lineCount = 0;
                                    
                                    for (int counterY2 = counterY-1; counterY2 <= counterY+1; counterY2++){
                                        for (int counterX2 = counterX-1; counterX2 <= counterX+1; counterX2++){
                                            if (counterX2 >= 0 && counterX2 < xLargest-xLowest+1 && counterY2 >= 0 && counterY2 < yLargest-yLowest+1){
                                                if (sourceMatrix [counterY2][counterX2] == 1){
                                                    attachCount++;
                                                    
                                                    if (attachCount == 2){
                                                        sourceMatrix [counterY2][counterX2] = 0;
                                                        attachCount = 1;
                                                    }
                                                }
                                            }
                                            
                                            if (lineCount == 3){
                                                lineCount = 0;
                                                attachCount = 0;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    if (counter2 == 3){
                        for (int counterX = xLargest-xLowest; counterX >= 0; counterX = counterX-1){
                            for (int counterY = 0; counterY < yLargest-yLowest+1; counterY++){
                                if (sourceMatrix [counterY][counterX] == 1){
                                    attachCount = 0;
                                    lineCount = 0;
                                    
                                    for (int counterY2 = counterY-1; counterY2 <= counterY+1; counterY2++){
                                        for (int counterX2 = counterX+1; counterX2 >= counterX-1; counterX2 = counterX2-1){
                                            if (counterX2 >= 0 && counterX2 < xLargest-xLowest+1 && counterY2 >= 0 && counterY2 < yLargest-yLowest+1){
                                                if (sourceMatrix [counterY2][counterX2] == 1){
                                                    attachCount++;
                                                    
                                                    if (attachCount == 2){
                                                        sourceMatrix [counterY2][counterX2] = 0;
                                                        attachCount = 1;
                                                    }
                                                }
                                            }
                                            
                                            if (lineCount == 3){
                                                lineCount = 0;
                                                attachCount = 0;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    //------Create Line list, Find first one, then track the line, Point one of line number, minus, point last length, minus------
                    lineTrackingCount = 0;
                    lineNumberEdge = 1;
                    lineLength = 1;
                    
                    for (int counterY = 0; counterY < yLargest-yLowest+1; counterY++){
                        for (int counterX = 0; counterX < xLargest-xLowest+1; counterX++){
                            if (sourceMatrix [counterY][counterX] == 1){
                                attachCount = 0;
                                xPositionNext = -1;
                                yPositionNext = -1;
                                
                                for (int counterY2 = counterY-1; counterY2 <= counterY+1; counterY2++){
                                    for (int counterX2 = counterX-1; counterX2 <= counterX+1; counterX2++){
                                        if (counterX2 >= 0 && counterX2 < xLargest-xLowest+1 && counterY2 >= 0 && counterY2 < yLargest-yLowest+1){
                                            if (sourceMatrix [counterY2][counterX2] == 1){
                                                if (counterY2 == counterY && counterX2 == counterX);
                                                else{
                                                    
                                                    xPositionNext = counterX2;
                                                    yPositionNext = counterY2;
                                                    attachCount++;
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                if (attachCount == 0){
                                    arrayLineTracking [lineTrackingCount] = counterX, lineTrackingCount++;
                                    arrayLineTracking [lineTrackingCount] = counterY, lineTrackingCount++;
                                    arrayLineTracking [lineTrackingCount] = lineNumberEdge*-1, lineTrackingCount++;
                                    arrayLineTracking [lineTrackingCount] = -1, lineTrackingCount++;
                                    
                                    sourceMatrix [counterY][counterX] = 0;
                                    lineNumberEdge++;
                                    lineLength = 1;
                                }
                                if (attachCount == 1){
                                    arrayLineTracking [lineTrackingCount] = counterX, lineTrackingCount++;
                                    arrayLineTracking [lineTrackingCount] = counterY, lineTrackingCount++;
                                    arrayLineTracking [lineTrackingCount] = lineNumberEdge*-1, lineTrackingCount++;
                                    arrayLineTracking [lineTrackingCount] = 1, lineTrackingCount++;
                                    
                                    sourceMatrix [counterY][counterX] = 0;
                                    lineLength++;
                                    
                                    xPositionNext2 = -1;
                                    yPositionNext2 = -1;
                                    
                                    do{
                                        
                                        terminationFlag1 = 1;
                                        attachCount2 = 0;
                                        
                                        for (int counterY2 = yPositionNext-1; counterY2 <= yPositionNext+1; counterY2++){
                                            for (int counterX2 = xPositionNext-1; counterX2 <= xPositionNext+1; counterX2++){
                                                if (counterX2 >= 0 && counterX2 < xLargest-xLowest+1 && counterY2 >= 0 && counterY2 < yLargest-yLowest+1){
                                                    if (sourceMatrix [counterY2][counterX2] == 1){
                                                        if (counterY2 == yPositionNext && counterX2 == xPositionNext);
                                                        else{
                                                            
                                                            xPositionNext2 = counterX2;
                                                            yPositionNext2 = counterY2;
                                                            attachCount2++;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (attachCount2 == 0){
                                            arrayLineTracking [lineTrackingCount] = xPositionNext, lineTrackingCount++;
                                            arrayLineTracking [lineTrackingCount] = yPositionNext, lineTrackingCount++;
                                            arrayLineTracking [lineTrackingCount] = lineNumberEdge, lineTrackingCount++;
                                            arrayLineTracking [lineTrackingCount] = lineLength*-1, lineTrackingCount++;
                                            sourceMatrix [yPositionNext][xPositionNext] = 0;
                                            lineNumberEdge++;
                                            lineLength = 1;
                                            terminationFlag1 = 0;
                                        }
                                        else{
                                            
                                            arrayLineTracking [lineTrackingCount] = xPositionNext, lineTrackingCount++;
                                            arrayLineTracking [lineTrackingCount] = yPositionNext, lineTrackingCount++;
                                            arrayLineTracking [lineTrackingCount] = lineNumberEdge, lineTrackingCount++;
                                            arrayLineTracking [lineTrackingCount] = lineLength, lineTrackingCount++;
                                            sourceMatrix [yPositionNext][xPositionNext] = 0;
                                            xPositionNext = xPositionNext2;
                                            yPositionNext = yPositionNext2;
                                            lineLength++;
                                        }
                                        
                                    } while (terminationFlag1 == 1);
                                }
                            }
                        }
                    }
                    
                    //------Data up-load to Map------
                    for (int counterY = 0; counterY < yLargest-yLowest+1; counterY++){
                        for (int counterX = 0; counterX < xLargest-xLowest+1; counterX++) pointLinkMap [counterY][counterX] = 0;
                    }
                    
                    for (int counter3 = 0; counter3 < lineTrackingCount/4; counter3++){
                        if (arrayLineTracking [counter3*4+2] < 0){
                            pointLinkMap [arrayLineTracking [counter3*4+1]][arrayLineTracking [counter3*4]] = arrayLineTracking [counter3*4+2]*-1;
                        }
                        else{
                            
                            pointLinkMap [arrayLineTracking [counter3*4+1]][arrayLineTracking [counter3*4]] = arrayLineTracking [counter3*4+2];
                        }
                    }
                    
                    //for (int counterA = 0; counterA < yLargest-yLowest+1; counterA++){
                    //	for (int counterB = 0; counterB < xLargest-xLowest+1; counterB++) cout<<" "<<pointLinkMap [counterA][counterB];
                    //	cout<<" pointLinkMap "<<counterA<<endl;
                    //}
                    
                    //------Line length (longer to shorter), line number list, start and end points list generation------
                    int *lineLengthList = new int [lineNumberEdge*2+1];
                    int *lineNumberList = new int [lineNumberEdge*2+1];
                    int **endData = new int *[lineNumberEdge*2+1];
                    for (int counter3 = 0; counter3 < lineNumberEdge*2+1; counter3++) endData [counter3] = new int [6];
                    
                    for (int counter3 = 0; counter3 < lineNumberEdge*2+1; counter3++){
                        lineLengthList [counter3] = 0;
                        lineNumberList [counter3] = 0;
                    }
                    
                    for (int counter3 = 0; counter3 < lineNumberEdge*2+1; counter3++){
                        for (int counter4 = 0; counter4 < 6; counter4++) endData [counter3][counter4] = -1;
                    }
                    
                    entryCount = 1;
                    
                    do{
                        
                        terminationFlag2 = 1;
                        longestLine = 0;
                        lineNumber1 = 0;
                        lineNumber2 = 0;
                        xStart1 = -1;
                        yStart1 = -1;
                        xStart2 = -1;
                        yStart2 = -1;
                        xEnd1 = -1;
                        yEnd1 = -1;
                        arrayStartPosition1 = 0;
                        arrayStartPosition2 = 0;
                        arrayEndPosition1 = 0;
                        
                        for (int counter3 = 0; counter3 < lineTrackingCount/4; counter3++){
                            if (arrayLineTracking [counter3*4+2] < 0){
                                lineNumber2 = arrayLineTracking [counter3*4+2]*-1;
                                xStart2 = arrayLineTracking [counter3*4];
                                yStart2 = arrayLineTracking [counter3*4+1];
                                arrayStartPosition2 = counter3*4;
                            }
                            if (arrayLineTracking [counter3*4+3] < 0){
                                if (arrayLineTracking [counter3*4+3]*-1 > longestLine){
                                    longestLine = arrayLineTracking [counter3*4+3]*-1;
                                    lineNumber1 = lineNumber2;
                                    xStart1 = xStart2;
                                    yStart1 = yStart2;
                                    xEnd1 = arrayLineTracking [counter3*4];
                                    yEnd1 = arrayLineTracking [counter3*4+1];
                                    arrayStartPosition1 = arrayStartPosition2;
                                    arrayEndPosition1 = counter3*4;
                                }
                            }
                        }
                        
                        if (longestLine != 0){
                            arrayLineTracking [arrayStartPosition1+2] = lineNumber1;
                            arrayLineTracking [arrayEndPosition1+3] = longestLine;
                            
                            lineLengthList [entryCount] = longestLine;
                            lineNumberList [entryCount] = lineNumber1;
                            
                            if (longestLine == 1){
                                endData [entryCount][0] = xStart1;
                                endData [entryCount][1] = yStart1;
                                endData [entryCount][2] = xStart1;
                                endData [entryCount][3] = yStart1;
                            }
                            if ((xStart1 < xEnd1 && (counter2 == 0 || counter2 == 1)) || (yStart1 < yEnd1 && (counter2 == 2 || counter2 == 3))){
                                endData [entryCount][0] = xStart1;
                                endData [entryCount][1] = yStart1;
                                endData [entryCount][2] = xEnd1;
                                endData [entryCount][3] = yEnd1;
                            }
                            if ((xStart1 >= xEnd1 && (counter2 == 0 || counter2 == 1)) || (yStart1 >= yEnd1 && (counter2 == 2 || counter2 == 3))){
                                endData [entryCount][0] = xEnd1;
                                endData [entryCount][1] = yEnd1;
                                endData [entryCount][2] = xStart1;
                                endData [entryCount][3] = yStart1;
                            }
                            
                            entryCount++;
                        }
                        else terminationFlag2 = 0;
                        
                    } while (terminationFlag2 == 1);
                    
                    //for (int counterA = 1; counterA <= lineNumberEdge-1; counterA++){
                    //	cout<<counterA<<" "<<lineLengthList [counterA]<<" "<<lineNumberList [counterA]<<" "<<endData [counterA][0]<<" "<<endData [counterA][1]<<" "<<endData [counterA][2]<<" "<<endData [counterA][3]<<" EndData"<<endl;
                    //}
                    
                    //------Track line and readjust if the position is too outside------
                    for (int counter3 = 1; counter3 < lineNumberEdge; counter3++){
                        if (lineLengthList [counter3] >= 3){
                            xPositionTrack1 = endData [counter3][0];
                            yPositionTrack1 = endData [counter3][1];
                            xPositionTrack2 = endData [counter3][0];
                            yPositionTrack2 = endData [counter3][1];
                            xPositionTrack3 = endData [counter3][0];
                            yPositionTrack3 = endData [counter3][1];
                            
                            for (int counter4 = 1; counter4 < lineLengthList [counter3]; counter4++){
                                pixData = arrayExtractedImage [yLowest+yPositionTrack2][xLowest+xPositionTrack2];
                                pixData2 = 0;
                                
                                for (int counterY = yPositionTrack2-1; counterY <= yPositionTrack2+1; counterY++){
                                    for (int counterX = xPositionTrack2-1; counterX <= xPositionTrack2+1; counterX++){
                                        if (counterX >= 0 && counterX < xLargest-xLowest+1 && counterY >= 0 && counterY < yLargest-yLowest+1){
                                            if (counterY == yPositionTrack2 && counterX == xPositionTrack2);
                                            else if (counterY == yPositionTrack1 && counterX == xPositionTrack1);
                                            else if (pointLinkMap [counterY][counterX] == lineNumberList [counter3]){
                                                xPositionTrack3 = counterX;
                                                yPositionTrack3 = counterY;
                                                pixData2 = arrayExtractedImage [yLowest+yPositionTrack3][xLowest+xPositionTrack3];
                                            }
                                        }
                                    }
                                }
                                
                                if (pixData-pixData2 > 15 || pixData-pixData2 < -15){
                                    xPositionTrack4 = 0;
                                    yPositionTrack4 = 0;
                                    
                                    if (counter2 == 0){
                                        xPositionTrack4 = xPositionTrack3;
                                        yPositionTrack4 = yPositionTrack3+1;
                                    }
                                    if (counter2 == 1){
                                        xPositionTrack4 = xPositionTrack3;
                                        yPositionTrack4 = yPositionTrack3-1;
                                    }
                                    if (counter2 == 2){
                                        xPositionTrack4 = xPositionTrack3+1;
                                        yPositionTrack4 = yPositionTrack3;
                                    }
                                    if (counter2 == 3){
                                        xPositionTrack4 = xPositionTrack3-1;
                                        yPositionTrack4 = yPositionTrack3;
                                    }
                                    
                                    attachedFind = 0;
                                    
                                    for (int counterY = yPositionTrack4-1; counterY <= yPositionTrack4+1; counterY++){
                                        for (int counterX = xPositionTrack4-1; counterX <= xPositionTrack4+1; counterX++){
                                            if (counterX >= 0 && counterX < xLargest-xLowest+1 && counterY >= 0 && counterY < yLargest-yLowest+1){
                                                if (counterY == yPositionTrack3 && counterX == xPositionTrack3);
                                                else if (pointLinkMap [counterY][counterX] == lineNumberList [counter3]) attachedFind++;
                                            }
                                        }
                                    }
                                    
                                    limitEdgeY = 0;
                                    limitEdgeX = 0;
                                    
                                    if (limitEdgeY < 0) limitEdgeY = 0;
                                    if (limitEdgeY > imageWidth) limitEdgeY = imageWidth-1;
                                    if (limitEdgeX < 0) limitEdgeX = 0;
                                    if (limitEdgeX > imageWidth) limitEdgeX = imageWidth-1;
                                    
                                    pixData3 = arrayExtractedImage [limitEdgeY][limitEdgeX];
                                    
                                    if ((abs(pixData-pixData2) > abs(pixData-pixData3)) && xPositionTrack4 > 0 && yPositionTrack4 > 0 && xPositionTrack4 < xDimension && yPositionTrack4 < yDimension){
                                        if (attachedFind == 2){
                                            pointLinkMap [yPositionTrack4][xPositionTrack4] = lineNumberList [counter3];
                                            pointLinkMap [yPositionTrack3][xPositionTrack3] = 0;
                                            xPositionTrack3 = xPositionTrack4;
                                            yPositionTrack3 = yPositionTrack4;
                                        }
                                    }
                                }
                                
                                xPositionTrack1 = xPositionTrack2;
                                yPositionTrack1 = yPositionTrack2;
                                xPositionTrack2 = xPositionTrack3;
                                yPositionTrack2 = yPositionTrack3;
                            }
                        }
                    }
                    
                    delete [] lineNumberList;
                    
                    //for (int counterA = 0; counterA < yLargest-yLowest+1; counterA++){
                    //	for (int counterB = 0; counterB < xLargest-xLowest+1; counterB++) cout<<" "<<pointLinkMap [counterA][counterB];
                    //	cout<<" pointLinkMap "<<counterA<<endl;
                    //}
                    
                    //------Connect two ends------
                    for (int counter3 = 1; counter3 <= lineNumberEdge-2; counter3++){
                        xPositionTrackStart = endData [counter3][0];
                        yPositionTrackStart = endData [counter3][1];
                        xPositionTrackEnd = endData [counter3][2];
                        yPositionTrackEnd = endData [counter3][3];
                        
                        startValue = arrayExtractedImage [yLowest+yPositionTrackStart][xLowest+xPositionTrackStart];
                        endValue = arrayExtractedImage [yLowest+yPositionTrackEnd][xLowest+xPositionTrackEnd];
                        lineLength = lineLengthList [counter3];
                        
                        //------Permission Marks: -1, new points; -2, length 1, start done; -3, length 1, end done; -4, done; -5, removed------
                        if (pointLinkMap [yPositionTrackStart][xPositionTrackStart] == -4 || pointLinkMap [yPositionTrackStart][xPositionTrackStart] == -2 || pointLinkMap [yPositionTrackStart][xPositionTrackStart] == -5){
                            startPermission = 0;
                        }
                        else startPermission = 1;
                        if (pointLinkMap [yPositionTrackEnd][xPositionTrackEnd] == -4 || pointLinkMap [yPositionTrackEnd][xPositionTrackEnd] == -3 || pointLinkMap [yPositionTrackEnd][xPositionTrackEnd] == -5){
                            endPermission = 0;
                        }
                        else endPermission = 1;
                        
                        if (counter2 == 0 || counter2 == 1){
                            fillFlagA1 = -1;
                            fillFlagA2 = -1;
                            fillFlagB1 = -1;
                            fillFlagB2 = -1;
                            fillFlagB3 = -1;
                            fillFlagB4 = -1;
                            fillFlagC1 = -1;
                            fillFlagC2 = -1;
                            fillFlagD1 = -1;
                            fillFlagD2 = -1;
                            fillFlagD3 = -1;
                            fillFlagD4 = -1;
                            xAddress1 = -1;
                            yAddress1 = -1;
                            xAddress2 = -1;
                            yAddress2 = -1;
                            lineLength2 = 0;
                            
                            for (int counter4 = counter3+1; counter4 <= lineNumberEdge-1; counter4++){
                                xPositionTrackStart2 = endData [counter4][0];
                                yPositionTrackStart2 = endData [counter4][1];
                                xPositionTrackEnd2 = endData [counter4][2];
                                yPositionTrackEnd2 = endData [counter4][3];
                                
                                startValue2 = arrayExtractedImage [yLowest+yPositionTrackStart2][xLowest+xPositionTrackStart2];
                                endValue2 = arrayExtractedImage [yLowest+yPositionTrackEnd2][xLowest+xPositionTrackEnd2];
                                
                                if (pointLinkMap [yPositionTrackStart2][xPositionTrackStart2] == -4 || pointLinkMap [yPositionTrackStart2][xPositionTrackStart2] == -2) startPermission2 = 0;
                                else startPermission2 = 1;
                                
                                if (pointLinkMap [yPositionTrackEnd2][xPositionTrackEnd2] == -4 || pointLinkMap [yPositionTrackEnd2][xPositionTrackEnd2] == -3) endPermission2 = 0;
                                else endPermission2 = 1;
                                
                                if (endValue2-startValue >= -20 && endValue2-startValue <= 20){
                                    if (endPermission2 == 1 && startPermission == 1){
                                        if (xPositionTrackStart-xPositionTrackEnd2 == 2){
                                            if (yPositionTrackEnd2-yPositionTrackStart == -2 || yPositionTrackEnd2-yPositionTrackStart == -1){
                                                fillFlagA1 = yPositionTrackStart-1;
                                                fillFlagA2 = xPositionTrackStart-1;
                                                xAddress1 = xPositionTrackEnd2;
                                                yAddress1 = yPositionTrackEnd2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (yPositionTrackEnd2-yPositionTrackStart == 0){
                                                fillFlagA1 = yPositionTrackStart;
                                                fillFlagA2 = xPositionTrackStart-1;
                                                xAddress1 = xPositionTrackEnd2;
                                                yAddress1 = yPositionTrackEnd2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (yPositionTrackEnd2-yPositionTrackStart == 1 || yPositionTrackEnd2-yPositionTrackStart == 2){
                                                fillFlagA1 = yPositionTrackStart+1;
                                                fillFlagA2 = xPositionTrackStart-1;
                                                xAddress1 = xPositionTrackEnd2;
                                                yAddress1 = yPositionTrackEnd2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                        }
                                        if (xPositionTrackStart-xPositionTrackEnd2 == 3){
                                            if (yPositionTrackEnd2-yPositionTrackStart == -3 || yPositionTrackEnd2-yPositionTrackStart == -2){
                                                fillFlagB1 = yPositionTrackStart-1;
                                                fillFlagB2 = yPositionTrackStart-2;
                                                fillFlagB3 = xPositionTrackStart-1;
                                                fillFlagB4 = xPositionTrackStart-2;
                                                xAddress1 = xPositionTrackEnd2;
                                                yAddress1 = yPositionTrackEnd2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (yPositionTrackEnd2-yPositionTrackStart == -1){
                                                fillFlagB1 = yPositionTrackStart-1;
                                                fillFlagB2 = yPositionTrackStart-1;
                                                fillFlagB3 = xPositionTrackStart-1;
                                                fillFlagB4 = xPositionTrackStart-2;
                                                xAddress1 = xPositionTrackEnd2;
                                                yAddress1 = yPositionTrackEnd2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (yPositionTrackEnd2-yPositionTrackStart == 0){
                                                fillFlagB1 = yPositionTrackStart;
                                                fillFlagB2 = yPositionTrackStart;
                                                fillFlagB3 = xPositionTrackStart-1;
                                                fillFlagB4 = xPositionTrackStart-2;
                                                xAddress1 = xPositionTrackEnd2;
                                                yAddress1 = yPositionTrackEnd2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (yPositionTrackEnd2-yPositionTrackStart == 1){
                                                fillFlagB1 = yPositionTrackStart+1;
                                                fillFlagB2 = yPositionTrackStart+1;
                                                fillFlagB3 = xPositionTrackStart-1;
                                                fillFlagB4 = xPositionTrackStart-2;
                                                xAddress1 = xPositionTrackEnd2;
                                                yAddress1 = yPositionTrackEnd2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (yPositionTrackEnd2-yPositionTrackStart == 2 || yPositionTrackEnd2-yPositionTrackStart == 2){
                                                fillFlagB1 = yPositionTrackStart+1;
                                                fillFlagB2 = yPositionTrackStart+2;
                                                fillFlagB3 = xPositionTrackStart-1;
                                                fillFlagB4 = xPositionTrackStart-2;
                                                xAddress1 = xPositionTrackEnd2;
                                                yAddress1 = yPositionTrackEnd2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                        }
                                    }
                                }
                                if (startValue2-endValue >= -20 && startValue2-endValue <= 20){
                                    if (endPermission == 1 && startPermission2 == 1){
                                        if (xPositionTrackStart2-xPositionTrackEnd == 2){
                                            if (yPositionTrackStart2-yPositionTrackEnd == -2 || yPositionTrackStart2-yPositionTrackEnd == -1){
                                                fillFlagC1 = yPositionTrackEnd-1;
                                                fillFlagC2 = xPositionTrackEnd+1;
                                                xAddress2 = xPositionTrackStart2;
                                                yAddress2 = yPositionTrackStart2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (yPositionTrackStart2-yPositionTrackEnd == 0){
                                                fillFlagC1 = yPositionTrackEnd;
                                                fillFlagC2 = xPositionTrackEnd+1;
                                                xAddress2 = xPositionTrackStart2;
                                                yAddress2 = yPositionTrackStart2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (yPositionTrackStart2-yPositionTrackEnd == 1 || yPositionTrackStart2-yPositionTrackEnd == 2){
                                                fillFlagC1 = yPositionTrackEnd+1;
                                                fillFlagC2 = xPositionTrackEnd+1;
                                                xAddress2 = xPositionTrackStart2;
                                                yAddress2 = yPositionTrackStart2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                        }
                                        if (xPositionTrackStart2-xPositionTrackEnd == 3){
                                            if (yPositionTrackStart2-yPositionTrackEnd == -3 || yPositionTrackStart2-yPositionTrackEnd == -2){
                                                fillFlagD1 = yPositionTrackEnd-1;
                                                fillFlagD2 = yPositionTrackEnd-2;
                                                fillFlagD3 = xPositionTrackEnd+1;
                                                fillFlagD4 = xPositionTrackEnd+2;
                                                xAddress2 = xPositionTrackStart2;
                                                yAddress2 = yPositionTrackStart2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (yPositionTrackStart2-yPositionTrackEnd == -1){
                                                fillFlagD1 = yPositionTrackEnd-1;
                                                fillFlagD2 = yPositionTrackEnd-1;
                                                fillFlagD3 = xPositionTrackEnd+1;
                                                fillFlagD4 = xPositionTrackEnd+2;
                                                xAddress2 = xPositionTrackStart2;
                                                yAddress2 = yPositionTrackStart2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (yPositionTrackStart2-yPositionTrackEnd == 0){
                                                fillFlagD1 = yPositionTrackEnd;
                                                fillFlagD2 = yPositionTrackEnd;
                                                fillFlagD3 = xPositionTrackEnd+1;
                                                fillFlagD4 = xPositionTrackEnd+2;
                                                xAddress2 = xPositionTrackStart2;
                                                yAddress2 = yPositionTrackStart2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (yPositionTrackStart2-yPositionTrackEnd == 1){
                                                fillFlagD1 = yPositionTrackEnd+1;
                                                fillFlagD2 = yPositionTrackEnd+1;
                                                fillFlagD3 = xPositionTrackEnd+1;
                                                fillFlagD4 = xPositionTrackEnd+2;
                                                xAddress2 = xPositionTrackStart2;
                                                yAddress2 = yPositionTrackStart2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (yPositionTrackStart2-yPositionTrackEnd == 2 || yPositionTrackStart2-yPositionTrackEnd == 2){
                                                fillFlagD1 = yPositionTrackEnd+1;
                                                fillFlagD2 = yPositionTrackEnd+2;
                                                fillFlagD3 = xPositionTrackEnd+1;
                                                fillFlagD4 = xPositionTrackEnd+2;
                                                xAddress2 = xPositionTrackStart2;
                                                yAddress2 = yPositionTrackStart2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                        }
                                    }
                                }
                            }
                            if (fillFlagA1 != -1){
                                pointLinkMap [fillFlagA1][fillFlagA2] = -1;
                                
                                if (lineLength == 1 && pointLinkMap [yPositionTrackStart][xPositionTrackStart] == 0) pointLinkMap [yPositionTrackStart][xPositionTrackStart] = -2;
                                else pointLinkMap [yPositionTrackStart][xPositionTrackStart] = -4;
                                
                                if (lineLength2 == 1 && pointLinkMap [yAddress1][xAddress1] == 0) pointLinkMap [yAddress1][xAddress1] = -3;
                                else pointLinkMap [yAddress1][xAddress1] = -4;
                                
                                if (counter2 == 0){
                                    for (int counter4 = fillFlagA1-1; counter4 >= 0; counter4--){
                                        if (pointLinkMap [counter4][fillFlagA2] != 0) pointLinkMap [counter4][fillFlagA2] = -5;
                                    }
                                }
                                
                                if (counter2 == 1){
                                    for (int counter4 = fillFlagA1+1; counter4 <= yLargest-yLowest; counter4++){
                                        if (pointLinkMap [counter4][fillFlagA2] != 0) pointLinkMap [counter4][fillFlagA2] = -5;
                                    }
                                }
                            }
                            else if (fillFlagB1 != -1){
                                pointLinkMap [fillFlagB1][fillFlagB3] = -1;
                                pointLinkMap [fillFlagB2][fillFlagB4] = -1;
                                
                                if (lineLength == 1 && pointLinkMap [yPositionTrackStart][xPositionTrackStart] == 0) pointLinkMap [yPositionTrackStart][xPositionTrackStart] = -2;
                                else pointLinkMap [yPositionTrackStart][xPositionTrackStart] = -4;
                                
                                if (lineLength2 == 1 && pointLinkMap [yAddress1][xAddress1] == 0) pointLinkMap [yAddress1][xAddress1] = -3;
                                else pointLinkMap [yAddress1][xAddress1] = -4;
                                
                                if (counter2 == 0){
                                    for (int counter4 = fillFlagB1-1; counter4 >= 0; counter4--){
                                        if (pointLinkMap [counter4][fillFlagB3] != 0) pointLinkMap [counter4][fillFlagB3] = -5;
                                    }
                                    
                                    for (int counter4 = fillFlagB2-1; counter4 >= 0; counter4--){
                                        if (pointLinkMap [counter4][fillFlagB4] != 0) pointLinkMap [counter4][fillFlagB4] = -5;
                                    }
                                }
                                if (counter2 == 1){
                                    for (int counter4 = fillFlagB1+1; counter4 <= yLargest-yLowest; counter4++){
                                        if (pointLinkMap [counter4][fillFlagB3] != 0) pointLinkMap [counter4][fillFlagB3] = -5;
                                    }
                                    
                                    for (int counter4 = fillFlagB2+1; counter4 <= yLargest-yLowest; counter4++){
                                        if (pointLinkMap [counter4][fillFlagB4] != 0) pointLinkMap [counter4][fillFlagB4] = -5;
                                    }
                                }
                            }
                            
                            if (fillFlagC1 != -1){
                                pointLinkMap [fillFlagC1][fillFlagC2] = -1;
                                
                                if (lineLength == 1 && pointLinkMap [yAddress2][xAddress2] == 0) pointLinkMap [yAddress2][xAddress2] = -2;
                                else pointLinkMap [yAddress2][xAddress2] = -4;
                                
                                if (lineLength2 == 1 && pointLinkMap [yPositionTrackEnd][xPositionTrackEnd] == 0) pointLinkMap [yPositionTrackEnd][xPositionTrackEnd] = -3;
                                else pointLinkMap [yPositionTrackEnd][xPositionTrackEnd] = -4;
                                
                                if (counter2 == 0){
                                    for (int counter4 = fillFlagC1-1; counter4 >= 0; counter4--){
                                        if (pointLinkMap [counter4][fillFlagC2] != 0) pointLinkMap [counter4][fillFlagC2] = -5;
                                    }
                                }
                                
                                if (counter2 == 1){
                                    for (int counter4 = fillFlagC1+1; counter4 <= yLargest-yLowest; counter4++){
                                        if (pointLinkMap [counter4][fillFlagC2] != 0) pointLinkMap [counter4][fillFlagC2] = -5;
                                    }
                                }
                            }
                            else if (fillFlagD1 != -1){
                                pointLinkMap [fillFlagD1][fillFlagD3] = -1;
                                pointLinkMap [fillFlagD2][fillFlagD4] = -1;
                                
                                if (lineLength == 1 && pointLinkMap [yAddress2][xAddress2] == 0) pointLinkMap [yAddress2][xAddress2] = -2;
                                else pointLinkMap [yAddress2][xAddress2] = -4;
                                
                                if (lineLength2 == 1 && pointLinkMap [yPositionTrackEnd][xPositionTrackEnd] == 0) pointLinkMap [yPositionTrackEnd][xPositionTrackEnd] = -3;
                                else pointLinkMap [yPositionTrackEnd][xPositionTrackEnd] = -4;
                                
                                if (counter2 == 0){
                                    for (int counter4 = fillFlagD1-1; counter4 >= 0; counter4--){
                                        if (pointLinkMap [counter4][fillFlagD3] != 0) pointLinkMap [counter4][fillFlagD3] = -5;
                                    }
                                    
                                    for (int counter4 = fillFlagD2-1; counter4 >= 0; counter4--){
                                        if (pointLinkMap [counter4][fillFlagD4] != 0) pointLinkMap [counter4][fillFlagD4] = -5;
                                    }
                                }
                                
                                if (counter2 == 1){
                                    for (int counter4 = fillFlagD1+1; counter4 <= yLargest-yLowest; counter4++){
                                        if (pointLinkMap [counter4][fillFlagD3] != 0) pointLinkMap [counter4][fillFlagD3] = -5;
                                    }
                                    
                                    for (int counter4 = fillFlagD2+1; counter4 <= yLargest-yLowest; counter4++){
                                        if (pointLinkMap [counter4][fillFlagD4] != 0) pointLinkMap [counter4][fillFlagD4] = -5;
                                    }
                                }
                            }
                        }
                        if (counter2 == 2 || counter2 == 3){
                            fillFlagA1 = -1;
                            fillFlagA2 = -1;
                            fillFlagB1 = -1;
                            fillFlagB2 = -1;
                            fillFlagB3 = -1;
                            fillFlagB4 = -1;
                            fillFlagC1 = -1;
                            fillFlagC2 = -1;
                            fillFlagD1 = -1;
                            fillFlagD2 = -1;
                            fillFlagD3 = -1;
                            fillFlagD4 = -1;
                            xAddress1 = -1;
                            yAddress1 = -1;
                            xAddress2 = -1;
                            yAddress2 = -1;
                            lineLength2 = 0;
                            
                            for (int counter4 = counter3+1; counter4 <= lineNumberEdge-1; counter4++){
                                xPositionTrackStart2 = endData [counter4][0];
                                yPositionTrackStart2 = endData [counter4][1];
                                xPositionTrackEnd2 = endData [counter4][2];
                                yPositionTrackEnd2 = endData [counter4][3];
                                startValue2 = arrayExtractedImage [yLowest+yPositionTrackStart2][xLowest+xPositionTrackStart2];
                                endValue2 = arrayExtractedImage [yLowest+yPositionTrackEnd2][xLowest+xPositionTrackEnd2];
                                
                                if (pointLinkMap [yPositionTrackStart2][xPositionTrackStart2] == -4 || pointLinkMap [yPositionTrackStart2][xPositionTrackStart2] == -2) startPermission2 = 0;
                                else startPermission2 = 1;
                                
                                if (pointLinkMap [yPositionTrackEnd2][xPositionTrackEnd2] == -4 || pointLinkMap [yPositionTrackEnd2][xPositionTrackEnd2] == -3) endPermission2 = 0;
                                else endPermission2 = 1;
                                
                                if (endValue2-startValue >= -20 && endValue2-startValue <= 20){
                                    if (endPermission2 == 1 && startPermission == 1){
                                        if (yPositionTrackStart-yPositionTrackEnd2 == 2){
                                            if (xPositionTrackEnd2-xPositionTrackStart == -2 || xPositionTrackEnd2-xPositionTrackStart == -1){
                                                fillFlagA1 = xPositionTrackStart-1;
                                                fillFlagA2 = yPositionTrackStart-1;
                                                xAddress1 = xPositionTrackEnd2;
                                                yAddress1 = yPositionTrackEnd2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (xPositionTrackEnd2-xPositionTrackStart == 0){
                                                fillFlagA1 = xPositionTrackStart;
                                                fillFlagA2 = yPositionTrackStart-1;
                                                xAddress1 = xPositionTrackEnd2;
                                                yAddress1 = yPositionTrackEnd2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (xPositionTrackEnd2-xPositionTrackStart == 1 || xPositionTrackEnd2-xPositionTrackStart == 2){
                                                fillFlagA1 = xPositionTrackStart+1;
                                                fillFlagA2 = yPositionTrackStart-1;
                                                xAddress1 = xPositionTrackEnd2;
                                                yAddress1 = yPositionTrackEnd2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                        }
                                        if (yPositionTrackStart-yPositionTrackEnd2 == 3){
                                            if (xPositionTrackEnd2-xPositionTrackStart == -3 || xPositionTrackEnd2-xPositionTrackStart == -2){
                                                fillFlagB1 = xPositionTrackStart-1;
                                                fillFlagB2 = xPositionTrackStart-2;
                                                fillFlagB3 = yPositionTrackStart-1;
                                                fillFlagB4 = yPositionTrackStart-2;
                                                xAddress1 = xPositionTrackEnd2;
                                                yAddress1 = yPositionTrackEnd2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (xPositionTrackEnd2-xPositionTrackStart == -1){
                                                fillFlagB1 = xPositionTrackStart-1;
                                                fillFlagB2 = xPositionTrackStart-1;
                                                fillFlagB3 = yPositionTrackStart-1;
                                                fillFlagB4 = yPositionTrackStart-2;
                                                xAddress1 = xPositionTrackEnd2;
                                                yAddress1 = yPositionTrackEnd2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (xPositionTrackEnd2-xPositionTrackStart == 0){
                                                fillFlagB1 = xPositionTrackStart;
                                                fillFlagB2 = xPositionTrackStart;
                                                fillFlagB3 = yPositionTrackStart-1;
                                                fillFlagB4 = yPositionTrackStart-2;
                                                xAddress1 = xPositionTrackEnd2;
                                                yAddress1 = yPositionTrackEnd2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (xPositionTrackEnd2-xPositionTrackStart == 1){
                                                fillFlagB1 = xPositionTrackStart+1;
                                                fillFlagB2 = xPositionTrackStart+2;
                                                fillFlagB3 = yPositionTrackStart-1;
                                                fillFlagB4 = yPositionTrackStart-1;
                                                xAddress1 = xPositionTrackEnd2;
                                                yAddress1 = yPositionTrackEnd2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (xPositionTrackEnd2-xPositionTrackStart == 2 || xPositionTrackEnd2-xPositionTrackStart == 2){
                                                fillFlagB1 = xPositionTrackStart+1;
                                                fillFlagB2 = xPositionTrackStart+2;
                                                fillFlagB3 = yPositionTrackStart-1;
                                                fillFlagB4 = yPositionTrackStart-2;
                                                xAddress1 = xPositionTrackEnd2;
                                                yAddress1 = yPositionTrackEnd2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                        }
                                    }
                                }
                                if (startValue2-endValue >= -20 && startValue2-endValue <= 20){
                                    if (endPermission == 1 && startPermission2 == 1){
                                        if (yPositionTrackStart2-yPositionTrackEnd == 2){
                                            if (xPositionTrackStart2-xPositionTrackEnd == -2 || xPositionTrackStart2-xPositionTrackEnd == -1){
                                                fillFlagC1 = xPositionTrackEnd-1;
                                                fillFlagC2 = yPositionTrackEnd+1;
                                                xAddress2 = xPositionTrackStart2;
                                                yAddress2 = yPositionTrackStart2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (xPositionTrackStart2-xPositionTrackEnd == 0){
                                                fillFlagC1 = xPositionTrackEnd;
                                                fillFlagC2 = yPositionTrackEnd+1;
                                                xAddress2 = xPositionTrackStart2;
                                                yAddress2 = yPositionTrackStart2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (xPositionTrackStart2-xPositionTrackEnd == 1 || xPositionTrackStart2-xPositionTrackEnd == 2){
                                                fillFlagC1 = xPositionTrackEnd+1;
                                                fillFlagC2 = yPositionTrackEnd+1;
                                                xAddress2 = xPositionTrackStart2;
                                                yAddress2 = yPositionTrackStart2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                        }
                                        if (yPositionTrackStart2-yPositionTrackEnd == 3){
                                            if (xPositionTrackStart2-xPositionTrackEnd == -3 || xPositionTrackStart2-xPositionTrackEnd == -2){
                                                fillFlagD1 = xPositionTrackEnd-1;
                                                fillFlagD2 = xPositionTrackEnd-2;
                                                fillFlagD3 = yPositionTrackEnd+1;
                                                fillFlagD4 = yPositionTrackEnd+2;
                                                xAddress2 = xPositionTrackStart2;
                                                yAddress2 = yPositionTrackStart2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (xPositionTrackStart2-xPositionTrackEnd == -1){
                                                fillFlagD1 = xPositionTrackEnd-1;
                                                fillFlagD2 = xPositionTrackEnd-1;
                                                fillFlagD3 = yPositionTrackEnd+1;
                                                fillFlagD4 = yPositionTrackEnd+2;
                                                xAddress2 = xPositionTrackStart2;
                                                yAddress2 = yPositionTrackStart2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (xPositionTrackStart2-xPositionTrackEnd == 0){
                                                fillFlagD1 = xPositionTrackEnd;
                                                fillFlagD2 = xPositionTrackEnd;
                                                fillFlagD3 = yPositionTrackEnd+1;
                                                fillFlagD4 = yPositionTrackEnd+2;
                                                xAddress2 = xPositionTrackStart2;
                                                yAddress2 = yPositionTrackStart2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (xPositionTrackStart2-xPositionTrackEnd == 1){
                                                fillFlagD1 = xPositionTrackEnd+1;
                                                fillFlagD2 = xPositionTrackEnd+2;
                                                fillFlagD3 = yPositionTrackEnd+1;
                                                fillFlagD4 = yPositionTrackEnd+2;
                                                xAddress2 = xPositionTrackStart2;
                                                yAddress2 = yPositionTrackStart2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                            if (xPositionTrackStart2-xPositionTrackEnd == 2 || xPositionTrackStart2-xPositionTrackEnd == 2){
                                                fillFlagD1 = xPositionTrackEnd+1;
                                                fillFlagD2 = xPositionTrackEnd+2;
                                                fillFlagD3 = yPositionTrackEnd+1;
                                                fillFlagD4 = yPositionTrackEnd+2;
                                                xAddress2 = xPositionTrackStart2;
                                                yAddress2 = yPositionTrackStart2;
                                                lineLength2 = lineLengthList [counter4];
                                            }
                                        }
                                    }
                                }
                            }
                            if (fillFlagA1 != -1){
                                pointLinkMap [fillFlagA2][fillFlagA1] = -1;
                                
                                if (lineLength == 1 && pointLinkMap [yPositionTrackStart][xPositionTrackStart] == 0) pointLinkMap [yPositionTrackStart][xPositionTrackStart] = -2;
                                else pointLinkMap [yPositionTrackStart][xPositionTrackStart] = -4;
                                
                                if (lineLength2 == 1 && pointLinkMap [yAddress1][xAddress1] == 0) pointLinkMap [yAddress1][xAddress1] = -3;
                                else pointLinkMap [yAddress1][xAddress1] = -4;
                                
                                if (counter2 == 2){
                                    for (int counter4 = fillFlagA1-1; counter4 >= 0; counter4--){
                                        if (pointLinkMap [fillFlagA2][counter4] != 0) pointLinkMap [fillFlagA2][counter4] = -5;
                                    }
                                }
                                if (counter2 == 3){
                                    for (int counter4 = fillFlagA1+1; counter4 <= xLargest-xLowest; counter4++){
                                        if (pointLinkMap [fillFlagA2][counter4] != 0) pointLinkMap [fillFlagA2][counter4] = -5;
                                    }
                                }
                            }
                            else if (fillFlagB1 != -1){
                                pointLinkMap [fillFlagB3][fillFlagB1] = -1;
                                pointLinkMap [fillFlagB4][fillFlagB2] = -1;
                                
                                if (lineLength == 1 && pointLinkMap [yPositionTrackStart][xPositionTrackStart] == 0) pointLinkMap [yPositionTrackStart][xPositionTrackStart] = -2;
                                else pointLinkMap [yPositionTrackStart][xPositionTrackStart] = -4;
                                
                                if (lineLength2 == 1 && pointLinkMap [yAddress1][xAddress1] == 0) pointLinkMap [yAddress1][xAddress1] = -3;
                                else pointLinkMap [yAddress1][xAddress1] = -4;
                                
                                if (counter2 == 2){
                                    for (int counter4 = fillFlagB1-1; counter4 >= 0; counter4--){
                                        if (pointLinkMap [fillFlagB3][counter4] != 0) pointLinkMap [fillFlagB3][counter4] = -5;
                                    }
                                    
                                    for (int counter4 = fillFlagB2-1; counter4 >= 0; counter4--){
                                        if (pointLinkMap [fillFlagB4][counter4] != 0) pointLinkMap [fillFlagB4][counter4] = -5;
                                    }
                                }
                                if (counter2 == 3){
                                    for (int counter4 = fillFlagB1+1; counter4 <= xLargest-xLowest; counter4++){
                                        if (pointLinkMap [fillFlagB3][counter4] != 0) pointLinkMap [fillFlagB3][counter4] = -5;
                                    }
                                    
                                    for (int counter4 = fillFlagB2+1; counter4 <= xLargest-xLowest; counter4++){
                                        if (pointLinkMap [fillFlagB4][counter4] != 0) pointLinkMap [fillFlagB4][counter4] = -5;
                                    }
                                }
                            }
                            if (fillFlagC1 != -1){
                                pointLinkMap [fillFlagC2][fillFlagC1] = -1;
                                
                                if (lineLength == 1 && pointLinkMap [yAddress2][xAddress2] == 0) pointLinkMap [yAddress2][xAddress2] = -2;
                                else pointLinkMap [yAddress2][xAddress2] = -4;
                                
                                if (lineLength2 == 1 && pointLinkMap [yPositionTrackEnd][xPositionTrackEnd] == 0) pointLinkMap [yPositionTrackEnd][xPositionTrackEnd] = -3;
                                else pointLinkMap [yPositionTrackEnd][xPositionTrackEnd] = -4;
                                
                                if (counter2 == 2){
                                    for (int counter4 = fillFlagC1-1; counter4 >= 0; counter4--){
                                        if (pointLinkMap [fillFlagC2][counter4] != 0) pointLinkMap [fillFlagC2][counter4] = -5;
                                    }
                                }
                                
                                if (counter2 == 3){
                                    for (int counter4 = fillFlagC1+1; counter4 <= xLargest-xLowest; counter4++){
                                        if (pointLinkMap [fillFlagC2][counter4] != 0) pointLinkMap [fillFlagC2][counter4] = -5;
                                    }
                                }
                            }
                            else if (fillFlagD1 != -1){
                                pointLinkMap [fillFlagD3][fillFlagD1] = -1;
                                pointLinkMap [fillFlagD4][fillFlagD2] = -1;
                                
                                if (lineLength == 1 && pointLinkMap [yAddress2][xAddress2] == 0) pointLinkMap [yAddress2][xAddress2] = -2;
                                else pointLinkMap [yAddress2][xAddress2] = -4;
                                
                                if (lineLength2 == 1 && pointLinkMap [yPositionTrackEnd][xPositionTrackEnd] == 0) pointLinkMap [yPositionTrackEnd][xPositionTrackEnd] = -3;
                                else pointLinkMap [yPositionTrackEnd][xPositionTrackEnd] = -4;
                                
                                if (counter2 == 2){
                                    for (int counter4 = fillFlagD1-1; counter4 >= 0; counter4--){
                                        if (pointLinkMap [fillFlagD3][counter4] != 0) pointLinkMap [fillFlagD3][counter4] = -5;
                                    }
                                    
                                    for (int counter4 = fillFlagD2-1; counter4 >= 0; counter4--){
                                        if (pointLinkMap [fillFlagD4][counter4] != 0) pointLinkMap [fillFlagD4][counter4] = -5;
                                    }
                                }
                                if (counter2 == 3){
                                    for (int counter4 = fillFlagD1+1; counter4 <= xLargest-xLowest; counter4++){
                                        if (pointLinkMap [fillFlagD3][counter4] != 0) pointLinkMap [fillFlagD3][counter4] = -5;
                                    }
                                    
                                    for (int counter4 = fillFlagD2+1; counter4 <= xLargest-xLowest; counter4++){
                                        if (pointLinkMap [fillFlagD4][counter4] != 0) pointLinkMap [fillFlagD4][counter4] = -5;
                                    }
                                }
                            }
                        }
                    }
                    
                    delete [] lineLengthList;
                    
                    for (int counter3 = 0; counter3 < lineNumberEdge*2+1; counter3++) delete [] endData [counter3];
                    delete [] endData;
                    
                    //for (int counterA = 0; counterA < yLargest-yLowest+1; counterA++){
                    //	for (int counterB = 0; counterB < xLargest-xLowest+1; counterB++) cout<<" "<<pointLinkMap [counterA][counterB];
                    //	cout<<" pointLinkMap "<<counterA<<endl;
                    //}
                    
                    //------Remove points outside of the lines------
                    for (int counterY = 0; counterY < yLargest-yLowest+1; counterY++){
                        for (int counterX = 0; counterX < xLargest-xLowest+1; counterX++){
                            if (pointLinkMap [counterY][counterX] == -5){
                                for (int counter3 = 0; counter3 < 2; counter3++){
                                    attachCount = 0;
                                    nextX = counterX;
                                    nextY = counterY;
                                    nextX1 = 0;
                                    nextY1 = 0;
                                    
                                    for (int counterY2 = nextY-1; counterY2 <= nextY+1; counterY2++){
                                        for (int counterX2 = nextX-1; counterX2 <= nextX+1; counterX2++){
                                            if (counterX2 >= 0 && counterX2 < xLargest-xLowest+1 && counterY2 >= 0 && counterY2 < yLargest-yLowest+1){
                                                if (pointLinkMap [counterY2][counterX2] != 0) attachCount++;
                                            }
                                        }
                                    }
                                    
                                    if (attachCount >= 2){
                                        break;
                                    }
                                    if (attachCount == 0) pointLinkMap [nextY][nextX] = 0;
                                    if (attachCount == 1 && counter3 == 0){
                                        nextX1 = nextX;
                                        nextY1 = nextY;
                                    }
                                    if (attachCount == 1 && counter3 == 1){
                                        pointLinkMap [nextY][nextX] = 0;
                                        pointLinkMap [nextY1][nextX1] = 0;
                                    }
                                }
                            }
                        }
                    }
                    
                    //------Find points, which are separated by 100, low shadow etc------
                    if (counter2 == 0){
                        yStart = 0;
                        
                        for (int counterX = 0; counterX < xLargest-xLowest+1; counterX++){
                            numberOfPoint = 0;
                            xPosition1 = 0;
                            yPosition1 = 0;
                            xPosition2 = 0;
                            yPosition2 = 0;
                            
                            for (int counterY = yStart; counterY < yLargest-yLowest+1; counterY++){
                                if (pointLinkMap [counterY][counterX] != 0){
                                    if (numberOfPoint == 0){
                                        xPosition1 = counterX;
                                        yPosition1 = counterY;
                                        numberOfPoint = 1;
                                    }
                                    else if (numberOfPoint == 1){
                                        xPosition2 = counterX;
                                        yPosition2 = counterY;
                                        numberOfPoint = 2;
                                        break;
                                    }
                                }
                            }
                            
                            if (yStart != 0) yStart = 0;
                            if (numberOfPoint == 2){
                                counterX = counterX-1;
                                
                                if (yPosition2-yPosition1 <= 5) pointLinkMap [yPosition2][xPosition2] = 0;
                                if (yPosition2-yPosition1 > 5){
                                    int valueList [yPosition2-yPosition1+2];
                                    
                                    for (int counter3 = 0; counter3 <= yPosition2-yPosition1; counter3++) valueList [counter3] = arrayExtractedImage [yLowest+yPosition1+counter3][xLowest+xPosition1];
                                    
                                    lowestValue2 = valueList [0];
                                    lowestPoint2 = 0;
                                    hundredEncounterPoint2 = 0;
                                    hundredEncounterFlag2 = 0;
                                    lowerFifteenFlag2 = 0;
                                    
                                    for (int counter3 = 1; counter3 <= yPosition2-yPosition1; counter3++){
                                        if (valueList [counter3] == 100 && hundredEncounterPoint2 == 0){
                                            hundredEncounterPoint2 = 1;
                                            hundredEncounterFlag2 = counter3;
                                        }
                                        else if (valueList [counter3] == 100 && hundredEncounterPoint2 == 1 && hundredEncounterFlag2+1 == counter3) hundredEncounterPoint2 = 2;
                                        else{
                                            
                                            hundredEncounterPoint2 = 0;
                                            hundredEncounterFlag2 = 0;
                                        }
                                        
                                        if (valueList [counter3] <= 50) lowerFifteenFlag2 = 1;
                                        if (lowestValue2 > valueList [counter3]){
                                            lowestValue2 = valueList [counter3];
                                            lowestPoint2 = 1;
                                        }
                                    }
                                    if (hundredEncounterPoint2 == 2 || lowerFifteenFlag2 == 1){
                                        pointLinkMap [yPosition2][xPosition2] = -6;
                                        yStart = yPosition2;
                                    }
                                    else if (lowestPoint2 == 1){
                                        if (lowestValue2 <= valueList [0]-20){
                                            pointLinkMap [yPosition2][xPosition2] = -6;
                                            yStart = yPosition2;
                                        }
                                        else pointLinkMap [yPosition2][xPosition2] = 0;
                                    }
                                    else pointLinkMap [yPosition2][xPosition2] = 0;
                                }
                            }
                        }
                    }
                    if (counter2 == 1){
                        for (int counterX = 0; counterX < xLargest-xLowest+1; counterX++){
                            numberOfPoint = 0;
                            xPosition2 = 0;
                            yPosition2 = 0;
                            
                            for (int counterY = yLargest-yLowest; counterY >= 0; counterY--){
                                if (pointLinkMap [counterY][counterX] != 0){
                                    if (numberOfPoint == 0) numberOfPoint = 1;
                                    else if (numberOfPoint == 1){
                                        xPosition2 = counterX;
                                        yPosition2 = counterY;
                                        numberOfPoint = 2;
                                        break;
                                    }
                                }
                            }
                            if (numberOfPoint == 2){
                                pointLinkMap [yPosition2][xPosition2] = 0;
                                counterX = counterX-1;
                            }
                        }
                    }
                    if (counter2 == 2){
                        xStart = 0;
                        
                        for (int counterY = 0; counterY < yLargest-yLowest+1; counterY++){
                            numberOfPoint = 0;
                            xPosition1 = 0;
                            yPosition1 = 0;
                            xPosition2 = 0;
                            yPosition2 = 0;
                            
                            for (int counterX = xStart; counterX < xLargest-xLowest+1; counterX++){
                                if (pointLinkMap [counterY][counterX] != 0){
                                    if (numberOfPoint == 0){
                                        xPosition1 = counterX;
                                        yPosition1 = counterY;
                                        numberOfPoint = 1;
                                    }
                                    else if (numberOfPoint == 1){
                                        xPosition2 = counterX;
                                        yPosition2 = counterY;
                                        numberOfPoint = 2;
                                        break;
                                    }
                                }
                            }
                            if (xStart != 0) xStart = 0;
                            if (numberOfPoint == 2){
                                counterY = counterY-1;
                                
                                if (xPosition2-xPosition1 <= 5) pointLinkMap [yPosition2][xPosition2] = 0;
                                if (xPosition2-xPosition1 > 5){
                                    int valueList [xPosition2-xPosition1+2];
                                    
                                    for (int counter3 = 0; counter3 <= xPosition2-xPosition1; counter3++) valueList [counter3] = arrayExtractedImage [yLowest+yPosition1][xLowest+xPosition1+counter3];
                                    
                                    lowestValue2 = valueList [0];
                                    lowestPoint2 = 0;
                                    hundredEncounterPoint2 = 0;
                                    hundredEncounterFlag2 = 0;
                                    lowerFifteenFlag2 = 0;
                                    
                                    for (int counter3 = 1; counter3 <= xPosition2-xPosition1; counter3++){
                                        if (valueList [counter3] == 100 && hundredEncounterPoint2 == 0){
                                            hundredEncounterPoint2 = 1;
                                            hundredEncounterFlag2 = counter3;
                                        }
                                        else if (valueList [counter3] == 100 && hundredEncounterPoint2 == 1 && hundredEncounterFlag2+1 == counter3) hundredEncounterPoint2 = 2;
                                        else{
                                            
                                            hundredEncounterPoint2 = 0;
                                            hundredEncounterFlag2 = 0;
                                        }
                                        
                                        if (valueList [counter3] <= 50) lowerFifteenFlag2 = 1;
                                        if (lowestValue2 > valueList [counter3]){
                                            lowestValue2 = valueList [counter3];
                                            lowestPoint2 = 1;
                                        }
                                    }
                                    
                                    if (hundredEncounterPoint2 == 2 || lowerFifteenFlag2 == 1){
                                        pointLinkMap [yPosition2][xPosition2] = -6;
                                        xStart = xPosition2;
                                    }
                                    else if (lowestPoint2 == 1){
                                        if (lowestValue2 <= valueList [0]-20){
                                            pointLinkMap [yPosition2][xPosition2] = -6;
                                            xStart = xPosition2;
                                        }
                                        else pointLinkMap [yPosition2][xPosition2] = 0;
                                    }
                                    else pointLinkMap [yPosition2][xPosition2] = 0;
                                }
                            }
                        }
                    }
                    if (counter2 == 3){
                        for (int counterY = 0; counterY < yLargest-yLowest+1; counterY++){
                            numberOfPoint = 0;
                            xPosition2 = 0;
                            yPosition2 = 0;
                            
                            for (int counterX = 0; counterX < xLargest-xLowest+1; counterX++){
                                if (pointLinkMap [counterY][counterX] != 0){
                                    if (numberOfPoint == 0) numberOfPoint = 1;
                                    else if (numberOfPoint == 1){
                                        xPosition2 = counterX;
                                        yPosition2 = counterY;
                                        numberOfPoint = 2;
                                        break;
                                    }
                                }
                            }
                            if (numberOfPoint == 2){
                                pointLinkMap [yPosition2][xPosition2] = 0;
                                counterY = counterY-1;
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < 50; counterA++){
                    //	for (int counterB = 0; counterB < 50; counterB++) cout<<" "<<pointLinkMap [counterA][counterB];
                    //	cout<<" pointLinkMap "<<counterA<<endl;
                    //}
                    
                    //------Clean up lines and register into an array------
                    startCountContinuous = lineOneToFourCount/5;
                    originalLine = 1;
                    additionalLine = 101; //------Additional Line, Line separated by < 50 or 100. Number starts from 101.------
                    
                    for (int counterY = 0; counterY < yLargest-yLowest+1; counterY++){
                        for (int counterX = 0; counterX < xLargest-xLowest+1; counterX++){
                            if (pointLinkMap [counterY][counterX] != 0){
                                additionalFlag = 0;
                                attachCount = 0;
                                xPositionNext = -1;
                                yPositionNext = -1;
                                
                                for (int counterY2 = counterY-1; counterY2 <= counterY+1; counterY2++){
                                    for (int counterX2 = counterX-1; counterX2 <= counterX+1; counterX2++){
                                        if (counterX2 >= 0 && counterX2 < xLargest-xLowest+1 && counterY2 >= 0 && counterY2 < yLargest-yLowest+1){
                                            if (pointLinkMap [counterY2][counterX2] != 0){
                                                if (counterY2 == counterY && counterX2 == counterX);
                                                else{
                                                    
                                                    xPositionNext = counterX2;
                                                    yPositionNext = counterY2;
                                                    attachCount++;
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                if (attachCount == 0){
                                    if (pointLinkMap [counterY][counterX] == -6){
                                        lineNumberSave = additionalLine;
                                        additionalLine++;
                                    }
                                    else{
                                        
                                        lineNumberSave = originalLine;
                                        originalLine++;
                                    }
                                    
                                    arrayLineOneToFour [lineOneToFourCount] = counterX, lineOneToFourCount++;
                                    arrayLineOneToFour [lineOneToFourCount] = counterY, lineOneToFourCount++;
                                    arrayLineOneToFour [lineOneToFourCount] = lineNumberSave*-1, lineOneToFourCount++;
                                    arrayLineOneToFour [lineOneToFourCount] = -1, lineOneToFourCount++;
                                    arrayLineOneToFour [lineOneToFourCount] = counter2, lineOneToFourCount++;
                                    
                                    pointLinkMap [counterY][counterX] = 0;
                                    startCountContinuous++;
                                }
                                
                                if (attachCount == 1){
                                    if (pointLinkMap [counterY][counterX] == -6) additionalFlag = 1;
                                    
                                    arrayLineOneToFour [lineOneToFourCount] = counterX, lineOneToFourCount++;
                                    arrayLineOneToFour [lineOneToFourCount] = counterY, lineOneToFourCount++;
                                    arrayLineOneToFour [lineOneToFourCount] = originalLine*-1, lineOneToFourCount++;
                                    arrayLineOneToFour [lineOneToFourCount] = 1, lineOneToFourCount++;
                                    arrayLineOneToFour [lineOneToFourCount] = counter2, lineOneToFourCount++;
                                    
                                    pointLinkMap [counterY][counterX] = 0;
                                    lineLength2 = 2;
                                    startCountFix = startCountContinuous;
                                    startCountContinuous++;
                                    
                                    xPositionNext2 = -1;
                                    yPositionNext2 = -1;
                                    
                                    do{
                                        
                                        terminationFlag1 = 1;
                                        attachCount2 = 0;
                                        
                                        for (int counterY2 = yPositionNext-1; counterY2 <= yPositionNext+1; counterY2++){
                                            for (int counterX2 = xPositionNext-1; counterX2 <= xPositionNext+1; counterX2++){
                                                if (counterX2 >= 0 && counterX2 < xLargest-xLowest+1 && counterY2 >= 0 && counterY2 < yLargest-yLowest+1){
                                                    if (pointLinkMap [counterY2][counterX2] != 0){
                                                        if (counterY2 == yPositionNext && counterX2 == xPositionNext);
                                                        else{
                                                            
                                                            xPositionNext2 = counterX2;
                                                            yPositionNext2 = counterY2;
                                                            attachCount2++;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (attachCount2 == 0){
                                            if (pointLinkMap [yPositionNext][xPositionNext] == -6) additionalFlag = 1;
                                            
                                            arrayLineOneToFour [lineOneToFourCount] = xPositionNext, lineOneToFourCount++;
                                            arrayLineOneToFour [lineOneToFourCount] = yPositionNext, lineOneToFourCount++;
                                            arrayLineOneToFour [lineOneToFourCount] = originalLine, lineOneToFourCount++;
                                            arrayLineOneToFour [lineOneToFourCount] = lineLength2*-1, lineOneToFourCount++;
                                            arrayLineOneToFour [lineOneToFourCount] = counter2, lineOneToFourCount++;
                                            
                                            pointLinkMap [yPositionNext][xPositionNext] = 0;
                                            
                                            if (additionalFlag == 1){
                                                for (int counter3 = 0; counter3 < lineOneToFourCount/5; counter3++){
                                                    if (counter3 == startCountFix) arrayLineOneToFour [counter3*5+2] = additionalLine*-1;
                                                    if (counter3 > startCountFix) arrayLineOneToFour [counter3*5+2] = additionalLine;
                                                }
                                                
                                                additionalLine++;
                                            }
                                            else originalLine++;
                                            
                                            startCountContinuous++;
                                            terminationFlag1 = 0;
                                        }
                                        else{
                                            
                                            if (pointLinkMap [yPositionNext][xPositionNext] == -6) additionalFlag = 1;
                                            
                                            arrayLineOneToFour [lineOneToFourCount] = xPositionNext, lineOneToFourCount++;
                                            arrayLineOneToFour [lineOneToFourCount] = yPositionNext, lineOneToFourCount++;
                                            arrayLineOneToFour [lineOneToFourCount] = originalLine, lineOneToFourCount++;
                                            arrayLineOneToFour [lineOneToFourCount] = lineLength2, lineOneToFourCount++;
                                            arrayLineOneToFour [lineOneToFourCount] = counter2, lineOneToFourCount++;
                                            
                                            pointLinkMap [yPositionNext][xPositionNext] = 0;
                                            xPositionNext = xPositionNext2;
                                            yPositionNext = yPositionNext2;
                                            startCountContinuous++;
                                            lineLength2++;
                                        }
                                        
                                    } while (terminationFlag1 == 1);
                                }
                            }
                        }
                    }
                }
                
                for (int counter2 = 0; counter2 < yDimension*2+1; counter2++){
                    delete [] pointLinkMap [counter2];
                    delete [] sourceMatrix [counter2];
                }
                
                delete [] pointLinkMap;
                delete [] sourceMatrix;
                
                delete [] arrayLineTracking;
                
                if (edgeTraceStartEndCount+3 > edgeTraceStartEndLimit){
                    int *arrayEdgeTraceTemp = new int [edgeTraceStartEndCount+50];
                    for (int counter2 = 0; counter2 < edgeTraceStartEndCount; counter2++) arrayEdgeTraceTemp [counter2] = arrayEdgeTraceStartEnd [counter2];
                    
                    delete [] arrayEdgeTraceStartEnd;
                    arrayEdgeTraceStartEnd = new int [edgeTraceStartEndLimit+5000], edgeTraceStartEndLimit = edgeTraceStartEndLimit+5000;
                    
                    for (int counter2 = 0; counter2 < edgeTraceStartEndCount; counter2++) arrayEdgeTraceStartEnd [counter2] = arrayEdgeTraceTemp [counter2];
                    delete [] arrayEdgeTraceTemp;
                }
                
                arrayEdgeTraceStartEnd [edgeTraceStartEndCount] = counter1, edgeTraceStartEndCount++;
                arrayEdgeTraceStartEnd [edgeTraceStartEndCount] = edgeTraceCount/6, edgeTraceStartEndCount++;
                
                for (int counter2 = 0; counter2 < lineOneToFourCount/5; counter2++){
                    if (arrayLineOneToFour [counter2*5]+xLowest >= 0 && arrayLineOneToFour [counter2*5+1]+yLowest >= 0){
                        if (edgeTraceCount+6 > edgeTraceLimit){
                            int *arrayEdgeTraceTemp = new int [edgeTraceCount+50];
                            for (int counter3 = 0; counter3 < edgeTraceCount; counter3++) arrayEdgeTraceTemp [counter3] = arrayEdgeTrace [counter3];
                            
                            delete [] arrayEdgeTrace;
                            arrayEdgeTrace = new int [edgeTraceLimit+7000], edgeTraceLimit = edgeTraceLimit+7000;
                            
                            for (int counter3 = 0; counter3 < edgeTraceCount; counter3++) arrayEdgeTrace [counter3] = arrayEdgeTraceTemp [counter3];
                            delete [] arrayEdgeTraceTemp;
                        }
                        
                        arrayEdgeTrace [edgeTraceCount] = counter1, edgeTraceCount++; //------Connectivity number------
                        arrayEdgeTrace [edgeTraceCount] = arrayLineOneToFour [counter2*5+4]+1, edgeTraceCount++; //------Orientation number------
                        arrayEdgeTrace [edgeTraceCount] = arrayLineOneToFour [counter2*5]+xLowest, edgeTraceCount++; //------X position------
                        arrayEdgeTrace [edgeTraceCount] = arrayLineOneToFour [counter2*5+1]+yLowest, edgeTraceCount++; //------Y position------
                        arrayEdgeTrace [edgeTraceCount] = arrayLineOneToFour [counter2*5+3], edgeTraceCount++; //------Length, last point *-1------
                        arrayEdgeTrace [edgeTraceCount] = arrayLineOneToFour [counter2*5+2], edgeTraceCount++; //------Line number, 1 or addition 2, 3, etc, first point *-1------
                    }
                }
                
                arrayEdgeTraceStartEnd [edgeTraceStartEndCount] = (edgeTraceCount-6)/6, edgeTraceStartEndCount++;
                
                delete [] arrayLineOneToFour;
                
                //for (int counterA = 0; counterA < edgeTraceCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayEdgeTrace [counterA*6+counterB];
                //	cout<<" arrayEdgeTrace "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < edgeTraceStartEndCount/3; counterA++){
                //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayEdgeTraceStartEnd [counterA*3+counterB];
                //	cout<<" arrayEdgeTraceStartEnd "<<counterA<<endl;
                //}
            }
        }
    }
    
    delete [] arrayEdgeTraceValue1;
    delete [] arrayEdgeTraceX1;
    delete [] arrayEdgeTraceY1;
    delete [] arrayEdgeTraceValue2;
    delete [] arrayEdgeTraceX2;
    delete [] arrayEdgeTraceY2;
    delete [] arrayEdgeTraceValue3;
    delete [] arrayEdgeTraceX3;
    delete [] arrayEdgeTraceY3;
    delete [] arrayEdgeTraceValue4;
    delete [] arrayEdgeTraceX4;
    delete [] arrayEdgeTraceY4;
}

@end
