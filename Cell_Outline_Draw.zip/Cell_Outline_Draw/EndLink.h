//
// EndLink.h
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 30/11/12.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#ifndef ENDLINK_H
#define ENDLINK_H
#import "Controller.h"
#endif

@interface EndLink : NSObject {
    id gapChase3;
}

-(void)endLinkProcess:(int)maxPointDimX :(int)maxPointDimY :(int)minPointDimX :(int)minPointDimY :(int)minValue;
-(void)gapChaseUpdate;
-(void)linkedLineUpDate;

@end
