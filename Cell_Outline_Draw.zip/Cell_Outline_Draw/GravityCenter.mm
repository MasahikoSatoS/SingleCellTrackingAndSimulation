//
// GravityCenter.mm
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 25/02/13.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#import "GravityCenter.h"

@implementation GravityCenter

-(void)gravityCenterDetermine{
    int gravityCenter [4];
    
    for (int counterY = 0; counterY < imageWidth; counterY++){
        for (int counterX = 0; counterX < imageWidth; counterX++) mapData [counterY][counterX] = 0;
    }
    
    int numberOfEntry = 0;
    
    for (int counter1 = 0; counter1 < forNextConnectivityCount/5; counter1++){
        if (arrayForNextConnectivity [counter1*5+4] == 1) numberOfEntry++;
    }
    
    int **entryPosition = new int *[numberOfEntry+1];
    for (int counter1 = 0; counter1 < numberOfEntry+1; counter1++) entryPosition [counter1] = new int [3];
    
    int numberOfEntry2 = 0;
    
    for (int counter1 = 0; counter1 < forNextConnectivityCount/5; counter1++){
        if (arrayForNextConnectivity [counter1*5+4] == 1) entryPosition [numberOfEntry2][0] = counter1;
        else if (arrayForNextConnectivity [counter1*5+4] == 2) entryPosition [numberOfEntry2][1] = counter1, numberOfEntry2++;
    }
    
    //for (int counterA = 0; counterA < numberOfEntry; counterA++){
    //	cout<<counterA<<" "<<entryPosition [counterA][0]<<" "<<entryPosition [counterA][1]<<" EntryPosition"<<endl;
    //}
    
    arrayXYPositionCenter = new int [numberOfEntry*7+50], xyPositionCenterCount = 0;
    
    int *connectAnalysisX = new int [imageWidth*4];
    int *connectAnalysisY = new int [imageWidth*4];
    int *connectAnalysisTempX = new int [imageWidth*4];
    int *connectAnalysisTempY = new int [imageWidth*4];
    
    int startPosition = 0;
    int endPosition = 0;
    int maxPointDimX = 0;
    int maxPointDimY = 0;
    int minPointDimX = 0;
    int minPointDimY = 0;
    int horizontalLength = 0;
    int verticalLength = 0;
    int dimension = 0;
    int horizontalStart = 0;
    int verticalStart = 0;
    int connectivityNumber = 0;
    int connectAnalysisCount = 0;
    int terminationFlag = 0;
    int connectAnalysisTempCount = 0;
    int xSource = 0;
    int ySource = 0;
    int XgravityImageTemp = 0;
    int YgravityImageTemp = 0;
    int gravityX = 0;
    int gravityY = 0;
    int averageIntensity = 0;
    
    for (int counter1 = 0; counter1 < numberOfEntry; counter1++){
        startPosition = entryPosition [counter1][0];
        endPosition = entryPosition [counter1][1];
        
        maxPointDimX = 0;
        maxPointDimY = 0;
        minPointDimX = 100000;
        minPointDimY = 100000;
        
        for (int counter2 = startPosition; counter2 <= endPosition; counter2++){
            if (maxPointDimX < arrayForNextConnectivity [counter2*5]) maxPointDimX = arrayForNextConnectivity [counter2*5];
            if (minPointDimX > arrayForNextConnectivity [counter2*5]) minPointDimX = arrayForNextConnectivity [counter2*5];
            if (maxPointDimY < arrayForNextConnectivity [counter2*5+1]) maxPointDimY = arrayForNextConnectivity [counter2*5+1];
            if (minPointDimY > arrayForNextConnectivity [counter2*5+1]) minPointDimY = arrayForNextConnectivity [counter2*5+1];
        }
        
        //------Determine the dimension of cell------
        horizontalLength = (maxPointDimX-minPointDimX)/2*2;
        verticalLength = (maxPointDimY-minPointDimY)/2*2;
        dimension = 0;
        
        if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
        
        if (horizontalLength < verticalLength) dimension = verticalLength+30;
        
        dimension = (dimension/2)*2;
        
        horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
        verticalStart = minPointDimY-(dimension-verticalLength)/2;
        
        if (dimension != 0){
            int **previousMap2 = new int *[dimension+1];
            
            for (int counter2 = 0; counter2 < dimension+1; counter2++) previousMap2 [counter2] = new int [dimension+1];
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++) previousMap2 [counterY][counterX] = 0;
            }
            
            for (int counter2 = startPosition; counter2 <= endPosition; counter2++){
                if (arrayForNextConnectivity [counter2*5]-horizontalStart >= 0 && arrayForNextConnectivity [counter2*5]-horizontalStart < dimension && arrayForNextConnectivity [counter2*5+1]-verticalStart >= 0 && arrayForNextConnectivity [counter2*5+1]-verticalStart < dimension) previousMap2 [arrayForNextConnectivity [counter2*5+1]-verticalStart][arrayForNextConnectivity [counter2*5]-horizontalStart] = arrayForNextConnectivity [startPosition*5+3];
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<< previousMap2 [counterA][counterB];
            //	cout<<" previousMap2 "<<counterA<<endl;
            //}
            
            connectivityNumber = -3;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (previousMap2 [counterY][counterX] == 0){
                        connectivityNumber = connectivityNumber+2;
                        connectAnalysisCount = 0;
                        
                        if (connectivityNumber >= 1){
                            connectivityNumber = arrayForNextConnectivity [startPosition*5+3];
                            previousMap2 [counterY][counterX] = connectivityNumber;
                        }
                        
                        if (counterY-1 >= 0 && previousMap2 [counterY-1][counterX] == 0){
                            previousMap2 [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension && previousMap2 [counterY][counterX+1] == 0){
                            previousMap2 [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && previousMap2 [counterY+1][counterX] == 0){
                            previousMap2 [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && previousMap2 [counterY][counterX-1] == 0){
                            previousMap2 [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                    xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                    
                                    if (ySource-1 >= 0 && previousMap2 [ySource-1][xSource] == 0){
                                        previousMap2 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && previousMap2 [ySource][xSource+1] == 0){
                                        previousMap2 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && previousMap2 [ySource+1][xSource] == 0){
                                        previousMap2 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && previousMap2 [ySource][xSource-1] == 0){
                                        previousMap2 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                    connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //------Remove connectivity groups, which attach edge, extract inner part of Linked Line------
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (previousMap2 [counterY][counterX] == -1) previousMap2 [counterY][counterX] = 0;
                }
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageWidth && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageWidth && mapData [counterY+verticalStart][counterX+horizontalStart] == 0 && previousMap2 [counterY][counterX] != 0){
                        mapData [counterY+verticalStart][counterX+horizontalStart] = previousMap2 [counterY][counterX];
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<< previousMap2 [counterA][counterB];
            //	cout<<" previousMap2 "<<counterA<<endl;
            //}
            
            //==========Gravity center determinatiin==========
            gravityCenter [0] = 0;
            gravityCenter [1] = 0;
            gravityCenter [2] = 0;
            gravityCenter [3] = 0; //------Determine the Gravity Center for Over 190. Done when image 6 is processed. Data will be kept------
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (previousMap2 [counterY][counterX] != 0){
                        gravityCenter [0] = gravityCenter [0]+counterX;
                        gravityCenter [1] = gravityCenter [1]+counterY;
                        gravityCenter [2]++;
                        
                        XgravityImageTemp = counterX+horizontalStart;
                        YgravityImageTemp = counterY+verticalStart;
                        
                        if (XgravityImageTemp > imageHeight) XgravityImageTemp = imageHeight;
                        
                        if (XgravityImageTemp < 0) XgravityImageTemp = 0;
                        
                        if (YgravityImageTemp > imageHeight) YgravityImageTemp = imageHeight;
                        
                        if (YgravityImageTemp < 0) YgravityImageTemp = 0;
                        
                        gravityCenter [3] = gravityCenter [3]+arrayExtractedImage [YgravityImageTemp][XgravityImageTemp];
                    }
                }
            }
            
            gravityX = (int)(gravityCenter [0]/(double)gravityCenter [2]);
            gravityY = (int)(gravityCenter [1]/(double)gravityCenter [2]);
            averageIntensity = (int)(gravityCenter [3]/(double)gravityCenter [2]);
            
            arrayXYPositionCenter [xyPositionCenterCount] = 1, xyPositionCenterCount++;
            arrayXYPositionCenter [xyPositionCenterCount] = gravityX+horizontalStart, xyPositionCenterCount++;
            arrayXYPositionCenter [xyPositionCenterCount] = gravityY+verticalStart, xyPositionCenterCount++;
            arrayXYPositionCenter [xyPositionCenterCount] = gravityCenter [2], xyPositionCenterCount++;
            arrayXYPositionCenter [xyPositionCenterCount] = averageIntensity, xyPositionCenterCount++;
            arrayXYPositionCenter [xyPositionCenterCount] = arrayForNextConnectivity [startPosition*5+3], xyPositionCenterCount++;
            arrayXYPositionCenter [xyPositionCenterCount] = 0, xyPositionCenterCount++;
            
            for (int counter2 = 0; counter2 < dimension+1; counter2++) delete [] previousMap2 [counter2];
            delete [] previousMap2;
        }
    }
    
    delete [] connectAnalysisX;
    delete [] connectAnalysisY;
    delete [] connectAnalysisTempX;
    delete [] connectAnalysisTempY;
    
    //for (int counterA = 0; counterA < dimension; counterA++){
    //	for (int counterB = 0; counterB < imageWidth; counterB++) cout<<" "<< mapData [counterA][counterB];
    //	cout<<" mapData "<<counterA<<endl;
    //}
    
    for (int counter1 = 0; counter1 < numberOfEntry+1; counter1++) delete [] entryPosition [counter1];
    delete [] entryPosition;
}

@end
