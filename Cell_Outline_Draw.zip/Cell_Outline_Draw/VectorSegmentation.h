//
// VectorSegmentation.h
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 11/10/04.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#ifndef VECTORSEGMENTATION_H
#define VECTORSEGMENTATION_H
#import "Controller.h"
#endif

@interface VectorSegmentation : NSObject {
}

-(void)vectorReconstraction;

@end
