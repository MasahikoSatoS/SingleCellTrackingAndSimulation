//
// ImageProcessing.h
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 10/07/11.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#ifndef IMAGEPROCESSING_H
#define IMAGEPROCESSING_H
#import "Controller.h"
#endif

@interface ImageProcessing : NSObject {
    id connectivityAnalysis;
    id outlineVector;
    id edgeTracingProcess;
    id lineChase;
    id vectorSegmentation;
    id vectorAnalysis;
    id gravityCenter;
}

-(id)init;
-(void)dealloc;

@end
