//
// LineChase.h
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 24/07/11.
// Modified by Masahiko Sato on 18/10/12.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#ifndef LINECHASE_H
#define LINECHASE_H
#import "Controller.h"
#endif

@interface LineChase : NSObject {
    id lineSelect;
    id linkPoint;
    id lineConnect;
    id gapChase;
    id gapFill;
    id arrayModification;
    id endlink;
    id shapeAdjust;
    id upDateLine;
    id overlapCheck;
}

-(void)lineChaseProcess:(int)typeSubArray;

@end
