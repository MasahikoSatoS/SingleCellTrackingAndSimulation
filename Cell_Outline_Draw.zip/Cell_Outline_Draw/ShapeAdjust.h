//
// shapeAdjust.h
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 25/12/12.
// Copyright 2012 Masahiko Sato. All rights reserved.
//

#ifndef SHAPEADJUST_H
#define SHAPEADJUST_H
#import "Controller.h"
#endif

@interface ShapeAdjust : NSObject {
    id gapFill;
}

-(void)shapeAdjustMain:(int)maxPointDimX :(int)maxPointDimY :(int)minPointDimX :(int)minPointDimY :(int)linkedLinePair :(int)counter;
-(void)linkedLineSizeUpDate;
-(void)linkedLineAssSizeUpDate;

@end
