//
// LineSelect.h
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 24/11/12.
// Copyright 2012 Masahiko Sato. All rights reserved.
//

#ifndef LINESELECT_H
#define LINESELECT_H
#import "Controller.h"
#endif

@interface LineSelect : NSObject {
}

-(void)lineCombine:(int)typeDefine :(int)lineSet;

@end
