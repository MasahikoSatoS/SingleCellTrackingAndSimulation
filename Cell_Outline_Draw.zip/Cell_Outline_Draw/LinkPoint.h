//
// LinkPoint.h
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 24/11/12.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#ifndef LINKPOINT_H
#define LINKPOINT_H
#import "Controller.h"
#endif

@interface LinkPoint : NSObject {
}

-(void)lineEndAdjust;

@end
