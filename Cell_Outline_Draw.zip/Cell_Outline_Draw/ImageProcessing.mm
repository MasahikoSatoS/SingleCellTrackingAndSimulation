//
// ImageProcessing.mm
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 10/07/11.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#import "ImageProcessing.h"

NSString *notificationToImageProcessing = @"notificationExecuteImageProcessing";

@implementation ImageProcessing

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToImageProcessing object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^(void){
        progressValue = 100;
        progressTiming = 1;
        
        arrayImage150 = new int *[imageWidth+1];
        arrayImageRemaining = new int *[imageWidth+1];
        arrayImageConnect200 = new int *[imageWidth+1];
        arrayImageConnect220 = new int *[imageWidth+1];
        arrayImageConnect240 = new int *[imageWidth+1];
        arrayImageConnectivity = new int *[imageWidth+1];
        arrayImageConnectivityA = new int *[imageWidth+1];
        arrayImageConnectivityB = new int *[imageWidth+1];
        arrayImageConnectivityC = new int *[imageWidth+1];
        arrayImageConnectivityD = new int *[imageWidth+1];
        mapData = new int *[imageWidth+1];
        
        for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
            arrayImage150 [counter1] = new int [imageWidth+1];
            arrayImageRemaining [counter1] = new int [imageWidth+1];
            arrayImageConnect200 [counter1] = new int [imageWidth+1];
            arrayImageConnect220 [counter1] = new int [imageWidth+1];
            arrayImageConnect240 [counter1] = new int [imageWidth+1];
            arrayImageConnectivity [counter1] = new int [imageWidth+1];
            arrayImageConnectivityA [counter1] = new int [imageWidth+1];
            arrayImageConnectivityB [counter1] = new int [imageWidth+1];
            arrayImageConnectivityC [counter1] = new int [imageWidth+1];
            arrayImageConnectivityD [counter1] = new int [imageWidth+1];
            mapData [counter1] = new int [imageWidth+1];
        }
        
        //cout<<areaLimitCurrent<<" "<<cutOffLevelCurrent<<" "<<cutOffLevelCurrent2<<" "<<cutOffLevelCurrent3<<" "<<cutOffLevelCurrent4<<" CutOffLevels"<<endl;
        
        //------Image 150------
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++){
                if (arrayExtractedImage [counterY][counterX] == 100) arrayImage150 [counterY][counterX] = 0;
                else if (arrayExtractedImage [counterY][counterX] < 30) arrayImage150 [counterY][counterX] = 0;
                else arrayImage150 [counterY][counterX] = 150;
            }
        }
        
        int typeSubArray = -1;
        self->connectivityAnalysis = [[ConnectivityAnalysis alloc] init];
        [self->connectivityAnalysis matchingCheck:typeSubArray];
        
        int **rangeMatrixCross = new int *[imageWidth+1];
        int **rangeMatrixExtracted = new int *[imageWidth+1];
        
        for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
            rangeMatrixCross [counter1] = new int [imageWidth+1];
            rangeMatrixExtracted [counter1] = new int [imageWidth+1];
        }
        
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++){
                rangeMatrixCross [counterY][counterX] = arrayImage150 [counterY][counterX];
                rangeMatrixExtracted [counterY][counterX] = arrayExtractedImage [counterY][counterX];
            }
        }
        
        int neighbourCount2 = 0;
        int neighbourTotal2 = 0;
        
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++){
                if (rangeMatrixCross [counterY][counterX] == 0){
                    if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrixCross [counterY-1][counterX-1] == 0) neighbourCount2++;
                    if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrixCross [counterY-1][counterX-1] != 0) neighbourTotal2 = neighbourTotal2+rangeMatrixExtracted [counterY-1][counterX-1];
                    if (counterY-1 >= 0 && rangeMatrixCross [counterY-1][counterX] == 0) neighbourCount2++;
                    if (counterY-1 >= 0 && rangeMatrixCross [counterY-1][counterX] != 0) neighbourTotal2 = neighbourTotal2+rangeMatrixExtracted [counterY-1][counterX];
                    if (counterY-1 >= 0 && counterX+1 < imageWidth && rangeMatrixCross [counterY-1][counterX+1] == 0) neighbourCount2++;
                    if (counterY-1 >= 0 && counterX+1 < imageWidth && rangeMatrixCross [counterY-1][counterX+1] != 0) neighbourTotal2 = neighbourTotal2+rangeMatrixExtracted [counterY-1][counterX+1];
                    if (counterX+1 < imageWidth && rangeMatrixCross [counterY][counterX+1] == 0) neighbourCount2++;
                    if (counterX+1 < imageWidth && rangeMatrixCross [counterY][counterX+1] != 0) neighbourTotal2 = neighbourTotal2+rangeMatrixExtracted [counterY][counterX+1];
                    if (rangeMatrixCross [counterY][counterX] == 0) neighbourCount2++;
                    if (rangeMatrixCross [counterY][counterX] != 0) neighbourTotal2 = neighbourTotal2+rangeMatrixExtracted [counterY][counterX];
                    if (counterY+1 < imageWidth && counterX+1 < imageWidth && rangeMatrixCross [counterY+1][counterX+1] == 0) neighbourCount2++;
                    if (counterY+1 < imageWidth && counterX+1 < imageWidth && rangeMatrixCross [counterY+1][counterX+1] != 0) neighbourTotal2 = neighbourTotal2+rangeMatrixExtracted [counterY+1][counterX+1];
                    if (counterY+1 < imageWidth && rangeMatrixCross [counterY+1][counterX] == 0) neighbourCount2++;
                    if (counterY+1 < imageWidth && rangeMatrixCross [counterY+1][counterX] != 0) neighbourTotal2 = neighbourTotal2+rangeMatrixExtracted [counterY+1][counterX];
                    if (counterY+1 < imageWidth && counterX-1 >= 0 && rangeMatrixCross [counterY+1][counterX-1] == 0) neighbourCount2++;
                    if (counterY+1 < imageWidth && counterX-1 >= 0 && rangeMatrixCross [counterY+1][counterX-1] != 0) neighbourTotal2 = neighbourTotal2+rangeMatrixExtracted [counterY+1][counterX-1];
                    if (counterX-1 >= 0 && rangeMatrixCross [counterY][counterX-1] == 0) neighbourCount2++;
                    if (counterX-1 >= 0 && rangeMatrixCross [counterY][counterX-1] != 0) neighbourTotal2 = neighbourTotal2+rangeMatrixExtracted [counterY][counterX-1];
                    
                    if (neighbourCount2 <= 2){
                        neighbourTotal2 = (int)(neighbourTotal2/(double)(9-neighbourCount2));
                        rangeMatrixCross [counterY][counterX] = neighbourTotal2*-1;
                    }
                    
                    neighbourCount2 = 0;
                    neighbourTotal2 = 0;
                }
            }
        }
        
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++){
                if (rangeMatrixCross [counterY][counterX] == 150) arrayExtractedImage [counterY][counterX] = rangeMatrixExtracted [counterY][counterX];
                else if (rangeMatrixCross [counterY][counterX] < 0) arrayExtractedImage [counterY][counterX] = rangeMatrixCross [counterY][counterX]*-1;
                else if (rangeMatrixExtracted [counterY][counterX] < 30) arrayExtractedImage [counterY][counterX] = rangeMatrixExtracted [counterY][counterX];
                else arrayExtractedImage [counterY][counterX] = 100;
            }
        }
        
        for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
            delete [] rangeMatrixCross [counter1];
            delete [] rangeMatrixExtracted [counter1];
        }
        
        delete [] rangeMatrixCross;
        delete [] rangeMatrixExtracted;
        
        arrayOutlineVectorSegment = new int [10000];
        outlineVectorSegmentCount = 0;
        outlineVectorSegmentLimit = 10000;
        arrayVectorSegmentation = new int [5000];
        vectorSegmentationCount = 0;
        vectorSegmentationLimit = 5000;
        arrayVectorSegmentationLength = new double [2500];
        vectorSegmentationLengthCount = 0;
        vectorSegmentationLengthLimit = 2500;
        
        analysisResultCount1 = 0;
        analysisResultStatus1 = 0;
        analysisResultCount2 = 0;
        analysisResultStatus2 = 0;
        analysisResultCount3 = 0;
        analysisResultStatus3 = 0;
        
        int cutOffHigherRange = (int)((250-cutOffLevelCurrent)/(double)4);
        
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++){
                if (arrayExtractedImage [counterY][counterX] == 100) arrayImageConnect200 [counterY][counterX] = 0;
                else if (arrayExtractedImage [counterY][counterX] < cutOffLevelCurrent+cutOffHigherRange) arrayImageConnect200 [counterY][counterX] = 0;
                else arrayImageConnect200 [counterY][counterX] = 150;
            }
        }
        
        typeSubArray = 2;
        self->connectivityAnalysis = [[ConnectivityAnalysis alloc] init];
        [self->connectivityAnalysis matchingCheck:typeSubArray];
        
        arrayOutlineVectorSource1 = new int [7500];
        outlineVectorSourceCount1 = 0;
        outlineVectorSourceLimit1 = 7500;
        outlineVectorSegmentCount = 0;
        vectorSegmentationCount = 0;
        vectorSegmentationLengthCount = 0;
        
        self->outlineVector = [[OutlineVector alloc] init];
        [self->outlineVector outlineVector:typeSubArray:imageWidth];
        
        self->vectorSegmentation = [[VectorSegmentation alloc] init];
        [self->vectorSegmentation vectorReconstraction];
        
        self->vectorAnalysis = [[VectorAnalysis alloc] init];
        [self->vectorAnalysis vectorAngle:typeSubArray];
        
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++){
                if (arrayExtractedImage [counterY][counterX] == 100) arrayImageConnect220 [counterY][counterX] = 0;
                else if (arrayExtractedImage [counterY][counterX] < cutOffLevelCurrent+cutOffHigherRange*2) arrayImageConnect220 [counterY][counterX] = 0;
                else arrayImageConnect220 [counterY][counterX] = 150;
            }
        }
        
        //for (int counterA = 0; counterA < 50; counterA++){
        //	for (int counterB = 0; counterB < 50; counterB++) cout<<" "<<arrayImageConnect220 [counterA][counterB];
        //	cout<<" arrayImageConnect220 "<<counterA<<endl;
        //}
        
        typeSubArray = 3;
        self->connectivityAnalysis = [[ConnectivityAnalysis alloc] init];
        [self->connectivityAnalysis matchingCheck:typeSubArray];
        
        arrayOutlineVectorSource2 = new int [7500];
        outlineVectorSourceCount2 = 0;
        outlineVectorSourceLimit2 = 7500;
        outlineVectorSegmentCount = 0;
        vectorSegmentationCount = 0;
        vectorSegmentationLengthCount = 0;
        
        self->outlineVector = [[OutlineVector alloc] init];
        [self->outlineVector outlineVector:typeSubArray:imageWidth];
        
        self->vectorSegmentation = [[VectorSegmentation alloc] init];
        [self->vectorSegmentation vectorReconstraction];
        
        self->vectorAnalysis = [[VectorAnalysis alloc] init];
        [self->vectorAnalysis vectorAngle:typeSubArray];
        
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++){
                if (arrayExtractedImage [counterY][counterX] == 100) arrayImageConnect240 [counterY][counterX] = 0;
                else if (arrayExtractedImage [counterY][counterX] < cutOffLevelCurrent+cutOffHigherRange*3) arrayImageConnect240 [counterY][counterX] = 0;
                else arrayImageConnect240 [counterY][counterX] = 150;
            }
        }
        
        //clock_t time1, time2, time3, time4, time5;
        
        typeSubArray = 4;
        self->connectivityAnalysis = [[ConnectivityAnalysis alloc] init];
        [self->connectivityAnalysis matchingCheck:typeSubArray];
        
        outlineVectorSegmentCount = 0;
        vectorSegmentationCount = 0;
        vectorSegmentationLengthCount = 0;
        
        arrayOutlineVectorSource3 = new int [7500];
        outlineVectorSourceCount3 = 0;
        outlineVectorSourceLimit3 = 7500;
        self->outlineVector = [[OutlineVector alloc] init];
        [self->outlineVector outlineVector:typeSubArray:imageWidth];
        
        self->vectorSegmentation = [[VectorSegmentation alloc] init];
        [self->vectorSegmentation vectorReconstraction];
        
        self->vectorAnalysis = [[VectorAnalysis alloc] init];
        [self->vectorAnalysis vectorAngle:typeSubArray];
        
        //------Image set for edge find------
        arrayEdgeTrace = new int [7500];
        edgeTraceLimit = 7000;
        arrayEdgeTraceStartEnd = new int [5000];
        edgeTraceStartEndLimit = 5000;
        arrayOutlineVectorSource0 = new int [7500];
        outlineVectorSourceLimit0 = 7500;
        arrayOutlineVectorSource4 = new int [7500];
        outlineVectorSourceLimit4 = 7500;
        arrayGapChase = new int [500];
        gapChaseCount = 0;
        gapChaseLimit = 500;
        arrayGapData = new int [500];
        gapDataCount = 0;
        gapDataLimit = 500;
        arrayMapData = new int [40000];
        mapDataCount = 0;
        mapDataLimit = 40000;
        arrayLinkedLine = new int [5000];
        linkedLineCount = 0;
        linkedLineLimit = 5000;
        arrayReturnData = new int [500];
        returnDataCount = 0;
        returnDataLimit = 500;
        arrayOutlineExist = new int [10000];
        outlineExistCount = 0;
        outlineExistLimit = 10000;
        arrayOutlineExistAss = new int [1000];
        outlineExistAssCount = 0;
        outlineExistAssLimit = 1000;
        arrayOutlineAddition = new int [10000];
        outlineAdditionCount = 0;
        outlineAdditionLimit = 10000;
        arrayForNextConnectivity = new int [10000];
        forNextConnectivityCount = 0;
        forNextConnectivityLimit = 10000;
        arrayForNextConnectivityAss = new int [5000];
        forNextConnectivityAssCount = 0;
        forNextConnectivityAssLimit = 5000;
        arrayLinkedLineUpdate = new int [50000];
        linkedLineUpdateCount = 0;
        linkedLineUpdateLimit = 50000;
        arrayLinkedLineUpdateAss = new int [50000];
        linkedLineUpdateAssCount = 0;
        linkedLineUpdateAssLimit = 50000;
        
        progressValue = 10;
        progressTiming = 3;
        
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++){
                if (arrayExtractedImage [counterY][counterX] == 100) arrayImage150 [counterY][counterX] = 0;
                else if (arrayExtractedImage [counterY][counterX] < cutOffLevelCurrent) arrayImage150 [counterY][counterX] = 0;
                else arrayImage150 [counterY][counterX] = 150;
            }
        }
        
        typeSubArray = 1;
        outlineVectorSourceCount0 = 0;
        self->connectivityAnalysis = [[ConnectivityAnalysis alloc] init];
        [self->connectivityAnalysis matchingCheck:typeSubArray];
        
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++) arrayImageConnectivityA [counterY][counterX] = 0;
        }
        
        for (int counterY = 1; counterY < imageWidth; counterY++){
            for (int counterX = 1; counterX < imageWidth; counterX++){
                if (arrayImageConnectivity [counterY][counterX] != 0){
                    arrayImageConnectivityA [counterY][counterX] = arrayImageConnectivity [counterY][counterX];
                }
            }
        }
        
        self->outlineVector = [[OutlineVector alloc] init];
        [self->outlineVector outlineVector:typeSubArray:imageWidth];
        
        edgeTraceCount = 0;
        edgeTraceStartEndCount = 0;
        
        int **arrayImageConnectivityTemp = new int *[imageWidth+2];
        
        for (int counter1 = 0; counter1 < imageWidth+2; counter1++) arrayImageConnectivityTemp [counter1] = new int [imageWidth+2];
        
        for (int counterY = 0; counterY < imageWidth+2; counterY++){
            for (int counterX = 0; counterX < imageWidth+2; counterX++) arrayImageConnectivityTemp [counterY][counterX] = 0;
        }
        
        for (int counter1 = 0; counter1 < outlineVectorSourceCount0/3; counter1++){
            arrayImageConnectivityTemp [arrayOutlineVectorSource0 [counter1*3+2]+1][arrayOutlineVectorSource0 [counter1*3+1]+1] = arrayOutlineVectorSource0 [counter1*3];
        }
        
        //for (int counterA = 2000; counterA < 2200; counterA++){
        //  for (int counterB = 2300; counterB < 2400; counterB++) cout<<" "<<arrayImageConnectivityTemp [counterA][counterB];
        // cout<<" arrayImageConnectivityTemp "<<counterA<<endl;
        //}
        
        int *connectAnalysisX = new int [(imageWidth+2)*4];
        int *connectAnalysisY = new int [(imageWidth+2)*4];
        int *connectAnalysisTempX = new int [(imageWidth+2)*4];
        int *connectAnalysisTempY = new int [(imageWidth+2)*4];
        
        int connectivityNumber = -3;
        int connectAnalysisCount = 0;
        int terminationFlag = 0;
        int connectAnalysisTempCount = 0;
        int xSource = 0;
        int ySource = 0;
        
        for (int counterY = 0; counterY < imageWidth+2; counterY++){
            for (int counterX = 0; counterX < imageWidth+2; counterX++){
                if (arrayImageConnectivityTemp [counterY][counterX] == 0){
                    connectivityNumber = connectivityNumber+2;
                    
                    if (connectivityNumber >= 1){
                        if (counterY-1 >= 0 && arrayImageConnectivityTemp [counterY-1][counterX] != -1 && arrayImageConnectivityTemp [counterY-1][counterX] != 0){
                            connectivityNumber = arrayImageConnectivityTemp [counterY-1][counterX], arrayImageConnectivityTemp [counterY-1][counterX] = connectivityNumber;
                        }
                        if (counterX+1 < imageWidth+2+2 && arrayImageConnectivityTemp [counterY][counterX+1] != -1 && arrayImageConnectivityTemp [counterY][counterX+1] != 0){
                            connectivityNumber = arrayImageConnectivityTemp [counterY][counterX+1], arrayImageConnectivityTemp [counterY][counterX+1] = connectivityNumber;
                        }
                        if (counterY+1 < imageWidth+2+2 && arrayImageConnectivityTemp [counterY+1][counterX] != -1 && arrayImageConnectivityTemp [counterY+1][counterX] != 0){
                            connectivityNumber = arrayImageConnectivityTemp [counterY+1][counterX], arrayImageConnectivityTemp [counterY+1][counterX] = connectivityNumber;
                        }
                        if (counterX-1 >= 0 && arrayImageConnectivityTemp [counterY][counterX-1] != -1 && arrayImageConnectivityTemp [counterY][counterX-1] != 0){
                            connectivityNumber = arrayImageConnectivityTemp [counterY][counterX-1], arrayImageConnectivityTemp [counterY][counterX-1] = connectivityNumber;
                        }
                    }
                    
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && arrayImageConnectivityTemp [counterY-1][counterX] == 0){
                        arrayImageConnectivityTemp [counterY-1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < imageWidth+2 && arrayImageConnectivityTemp [counterY][counterX+1] == 0){
                        arrayImageConnectivityTemp [counterY][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < imageWidth+2 && arrayImageConnectivityTemp [counterY+1][counterX] == 0){
                        arrayImageConnectivityTemp [counterY+1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && arrayImageConnectivityTemp [counterY][counterX-1] == 0){
                        arrayImageConnectivityTemp [counterY][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && arrayImageConnectivityTemp [ySource-1][xSource] == 0){
                                    arrayImageConnectivityTemp [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < imageWidth+2 && arrayImageConnectivityTemp [ySource][xSource+1] == 0){
                                    arrayImageConnectivityTemp [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < imageWidth+2 && arrayImageConnectivityTemp [ySource+1][xSource] == 0){
                                    arrayImageConnectivityTemp [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && arrayImageConnectivityTemp [ySource][xSource-1] == 0){
                                    arrayImageConnectivityTemp [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        delete [] connectAnalysisX;
        delete [] connectAnalysisY;
        delete [] connectAnalysisTempX;
        delete [] connectAnalysisTempY;
        
        for (int counterY = 0; counterY < imageWidth+2; counterY++){
            for (int counterX = 0; counterX < imageWidth+2; counterX++){
                if (arrayImageConnectivityTemp [counterY][counterX] == -1) arrayImageConnectivityTemp [counterY][counterX] = 0;
            }
        }
        
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++) arrayImageConnectivity [counterY][counterX] = 0;
        }
        
        for (int counterY = 1; counterY < imageWidth+2; counterY++){
            for (int counterX = 1; counterX < imageWidth+2; counterX++){
                if (arrayImageConnectivityTemp [counterY][counterX] != 0){
                    arrayImageConnectivity [counterY-1][counterX-1] = arrayImageConnectivityTemp [counterY][counterX];
                }
            }
        }
        
        for (int counter1 = 0; counter1 < imageWidth+2; counter1++) delete [] arrayImageConnectivityTemp [counter1];
        
        delete [] arrayImageConnectivityTemp;
        
        //for (int counterA = 0; counterA < outlineVectorSourceCount0/3; counterA++){
        //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOutlineVectorSource0 [counterA*3+counterB];
        //	cout<<" arrayOutlineVectorSource0 "<<counterA<<endl;
        //}
        
        //for (int counterA = 2000; counterA < 2200; counterA++){
        //  for (int counterB = 2300; counterB < 2400; counterB++) cout<<" "<<arrayImageConnectivity [counterA][counterB];
        // cout<<" arrayImageConnectivity "<<counterA<<endl;
        //}
        
        self->edgeTracingProcess = [[EdgeTracing alloc] init];
        [self->edgeTracingProcess edgeTrace:typeSubArray];
        
        linkedLineUpdateCount = 0;
        linkedLineUpdateAssCount = 0;
        self->lineChase = [[LineChase alloc] init];
        [self->lineChase lineChaseProcess:typeSubArray];
        
        progressValue = 28;
        progressTiming = 3;
        
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++){
                if (arrayExtractedImage [counterY][counterX] == 100) arrayImage150 [counterY][counterX] = 0;
                else if (arrayExtractedImage [counterY][counterX] < cutOffLevelCurrent2) arrayImage150 [counterY][counterX] = 0;
                else arrayImage150 [counterY][counterX] = 150;
            }
        }
        
        typeSubArray = 2;
        outlineVectorSourceCount4 = 0;
        self->connectivityAnalysis = [[ConnectivityAnalysis alloc] init];
        [self->connectivityAnalysis reconstruction:typeSubArray];
        
        edgeTraceCount = 0;
        edgeTraceStartEndCount = 0;
        self->edgeTracingProcess = [[EdgeTracing alloc] init];
        [self->edgeTracingProcess edgeTrace:typeSubArray];
        
        linkedLineUpdateCount = 0;
        linkedLineUpdateAssCount = 0;
        self->lineChase = [[LineChase alloc] init];
        [self->lineChase lineChaseProcess:typeSubArray];
        
        progressValue = 44;
        progressTiming = 3;
        
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++){
                if (arrayExtractedImage [counterY][counterX] == 100) arrayImage150 [counterY][counterX] = 0;
                else if (arrayExtractedImage [counterY][counterX] < cutOffLevelCurrent3) arrayImage150 [counterY][counterX] = 0;
                else arrayImage150 [counterY][counterX] = 150;
            }
        }
        
        typeSubArray = 3;
        outlineVectorSourceCount4 = 0;
        self->connectivityAnalysis = [[ConnectivityAnalysis alloc] init];
        [self->connectivityAnalysis reconstruction:typeSubArray];
        
        edgeTraceCount = 0;
        edgeTraceStartEndCount = 0;
        self->edgeTracingProcess = [[EdgeTracing alloc] init];
        [self->edgeTracingProcess edgeTrace:typeSubArray];
        
        linkedLineUpdateCount = 0;
        linkedLineUpdateAssCount = 0;
        self->lineChase = [[LineChase alloc] init];
        [self->lineChase lineChaseProcess:typeSubArray];
        
        progressValue = 68;
        progressTiming = 3;
        
        //time1 = clock();
        
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++){
                if (arrayExtractedImage [counterY][counterX] == 100) arrayImage150 [counterY][counterX] = 0;
                else if (arrayExtractedImage [counterY][counterX] < cutOffLevelCurrent4) arrayImage150 [counterY][counterX] = 0;
                else arrayImage150 [counterY][counterX] = 150;
            }
        }
        
        typeSubArray = 4;
        outlineVectorSourceCount4 = 0;
        
        //time2 = clock();
        
        //cout<<"LineChaseTime01 "<<time2-time1<<endl;
        
        self->connectivityAnalysis = [[ConnectivityAnalysis alloc] init];
        [self->connectivityAnalysis reconstruction:typeSubArray];
        
        edgeTraceCount = 0;
        edgeTraceStartEndCount = 0;
        
        //time3 = clock();
        
        //cout<<"LineChaseTime02 "<<time3-time2<<endl;
        
        self->edgeTracingProcess = [[EdgeTracing alloc] init];
        [self->edgeTracingProcess edgeTrace:typeSubArray];
        
        linkedLineUpdateCount = 0;
        linkedLineUpdateAssCount = 0;
        
        //time4 = clock();
        
        //cout<<"LineChaseTime03 "<<time4-time3<<endl;
        
        self->lineChase = [[LineChase alloc] init];
        [self->lineChase lineChaseProcess:typeSubArray];
        
        //time5 = clock();
        
        progressValue = 100;
        progressTiming = 3;
        
        //cout<<"LineChaseTime04 "<<time5-time4<<endl;
        
        delete [] arrayEdgeTrace;
        delete [] arrayEdgeTraceStartEnd;
        delete [] arrayOutlineVectorSource0;
        delete [] arrayOutlineVectorSource1;
        delete [] arrayOutlineVectorSource2;
        delete [] arrayOutlineVectorSource3;
        delete [] arrayOutlineVectorSource4;
        delete [] arrayGapChase;
        delete [] arrayGapData;
        delete [] arrayMapData;
        delete [] arrayLinkedLine;
        delete [] arrayReturnData;
        delete [] arrayOutlineExist;
        delete [] arrayOutlineExistAss;
        delete [] arrayOutlineAddition;
        delete [] arrayOutlineVectorSegment;
        delete [] arrayVectorSegmentation;
        delete [] arrayVectorSegmentationLength;
        delete [] arrayLinkedLineUpdate;
        delete [] arrayLinkedLineUpdateAss;
        
        if (analysisResultStatus1 == 1) delete [] arrayAnalysisResult1;
        if (analysisResultStatus2 == 1) delete [] arrayAnalysisResult2;
        if (analysisResultStatus3 == 1) delete [] arrayAnalysisResult3;
        
        // for (int counterA = 0; counterA < forNextConnectivityCount/5; counterA++){
        //     for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayForNextConnectivity [counterA*5+counterB];
        //     cout<<" arrayForNextConnectivity "<<counterA<<" "<<counter1<<endl;
        // }
        
        self->gravityCenter = [[GravityCenter alloc] init];
        [self->gravityCenter gravityCenterDetermine];
        
        //for (int counterA = 0; counterA < xyPositionCenterCount/7; counterA++){
        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenter [counterA*7+counterB];
        //    cout<<" arrayXYPositionCenter "<<counterA<<" "<<endl;
        //}
        
        //for (int counterA = 0; counterA < forNextConnectivityAssCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayForNextConnectivityAss [counterA*6+counterB];
        //	cout<<" arrayForNextConnectivityAss "<<counterA<<" "<<endl;
        //}
        
        string extension = to_string(displayImageNumber);
        
        if (extension.length() == 1) extension = "000"+extension;
        else if (extension.length() == 2) extension = "00"+extension;
        else if (extension.length() == 3) extension = "0"+extension;
        
        string savePath;
        string saveConnectPath;
        
        if (runMode == 3){
            savePath = imageFolderPath+"/"+bodyName+"_Image"+"/"+treatNameManualString+"_Processed";
            saveConnectPath = savePath+"/"+extension+"_"+bodyName+"_"+treatNameManualString+"_MasterData";
        }
        
        if (runMode == 1){
            savePath = imageFolderPath+"/"+analysisNameManualString+"_Image"+"/"+treatNameManualString+"_Processed";
            saveConnectPath = savePath+"/"+extension+"_"+analysisNameManualString+"_"+treatNameManualString+"_MasterData";
        }
        
        int readBit [3];
        long indexCount = 0;
        
        char *writingArray = new char [(forNextConnectivityCount/5)*20+(forNextConnectivityAssCount/6)*22+(xyPositionCenterCount/7)*22+90];
        
        int dataTemp = 0;
        
        for (int counter1 = 0; counter1 < forNextConnectivityCount/5; counter1++){
            dataTemp = arrayForNextConnectivity [counter1*5];
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            dataTemp = arrayForNextConnectivity [counter1*5+1];
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            writingArray [indexCount] = (char)arrayForNextConnectivity [counter1*5+2], indexCount++;
            
            dataTemp = arrayForNextConnectivity [counter1*5+3];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = (char)arrayForNextConnectivity [counter1*5+4], indexCount++;
            
            writingArray [indexCount] = 0, indexCount++;
        }
        
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        
        for (int counter1 = 0; counter1 < forNextConnectivityAssCount/6; counter1++){
            dataTemp = arrayForNextConnectivityAss [counter1*6];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = (char)arrayForNextConnectivityAss [counter1*6+1], indexCount++;
            
            writingArray [indexCount] = (char)arrayForNextConnectivityAss [counter1*6+2], indexCount++;
            
            dataTemp = arrayForNextConnectivityAss [counter1*6+3];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayForNextConnectivityAss [counter1*6+4];
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            writingArray [indexCount] = (char)arrayForNextConnectivityAss [counter1*6+5], indexCount++;
        }
        
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        
        for (int counter1 = 0; counter1 < xyPositionCenterCount/7; counter1++){
            dataTemp = arrayXYPositionCenter [counter1*7+1];
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            dataTemp = arrayXYPositionCenter [counter1*7+2];
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            dataTemp = arrayXYPositionCenter [counter1*7+3];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = (char)arrayXYPositionCenter [counter1*7+4], indexCount++;
            
            dataTemp = arrayXYPositionCenter [counter1*7+5];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
        }
        
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        writingArray [indexCount] = 0, indexCount++;
        
        ofstream outfile8 (saveConnectPath.c_str(), ofstream::binary);
        outfile8.write ((char*)writingArray, indexCount);
        outfile8.close();
        
        delete []  writingArray;
        
        delete [] arrayForNextConnectivity;
        delete [] arrayForNextConnectivityAss;
        delete [] arrayXYPositionCenter;
        
        string wholeMapPath;
        
        if (runMode == 3) wholeMapPath = savePath+"/"+extension+"_"+bodyName+"_"+treatNameManualString+"_Map";
        if (runMode == 1) wholeMapPath = savePath+"/"+extension+"_"+analysisNameManualString+"_"+treatNameManualString+"_Map";
        
        int totalPix = imageWidth*imageWidth*4;
        
        char *dataHold = new char [totalPix];
        indexCount = 0;
        
        int entryCount = 0;
        int dataTemp2 = 0;
        int readBit2 [4];
        
        for (int counter1 = 0; counter1 < imageWidth; counter1++){
            for (int counter2 = 0; counter2 < imageWidth; counter2++){
                dataTemp = mapData [counter1][counter2];
                
                if (counter2 == 0) dataTemp2 = dataTemp, entryCount++;
                else if (dataTemp != dataTemp2 || entryCount == 254 || counter2 == imageWidth-1){
                    readBit2 [0] = dataTemp2/65536;
                    dataTemp2 = dataTemp2%65536;
                    readBit2 [1] = dataTemp2/256;
                    dataTemp2 = dataTemp2%256;
                    readBit2 [2] = dataTemp2;
                    
                    if (counter2 == imageWidth-1){
                        if (dataTemp != dataTemp2){
                            dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                            dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                            dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                            dataHold [indexCount] = (char)entryCount, indexCount++;
                            
                            readBit2 [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit2 [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit2 [2] = dataTemp;
                            
                            entryCount = 1;
                            
                            dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                            dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                            dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                            dataHold [indexCount] = (char)entryCount, indexCount++;
                        }
                        else{
                            
                            entryCount++;
                            
                            dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                            dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                            dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                            dataHold [indexCount] = (char)entryCount, indexCount++;
                        }
                    }
                    else{
                        
                        dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                        dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                        dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                        dataHold [indexCount] = (char)entryCount, indexCount++;
                    }
                    
                    if (counter2 == imageWidth-1) entryCount = 0;
                    else{
                        
                        entryCount = 1;
                        dataTemp2 = dataTemp;
                    }
                }
                else entryCount++;
            }
        }
        
        ofstream outfile1 (wholeMapPath.c_str(), ofstream::binary);
        outfile1.write(dataHold, indexCount);
        outfile1.close();
        
        delete [] dataHold;
        
        if (runMode == 3) wholeMapPath = savePath+"/"+extension+"_"+bodyName+"_"+treatNameManualString+"_Image";
        if (runMode == 1) wholeMapPath = savePath+"/"+extension+"_"+analysisNameManualString+"_"+treatNameManualString+"_Image";
        
        //for (int counterA = 0; counterA < 400; counterA++){
        //	for (int counterB = 0; counterB < 400; counterB++) cout<<" "<<arrayImageConnectivityA [counterA][counterB];
        //	cout<<" arrayImageConnectivityA "<<counterA<<endl;
        //}
        
        dataHold = new char [totalPix];
        indexCount = 0;
        
        entryCount = 0;
        dataTemp2 = 0;
        
        for (int counter1 = 0; counter1 < imageWidth; counter1++){
            for (int counter2 = 0; counter2 < imageWidth; counter2++){
                dataTemp = arrayExtractedImage [counter1][counter2];
                
                if (counter2 == 0) dataTemp2 = dataTemp, entryCount++;
                else if (dataTemp != dataTemp2 || entryCount == 254 || counter2 == imageWidth-1){
                    readBit2 [0] = dataTemp2/65536;
                    dataTemp2 = dataTemp2%65536;
                    readBit2 [1] = dataTemp2/256;
                    dataTemp2 = dataTemp2%256;
                    readBit2 [2] = dataTemp2;
                    
                    if (counter2 == imageWidth-1){
                        if (dataTemp != dataTemp2){
                            dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                            dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                            dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                            dataHold [indexCount] = (char)entryCount, indexCount++;
                            
                            readBit2 [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit2 [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit2 [2] = dataTemp;
                            
                            entryCount = 1;
                            
                            dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                            dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                            dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                            dataHold [indexCount] = (char)entryCount, indexCount++;
                        }
                        else{
                            
                            entryCount++;
                            
                            dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                            dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                            dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                            dataHold [indexCount] = (char)entryCount, indexCount++;
                        }
                    }
                    else{
                        
                        dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                        dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                        dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                        dataHold [indexCount] = (char)entryCount, indexCount++;
                    }
                    
                    if (counter2 == imageWidth-1) entryCount = 0;
                    else{
                        
                        entryCount = 1;
                        dataTemp2 = dataTemp;
                    }
                }
                else entryCount++;
            }
        }
        
        ofstream outfile2 (wholeMapPath.c_str(), ofstream::binary);
        outfile2.write(dataHold, indexCount);
        outfile2.close();
        
        delete [] dataHold;
        
        for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
            delete [] arrayImage150 [counter1];
            delete [] arrayImageRemaining [counter1];
            delete [] arrayImageConnect200 [counter1];
            delete [] arrayImageConnect220 [counter1];
            delete [] arrayImageConnect240 [counter1];
            delete [] arrayImageConnectivity [counter1];
            delete [] arrayImageConnectivityA [counter1];
            delete [] arrayImageConnectivityB [counter1];
            delete [] arrayImageConnectivityC [counter1];
            delete [] arrayImageConnectivityD [counter1];
            delete [] mapData [counter1];
        }
        
        delete [] arrayImage150;
        delete [] arrayImageRemaining;
        delete [] arrayImageConnect200;
        delete [] arrayImageConnect220;
        delete [] arrayImageConnect240;
        delete [] arrayImageConnectivity;
        delete [] arrayImageConnectivityA;
        delete [] arrayImageConnectivityB;
        delete [] arrayImageConnectivityC;
        delete [] arrayImageConnectivityD;
        delete [] mapData;
        
        progressTiming = 5;
        
        if (processSequenceFlag == 9) processSequenceFlag = 10;
        else if (processSequenceFlag == 22) processSequenceFlag = 24;
        else if (reprocessImageNo == 9) reprocessImageNo = 10;
    });
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToImageProcessing object:nil];
}

@end
