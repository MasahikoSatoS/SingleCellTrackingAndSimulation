//
// GapChase2.h
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 20/12/12.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#ifndef GAPCHASE2_H
#define GAPCHASE2_H
#import "Controller.h"
#endif

@interface GapChase2 : NSObject {
    int numberOfFill; //No of fill
    int fillLimit; //Fill limit
    int fillAddition; //Fill addition
    
    int *arrayGapDataTemp; //Gap fill array
    
    id gapFill;
}

-(int)gapChaseing2:(int)originX :(int)originY :(int)destinationX :(int)destinationY :(int)lineSet;
-(void)gapFillUpdate;

@end
