//
// GapChase3.h
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 21/12/12.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#ifndef GAPCHASE3_H
#define GAPCHASE3_H
#import "Controller.h"
#endif

@interface GapChase3 : NSObject {
    int numberOfFill; //No of fill
    int fillLimit; //Fill limit
    int fillAddition; //Fill addition
    
    int *arrayGapDataTemp; //Gap fill array
    
    id gapFill;
}

-(int)gapChaseing3:(int)originX :(int)originY :(int)destinationX :(int)destinationY :(int)lineSet :(int)maxPointDimX :(int)maxPointDimY :(int)minPointDimX :(int)minPointDimY :(int)minValue;
-(void)gapFillUpdate;

@end
