//
// arrayModification.mm
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 03/12/12.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#import "ArrayModification.h"

@implementation ArrayModification

-(void)lineFlip:(int)lineSet{
    int blockNumber = 0;
    int findFlag = 0;
    int startDataX = 0;
    int endDataX = 0;
    int startDataY = 0;
    int endDataY = 0;
    int startCount = -1;
    int endCount = -1;
    int enterFlag = 0;
    
    if (lineSet == 1){
        int *arrayTransitionTemp = new int [lineFiveCount*2+50];
        int arrayTransitionTempCount = 0;
        
        for (int counter1 = 0; counter1 < lineFiveCount/6; counter1++){ //------Set Start End Mark------
            if (blockNumber != arrayLineFive [counter1*6+3] && findFlag == 0){
                blockNumber = arrayLineFive [counter1*6+3];
                arrayLineFive [counter1*6+5] = 1;
                findFlag = 1;
            }
            else if (blockNumber != arrayLineFive [counter1*6+3] && findFlag == 1){
                blockNumber = arrayLineFive [counter1*6+3];
                arrayLineFive [counter1*6+5] = 1;
                arrayLineFive [(counter1-1)*6+5] = 2;
            }
            else arrayLineFive [counter1*6+5] = 0;
        }
        
        int lineFiveTemp = (lineFiveCount/6-1)*6+5;
        arrayLineFive [lineFiveTemp] = 2;
        
        for (int counter1 = 0; counter1 < lineFiveCount/6; counter1++){
            if (arrayLineFive [counter1*6+5] == 1 && enterFlag == 0){
                startCount = counter1;
                startDataX = arrayLineFive [counter1*6];
                startDataY = arrayLineFive [counter1*6+1];
                enterFlag = 1;
            }
            else if (arrayLineFive [counter1*6+5] == 2 && enterFlag == 1){
                endCount = counter1;
                endDataX = arrayLineFive [counter1*6];
                endDataY = arrayLineFive [counter1*6+1];
                enterFlag = 0;
                
                if (arrayLineFive [counter1*6+4] == 0 && ((abs(startDataY-endDataY) > abs(startDataX-endDataX) && startDataY < endDataY) || (abs(startDataY-endDataY) < abs(startDataX-endDataX) && startDataX > endDataX))){
                    for (int counter2 = endCount; counter2 >= startCount; counter2 = counter2-1){
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineFive [counter2*6], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineFive [counter2*6+1], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineFive [counter2*6+2], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineFive [counter2*6+3], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineFive [counter2*6+4], arrayTransitionTempCount++;
                        
                        if (counter2 == endCount) arrayTransitionTemp [arrayTransitionTempCount] = 1, arrayTransitionTempCount++; //------Start end------5
                        else if (counter2 == startCount) arrayTransitionTemp [arrayTransitionTempCount] = 2, arrayTransitionTempCount++; //------Start end------5
                        else arrayTransitionTemp [arrayTransitionTempCount] = 0, arrayTransitionTempCount++; //------Start end------5
                    }
                }
                else{
                    
                    for (int counter2 = startCount; counter2 <= endCount; counter2++){
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineFive [counter2*6], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineFive [counter2*6+1], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineFive [counter2*6+2], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineFive [counter2*6+3], arrayTransitionTempCount++; //------Block------3
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineFive [counter2*6+4], arrayTransitionTempCount++; //------For combined line mark------4
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineFive [counter2*6+5], arrayTransitionTempCount++;
                    }
                }
            }
        }
        
        lineFiveCount = 0;
        for (int counter1 = 0; counter1 < arrayTransitionTempCount; counter1++) arrayLineFive [counter1] = arrayTransitionTemp [counter1], lineFiveCount++;
        
        delete [] arrayTransitionTemp;
    }
    
    if (lineSet == 3){
        int *arrayTransitionTemp = new int [lineSevenCount*2+50];
        int arrayTransitionTempCount = 0;
        
        for (int counter1 = 0; counter1 < lineSevenCount/6; counter1++){ //------Set Start End Mark------
            if (blockNumber != arrayLineSeven [counter1*6+3] && findFlag == 0){
                blockNumber = arrayLineSeven [counter1*6+3];
                arrayLineSeven [counter1*6+5] = 1;
                findFlag = 1;
            }
            else if (blockNumber != arrayLineSeven [counter1*6+3] && findFlag == 1){
                blockNumber = arrayLineSeven [counter1*6+3];
                arrayLineSeven [counter1*6+5] = 1;
                arrayLineSeven [(counter1-1)*6+5] = 2;
            }
            else arrayLineSeven [counter1*6+5] = 0;
        }
        
        int lineSevenTemp = (lineSevenCount/6-1)*6+5;
        arrayLineSeven [lineSevenTemp] = 2;
        
        for (int counter1 = 0; counter1 < lineSevenCount/6; counter1++){
            if (arrayLineSeven [counter1*6+5] == 1 && enterFlag == 0){
                startCount = counter1;
                startDataX = arrayLineSeven [counter1*6];
                startDataY = arrayLineSeven [counter1*6+1];
                enterFlag = 1;
            }
            else if (arrayLineSeven [counter1*6+5] == 2 && enterFlag == 1){
                endCount = counter1;
                endDataX = arrayLineSeven [counter1*6];
                endDataY = arrayLineSeven [counter1*6+1];
                enterFlag = 0;
                
                if (arrayLineSeven [counter1*6+4] == 0 && ((abs(startDataY-endDataY) > abs(startDataX-endDataX) && startDataY > endDataY) || (abs(startDataY-endDataY) < abs(startDataX-endDataX) && startDataX < endDataX))){
                    for (int counter2 = endCount; counter2 >= startCount; counter2 = counter2-1){
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineSeven [counter2*6], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineSeven [counter2*6+1], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineSeven [counter2*6+2], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineSeven [counter2*6+3], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineSeven [counter2*6+4], arrayTransitionTempCount++;
                        
                        if (counter2 == endCount) arrayTransitionTemp [arrayTransitionTempCount] = 1, arrayTransitionTempCount++; //------Start end------5
                        else if (counter2 == startCount) arrayTransitionTemp [arrayTransitionTempCount] = 2, arrayTransitionTempCount++; //------Start end------5
                        else arrayTransitionTemp [arrayTransitionTempCount] = 0, arrayTransitionTempCount++; //------Start end------5
                    }
                }
                else{
                    
                    for (int counter2 = startCount; counter2 <= endCount; counter2++){
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineSeven [counter2*6], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineSeven [counter2*6+1], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineSeven [counter2*6+2], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineSeven [counter2*6+3], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineSeven [counter2*6+4], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineSeven [counter2*6+5], arrayTransitionTempCount++;
                    }
                }
            }
        }
        
        lineSevenCount = 0;
        for (int counter1 = 0; counter1 < arrayTransitionTempCount; counter1++) arrayLineSeven [counter1] = arrayTransitionTemp [counter1], lineSevenCount++;
        
        delete [] arrayTransitionTemp;
    }
}

-(void)lineLengthTwoRemove:(int)lineSet{
    int startCount = -1;
    int latestBlockNumberTemp = 0;
    
    if (lineSet == 1){
        int *arrayTransitionTemp = new int [lineFiveCount*2+50];
        int arrayTransitionTempCount = 0;
        int enterFlag = 0;
        
        for (int counter1 = 0; counter1 < lineFiveCount/6; counter1++){
            if (arrayLineFive [counter1*6+5] == 1 && enterFlag == 0){
                startCount = counter1;
                enterFlag = 1;
            }
            else if (arrayLineFive [counter1*6+5] == 2 && enterFlag == 1){
                enterFlag = 0;
                
                if (startCount+1 != counter1){
                    latestBlockNumberTemp++;
                    
                    for (int counter2 = startCount; counter2 <= counter1; counter2++){
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineFive [counter2*6], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineFive [counter2*6+1], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineFive [counter2*6+2], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = latestBlockNumberTemp, arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineFive [counter2*6+4], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineFive [counter2*6+5], arrayTransitionTempCount++;
                    }
                }
            }
        }
        
        lineFiveCount = 0;
        for (int counter1 = 0; counter1 < arrayTransitionTempCount; counter1++) arrayLineFive [counter1] = arrayTransitionTemp [counter1], lineFiveCount++;
        
        delete [] arrayTransitionTemp;
    }
    
    if (lineSet == 3){
        int *arrayTransitionTemp = new int [lineSevenCount*2+50];
        int arrayTransitionTempCount = 0;
        int enterFlag = 0;
        
        for (int counter1 = 0; counter1 < lineSevenCount/6; counter1++){
            if (arrayLineSeven [counter1*6+5] == 1 && enterFlag == 0){
                startCount = counter1;
                enterFlag = 1;
            }
            else if (arrayLineSeven [counter1*6+5] == 2 && enterFlag == 1){
                enterFlag = 0;
                
                if (startCount+1 != counter1){
                    latestBlockNumberTemp++;
                    
                    for (int counter2 = startCount; counter2 <= counter1; counter2++){
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineSeven [counter2*6], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineSeven [counter2*6+1], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineSeven [counter2*6+2], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = latestBlockNumberTemp, arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineSeven [counter2*6+4], arrayTransitionTempCount++;
                        arrayTransitionTemp [arrayTransitionTempCount] = arrayLineSeven [counter2*6+5], arrayTransitionTempCount++;
                    }
                }
            }
        }
        
        lineSevenCount = 0;
        for (int counter1 = 0; counter1 < arrayTransitionTempCount; counter1++) arrayLineSeven [counter1] = arrayTransitionTemp [counter1], lineSevenCount++;
        
        delete [] arrayTransitionTemp;
    }
}

@end
