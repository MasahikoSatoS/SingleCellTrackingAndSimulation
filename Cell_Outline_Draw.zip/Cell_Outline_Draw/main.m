//
// main.m
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 13/11/27.
// Copyright Masahiko Sato 2013. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[]){
    return NSApplicationMain(argc, (const char **) argv);
}
