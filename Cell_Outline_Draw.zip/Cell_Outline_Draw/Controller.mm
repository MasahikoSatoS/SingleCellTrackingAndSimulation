//
// Controller.mm
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 25/11/13.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#import "Controller.h"

//------Controller------
int autoRunStatus;
int displayImageNumber;
int jumpSet;
int imageFirstLoadFlag;
int imageWidth;
int imageHeight;
int toControllerDisplay1;
int runMode;
int processSequenceFlag;
int imageNameFileListCount;
int displayMode;
int areaLimit;
int cutOffLevel;
int cutOffLevel2;
int cutOffLevel3;
int cutOffLevel4;
int areaLimitCurrent;
int cutOffLevelCurrent;
int cutOffLevelCurrent2;
int cutOffLevelCurrent3;
int cutOffLevelCurrent4;
int imageFirstLoadFlagDisplay;
int imageFirstLoadFlagCell;
int processOption;
string pathNameString;
string analysisNameManualString;
string treatNameManualString;
string bodyName;
string imageFolderPath;
string treatmentOptionNameHold;
string *arrayWholeImage;
int wholeImageCount;
int wholeImageLimit;
string *arrayDirectoryInfo;
int directoryInfoCount;
int directoryInfoLimit;
int allRunFlag;
int processingFromHold;
int processingToHold;
int reprocessImageNo;
int reprocessStatus;
int progressValue;
int progressTiming;
string *treatmentSelectList;
int treatmentSelectListStatus;
int treatmentSelectListCount;

//------Line Chase Arrays------
int *arrayLineOne;
int lineOneCount;
int *arrayLineThree;
int lineThreeCount;
int *arrayLineFive;
int lineFiveCount;
int *arrayLineSeven;
int lineSevenCount;
int *arrayGapChase;
int gapChaseCount;
int gapChaseLimit;
int *arrayGapData;
int gapDataCount;
int gapDataLimit;
int *arrayMapData;
int mapDataCount;
int mapDataLimit;
int *arrayReturnData;
int returnDataCount;
int returnDataLimit;
int *arrayEdgeTrace;
int edgeTraceCount;
int edgeTraceLimit;
int *arrayEdgeTraceStartEnd;
int edgeTraceStartEndCount;
int edgeTraceStartEndLimit;
int *arrayLinkedLine;
int linkedLineCount;
int linkedLineLimit;
int *arrayOutlineExist;
int outlineExistCount;
int outlineExistLimit;
int *arrayOutlineExistAss;
int outlineExistAssCount;
int outlineExistAssLimit;
int *arrayOutlineAddition;
int outlineAdditionCount;
int outlineAdditionLimit;
int *arrayOutlineVectorSegment;
int outlineVectorSegmentCount;
int outlineVectorSegmentLimit;
int *arrayVectorSegmentation;
int vectorSegmentationCount;
int vectorSegmentationLimit;
double *arrayVectorSegmentationLength;
int vectorSegmentationLengthCount;
int vectorSegmentationLengthLimit;
int *arrayForNextConnectivity;
int forNextConnectivityCount;
int forNextConnectivityLimit;
int *arrayForNextConnectivityAss;
int forNextConnectivityAssCount;
int forNextConnectivityAssLimit;
int *arrayAnalysisResult1;
int analysisResultCount1;
int analysisResultStatus1;
int *arrayAnalysisResult2;
int analysisResultCount2;
int analysisResultStatus2;
int *arrayAnalysisResult3;
int analysisResultCount3;
int analysisResultStatus3;
int *arrayLinkedLineUpdate;
int linkedLineUpdateCount;
int linkedLineUpdateLimit;
int *arrayLinkedLineUpdateAss;
int linkedLineUpdateAssCount;
int linkedLineUpdateAssLimit;

//------Line Chase Variables------
int linkedLineMainCount;

//------Display Arrays------
int *arrayLineDataForDisplay6;
int lineDataForDisplayCount6;
int lineDataForDisplayStatus6;
int *arrayLineDataForDisplay7;
int lineDataForDisplayCount7;
int lineDataForDisplayStatus7;
int *arrayLineDataForDisplay8;
int lineDataForDisplayCount8;
int lineDataForDisplayStatus8;
int *arrayLineDataForDisplay9;
int lineDataForDisplayCount9;
int lineDataForDisplayStatus9;
int **imageForDisplay1;
int **imageForDisplay2;
int **imageForDisplay3;
int **imageForDisplay4;
int imageForDisplayStatus;

//------Image Processing Arrays: Image related------
int **arrayExtractedImage;
int extractImageStatus;
int **arrayImage150;
int **arrayImageRemaining;
int **arrayImageConnect200;
int **arrayImageConnect220;
int **arrayImageConnect240;
int **arrayImageConnectivity;
int **arrayImageConnectivityA;
int **arrayImageConnectivityB;
int **arrayImageConnectivityC;
int **arrayImageConnectivityD;
int **mapData;

//------Image Processing Arrays: Outline data related------
int *arrayOutlineVectorSource0;
int outlineVectorSourceCount0;
int outlineVectorSourceLimit0;
int *arrayOutlineVectorSource1;
int outlineVectorSourceCount1;
int outlineVectorSourceLimit1;
int *arrayOutlineVectorSource2;
int outlineVectorSourceCount2;
int outlineVectorSourceLimit2;
int *arrayOutlineVectorSource3;
int outlineVectorSourceCount3;
int outlineVectorSourceLimit3;
int *arrayOutlineVectorSource4;
int outlineVectorSourceCount4;
int outlineVectorSourceLimit4;
int *arrayXYPositionCenter;
int xyPositionCenterCount;

//------Image source------
int magnificationDisplay;
double windowWidthDisplay;
double windowHeightDisplay;
int sourceDisplayCheck;

//------Image Cell------
int magnificationCell;
double windowWidthCell;
double windowHeightCell;
int cellImageDisplayCheck;

//------Threshold list------
int initialArraySet;
int *thresholdDataHold;
int thresholdDataHoldCount;
int thresholdDataHoldLimit;

uint8_t *fileReadArray;

@implementation Controller

-(id)init{
    self = [super init];
    
    if (self != nil){
        [self userPathSet];
        
        autoRunStatus = 0;
        imageFirstLoadFlag = 0;
        toControllerDisplay1 = 0;
        runMode = 0;
        displayMode = 0;
        areaLimit = 5;
        cutOffLevel = 220;
        cutOffLevel2 = 180;
        cutOffLevel3 = 140;
        cutOffLevel4 = 120;
        areaLimitCurrent = 5;
        cutOffLevelCurrent = 220;
        cutOffLevelCurrent2 = 180;
        cutOffLevelCurrent3 = 140;
        cutOffLevelCurrent4 = 120;
        imageFirstLoadFlagDisplay = 0;
        imageFirstLoadFlagCell = 0;
        treatmentOptionNameHold = "nil";
        bodyName = "nil";
        allRunFlag = 0;
        processingFromHold = 0;
        processingToHold = 0;
        reprocessStatus = 0;
        progressValue = 0;
        progressTiming = 0;
        treatmentSelectListStatus = 0;
        
        lineDataForDisplayStatus6 = 0;
        lineDataForDisplayStatus7 = 0;
        lineDataForDisplayStatus8 = 0;
        lineDataForDisplayStatus9 = 0;
        imageForDisplayStatus = 0;
        
        extractImageStatus = 0;
        
        startProcessPermission = 0;
        remainingImages = 0;
        autoModeOffControl = 0;
        
        magnificationDisplay = 10;
        magnificationCell = 10;
        
        initialArraySet = 0;
    }
    
    return self;
}

-(void)userPathSet{
    NSString *CurrentDirectoryPathNSString = [[NSBundle mainBundle] bundlePath];
    string userPathNameString = [CurrentDirectoryPathNSString cStringUsingEncoding:NSUTF8StringEncoding];
    
    if (userPathNameString.length() == 0) exit (0);
    else if ((int)userPathNameString.find("/Users/") == -1) exit (0);
    else{
        
        string pathName2 = userPathNameString.substr((unsigned long)userPathNameString.find("/Users/")+7);
        pathNameString = pathName2.substr(0, (unsigned long)pathName2.find("/"));
    }
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [controllerWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    CGFloat displayX = 80;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [controllerWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [reprocessFromDisplay setDelegate:self];
    [reprocessToDisplay setDelegate:self];
    [listBrowser setTarget:self];
    [listBrowser setDoubleAction:@selector(browserDoubleClick:)];
}

-(void)applicationDidFinishLaunching:(NSNotification*)notification{
    string getString;
    
    imageFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images";
    string cellOutlineSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CellOutlineDrawSetting";
    string thDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CellOutlineTHData";
    
    //------Saved condition read------
    ifstream fin;
    fin.open(cellOutlineSettingPath.c_str(), ios::in);
    
    if (fin.is_open()){
        getline(fin, getString);
        
        if (getString == "nil") analysisNameManualString = "";
        else analysisNameManualString = getString;
        
        getline(fin, getString);
        
        if (getString == "nil") treatNameManualString = "";
        else treatNameManualString = getString;
        
        getline(fin, getString);
        
        if (getString == "nil") cutOffLevel = 190;
        else cutOffLevel = atoi(getString.c_str());
        
        getline(fin, getString);
        
        if (getString == "nil") cutOffLevel2 = 150;
        else cutOffLevel2 = atoi(getString.c_str());
        
        getline(fin, getString);
        
        if (getString == "nil") cutOffLevel3 = 110;
        else cutOffLevel3 = atoi(getString.c_str());
        
        getline(fin, getString);
        
        if (getString == "nil") cutOffLevel4 = 90;
        else cutOffLevel4 = atoi(getString.c_str());
        
        getline(fin, getString);
        
        if (getString == "nil") areaLimit = 20;
        else areaLimit = atoi(getString.c_str());
        
        getline(fin, getString);
        
        if (getString == "1") processOption = 1;
        else processOption = 0;
        
        fin.close();
    }
    else{
        
        analysisNameManualString = "";
        treatNameManualString = "";
        cutOffLevel = 190;
        cutOffLevel2 = 150;
        cutOffLevel3 = 110;
        cutOffLevel4 = 90;
        areaLimit = 20;
        processOption = 0;
    }
    
    if (analysisNameManualString != "") [analysisNameManual setStringValue:@(analysisNameManualString.c_str())];
    else [analysisNameManual setStringValue:@"nil"];
    
    if (treatNameManualString != "") [treatNameManual setStringValue:@(treatNameManualString.c_str())];
    else [treatNameManual setStringValue:@"nil"];
    
    [cutOffDisplay setIntegerValue:cutOffLevel];
    [cutOffDisplay2 setIntegerValue:cutOffLevel2];
    [cutOffDisplay3 setIntegerValue:cutOffLevel3];
    [cutOffDisplay4 setIntegerValue:cutOffLevel4];
    [areaLimitDisplay setIntegerValue:areaLimit];
    
    if (processOption == 0) [optionDisplay setStringValue:@"Time"];
    else if (processOption == 1) [optionDisplay setStringValue:@"Treatment"];
    
    [inputField setStringValue:@""];
    [analysisNameAuto setStringValue:@"nil"];
    [treatNameAuto setStringValue:@"nil"];
    [imageLoadResult setStringValue:@"nil"];
    [imageSize setStringValue:@"nil"];
    [timePointNumber setStringValue:@"nil"];
    [jumpDisplay setStringValue:@"nil"];
    [runOnOFF setStringValue:@"Off"];
    [processingStatusDisplay setStringValue:@"nil"];
    [allRunStatus setStringValue:@"Off"];
    [displayThreshold setStringValue:@"TH 90"];
    [autoRunStatusDisplay setStringValue:@"Off"];
    
    int enterCount = 0;
    int terminationFlag = 0;
    
    fin.open(thDataPath.c_str(), ios::in);
    
    if (fin.is_open()){
        do{
            
            terminationFlag = 1;
            
            getline(fin, getString);
            
            if (getString == "") terminationFlag = 0;
            else enterCount++;
            
        } while (terminationFlag == 1);
        
        fin.close();
    }
    
    if (enterCount != 0){
        thresholdDataHold = new int [enterCount+60];
        thresholdDataHoldCount = 0;
        thresholdDataHoldLimit = enterCount+60;
        
        fin.open(thDataPath.c_str(), ios::in);
        
        if (fin.is_open()){
            do{
                
                terminationFlag = 1;
                
                getline(fin, getString);
                
                if (getString == "") terminationFlag = 0;
                else thresholdDataHold [thresholdDataHoldCount] = atoi(getString.c_str()), thresholdDataHoldCount++;
                
            } while (terminationFlag == 1);
            
            fin.close();
        }
    }
    else{
        
        thresholdDataHold = new int [60];
        thresholdDataHoldCount = 0;
        thresholdDataHoldLimit = 60;
    }
    
    //for (int counterA = 0; counterA < thresholdDataHoldCount/6; counterA++){
    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<thresholdDataHold [counterA*6+counterB];
    //    cout<<" thresholdDataHold "<<counterA<<endl;
    //}
    
    initialArraySet = 1;
    
    [reprocessFromDisplay setIntegerValue:0];
    [reprocessToDisplay setIntegerValue:0];
    
    arrayWholeImage = new string [500];
    wholeImageCount = 0;
    wholeImageLimit = 500; //------Lineage Start/end point------
    arrayDirectoryInfo = new string [500];
    directoryInfoCount = 0;
    directoryInfoLimit = 500;
    
    runMode = 0;
    
    [listBrowser reloadColumn:0];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCommunication object:self];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToThresholdTable object:self];
    controllerTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(processControl) userInfo:nil repeats:YES];
}

-(void)processControl{
    //------For Display------
    if (toControllerDisplay1 == 1){
        toControllerDisplay1 = 0;
        [timePointNumber setIntegerValue:displayImageNumber];
    }
    
    //------Auto run mode------
    if (runMode == 3 && processSequenceFlag == 0){
        processSequenceFlag = 150;
        [self processImageFiles];
    }
    else if (runMode == 3 && processSequenceFlag == 150){
        processSequenceFlag = 2;
        [self autoProcessing];
    }
    else if (runMode == 3 && processSequenceFlag == 3) processSequenceFlag = 4;
    else if (runMode == 3 && processSequenceFlag < 7 && processSequenceFlag >= 4){
        processSequenceFlag++;
        
        if (processSequenceFlag == 7) processSequenceFlag = 8;
    }
    else if (runMode == 3 && processSequenceFlag == 8){
        processSequenceFlag = 9;
        [self processStartSub];
    }
    else if (runMode == 3 && processSequenceFlag == 10){
        cellImageDisplayCheck = 0;
        sourceDisplayCheck = 0;
        processSequenceFlag = 50;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSourceImage object:self];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCellImage object:self];
        
        processSequenceFlag = 11;
    }
    else if (runMode == 3 && processSequenceFlag == 11){
        if (cellImageDisplayCheck >= 1 && sourceDisplayCheck >= 1) processSequenceFlag = 12;
    }
    else if (runMode == 3 && processSequenceFlag == 12){
        processSequenceFlag = 13;
        
        [analysisNameDisplay setStringValue:@(bodyName.c_str())];
        [treatNameDisplay setStringValue:@(treatNameManualString.c_str())];
        [timePointNumber setIntegerValue:displayImageNumber];
        
        string loadingImagePath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Processed";
        string entry;
        string extractString;
        string outlineRangeString;
        
        DIR *dir = opendir(loadingImagePath.c_str());
        struct dirent *dent;
        
        if (dir != NULL){
            int findString1 = 0;
            int imageNumber = 0;
            
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                findString1 = (int)entry.length();
                
                if (findString1 > 4){
                    extractString = entry.substr(0, 4);
                    
                    if (atoi(extractString.c_str()) > imageNumber) imageNumber = atoi(extractString.c_str());
                }
            }
            
            closedir(dir);
            
            string extension = to_string(imageNumber);
            outlineRangeString = "1-"+extension;
        }
        else outlineRangeString = "0";
        
        [outlineRange setStringValue:@(outlineRangeString.c_str())];
    }
    else if (runMode == 3 && processSequenceFlag < 17 && processSequenceFlag >= 13){
        processSequenceFlag++;
        
        if (processSequenceFlag == 17) processSequenceFlag = 18;
    }
    else if (runMode == 3 && processSequenceFlag == 18){
        if (autoModeOffControl == 1){
            wholeImageCount = 0;
            processSequenceFlag = 0;
            runMode = 1;
            [autoRunStatusDisplay setStringValue:@"Off"];
        }
        else processSequenceFlag = 150;
    }
    
    //------Manual run mode: All run------
    if (runMode == 1 && allRunFlag == 1 && processSequenceFlag == 0){
        processSequenceFlag = 150;
        [self processImageFiles];
    }
    else if (runMode == 1 && allRunFlag == 1 && processSequenceFlag == 150){
        processSequenceFlag = 2;
        [self autoProcessing];
    }
    else if (runMode == 1 && allRunFlag == 1 && processSequenceFlag == 3) processSequenceFlag = 4;
    else if (runMode == 1 && allRunFlag == 1 && processSequenceFlag < 7 && processSequenceFlag >= 4){
        processSequenceFlag++;
        
        if (processSequenceFlag == 7) processSequenceFlag = 8;
    }
    else if (runMode == 1 && allRunFlag == 1 && processSequenceFlag == 8){
        processSequenceFlag = 9;
        
        [self processStartSub];
    }
    else if (runMode == 1 && processSequenceFlag == 10){
        cellImageDisplayCheck = 0;
        sourceDisplayCheck = 0;
        processSequenceFlag = 50;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSourceImage object:self];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCellImage object:self];
        
        processSequenceFlag = 11;
    }
    else if (runMode == 1 && processSequenceFlag == 11){
        if (cellImageDisplayCheck >= 1 && sourceDisplayCheck >= 1) processSequenceFlag = 12;
    }
    else if (runMode == 1 && processSequenceFlag == 12){
        processSequenceFlag = 13;
        
        [analysisNameDisplay setStringValue:@(analysisNameManualString.c_str())];
        [treatNameDisplay setStringValue:@(treatNameManualString.c_str())];
        [timePointNumber setIntegerValue:displayImageNumber];
        
        string loadingImagePath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Processed";
        string entry;
        string extractString;
        string outlineRangeString;
        
        DIR *dir = opendir(loadingImagePath.c_str());
        struct dirent *dent;
        
        if (dir != NULL){
            int findString1 = 0;
            int imageNumber = 0;
            
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                findString1 = (int)entry.length();
                
                if (findString1 > 4){
                    extractString = entry.substr(0, 4);
                    
                    if (atoi(extractString.c_str()) > imageNumber) imageNumber = atoi(extractString.c_str());
                }
            }
            
            closedir(dir);
            
            string extension = to_string(imageNumber);
            outlineRangeString = "1-"+extension;
        }
        else outlineRangeString = "0";
        
        [outlineRange setStringValue:@(outlineRangeString.c_str())];
    }
    else if (runMode == 1 && processSequenceFlag < 17 && processSequenceFlag >= 13){
        processSequenceFlag++;
        
        if (processSequenceFlag == 17) processSequenceFlag = 18;
    }
    else if (runMode == 1 && processSequenceFlag == 18){
        if (allRunFlag == 2){
            [allRunStatus setStringValue:@"Off"];
            wholeImageCount = 0;
            processSequenceFlag = 0;
            allRunFlag = 0;
        }
        else processSequenceFlag = 150;
    }
    else if (allRunFlag == 2 && processSequenceFlag != 0){
        [allRunStatus setStringValue:@"Off"];
        wholeImageCount = 0;
        processSequenceFlag = 0;
        allRunFlag = 0;
    }
    
    //------Run one time point------
    if (processSequenceFlag == 20) processSequenceFlag = 21;
    else if (processSequenceFlag == 21){
        areaLimitCurrent = areaLimit;
        cutOffLevelCurrent = cutOffLevel;
        cutOffLevelCurrent2 = cutOffLevel2;
        cutOffLevelCurrent3 = cutOffLevel3;
        cutOffLevelCurrent4 = cutOffLevel4;
        
        processSequenceFlag = 22;
        [self processStartSub];
    }
    else if (processSequenceFlag == 24){
        processSequenceFlag = 0;
        [runOnOFF setStringValue:@"Off"];
        [analysisNameAuto setStringValue:@"nil"];
        [treatNameAuto setStringValue:@"nil"];
        [imageNoAuto setStringValue:@"nil"];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSourceImage object:self];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCellImage object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    
    //------Manual run mode: Re-do Process------
    if (runMode == 1 && reprocessImageNo == 1){
        reprocessImageNo = 2;
        [reprocessNoDisplay setStringValue:@"On"];
        [self autoProcessing];
    }
    else if (runMode == 1 && reprocessImageNo == 3){
        reprocessImageNo = 4;
    }
    else if (runMode == 1 && reprocessImageNo < 7 && reprocessImageNo >= 4){
        reprocessImageNo++;
        
        if (reprocessImageNo == 7) reprocessImageNo = 8;
    }
    else if (runMode == 1 && reprocessImageNo == 8){
        reprocessImageNo = 9;
        
        [self processStartSub];
    }
    else if (runMode == 1 && reprocessImageNo == 10){
        cellImageDisplayCheck = 0;
        sourceDisplayCheck = 0;
        processSequenceFlag = 50;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSourceImage object:self];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCellImage object:self];
        
        reprocessImageNo = 11;
    }
    else if (runMode == 1 && reprocessImageNo == 11){
        if (cellImageDisplayCheck >= 1 && sourceDisplayCheck >= 1) reprocessImageNo = 12;
    }
    else if (runMode == 1 && reprocessImageNo == 12){
        reprocessImageNo = 13;
        
        [analysisNameDisplay setStringValue:@(analysisNameManualString.c_str())];
        [treatNameDisplay setStringValue:@(treatNameManualString.c_str())];
        [timePointNumber setIntegerValue:displayImageNumber];
    }
    else if (runMode == 1 && reprocessImageNo < 17 && reprocessImageNo >= 13){
        reprocessImageNo++;
        
        if (reprocessImageNo == 17) reprocessImageNo = 18;
    }
    else if (runMode == 1 && reprocessImageNo == 18){
        if (reprocessStatus == 2){
            [reprocessNoDisplay setStringValue:@"nil"];
            wholeImageCount = 0;
            reprocessImageNo = 0;
            reprocessStatus = 0;
            processSequenceFlag = 0;
        }
        else reprocessImageNo = 1;
    }
    
    if (imageFirstLoadFlagDisplay == 1 && imageFirstLoadFlagCell == 1) imageFirstLoadFlag = 1;
    
    if (progressTiming == 1){
        [progressIndicator setMinValue:0];
        [progressIndicator setMaxValue:progressValue];
        [progressIndicator startAnimation:self];
        [progressIndicator setHidden:NO];
        
        double bValue = [progressIndicator maxValue];
        
        if (progressIndicator){
            if (bValue == progressValue){
                [progressIndicator setDoubleValue:5];
                [progressIndicator displayIfNeeded];
                
                double bValue2 = [progressIndicator doubleValue];
                
                if (bValue2 == 5) progressTiming = 2;
            }
        }
    }
    else if (progressTiming == 3){
        [progressIndicator setDoubleValue:progressValue];
        [progressIndicator displayIfNeeded];
        
        double bValue = [progressIndicator doubleValue];
        
        if (bValue == progressValue) progressTiming = 4;
    }
    else if (progressTiming == 5){
        [progressIndicator setDoubleValue:0];
        [progressIndicator displayIfNeeded];
        
        double bValue = [progressIndicator doubleValue];
        
        if (bValue == 0){
            [progressIndicator stopAnimation:self];
            
            if (!progressIndicator) progressTiming = 0;
        }
    }
}

-(void)autoProcessing{
    string wholeTreatmentName;
    string wholeImageNumber;
    int smallestImageNumber = 10000;
    int wholeProcessPosition = 0;
    
    if ((processOption == 0 && runMode == 1) || runMode == 3){
        for (int counter1 = 0; counter1 < wholeImageCount/2; counter1++){
            if (atoi(arrayWholeImage [counter1*2+1].c_str()) < smallestImageNumber && atoi(arrayWholeImage [counter1*2+1].c_str()) != 0){
                wholeTreatmentName = arrayWholeImage [counter1*2];
                wholeImageNumber = arrayWholeImage [counter1*2+1];
                wholeProcessPosition = counter1;
                smallestImageNumber = atoi(arrayWholeImage [counter1*2+1].c_str());
            }
        }
    }
    else if (processOption == 1 && runMode == 1){
        string imageFileNameTemp;
        int nameFindFlag = 0;
        
        if (treatmentOptionNameHold == "nil") treatmentOptionNameHold = treatNameManualString;
        
        for (int counter1 = 0; counter1 < wholeImageCount/2; counter1++){
            imageFileNameTemp = arrayWholeImage [counter1*2];
            
            if (imageFileNameTemp == treatmentOptionNameHold){
                nameFindFlag = 1;
                break;
            }
        }
        
        if (nameFindFlag == 0){
            for (int counter1 = 0; counter1 < wholeImageCount/2; counter1++){
                imageFileNameTemp = arrayWholeImage [counter1*2];
                
                if (imageFileNameTemp != "0"){
                    treatmentOptionNameHold = imageFileNameTemp;
                    nameFindFlag = 1;
                    break;
                }
            }
        }
        
        if (nameFindFlag == 1){
            for (int counter1 = 0; counter1 < wholeImageCount/2; counter1++){
                int numberTemp = atoi(arrayWholeImage [counter1*2+1].c_str());
                imageFileNameTemp = arrayWholeImage [counter1*2];
                
                if (numberTemp < smallestImageNumber && numberTemp != 0 && treatmentOptionNameHold == imageFileNameTemp){
                    wholeTreatmentName = arrayWholeImage [counter1*2];
                    wholeImageNumber = arrayWholeImage [counter1*2+1];
                    wholeProcessPosition = counter1;
                    smallestImageNumber = numberTemp;
                }
            }
        }
    }
    
    if (smallestImageNumber == 10000) treatmentOptionNameHold = "nil";
    
    if (smallestImageNumber != 10000){
        string loadingImagePath;
        int tifBmpType = 0;
        ifstream fin;
        
        arrayWholeImage [wholeProcessPosition*2+1] = "0";
        arrayWholeImage [wholeProcessPosition*2] = "0";
        
        remainingImages--;
        
        if (runMode == 3){
            loadingImagePath = imageFolderPath+"/"+bodyName+"_Image/"+wholeTreatmentName+"_Stitch/STimage "+wholeImageNumber+".tif";
            
            fin.open(loadingImagePath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                tifBmpType = 0;
                fin.close();
            }
            else{
                
                loadingImagePath = imageFolderPath+"/"+bodyName+"_Image/"+wholeTreatmentName+"_Stitch/STimage "+wholeImageNumber+".bmp";
                tifBmpType = 1;
            }
        }
        
        if (runMode == 1){
            loadingImagePath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+wholeTreatmentName+"_Stitch/STimage "+wholeImageNumber+".tif";
            
            fin.open(loadingImagePath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                tifBmpType = 0;
                fin.close();
            }
            else{
                
                loadingImagePath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+wholeTreatmentName+"_Stitch/STimage "+wholeImageNumber+".bmp";
                tifBmpType = 1;
            }
        }
        
        fin.open(loadingImagePath.c_str(), ios::in | ios::binary);
        
        if (fin.is_open()){
            fin.close();
            
            if (extractImageStatus == 1){
                for (int counter1 = 0; counter1 < imageWidth+1; counter1++) delete [] arrayExtractedImage [counter1];
                delete [] arrayExtractedImage;
                extractImageStatus = 0;
            }
            
            if (imageForDisplayStatus == 1){
                for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
                    delete [] imageForDisplay1 [counter1];
                    delete [] imageForDisplay2 [counter1];
                    delete [] imageForDisplay3 [counter1];
                    delete [] imageForDisplay4 [counter1];
                }
                
                delete [] imageForDisplay1;
                delete [] imageForDisplay2;
                delete [] imageForDisplay3;
                delete [] imageForDisplay4;
                
                imageForDisplayStatus = 0;
            }
            
            if (tifBmpType == 0){
                //------Tiff reading------
                unsigned long stripFirstAddress = 0;
                unsigned long stripByteCountAddress = 0;
                unsigned long nextAddress = 0;
                unsigned long headPosition = 0;
                unsigned long stripEntry = 0;
                long sizeForCopy = 0;
                
                double xPosition = 0;
                double yPosition = 0;
                
                int imageWidthTif = 0;
                int imageHeightTif = 0;
                int imageBit = 0; // check 8, 16
                int imageCompression = 0; // check 1
                int photoMetric = 0; //check 0, 1, 2
                int imageDimension = 0;
                int verticalBmp = 0;
                int horizontalBmp = 0;
                int endianType = 0;
                int samplePerPix = 0;
                int dataConversion [4];
                int processType = 1;
                int numberOfLayers = 0;
                
                struct stat sizeOfFile;
                
                if (stat(loadingImagePath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    fileReadArray = new uint8_t [sizeForCopy+4];
                    fin.open(loadingImagePath.c_str(), ios::in | ios::binary);
                    
                    fin.read((char*)fileReadArray, sizeForCopy+4);
                    fin.close();
                    
                    dataConversion [0] = fileReadArray [0];
                    dataConversion [1] = fileReadArray [1];
                    
                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                    else endianType = 0;
                    
                    int *arrayExtractedImage3 = new int [100];
                    
                    headPosition = 0;
                    
                    if (endianType == 1){
                        dataConversion [0] = fileReadArray [7];
                        dataConversion [1] = fileReadArray [6];
                        dataConversion [2] = fileReadArray [5];
                        dataConversion [3] = fileReadArray [4];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    else if (endianType == 0){
                        dataConversion [0] = fileReadArray [4];
                        dataConversion [1] = fileReadArray [5];
                        dataConversion [2] = fileReadArray [6];
                        dataConversion [3] = fileReadArray [7];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    
                    if (endianType == 1){
                        tiffFileRead = [[TiffFileRead alloc] init];
                        [tiffFileRead tiffReadLargeEndian: headPosition:&imageWidthTif:&imageHeightTif:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                        
                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                            if (imageWidthTif > imageHeightTif) imageDimension = imageWidthTif;
                            else imageDimension = imageHeightTif;
                            
                            tiffFileRead = [[TiffFileRead alloc] init];
                            delete [] arrayExtractedImage3;
                            
                            arrayExtractedImage3 = [tiffFileRead imageSetLargeEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                        }
                    }
                    else if (endianType == 0){
                        tiffFileRead = [[TiffFileRead alloc] init];
                        [tiffFileRead tiffReadSmallEndian: headPosition:&imageWidthTif:&imageHeightTif:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                        
                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                            if (imageWidth > imageHeightTif) imageDimension = imageWidthTif;
                            else imageDimension = imageHeightTif;
                            
                            tiffFileRead = [[TiffFileRead alloc] init];
                            delete [] arrayExtractedImage3;
                            
                            arrayExtractedImage3 = [tiffFileRead imageSetSmallEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                        }
                    }
                    
                    imageWidth = imageWidthTif;
                    imageHeight = imageHeightTif;
                    
                    int entryValueSet = 0;
                    
                    for (int counter1 = 0; counter1 < thresholdDataHoldCount/6; counter1++){
                        if (atoi(wholeImageNumber.c_str()) >= thresholdDataHold [counter1*6]){
                            areaLimitCurrent = thresholdDataHold [counter1*6+5];
                            cutOffLevelCurrent = thresholdDataHold [counter1*6+1];
                            cutOffLevelCurrent2 = thresholdDataHold [counter1*6+2];
                            cutOffLevelCurrent3 = thresholdDataHold [counter1*6+3];
                            cutOffLevelCurrent4 = thresholdDataHold [counter1*6+4];
                            entryValueSet = 1;
                        }
                    }
                    
                    if (entryValueSet == 0){
                        areaLimitCurrent = areaLimit;
                        cutOffLevelCurrent = cutOffLevel;
                        cutOffLevelCurrent2 = cutOffLevel2;
                        cutOffLevelCurrent3 = cutOffLevel3;
                        cutOffLevelCurrent4 = cutOffLevel4;
                    }
                    
                    if (extractImageStatus == 0) extractImageStatus = 1;
                    if (imageForDisplayStatus == 0) imageForDisplayStatus = 1;
                    
                    arrayExtractedImage = new int *[imageWidth+1];
                    imageForDisplay1 = new int *[imageWidth+1];
                    imageForDisplay2 = new int *[imageWidth+1];
                    imageForDisplay3 = new int *[imageWidth+1];
                    imageForDisplay4 = new int *[imageWidth+1];
                    
                    for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
                        arrayExtractedImage [counter1] = new int [imageWidth+1];
                        imageForDisplay1 [counter1] = new int [imageWidth+1];
                        imageForDisplay2 [counter1] = new int [imageWidth+1];
                        imageForDisplay3 [counter1] = new int [imageWidth+1];
                        imageForDisplay4 [counter1] = new int [imageWidth+1];
                    }
                    
                    horizontalBmp = 0;
                    verticalBmp = 0;
                    
                    for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                        if (horizontalBmp < imageWidth){
                            if (arrayExtractedImage3 [counter3] >= cutOffLevelCurrent && arrayExtractedImage3 [counter3] != 100) imageForDisplay1 [verticalBmp][horizontalBmp] = 220;
                            else imageForDisplay1 [verticalBmp][horizontalBmp] = 0;
                            
                            if (arrayExtractedImage3 [counter3] >= cutOffLevelCurrent2 && arrayExtractedImage3 [counter3] != 100) imageForDisplay2 [verticalBmp][horizontalBmp] = 220;
                            else imageForDisplay2 [verticalBmp][horizontalBmp] = 0;
                            
                            if (arrayExtractedImage3 [counter3] >= cutOffLevelCurrent3 && arrayExtractedImage3 [counter3] != 100) imageForDisplay3 [verticalBmp][horizontalBmp] = 220;
                            else imageForDisplay3 [verticalBmp][horizontalBmp] = 0;
                            
                            if (arrayExtractedImage3 [counter3] >= cutOffLevelCurrent4 && arrayExtractedImage3 [counter3] != 100) imageForDisplay4 [verticalBmp][horizontalBmp] = 220;
                            else imageForDisplay4 [verticalBmp][horizontalBmp] = 0;
                            
                            arrayExtractedImage [verticalBmp][horizontalBmp] = arrayExtractedImage3 [counter3];
                            
                            horizontalBmp++;
                        }
                        
                        if (horizontalBmp == imageWidth){
                            horizontalBmp = 0;
                            verticalBmp++;
                        }
                    }
                    
                    delete [] fileReadArray;
                    delete [] arrayExtractedImage3;
                }
            }
            else if (tifBmpType == 1){
                fin.open(loadingImagePath.c_str(), ios::in | ios::binary);
                
                unsigned long bitPosition = 0;
                int horizontalBit [4] = {0,0,0,0};
                int verticalBit [4] = {0,0,0,0};
                int bitData = 0;
                imageWidth = 0;
                imageHeight = 0;
                
                while ((bitData = fin.get()) != EOF){
                    if (bitPosition == 18) horizontalBit [0] = bitData;
                    if (bitPosition == 19) horizontalBit [1] = bitData;
                    if (bitPosition == 20) horizontalBit [2] = bitData;
                    if (bitPosition == 21) horizontalBit [3] = bitData;
                    if (bitPosition == 22) verticalBit [0] = bitData;
                    if (bitPosition == 23) verticalBit [1] = bitData;
                    if (bitPosition == 24) verticalBit [2] = bitData;
                    if (bitPosition == 25){
                        verticalBit [3] = bitData;
                        
                        imageWidth = horizontalBit [3]*16777216+horizontalBit [2]*65536+horizontalBit [1]*256+horizontalBit [0];
                        imageHeight = verticalBit [3]*16777216+verticalBit [2]*65536+verticalBit [1]*256+verticalBit [0];
                        break;
                    }
                    
                    bitPosition++;
                }
                
                fin.close();
                
                int entryValueSet = 0;
                
                for (int counter1 = 0; counter1 < thresholdDataHoldCount/6; counter1++){
                    if (atoi(wholeImageNumber.c_str()) >= thresholdDataHold [counter1*6]){
                        areaLimitCurrent = thresholdDataHold [counter1*6+5];
                        cutOffLevelCurrent = thresholdDataHold [counter1*6+1];
                        cutOffLevelCurrent2 = thresholdDataHold [counter1*6+2];
                        cutOffLevelCurrent3 = thresholdDataHold [counter1*6+3];
                        cutOffLevelCurrent4 = thresholdDataHold [counter1*6+4];
                        entryValueSet = 1;
                    }
                }
                
                if (entryValueSet == 0){
                    areaLimitCurrent = areaLimit;
                    cutOffLevelCurrent = cutOffLevel;
                    cutOffLevelCurrent2 = cutOffLevel2;
                    cutOffLevelCurrent3 = cutOffLevel3;
                    cutOffLevelCurrent4 = cutOffLevel4;
                }
                
                if (extractImageStatus == 0) extractImageStatus = 1;
                if (imageForDisplayStatus == 0) imageForDisplayStatus = 1;
                
                arrayExtractedImage = new int *[imageWidth+1];
                imageForDisplay1 = new int *[imageWidth+1];
                imageForDisplay2 = new int *[imageWidth+1];
                imageForDisplay3 = new int *[imageWidth+1];
                imageForDisplay4 = new int *[imageWidth+1];
                
                for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
                    arrayExtractedImage [counter1] = new int [imageWidth+1];
                    imageForDisplay1 [counter1] = new int [imageWidth+1];
                    imageForDisplay2 [counter1] = new int [imageWidth+1];
                    imageForDisplay3 [counter1] = new int [imageWidth+1];
                    imageForDisplay4 [counter1] = new int [imageWidth+1];
                }
                
                long sizeForCopy = 0;
                int imageDimensionCount = 0;
                
                struct stat sizeOfFile;
                
                if (stat(loadingImagePath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+4];
                    fin.open(loadingImagePath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+1);
                        fin.close();
                        
                        for (int counter1 = imageHeight-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                bitData = uploadTemp [1078+counter1*imageHeight+counter2];
                                
                                if (bitData >= cutOffLevelCurrent && bitData != 100) imageForDisplay1 [imageDimensionCount][counter2] = 220;
                                else imageForDisplay1 [imageDimensionCount][counter2] = 0;
                                
                                if (bitData >= cutOffLevelCurrent2 && bitData != 100) imageForDisplay2 [imageDimensionCount][counter2] = 220;
                                else imageForDisplay2 [imageDimensionCount][counter2] = 0;
                                
                                if (bitData >= cutOffLevelCurrent3 && bitData != 100) imageForDisplay3 [imageDimensionCount][counter2] = 220;
                                else imageForDisplay3 [imageDimensionCount][counter2] = 0;
                                
                                if (bitData >= cutOffLevelCurrent4 && bitData != 100) imageForDisplay4 [imageDimensionCount][counter2] = 220;
                                else imageForDisplay4 [imageDimensionCount][counter2] = 0;
                                
                                arrayExtractedImage [imageDimensionCount][counter2] = bitData;
                            }
                            
                            imageDimensionCount++;
                        }
                    }
                    
                    delete [] uploadTemp;
                }
            }
            
            [imageNoAuto setIntegerValue:atoi(wholeImageNumber.c_str())];
            [treatNameAuto setStringValue:@(wholeTreatmentName.c_str())];
            
            if (runMode == 1) [analysisNameAuto setStringValue:@(analysisNameManualString.c_str())];
            if (runMode == 3) [analysisNameAuto setStringValue:@(bodyName.c_str())];
            
            [imageSize setIntegerValue:imageWidth];
            [processingStatusDisplay setIntegerValue:remainingImages];
            
            treatNameManualString = wholeTreatmentName;
            displayImageNumber = atoi(wholeImageNumber.c_str());
            
            string loadingImagePath2 = imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Stitch";
            imageNameFileListCount = 0;
            
            string entry;
            
            DIR *dir;
            struct dirent *dent;
            
            dir = opendir(loadingImagePath2.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if ((int)entry.find("bmp") != -1 || (int)entry.find("tif") != -1) imageNameFileListCount++;
                }
                
                closedir(dir);
            }
            
            if (processSequenceFlag == 2) processSequenceFlag = 3;
            if (reprocessImageNo == 2) reprocessImageNo = 3;
            
            startProcessPermission = 1;
        }
    }
    else{
        
        if (runMode == 3){
            processSequenceFlag = 0;
            [self processImageFiles];
        }
        
        if (allRunFlag == 1){
            wholeImageCount = 0;
            processSequenceFlag = 0;
            allRunFlag = 0;
            [allRunStatus setStringValue:@"Off"];
        }
        
        if (reprocessImageNo == 2){
            wholeImageCount = 0;
            reprocessImageNo = 0;
            reprocessStatus = 0;
            processSequenceFlag = 0;
            [reprocessNoDisplay setStringValue:@"nil"];
        }
    }
}

-(void)processImageFiles{
    ifstream fin;
    ifstream fin2;
    
    string *treatmentList = new string [100];
    int treatmentListCount = 0;
    
    wholeImageCount = 0;
    remainingImages = 0;
    
    string loadingImagePath;
    
    if (runMode == 3) loadingImagePath = imageFolderPath+"/"+bodyName+"_Image";
    if (runMode == 1) loadingImagePath = imageFolderPath+"/"+analysisNameManualString+"_Image";
    
    DIR *dir;
    struct dirent *dent;
    DIR *dir2;
    struct dirent *dent2;
    
    int fileNumber = 0;
    
    dir = opendir(loadingImagePath.c_str());
    
    if (dir != NULL){
        int findString1 = 0;
        string entry;
        string entry2;
        string nameExtract;
        string imageFilePath;
        string numberExtract;
        
        while ((dent = readdir(dir))){
            entry = dent -> d_name;
            
            if ((findString1 = (int)entry.find("_Stitch")) != -1){
                nameExtract = entry.substr(0, (unsigned long)findString1);
                
                treatmentList [treatmentListCount] = nameExtract, treatmentListCount++;
                imageFilePath = loadingImagePath+"/"+entry;
                
                dir2 = opendir(imageFilePath.c_str());
                
                if (dir2 != NULL){
                    while ((dent2 = readdir(dir2))){
                        entry2 = dent2 -> d_name;
                        
                        if ((findString1 = (int)entry2.find("bmp")) != -1 || (findString1 = (int)entry2.find("tif")) != -1){
                            numberExtract = entry2.substr((unsigned long)findString1-5, 4);
                            
                            if (fileNumber < atoi(numberExtract.c_str())) fileNumber = atoi(numberExtract.c_str());
                        }
                    }
                    
                    closedir(dir2);
                }
            }
        }
        
        closedir(dir);
        
        //-------Directory Sort------
        NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
        
        for (int counter1 = 0; counter1 < treatmentListCount; counter1++){
            [unsortedArray addObject:@(treatmentList [counter1].c_str())];
        }
        
        [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
        
        for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
            treatmentList [counter1] = [unsortedArray [counter1] UTF8String];
        }
    }
    
    //------Whole image process status check, read not processed image point into an array 1. Treatment Name, 2. ImageNo------
    string nameString;
    string extension;
    string sourceImagePath;
    string processImagePath;
    
    for (int counter1 = 0; counter1 < treatmentListCount; counter1++){
        nameString = treatmentList [counter1];
        
        for (int counter2 = 1; counter2 <= fileNumber; counter2++){
            extension = to_string(counter2);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            sourceImagePath = loadingImagePath+"/"+nameString+"_Stitch"+"/STimage "+extension+".tif";
            
            fin.open(loadingImagePath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                fin.close();
            }
            else{
                
                sourceImagePath = loadingImagePath+"/"+nameString+"_Stitch"+"/STimage "+extension+".bmp";
            }
            
            if (runMode == 3) processImagePath = loadingImagePath+"/"+nameString+"_Processed"+"/"+extension+"_"+bodyName+"_"+nameString+"_MasterData";
            if (runMode == 1) processImagePath = loadingImagePath+"/"+nameString+"_Processed"+"/"+extension+"_"+analysisNameManualString+"_"+nameString+"_MasterData";
            
            fin.open(sourceImagePath.c_str(), ios::in);
            fin2.open(processImagePath.c_str(), ios::in);
            
            if (fin.is_open() && fin2.is_open()){
                fin.close();
                fin2.close();
            }
            else if (!fin.is_open() && fin2.is_open()) fin2.close();
            else if (fin.is_open() && !fin2.is_open()){
                if (wholeImageCount+5 > wholeImageLimit) [self wholeImageUpDate];
                
                arrayWholeImage [wholeImageCount] = nameString, wholeImageCount++;
                arrayWholeImage [wholeImageCount] = extension, wholeImageCount++;
                
                fin.close();
            }
        }
        
        remainingImages = wholeImageCount/2;
    }
    
    for (int counter1 = 0; counter1 < wholeImageCount/2; counter1++){
        for (int counter2 = 0; counter2 < treatmentSelectListCount/2; counter2++){
            if (arrayWholeImage [counter1*2] == treatmentSelectList [counter2*2+1] && treatmentSelectList [counter2*2] == "0"){
                arrayWholeImage [counter1*2] = "0";
                arrayWholeImage [counter1*2+1] = "0";
            }
        }
    }
    
    delete [] treatmentList;
    
    processSequenceFlag = 150;
}

-(IBAction)allProcess:(id)sender{
    if (runMode == 1 && imageFirstLoadFlag == 1){
        if (allRunFlag == 0 && processSequenceFlag == 0 && reprocessStatus == 0){
            string *arrayFileDelete = new string [500];
            int fileDeleteCount = 0;
            int fileDeleteLimit = 0;
            int continuityCheck = 0;
            
            string loadingImagePath = imageFolderPath+"/"+analysisNameManualString+"_Image";
            string productDataPath1;
            string entry;
            string entry2;
            
            DIR *dir;
            struct dirent *dent;
            DIR *dir2;
            struct dirent *dent2;
            
            dir = opendir(loadingImagePath.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("_Processed") != -1){
                        productDataPath1 = loadingImagePath+"/"+entry;
                        
                        dir2 = opendir(productDataPath1.c_str());
                        
                        if (dir2 != NULL){
                            while ((dent2 = readdir(dir2))){
                                entry2 = dent2 -> d_name;
                                
                                if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && (int)entry2.find("_MasterData") != -1){
                                    if (fileDeleteCount+5 > fileDeleteLimit){
                                        string *arrayUpDate = new string [fileDeleteCount+10];
                                        
                                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
                                        
                                        delete [] arrayFileDelete;
                                        arrayFileDelete = new string [fileDeleteLimit+500];
                                        fileDeleteLimit = fileDeleteLimit+500;
                                        
                                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    arrayFileDelete [fileDeleteCount] = entry2, fileDeleteCount++;
                                }
                            }
                            
                            closedir(dir2);
                        }
                        
                        //-------Directory Sort------
                        NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                        
                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                        }
                        
                        [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                        
                        for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                            arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                        }
                        
                        continuityCheck = 1;
                        
                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            if (atoi(arrayFileDelete [counter1].substr(0, 4).c_str()) == continuityCheck) continuityCheck++;
                        }
                        
                        dir2 = opendir(productDataPath1.c_str());
                        
                        fileDeleteCount = 0;
                        
                        if (dir2 != NULL){
                            while ((dent2 = readdir(dir2))){
                                entry2 = dent2 -> d_name;
                                
                                if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                    if (atoi(entry2.substr(0, 4).c_str()) >= continuityCheck){
                                        arrayFileDelete [fileDeleteCount] = productDataPath1+"/"+entry2, fileDeleteCount++;
                                    }
                                }
                            }
                            
                            closedir(dir2);
                        }
                    }
                }
            }
            
            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                remove (arrayFileDelete [counter1] .c_str());
            }
            
            delete [] arrayFileDelete;
            
            allRunFlag = 1;
            processSequenceFlag = 0;
            [allRunStatus setStringValue:@"On"];
        }
        else{
            
            if (allRunFlag == 1){
                allRunFlag = 2;
                treatmentOptionNameHold = "nil";
                [allRunStatus setStringValue:@"Off"];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Processing Ongoing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Images Unloaded"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)autoRunOnOff:(id)sender{
    if (bodyName != "nil"){
        if (processSequenceFlag == 0 && allRunFlag != 1 && reprocessStatus == 0){
            string imageFolderSetPath = imageFolderPath+"/"+bodyName+"_Image";
            
            ifstream fin;
            fin.open(imageFolderSetPath.c_str(), ios::in);
            
            if (fin.is_open()){
                fin.close();
                
                if (runMode == 1){
                    runMode = 3;
                    processSequenceFlag = 0;
                    [autoRunStatusDisplay setStringValue:@"On"];
                }
                else if (runMode == 3){
                    autoModeOffControl = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Missing Image Folder"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Ongoing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Analysis Name"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)treatmentNameSet:(id)sender{
    if (runMode == 1 && autoRunStatus == 0){
        if (processSequenceFlag == 0 && allRunFlag != 1 && reprocessStatus == 0){
            string inputData = [[inputField stringValue] UTF8String];
            [inputField setStringValue:@""];
            
            int errorData = [self nameCheck:inputData];
            
            if (analysisNameManualString != "" && errorData == 0){
                treatNameManualString = inputData;
                
                int tifBmpType = 0;
                
                string loadingImagePath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Stitch";
                
                DIR *dir = opendir(loadingImagePath.c_str());
                struct dirent *dent;
                
                if (dir != NULL){
                    imageNameFileListCount = 0;
                    
                    string entry;
                    string firstImageName = "";
                    
                    string *arrayFileInfo = new string [500];
                    int fileInfoCount = 0;
                    int fileInfoLimit = 0;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if ((int)entry.find("bmp") != -1 || (int)entry.find("tif") != -1){
                            if ((int)entry.find("bmp") != -1) tifBmpType = 1;
                            else if ((int)entry.find("tif") != -1) tifBmpType = 0;
                            
                            imageNameFileListCount++;
                            
                            if (fileInfoCount+5 > fileInfoLimit){
                                string *arrayUpDate = new string [fileInfoCount+10];
                                
                                for (int counter1 = 0; counter1 < fileInfoCount; counter1++) arrayUpDate [counter1] = arrayFileInfo [counter1];
                                
                                delete [] arrayFileInfo;
                                arrayFileInfo = new string [fileInfoLimit+500];
                                fileInfoLimit = fileInfoLimit+500;
                                
                                for (int counter1 = 0; counter1 < fileInfoCount; counter1++) arrayFileInfo [counter1] = arrayUpDate [counter1];
                                delete [] arrayUpDate;
                            }
                            
                            arrayFileInfo [fileInfoCount] = entry, fileInfoCount++;
                        }
                    }
                    
                    closedir(dir);
                    
                    //-------Directory Sort------
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < fileInfoCount; counter1++){
                        [unsortedArray addObject:@(arrayFileInfo [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        arrayFileInfo [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                    
                    if (fileInfoCount != 0) firstImageName = arrayFileInfo [0];
                    
                    delete [] arrayFileInfo;
                    
                    if (imageNameFileListCount != 0){
                        string loadingImagePath2 = loadingImagePath+"/"+firstImageName;
                        
                        if (tifBmpType == 0){
                            ifstream fin;
                            
                            //------Tiff reading------
                            unsigned long stripFirstAddress = 0;
                            unsigned long stripByteCountAddress = 0;
                            unsigned long nextAddress = 0;
                            unsigned long headPosition = 0;
                            unsigned long stripEntry = 0;
                            long sizeForCopy = 0;
                            
                            double xPosition = 0;
                            double yPosition = 0;
                            
                            int imageWidthTif = 0;
                            int imageHeightTif = 0;
                            int imageBit = 0; // Check 8, 16
                            int imageCompression = 0; // Check 1
                            int photoMetric = 0; //Check 0, 1, 2
                            int imageDimension = 0;
                            int verticalBmp = 0;
                            int horizontalBmp = 0;
                            int endianType = 0;
                            int samplePerPix = 0;
                            int dataConversion [4];
                            int processType = 1;
                            int numberOfLayers = 0;
                            
                            struct stat sizeOfFile;
                            
                            if (stat(loadingImagePath2.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                fileReadArray = new uint8_t [sizeForCopy+4];
                                fin.open(loadingImagePath2.c_str(), ios::in | ios::binary);
                                
                                fin.read((char*)fileReadArray, sizeForCopy+4);
                                fin.close();
                                
                                dataConversion [0] = fileReadArray [0];
                                dataConversion [1] = fileReadArray [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                int *arrayExtractedImage3 = new int [100];
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = fileReadArray [7];
                                    dataConversion [1] = fileReadArray [6];
                                    dataConversion [2] = fileReadArray [5];
                                    dataConversion [3] = fileReadArray [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = fileReadArray [4];
                                    dataConversion [1] = fileReadArray [5];
                                    dataConversion [2] = fileReadArray [6];
                                    dataConversion [3] = fileReadArray [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                if (endianType == 1){
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    [tiffFileRead tiffReadLargeEndian: headPosition:&imageWidthTif:&imageHeightTif:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                    
                                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                        if (imageWidthTif > imageHeightTif) imageDimension = imageWidthTif;
                                        else imageDimension = imageHeightTif;
                                        
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [tiffFileRead imageSetLargeEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                    }
                                }
                                else if (endianType == 0){
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    [tiffFileRead tiffReadSmallEndian: headPosition:&imageWidthTif:&imageHeightTif:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                    
                                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                        if (imageWidth > imageHeightTif) imageDimension = imageWidthTif;
                                        else imageDimension = imageHeightTif;
                                        
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [tiffFileRead imageSetSmallEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                    }
                                }
                                
                                imageWidth = imageWidthTif;
                                imageHeight = imageHeightTif;
                                
                                if (extractImageStatus == 1){
                                    for (int counter1 = 0; counter1 < imageWidth+1; counter1++) delete [] arrayExtractedImage [counter1];
                                    delete [] arrayExtractedImage;
                                    extractImageStatus = 0;
                                }
                                
                                if (imageForDisplayStatus == 1){
                                    for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
                                        delete [] imageForDisplay1 [counter1];
                                        delete [] imageForDisplay2 [counter1];
                                        delete [] imageForDisplay3 [counter1];
                                        delete [] imageForDisplay4 [counter1];
                                    }
                                    
                                    delete [] imageForDisplay1;
                                    delete [] imageForDisplay2;
                                    delete [] imageForDisplay3;
                                    delete [] imageForDisplay4;
                                    
                                    imageForDisplayStatus = 0;
                                }
                                
                                if (extractImageStatus == 0) extractImageStatus = 1;
                                if (imageForDisplayStatus == 0) imageForDisplayStatus = 1;
                                
                                arrayExtractedImage = new int *[imageWidth+1];
                                imageForDisplay1 = new int *[imageWidth+1];
                                imageForDisplay2 = new int *[imageWidth+1];
                                imageForDisplay3 = new int *[imageWidth+1];
                                imageForDisplay4 = new int *[imageWidth+1];
                                
                                for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
                                    arrayExtractedImage [counter1] = new int [imageWidth+1];
                                    imageForDisplay1 [counter1] = new int [imageWidth+1];
                                    imageForDisplay2 [counter1] = new int [imageWidth+1];
                                    imageForDisplay3 [counter1] = new int [imageWidth+1];
                                    imageForDisplay4 [counter1] = new int [imageWidth+1];
                                }
                                
                                horizontalBmp = 0;
                                verticalBmp = 0;
                                
                                for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                    if (horizontalBmp < imageWidth){
                                        if (arrayExtractedImage3 [counter3] >= cutOffLevel&& arrayExtractedImage3 [counter3] != 100) imageForDisplay1 [verticalBmp][horizontalBmp] = 220;
                                        else imageForDisplay1 [verticalBmp][horizontalBmp] = 0;
                                        
                                        if (arrayExtractedImage3 [counter3] >= cutOffLevel2 && arrayExtractedImage3 [counter3] != 100) imageForDisplay2 [verticalBmp][horizontalBmp] = 220;
                                        else imageForDisplay2 [verticalBmp][horizontalBmp] = 0;
                                        
                                        if (arrayExtractedImage3 [counter3] >= cutOffLevel3 && arrayExtractedImage3 [counter3] != 100) imageForDisplay3 [verticalBmp][horizontalBmp] = 220;
                                        else imageForDisplay3 [verticalBmp][horizontalBmp] = 0;
                                        
                                        if (arrayExtractedImage3 [counter3] >= cutOffLevel4 && arrayExtractedImage3 [counter3] != 100) imageForDisplay4 [verticalBmp][horizontalBmp] = 220;
                                        else imageForDisplay4 [verticalBmp][horizontalBmp] = 0;
                                        
                                        arrayExtractedImage [verticalBmp][horizontalBmp] = arrayExtractedImage3 [counter3];
                                        
                                        horizontalBmp++;
                                    }
                                    
                                    if (horizontalBmp == imageWidth){
                                        horizontalBmp = 0;
                                        verticalBmp++;
                                    }
                                }
                                
                                delete [] fileReadArray;
                                delete [] arrayExtractedImage3;
                            }
                            
                            if (imageWidth != 0){
                                string cellOutlineSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CellOutlineDrawSetting";
                                
                                [treatNameManual setStringValue:@(treatNameManualString.c_str())];
                                [treatNameDisplay setStringValue:@(treatNameManualString.c_str())];
                                
                                ofstream oin;
                                oin.open(cellOutlineSettingPath.c_str(), ios::out);
                                
                                oin<<analysisNameManualString<<endl;
                                oin<<treatNameManualString<<endl;
                                oin<<cutOffLevel<<endl;
                                oin<<cutOffLevel2<<endl;
                                oin<<cutOffLevel3<<endl;
                                oin<<cutOffLevel4<<endl;
                                oin<<areaLimit<<endl;
                                oin<<processOption<<endl;
                                
                                oin.close();
                                
                                [imageSize setIntegerValue:imageWidth];
                                [jumpDisplay setStringValue:@"nil"];
                                
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                                
                                if (imageFirstLoadFlag == 1){
                                    displayImageNumber = 1;
                                    lineDataForDisplayCount6 = 0;
                                    lineDataForDisplayCount7 = 0;
                                    lineDataForDisplayCount8 = 0;
                                    lineDataForDisplayCount9 = 0;
                                    
                                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSourceImage object:self];
                                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCellImage object:self];
                                }
                                
                                loadingImagePath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Processed";
                                
                                string extractString;
                                string outlineRangeString;
                                
                                dir = opendir(loadingImagePath.c_str());
                                
                                if (dir != NULL){
                                    int imageNumber = 0;
                                    
                                    while ((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        
                                        if ((int)entry.length() > 4){
                                            extractString = entry.substr(0, 4);
                                            
                                            if (atoi(extractString.c_str()) > imageNumber) imageNumber = atoi(extractString.c_str());
                                        }
                                    }
                                    
                                    closedir(dir);
                                    
                                    string extension = to_string(imageNumber);
                                    outlineRangeString = "1-"+extension;
                                }
                                else outlineRangeString = "0";
                                
                                [outlineRange setStringValue:@(outlineRangeString.c_str())];
                            }
                            else{
                                
                                treatNameManualString = "";
                                [inputField setStringValue:@""];
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"Error in Image File"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                        else  if (tifBmpType == 1){
                            ifstream fin;
                            fin.open(loadingImagePath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                if (extractImageStatus == 1){
                                    for (int counter1 = 0; counter1 < imageWidth+1; counter1++) delete [] arrayExtractedImage [counter1];
                                    delete [] arrayExtractedImage;
                                    extractImageStatus = 0;
                                }
                                
                                if (imageForDisplayStatus == 1){
                                    for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
                                        delete [] imageForDisplay1 [counter1];
                                        delete [] imageForDisplay2 [counter1];
                                        delete [] imageForDisplay3 [counter1];
                                        delete [] imageForDisplay4 [counter1];
                                    }
                                    
                                    delete [] imageForDisplay1;
                                    delete [] imageForDisplay2;
                                    delete [] imageForDisplay3;
                                    delete [] imageForDisplay4;
                                    
                                    imageForDisplayStatus = 0;
                                }
                                
                                unsigned long bitPosition = 0;
                                int bitData = 0;
                                int horizontalBit [4] = {0,0,0,0};
                                int verticalBit [4] = {0,0,0,0};
                                imageWidth = 0;
                                imageHeight = 0;
                                
                                while ((bitData = fin.get()) != EOF){
                                    if (bitPosition == 18) horizontalBit [0] = bitData;
                                    if (bitPosition == 19) horizontalBit [1] = bitData;
                                    if (bitPosition == 20) horizontalBit [2] = bitData;
                                    if (bitPosition == 21) horizontalBit [3] = bitData;
                                    if (bitPosition == 22) verticalBit [0] = bitData;
                                    if (bitPosition == 23) verticalBit [1] = bitData;
                                    if (bitPosition == 24) verticalBit [2] = bitData;
                                    if (bitPosition == 25){
                                        verticalBit [3] = bitData;
                                        
                                        imageWidth = horizontalBit [3]*16777216+horizontalBit [2]*65536+horizontalBit [1]*256+horizontalBit [0];
                                        imageHeight = verticalBit [3]*16777216+verticalBit [2]*65536+verticalBit [1]*256+verticalBit [0];
                                        break;
                                    }
                                    
                                    bitPosition++;
                                }
                                
                                fin.close();
                                
                                if (imageWidth != 0){
                                    string cellOutlineSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CellOutlineDrawSetting";
                                    
                                    [treatNameManual setStringValue:@(treatNameManualString.c_str())];
                                    [treatNameDisplay setStringValue:@(treatNameManualString.c_str())];
                                    
                                    ofstream oin;
                                    oin.open(cellOutlineSettingPath.c_str(), ios::out);
                                    
                                    oin<<analysisNameManualString<<endl;
                                    oin<<treatNameManualString<<endl;
                                    oin<<cutOffLevel<<endl;
                                    oin<<cutOffLevel2<<endl;
                                    oin<<cutOffLevel3<<endl;
                                    oin<<cutOffLevel4<<endl;
                                    oin<<areaLimit<<endl;
                                    oin<<processOption<<endl;
                                    
                                    oin.close();
                                    
                                    [imageSize setIntegerValue:imageWidth];
                                    [jumpDisplay setStringValue:@"nil"];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                    
                                    if (imageFirstLoadFlag == 1){
                                        fin.open(loadingImagePath2.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.close();
                                            
                                            if (extractImageStatus == 0) extractImageStatus = 1;
                                            if (imageForDisplayStatus == 0) imageForDisplayStatus = 1;
                                            
                                            arrayExtractedImage = new int *[imageWidth+1];
                                            imageForDisplay1 = new int *[imageWidth+1];
                                            imageForDisplay2 = new int *[imageWidth+1];
                                            imageForDisplay3 = new int *[imageWidth+1];
                                            imageForDisplay4 = new int *[imageWidth+1];
                                            
                                            for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
                                                arrayExtractedImage [counter1] = new int [imageWidth+1];
                                                imageForDisplay1 [counter1] = new int [imageWidth+1];
                                                imageForDisplay2 [counter1] = new int [imageWidth+1];
                                                imageForDisplay3 [counter1] = new int [imageWidth+1];
                                                imageForDisplay4 [counter1] = new int [imageWidth+1];
                                            }
                                            
                                            long sizeForCopy = 0;
                                            int imageDimensionCount = 0;
                                            
                                            struct stat sizeOfFile;
                                            
                                            if (stat(loadingImagePath2.c_str(), &sizeOfFile) == 0){
                                                sizeForCopy = sizeOfFile.st_size;
                                                
                                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+4];
                                                fin.open(loadingImagePath2.c_str(), ios::in | ios::binary);
                                                
                                                if (fin.is_open()){
                                                    fin.read((char*)uploadTemp, sizeForCopy+1);
                                                    fin.close();
                                                    
                                                    for (int counter1 = imageHeight-1; counter1 >= 0; counter1--){
                                                        for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                                            bitData = uploadTemp [1078+counter1*imageHeight+counter2];
                                                            
                                                            if (bitData >= cutOffLevel && bitData != 100) imageForDisplay1 [imageDimensionCount][counter2] = 220;
                                                            else imageForDisplay1 [imageDimensionCount][counter2] = 0;
                                                            
                                                            if (bitData >= cutOffLevel2 && bitData != 100) imageForDisplay2 [imageDimensionCount][counter2] = 220;
                                                            else imageForDisplay2 [imageDimensionCount][counter2] = 0;
                                                            
                                                            if (bitData >= cutOffLevel3 && bitData != 100) imageForDisplay3 [imageDimensionCount][counter2] = 220;
                                                            else imageForDisplay3 [imageDimensionCount][counter2] = 0;
                                                            
                                                            if (bitData >= cutOffLevel4 && bitData != 100) imageForDisplay4 [imageDimensionCount][counter2] = 220;
                                                            else imageForDisplay4 [imageDimensionCount][counter2] = 0;
                                                            
                                                            arrayExtractedImage [imageDimensionCount][counter2] = bitData;
                                                        }
                                                        
                                                        imageDimensionCount++;
                                                    }
                                                }
                                                
                                                delete [] uploadTemp;
                                            }
                                        }
                                        
                                        displayImageNumber = 1;
                                        lineDataForDisplayCount6 = 0;
                                        lineDataForDisplayCount7 = 0;
                                        lineDataForDisplayCount8 = 0;
                                        lineDataForDisplayCount9 = 0;
                                        
                                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSourceImage object:self];
                                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCellImage object:self];
                                    }
                                    
                                    loadingImagePath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Processed";
                                    
                                    string extractString;
                                    string outlineRangeString;
                                    
                                    dir = opendir(loadingImagePath.c_str());
                                    
                                    if (dir != NULL){
                                        int imageNumber = 0;
                                        
                                        while ((dent = readdir(dir))){
                                            entry = dent -> d_name;
                                            
                                            if ((int)entry.length() > 4){
                                                extractString = entry.substr(0, 4);
                                                
                                                if (atoi(extractString.c_str()) > imageNumber) imageNumber = atoi(extractString.c_str());
                                            }
                                        }
                                        
                                        closedir(dir);
                                        
                                        string extension = to_string(imageNumber);
                                        outlineRangeString = "1-"+extension;
                                    }
                                    else outlineRangeString = "0";
                                    
                                    [outlineRange setStringValue:@(outlineRangeString.c_str())];
                                }
                                else{
                                    
                                    treatNameManualString = "";
                                    [inputField setStringValue:@""];
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"Error in Image File"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                            }
                            else{
                                
                                treatNameManualString = "";
                                [inputField setStringValue:@""];
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"File Missing"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                    }
                    else{
                        
                        [inputField setStringValue:@""];
                        [imageLoadResult setStringValue:@"nil"];
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Image File Missing"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    treatNameManualString = "";
                    [inputField setStringValue:@""];
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Directory Unavailable"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                [inputField setStringValue:@""];
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Missing Analysis/Treatment Name"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            [inputField setStringValue:@""];
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Ongoing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        [inputField setStringValue:@""];
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Manual Disabled, Auto Enabled"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)analysisNameSet:(id)sender{
    if (runMode == 1 && autoRunStatus == 0){
        if (processSequenceFlag == 0 && allRunFlag != 1 && reprocessStatus == 01){
            string inputData = [[inputField stringValue] UTF8String];
            [inputField setStringValue:@""];
            
            int errorData = [self nameCheck:inputData];
            
            if (errorData == 0){
                string cellOutlineSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CellOutlineDrawSetting";
                
                treatNameManualString = "";
                analysisNameManualString = inputData;
                
                ofstream oin;
                oin.open(cellOutlineSettingPath.c_str(), ios::out);
                
                oin<<analysisNameManualString<<endl;
                oin<<"nil"<<endl;
                oin<<cutOffLevel<<endl;
                oin<<cutOffLevel2<<endl;
                oin<<cutOffLevel3<<endl;
                oin<<cutOffLevel4<<endl;
                oin<<areaLimit<<endl;
                oin<<processOption<<endl;
                
                oin.close();
                
                [analysisNameManual setStringValue:@(analysisNameManualString.c_str())];
                [treatNameManual setStringValue:@"nil"];
                [jumpDisplay setStringValue:@"nil"];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                [inputField setStringValue:@""];
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Incorrect Name"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            [inputField setStringValue:@""];
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Ongoing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        [inputField setStringValue:@""];
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Manual Disabled, Auto Enabled"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(int)nameCheck:(string)inputData{
    int errorData = 0;
    
    if (inputData.length() < 4 && inputData.length() == 0) errorData = 1;
    if ((int)inputData.find(" ") >= 0) errorData = 1;
    if ((int)inputData.find(",") >= 0) errorData = 1;
    if ((int)inputData.find(".") >= 0) errorData = 1;
    if ((int)inputData.find("/") >= 0) errorData = 1;
    if ((int)inputData.find(",") >= 0) errorData = 1;
    if ((int)inputData.find(":") >= 0) errorData = 1;
    if ((int)inputData.find("<") >= 0) errorData = 1;
    if ((int)inputData.find(">") >= 0) errorData = 1;
    if ((int)inputData.find("'") >= 0) errorData = 1;
    if ((int)inputData.find("[") >= 0) errorData = 1;
    if ((int)inputData.find("]") >= 0) errorData = 1;
    if ((int)inputData.find("=") >= 0) errorData = 1;
    if ((int)inputData.find("+") >= 0) errorData = 1;
    if ((int)inputData.find("{") >= 0) errorData = 1;
    if ((int)inputData.find("}") >= 0) errorData = 1;
    if ((int)inputData.find("-") >= 0) errorData = 1;
    if ((int)inputData.find("_") >= 0) errorData = 1;
    if ((int)inputData.find(")") >= 0) errorData = 1;
    if ((int)inputData.find("(") >= 0) errorData = 1;
    if ((int)inputData.find("*") >= 0) errorData = 1;
    if ((int)inputData.find("&") >= 0) errorData = 1;
    if ((int)inputData.find("^") >= 0) errorData = 1;
    if ((int)inputData.find("%") >= 0) errorData = 1;
    if ((int)inputData.find("$") >= 0) errorData = 1;
    if ((int)inputData.find("#") >= 0) errorData = 1;
    if ((int)inputData.find("@") >= 0) errorData = 1;
    if ((int)inputData.find("!") >= 0) errorData = 1;
    if ((int)inputData.find("`") >= 0) errorData = 1;
    if ((int)inputData.find("~") >= 0) errorData = 1;
    if ((int)inputData.find("|") >= 0) errorData = 1;
    
    return errorData;
}

-(IBAction)imageLoad:(id)sender{
    if (runMode == 1 && autoRunStatus == 0 && imageFirstLoadFlag == 0){
        if (processSequenceFlag == 0 && allRunFlag != 1 && reprocessStatus == 0){
            [imageLoadResult setStringValue:@"nil"];
            string loadingImagePath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Stitch";
            
            int tifBmpType = 0;
            
            DIR *dir = opendir(loadingImagePath.c_str());
            struct dirent *dent;
            
            if (dir != NULL){
                imageNameFileListCount = 0;
                string firstImageName = "";
                string entry;
                
                string *nameTemp = new string [10000];
                int nameTempCount = 0;
                int nameTempLimit = 0;
                
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if ((int)entry.find("bmp") != -1 || (int)entry.find("tif") != -1){
                        if ((int)entry.find("bmp") != -1) tifBmpType = 1;
                        else if ((int)entry.find("tif") != -1) tifBmpType = 0;
                        
                        imageNameFileListCount++;
                        
                        if (nameTempLimit < nameTempCount+10){
                            string *arrayUpDate = new string [nameTempCount+10];
                            
                            for (int counter1 = 0; counter1 < nameTempCount; counter1++) arrayUpDate [counter1] = nameTemp [counter1];
                            
                            delete [] nameTemp;
                            nameTemp = new string [nameTempLimit+500];
                            nameTempLimit = nameTempLimit+500;
                            
                            for (int counter1 = 0; counter1 < nameTempCount; counter1++) nameTemp [counter1] = arrayUpDate [counter1];
                            delete [] arrayUpDate;
                        }
                        
                        nameTemp [nameTempCount] = entry, nameTempCount++;
                    }
                }
                
                closedir(dir);
                
                //-------Directory Sort------
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < nameTempCount; counter1++){
                    [unsortedArray addObject:@(nameTemp [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    nameTemp [counter1] = [unsortedArray [counter1] UTF8String];
                }
                
                firstImageName = nameTemp [0];
                
                delete [] nameTemp;
                
                if (imageNameFileListCount != 0){
                    [maxImageNo setIntegerValue:imageNameFileListCount];
                    
                    loadingImagePath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Stitch/"+firstImageName;
                    
                    if (tifBmpType == 0){
                        ifstream fin;
                        
                        //------Tiff reading------
                        unsigned long stripFirstAddress = 0;
                        unsigned long stripByteCountAddress = 0;
                        unsigned long nextAddress = 0;
                        unsigned long headPosition = 0;
                        unsigned long stripEntry = 0;
                        long sizeForCopy = 0;
                        
                        double xPosition = 0;
                        double yPosition = 0;
                        
                        int imageWidthTif = 0;
                        int imageHeightTif = 0;
                        int imageBit = 0; //Check 8, 16
                        int imageCompression = 0; //Check 1
                        int photoMetric = 0; //Check 0, 1, 2
                        int imageDimension = 0;
                        int verticalBmp = 0;
                        int horizontalBmp = 0;
                        int endianType = 0;
                        int samplePerPix = 0;
                        int dataConversion [4];
                        int processType = 1;
                        int numberOfLayers = 0;
                        
                        struct stat sizeOfFile;
                        
                        if (stat(loadingImagePath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            fileReadArray = new uint8_t [sizeForCopy+4];
                            fin.open(loadingImagePath.c_str(), ios::in | ios::binary);
                            
                            fin.read((char*)fileReadArray, sizeForCopy+4);
                            fin.close();
                            
                            dataConversion [0] = fileReadArray [0];
                            dataConversion [1] = fileReadArray [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            int *arrayExtractedImage3 = new int [100];
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = fileReadArray [7];
                                dataConversion [1] = fileReadArray [6];
                                dataConversion [2] = fileReadArray [5];
                                dataConversion [3] = fileReadArray [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = fileReadArray [4];
                                dataConversion [1] = fileReadArray [5];
                                dataConversion [2] = fileReadArray [6];
                                dataConversion [3] = fileReadArray [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            if (endianType == 1){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadLargeEndian: headPosition:&imageWidthTif:&imageHeightTif:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    if (imageWidthTif > imageHeightTif) imageDimension = imageWidthTif;
                                    else imageDimension = imageHeightTif;
                                    
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [tiffFileRead imageSetLargeEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                }
                            }
                            else if (endianType == 0){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadSmallEndian: headPosition:&imageWidthTif:&imageHeightTif:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    if (imageWidth > imageHeightTif) imageDimension = imageWidthTif;
                                    else imageDimension = imageHeightTif;
                                    
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [tiffFileRead imageSetSmallEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                }
                            }
                            
                            imageWidth = imageWidthTif;
                            imageHeight = imageHeightTif;
                            
                            if (extractImageStatus == 1){
                                for (int counter1 = 0; counter1 < imageWidth+1; counter1++) delete [] arrayExtractedImage [counter1];
                                
                                delete [] arrayExtractedImage;
                                extractImageStatus = 0;
                            }
                            
                            if (imageForDisplayStatus == 1){
                                for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
                                    delete [] imageForDisplay1 [counter1];
                                    delete [] imageForDisplay2 [counter1];
                                    delete [] imageForDisplay3 [counter1];
                                    delete [] imageForDisplay4 [counter1];
                                }
                                
                                delete [] imageForDisplay1;
                                delete [] imageForDisplay2;
                                delete [] imageForDisplay3;
                                delete [] imageForDisplay4;
                                
                                imageForDisplayStatus = 0;
                            }
                            
                            if (extractImageStatus == 0) extractImageStatus = 1;
                            if (imageForDisplayStatus == 0) imageForDisplayStatus = 1;
                            
                            arrayExtractedImage = new int *[imageWidth+1];
                            imageForDisplay1 = new int *[imageWidth+1];
                            imageForDisplay2 = new int *[imageWidth+1];
                            imageForDisplay3 = new int *[imageWidth+1];
                            imageForDisplay4 = new int *[imageWidth+1];
                            
                            for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
                                arrayExtractedImage [counter1] = new int [imageWidth+1];
                                imageForDisplay1 [counter1] = new int [imageWidth+1];
                                imageForDisplay2 [counter1] = new int [imageWidth+1];
                                imageForDisplay3 [counter1] = new int [imageWidth+1];
                                imageForDisplay4 [counter1] = new int [imageWidth+1];
                            }
                            
                            horizontalBmp = 0;
                            verticalBmp = 0;
                            
                            for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                if (horizontalBmp < imageWidth){
                                    if (arrayExtractedImage3 [counter3] >= cutOffLevel && arrayExtractedImage3 [counter3] != 100) imageForDisplay1 [verticalBmp][horizontalBmp] = 220;
                                    else imageForDisplay1 [verticalBmp][horizontalBmp] = 0;
                                    
                                    if (arrayExtractedImage3 [counter3] >= cutOffLevel2 && arrayExtractedImage3 [counter3] != 100) imageForDisplay2 [verticalBmp][horizontalBmp] = 220;
                                    else imageForDisplay2 [verticalBmp][horizontalBmp] = 0;
                                    
                                    if (arrayExtractedImage3 [counter3] >= cutOffLevel3 && arrayExtractedImage3 [counter3] != 100) imageForDisplay3 [verticalBmp][horizontalBmp] = 220;
                                    else imageForDisplay3 [verticalBmp][horizontalBmp] = 0;
                                    
                                    if (arrayExtractedImage3 [counter3] >= cutOffLevel4 && arrayExtractedImage3 [counter3] != 100) imageForDisplay4 [verticalBmp][horizontalBmp] = 220;
                                    else imageForDisplay4 [verticalBmp][horizontalBmp] = 0;
                                    
                                    arrayExtractedImage [verticalBmp][horizontalBmp] = arrayExtractedImage3 [counter3];
                                    
                                    horizontalBmp++;
                                }
                                
                                if (horizontalBmp == imageWidth){
                                    horizontalBmp = 0;
                                    verticalBmp++;
                                }
                            }
                            
                            delete [] fileReadArray;
                            delete [] arrayExtractedImage3;
                        }
                        
                        if (imageWidth != 0){
                            [imageSize setIntegerValue:imageWidth];
                            [imageLoadResult setStringValue:@"Loaded"];
                            [analysisNameDisplay setStringValue:@(analysisNameManualString.c_str())];
                            [treatNameDisplay setStringValue:@(treatNameManualString.c_str())];
                            
                            lineDataForDisplayCount6 = 0;
                            lineDataForDisplayCount7 = 0;
                            lineDataForDisplayCount8 = 0;
                            lineDataForDisplayCount9 = 0;
                            startProcessPermission = 1;
                            displayImageNumber = 1;
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                            
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSourceImage object:self];
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCellImage object:self];
                        }
                        else{
                            
                            [imageLoadResult setStringValue:@"No Files"];
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Image File Missing"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else  if (tifBmpType == 1){
                        ifstream fin;
                        fin.open(loadingImagePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            if (extractImageStatus == 1){
                                for (int counter1 = 0; counter1 < imageWidth+1; counter1++) delete [] arrayExtractedImage [counter1];
                                delete [] arrayExtractedImage;
                                extractImageStatus = 0;
                            }
                            
                            if (imageForDisplayStatus == 1){
                                for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
                                    delete [] imageForDisplay1 [counter1];
                                    delete [] imageForDisplay2 [counter1];
                                    delete [] imageForDisplay3 [counter1];
                                    delete [] imageForDisplay4 [counter1];
                                }
                                
                                delete [] imageForDisplay1;
                                delete [] imageForDisplay2;
                                delete [] imageForDisplay3;
                                delete [] imageForDisplay4;
                                
                                imageForDisplayStatus = 0;
                            }
                            
                            unsigned long bitPosition = 0;
                            imageWidth = 0;
                            imageHeight = 0;
                            int bitData = 0;
                            int horizontalBit [4] = {0,0,0,0};
                            int verticalBit [4] = {0,0,0,0};
                            
                            while ((bitData = fin.get()) != EOF){
                                if (bitPosition == 18) horizontalBit [0] = bitData;
                                if (bitPosition == 19) horizontalBit [1] = bitData;
                                if (bitPosition == 20) horizontalBit [2] = bitData;
                                if (bitPosition == 21) horizontalBit [3] = bitData;
                                if (bitPosition == 22) verticalBit [0] = bitData;
                                if (bitPosition == 23) verticalBit [1] = bitData;
                                if (bitPosition == 24) verticalBit [2] = bitData;
                                if (bitPosition == 25){
                                    verticalBit [3] = bitData;
                                    
                                    imageWidth = horizontalBit [3]*16777216+horizontalBit [2]*65536+horizontalBit [1]*256+horizontalBit [0];
                                    imageHeight = verticalBit [3]*16777216+verticalBit [2]*65536+verticalBit [1]*256+verticalBit [0];
                                    break;
                                }
                                
                                bitPosition++;
                            }
                            
                            fin.close();
                            
                            if (imageWidth != 0){
                                [imageSize setIntegerValue:imageWidth];
                                [imageLoadResult setStringValue:@"Loaded"];
                                [analysisNameDisplay setStringValue:@(analysisNameManualString.c_str())];
                                [treatNameDisplay setStringValue:@(treatNameManualString.c_str())];
                                
                                fin.open(loadingImagePath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    
                                    if (extractImageStatus == 0) extractImageStatus = 1;
                                    if (imageForDisplayStatus == 0) imageForDisplayStatus = 1;
                                    
                                    arrayExtractedImage = new int *[imageWidth+1];
                                    imageForDisplay1 = new int *[imageWidth+1];
                                    imageForDisplay2 = new int *[imageWidth+1];
                                    imageForDisplay3 = new int *[imageWidth+1];
                                    imageForDisplay4 = new int *[imageWidth+1];
                                    
                                    for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
                                        arrayExtractedImage [counter1] = new int [imageWidth+1];
                                        imageForDisplay1 [counter1] = new int [imageWidth+1];
                                        imageForDisplay2 [counter1] = new int [imageWidth+1];
                                        imageForDisplay3 [counter1] = new int [imageWidth+1];
                                        imageForDisplay4 [counter1] = new int [imageWidth+1];
                                    }
                                    
                                    long sizeForCopy = 0;
                                    int imageDimensionCount = 0;
                                    
                                    struct stat sizeOfFile;
                                    
                                    if (stat(loadingImagePath.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                        
                                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+4];
                                        fin.open(loadingImagePath.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTemp, sizeForCopy+1);
                                            fin.close();
                                            
                                            for (int counter1 = imageHeight-1; counter1 >= 0; counter1--){
                                                for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                                    bitData = uploadTemp [1078+counter1*imageHeight+counter2];
                                                    
                                                    if (bitData >= cutOffLevel && bitData != 100) imageForDisplay1 [imageDimensionCount][counter2] = 220;
                                                    else imageForDisplay1 [imageDimensionCount][counter2] = 0;
                                                    
                                                    if (bitData >= cutOffLevel2 && bitData != 100) imageForDisplay2 [imageDimensionCount][counter2] = 220;
                                                    else imageForDisplay2 [imageDimensionCount][counter2] = 0;
                                                    
                                                    if (bitData >= cutOffLevel3 && bitData != 100) imageForDisplay3 [imageDimensionCount][counter2] = 220;
                                                    else imageForDisplay3 [imageDimensionCount][counter2] = 0;
                                                    
                                                    if (bitData >= cutOffLevel4 && bitData != 100) imageForDisplay4 [imageDimensionCount][counter2] = 220;
                                                    else imageForDisplay4 [imageDimensionCount][counter2] = 0;
                                                    
                                                    arrayExtractedImage [imageDimensionCount][counter2] = bitData;
                                                }
                                                
                                                imageDimensionCount++;
                                            }
                                        }
                                        
                                        delete [] uploadTemp;
                                    }
                                }
                                
                                lineDataForDisplayCount6 = 0;
                                lineDataForDisplayCount7 = 0;
                                lineDataForDisplayCount8 = 0;
                                lineDataForDisplayCount9 = 0;
                                startProcessPermission = 1;
                                displayImageNumber = 1;
                                
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                                
                                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSourceImage object:self];
                                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCellImage object:self];
                            }
                            else{
                                
                                [imageLoadResult setStringValue:@"No Files"];
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"Image File Missing"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                        else{
                            
                            [imageLoadResult setStringValue:@"No Files"];
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Image File Missing"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                }
                else{
                    
                    [imageLoadResult setStringValue:@"nil"];
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Image Files Absent"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                [imageLoadResult setStringValue:@"nil"];
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Image File Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            [imageLoadResult setStringValue:@"nil"];
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Ongoing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (imageFirstLoadFlag == 0){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Manual Disabled, Auto Enabled/Images Already Loaded"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (imageFirstLoadFlag == 1){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Images Already Loaded"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)jump:(id)sender{
    if (runMode == 1 && autoRunStatus == 0 && imageFirstLoadFlag == 1){
        if (processSequenceFlag == 0 && allRunFlag != 1 && reprocessStatus == 0){
            if ([inputField integerValue] > 0 && [inputField integerValue] <= imageNameFileListCount){
                jumpSet = (int)[inputField integerValue];
                [inputField setStringValue:@""];
                
                displayImageNumber = jumpSet;
                
                [maxImageNo setIntegerValue:displayImageNumber];
                
                string extension = to_string(displayImageNumber);
                int tifBmpType = 0;
                
                ifstream fin;
                
                if (extension.length() == 1) extension = "000"+extension;
                else if (extension.length() == 2) extension = "00"+extension;
                else if (extension.length() == 3) extension = "0"+extension;
                
                string loadingImagePath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Stitch/"+"STimage "+extension+".tif";
                
                fin.open(loadingImagePath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    tifBmpType = 0;
                    fin.close();
                }
                else{
                    
                    imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Stitch/"+"STimage "+extension+".bmp";
                    tifBmpType = 1;
                }
                
                if (tifBmpType == 0){
                    //------Tiff reading------
                    unsigned long stripFirstAddress = 0;
                    unsigned long stripByteCountAddress = 0;
                    unsigned long nextAddress = 0;
                    unsigned long headPosition = 0;
                    unsigned long stripEntry = 0;
                    long sizeForCopy = 0;
                    
                    double xPosition = 0;
                    double yPosition = 0;
                    
                    int imageWidthTif = 0;
                    int imageHeightTif = 0;
                    int imageBit = 0; //Check 8, 16
                    int imageCompression = 0; //Check 1
                    int photoMetric = 0; //Check 0, 1, 2
                    int imageDimension = 0;
                    int verticalBmp = 0;
                    int horizontalBmp = 0;
                    int endianType = 0;
                    int samplePerPix = 0;
                    int dataConversion [4];
                    int processType = 1;
                    int numberOfLayers = 0;
                    
                    struct stat sizeOfFile;
                    
                    if (stat(loadingImagePath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        fileReadArray = new uint8_t [sizeForCopy+4];
                        fin.open(loadingImagePath.c_str(), ios::in | ios::binary);
                        
                        fin.read((char*)fileReadArray, sizeForCopy+4);
                        fin.close();
                        
                        dataConversion [0] = fileReadArray [0];
                        dataConversion [1] = fileReadArray [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        int *arrayExtractedImage3 = new int [100];
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = fileReadArray [7];
                            dataConversion [1] = fileReadArray [6];
                            dataConversion [2] = fileReadArray [5];
                            dataConversion [3] = fileReadArray [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = fileReadArray [4];
                            dataConversion [1] = fileReadArray [5];
                            dataConversion [2] = fileReadArray [6];
                            dataConversion [3] = fileReadArray [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        if (endianType == 1){
                            tiffFileRead = [[TiffFileRead alloc] init];
                            [tiffFileRead tiffReadLargeEndian: headPosition:&imageWidthTif:&imageHeightTif:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            
                            if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                if (imageWidthTif > imageHeightTif) imageDimension = imageWidthTif;
                                else imageDimension = imageHeightTif;
                                
                                tiffFileRead = [[TiffFileRead alloc] init];
                                delete [] arrayExtractedImage3;
                                
                                arrayExtractedImage3 = [tiffFileRead imageSetLargeEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                            }
                        }
                        else if (endianType == 0){
                            tiffFileRead = [[TiffFileRead alloc] init];
                            [tiffFileRead tiffReadSmallEndian: headPosition:&imageWidthTif:&imageHeightTif:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            
                            if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                if (imageWidth > imageHeightTif) imageDimension = imageWidthTif;
                                else imageDimension = imageHeightTif;
                                
                                tiffFileRead = [[TiffFileRead alloc] init];
                                delete [] arrayExtractedImage3;
                                
                                arrayExtractedImage3 = [tiffFileRead imageSetSmallEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                            }
                        }
                        
                        imageWidth = imageWidthTif;
                        imageHeight = imageHeightTif;
                        
                        horizontalBmp = 0;
                        verticalBmp = 0;
                        
                        for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                            if (horizontalBmp < imageWidth){
                                if (arrayExtractedImage3 [counter3] >= cutOffLevel && arrayExtractedImage3 [counter3] != 100) imageForDisplay1 [verticalBmp][horizontalBmp] = 220;
                                else imageForDisplay1 [verticalBmp][horizontalBmp] = 0;
                                
                                if (arrayExtractedImage3 [counter3] >= cutOffLevel2 && arrayExtractedImage3 [counter3] != 100) imageForDisplay2 [verticalBmp][horizontalBmp] = 220;
                                else imageForDisplay2 [verticalBmp][horizontalBmp] = 0;
                                
                                if (arrayExtractedImage3 [counter3] >= cutOffLevel3 && arrayExtractedImage3 [counter3] != 100) imageForDisplay3 [verticalBmp][horizontalBmp] = 220;
                                else imageForDisplay3 [verticalBmp][horizontalBmp] = 0;
                                
                                if (arrayExtractedImage3 [counter3] >= cutOffLevel4 && arrayExtractedImage3 [counter3] != 100) imageForDisplay4 [verticalBmp][horizontalBmp] = 220;
                                else imageForDisplay4 [verticalBmp][horizontalBmp] = 0;
                                
                                arrayExtractedImage [verticalBmp][horizontalBmp] = arrayExtractedImage3 [counter3];
                                
                                horizontalBmp++;
                            }
                            
                            if (horizontalBmp == imageWidth){
                                horizontalBmp = 0;
                                verticalBmp++;
                            }
                        }
                        
                        delete [] fileReadArray;
                        delete [] arrayExtractedImage3;
                    }
                }
                else if (tifBmpType == 1){
                    long sizeForCopy = 0;
                    int imageDimensionCount = 0;
                    
                    struct stat sizeOfFile;
                    
                    if (stat(loadingImagePath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+4];
                        fin.open(loadingImagePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+1);
                            fin.close();
                            
                            int bitData;
                            
                            for (int counter1 = imageHeight-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                    bitData = uploadTemp [1078+counter1*imageHeight+counter2];
                                    
                                    if (bitData >= cutOffLevel && bitData != 100) imageForDisplay1 [imageDimensionCount][counter2] = 220;
                                    else imageForDisplay1 [imageDimensionCount][counter2] = 0;
                                    
                                    if (bitData >= cutOffLevel2 && bitData != 100) imageForDisplay2 [imageDimensionCount][counter2] = 220;
                                    else imageForDisplay2 [imageDimensionCount][counter2] = 0;
                                    
                                    if (bitData >= cutOffLevel3 && bitData != 100) imageForDisplay3 [imageDimensionCount][counter2] = 220;
                                    else imageForDisplay3 [imageDimensionCount][counter2] = 0;
                                    
                                    if (bitData >= cutOffLevel4 && bitData != 100) imageForDisplay4 [imageDimensionCount][counter2] = 220;
                                    else imageForDisplay4 [imageDimensionCount][counter2] = 0;
                                    
                                    arrayExtractedImage [imageDimensionCount][counter2] = bitData;
                                }
                                
                                imageDimensionCount++;
                            }
                        }
                        
                        delete [] uploadTemp;
                    }
                }
                
                [jumpDisplay setIntegerValue:jumpSet];
                [timePointNumber setIntegerValue:jumpSet];
                
                lineDataForDisplayCount6 = 0;
                lineDataForDisplayCount7 = 0;
                lineDataForDisplayCount8 = 0;
                lineDataForDisplayCount9 = 0;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSourceImage object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCellImage object:self];
            }
            else{
                
                [jumpDisplay setStringValue:@"nil"];
                [inputField setStringValue:@""];
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Image Exceeds Limits"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            [jumpDisplay setStringValue:@"nil"];
            [inputField setStringValue:@""];
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Ongoing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        [jumpDisplay setStringValue:@"nil"];
        [inputField setStringValue:@""];
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Manual Disabled, Auto Enabled/Image Not Loaded"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)processStartMain:(id)sender{
    if (runMode == 1 && autoRunStatus == 0 && imageFirstLoadFlag == 1 && allRunFlag == 0 && processSequenceFlag == 0 && reprocessStatus == 0){
        processSequenceFlag = 20;
        [runOnOFF setStringValue:@"On"];
        [analysisNameAuto setStringValue:@(analysisNameManualString.c_str())];
        [treatNameAuto setStringValue:@(treatNameManualString.c_str())];
        [imageNoAuto setIntegerValue:displayImageNumber];
    }
    else{
        
        if (imageFirstLoadFlag == 0){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Image Not Loaded"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
            
        }
        else{
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Ongoing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(void)processStartSub{
    if (startProcessPermission == 1){
        string folderCreationPath;
        
        if (runMode == 3) folderCreationPath = imageFolderPath+"/"+bodyName+"_Image"+"/"+treatNameManualString+"_Processed";
        if (runMode == 1) folderCreationPath = imageFolderPath+"/"+analysisNameManualString+"_Image"+"/"+treatNameManualString+"_Processed";
        
        mkdir(folderCreationPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string statusSavePath = folderCreationPath+"/OutlineSetting";
        
        ofstream oin;
        oin.open(statusSavePath.c_str(), ios::out);
        
        oin<<analysisNameManualString<<endl;
        oin<<treatNameManualString<<endl;
        oin<<cutOffLevel<<endl;
        oin<<cutOffLevel2<<endl;
        oin<<cutOffLevel3<<endl;
        oin<<cutOffLevel4<<endl;
        oin<<areaLimit<<endl;
        oin<<processOption<<endl;
        
        oin.close();
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageProcessing object:self];
    }
}

-(IBAction)displayModeSW:(id)sender{
    if (processSequenceFlag == 0 && allRunFlag != 1 && reprocessStatus == 0){
        if (processSequenceFlag == 0){
            int cutOff1 = cutOffLevel;
            int cutOff2 = cutOffLevel2;
            int cutOff3 = cutOffLevel3;
            int cutOff4 = cutOffLevel4;
            
            string extension = to_string(cutOff1);
            string cutOffString1 = "TH "+extension;
            
            extension = to_string(cutOff2);
            string cutOffString2 = "TH "+extension;
            
            extension = to_string(cutOff3);
            string cutOffString3 = "TH "+extension;
            
            extension = to_string(cutOff4);
            string cutOffString4 = "TH "+extension;
            
            if (displayMode == 0) displayMode = 1, [displayThreshold setStringValue:@(cutOffString2.c_str())];
            else if (displayMode == 1) displayMode = 2, [displayThreshold setStringValue:@(cutOffString3.c_str())];
            else if (displayMode == 2) displayMode = 3, [displayThreshold setStringValue:@(cutOffString4.c_str())];
            else if (displayMode == 3) displayMode = 0, [displayThreshold setStringValue:@(cutOffString1.c_str())];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSourceImage object:self];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Processing Ongoing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cutOffSetMain:(id)sender{
    if (runMode == 1 && autoRunStatus == 0){
        if (processSequenceFlag == 0 && allRunFlag != 1 && reprocessStatus == 0){
            if ([inputField integerValue] >= 50 && [inputField integerValue] <= 220 && [inputField integerValue] > cutOffLevel2){
                cutOffLevel = (int)[inputField integerValue];
                [inputField setStringValue:@""];
                
                string cellOutlineSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CellOutlineDrawSetting";
                
                ofstream oin;
                oin.open(cellOutlineSettingPath.c_str(), ios::out);
                
                oin<<analysisNameManualString<<endl;
                oin<<treatNameManualString<<endl;
                oin<<cutOffLevel<<endl;
                oin<<cutOffLevel2<<endl;
                oin<<cutOffLevel3<<endl;
                oin<<cutOffLevel4<<endl;
                oin<<areaLimit<<endl;
                oin<<processOption<<endl;
                
                oin.close();
                
                [cutOffDisplay setIntegerValue:cutOffLevel];
                
                if (imageFirstLoadFlag == 1){
                    string imageNumberString = to_string(displayImageNumber);
                    
                    if (imageNumberString.length() == 1) imageNumberString = "000"+imageNumberString;
                    else if (imageNumberString.length() == 2) imageNumberString = "00"+imageNumberString;
                    else if (imageNumberString.length() == 3) imageNumberString = "0"+imageNumberString;
                    
                    int tifBmpType = 0;
                    
                    ifstream fin;
                    
                    string imageDataPath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Stitch/"+"STimage "+imageNumberString+".tif";
                    
                    fin.open(imageDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        tifBmpType = 0;
                        fin.close();
                    }
                    else{
                        
                        imageDataPath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Stitch/"+"STimage "+imageNumberString+".bmp";
                        tifBmpType = 1;
                    }
                    
                    if (tifBmpType == 0){
                        //------Tiff reading------
                        unsigned long stripFirstAddress = 0;
                        unsigned long stripByteCountAddress = 0;
                        unsigned long nextAddress = 0;
                        unsigned long headPosition = 0;
                        unsigned long stripEntry = 0;
                        long sizeForCopy = 0;
                        
                        double xPosition = 0;
                        double yPosition = 0;
                        
                        int imageWidthTif = 0;
                        int imageHeightTif = 0;
                        int imageBit = 0; //Check 8, 16
                        int imageCompression = 0; //Check 1
                        int photoMetric = 0; //Check 0, 1, 2
                        int imageDimension = 0;
                        int verticalBmp = 0;
                        int horizontalBmp = 0;
                        int endianType = 0;
                        int samplePerPix = 0;
                        int dataConversion [4];
                        int processType = 1;
                        int numberOfLayers = 0;
                        
                        struct stat sizeOfFile;
                        
                        if (stat(imageDataPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            fileReadArray = new uint8_t [sizeForCopy+4];
                            fin.open(imageDataPath.c_str(), ios::in | ios::binary);
                            
                            fin.read((char*)fileReadArray, sizeForCopy+4);
                            fin.close();
                            
                            dataConversion [0] = fileReadArray [0];
                            dataConversion [1] = fileReadArray [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            int *arrayExtractedImage3 = new int [100];
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = fileReadArray [7];
                                dataConversion [1] = fileReadArray [6];
                                dataConversion [2] = fileReadArray [5];
                                dataConversion [3] = fileReadArray [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = fileReadArray [4];
                                dataConversion [1] = fileReadArray [5];
                                dataConversion [2] = fileReadArray [6];
                                dataConversion [3] = fileReadArray [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            if (endianType == 1){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadLargeEndian: headPosition:&imageWidthTif:&imageHeightTif:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    if (imageWidthTif > imageHeightTif) imageDimension = imageWidthTif;
                                    else imageDimension = imageHeightTif;
                                    
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [tiffFileRead imageSetLargeEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                }
                            }
                            else if (endianType == 0){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadSmallEndian: headPosition:&imageWidthTif:&imageHeightTif:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    if (imageWidth > imageHeightTif) imageDimension = imageWidthTif;
                                    else imageDimension = imageHeightTif;
                                    
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [tiffFileRead imageSetSmallEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                }
                            }
                            
                            imageWidth = imageWidthTif;
                            imageHeight = imageHeightTif;
                            
                            if (extractImageStatus == 0) extractImageStatus = 1;
                            if (imageForDisplayStatus == 0) imageForDisplayStatus = 1;
                            
                            arrayExtractedImage = new int *[imageWidth+1];
                            imageForDisplay1 = new int *[imageWidth+1];
                            imageForDisplay2 = new int *[imageWidth+1];
                            imageForDisplay3 = new int *[imageWidth+1];
                            imageForDisplay4 = new int *[imageWidth+1];
                            
                            for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
                                arrayExtractedImage [counter1] = new int [imageWidth+1];
                                imageForDisplay1 [counter1] = new int [imageWidth+1];
                                imageForDisplay2 [counter1] = new int [imageWidth+1];
                                imageForDisplay3 [counter1] = new int [imageWidth+1];
                                imageForDisplay4 [counter1] = new int [imageWidth+1];
                            }
                            
                            horizontalBmp = 0;
                            verticalBmp = 0;
                            
                            for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                if (horizontalBmp < imageWidth){
                                    if (arrayExtractedImage3 [counter3] >= cutOffLevel && arrayExtractedImage3 [counter3] != 100) imageForDisplay1 [verticalBmp][horizontalBmp] = 220;
                                    else imageForDisplay1 [verticalBmp][horizontalBmp] = 0;
                                    
                                    if (arrayExtractedImage3 [counter3] >= cutOffLevel2 && arrayExtractedImage3 [counter3] != 100) imageForDisplay2 [verticalBmp][horizontalBmp] = 220;
                                    else imageForDisplay2 [verticalBmp][horizontalBmp] = 0;
                                    
                                    if (arrayExtractedImage3 [counter3] >= cutOffLevel3 && arrayExtractedImage3 [counter3] != 100) imageForDisplay3 [verticalBmp][horizontalBmp] = 220;
                                    else imageForDisplay3 [verticalBmp][horizontalBmp] = 0;
                                    
                                    if (arrayExtractedImage3 [counter3] >= cutOffLevel4 && arrayExtractedImage3 [counter3] != 100) imageForDisplay4 [verticalBmp][horizontalBmp] = 220;
                                    else imageForDisplay4 [verticalBmp][horizontalBmp] = 0;
                                    
                                    arrayExtractedImage [verticalBmp][horizontalBmp] = arrayExtractedImage3 [counter3];
                                    
                                    horizontalBmp++;
                                }
                                
                                if (horizontalBmp == imageWidth){
                                    horizontalBmp = 0;
                                    verticalBmp++;
                                }
                            }
                            
                            delete [] fileReadArray;
                            delete [] arrayExtractedImage3;
                        }
                    }
                    else{
                        
                        fin.open(imageDataPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (extractImageStatus == 0) extractImageStatus = 1;
                            if (imageForDisplayStatus == 0) imageForDisplayStatus = 1;
                            
                            arrayExtractedImage = new int *[imageWidth+1];
                            imageForDisplay1 = new int *[imageWidth+1];
                            imageForDisplay2 = new int *[imageWidth+1];
                            imageForDisplay3 = new int *[imageWidth+1];
                            imageForDisplay4 = new int *[imageWidth+1];
                            
                            for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
                                arrayExtractedImage [counter1] = new int [imageWidth+1];
                                imageForDisplay1 [counter1] = new int [imageWidth+1];
                                imageForDisplay2 [counter1] = new int [imageWidth+1];
                                imageForDisplay3 [counter1] = new int [imageWidth+1];
                                imageForDisplay4 [counter1] = new int [imageWidth+1];
                            }
                            
                            long sizeForCopy = 0;
                            int imageDimensionCount = 0;
                            
                            struct stat sizeOfFile;
                            
                            if (stat(imageDataPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+4];
                                fin.open(imageDataPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.read((char*)uploadTemp, sizeForCopy+1);
                                    fin.close();
                                    
                                    int bitData;
                                    
                                    for (int counter1 = imageHeight-1; counter1 >= 0; counter1--){
                                        for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                            bitData = uploadTemp [1078+counter1*imageHeight+counter2];
                                            
                                            if (bitData >= cutOffLevel && bitData != 100) imageForDisplay1 [imageDimensionCount][counter2] = 220;
                                            else imageForDisplay1 [imageDimensionCount][counter2] = 0;
                                            
                                            if (bitData >= cutOffLevel2 && bitData != 100) imageForDisplay2 [imageDimensionCount][counter2] = 220;
                                            else imageForDisplay2 [imageDimensionCount][counter2] = 0;
                                            
                                            if (bitData >= cutOffLevel3 && bitData != 100) imageForDisplay3 [imageDimensionCount][counter2] = 220;
                                            else imageForDisplay3 [imageDimensionCount][counter2] = 0;
                                            
                                            if (bitData >= cutOffLevel4 && bitData != 100) imageForDisplay4 [imageDimensionCount][counter2] = 220;
                                            else imageForDisplay4 [imageDimensionCount][counter2] = 0;
                                            
                                            arrayExtractedImage [imageDimensionCount][counter2] = bitData;
                                        }
                                        
                                        imageDimensionCount++;
                                    }
                                }
                                
                                delete [] uploadTemp;
                            }
                        }
                    }
                    
                    if (imageFirstLoadFlag == 1) [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSourceImage object:self];
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                [jumpDisplay setStringValue:@"nil"];
                [inputField setStringValue:@""];
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Value Exceeds Limit"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            [jumpDisplay setStringValue:@"nil"];
            [inputField setStringValue:@""];
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Ongoing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        [jumpDisplay setStringValue:@"nil"];
        [inputField setStringValue:@""];
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Manual Disabled, Auto Enabled"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cutOffSetMain2:(id)sender{
    if (runMode == 1 && autoRunStatus == 0){
        if (processSequenceFlag == 0 && allRunFlag != 1 && reprocessStatus == 0){
            if ([inputField integerValue] >= 50 && [inputField integerValue] <= 220 && cutOffLevel > [inputField integerValue] && [inputField integerValue] > cutOffLevel3){
                cutOffLevel2 = (int)[inputField integerValue];
                [inputField setStringValue:@""];
                
                string cellOutlineSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CellOutlineDrawSetting";
                
                ofstream oin;
                oin.open(cellOutlineSettingPath.c_str(), ios::out);
                
                oin<<analysisNameManualString<<endl;
                oin<<treatNameManualString<<endl;
                oin<<cutOffLevel<<endl;
                oin<<cutOffLevel2<<endl;
                oin<<cutOffLevel3<<endl;
                oin<<cutOffLevel4<<endl;
                oin<<areaLimit<<endl;
                oin<<processOption<<endl;
                
                oin.close();
                
                [cutOffDisplay2 setIntegerValue:cutOffLevel2];
                
                if (imageFirstLoadFlag == 1){
                    string imageNumberString = to_string(displayImageNumber);
                    
                    if (imageNumberString.length() == 1) imageNumberString = "000"+imageNumberString;
                    else if (imageNumberString.length() == 2) imageNumberString = "00"+imageNumberString;
                    else if (imageNumberString.length() == 3) imageNumberString = "0"+imageNumberString;
                    
                    int tifBmpType = 0;
                    
                    ifstream fin;
                    
                    string imageDataPath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Stitch/"+"STimage "+imageNumberString+".tif";
                    
                    fin.open(imageDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        tifBmpType = 0;
                        fin.close();
                    }
                    else{
                        
                        imageDataPath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Stitch/"+"STimage "+imageNumberString+".bmp";
                        tifBmpType = 1;
                    }
                    
                    if (tifBmpType == 0){
                        //------Tiff reading------
                        unsigned long stripFirstAddress = 0;
                        unsigned long stripByteCountAddress = 0;
                        unsigned long nextAddress = 0;
                        unsigned long headPosition = 0;
                        unsigned long stripEntry = 0;
                        long sizeForCopy = 0;
                        
                        double xPosition = 0;
                        double yPosition = 0;
                        
                        int imageWidthTif = 0;
                        int imageHeightTif = 0;
                        int imageBit = 0; //Check 8, 16
                        int imageCompression = 0; //Check 1
                        int photoMetric = 0; //Check 0, 1, 2
                        int imageDimension = 0;
                        int verticalBmp = 0;
                        int horizontalBmp = 0;
                        int endianType = 0;
                        int samplePerPix = 0;
                        int dataConversion [4];
                        int processType = 1;
                        int numberOfLayers = 0;
                        
                        struct stat sizeOfFile;
                        
                        if (stat(imageDataPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            fileReadArray = new uint8_t [sizeForCopy+4];
                            fin.open(imageDataPath.c_str(), ios::in | ios::binary);
                            
                            fin.read((char*)fileReadArray, sizeForCopy+4);
                            fin.close();
                            
                            dataConversion [0] = fileReadArray [0];
                            dataConversion [1] = fileReadArray [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            int *arrayExtractedImage3 = new int [100];
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = fileReadArray [7];
                                dataConversion [1] = fileReadArray [6];
                                dataConversion [2] = fileReadArray [5];
                                dataConversion [3] = fileReadArray [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = fileReadArray [4];
                                dataConversion [1] = fileReadArray [5];
                                dataConversion [2] = fileReadArray [6];
                                dataConversion [3] = fileReadArray [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            if (endianType == 1){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadLargeEndian: headPosition:&imageWidthTif:&imageHeightTif:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    if (imageWidthTif > imageHeightTif) imageDimension = imageWidthTif;
                                    else imageDimension = imageHeightTif;
                                    
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [tiffFileRead imageSetLargeEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                }
                            }
                            else if (endianType == 0){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadSmallEndian: headPosition:&imageWidthTif:&imageHeightTif:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    if (imageWidth > imageHeightTif) imageDimension = imageWidthTif;
                                    else imageDimension = imageHeightTif;
                                    
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [tiffFileRead imageSetSmallEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                }
                            }
                            
                            imageWidth = imageWidthTif;
                            imageHeight = imageHeightTif;
                            
                            if (extractImageStatus == 0) extractImageStatus = 1;
                            if (imageForDisplayStatus == 0) imageForDisplayStatus = 1;
                            
                            arrayExtractedImage = new int *[imageWidth+1];
                            imageForDisplay1 = new int *[imageWidth+1];
                            imageForDisplay2 = new int *[imageWidth+1];
                            imageForDisplay3 = new int *[imageWidth+1];
                            imageForDisplay4 = new int *[imageWidth+1];
                            
                            for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
                                arrayExtractedImage [counter1] = new int [imageWidth+1];
                                imageForDisplay1 [counter1] = new int [imageWidth+1];
                                imageForDisplay2 [counter1] = new int [imageWidth+1];
                                imageForDisplay3 [counter1] = new int [imageWidth+1];
                                imageForDisplay4 [counter1] = new int [imageWidth+1];
                            }
                            
                            horizontalBmp = 0;
                            verticalBmp = 0;
                            
                            for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                if (horizontalBmp < imageWidth){
                                    if (arrayExtractedImage3 [counter3] >= cutOffLevel && arrayExtractedImage3 [counter3] != 100) imageForDisplay1 [verticalBmp][horizontalBmp] = 220;
                                    else imageForDisplay1 [verticalBmp][horizontalBmp] = 0;
                                    
                                    if (arrayExtractedImage3 [counter3] >= cutOffLevel2 && arrayExtractedImage3 [counter3] != 100) imageForDisplay2 [verticalBmp][horizontalBmp] = 220;
                                    else imageForDisplay2 [verticalBmp][horizontalBmp] = 0;
                                    
                                    if (arrayExtractedImage3 [counter3] >= cutOffLevel3 && arrayExtractedImage3 [counter3] != 100) imageForDisplay3 [verticalBmp][horizontalBmp] = 220;
                                    else imageForDisplay3 [verticalBmp][horizontalBmp] = 0;
                                    
                                    if (arrayExtractedImage3 [counter3] >= cutOffLevel4 && arrayExtractedImage3 [counter3] != 100) imageForDisplay4 [verticalBmp][horizontalBmp] = 220;
                                    else imageForDisplay4 [verticalBmp][horizontalBmp] = 0;
                                    
                                    arrayExtractedImage [verticalBmp][horizontalBmp] = arrayExtractedImage3 [counter3];
                                    
                                    horizontalBmp++;
                                }
                                
                                if (horizontalBmp == imageWidth){
                                    horizontalBmp = 0;
                                    verticalBmp++;
                                }
                            }
                            
                            delete [] fileReadArray;
                            delete [] arrayExtractedImage3;
                        }
                    }
                    else if (tifBmpType == 1){
                        fin.open(imageDataPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (extractImageStatus == 0) extractImageStatus = 1;
                            if (imageForDisplayStatus == 0) imageForDisplayStatus = 1;
                            
                            arrayExtractedImage = new int *[imageWidth+1];
                            imageForDisplay1 = new int *[imageWidth+1];
                            imageForDisplay2 = new int *[imageWidth+1];
                            imageForDisplay3 = new int *[imageWidth+1];
                            imageForDisplay4 = new int *[imageWidth+1];
                            
                            for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
                                arrayExtractedImage [counter1] = new int [imageWidth+1];
                                imageForDisplay1 [counter1] = new int [imageWidth+1];
                                imageForDisplay2 [counter1] = new int [imageWidth+1];
                                imageForDisplay3 [counter1] = new int [imageWidth+1];
                                imageForDisplay4 [counter1] = new int [imageWidth+1];
                            }
                            
                            long sizeForCopy = 0;
                            int imageDimensionCount = 0;
                            
                            struct stat sizeOfFile;
                            
                            if (stat(imageDataPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+4];
                                fin.open(imageDataPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.read((char*)uploadTemp, sizeForCopy+1);
                                    fin.close();
                                    
                                    int bitData;
                                    
                                    for (int counter1 = imageHeight-1; counter1 >= 0; counter1--){
                                        for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                            bitData = uploadTemp [1078+counter1*imageHeight+counter2];
                                            
                                            if (bitData >= cutOffLevel && bitData != 100) imageForDisplay1 [imageDimensionCount][counter2] = 220;
                                            else imageForDisplay1 [imageDimensionCount][counter2] = 0;
                                            
                                            if (bitData >= cutOffLevel2 && bitData != 100) imageForDisplay2 [imageDimensionCount][counter2] = 220;
                                            else imageForDisplay2 [imageDimensionCount][counter2] = 0;
                                            
                                            if (bitData >= cutOffLevel3 && bitData != 100) imageForDisplay3 [imageDimensionCount][counter2] = 220;
                                            else imageForDisplay3 [imageDimensionCount][counter2] = 0;
                                            
                                            if (bitData >= cutOffLevel4 && bitData != 100) imageForDisplay4 [imageDimensionCount][counter2] = 220;
                                            else imageForDisplay4 [imageDimensionCount][counter2] = 0;
                                            
                                            arrayExtractedImage [imageDimensionCount][counter2] = bitData;
                                        }
                                        
                                        imageDimensionCount++;
                                    }
                                }
                                
                                delete [] uploadTemp;
                            }
                        }
                    }
                    
                    if (imageFirstLoadFlag == 1) [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSourceImage object:self];
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                [jumpDisplay setStringValue:@"nil"];
                [inputField setStringValue:@""];
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Value Exceeds Limit"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            [jumpDisplay setStringValue:@"nil"];
            [inputField setStringValue:@""];
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Ongoing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        [jumpDisplay setStringValue:@"nil"];
        [inputField setStringValue:@""];
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Manual Disabled, Auto Enabled"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cutOffSetMain3:(id)sender{
    if (runMode == 1 && autoRunStatus == 0){
        if (processSequenceFlag == 0 && allRunFlag != 1 && reprocessStatus == 0){
            if ([inputField integerValue] >= 50 && [inputField integerValue] <= 220 && cutOffLevel2 > [inputField integerValue] && [inputField integerValue] > cutOffLevel4){
                cutOffLevel3 = (int)[inputField integerValue];
                [inputField setStringValue:@""];
                
                string cellOutlineSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CellOutlineDrawSetting";
                
                ofstream oin;
                oin.open(cellOutlineSettingPath.c_str(), ios::out);
                
                oin<<analysisNameManualString<<endl;
                oin<<treatNameManualString<<endl;
                oin<<cutOffLevel<<endl;
                oin<<cutOffLevel2<<endl;
                oin<<cutOffLevel3<<endl;
                oin<<cutOffLevel4<<endl;
                oin<<areaLimit<<endl;
                oin<<processOption<<endl;
                
                oin.close();
                
                [cutOffDisplay3 setIntegerValue:cutOffLevel3];
                
                if (imageFirstLoadFlag == 1){
                    string imageNumberString = to_string(displayImageNumber);
                    
                    if (imageNumberString.length() == 1) imageNumberString = "000"+imageNumberString;
                    else if (imageNumberString.length() == 2) imageNumberString = "00"+imageNumberString;
                    else if (imageNumberString.length() == 3) imageNumberString = "0"+imageNumberString;
                    
                    int tifBmpType = 0;
                    
                    ifstream fin;
                    
                    string imageDataPath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Stitch/"+"STimage "+imageNumberString+".tif";
                    
                    fin.open(imageDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        tifBmpType = 0;
                        fin.close();
                    }
                    else{
                        
                        imageDataPath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Stitch/"+"STimage "+imageNumberString+".bmp";
                        tifBmpType = 1;
                    }
                    
                    if (tifBmpType == 0){
                        //------Tiff reading------
                        unsigned long stripFirstAddress = 0;
                        unsigned long stripByteCountAddress = 0;
                        unsigned long nextAddress = 0;
                        unsigned long headPosition = 0;
                        unsigned long stripEntry = 0;
                        long sizeForCopy = 0;
                        
                        double xPosition = 0;
                        double yPosition = 0;
                        
                        int imageWidthTif = 0;
                        int imageHeightTif = 0;
                        int imageBit = 0; //Check 8, 16
                        int imageCompression = 0; //Check 1
                        int photoMetric = 0; //Check 0, 1, 2
                        int imageDimension = 0;
                        int verticalBmp = 0;
                        int horizontalBmp = 0;
                        int endianType = 0;
                        int samplePerPix = 0;
                        int dataConversion [4];
                        int processType = 1;
                        int numberOfLayers = 0;
                        
                        struct stat sizeOfFile;
                        
                        if (stat(imageDataPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            fileReadArray = new uint8_t [sizeForCopy+4];
                            fin.open(imageDataPath.c_str(), ios::in | ios::binary);
                            
                            fin.read((char*)fileReadArray, sizeForCopy+4);
                            fin.close();
                            
                            dataConversion [0] = fileReadArray [0];
                            dataConversion [1] = fileReadArray [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            int *arrayExtractedImage3 = new int [100];
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = fileReadArray [7];
                                dataConversion [1] = fileReadArray [6];
                                dataConversion [2] = fileReadArray [5];
                                dataConversion [3] = fileReadArray [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = fileReadArray [4];
                                dataConversion [1] = fileReadArray [5];
                                dataConversion [2] = fileReadArray [6];
                                dataConversion [3] = fileReadArray [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            if (endianType == 1){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadLargeEndian: headPosition:&imageWidthTif:&imageHeightTif:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    if (imageWidthTif > imageHeightTif) imageDimension = imageWidthTif;
                                    else imageDimension = imageHeightTif;
                                    
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [tiffFileRead imageSetLargeEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                }
                            }
                            else if (endianType == 0){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadSmallEndian: headPosition:&imageWidthTif:&imageHeightTif:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    if (imageWidth > imageHeightTif) imageDimension = imageWidthTif;
                                    else imageDimension = imageHeightTif;
                                    
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [tiffFileRead imageSetSmallEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                }
                            }
                            
                            imageWidth = imageWidthTif;
                            imageHeight = imageHeightTif;
                            
                            if (extractImageStatus == 0) extractImageStatus = 1;
                            if (imageForDisplayStatus == 0) imageForDisplayStatus = 1;
                            
                            arrayExtractedImage = new int *[imageWidth+1];
                            imageForDisplay1 = new int *[imageWidth+1];
                            imageForDisplay2 = new int *[imageWidth+1];
                            imageForDisplay3 = new int *[imageWidth+1];
                            imageForDisplay4 = new int *[imageWidth+1];
                            
                            for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
                                arrayExtractedImage [counter1] = new int [imageWidth+1];
                                imageForDisplay1 [counter1] = new int [imageWidth+1];
                                imageForDisplay2 [counter1] = new int [imageWidth+1];
                                imageForDisplay3 [counter1] = new int [imageWidth+1];
                                imageForDisplay4 [counter1] = new int [imageWidth+1];
                            }
                            
                            horizontalBmp = 0;
                            verticalBmp = 0;
                            
                            for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                if (horizontalBmp < imageWidth){
                                    if (arrayExtractedImage3 [counter3] >= cutOffLevel && arrayExtractedImage3 [counter3] != 100) imageForDisplay1 [verticalBmp][horizontalBmp] = 220;
                                    else imageForDisplay1 [verticalBmp][horizontalBmp] = 0;
                                    
                                    if (arrayExtractedImage3 [counter3] >= cutOffLevel2 && arrayExtractedImage3 [counter3] != 100) imageForDisplay2 [verticalBmp][horizontalBmp] = 220;
                                    else imageForDisplay2 [verticalBmp][horizontalBmp] = 0;
                                    
                                    if (arrayExtractedImage3 [counter3] >= cutOffLevel3 && arrayExtractedImage3 [counter3] != 100) imageForDisplay3 [verticalBmp][horizontalBmp] = 220;
                                    else imageForDisplay3 [verticalBmp][horizontalBmp] = 0;
                                    
                                    if (arrayExtractedImage3 [counter3] >= cutOffLevel4 && arrayExtractedImage3 [counter3] != 100) imageForDisplay4 [verticalBmp][horizontalBmp] = 220;
                                    else imageForDisplay4 [verticalBmp][horizontalBmp] = 0;
                                    
                                    arrayExtractedImage [verticalBmp][horizontalBmp] = arrayExtractedImage3 [counter3];
                                    
                                    horizontalBmp++;
                                }
                                
                                if (horizontalBmp == imageWidth){
                                    horizontalBmp = 0;
                                    verticalBmp++;
                                }
                            }
                            
                            delete [] fileReadArray;
                            delete [] arrayExtractedImage3;
                        }
                    }
                    else if (tifBmpType == 1){
                        fin.open(imageDataPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (extractImageStatus == 0) extractImageStatus = 1;
                            if (imageForDisplayStatus == 0) imageForDisplayStatus = 1;
                            
                            arrayExtractedImage = new int *[imageWidth+1];
                            imageForDisplay1 = new int *[imageWidth+1];
                            imageForDisplay2 = new int *[imageWidth+1];
                            imageForDisplay3 = new int *[imageWidth+1];
                            imageForDisplay4 = new int *[imageWidth+1];
                            
                            for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
                                arrayExtractedImage [counter1] = new int [imageWidth+1];
                                imageForDisplay1 [counter1] = new int [imageWidth+1];
                                imageForDisplay2 [counter1] = new int [imageWidth+1];
                                imageForDisplay3 [counter1] = new int [imageWidth+1];
                                imageForDisplay4 [counter1] = new int [imageWidth+1];
                            }
                            
                            long sizeForCopy = 0;
                            int imageDimensionCount = 0;
                            
                            struct stat sizeOfFile;
                            
                            if (stat(imageDataPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+4];
                                fin.open(imageDataPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.read((char*)uploadTemp, sizeForCopy+1);
                                    fin.close();
                                    
                                    int bitData;
                                    
                                    for (int counter1 = imageHeight-1; counter1 >= 0; counter1--){
                                        for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                            bitData = uploadTemp [1078+counter1*imageHeight+counter2];
                                            
                                            if (bitData >= cutOffLevel && bitData != 100) imageForDisplay1 [imageDimensionCount][counter2] = 220;
                                            else imageForDisplay1 [imageDimensionCount][counter2] = 0;
                                            
                                            if (bitData >= cutOffLevel2 && bitData != 100) imageForDisplay2 [imageDimensionCount][counter2] = 220;
                                            else imageForDisplay2 [imageDimensionCount][counter2] = 0;
                                            
                                            if (bitData >= cutOffLevel3 && bitData != 100) imageForDisplay3 [imageDimensionCount][counter2] = 220;
                                            else imageForDisplay3 [imageDimensionCount][counter2] = 0;
                                            
                                            if (bitData >= cutOffLevel4 && bitData != 100) imageForDisplay4 [imageDimensionCount][counter2] = 220;
                                            else imageForDisplay4 [imageDimensionCount][counter2] = 0;
                                            
                                            arrayExtractedImage [imageDimensionCount][counter2] = bitData;
                                        }
                                        
                                        imageDimensionCount++;
                                    }
                                }
                                
                                delete [] uploadTemp;
                            }
                        }
                    }
                    
                    if (imageFirstLoadFlag == 1) [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSourceImage object:self];
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                [jumpDisplay setStringValue:@"nil"];
                [inputField setStringValue:@""];
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Value Exceeds Limit"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            [jumpDisplay setStringValue:@"nil"];
            [inputField setStringValue:@""];
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Ongoing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        [jumpDisplay setStringValue:@"nil"];
        [inputField setStringValue:@""];
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Manual Disabled, Auto Enabled"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cutOffSetMain4:(id)sender{
    if (runMode == 1 && autoRunStatus == 0){
        if (processSequenceFlag == 0 && allRunFlag != 1 && reprocessStatus == 0){
            if ([inputField integerValue] >= 50 && [inputField integerValue] <= 220 && cutOffLevel3 > [inputField integerValue]){
                cutOffLevel4 = (int)[inputField integerValue];
                [inputField setStringValue:@""];
                
                string cellOutlineSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CellOutlineDrawSetting";
                
                ofstream oin;
                oin.open(cellOutlineSettingPath.c_str(), ios::out);
                
                oin<<analysisNameManualString<<endl;
                oin<<treatNameManualString<<endl;
                oin<<cutOffLevel<<endl;
                oin<<cutOffLevel2<<endl;
                oin<<cutOffLevel3<<endl;
                oin<<cutOffLevel4<<endl;
                oin<<areaLimit<<endl;
                oin<<processOption<<endl;
                
                oin.close();
                
                [cutOffDisplay4 setIntegerValue:cutOffLevel4];
                
                if (imageFirstLoadFlag == 1){
                    string imageNumberString = to_string(displayImageNumber);
                    
                    if (imageNumberString.length() == 1) imageNumberString = "000"+imageNumberString;
                    else if (imageNumberString.length() == 2) imageNumberString = "00"+imageNumberString;
                    else if (imageNumberString.length() == 3) imageNumberString = "0"+imageNumberString;
                    
                    int tifBmpType = 0;
                    
                    ifstream fin;
                    
                    string imageDataPath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Stitch/"+"STimage "+imageNumberString+".tif";
                    
                    fin.open(imageDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        tifBmpType = 0;
                        fin.close();
                    }
                    else{
                        
                        imageDataPath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Stitch/"+"STimage "+imageNumberString+".bmp";
                        tifBmpType = 1;
                    }
                    
                    if (tifBmpType == 0){
                        //------Tiff reading------
                        unsigned long stripFirstAddress = 0;
                        unsigned long stripByteCountAddress = 0;
                        unsigned long nextAddress = 0;
                        unsigned long headPosition = 0;
                        unsigned long stripEntry = 0;
                        long sizeForCopy = 0;
                        
                        double xPosition = 0;
                        double yPosition = 0;
                        
                        int imageWidthTif = 0;
                        int imageHeightTif = 0;
                        int imageBit = 0; //Check 8, 16
                        int imageCompression = 0; //Check 1
                        int photoMetric = 0; //Check 0, 1, 2
                        int imageDimension = 0;
                        int verticalBmp = 0;
                        int horizontalBmp = 0;
                        int endianType = 0;
                        int samplePerPix = 0;
                        int dataConversion [4];
                        int processType = 1;
                        int numberOfLayers = 0;
                        
                        struct stat sizeOfFile;
                        
                        if (stat(imageDataPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            fileReadArray = new uint8_t [sizeForCopy+4];
                            fin.open(imageDataPath.c_str(), ios::in | ios::binary);
                            
                            fin.read((char*)fileReadArray, sizeForCopy+4);
                            fin.close();
                            
                            dataConversion [0] = fileReadArray [0];
                            dataConversion [1] = fileReadArray [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            int *arrayExtractedImage3 = new int [100];
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = fileReadArray [7];
                                dataConversion [1] = fileReadArray [6];
                                dataConversion [2] = fileReadArray [5];
                                dataConversion [3] = fileReadArray [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = fileReadArray [4];
                                dataConversion [1] = fileReadArray [5];
                                dataConversion [2] = fileReadArray [6];
                                dataConversion [3] = fileReadArray [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            if (endianType == 1){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadLargeEndian: headPosition:&imageWidthTif:&imageHeightTif:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    if (imageWidthTif > imageHeightTif) imageDimension = imageWidthTif;
                                    else imageDimension = imageHeightTif;
                                    
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [tiffFileRead imageSetLargeEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                }
                            }
                            else if (endianType == 0){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadSmallEndian: headPosition:&imageWidthTif:&imageHeightTif:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    if (imageWidth > imageHeightTif) imageDimension = imageWidthTif;
                                    else imageDimension = imageHeightTif;
                                    
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [tiffFileRead imageSetSmallEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                }
                            }
                            
                            imageWidth = imageWidthTif;
                            imageHeight = imageHeightTif;
                            
                            if (extractImageStatus == 0) extractImageStatus = 1;
                            if (imageForDisplayStatus == 0) imageForDisplayStatus = 1;
                            
                            arrayExtractedImage = new int *[imageWidth+1];
                            imageForDisplay1 = new int *[imageWidth+1];
                            imageForDisplay2 = new int *[imageWidth+1];
                            imageForDisplay3 = new int *[imageWidth+1];
                            imageForDisplay4 = new int *[imageWidth+1];
                            
                            for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
                                arrayExtractedImage [counter1] = new int [imageWidth+1];
                                imageForDisplay1 [counter1] = new int [imageWidth+1];
                                imageForDisplay2 [counter1] = new int [imageWidth+1];
                                imageForDisplay3 [counter1] = new int [imageWidth+1];
                                imageForDisplay4 [counter1] = new int [imageWidth+1];
                            }
                            
                            horizontalBmp = 0;
                            verticalBmp = 0;
                            
                            for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                if (horizontalBmp < imageWidth){
                                    if (arrayExtractedImage3 [counter3] >= cutOffLevel && arrayExtractedImage3 [counter3] != 100) imageForDisplay1 [verticalBmp][horizontalBmp] = 220;
                                    else imageForDisplay1 [verticalBmp][horizontalBmp] = 0;
                                    
                                    if (arrayExtractedImage3 [counter3] >= cutOffLevel2 && arrayExtractedImage3 [counter3] != 100) imageForDisplay2 [verticalBmp][horizontalBmp] = 220;
                                    else imageForDisplay2 [verticalBmp][horizontalBmp] = 0;
                                    
                                    if (arrayExtractedImage3 [counter3] >= cutOffLevel3 && arrayExtractedImage3 [counter3] != 100) imageForDisplay3 [verticalBmp][horizontalBmp] = 220;
                                    else imageForDisplay3 [verticalBmp][horizontalBmp] = 0;
                                    
                                    if (arrayExtractedImage3 [counter3] >= cutOffLevel4 && arrayExtractedImage3 [counter3] != 100) imageForDisplay4 [verticalBmp][horizontalBmp] = 220;
                                    else imageForDisplay4 [verticalBmp][horizontalBmp] = 0;
                                    
                                    arrayExtractedImage [verticalBmp][horizontalBmp] = arrayExtractedImage3 [counter3];
                                    
                                    horizontalBmp++;
                                }
                                
                                if (horizontalBmp == imageWidth){
                                    horizontalBmp = 0;
                                    verticalBmp++;
                                }
                            }
                            
                            delete [] fileReadArray;
                            delete [] arrayExtractedImage3;
                        }
                    }
                    else  if (tifBmpType == 1){
                        fin.open(imageDataPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (extractImageStatus == 0) extractImageStatus = 1;
                            if (imageForDisplayStatus == 0) imageForDisplayStatus = 1;
                            
                            arrayExtractedImage = new int *[imageWidth+1];
                            imageForDisplay1 = new int *[imageWidth+1];
                            imageForDisplay2 = new int *[imageWidth+1];
                            imageForDisplay3 = new int *[imageWidth+1];
                            imageForDisplay4 = new int *[imageWidth+1];
                            
                            for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
                                arrayExtractedImage [counter1] = new int [imageWidth+1];
                                imageForDisplay1 [counter1] = new int [imageWidth+1];
                                imageForDisplay2 [counter1] = new int [imageWidth+1];
                                imageForDisplay3 [counter1] = new int [imageWidth+1];
                                imageForDisplay4 [counter1] = new int [imageWidth+1];
                            }
                            
                            long sizeForCopy = 0;
                            int imageDimensionCount = 0;
                            
                            struct stat sizeOfFile;
                            
                            if (stat(imageDataPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+4];
                                fin.open(imageDataPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.read((char*)uploadTemp, sizeForCopy+1);
                                    fin.close();
                                    
                                    int bitData;
                                    
                                    for (int counter1 = imageHeight-1; counter1 >= 0; counter1--){
                                        for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                            bitData = uploadTemp [1078+counter1*imageHeight+counter2];
                                            
                                            if (bitData >= cutOffLevel && bitData != 100) imageForDisplay1 [imageDimensionCount][counter2] = 220;
                                            else imageForDisplay1 [imageDimensionCount][counter2] = 0;
                                            
                                            if (bitData >= cutOffLevel2 && bitData != 100) imageForDisplay2 [imageDimensionCount][counter2] = 220;
                                            else imageForDisplay2 [imageDimensionCount][counter2] = 0;
                                            
                                            if (bitData >= cutOffLevel3 && bitData != 100) imageForDisplay3 [imageDimensionCount][counter2] = 220;
                                            else imageForDisplay3 [imageDimensionCount][counter2] = 0;
                                            
                                            if (bitData >= cutOffLevel4 && bitData != 100) imageForDisplay4 [imageDimensionCount][counter2] = 220;
                                            else imageForDisplay4 [imageDimensionCount][counter2] = 0;
                                            
                                            arrayExtractedImage [imageDimensionCount][counter2] = bitData;
                                        }
                                        
                                        imageDimensionCount++;
                                    }
                                }
                                
                                delete [] uploadTemp;
                            }
                        }
                    }
                    
                    if (imageFirstLoadFlag == 1) [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSourceImage object:self];
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                [jumpDisplay setStringValue:@"nil"];
                [inputField setStringValue:@""];
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Value Exceeds Limit"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            [jumpDisplay setStringValue:@"nil"];
            [inputField setStringValue:@""];
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Ongoing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        [jumpDisplay setStringValue:@"nil"];
        [inputField setStringValue:@""];
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Manual Disabled, Auto Enabled"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)areaLimitSet:(id)sender{
    if (runMode == 1 && autoRunStatus == 0){
        if (processSequenceFlag == 0 && allRunFlag != 1 && reprocessStatus == 0){
            if ([inputField integerValue] >= 5 && [inputField integerValue] <= 500){
                areaLimit = (int)[inputField integerValue];
                [inputField setStringValue:@""];
                
                string cellOutlineSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CellOutlineDrawSetting";
                
                ofstream oin;
                oin.open(cellOutlineSettingPath.c_str(), ios::out);
                
                oin<<analysisNameManualString<<endl;
                oin<<treatNameManualString<<endl;
                oin<<cutOffLevel<<endl;
                oin<<cutOffLevel2<<endl;
                oin<<cutOffLevel3<<endl;
                oin<<cutOffLevel4<<endl;
                oin<<areaLimit<<endl;
                oin<<processOption<<endl;
                
                oin.close();
                
                [areaLimitDisplay setIntegerValue:areaLimit];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                [jumpDisplay setStringValue:@"nil"];
                [inputField setStringValue:@""];
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Value Exceeds Limit"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            [jumpDisplay setStringValue:@"nil"];
            [inputField setStringValue:@""];
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Ongoing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        [jumpDisplay setStringValue:@"nil"];
        [inputField setStringValue:@""];
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Manual Disabled, Auto Enabled"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cutOffDefault:(id)sender{
    if (processSequenceFlag == 0 && allRunFlag != 1 && reprocessStatus == 0){
        cutOffLevel = 190;
        cutOffLevel2 = 150;
        cutOffLevel3 = 110;
        cutOffLevel4 = 90;
        areaLimit = 20;
        
        string cellOutlineSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CellOutlineDrawSetting";
        
        ofstream oin;
        oin.open(cellOutlineSettingPath.c_str(), ios::out);
        
        oin<<analysisNameManualString<<endl;
        oin<<treatNameManualString<<endl;
        oin<<cutOffLevel<<endl;
        oin<<cutOffLevel2<<endl;
        oin<<cutOffLevel3<<endl;
        oin<<cutOffLevel4<<endl;
        oin<<areaLimit<<endl;
        oin<<processOption<<endl;
        
        oin.close();
        
        [cutOffDisplay setIntegerValue:cutOffLevel];
        [cutOffDisplay2 setIntegerValue:cutOffLevel2];
        [cutOffDisplay3 setIntegerValue:cutOffLevel3];
        [cutOffDisplay4 setIntegerValue:cutOffLevel4];
        [areaLimitDisplay setIntegerValue:areaLimit];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        [jumpDisplay setStringValue:@"nil"];
        [inputField setStringValue:@""];
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Processing Ongoing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(int)browser:(NSBrowser *)sender numberOfRowsInColumn:(int)column{
    directoryInfoCount = 0;
    
    string entry;
    
    DIR *dir;
    struct dirent *dent;
    
    if (column == 0){
        dir = opendir(imageFolderPath.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    int findString1 = (int)entry.find("_Image");
                    
                    if (findString1 != -1){
                        if (directoryInfoCount+2 > directoryInfoLimit) [self directoryInfoUpDate];
                        
                        entry = entry.substr(0, (unsigned long)findString1);
                        arrayDirectoryInfo [directoryInfoCount] = entry, directoryInfoCount++;
                    }
                }
            }
            
            closedir(dir);
            
            //-------Directory Sort------
            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
            
            for (int counter1 = 0; counter1 < directoryInfoCount; counter1++){
                [unsortedArray addObject:@(arrayDirectoryInfo [counter1].c_str())];
            }
            
            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
            
            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                arrayDirectoryInfo [counter1] = [unsortedArray [counter1] UTF8String];
            }
        }
    }
    if (column == 1){
        NSString *path;
        path = [sender path];
        
        string imageFolderPath3 = imageFolderPath+[path UTF8String]+"_Image";
        string imageFolderPath2 = "";
        string imageNameTemp = [path UTF8String];
        
        if (imageNameTemp != ""){
            imageNameTemp = imageNameTemp.substr(1);
            
            dir = opendir(imageFolderPath3.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        int findString1 = (int)entry.find("_Stitch");
                        
                        if (findString1 != -1){
                            if (directoryInfoCount+2 > directoryInfoLimit) [self directoryInfoUpDate];
                            
                            entry = entry.substr(0, (unsigned long)findString1);
                            
                            arrayDirectoryInfo [directoryInfoCount] = entry, directoryInfoCount++;
                        }
                    }
                }
                
                closedir(dir);
                
                //-------Directory Sort------
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < directoryInfoCount; counter1++){
                    [unsortedArray addObject:@(arrayDirectoryInfo [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arrayDirectoryInfo [counter1] = [unsortedArray [counter1] UTF8String];
                }
            }
        }
    }
    
    return directoryInfoCount;
}

-(void)browser:(NSBrowser *)sender willDisplayCell:(id)cell atRow:(int)row column:(int)column{
    if (column == 0){
        string folderName = arrayDirectoryInfo [row];
        [cell setStringValue: @(folderName.c_str())];
        [cell setLoaded:YES];
    }
    if (column == 1){
        string folderName = arrayDirectoryInfo [row];
        [cell setStringValue: @(folderName.c_str())];
        [cell setLeaf:YES];
    }
}

-(IBAction)browserDoubleClick:(id)browser{
    NSString *nodePath = [browser path];
    string nodePathString = [nodePath UTF8String];
    
    if (nodePathString != "" && processSequenceFlag == 0 && allRunFlag != 1 && reprocessStatus == 0){
        nodePathString = nodePathString.substr(1);
        int findString1 = (int)nodePathString.find("/");
        
        if (findString1 != -1){
            string analysisNameHold = nodePathString.substr(0, (unsigned long)findString1);
            string treatNameHold = nodePathString.substr((unsigned long)findString1+1);
            
            if (analysisNameHold != "" && treatNameHold != ""){
                string entry;
                
                int tifBmpType = 0;
                
                string loadingImagePath = imageFolderPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Stitch";
                
                DIR *dir = opendir(loadingImagePath.c_str());
                struct dirent *dent;
                
                if (dir != NULL){
                    int imageFileNumber = 0;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if ((int)entry.find("bmp") != -1 || (int)entry.find("tif") != -1){
                            if ((int)entry.find("bmp") != -1) tifBmpType = 1;
                            else if ((int)entry.find("tif") != -1) tifBmpType = 0;
                            
                            imageFileNumber++;
                        }
                    }
                    
                    closedir(dir);
                    
                    if (imageFileNumber != 0){
                        [maxImageNo setIntegerValue:imageFileNumber];
                        
                        string *arrayImageNameFileUpload = new string [imageFileNumber+50];
                        int arrayImageNameFileUploadCount = 0;
                        
                        dir = opendir(loadingImagePath.c_str());
                        
                        if (dir != NULL){
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if ((int)entry.find("bmp") != -1 || (int)entry.find("tif") != -1) arrayImageNameFileUpload [arrayImageNameFileUploadCount] = entry, arrayImageNameFileUploadCount++;
                            }
                            
                            closedir(dir);
                            
                            //-------Directory Sort------
                            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                            
                            for (int counter1 = 0; counter1 < arrayImageNameFileUploadCount; counter1++){
                                [unsortedArray addObject:@(arrayImageNameFileUpload [counter1].c_str())];
                            }
                            
                            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                            
                            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                                arrayImageNameFileUpload [counter1] = [unsortedArray [counter1] UTF8String];
                            }
                            
                            string loadingImagePath2 = loadingImagePath+"/"+arrayImageNameFileUpload [0];
                            
                            if (tifBmpType == 0){
                                ifstream fin;
                                
                                //------Tiff reading------
                                unsigned long stripFirstAddress = 0;
                                unsigned long stripByteCountAddress = 0;
                                unsigned long nextAddress = 0;
                                unsigned long headPosition = 0;
                                unsigned long stripEntry = 0;
                                long sizeForCopy = 0;
                                
                                double xPosition = 0;
                                double yPosition = 0;
                                
                                int imageWidthTif = 0;
                                int imageHeightTif = 0;
                                int imageBit = 0; //Check 8, 16
                                int imageCompression = 0; //Check 1
                                int photoMetric = 0; //Check 0, 1, 2
                                int imageDimension = 0;
                                int verticalBmp = 0;
                                int horizontalBmp = 0;
                                int endianType = 0;
                                int samplePerPix = 0;
                                int dataConversion [4];
                                int processType = 1;
                                int numberOfLayers = 0;
                                
                                struct stat sizeOfFile;
                                
                                if (stat(loadingImagePath2.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    fileReadArray = new uint8_t [sizeForCopy+4];
                                    fin.open(loadingImagePath2.c_str(), ios::in | ios::binary);
                                    
                                    fin.read((char*)fileReadArray, sizeForCopy+4);
                                    fin.close();
                                    
                                    dataConversion [0] = fileReadArray [0];
                                    dataConversion [1] = fileReadArray [1];
                                    
                                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                    else endianType = 0;
                                    
                                    int *arrayExtractedImage3 = new int [100];
                                    
                                    headPosition = 0;
                                    
                                    if (endianType == 1){
                                        dataConversion [0] = fileReadArray [7];
                                        dataConversion [1] = fileReadArray [6];
                                        dataConversion [2] = fileReadArray [5];
                                        dataConversion [3] = fileReadArray [4];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    else if (endianType == 0){
                                        dataConversion [0] = fileReadArray [4];
                                        dataConversion [1] = fileReadArray [5];
                                        dataConversion [2] = fileReadArray [6];
                                        dataConversion [3] = fileReadArray [7];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    
                                    if (endianType == 1){
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        [tiffFileRead tiffReadLargeEndian: headPosition:&imageWidthTif:&imageHeightTif:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        
                                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                            if (imageWidthTif > imageHeightTif) imageDimension = imageWidthTif;
                                            else imageDimension = imageHeightTif;
                                            
                                            tiffFileRead = [[TiffFileRead alloc] init];
                                            delete [] arrayExtractedImage3;
                                            
                                            arrayExtractedImage3 = [tiffFileRead imageSetLargeEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                        }
                                    }
                                    else if (endianType == 0){
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        [tiffFileRead tiffReadSmallEndian: headPosition:&imageWidthTif:&imageHeightTif:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        
                                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                            if (imageWidth > imageHeightTif) imageDimension = imageWidthTif;
                                            else imageDimension = imageHeightTif;
                                            
                                            tiffFileRead = [[TiffFileRead alloc] init];
                                            delete [] arrayExtractedImage3;
                                            
                                            arrayExtractedImage3 = [tiffFileRead imageSetSmallEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                        }
                                    }
                                    
                                    imageWidth = imageWidthTif;
                                    imageHeight = imageHeightTif;
                                    
                                    if (extractImageStatus == 1){
                                        for (int counter1 = 0; counter1 < imageWidth+1; counter1++) delete [] arrayExtractedImage [counter1];
                                        delete [] arrayExtractedImage;
                                        extractImageStatus = 0;
                                    }
                                    
                                    if (imageForDisplayStatus == 1){
                                        for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
                                            delete [] imageForDisplay1 [counter1];
                                            delete [] imageForDisplay2 [counter1];
                                            delete [] imageForDisplay3 [counter1];
                                            delete [] imageForDisplay4 [counter1];
                                        }
                                        
                                        delete [] imageForDisplay1;
                                        delete [] imageForDisplay2;
                                        delete [] imageForDisplay3;
                                        delete [] imageForDisplay4;
                                        
                                        imageForDisplayStatus = 0;
                                    }
                                    
                                    if (extractImageStatus == 0) extractImageStatus = 1;
                                    if (imageForDisplayStatus == 0) imageForDisplayStatus = 1;
                                    
                                    arrayExtractedImage = new int *[imageWidth+1];
                                    imageForDisplay1 = new int *[imageWidth+1];
                                    imageForDisplay2 = new int *[imageWidth+1];
                                    imageForDisplay3 = new int *[imageWidth+1];
                                    imageForDisplay4 = new int *[imageWidth+1];
                                    
                                    for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
                                        arrayExtractedImage [counter1] = new int [imageWidth+1];
                                        imageForDisplay1 [counter1] = new int [imageWidth+1];
                                        imageForDisplay2 [counter1] = new int [imageWidth+1];
                                        imageForDisplay3 [counter1] = new int [imageWidth+1];
                                        imageForDisplay4 [counter1] = new int [imageWidth+1];
                                    }
                                    
                                    horizontalBmp = 0;
                                    verticalBmp = 0;
                                    
                                    for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                        if (horizontalBmp < imageWidth){
                                            if (arrayExtractedImage3 [counter3] >= cutOffLevel && arrayExtractedImage3 [counter3] != 100) imageForDisplay1 [verticalBmp][horizontalBmp] = 220;
                                            else imageForDisplay1 [verticalBmp][horizontalBmp] = 0;
                                            
                                            if (arrayExtractedImage3 [counter3] >= cutOffLevel2 && arrayExtractedImage3 [counter3] != 100) imageForDisplay2 [verticalBmp][horizontalBmp] = 220;
                                            else imageForDisplay2 [verticalBmp][horizontalBmp] = 0;
                                            
                                            if (arrayExtractedImage3 [counter3] >= cutOffLevel3 && arrayExtractedImage3 [counter3] != 100) imageForDisplay3 [verticalBmp][horizontalBmp] = 220;
                                            else imageForDisplay3 [verticalBmp][horizontalBmp] = 0;
                                            
                                            if (arrayExtractedImage3 [counter3] >= cutOffLevel4 && arrayExtractedImage3 [counter3] != 100) imageForDisplay4 [verticalBmp][horizontalBmp] = 220;
                                            else imageForDisplay4 [verticalBmp][horizontalBmp] = 0;
                                            
                                            arrayExtractedImage [verticalBmp][horizontalBmp] = arrayExtractedImage3 [counter3];
                                            
                                            horizontalBmp++;
                                        }
                                        
                                        if (horizontalBmp == imageWidth){
                                            horizontalBmp = 0;
                                            verticalBmp++;
                                        }
                                    }
                                    
                                    delete [] fileReadArray;
                                    delete [] arrayExtractedImage3;
                                }
                                
                                if (imageWidth != 0){
                                    analysisNameManualString = analysisNameHold;
                                    treatNameManualString = treatNameHold;
                                    
                                    [analysisNameManual setStringValue:@(analysisNameManualString.c_str())];
                                    [treatNameManual setStringValue:@(treatNameManualString.c_str())];
                                    
                                    imageNameFileListCount = 0;
                                    
                                    dir = opendir(loadingImagePath.c_str());
                                    
                                    if (dir != NULL){
                                        while ((dent = readdir(dir))){
                                            entry = dent -> d_name;
                                            
                                            if ((int)entry.find("bmp") != -1 || (int)entry.find("tif") != -1) imageNameFileListCount++;
                                        }
                                        
                                        closedir(dir);
                                    }
                                    
                                    string cellOutlineSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CellOutlineDrawSetting";
                                    
                                    ofstream oin;
                                    oin.open(cellOutlineSettingPath.c_str(), ios::out);
                                    
                                    oin<<analysisNameManualString<<endl;
                                    oin<<treatNameManualString<<endl;
                                    oin<<cutOffLevel<<endl;
                                    oin<<cutOffLevel2<<endl;
                                    oin<<cutOffLevel3<<endl;
                                    oin<<cutOffLevel4<<endl;
                                    oin<<areaLimit<<endl;
                                    oin<<processOption<<endl;
                                    
                                    oin.close();
                                    
                                    [imageSize setIntegerValue:imageWidth];
                                    [analysisNameDisplay setStringValue:@(analysisNameManualString.c_str())];
                                    [treatNameDisplay setStringValue:@(treatNameManualString.c_str())];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                    
                                    if (imageFirstLoadFlag == 1){
                                        displayImageNumber = 1;
                                        lineDataForDisplayCount6 = 0;
                                        lineDataForDisplayCount7 = 0;
                                        lineDataForDisplayCount8 = 0;
                                        lineDataForDisplayCount9 = 0;
                                        
                                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSourceImage object:self];
                                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCellImage object:self];
                                    }
                                    
                                    loadingImagePath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Processed";
                                    string extractString;
                                    string outlineRangeString;
                                    
                                    dir = opendir(loadingImagePath.c_str());
                                    
                                    if (dir != NULL){
                                        int imageNumber = 0;
                                        
                                        while ((dent = readdir(dir))){
                                            entry = dent -> d_name;
                                            findString1 = (int)entry.length();
                                            
                                            if (findString1 > 4){
                                                extractString = entry.substr(0, 4);
                                                
                                                if (atoi(extractString.c_str()) > imageNumber) imageNumber = atoi(extractString.c_str());
                                            }
                                        }
                                        
                                        closedir(dir);
                                        
                                        string extension = to_string(imageNumber);
                                        outlineRangeString = "1-"+extension;
                                    }
                                    else outlineRangeString = "0";
                                    
                                    [outlineRange setStringValue:@(outlineRangeString.c_str())];
                                    
                                    if (treatmentSelectListStatus == 0){
                                        treatmentSelectList = new string [40];
                                        treatmentSelectListStatus = 1;
                                        treatmentSelectListCount = 0;
                                    }
                                    else treatmentSelectListCount = 0;
                                    
                                    loadingImagePath = imageFolderPath+"/"+analysisNameManualString+"_Image/";
                                    
                                    dir = opendir(loadingImagePath.c_str());
                                    
                                    if (dir != NULL){
                                        while ((dent = readdir(dir))){
                                            entry = dent -> d_name;
                                            
                                            if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("_Stitch") != -1){
                                                treatmentSelectList [treatmentSelectListCount] = entry.substr(0, entry.find("_Stitch")), treatmentSelectListCount++;
                                                treatmentSelectList [treatmentSelectListCount] = entry.substr(0, entry.find("_Stitch")), treatmentSelectListCount++;
                                            }
                                        }
                                        
                                        closedir(dir);
                                        
                                        //-------Directory Sort------
                                        NSMutableArray *unsortedArray2 = [[NSMutableArray alloc] init];
                                        
                                        for (int counter1 = 0; counter1 < treatmentSelectListCount; counter1++){
                                            [unsortedArray2 addObject:@(treatmentSelectList [counter1].c_str())];
                                        }
                                        
                                        [unsortedArray2 sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                                        
                                        for (NSUInteger counter1 = 0; counter1 < [unsortedArray2 count]; counter1++){
                                            treatmentSelectList [counter1] = [unsortedArray2 [counter1] UTF8String];
                                        }
                                        
                                        for (int counter1 = 0; counter1 < treatmentSelectListCount/2; counter1++){
                                            treatmentSelectList [counter1*2] = "1";
                                        }
                                    }
                                    
                                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTreatList object:self];
                                }
                                else{
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"Image File Missing"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                            }
                            else if (tifBmpType == 1){
                                ifstream fin;
                                fin.open(loadingImagePath2.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    if (extractImageStatus == 1){
                                        for (int counter1 = 0; counter1 < imageWidth+1; counter1++) delete [] arrayExtractedImage [counter1];
                                        delete [] arrayExtractedImage;
                                        extractImageStatus = 0;
                                    }
                                    
                                    if (imageForDisplayStatus == 1){
                                        for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
                                            delete [] imageForDisplay1 [counter1];
                                            delete [] imageForDisplay2 [counter1];
                                            delete [] imageForDisplay3 [counter1];
                                            delete [] imageForDisplay4 [counter1];
                                        }
                                        
                                        delete [] imageForDisplay1;
                                        delete [] imageForDisplay2;
                                        delete [] imageForDisplay3;
                                        delete [] imageForDisplay4;
                                        
                                        imageForDisplayStatus = 0;
                                    }
                                    
                                    unsigned long bitPosition = 0;
                                    int bitData = 0;
                                    int horizontalBit [4] = {0,0,0,0};
                                    int verticalBit [4] = {0,0,0,0};
                                    imageWidth = 0;
                                    imageHeight = 0;
                                    
                                    while ((bitData = fin.get()) != EOF){
                                        if (bitPosition == 18) horizontalBit [0] = bitData;
                                        if (bitPosition == 19) horizontalBit [1] = bitData;
                                        if (bitPosition == 20) horizontalBit [2] = bitData;
                                        if (bitPosition == 21) horizontalBit [3] = bitData;
                                        if (bitPosition == 22) verticalBit [0] = bitData;
                                        if (bitPosition == 23) verticalBit [1] = bitData;
                                        if (bitPosition == 24) verticalBit [2] = bitData;
                                        if (bitPosition == 25){
                                            verticalBit [3] = bitData;
                                            
                                            imageWidth = horizontalBit [3]*16777216+horizontalBit [2]*65536+horizontalBit [1]*256+horizontalBit [0];
                                            imageHeight = verticalBit [3]*16777216+verticalBit [2]*65536+verticalBit [1]*256+verticalBit [0];
                                            break;
                                        }
                                        
                                        bitPosition++;
                                    }
                                    
                                    fin.close();
                                    
                                    if (imageWidth != 0){
                                        analysisNameManualString = analysisNameHold;
                                        treatNameManualString = treatNameHold;
                                        
                                        [analysisNameManual setStringValue:@(analysisNameManualString.c_str())];
                                        [treatNameManual setStringValue:@(treatNameManualString.c_str())];
                                        
                                        imageNameFileListCount = 0;
                                        
                                        dir = opendir(loadingImagePath.c_str());
                                        
                                        if (dir != NULL){
                                            while ((dent = readdir(dir))){
                                                entry = dent -> d_name;
                                                
                                                if ((int)entry.find("bmp") != -1 || (int)entry.find("tif") != -1) imageNameFileListCount++;
                                            }
                                            
                                            closedir(dir);
                                        }
                                        
                                        string cellOutlineSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CellOutlineDrawSetting";
                                        
                                        ofstream oin;
                                        oin.open(cellOutlineSettingPath.c_str(), ios::out);
                                        
                                        oin<<analysisNameManualString<<endl;
                                        oin<<treatNameManualString<<endl;
                                        oin<<cutOffLevel<<endl;
                                        oin<<cutOffLevel2<<endl;
                                        oin<<cutOffLevel3<<endl;
                                        oin<<cutOffLevel4<<endl;
                                        oin<<areaLimit<<endl;
                                        oin<<processOption<<endl;
                                        
                                        oin.close();
                                        
                                        [imageSize setIntegerValue:imageWidth];
                                        [analysisNameDisplay setStringValue:@(analysisNameManualString.c_str())];
                                        [treatNameDisplay setStringValue:@(treatNameManualString.c_str())];
                                        
                                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                                        [sound play];
                                        
                                        if (imageFirstLoadFlag == 1){
                                            fin.open(loadingImagePath2.c_str(), ios::in | ios::binary);
                                            
                                            if (fin.is_open()){
                                                fin.close();
                                                
                                                if (extractImageStatus == 0) extractImageStatus = 1;
                                                if (imageForDisplayStatus == 0) imageForDisplayStatus = 1;
                                                
                                                arrayExtractedImage = new int *[imageWidth+1];
                                                imageForDisplay1 = new int *[imageWidth+1];
                                                imageForDisplay2 = new int *[imageWidth+1];
                                                imageForDisplay3 = new int *[imageWidth+1];
                                                imageForDisplay4 = new int *[imageWidth+1];
                                                
                                                for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
                                                    arrayExtractedImage [counter1] = new int [imageWidth+1];
                                                    imageForDisplay1 [counter1] = new int [imageWidth+1];
                                                    imageForDisplay2 [counter1] = new int [imageWidth+1];
                                                    imageForDisplay3 [counter1] = new int [imageWidth+1];
                                                    imageForDisplay4 [counter1] = new int [imageWidth+1];
                                                }
                                                
                                                long sizeForCopy = 0;
                                                int imageDimensionCount = 0;
                                                
                                                struct stat sizeOfFile;
                                                
                                                if (stat(loadingImagePath2.c_str(), &sizeOfFile) == 0){
                                                    sizeForCopy = sizeOfFile.st_size;
                                                    
                                                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+4];
                                                    fin.open(loadingImagePath2.c_str(), ios::in | ios::binary);
                                                    
                                                    if (fin.is_open()){
                                                        fin.read((char*)uploadTemp, sizeForCopy+1);
                                                        fin.close();
                                                        
                                                        for (int counter1 = imageHeight-1; counter1 >= 0; counter1--){
                                                            for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                                                bitData = uploadTemp [1078+counter1*imageHeight+counter2];
                                                                
                                                                if (bitData >= cutOffLevel && bitData != 100) imageForDisplay1 [imageDimensionCount][counter2] = 220;
                                                                else imageForDisplay1 [imageDimensionCount][counter2] = 0;
                                                                
                                                                if (bitData >= cutOffLevel2 && bitData != 100) imageForDisplay2 [imageDimensionCount][counter2] = 220;
                                                                else imageForDisplay2 [imageDimensionCount][counter2] = 0;
                                                                
                                                                if (bitData >= cutOffLevel3 && bitData != 100) imageForDisplay3 [imageDimensionCount][counter2] = 220;
                                                                else imageForDisplay3 [imageDimensionCount][counter2] = 0;
                                                                
                                                                if (bitData >= cutOffLevel4 && bitData != 100) imageForDisplay4 [imageDimensionCount][counter2] = 220;
                                                                else imageForDisplay4 [imageDimensionCount][counter2] = 0;
                                                                
                                                                arrayExtractedImage [imageDimensionCount][counter2] = bitData;
                                                            }
                                                            
                                                            imageDimensionCount++;
                                                        }
                                                    }
                                                    
                                                    delete [] uploadTemp;
                                                }
                                            }
                                            
                                            displayImageNumber = 1;
                                            lineDataForDisplayCount6 = 0;
                                            lineDataForDisplayCount7 = 0;
                                            lineDataForDisplayCount8 = 0;
                                            lineDataForDisplayCount9 = 0;
                                            
                                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSourceImage object:self];
                                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCellImage object:self];
                                        }
                                        
                                        loadingImagePath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Processed";
                                        string extractString;
                                        string outlineRangeString;
                                        
                                        dir = opendir(loadingImagePath.c_str());
                                        
                                        if (dir != NULL){
                                            int imageNumber = 0;
                                            
                                            while ((dent = readdir(dir))){
                                                entry = dent -> d_name;
                                                findString1 = (int)entry.length();
                                                
                                                if (findString1 > 4){
                                                    extractString = entry.substr(0, 4);
                                                    
                                                    if (atoi(extractString.c_str()) > imageNumber) imageNumber = atoi(extractString.c_str());
                                                }
                                            }
                                            
                                            closedir(dir);
                                            
                                            string extension = to_string(imageNumber);
                                            outlineRangeString = "1-"+extension;
                                            
                                        }
                                        else outlineRangeString = "0";
                                        
                                        [outlineRange setStringValue:@(outlineRangeString.c_str())];
                                        
                                        if (treatmentSelectListStatus == 0){
                                            treatmentSelectList = new string [40];
                                            treatmentSelectListStatus = 1;
                                            treatmentSelectListCount = 0;
                                        }
                                        else treatmentSelectListCount = 0;
                                        
                                        loadingImagePath = imageFolderPath+"/"+analysisNameManualString+"_Image/";
                                        
                                        dir = opendir(loadingImagePath.c_str());
                                        
                                        if (dir != NULL){
                                            while ((dent = readdir(dir))){
                                                entry = dent -> d_name;
                                                
                                                if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("_Stitch") != -1){
                                                    treatmentSelectList [treatmentSelectListCount] = entry.substr(0, entry.find("_Stitch")), treatmentSelectListCount++;
                                                    treatmentSelectList [treatmentSelectListCount] = entry.substr(0, entry.find("_Stitch")), treatmentSelectListCount++;
                                                }
                                            }
                                            
                                            closedir(dir);
                                            
                                            //-------Directory Sort------
                                            NSMutableArray *unsortedArray2 = [[NSMutableArray alloc] init];
                                            
                                            for (int counter1 = 0; counter1 < treatmentSelectListCount; counter1++){
                                                [unsortedArray2 addObject:@(treatmentSelectList [counter1].c_str())];
                                            }
                                            
                                            [unsortedArray2 sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                                            
                                            for (NSUInteger counter1 = 0; counter1 < [unsortedArray2 count]; counter1++){
                                                treatmentSelectList [counter1] = [unsortedArray2 [counter1] UTF8String];
                                            }
                                            
                                            for (int counter1 = 0; counter1 < treatmentSelectListCount/2; counter1++){
                                                treatmentSelectList [counter1*2] = "1";
                                            }
                                        }
                                        
                                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTreatList object:self];
                                    }
                                    else{
                                        
                                        NSAlert *alert = [[NSAlert alloc] init];
                                        [alert addButtonWithTitle:@"OK"];
                                        [alert setMessageText:@"Image File Missing"];
                                        [alert setAlertStyle:NSAlertStyleWarning];
                                        [alert runModal];
                                        
                                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                                        [sound play];
                                    }
                                }
                                else{
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"Directory Unavailable"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                            }
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Directory Unavailable"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                        
                        delete [] arrayImageNameFileUpload;
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Image File Absent"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Directory Unavailable"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Image Unavailable"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Missing Image Folder"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(void)wholeImageUpDate{
    string *arrayUpDate = new string [wholeImageCount+10];
    
    for (int counter1 = 0; counter1 < wholeImageCount; counter1++) arrayUpDate [counter1] = arrayWholeImage [counter1];
    
    delete [] arrayWholeImage;
    arrayWholeImage = new string [wholeImageLimit+5000];
    wholeImageLimit = wholeImageLimit+5000;
    
    for (int counter1 = 0; counter1 < wholeImageCount; counter1++) arrayWholeImage [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)directoryInfoUpDate{
    string *arrayUpDate = new string [directoryInfoCount+10];
    
    for (int counter1 = 0; counter1 < directoryInfoCount; counter1++) arrayUpDate [counter1] = arrayDirectoryInfo [counter1];
    
    delete [] arrayDirectoryInfo;
    arrayDirectoryInfo = new string [directoryInfoLimit+500];
    directoryInfoLimit = directoryInfoLimit+500;
    
    for (int counter1 = 0; counter1 < directoryInfoCount; counter1++) arrayDirectoryInfo [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(IBAction)processOptionSet:(id)browser{
    if (runMode == 1 && autoRunStatus == 0){
        if (processSequenceFlag == 0 && allRunFlag != 1 && reprocessStatus == 0){
            string cellOutlineSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CellOutlineDrawSetting";
            
            if (processOption == 0){
                processOption = 1;
                
                ofstream oin;
                oin.open(cellOutlineSettingPath.c_str(), ios::out);
                
                oin<<analysisNameManualString<<endl;
                oin<<treatNameManualString<<endl;
                oin<<cutOffLevel<<endl;
                oin<<cutOffLevel2<<endl;
                oin<<cutOffLevel3<<endl;
                oin<<cutOffLevel4<<endl;
                oin<<areaLimit<<endl;
                oin<<processOption<<endl;
                
                oin.close();
                
                [optionDisplay setStringValue:@"Treatment"];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else if (processOption == 1){
                processOption = 0;
                
                ofstream oin;
                oin.open(cellOutlineSettingPath.c_str(), ios::out);
                
                oin<<analysisNameManualString<<endl;
                oin<<treatNameManualString<<endl;
                oin<<cutOffLevel<<endl;
                oin<<cutOffLevel2<<endl;
                oin<<cutOffLevel3<<endl;
                oin<<cutOffLevel4<<endl;
                oin<<areaLimit<<endl;
                oin<<processOption<<endl;
                
                oin.close();
                
                [optionDisplay setStringValue:@"Time"];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Ongoing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Manual Disabled, Auto Enabled"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)processDataRemove:(id)browser{
    if (runMode == 1 && autoRunStatus == 0){
        if (processSequenceFlag == 0 && allRunFlag != 1 && reprocessStatus == 0){
            if ([inputField integerValue] > 0){
                int cutImageNumber = (int)[inputField integerValue];
                
                [inputField setStringValue:@""];
                
                int proceedingFlag = 0;
                int imageNumber = 0;
                
                string loadingImagePath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Processed";
                string entry;
                string extractString;
                
                DIR *dir = opendir(loadingImagePath.c_str());
                struct dirent *dent;
                
                if (dir != NULL){
                    int findString1 = 0;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        findString1 = (int)entry.length();
                        
                        if (findString1 > 4){
                            extractString = entry.substr(0, 4);
                            imageNumber = atoi(extractString.c_str());
                            
                            if (imageNumber >= cutImageNumber){
                                proceedingFlag = 1;
                                break;
                            }
                        }
                    }
                    
                    closedir(dir);
                    
                    if (proceedingFlag == 1){
                        string extension = "Remove Outline Data >= "+to_string(imageNumber);
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert addButtonWithTitle:@"Cancel"];
                        [alert setMessageText:@(extension.c_str())];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        
                        if ([alert runModal] == NSAlertFirstButtonReturn){
                            string removeFile;
                            
                            dir = opendir(loadingImagePath.c_str());
                            
                            if (dir != NULL){
                                string *arrayFileDelete = new string [500];
                                int fileDeleteCount = 0;
                                int fileDeleteLimit = 0;
                                
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (fileDeleteCount+5 > fileDeleteLimit){
                                        string *arrayUpDate = new string [fileDeleteCount+10];
                                        
                                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
                                        
                                        delete [] arrayFileDelete;
                                        arrayFileDelete = new string [fileDeleteLimit+500];
                                        fileDeleteLimit = fileDeleteLimit+500;
                                        
                                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                                }
                                
                                closedir(dir);
                                
                                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                    entry = arrayFileDelete [counter1];
                                    
                                    findString1 = (int)entry.length();
                                    
                                    if (findString1 > 4){
                                        extractString = entry.substr(0, 4);
                                        
                                        if (atoi(extractString.c_str()) >= cutImageNumber){
                                            removeFile = loadingImagePath+"/"+entry;
                                            remove (removeFile .c_str());
                                        }
                                    }
                                }
                                
                                delete [] arrayFileDelete;
                                
                                [removeNumber setIntegerValue:cutImageNumber];
                                
                                loadingImagePath = imageFolderPath+"/"+analysisNameManualString+"_Image/"+treatNameManualString+"_Processed";
                                string outlineRangeString;
                                
                                dir = opendir(loadingImagePath.c_str());
                                
                                if (dir != NULL){
                                    int imageNumber2 = 0;
                                    
                                    while ((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        findString1 = (int)entry.length();
                                        
                                        if (findString1 > 4){
                                            extractString = entry.substr(0, 4);
                                            
                                            if (atoi(extractString.c_str()) > imageNumber2) imageNumber2 = atoi(extractString.c_str());
                                        }
                                    }
                                    
                                    closedir(dir);
                                    
                                    outlineRangeString = "1-"+to_string(imageNumber2);
                                }
                                else outlineRangeString = "0";
                                
                                [outlineRange setStringValue:@(outlineRangeString.c_str())];
                                
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                            }
                            else{
                                
                                [removeNumber setStringValue:@"nil"];
                                
                                NSAlert *alert2 = [[NSAlert alloc] init];
                                [alert2 addButtonWithTitle:@"OK"];
                                [alert2 setMessageText:@"Folder Not Found"];
                                [alert2 setAlertStyle:NSAlertStyleWarning];
                                [alert2 runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                    }
                    else{
                        
                        [removeNumber setStringValue:@"nil"];
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"File Missing"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    [removeNumber setStringValue:@"nil"];
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"No Processed Folder"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                [removeNumber setStringValue:@"nil"];
                [inputField setStringValue:@""];
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"File Number Exceeds Limit"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            [removeNumber setStringValue:@"nil"];
            [inputField setStringValue:@""];
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Ongoing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        [removeNumber setStringValue:@"nil"];
        [inputField setStringValue:@""];
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Manual Disabled, Auto Enabled"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)processStopSub:(id)sender{
    if (runMode != 3){
        if (processSequenceFlag == 0 && allRunFlag != 1 && reprocessStatus == 0){
            [self processStop];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Ongoing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Manual Mode Unset"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)processStop{
    if (extractImageStatus == 1){
        extractImageStatus = 0;
        
        for (int counter1 = 0; counter1 < imageWidth+1; counter1++) delete [] arrayExtractedImage [counter1];
        delete [] arrayExtractedImage;
    }
    
    if (imageForDisplayStatus == 1){
        for (int counter1 = 0; counter1 < imageWidth+1; counter1++){
            delete [] imageForDisplay1 [counter1];
            delete [] imageForDisplay2 [counter1];
            delete [] imageForDisplay3 [counter1];
            delete [] imageForDisplay4 [counter1];
        }
        
        delete [] imageForDisplay1;
        delete [] imageForDisplay2;
        delete [] imageForDisplay3;
        delete [] imageForDisplay4;
    }
    
    if (lineDataForDisplayStatus6 == 1) delete [] arrayLineDataForDisplay6;
    if (lineDataForDisplayStatus7 == 1) delete [] arrayLineDataForDisplay7;
    if (lineDataForDisplayStatus8 == 1) delete [] arrayLineDataForDisplay8;
    if (lineDataForDisplayStatus9 == 1) delete [] arrayLineDataForDisplay9;
    
    delete [] arrayWholeImage;
    delete [] arrayDirectoryInfo;
    delete [] thresholdDataHold;
    
    if (treatmentSelectListStatus == 1) delete [] treatmentSelectList;
    exit (0);
}

-(void)controlTextDidChange:(NSNotification *)aNotification {
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]) {
        if ([aNotification object] == reprocessFromDisplay && reprocessStatus == 0){
            if ([reprocessFromDisplay intValue] >= 1 && [reprocessFromDisplay intValue] <= imageNameFileListCount){
                [stepperFrom setIntValue:[reprocessFromDisplay intValue]];
                processingFromHold = [reprocessFromDisplay intValue];
            }
        }
        
        if ([aNotification object] == reprocessToDisplay && reprocessStatus == 0){
            if ([reprocessToDisplay intValue] >= 1 && [reprocessToDisplay intValue] <= imageNameFileListCount){
                [stepperTo setIntValue:[reprocessToDisplay intValue]];
                processingToHold = [reprocessToDisplay intValue];
            }
        }
    }
}

-(IBAction)stepperActionFrom:(id)sender{
    if ([stepperFrom intValue] >= 1 && [stepperFrom intValue] <= imageNameFileListCount && reprocessStatus == 0){
        [reprocessFromDisplay setIntValue:[stepperFrom intValue]];
        processingFromHold = [stepperFrom intValue];
    }
}

-(IBAction)stepperActionTo:(id)sender{
    if ([stepperTo intValue] >= 1 && [stepperTo intValue] <= imageNameFileListCount && reprocessStatus == 0){
        [reprocessToDisplay setIntValue:[stepperTo intValue]];
        processingToHold = [stepperTo intValue];
    }
}

-(IBAction)reProcessingSet:(id)sender{
    if (runMode == 1 && autoRunStatus == 0){
        if (processSequenceFlag == 0 && allRunFlag != 1){
            if (reprocessStatus == 0){
                if (processingFromHold == 0 || processingToHold == 0){
                    [reprocessFromDisplay setIntegerValue:0];
                    [reprocessToDisplay setIntegerValue:0];
                    [stepperFrom setIntValue:0];
                    [stepperTo setIntValue:0];
                    
                    processingFromHold = 0;
                    processingToHold = 0;
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                else if (processingFromHold >= processingToHold || processingFromHold+1 == processingToHold){
                    [reprocessFromDisplay setIntegerValue:0];
                    [reprocessToDisplay setIntegerValue:0];
                    [stepperFrom setIntValue:0];
                    [stepperTo setIntValue:0];
                    
                    processingFromHold = 0;
                    processingToHold = 0;
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                else{
                    
                    int fileNoTemp = 0;
                    
                    DIR *dir;
                    struct dirent *dent;
                    DIR *dir2;
                    struct dirent *dent2;
                    DIR *dir3;
                    struct dirent *dent3;
                    
                    dir = opendir(imageFolderPath.c_str());
                    
                    if (dir != NULL){
                        string entry;
                        string entry2;
                        string entry3;
                        string productDataPath1;
                        string productDataPath2;
                        string productDataPath3;
                        string fileNoCheckTemp;
                        
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            productDataPath1 = imageFolderPath+"/"+entry;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(analysisNameManualString) != -1){
                                dir2 = opendir(productDataPath1.c_str());
                                
                                if (dir2 != NULL){
                                    while ((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && (int)entry2.find("_Stitch") != -1){
                                            productDataPath2 = productDataPath1+"/"+entry2;
                                            
                                            dir3 = opendir(productDataPath2.c_str());
                                            
                                            if (dir3 != NULL){
                                                while ((dent3 = readdir(dir3))){
                                                    entry3 = dent3 -> d_name;
                                                    
                                                    if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store" && (int)entry3.find("STimage ") != -1){
                                                        fileNoCheckTemp = entry3.substr(entry3.find("STimage ")+8, 4);
                                                        
                                                        if (atoi(fileNoCheckTemp.c_str()) > fileNoTemp) fileNoTemp = atoi(fileNoCheckTemp.c_str());
                                                    }
                                                }
                                                
                                                closedir(dir3);
                                            }
                                        }
                                    }
                                    
                                    closedir(dir2);
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    int processingFromSet = 0;
                    int processingToSet = 0;
                    
                    if (processingToHold <= fileNoTemp){
                        processingFromSet = processingFromHold;
                        processingToSet = processingToHold;
                    }
                    else if (processingToHold > fileNoTemp && processingFromHold < fileNoTemp && processingFromHold+1 < fileNoTemp){
                        processingFromSet = processingToHold;
                        processingToSet = fileNoTemp;
                    }
                    else{
                        
                        [reprocessFromDisplay setIntegerValue:0];
                        [reprocessToDisplay setIntegerValue:0];
                        [stepperFrom setIntValue:0];
                        [stepperTo setIntValue:0];
                        
                        processingFromHold = 0;
                        processingToHold = 0;
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    
                    if (processingFromSet != 0 && processingToSet != 0){
                        processingFromHold = processingFromSet;
                        processingToHold = processingToSet;
                        
                        ifstream fin;
                        
                        string *treatmentList = new string [100];
                        int treatmentListCount = 0;
                        
                        wholeImageCount = 0;
                        remainingImages = 0;
                        
                        string loadingImagePath;
                        
                        loadingImagePath = imageFolderPath+"/"+analysisNameManualString+"_Image";
                        
                        int fileNumber = 0;
                        
                        dir = opendir(loadingImagePath.c_str());
                        
                        if (dir != NULL){
                            int findString1 = 0;
                            string entry;
                            string entry2;
                            string nameExtract;
                            string imageFilePath;
                            string numberExtract;
                            
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if ((findString1 = (int)entry.find("_Stitch")) != -1){
                                    nameExtract = entry.substr(0, (unsigned long)findString1);
                                    
                                    treatmentList [treatmentListCount] = nameExtract, treatmentListCount++;
                                    imageFilePath = loadingImagePath+"/"+entry;
                                    
                                    dir2 = opendir(imageFilePath.c_str());
                                    
                                    if (dir2 != NULL){
                                        while ((dent2 = readdir(dir2))){
                                            entry2 = dent2 -> d_name;
                                            
                                            if ((findString1 = (int)entry2.find("bmp")) != -1 || (findString1 = (int)entry2.find("tif")) != -1){
                                                numberExtract = entry2.substr((unsigned long)findString1-5, 4);
                                                
                                                if (fileNumber < atoi(numberExtract.c_str())) fileNumber = atoi(numberExtract.c_str());
                                            }
                                        }
                                        
                                        closedir(dir2);
                                    }
                                }
                            }
                            
                            closedir(dir);
                        }
                        
                        //------Whole image process status check, read not processed image point into an array 1. Treatment Name, 2. ImageNo------
                        string nameString;
                        string extension;
                        string sourceImagePath;
                        string processImagePath;
                        
                        wholeImageCount = 0;
                        
                        for (int counter1 = 0; counter1 < treatmentListCount; counter1++){
                            nameString = treatmentList [counter1];
                            
                            for (int counter2 = 1; counter2 <= fileNumber; counter2++){
                                if (counter2 >= processingFromHold && counter2 <= processingToHold){
                                    extension = to_string(counter2);
                                    
                                    if (extension.length() == 1) extension = "000"+extension;
                                    else if (extension.length() == 2) extension = "00"+extension;
                                    else if (extension.length() == 3) extension = "0"+extension;
                                    
                                    sourceImagePath = loadingImagePath+"/"+nameString+"_Stitch"+"/STimage "+extension+".tif";
                                    
                                    fin.open(sourceImagePath.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.close();
                                    }
                                    else sourceImagePath = loadingImagePath+"/"+nameString+"_Stitch"+"/STimage "+extension+".bmp";
                                    
                                    fin.open(sourceImagePath.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        if (wholeImageCount+5 > wholeImageLimit) [self wholeImageUpDate];
                                        
                                        arrayWholeImage [wholeImageCount] = nameString, wholeImageCount++;
                                        arrayWholeImage [wholeImageCount] = extension, wholeImageCount++;
                                        
                                        fin.close();
                                    }
                                }
                            }
                            
                            remainingImages = wholeImageCount/2;
                        }
                        
                        for (int counter1 = 0; counter1 < wholeImageCount/2; counter1++){
                            for (int counter2 = 0; counter2 < treatmentSelectListCount/2; counter2++){
                                if (arrayWholeImage [counter1*2] == treatmentSelectList [counter2*2+1] && treatmentSelectList [counter2*2] == "0"){
                                    arrayWholeImage [counter1*2] = "0";
                                    arrayWholeImage [counter1*2+1] = "0";
                                }
                            }
                        }
                        
                        delete [] treatmentList;
                        
                        reprocessImageNo = 1;
                        reprocessStatus = 1;
                        
                        [stepperFrom setIntValue:processingFromHold];
                        [stepperTo setIntValue:processingToHold];
                        [reprocessFromDisplay setIntegerValue:processingFromHold];
                        [reprocessToDisplay setIntegerValue:processingToHold];
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                }
            }
            else if (reprocessStatus == 1){
                reprocessStatus = 2;
                [reprocessNoDisplay setStringValue:@"Wait"];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Processing Ongoing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Manual Disabled, Auto Enabled"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)dealloc{
    if (controllerTimer) [controllerTimer invalidate];
}

@end
