//
// GapFill.mm
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 20/12/12.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#import "GapFill.h"

@implementation GapFill

-(void)gapFilling:(int)originX :(int)originY :(int)destinationX :(int)destinationY{
    int xDistance = destinationX-originX;
    int yDistance = destinationY-originY;
    int xIncrement = 0;
    int yIncrement = 0;
    int xLinear = 0;
    int yLinear = 0;
    int remaining = 0;
    int numberOfPixTemp = 0;
    
    if (abs(xDistance) >= abs(yDistance)){
        numberOfPixTemp = abs(xDistance)-1;
        
        if (yDistance != 0){
            xIncrement = abs(xDistance)/abs(yDistance);
            remaining = abs(xDistance)%abs(yDistance);
        }
        else{
            
            xIncrement = abs(xDistance);
            xLinear = 1;
        }
    }
    if (abs(xDistance) < abs(yDistance)){
        numberOfPixTemp = abs(yDistance)-1;
        
        if (xDistance != 0){
            yIncrement = abs(yDistance)/abs(xDistance);
            remaining = abs(yDistance)%abs(xDistance);
        }
        else{
            
            yIncrement = abs(yDistance);
            yLinear = 1;
        }
    }
    
    int **pixValueTemp2 = new int *[numberOfPixTemp+1];
    for (int counter1 = 0; counter1 < numberOfPixTemp+1; counter1++) pixValueTemp2 [counter1] = new int [3];
    
    int remainingAddCount = abs(remaining);
    int xDistanceTemp = originX;
    int yDistanceTemp = originY;
    
    if (xIncrement != 0 && yIncrement == 0){
        int incrementSet = 0;
        int xincrementCount = 0;
        int yincrementCount = 0;
        int addCountFlag = 0;
        
        if (xDistance < 0) xincrementCount = -1;
        else xincrementCount = 1;
        
        if (yDistance < 0) yincrementCount = -1;
        else if (xLinear == 1) yincrementCount = 0;
        else yincrementCount = 1;
        
        for (int counter1 = 0; counter1 < numberOfPixTemp; counter1++){
            pixValueTemp2 [counter1][0] = xDistanceTemp+xincrementCount;
            pixValueTemp2 [counter1][1] = yDistanceTemp+yincrementCount;
            incrementSet++;
            
            if (incrementSet == abs(xIncrement)){
                if (remainingAddCount != 0 && addCountFlag == 0){
                    incrementSet = incrementSet-1;
                    remainingAddCount = remainingAddCount-1;
                    addCountFlag = 1;
                }
                else{
                    
                    incrementSet = 0;
                    addCountFlag = 0;
                    
                    if (yDistance < 0) yincrementCount = yincrementCount-1;
                    else if (xLinear == 1) yincrementCount = 0;
                    else yincrementCount++;
                }
            }
            if (xDistance < 0) xincrementCount = xincrementCount-1;
            else xincrementCount++;
        }
    }
    
    if (xIncrement == 0 && yIncrement != 0){
        int incrementSet = 0;
        int xincrementCount = 0;
        int yincrementCount = 0;
        int addCountFlag = 0;
        
        if (xDistance < 0) xincrementCount = -1;
        else if (yLinear == 1) xincrementCount = 0;
        else xincrementCount = 1;
        
        if (yDistance < 0) yincrementCount = -1;
        else yincrementCount = 1;
        
        for (int counter1 = 0; counter1 < numberOfPixTemp; counter1++){
            pixValueTemp2 [counter1][0] = xDistanceTemp+xincrementCount;
            pixValueTemp2 [counter1][1] = yDistanceTemp+yincrementCount;
            incrementSet++;
            
            if (incrementSet == abs(yIncrement)){
                if (remainingAddCount != 0 && addCountFlag == 0){
                    incrementSet = incrementSet-1;
                    remainingAddCount = remainingAddCount-1;
                    addCountFlag = 1;
                }
                else{
                    
                    incrementSet = 0;
                    addCountFlag = 0;
                    
                    if (xDistance < 0) xincrementCount = xincrementCount-1;
                    else if (yLinear == 1) xincrementCount = 0;
                    else xincrementCount++;
                }
            }
            
            if (yDistance < 0) yincrementCount = yincrementCount-1;
            else yincrementCount++;
        }
    }
    
    if (numberOfPixTemp*2 > gapDataLimit){
        delete [] arrayGapData;
        arrayGapData = new int [numberOfPixTemp*2+50], gapDataLimit = numberOfPixTemp*2+50;
    }
    
    gapDataCount = 0;
    
    for (int counter1 = 0; counter1 < numberOfPixTemp; counter1++){
        arrayGapData [gapDataCount] = pixValueTemp2 [counter1][0], gapDataCount++;
        arrayGapData [gapDataCount] = pixValueTemp2 [counter1][1], gapDataCount++;
    }
    
    for (int counter1 = 0; counter1 < numberOfPixTemp+1; counter1++) delete [] pixValueTemp2 [counter1];
    delete [] pixValueTemp2;
    
    return;
}

-(int)gapChaseingMain:(int)midStartXMap2 :(int)midStartYMap2 :(int)midEndXMap2 :(int)midEndYMap2 :(int)dimension :(int)connectivityNumber{
    int distanceMap [3][3];
    int distanceMap2 [3][3];
    int noClosest = 0;
    
    if (dimension > 0 && dimension < 1000){
        int indexCount = 0;
        
        int **dimensionMap = new int *[dimension+1];
        for (int counter1 = 0; counter1 < dimension+1; counter1++) dimensionMap [counter1]= new int [dimension+1];
        
        for (int counter1 = 0; counter1 < dimension; counter1++){
            for (int counter2 = 0; counter2 < dimension; counter2++) dimensionMap [counter1][counter2] = arrayMapData [indexCount], indexCount++;
        }
        
        for (int counter1 = 0; counter1 < 3; counter1++){
            for (int counter2 = 0; counter2 < 3; counter2++){
                if (midStartYMap2+counter1-1 >= 0 && midStartYMap2+counter1-1 < dimension && midStartXMap2+counter2-1 >= 0 && midStartXMap2+counter2-1 < dimension){
                    if (dimensionMap [midStartYMap2+counter1-1][midStartXMap2+counter2-1] == connectivityNumber
                        || dimensionMap [midStartYMap2+counter1-1][midStartXMap2+counter2-1] == connectivityNumber+1){
                        distanceMap [counter1][counter2] = abs(midEndYMap2-(midStartYMap2+counter1-1))+abs(midEndXMap2-(midStartXMap2+counter2-1));
                    }
                    else distanceMap [counter1][counter2] = -1;
                }
                else distanceMap [counter1][counter2] = -1;
            }
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<< dimensionMap [counterA][counterB];
        //	cout<<" dimensionMap "<<counterA<<endl;
        //}
        
        int **trajectoryMap = new int *[dimension+1];
        for (int counter1 = 0; counter1 < dimension+1; counter1++) trajectoryMap [counter1]= new int [dimension+1];
        
        int terminationFlag = 0;
        int closest = 0;
        int chaseStartX = 0;
        int chaseStartY = 0;
        int chaseCountX = 0;
        int chaseCountY = 0;
        int doneFlag = 0;
        int trajectoryCount = 0;
        int terminationFlag2 = 0;
        int closest2 = 0;
        int chaseStartXTemp = 0;
        int chaseStartYTemp = 0;
        int noChaseFind = 0;
        
        do{
            
            terminationFlag = 1;
            noClosest = 0;
            
            for (int counter1 = 0; counter1 < dimension; counter1++){
                for (int counter2 = 0; counter2 < dimension; counter2++) trajectoryMap [counter1][counter2] = 0;
            }
            
            closest = 10000;
            chaseStartX = 0;
            chaseStartY = 0;
            chaseCountX = 0;
            chaseCountY = 0;
            
            for (int counter1 = 0; counter1 < 3; counter1++){
                for (int counter2 = 0; counter2 < 3; counter2++){
                    if (distanceMap [counter1][counter2] < closest && distanceMap [counter1][counter2] != -1){
                        closest = distanceMap [counter1][counter2];
                        chaseStartX = midStartXMap2+counter2-1;
                        chaseStartY = midStartYMap2+counter1-1;
                        chaseCountX = counter2;
                        chaseCountY = counter1;
                        noClosest = 1;
                    }
                }
            }
            
            distanceMap [chaseCountY][chaseCountX] = -1;
            
            if (noClosest == 0) terminationFlag = 0;
            else{
                
                trajectoryMap [chaseStartY][chaseStartX] = -1;
                
                returnDataCount = 0;
                
                arrayReturnData [returnDataCount] = chaseStartX, returnDataCount++;
                arrayReturnData [returnDataCount] = chaseStartY, returnDataCount++;
                
                doneFlag = 0;
                trajectoryCount = -1;
                
                do{
                    
                    for (int counter1 = 0; counter1 < 3; counter1++){
                        for (int counter2 = 0; counter2 < 3; counter2++){
                            if (chaseStartY+counter1-1 >= 0 && chaseStartY+counter1-1 < dimension && chaseStartX+counter2-1 >= 0 && chaseStartX+counter2-1 < dimension){
                                if ((dimensionMap [chaseStartY+counter1-1][chaseStartX+counter2-1] == connectivityNumber || dimensionMap [chaseStartY+counter1-1][chaseStartX+counter2-1] == connectivityNumber+1) && trajectoryMap [chaseStartY+counter1-1][chaseStartX+counter2-1] >= 0){
                                    distanceMap2 [counter1][counter2] = abs(midEndYMap2-(chaseStartY+counter1-1))+abs(midEndXMap2-(chaseStartX+counter2-1));
                                }
                                else distanceMap2 [counter1][counter2] = -1;
                            }
                            else distanceMap2 [counter1][counter2] = -1;
                            
                            if (chaseStartY+counter1-1 == midEndYMap2 && chaseStartX+counter2-1 == midEndXMap2) doneFlag = 1;
                        }
                    }
                    
                    if (doneFlag == 1){
                        terminationFlag = 0;
                        terminationFlag2 = 0;
                    }
                    else{
                        
                        closest2 = 10000;
                        chaseStartXTemp = chaseStartX;
                        chaseStartYTemp = chaseStartY;
                        noChaseFind = 0;
                        
                        for (int counter1 = 0; counter1 < 3; counter1++){
                            for (int counter2 = 0; counter2 < 3; counter2++){
                                if (distanceMap2 [counter1][counter2] < closest2 && distanceMap2 [counter1][counter2] != -1){
                                    closest2 = distanceMap2 [counter1][counter2];
                                    chaseStartX = chaseStartXTemp+counter2-1;
                                    chaseStartY = chaseStartYTemp+counter1-1;
                                    noChaseFind = 1;
                                }
                            }
                        }
                        
                        if (noChaseFind == 1){
                            if (returnDataCount+2 > returnDataLimit) [self returnDataUpDate];
                            
                            arrayReturnData [returnDataCount] = chaseStartX, returnDataCount++;
                            arrayReturnData [returnDataCount] = chaseStartY, returnDataCount++;
                            trajectoryCount = trajectoryCount-1;
                            trajectoryMap [chaseStartY][chaseStartX] = trajectoryCount;
                            terminationFlag2 = 1;
                        }
                        else{
                            
                            distanceMap [chaseCountY][chaseCountX] = -1;
                            terminationFlag2 = 0;
                            terminationFlag = 1;
                        }
                    }
                    
                } while (terminationFlag2 == 1);
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<< trajectoryMap [counterA][counterB];
            //	cout<<" trajectoryMap "<<counterA<<endl;
            //}
            
        } while (terminationFlag == 1);
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++){
            delete [] dimensionMap [counter1];
            delete [] trajectoryMap [counter1];
        }
        
        delete [] dimensionMap;
        delete [] trajectoryMap;
    }
    
    return noClosest;
}

-(void)returnDataUpDate{
    int *arrayUpDate = new int [returnDataCount+10];
    
    for (int counter1 = 0; counter1 < returnDataCount; counter1++) arrayUpDate [counter1] = arrayReturnData [counter1];
    
    delete [] arrayReturnData;
    arrayReturnData = new int [returnDataLimit+5000];
    returnDataLimit = returnDataLimit+5000;
    
    for (int counter1 = 0; counter1 < returnDataCount; counter1++) arrayReturnData [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

@end
