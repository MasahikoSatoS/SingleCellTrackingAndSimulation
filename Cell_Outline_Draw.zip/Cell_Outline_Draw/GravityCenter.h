//
// GravityCenter.h
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 25/02/13.
// Copyright 2012 Masahiko Sato. All rights reserved.
//

#ifndef GRAVITYCENTER_H
#define GRAVITYCENTER_H
#import "Controller.h"
#endif

@interface GravityCenter : NSObject {
}

-(void)gravityCenterDetermine;

@end
