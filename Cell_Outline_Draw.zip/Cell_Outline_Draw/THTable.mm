//
//  THTable.m
//  Cell_Outline_Draw
//
//  Created by Masahiko Sato on 9/8/16.
//
//

#import "THTable.h"

NSString *notificationToThresholdTable = @"notificationExecuteTHTable";

@implementation THTable

-(id)init{
    self = [super init];
    
    if (self != nil){
        tableCallCount = 0;
        tableCurrentRowHold = 0;
        rowIndexHold = 0;
        tableViewCall = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToThresholdTable object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    thTableTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
    
    [thViewList setDataSource:self];
    [thViewList reloadData];
    
    for (NSTableColumn* column in [thViewList tableColumns]) {
        if ([[column identifier] isEqualToString:@"COL1"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Time" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL2"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"TH1" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL3"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"TH2" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL4"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"TH3" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL5"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"TH4" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL6"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"AL" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
    }
}

-(void)display{
    if (tableCallCount == 1){
        tableCallCount = 0;
        rowIndexHold = tableCurrentRowHold;
    }
    
    if (tableCallCount > 1) tableCallCount = 0;
    
    if (tableViewCall == 1){
        tableViewCall = 0;
        [thViewList reloadData];
    }
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = thresholdDataHoldCount/6;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    
    if (initialArraySet == 1){
        string displayData1 = to_string(thresholdDataHold [rowIndex*6]);
        string displayData2 = to_string(thresholdDataHold [rowIndex*6+1]);
        string displayData3 = to_string(thresholdDataHold [rowIndex*6+2]);
        string displayData4 = to_string(thresholdDataHold [rowIndex*6+3]);
        string displayData5 = to_string(thresholdDataHold [rowIndex*6+4]);
        string displayData6 = to_string(thresholdDataHold [rowIndex*6+5]);
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        [attributes setObject:[NSFont boldSystemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData3.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"]){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData4.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL5"]){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData5.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL6"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData6.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else{
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL5"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL6"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    tableCallCount++;
    tableCurrentRowHold = rowIndex;
    
    if (tableCallCount == 2) tableCurrentRowHold = rowIndexHold;
    else if (tableCallCount == 1) tableCurrentRowHold = rowIndex;
    
    return YES;
}

-(void)tableView:(NSTableView *)aTableView setObjectValue:(id)anObject forTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex {
    NSString *columnIdentifier = [aTableColumn identifier];
    NSString *objectInfo = anObject;
    
    string stringExtract;
    
    if ([columnIdentifier isEqualToString:@"COL1"] && thresholdDataHoldCount/6 > rowIndex){
        string nameCheckString = [objectInfo UTF8String];
        
        if (atoi(nameCheckString.c_str()) > 0 && atoi(nameCheckString.c_str()) < 10000){
            thresholdDataHold [rowIndex*6] = atoi(nameCheckString.c_str());
            
            string thDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CellOutlineTHData";
            
            ofstream oin;
            
            oin.open(thDataPath.c_str(), ios::out);
            
            for (int counter1 = 0; counter1 < thresholdDataHoldCount; counter1++) oin<<thresholdDataHold [counter1]<<endl;
            
            oin.close();
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    
    tableViewCall = 1;
}

-(IBAction)setTHValue:(id)sender{
    if (imageFirstLoadFlag == 1){
        int samePointFind = -1;
        
        for (int counter1 = 0; counter1 < thresholdDataHoldCount/6; counter1++){
            if (displayImageNumber == thresholdDataHold [counter1*6]){
                samePointFind = counter1;
                break;
            }
        }
        
        if (samePointFind != -1){
            thresholdDataHold [samePointFind*6] = displayImageNumber;
            thresholdDataHold [samePointFind*6+1] = cutOffLevel;
            thresholdDataHold [samePointFind*6+2] = cutOffLevel2;
            thresholdDataHold [samePointFind*6+3] = cutOffLevel3;
            thresholdDataHold [samePointFind*6+4] = cutOffLevel4;
            thresholdDataHold [samePointFind*6+5] = areaLimit;
            
            //for (int counterA = 0; counterA < thresholdDataHoldCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<thresholdDataHold [counterA*6+counterB];
            //    cout<<" thresholdDataHold "<<counterA<<endl;
            //}
        }
        else{
            
            if (thresholdDataHoldCount+6 > thresholdDataHoldLimit) [self thTableUpDate];
            
            int insertPoint = -1;
            
            for (int counter1 = 0; counter1 < thresholdDataHoldCount/6; counter1++){
                if (displayImageNumber >= thresholdDataHold [counter1*6]){
                    insertPoint = counter1;
                }
            }
            
            if (insertPoint == thresholdDataHoldCount/6-1){
                thresholdDataHold [thresholdDataHoldCount] = displayImageNumber, thresholdDataHoldCount++;
                thresholdDataHold [thresholdDataHoldCount] = cutOffLevel, thresholdDataHoldCount++;
                thresholdDataHold [thresholdDataHoldCount] = cutOffLevel2, thresholdDataHoldCount++;
                thresholdDataHold [thresholdDataHoldCount] = cutOffLevel3, thresholdDataHoldCount++;
                thresholdDataHold [thresholdDataHoldCount] = cutOffLevel4, thresholdDataHoldCount++;
                thresholdDataHold [thresholdDataHoldCount] = areaLimit, thresholdDataHoldCount++;
            }
            else{
                
                int *thresholdDataHoldTemp = new int [thresholdDataHoldCount+10];
                int thresholdDataHoldTempCount = 0;
                
                for (int counter1 = 0; counter1 < thresholdDataHoldCount/6; counter1++){
                    if (counter1 <= insertPoint){
                        thresholdDataHoldTemp [thresholdDataHoldTempCount] = thresholdDataHold [counter1*6], thresholdDataHoldTempCount++;
                        thresholdDataHoldTemp [thresholdDataHoldTempCount] = thresholdDataHold [counter1*6+1], thresholdDataHoldTempCount++;
                        thresholdDataHoldTemp [thresholdDataHoldTempCount] = thresholdDataHold [counter1*6+2], thresholdDataHoldTempCount++;
                        thresholdDataHoldTemp [thresholdDataHoldTempCount] = thresholdDataHold [counter1*6+3], thresholdDataHoldTempCount++;
                        thresholdDataHoldTemp [thresholdDataHoldTempCount] = thresholdDataHold [counter1*6+4], thresholdDataHoldTempCount++;
                        thresholdDataHoldTemp [thresholdDataHoldTempCount] = thresholdDataHold [counter1*6+5], thresholdDataHoldTempCount++;
                    }
                }
                
                //for (int counterA = 0; counterA < thresholdDataHoldTempCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<thresholdDataHoldTemp [counterA*6+counterB];
                //    cout<<" thresholdDataHoldTemp "<<counterA<<endl;
                //}
                
                thresholdDataHoldTemp [thresholdDataHoldTempCount] = displayImageNumber, thresholdDataHoldTempCount++;
                thresholdDataHoldTemp [thresholdDataHoldTempCount] = cutOffLevel, thresholdDataHoldTempCount++;
                thresholdDataHoldTemp [thresholdDataHoldTempCount] = cutOffLevel2, thresholdDataHoldTempCount++;
                thresholdDataHoldTemp [thresholdDataHoldTempCount] = cutOffLevel3, thresholdDataHoldTempCount++;
                thresholdDataHoldTemp [thresholdDataHoldTempCount] = cutOffLevel4, thresholdDataHoldTempCount++;
                thresholdDataHoldTemp [thresholdDataHoldTempCount] = areaLimit, thresholdDataHoldTempCount++;
                
                for (int counter1 = 0; counter1 < thresholdDataHoldCount/6; counter1++){
                    if (counter1 > insertPoint){
                        thresholdDataHoldTemp [thresholdDataHoldTempCount] = thresholdDataHold [counter1*6], thresholdDataHoldTempCount++;
                        thresholdDataHoldTemp [thresholdDataHoldTempCount] = thresholdDataHold [counter1*6+1], thresholdDataHoldTempCount++;
                        thresholdDataHoldTemp [thresholdDataHoldTempCount] = thresholdDataHold [counter1*6+2], thresholdDataHoldTempCount++;
                        thresholdDataHoldTemp [thresholdDataHoldTempCount] = thresholdDataHold [counter1*6+3], thresholdDataHoldTempCount++;
                        thresholdDataHoldTemp [thresholdDataHoldTempCount] = thresholdDataHold [counter1*6+4], thresholdDataHoldTempCount++;
                        thresholdDataHoldTemp [thresholdDataHoldTempCount] = thresholdDataHold [counter1*6+5], thresholdDataHoldTempCount++;
                    }
                }
                
                thresholdDataHoldCount = 0;
                
                for (int counter1 = 0; counter1 < thresholdDataHoldTempCount; counter1++) thresholdDataHold [thresholdDataHoldCount] = thresholdDataHoldTemp [counter1], thresholdDataHoldCount++;
                
                //for (int counterA = 0; counterA < thresholdDataHoldCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<thresholdDataHold [counterA*6+counterB];
                //    cout<<" thresholdDataHold "<<counterA<<endl;
                //}
                
                delete [] thresholdDataHoldTemp;
            }
        }
        
        string thDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CellOutlineTHData";
        
        ofstream oin;
        
        oin.open(thDataPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 < thresholdDataHoldCount; counter1++) oin<<thresholdDataHold [counter1]<<endl;
        
        oin.close();
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        tableViewCall = 1;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Setting Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)removeEntry:(id)sender{
    if (imageFirstLoadFlag == 1){
        int *thresholdDataHoldTemp = new int [thresholdDataHoldCount+1];
        int thresholdDataHoldTempCount = 0;
        
        for (int counter1 = 0; counter1 < thresholdDataHoldCount/6; counter1++){
            if (counter1 != tableCurrentRowHold){
                thresholdDataHoldTemp [thresholdDataHoldTempCount] = thresholdDataHold [counter1*6], thresholdDataHoldTempCount++;
                thresholdDataHoldTemp [thresholdDataHoldTempCount] = thresholdDataHold [counter1*6+1], thresholdDataHoldTempCount++;
                thresholdDataHoldTemp [thresholdDataHoldTempCount] = thresholdDataHold [counter1*6+2], thresholdDataHoldTempCount++;
                thresholdDataHoldTemp [thresholdDataHoldTempCount] = thresholdDataHold [counter1*6+3], thresholdDataHoldTempCount++;
                thresholdDataHoldTemp [thresholdDataHoldTempCount] = thresholdDataHold [counter1*6+4], thresholdDataHoldTempCount++;
                thresholdDataHoldTemp [thresholdDataHoldTempCount] = thresholdDataHold [counter1*6+5], thresholdDataHoldTempCount++;
            }
        }
        
        thresholdDataHoldCount = 0;
        
        for (int counter1 = 0; counter1 < thresholdDataHoldTempCount/6; counter1++){
            thresholdDataHold [thresholdDataHoldCount] = thresholdDataHoldTemp [counter1*6], thresholdDataHoldCount++;
            thresholdDataHold [thresholdDataHoldCount] = thresholdDataHoldTemp [counter1*6+1], thresholdDataHoldCount++;
            thresholdDataHold [thresholdDataHoldCount] = thresholdDataHoldTemp [counter1*6+2], thresholdDataHoldCount++;
            thresholdDataHold [thresholdDataHoldCount] = thresholdDataHoldTemp [counter1*6+3], thresholdDataHoldCount++;
            thresholdDataHold [thresholdDataHoldCount] = thresholdDataHoldTemp [counter1*6+4], thresholdDataHoldCount++;
            thresholdDataHold [thresholdDataHoldCount] = thresholdDataHoldTemp [counter1*6+5], thresholdDataHoldCount++;
        }
        
        delete [] thresholdDataHoldTemp;
        
        string thDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CellOutlineTHData";
        
        if (thresholdDataHoldCount != 0){
            ofstream oin;
            
            oin.open(thDataPath.c_str(), ios::out);
            
            for (int counter1 = 0; counter1 < thresholdDataHoldCount; counter1++) oin<<thresholdDataHold [counter1]<<endl;
            
            oin.close();
        }
        else{
            
            remove (thDataPath.c_str());
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        tableViewCall = 1;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Setting Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clearEnter:(id)sender{
    if (imageFirstLoadFlag == 1){
        thresholdDataHoldCount = 0;
        
        string thDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CellOutlineTHData";
        
        remove (thDataPath.c_str());
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        tableViewCall = 1;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Setting Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)thTableUpDate{
    int *arrayUpDate = new int [thresholdDataHoldCount+10];
    
    for (int counter1 = 0; counter1 < thresholdDataHoldCount; counter1++) arrayUpDate [counter1] = thresholdDataHold [counter1];
    
    delete [] thresholdDataHold;
    thresholdDataHold = new int [thresholdDataHoldLimit+60];
    thresholdDataHoldLimit = thresholdDataHoldLimit+60;
    
    for (int counter1 = 0; counter1 < thresholdDataHoldCount; counter1++) thresholdDataHold [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    if (thTableTimer) [thTableTimer invalidate];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToThresholdTable object:nil];
}

@end
