//
// UpDatedLine.h
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 09/02/13.
// Copyright 2012 Masahiko Sato. All rights reserved.
//

#ifndef UPDATELINE_H
#define UPDATELINE_H
#import "Controller.h"
#endif

@interface UpDateLine : NSObject {
}

-(void)upDateLineMain:(int)counter;
-(void)linkedLineSizeUpDate;
-(void)linkedLineAssSizeUpDate;

@end
