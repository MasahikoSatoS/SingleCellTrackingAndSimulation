//
// Controller.h
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 10/07/11.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#ifndef CONTROLLER_H
#define CONTROLLER_H
#import <Cocoa/Cocoa.h>
#import "TreatList.h"
#import "SourceDisplay.h"
#import "CellImage.h"
#import "ImageProcessing.h"
#import "EdgeTracing.h"
#import "LineChase.h"
#import "GapChase.h"
#import "GapChase2.h"
#import "GapChase3.h"
#import "GapFill.h"
#import "LineSelect.h"
#import "LinkPoint.h"
#import "LineConnect.h"
#import "ArrayModification.h"
#import "EndLink.h"
#import "ShapeAdjust.h"
#import "UpDateLine.h"
#import "OverlapCheck.h"
#import "GravityCenter.h"
#import "OutlineVector.h"
#import "VectorSegmentation.h"
#import "VectorAnalysis.h"
#import "ConnectivityAnalysis.h"
#import "Communication.h"
#import "THTable.h"
#import "TiffFileRead.h"
#include <iostream>
#include <string>
#include <cstdio>
#include <dirent.h>
#include <sys/stat.h>
#include <fstream>
#include <sstream>
#endif

using namespace std;

extern NSString *notificationToSourceImage;
extern NSString *notificationToCellImage;
extern NSString *notificationToImageProcessing;
extern NSString *notificationToCommunication;
extern NSString *notificationToThresholdTable;
extern NSString *notificationToTreatList;

//------Controller------
extern int autoRunStatus; //Auto Run Manual status
extern int displayImageNumber; //Image number to be displayed
extern int jumpSet; //Jump Number
extern int imageFirstLoadFlag; //Flag for the first image load
extern int imageWidth; //Image size
extern int imageHeight; //Image size
extern int toControllerDisplay1; //Controller display request
extern int runMode; //Manual/Auto Status
extern int processSequenceFlag; //Auto process count
extern int imageNameFileListCount; //Image file count
extern int displayMode; //Set threshold display Mode
extern int areaLimit; //Outline vector limit
extern int cutOffLevel; //Cut off level
extern int cutOffLevel2; //Cut off level
extern int cutOffLevel3; //Cut off level
extern int cutOffLevel4; //Cut off level
extern int areaLimitCurrent; //Outline vector limit
extern int cutOffLevelCurrent; //Cut off level Current
extern int cutOffLevelCurrent2; //Cut off level Current
extern int cutOffLevelCurrent3; //Cut off level Current
extern int cutOffLevelCurrent4; //Cut off level Current
extern int imageFirstLoadFlagDisplay; //First loading flag, source
extern int imageFirstLoadFlagCell; //First loading flag, Cell
extern int processOption; //Time/Treatment
extern string pathNameString; //Path name
extern string analysisNameManualString; //Analysis name for manual
extern string treatNameManualString; //Treatment name for manual
extern string bodyName; //Hold bodyName
extern string imageFolderPath; //Image Path
extern string *arrayWholeImage; //Lineage Start/end point
extern int wholeImageCount;
extern int wholeImageLimit;
extern string *arrayDirectoryInfo; //File sorting array
extern int directoryInfoCount;
extern int directoryInfoLimit;
extern int allRunFlag; //All Run status
extern int processingFromHold; //Hold reprocessing from
extern int processingToHold; //Hold reprocessing To
extern int reprocessImageNo; //Hold reprocessing image no
extern int reprocessStatus; //Hold reprocessing status
extern int progressValue; //Hold Progress indicator value
extern int progressTiming; //Hold Progress indicator timing
extern string *treatmentSelectList; //Hold treatment select status
extern int treatmentSelectListStatus;
extern int treatmentSelectListCount;

//------Line Chase Arrays------
extern int *arrayLineOne; //Line One
extern int lineOneCount;
extern int *arrayLineThree; //Line Three
extern int lineThreeCount;
extern int *arrayLineFive; //Line Five
extern int lineFiveCount;
extern int *arrayLineSeven; //Line Seven
extern int lineSevenCount;
extern int *arrayGapChase; //Gap Chase date hold
extern int gapChaseCount;
extern int gapChaseLimit;
extern int *arrayGapData; //Gap Data hold
extern int gapDataCount;
extern int gapDataLimit;
extern int *arrayMapData; //Map date used for Gap Chase
extern int mapDataCount;
extern int mapDataLimit;
extern int *arrayReturnData; //Chase Result
extern int returnDataCount;
extern int returnDataLimit;
extern int *arrayEdgeTrace; //Edge Trace data
extern int edgeTraceCount;
extern int edgeTraceLimit;
extern int *arrayEdgeTraceStartEnd; //Edge Trace Entry Start/End List
extern int edgeTraceStartEndCount;
extern int edgeTraceStartEndLimit;
extern int *arrayLinkedLine; //Linked line created by EndLink
extern int linkedLineCount;
extern int linkedLineLimit;
extern int *arrayOutlineExist; //Existed line information, created by the Connectivity analysis
extern int outlineExistCount;
extern int outlineExistLimit;
extern int *arrayOutlineExistAss; //Existed line associated information
extern int outlineExistAssCount;
extern int outlineExistAssLimit;
extern int *arrayOutlineAddition; //Outline data newly added
extern int outlineAdditionCount;
extern int outlineAdditionLimit;
extern int *arrayOutlineVectorSegment; //Array to VectorSegmentation
extern int outlineVectorSegmentCount;
extern int outlineVectorSegmentLimit;
extern int *arrayVectorSegmentation; //Array from VectorSegmentation to VectorAnalysis
extern int vectorSegmentationCount;
extern int vectorSegmentationLimit;
extern double *arrayVectorSegmentationLength; //Array from VectorSegmentation to VectorAnalysis, length data
extern int vectorSegmentationLengthCount;
extern int vectorSegmentationLengthLimit;
extern int *arrayForNextConnectivity; //Hold Final Results, UpDate after every round
extern int forNextConnectivityCount;
extern int forNextConnectivityLimit;
extern int *arrayForNextConnectivityAss; //Hold Final Results, Ass (Associated data) info, UpDate after every round
extern int forNextConnectivityAssCount;
extern int forNextConnectivityAssLimit;
extern int *arrayAnalysisResult1; //Cell shape date, 200, to ShapeAdjust
extern int analysisResultCount1;
extern int analysisResultStatus1;
extern int *arrayAnalysisResult2; //Cell shape date, 220, to ShapeAdjust
extern int analysisResultCount2;
extern int analysisResultStatus2;
extern int *arrayAnalysisResult3; //Cell shape date, 240, to ShapeAdjust
extern int analysisResultCount3;
extern int analysisResultStatus3;
extern int *arrayLinkedLineUpdate; //Linked Update Line data
extern int linkedLineUpdateCount;
extern int linkedLineUpdateLimit;
extern int *arrayLinkedLineUpdateAss; //Linked Update line Ass data
extern int linkedLineUpdateAssCount;
extern int linkedLineUpdateAssLimit;

//------Line Chase Variables------
extern int linkedLineMainCount; //Linked line count

//------Display Arraies------
extern int *arrayLineDataForDisplay6; //For display, line data
extern int lineDataForDisplayCount6;
extern int lineDataForDisplayStatus6;
extern int *arrayLineDataForDisplay7; //For display, line data
extern int lineDataForDisplayCount7;
extern int lineDataForDisplayStatus7;
extern int *arrayLineDataForDisplay8; //For display, line data
extern int lineDataForDisplayCount8;
extern int lineDataForDisplayStatus8;
extern int *arrayLineDataForDisplay9; //For display, line data
extern int lineDataForDisplayCount9;
extern int lineDataForDisplayStatus9;
extern int **imageForDisplay1; //Images for display
extern int **imageForDisplay2; //Images for display
extern int **imageForDisplay3; //Images for display
extern int **imageForDisplay4; //Images for display
extern int imageForDisplayStatus;

//------Image Processing Arrays: Image related------
extern int **arrayExtractedImage; //Grey scale image Map
extern int extractImageStatus;
extern int **arrayImage150; //Source image for Connectivity analysis etc, values are 150
extern int **arrayImageRemaining; //After overlaying existing pixels, extract remaining pixels, values are 150
extern int **arrayImageConnect200; //TH200 image, connect Data
extern int **arrayImageConnect220; //TH220 image, connect Data
extern int **arrayImageConnect240; //TH240 image, connect Data
extern int **arrayImageConnectivity; //Connectivity Data, Source
extern int **arrayImageConnectivityA; //TH190 Connectivity Data
extern int **arrayImageConnectivityB; //TH160 Connectivity Data
extern int **arrayImageConnectivityC; //TH130 Connectivity Data
extern int **arrayImageConnectivityD; //TH90 Connectivity Data
extern int **mapData; //Map data from Gravity Center to Save

//------Image Processing Arrays: Outline data related------
extern int *arrayOutlineVectorSource0; //TH190 connect line Data hold
extern int outlineVectorSourceCount0;
extern int outlineVectorSourceLimit0;
extern int *arrayOutlineVectorSource1; //TH200 connect line Data hold
extern int outlineVectorSourceCount1;
extern int outlineVectorSourceLimit1;
extern int *arrayOutlineVectorSource2; //TH220 connect line Data hold
extern int outlineVectorSourceCount2;
extern int outlineVectorSourceLimit2;
extern int *arrayOutlineVectorSource3; //TH240 connect line Data hold
extern int outlineVectorSourceCount3;
extern int outlineVectorSourceLimit3;
extern int *arrayOutlineVectorSource4; //Remaining connect line data
extern int outlineVectorSourceCount4;
extern int outlineVectorSourceLimit4;
extern int *arrayXYPositionCenter; //Gravity Center
extern int xyPositionCenterCount;

//------Image source------
extern int magnificationDisplay; //Magnification fold
extern double windowWidthDisplay; //Window/Image position adjust
extern double windowHeightDisplay; //Window/Image position adjust
extern int sourceDisplayCheck; //Source display end check

//------Image Cell------
extern int magnificationCell; //Magnification fold
extern double windowWidthCell; //Window/Image position adjust
extern double windowHeightCell; //Window/Image position adjust
extern int cellImageDisplayCheck; //Cell image display end check

//------Threshold list------
extern int initialArraySet; //Initial array set flag
extern int *thresholdDataHold; //Entry no of Threshold list
extern int thresholdDataHoldCount;
extern int thresholdDataHoldLimit;

extern uint8_t *fileReadArray; //Array holding image data

@interface Controller : NSObject <NSTextFieldDelegate>{
    int startProcessPermission; //Permit to start
    int remainingImages; //Set Threshold display Mode
    int autoModeOffControl; //Control off timing
    
    IBOutlet NSTextField *analysisNameAuto;
    IBOutlet NSTextField *treatNameAuto;
    IBOutlet NSTextField *imageNoAuto;
    IBOutlet NSTextField *imageSize;
    IBOutlet NSTextField *timePointNumber;
    IBOutlet NSTextField *analysisNameManual;
    IBOutlet NSTextField *treatNameManual;
    IBOutlet NSTextField *imageLoadResult;
    IBOutlet NSTextField *inputField;
    IBOutlet NSTextField *jumpDisplay;
    IBOutlet NSTextField *runOnOFF;
    IBOutlet NSTextField *processingStatusDisplay;
    IBOutlet NSTextField *allRunStatus;
    IBOutlet NSTextField *displayThreshold;
    IBOutlet NSTextField *autoRunStatusDisplay;
    IBOutlet NSTextField *maxImageNo;
    IBOutlet NSTextField *cutOffDisplay;
    IBOutlet NSTextField *cutOffDisplay2;
    IBOutlet NSTextField *cutOffDisplay3;
    IBOutlet NSTextField *cutOffDisplay4;
    IBOutlet NSTextField *analysisNameDisplay;
    IBOutlet NSTextField *treatNameDisplay;
    IBOutlet NSTextField *areaLimitDisplay;
    IBOutlet NSTextField *optionDisplay;
    IBOutlet NSTextField *removeNumber;
    IBOutlet NSTextField *outlineRange;
    IBOutlet NSTextField *reprocessFromDisplay;
    IBOutlet NSTextField *reprocessToDisplay;
    IBOutlet NSTextField *reprocessNoDisplay;
    
    IBOutlet NSStepper *stepperFrom;
    IBOutlet NSStepper *stepperTo;
    
    IBOutlet NSWindow *controllerWindow;
    IBOutlet NSBrowser *listBrowser;
    IBOutlet NSProgressIndicator *progressIndicator;
    
    NSTimer *controllerTimer;
    
    id tiffFileRead;
}

-(id)init;
-(void)dealloc;
-(void)userPathSet;
-(void)processControl;
-(int)nameCheck:(string)inputDate;
-(void)processStartSub;
-(void)autoProcessing;
-(void)processImageFiles;
-(void)processStop;
-(void)wholeImageUpDate;
-(void)directoryInfoUpDate;

-(IBAction)analysisNameSet:(id)sender;
-(IBAction)treatmentNameSet:(id)sender;
-(IBAction)imageLoad:(id)sender;
-(IBAction)processStartMain:(id)sender;
-(IBAction)jump:(id)sender;
-(IBAction)allProcess:(id)sender;
-(IBAction)processStopSub:(id)sender;
-(IBAction)displayModeSW:(id)sender;
-(IBAction)autoRunOnOff:(id)sender;
-(IBAction)cutOffSetMain:(id)sender;
-(IBAction)cutOffSetMain2:(id)sender;
-(IBAction)cutOffSetMain3:(id)sender;
-(IBAction)cutOffSetMain4:(id)sender;
-(IBAction)cutOffDefault:(id)sender;
-(IBAction)areaLimitSet:(id)sender;
-(IBAction)browserDoubleClick:(id)browser;
-(IBAction)processOptionSet:(id)browser;
-(IBAction)processDataRemove:(id)browser;
-(IBAction)stepperActionFrom:(id)sender;
-(IBAction)stepperActionTo:(id)sender;
-(IBAction)reProcessingSet:(id)sender;

@end
