//
// ConnectivityAnalysis.h
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 11/11/04.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#ifndef CONNECTIVITYANALYSIS_H
#define CONNECTIVITYANALYSIS_H
#import "Controller.h"
#endif

@interface ConnectivityAnalysis : NSObject {
    id outlineVector;
}

-(void)matchingCheck:(int)subjectArray;
-(void)reconstruction:(int)subjectArray;

@end
