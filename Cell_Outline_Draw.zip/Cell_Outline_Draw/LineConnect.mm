//
// LineConnect.mm
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 26/11/12.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#import "LineConnect.h"

@implementation LineConnect

-(void)lineConnectSameType:(int)lineSet{
    int referenceXY [6];
    int subjectX [8];
    int subjectY [8];
    int subjectCount [8];
    double shortestDistance [8];
    
    int *arraySelectedBlock;
    int selectedBlockCount = 0;
    int selectedBlockStatus = 0;
    
    //------Read original image data------
    selectedBlockCount = 0;
    
    if (lineSet == 1){
        arraySelectedBlock = new int [lineFiveCount+500];
        
        selectedBlockCount = 0;
        selectedBlockStatus = 1;
        
        for (int counter1 = 0; counter1 < lineFiveCount/6; counter1++){
            arraySelectedBlock [selectedBlockCount] = arrayLineFive [counter1*6], selectedBlockCount++; //------X Position------0
            arraySelectedBlock [selectedBlockCount] = arrayLineFive [counter1*6+1], selectedBlockCount++; //------Y position------1
            arraySelectedBlock [selectedBlockCount] = arrayLineFive [counter1*6+2], selectedBlockCount++; //------Value------2
            arraySelectedBlock [selectedBlockCount] = arrayLineFive [counter1*6+3], selectedBlockCount++; //------Block------3
            arraySelectedBlock [selectedBlockCount] = arrayLineFive [counter1*6+4], selectedBlockCount++; //------Combine------4
            arraySelectedBlock [selectedBlockCount] = arrayLineFive [counter1*6+5], selectedBlockCount++; //------Status------5
        }
    }
    if (lineSet == 3){
        arraySelectedBlock = new int [lineSevenCount+500];
        
        selectedBlockCount = 0;
        selectedBlockStatus = 1;
        
        for (int counter1 = 0; counter1 < lineSevenCount/6; counter1++){
            arraySelectedBlock [selectedBlockCount] = arrayLineSeven [counter1*6], selectedBlockCount++; //------X Position------0
            arraySelectedBlock [selectedBlockCount] = arrayLineSeven [counter1*6+1], selectedBlockCount++; //------Y position------1
            arraySelectedBlock [selectedBlockCount] = arrayLineSeven [counter1*6+2], selectedBlockCount++; //------Value------2
            arraySelectedBlock [selectedBlockCount] = arrayLineSeven [counter1*6+3], selectedBlockCount++; //------Block------3
            arraySelectedBlock [selectedBlockCount] = arrayLineSeven [counter1*6+4], selectedBlockCount++; //------Combine------4
            arraySelectedBlock [selectedBlockCount] = arrayLineSeven [counter1*6+5], selectedBlockCount++; //------Status------5
        }
    }
    
    //for (int counterA = 0; counterA < selectedBlockCount/6; counterA++){
    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arraySelectedBlock [counterA*6+counterB];
    //	cout<<" arraySelectedBlock "<<counterA<<endl;
    //}
    
    int *arraySelectedBlockReturn = new int [selectedBlockCount+500];
    
    int selectedBlockReturnCount = 0;
    int selectedBlockReturnLimit = selectedBlockCount+500;
    
    if (selectedBlockCount != 0){
        int newBlockFind = 0;
        int terminationFlag = 0;
        int numberOfStartPoints = 0;
        int startingPositionTemp = 0;
        int findFlag = 0;
        int subjectStartX = 0;
        int subjectStartY = 0;
        int subjectStartCount = 0;
        int subjectEndX = 0;
        int subjectEndY = 0;
        int subjectEndCount = 0;
        int subjectEndCount2 = 0;
        int remainingPoint1 = 0;
        int remainingPoint2 = 0;
        int refEndZero = 0;
        int refStartZero = 0;
        int jumpX1 = 0;
        int jumpY1 = 0;
        int jumpX2 = 0;
        int jumpY2 = 0;
        int chaseResult = 0;
        int shortestDistanceCount1 = 0;
        int shortestDistanceCount2 = 0;
        int subBlockStart = 0;
        int subBlockEnd = 0;
        int blockBuildTempCount = 0;
        int blockBuildTempStatus = 0;
        int firstBlock = 0;
        int firstEnd = 0;
        int secondConnect = 0;
        int secondEnd = 0;
        int adjustArraySize = 0;
        int firstConnect = 0;
        int secondBlock = 0;
        
        double shortestDistanceTemp = 0;
        double shortestDistance1 = 0;
        double shortestDistance2 = 0;
        
        do{
            
            terminationFlag = 1;
            
            referenceXY [0] = 0;
            referenceXY [1] = 0;
            referenceXY [2] = 0;
            referenceXY [3] = 0;
            referenceXY [4] = 0;
            referenceXY [5] = 0;
            
            for (int counter1 = 0; counter1 < selectedBlockCount/6; counter1++){
                if (arraySelectedBlock [counter1*6+5] == 1){
                    referenceXY [0] = arraySelectedBlock [counter1*6];
                    referenceXY [1] = arraySelectedBlock [counter1*6+1];
                    referenceXY [2] = counter1;
                }
                else if (arraySelectedBlock [counter1*6+5] == 2){
                    referenceXY [3] = arraySelectedBlock [counter1*6];
                    referenceXY [4] = arraySelectedBlock [counter1*6+1];
                    referenceXY [5] = counter1;
                    break;
                }
            }
            
            //cout<<referenceXY [0]<<" "<<referenceXY [1]<<" "<<referenceXY [2]<<" "<<referenceXY [3]<<" "<<referenceXY [4]<<" "<<referenceXY [5]<<" RefDATA"<<endl;
            
            numberOfStartPoints = 0;
            
            for (int counter1 = referenceXY [5]+1; counter1 < selectedBlockCount/6; counter1++){
                if (arraySelectedBlock [counter1*6+5] == 1) numberOfStartPoints++;
            }
            
            if (numberOfStartPoints == 0){
                if (selectedBlockReturnCount+selectedBlockCount > selectedBlockReturnLimit){
                    int *arraySourceTemp = new int [selectedBlockReturnCount+50];
                    for (int counter1 = 0; counter1 < selectedBlockReturnCount; counter1++) arraySourceTemp [counter1] = arraySelectedBlockReturn [counter1];
                    
                    delete [] arraySelectedBlockReturn;
                    arraySelectedBlockReturn = new int [selectedBlockReturnLimit+selectedBlockCount+500];
                    selectedBlockReturnLimit = selectedBlockReturnLimit+selectedBlockCount+500;
                    
                    for (int counter1 = 0; counter1 < selectedBlockReturnCount; counter1++) arraySelectedBlockReturn [counter1] = arraySourceTemp [counter1];
                    delete [] arraySourceTemp;
                }
                
                newBlockFind++;
                
                for (int counter1 = 0; counter1 < selectedBlockCount/6; counter1++){
                    arraySelectedBlockReturn [selectedBlockReturnCount] = arraySelectedBlock [counter1*6], selectedBlockReturnCount++; //------X position------
                    arraySelectedBlockReturn [selectedBlockReturnCount] = arraySelectedBlock [counter1*6+1], selectedBlockReturnCount++; //------Y position------
                    arraySelectedBlockReturn [selectedBlockReturnCount] = arraySelectedBlock [counter1*6+2], selectedBlockReturnCount++; //------Value------
                    arraySelectedBlockReturn [selectedBlockReturnCount] = newBlockFind, selectedBlockReturnCount++; //------Block------
                    arraySelectedBlockReturn [selectedBlockReturnCount] = arraySelectedBlock [counter1*6+4], selectedBlockReturnCount++; //------Combined------
                    arraySelectedBlockReturn [selectedBlockReturnCount] = arraySelectedBlock [counter1*6+5], selectedBlockReturnCount++; //------Status------
                }
                
                terminationFlag = 0;
            }
            else{
                
                int **startEndPositionList = new int *[numberOfStartPoints+50];
                for (int counter1 = 0; counter1 < numberOfStartPoints+50; counter1++) startEndPositionList [counter1] = new int [7];
                
                startingPositionTemp = 0;
                findFlag = 0;
                
                for (int counter1 = referenceXY [5]+1; counter1 < selectedBlockCount/6; counter1++){
                    if (arraySelectedBlock [counter1*6+5] == 1 && findFlag == 0){
                        startEndPositionList [startingPositionTemp][0] = arraySelectedBlock [counter1*6];
                        startEndPositionList [startingPositionTemp][1] = arraySelectedBlock [counter1*6+1];
                        startEndPositionList [startingPositionTemp][2] = counter1;
                        findFlag = 1;
                    }
                    else if (arraySelectedBlock [counter1*6+5] == 2 && findFlag == 1){
                        startEndPositionList [startingPositionTemp][3] = arraySelectedBlock [counter1*6];
                        startEndPositionList [startingPositionTemp][4] = arraySelectedBlock [counter1*6+1];
                        startEndPositionList [startingPositionTemp][5] = counter1;
                        startingPositionTemp++;
                        findFlag = 0;
                    }
                }
                
                //for (int counterA = 0; counterA < numberOfStartPoints; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<startEndPositionList [counterA][counterB];
                //	cout<<" startEndPositionList "<<counterA<<endl;
                //}
                
                int **crossPositionListRefEnd2 = new int *[numberOfStartPoints+50];
                int **crossPositionListRefStart2 = new int *[numberOfStartPoints+50];
                
                for (int counter1 = 0; counter1 < numberOfStartPoints+50; counter1++){
                    crossPositionListRefEnd2 [counter1] = new int [5];
                    crossPositionListRefStart2 [counter1] = new int [5];
                }
                
                double *crossDistanceRefEnd2 = new double [numberOfStartPoints+50];
                double *crossDistanceRefStart2 = new double [numberOfStartPoints+50];
                
                for (int counter1 = 0; counter1 < numberOfStartPoints; counter1++){
                    subjectStartX = startEndPositionList[counter1][0];
                    subjectStartY = startEndPositionList[counter1][1];
                    subjectStartCount = startEndPositionList[counter1][2];
                    subjectEndX = startEndPositionList[counter1][3];
                    subjectEndY = startEndPositionList[counter1][4];
                    subjectEndCount = startEndPositionList[counter1][5];
                    
                    for (int counter2 = 0; counter2 < 8; counter2++){
                        subjectX [counter2] = 0;
                        subjectY [counter2] = 0;
                        subjectCount [counter2] = 0;
                        shortestDistance [counter2] = 10000;
                    }
                    
                    //------RefEnd >>> SubStart------
                    if ((subjectEndCount-subjectStartCount) == 2 || (subjectEndCount-subjectStartCount) == 3) subjectEndCount2 = subjectEndCount-1;
                    else subjectEndCount2 = subjectEndCount-(subjectEndCount-subjectStartCount)/2;
                    
                    for (int counter2 = subjectStartCount; counter2 <= subjectEndCount2; counter2++){
                        shortestDistanceTemp = sqrt((referenceXY [3]-arraySelectedBlock [counter2*6])*(referenceXY [3]-arraySelectedBlock [counter2*6])+(referenceXY [4]-arraySelectedBlock [counter2*6+1])*(referenceXY [4]-arraySelectedBlock [counter2*6+1]));
                        
                        //cout<<referenceXY [3]<<" "<<referenceXY [4]<<" "<<dataXTemp<<" "<<dataYTemp<<" "<<shortestDistanceTemp<<" RefEd>>SubSt"<<endl;
                        
                        if (shortestDistance [0] > shortestDistanceTemp && arrayExtractedImage [arraySelectedBlock [counter2*6+1]][arraySelectedBlock [counter2*6]] != 100){
                            subjectX [0] = arraySelectedBlock [counter2*6];
                            subjectY [0] = arraySelectedBlock [counter2*6+1];
                            subjectCount [0] = counter2;
                            shortestDistance [0] = shortestDistanceTemp;
                        }
                    }
                    
                    //------SubStart >>> RefEnd------
                    if ((referenceXY [5]-referenceXY [2]) == 2 || (referenceXY [5]-referenceXY [2]) == 3) subjectEndCount2 = referenceXY [5]-1;
                    else subjectEndCount2 = referenceXY [2]+(referenceXY [5]-referenceXY [2])/2;
                    
                    for (int counter2 = referenceXY [5]; counter2 >= subjectEndCount2; counter2 = counter2-1){
                        shortestDistanceTemp = sqrt((subjectStartX-arraySelectedBlock [counter2*6])*(subjectStartX-arraySelectedBlock [counter2*6])+(subjectStartY-arraySelectedBlock [counter2*6+1])*(subjectStartY-arraySelectedBlock [counter2*6+1]));
                        
                        //cout<<subjectStartX<<" "<<subjectStartY<<" "<<dataXTemp<<" "<<dataYTemp<<" "<<shortestDistanceTemp<<" RefSt>>SubEd"<<endl;
                        
                        if (shortestDistance [1] > shortestDistanceTemp && arrayExtractedImage [arraySelectedBlock [counter2*6+1]][arraySelectedBlock [counter2*6]] != 100){
                            subjectX [1] = arraySelectedBlock [counter2*6];
                            subjectY [1] = arraySelectedBlock [counter2*6+1];
                            subjectCount [1] = counter2;
                            shortestDistance [1] = shortestDistanceTemp;
                        }
                    }
                    
                    //------RefStart >>> SubEnd------
                    if ((subjectEndCount-subjectStartCount) == 2 || (subjectEndCount-subjectStartCount) == 3) subjectEndCount2 = subjectEndCount-1;
                    else subjectEndCount2 = subjectEndCount-(subjectEndCount-subjectStartCount)/2;
                    
                    for (int counter2 = subjectEndCount; counter2 >= subjectEndCount2; counter2 = counter2-1){
                        shortestDistanceTemp = sqrt((referenceXY [0]-arraySelectedBlock [counter2*6])*(referenceXY [0]-arraySelectedBlock [counter2*6])+(referenceXY [1]-arraySelectedBlock [counter2*6+1])*(referenceXY [1]-arraySelectedBlock [counter2*6+1]));
                        
                        //cout<<counter2<<" "<<referenceXY [0]<<" "<<referenceXY [0]<<" "<<dataXTemp<<" "<<dataYTemp<<" "<<shortestDistanceTemp<<" RefSt>>SubEd"<<endl;
                        
                        if (shortestDistance [2] > shortestDistanceTemp && arrayExtractedImage [arraySelectedBlock [counter2*6+1]][arraySelectedBlock [counter2*6]] != 100){
                            subjectX [2] = arraySelectedBlock [counter2*6];
                            subjectY [2] = arraySelectedBlock [counter2*6+1];
                            subjectCount [2] = counter2;
                            shortestDistance [2] = shortestDistanceTemp;
                        }
                    }
                    
                    //------SubEnd >>> RefStart------
                    if ((referenceXY [5]-referenceXY [2]) == 2 || (referenceXY [5]-referenceXY [2]) == 3) subjectEndCount2 = referenceXY [5]-1;
                    else subjectEndCount2 = subjectEndCount-(referenceXY [5]-referenceXY [2])/2;
                    
                    for (int counter2 = 0; counter2 <= subjectEndCount2; counter2++){
                        shortestDistanceTemp = sqrt((subjectEndX-arraySelectedBlock [counter2*6])*(subjectEndX-arraySelectedBlock [counter2*6])+(subjectEndY-arraySelectedBlock [counter2*6+1])*(subjectEndY-arraySelectedBlock [counter2*6+1]));
                        
                        //cout<<subjectEndX<<" "<<subjectEndY<<" "<<dataXTemp<<" "<<dataYTemp<<" "<<shortestDistanceTemp<<" SunEd>>RefSt"<<endl;
                        
                        if (shortestDistance [3] > shortestDistanceTemp && arrayExtractedImage [arraySelectedBlock [counter2*6+1]][arraySelectedBlock [counter2*6]] != 100){
                            subjectX [3] = arraySelectedBlock [counter2*6];
                            subjectY [3] = arraySelectedBlock [counter2*6+1];
                            subjectCount [3] = counter2;
                            shortestDistance [3] = shortestDistanceTemp;
                        }
                    }
                    
                    remainingPoint1 = -1;
                    
                    if (shortestDistance [0] > 15 && shortestDistance [1] <= 15) remainingPoint1 = 1;
                    
                    if (shortestDistance [0] <= 15 && shortestDistance [1] > 15) remainingPoint1 = 0;
                    
                    if (shortestDistance [0] <= 15 && shortestDistance [1] <= 15){
                        if (shortestDistance [0] > shortestDistance [1]) remainingPoint1 = 1;
                        else remainingPoint1 = 0;
                    }
                    
                    remainingPoint2 = -1;
                    
                    if (shortestDistance [2] > 15 && shortestDistance [3] <= 15) remainingPoint2 = 3;
                    
                    if (shortestDistance [2] <= 15 && shortestDistance [3] > 15) remainingPoint2 = 2;
                    
                    if (shortestDistance [2] <= 15 && shortestDistance [3] <= 15){
                        if (shortestDistance [2] > shortestDistance [3]) remainingPoint2 = 3;
                        else remainingPoint2 = 2;
                    }
                    
                    if (remainingPoint1 != -1){
                        crossPositionListRefEnd2 [counter1][0] = subjectX [remainingPoint1];
                        crossPositionListRefEnd2 [counter1][1] = subjectY [remainingPoint1];
                        crossPositionListRefEnd2 [counter1][2] = subjectCount [remainingPoint1];
                        crossPositionListRefEnd2 [counter1][3] = remainingPoint1;
                        crossDistanceRefEnd2 [counter1] = shortestDistance [remainingPoint1];
                    }
                    else{
                        
                        crossPositionListRefEnd2 [counter1][0] = -1;
                        crossPositionListRefEnd2 [counter1][1] = -1;
                        crossPositionListRefEnd2 [counter1][2] = -1;
                        crossDistanceRefEnd2 [counter1] = -1;
                    }
                    
                    if (remainingPoint2 != -1){
                        crossPositionListRefStart2 [counter1][0] = subjectX [remainingPoint2];
                        crossPositionListRefStart2 [counter1][1] = subjectY [remainingPoint2];
                        crossPositionListRefStart2 [counter1][2] = subjectCount [remainingPoint2];
                        crossPositionListRefStart2 [counter1][3] = remainingPoint2;
                        crossDistanceRefStart2 [counter1] = shortestDistance [remainingPoint2];
                    }
                    else{
                        
                        crossPositionListRefStart2 [counter1][0] = -1;
                        crossPositionListRefStart2 [counter1][1] = -1;
                        crossPositionListRefStart2 [counter1][2] = -1;
                        crossDistanceRefStart2 [counter1] = -1;
                    }
                }
                
                //for (int counterA = 0; counterA < numberOfStartPoints; counterA++){
                //	cout<<crossPositionListRefEnd2[counterA][0]<<" "<<crossPositionListRefEnd2[counterA][1]<<" "<<crossPositionListRefEnd2[counterA][2]<<" RS(0, 1)"<<endl;
                //}
                
                //for (int counterA = 0; counterA < numberOfStartPoints; counterA++){
                //	cout<<crossPositionListRefStart2[counterA][0]<<" "<<crossPositionListRefStart2[counterA][1]<<" "<<crossPositionListRefStart2[counterA][2]<<" SR(2, 3)"<<endl;
                //}
                
                //for (int counterA = 0; counterA < numberOfStartPoints; counterA++){
                //	cout<<crossDistanceRefEnd2 [counterA]<<" RS(DS)"<<endl;
                //}
                
                //for (int counterA = 0; counterA < numberOfStartPoints; counterA++){
                //	cout<<crossDistanceRefStart2 [counterA]<<" SR(DS)"<<endl;
                //}
                
                //------Block location check------
                for (int counter1 = 0; counter1 < numberOfStartPoints; counter1++){
                    if (crossPositionListRefEnd2 [counter1][0] != -1){
                        if (lineSet == 1|| lineSet== 2){
                            if ((startEndPositionList [counter1][3] < referenceXY [3] && startEndPositionList [counter1][0] < referenceXY [0]) || (startEndPositionList [counter1][4] > referenceXY [4] && startEndPositionList [counter1][1] > referenceXY [1])){
                                crossPositionListRefEnd2 [counter1][0] = -1;
                                crossPositionListRefEnd2 [counter1][1] = -1;
                                crossPositionListRefEnd2 [counter1][2] = -1;
                                crossDistanceRefEnd2 [counter1] = -1;
                            }
                        }
                        
                        if (lineSet == 3 || lineSet== 4){
                            if ((startEndPositionList [counter1][3] > referenceXY [3] && startEndPositionList [counter1][0] > referenceXY [0]) || (startEndPositionList [counter1][4] < referenceXY [4] && startEndPositionList [counter1][1] < referenceXY [1])){
                                crossPositionListRefEnd2 [counter1][0] = -1;
                                crossPositionListRefEnd2 [counter1][1] = -1;
                                crossPositionListRefEnd2 [counter1][2] = -1;
                                crossDistanceRefEnd2 [counter1] = -1;
                            }
                        }
                    }
                    
                    if (crossPositionListRefStart2 [counter1][0] != -1){
                        if (lineSet == 1|| lineSet== 2){
                            if ((startEndPositionList [counter1][0] > referenceXY [0] && startEndPositionList [counter1][3] > referenceXY [3]) || (startEndPositionList [counter1][1] < referenceXY [1] && startEndPositionList [counter1][4] < referenceXY [4])){
                                crossPositionListRefStart2 [counter1][0] = -1;
                                crossPositionListRefStart2 [counter1][1] = -1;
                                crossPositionListRefStart2 [counter1][2] = -1;
                                crossDistanceRefStart2 [counter1] = -1;
                            }
                        }
                        
                        if (lineSet == 3 || lineSet== 4){
                            if ((startEndPositionList [counter1][0] < referenceXY [0] && startEndPositionList [counter1][3] < referenceXY [3]) || (startEndPositionList [counter1][1] > referenceXY [1] && startEndPositionList [counter1][4] > referenceXY [4])){
                                crossPositionListRefStart2 [counter1][0] = -1;
                                crossPositionListRefStart2 [counter1][1] = -1;
                                crossPositionListRefStart2 [counter1][2] = -1;
                                crossDistanceRefStart2 [counter1] = -1;
                            }
                        }
                    }
                }
                
                //------Tail length compare, if extension makes length shorter, reject------
                for (int counter1 = 0; counter1 < numberOfStartPoints; counter1++){
                    if (crossPositionListRefEnd2 [counter1][0] != -1){
                        if (crossPositionListRefEnd2 [counter1][3] == 1){
                            if (referenceXY [5]-crossPositionListRefEnd2 [counter1][2] >= startEndPositionList [counter1][5]-startEndPositionList [counter1][2]){
                                crossPositionListRefEnd2 [counter1][0] = -1;
                                crossPositionListRefEnd2 [counter1][1] = -1;
                                crossPositionListRefEnd2 [counter1][2] = -1;
                                crossDistanceRefEnd2 [counter1] = -1;
                            }
                        }
                    }
                    
                    if (crossPositionListRefStart2 [counter1][0] != -1){
                        if (crossPositionListRefStart2 [counter1][3] == 3){
                            if (crossPositionListRefStart2 [counter1][2]-referenceXY [2] >= startEndPositionList [counter1][5]-startEndPositionList [counter1][2]){
                                crossPositionListRefStart2 [counter1][0] = -1;
                                crossPositionListRefStart2 [counter1][1] = -1;
                                crossPositionListRefStart2 [counter1][2] = -1;
                                crossDistanceRefStart2 [counter1] = -1;
                            }
                        }
                    }
                }
                
                //------Zero cross point------
                refEndZero = 0;
                refStartZero = 0;
                
                for (int counter1 = 0; counter1 < numberOfStartPoints; counter1++){
                    if (crossPositionListRefEnd2 [counter1][0] != -1){
                        if (crossDistanceRefEnd2 [counter1] == 0) refEndZero = 1;
                    }
                }
                
                for (int counter1 = 0; counter1 < numberOfStartPoints; counter1++){
                    if (crossPositionListRefStart2 [counter1][0] != -1){
                        if (crossDistanceRefStart2 [counter1] == 0) refStartZero = 1;
                    }
                }
                
                if (refEndZero == 1 && refStartZero == 1){
                    for (int counter1 = 0; counter1 < numberOfStartPoints; counter1++){
                        if (crossPositionListRefEnd2 [counter1][0] != -1){
                            if (crossDistanceRefEnd2 [counter1] == 0){
                                if (referenceXY [5]-crossPositionListRefEnd2 [counter1][2]+1 >= crossPositionListRefEnd2 [counter1][2]-referenceXY [0]+1){
                                    crossPositionListRefStart2 [counter1][0] = -1;
                                    crossPositionListRefStart2 [counter1][1] = -1;
                                    crossPositionListRefStart2 [counter1][2] = -1;
                                    crossDistanceRefStart2 [counter1] = -1;
                                }
                                else{
                                    
                                    crossPositionListRefEnd2 [counter1][0] = -1;
                                    crossPositionListRefEnd2 [counter1][1] = -1;
                                    crossPositionListRefEnd2 [counter1][2] = -1;
                                    crossDistanceRefEnd2 [counter1] = -1;
                                }
                            }
                        }
                    }
                }
                
                int *arrayGapDataStore = new int [500];
                int gapDataStoreCount = 0;
                int gapDataStoreLimit = 500;
                
                if (refEndZero != 1 && refStartZero != 1){
                    for (int counter1 = 0; counter1 < numberOfStartPoints; counter1++){
                        jumpX1 = 0;
                        jumpY1 = 0;
                        jumpX2 = 0;
                        jumpY2 = 0;
                        
                        if (crossPositionListRefEnd2 [counter1][0] != -1){
                            if (crossPositionListRefEnd2 [counter1][3] == 0){
                                jumpX1 = referenceXY [3];
                                jumpY1 = referenceXY [4];
                                jumpX2 = crossPositionListRefEnd2 [counter1][0];
                                jumpY2 = crossPositionListRefEnd2 [counter1][1];
                                
                                gapChaseCount = 0;
                                
                                for (int counter2 = referenceXY [2]; counter2 <= referenceXY [5]; counter2++){
                                    if (gapChaseCount+5 > gapChaseLimit) [self gapChaseUpdate];
                                    
                                    arrayGapChase [gapChaseCount] = arraySelectedBlock [counter2*6], gapChaseCount++;
                                    arrayGapChase [gapChaseCount] = arraySelectedBlock [counter2*6+1], gapChaseCount++;
                                    arrayGapChase [gapChaseCount] = 1, gapChaseCount++;
                                }
                                
                                for (int counter2 = crossPositionListRefEnd2 [counter1][2]; counter2 <= startEndPositionList[counter1][5]; counter2++){
                                    if (gapChaseCount+5 > gapChaseLimit) [self gapChaseUpdate];
                                    
                                    arrayGapChase [gapChaseCount] = arraySelectedBlock [counter2*6], gapChaseCount++;
                                    arrayGapChase [gapChaseCount] = arraySelectedBlock [counter2*6+1], gapChaseCount++;
                                    arrayGapChase [gapChaseCount] = 2, gapChaseCount++;
                                }
                                
                                //for (int counterA = 0; counterA < gapChaseCount/3; counterA++){
                                //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayGapChase [counterA*3+counterB];
                                //    cout<<" arrayGapChase "<<counterA<<endl;
                                //}
                            }
                            else if (crossPositionListRefEnd2 [counter1][3] == 1){
                                jumpX1 = crossPositionListRefEnd2 [counter1][0];
                                jumpY1 = crossPositionListRefEnd2 [counter1][1];
                                jumpX2 = startEndPositionList[counter1][0];
                                jumpY2 = startEndPositionList[counter1][1];
                                
                                gapChaseCount = 0;
                                
                                for (int counter2 = referenceXY [2]; counter2 <= crossPositionListRefEnd2 [counter1][2]; counter2++){
                                    if (gapChaseCount+5 > gapChaseLimit) [self gapChaseUpdate];
                                    
                                    arrayGapChase [gapChaseCount] = arraySelectedBlock [counter2*6], gapChaseCount++;
                                    arrayGapChase [gapChaseCount] = arraySelectedBlock [counter2*6+1], gapChaseCount++;
                                    arrayGapChase [gapChaseCount] = 1, gapChaseCount++;
                                }
                                
                                for (int counter2 = startEndPositionList[counter1][2]; counter2 <= startEndPositionList[counter1][5]; counter2++){
                                    if (gapChaseCount+5 > gapChaseLimit) [self gapChaseUpdate];
                                    
                                    arrayGapChase [gapChaseCount] = arraySelectedBlock [counter2*6], gapChaseCount++;
                                    arrayGapChase [gapChaseCount] = arraySelectedBlock [counter2*6+1], gapChaseCount++;
                                    arrayGapChase [gapChaseCount] = 2, gapChaseCount++;
                                }
                            }
                            
                            gapChase2 = [[GapChase2 alloc] init];
                            chaseResult = [gapChase2 gapChaseing2:jumpX1:jumpY1:jumpX2:jumpY2:lineSet];
                            
                            if (chaseResult == 0){ //------If it is successful, save data------
                                if (gapChaseCount*2+gapDataStoreCount+10 > gapDataStoreLimit){
                                    int *arraySourceTemp = new int [gapDataStoreCount+50];
                                    for (int counter2 = 0; counter2 < gapDataStoreCount; counter2++) arraySourceTemp [counter2] = arrayGapDataStore [counter2];
                                    
                                    delete [] arrayGapDataStore;
                                    arrayGapDataStore = new int [gapChaseCount*2+gapDataStoreCount+500];
                                    gapDataStoreLimit = gapChaseCount*2+gapDataStoreCount+500;
                                    
                                    for (int counter2 = 0; counter2 < gapDataStoreCount; counter2++) arrayGapDataStore [counter2] = arraySourceTemp [counter2];
                                    delete [] arraySourceTemp;
                                }
                                
                                for (int counter2 = 0; counter2 < gapChaseCount/3; counter2++){
                                    arrayGapDataStore [gapDataStoreCount] = arrayGapChase [counter2*3], gapDataStoreCount++;
                                    arrayGapDataStore [gapDataStoreCount] = arrayGapChase [counter2*3+1], gapDataStoreCount++;
                                    arrayGapDataStore [gapDataStoreCount] = arrayGapChase [counter2*3+2], gapDataStoreCount++;
                                    arrayGapDataStore [gapDataStoreCount] = counter1, gapDataStoreCount++;
                                    arrayGapDataStore [gapDataStoreCount] = 0, gapDataStoreCount++;
                                }
                            }
                            else{
                                
                                crossPositionListRefEnd2 [counter1][0] = -1;
                                crossPositionListRefEnd2 [counter1][1] = -1;
                                crossPositionListRefEnd2 [counter1][2] = -1;
                                crossDistanceRefEnd2 [counter1] = -1;
                            }
                        }
                        
                        if (crossPositionListRefStart2 [counter1][0] != -1){
                            if (crossPositionListRefStart2 [counter1][3] == 2){
                                jumpX1 = crossPositionListRefStart2 [counter1][0];
                                jumpY1 = crossPositionListRefStart2 [counter1][1];
                                jumpX2 = referenceXY [0];
                                jumpY2 = referenceXY [1];
                                
                                gapChaseCount = 0;
                                
                                for (int counter2 = crossPositionListRefStart2 [counter1][2]; counter2 <= startEndPositionList[counter1][5]; counter2++){
                                    if (gapChaseCount+5 > gapChaseLimit) [self gapChaseUpdate];
                                    
                                    arrayGapChase [gapChaseCount] = arraySelectedBlock [counter2*6], gapChaseCount++;
                                    arrayGapChase [gapChaseCount] = arraySelectedBlock [counter2*6+1], gapChaseCount++;
                                    arrayGapChase [gapChaseCount] = 1, gapChaseCount++;
                                }
                                
                                for (int counter2 = referenceXY [2]; counter2 <= referenceXY [5]; counter2++){
                                    if (gapChaseCount+5 > gapChaseLimit) [self gapChaseUpdate];
                                    
                                    arrayGapChase [gapChaseCount] = arraySelectedBlock [counter2*6], gapChaseCount++;
                                    arrayGapChase [gapChaseCount] = arraySelectedBlock [counter2*6+1], gapChaseCount++;
                                    arrayGapChase [gapChaseCount] = 2, gapChaseCount++;
                                }
                            }
                            else if (crossPositionListRefStart2 [counter1][3] == 3){
                                jumpX1 = startEndPositionList[counter1][3];
                                jumpY1 = startEndPositionList[counter1][4];
                                jumpX2 = crossPositionListRefStart2 [counter1][0];
                                jumpY2 = crossPositionListRefStart2 [counter1][1];
                                
                                gapChaseCount = 0;
                                
                                for (int counter2 = startEndPositionList[counter1][2]; counter2 <= startEndPositionList[counter1][5]; counter2++){
                                    if (gapChaseCount+5 > gapChaseLimit) [self gapChaseUpdate];
                                    
                                    arrayGapChase [gapChaseCount] = arraySelectedBlock [counter2*6], gapChaseCount++;
                                    arrayGapChase [gapChaseCount] = arraySelectedBlock [counter2*6+1], gapChaseCount++;
                                    arrayGapChase [gapChaseCount] = 1, gapChaseCount++;
                                }
                                
                                for (int counter2 = crossPositionListRefStart2 [counter1][2]; counter2 <= referenceXY [5]; counter2++){
                                    if (gapChaseCount+5 > gapChaseLimit) [self gapChaseUpdate];
                                    
                                    arrayGapChase [gapChaseCount] = arraySelectedBlock [counter2*6], gapChaseCount++;
                                    arrayGapChase [gapChaseCount] = arraySelectedBlock [counter2*6+1], gapChaseCount++;
                                    arrayGapChase [gapChaseCount] = 2, gapChaseCount++;
                                }
                                
                                //for (int counterA = 0; counterA < gapChaseCount/3; counterA++){
                                //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayGapChase [counterA*3+counterB];
                                //    cout<<" arrayGapChase "<<counterA<<endl;
                                //}
                            }
                            
                            gapChase2 = [[GapChase2 alloc] init];
                            chaseResult = [gapChase2 gapChaseing2:jumpX1:jumpY1:jumpX2:jumpY2:lineSet];
                            
                            if (chaseResult == 0){
                                if (gapChaseCount*2+gapDataStoreCount+10 > gapDataStoreLimit){
                                    int *arraySourceTemp = new int [gapDataStoreCount+50];
                                    for (int counter2 = 0; counter2 < gapDataStoreCount; counter2++) arraySourceTemp [counter2] = arrayGapDataStore [counter2];
                                    
                                    delete [] arrayGapDataStore;
                                    arrayGapDataStore = new int [gapChaseCount*2+gapDataStoreCount+500];
                                    gapDataStoreLimit = gapChaseCount*2+gapDataStoreCount+500;
                                    
                                    for (int counter2 = 0; counter2 < gapDataStoreCount; counter2++) arrayGapDataStore [counter2] = arraySourceTemp [counter2];
                                    delete [] arraySourceTemp;
                                }
                                
                                for (int counter2 = 0; counter2 < gapChaseCount/3; counter2++){
                                    arrayGapDataStore [gapDataStoreCount] = arrayGapChase [counter2*3], gapDataStoreCount++;
                                    arrayGapDataStore [gapDataStoreCount] = arrayGapChase [counter2*3+1], gapDataStoreCount++;
                                    arrayGapDataStore [gapDataStoreCount] = arrayGapChase [counter2*3+2], gapDataStoreCount++;
                                    arrayGapDataStore [gapDataStoreCount] = counter1, gapDataStoreCount++;
                                    arrayGapDataStore [gapDataStoreCount] = 1, gapDataStoreCount++;
                                }
                            }
                            else{
                                
                                crossPositionListRefStart2 [counter1][0] = -1;
                                crossPositionListRefStart2 [counter1][1] = -1;
                                crossPositionListRefStart2 [counter1][2] = -1;
                                crossDistanceRefStart2 [counter1] = -1;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < gapDataStoreCount/5; counterA++){
                        //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayGapDataStore [counterA*5+counterB];
                        //    cout<<" arrayGapDataStore "<<counterA<<endl;
                        //}
                    }
                    
                    //for (int counterA = 0; counterA < numberOfStartPoints; counterA++){
                    //	cout<<crossPositionListRefEnd2[counterA][0]<<" "<<crossPositionListRefEnd2[counterA][1]<<" "<<crossPositionListRefEnd2 [counterA][2]<<" 2RS(0, 1)"<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < numberOfStartPoints; counterA++){
                    //	cout<<crossPositionListRefStart2[counterA][0]<<" "<<crossPositionListRefStart2[counterA][1]<<" "<<crossPositionListRefStart2 [counterA][2]<<" 2SR(2, 3)"<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < numberOfStartPoints; counterA++){
                    //	cout<<crossDistanceRefEnd2 [counterA]<<" 2RS(DS)"<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < numberOfStartPoints; counterA++){
                    //	cout<<crossDistanceRefStart2 [counterA]<<" 2SR(DS)"<<endl;
                    //}
                }
                
                shortestDistance1 = 10000;
                shortestDistanceCount1 = -1;
                
                for (int counter1 = 0; counter1 < numberOfStartPoints; counter1++){
                    if (shortestDistance1 > crossDistanceRefEnd2 [counter1] && crossDistanceRefEnd2 [counter1] != -1){
                        shortestDistance1 = crossDistanceRefEnd2 [counter1];
                        shortestDistanceCount1 = counter1;
                    }
                }
                
                shortestDistance2 = 10000;
                shortestDistanceCount2 = -1;
                
                for (int counter1 = 0; counter1 < numberOfStartPoints; counter1++){
                    if (shortestDistance2 > crossDistanceRefStart2 [counter1] && crossDistanceRefStart2 [counter1] != -1){
                        shortestDistance2 = crossDistanceRefStart2 [counter1];
                        shortestDistanceCount2 = counter1;
                    }
                }
                
                if (shortestDistanceCount1 == -1 && shortestDistanceCount2 == -1){
                    newBlockFind++;
                    
                    for (int counter1 = 0; counter1 <= referenceXY [5]; counter1++){
                        if (selectedBlockReturnCount+10 > selectedBlockReturnLimit){
                            int *arraySourceTemp = new int [selectedBlockReturnCount+50];
                            for (int counter2 = 0; counter2 < selectedBlockReturnCount; counter2++) arraySourceTemp [counter2] = arraySelectedBlockReturn [counter2];
                            
                            delete [] arraySelectedBlockReturn;
                            arraySelectedBlockReturn = new int [selectedBlockReturnLimit+1000];
                            selectedBlockReturnLimit = selectedBlockReturnLimit+1000;
                            
                            for (int counter2 = 0; counter2 < selectedBlockReturnCount; counter2++) arraySelectedBlockReturn [counter2] = arraySourceTemp [counter2];
                            delete [] arraySourceTemp;
                        }
                        
                        arraySelectedBlockReturn [selectedBlockReturnCount] = arraySelectedBlock [counter1*6], selectedBlockReturnCount++;
                        arraySelectedBlockReturn [selectedBlockReturnCount] = arraySelectedBlock [counter1*6+1], selectedBlockReturnCount++;
                        arraySelectedBlockReturn [selectedBlockReturnCount] = arraySelectedBlock [counter1*6+2], selectedBlockReturnCount++;
                        arraySelectedBlockReturn [selectedBlockReturnCount] = newBlockFind, selectedBlockReturnCount++;
                        arraySelectedBlockReturn [selectedBlockReturnCount] = arraySelectedBlock [counter1*6+4], selectedBlockReturnCount++;
                        arraySelectedBlockReturn [selectedBlockReturnCount] = arraySelectedBlock [counter1*6+5], selectedBlockReturnCount++;
                    }
                    
                    int *arrayReference2 = new int [selectedBlockCount+50], referenceCount2 = 0;
                    
                    for (int counter1 = referenceXY [5]+1; counter1 < selectedBlockCount/6; counter1++){
                        arrayReference2 [referenceCount2] = arraySelectedBlock [counter1*6], referenceCount2++; //------X position------0
                        arrayReference2 [referenceCount2] = arraySelectedBlock [counter1*6+1], referenceCount2++; //------Y position------1
                        arrayReference2 [referenceCount2] = arraySelectedBlock [counter1*6+2], referenceCount2++; //------Pixel value------2
                        arrayReference2 [referenceCount2] = arraySelectedBlock [counter1*6+3], referenceCount2++;
                        arrayReference2 [referenceCount2] = arraySelectedBlock [counter1*6+4], referenceCount2++;
                        arrayReference2 [referenceCount2] = arraySelectedBlock [counter1*6+5], referenceCount2++;
                    }
                    
                    if (selectedBlockStatus == 1) delete [] arraySelectedBlock;
                    arraySelectedBlock = new int [referenceCount2+50], selectedBlockCount = 0, selectedBlockStatus = 1;
                    
                    for (int counter1 = 0; counter1 < referenceCount2/6; counter1++){
                        arraySelectedBlock [selectedBlockCount] = arrayReference2 [counter1*6], selectedBlockCount++; //------X position------0
                        arraySelectedBlock [selectedBlockCount] = arrayReference2 [counter1*6+1], selectedBlockCount++; //------Y position------1
                        arraySelectedBlock [selectedBlockCount] = arrayReference2 [counter1*6+2], selectedBlockCount++; //------Pixel value------2
                        arraySelectedBlock [selectedBlockCount] = arrayReference2 [counter1*6+3], selectedBlockCount++;
                        arraySelectedBlock [selectedBlockCount] = arrayReference2 [counter1*6+4], selectedBlockCount++;
                        arraySelectedBlock [selectedBlockCount] = arrayReference2 [counter1*6+5], selectedBlockCount++;
                    }
                    
                    delete [] arrayReference2;
                    
                    //for (int counterA = 0; counterA < selectedBlockCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arraySelectedBlock [counterA*6+counterB];
                    //	cout<<" arraySelectedBlock"<<counterA<<endl;
                    //}
                }
                else{
                    
                    subBlockStart = 0;
                    subBlockEnd = 0;
                    
                    //cout<<shortestDistance1<<" "<<shortestDistanceCount1<<" "<<shortestDistance2<<" "<<shortestDistanceCount2<<" Distances_count"<<endl;
                    
                    int *arrayBlockBuildTemp;
                    
                    if ((shortestDistance1 != 10000 && shortestDistance2 != 10000 && shortestDistance1 <= shortestDistance2) || (shortestDistance1 != 10000 && shortestDistance2 == 10000)){
                        if (crossPositionListRefEnd2 [shortestDistanceCount1][3] == 0){
                            firstBlock = referenceXY [2];
                            firstEnd = referenceXY [5];
                            secondConnect = crossPositionListRefEnd2 [shortestDistanceCount1][2];
                            secondEnd = startEndPositionList[shortestDistanceCount1][5];
                            
                            subBlockStart = startEndPositionList[shortestDistanceCount1][2];
                            subBlockEnd = startEndPositionList[shortestDistanceCount1][5];
                            
                            if (shortestDistance1 == 0) firstEnd = firstEnd-1;
                            
                            adjustArraySize = 0;
                            
                            if (firstEnd-firstBlock > 0) adjustArraySize = (firstEnd-firstBlock)*6;
                            adjustArraySize = adjustArraySize+gapDataStoreCount*2;
                            if (secondEnd-secondConnect > 0) adjustArraySize = adjustArraySize+(secondEnd-secondConnect)*6;
                            
                            arrayBlockBuildTemp = new int [adjustArraySize+500], blockBuildTempCount = 0, blockBuildTempStatus = 1;
                            
                            for (int counter1 = firstBlock; counter1 <= firstEnd; counter1++){
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6], blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6+1], blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6+2], blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = 1, blockBuildTempCount++;
                                
                                if (counter1 == firstBlock) arrayBlockBuildTemp [blockBuildTempCount] = 1, blockBuildTempCount++;
                                else arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                            }
                            
                            //for (int counterA = 0; counterA < blockBuildTempCount/6; counterA++){
                            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayBlockBuildTemp [counterA*6+counterB];
                            //    cout<<" arrayBlockBuildTemp "<<counterA<<endl;
                            //}
                            
                            for (int counter1 = 0; counter1 < gapDataStoreCount/5; counter1++){
                                if (arrayGapDataStore [counter1*5+3] == shortestDistanceCount1 && arrayGapDataStore [counter1*5+4] == 0){
                                    arrayBlockBuildTemp [blockBuildTempCount] = arrayGapDataStore [counter1*5], blockBuildTempCount++;
                                    arrayBlockBuildTemp [blockBuildTempCount] = arrayGapDataStore [counter1*5+1], blockBuildTempCount++;
                                    arrayBlockBuildTemp [blockBuildTempCount] = arrayGapDataStore [counter1*5+2], blockBuildTempCount++;
                                    arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                                    arrayBlockBuildTemp [blockBuildTempCount] = 1, blockBuildTempCount++;
                                    arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < blockBuildTempCount/6; counterA++){
                            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayBlockBuildTemp [counterA*6+counterB];
                            //    cout<<" arrayBlockBuildTemp "<<counterA<<endl;
                            //}
                            
                            for (int counter1 = secondConnect; counter1 <= secondEnd; counter1++){
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6], blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6+1], blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6+2], blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = 1, blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                            }
                        }
                        
                        if (crossPositionListRefEnd2 [shortestDistanceCount1][3] == 1){
                            firstBlock = 0;
                            firstConnect = crossPositionListRefEnd2 [shortestDistanceCount1][2];
                            secondBlock = startEndPositionList[shortestDistanceCount1][2];
                            secondEnd = startEndPositionList[shortestDistanceCount1][5];
                            subBlockStart = startEndPositionList[shortestDistanceCount1][2];
                            subBlockEnd = startEndPositionList[shortestDistanceCount1][5];
                            
                            if (shortestDistance1 == 0) firstConnect = firstConnect-1;
                            
                            adjustArraySize = 0;
                            
                            if (firstConnect-firstBlock > 0) adjustArraySize = (firstConnect-firstBlock)*6;
                            adjustArraySize = adjustArraySize+gapDataStoreCount*2;
                            if (secondEnd-secondBlock > 0) adjustArraySize = adjustArraySize+(secondEnd-secondBlock)*6;
                            
                            arrayBlockBuildTemp = new int [adjustArraySize+500], blockBuildTempCount = 0, blockBuildTempStatus = 1;
                            
                            for (int counter1 = firstBlock; counter1 <= firstConnect; counter1++){
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6], blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6+1], blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6+2], blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = 1, blockBuildTempCount++;
                                
                                if (counter1 == firstBlock) arrayBlockBuildTemp [blockBuildTempCount] = 1, blockBuildTempCount++;
                                else arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                            }
                            
                            for (int counter1 = 0; counter1 < gapDataStoreCount/5; counter1++){
                                if (arrayGapDataStore [counter1*5+3] == shortestDistanceCount1 && arrayGapDataStore [counter1*5+4] == 0){
                                    arrayBlockBuildTemp [blockBuildTempCount] = arrayGapDataStore [counter1*5], blockBuildTempCount++;
                                    arrayBlockBuildTemp [blockBuildTempCount] = arrayGapDataStore [counter1*5+1], blockBuildTempCount++;
                                    arrayBlockBuildTemp [blockBuildTempCount] = arrayGapDataStore [counter1*5+2], blockBuildTempCount++;
                                    arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                                    arrayBlockBuildTemp [blockBuildTempCount] = 1, blockBuildTempCount++;
                                    arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                                }
                            }
                            
                            for (int counter1 = secondBlock; counter1 <= secondEnd; counter1++){
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6] , blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6+1], blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6+2], blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = 1, blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                            }
                            
                            //for (int counterA = 0; counterA < blockBuildTempCount/6; counterA++){
                            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayBlockBuildTemp [counterA*6+counterB];
                            //    cout<<" arrayBlockBuildTemp "<<counterA<<endl;
                            //}
                        }
                    }
                    
                    if ((shortestDistance1 != 10000 && shortestDistance2 != 10000 && shortestDistance1 > shortestDistance2) || (shortestDistance1 == 10000 && shortestDistance2 != 10000)){
                        if (crossPositionListRefStart2 [shortestDistanceCount2][3] == 2){
                            firstBlock = startEndPositionList[shortestDistanceCount2][2];
                            firstConnect = crossPositionListRefStart2 [shortestDistanceCount2][2];
                            secondBlock = 0;
                            secondEnd = referenceXY [5];
                            
                            subBlockStart = startEndPositionList[shortestDistanceCount2][2];
                            subBlockEnd = startEndPositionList[shortestDistanceCount2][5];
                            
                            if (shortestDistance1 == 0) firstConnect = firstConnect-1;
                            
                            adjustArraySize = 0;
                            
                            if (firstConnect-firstBlock > 0) adjustArraySize = (firstConnect-firstBlock)*6;
                            adjustArraySize = adjustArraySize+gapDataStoreCount*2;
                            if (secondEnd-secondBlock > 0) adjustArraySize = adjustArraySize+(secondEnd-secondBlock)*6;
                            
                            arrayBlockBuildTemp = new int [adjustArraySize+500], blockBuildTempCount = 0, blockBuildTempStatus = 1;
                            
                            for (int counter1 = firstBlock; counter1 <= firstConnect; counter1++){
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6], blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6+1], blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6+2], blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = 1, blockBuildTempCount++;
                                
                                if (counter1 == firstBlock) arrayBlockBuildTemp [blockBuildTempCount] = 1, blockBuildTempCount++;
                                else arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                            }
                            
                            for (int counter1 = 0; counter1 < gapDataStoreCount/5; counter1++){
                                if (arrayGapDataStore [counter1*5+3] == shortestDistanceCount2 && arrayGapDataStore [counter1*5+4] == 1){
                                    arrayBlockBuildTemp [blockBuildTempCount] = arrayGapDataStore [counter1*5], blockBuildTempCount++;
                                    arrayBlockBuildTemp [blockBuildTempCount] = arrayGapDataStore [counter1*5+1], blockBuildTempCount++;
                                    arrayBlockBuildTemp [blockBuildTempCount] = arrayGapDataStore [counter1*5+2], blockBuildTempCount++;
                                    arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                                    arrayBlockBuildTemp [blockBuildTempCount] = 1, blockBuildTempCount++;
                                    arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                                }
                            }
                            
                            for (int counter1 = secondBlock; counter1 <= secondEnd; counter1++){
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6], blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6+1], blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6+2], blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = 1, blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                            }
                        }
                        
                        if (crossPositionListRefStart2 [shortestDistanceCount2][3] == 3){
                            firstBlock = startEndPositionList[shortestDistanceCount2][2];
                            firstEnd = startEndPositionList[shortestDistanceCount2][5];
                            secondConnect = crossPositionListRefStart2 [shortestDistanceCount2][2];
                            secondEnd = referenceXY [5];
                            
                            subBlockStart = startEndPositionList[shortestDistanceCount2][2];
                            subBlockEnd = startEndPositionList[shortestDistanceCount2][5];
                            
                            if (shortestDistance1 == 0) firstEnd = firstEnd-1;
                            
                            adjustArraySize = 0;
                            
                            if (firstEnd-firstBlock > 0) adjustArraySize = (firstEnd-firstBlock)*6;
                            adjustArraySize = adjustArraySize+gapDataStoreCount*2;
                            if (secondEnd-secondConnect > 0) adjustArraySize = adjustArraySize+(secondEnd-secondConnect)*6;
                            
                            arrayBlockBuildTemp = new int [adjustArraySize+500], blockBuildTempCount = 0, blockBuildTempStatus = 1;
                            
                            for (int counter1 = firstBlock; counter1 <= firstEnd; counter1++){
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6], blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6+1], blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6+2], blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = 1, blockBuildTempCount++;
                                
                                if (counter1 == firstBlock) arrayBlockBuildTemp [blockBuildTempCount] = 1, blockBuildTempCount++;
                                else arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                            }
                            
                            for (int counter1 = 0; counter1 < gapDataStoreCount/5; counter1++){
                                if (arrayGapDataStore [counter1*5+3] == shortestDistanceCount2 && arrayGapDataStore [counter1*5+4] == 1){
                                    arrayBlockBuildTemp [blockBuildTempCount] = arrayGapDataStore [counter1*5], blockBuildTempCount++;
                                    arrayBlockBuildTemp [blockBuildTempCount] = arrayGapDataStore [counter1*5+1], blockBuildTempCount++;
                                    arrayBlockBuildTemp [blockBuildTempCount] = arrayGapDataStore [counter1*5+2], blockBuildTempCount++;
                                    arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                                    arrayBlockBuildTemp [blockBuildTempCount] = 1, blockBuildTempCount++;
                                    arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                                }
                            }
                            
                            for (int counter1 = secondConnect; counter1 <= secondEnd; counter1++){
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6], blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6+1], blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = arraySelectedBlock [counter1*6+2], blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = 1, blockBuildTempCount++;
                                arrayBlockBuildTemp [blockBuildTempCount] = 0, blockBuildTempCount++;
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < blockBuildTempCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayBlockBuildTemp [counterA*6+counterB];
                    //	cout<<" arrayBlockBuildTemp "<<counterA<<endl;
                    //}
                    
                    int *arrayReference2 = new int [subBlockStart*6+selectedBlockCount+500], referenceCount2 = 0;
                    
                    for (int counter1 = referenceXY [5]+1; counter1 <= subBlockStart-1; counter1++){
                        arrayReference2 [referenceCount2] = arraySelectedBlock [counter1*6], referenceCount2++; //------X position------0
                        arrayReference2 [referenceCount2] = arraySelectedBlock [counter1*6+1], referenceCount2++; //------Y position------1
                        arrayReference2 [referenceCount2] = arraySelectedBlock [counter1*6+2], referenceCount2++; //------Pixel value------2
                        arrayReference2 [referenceCount2] = arraySelectedBlock [counter1*6+3], referenceCount2++; //------Block------3
                        arrayReference2 [referenceCount2] = arraySelectedBlock [counter1*6+4], referenceCount2++;
                        arrayReference2 [referenceCount2] = arraySelectedBlock [counter1*6+5], referenceCount2++;
                    }
                    
                    for (int counter1 = subBlockEnd+1; counter1 < selectedBlockCount/6; counter1++){
                        arrayReference2 [referenceCount2] = arraySelectedBlock [counter1*6], referenceCount2++; //------X position------0
                        arrayReference2 [referenceCount2] = arraySelectedBlock [counter1*6+1], referenceCount2++; //------Y position------1
                        arrayReference2 [referenceCount2] = arraySelectedBlock [counter1*6+2], referenceCount2++; //------Pixel value------2
                        arrayReference2 [referenceCount2] = arraySelectedBlock [counter1*6+3], referenceCount2++;
                        arrayReference2 [referenceCount2] = arraySelectedBlock [counter1*6+4], referenceCount2++;
                        arrayReference2 [referenceCount2] = arraySelectedBlock [counter1*6+5], referenceCount2++;
                    }
                    
                    //for (int counterA = 0; counterA < referenceCount2/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayReference2 [counterA*6+counterB];
                    //	cout<<" arrayReference2 "<<counterA<<endl;
                    //}
                    
                    if (selectedBlockStatus == 1) delete [] arraySelectedBlock;
                    arraySelectedBlock = new int [blockBuildTempCount+referenceCount2+500], selectedBlockCount = 0, selectedBlockStatus = 1;
                    
                    for (int counter1 = 0; counter1 < blockBuildTempCount/6; counter1++){
                        arraySelectedBlock [selectedBlockCount] = arrayBlockBuildTemp [counter1*6], selectedBlockCount++; //------X position------0
                        arraySelectedBlock [selectedBlockCount] = arrayBlockBuildTemp [counter1*6+1], selectedBlockCount++; //------Y position------1
                        arraySelectedBlock [selectedBlockCount] = arrayBlockBuildTemp [counter1*6+2], selectedBlockCount++; //------Pixel value------2
                        arraySelectedBlock [selectedBlockCount] = 1, selectedBlockCount++;
                        arraySelectedBlock [selectedBlockCount] = arrayBlockBuildTemp [counter1*6+4], selectedBlockCount++;
                        arraySelectedBlock [selectedBlockCount] = arrayBlockBuildTemp [counter1*6+5], selectedBlockCount++;
                    }
                    
                    arraySelectedBlock [(selectedBlockCount/6-1)*6+5] = 2;
                    
                    for (int counter1 = 0; counter1 < referenceCount2/6; counter1++){
                        arraySelectedBlock [selectedBlockCount] = arrayReference2 [counter1*6], selectedBlockCount++; //------X position------0
                        arraySelectedBlock [selectedBlockCount] = arrayReference2 [counter1*6+1], selectedBlockCount++; //------Y position------1
                        arraySelectedBlock [selectedBlockCount] = arrayReference2 [counter1*6+2], selectedBlockCount++; //------Pixel value------2
                        arraySelectedBlock [selectedBlockCount] = arrayReference2 [counter1*6+3], selectedBlockCount++;
                        arraySelectedBlock [selectedBlockCount] = arrayReference2 [counter1*6+4], selectedBlockCount++;
                        arraySelectedBlock [selectedBlockCount] = arrayReference2 [counter1*6+5], selectedBlockCount++;
                    }
                    
                    //for (int counterA = 0; counterA < selectedBlockCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arraySelectedBlock [counterA*6+counterB];
                    //	cout<<" arraySelectedBlock "<<counterA<<endl;
                    //}
                    
                    if (blockBuildTempStatus == 1) delete [] arrayBlockBuildTemp;
                    
                    delete [] arrayReference2;
                }
                
                for (int counter1 = 0; counter1 < numberOfStartPoints+50; counter1++){
                    delete [] startEndPositionList [counter1];
                    delete [] crossPositionListRefEnd2 [counter1];
                    delete [] crossPositionListRefStart2 [counter1];
                }
                
                delete [] startEndPositionList;
                delete [] crossPositionListRefEnd2;
                delete [] crossPositionListRefStart2;
                
                delete [] crossDistanceRefEnd2;
                delete [] crossDistanceRefStart2;
                delete [] arrayGapDataStore;
            }
            
        } while (terminationFlag == 1);
    }
    
    if (lineSet == 1){
        delete [] arrayLineFive;
        arrayLineFive = new int [selectedBlockReturnCount+500], lineFiveCount = 0;
        
        for (int counter1 = 0; counter1 < selectedBlockReturnCount/6; counter1++){
            arrayLineFive [lineFiveCount] = arraySelectedBlockReturn [counter1*6], lineFiveCount++; //------X Position------0
            arrayLineFive [lineFiveCount] = arraySelectedBlockReturn [counter1*6+1], lineFiveCount++; //------Y position------1
            arrayLineFive [lineFiveCount] = arraySelectedBlockReturn [counter1*6+2], lineFiveCount++; //------Value------2
            arrayLineFive [lineFiveCount] = arraySelectedBlockReturn [counter1*6+3], lineFiveCount++; //------Block------3
            arrayLineFive [lineFiveCount] = arraySelectedBlockReturn [counter1*6+4], lineFiveCount++; //------Combine------4
            arrayLineFive [lineFiveCount] = arraySelectedBlockReturn [counter1*6+5], lineFiveCount++;
        }
    }
    
    if (lineSet == 3){
        delete [] arrayLineSeven;
        arrayLineSeven = new int [selectedBlockReturnCount+500], lineSevenCount = 0;
        
        for (int counter1 = 0; counter1 < selectedBlockReturnCount/6; counter1++){
            arrayLineSeven [lineSevenCount] = arraySelectedBlockReturn [counter1*6], lineSevenCount++;
            arrayLineSeven [lineSevenCount] = arraySelectedBlockReturn [counter1*6+1], lineSevenCount++;
            arrayLineSeven [lineSevenCount] = arraySelectedBlockReturn [counter1*6+2], lineSevenCount++;
            arrayLineSeven [lineSevenCount] = arraySelectedBlockReturn [counter1*6+3], lineSevenCount++;
            arrayLineSeven [lineSevenCount] = arraySelectedBlockReturn [counter1*6+4], lineSevenCount++;
            arrayLineSeven [lineSevenCount] = arraySelectedBlockReturn [counter1*6+5], lineSevenCount++;
        }
    }
    
    if (selectedBlockStatus == 1) delete [] arraySelectedBlock;
    delete [] arraySelectedBlockReturn;
}

-(void)gapChaseUpdate{
    int *arrayGapUpDate = new int [gapChaseCount+10];
    for (int counter1 = 0; counter1 < gapChaseCount; counter1++) arrayGapUpDate [counter1] = arrayGapChase [counter1];
    
    delete [] arrayGapChase;
    arrayGapChase = new int [gapChaseLimit+500];
    gapChaseLimit = gapChaseLimit+500;
    
    for (int counter1 = 0; counter1 < gapChaseCount; counter1++) arrayGapChase [counter1] = arrayGapUpDate [counter1];
    delete [] arrayGapUpDate;
}

@end
