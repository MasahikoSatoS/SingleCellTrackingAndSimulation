//
// UpDateLine.mm
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 09/02/13.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#import "UpDateLine.h"

@implementation UpDateLine

-(void)upDateLineMain:(int)counter{
    //------Dimension of Previous Connect------
    int maxForNextCount = 0;
    int maxPointDimX = 0;
    int maxPointDimY = 0;
    int minPointDimX = 100000;
    int minPointDimY = 100000;
    
    for (int counter1 = 0; counter1 < forNextConnectivityCount/5; counter1++){
        if (maxForNextCount < arrayForNextConnectivity [counter1*5+3]) maxForNextCount = arrayForNextConnectivity [counter1*5+3];
    }
    
    //------Check whether line pass non permitted area------
    int maxLinkedUpdateCount = 0;
    
    if (linkedLineUpdateCount/5 != 0){
        for (int counter1 = 0; counter1 < linkedLineUpdateCount/5; counter1++){
            if (maxLinkedUpdateCount < arrayLinkedLineUpdate [counter1*5+3]) maxLinkedUpdateCount = arrayLinkedLineUpdate [counter1*5+3];
        }
    }
    
    int vectorNumberSave = 0;
    
    if (counter <= maxForNextCount) vectorNumberSave = counter;
    else if (counter > maxForNextCount) vectorNumberSave = maxLinkedUpdateCount+1;
    else if (vectorNumberSave == 0 && maxForNextCount == 0) vectorNumberSave = 1;
    
    //-----------Exist Line-----------
    if (counter <= maxForNextCount){
        if (linkedLineCount == 0){
            if (outlineExistCount != 0){
                int startFlag = 0;
                
                for (int counter1 = 0; counter1 < outlineExistCount/3; counter1++){
                    if (arrayOutlineExist [counter1*3] == counter){
                        if (linkedLineUpdateCount+5 > linkedLineUpdateLimit) [self linkedLineSizeUpDate];
                        
                        arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayOutlineExist [counter1*3+1], linkedLineUpdateCount++;
                        arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayOutlineExist [counter1*3+2], linkedLineUpdateCount++;
                        arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayExtractedImage [arrayOutlineExist [counter1*3+2]][arrayOutlineExist [counter1*3+1]], linkedLineUpdateCount++;
                        arrayLinkedLineUpdate [linkedLineUpdateCount] = vectorNumberSave, linkedLineUpdateCount++;
                        
                        if (startFlag == 0) startFlag = 1, arrayLinkedLineUpdate [linkedLineUpdateCount] = 1, linkedLineUpdateCount++;
                        else arrayLinkedLineUpdate [linkedLineUpdateCount] = 0, linkedLineUpdateCount++;
                    }
                }
                
                if (linkedLineUpdateCount != 0){
                    int linkedLineUpdateTemp = (linkedLineUpdateCount/5-1)*5+4;
                    arrayLinkedLineUpdate [linkedLineUpdateTemp] = 2;
                    
                    //for (int counterA = 0; counterA < linkedLineUpdateCount/5; counterA++){
                    //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayLinkedLineUpdate [counterA*5+counterB];
                    //	cout<<" arrayLinkedLineUpdate "<<counterA<<endl;
                    //}
                    
                    for (int counter1 = 0; counter1 < outlineExistAssCount/6; counter1++){
                        if (arrayOutlineExistAss [counter1*6] == counter){
                            if (linkedLineUpdateAssCount+6 > linkedLineUpdateAssLimit) [self linkedLineAssSizeUpDate];
                            
                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = vectorNumberSave, linkedLineUpdateAssCount++;
                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = arrayOutlineExistAss [counter1*6+1], linkedLineUpdateAssCount++;
                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = arrayOutlineExistAss [counter1*6+2], linkedLineUpdateAssCount++;
                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = arrayOutlineExistAss [counter1*6+3], linkedLineUpdateAssCount++;
                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = arrayOutlineExistAss [counter1*6+4], linkedLineUpdateAssCount++;
                            arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                            break;
                        }
                    }
                }
            }
        }
        else{
            
            for (int counter1 = 0; counter1 < outlineExistCount/3; counter1++){
                if (arrayOutlineExist [counter1*3] == counter){
                    if (maxPointDimX < arrayOutlineExist [counter1*3+1]) maxPointDimX = arrayOutlineExist [counter1*3+1];
                    if (minPointDimX > arrayOutlineExist [counter1*3+1]) minPointDimX = arrayOutlineExist [counter1*3+1];
                    if (maxPointDimY < arrayOutlineExist [counter1*3+2]) maxPointDimY = arrayOutlineExist [counter1*3+2];
                    if (minPointDimY > arrayOutlineExist [counter1*3+2]) minPointDimY = arrayOutlineExist [counter1*3+2];
                }
            }
            
            for (int counter1 = 0; counter1 < linkedLineCount/5; counter1++){
                if (maxPointDimX < arrayLinkedLine [counter1*5]) maxPointDimX = arrayLinkedLine [counter1*5];
                if (minPointDimX > arrayLinkedLine [counter1*5]) minPointDimX = arrayLinkedLine [counter1*5];
                if (maxPointDimY < arrayLinkedLine [counter1*5+1]) maxPointDimY = arrayLinkedLine [counter1*5+1];
                if (minPointDimY > arrayLinkedLine [counter1*5+1]) minPointDimY = arrayLinkedLine [counter1*5+1];
            }
            
            int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
            int verticalLength = (maxPointDimY-minPointDimY)/2*2;
            int dimension = 0;
            
            if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
            if (horizontalLength < verticalLength) dimension = verticalLength+30;
            
            dimension = (dimension/2)*2;
            
            int horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
            int verticalStart = minPointDimY-(dimension-verticalLength)/2;
            
            int **outlineCheck = new int *[dimension+4]; //------Matrix, Over 200, A3 holds final results------
            for (int counter1 = 0; counter1 < dimension+4; counter1++) outlineCheck [counter1] = new int [dimension+4];
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++) outlineCheck [counterY][counterX] = 0;
            }
            
            for (int counter1 = 0; counter1 < outlineExistCount/3; counter1++){
                if (arrayOutlineExist [counter1*3] == counter){
                    outlineCheck [arrayOutlineExist [counter1*3+2]-verticalStart][arrayOutlineExist [counter1*3+1]-horizontalStart] = 1;
                }
            }
            
            for (int counter1 = 0; counter1 < linkedLineCount/5; counter1++){
                outlineCheck [arrayLinkedLine [counter1*5+1]-verticalStart][arrayLinkedLine [counter1*5]-horizontalStart] = 1;
            }
            
            //------Connectivity analysis, For Zero------
            int *connectAnalysisX = new int [(dimension+4)*4];
            int *connectAnalysisY = new int [(dimension+4)*4];
            int *connectAnalysisTempX = new int [(dimension+4)*4];
            int *connectAnalysisTempY = new int [(dimension+4)*4];
            
            int connectivityNumber = -3;
            int connectAnalysisCount = 0;
            int terminationFlag = 0;
            int connectAnalysisTempCount = 0;
            int xSource = 0;
            int ySource = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (outlineCheck [counterY][counterX] == 0){
                        connectivityNumber = connectivityNumber+2;
                        outlineCheck [counterY][counterX] = connectivityNumber;
                        
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && outlineCheck [counterY-1][counterX] == 0){
                            outlineCheck [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension && outlineCheck [counterY][counterX+1] == 0){
                            outlineCheck [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && outlineCheck [counterY+1][counterX] == 0){
                            outlineCheck [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && outlineCheck [counterY][counterX-1] == 0){
                            outlineCheck [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && outlineCheck [ySource-1][xSource] == 0){
                                        outlineCheck [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && outlineCheck [ySource][xSource+1] == 0){
                                        outlineCheck [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && outlineCheck [ySource+1][xSource] == 0){
                                        outlineCheck [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && outlineCheck [ySource][xSource-1] == 0){
                                        outlineCheck [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //------Remove connectivity groups, which attach edge, extract inner part of Linked Line------
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (outlineCheck [counterY][counterX] == -1) outlineCheck [counterY][counterX] = 0;
                }
            }
            
            //for (int counterY = 0; counterY < dimension; counterY++){
            //    for (int counterX = 0; counterX < dimension; counterX++){
            //       if (outlineCheck2 [counterY][counterX] != 0) outlineCheck [counterY][counterX] = outlineCheck2 [counterY][counterX];
            //   }
            //}
            
            //-------Internal Zero Find and Fill-------
            int **connectivityUpdate5 = new int *[dimension+4];
            
            for (int counter1 = 0; counter1 < dimension+4; counter1++) connectivityUpdate5 [counter1] = new int [dimension+4];
            
            for (int counterX = 0; counterX < dimension+2; counterX++){
                for (int counterY = 0; counterY < dimension+2; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    connectivityUpdate5 [counterY+1][counterX+1] = outlineCheck [counterY][counterX];
                }
            }
            
            connectivityNumber = 0;
            
            for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                    if (connectivityUpdate5 [counterY2][counterX2] == 0){
                        connectivityNumber--;
                        connectAnalysisCount = 0;
                        
                        connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                        
                        if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                            connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                        }
                        if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                            connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                            connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                        }
                        if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                            connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                        connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                        connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                        connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                        connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension+2; counterA++){
            //	for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
            //	cout<<" connectivityUpdate5 "<<counterA<<endl;
            //}
            
            int connectTemp2 = 0;
            
            if (connectivityNumber < -1){
                int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                
                for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
                
                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                        connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                        
                        if (connectTemp2 < -1){
                            connectTemp2 = connectTemp2*-1;
                            
                            if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2-1 >= 0 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2+1 < dimension+2 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2+1 < dimension+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                        }
                    }
                }
                
                int zeroFillFlag = 0;
                
                for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                    if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
                }
                
                if (zeroFillFlag == 1){
                    for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                            connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                            
                            if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                        }
                    }
                    
                    for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                            if (connectivityUpdate5 [counterY2][counterX2] > 0) outlineCheck [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                        }
                    }
                }
                
                delete [] connectCheckArray;
            }
            
            for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] connectivityUpdate5 [counter1];
            
            delete [] connectivityUpdate5;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (outlineCheck [counterY][counterX] != 0){
                        if (counterX+1 < dimension && outlineCheck [counterY][counterX+1] == 0) outlineCheck [counterY][counterX] = -1;
                        else if (counterY+1 < dimension && outlineCheck [counterY+1][counterX] == 0) outlineCheck [counterY][counterX] = -1;
                        else if (counterX-1 >= 0 && outlineCheck [counterY][counterX-1] == 0) outlineCheck [counterY][counterX] = -1;
                        else if (counterY-1 >= 0 && outlineCheck [counterY-1][counterX] == 0) outlineCheck [counterY][counterX] = -1;
                    }
                }
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (outlineCheck [counterY][counterX] > 0) outlineCheck [counterY][counterX] = 0;
                    
                    if (outlineCheck [counterY][counterX] < 0) outlineCheck [counterY][counterX] = 1;
                }
            }
            
            connectivityNumber = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (outlineCheck [counterY2][counterX2] == 0){
                        connectivityNumber--;
                        connectAnalysisCount = 0;
                        
                        outlineCheck [counterY2][counterX2] = connectivityNumber;
                        
                        if (counterY2-1 >= 0 && outlineCheck [counterY2-1][counterX2] == 0){
                            outlineCheck [counterY2-1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                        }
                        if (counterX2+1 < dimension && outlineCheck [counterY2][counterX2+1] == 0){
                            outlineCheck [counterY2][counterX2+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        if (counterY2+1 < dimension && outlineCheck [counterY2+1][counterX2] == 0){
                            outlineCheck [counterY2+1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                        }
                        if (counterX2-1 >= 0 && outlineCheck [counterY2][counterX2-1] == 0){
                            outlineCheck [counterY2][counterX2-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && outlineCheck [ySource-1][xSource] == 0){
                                        outlineCheck [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && outlineCheck [ySource][xSource+1] == 0){
                                        outlineCheck [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && outlineCheck [ySource+1][xSource] == 0){
                                        outlineCheck [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && outlineCheck [ySource][xSource-1] == 0){
                                        outlineCheck [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            delete [] connectAnalysisX;
            delete [] connectAnalysisY;
            delete [] connectAnalysisTempX;
            delete [] connectAnalysisTempY;
            
            //------Determine number of pixels------
            connectivityNumber = connectivityNumber*-1;
            
            int *connectedPix = new int [connectivityNumber+50];
            
            for (int counter1 = 0; counter1 <= connectivityNumber; counter1++) connectedPix [counter1] = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (outlineCheck [counterY2][counterX2] < -1){
                        connectedPix [outlineCheck [counterY2][counterX2]*-1]++;
                    }
                }
            }
            
            int **newConnectivityMapTemp = new int *[dimension+4];
            for (int counter1 = 0; counter1 < dimension+4; counter1++) newConnectivityMapTemp [counter1] = new int [dimension+4];
            
            for (int counterY = 0; counterY < dimension+4; counterY++){
                for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
            }
            
            int largestConnect = 0;
            int largestConnectNo = 0;
            
            for (int counter1 = 2; counter1 <= connectivityNumber; counter1++){
                if (connectedPix [counter1] > largestConnect){
                    largestConnect = connectedPix [counter1];
                    largestConnectNo = counter1;
                }
            }
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    connectTemp2 = outlineCheck [counterY2][counterX2];
                    
                    if (connectTemp2 == largestConnectNo*-1){
                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && outlineCheck [counterY2-1][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                            outlineCheck [counterY2-1][counterX2-1] = 0;
                        }
                        
                        if (counterY2-1 >= 0 && outlineCheck [counterY2-1][counterX2] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                            outlineCheck [counterY2-1][counterX2] = 0;
                        }
                        
                        if (counterY2-1 >= 0 && counterX2+1 < dimension && outlineCheck [counterY2-1][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                            outlineCheck [counterY2-1][counterX2+1] = 0;
                        }
                        
                        if (counterX2+1 < dimension && outlineCheck [counterY2][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                            outlineCheck [counterY2][counterX2+1] = 0;
                        }
                        
                        if (counterY2+1 < dimension && counterX2+1 < dimension && outlineCheck [counterY2+1][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                            outlineCheck [counterY2+1][counterX2+1] = 0;
                        }
                        
                        if (counterY2+1 < dimension && outlineCheck [counterY2+1][counterX2] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                            outlineCheck [counterY2+1][counterX2] = 0;
                        }
                        
                        if (counterY2+1 < dimension && counterX2-1 >= 0 && outlineCheck [counterY2+1][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                            outlineCheck [counterY2+1][counterX2-1] = 0;
                        }
                        
                        if (counterX2-1 >= 0 && outlineCheck [counterY2][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                            outlineCheck [counterY2][counterX2-1] = 0;
                        }
                    }
                }
            }
            
            delete [] connectedPix;
            
            int xPositionTempStart = 0;
            int yPositionTempStart = 0;
            int lineSize = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                        outlineCheck [counterY2][counterX2] = 1;
                        xPositionTempStart = counterX2;
                        yPositionTempStart = counterY2;
                        lineSize++;
                    }
                    else outlineCheck [counterY2][counterX2] = 0;
                }
            }
            
            for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] newConnectivityMapTemp [counter1];
            delete [] newConnectivityMapTemp;
            
            int constructedLineCount = 0;
            int findFlag = 0;
            
            int *arrayNewLines = new int [lineSize*2+50];
            
            outlineCheck [yPositionTempStart][xPositionTempStart] = -1;
            arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
            arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
            
            do{
                
                findFlag = 0;
                terminationFlag = 0;
                
                if (xPositionTempStart+1 < dimension){
                    if (outlineCheck [yPositionTempStart][xPositionTempStart+1] == 1){
                        outlineCheck [yPositionTempStart][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                
                if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                    if (outlineCheck [yPositionTempStart+1][xPositionTempStart+1] == 1){
                        outlineCheck [yPositionTempStart+1][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                
                if (yPositionTempStart+1 < dimension && findFlag == 0){
                    if (outlineCheck [yPositionTempStart+1][xPositionTempStart] == 1){
                        outlineCheck [yPositionTempStart+1][xPositionTempStart] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                        yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                
                if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                    if (outlineCheck [yPositionTempStart+1][xPositionTempStart-1] == 1){
                        outlineCheck [yPositionTempStart+1][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                
                if (xPositionTempStart-1 >= 0 && findFlag == 0){
                    if (outlineCheck [yPositionTempStart][xPositionTempStart-1] == 1){
                        outlineCheck [yPositionTempStart][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                
                if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (outlineCheck [yPositionTempStart-1][xPositionTempStart-1] == 1){
                        outlineCheck [yPositionTempStart-1][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                
                if (yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (outlineCheck [yPositionTempStart-1][xPositionTempStart] == 1){
                        outlineCheck [yPositionTempStart-1][xPositionTempStart] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                        yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                
                if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (outlineCheck [yPositionTempStart-1][xPositionTempStart+1] == 1){
                        outlineCheck [yPositionTempStart-1][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                    }
                }
                
            } while (terminationFlag == 1);
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<< outlineCheck [counterA][counterB];
            //	cout<<"  outlineCheck "<<counterA<<endl;
            //}
            
            int startFlag = 0;
            int pixValue = 110;
            
            for (int counter1 = 0; counter1 < constructedLineCount/2; counter1++){
                if (arrayNewLines [counter1*2] >= 0 && arrayNewLines [counter1*2] < imageWidth && arrayNewLines [counter1*2+1] >= 0 && arrayNewLines [counter1*2+1] < imageWidth) pixValue = arrayExtractedImage [arrayNewLines [counter1*2+1]][arrayNewLines [counter1*2]];
                
                if (linkedLineUpdateCount+5 > linkedLineUpdateLimit) [self linkedLineSizeUpDate];
                
                arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayNewLines [counter1*2], linkedLineUpdateCount++;
                arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayNewLines [counter1*2+1], linkedLineUpdateCount++;
                arrayLinkedLineUpdate [linkedLineUpdateCount] = pixValue, linkedLineUpdateCount++;
                arrayLinkedLineUpdate [linkedLineUpdateCount] = vectorNumberSave, linkedLineUpdateCount++;
                
                if (startFlag == 0) startFlag = 1, arrayLinkedLineUpdate [linkedLineUpdateCount] = 1, linkedLineUpdateCount++;
                else arrayLinkedLineUpdate [linkedLineUpdateCount] = 0, linkedLineUpdateCount++;
            }
            
            int linkedLineUpdateTemp = (linkedLineUpdateCount/5-1)*5+4;
            arrayLinkedLineUpdate [linkedLineUpdateTemp] = 2;
            
            //for (int counterA = 0; counterA < linkedLineUpdateCount/5; counterA++){
            //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayLinkedLineUpdate [counterA*5+counterB];
            //	cout<<" arrayLinkedLineUpdate "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < forNextConnectivityAssCount/6; counter1++){
                if (arrayForNextConnectivityAss [counter1*6] == counter){
                    if (linkedLineUpdateAssCount+6 > linkedLineUpdateAssLimit) [self linkedLineAssSizeUpDate];
                    
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = vectorNumberSave, linkedLineUpdateAssCount++;
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = arrayForNextConnectivityAss [counter1*6+1], linkedLineUpdateAssCount++;
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = arrayForNextConnectivityAss [counter1*6+2], linkedLineUpdateAssCount++;
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = arrayForNextConnectivityAss [counter1*6+3], linkedLineUpdateAssCount++;
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = arrayForNextConnectivityAss [counter1*6+4], linkedLineUpdateAssCount++;
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                    break;
                }
            }
            
            for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] outlineCheck [counter1];
            delete [] outlineCheck;
            
            delete [] arrayNewLines;
        }
    }
    else{
        
        if (linkedLineCount == 0){
            int startFlag = 0;
            
            if (outlineAdditionCount != 0){
                for (int counter1 = 0; counter1 < outlineAdditionCount/5; counter1++){
                    if (arrayOutlineAddition [counter1*5] == counter){
                        if (linkedLineUpdateCount+5 > linkedLineUpdateLimit) [self linkedLineSizeUpDate];
                        
                        arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayOutlineAddition [counter1*5+1], linkedLineUpdateCount++;
                        arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayOutlineAddition [counter1*5+2], linkedLineUpdateCount++;
                        arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayExtractedImage [arrayOutlineAddition [counter1*5+2]][arrayOutlineAddition [counter1*5+1]], linkedLineUpdateCount++;
                        arrayLinkedLineUpdate [linkedLineUpdateCount] = vectorNumberSave, linkedLineUpdateCount++;
                        
                        if (startFlag == 0) startFlag = 1, arrayLinkedLineUpdate [linkedLineUpdateCount] = 1, linkedLineUpdateCount++;
                        else arrayLinkedLineUpdate [linkedLineUpdateCount] = 0, linkedLineUpdateCount++;
                    }
                }
                
                if (linkedLineUpdateCount != 0){
                    int linkedLineUpdateTemp = (linkedLineUpdateCount/5-1)*5+4;
                    arrayLinkedLineUpdate [linkedLineUpdateTemp] = 2;
                    
                    if (linkedLineUpdateAssCount+6 > linkedLineUpdateAssLimit) [self linkedLineAssSizeUpDate];
                    
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = vectorNumberSave, linkedLineUpdateAssCount++;
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                }
            }
        }
        else{
            
            for (int counter1 = 0; counter1 < outlineAdditionCount/5; counter1++){
                if (arrayOutlineAddition [counter1*5] == counter){
                    if (maxPointDimX < arrayOutlineAddition [counter1*5+1]) maxPointDimX = arrayOutlineAddition [counter1*5+1];
                    if (minPointDimX > arrayOutlineAddition [counter1*5+1]) minPointDimX = arrayOutlineAddition [counter1*5+1];
                    if (maxPointDimY < arrayOutlineAddition [counter1*5+2]) maxPointDimY = arrayOutlineAddition [counter1*5+2];
                    if (minPointDimY > arrayOutlineAddition [counter1*5+2]) minPointDimY = arrayOutlineAddition [counter1*5+2];
                }
            }
            
            for (int counter1 = 0; counter1 < linkedLineCount/5; counter1++){
                if (maxPointDimX < arrayLinkedLine [counter1*5]) maxPointDimX = arrayLinkedLine [counter1*5];
                if (minPointDimX > arrayLinkedLine [counter1*5]) minPointDimX = arrayLinkedLine [counter1*5];
                if (maxPointDimY < arrayLinkedLine [counter1*5+1]) maxPointDimY = arrayLinkedLine [counter1*5+1];
                if (minPointDimY > arrayLinkedLine [counter1*5+1]) minPointDimY = arrayLinkedLine [counter1*5+1];
            }
            
            int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
            int verticalLength = (maxPointDimY-minPointDimY)/2*2;
            int dimension = 0;
            
            if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
            if (horizontalLength < verticalLength) dimension = verticalLength+30;
            
            dimension = (dimension/2)*2;
            
            int horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
            int verticalStart = minPointDimY-(dimension-verticalLength)/2;
            
            int **outlineCheck = new int *[dimension+4]; //------Matrix, Over 200, A3 holds final results------
            for (int counter1 = 0; counter1 < dimension+4; counter1++) outlineCheck [counter1] = new int [dimension+4];
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++) outlineCheck [counterY][counterX] = 0;
            }
            
            for (int counter1 = 0; counter1 < outlineAdditionCount/5; counter1++){
                if (arrayOutlineAddition [counter1*5] == counter){
                    outlineCheck [arrayOutlineAddition [counter1*5+2]-verticalStart][arrayOutlineAddition [counter1*5+1]-horizontalStart] = 1;
                }
            }
            
            for (int counter1 = 0; counter1 < linkedLineCount/5; counter1++){
                outlineCheck [arrayLinkedLine [counter1*5+1]-verticalStart][arrayLinkedLine [counter1*5]-horizontalStart] = 1;
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<outlineCheck [counterA][counterB];
            //    cout<<" outlineCheck "<<counterA<<endl;
            //}
            
            //------Connectivity analysis, For Zero------
            int *connectAnalysisX = new int [dimension*4];
            int *connectAnalysisY = new int [dimension*4];
            int *connectAnalysisTempX = new int [dimension*4];
            int *connectAnalysisTempY = new int [dimension*4];
            
            int connectivityNumber = -3;
            int connectAnalysisCount = 0;
            int terminationFlag = 0;
            int connectAnalysisTempCount = 0;
            int xSource = 0;
            int ySource = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (outlineCheck [counterY][counterX] == 0){
                        connectivityNumber = connectivityNumber+2;
                        outlineCheck [counterY][counterX] = connectivityNumber;
                        
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && outlineCheck [counterY-1][counterX] == 0){
                            outlineCheck [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension && outlineCheck [counterY][counterX+1] == 0){
                            outlineCheck [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && outlineCheck [counterY+1][counterX] == 0){
                            outlineCheck [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && outlineCheck [counterY][counterX-1] == 0){
                            outlineCheck [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && outlineCheck [ySource-1][xSource] == 0){
                                        outlineCheck [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && outlineCheck [ySource][xSource+1] == 0){
                                        outlineCheck [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && outlineCheck [ySource+1][xSource] == 0){
                                        outlineCheck [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && outlineCheck [ySource][xSource-1] == 0){
                                        outlineCheck [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //------Remove connectivity groups, which attach edge, extract inner part of Linked Line------
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (outlineCheck [counterY][counterX] == -1) outlineCheck [counterY][counterX] = 0;
                    else outlineCheck [counterY][counterX] = 1;
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<outlineCheck [counterA][counterB];
            //    cout<<" outlineCheck "<<counterA<<endl;
            //}
            
            //-------Internal Zero Find and Fill-------
            int **connectivityUpdate5 = new int *[dimension+4];
            
            for (int counter1 = 0; counter1 < dimension+4; counter1++) connectivityUpdate5 [counter1] = new int [dimension+4];
            
            for (int counterX = 0; counterX < dimension+2; counterX++){
                for (int counterY = 0; counterY < dimension+2; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++) connectivityUpdate5 [counterY+1][counterX+1] = outlineCheck [counterY][counterX];
            }
            
            connectivityNumber = 0;
            
            for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                    if (connectivityUpdate5 [counterY2][counterX2] == 0){
                        connectivityNumber--;
                        connectAnalysisCount = 0;
                        
                        connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                        
                        if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                            connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                        }
                        if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                            connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                            connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                        }
                        if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                            connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                        connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                        connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                        connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                        connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension+2; counterA++){
            //	for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
            //	cout<<" connectivityUpdate5 "<<counterA<<endl;
            //}
            
            int connectTemp2 = 0;
            
            if (connectivityNumber < -1){
                int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                
                for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
                
                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                        connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                        
                        if (connectTemp2 < -1){
                            connectTemp2 = connectTemp2*-1;
                            
                            if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2-1 >= 0 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2+1 < dimension+2 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2+1 < dimension+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                        }
                    }
                }
                
                int zeroFillFlag = 0;
                
                for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                    if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
                }
                
                if (zeroFillFlag == 1){
                    for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                            connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                            
                            if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                        }
                    }
                    
                    for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                            if (connectivityUpdate5 [counterY2][counterX2] > 0) outlineCheck [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                        }
                    }
                }
                
                delete [] connectCheckArray;
            }
            
            for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] connectivityUpdate5 [counter1];
            
            delete [] connectivityUpdate5;
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<outlineCheck [counterA][counterB];
            //    cout<<" outlineCheck "<<counterA<<endl;
            //}
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (outlineCheck [counterY][counterX] != 0){
                        if (counterX+1 < dimension && outlineCheck [counterY][counterX+1] == 0) outlineCheck [counterY][counterX] = -1;
                        else if (counterY+1 < dimension && outlineCheck [counterY+1][counterX] == 0) outlineCheck [counterY][counterX] = -1;
                        else if (counterX-1 >= 0 && outlineCheck [counterY][counterX-1] == 0) outlineCheck [counterY][counterX] = -1;
                        else if (counterY-1 >= 0 && outlineCheck [counterY-1][counterX] == 0) outlineCheck [counterY][counterX] = -1;
                    }
                }
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (outlineCheck [counterY][counterX] > 0) outlineCheck [counterY][counterX] = 0;
                    
                    if (outlineCheck [counterY][counterX] < 0) outlineCheck [counterY][counterX] = 1;
                }
            }
            
            connectivityNumber = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (outlineCheck [counterY2][counterX2] == 0){
                        connectivityNumber--;
                        connectAnalysisCount = 0;
                        
                        outlineCheck [counterY2][counterX2] = connectivityNumber;
                        
                        if (counterY2-1 >= 0 && outlineCheck [counterY2-1][counterX2] == 0){
                            outlineCheck [counterY2-1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                        }
                        if (counterX2+1 < dimension && outlineCheck [counterY2][counterX2+1] == 0){
                            outlineCheck [counterY2][counterX2+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        if (counterY2+1 < dimension && outlineCheck [counterY2+1][counterX2] == 0){
                            outlineCheck [counterY2+1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                        }
                        if (counterX2-1 >= 0 && outlineCheck [counterY2][counterX2-1] == 0){
                            outlineCheck [counterY2][counterX2-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && outlineCheck [ySource-1][xSource] == 0){
                                        outlineCheck [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && outlineCheck [ySource][xSource+1] == 0){
                                        outlineCheck [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && outlineCheck [ySource+1][xSource] == 0){
                                        outlineCheck [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && outlineCheck [ySource][xSource-1] == 0){
                                        outlineCheck [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            delete [] connectAnalysisX;
            delete [] connectAnalysisY;
            delete [] connectAnalysisTempX;
            delete [] connectAnalysisTempY;
            
            //------Determine number of pixels------
            connectivityNumber = connectivityNumber*-1;
            
            int *connectedPix = new int [connectivityNumber+50];
            
            for (int counter1 = 0; counter1 <= connectivityNumber; counter1++) connectedPix [counter1] = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (outlineCheck [counterY2][counterX2] < -1) connectedPix [outlineCheck [counterY2][counterX2]*-1]++;
                }
            }
            
            int **newConnectivityMapTemp = new int *[dimension+4];
            for (int counter1 = 0; counter1 < dimension+4; counter1++) newConnectivityMapTemp [counter1] = new int [dimension+4];
            
            for (int counterY = 0; counterY < dimension+4; counterY++){
                for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
            }
            
            int largestConnect = 0;
            int largestConnectNo = 0;
            
            for (int counter1 = 2; counter1 <= connectivityNumber; counter1++){
                if (connectedPix [counter1] > largestConnect){
                    largestConnect = connectedPix [counter1];
                    largestConnectNo = counter1;
                }
            }
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    connectTemp2 = outlineCheck [counterY2][counterX2];
                    
                    if (connectTemp2 == largestConnectNo*-1){
                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && outlineCheck [counterY2-1][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                            outlineCheck [counterY2-1][counterX2-1] = 0;
                        }
                        if (counterY2-1 >= 0 && outlineCheck [counterY2-1][counterX2] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                            outlineCheck [counterY2-1][counterX2] = 0;
                        }
                        if (counterY2-1 >= 0 && counterX2+1 < dimension && outlineCheck [counterY2-1][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                            outlineCheck [counterY2-1][counterX2+1] = 0;
                        }
                        if (counterX2+1 < dimension && outlineCheck [counterY2][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                            outlineCheck [counterY2][counterX2+1] = 0;
                        }
                        if (counterY2+1 < dimension && counterX2+1 < dimension && outlineCheck [counterY2+1][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                            outlineCheck [counterY2+1][counterX2+1] = 0;
                        }
                        if (counterY2+1 < dimension && outlineCheck [counterY2+1][counterX2] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                            outlineCheck [counterY2+1][counterX2] = 0;
                        }
                        if (counterY2+1 < dimension && counterX2-1 >= 0 && outlineCheck [counterY2+1][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                            outlineCheck [counterY2+1][counterX2-1] = 0;
                        }
                        if (counterX2-1 >= 0 && outlineCheck [counterY2][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                            outlineCheck [counterY2][counterX2-1] = 0;
                        }
                    }
                }
            }
            
            delete [] connectedPix;
            
            int xPositionTempStart = 0;
            int yPositionTempStart = 0;
            int lineSize = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                        outlineCheck [counterY2][counterX2] = 1;
                        
                        xPositionTempStart = counterX2;
                        yPositionTempStart = counterY2;
                        lineSize++;
                    }
                    else outlineCheck [counterY2][counterX2] = 0;
                }
            }
            
            for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] newConnectivityMapTemp [counter1];
            delete [] newConnectivityMapTemp;
            
            int constructedLineCount = 0;
            int findFlag = 0;
            
            int *arrayNewLines = new int [lineSize*2+50];
            
            outlineCheck [yPositionTempStart][xPositionTempStart] = -1;
            arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
            arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
            
            do{
                
                findFlag = 0;
                terminationFlag = 0;
                
                if (xPositionTempStart+1 < dimension){
                    if (outlineCheck [yPositionTempStart][xPositionTempStart+1] == 1){
                        outlineCheck [yPositionTempStart][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                
                if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                    if (outlineCheck [yPositionTempStart+1][xPositionTempStart+1] == 1){
                        outlineCheck [yPositionTempStart+1][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                
                if (yPositionTempStart+1 < dimension && findFlag == 0){
                    if (outlineCheck [yPositionTempStart+1][xPositionTempStart] == 1){
                        outlineCheck [yPositionTempStart+1][xPositionTempStart] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                        yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                
                if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                    if (outlineCheck [yPositionTempStart+1][xPositionTempStart-1] == 1){
                        outlineCheck [yPositionTempStart+1][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                
                if (xPositionTempStart-1 >= 0 && findFlag == 0){
                    if (outlineCheck [yPositionTempStart][xPositionTempStart-1] == 1){
                        outlineCheck [yPositionTempStart][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                
                if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (outlineCheck [yPositionTempStart-1][xPositionTempStart-1] == 1){
                        outlineCheck [yPositionTempStart-1][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                
                if (yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (outlineCheck [yPositionTempStart-1][xPositionTempStart] == 1){
                        outlineCheck [yPositionTempStart-1][xPositionTempStart] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                        yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                
                if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (outlineCheck [yPositionTempStart-1][xPositionTempStart+1] == 1){
                        outlineCheck [yPositionTempStart-1][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                    }
                }
                
            } while (terminationFlag == 1);
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<outlineCheck [counterA][counterB];
            //    cout<<" outlineCheck "<<counterA<<endl;
            //}
            
            int startFlag = 0;
            int pixValue = 110;
            
            for (int counter1 = 0; counter1 < constructedLineCount/2; counter1++){
                if (arrayNewLines [counter1*2] >= 0 && arrayNewLines [counter1*2] < imageWidth && arrayNewLines [counter1*2+1] >= 0 && arrayNewLines [counter1*2+1] < imageWidth){
                    pixValue = arrayExtractedImage [arrayNewLines [counter1*2+1]][arrayNewLines [counter1*2]];
                }
                
                if (linkedLineUpdateCount+5 > linkedLineUpdateLimit) [self linkedLineSizeUpDate];
                
                arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayNewLines [counter1*2], linkedLineUpdateCount++;
                arrayLinkedLineUpdate [linkedLineUpdateCount] = arrayNewLines [counter1*2+1], linkedLineUpdateCount++;
                arrayLinkedLineUpdate [linkedLineUpdateCount] = pixValue, linkedLineUpdateCount++;
                arrayLinkedLineUpdate [linkedLineUpdateCount] = vectorNumberSave, linkedLineUpdateCount++;
                
                if (startFlag == 0) startFlag = 1, arrayLinkedLineUpdate [linkedLineUpdateCount] = 1, linkedLineUpdateCount++;
                else arrayLinkedLineUpdate [linkedLineUpdateCount] = 0, linkedLineUpdateCount++;
            }
            
            arrayLinkedLineUpdate [(linkedLineUpdateCount/5-1)*5+4] = 2;
            
            //for (int counterA = 0; counterA < linkedLineUpdateCount/5; counterA++){
            //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayLinkedLineUpdate [counterA*5+counterB];
            //	cout<<" arrayLinkedLineUpdate "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < outlineExistAssCount/6; counter1++){
                if (arrayOutlineExistAss [counter1*6] == counter){
                    if (linkedLineUpdateAssCount+6 > linkedLineUpdateAssLimit) [self linkedLineAssSizeUpDate];
                    
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = vectorNumberSave, linkedLineUpdateAssCount++;
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = arrayOutlineExistAss [counter1*6+1], linkedLineUpdateAssCount++;
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = arrayOutlineExistAss [counter1*6+2], linkedLineUpdateAssCount++;
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = arrayOutlineExistAss [counter1*6+3], linkedLineUpdateAssCount++;
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = arrayOutlineExistAss [counter1*6+4], linkedLineUpdateAssCount++;
                    arrayLinkedLineUpdateAss [linkedLineUpdateAssCount] = 0, linkedLineUpdateAssCount++;
                    break;
                }
            }
            
            for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] outlineCheck [counter1];
            delete [] outlineCheck;
            
            delete [] arrayNewLines;
        }
    }
}

-(void)linkedLineSizeUpDate{
    int *arrayUpDate = new int [linkedLineUpdateCount+10];
    for (int counter1 = 0; counter1 < linkedLineUpdateCount; counter1++) arrayUpDate [counter1] = arrayLinkedLineUpdate [counter1];
    
    delete [] arrayLinkedLineUpdate;
    arrayLinkedLineUpdate = new int [linkedLineUpdateLimit+5000];
    linkedLineUpdateLimit = linkedLineUpdateLimit+5000;
    
    for (int counter1 = 0; counter1 < linkedLineUpdateCount; counter1++) arrayLinkedLineUpdate [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)linkedLineAssSizeUpDate{
    int *arrayUpDate = new int [linkedLineUpdateAssCount+10];
    for (int counter1 = 0; counter1 < linkedLineUpdateAssCount; counter1++) arrayUpDate [counter1] = arrayLinkedLineUpdateAss [counter1];
    
    delete [] arrayLinkedLineUpdateAss;
    arrayLinkedLineUpdateAss = new int [linkedLineUpdateAssLimit+5000];
    linkedLineUpdateAssLimit = linkedLineUpdateAssLimit+5000;
    
    for (int counter1 = 0; counter1 < linkedLineUpdateAssCount; counter1++) arrayLinkedLineUpdateAss [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

@end
