//
// GapChase.h
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 26/11/12.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#ifndef GAPCHASE_H
#define GAPCHASE_H
#import "Controller.h"
#endif

@interface GapChase : NSObject {
    int numberOfFill; //No of fill
    int fillLimit; //Fill limit
    int fillAddition; //Fill addition
    
    int *arrayGapDataTemp; //Gap fill array
    
    id gapFill;
}

-(int)gapChaseing1:(int)originX :(int)originY :(int)destinationX :(int)destinationY :(int)lineType;
-(void)gapFillUpdate;

@end
