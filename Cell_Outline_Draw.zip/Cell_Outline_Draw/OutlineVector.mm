//
// OutlineVector.mm
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 04/11/11.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#import "OutlineVector.h"

@implementation OutlineVector

-(void)outlineVector:(int)arrayNumber :(int)pixelNumber{
    //clock_t time1, time2, time3, time4, time5, time6, time7, time8, time9, time10, time11, time12, time13, time14, time15;
    
    //time1 = clock();
    
    //------Loop counter define------
    int **connectivityOutlineMap = new int *[pixelNumber+4];
    int **connectivityOutlineMap2 = new int *[pixelNumber+4];
    
    for (int counterY = 0; counterY < pixelNumber+4; counterY++){
        connectivityOutlineMap [counterY] = new int [pixelNumber+4];
        connectivityOutlineMap2 [counterY] = new int [pixelNumber+4];
    }
    
    for (int counterY = 0; counterY < pixelNumber+2; counterY++){
        for (int counterX = 0; counterX < pixelNumber+2; counterX++) connectivityOutlineMap2 [counterY][counterX] = 0;
    }
    
    if (arrayNumber == 1){
        for (int counterY = 0; counterY < pixelNumber; counterY++){
            for (int counterX = 0; counterX < pixelNumber; counterX++) connectivityOutlineMap [counterY][counterX] = arrayImageConnectivity [counterY][counterX];
        }
    }
    else if (arrayNumber == 2){
        for (int counterY = 0; counterY < pixelNumber; counterY++){
            for (int counterX = 0; counterX < pixelNumber; counterX++) connectivityOutlineMap [counterY][counterX] = arrayImageConnect200 [counterY][counterX];
        }
    }
    else if (arrayNumber == 3){
        for (int counterY = 0; counterY < pixelNumber; counterY++){
            for (int counterX = 0; counterX < pixelNumber; counterX++) connectivityOutlineMap [counterY][counterX] = arrayImageConnect220 [counterY][counterX];
        }
    }
    else if (arrayNumber == 4){
        for (int counterY = 0; counterY < pixelNumber; counterY++){
            for (int counterX = 0; counterX < pixelNumber; counterX++) connectivityOutlineMap [counterY][counterX] = arrayImageConnect240 [counterY][counterX];
        }
    }
    else if (arrayNumber == 5){
        for (int counterY = 0; counterY < pixelNumber; counterY++){
            for (int counterX = 0; counterX < pixelNumber; counterX++) connectivityOutlineMap [counterY][counterX] = arrayImageRemaining [counterY][counterX];
        }
    }
    
    for (int counterY = 0; counterY < pixelNumber; counterY++){
        for (int counterX = 0; counterX < pixelNumber; counterX++) connectivityOutlineMap2 [counterY+1][counterX+1] = connectivityOutlineMap [counterY][counterX];
    }
    
    //for (int counterA = 0; counterA < pixelNumber; counterA++){
    //	for (int counterB = 0; counterB < pixelNumber; counterB++) cout<<" "<<connectivityOutlineMap2 [counterA][counterB];
    //	cout<<" connectivityOutlineMap2 "<<counterA<<endl;
    //}
    
    //------Connectivity analysis, data 0, only Up Down, Right, Left: This perform connectivity analysis of background------
    int *connectAnalysisX = new int [pixelNumber*4];
    int *connectAnalysisY = new int [pixelNumber*4];
    int *connectAnalysisTempX = new int [pixelNumber*4];
    int *connectAnalysisTempY = new int [pixelNumber*4];
    
    int connectivityNumber = 0;
    int connectAnalysisCount = 0;
    int terminationFlag = 0;
    int connectAnalysisTempCount = 0;
    int xSource = 0;
    int ySource = 0;
    
    for (int counterY = 0; counterY < pixelNumber+2; counterY++){
        for (int counterX = 0; counterX < pixelNumber+2; counterX++){
            if (connectivityOutlineMap2 [counterY][counterX] == 0){
                connectivityNumber = connectivityNumber-1;
                connectivityOutlineMap2 [counterY][counterX] = connectivityNumber;
                
                connectAnalysisCount = 0;
                
                if (counterY-1 >= 0 && connectivityOutlineMap2 [counterY-1][counterX] == 0){
                    connectivityOutlineMap2 [counterY-1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterX+1 < pixelNumber+2 && connectivityOutlineMap2 [counterY][counterX+1] == 0){
                    connectivityOutlineMap2 [counterY][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                if (counterY+1 < pixelNumber+2 && connectivityOutlineMap2 [counterY+1][counterX] == 0){
                    connectivityOutlineMap2 [counterY+1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterX-1 >= 0 && connectivityOutlineMap2 [counterY][counterX-1] == 0){
                    connectivityOutlineMap2 [counterY][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                
                if (connectAnalysisCount != 0){
                    do{
                        
                        terminationFlag = 1;
                        connectAnalysisTempCount = 0;
                        
                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                            xSource = connectAnalysisX [counter1];
                            ySource = connectAnalysisY [counter1];
                            
                            if (ySource-1 >= 0 && connectivityOutlineMap2 [ySource-1][xSource] == 0){
                                connectivityOutlineMap2 [ySource-1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (xSource+1 < pixelNumber+2 && connectivityOutlineMap2 [ySource][xSource+1] == 0){
                                connectivityOutlineMap2 [ySource][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < pixelNumber+2 && connectivityOutlineMap2 [ySource+1][xSource] == 0){
                                connectivityOutlineMap2 [ySource+1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (xSource-1 >= 0 && connectivityOutlineMap2 [ySource][xSource-1] == 0){
                                connectivityOutlineMap2 [ySource][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                        }
                        
                        connectAnalysisCount = connectAnalysisTempCount;
                        
                        if (connectAnalysisCount == 0) terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                }
            }
        }
    }
    
    //for (int counterA = 0; counterA < pixelNumber; counterA++){
    //	for (int counterB = 0; counterB < pixelNumber; counterB++) cout<<" "<<connectivityOutlineMap2 [counterA][counterB];
    //	cout<<" connectivityOutlineMap2 "<<counterA<<endl;
    //}
    
    //------Fill internal data 0: Check whether connective pixels (background) group faces to edge or two different connective groups.------
    //------If it is not, the group is considered as a internal Zero------
    connectivityNumber = connectivityNumber*-1;
    
    int *connectPixCount = new int [connectivityNumber+50];
    
    for (int counter1 = 0; counter1 < connectivityNumber+1; counter1++) connectPixCount [counter1] = 0;
    for (int counterY = 0; counterY < pixelNumber+2; counterY++){
        for (int counterX = 0; counterX < pixelNumber+2; counterX++){
            if (connectivityOutlineMap2 [counterY][counterX] < -1) connectPixCount [connectivityOutlineMap2 [counterY][counterX]*-1]++;
        }
    }
    
    int largestConnect = 0;
    
    for (int counter1 = 0; counter1 < connectivityNumber+1; counter1++){
        if (connectPixCount [counter1] > largestConnect) largestConnect = connectPixCount [counter1];
    }
    
    delete [] connectPixCount;
    
    int *connectAnalysisSaveX = new int [largestConnect+50];
    int *connectAnalysisSaveY = new int [largestConnect+50];
    
    for (int counter1 = 0; counter1 < largestConnect+1; counter1++){
        connectAnalysisSaveX [counter1] = 0;
        connectAnalysisSaveY [counter1] = 0;
    }
    
    int connectAnalysisSaveCount = 0;
    int cancelFlag = 0;
    int attachedLine = 0;
    
    for (int counterY = 0; counterY < pixelNumber+2; counterY++){
        for (int counterX = 0; counterX < pixelNumber+2; counterX++){
            if (connectivityOutlineMap2 [counterY][counterX] < -1){
                connectivityNumber = connectivityOutlineMap2 [counterY][counterX];
                connectAnalysisCount = 0;
                connectAnalysisSaveCount = 0;
                cancelFlag = 0;
                attachedLine = 0;
                
                if (counterY-1 >= 0){
                    if (connectivityOutlineMap2 [counterY-1][counterX] == connectivityNumber){
                        connectivityOutlineMap2 [counterY-1][counterX] = -1;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        connectAnalysisSaveX [connectAnalysisSaveCount] = counterX, connectAnalysisSaveY [connectAnalysisSaveCount] = counterY-1, connectAnalysisSaveCount++;
                    }
                    else if (connectivityOutlineMap2 [counterY-1][counterX] > 0 && attachedLine == 0) attachedLine = connectivityOutlineMap2 [counterY-1][counterX];
                    else if (attachedLine != 0 && attachedLine != connectivityOutlineMap2 [counterY-1][counterX] && connectivityOutlineMap2 [counterY-1][counterX] > 0) cancelFlag = 1;
                }
                if (counterX+1 < pixelNumber+2){
                    if (connectivityOutlineMap2 [counterY][counterX+1] == connectivityNumber){
                        connectivityOutlineMap2 [counterY][counterX+1] = -1;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        connectAnalysisSaveX [connectAnalysisSaveCount] = counterX+1, connectAnalysisSaveY [connectAnalysisSaveCount] = counterY, connectAnalysisSaveCount++;
                    }
                    else if (connectivityOutlineMap2 [counterY][counterX+1] > 0 && attachedLine == 0) attachedLine = connectivityOutlineMap2 [counterY][counterX+1];
                    else if (attachedLine != 0 && attachedLine != connectivityOutlineMap2 [counterY][counterX+1] && connectivityOutlineMap2 [counterY][counterX+1] > 0) cancelFlag = 1;
                }
                if (counterY+1 < pixelNumber+2){
                    if (connectivityOutlineMap2 [counterY+1][counterX] == connectivityNumber){
                        connectivityOutlineMap2 [counterY+1][counterX] = -1;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        connectAnalysisSaveX [connectAnalysisSaveCount] = counterX, connectAnalysisSaveY [connectAnalysisSaveCount] = counterY+1, connectAnalysisSaveCount++;
                    }
                    else if (connectivityOutlineMap2 [counterY+1][counterX] > 0 && attachedLine == 0) attachedLine = connectivityOutlineMap2 [counterY+1][counterX];
                    else if (attachedLine != 0 && attachedLine != connectivityOutlineMap2 [counterY+1][counterX] && connectivityOutlineMap2 [counterY+1][counterX] > 0) cancelFlag = 1;
                }
                if (counterX-1 >= 0){
                    if (connectivityOutlineMap2 [counterY][counterX-1] == connectivityNumber){
                        connectivityOutlineMap2 [counterY][counterX-1] = -1;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        connectAnalysisSaveX [connectAnalysisSaveCount] = counterX-1, connectAnalysisSaveY [connectAnalysisSaveCount] = counterY, connectAnalysisSaveCount++;
                    }
                    else if (connectivityOutlineMap2 [counterY][counterX-1] > 0 && attachedLine == 0) attachedLine = connectivityOutlineMap2 [counterY][counterX-1];
                    else if (attachedLine != 0 && attachedLine != connectivityOutlineMap2 [counterY][counterX-1] && connectivityOutlineMap2 [counterY][counterX-1] > 0) cancelFlag = 1;
                }
                
                if (connectAnalysisCount != 0){
                    do{
                        
                        terminationFlag = 1;
                        connectAnalysisTempCount = 0;
                        
                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                            xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                            
                            if (ySource-1 >= 0){
                                if (connectivityOutlineMap2 [ySource-1][xSource] == connectivityNumber){
                                    connectivityOutlineMap2 [ySource-1][xSource] = -1;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    connectAnalysisSaveX [connectAnalysisSaveCount] = xSource, connectAnalysisSaveY [connectAnalysisSaveCount] = ySource-1, connectAnalysisSaveCount++;
                                }
                                else if (connectivityOutlineMap2 [ySource-1][xSource] > 0 && attachedLine == 0) attachedLine = connectivityOutlineMap2 [ySource-1][xSource];
                                else if (attachedLine != 0 && attachedLine != connectivityOutlineMap2 [ySource-1][xSource] && connectivityOutlineMap2 [ySource-1][xSource] > 0) cancelFlag = 1;
                            }
                            if (xSource+1 < pixelNumber+2){
                                if (connectivityOutlineMap2 [ySource][xSource+1] == connectivityNumber){
                                    connectivityOutlineMap2 [ySource][xSource+1] = -1;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    connectAnalysisSaveX [connectAnalysisSaveCount] = xSource+1, connectAnalysisSaveY [connectAnalysisSaveCount] = ySource, connectAnalysisSaveCount++;
                                }
                                else if (connectivityOutlineMap2 [ySource][xSource+1] > 0 && attachedLine == 0) attachedLine = connectivityOutlineMap2 [ySource][xSource+1];
                                else if (attachedLine != 0 && attachedLine != connectivityOutlineMap2 [ySource][xSource+1] && connectivityOutlineMap2 [ySource][xSource+1] > 0) cancelFlag = 1;
                            }
                            
                            if (ySource+1 < pixelNumber+2){
                                if (connectivityOutlineMap2 [ySource+1][xSource] == connectivityNumber){
                                    connectivityOutlineMap2 [ySource+1][xSource] = -1;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    connectAnalysisSaveX [connectAnalysisSaveCount] = xSource, connectAnalysisSaveY [connectAnalysisSaveCount] = ySource+1, connectAnalysisSaveCount++;
                                }
                                else if (connectivityOutlineMap2 [ySource+1][xSource] > 0 && attachedLine == 0) attachedLine = connectivityOutlineMap2 [ySource+1][xSource];
                                else if (attachedLine != 0 && attachedLine != connectivityOutlineMap2 [ySource+1][xSource] && connectivityOutlineMap2 [ySource+1][xSource] > 0) cancelFlag = 1;
                            }
                            if (xSource-1 >= 0){
                                if (connectivityOutlineMap2 [ySource][xSource-1] == connectivityNumber){
                                    connectivityOutlineMap2 [ySource][xSource-1] = -1;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    connectAnalysisSaveX [connectAnalysisSaveCount] = xSource-1, connectAnalysisSaveY [connectAnalysisSaveCount] = ySource, connectAnalysisSaveCount++;
                                }
                                else if (connectivityOutlineMap2 [ySource][xSource-1] > 0 && attachedLine == 0) attachedLine = connectivityOutlineMap2 [ySource][xSource-1];
                                else if (attachedLine != 0 && attachedLine != connectivityOutlineMap2 [ySource][xSource-1] && connectivityOutlineMap2 [ySource][xSource-1] > 0) cancelFlag = 1;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                        }
                        
                        connectAnalysisCount = connectAnalysisTempCount;
                        
                        if (connectAnalysisCount == 0) terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    if (cancelFlag == 0 && connectAnalysisSaveCount != 0){
                        for (int counter1 = 0; counter1 < connectAnalysisSaveCount; counter1++){
                            connectivityOutlineMap [connectAnalysisSaveY [counter1]-1][connectAnalysisSaveX [counter1]-1] = attachedLine;
                        }
                    }
                }
                else if (connectAnalysisCount == 0 && attachedLine != 0){
                    connectivityOutlineMap [counterY-1][counterX-1] = attachedLine;
                    
                }
            }
        }
    }
    
    delete [] connectAnalysisX;
    delete [] connectAnalysisY;
    delete [] connectAnalysisTempX;
    delete [] connectAnalysisTempY;
    delete [] connectAnalysisSaveX;
    delete [] connectAnalysisSaveY;
    
    //for (int counterA = 0; counterA < pixelNumber; counterA++){
    //	for (int counterB = 0; counterB < pixelNumber; counterB++) cout<<" "<<connectivityOutlineMap [counterA][counterB];
    //	cout<<" connectivityOutlineMap "<<counterA<<endl;
    //}
    
    //------Boarder Mark: it will be marked as Original Connective Number x 1000------
    largestConnect = 0;
    
    for (int counterY = 0; counterY < pixelNumber; counterY++){
        for (int counterX = 0; counterX < pixelNumber; counterX++){
            if (connectivityOutlineMap [counterY][counterX] != 0) largestConnect++;
        }
    }
    
    int *arrayOutLineDataBrightTempValue = new int [largestConnect*2+50];
    int *arrayOutLineDataBrightTempX = new int [largestConnect*2+50];
    int *arrayOutLineDataBrightTempY = new int [largestConnect*2+50];
    
    int entryCount = 0;
    int zeroHitCount = 0;
    int subjectPixelNumber = 0;
    
    for (int counterY = 0; counterY < pixelNumber; counterY++){
        for (int counterX = 0; counterX < pixelNumber; counterX++){
            if (connectivityOutlineMap [counterY][counterX] != 0){
                zeroHitCount = 0;
                subjectPixelNumber = connectivityOutlineMap [counterY][counterX];
                
                if (counterY-1 < 0 || counterY+1 > pixelNumber-1 || counterX-1 < 0 || counterX+1 > pixelNumber-1) zeroHitCount = 1;
                else{
                    
                    if (connectivityOutlineMap [counterY-1][counterX-1] == 0 || connectivityOutlineMap [counterY-1][counterX-1] != subjectPixelNumber) zeroHitCount = 1;
                    if (connectivityOutlineMap [counterY-1][counterX] == 0 || connectivityOutlineMap [counterY-1][counterX] != subjectPixelNumber) zeroHitCount = 1;
                    if (connectivityOutlineMap [counterY-1][counterX+1] == 0 || connectivityOutlineMap [counterY-1][counterX+1] != subjectPixelNumber) zeroHitCount = 1;
                    if (connectivityOutlineMap [counterY][counterX+1] == 0 || connectivityOutlineMap [counterY][counterX+1] != subjectPixelNumber) zeroHitCount = 1;
                    if (connectivityOutlineMap [counterY][counterX] == 0 || connectivityOutlineMap [counterY][counterX] != subjectPixelNumber) zeroHitCount = 1;
                    if (connectivityOutlineMap [counterY+1][counterX+1] == 0 || connectivityOutlineMap [counterY+1][counterX+1] != subjectPixelNumber) zeroHitCount = 1;
                    if (connectivityOutlineMap [counterY+1][counterX] == 0 || connectivityOutlineMap [counterY+1][counterX] != subjectPixelNumber) zeroHitCount = 1;
                    if (connectivityOutlineMap [counterY+1][counterX-1] == 0 || connectivityOutlineMap [counterY+1][counterX-1] != subjectPixelNumber) zeroHitCount = 1;
                    if (connectivityOutlineMap [counterY][counterX-1] == 0 || connectivityOutlineMap [counterY][counterX-1] != subjectPixelNumber) zeroHitCount = 1;
                }
                
                if (zeroHitCount == 1){
                    arrayOutLineDataBrightTempValue [entryCount] = connectivityOutlineMap [counterY][counterX];
                    arrayOutLineDataBrightTempX [entryCount] = counterX;
                    arrayOutLineDataBrightTempY [entryCount] = counterY;
                    entryCount++;
                }
            }
        }
    }
    
    for (int counter1 = 0; counter1 < entryCount; counter1++){
        connectivityOutlineMap [arrayOutLineDataBrightTempY [counter1]][arrayOutLineDataBrightTempX [counter1]] = arrayOutLineDataBrightTempValue [counter1]*-1;
    }
    
    //------Change Cross Boarder point: e.g. 3000, 3/3, 3000 to 3000, 3000/3000, 3000------
    entryCount = 0;
    
    int originalCount = 0;
    int originalCountCorrect = 0;
    
    for (int counterY = 0; counterY < pixelNumber; counterY++){
        for (int counterX = 0; counterX < pixelNumber; counterX++){
            if (connectivityOutlineMap [counterY][counterX] < 0){ //========
                originalCount = connectivityOutlineMap [counterY][counterX];
                originalCountCorrect = connectivityOutlineMap [counterY][counterX]*-1;
                
                if (counterY+1 < pixelNumber && counterX+1 < pixelNumber){
                    if (connectivityOutlineMap [counterY][counterX] == originalCount && connectivityOutlineMap [counterY][counterX+1] == originalCountCorrect && connectivityOutlineMap [counterY+1][counterX] == originalCountCorrect && connectivityOutlineMap [counterY+1][counterX+1] == originalCount){
                        arrayOutLineDataBrightTempValue [entryCount] = originalCount;
                        arrayOutLineDataBrightTempX [entryCount] = counterX+1;
                        arrayOutLineDataBrightTempY [entryCount] = counterY;
                        entryCount++;
                        
                        arrayOutLineDataBrightTempValue [entryCount] = originalCount;
                        arrayOutLineDataBrightTempX [entryCount] = counterX;
                        arrayOutLineDataBrightTempY [entryCount] = counterY+1;
                        entryCount++;
                    }
                }
                
                if (counterY+1 < pixelNumber && counterX-1 >= 0){
                    if (connectivityOutlineMap [counterY][counterX-1] == originalCountCorrect && connectivityOutlineMap [counterY][counterX] == originalCount && connectivityOutlineMap [counterY+1][counterX-1] == originalCount && connectivityOutlineMap [counterY+1][counterX] == originalCountCorrect){
                        arrayOutLineDataBrightTempValue [entryCount] = originalCount;
                        arrayOutLineDataBrightTempX [entryCount] = counterX-1;
                        arrayOutLineDataBrightTempY [entryCount] = counterY;
                        entryCount++;
                        
                        arrayOutLineDataBrightTempValue [entryCount] = originalCount;
                        arrayOutLineDataBrightTempX [entryCount] = counterX;
                        arrayOutLineDataBrightTempY [entryCount] = counterY+1;
                        entryCount++;
                    }
                }
            }
        }
    }
    
    for (int counter1 = 0; counter1 < entryCount; counter1++){
        connectivityOutlineMap [arrayOutLineDataBrightTempY [counter1]][arrayOutLineDataBrightTempX [counter1]] = arrayOutLineDataBrightTempValue [counter1];
    }
    
    //for (int counterA = 0; counterA < pixelNumber; counterA++){
    //	for (int counterB = 0; counterB < pixelNumber; counterB++) cout<<" "<<connectivityOutlineMap [counterA][counterB];
    //	cout<<" connectivityOutlineMap "<<counterA<<endl;
    //}
    
    //------Remove points, which do not face to original number------
    entryCount = 0;
    int sourceCount = 0;
    
    for (int counterY = 0; counterY < pixelNumber; counterY++){
        for (int counterX = 0; counterX < pixelNumber; counterX++){
            if (connectivityOutlineMap [counterY][counterX] < 0){
                originalCount = connectivityOutlineMap [counterY][counterX]*-1;
                sourceCount = 0;
                
                if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityOutlineMap [counterY-1][counterX-1] == originalCount) sourceCount = 1;
                if (counterY-1 >= 0 && connectivityOutlineMap [counterY-1][counterX] == originalCount) sourceCount = 1;
                if (counterY-1 >= 0 && counterX+1 < pixelNumber && connectivityOutlineMap [counterY-1][counterX+1] == originalCount) sourceCount = 1;
                if (counterX+1 < pixelNumber && connectivityOutlineMap [counterY][counterX+1] == originalCount) sourceCount = 1;
                if (connectivityOutlineMap [counterY][counterX] == originalCount) sourceCount = 1;
                if (counterY+1 < pixelNumber && counterX+1 < pixelNumber && connectivityOutlineMap [counterY+1][counterX+1] == originalCount) sourceCount = 1;
                if (counterY+1 < pixelNumber && connectivityOutlineMap [counterY+1][counterX] == originalCount) sourceCount = 1;
                if (counterY+1 < pixelNumber && counterX-1 >= 0 && connectivityOutlineMap [counterY+1][counterX-1] == originalCount) sourceCount = 1;
                if (counterX-1 >= 0 && connectivityOutlineMap [counterY][counterX-1] == originalCount) sourceCount = 1;
                if (sourceCount == 0){
                    arrayOutLineDataBrightTempValue [entryCount] = originalCount;
                    arrayOutLineDataBrightTempX [entryCount] = counterX;
                    arrayOutLineDataBrightTempY [entryCount] = counterY;
                    entryCount++;
                }
            }
        }
    }
    
    for (int counter1 = 0; counter1 < entryCount; counter1++){
        connectivityOutlineMap [arrayOutLineDataBrightTempY [counter1]][arrayOutLineDataBrightTempX [counter1]] = 0;
    }
    
    //------Find boarder, which connect 3 or more borders, change nearest original number to border number------
    entryCount = 0;
    int connectCount = 0;
    
    for (int counterY = 0; counterY < pixelNumber; counterY++){
        for (int counterX = 0; counterX < pixelNumber; counterX++){
            if (connectivityOutlineMap [counterY][counterX] < 0){
                originalCount = connectivityOutlineMap [counterY][counterX]*-1;
                connectCount = 0;
                
                if (counterY-1 >= 0 && connectivityOutlineMap [counterY-1][counterX] == connectivityOutlineMap [counterY][counterX]) connectCount++;
                if (counterX+1 < pixelNumber && connectivityOutlineMap [counterY][counterX+1] == connectivityOutlineMap [counterY][counterX]) connectCount++;
                if (counterY+1 < pixelNumber && connectivityOutlineMap [counterY+1][counterX] == connectivityOutlineMap [counterY][counterX]) connectCount++;
                if (counterX-1 >= 0 && connectivityOutlineMap [counterY][counterX-1] == connectivityOutlineMap [counterY][counterX]) connectCount++;
                if (connectCount == 3 || connectCount == 4){
                    if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityOutlineMap [counterY-1][counterX-1] == originalCount){
                        arrayOutLineDataBrightTempValue [entryCount] = connectivityOutlineMap [counterY][counterX];
                        arrayOutLineDataBrightTempX [entryCount] = counterX-1;
                        arrayOutLineDataBrightTempY [entryCount] = counterY-1;
                        entryCount++;
                    }
                    
                    if (counterY-1 >= 0 && connectivityOutlineMap [counterY-1][counterX] == originalCount){
                        arrayOutLineDataBrightTempValue [entryCount] = connectivityOutlineMap [counterY][counterX];
                        arrayOutLineDataBrightTempX [entryCount] = counterX;
                        arrayOutLineDataBrightTempY [entryCount] = counterY-1;
                        entryCount++;
                    }
                    
                    if (counterY-1 >= 0 && counterX+1 < pixelNumber && connectivityOutlineMap [counterY-1][counterX+1] == originalCount){
                        arrayOutLineDataBrightTempValue [entryCount] = connectivityOutlineMap [counterY][counterX];
                        arrayOutLineDataBrightTempX [entryCount] = counterX+1;
                        arrayOutLineDataBrightTempY [entryCount] = counterY-1;
                        entryCount++;
                    }
                    
                    if (counterX+1 < pixelNumber && connectivityOutlineMap [counterY][counterX+1] == originalCount){
                        arrayOutLineDataBrightTempValue [entryCount] = connectivityOutlineMap [counterY][counterX];
                        arrayOutLineDataBrightTempX [entryCount] = counterX+1;
                        arrayOutLineDataBrightTempY [entryCount] = counterY;
                        entryCount++;
                    }
                    
                    if (connectivityOutlineMap [counterY][counterX] == originalCount){
                        arrayOutLineDataBrightTempValue [entryCount] = connectivityOutlineMap [counterY][counterX];
                        arrayOutLineDataBrightTempX [entryCount] = counterX;
                        arrayOutLineDataBrightTempY [entryCount] = counterY;
                        entryCount++;
                    }
                    
                    if (counterY+1 < pixelNumber && counterX+1 < pixelNumber && connectivityOutlineMap [counterY+1][counterX+1] == originalCount){
                        arrayOutLineDataBrightTempValue [entryCount] = connectivityOutlineMap [counterY][counterX];
                        arrayOutLineDataBrightTempX [entryCount] = counterX+1;
                        arrayOutLineDataBrightTempY [entryCount] = counterY+1;
                        entryCount++;
                    }
                    
                    if (counterY+1 < pixelNumber && connectivityOutlineMap [counterY+1][counterX] == originalCount){
                        arrayOutLineDataBrightTempValue [entryCount] = connectivityOutlineMap [counterY][counterX];
                        arrayOutLineDataBrightTempX [entryCount] = counterX;
                        arrayOutLineDataBrightTempY [entryCount] = counterY+1;
                        entryCount++;
                    }
                    
                    if (counterY+1 < pixelNumber && counterX-1 >= 0 && connectivityOutlineMap [counterY+1][counterX-1] == originalCount){
                        arrayOutLineDataBrightTempValue [entryCount] = connectivityOutlineMap [counterY][counterX];
                        arrayOutLineDataBrightTempX [entryCount] = counterX-1;
                        arrayOutLineDataBrightTempY [entryCount] = counterY+1;
                        entryCount++;
                    }
                    
                    if (counterX-1 >= 0 && connectivityOutlineMap [counterY][counterX-1] == originalCount){
                        arrayOutLineDataBrightTempValue [entryCount] = connectivityOutlineMap [counterY][counterX];
                        arrayOutLineDataBrightTempX [entryCount] = counterX-1;
                        arrayOutLineDataBrightTempY [entryCount] = counterY;
                        entryCount++;
                    }
                }
            }
        }
    }
    
    for (int counter1 = 0; counter1 < entryCount; counter1++){
        connectivityOutlineMap [arrayOutLineDataBrightTempY [counter1]][arrayOutLineDataBrightTempX [counter1]] = arrayOutLineDataBrightTempValue [counter1];
    }
    
    //------Remove Original numbers, which face Zero: Check 3x3 pixel and if any of them are Edge of image or Zero, put Zero------
    for (int counterY = 0; counterY < pixelNumber; counterY++){
        for (int counterX = 0; counterX < pixelNumber; counterX++){
            if (connectivityOutlineMap [counterY][counterX] > 0 && connectivityOutlineMap [counterY][counterX] != 0){
                sourceCount = 0;
                
                if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityOutlineMap [counterY-1][counterX-1] == 0) sourceCount = 1;
                if (counterY-1 >= 0 && connectivityOutlineMap [counterY-1][counterX] == 0) sourceCount = 1;
                if (counterY-1 >= 0 && counterX+1 < pixelNumber && connectivityOutlineMap [counterY-1][counterX+1] == 0) sourceCount = 1;
                if (counterX+1 < pixelNumber && connectivityOutlineMap [counterY][counterX+1] == 0) sourceCount = 1;
                if (counterY+1 < pixelNumber && counterX+1 < pixelNumber && connectivityOutlineMap [counterY+1][counterX+1] == 0) sourceCount = 1;
                if (counterY+1 < pixelNumber && connectivityOutlineMap [counterY+1][counterX] == 0) sourceCount = 1;
                if (counterY+1 < pixelNumber && counterX-1 >= 0 && connectivityOutlineMap [counterY+1][counterX-1] == 0) sourceCount = 1;
                if (counterX-1 >= 0 && connectivityOutlineMap [counterY][counterX-1] == 0) sourceCount = 1;
                if (sourceCount == 1) connectivityOutlineMap [counterY][counterX] = 0;
                else{
                    
                    if (counterX-1 == -1) connectivityOutlineMap [counterY][counterX] = 0;
                    if (counterX+1 == pixelNumber) connectivityOutlineMap [counterY][counterX] = 0;
                    if (counterY-1 == -1) connectivityOutlineMap [counterY][counterX] = 0;
                    if (counterY+1 == pixelNumber) connectivityOutlineMap [counterY][counterX] = 0;
                }
            }
        }
    }
    
    int *arrayOutLineDataBrightValue = new int [largestConnect+50];
    int *arrayOutLineDataBrightX = new int [largestConnect+50];
    int *arrayOutLineDataBrightY = new int [largestConnect+50];
    
    //------Remove multi point attached border numbers: Check 3x3 pixels and if any of them are not the original number, Border number is changed to non-boarder number------
    int outLineDataBrightCount = 0;
    
    for (int counterY = 0; counterY < pixelNumber; counterY++){
        for (int counterX = 0; counterX < pixelNumber; counterX++){
            if (connectivityOutlineMap [counterY][counterX] < 0){
                originalCount = connectivityOutlineMap [counterY][counterX]*-1;
                sourceCount = 0;
                
                if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityOutlineMap [counterY-1][counterX-1] == originalCount) sourceCount = 1;
                if (counterY-1 >= 0 && connectivityOutlineMap [counterY-1][counterX] == originalCount) sourceCount = 1;
                if (counterY-1 >= 0 && counterX+1 < pixelNumber && connectivityOutlineMap [counterY-1][counterX+1] == originalCount) sourceCount = 1;
                if (counterX+1 < pixelNumber && connectivityOutlineMap [counterY][counterX+1] == originalCount) sourceCount = 1;
                if (counterY+1 < pixelNumber && counterX+1 < pixelNumber && connectivityOutlineMap [counterY+1][counterX+1] == originalCount) sourceCount = 1;
                if (counterY+1 < pixelNumber && connectivityOutlineMap [counterY+1][counterX] == originalCount) sourceCount = 1;
                if (counterY+1 < pixelNumber && counterX-1 >= 0 && connectivityOutlineMap [counterY+1][counterX-1] == originalCount) sourceCount = 1;
                if (counterX-1 >= 0 && connectivityOutlineMap [counterY][counterX-1] == originalCount) sourceCount = 1;
                if (sourceCount != 0){
                    arrayOutLineDataBrightValue [outLineDataBrightCount] = connectivityOutlineMap [counterY][counterX];
                    arrayOutLineDataBrightX [outLineDataBrightCount] = counterX;
                    arrayOutLineDataBrightY [outLineDataBrightCount] = counterY;
                    outLineDataBrightCount++;
                }
                else{
                    
                    arrayOutLineDataBrightTempValue [entryCount] = originalCount;
                    arrayOutLineDataBrightTempX [entryCount] = counterX;
                    arrayOutLineDataBrightTempY [entryCount] = counterY;
                    entryCount++;
                }
            }
        }
    }
    
    for (int counter1 = 0; counter1 < entryCount; counter1++){
        connectivityOutlineMap [arrayOutLineDataBrightTempY [counter1]][arrayOutLineDataBrightTempX [counter1]] = arrayOutLineDataBrightTempValue [counter1];
    }
    
    delete [] arrayOutLineDataBrightTempX;
    delete [] arrayOutLineDataBrightTempY;
    delete [] arrayOutLineDataBrightTempValue;
    
    for (int counterY = 0; counterY < pixelNumber; counterY++){
        for (int counterX = 0; counterX < pixelNumber; counterX++){
            if (connectivityOutlineMap [counterY][counterX] > 0) connectivityOutlineMap [counterY][counterX] = 0;
            else if (connectivityOutlineMap [counterY][counterX] < 0) connectivityOutlineMap [counterY][counterX] = connectivityOutlineMap [counterY][counterX]*-1;
        }
    }
    
    //------Vector Set------
    int vectorNumberTemp = 1;
    largestConnect = 0;
    
    for (int counterY = 0; counterY < pixelNumber; counterY++){
        for (int counterX = 0; counterX < pixelNumber; counterX++){
            if (connectivityOutlineMap [counterY][counterX] != 0) largestConnect++;
        }
    }
    
    int *arrayVectorSourceLineTempValue = new int [largestConnect+50];
    int *arrayVectorSourceLineTempX = new int [largestConnect+50];
    int *arrayVectorSourceLineTempY = new int [largestConnect+50];
    int *arrayVectorSourceLineTempValue2 = new int [largestConnect+50];
    int *arrayVectorSourceLineTempX2 = new int [largestConnect+50];
    int *arrayVectorSourceLineTempY2 = new int [largestConnect+50];
    int *arrayLineTrimmingValue = new int [largestConnect+50];
    int *arraylineTrimmingX = new int [largestConnect+50];
    int *arraylineTrimmingY = new int [largestConnect+50];
    int *arrayLineTrimmingValue2 = new int [largestConnect+50];
    int *arraylineTrimmingX2 = new int [largestConnect+50];
    int *arraylineTrimmingY2 = new int [largestConnect+50];
    
    int overallClearCount = 1;
    int xPositionTemp = 0;
    int yPositionTemp = 0;
    int numberOriginal = 0;
    int vectorSourceCount1 = 0;
    int firstSetFlag = 0;
    int linkPixCount = 0;
    int shapeCheckFlag = 0;
    int findFlag = 0;
    int maxPointDimX = 0;
    int maxPointDimY = 0;
    int minPointDimX = 0;
    int minPointDimY = 0;
    int horizontalLength = 0;
    int verticalLength = 0;
    int dimension = 0;
    int horizontalStart = 0;
    int verticalStart = 0;
    int firstProcess = 0;
    int largestConnectNo2 = 0;
    int largestConnect2 = 0;
    int removeFlag = 0;
    int linePointCount = 0;
    int lineTrimmingX = 0;
    int lineTrimmingY = 0;
    int attachPoint = 0;
    int countSave = 0;
    int lineTrimmingX2 = 0;
    int lineTrimmingY2 = 0;
    int vectorSourceCount2 = 0;
    int linePointCount2 = 0;
    int lineTrimmingCount2 = 0;
    
    for (int counterY = 0; counterY < pixelNumber; counterY++){
        for (int counterX = 0; counterX < pixelNumber; counterX++){
            if (connectivityOutlineMap [counterY][counterX] > 0){
                xPositionTemp = counterX;
                yPositionTemp = counterY;
                numberOriginal = connectivityOutlineMap [yPositionTemp][xPositionTemp];
                connectivityOutlineMap [yPositionTemp][xPositionTemp] = overallClearCount*-1;
                
                vectorSourceCount1 = 0;
                firstSetFlag = 0;
                
                if (numberOriginal > 0){
                    linkPixCount = 0;
                    shapeCheckFlag = 0;
                    
                    if (xPositionTemp+1 < pixelNumber){
                        if (connectivityOutlineMap [yPositionTemp][xPositionTemp+1] == numberOriginal) linkPixCount++;
                    }
                    
                    if (yPositionTemp+1 < pixelNumber){
                        if (connectivityOutlineMap [yPositionTemp+1][xPositionTemp] == numberOriginal) linkPixCount++;
                    }
                    
                    if (xPositionTemp-1 >= 0){
                        if (connectivityOutlineMap [yPositionTemp][xPositionTemp-1] == numberOriginal) linkPixCount++;
                    }
                    
                    if (yPositionTemp-1 >= 0){
                        if (connectivityOutlineMap [yPositionTemp-1][xPositionTemp] == numberOriginal) linkPixCount++;
                    }
                    
                    if (linkPixCount > 2) shapeCheckFlag = 1;
                    
                    if (shapeCheckFlag == 0){
                        do{
                            
                            terminationFlag = 0;
                            findFlag = 0;
                            linkPixCount = 0;
                            
                            if (xPositionTemp+1 < pixelNumber){
                                if (connectivityOutlineMap [yPositionTemp][xPositionTemp+1] == numberOriginal) linkPixCount++;
                            }
                            
                            if (yPositionTemp+1 < pixelNumber){
                                if (connectivityOutlineMap [yPositionTemp+1][xPositionTemp] == numberOriginal) linkPixCount++;
                            }
                            
                            if (xPositionTemp-1 >= 0){
                                if (connectivityOutlineMap [yPositionTemp][xPositionTemp-1] == numberOriginal) linkPixCount++;
                            }
                            
                            if (yPositionTemp-1 >= 0){
                                if (connectivityOutlineMap [yPositionTemp-1][xPositionTemp] == numberOriginal) linkPixCount++;
                            }
                            
                            if ((firstSetFlag == 0 && linkPixCount == 2) || (firstSetFlag == 1 && linkPixCount == 1) || (firstSetFlag == 1 && linkPixCount == 0)){
                                if (firstSetFlag == 0) firstSetFlag = 1;
                                
                                if (xPositionTemp+1 < pixelNumber){
                                    if (connectivityOutlineMap [yPositionTemp][xPositionTemp+1] == numberOriginal){
                                        connectivityOutlineMap [yPositionTemp][xPositionTemp+1] = overallClearCount*-1;
                                        arrayVectorSourceLineTempValue [vectorSourceCount1] = vectorNumberTemp;
                                        arrayVectorSourceLineTempX [vectorSourceCount1] = xPositionTemp+1;
                                        arrayVectorSourceLineTempY [vectorSourceCount1] = yPositionTemp;
                                        vectorSourceCount1++;
                                        
                                        xPositionTemp = xPositionTemp+1;
                                        terminationFlag = 1;
                                        findFlag = 1;
                                    }
                                }
                                
                                if (yPositionTemp+1 < pixelNumber && findFlag == 0){
                                    if (connectivityOutlineMap [yPositionTemp+1][xPositionTemp] == numberOriginal){
                                        connectivityOutlineMap [yPositionTemp+1][xPositionTemp] = overallClearCount*-1;
                                        arrayVectorSourceLineTempValue [vectorSourceCount1] = vectorNumberTemp;
                                        arrayVectorSourceLineTempX [vectorSourceCount1] = xPositionTemp;
                                        arrayVectorSourceLineTempY [vectorSourceCount1] = yPositionTemp+1;
                                        vectorSourceCount1++;
                                        
                                        yPositionTemp = yPositionTemp+1;
                                        terminationFlag = 1;
                                        findFlag = 1;
                                    }
                                }
                                
                                if (xPositionTemp-1 >= 0 && findFlag == 0){
                                    if (connectivityOutlineMap [yPositionTemp][xPositionTemp-1] == numberOriginal){
                                        connectivityOutlineMap [yPositionTemp][xPositionTemp-1] = overallClearCount*-1;
                                        arrayVectorSourceLineTempValue [vectorSourceCount1] = vectorNumberTemp;
                                        arrayVectorSourceLineTempX [vectorSourceCount1] = xPositionTemp-1;
                                        arrayVectorSourceLineTempY [vectorSourceCount1] = yPositionTemp;
                                        vectorSourceCount1++;
                                        
                                        xPositionTemp = xPositionTemp-1;
                                        terminationFlag = 1;
                                        findFlag = 1;
                                    }
                                }
                                
                                if (yPositionTemp-1 >= 0 && findFlag == 0){
                                    if (connectivityOutlineMap [yPositionTemp-1][xPositionTemp] == numberOriginal){
                                        connectivityOutlineMap [yPositionTemp-1][xPositionTemp] = overallClearCount*-1;
                                        arrayVectorSourceLineTempValue [vectorSourceCount1] = vectorNumberTemp;
                                        arrayVectorSourceLineTempX [vectorSourceCount1] = xPositionTemp;
                                        arrayVectorSourceLineTempY [vectorSourceCount1] = yPositionTemp-1;
                                        vectorSourceCount1++;
                                        
                                        yPositionTemp = yPositionTemp-1;
                                        terminationFlag = 1;
                                    }
                                }
                            }
                            else{
                                
                                shapeCheckFlag = 1;
                                terminationFlag = 0;
                            }
                            
                        } while (terminationFlag == 1);
                    }
                    
                    if (shapeCheckFlag == 1){
                        maxPointDimX = 0;
                        maxPointDimY = 0;
                        minPointDimX = 100000;
                        minPointDimY = 100000;
                        
                        for (int counterY2 = 0; counterY2 < pixelNumber; counterY2++){
                            for (int counterX2 = 0; counterX2 < pixelNumber; counterX2++){
                                if (connectivityOutlineMap [counterY2][counterX2] == overallClearCount*-1) connectivityOutlineMap [counterY2][counterX2] = numberOriginal;
                                
                                if (connectivityOutlineMap [counterY2][counterX2] == numberOriginal){
                                    if (maxPointDimX < counterX2) maxPointDimX = counterX2;
                                    if (minPointDimX > counterX2) minPointDimX = counterX2;
                                    if (maxPointDimY < counterY2) maxPointDimY = counterY2;
                                    if (minPointDimY > counterY2) minPointDimY = counterY2;
                                }
                            }
                        }
                        
                        horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                        verticalLength = (maxPointDimY-minPointDimY)/2*2;
                        dimension = 0;
                        
                        if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
                        
                        if (horizontalLength < verticalLength) dimension = verticalLength+30;
                        
                        dimension = (dimension/2)*2;
                        
                        horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
                        verticalStart = minPointDimY-(dimension-verticalLength)/2;
                        
                        int **previousMap2 = new int *[dimension+4];
                        int **previousMap3 = new int *[dimension+4];
                        
                        for (int counter2 = 0; counter2 < dimension+4; counter2++){
                            previousMap2 [counter2] = new int [dimension+4];
                            previousMap3 [counter2] = new int [dimension+4];
                        }
                        
                        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                previousMap2 [counterY2][counterX2] = 0;
                                previousMap3 [counterY2][counterX2] = 0;
                            }
                        }
                        
                        for (int counterY2 = 0; counterY2 < pixelNumber; counterY2++){
                            for (int counterX2 = 0; counterX2 < pixelNumber; counterX2++){
                                if (connectivityOutlineMap [counterY2][counterX2] == numberOriginal){
                                    previousMap2 [counterY2-verticalStart][counterX2-horizontalStart] = numberOriginal;
                                    connectivityOutlineMap [counterY2][counterX2] = 0;
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap2 [counterA][counterB];
                        //  cout<<" previousMap2 "<<counterA<<endl;
                        //}
                        
                        connectAnalysisX = new int [dimension*4];
                        connectAnalysisY = new int [dimension*4];
                        connectAnalysisTempX = new int [dimension*4];
                        connectAnalysisTempY = new int [dimension*4];
                        
                        connectivityNumber = 0;
                        
                        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                if (previousMap2 [counterY2][counterX2] == 0){
                                    connectivityNumber--;
                                    connectAnalysisCount = 0;
                                    
                                    previousMap2 [counterY2][counterX2] = connectivityNumber;
                                    
                                    if (counterY2-1 >= 0 && previousMap2 [counterY2-1][counterX2] == 0){
                                        previousMap2 [counterY2-1][counterX2] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                    }
                                    if (counterX2+1 < dimension && previousMap2 [counterY2][counterX2+1] == 0){
                                        previousMap2 [counterY2][counterX2+1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                    }
                                    if (counterY2+1 < dimension && previousMap2 [counterY2+1][counterX2] == 0){
                                        previousMap2 [counterY2+1][counterX2] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                    }
                                    if (counterX2-1 >= 0 && previousMap2 [counterY2][counterX2-1] == 0){
                                        previousMap2 [counterY2][counterX2-1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                    }
                                    
                                    if (connectAnalysisCount != 0){
                                        do{
                                            
                                            terminationFlag = 1;
                                            connectAnalysisTempCount = 0;
                                            
                                            for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                
                                                if (ySource-1 >= 0 && previousMap2 [ySource-1][xSource] == 0){
                                                    previousMap2 [ySource-1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (xSource+1 < dimension && previousMap2 [ySource][xSource+1] == 0){
                                                    previousMap2 [ySource][xSource+1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 < dimension && previousMap2 [ySource+1][xSource] == 0){
                                                    previousMap2 [ySource+1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (xSource-1 >= 0 && previousMap2 [ySource][xSource-1] == 0){
                                                    previousMap2 [ySource][xSource-1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                            }
                                            
                                            for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                            }
                                            
                                            connectAnalysisCount = connectAnalysisTempCount;
                                            
                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                    }
                                }
                            }
                        }
                        
                        //------Remove connectivity groups, which attach edge, extract inner part of Linked Line------
                        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                if (previousMap2 [counterY2][counterX2] == -1) previousMap2 [counterY2][counterX2] = 0;
                            }
                        }
                        
                        delete [] connectAnalysisX;
                        delete [] connectAnalysisY;
                        delete [] connectAnalysisTempX;
                        delete [] connectAnalysisTempY;
                        
                        //------Determine number of pixels------
                        connectivityNumber = connectivityNumber*-1;
                        
                        int *connectedPix = new int [connectivityNumber+50];
                        
                        for (int counter2 = 0; counter2 <= connectivityNumber; counter2++) connectedPix [counter2] = 0;
                        
                        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                if (previousMap2 [counterY2][counterX2] < -1){
                                    connectedPix [previousMap2 [counterY2][counterX2]*-1]++;
                                }
                            }
                        }
                        
                        firstProcess = 0;
                        
                        for (int counter2 = 2; counter2 <= connectivityNumber; counter2++){
                            largestConnect2 = 0;
                            largestConnectNo2 = 0;
                            
                            for (int counter3 = 2; counter3 <= connectivityNumber; counter3++){
                                if (connectedPix [counter3] > largestConnect2){
                                    largestConnect2 = connectedPix [counter3];
                                    largestConnectNo2 = counter3;
                                }
                            }
                            
                            connectedPix [largestConnectNo2] = 0;
                            
                            removeFlag = 0;
                            
                            if (firstProcess == 1){
                                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                                    for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                        if (previousMap2 [counterY2][counterX2] == largestConnectNo2*-1){
                                            if (counterY2-1 >= 0 && counterX2-1 >= 0 && previousMap2 [counterY2-1][counterX2-1] == 0) removeFlag = 1;
                                            if (counterY2-1 >= 0 && previousMap2 [counterY2-1][counterX2] == 0) removeFlag = 1;
                                            if (counterY2-1 >= 0 && counterX2+1 < dimension && previousMap2 [counterY2-1][counterX2+1] == 0) removeFlag = 1;
                                            if (counterX2+1 < dimension && previousMap2 [counterY2][counterX2+1] == 0) removeFlag = 1;
                                            if (counterY2+1 < dimension && counterX2+1 < dimension && previousMap2 [counterY2+1][counterX2+1] == 0) removeFlag = 1;
                                            if (counterY2+1 < dimension && previousMap2 [counterY2+1][counterX2] == 0) removeFlag = 1;
                                            if (counterY2+1 < dimension && counterX2-1 >= 0 && previousMap2 [counterY2+1][counterX2-1] == 0) removeFlag = 1;
                                            if (counterX2-1 >= 0 && previousMap2 [counterY2][counterX2-1] == 0) removeFlag = 1;
                                        }
                                    }
                                }
                            }
                            
                            if (removeFlag == 0){
                                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                                    for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                        if (previousMap2 [counterY2][counterX2] == largestConnectNo2*-1){
                                            if (counterY2-1 >= 0 && counterX2-1 >= 0 && previousMap2 [counterY2-1][counterX2-1] == numberOriginal){
                                                previousMap3 [counterY2-1][counterX2-1] = numberOriginal;
                                                previousMap2 [counterY2-1][counterX2-1] = 0;
                                            }
                                            
                                            if (counterY2-1 >= 0 && previousMap2 [counterY2-1][counterX2] == numberOriginal){
                                                previousMap3 [counterY2-1][counterX2] = numberOriginal;
                                                previousMap2 [counterY2-1][counterX2] = 0;
                                            }
                                            
                                            if (counterY2-1 >= 0 && counterX2+1 < dimension && previousMap2 [counterY2-1][counterX2+1] == numberOriginal){
                                                previousMap3 [counterY2-1][counterX2+1] = numberOriginal;
                                                previousMap2 [counterY2-1][counterX2+1] = 0;
                                            }
                                            
                                            if (counterX2+1 < dimension && previousMap2 [counterY2][counterX2+1] == numberOriginal){
                                                previousMap3 [counterY2][counterX2+1] = numberOriginal;
                                                previousMap2 [counterY2][counterX2+1] = 0;
                                            }
                                            
                                            if (counterY2+1 < dimension && counterX2+1 < dimension && previousMap2 [counterY2+1][counterX2+1] == numberOriginal){
                                                previousMap3 [counterY2+1][counterX2+1] = numberOriginal;
                                                previousMap2 [counterY2+1][counterX2+1] = 0;
                                            }
                                            
                                            if (counterY2+1 < dimension && previousMap2 [counterY2+1][counterX2] == numberOriginal){
                                                previousMap3 [counterY2+1][counterX2] = numberOriginal;
                                                previousMap2 [counterY2+1][counterX2] = 0;
                                            }
                                            
                                            if (counterY2+1 < dimension && counterX2-1 >= 0 && previousMap2 [counterY2+1][counterX2-1] == numberOriginal){
                                                previousMap3 [counterY2+1][counterX2-1] = numberOriginal;
                                                previousMap2 [counterY2+1][counterX2-1] = 0;
                                            }
                                            
                                            if (counterX2-1 >= 0 && previousMap2 [counterY2][counterX2-1] == numberOriginal){
                                                previousMap3 [counterY2][counterX2-1] = numberOriginal;
                                                previousMap2 [counterY2][counterX2-1] = 0;
                                            }
                                        }
                                    }
                                }
                            }
                            
                            if (removeFlag == 1){
                                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                                    for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                        if (previousMap2 [counterY2][counterX2] == largestConnectNo2*-1){
                                            if (counterY2-1 >= 0 && counterX2-1 >= 0 && previousMap2 [counterY2-1][counterX2-1] == numberOriginal){
                                                previousMap3 [counterY2-1][counterX2-1] = connectivityNumber+numberOriginal+1;
                                                previousMap2 [counterY2-1][counterX2-1] = 0;
                                            }
                                            
                                            if (counterY2-1 >= 0 && previousMap2 [counterY2-1][counterX2] == numberOriginal){
                                                previousMap3 [counterY2-1][counterX2] = connectivityNumber+numberOriginal+1;
                                                previousMap2 [counterY2-1][counterX2] = 0;
                                            }
                                            
                                            if (counterY2-1 >= 0 && counterX2+1 < dimension && previousMap2 [counterY2-1][counterX2+1] == numberOriginal){
                                                previousMap3 [counterY2-1][counterX2+1] = connectivityNumber+numberOriginal+1;
                                                previousMap2 [counterY2-1][counterX2+1] = 0;
                                            }
                                            
                                            if (counterX2+1 < dimension && previousMap2 [counterY2][counterX2+1] == numberOriginal){
                                                previousMap3 [counterY2][counterX2+1] = connectivityNumber+numberOriginal+1;
                                                previousMap2 [counterY2][counterX2+1] = 0;
                                            }
                                            
                                            if (counterY2+1 < dimension && counterX2+1 < dimension && previousMap2 [counterY2+1][counterX2+1] == numberOriginal){
                                                previousMap3 [counterY2+1][counterX2+1] = connectivityNumber+numberOriginal+1;
                                                previousMap2 [counterY2+1][counterX2+1] = 0;
                                            }
                                            
                                            if (counterY2+1 < dimension && previousMap2 [counterY2+1][counterX2] == numberOriginal){
                                                previousMap3 [counterY2+1][counterX2] = connectivityNumber+numberOriginal+1;
                                                previousMap2 [counterY2+1][counterX2] = 0;
                                            }
                                            
                                            if (counterY2+1 < dimension && counterX2-1 >= 0 && previousMap2 [counterY2+1][counterX2-1] == numberOriginal){
                                                previousMap3 [counterY2+1][counterX2-1] = connectivityNumber+numberOriginal+1;
                                                previousMap2 [counterY2+1][counterX2-1] = 0;
                                            }
                                            
                                            if (counterX2-1 >= 0 && previousMap2 [counterY2][counterX2-1] == numberOriginal){
                                                previousMap3 [counterY2][counterX2-1] = connectivityNumber+numberOriginal+1;
                                                previousMap2 [counterY2][counterX2-1] = 0;
                                            }
                                        }
                                    }
                                }
                            }
                            
                            if (firstProcess == 0) firstProcess = 1;
                        }
                        
                        delete [] connectedPix;
                        
                        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                if (previousMap3 [counterY2][counterX2] == numberOriginal){
                                    connectivityOutlineMap [counterY2+verticalStart][counterX2+horizontalStart] = numberOriginal;
                                }
                                else if (previousMap3 [counterY2][counterX2] == connectivityNumber+numberOriginal+1){
                                    connectivityOutlineMap [counterY2+verticalStart][counterX2+horizontalStart] = 0;
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap2 [counterA][counterB];
                        //     cout<<" previousMap2 "<<counterA<<endl;
                        // }
                        
                        //for (int counterA = 760; counterA < 820; counterA++){
                        //    for (int counterB = 150; counterB < 230; counterB++) cout<<" "<<connectivityOutlineMap [counterA][counterB];
                        //     cout<<" connectivityOutlineMap "<<counterA<<endl;
                        // }
                        
                        // for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3 [counterA][counterB];
                        //     cout<<" previousMap3 "<<counterA<<endl;
                        // }
                        
                        for (int counter2 = 0; counter2 < dimension+4; counter2++){
                            delete [] previousMap2 [counter2];
                            delete [] previousMap3 [counter2];
                        }
                        
                        delete [] previousMap2;
                        delete [] previousMap3;
                        
                        xPositionTemp = counterX;
                        yPositionTemp = counterY;
                        connectivityOutlineMap [yPositionTemp][xPositionTemp] = overallClearCount*-1;
                        
                        vectorSourceCount1 = 0;
                        
                        do{
                            
                            terminationFlag = 0;
                            findFlag = 0;
                            
                            if (xPositionTemp+1 < pixelNumber){
                                if (connectivityOutlineMap [yPositionTemp][xPositionTemp+1] == numberOriginal){
                                    connectivityOutlineMap [yPositionTemp][xPositionTemp+1] = overallClearCount*-1;
                                    arrayVectorSourceLineTempValue [vectorSourceCount1] = vectorNumberTemp;
                                    arrayVectorSourceLineTempX [vectorSourceCount1] = xPositionTemp+1;
                                    arrayVectorSourceLineTempY [vectorSourceCount1] = yPositionTemp;
                                    vectorSourceCount1++;
                                    
                                    xPositionTemp = xPositionTemp+1;
                                    terminationFlag = 1;
                                    findFlag = 1;
                                }
                            }
                            if (yPositionTemp+1 < pixelNumber && findFlag == 0){
                                if (connectivityOutlineMap [yPositionTemp+1][xPositionTemp] == numberOriginal){
                                    connectivityOutlineMap [yPositionTemp+1][xPositionTemp] = overallClearCount*-1;
                                    arrayVectorSourceLineTempValue [vectorSourceCount1] = vectorNumberTemp;
                                    arrayVectorSourceLineTempX [vectorSourceCount1] = xPositionTemp;
                                    arrayVectorSourceLineTempY [vectorSourceCount1] = yPositionTemp+1;
                                    vectorSourceCount1++;
                                    
                                    yPositionTemp = yPositionTemp+1;
                                    terminationFlag = 1;
                                    findFlag = 1;
                                }
                            }
                            if (xPositionTemp-1 >= 0 && findFlag == 0){
                                if (connectivityOutlineMap [yPositionTemp][xPositionTemp-1] == numberOriginal){
                                    connectivityOutlineMap [yPositionTemp][xPositionTemp-1] = overallClearCount*-1;
                                    arrayVectorSourceLineTempValue [vectorSourceCount1] = vectorNumberTemp;
                                    arrayVectorSourceLineTempX [vectorSourceCount1] = xPositionTemp-1;
                                    arrayVectorSourceLineTempY [vectorSourceCount1] = yPositionTemp;
                                    vectorSourceCount1++;
                                    
                                    xPositionTemp = xPositionTemp-1;
                                    terminationFlag = 1;
                                    findFlag = 1;
                                }
                            }
                            if (yPositionTemp-1 >= 0 && findFlag == 0){
                                if (connectivityOutlineMap [yPositionTemp-1][xPositionTemp] == numberOriginal){
                                    connectivityOutlineMap [yPositionTemp-1][xPositionTemp] = overallClearCount*-1;
                                    arrayVectorSourceLineTempValue [vectorSourceCount1] = vectorNumberTemp;
                                    arrayVectorSourceLineTempX [vectorSourceCount1] = xPositionTemp;
                                    arrayVectorSourceLineTempY [vectorSourceCount1] = yPositionTemp-1;
                                    vectorSourceCount1++;
                                    
                                    yPositionTemp = yPositionTemp-1;
                                    terminationFlag = 1;
                                }
                            }
                            
                        } while (terminationFlag == 1);
                    }
                    
                    //for (int counterA = 0; counterA < pixelNumber; counterA++){
                    //	for (int counterB = 0; counterB < pixelNumber; counterB++) cout<<" "<<connectivityOutlineMap [counterA][counterB];
                    //	cout<<" connectivityOutlineMap "<<counterA<<endl;
                    //}
                    
                    if (vectorSourceCount1 > 10){
                        //------Line cleaning------
                        linePointCount = vectorSourceCount1;
                        
                        for (int counter1 = 0; counter1 < linePointCount; counter1++){
                            arrayLineTrimmingValue [counter1] = arrayVectorSourceLineTempValue [counter1];
                            arraylineTrimmingX [counter1] = arrayVectorSourceLineTempX [counter1];
                            arraylineTrimmingY [counter1] = arrayVectorSourceLineTempY [counter1];
                        }
                        
                        for (int counter1 = 0; counter1 < linePointCount-3; counter1++){
                            lineTrimmingX = arraylineTrimmingX [counter1];
                            lineTrimmingY = arraylineTrimmingY [counter1];
                            arraylineTrimmingX [counter1] = -1;
                            arraylineTrimmingY [counter1] = -1;
                            
                            if (lineTrimmingX != -1){
                                attachPoint = 0;
                                countSave = 0;
                                
                                for (int counter2 = counter1+1; counter2 <= counter1+2; counter2++){
                                    lineTrimmingX2 = arraylineTrimmingX [counter2];
                                    lineTrimmingY2 = arraylineTrimmingY [counter2];
                                    
                                    if (lineTrimmingY2 == lineTrimmingY-1 && lineTrimmingX2 == lineTrimmingX-1){
                                        attachPoint++;
                                        
                                        if (attachPoint == 1) countSave = counter2;
                                        
                                        if (attachPoint > 1){
                                            for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                arraylineTrimmingX [counter3] = -1;
                                                arraylineTrimmingY [counter3] = -1;
                                                arrayLineTrimmingValue [counter3] = -1;
                                            }
                                        }
                                    }
                                    if (lineTrimmingY2 == lineTrimmingY-1 && lineTrimmingX2 == lineTrimmingX){
                                        attachPoint++;
                                        
                                        if (attachPoint == 1) countSave = counter2;
                                        
                                        if (attachPoint > 1){
                                            for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                arraylineTrimmingX [counter3] = -1;
                                                arraylineTrimmingY [counter3] = -1;
                                                arrayLineTrimmingValue [counter3] = -1;
                                            }
                                        }
                                    }
                                    if (lineTrimmingY2 == lineTrimmingY-1 && lineTrimmingX2 == lineTrimmingX+1){
                                        attachPoint++;
                                        
                                        if (attachPoint == 1) countSave = counter2;
                                        
                                        if (attachPoint > 1){
                                            for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                arraylineTrimmingX [counter3] = -1;
                                                arraylineTrimmingY [counter3] = -1;
                                                arrayLineTrimmingValue [counter3] = -1;
                                            }
                                        }
                                    }
                                    if (lineTrimmingY2 == lineTrimmingY && lineTrimmingX2 == lineTrimmingX-1){
                                        attachPoint++;
                                        
                                        if (attachPoint == 1) countSave = counter2;
                                        
                                        if (attachPoint > 1){
                                            for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                arraylineTrimmingX [counter3] = -1;
                                                arraylineTrimmingY [counter3] = -1;
                                                arrayLineTrimmingValue [counter3] = -1;
                                            }
                                        }
                                    }
                                    if (lineTrimmingY2 == lineTrimmingY && lineTrimmingX2 == lineTrimmingX){
                                        attachPoint++;
                                        
                                        if (attachPoint == 1) countSave = counter2;
                                        
                                        if (attachPoint > 1){
                                            for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                arraylineTrimmingX [counter3] = -1;
                                                arraylineTrimmingY [counter3] = -1;
                                                arrayLineTrimmingValue [counter3] = -1;
                                            }
                                        }
                                    }
                                    if (lineTrimmingY2 == lineTrimmingY && lineTrimmingX2 == lineTrimmingX+1){
                                        attachPoint++;
                                        
                                        if (attachPoint == 1) countSave = counter2;
                                        
                                        if (attachPoint > 1){
                                            for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                arraylineTrimmingX [counter3] = -1;
                                                arraylineTrimmingY [counter3] = -1;
                                                arrayLineTrimmingValue [counter3] = -1;
                                            }
                                        }
                                    }
                                    if (lineTrimmingY2 == lineTrimmingY+1 && lineTrimmingX2 == lineTrimmingX-1){
                                        attachPoint++;
                                        
                                        if (attachPoint == 1) countSave = counter2;
                                        
                                        if (attachPoint > 1){
                                            for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                arraylineTrimmingX [counter3] = -1;
                                                arraylineTrimmingY [counter3] = -1;
                                                arrayLineTrimmingValue [counter3] = -1;
                                            }
                                        }
                                    }
                                    if (lineTrimmingY2 == lineTrimmingY+1 && lineTrimmingX2 == lineTrimmingX){
                                        attachPoint++;
                                        
                                        if (attachPoint == 1) countSave = counter2;
                                        
                                        if (attachPoint > 1){
                                            for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                arraylineTrimmingX [counter3] = -1;
                                                arraylineTrimmingY [counter3] = -1;
                                                arrayLineTrimmingValue [counter3] = -1;
                                            }
                                        }
                                    }
                                    if (lineTrimmingY2 == lineTrimmingY+1 && lineTrimmingX2 == lineTrimmingX+1){
                                        attachPoint++;
                                        
                                        if (attachPoint == 1) countSave = counter2;
                                        
                                        if (attachPoint > 1){
                                            for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                arraylineTrimmingX [counter3] = -1;
                                                arraylineTrimmingY [counter3] = -1;
                                                arrayLineTrimmingValue [counter3] = -1;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        
                        vectorSourceCount2 = 0;
                        
                        for (int counter1 = 0; counter1 < linePointCount; counter1++){
                            if (arrayLineTrimmingValue [counter1] != -1){
                                arrayVectorSourceLineTempValue2 [vectorSourceCount2] = arrayVectorSourceLineTempValue [counter1];
                                arrayVectorSourceLineTempX2 [vectorSourceCount2] = arrayVectorSourceLineTempX [counter1];
                                arrayVectorSourceLineTempY2 [vectorSourceCount2] = arrayVectorSourceLineTempY [counter1];
                                vectorSourceCount2++;
                            }
                        }
                        
                        if (vectorSourceCount2 > 8){
                            vectorSourceCount1 = 0;
                            linePointCount2 = vectorSourceCount2;
                            
                            for (int counter1 = linePointCount2/2; counter1 < linePointCount2; counter1++){
                                arrayVectorSourceLineTempValue [vectorSourceCount1] = arrayVectorSourceLineTempValue2 [counter1];
                                arrayVectorSourceLineTempX [vectorSourceCount1] = arrayVectorSourceLineTempX2 [counter1];
                                arrayVectorSourceLineTempY [vectorSourceCount1] = arrayVectorSourceLineTempY2 [counter1];
                                vectorSourceCount1++;
                            }
                            
                            for (int counter1 = 0; counter1 < linePointCount2/2; counter1++){
                                arrayVectorSourceLineTempValue [vectorSourceCount1] = arrayVectorSourceLineTempValue2 [counter1];
                                arrayVectorSourceLineTempX [vectorSourceCount1] = arrayVectorSourceLineTempX2 [counter1];
                                arrayVectorSourceLineTempY [vectorSourceCount1] = arrayVectorSourceLineTempY2 [counter1];
                                vectorSourceCount1++;
                            }
                            
                            lineTrimmingCount2 = 0;
                            
                            for (int counter1 = 0; counter1 < linePointCount2; counter1++){
                                arrayLineTrimmingValue2 [counter1] = arrayVectorSourceLineTempValue [counter1];
                                arraylineTrimmingX2 [counter1] = arrayVectorSourceLineTempX [counter1];
                                arraylineTrimmingY2 [counter1] = arrayVectorSourceLineTempY [counter1];
                            }
                            
                            for (int counter1 = 0; counter1 < linePointCount2-3; counter1++){
                                lineTrimmingX = arraylineTrimmingX2 [counter1];
                                lineTrimmingY = arraylineTrimmingY2 [counter1];
                                arraylineTrimmingX2 [counter1] = -1;
                                arraylineTrimmingY2 [counter1] = -1;
                                
                                if (lineTrimmingX != -1){
                                    attachPoint = 0;
                                    countSave = 0;
                                    
                                    for (int counter2 = counter1+1; counter2 <= counter1+2; counter2++){
                                        lineTrimmingX2 = arraylineTrimmingX2 [counter2];
                                        lineTrimmingY2 = arraylineTrimmingY2 [counter2];
                                        
                                        if (lineTrimmingY2 == lineTrimmingY-1 && lineTrimmingX2 == lineTrimmingX-1){
                                            attachPoint++;
                                            
                                            if (attachPoint == 1) countSave = counter2;
                                            
                                            if (attachPoint > 1){
                                                for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                    arraylineTrimmingX2 [counter3] = -1;
                                                    arraylineTrimmingY2 [counter3] = -1;
                                                    arrayLineTrimmingValue2 [counter3] = -1;
                                                    lineTrimmingCount2++;
                                                }
                                            }
                                        }
                                        
                                        if (lineTrimmingY2 == lineTrimmingY-1 && lineTrimmingX2 == lineTrimmingX){
                                            attachPoint++;
                                            
                                            if (attachPoint == 1) countSave = counter2;
                                            
                                            if (attachPoint > 1){
                                                for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                    arraylineTrimmingX2 [counter3] = -1;
                                                    arraylineTrimmingY2 [counter3] = -1;
                                                    arrayLineTrimmingValue2 [counter3] = -1;
                                                    lineTrimmingCount2++;
                                                }
                                            }
                                        }
                                        
                                        if (lineTrimmingY2 == lineTrimmingY-1 && lineTrimmingX2 == lineTrimmingX+1){
                                            attachPoint++;
                                            
                                            if (attachPoint == 1) countSave = counter2;
                                            
                                            if (attachPoint > 1){
                                                for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                    arraylineTrimmingX2 [counter3] = -1;
                                                    arraylineTrimmingY2 [counter3] = -1;
                                                    arrayLineTrimmingValue2 [counter3] = -1;
                                                    lineTrimmingCount2++;
                                                }
                                            }
                                        }
                                        
                                        if (lineTrimmingY2 == lineTrimmingY && lineTrimmingX2 == lineTrimmingX-1){
                                            attachPoint++;
                                            
                                            if (attachPoint == 1) countSave = counter2;
                                            
                                            if (attachPoint > 1){
                                                for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                    arraylineTrimmingX2 [counter3] = -1;
                                                    arraylineTrimmingY2 [counter3] = -1;
                                                    arrayLineTrimmingValue2 [counter3] = -1;
                                                    lineTrimmingCount2++;
                                                }
                                            }
                                        }
                                        
                                        if (lineTrimmingY2 == lineTrimmingY && lineTrimmingX2 == lineTrimmingX){
                                            attachPoint++;
                                            
                                            if (attachPoint == 1) countSave = counter2;
                                            
                                            if (attachPoint > 1){
                                                for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                    arraylineTrimmingX2 [counter3] = -1;
                                                    arraylineTrimmingY2 [counter3] = -1;
                                                    arrayLineTrimmingValue2 [counter3] = -1;
                                                    lineTrimmingCount2++;
                                                }
                                            }
                                        }
                                        
                                        if (lineTrimmingY2 == lineTrimmingY && lineTrimmingX2 == lineTrimmingX+1){
                                            attachPoint++;
                                            
                                            if (attachPoint == 1) countSave = counter2;
                                            
                                            if (attachPoint > 1){
                                                for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                    arraylineTrimmingX2 [counter3] = -1;
                                                    arraylineTrimmingY2 [counter3] = -1;
                                                    arrayLineTrimmingValue2 [counter3] = -1;
                                                    lineTrimmingCount2++;
                                                }
                                            }
                                        }
                                        
                                        if (lineTrimmingY2 == lineTrimmingY+1 && lineTrimmingX2 == lineTrimmingX-1){
                                            attachPoint++;
                                            
                                            if (attachPoint == 1) countSave = counter2;
                                            
                                            if (attachPoint > 1){
                                                for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                    arraylineTrimmingX2 [counter3] = -1;
                                                    arraylineTrimmingY2 [counter3] = -1;
                                                    arrayLineTrimmingValue2 [counter3] = -1;
                                                    lineTrimmingCount2++;
                                                }
                                            }
                                        }
                                        
                                        if (lineTrimmingY2 == lineTrimmingY+1 && lineTrimmingX2 == lineTrimmingX){
                                            attachPoint++;
                                            
                                            if (attachPoint == 1) countSave = counter2;
                                            
                                            if (attachPoint > 1){
                                                for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                    arraylineTrimmingX2 [counter3] = -1;
                                                    arraylineTrimmingY2 [counter3] = -1;
                                                    arrayLineTrimmingValue2 [counter3] = -1;
                                                    lineTrimmingCount2++;
                                                }
                                            }
                                        }
                                        
                                        if (lineTrimmingY2 == lineTrimmingY+1 && lineTrimmingX2 == lineTrimmingX+1){
                                            attachPoint++;
                                            
                                            if (attachPoint == 1) countSave = counter2;
                                            
                                            if (attachPoint > 1){
                                                for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                    arraylineTrimmingX2 [counter3] = -1;
                                                    arraylineTrimmingY2 [counter3] = -1;
                                                    arrayLineTrimmingValue2 [counter3] = -1;
                                                    lineTrimmingCount2++;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            
                            if (linePointCount-lineTrimmingCount2 > areaLimitCurrent){
                                if (arrayNumber == 1){
                                    if (outlineVectorSourceCount0+linePointCount2*3 > outlineVectorSourceLimit0){
                                        int *arraySourceTemp = new int [outlineVectorSourceCount0+50];
                                        for (int counter1 = 0; counter1 < outlineVectorSourceCount0; counter1++) arraySourceTemp [counter1] = arrayOutlineVectorSource0 [counter1];
                                        
                                        delete [] arrayOutlineVectorSource0;
                                        arrayOutlineVectorSource0 = new int [outlineVectorSourceLimit0+linePointCount2*3+7500];
                                        outlineVectorSourceLimit0 = outlineVectorSourceLimit0+linePointCount2*3+7500;
                                        
                                        for (int counter1 = 0; counter1 < outlineVectorSourceCount0; counter1++) arrayOutlineVectorSource0 [counter1] = arraySourceTemp [counter1];
                                        delete [] arraySourceTemp;
                                    }
                                    
                                    for (int counter1 = 0; counter1 < linePointCount2; counter1++){
                                        if (arrayLineTrimmingValue2 [counter1] != -1){
                                            arrayOutlineVectorSource0 [outlineVectorSourceCount0] = arrayVectorSourceLineTempValue [counter1], outlineVectorSourceCount0++; //------vector no------
                                            arrayOutlineVectorSource0 [outlineVectorSourceCount0] = arrayVectorSourceLineTempX [counter1], outlineVectorSourceCount0++; //------X position------
                                            arrayOutlineVectorSource0 [outlineVectorSourceCount0] = arrayVectorSourceLineTempY [counter1], outlineVectorSourceCount0++; //------Y position------
                                        }
                                    }
                                }
                                
                                if (arrayNumber == 2){
                                    if (outlineVectorSourceCount1+linePointCount2*3 > outlineVectorSourceLimit1){
                                        int *arraySourceTemp = new int [outlineVectorSourceCount1+50];
                                        for (int counter1 = 0; counter1 < outlineVectorSourceCount1; counter1++) arraySourceTemp [counter1] = arrayOutlineVectorSource1 [counter1];
                                        
                                        delete [] arrayOutlineVectorSource1;
                                        arrayOutlineVectorSource1 = new int [outlineVectorSourceLimit1+linePointCount2*3+7500];
                                        outlineVectorSourceLimit1 = outlineVectorSourceLimit1+linePointCount2*3+7500;
                                        
                                        for (int counter1 = 0; counter1 < outlineVectorSourceCount1; counter1++) arrayOutlineVectorSource1 [counter1] = arraySourceTemp [counter1];
                                        delete [] arraySourceTemp;
                                    }
                                    
                                    for (int counter1 = 0; counter1 < linePointCount2; counter1++){
                                        if (arrayLineTrimmingValue2 [counter1] != -1){
                                            arrayOutlineVectorSource1 [outlineVectorSourceCount1] = arrayVectorSourceLineTempValue [counter1], outlineVectorSourceCount1++; //------vector no------
                                            arrayOutlineVectorSource1 [outlineVectorSourceCount1] = arrayVectorSourceLineTempX [counter1], outlineVectorSourceCount1++; //------X position------
                                            arrayOutlineVectorSource1 [outlineVectorSourceCount1] = arrayVectorSourceLineTempY [counter1], outlineVectorSourceCount1++; //------Y position------
                                        }
                                    }
                                }
                                
                                if (arrayNumber == 3){
                                    if (outlineVectorSourceCount2+linePointCount2*3 > outlineVectorSourceLimit2){
                                        int *arraySourceTemp = new int [outlineVectorSourceCount2+50];
                                        for (int counter1 = 0; counter1 < outlineVectorSourceCount2; counter1++) arraySourceTemp [counter1] = arrayOutlineVectorSource2 [counter1];
                                        
                                        delete [] arrayOutlineVectorSource2;
                                        arrayOutlineVectorSource2 = new int [outlineVectorSourceLimit2+linePointCount2*3+7500];
                                        outlineVectorSourceLimit2 = outlineVectorSourceLimit2+linePointCount2*3+7500;
                                        
                                        for (int counter1 = 0; counter1 < outlineVectorSourceCount2; counter1++) arrayOutlineVectorSource2 [counter1] = arraySourceTemp [counter1];
                                        delete [] arraySourceTemp;
                                    }
                                    
                                    for (int counter1 = 0; counter1 < linePointCount2; counter1++){
                                        if (arrayLineTrimmingValue2 [counter1] != -1){
                                            arrayOutlineVectorSource2 [outlineVectorSourceCount2] = arrayVectorSourceLineTempValue [counter1], outlineVectorSourceCount2++; //------vector no------
                                            arrayOutlineVectorSource2 [outlineVectorSourceCount2] = arrayVectorSourceLineTempX [counter1], outlineVectorSourceCount2++; //------X position------
                                            arrayOutlineVectorSource2 [outlineVectorSourceCount2] = arrayVectorSourceLineTempY [counter1], outlineVectorSourceCount2++; //------Y position------
                                        }
                                    }
                                }
                                
                                if (arrayNumber == 4){
                                    if (outlineVectorSourceCount3+linePointCount2*3 > outlineVectorSourceLimit3){
                                        int *arraySourceTemp = new int [outlineVectorSourceCount3+50];
                                        for (int counter1 = 0; counter1 < outlineVectorSourceCount3; counter1++) arraySourceTemp [counter1] = arrayOutlineVectorSource3 [counter1];
                                        
                                        delete [] arrayOutlineVectorSource3;
                                        arrayOutlineVectorSource3 = new int [outlineVectorSourceLimit3+linePointCount2*3+7500];
                                        outlineVectorSourceLimit3 = outlineVectorSourceLimit3+linePointCount2*3+7500;
                                        
                                        for (int counter1 = 0; counter1 < outlineVectorSourceCount3; counter1++) arrayOutlineVectorSource3 [counter1] = arraySourceTemp [counter1];
                                        delete [] arraySourceTemp;
                                    }
                                    
                                    for (int counter1 = 0; counter1 < linePointCount2; counter1++){
                                        if (arrayLineTrimmingValue2 [counter1] != -1){
                                            arrayOutlineVectorSource3 [outlineVectorSourceCount3] = arrayVectorSourceLineTempValue [counter1], outlineVectorSourceCount3++; //------vector no------
                                            arrayOutlineVectorSource3 [outlineVectorSourceCount3] = arrayVectorSourceLineTempX [counter1], outlineVectorSourceCount3++; //------X position------
                                            arrayOutlineVectorSource3 [outlineVectorSourceCount3] = arrayVectorSourceLineTempY [counter1], outlineVectorSourceCount3++; //------Y position------
                                        }
                                    }
                                }
                                
                                if (arrayNumber == 5){
                                    if (outlineVectorSourceCount4+linePointCount2*5 > outlineVectorSourceLimit4){
                                        int *arraySourceTemp = new int [outlineVectorSourceCount4+50];
                                        for (int counter1 = 0; counter1 < outlineVectorSourceCount4; counter1++) arraySourceTemp [counter1] = arrayOutlineVectorSource4 [counter1];
                                        
                                        delete [] arrayOutlineVectorSource4;
                                        arrayOutlineVectorSource4 = new int [outlineVectorSourceLimit4+linePointCount2*5+7500];
                                        outlineVectorSourceLimit4 = outlineVectorSourceLimit4+linePointCount2*5+7500;
                                        
                                        for (int counter1 = 0; counter1 < outlineVectorSourceCount4; counter1++) arrayOutlineVectorSource4 [counter1] = arraySourceTemp [counter1];
                                        delete [] arraySourceTemp;
                                    }
                                    
                                    for (int counter1 = 0; counter1 < linePointCount2; counter1++){
                                        if (arrayLineTrimmingValue2 [counter1] != -1){
                                            arrayOutlineVectorSource4 [outlineVectorSourceCount4] = arrayVectorSourceLineTempValue [counter1], outlineVectorSourceCount4++; //------vector no------
                                            arrayOutlineVectorSource4 [outlineVectorSourceCount4] = arrayVectorSourceLineTempX [counter1], outlineVectorSourceCount4++; //------X position------
                                            arrayOutlineVectorSource4 [outlineVectorSourceCount4] = arrayVectorSourceLineTempY [counter1], outlineVectorSourceCount4++; //------Y position------
                                            arrayOutlineVectorSource4 [outlineVectorSourceCount4] = 0, outlineVectorSourceCount4++; //------reserve------
                                            arrayOutlineVectorSource4 [outlineVectorSourceCount4] = 0, outlineVectorSourceCount4++; //------reserve------
                                        }
                                    }
                                }
                                
                                vectorNumberTemp++;
                            }
                        }
                    }
                    
                    overallClearCount++;
                }
            }
        }
    }
    
    delete [] arrayVectorSourceLineTempValue;
    delete [] arrayVectorSourceLineTempX;
    delete [] arrayVectorSourceLineTempY;
    delete [] arrayVectorSourceLineTempValue2;
    delete [] arrayVectorSourceLineTempX2;
    delete [] arrayVectorSourceLineTempY2;
    delete [] arrayLineTrimmingValue;
    delete [] arraylineTrimmingX;
    delete [] arraylineTrimmingY;
    delete [] arrayLineTrimmingValue2;
    delete [] arraylineTrimmingX2;
    delete [] arraylineTrimmingY2;
    
    for (int counterY = 0; counterY < pixelNumber+4; counterY++){
        delete [] connectivityOutlineMap [counterY];
        delete [] connectivityOutlineMap2 [counterY];
    }
    
    delete [] connectivityOutlineMap;
    delete [] connectivityOutlineMap2;
    
    if (arrayNumber < 5){
        int *arrayOutLineDataBrightX2 = new int [largestConnect+50];
        int *arrayOutLineDataBrightY2 = new int [largestConnect+50];
        int *arrayVectorTempX = new int [largestConnect+50];
        int *arrayVectorTempY = new int [largestConnect+50];
        
        int vectorThroughNumber = 0;
        int terminationCheck = outLineDataBrightCount;
        int outlineDataBrightCount2 = 0;
        int regionNumber = 0;
        int extractedX = 0;
        int extractedY = 0;
        int extractedTempX = 0;
        int extractedTempY = 0;
        int noFindFlag = 1;
        int loopCloseCheck = 0;
        int outlineDataCount = 0;
        int extractedX2 = 0;
        int extractedY2 = 0;
        int vectorArrayTempCount = 0;
        int extractedTempX2 = 0;
        int extractedTempY2 = 0;
        
        while (outLineDataBrightCount != 0){
            outlineDataBrightCount2 = 0;
            
            regionNumber = arrayOutLineDataBrightValue [0];
            extractedX = arrayOutLineDataBrightX [0];
            extractedY = arrayOutLineDataBrightY [0];
            extractedTempX = arrayOutLineDataBrightX [0];
            extractedTempY = arrayOutLineDataBrightY [0];
            
            arrayOutLineDataBrightX2 [outlineDataBrightCount2] = arrayOutLineDataBrightX [0];
            arrayOutLineDataBrightY2 [outlineDataBrightCount2] = arrayOutLineDataBrightY [0];
            outlineDataBrightCount2++;
            
            for (int counter1 = 1; counter1 < outLineDataBrightCount; counter1++){
                arrayOutLineDataBrightValue [counter1-1] = arrayOutLineDataBrightValue [counter1];
                arrayOutLineDataBrightX [counter1-1] = arrayOutLineDataBrightX [counter1];
                arrayOutLineDataBrightY [counter1-1] = arrayOutLineDataBrightY [counter1];
            }
            
            arrayOutLineDataBrightValue [outLineDataBrightCount-1] = regionNumber;
            arrayOutLineDataBrightX [outLineDataBrightCount-1] = extractedX;
            arrayOutLineDataBrightY [outLineDataBrightCount-1] = extractedY;
            
            noFindFlag = 1;
            loopCloseCheck = 0;
            
            while (noFindFlag == 1){
                noFindFlag = 1;
                outlineDataCount = outLineDataBrightCount;
                
                for (int counter1 = 0; counter1 < outlineDataCount; counter1++){
                    if (arrayOutLineDataBrightValue [counter1] == regionNumber){
                        extractedX2 = arrayOutLineDataBrightX [counter1];
                        extractedY2 = arrayOutLineDataBrightY [counter1];
                        
                        if ((extractedY2-1 == extractedTempY && extractedX2 == extractedTempX) || (extractedY2 == extractedTempY && extractedX2+1 == extractedTempX) || (extractedY2+1 == extractedTempY && extractedX2 == extractedTempX) || (extractedY2 == extractedTempY && extractedX2-1 == extractedTempX)){
                            if (extractedY2 == extractedY && extractedX2 == extractedX){
                                arrayOutLineDataBrightX2 [outlineDataBrightCount2] = extractedX2;
                                arrayOutLineDataBrightY2 [outlineDataBrightCount2] = extractedY2;
                                outlineDataBrightCount2++;
                                
                                for (int counter2 = counter1; counter2 < outLineDataBrightCount-1; counter2++){
                                    arrayOutLineDataBrightValue [counter2] = arrayOutLineDataBrightValue [counter2+1];
                                    arrayOutLineDataBrightX [counter2] = arrayOutLineDataBrightX [counter2+1];
                                    arrayOutLineDataBrightY [counter2] = arrayOutLineDataBrightY [counter2+1];
                                }
                                
                                outLineDataBrightCount--;
                                
                                arrayOutLineDataBrightX2 [outlineDataBrightCount2] = extractedX2;
                                arrayOutLineDataBrightY2 [outlineDataBrightCount2] = extractedY2;
                                outlineDataBrightCount2++;
                                
                                noFindFlag = 0;
                                loopCloseCheck = 1;
                                break;
                            }
                            else{
                                
                                arrayOutLineDataBrightX2 [outlineDataBrightCount2] = extractedX2;
                                arrayOutLineDataBrightY2 [outlineDataBrightCount2] = extractedY2;
                                outlineDataBrightCount2++;
                                
                                extractedTempX = extractedX2;
                                extractedTempY = extractedY2;
                                
                                for (int counter2 = counter1; counter2 < outLineDataBrightCount-1; counter2++){
                                    arrayOutLineDataBrightValue [counter2] = arrayOutLineDataBrightValue [counter2+1];
                                    arrayOutLineDataBrightX [counter2] = arrayOutLineDataBrightX [counter2+1];
                                    arrayOutLineDataBrightY [counter2] = arrayOutLineDataBrightY [counter2+1];
                                }
                                
                                outLineDataBrightCount--;
                                
                                noFindFlag = 1;
                                break;
                            }
                        }
                    }
                    
                    if (counter1 == outLineDataBrightCount-1) noFindFlag = 0;
                }
            }
            
            if (outlineDataBrightCount2 >= 4 && loopCloseCheck != 0){
                vectorArrayTempCount = 0;
                
                extractedTempX2 = arrayOutLineDataBrightX2 [0];
                extractedTempY2 = arrayOutLineDataBrightY2 [0];
                
                arrayVectorTempX [vectorArrayTempCount] = extractedTempX2;
                arrayVectorTempY [vectorArrayTempCount] = extractedTempY2;
                vectorArrayTempCount++;
                
                for (int counter1 = 0; counter1 < outlineDataBrightCount2; counter1 = counter1+2){
                    if ((arrayOutLineDataBrightX2 [counter1]-extractedTempX2 >= 3) || (arrayOutLineDataBrightX2 [counter1]-extractedTempX2 <= -3) || (arrayOutLineDataBrightY2 [counter1]-extractedTempY2 >= 3) || (arrayOutLineDataBrightY2 [counter1]-extractedTempY2 <= -3)){
                        arrayVectorTempX [vectorArrayTempCount] = arrayOutLineDataBrightX2 [counter1];
                        arrayVectorTempY [vectorArrayTempCount] = arrayOutLineDataBrightY2 [counter1];
                        vectorArrayTempCount++;
                        
                        extractedTempX2 = arrayOutLineDataBrightX2 [counter1];
                        extractedTempY2 = arrayOutLineDataBrightY2 [counter1];
                    }
                    else{
                        
                        if (counter1 == outlineDataBrightCount2-1){
                            if (vectorArrayTempCount >= 1){
                                arrayVectorTempX [vectorArrayTempCount-1] = arrayOutLineDataBrightX2 [counter1];
                                arrayVectorTempY [vectorArrayTempCount-1] = arrayOutLineDataBrightY2 [counter1];
                            }
                        }
                    }
                }
                
                if (vectorArrayTempCount >= 6){ //------If number of vector is less than 6, do not save------
                    vectorThroughNumber++;
                    
                    if (arrayNumber == 1 || arrayNumber == 2 || arrayNumber == 3 || arrayNumber == 4){
                        if (vectorArrayTempCount*3+outlineVectorSegmentCount > outlineVectorSegmentLimit){
                            int *arraySourceTemp = new int [outlineVectorSegmentCount+50];
                            for (int counter1 = 0; counter1 < outlineVectorSegmentCount; counter1++) arraySourceTemp [counter1] = arrayOutlineVectorSegment [counter1];
                            
                            delete [] arrayOutlineVectorSegment;
                            arrayOutlineVectorSegment = new int [vectorArrayTempCount*3+outlineVectorSegmentLimit+500];
                            outlineVectorSegmentLimit = vectorArrayTempCount*3+outlineVectorSegmentLimit+500;
                            
                            for (int counter1 = 0; counter1 < outlineVectorSegmentCount; counter1++) arrayOutlineVectorSegment [counter1] = arraySourceTemp [counter1];
                            delete [] arraySourceTemp;
                        }
                        
                        for (int counter1 = 0; counter1 < vectorArrayTempCount; counter1 = counter1+2){
                            arrayOutlineVectorSegment [outlineVectorSegmentCount] = vectorThroughNumber, outlineVectorSegmentCount++;
                            arrayOutlineVectorSegment [outlineVectorSegmentCount] = arrayVectorTempX [counter1], outlineVectorSegmentCount++;
                            arrayOutlineVectorSegment [outlineVectorSegmentCount] = arrayVectorTempY [counter1], outlineVectorSegmentCount++;
                        }
                    }
                }
            }
            
            if (outLineDataBrightCount != 0){
                if (terminationCheck != outLineDataBrightCount) terminationCheck = outLineDataBrightCount;
                else outLineDataBrightCount = 0;
            }
        }
        
        delete [] arrayOutLineDataBrightX2;
        delete [] arrayOutLineDataBrightY2;
        delete [] arrayVectorTempX;
        delete [] arrayVectorTempY;
    }
    
    delete [] arrayOutLineDataBrightValue;
    delete [] arrayOutLineDataBrightX;
    delete [] arrayOutLineDataBrightY;
    
    //for (int counterA = 0; counterA < outlineVectorSegmentCount/3; counterA++){
    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOutlineVectorSegment [counterA*3+counterB];
    //	cout<<" arrayOutlineVectorSegment "<<counterA<<endl;
    //}
}

@end
