//
// OverlapCheck.mm
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 02/02/13.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#import "OverlapCheck.h"

@implementation OverlapCheck

-(void)overlapCheckMain:(int)typeSubArray{
    //for (int counterA = 0; counterA < linkedLineUpdateCount/5; counterA++){
    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayLinkedLineUpdate [counterA*5+counterB];
    //    cout<<" arrayLinkedLineUpdate "<<counterA<<endl;
    //}
    
    if (linkedLineUpdateCount != 0){
        int numberOfEntryTemp = 0;
        int numberOfEntryTemp2 = 0;
        
        for (int counter1 = 0; counter1 < linkedLineUpdateCount/5; counter1++){
            if (arrayLinkedLineUpdate [counter1*5+4] == 1) numberOfEntryTemp++;
            if (arrayLinkedLineUpdate [counter1*5+4] == 2) numberOfEntryTemp2++;
        }
        
        int numberOfEntry = 0;
        
        if (numberOfEntryTemp >= numberOfEntryTemp2) numberOfEntry = numberOfEntryTemp;
        else numberOfEntry = numberOfEntryTemp2;
        
        int **entryPosition = new int *[numberOfEntry+4];
        for (int counter1 = 0; counter1 < numberOfEntry+4; counter1++) entryPosition [counter1] = new int [3];
        
        for (int counter1 = 0; counter1 < numberOfEntry+4; counter1++){
            entryPosition [counter1][0] = -1;
            entryPosition [counter1][1] = -1;
        }
        
        int numberOfEntry2 = 0;
        int entryFlag = 0;
        int firstEntryTemp = 0;
        
        for (int counter1 = 0; counter1 < linkedLineUpdateCount/5; counter1++){
            if (arrayLinkedLineUpdate [counter1*5+4] == 1 && entryFlag == 0){
                entryFlag = 1;
                firstEntryTemp = counter1;
            }
            else if (arrayLinkedLineUpdate [counter1*5+4] == 2 && entryFlag == 1){
                entryPosition [numberOfEntry2][0] = firstEntryTemp;
                entryPosition [numberOfEntry2][1] = counter1, numberOfEntry2++;
                entryFlag = 0;
            }
            else if (arrayLinkedLineUpdate [counter1*5+4] == 1 && entryFlag == 1){
                firstEntryTemp = counter1;
            }
        }
        
        // for (int counterA = 0; counterA < numberOfEntry2; counterA++){
        //     cout<<counterA+1<<" "<<numberOfEntry<<" "<< entryPosition [counterA][0]<<" "<< entryPosition [counterA][1]<<" entryPosition"<<endl;
        //}
        
        int **horizontalVerticalData = new int *[numberOfEntry+4];
        for (int counter1 = 0; counter1 < numberOfEntry+4; counter1++) horizontalVerticalData [counter1] = new int [5];
        
        int *associatedInfo1 = new int [numberOfEntry+4]; //------Process Type------
        int *associatedInfo2 = new int [numberOfEntry+4]; //------Cut Type------
        int *associatedInfo3 = new int [numberOfEntry+4]; //------Pair Number------
        int *associatedInfo4 = new int [numberOfEntry+4]; //------Cell dimension------
        int *modificationInfo = new int [numberOfEntry+4];
        int *fusionInfo = new int [numberOfEntry+4];
        int *extensionRemoveInfo = new int [numberOfEntry+4];
        
        for (int counter1 = 0; counter1 < numberOfEntry+1; counter1++){
            horizontalVerticalData [counter1][0] = 0;
            horizontalVerticalData [counter1][1] = 0;
            horizontalVerticalData [counter1][2] = 0;
            horizontalVerticalData [counter1][3] = 0;
            associatedInfo1 [counter1] = 0;
            associatedInfo2 [counter1] = 0;
            associatedInfo3 [counter1] = 0;
            associatedInfo4 [counter1] = 0;
            modificationInfo [counter1] = 0;
            fusionInfo [counter1] = 0;
            extensionRemoveInfo [counter1] = 0;
        }
        
        int **arrayConnectData = new int *[numberOfEntry+1];
        for (int counter1 = 0; counter1 < numberOfEntry+1; counter1++) arrayConnectData [counter1] = new int [5000];
        
        int *arrayConnectDataPosition = new int [numberOfEntry*2+50];
        for (int counter1 = 0; counter1 < numberOfEntry*2+50; counter1++) arrayConnectDataPosition [counter1] = 0;
        
        int **arrayLineData = new int *[numberOfEntry+1];
        for (int counter1 = 0; counter1 < numberOfEntry+1; counter1++) arrayLineData [counter1] = new int [5000];
        
        int *arrayLineDataPosition = new int [numberOfEntry+1];
        for (int counter1 = 0; counter1 < numberOfEntry+1; counter1++) arrayLineDataPosition [counter1] = 0;
        
        int **arrayLineDataAss = new int *[numberOfEntry+1];
        for (int counter1 = 0; counter1 < numberOfEntry+1; counter1++) arrayLineDataAss [counter1] = new int [10];
        
        int startPosition = 0;
        int endPosition = 0;
        int lineNumber = 0;
        int maxPointDimX = 0;
        int maxPointDimY = 0;
        int minPointDimX = 0;
        int minPointDimY = 0;
        int horizontalLength = 0;
        int verticalLength = 0;
        int dimension = 0;
        int horizontalStart = 0;
        int verticalStart = 0;
        int lineTempX = 0;
        int lineTempY = 0;
        int connectivityNumber = 0;
        int connectAnalysisCount = 0;
        int terminationFlag = 0;
        int connectAnalysisTempCount = 0;
        int xSource = 0;
        int ySource = 0;
        int extensionFindFlag = 0;
        int mapEntryCount = 0;
        int connectDataCount = 0;
        int totalValue = 0;
        int lineDataEntryCount = 0;
        
        for (int counter1 = 0; counter1 < numberOfEntry2; counter1++){
            startPosition = entryPosition [counter1][0];
            endPosition = entryPosition [counter1][1];
            lineNumber = arrayLinkedLineUpdate [startPosition*5+3];
            
            maxPointDimX = 0;
            maxPointDimY = 0;
            minPointDimX = 100000;
            minPointDimY = 100000;
            
            if ((endPosition-startPosition+1)*5 > 5000){
                delete [] arrayLineData [counter1];
                arrayLineData [counter1] = new int [(endPosition-startPosition+1)*5+500];
            }
            
            lineDataEntryCount = 0;
            
            for (int counter2 = startPosition; counter2 <= endPosition; counter2++){
                arrayLineData [counter1][lineDataEntryCount] = arrayLinkedLineUpdate [counter2*5], lineDataEntryCount++;
                arrayLineData [counter1][lineDataEntryCount] = arrayLinkedLineUpdate [counter2*5+1], lineDataEntryCount++;
                arrayLineData [counter1][lineDataEntryCount] = arrayLinkedLineUpdate [counter2*5+2], lineDataEntryCount++;
                arrayLineData [counter1][lineDataEntryCount] = arrayLinkedLineUpdate [counter2*5+3], lineDataEntryCount++;
                arrayLineData [counter1][lineDataEntryCount] = arrayLinkedLineUpdate [counter2*5+4], lineDataEntryCount++;
                
                if (maxPointDimX < arrayLinkedLineUpdate [counter2*5]) maxPointDimX = arrayLinkedLineUpdate [counter2*5];
                if (minPointDimX > arrayLinkedLineUpdate [counter2*5]) minPointDimX = arrayLinkedLineUpdate [counter2*5];
                if (maxPointDimY < arrayLinkedLineUpdate [counter2*5+1]) maxPointDimY = arrayLinkedLineUpdate [counter2*5+1];
                if (minPointDimY > arrayLinkedLineUpdate [counter2*5+1]) minPointDimY = arrayLinkedLineUpdate [counter2*5+1];
            }
            
            arrayLineDataPosition [counter1] = lineDataEntryCount;
            
            for (int counter2 = 0; counter2 < linkedLineUpdateAssCount/6; counter2++){
                if (arrayLinkedLineUpdateAss [counter2*6] == lineNumber){
                    arrayLineDataAss [counter1][0] = arrayLinkedLineUpdateAss [counter2*6];
                    arrayLineDataAss [counter1][1] = arrayLinkedLineUpdateAss [counter2*6+1];
                    arrayLineDataAss [counter1][2] = arrayLinkedLineUpdateAss [counter2*6+2];
                    arrayLineDataAss [counter1][3] = arrayLinkedLineUpdateAss [counter2*6+3];
                    arrayLineDataAss [counter1][4] = arrayLinkedLineUpdateAss [counter2*6+4];
                    arrayLineDataAss [counter1][5] = arrayLinkedLineUpdateAss [counter2*6+5];
                    break;
                }
            }
            
            //------Determine the dimension of cell------
            horizontalLength = (maxPointDimX-minPointDimX)/2*2;
            verticalLength = (maxPointDimY-minPointDimY)/2*2;
            dimension = 0;
            
            if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
            
            if (horizontalLength < verticalLength) dimension = verticalLength+30;
            
            dimension = (dimension/2)*2;
            
            horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
            verticalStart = minPointDimY-(dimension-verticalLength)/2;
            
            horizontalVerticalData [counter1+1][0] = horizontalStart;
            horizontalVerticalData [counter1+1][1] = verticalStart;
            horizontalVerticalData [counter1+1][2] = dimension;
            
            int **previousMap2 = new int *[dimension+4];
            
            for (int counter2 = 0; counter2 < dimension+4; counter2++) previousMap2 [counter2] = new int [dimension+4];
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++) previousMap2 [counterY][counterX] = 0;
            }
            
            for (int counter2 = startPosition; counter2 <= endPosition; counter2++){
                lineTempX = arrayLinkedLineUpdate [counter2*5]-horizontalStart;
                lineTempY = arrayLinkedLineUpdate [counter2*5+1]-verticalStart;
                
                if (lineTempX < 0) lineTempX = 0;
                else if (lineTempX >= dimension) lineTempX = dimension-1;
                
                if (lineTempY < 0) lineTempY = 0;
                else if (lineTempY >= dimension) lineTempY = dimension-1;
                
                previousMap2 [lineTempY][lineTempX] = lineNumber;
            }
            
            int *connectAnalysisX = new int [dimension*4];
            int *connectAnalysisY = new int [dimension*4];
            int *connectAnalysisTempX = new int [dimension*4];
            int *connectAnalysisTempY = new int [dimension*4];
            
            connectivityNumber = -3;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (previousMap2 [counterY][counterX] == 0){
                        connectivityNumber = connectivityNumber+2;
                        connectAnalysisCount = 0;
                        
                        if (connectivityNumber >= 1) connectivityNumber = lineNumber, previousMap2 [counterY][counterX] = connectivityNumber;
                        
                        if (counterY-1 >= 0 && previousMap2 [counterY-1][counterX] == 0){
                            previousMap2 [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension && previousMap2 [counterY][counterX+1] == 0){
                            previousMap2 [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && previousMap2 [counterY+1][counterX] == 0){
                            previousMap2 [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && previousMap2 [counterY][counterX-1] == 0){
                            previousMap2 [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                    xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                    
                                    if (ySource-1 >= 0 && previousMap2 [ySource-1][xSource] == 0){
                                        previousMap2 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && previousMap2 [ySource][xSource+1] == 0){
                                        previousMap2 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && previousMap2 [ySource+1][xSource] == 0){
                                        previousMap2 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && previousMap2 [ySource][xSource-1] == 0){
                                        previousMap2 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                    connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            delete [] connectAnalysisX;
            delete [] connectAnalysisY;
            delete [] connectAnalysisTempX;
            delete [] connectAnalysisTempY;
            
            //------Remove connectivity groups, which attach edge, extract inner part of Linked Line------
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (previousMap2 [counterY][counterX] == -1) previousMap2 [counterY][counterX] = 0;
                }
            }
            
            //------Extension to area 100 remove------
            extensionFindFlag = 0;
            mapEntryCount = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (previousMap2 [counterY][counterX] != 0 && counterY+verticalStart >= 0 && counterY+verticalStart < imageWidth && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageWidth && arrayExtractedImage [counterY+verticalStart][counterX+horizontalStart] == 100){
                        previousMap2 [counterY][counterX] = 0;
                        extensionFindFlag = 1;
                    }
                    else if (previousMap2 [counterY][counterX] != 0) mapEntryCount++;
                }
            }
            
            if (extensionFindFlag == 1) extensionRemoveInfo [counter1+1] = 1;
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap2 [counterA][counterB];
            //	cout<<" previousMap2 "<<counterA<<endl;
            //}
            
            connectDataCount = 0;
            
            if (mapEntryCount*2 > 5000){
                delete [] arrayConnectData [counter1];
                arrayConnectData [counter1] = new int [mapEntryCount*2+500];
            }
            
            totalValue = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (previousMap2 [counterY][counterX] != 0){
                        arrayConnectData [counter1][connectDataCount] = counterX+horizontalStart, connectDataCount++;
                        arrayConnectData [counter1][connectDataCount] = counterY+verticalStart, connectDataCount++;
                        
                        if (counterY+verticalStart >= 0 && counterY+verticalStart < imageWidth && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageWidth){
                            totalValue = totalValue+arrayExtractedImage [counterY+verticalStart][counterX+horizontalStart];
                        }
                    }
                }
            }
            
            arrayConnectDataPosition [counter1*2] = connectDataCount; //----------Total of X+Y position----------
            arrayConnectDataPosition [counter1*2+1] = mapEntryCount*2+500; //---------Max array entry, connectDataCount+500----------
            
            horizontalVerticalData [counter1+1][3] = totalValue;
            
            for (int counter2 = 0; counter2 < linkedLineUpdateAssCount/6; counter2++){
                if (arrayLinkedLineUpdateAss [counter2*6] == lineNumber){
                    associatedInfo1 [counter1+1] = arrayLinkedLineUpdateAss [counter2*6+1];
                    associatedInfo2 [counter1+1] = arrayLinkedLineUpdateAss [counter2*6+2];
                    associatedInfo3 [counter1+1] = arrayLinkedLineUpdateAss [counter2*6+3];
                    associatedInfo4 [counter1+1] = arrayLinkedLineUpdateAss [counter2*6+4];
                    break;
                }
            }
            
            for (int counter2 = 0; counter2 < dimension+4; counter2++) delete [] previousMap2 [counter2];
            delete [] previousMap2;
        }
        
        for (int counter1 = 0; counter1 < numberOfEntry+4; counter1++) delete [] entryPosition [counter1];
        delete [] entryPosition;
        
        //for (int counterA = 0; counterA < numberOfEntry; counterA++){
        //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayConnectDataPosition [counterA*3+counterB];
        //	cout<<" arrayConnectDataPosition "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < numberOfEntry; counterA++){
        //	cout<<counterA<<" "<<entryPosition [counterA][0]<<" "<<entryPosition [counterA][1]<<" EntryPoint"<<endl;
        //}
        
        int **overlapFind = new int *[imageWidth+4];
        
        for (int counter1 = 0; counter1 < imageWidth+4; counter1++) overlapFind [counter1] = new int [imageWidth+4];
        
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++) overlapFind [counterY][counterX] = 0;
        }
        
        int **overlapInfo = new int *[numberOfEntry+4];
        int **overlapValue = new int *[numberOfEntry+4];
        
        for (int counter1 = 0; counter1 < numberOfEntry+4; counter1++){
            overlapInfo [counter1] = new int [numberOfEntry+4];
            overlapValue [counter1] = new int [numberOfEntry+4];
        }
        
        for (int counterY = 0; counterY < numberOfEntry+1; counterY++){
            for (int counterX = 0; counterX < numberOfEntry+1; counterX++){
                overlapInfo [counterY][counterX] = 0;
                overlapValue [counterY][counterX] = 0;
            }
        }
        
        //for (int counterA = 0; counterA < numberOfEntry; counterA++){
        //	cout<<counterA<<" "<<arrayConnectDataPosition [counterA*2]<<" "<<arrayConnectDataPosition [counterA*2+1]<<" arrayConnectDataPosition"<<endl;
        //}
        
        for (int counter1 = 0; counter1 < numberOfEntry; counter1++){
            for (int counter2 = 0; counter2 < arrayConnectDataPosition [counter1*2]/2; counter2++){
                if (overlapFind [arrayConnectData [counter1][counter2*2+1]][arrayConnectData [counter1][counter2*2]] != 0){
                    int connectNumber = counter1+1;
                    int overlappedConnect = overlapFind [arrayConnectData [counter1][counter2*2+1]][arrayConnectData [counter1][counter2*2]];
                    overlapInfo [connectNumber][overlappedConnect]++;
                    
                    if (connectNumber >= 0 && connectNumber < imageWidth && overlappedConnect >= 0 && overlappedConnect < imageWidth){
                        overlapValue [connectNumber][overlappedConnect] = overlapValue [connectNumber][overlappedConnect]+arrayExtractedImage [connectNumber][overlappedConnect];
                    }
                }
                else overlapFind [arrayConnectData [counter1][counter2*2+1]][arrayConnectData [counter1][counter2*2]] = counter1+1;
            }
        }
        
        int connect1 = 0;
        int connect2 = 0;
        int horizontalStart1 = 0;
        int verticalStart1 = 0;
        int dimension1 = 0;
        int horizontalStart2 = 0;
        int verticalStart2 = 0;
        int dimension2 = 0;
        int total1 = 0;
        int total2 = 0;
        int totalValue1 = 0;
        int totalValue2 = 0;
        int overlapTotal0 = 0;
        int overlapValue0 = 0;
        int processTypeA1 = 0;
        int processTypeA2 = 0;
        int processTypeC1 = 0;
        int processTypeC2 = 0;
        int totalPrevious = 0;
        int totalCurrent = 0;
        int totalAttach = 0;
        int minusTwoProcess = 0;
        int minusOneRemaining = 0;
        int fusionFlag = 0;
        int processSide = 0;
        int connectivityNumberPrevious = 0;
        int connectivityNumberCurrent = 0;
        int previousLimit = 0;
        int previousCount = 0;
        int previousPix = 0;
        int CurrentLimit = 0;
        int CurrentCount = 0;
        int CurrentPix = 0;
        int previousAttach = 0;
        int CurrentAttach = 0;
        int minusTwoRemain = 0;
        int findFlag = 0;
        int lineNumberExist = 0;
        int remainingCount = 0;
        int connectEntryLimit = 0;
        int connectOverlapEntry1 = 0;
        
        double averageValue1 = 0;
        double averageValue2 = 0;
        double overlapAverage0 = 0;
        
        //------Determine overlap type------
        for (int counter1 = 0; counter1 < numberOfEntry; counter1++){
            for (int counter2 = 0; counter2 < numberOfEntry; counter2++){
                if (overlapInfo [counter1+1][counter2+1] != 0){
                    connect1 = counter1+1;
                    connect2 = counter2+1;
                    horizontalStart1 = horizontalVerticalData [counter1+1][0];
                    verticalStart1 = horizontalVerticalData [counter1+1][1];
                    dimension1 = horizontalVerticalData [counter1+1][2];
                    horizontalStart2 = horizontalVerticalData [counter2+1][0];
                    verticalStart2 = horizontalVerticalData [counter2+1][1];
                    dimension2 = horizontalVerticalData [counter2+1][2];
                    
                    total1 = arrayConnectDataPosition [counter1*2]/2;
                    total2 = arrayConnectDataPosition [counter2*2]/2;
                    
                    totalValue1 = horizontalVerticalData [counter1+1][3];
                    totalValue2 = horizontalVerticalData [counter2+1][3];
                    averageValue1 = totalValue1/(double)total1;
                    averageValue2 = totalValue2/(double)total2;
                    overlapTotal0 = overlapInfo [counter1+1][counter2+1];
                    overlapValue0 = overlapValue [counter1+1][counter2+1];
                    overlapAverage0 = overlapValue0/(double)overlapTotal0;
                    processTypeA1 = associatedInfo1 [connect1]; //------ProcessType: 1: A190, 2: A200 > 0: add later round------
                    processTypeA2 = associatedInfo1 [connect2];
                    processTypeC1 = associatedInfo4 [connect1]; //------Dimension------
                    processTypeC2 = associatedInfo4 [connect2];
                    
                    modificationInfo [connect1] = 1;
                    modificationInfo [connect2] = 1;
                    
                    int **previousMap2 = new int *[dimension1+4];
                    int **previousMap3 = new int *[dimension1+4];
                    int **overlapMap = new int *[dimension1+4];
                    
                    for (int counter3 = 0; counter3 < dimension1+4; counter3++){
                        previousMap2 [counter3] = new int [dimension1+4];
                        previousMap3 [counter3] = new int [dimension1+4];
                        overlapMap [counter3] = new int [dimension1+4];
                    }
                    
                    int **currentMap2 = new int *[dimension2+4];
                    int **currentMap3 = new int *[dimension2+4];
                    
                    for (int counter3 = 0; counter3 < dimension2+4; counter3++){
                        currentMap2 [counter3] = new int [dimension2+4];
                        currentMap3 [counter3] = new int [dimension2+4];
                    }
                    
                    for (int counterY = 0; counterY < dimension1; counterY++){
                        for (int counterX = 0; counterX < dimension1; counterX++){
                            previousMap2 [counterY][counterX] = 0;
                            previousMap3 [counterY][counterX] = 0;
                            overlapMap [counterY][counterX] = 0;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < arrayConnectDataPosition [counter1*2]/2; counter3++){
                        if (arrayConnectData [counter1][counter3*2]-horizontalStart1 >= 0 && arrayConnectData [counter1][counter3*2]-horizontalStart1 < dimension1 && arrayConnectData [counter1][counter3*2+1]-verticalStart1 >= 0 && arrayConnectData [counter1][counter3*2+1]-verticalStart1 < dimension1){
                            previousMap2 [arrayConnectData [counter1][counter3*2+1]-verticalStart1][arrayConnectData [counter1][counter3*2]-horizontalStart1] = connect1;
                        }
                    }
                    
                    totalPrevious = 0;
                    
                    for (int counterY = 0; counterY < dimension1; counterY++){
                        for (int counterX = 0; counterX < dimension1; counterX++){
                            if (previousMap2 [counterY][counterX] != 0) totalPrevious++;
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension2; counterY++){
                        for (int counterX = 0; counterX < dimension2; counterX++){
                            currentMap2 [counterY][counterX] = 0;
                            currentMap3 [counterY][counterX] = 0;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < arrayConnectDataPosition [counter2*2]/2; counter3++){
                        if (arrayConnectData [counter2][counter3*2]-horizontalStart2 >= 0 && arrayConnectData [counter2][counter3*2]-horizontalStart2 < dimension2 && arrayConnectData [counter2][counter3*2+1]-verticalStart2 >= 0 && arrayConnectData [counter2][counter3*2+1]-verticalStart2 < dimension2){
                            currentMap2 [arrayConnectData [counter2][counter3*2+1]-verticalStart2][arrayConnectData [counter2][counter3*2]-horizontalStart2] = connect2;
                        }
                    }
                    
                    totalCurrent = 0;
                    
                    for (int counterY = 0; counterY < dimension2; counterY++){
                        for (int counterX = 0; counterX < dimension2; counterX++){
                            if (currentMap2 [counterY][counterX] != 0) totalCurrent++;
                        }
                    }
                    
                    //------Mark overlapped area, centre: -1, overlap boarder -2, line, each number------
                    totalAttach = 0;
                    
                    for (int counterY = 0; counterY < dimension1; counterY++){
                        for (int counterX = 0; counterX < dimension1; counterX++){
                            if (counterX+horizontalStart1-horizontalStart2 >= 0 && counterX+horizontalStart1-horizontalStart2 < dimension2 && counterY+verticalStart1-verticalStart2 >= 0 && counterY+verticalStart1-verticalStart2 < dimension2){
                                if (previousMap2 [counterY][counterX] != 0 && currentMap2 [counterY+verticalStart1-verticalStart2][counterX+horizontalStart1-horizontalStart2] != 0){
                                    if (previousMap2 [counterY][counterX] < 0 && currentMap2 [counterY+verticalStart1-verticalStart2][counterX+horizontalStart1-horizontalStart2] < 0) overlapMap [counterY][counterX] = -2;
                                    
                                    if (previousMap2 [counterY][counterX] < 0 && currentMap2 [counterY+verticalStart1-verticalStart2][counterX+horizontalStart1-horizontalStart2] > 0) overlapMap [counterY][counterX] = connect2;
                                    
                                    if (previousMap2 [counterY][counterX] > 0 && currentMap2 [counterY+verticalStart1-verticalStart2][counterX+horizontalStart1-horizontalStart2] < 0) overlapMap [counterY][counterX] = connect1;
                                    
                                    if (previousMap2 [counterY][counterX] > 0 && currentMap2 [counterY+verticalStart1-verticalStart2][counterX+horizontalStart1-horizontalStart2] > 0) overlapMap [counterY][counterX] = -1;
                                }
                            }
                            
                            //------number of attached points (not overlap)------
                            if (previousMap2 [counterY][counterX] < 0){
                                for (int counterY2 = counterY-1; counterY2 <= counterY+1; counterY2++){
                                    for (int counterX2 = counterX-1; counterX2 <= counterX+1; counterX2++){
                                        if (counterX2+horizontalStart1-horizontalStart2 >= 0 && counterX2+horizontalStart1-horizontalStart2 < dimension2 && counterY2+verticalStart1-verticalStart2 >= 0 && counterY2+verticalStart1-verticalStart2 < dimension2){
                                            if (currentMap2 [counterY2+verticalStart1-verticalStart2][counterX2+horizontalStart1-horizontalStart2] < 0) totalAttach++;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    //------Remove overlap area from previous and Current Map------
                    for (int counterY = 0; counterY < dimension1; counterY++){
                        for (int counterX = 0; counterX < dimension1; counterX++){
                            if (counterY+verticalStart1-verticalStart2 >= 0 && counterY+verticalStart1-verticalStart2 < dimension2 && counterX+horizontalStart1-horizontalStart2 >= 0 && counterX+horizontalStart1-horizontalStart2 < dimension2){
                                if (overlapMap [counterY][counterX] != 0){
                                    previousMap2 [counterY][counterX] = 0;
                                    currentMap2 [counterY+verticalStart1-verticalStart2][counterX+horizontalStart1-horizontalStart2] = 0;
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < dimension2; counterA++){
                    //	for (int counterB = 0; counterB < dimension2; counterB++) cout<<" "<<currentMap2 [counterA][counterB];
                    //	cout<<" currentMap2 "<<counterA<<endl;
                    //}
                    
                    //------Remove if -2 does not attach to -1------
                    for (int counterY = 0; counterY < dimension1; counterY++){
                        for (int counterX = 0; counterX < dimension1; counterX++){
                            if (overlapMap [counterY][counterX] == -2){
                                minusTwoProcess = 0;
                                
                                for (int counterY2 = counterY-1; counterY2 <= counterY+1; counterY2++){
                                    for (int counterX2 = counterX-1; counterX2 <= counterX+1; counterX2++){
                                        if (counterX2 >= 0 && counterX2 < dimension1 && counterY2 >= 0 && counterY2 < dimension1){
                                            if (overlapMap [counterY2][counterX2] == -1) minusTwoProcess = 1;
                                        }
                                    }
                                }
                                
                                if (minusTwoProcess == 0){
                                    if (processTypeA1 != 0 && processTypeA2 == 0){
                                        previousMap2 [counterY][counterX] = connect1;
                                        overlapMap [counterY][counterX] = 0;
                                    }
                                    else if (processTypeA1 == 0 && processTypeA2 != 0 && counterY+verticalStart1-verticalStart2 >= 0 && counterY+verticalStart1-verticalStart2 < dimension2 && counterX+horizontalStart1-horizontalStart2 >= 0 && counterX+horizontalStart1-horizontalStart2 < dimension2){
                                        currentMap2 [counterY+verticalStart1-verticalStart2][counterX+horizontalStart1-horizontalStart2] = connect2;
                                        overlapMap [counterY][counterX] = 0;
                                    }
                                    else if ((processTypeA1 == 0 && processTypeA2 == 0) || (processTypeA1 != 0 && processTypeA2 != 0)){
                                        if (total2 > total1){
                                            currentMap2 [counterY+verticalStart1-verticalStart2][counterX+horizontalStart1-horizontalStart2] = connect2;
                                            overlapMap [counterY][counterX] = 0;
                                        }
                                        else{
                                            
                                            previousMap2 [counterY][counterX] = connect1;
                                            overlapMap [counterY][counterX] = 0;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < dimension2; counterA++){
                    //	for (int counterB = 0; counterB < dimension2; counterB++) cout<<" "<<currentMap2 [counterA][counterB];
                    //	cout<<" currentMap2 "<<counterA<<endl;
                    //}
                    
                    //------Put Back line number point if it does not attach to -1------
                    for (int counterY = 0; counterY < dimension1; counterY++){
                        for (int counterX = 0; counterX < dimension1; counterX++){
                            if (overlapMap [counterY][counterX] == connect1 || overlapMap [counterY][counterX] == connect2){
                                minusTwoProcess = 0;
                                
                                for (int counterY2 = counterY-1; counterY2 <= counterY+1; counterY2++){
                                    for (int counterX2 = counterX-1; counterX2 <= counterX+1; counterX2++){
                                        if (counterX2 >= 0 && counterX2 < dimension1 && counterY2 >= 0 && counterY2 < dimension1){
                                            if (overlapMap [counterY2][counterX2] == -1) minusTwoProcess = 1;
                                        }
                                    }
                                }
                                
                                if (minusTwoProcess == 0){
                                    if (overlapMap [counterY][counterX] == connect1){
                                        previousMap2 [counterY][counterX] = connect1;
                                        overlapMap [counterY][counterX] = 0;
                                    }
                                    else if (counterY+verticalStart1-verticalStart2 >= 0 && counterY+verticalStart1-verticalStart2 < dimension2 && counterX+horizontalStart1-horizontalStart2 >= 0 && counterX+horizontalStart1-horizontalStart2 < dimension2){
                                        currentMap2 [counterY+verticalStart1-verticalStart2][counterX+horizontalStart1-horizontalStart2] = connect2;
                                        overlapMap [counterY][counterX] = 0;
                                    }
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < dimension2; counterA++){
                    //	for (int counterB = 0; counterB < dimension2; counterB++) cout<<" "<<currentMap2 [counterA][counterB];
                    //	cout<<" currentMap2 "<<counterA<<endl;
                    //}
                    
                    //------Remaining Minus One check------
                    minusOneRemaining = 0;
                    
                    for (int counterY = 0; counterY < dimension1; counterY++){
                        for (int counterX = 0; counterX < dimension1; counterX++){
                            if (overlapMap [counterY][counterX] == -1) minusOneRemaining = 1;
                        }
                    }
                    
                    fusionFlag = 0;
                    processSide = 0;
                    
                    if (minusOneRemaining == 1){
                        
                        //for (int counterA = 0; counterA < dimension1; counterA++){
                        //	for (int counterB = 0; counterB < dimension1; counterB++) cout<<" "<<overlapMap [counterA][counterB];
                        //	cout<<" overlapMap "<<counterA<<endl;
                        //}
                        
                        //------Copy previousMap2 and currentMap2 to previousMap3 and currentMap3------
                        for (int counterY = 0; counterY < dimension1; counterY++){
                            for (int counterX = 0; counterX < dimension1; counterX++){
                                if (previousMap2 [counterY][counterX] != 0) previousMap3 [counterY][counterX] = -1;
                            }
                        }
                        
                        for (int counterY = 0; counterY < dimension2; counterY++){
                            for (int counterX = 0; counterX < dimension2; counterX++){
                                if (currentMap2 [counterY][counterX] != 0) currentMap3 [counterY][counterX] = -1;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < dimension1; counterA++){
                        //	for (int counterB = 0; counterB < dimension1; counterB++) cout<<" "<<previousMap2 [counterA][counterB];
                        //	cout<<" previousMap2 "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < dimension2; counterA++){
                        //	for (int counterB = 0; counterB < dimension2; counterB++) cout<<" "<<currentMap2 [counterA][counterB];
                        //	cout<<" currentMap2 "<<counterA<<endl;
                        //}
                        
                        //------Connectivity analysis, previous------
                        int *connectAnalysisX = new int [dimension1*4];
                        int *connectAnalysisY = new int [dimension1*4];
                        int *connectAnalysisTempX = new int [dimension1*4];
                        int *connectAnalysisTempY = new int [dimension1*4];
                        
                        connectivityNumberPrevious = 0;
                        
                        for (int counterY = 0; counterY < dimension1; counterY++){
                            for (int counterX = 0; counterX < dimension1; counterX++){
                                if (previousMap3 [counterY][counterX] == -1){
                                    connectivityNumberPrevious++;
                                    previousMap3 [counterY][counterX] = connectivityNumberPrevious;
                                    connectAnalysisCount = 0;
                                    
                                    if (counterY-1 >= 0 && counterX-1 >= 0 && previousMap3 [counterY-1][counterX-1] == -1){
                                        previousMap3 [counterY-1][counterX-1] = connectivityNumberPrevious;
                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                    }
                                    if (counterY-1 >= 0 && previousMap3 [counterY-1][counterX] == -1){
                                        previousMap3 [counterY-1][counterX] = connectivityNumberPrevious;
                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                    }
                                    if (counterY-1 >= 0 && counterX+1 < dimension1 && previousMap3 [counterY-1][counterX+1] == -1){
                                        previousMap3 [counterY-1][counterX+1] = connectivityNumberPrevious;
                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                    }
                                    if (counterX+1 < dimension1 && previousMap3 [counterY][counterX+1] == -1){
                                        previousMap3 [counterY][counterX+1] = connectivityNumberPrevious;
                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                    }
                                    if (counterY+1 < dimension1 && counterX+1 < dimension1 && previousMap3 [counterY+1][counterX+1] == -1){
                                        previousMap3 [counterY+1][counterX+1] = connectivityNumberPrevious;
                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                    }
                                    if (counterY+1 < dimension1 && previousMap3 [counterY+1][counterX] == -1){
                                        previousMap3 [counterY+1][counterX] = connectivityNumberPrevious;
                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                    }
                                    if (counterY+1 < dimension1 && counterX-1 >= 0 && previousMap3 [counterY+1][counterX-1] == -1){
                                        previousMap3 [counterY+1][counterX-1] = connectivityNumberPrevious;
                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                    }
                                    if (counterX-1 >= 0 && previousMap3 [counterY][counterX-1] == -1){
                                        previousMap3 [counterY][counterX-1] = connectivityNumberPrevious;
                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                    }
                                    
                                    if (connectAnalysisCount != 0){
                                        do{
                                            
                                            terminationFlag = 1;
                                            connectAnalysisTempCount = 0;
                                            
                                            for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                
                                                if (ySource-1 >= 0 && xSource-1 >= 0 && previousMap3 [ySource-1][xSource-1] == -1){
                                                    previousMap3 [ySource-1][xSource-1] = connectivityNumberPrevious;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (ySource-1 >= 0 && previousMap3 [ySource-1][xSource] == -1){
                                                    previousMap3 [ySource-1][xSource] = connectivityNumberPrevious;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (ySource-1 >= 0 && xSource+1 < dimension1 && previousMap3 [ySource-1][xSource+1] == -1){
                                                    previousMap3 [ySource-1][xSource+1] = connectivityNumberPrevious;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (xSource+1 < dimension1 && previousMap3 [ySource][xSource+1] == -1){
                                                    previousMap3 [ySource][xSource+1] = connectivityNumberPrevious;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 > dimension1 && xSource+1 < dimension1 && previousMap3 [ySource+1][xSource+1] == -1){
                                                    previousMap3 [ySource+1][xSource+1] = connectivityNumberPrevious;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 < dimension1 && previousMap3 [ySource+1][xSource] == -1){
                                                    previousMap3 [ySource+1][xSource] = connectivityNumberPrevious;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 < dimension1 && xSource-1 >= 0 && previousMap3 [ySource+1][xSource-1] == -1){
                                                    previousMap3 [ySource+1][xSource-1] = connectivityNumberPrevious;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (xSource-1 >= 0 && previousMap3 [ySource][xSource-1] == -1){
                                                    previousMap3 [ySource][xSource-1] = connectivityNumberPrevious;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                            }
                                            
                                            for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                            }
                                            
                                            connectAnalysisCount = connectAnalysisTempCount;
                                            
                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                    }
                                }
                            }
                        }
                        
                        delete [] connectAnalysisX;
                        delete [] connectAnalysisY;
                        delete [] connectAnalysisTempX;
                        delete [] connectAnalysisTempY;
                        
                        //for (int counterA = 0; counterA < dimension1; counterA++){
                        //	for (int counterB = 0; counterB < dimension1; counterB++) cout<<" "<<previousMap3 [counterA][counterB];
                        //	cout<<" previousMap3 "<<counterA<<endl;
                        //}
                        
                        //------Connectivity analysis, Current------
                        connectAnalysisX = new int [dimension2*4];
                        connectAnalysisY = new int [dimension2*4];
                        connectAnalysisTempX = new int [dimension2*4];
                        connectAnalysisTempY = new int [dimension2*4];
                        
                        connectivityNumberCurrent = 0;
                        
                        for (int counterY = 0; counterY < dimension2; counterY++){
                            for (int counterX = 0; counterX < dimension2; counterX++){
                                if (currentMap3 [counterY][counterX] == -1){
                                    connectivityNumberCurrent++;
                                    currentMap3 [counterY][counterX] = connectivityNumberCurrent;
                                    connectAnalysisCount = 0;
                                    
                                    if (counterY-1 >= 0 && counterX-1 >= 0 && currentMap3 [counterY-1][counterX-1] == -1){
                                        currentMap3 [counterY-1][counterX-1] = connectivityNumberCurrent;
                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                    }
                                    if (counterY-1 >= 0 && currentMap3 [counterY-1][counterX] == -1){
                                        currentMap3 [counterY-1][counterX] = connectivityNumberCurrent;
                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                    }
                                    if (counterY-1 >= 0 && counterX+1 < dimension2 && currentMap3 [counterY-1][counterX+1] == -1){
                                        currentMap3 [counterY-1][counterX+1] = connectivityNumberCurrent;
                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                    }
                                    if (counterX+1 < dimension2 && currentMap3 [counterY][counterX+1] == -1){
                                        currentMap3 [counterY][counterX+1] = connectivityNumberCurrent;
                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                    }
                                    if (counterY+1 < dimension2 && counterX+1 < dimension2 && currentMap3 [counterY+1][counterX+1] == -1){
                                        currentMap3 [counterY+1][counterX+1] = connectivityNumberCurrent;
                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                    }
                                    if (counterY+1 < dimension2 && currentMap3 [counterY+1][counterX] == -1){
                                        currentMap3 [counterY+1][counterX] = connectivityNumberCurrent;
                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                    }
                                    if (counterY+1 < dimension2 && counterX-1 >= 0 && currentMap3 [counterY+1][counterX-1] == -1){
                                        currentMap3 [counterY+1][counterX-1] = connectivityNumberCurrent;
                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                    }
                                    if (counterX-1 >= 0 && currentMap3 [counterY][counterX-1] == -1){
                                        currentMap3 [counterY][counterX-1] = connectivityNumberCurrent;
                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                    }
                                    
                                    if (connectAnalysisCount != 0){
                                        do{
                                            
                                            terminationFlag = 1;
                                            connectAnalysisTempCount = 0;
                                            
                                            for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                
                                                if (ySource-1 >= 0 && xSource-1 >= 0 && currentMap3 [ySource-1][xSource-1] == -1){
                                                    currentMap3 [ySource-1][xSource-1] = connectivityNumberCurrent;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (ySource-1 >= 0 && currentMap3 [ySource-1][xSource] == -1){
                                                    currentMap3 [ySource-1][xSource] = connectivityNumberCurrent;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (ySource-1 >= 0 && xSource+1 < dimension2 && currentMap3 [ySource-1][xSource+1] == -1){
                                                    currentMap3 [ySource-1][xSource+1] = connectivityNumberCurrent;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (xSource+1 < dimension2 && currentMap3 [ySource][xSource+1] == -1){
                                                    currentMap3 [ySource][xSource+1] = connectivityNumberCurrent;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 > dimension2 && xSource+1 < dimension2 && currentMap3 [ySource+1][xSource+1] == -1){
                                                    currentMap3 [ySource+1][xSource+1] = connectivityNumberCurrent;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 < dimension2 && currentMap3 [ySource+1][xSource] == -1){
                                                    currentMap3 [ySource+1][xSource] = connectivityNumberCurrent;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 < dimension2 && xSource-1 >= 0 && currentMap3 [ySource+1][xSource-1] == -1){
                                                    currentMap3 [ySource+1][xSource-1] = connectivityNumberCurrent;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (xSource-1 >= 0 && currentMap3 [ySource][xSource-1] == -1){
                                                    currentMap3 [ySource][xSource-1] = connectivityNumberCurrent;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                            }
                                            
                                            for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                            }
                                            
                                            connectAnalysisCount = connectAnalysisTempCount;
                                            
                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                    }
                                }
                            }
                        }
                        
                        delete [] connectAnalysisX;
                        delete [] connectAnalysisY;
                        delete [] connectAnalysisTempX;
                        delete [] connectAnalysisTempY;
                        
                        //for (int counterA = 0; counterA < dimension2; counterA++){
                        //	for (int counterB = 0; counterB < dimension2; counterB++) cout<<" "<<currentMap3 [counterA][counterB];
                        //	cout<<" currentMap3 "<<counterA<<endl;
                        //}
                        
                        //------Determine number of pix of each connectivity group, previous, previousLimit = 1: max connect is less than 50------
                        previousLimit = 1;
                        previousCount = 0;
                        previousPix = 0;
                        
                        if (connectivityNumberPrevious > 0){
                            int *connectedPix = new int [connectivityNumberPrevious+4];
                            
                            for (int counter3 = 0; counter3 <= connectivityNumberPrevious; counter3++) connectedPix [counter3] = 0;
                            
                            for (int counterY= 0; counterY < dimension1; counterY++){
                                for (int counterX = 0; counterX < dimension1; counterX++){
                                    if (previousMap3 [counterY][counterX] != 0) connectedPix [previousMap3 [counterY][counterX]]++;
                                }
                            }
                            
                            for (int counter3 = 1; counter3 <= connectivityNumberPrevious; counter3++){
                                if (previousPix < connectedPix [counter3]){
                                    previousPix = connectedPix [counter3];
                                    previousCount = counter3;
                                }
                            }
                            
                            if (previousPix > 50){
                                previousLimit = 0;
                                
                                for (int counterY = 0; counterY < dimension1; counterY++){
                                    for (int counterX = 0; counterX < dimension1; counterX++){
                                        if (previousMap3 [counterY][counterX] != previousCount) previousMap2 [counterY][counterX] = 0;
                                    }
                                }
                            }
                            else previousLimit = 1;
                            
                            delete [] connectedPix;
                        }
                        
                        //------Determine number of pix of each connectivity group, Current, CurrentLimit = 1: max connect is less than 50------
                        CurrentLimit = 1;
                        CurrentCount = 0;
                        CurrentPix = 0;
                        
                        if (connectivityNumberCurrent > 0){
                            int *connectedPix = new int [connectivityNumberCurrent+4];
                            
                            for (int counter3 = 0; counter3 <= connectivityNumberCurrent; counter3++) connectedPix [counter3] = 0;
                            
                            for (int counterY = 0; counterY < dimension2; counterY++){
                                for (int counterX = 0; counterX < dimension2; counterX++){
                                    if (currentMap3 [counterY][counterX] != 0) connectedPix [currentMap3 [counterY][counterX]]++;
                                }
                            }
                            
                            for (int counter3 = 1; counter3 <= connectivityNumberCurrent; counter3++){
                                if (CurrentPix < connectedPix [counter3]){
                                    CurrentPix = connectedPix [counter3];
                                    CurrentCount = counter3;
                                }
                            }
                            
                            if (CurrentPix > 50){
                                CurrentLimit = 0;
                                
                                for (int counterY = 0; counterY < dimension2; counterY++){
                                    for (int counterX = 0; counterX < dimension2; counterX++){
                                        if (currentMap3 [counterY][counterX] != CurrentCount) currentMap2 [counterY][counterX] = 0;
                                    }
                                }
                            }
                            else CurrentLimit = 1;
                            
                            delete [] connectedPix;
                        }
                        
                        //cout<<previousLimit<<" "<<CurrentLimit<<" "<<connectivityNumberPrevious<<" "<<connectivityNumberCurrent<<" ConnectNo"<<endl;
                        //cout<<processTypeA1<<" "<<processTypeA2<<" Type"<<endl; //1--prev, 2--Current
                        
                        //------Max connect < 50 or connectivityNumberPrevious >= 3 process------
                        lineNumberExist = 0;
                        
                        if ((previousLimit == 1 && CurrentLimit == 0) || (previousLimit == 0 && CurrentLimit == 1) || (previousLimit == 1 && CurrentLimit == 1) || connectivityNumberPrevious >= 3 || connectivityNumberCurrent >= 3){
                            if (previousLimit == 1 && CurrentLimit == 0){
                                modificationInfo [connect2] = 0;
                                processSide = 1;
                                
                                if (previousPix < 50) modificationInfo [connect1] = -1;
                            }
                            else if (previousLimit == 0 && CurrentLimit == 1){
                                modificationInfo [connect1] = 0;
                                processSide = 2;
                                
                                if (CurrentPix < 50) modificationInfo [connect2] = -1;
                            }
                            else if ((previousLimit == 1 && CurrentLimit == 1) || connectivityNumberPrevious >= 3 || connectivityNumberCurrent >= 3){
                                if (processTypeA1 != 0 && processTypeA2 == 0){
                                    modificationInfo [connect1] = 0;
                                    processSide = 2;
                                    
                                    if (CurrentPix < 50) modificationInfo [connect2] = -1;
                                }
                                else if (processTypeA1 == 0 && processTypeA2 != 0){
                                    modificationInfo [connect2] = 0;
                                    processSide = 1;
                                    
                                    if (previousPix < 50) modificationInfo [connect1] = -1;
                                }
                                else if ((processTypeA1 == 0 && processTypeA2 == 0) || (processTypeA1 != 0 && processTypeA2 != 0)){
                                    if (processTypeA1 != 0 && processTypeA2 != 0 && (overlapTotal0/(double)total2 > 0.4 || overlapTotal0/(double)total1 > 0.4) && typeSubArray == 1) fusionFlag = 1;
                                    else if (CurrentPix > previousPix){
                                        modificationInfo [connect2] = 0;
                                        processSide = 1;
                                        
                                        if (previousPix < 50) modificationInfo [connect1] = -1;
                                    }
                                    else{
                                        
                                        modificationInfo [connect1] = 0;
                                        processSide = 2;
                                        
                                        if (CurrentPix < 50) modificationInfo [connect2] = -1;
                                    }
                                }
                            }
                        }
                        else{
                            
                            if (connectivityNumberPrevious == 2 || connectivityNumberCurrent == 2){
                                //------connectivityNumberPrevious == 2 process, line number rewrite, if it is not attached its corresponding number, put -2------
                                lineNumberExist = 0;
                                
                                for (int counterY = 0; counterY < dimension1; counterY++){
                                    for (int counterX = 0; counterX < dimension1; counterX++){
                                        if (overlapMap [counterY][counterX] > 0){
                                            lineNumberExist++;
                                            previousAttach = 0;
                                            CurrentAttach = 0;
                                            
                                            for (int counterY2 = counterY-1; counterY2 <= counterY+1; counterY2++){
                                                for (int counterX2 = counterX-1; counterX2 <= counterX+1; counterX2++){
                                                    if (counterX2 >= 0 && counterX2 < dimension1 && counterY2 >= 0 && counterY2 < dimension1){
                                                        if (overlapMap [counterY][counterX] == connect1 && previousMap2 [counterY2][counterX2] == connect1) previousAttach++;
                                                        
                                                        if (counterY+verticalStart1-verticalStart2 >= 0 && counterY+verticalStart1-verticalStart2 < dimension2 && counterX+horizontalStart1-horizontalStart2 >= 0 && counterX+horizontalStart1-horizontalStart2 < dimension2 && overlapMap [counterY][counterX] == connect2 && currentMap2 [counterY+verticalStart1-verticalStart2][counterX+horizontalStart1-horizontalStart2] == connect2){
                                                            CurrentAttach++;
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            if ((overlapMap [counterY][counterX] == connect1 && previousAttach == 0) || (overlapMap [counterY][counterX] == connect2 && CurrentAttach != 0)){
                                                overlapMap [counterY][counterX] = -2;
                                            }
                                        }
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < dimension1; counterA++){
                            //	for (int counterB = 0; counterB < dimension1; counterB++) cout<<" "<<previousMap2 [counterA][counterB];
                            //	cout<<" previousMap2 "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < dimension2; counterA++){
                            //	for (int counterB = 0; counterB < dimension2; counterB++) cout<<" "<<currentMap2 [counterA][counterB];
                            //	cout<<" currentMap2 "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < dimension1; counterA++){
                            //	for (int counterB = 0; counterB < dimension1; counterB++) cout<<" "<<overlapMap [counterA][counterB];
                            //	cout<<" overlapMap "<<counterA<<endl;
                            //}
                            
                            //------Replace -2 or relevant kine number------
                            minusTwoRemain = 0;
                            
                            do{
                                
                                terminationFlag = 1;
                                findFlag = 0;
                                
                                for (int counterY = 0; counterY < dimension1; counterY++){
                                    for (int counterX = 0; counterX < dimension1; counterX++){
                                        if (overlapMap [counterY][counterX] == -2){
                                            minusTwoRemain = 1;
                                            previousAttach = 0;
                                            CurrentAttach = 0;
                                            
                                            for (int counterY2 = counterY-1; counterY2 <= counterY+1; counterY2++){
                                                for (int counterX2 = counterX-1; counterX2 <= counterX+1; counterX2++){
                                                    if (counterX2 >= 0 && counterX2 < dimension1 && counterY2 >= 0 && counterY2 < dimension1){
                                                        if (overlapMap [counterY2][counterX2] == connect1) previousAttach++;
                                                        
                                                        if (overlapMap [counterY2][counterX2] == connect2) CurrentAttach++;
                                                    }
                                                }
                                            }
                                            
                                            if (previousAttach != 0 && CurrentAttach != 0){
                                                findFlag = 1;
                                                
                                                if (total2 > total1) overlapMap [counterY][counterX] = connect2;
                                                else overlapMap [counterY][counterX] = connect1;
                                            }
                                            
                                            if (previousAttach != 0 && CurrentAttach == 0){
                                                findFlag = 1;
                                                overlapMap [counterY][counterX] = connect1;
                                            }
                                            
                                            if (previousAttach == 0 && CurrentAttach != 0){
                                                findFlag = 1;
                                                overlapMap [counterY][counterX] = connect2;
                                            }
                                        }
                                    }
                                }
                                
                                if (findFlag == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                            
                            //------Process for un-replaced -2 remain with line number------
                            if (lineNumberExist == 1 && minusTwoRemain == 1){
                                if (processTypeA1 != 0 && processTypeA2 == 0){
                                    modificationInfo [connect1] = 0;
                                    processSide = 2;
                                    
                                    if (totalCurrent < 50) modificationInfo [connect2] = -1;
                                }
                                else if (processTypeA1 == 0 && processTypeA2 != 0){
                                    modificationInfo [connect2] = 0;
                                    processSide = 1;
                                    
                                    if (totalPrevious < 50) modificationInfo [connect1] = -1;
                                }
                                else if ((processTypeA1 == 0 && processTypeA2 == 0) || (processTypeA1 != 0 && processTypeA2 != 0)){
                                    if (processTypeA1 != 0 && processTypeA2 != 0 && (overlapTotal0/(double)total2 > 0.4 || overlapTotal0/(double)total1 > 0.4) && typeSubArray == 1) fusionFlag = 1;
                                    else if (totalCurrent > totalPrevious){
                                        modificationInfo [connect2] = 0;
                                        processSide = 1;
                                        
                                        if (totalPrevious < 50) modificationInfo [connect1] = -1;
                                    }
                                    else{
                                        
                                        modificationInfo [connect1] = 0;
                                        processSide = 2;
                                        
                                        if (totalCurrent < 50) modificationInfo [connect2] = -1;
                                    }
                                }
                            }
                            else{
                                
                                if (lineNumberExist == 0 && minusTwoRemain == 1){
                                    for (int counterY = 0; counterY < dimension1; counterY++){
                                        for (int counterX = 0; counterX < dimension1; counterX++){
                                            if (overlapMap [counterY][counterX] == -2) overlapMap [counterY][counterX] = connect1;
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < dimension1; counterA++){
                                //	for (int counterB = 0; counterB < dimension1; counterB++) cout<<" "<<previousMap2 [counterA][counterB];
                                //	cout<<" previousMap2 "<<counterA<<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < dimension2; counterA++){
                                //	for (int counterB = 0; counterB < dimension2; counterB++) cout<<" "<<currentMap2 [counterA][counterB];
                                //	cout<<" currentMap2 "<<counterA<<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < dimension1; counterA++){
                                //	for (int counterB = 0; counterB < dimension1; counterB++) cout<<" "<<overlapMap [counterA][counterB];
                                //	cout<<" overlapMap "<<counterA<<endl;
                                //}
                                
                                //int test[dimension1][ dimension1];
                                
                                //for (int counterY = 0; counterY < dimension1; counterY++){
                                //	for (int counterX = 0; counterX < dimension1; counterX++){
                                //		if (previousMap2 [counterY][counterX] != 0 && currentMap2 [counterY+verticalStart1-verticalStart2][counterX+horizontalStart1-horizontalStart2] != 0){
                                //			test[counterY][counterX] = 9;
                                //		}
                                //		if (previousMap2 [counterY][counterX] == 0 && currentMap2 [counterY+verticalStart1-verticalStart2][counterX+horizontalStart1-horizontalStart2] != 0){
                                //			test[counterY][counterX] = 1;
                                //		}
                                //		if (previousMap2 [counterY][counterX] != 0 && currentMap2 [counterY+verticalStart1-verticalStart2][counterX+horizontalStart1-horizontalStart2] == 0){
                                //			test[counterY][counterX] = 2;
                                //		}
                                //		if (previousMap2 [counterY][counterX] == 0 && currentMap2 [counterY+verticalStart1-verticalStart2][counterX+horizontalStart1-horizontalStart2] == 0){
                                //			test[counterY][counterX] = 0;
                                //		}
                                //	}
                                //}
                                
                                //for (int counterA = 0; counterA < dimension1; counterA++){
                                //	for (int counterB = 0; counterB < dimension1; counterB++) cout<<" "<<test [counterA][counterB];
                                //	cout<<" test "<<counterA<<endl;
                                //}
                                
                                //cout<<processTypeA1<<" "<<processTypeA2<<" "<<processTypeC1<<" "<<processTypeC2<<" processType"<<endl;
                                
                                //------Determine process type------
                                if (processTypeA1 != 0 && processTypeA2 != 0){
                                    if ((overlapTotal0/(double)total2 > 0.4 || overlapTotal0/(double)total1 > 0.4) && typeSubArray == 1) fusionFlag = 1;
                                    else if (processTypeC1 > 4 && processTypeC2 > 4) processSide = 3;
                                    else if (processTypeC1 <= 4 && processTypeC2 > 4){
                                        processSide = 2;
                                        modificationInfo [connect1] = 0;
                                    }
                                    else if (processTypeC1 > 4 && processTypeC2 <= 4){
                                        processSide = 1;
                                        modificationInfo [connect2] = 0;
                                    }
                                    else if (processTypeC1 <= 4 && processTypeC2 <= 4){
                                        if (overlapTotal0 <= 50){
                                            if (averageValue2 > overlapAverage0 && averageValue1 > overlapAverage0 && averageValue2 > averageValue1+50){
                                                processSide = 2;
                                                modificationInfo [connect1] = 0;
                                            }
                                            else if (averageValue2 > overlapAverage0 && averageValue1 > overlapAverage0 && averageValue1 > averageValue2+50){
                                                processSide = 1;
                                                modificationInfo [connect2] = 0;
                                            }
                                            else processSide = 3;
                                        }
                                        else processSide = 3;
                                    }
                                }
                                else if ((processTypeA1 != 0 && processTypeA2 == 0) || (processTypeA1 == 0 && processTypeA2 != 0)){
                                    if (processTypeA1 != 0 && processTypeA2 == 0){
                                        processSide = 2;
                                        modificationInfo [connect1] = 0;
                                        
                                        if (totalCurrent < 50) modificationInfo [connect2] = -1;
                                    }
                                    if (processTypeA1 == 0 && processTypeA2 != 0){
                                        processSide = 1;
                                        modificationInfo [connect2] = 0;
                                        
                                        if (totalPrevious < 50) modificationInfo [connect1] = -1;
                                    }
                                }
                                else if (totalAttach > totalPrevious*0.3 && totalAttach > totalCurrent*0.3 && (averageValue1-averageValue2 > -20 && averageValue1-averageValue2 < 20) && averageValue1 < 190 && averageValue2 < 190 && totalAttach > 20 && abs(total1-total2) < 30 && processTypeA1 == 0 && processTypeA2 == 0) fusionFlag = 1;
                                else if (overlapTotal0/(double)total2 > 0.4 || overlapTotal0/(double)total1 > 0.4) fusionFlag = 1;
                                else if (averageValue1 < 190 && total1 < 50) fusionFlag = 1;
                                else if (averageValue2 < 190 && total2 < 50) fusionFlag = 1;
                                else if (averageValue2 > overlapAverage0 && averageValue1 > overlapAverage0 && averageValue2 > averageValue1+50){
                                    modificationInfo [connect1] = 0;
                                    processSide = 2;
                                }
                                else if (averageValue2 > overlapAverage0 && averageValue1 > overlapAverage0 && averageValue1 > averageValue2+50){
                                    modificationInfo [connect2] = 0;
                                    processSide = 1;
                                }
                                else processSide = 3;
                            }
                        }
                    }
                    
                    //------Previous Set------
                    if (processSide == 1){
                        for (int counterY = 0; counterY < dimension1; counterY++){
                            for (int counterX = 0; counterX < dimension1; counterX++){
                                if (counterY+verticalStart1-verticalStart2 >= 0 && counterY+verticalStart1-verticalStart2 < dimension2 && counterX+horizontalStart1-horizontalStart2 >= 0 && counterX+horizontalStart1-horizontalStart2 < dimension2 && overlapMap [counterY][counterX] == connect2){
                                    if (overlapMap [counterY][counterX] != 0) currentMap2 [counterY+verticalStart1-verticalStart2][counterX+horizontalStart1-horizontalStart2] = connect2;
                                }
                            }
                        }
                        
                        remainingCount = 0;
                        
                        for (int counterY = 0; counterY < dimension1; counterY++){
                            for (int counterX = 0; counterX < dimension1; counterX++){
                                if (previousMap2 [counterY][counterX] != 0) remainingCount++;
                            }
                        }
                        
                        if (remainingCount < 50 && fusionFlag == 0){
                            for (int counterY = 0; counterY < numberOfEntry+1; counterY++){
                                if (overlapInfo [counterY][connect1] != 0) overlapInfo [counterY][connect1] = 0;
                            }
                            
                            for (int counterX = 0; counterX < numberOfEntry+1; counterX++){
                                if (overlapInfo [connect1][counterX] != 0) overlapInfo [connect1][counterX] = 0;
                            }
                            
                            modificationInfo [connect1] = -1;
                            processSide = 0;
                        }
                        
                        //for (int counterA = 0; counterA < dimension1; counterA++){
                        //	for (int counterB = 0; counterB < dimension1; counterB++) cout<<" "<<previousMap2 [counterA][counterB];
                        //	cout<<" previousMap2 "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < dimension2; counterA++){
                        //	for (int counterB = 0; counterB < dimension2; counterB++) cout<<" "<<currentMap2 [counterA][counterB];
                        //	cout<<" currentMap2 "<<counterA<<endl;
                        //}
                    }
                    
                    //------Current Set------
                    if (processSide == 2){
                        for (int counterY = 0; counterY < dimension1; counterY++){
                            for (int counterX = 0; counterX < dimension1; counterX++){
                                if (overlapMap [counterY][counterX] != 0) previousMap2 [counterY][counterX] = connect1;
                            }
                        }
                        
                        remainingCount = 0;
                        
                        for (int counterY = 0; counterY < dimension2; counterY++){
                            for (int counterX = 0; counterX < dimension2; counterX++){
                                if (currentMap2 [counterY][counterX] != 0) remainingCount++;
                            }
                        }
                        
                        if (remainingCount < 50 && fusionFlag == 0){
                            for (int counterY = 0; counterY < numberOfEntry+1; counterY++){
                                if (overlapInfo [counterY][connect2] != 0) overlapInfo [counterY][connect2] = 0;
                            }
                            
                            for (int counterX = 0; counterX < numberOfEntry+1; counterX++){
                                if (overlapInfo [connect2][counterX] != 0) overlapInfo [connect2][counterX] = 0;
                            }
                            
                            modificationInfo [connect2] = -1;
                            processSide = 0;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < dimension1; counterA++){
                    //	for (int counterB = 0; counterB < dimension1; counterB++) cout<<" "<<previousMap2 [counterA][counterB];
                    //	cout<<" previousMap2 "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < dimension2; counterA++){
                    //	for (int counterB = 0; counterB < dimension2; counterB++) cout<<" "<<currentMap2 [counterA][counterB];
                    //	cout<<" currentMap2 "<<counterA<<endl;
                    //}
                    
                    if (fusionFlag == 0){
                        overlapInfo [connect1][connect2] = 0;
                        
                        //------Border trace------
                        if (minusOneRemaining != 0 || processSide == 3){
                            int *arrayAreaDivisionLine = new int [dimension1*dimension1+4], areaDivisionLineCount = 0;
                            int *arrayAreaDivisionInside = new int [dimension1*dimension1+4], areaDivisionInsideCount = 0;
                            
                            for (int counterY = 0; counterY < dimension1; counterY++){
                                for (int counterX = 0; counterX < dimension1; counterX++){
                                    if (overlapMap [counterY][counterX] != 0){
                                        if (overlapMap [counterY][counterX] != -1){
                                            arrayAreaDivisionLine [areaDivisionLineCount] = counterX, areaDivisionLineCount++;
                                            arrayAreaDivisionLine [areaDivisionLineCount] = counterY, areaDivisionLineCount++;
                                            
                                            if (overlapMap [counterY][counterX] == connect1) arrayAreaDivisionLine [areaDivisionLineCount] = connect1, areaDivisionLineCount++;
                                            else if (overlapMap [counterY][counterX] == connect2) arrayAreaDivisionLine [areaDivisionLineCount] = connect2, areaDivisionLineCount++;
                                        }
                                    }
                                }
                            }
                            
                            do{
                                
                                terminationFlag = 1;
                                findFlag = 0;
                                
                                for (int counter3 = 0; counter3 < areaDivisionLineCount/3; counter3++){
                                    for (int counterY2 = arrayAreaDivisionLine [counter3*3+1]-1; counterY2 <= arrayAreaDivisionLine [counter3*3+1]+1; counterY2++){
                                        for (int counterX2 = arrayAreaDivisionLine [counter3*3]-1; counterX2 <= arrayAreaDivisionLine [counter3*3]+1; counterX2++){
                                            if (overlapMap [counterY2][counterX2] == -1){
                                                overlapMap [counterY2][counterX2] = arrayAreaDivisionLine [counter3*3+2];
                                                arrayAreaDivisionInside [areaDivisionInsideCount] = arrayAreaDivisionLine [counter3*3], areaDivisionInsideCount++;
                                                arrayAreaDivisionInside [areaDivisionInsideCount] = arrayAreaDivisionLine [counter3*3+1], areaDivisionInsideCount++;
                                                arrayAreaDivisionInside [areaDivisionInsideCount] = arrayAreaDivisionLine [counter3*3+2], areaDivisionInsideCount++;
                                                findFlag = 1;
                                            }
                                        }
                                    }
                                }
                                
                                if (findFlag == 1){
                                    areaDivisionLineCount = 0;
                                    
                                    if (areaDivisionInsideCount != 0){
                                        for (int counter3 = 0; counter3 < areaDivisionInsideCount/3; counter3++){
                                            arrayAreaDivisionLine [areaDivisionLineCount] = arrayAreaDivisionInside [counter3*3], areaDivisionLineCount++;
                                            arrayAreaDivisionLine [areaDivisionLineCount] = arrayAreaDivisionInside [counter3*3+1], areaDivisionLineCount++;
                                            arrayAreaDivisionLine [areaDivisionLineCount] = arrayAreaDivisionInside [counter3*3+2], areaDivisionLineCount++;
                                        }
                                    }
                                    
                                    areaDivisionLineCount = 0;
                                }
                                else terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                            
                            delete [] arrayAreaDivisionLine;
                            delete [] arrayAreaDivisionInside;
                            
                            for (int counterY = 0; counterY < dimension1; counterY++){
                                for (int counterX = 0; counterX < dimension1; counterX++){
                                    if (overlapMap [counterY][counterX] != 0 && overlapMap [counterY][counterX] != -1){
                                        if (overlapMap [counterY][counterX] == connect1) previousMap2 [counterY][counterX] = connect1;
                                        
                                        if (overlapMap [counterY][counterX] == connect2 && counterY+verticalStart1-verticalStart2 >= 0 && counterY+verticalStart1-verticalStart2 < dimension2 && counterX+horizontalStart1-horizontalStart2 >= 0 && counterX+horizontalStart1-horizontalStart2 < dimension2) currentMap2 [counterY+verticalStart1-verticalStart2][counterX+horizontalStart1-horizontalStart2] = connect2;
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < dimension2; counterA++){
                            //	for (int counterB = 0; counterB < dimension2; counterB++) cout<<" "<<currentMap2 [counterA][counterB];
                            //	cout<<" currentMap2 "<<counterA<<endl;
                            //}
                        }
                        
                        //------Array update------
                        if (processSide == 1 || processSide == 3 || minusOneRemaining == 0){
                            connectEntryLimit = arrayConnectDataPosition [counter1*2+1];
                            connectOverlapEntry1 = 0;
                            
                            for (int counterY = 0; counterY < dimension1; counterY++){
                                for (int counterX = 0; counterX < dimension1; counterX++){
                                    if (previousMap2 [counterY][counterX] != 0){
                                        if (connectOverlapEntry1+2 > connectEntryLimit){
                                            int *arraySourceTemp = new int [connectOverlapEntry1+50];
                                            for (int counter3 = 0; counter3 < connectOverlapEntry1; counter3++) arraySourceTemp [counter3] = arrayConnectData [counter1][counter3];
                                            
                                            delete [] arrayConnectData [counter1];
                                            arrayConnectData [counter1] = new int [connectEntryLimit+5000];
                                            connectEntryLimit = connectEntryLimit+5000;
                                            
                                            for (int counter3 = 0; counter3 < connectOverlapEntry1; counter3++) arrayConnectData [counter1][counter3] = arraySourceTemp [counter3];
                                            delete [] arraySourceTemp;
                                        }
                                        
                                        arrayConnectData [counter1][connectOverlapEntry1] = counterX+horizontalStart1, connectOverlapEntry1++;
                                        arrayConnectData [counter1][connectOverlapEntry1] = counterY+verticalStart1, connectOverlapEntry1++;
                                    }
                                }
                            }
                            
                            arrayConnectDataPosition [counter1*2] = connectOverlapEntry1;
                            arrayConnectDataPosition [counter1*2+1] = connectEntryLimit;
                        }
                        
                        if (processSide == 2 || processSide == 3 || minusOneRemaining == 0){
                            connectEntryLimit = arrayConnectDataPosition [counter2*2+1];
                            connectOverlapEntry1 = 0;
                            
                            for (int counterY = 0; counterY < dimension2; counterY++){
                                for (int counterX = 0; counterX < dimension2; counterX++){
                                    if (currentMap2 [counterY][counterX] != 0){
                                        if (connectOverlapEntry1+2 > connectEntryLimit){
                                            int *arraySourceTemp = new int [connectOverlapEntry1+50];
                                            for (int counter3 = 0; counter3 < connectOverlapEntry1; counter3++) arraySourceTemp [counter3] = arrayConnectData [counter2][counter3];
                                            
                                            delete [] arrayConnectData [counter2];
                                            arrayConnectData [counter2] = new int [connectEntryLimit+5000];
                                            connectEntryLimit = connectEntryLimit+5000;
                                            
                                            for (int counter3 = 0; counter3 < connectOverlapEntry1; counter3++) arrayConnectData [counter2][counter3] = arraySourceTemp [counter3];
                                            delete [] arraySourceTemp;
                                        }
                                        
                                        arrayConnectData [counter2][connectOverlapEntry1] = counterX+horizontalStart2, connectOverlapEntry1++;
                                        arrayConnectData [counter2][connectOverlapEntry1] = counterY+verticalStart2, connectOverlapEntry1++;
                                    }
                                }
                            }
                            
                            arrayConnectDataPosition [counter2*2] = connectOverlapEntry1;
                            arrayConnectDataPosition [counter2*2+1] = connectEntryLimit;
                            
                            //for (int counterA = 0; counterA < numberOfEntry; counterA++){
                            //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayConnectDataPosition [counterA*3+counterB];
                            //	cout<<" arrayConnectDataPosition "<<counterA<<endl;
                            //}
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < dimension1+4; counter3++){
                        delete [] previousMap2 [counter3];
                        delete [] previousMap3 [counter3];
                        delete [] overlapMap [counter3];
                    }
                    
                    delete [] previousMap2;
                    delete [] previousMap3;
                    delete [] overlapMap;
                    
                    for (int counter3 = 0; counter3 < dimension2+4; counter3++){
                        delete [] currentMap2 [counter3];
                        delete [] currentMap3 [counter3];
                    }
                    
                    delete [] currentMap2;
                    delete [] currentMap3;
                }
            }
        }
        
        int connectEntryCount = 0;
        int connectEntryCount2 = 0;
        
        //------Fusion case process------
        for (int counter1 = 0; counter1 < numberOfEntry; counter1++){
            for (int counter2 = 0; counter2 < numberOfEntry; counter2++){
                if (overlapInfo [counter1+1][counter2+1] != 0){
                    connect1 = counter1+1;
                    connect2 = counter2+1;
                    maxPointDimX = 0;
                    maxPointDimY = 0;
                    minPointDimX = 100000;
                    minPointDimY = 100000;
                    connectEntryCount = arrayConnectDataPosition [counter1*2];
                    
                    for (int counter3 = 0; counter3 < connectEntryCount/2; counter3++){
                        if (maxPointDimX < arrayConnectData [counter1][counter3*2]) maxPointDimX = arrayConnectData [counter1][counter3*2];
                        if (minPointDimX > arrayConnectData [counter1][counter3*2]) minPointDimX = arrayConnectData [counter1][counter3*2];
                        if (maxPointDimY < arrayConnectData [counter1][counter3*2+1]) maxPointDimY = arrayConnectData [counter1][counter3*2+1];
                        if (minPointDimY > arrayConnectData [counter1][counter3*2+1]) minPointDimY = arrayConnectData [counter1][counter3*2+1];
                    }
                    
                    connectEntryCount2 = arrayConnectDataPosition [counter2*2];
                    
                    for (int counter3 = 0; counter3 < connectEntryCount2/2; counter3++){
                        if (maxPointDimX < arrayConnectData [counter2][counter3*2]) maxPointDimX = arrayConnectData [counter2][counter3*2];
                        if (minPointDimX > arrayConnectData [counter2][counter3*2]) minPointDimX = arrayConnectData [counter2][counter3*2];
                        if (maxPointDimY < arrayConnectData [counter2][counter3*2+1]) maxPointDimY = arrayConnectData [counter2][counter3*2+1];
                        if (minPointDimY > arrayConnectData [counter2][counter3*2+1]) minPointDimY = arrayConnectData [counter2][counter3*2+1];
                    }
                    
                    horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                    verticalLength = (maxPointDimY-minPointDimY)/2*2;
                    dimension = 0;
                    
                    if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
                    if (horizontalLength < verticalLength) dimension = verticalLength+30;
                    
                    dimension = (dimension/2)*2;
                    
                    horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
                    verticalStart = minPointDimY-(dimension-verticalLength)/2;
                    
                    horizontalVerticalData [connect1][0] = horizontalStart;
                    horizontalVerticalData [connect1][1] = verticalStart;
                    horizontalVerticalData [connect1][2] = dimension;
                    
                    int **overlapFind2 = new int *[dimension+4];
                    int **overlapFind3 = new int *[dimension+4];
                    
                    for (int counter3 = 0; counter3 < dimension+4; counter3++){
                        overlapFind2 [counter3] = new int [dimension+4];
                        overlapFind3 [counter3] = new int [dimension+4];
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            overlapFind2 [counterY][counterX] = 0;
                            overlapFind3 [counterY][counterX] = 0;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < connectEntryCount/2; counter3++){
                        if (arrayConnectData [counter1][counter3*2]-horizontalStart >= 0 && arrayConnectData [counter1][counter3*2]-horizontalStart < dimension && arrayConnectData [counter1][counter3*2+1]-verticalStart >= 0 && arrayConnectData [counter1][counter3*2+1]-verticalStart < dimension){
                            overlapFind2 [arrayConnectData [counter1][counter3*2+1]-verticalStart][arrayConnectData [counter1][counter3*2]-horizontalStart] = 1;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < connectEntryCount2/2; counter3++){
                        if (arrayConnectData [counter2][counter3*2]-horizontalStart >= 0 && arrayConnectData [counter2][counter3*2]-horizontalStart < dimension && arrayConnectData [counter2][counter3*2+1]-verticalStart >= 0 && arrayConnectData [counter2][counter3*2+1]-verticalStart < dimension){
                            overlapFind2 [arrayConnectData [counter2][counter3*2+1]-verticalStart][arrayConnectData [counter2][counter3*2]-horizontalStart] = 1;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<overlapFind2 [counterA][counterB];
                    //	cout<<" overlapFind2 "<<counterA<<endl;
                    //}
                    
                    connectEntryLimit = arrayConnectDataPosition [counter1*2+1];
                    connectOverlapEntry1 = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (overlapFind2 [counterY][counterX] != 0){
                                if (connectOverlapEntry1+2 > connectEntryLimit){
                                    int *arraySourceTemp = new int [connectOverlapEntry1+50];
                                    for (int counter3 = 0; counter3 < connectOverlapEntry1; counter3++) arraySourceTemp [counter3] = arrayConnectData [counter1][counter3];
                                    
                                    delete [] arrayConnectData [counter1];
                                    arrayConnectData [counter1] = new int [connectEntryLimit+5000];
                                    connectEntryLimit = connectEntryLimit+5000;
                                    
                                    for (int counter3 = 0; counter3 < connectOverlapEntry1; counter3++) arrayConnectData [counter1][counter3] = arraySourceTemp [counter3];
                                    delete [] arraySourceTemp;
                                }
                                
                                arrayConnectData [counter1][connectOverlapEntry1] = counterX+horizontalStart, connectOverlapEntry1++;
                                arrayConnectData [counter1][connectOverlapEntry1] = counterY+verticalStart, connectOverlapEntry1++;
                            }
                        }
                    }
                    
                    arrayConnectDataPosition [counter1*2] = connectOverlapEntry1;
                    arrayConnectDataPosition [counter1*2+1] = connectEntryLimit;
                    arrayConnectDataPosition [counter2*2] = 0;
                    
                    overlapInfo [counter1+1][counter2+1] = 0;
                    
                    for (int counter3 = 0; counter3 < numberOfEntry; counter3++){
                        if (overlapInfo [counter3+1][connect2-1] != 0){
                            overlapInfo [counter3+1][connect1-1] = overlapInfo [counter3+1][connect2-1];
                            overlapInfo [counter3+1][connect2-1] = 0;
                        }
                    }
                    
                    fusionInfo [connect1] = 1;
                    modificationInfo [connect2] = -1;
                    
                    for (int counter3 = 0; counter3 < dimension+4; counter3++){
                        delete [] overlapFind2 [counter3];
                        delete [] overlapFind3 [counter3];
                    }
                    
                    delete [] overlapFind2;
                    delete [] overlapFind3;
                }
            }
        }
        
        for (int counter1 = 0; counter1 < numberOfEntry+4; counter1++){
            delete [] horizontalVerticalData [counter1];
            delete [] overlapInfo [counter1];
            delete [] overlapValue [counter1];
        }
        
        delete [] horizontalVerticalData;
        delete [] overlapInfo;
        delete [] overlapValue;
        
        for (int counter1 = 0; counter1 < imageWidth+4; counter1++) delete [] overlapFind [counter1];
        delete [] overlapFind;
        
        for (int counter1 = 0; counter1 < numberOfEntry; counter1++){
            if (modificationInfo [counter1+1] == 0 && extensionRemoveInfo [counter1+1] == 1) modificationInfo [counter1+1] = 1;
        }
        
        delete [] extensionRemoveInfo;
        
        //------Border determination and Save------
        int vectorCount = 0;
        int connectEndPosition = 0;
        int connectTemp2 = 0;
        int zeroFillFlag = 0;
        int largestConnect = 0;
        int largestConnectNo = 0;
        int xPositionTempStart = 0;
        int yPositionTempStart = 0;
        int lineSize = 0;
        int constructedLineCount = 0;
        int processType = 0;
        int processTypeSet = 0;
        int pairNumber = 0;
        int cellDimension = 0;
        int firstTimeFlag = 0;
        
        for (int counter1 = 0; counter1 < numberOfEntry; counter1++){
            if (modificationInfo [counter1+1] != -1) vectorCount++;
            
            if (modificationInfo [counter1+1] == 1){
                maxPointDimX = 0;
                maxPointDimY = 0;
                minPointDimX = 100000;
                minPointDimY = 100000;
                connectEndPosition = arrayConnectDataPosition [counter1*2];
                
                for (int counter2 = 0; counter2 < connectEndPosition/2; counter2++){
                    if (maxPointDimX < arrayConnectData [counter1][counter2*2]) maxPointDimX = arrayConnectData [counter1][counter2*2];
                    if (minPointDimX > arrayConnectData [counter1][counter2*2]) minPointDimX = arrayConnectData [counter1][counter2*2];
                    if (maxPointDimY < arrayConnectData [counter1][counter2*2+1]) maxPointDimY = arrayConnectData [counter1][counter2*2+1];
                    if (minPointDimY > arrayConnectData [counter1][counter2*2+1]) minPointDimY = arrayConnectData [counter1][counter2*2+1];
                }
                
                horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                verticalLength = (maxPointDimY-minPointDimY)/2*2;
                dimension = 0;
                
                if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
                
                if (horizontalLength < verticalLength) dimension = verticalLength+30;
                
                dimension = (dimension/2)*2;
                
                horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
                verticalStart = minPointDimY-(dimension-verticalLength)/2;
                
                if (dimension > 0){
                    int **previousMap3A = new int *[dimension+4];
                    
                    for (int counter2 = 0; counter2 < dimension+4; counter2++) previousMap3A [counter2] = new int [dimension+4];
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) previousMap3A [counterY][counterX] = 0;
                    }
                    
                    for (int counter2 = 0; counter2 < connectEndPosition/2; counter2++){
                        if (arrayConnectData [counter1][counter2*2]-horizontalStart >= 0 && arrayConnectData [counter1][counter2*2]-horizontalStart < dimension && arrayConnectData [counter1][counter2*2+1]-verticalStart >= 0 && arrayConnectData [counter1][counter2*2+1]-verticalStart < dimension){
                            previousMap3A [arrayConnectData [counter1][counter2*2+1]-verticalStart][arrayConnectData [counter1][counter2*2]-horizontalStart] = 1;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<< previousMap3A [counterA][counterB];
                    //    cout<<"  previousMap3A2 "<<counterA<<endl;
                    //}
                    
                    //------Connectivity analysis, For Zero------
                    int *connectAnalysisX = new int [(dimension+4)*4];
                    int *connectAnalysisY = new int [(dimension+4)*4];
                    int *connectAnalysisTempX = new int [(dimension+4)*4];
                    int *connectAnalysisTempY = new int [(dimension+4)*4];
                    
                    connectivityNumber = -3;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (previousMap3A [counterY][counterX] == 0){
                                connectivityNumber = connectivityNumber+2;
                                previousMap3A [counterY][counterX] = connectivityNumber;
                                
                                connectAnalysisCount = 0;
                                
                                if (counterY-1 >= 0 && previousMap3A [counterY-1][counterX] == 0){
                                    previousMap3A [counterY-1][counterX] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                }
                                if (counterX+1 < dimension && previousMap3A [counterY][counterX+1] == 0){
                                    previousMap3A [counterY][counterX+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                if (counterY+1 < dimension && previousMap3A [counterY+1][counterX] == 0){
                                    previousMap3A [counterY+1][counterX] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                }
                                if (counterX-1 >= 0 && previousMap3A [counterY][counterX-1] == 0){
                                    previousMap3A [counterY][counterX-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                            xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                            
                                            if (ySource-1 >= 0 && previousMap3A [ySource-1][xSource] == 0){
                                                previousMap3A [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension && previousMap3A [ySource][xSource+1] == 0){
                                                previousMap3A [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension && previousMap3A [ySource+1][xSource] == 0){
                                                previousMap3A [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && previousMap3A [ySource][xSource-1] == 0){
                                                previousMap3A [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                            connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    //------Remove connectivity groups, which attach edge, extract inner part of Linked Line------
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (previousMap3A [counterY][counterX] == -1) previousMap3A [counterY][counterX] = 0;
                            else previousMap3A [counterY][counterX] = 1;
                        }
                    }
                    
                    //-------Internal Zero Find and Fill-------
                    int **connectivityUpdate5 = new int *[dimension+4];
                    
                    for (int counter2 = 0; counter2 < dimension+4; counter2++) connectivityUpdate5 [counter2] = new int [dimension+4];
                    
                    for (int counterX = 0; counterX < dimension+2; counterX++){
                        for (int counterY = 0; counterY < dimension+2; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            connectivityUpdate5 [counterY+1][counterX+1] = previousMap3A [counterY][counterX];
                        }
                    }
                    
                    connectivityNumber = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                            if (connectivityUpdate5 [counterY2][counterX2] == 0){
                                connectivityNumber--;
                                connectAnalysisCount = 0;
                                
                                connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                                
                                if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                                    connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                }
                                if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                    connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                    connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                }
                                if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                    connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                            xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                            
                                            if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                                connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                                connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                                connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                                connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                            connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < dimension+2; counterA++){
                    //	for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                    //	cout<<" connectivityUpdate5 "<<counterA<<endl;
                    //}
                    
                    if (connectivityNumber < -1){
                        int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                        
                        for (int counter2 = 0; counter2 < connectivityNumber*-1*2+5; counter2++) connectCheckArray [counter2] = 0;
                        
                        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                                
                                if (connectTemp2 < -1){
                                    connectTemp2 = connectTemp2*-1;
                                    
                                    if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterY2-1 >= 0 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterY2+1 < dimension+2 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterY2+1 < dimension+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                }
                            }
                        }
                        
                        zeroFillFlag = 0;
                        
                        for (int counter2 = 2; counter2 <= connectivityNumber*-1; counter2++){
                            if (connectCheckArray [counter2*2] != 0 && connectCheckArray [counter2*2+1] == 0) zeroFillFlag = 1;
                        }
                        
                        if (zeroFillFlag == 1){
                            for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                                for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                    connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                                    
                                    if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                                }
                            }
                            
                            for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                                for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                    if (connectivityUpdate5 [counterY2][counterX2] > 0) previousMap3A [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                                }
                            }
                        }
                        
                        delete [] connectCheckArray;
                    }
                    
                    for (int counter2 = 0; counter2 < dimension+4; counter2++) delete [] connectivityUpdate5 [counter2];
                    
                    delete [] connectivityUpdate5;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (previousMap3A [counterY][counterX] != 0){
                                if (counterX+1 < dimension && previousMap3A [counterY][counterX+1] == 0) previousMap3A [counterY][counterX] = -1;
                                else if (counterY+1 < dimension && previousMap3A [counterY+1][counterX] == 0) previousMap3A [counterY][counterX] = -1;
                                else if (counterX-1 >= 0 && previousMap3A [counterY][counterX-1] == 0) previousMap3A [counterY][counterX] = -1;
                                else if (counterY-1 >= 0 && previousMap3A [counterY-1][counterX] == 0) previousMap3A [counterY][counterX] = -1;
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (previousMap3A [counterY][counterX] > 0) previousMap3A [counterY][counterX] = 0;
                            
                            if (previousMap3A [counterY][counterX] < 0) previousMap3A [counterY][counterX] = 1;
                        }
                    }
                    
                    connectivityNumber = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (previousMap3A [counterY2][counterX2] == 0){
                                connectivityNumber--;
                                connectAnalysisCount = 0;
                                
                                previousMap3A [counterY2][counterX2] = connectivityNumber;
                                
                                if (counterY2-1 >= 0 && previousMap3A [counterY2-1][counterX2] == 0){
                                    previousMap3A [counterY2-1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                }
                                if (counterX2+1 < dimension && previousMap3A [counterY2][counterX2+1] == 0){
                                    previousMap3A [counterY2][counterX2+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                if (counterY2+1 < dimension && previousMap3A [counterY2+1][counterX2] == 0){
                                    previousMap3A [counterY2+1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                }
                                if (counterX2-1 >= 0 && previousMap3A [counterY2][counterX2-1] == 0){
                                    previousMap3A [counterY2][counterX2-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                            xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                            
                                            if (ySource-1 >= 0 && previousMap3A [ySource-1][xSource] == 0){
                                                previousMap3A [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension && previousMap3A [ySource][xSource+1] == 0){
                                                previousMap3A [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension && previousMap3A [ySource+1][xSource] == 0){
                                                previousMap3A [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && previousMap3A [ySource][xSource-1] == 0){
                                                previousMap3A [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                            connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    delete [] connectAnalysisX;
                    delete [] connectAnalysisY;
                    delete [] connectAnalysisTempX;
                    delete [] connectAnalysisTempY;
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<< previousMap3A [counterA][counterB];
                    //	cout<<" previousMap3A "<<counterA<<endl;
                    //}
                    
                    //------Determine number of pixels------
                    connectivityNumber = connectivityNumber*-1;
                    
                    int *connectedPix = new int [connectivityNumber+50];
                    
                    for (int counter2 = 0; counter2 <= connectivityNumber; counter2++) connectedPix [counter2] = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (previousMap3A [counterY2][counterX2] < -1){
                                connectedPix [previousMap3A [counterY2][counterX2]*-1]++;
                            }
                        }
                    }
                    
                    int **newConnectivityMapTemp = new int *[dimension+4];
                    
                    for (int counter2 = 0; counter2 < dimension+4; counter2++) newConnectivityMapTemp [counter2] = new int [dimension+4];
                    
                    for (int counterY = 0; counterY < dimension+4; counterY++){
                        for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
                    }
                    
                    largestConnect = 0;
                    largestConnectNo = 0;
                    
                    for (int counter2 = 2; counter2 <= connectivityNumber; counter2++){
                        if (connectedPix [counter2] > largestConnect){
                            largestConnect = connectedPix [counter2];
                            largestConnectNo = counter2;
                        }
                    }
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            connectTemp2 = previousMap3A [counterY2][counterX2];
                            
                            if (connectTemp2 == largestConnectNo*-1){
                                if (counterY2-1 >= 0 && counterX2-1 >= 0 && previousMap3A [counterY2-1][counterX2-1] == 1){
                                    newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                                    previousMap3A [counterY2-1][counterX2-1] = 0;
                                }
                                if (counterY2-1 >= 0 && previousMap3A [counterY2-1][counterX2] == 1){
                                    newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                                    previousMap3A [counterY2-1][counterX2] = 0;
                                }
                                if (counterY2-1 >= 0 && counterX2+1 < dimension && previousMap3A [counterY2-1][counterX2+1] == 1){
                                    newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                                    previousMap3A [counterY2-1][counterX2+1] = 0;
                                }
                                if (counterX2+1 < dimension && previousMap3A [counterY2][counterX2+1] == 1){
                                    newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                                    previousMap3A [counterY2][counterX2+1] = 0;
                                }
                                if (counterY2+1 < dimension && counterX2+1 < dimension && previousMap3A [counterY2+1][counterX2+1] == 1){
                                    newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                                    previousMap3A [counterY2+1][counterX2+1] = 0;
                                }
                                if (counterY2+1 < dimension && previousMap3A [counterY2+1][counterX2] == 1){
                                    newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                                    previousMap3A [counterY2+1][counterX2] = 0;
                                }
                                if (counterY2+1 < dimension && counterX2-1 >= 0 && previousMap3A [counterY2+1][counterX2-1] == 1){
                                    newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                                    previousMap3A [counterY2+1][counterX2-1] = 0;
                                }
                                if (counterX2-1 >= 0 && previousMap3A [counterY2][counterX2-1] == 1){
                                    newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                                    previousMap3A [counterY2][counterX2-1] = 0;
                                }
                            }
                        }
                    }
                    
                    delete [] connectedPix;
                    
                    xPositionTempStart = 0;
                    yPositionTempStart = 0;
                    lineSize = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                                previousMap3A [counterY2][counterX2] = 1;
                                xPositionTempStart = counterX2;
                                yPositionTempStart = counterY2;
                                lineSize++;
                            }
                            else previousMap3A [counterY2][counterX2] = 0;
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < dimension+4; counter2++) delete [] newConnectivityMapTemp [counter2];
                    delete [] newConnectivityMapTemp;
                    
                    constructedLineCount = 0;
                    
                    int *arrayNewLines = new int [lineSize*2+50];
                    
                    previousMap3A [yPositionTempStart][xPositionTempStart] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                    
                    do{
                        
                        findFlag = 0;
                        terminationFlag = 0;
                        
                        if (xPositionTempStart+1 < dimension){
                            if (previousMap3A [yPositionTempStart][xPositionTempStart+1] == 1){
                                previousMap3A [yPositionTempStart][xPositionTempStart+1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        
                        if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                            if (previousMap3A [yPositionTempStart+1][xPositionTempStart+1] == 1){
                                previousMap3A [yPositionTempStart+1][xPositionTempStart+1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        
                        if (yPositionTempStart+1 < dimension && findFlag == 0){
                            if (previousMap3A [yPositionTempStart+1][xPositionTempStart] == 1){
                                previousMap3A [yPositionTempStart+1][xPositionTempStart] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                                yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        
                        if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                            if (previousMap3A [yPositionTempStart+1][xPositionTempStart-1] == 1){
                                previousMap3A [yPositionTempStart+1][xPositionTempStart-1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        
                        if (xPositionTempStart-1 >= 0 && findFlag == 0){
                            if (previousMap3A [yPositionTempStart][xPositionTempStart-1] == 1){
                                previousMap3A [yPositionTempStart][xPositionTempStart-1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        
                        if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                            if (previousMap3A [yPositionTempStart-1][xPositionTempStart-1] == 1){
                                previousMap3A [yPositionTempStart-1][xPositionTempStart-1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        
                        if (yPositionTempStart-1 >= 0 && findFlag == 0){
                            if (previousMap3A [yPositionTempStart-1][xPositionTempStart] == 1){
                                previousMap3A [yPositionTempStart-1][xPositionTempStart] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                                yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        
                        if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                            if (previousMap3A [yPositionTempStart-1][xPositionTempStart+1] == 1){
                                previousMap3A [yPositionTempStart-1][xPositionTempStart+1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                            }
                        }
                        
                    } while (terminationFlag == 1);
                    
                    for (int counter2 = 0; counter2 < dimension+4; counter2++) delete [] previousMap3A [counter2];
                    delete [] previousMap3A;
                    
                    processType = associatedInfo1 [counter1+1];
                    processTypeSet = associatedInfo2 [counter1+1];
                    pairNumber = associatedInfo3 [counter1+1];
                    cellDimension = associatedInfo4 [counter1+1];
                    
                    if (fusionInfo [counter1+1] == 1){
                        processType = 0;
                        processTypeSet = 0;
                    }
                    
                    if (constructedLineCount*3+forNextConnectivityCount > forNextConnectivityLimit){
                        int *arraySourceTemp = new int [forNextConnectivityCount+50];
                        for (int counter2 = 0; counter2 < forNextConnectivityCount; counter2++) arraySourceTemp [counter2] = arrayForNextConnectivity [counter2];
                        
                        delete [] arrayForNextConnectivity;
                        arrayForNextConnectivity = new int [constructedLineCount*3+forNextConnectivityLimit+10000];
                        forNextConnectivityLimit = constructedLineCount*3+forNextConnectivityLimit+10000;
                        
                        for (int counter2 = 0; counter2 < forNextConnectivityCount; counter2++) arrayForNextConnectivity [counter2] = arraySourceTemp [counter2];
                        delete [] arraySourceTemp;
                    }
                    
                    if (constructedLineCount/2 >= 12){
                        firstTimeFlag = 0;
                        
                        for (int counter2 = 0; counter2 < constructedLineCount/2; counter2++){
                            arrayForNextConnectivity [forNextConnectivityCount] = arrayNewLines [counter2*2], forNextConnectivityCount++; //------X position------
                            arrayForNextConnectivity [forNextConnectivityCount] = arrayNewLines [counter2*2+1], forNextConnectivityCount++; //------Y position------
                            arrayForNextConnectivity [forNextConnectivityCount] = arrayExtractedImage [arrayNewLines [counter2*2+1]][arrayNewLines [counter2*2]], forNextConnectivityCount++; //------Value------
                            arrayForNextConnectivity [forNextConnectivityCount] = vectorCount, forNextConnectivityCount++; //------Vector Number------
                            
                            if (firstTimeFlag == 0) firstTimeFlag = 1, arrayForNextConnectivity [forNextConnectivityCount] = 1, forNextConnectivityCount++;
                            else arrayForNextConnectivity [forNextConnectivityCount] = 0, forNextConnectivityCount++;
                        }
                        
                        arrayForNextConnectivity [(forNextConnectivityCount/5-1)*5+4] = 2;
                        
                        //for (int counterA = 0; counterA < forNextConnectivityCount/5; counterA++){
                        //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayForNextConnectivity [counterA*5+counterB];
                        //	cout<<" arrayForNextConnectivity "<<counterA<<" "<<counter1<<endl;
                        //}
                        
                        if (forNextConnectivityAssCount+6 > forNextConnectivityAssLimit){
                            int *arraySourceTemp = new int [forNextConnectivityAssCount+50];
                            for (int counter2 = 0; counter2 < forNextConnectivityAssCount; counter2++) arraySourceTemp [counter2] = arrayForNextConnectivityAss [counter2];
                            
                            delete [] arrayForNextConnectivityAss;
                            arrayForNextConnectivityAss = new int [forNextConnectivityAssLimit+5000];
                            forNextConnectivityAssLimit = forNextConnectivityAssLimit+5000;
                            
                            for (int counter2 = 0; counter2 < forNextConnectivityAssCount; counter2++) arrayForNextConnectivityAss [counter2] = arraySourceTemp [counter2];
                            delete [] arraySourceTemp;
                        }
                        
                        arrayForNextConnectivityAss [forNextConnectivityAssCount] = vectorCount, forNextConnectivityAssCount++;
                        arrayForNextConnectivityAss [forNextConnectivityAssCount] = processType, forNextConnectivityAssCount++; //------Process Type: 1 A190, 2: > A200------
                        arrayForNextConnectivityAss [forNextConnectivityAssCount] = processTypeSet, forNextConnectivityAssCount++;
                        arrayForNextConnectivityAss [forNextConnectivityAssCount] = pairNumber, forNextConnectivityAssCount++;
                        arrayForNextConnectivityAss [forNextConnectivityAssCount] = cellDimension, forNextConnectivityAssCount++;
                        arrayForNextConnectivityAss [forNextConnectivityAssCount] = 0, forNextConnectivityAssCount++;
                    }
                    else vectorCount = vectorCount-1;
                    
                    delete [] arrayNewLines;
                }
                else vectorCount = vectorCount-1;
            }
            else if (modificationInfo [counter1+1] != -1){
                lineDataEntryCount = arrayLineDataPosition [counter1];
                
                if (lineDataEntryCount+forNextConnectivityCount > forNextConnectivityLimit){
                    int *arraySourceTemp = new int [forNextConnectivityCount+50];
                    for (int counter2 = 0; counter2 < forNextConnectivityCount; counter2++) arraySourceTemp [counter2] = arrayForNextConnectivity [counter2];
                    
                    delete [] arrayForNextConnectivity;
                    arrayForNextConnectivity = new int [lineDataEntryCount+forNextConnectivityLimit+10000];
                    forNextConnectivityLimit = lineDataEntryCount+forNextConnectivityLimit+10000;
                    
                    for (int counter2 = 0; counter2 < forNextConnectivityCount; counter2++) arrayForNextConnectivity [counter2] = arraySourceTemp [counter2];
                    delete [] arraySourceTemp;
                }
                
                for (int counter2 = 0; counter2 < lineDataEntryCount/5; counter2++){
                    arrayForNextConnectivity [forNextConnectivityCount] = arrayLineData [counter1][counter2*5], forNextConnectivityCount++; //------X position------
                    arrayForNextConnectivity [forNextConnectivityCount] = arrayLineData [counter1][counter2*5+1], forNextConnectivityCount++; //------Y position------
                    arrayForNextConnectivity [forNextConnectivityCount] = arrayLineData [counter1][counter2*5+2], forNextConnectivityCount++; //------Value------
                    arrayForNextConnectivity [forNextConnectivityCount] = vectorCount, forNextConnectivityCount++; //------Vector Number------
                    arrayForNextConnectivity [forNextConnectivityCount] = arrayLineData [counter1][counter2*5+4], forNextConnectivityCount++; //------Start/End------
                }
                
                if (forNextConnectivityAssCount+6 > forNextConnectivityAssLimit){
                    int *arraySourceTemp = new int [forNextConnectivityAssCount+50];
                    for (int counter2 = 0; counter2 < forNextConnectivityAssCount; counter2++) arraySourceTemp [counter2] = arrayForNextConnectivityAss [counter2];
                    
                    delete [] arrayForNextConnectivityAss;
                    arrayForNextConnectivityAss = new int [forNextConnectivityAssLimit+5000];
                    forNextConnectivityAssLimit = forNextConnectivityAssLimit+5000;
                    
                    for (int counter2 = 0; counter2 < forNextConnectivityAssCount; counter2++) arrayForNextConnectivityAss [counter2] = arraySourceTemp [counter2];
                    delete [] arraySourceTemp;
                }
                
                arrayForNextConnectivityAss [forNextConnectivityAssCount] = vectorCount, forNextConnectivityAssCount++; //------Vector Number------
                arrayForNextConnectivityAss [forNextConnectivityAssCount] = arrayLineDataAss [counter1][1], forNextConnectivityAssCount++; //------Process Type: 1 A190, 2: > A200------
                arrayForNextConnectivityAss [forNextConnectivityAssCount] = arrayLineDataAss [counter1][2], forNextConnectivityAssCount++; //------Cut type: 1 A240 cut, 2: unCut------
                arrayForNextConnectivityAss [forNextConnectivityAssCount] = arrayLineDataAss [counter1][3], forNextConnectivityAssCount++; //------Pair Number------
                arrayForNextConnectivityAss [forNextConnectivityAssCount] = arrayLineDataAss [counter1][4], forNextConnectivityAssCount++; //------Cell dimension------
                arrayForNextConnectivityAss [forNextConnectivityAssCount] = arrayLineDataAss [counter1][5], forNextConnectivityAssCount++; //------Reserve------
                
                //for (int counterA = 0; counterA < forNextConnectivityAssCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayForNextConnectivityAss [counterA*6+counterB];
                //	cout<<" arrayForNextConnectivityAss "<<counterA<<" "<<counter1<<endl;
                //}
            }
        }
        
        delete [] associatedInfo1;
        delete [] associatedInfo2;
        delete [] associatedInfo3;
        delete [] associatedInfo4;
        delete [] modificationInfo;
        delete [] fusionInfo;
        
        for (int counter1 = 0; counter1 < numberOfEntry+1; counter1++){
            delete [] arrayConnectData [counter1];
            delete [] arrayLineData [counter1];
            delete [] arrayLineDataAss [counter1];
        }
        
        delete [] arrayConnectData;
        delete [] arrayLineData;
        delete [] arrayLineDataAss;
        
        delete [] arrayConnectDataPosition;
        delete [] arrayLineDataPosition;
    }
}

@end
