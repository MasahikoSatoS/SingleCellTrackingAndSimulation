//
// OverlapCheck.h
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 02/02/13.
// Copyright 2012 Masahiko Sato. All rights reserved.
//

#ifndef OVERLAPCHECK_H
#define OVERLAPCHECK_H
#import "Controller.h"
#endif

@interface OverlapCheck : NSObject {
}

-(void)overlapCheckMain:(int)typeSubArray;

@end
