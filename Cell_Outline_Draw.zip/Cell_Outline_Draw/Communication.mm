//
//  Communication.mm
//  Cell_Outline_Draw
//
//  Created by Masahiko Sato on 2014-05-14.
//
//

#import "Communication.h"

NSString *notificationToCommunication = @"notificationExecuteCommunication";

@implementation Communication

-(id)init{
    self = [super init];
    
    if (self != nil){
        firstCommunication = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToCommunication object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    communicationTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(processControl) userInfo:nil repeats:YES];
}

-(void)processControl{
    //runMode = 1; //================================For Debugging===========
    
    if (firstCommunication == 0){
        string bodyNamePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/AnalysisSetting";
        string getString;
        
        ifstream fin;
        fin.open(bodyNamePath.c_str(), ios::in);
        
        if (fin.is_open()){
            getline(fin, getString);
            
            if (getString == "nil") bodyName = "nil";
            else bodyName = getString;
            
            fin.close();
            
            firstCommunication = 1;
            runMode = 1;
            
            [communicationTimer invalidate];
        }
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToCommunication object:nil];
    if (communicationTimer) [communicationTimer invalidate];
}

@end

