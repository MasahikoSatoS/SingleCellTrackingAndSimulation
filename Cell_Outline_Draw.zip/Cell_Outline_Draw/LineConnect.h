//
// LineConnect.h
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 26/11/12.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#ifndef LINECONNECT_H
#define LINECONNECT_H
#import "Controller.h"
#endif

@interface LineConnect : NSObject {
    id gapChase2;
}

-(void)lineConnectSameType:(int)lineSet;
-(void)gapChaseUpdate;

@end
