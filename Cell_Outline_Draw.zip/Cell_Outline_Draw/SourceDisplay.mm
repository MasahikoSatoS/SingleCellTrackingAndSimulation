//
// SourceDisplay.mm
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 10/07/11.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#import "SourceDisplay.h"

NSString *notificationToSourceImage = @"notificationExecuteSourceImage";

@implementation SourceDisplay

-(id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    
    if (self) {
        cellImageOutline = [[NSImage alloc] initWithContentsOfFile:@""];
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToSourceImage object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    //------Source Image loading------
    NSBitmapImageRep *bitmapReps;
    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageWidth pixelsHigh:imageHeight bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageHeight bitsPerPixel:8];
    unsigned char *bitmapData = [bitmapReps bitmapData];
    
    if (displayMode == 0){
        for (int counter1 = 0; counter1 < imageWidth; counter1++){
            for (int counter2 = 0; counter2 < imageHeight; counter2++) *bitmapData++ = (unsigned char)imageForDisplay1 [counter1][counter2];
        }
    }
    
    if (displayMode == 1){
        for (int counter1 = 0; counter1 < imageWidth; counter1++){
            for (int counter2 = 0; counter2 < imageHeight; counter2++) *bitmapData++ = (unsigned char)imageForDisplay2 [counter1][counter2];
        }
    }
    
    if (displayMode == 2){
        for (int counter1 = 0; counter1 < imageWidth; counter1++){
            for (int counter2 = 0; counter2 < imageHeight; counter2++) *bitmapData++ = (unsigned char)imageForDisplay3 [counter1][counter2];
        }
    }
    
    if (displayMode == 3){
        for (int counter1 = 0; counter1 < imageWidth; counter1++){
            for (int counter2 = 0; counter2 < imageHeight; counter2++) *bitmapData++ = (unsigned char)imageForDisplay4 [counter1][counter2];
        }
    }
    
    cellImageOutline = [[NSImage alloc] initWithSize:NSMakeSize(imageWidth, imageHeight)];
    [cellImageOutline addRepresentation:bitmapReps];
    
    if (imageFirstLoadFlagDisplay == 0){
        xPositionDisplay = 0;
        yPositionDisplay = 0;
        xPositionAdjustDisplay = 0;
        yPositionAdjustDisplay = 0;
        magnificationDisplay = 10;
        imageFirstLoadFlagDisplay = 1;
    }
    
    //------Window size and Position re-adjust------
    int vertical = 350+78;
    int horizontal = 350;
    
    windowWidthDisplay = imageWidth/(double)horizontal;
    windowHeightDisplay = imageWidth/(double)(vertical-78);
    
    xPositionAdjustDisplay = (imageWidth-imageHeight/(double)(magnificationDisplay*0.1))/(double)2;
    yPositionAdjustDisplay = (imageWidth-imageHeight/(double)(magnificationDisplay*0.1))/(double)2;
    
    toControllerDisplay1 = 1;
    
    [self setNeedsDisplay:YES];
}

-(void)mouseDown:(NSEvent *)event{
    NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
    xPointDownDisplay = clickPoint.x;
    yPointDownDisplay = clickPoint.y;
    
    [self setNeedsDisplay:YES];
}

-(void)mouseUp:(NSEvent *)event{
    xPositionDisplay = xPositionDisplay+xPositionMoveDisplay;
    yPositionDisplay = yPositionDisplay+yPositionMoveDisplay;
    xPositionMoveDisplay = 0;
    yPositionMoveDisplay = 0;
    mouseDragFlag = 0;
    
    [self setNeedsDisplay:YES];
}

- (void)mouseDragged:(NSEvent *)event{
    NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
    xPointDragDisplay = clickPoint.x;
    yPointDragDisplay = clickPoint.y;
    xPositionMoveDisplay = (xPointDownDisplay-xPointDragDisplay)*windowWidthDisplay/(double)(magnificationDisplay*0.1);
    yPositionMoveDisplay = (yPointDownDisplay-yPointDragDisplay)*windowHeightDisplay/(double)(magnificationDisplay*0.1);
    
    mouseDragFlag = 1;
    [self setNeedsDisplay:YES];
}

-(void)keyDown:(NSEvent *)event{
    int keyCode = [event keyCode];
    int proceedFlag = 0;
    
    //------Original size------
    if (keyCode == 6){
        proceedFlag = 1;
        xPositionDisplay = 0;
        yPositionDisplay = 0;
        xPositionAdjustDisplay = 0;
        yPositionAdjustDisplay = 0;
        magnificationDisplay = 10;
    }
    
    //------Magnification Magnify------
    if (keyCode == 125){
        if (magnificationDisplay >= 10 && magnificationDisplay <= 498){
            proceedFlag = 1;
            if (magnificationDisplay-10 < 12) magnificationDisplay = 12;
            else magnificationDisplay = magnificationDisplay-10;
            
            xPositionAdjustDisplay = -1*(imageHeight/(double)(magnificationDisplay*0.1)-imageHeight)/(double)2;
            yPositionAdjustDisplay = -1*(imageHeight/(double)(magnificationDisplay*0.1)-imageHeight)/(double)2;
        }
        else if (magnificationDisplay < 10) magnificationDisplay = 10;
    }
    
    //------Magnification Reduction------
    if (keyCode == 126){
        if (magnificationDisplay >= 10 && magnificationDisplay <= 498){
            proceedFlag = 1;
            
            if (magnificationDisplay+10 > 498) magnificationDisplay = 498;
            else magnificationDisplay = magnificationDisplay+10;
            xPositionAdjustDisplay = (imageHeight-imageHeight/(double)(magnificationDisplay*0.1))/(double)2;
            yPositionAdjustDisplay = (imageHeight-imageHeight/(double)(magnificationDisplay*0.1))/(double)2;
        }
        else if (magnificationDisplay > 498) magnificationDisplay = 498;
    }
    
    //------Magnification Reduction------
    if (keyCode == 49){
        proceedFlag = 1;
        magnificationDisplay = (int)(200/((double)(50/(double)imageHeight)*350)*10);
        xPositionAdjustDisplay = (imageHeight-imageHeight/(double)(magnificationDisplay*0.1))/(double)2;
        yPositionAdjustDisplay = (imageHeight-imageHeight/(double)(magnificationDisplay*0.1))/(double)2;
    }
    
    if (proceedFlag == 1) [self setNeedsDisplay:YES];
}

//------First Responder------
-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)drawRect:(NSRect)rect {
    NSRect srcRect;
    srcRect.origin.x = xPositionDisplay+xPositionAdjustDisplay+xPositionMoveDisplay;
    srcRect.origin.y = yPositionDisplay+yPositionAdjustDisplay+yPositionMoveDisplay;
    srcRect.size.width = imageHeight/(double)(magnificationDisplay*0.1);
    srcRect.size.height = imageHeight/(double)(magnificationDisplay*0.1);
    
    [cellImageOutline drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
    
    if (imageFirstLoadFlag == 1){
        if (mouseDragFlag == 0){
            double xPositionAdj = xPositionAdjustDisplay+xPositionDisplay;
            double yPositionAdj = yPositionAdjustDisplay+yPositionDisplay;
            double xCalValue = 1/(double)windowWidthDisplay*magnificationDisplay*0.1;
            double yCalValue = 1/(double)windowHeightDisplay*magnificationDisplay*0.1;
            
            double displayFrequencyTemp = (2-xPositionAdj)*xCalValue-(1-xPositionAdj)*xCalValue;
            int displayFrequency = (int)displayFrequencyTemp;
            
            if (displayFrequencyTemp <= 2 && displayFrequencyTemp != 0) displayFrequency = (int)(2/(double)displayFrequencyTemp);
            else if (displayFrequencyTemp > 2) displayFrequency = 1;
            
            CGFloat sizeCalculation = 512*xCalValue;
            sizeCalculation = (sizeCalculation/(double)350)*2;
            
            if (sizeCalculation >= 7) sizeCalculation = 7;
            
            NSBezierPath *path3;
            [NSBezierPath setDefaultLineWidth:sizeCalculation];
            
            int xPointMarkTemp = 0;
            int yPointMarkTemp = 0;
            int valueTemp3 = 0;
            
            if (displayMode == 0){
                for (int counter1 = 0; counter1 < lineDataForDisplayCount9/3; counter1 = counter1+displayFrequency){
                    xPointMarkTemp = (int)((arrayLineDataForDisplay9 [counter1*3]-xPositionAdj)*xCalValue);
                    yPointMarkTemp = (int)(((imageWidth-arrayLineDataForDisplay9 [counter1*3+1])-yPositionAdj)*yCalValue);
                    
                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 350 && yPointMarkTemp >= 0 && yPointMarkTemp <= 350){
                        [[NSColor blueColor] set];
                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, sizeCalculation, sizeCalculation)];
                        [path3 fill];
                    }
                }
            }
            
            if (displayMode == 1){
                for (int counter1 = 0; counter1 < lineDataForDisplayCount8/3; counter1 = counter1+displayFrequency){
                    valueTemp3 = arrayLineDataForDisplay8 [counter1*3+2];
                    xPointMarkTemp = (int)((arrayLineDataForDisplay8 [counter1*3]-xPositionAdj)*xCalValue);
                    yPointMarkTemp = (int)(((imageWidth-arrayLineDataForDisplay8 [counter1*3+1])-yPositionAdj)*yCalValue);
                    
                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 350 && yPointMarkTemp >= 0 && yPointMarkTemp <= 350){
                        if (valueTemp3 == 3){
                            [[NSColor blueColor] set];
                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, sizeCalculation, sizeCalculation)];
                            [path3 fill];
                        }
                        else if (valueTemp3 == 2){
                            [[NSColor greenColor] set];
                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, sizeCalculation, sizeCalculation)];
                            [path3 fill];
                        }
                        else if (valueTemp3 == 1){
                            [[NSColor redColor] set];
                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, sizeCalculation, sizeCalculation)];
                            [path3 fill];
                        }
                    }
                }
            }
            
            if (displayMode == 2){
                for (int counter1 = 0; counter1 < lineDataForDisplayCount7/3; counter1 = counter1+displayFrequency){
                    valueTemp3 = arrayLineDataForDisplay7 [counter1*3+2];
                    xPointMarkTemp = (int)((arrayLineDataForDisplay7 [counter1*3]-xPositionAdj)*xCalValue);
                    yPointMarkTemp = (int)(((imageWidth-arrayLineDataForDisplay7 [counter1*3+1])-yPositionAdj)*yCalValue);
                    
                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 350 && yPointMarkTemp >= 0 && yPointMarkTemp <= 350){
                        if (valueTemp3 == 3){
                            [[NSColor blueColor] set];
                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, sizeCalculation, sizeCalculation)];
                            [path3 fill];
                        }
                        else if (valueTemp3 == 2){
                            [[NSColor greenColor] set];
                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, sizeCalculation, sizeCalculation)];
                            [path3 fill];
                        }
                        else if (valueTemp3 == 1){
                            [[NSColor redColor] set];
                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, sizeCalculation, sizeCalculation)];
                            [path3 fill];
                        }
                    }
                }
            }
            
            if (displayMode == 3){
                for (int counter1 = 0; counter1 < lineDataForDisplayCount6/3; counter1 = counter1+displayFrequency){
                    valueTemp3 = arrayLineDataForDisplay6 [counter1*3+2];
                    xPointMarkTemp = (int)((arrayLineDataForDisplay6 [counter1*3]-xPositionAdj)*xCalValue);
                    yPointMarkTemp = (int)(((imageWidth-arrayLineDataForDisplay6 [counter1*3+1])-yPositionAdj)*yCalValue);
                    
                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 350 && yPointMarkTemp >= 0 && yPointMarkTemp <= 350){
                        if (valueTemp3 == 3){
                            [[NSColor blueColor] set];
                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, sizeCalculation, sizeCalculation)];
                            [path3 fill];
                        }
                        else if (valueTemp3 == 2){
                            [[NSColor greenColor] set];
                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, sizeCalculation, sizeCalculation)];
                            [path3 fill];
                        }
                        else if (valueTemp3 == 1){
                            [[NSColor redColor] set];
                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, sizeCalculation, sizeCalculation)];
                            [path3 fill];
                        }
                    }
                }
            }
        }
    }
    
    sourceDisplayCheck++;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToSourceImage object:nil];
}

@end

