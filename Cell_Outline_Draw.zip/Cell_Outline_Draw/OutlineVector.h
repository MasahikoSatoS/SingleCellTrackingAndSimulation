//
// OutlineVector.h
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 04/11/11.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#ifndef OUTLINEVECTOR_H
#define OUTLINEVECTOR_H
#import "Controller.h"
#endif

@interface OutlineVector : NSObject {
}

-(void)outlineVector:(int)arrayNumber :(int)pixelNumber;

@end
