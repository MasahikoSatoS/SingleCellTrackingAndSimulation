//
// ConnectivityAnalysis.mm
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 11/11/04.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#import "ConnectivityAnalysis.h"

@implementation ConnectivityAnalysis

-(void)matchingCheck:(int)subjectArray{
    //------Memory allocation------
    int **rangeMatrix = new int *[imageWidth+4];
    int **connectivityMap = new int *[imageWidth+4];
    
    for (int counter1 = 0; counter1 < imageWidth+4; counter1++){
        rangeMatrix [counter1] = new int [imageWidth+4];
        connectivityMap [counter1] = new int [imageWidth+4];
    }
    
    if (subjectArray == 1 || subjectArray == -1){
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++) rangeMatrix [counterY][counterX] = arrayImage150 [counterY][counterX];
        }
    }
    
    if (subjectArray == 2){
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++) rangeMatrix [counterY][counterX] = arrayImageConnect200 [counterY][counterX];
        }
    }
    
    if (subjectArray == 3){
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++) rangeMatrix [counterY][counterX] = arrayImageConnect220 [counterY][counterX];
        }
    }
    
    if (subjectArray == 4){
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++) rangeMatrix [counterY][counterX] = arrayImageConnect240 [counterY][counterX];
        }
    }
    
    //------Remove 150-pixels attached with one 150------
    int neighbourCount = 0;
    
    for (int counterY = 0; counterY < imageWidth; counterY++){
        for (int counterX = 0; counterX < imageWidth; counterX++){
            if (rangeMatrix [counterY][counterX] != 0){
                if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrix [counterY-1][counterX-1] > 0) neighbourCount++;
                if (counterY-1 >= 0 && rangeMatrix [counterY-1][counterX] > 0) neighbourCount++;
                if (counterY-1 >= 0 && counterX+1 < imageWidth && rangeMatrix [counterY-1][counterX+1] > 0) neighbourCount++;
                if (counterX+1 < imageWidth && rangeMatrix [counterY][counterX+1] > 0) neighbourCount++;
                if (counterY+1 < imageWidth && counterX+1 < imageWidth && rangeMatrix [counterY+1][counterX+1] > 0) neighbourCount++;
                if (counterY+1 < imageWidth && rangeMatrix [counterY+1][counterX] > 0) neighbourCount++;
                if (counterY+1 < imageWidth && counterX-1 >= 0 && rangeMatrix [counterY+1][counterX-1] > 0) neighbourCount++;
                if (counterX-1 >= 0 && rangeMatrix [counterY][counterX-1] > 0) neighbourCount++;
                if (rangeMatrix [counterY][counterX] > 0) neighbourCount++;
                
                if (neighbourCount <= 4) rangeMatrix [counterY][counterX] = 0; //------Remove edge point attached with 3 other pixels------
                neighbourCount = 0;
            }
        }
    }
    
    //------Connected pixels------
    for (int counterY = 0; counterY < imageWidth; counterY++){
        for (int counterX = 0; counterX < imageWidth; counterX++) connectivityMap [counterY][counterX] = rangeMatrix [counterY][counterX]*-1;
    }
    
    int *connectAnalysisX = new int [imageWidth*4];
    int *connectAnalysisY = new int [imageWidth*4];
    int *connectAnalysisTempX = new int [imageWidth*4];
    int *connectAnalysisTempY = new int [imageWidth*4];
    
    int connectivityNumber = 0;
    int connectAnalysisCount = 0;
    int terminationFlag = 0;
    int connectAnalysisTempCount = 0;
    int xSource = 0;
    int ySource = 0;
    
    for (int counterY = 0; counterY < imageWidth; counterY++){
        for (int counterX = 0; counterX < imageWidth; counterX++){
            if (connectivityMap [counterY][counterX] == -150){
                connectivityNumber++;
                connectivityMap [counterY][counterX] = connectivityNumber;
                connectAnalysisCount = 0;
                
                if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMap [counterY-1][counterX-1] == -150){
                    connectivityMap [counterY-1][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterY-1 >= 0 && connectivityMap [counterY-1][counterX] == -150){
                    connectivityMap [counterY-1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterY-1 >= 0 && counterX+1 < imageWidth && connectivityMap [counterY-1][counterX+1] == -150){
                    connectivityMap [counterY-1][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterX+1 < imageWidth && connectivityMap [counterY][counterX+1] == -150){
                    connectivityMap [counterY][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                if (counterY+1 < imageWidth && counterX+1 < imageWidth && connectivityMap [counterY+1][counterX+1] == -150){
                    connectivityMap [counterY+1][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterY+1 < imageWidth && connectivityMap [counterY+1][counterX] == -150){
                    connectivityMap [counterY+1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterY+1 < imageWidth && counterX-1 >= 0 && connectivityMap [counterY+1][counterX-1] == -150){
                    connectivityMap [counterY+1][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterX-1 >= 0 && connectivityMap [counterY][counterX-1] == -150){
                    connectivityMap [counterY][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                
                if (connectAnalysisCount != 0){
                    do{
                        
                        terminationFlag = 1;
                        connectAnalysisTempCount = 0;
                        
                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                            xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                            
                            if (ySource-1 >= 0 && xSource-1 >= 0 && connectivityMap [ySource-1][xSource-1] == -150){
                                connectivityMap [ySource-1][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (ySource-1 >= 0 && connectivityMap [ySource-1][xSource] == -150){
                                connectivityMap [ySource-1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (ySource-1 >= 0 && xSource+1 < imageWidth && connectivityMap [ySource-1][xSource+1] == -150){
                                connectivityMap [ySource-1][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (xSource+1 < imageWidth && connectivityMap [ySource][xSource+1] == -150){
                                connectivityMap [ySource][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                            if (ySource+1 > imageWidth && xSource+1 < imageWidth && connectivityMap [ySource+1][xSource+1] == -150){
                                connectivityMap [ySource+1][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < imageWidth && connectivityMap [ySource+1][xSource] == -150){
                                connectivityMap [ySource+1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < imageWidth && xSource-1 >= 0 && connectivityMap [ySource+1][xSource-1] == -150){
                                connectivityMap [ySource+1][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (xSource-1 >= 0 && connectivityMap [ySource][xSource-1] == -150){
                                connectivityMap [ySource][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                        }
                        
                        connectAnalysisCount = connectAnalysisTempCount;
                        
                        if (connectAnalysisCount == 0) terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                }
            }
        }
    }
    
    delete [] connectAnalysisX;
    delete [] connectAnalysisY;
    delete [] connectAnalysisTempX;
    delete [] connectAnalysisTempY;
    
    //------Determine number of pixels------
    int *connectedPix = new int [connectivityNumber+50];
    
    for (int counter1 = 0; counter1 <= connectivityNumber; counter1++) connectedPix [counter1] = 0;
    
    for (int counterY = 0; counterY < imageWidth; counterY++){
        for (int counterX = 0; counterX < imageWidth; counterX++){
            if (connectivityMap [counterY][counterX] != 0) connectedPix [connectivityMap [counterY][counterX]]++;
        }
    }
    
    //------Map up-date------
    int connectTemp = 1;
    
    for (int counter1 = 1; counter1 <= connectivityNumber; counter1++){
        if (connectedPix [counter1] < 40) connectedPix [counter1] = 0;
        else{
            
            connectedPix [counter1] = connectTemp;
            connectTemp++;
        }
    }
    
    for (int counterY = 0; counterY < imageWidth; counterY++){
        for (int counterX = 0; counterX < imageWidth; counterX++){
            if ((connectTemp = connectivityMap [counterY][counterX]) != 0) connectivityMap [counterY][counterX] = connectedPix [connectTemp];
        }
    }
    
    delete [] connectedPix;
    
    //for (int counterA = 1500; counterA < 1620; counterA++){
    //    for (int counterB = 350; counterB < 450; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
    //    cout<<" connectivityMap"<<counterA<<endl;
    //}
    
    //------Data Save to array------
    if (subjectArray == 1 || subjectArray == -1){
        if (subjectArray == 1){
            for (int counterY = 0; counterY < imageWidth; counterY++){
                for (int counterX = 0; counterX < imageWidth; counterX++) arrayImageConnectivity [counterY][counterX] = connectivityMap [counterY][counterX];
            }
        }
        
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++){
                if (connectivityMap [counterY][counterX] != 0) arrayImage150 [counterY][counterX] = rangeMatrix [counterY][counterX];
                else arrayImage150 [counterY][counterX] = 0;
            }
        }
    }
    
    if (subjectArray == 2){
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++){
                if (connectivityMap [counterY][counterX] != 0) arrayImageConnect200 [counterY][counterX] = connectivityMap [counterY][counterX];
                else arrayImageConnect200 [counterY][counterX] = 0;
            }
        }
    }
    
    if (subjectArray == 3){
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++){
                if (connectivityMap [counterY][counterX] != 0) arrayImageConnect220 [counterY][counterX] = connectivityMap [counterY][counterX];
                else arrayImageConnect220 [counterY][counterX] = 0;
            }
        }
    }
    
    if (subjectArray == 4){
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++){
                if (connectivityMap [counterY][counterX] != 0) arrayImageConnect240 [counterY][counterX] = connectivityMap [counterY][counterX];
                else arrayImageConnect240 [counterY][counterX] = 0;
            }
        }
    }
    
    for (int counter1 = 0; counter1 < imageWidth+4; counter1++){
        delete [] connectivityMap [counter1];
        delete [] rangeMatrix [counter1];
    }
    
    delete [] connectivityMap;
    delete [] rangeMatrix;
}

-(void)reconstruction:(int)subjectArray{
    int **rangeMatrix = new int *[imageWidth+4]; //------Hold 150 map------
    int **connectivityMap = new int *[imageWidth+4]; //------Hold Connect Map------
    int **delaySourceMap = new int *[imageWidth+4];
    int **delayMap = new int *[imageWidth+4];
    
    //clock_t time1, time2, time3, time4, time5, time6, time7, time8, time9, time10, time11, time12, time13, time14, time15;
    
    //time1 = clock();
    
    for (int counter1 = 0; counter1 < imageWidth+4; counter1++){
        rangeMatrix [counter1] = new int [imageWidth+4];
        connectivityMap [counter1] = new int [imageWidth+4];
        delaySourceMap [counter1] = new int [imageWidth+4];
        delayMap [counter1] = new int [imageWidth+4];
    }
    
    for (int counterY = 0; counterY < imageWidth; counterY++){
        for (int counterX = 0; counterX < imageWidth; counterX++) rangeMatrix [counterY][counterX] = arrayImage150 [counterY][counterX];
    }
    
    int neighbourCount = 0;
    
    for (int counterY = 0; counterY < imageWidth; counterY++){
        for (int counterX = 0; counterX < imageWidth; counterX++){
            if (rangeMatrix [counterY][counterX] != 0){
                if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrix [counterY-1][counterX-1] != 0) neighbourCount++;
                if (counterY-1 >= 0 && rangeMatrix [counterY-1][counterX] != 0) neighbourCount++;
                if (counterY-1 >= 0 && counterX+1 < imageWidth && rangeMatrix [counterY-1][counterX+1] != 0) neighbourCount++;
                if (counterX+1 < imageWidth && rangeMatrix [counterY][counterX+1] != 0) neighbourCount++;
                if (counterY+1 < imageWidth && counterX+1 < imageWidth && rangeMatrix [counterY+1][counterX+1] != 0) neighbourCount++;
                if (counterY+1 < imageWidth && rangeMatrix [counterY+1][counterX] != 0) neighbourCount++;
                if (counterY+1 < imageWidth && counterX-1 >= 0 && rangeMatrix [counterY+1][counterX-1] != 0) neighbourCount++;
                if (counterX-1 >= 0 && rangeMatrix [counterY][counterX-1] != 0) neighbourCount++;
                if (rangeMatrix [counterY][counterX] != 0) neighbourCount++;
                
                if (neighbourCount <= 3) rangeMatrix [counterY][counterX] = 0;
                neighbourCount = 0;
            }
        }
    }
    
    //for (int counterA = 870; counterA < 1000; counterA++){
    //	for (int counterB = 870; counterB < 930; counterB++) cout<<" "<<rangeMatrix [counterA][counterB];
    //	cout<<" rangeMatrix "<<counterA<<endl;
    //}
    
    //------Connectivity Analysis for A150------
    for (int counterY = 0; counterY < imageWidth; counterY++){
        for (int counterX = 0; counterX < imageWidth; counterX++){
            connectivityMap [counterY][counterX] = rangeMatrix [counterY][counterX]*-1;
            delaySourceMap [counterY][counterX] = 0;
            delayMap [counterY][counterX] = 0;
        }
    }
    
    int *connectAnalysisX = new int [(imageWidth+2)*4];
    int *connectAnalysisY = new int [(imageWidth+2)*4];
    int *connectAnalysisTempX = new int [(imageWidth+2)*4];
    int *connectAnalysisTempY = new int [(imageWidth+2)*4];
    
    int connectivityNumber = 0;
    int connectAnalysisCount = 0;
    int terminationFlag = 0;
    int connectAnalysisTempCount = 0;
    int xSource = 0;
    int ySource = 0;
    
    for (int counterY = 0; counterY < imageWidth; counterY++){
        for (int counterX = 0; counterX < imageWidth; counterX++){
            if (connectivityMap [counterY][counterX] == -150){
                connectivityNumber++;
                connectivityMap [counterY][counterX] = connectivityNumber;
                connectAnalysisCount = 0;
                
                if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMap [counterY-1][counterX-1] == -150){
                    connectivityMap [counterY-1][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterY-1 >= 0 && connectivityMap [counterY-1][counterX] == -150){
                    connectivityMap [counterY-1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterY-1 >= 0 && counterX+1 < imageWidth && connectivityMap [counterY-1][counterX+1] == -150){
                    connectivityMap [counterY-1][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterX+1 < imageWidth && connectivityMap [counterY][counterX+1] == -150){
                    connectivityMap [counterY][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                if (counterY+1 < imageWidth && counterX+1 < imageWidth && connectivityMap [counterY+1][counterX+1] == -150){
                    connectivityMap [counterY+1][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterY+1 < imageWidth && connectivityMap [counterY+1][counterX] == -150){
                    connectivityMap [counterY+1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterY+1 < imageWidth && counterX-1 >= 0 && connectivityMap [counterY+1][counterX-1] == -150){
                    connectivityMap [counterY+1][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterX-1 >= 0 && connectivityMap [counterY][counterX-1] == -150){
                    connectivityMap [counterY][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                
                if (connectAnalysisCount != 0){
                    do{
                        
                        terminationFlag = 1;
                        connectAnalysisTempCount = 0;
                        
                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                            xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                            
                            if (ySource-1 >= 0 && xSource-1 >= 0 && connectivityMap [ySource-1][xSource-1] == -150){
                                connectivityMap [ySource-1][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (ySource-1 >= 0 && connectivityMap [ySource-1][xSource] == -150){
                                connectivityMap [ySource-1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (ySource-1 >= 0 && xSource+1 < imageWidth && connectivityMap [ySource-1][xSource+1] == -150){
                                connectivityMap [ySource-1][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (xSource+1 < imageWidth && connectivityMap [ySource][xSource+1] == -150){
                                connectivityMap [ySource][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                            if (ySource+1 > imageWidth && xSource+1 < imageWidth && connectivityMap [ySource+1][xSource+1] == -150){
                                connectivityMap [ySource+1][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < imageWidth && connectivityMap [ySource+1][xSource] == -150){
                                connectivityMap [ySource+1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < imageWidth && xSource-1 >= 0 && connectivityMap [ySource+1][xSource-1] == -150){
                                connectivityMap [ySource+1][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (xSource-1 >= 0 && connectivityMap [ySource][xSource-1] == -150){
                                connectivityMap [ySource][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                        }
                        
                        connectAnalysisCount = connectAnalysisTempCount;
                        
                        if (connectAnalysisCount == 0) terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                }
            }
        }
    }
    
    //for (int counterA = 870; counterA < 1000; counterA++){
    //	for (int counterB = 870; counterB < 930; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
    //	cout<<" connectivityMap "<<counterA<<endl;
    //}
    
    //------Determine number of pixels------
    int *connectedPix = new int [connectivityNumber+50];
    
    for (int counter1 = 0; counter1 <= connectivityNumber; counter1++) connectedPix [counter1] = 0;
    
    for (int counterY = 0; counterY < imageWidth; counterY++){
        for (int counterX = 0; counterX < imageWidth; counterX++){
            if (connectivityMap [counterY][counterX] != 0) connectedPix [connectivityMap [counterY][counterX]]++;
        }
    }
    
    int maxVectorNumber = 0;
    
    for (int counter1 = 0; counter1 < forNextConnectivityCount/5; counter1++){
        if (arrayForNextConnectivity [counter1*5+3] > maxVectorNumber) maxVectorNumber = arrayForNextConnectivity [counter1*5+3];
    }
    
    //------Map up-date, Connect numbers are "MINUS"------
    int connectTemp = 1;
    
    for (int counter1 = 1; counter1 <= connectivityNumber; counter1++){
        if (connectedPix [counter1] < 30) connectedPix [counter1] = 0;
        else{
            
            connectedPix [counter1] = connectTemp;
            connectTemp++;
        }
    }
    
    int connectTempHold = connectTemp;
    
    for (int counterY = 0; counterY < imageWidth; counterY++){
        for (int counterX = 0; counterX < imageWidth; counterX++){
            connectTemp = connectivityMap [counterY][counterX];
            
            if (connectedPix [connectTemp] != 0) connectivityMap [counterY][counterX] = (connectedPix [connectTemp]+maxVectorNumber)*-1;
            else connectivityMap [counterY][counterX] = 0;
        }
    }
    
    delete [] connectedPix;
    
    //for (int counterA = 0; counterA < 400; counterA++){
    //	for (int counterB = 0; counterB < 400; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
    //	cout<<" connectMap2 "<<counterA<<endl;
    //}
    
    //======connectivityMap holds map made from image applied second TH, numbers are minus==========
    
    if (subjectArray == 2){
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++) arrayImageConnectivityB [counterY][counterX] = connectivityMap [counterY][counterX];
        }
    }
    
    if (subjectArray == 3){
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++) arrayImageConnectivityC [counterY][counterX] = connectivityMap [counterY][counterX];
        }
    }
    
    if (subjectArray == 4){
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++) arrayImageConnectivityD [counterY][counterX] = connectivityMap [counterY][counterX];
        }
    }
    
    //------Map making, arrayForNext Connectivity data------
    int **associatedInfo = new int *[maxVectorNumber+4];
    
    for (int counter1 = 0; counter1 < maxVectorNumber+4; counter1++) associatedInfo [counter1] = new int [4];
    
    for (int counter1 = 1; counter1 < maxVectorNumber+1; counter1++){
        associatedInfo [counter1][0] = 0;
        associatedInfo [counter1][1] = 0;
        associatedInfo [counter1][2] = 0;
        associatedInfo [counter1][3] = 0;
    }
    
    int **vectorSourceB1 = new int *[imageWidth+4];
    
    for (int counter1 = 0; counter1 < imageWidth+4; counter1++) vectorSourceB1 [counter1] = new int [imageWidth+4];
    
    for (int counterY = 0; counterY < imageWidth+2; counterY++){
        for (int counterX = 0; counterX < imageWidth+2; counterX++) vectorSourceB1 [counterY][counterX] = 0;
    }
    
    for (int counter1 = 0; counter1 < forNextConnectivityCount/5; counter1++){
        vectorSourceB1 [arrayForNextConnectivity [counter1*5+1]+1][arrayForNextConnectivity [counter1*5]+1] = arrayForNextConnectivity [counter1*5+3];
    }
    
    for (int counter1 = 0; counter1 < forNextConnectivityAssCount/6; counter1++){
        associatedInfo [arrayForNextConnectivityAss [counter1*6]][0] = arrayForNextConnectivityAss [counter1*6+1];
        associatedInfo [arrayForNextConnectivityAss [counter1*6]][1] = arrayForNextConnectivityAss [counter1*6+2];
        associatedInfo [arrayForNextConnectivityAss [counter1*6]][2] = arrayForNextConnectivityAss [counter1*6+3];
        associatedInfo [arrayForNextConnectivityAss [counter1*6]][3] = arrayForNextConnectivityAss [counter1*6+4];
    }
    
    //------Connectivity Analysis, Fill inside, outside: "Minus 1"------
    connectivityNumber = -3;
    
    for (int counterY = 0; counterY < imageWidth+2; counterY++){
        for (int counterX = 0; counterX < imageWidth+2; counterX++){
            if (vectorSourceB1 [counterY][counterX] == 0){
                connectivityNumber = connectivityNumber+2;
                
                if (connectivityNumber >= 1){
                    if (counterY-1 >= 0 && vectorSourceB1 [counterY-1][counterX] > 0){
                        connectivityNumber = vectorSourceB1 [counterY-1][counterX], vectorSourceB1 [counterY-1][counterX] = connectivityNumber;
                    }
                    if (counterX+1 < imageWidth+2 && vectorSourceB1 [counterY][counterX+1] > 0){
                        connectivityNumber = vectorSourceB1 [counterY][counterX+1], vectorSourceB1 [counterY][counterX+1] = connectivityNumber;
                    }
                    if (counterY+1 < imageWidth+2 && vectorSourceB1 [counterY+1][counterX] > 0){
                        connectivityNumber = vectorSourceB1 [counterY+1][counterX], vectorSourceB1 [counterY+1][counterX] = connectivityNumber;
                    }
                    if (counterX-1 >= 0 && vectorSourceB1 [counterY][counterX-1] > 0){
                        connectivityNumber = vectorSourceB1 [counterY][counterX-1], vectorSourceB1 [counterY][counterX-1] = connectivityNumber;
                    }
                }
                
                connectAnalysisCount = 0;
                
                if (counterY-1 >= 0 && vectorSourceB1 [counterY-1][counterX] == 0){
                    vectorSourceB1 [counterY-1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterX+1 < imageWidth+2 && vectorSourceB1 [counterY][counterX+1] == 0){
                    vectorSourceB1 [counterY][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                if (counterY+1 < imageWidth+2 && vectorSourceB1 [counterY+1][counterX] == 0){
                    vectorSourceB1 [counterY+1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterX-1 >= 0 && vectorSourceB1 [counterY][counterX-1] == 0){
                    vectorSourceB1 [counterY][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                
                if (connectAnalysisCount != 0){
                    do{
                        
                        terminationFlag = 1;
                        connectAnalysisTempCount = 0;
                        
                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                            xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                            
                            if (ySource-1 >= 0 && vectorSourceB1 [ySource-1][xSource] == 0){
                                vectorSourceB1 [ySource-1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (xSource+1 < imageWidth+2 && vectorSourceB1 [ySource][xSource+1] == 0){
                                vectorSourceB1 [ySource][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < imageWidth+2 && vectorSourceB1 [ySource+1][xSource] == 0){
                                vectorSourceB1 [ySource+1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (xSource-1 >= 0 && vectorSourceB1 [ySource][xSource-1] == 0){
                                vectorSourceB1 [ySource][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                        }
                        
                        connectAnalysisCount = connectAnalysisTempCount;
                        
                        if (connectAnalysisCount == 0) terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                }
            }
        }
    }
    
    //------Remove MINUS 1------
    for (int counterY = 0; counterY < imageWidth+2; counterY++){
        for (int counterX = 0; counterX < imageWidth+2; counterX++){
            if (vectorSourceB1 [counterY][counterX] == -1) vectorSourceB1 [counterY][counterX] = 0;
        }
    }
    
    connectivityNumber = connectTempHold+maxVectorNumber;
    int largestConnect = 0;
    
    int *connectPixCount = new int [connectivityNumber+50];
    
    for (int counter1 = 0; counter1 < connectivityNumber+1; counter1++) connectPixCount [counter1] = 0;
    
    for (int counterY = 0; counterY < imageWidth; counterY++){
        for (int counterX = 0; counterX < imageWidth; counterX++){
            if ((connectTemp = connectivityMap [counterY][counterX]) < -1) connectPixCount [connectTemp*-1]++;
        }
    }
    
    for (int counter1 = 0; counter1 < connectivityNumber+1; counter1++){
        if (connectPixCount [counter1] > largestConnect) largestConnect = connectPixCount [counter1];
    }
    
    delete [] connectPixCount;
    
    //------Overlay connect from arrayForNextConnectivity to connect 150 Map (ForNextConnect +, 150 Map, -)------
    for (int counterY = 0; counterY < imageWidth+2; counterY++){
        for (int counterX = 0; counterX < imageWidth+2; counterX++){
            if (vectorSourceB1 [counterY][counterX] != 0) connectivityMap [counterY-1][counterX-1] = vectorSourceB1 [counterY][counterX];
        }
    }
    
    for (int counter1 = 0; counter1 < imageWidth+4; counter1++){
        delete [] vectorSourceB1 [counter1];
        delete [] delaySourceMap [counter1];
        delete [] delayMap [counter1];
    }
    
    delete [] vectorSourceB1;
    delete [] delaySourceMap;
    delete [] delayMap;
    
    int **connectivityMapExpansion = new int *[imageWidth+4];
    for (int counter1 = 0; counter1 < imageWidth+4; counter1++) connectivityMapExpansion [counter1] = new int [imageWidth+4];
    
    for (int counterY = 0; counterY < imageWidth; counterY++){
        for (int counterX = 0; counterX < imageWidth; counterX++) connectivityMapExpansion [counterY][counterX] = 0;
    }
    
    for (int counter1 = 0; counter1 < 2; counter1++){
        for (int counterY = 0; counterY < imageWidth; counterY++){
            for (int counterX = 0; counterX < imageWidth; counterX++){
                if (connectivityMap [counterY][counterX] > 0){
                    if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMap [counterY-1][counterX-1] < 0) connectivityMapExpansion [counterY-1][counterX-1] = connectivityMap [counterY][counterX];
                    if (counterY-1 >= 0 && connectivityMap [counterY-1][counterX] < 0) connectivityMap [counterY-1][counterX] = connectivityMap [counterY][counterX];
                    if (counterY-1 >= 0 && counterX+1 < imageWidth  && connectivityMap [counterY-1][counterX+1] < 0) connectivityMapExpansion [counterY-1][counterX+1] = connectivityMap [counterY][counterX];
                    if (counterX+1 < imageWidth && connectivityMap [counterY][counterX+1] < 0) connectivityMapExpansion [counterY][counterX+1] = connectivityMap [counterY][counterX];
                    if (counterY+1 < imageWidth && counterX+1 < imageWidth && connectivityMap [counterY+1][counterX+1] < 0) connectivityMapExpansion [counterY+1][counterX+1] = connectivityMap [counterY][counterX];
                    if (counterY+1 < imageWidth && connectivityMap [counterY+1][counterX] < 0) connectivityMapExpansion [counterY+1][counterX] = connectivityMap [counterY][counterX];
                    if (counterY+1 < imageWidth && counterX-1 >= 0 && connectivityMap [counterY+1][counterX-1] < 0) connectivityMapExpansion [counterY+1][counterX-1] = connectivityMap [counterY][counterX];
                    if (counterX-1 >= 0 && connectivityMap [counterY][counterX-1] < 0) connectivityMapExpansion [counterY][counterX-1] = connectivityMap [counterY][counterX];
                }
            }
        }
        
        for (int counterY2 = 0; counterY2 < imageWidth; counterY2++){
            for (int counterX2 = 0; counterX2 < imageWidth; counterX2++){
                if (connectivityMapExpansion [counterY2][counterX2] != 0) connectivityMap [counterY2][counterX2] = connectivityMapExpansion [counterY2][counterX2];
            }
        }
    }
    
    for (int counter1 = 0; counter1 < imageWidth+4; counter1++) delete [] connectivityMapExpansion [counter1];
    delete [] connectivityMapExpansion;
    
    //------Extract < 0 Connect and set to arrayOutlineVectorSource4, will be send to Outline vector to get outline of remaining connect------
    for (int counterY = 0; counterY < imageWidth; counterY++){
        for (int counterX = 0; counterX < imageWidth; counterX++){
            if (connectivityMap [counterY][counterX] < 0) arrayImageRemaining [counterY][counterX] = -150;
            else arrayImageRemaining [counterY][counterX] = 0;
        }
    }
    
    //for (int counterA = 1800; counterA < 2000; counterA++){
    //	for (int counterB = 350; counterB < 450; counterB++) cout<<" "<<arrayImageRemaining [counterA][counterB];
    //	cout<<" arrayImageRemaining "<<counterA<<endl;
    //}
    
    //------Connectivity Analysis Existing Connect------
    int **newConnectivityMap = new int *[imageWidth+4];
    int **newConnectivityMap4 = new int *[imageWidth+4];
    int **remainingPixelMap = new int *[imageWidth+4];
    
    for (int counter1 = 0; counter1 < imageWidth+4; counter1++){
        newConnectivityMap [counter1] = new int [imageWidth+4];
        newConnectivityMap4 [counter1] = new int [imageWidth+4];
        remainingPixelMap [counter1] = new int [imageWidth+4];
    }
    
    for (int counterY = 0; counterY < imageWidth; counterY++){
        for (int counterX = 0; counterX < imageWidth; counterX++){
            newConnectivityMap [counterY][counterX] = 0;
            newConnectivityMap4 [counterY][counterX] = 0;
        }
    }
    
    for (int counterY = 0; counterY < imageWidth+2; counterY++){
        for (int counterX = 0; counterX < imageWidth+2; counterX++) remainingPixelMap [counterY][counterX] = 0;
    }
    
    int *arrayNewConstructedLinesX = new int [largestConnect*2+50];
    int *arrayNewConstructedLinesY = new int [largestConnect*2+50];
    
    for (int counterY = 0; counterY < imageWidth; counterY++){
        for (int counterX = 0; counterX < imageWidth; counterX++){
            if (connectivityMap [counterY][counterX] > 0) newConnectivityMap [counterY][counterX] = connectivityMap [counterY][counterX];
            else newConnectivityMap [counterY][counterX] = 0;
        }
    }
    
    //for (int counterA = 870; counterA < 1000; counterA++){
    //	for (int counterB = 870; counterB < 930; counterB++) cout<<" "<<newConnectivityMap [counterA][counterB];
    //	cout<<" newConnectivityMap "<<counterA<<endl;
    //}
    
    outlineExistCount = 0;
    outlineExistAssCount = 0;
    
    int horizontalLength = 0;
    int verticalLength = 0;
    int dimension = 0;
    int horizontalStart = 0;
    int verticalStart = 0;
    int valueTempX = 0;
    int valueTempY = 0;
    int oneCount = 0;
    int xPositionTemp = 0;
    int yPositionTemp = 0;
    int constructedLineCount = 0;
    int firstCount = 0;
    int shapeCheckFlag = 0;
    int multipleFaceCount = 0;
    int findFlag = 0;
    int firstProcess = 0;
    int largestConnectNo = 0;
    int removeFlag = 0;
    
    int *maxMinXY = new int [maxVectorNumber*4+20];
    
    for (int counter1 = 1; counter1 < maxVectorNumber+1; counter1++){
        maxMinXY [counter1*4] = 0;
        maxMinXY [counter1*4+1] = 100000;
        maxMinXY [counter1*4+2] = 0;
        maxMinXY [counter1*4+3] = 100000;
    }
    
    for (int counterY = 0; counterY < imageWidth; counterY++){
        for (int counterX = 0; counterX < imageWidth; counterX++){
            if (newConnectivityMap [counterY][counterX] != 0){
                if (maxMinXY [newConnectivityMap [counterY][counterX]*4] < counterX) maxMinXY [newConnectivityMap [counterY][counterX]*4] = counterX;
                if (maxMinXY [newConnectivityMap [counterY][counterX]*4+1] > counterX) maxMinXY [newConnectivityMap [counterY][counterX]*4+1] = counterX;
                if (maxMinXY [newConnectivityMap [counterY][counterX]*4+2] < counterY) maxMinXY [newConnectivityMap [counterY][counterX]*4+2] = counterY;
                if (maxMinXY [newConnectivityMap [counterY][counterX]*4+3] > counterY) maxMinXY [newConnectivityMap [counterY][counterX]*4+3] = counterY;
            }
        }
    }
    
    for (int counter1 = 1; counter1 < maxVectorNumber+1; counter1++){
        //------Determine the dimension of cell------
        horizontalLength = (maxMinXY [counter1*4]-maxMinXY [counter1*4+1])/2*2;
        verticalLength = (maxMinXY [counter1*4+2]-maxMinXY [counter1*4+3])/2*2;
        dimension = 0;
        
        if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
        else if (horizontalLength < verticalLength) dimension = verticalLength+30;
        
        dimension = (dimension/2)*2;
        
        horizontalStart = maxMinXY [counter1*4+1]-(dimension-horizontalLength)/2;
        verticalStart = maxMinXY [counter1*4+3]-(dimension-verticalLength)/2;
        
        if (dimension > 30){
            int **newConnectivityMap2 = new int *[dimension+4];
            int **newConnectivityMap3 = new int *[dimension+4];
            
            for (int counter2 = 0; counter2 < dimension+4; counter2++){
                newConnectivityMap2 [counter2] = new int [dimension+4];
                newConnectivityMap3 [counter2] = new int [dimension+4];
            }
            
            for (int counterY = 0; counterY < dimension+4; counterY++){
                for (int counterX = 0; counterX < dimension+4; counterX++){
                    newConnectivityMap2 [counterY][counterX] = 0;
                    newConnectivityMap3 [counterY][counterX] = 0;
                }
            }
            
            for (int counterY = maxMinXY [counter1*4+3]; counterY < maxMinXY [counter1*4+2]; counterY++){
                for (int counterX = maxMinXY [counter1*4+1]; counterX < maxMinXY [counter1*4]; counterX++){
                    if (newConnectivityMap [counterY][counterX] == counter1){
                        if (counterX-horizontalStart < 0) valueTempX = 0;
                        else if (counterX-horizontalStart >= dimension) valueTempX = dimension-1;
                        else valueTempX = counterX-horizontalStart;
                        
                        if (counterY-verticalStart < 0) valueTempY = 0;
                        else if (counterY-verticalStart >= dimension) valueTempY = dimension-1;
                        else valueTempY = counterY-verticalStart;
                        
                        newConnectivityMap2 [valueTempY][valueTempX] = 1;
                    }
                }
            }
            
            connectivityNumber = 1;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (newConnectivityMap2 [counterY][counterX] == 0){
                        connectivityNumber++;
                        newConnectivityMap2 [counterY][counterX] = connectivityNumber;
                        
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && newConnectivityMap2 [counterY-1][counterX] == 0){
                            newConnectivityMap2 [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension && newConnectivityMap2 [counterY][counterX+1] == 0){
                            newConnectivityMap2 [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && newConnectivityMap2 [counterY+1][counterX] == 0){
                            newConnectivityMap2 [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && newConnectivityMap2 [counterY][counterX-1] == 0){
                            newConnectivityMap2 [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                    xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                    
                                    if (ySource-1 >= 0 && newConnectivityMap2 [ySource-1][xSource] == 0){
                                        newConnectivityMap2 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && newConnectivityMap2 [ySource][xSource+1] == 0){
                                        newConnectivityMap2 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && newConnectivityMap2 [ySource+1][xSource] == 0){
                                        newConnectivityMap2 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && newConnectivityMap2 [ySource][xSource-1] == 0){
                                        newConnectivityMap2 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                    connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<newConnectivityMap2 [counterA][counterB];
            //	cout<<" newConnectivityMap2 "<<counterA<<endl;
            //}
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (newConnectivityMap2 [counterY][counterX] != 2){
                        oneCount = 0;
                        
                        if (counterY-1 >= 0 && newConnectivityMap2 [counterY-1][counterX] == 2) oneCount++;
                        if (counterX+1 < dimension && newConnectivityMap2 [counterY][counterX+1] == 2) oneCount++;
                        if (counterY+1 < dimension && newConnectivityMap2 [counterY+1][counterX] == 2) oneCount++;
                        if (counterX-1 >= 0 && newConnectivityMap2 [counterY][counterX-1] == 2) oneCount++;
                        
                        if (oneCount != 0) newConnectivityMap2 [counterY][counterX] = -1;
                        else newConnectivityMap2 [counterY][counterX] = 1;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<newConnectivityMap2 [counterA][counterB];
            //	cout<<" newConnectivityMap2"<<counterA<<endl;
            //}
            
            xPositionTemp = -1;
            yPositionTemp = -1;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (newConnectivityMap2 [counterY][counterX] == -1){
                        oneCount = 0;
                        
                        if (counterY-1 >= 0 && newConnectivityMap2 [counterY-1][counterX] == 1) oneCount++;
                        if (counterX+1 < dimension && newConnectivityMap2 [counterY][counterX+1] == 1) oneCount++;
                        if (counterY+1 < dimension && newConnectivityMap2 [counterY+1][counterX] == 1) oneCount++;
                        if (counterX-1 >= 0 && newConnectivityMap2 [counterY][counterX-1] == 1) oneCount++;
                        
                        if (oneCount != 0){
                            newConnectivityMap3 [counterY][counterX] = 1;
                            xPositionTemp = counterX;
                            yPositionTemp = counterY;
                        }
                        else newConnectivityMap2 [counterY][counterX] = 2;
                    }
                }
            }
            
            if (xPositionTemp != -1 && yPositionTemp != -1){
                constructedLineCount = 0;
                firstCount = 0;
                shapeCheckFlag = 0;
                multipleFaceCount = 0;
                
                if (xPositionTemp+1 < dimension && newConnectivityMap3 [yPositionTemp][xPositionTemp+1] == 1) multipleFaceCount++;
                if (xPositionTemp+1 < dimension && yPositionTemp+1 < dimension && newConnectivityMap3 [yPositionTemp+1][xPositionTemp+1] == 1) multipleFaceCount++;
                if (yPositionTemp+1 < dimension && newConnectivityMap3 [yPositionTemp+1][xPositionTemp] == 1) multipleFaceCount++;
                if (xPositionTemp-1 >= 0 && yPositionTemp+1 < dimension && newConnectivityMap3 [yPositionTemp+1][xPositionTemp-1] == 1) multipleFaceCount++;
                if (xPositionTemp-1 >= 0 && newConnectivityMap3 [yPositionTemp][xPositionTemp-1] == 1) multipleFaceCount++;
                if (xPositionTemp-1 >= 0 && yPositionTemp-1 >= 0 && newConnectivityMap3 [yPositionTemp-1][xPositionTemp-1] == 1) multipleFaceCount++;
                if (yPositionTemp-1 >= 0 && newConnectivityMap3 [yPositionTemp-1][xPositionTemp] == 1) multipleFaceCount++;
                if (xPositionTemp+1 < dimension && yPositionTemp-1 >= 0 && newConnectivityMap3 [yPositionTemp-1][xPositionTemp+1] == 1) multipleFaceCount++;
                
                if (multipleFaceCount >= 3) shapeCheckFlag = 1;
                else{
                    
                    newConnectivityMap3 [yPositionTemp][xPositionTemp] = -1;
                    arrayNewConstructedLinesX [constructedLineCount] = xPositionTemp+horizontalStart;
                    arrayNewConstructedLinesY [constructedLineCount] = yPositionTemp+verticalStart;
                    constructedLineCount++;
                }
                
                if (shapeCheckFlag == 0){
                    do{
                        
                        findFlag = 0;
                        terminationFlag = 0;
                        multipleFaceCount = 0;
                        
                        if (xPositionTemp+1 < dimension && newConnectivityMap3 [yPositionTemp][xPositionTemp+1] == 1) multipleFaceCount++;
                        if (xPositionTemp+1 < dimension && yPositionTemp+1 < dimension && newConnectivityMap3 [yPositionTemp+1][xPositionTemp+1] == 1) multipleFaceCount++;
                        if (yPositionTemp+1 < dimension && newConnectivityMap3 [yPositionTemp+1][xPositionTemp] == 1) multipleFaceCount++;
                        if (xPositionTemp-1 >= 0 && yPositionTemp+1 < dimension && newConnectivityMap3 [yPositionTemp+1][xPositionTemp-1] == 1) multipleFaceCount++;
                        if (xPositionTemp-1 >= 0 && newConnectivityMap3 [yPositionTemp][xPositionTemp-1] == 1) multipleFaceCount++;
                        if (xPositionTemp-1 >= 0 && yPositionTemp-1 >= 0 && newConnectivityMap3 [yPositionTemp-1][xPositionTemp-1] == 1) multipleFaceCount++;
                        if (yPositionTemp-1 >= 0 && newConnectivityMap3 [yPositionTemp-1][xPositionTemp] == 1) multipleFaceCount++;
                        if (xPositionTemp+1 < dimension && yPositionTemp-1 >= 0 && newConnectivityMap3 [yPositionTemp-1][xPositionTemp+1] == 1) multipleFaceCount++;
                        
                        if (multipleFaceCount >= 2 && firstCount == 1) shapeCheckFlag = 1;
                        
                        if ((firstCount == 0 && multipleFaceCount == 2) || (firstCount == 1 && multipleFaceCount == 1) || (firstCount == 1 && multipleFaceCount == 0)){
                            if (xPositionTemp+1 < dimension){
                                if (newConnectivityMap3 [yPositionTemp][xPositionTemp+1] == 1){
                                    newConnectivityMap3 [yPositionTemp][xPositionTemp+1] = -1;
                                    arrayNewConstructedLinesX [constructedLineCount] = xPositionTemp+1+horizontalStart;
                                    arrayNewConstructedLinesY [constructedLineCount] = yPositionTemp+verticalStart;
                                    constructedLineCount++;
                                    xPositionTemp = xPositionTemp+1, terminationFlag = 1, findFlag = 1;
                                }
                            }
                            
                            if (xPositionTemp+1 < dimension && yPositionTemp+1 < dimension && findFlag == 0){
                                if (newConnectivityMap3 [yPositionTemp+1][xPositionTemp+1] == 1){
                                    newConnectivityMap3 [yPositionTemp+1][xPositionTemp+1] = -1;
                                    arrayNewConstructedLinesX [constructedLineCount] = xPositionTemp+1+horizontalStart;
                                    arrayNewConstructedLinesY [constructedLineCount] = yPositionTemp+1+verticalStart;
                                    constructedLineCount++;
                                    xPositionTemp = xPositionTemp+1, yPositionTemp = yPositionTemp+1, terminationFlag = 1, findFlag = 1;
                                }
                            }
                            
                            if (yPositionTemp+1 < dimension && findFlag == 0){
                                if (newConnectivityMap3 [yPositionTemp+1][xPositionTemp] == 1){
                                    newConnectivityMap3 [yPositionTemp+1][xPositionTemp] = -1;
                                    arrayNewConstructedLinesX [constructedLineCount] = xPositionTemp+horizontalStart;
                                    arrayNewConstructedLinesY [constructedLineCount] = yPositionTemp+1+verticalStart;
                                    constructedLineCount++;
                                    yPositionTemp = yPositionTemp+1, terminationFlag = 1, findFlag = 1;
                                }
                            }
                            
                            if (xPositionTemp-1 >= 0 && yPositionTemp+1 < dimension && findFlag == 0){
                                if (newConnectivityMap3 [yPositionTemp+1][xPositionTemp-1] == 1){
                                    newConnectivityMap3 [yPositionTemp+1][xPositionTemp-1] = -1;
                                    arrayNewConstructedLinesX [constructedLineCount] = xPositionTemp-1+horizontalStart;
                                    arrayNewConstructedLinesY [constructedLineCount] = yPositionTemp+1+verticalStart;
                                    constructedLineCount++;
                                    xPositionTemp = xPositionTemp-1, yPositionTemp = yPositionTemp+1, terminationFlag = 1, findFlag = 1;
                                }
                            }
                            
                            if (xPositionTemp-1 >= 0 && findFlag == 0){
                                if (newConnectivityMap3 [yPositionTemp][xPositionTemp-1] == 1){
                                    newConnectivityMap3 [yPositionTemp][xPositionTemp-1] = -1;
                                    arrayNewConstructedLinesX [constructedLineCount] = xPositionTemp-1+horizontalStart;
                                    arrayNewConstructedLinesY [constructedLineCount] = yPositionTemp+verticalStart;
                                    constructedLineCount++;
                                    xPositionTemp = xPositionTemp-1, terminationFlag = 1, findFlag = 1;
                                }
                            }
                            
                            if (xPositionTemp-1 >= 0 && yPositionTemp-1 >= 0 && findFlag == 0){
                                if (newConnectivityMap3 [yPositionTemp-1][xPositionTemp-1] == 1){
                                    newConnectivityMap3 [yPositionTemp-1][xPositionTemp-1] = -1;
                                    arrayNewConstructedLinesX [constructedLineCount] = xPositionTemp-1+horizontalStart;
                                    arrayNewConstructedLinesY [constructedLineCount] = yPositionTemp-1+verticalStart;
                                    constructedLineCount++;
                                    xPositionTemp = xPositionTemp-1, yPositionTemp = yPositionTemp-1, terminationFlag = 1, findFlag = 1;
                                }
                            }
                            
                            if (yPositionTemp-1 >= 0 && findFlag == 0){
                                if (newConnectivityMap3 [yPositionTemp-1][xPositionTemp] == 1){
                                    newConnectivityMap3 [yPositionTemp-1][xPositionTemp] = -1;
                                    arrayNewConstructedLinesX [constructedLineCount] = xPositionTemp+horizontalStart;
                                    arrayNewConstructedLinesY [constructedLineCount] = yPositionTemp-1+verticalStart;
                                    constructedLineCount++;
                                    yPositionTemp = yPositionTemp-1, terminationFlag = 1, findFlag = 1;
                                }
                            }
                            
                            if (xPositionTemp+1 < dimension && yPositionTemp-1 >= 0 && findFlag == 0){
                                if (newConnectivityMap3 [yPositionTemp-1][xPositionTemp+1] == 1){
                                    newConnectivityMap3 [yPositionTemp-1][xPositionTemp+1] = -1;
                                    arrayNewConstructedLinesX [constructedLineCount] = xPositionTemp+1+horizontalStart;
                                    arrayNewConstructedLinesY [constructedLineCount] = yPositionTemp-1+verticalStart;
                                    constructedLineCount++;
                                    xPositionTemp = xPositionTemp+1, yPositionTemp = yPositionTemp-1, terminationFlag = 1;
                                }
                            }
                        }
                        else terminationFlag = 0;
                        
                        if (firstCount == 0) firstCount = 1;
                        
                    } while (terminationFlag == 1);
                }
                
                if (shapeCheckFlag == 1){
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (newConnectivityMap3 [counterY2][counterX2] == -1) newConnectivityMap3 [counterY2][counterX2] = 1;
                        }
                    }
                    
                    int *connectAnalysisX2 = new int [dimension*4];
                    int *connectAnalysisY2 = new int [dimension*4];
                    int *connectAnalysisTempX2 = new int [dimension*4];
                    int *connectAnalysisTempY2 = new int [dimension*4];
                    
                    connectivityNumber = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (newConnectivityMap3 [counterY2][counterX2] == 0){
                                connectivityNumber--;
                                connectAnalysisCount = 0;
                                
                                newConnectivityMap3 [counterY2][counterX2] = connectivityNumber;
                                
                                if (counterY2-1 >= 0 && newConnectivityMap3 [counterY2-1][counterX2] == 0){
                                    newConnectivityMap3 [counterY2-1][counterX2] = connectivityNumber;
                                    connectAnalysisX2 [connectAnalysisCount] = counterX2, connectAnalysisY2 [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                }
                                if (counterX2+1 < dimension && newConnectivityMap3 [counterY2][counterX2+1] == 0){
                                    newConnectivityMap3 [counterY2][counterX2+1] = connectivityNumber;
                                    connectAnalysisX2 [connectAnalysisCount] = counterX2+1, connectAnalysisY2 [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                if (counterY2+1 < dimension && newConnectivityMap3 [counterY2+1][counterX2] == 0){
                                    newConnectivityMap3 [counterY2+1][counterX2] = connectivityNumber;
                                    connectAnalysisX2 [connectAnalysisCount] = counterX2, connectAnalysisY2 [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                }
                                if (counterX2-1 >= 0 && newConnectivityMap3 [counterY2][counterX2-1] == 0){
                                    newConnectivityMap3 [counterY2][counterX2-1] = connectivityNumber;
                                    connectAnalysisX2 [connectAnalysisCount] = counterX2-1, connectAnalysisY2 [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                            xSource = connectAnalysisX2 [counter2], ySource = connectAnalysisY2 [counter2];
                                            
                                            if (ySource-1 >= 0 && newConnectivityMap3 [ySource-1][xSource] == 0){
                                                newConnectivityMap3 [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX2 [connectAnalysisTempCount] = xSource, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension && newConnectivityMap3 [ySource][xSource+1] == 0){
                                                newConnectivityMap3 [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX2 [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension && newConnectivityMap3 [ySource+1][xSource] == 0){
                                                newConnectivityMap3 [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX2 [connectAnalysisTempCount] = xSource, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && newConnectivityMap3 [ySource][xSource-1] == 0){
                                                newConnectivityMap3 [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX2 [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY2 [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                            connectAnalysisX2 [counter2] = connectAnalysisTempX2 [counter2], connectAnalysisY2 [counter2] = connectAnalysisTempY2 [counter2];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    delete [] connectAnalysisX2;
                    delete [] connectAnalysisY2;
                    delete [] connectAnalysisTempX2;
                    delete [] connectAnalysisTempY2;
                    
                    //------Remove connectivity groups, which attach edge, extract inner part of Linked Line------
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (newConnectivityMap3 [counterY2][counterX2] == -1) newConnectivityMap3 [counterY2][counterX2] = 0;
                        }
                    }
                    
                    //------Determine number of pixels------
                    connectivityNumber = connectivityNumber*-1;
                    
                    connectedPix = new int [connectivityNumber+50];
                    for (int counter2 = 0; counter2 <= connectivityNumber; counter2++) connectedPix [counter2] = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (newConnectivityMap3 [counterY2][counterX2] < -1) connectedPix [newConnectivityMap3 [counterY2][counterX2]*-1]++;
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension+4; counterY++){
                        for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMap2 [counterY][counterX] = 0;
                    }
                    
                    firstProcess = 0;
                    
                    for (int counter2 = 2; counter2 <= connectivityNumber; counter2++){
                        largestConnect = 0;
                        largestConnectNo = 0;
                        
                        for (int counter3 = 2; counter3 <= connectivityNumber; counter3++){
                            if (connectedPix [counter3] > largestConnect){
                                largestConnect = connectedPix [counter3];
                                largestConnectNo = counter3;
                            }
                        }
                        
                        connectedPix [largestConnectNo] = 0;
                        
                        removeFlag = 0;
                        
                        if (firstProcess == 1){
                            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                    if (newConnectivityMap3 [counterY2][counterX2] == largestConnectNo*-1){
                                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && newConnectivityMap3 [counterY2-1][counterX2-1] == 0) removeFlag = 1;
                                        if (counterY2-1 >= 0 && newConnectivityMap3 [counterY2-1][counterX2] == 0) removeFlag = 1;
                                        if (counterY2-1 >= 0 && counterX2+1 < dimension && newConnectivityMap3 [counterY2-1][counterX2+1] == 0) removeFlag = 1;
                                        if (counterX2+1 < dimension && newConnectivityMap3 [counterY2][counterX2+1] == 0) removeFlag = 1;
                                        if (counterY2+1 < dimension && counterX2+1 < dimension && newConnectivityMap3 [counterY2+1][counterX2+1] == 0) removeFlag = 1;
                                        if (counterY2+1 < dimension && newConnectivityMap3 [counterY2+1][counterX2] == 0) removeFlag = 1;
                                        if (counterY2+1 < dimension && counterX2-1 >= 0 && newConnectivityMap3 [counterY2+1][counterX2-1] == 0) removeFlag = 1;
                                        if (counterX2-1 >= 0 && newConnectivityMap3 [counterY2][counterX2-1] == 0) removeFlag = 1;
                                    }
                                }
                            }
                        }
                        
                        if (removeFlag == 0){
                            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                    if (newConnectivityMap3 [counterY2][counterX2] == largestConnectNo*-1){
                                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && newConnectivityMap3 [counterY2-1][counterX2-1] == 1){
                                            newConnectivityMap2 [counterY2-1][counterX2-1] = 1;
                                            newConnectivityMap3 [counterY2-1][counterX2-1] = 0;
                                        }
                                        if (counterY2-1 >= 0 && newConnectivityMap3 [counterY2-1][counterX2] == 1){
                                            newConnectivityMap2 [counterY2-1][counterX2] = 1;
                                            newConnectivityMap3 [counterY2-1][counterX2] = 0;
                                        }
                                        if (counterY2-1 >= 0 && counterX2+1 < dimension && newConnectivityMap3 [counterY2-1][counterX2+1] == 1){
                                            newConnectivityMap2 [counterY2-1][counterX2+1] = 1;
                                            newConnectivityMap3 [counterY2-1][counterX2+1] = 0;
                                        }
                                        if (counterX2+1 < dimension && newConnectivityMap3 [counterY2][counterX2+1] == 1){
                                            newConnectivityMap2 [counterY2][counterX2+1] = 1;
                                            newConnectivityMap3 [counterY2][counterX2+1] = 0;
                                        }
                                        if (counterY2+1 < dimension && counterX2+1 < dimension && newConnectivityMap3 [counterY2+1][counterX2+1] == 1){
                                            newConnectivityMap2 [counterY2+1][counterX2+1] = 1;
                                            newConnectivityMap3 [counterY2+1][counterX2+1] = 0;
                                        }
                                        if (counterY2+1 < dimension && newConnectivityMap3 [counterY2+1][counterX2] == 1){
                                            newConnectivityMap2 [counterY2+1][counterX2] = 1;
                                            newConnectivityMap3 [counterY2+1][counterX2] = 0;
                                        }
                                        if (counterY2+1 < dimension && counterX2-1 >= 0 && newConnectivityMap3 [counterY2+1][counterX2-1] == 1){
                                            newConnectivityMap2 [counterY2+1][counterX2-1] = 1;
                                            newConnectivityMap3 [counterY2+1][counterX2-1] = 0;
                                        }
                                        if (counterX2-1 >= 0 && newConnectivityMap3 [counterY2][counterX2-1] == 1){
                                            newConnectivityMap2 [counterY2][counterX2-1] = 1;
                                            newConnectivityMap3 [counterY2][counterX2-1] = 0;
                                        }
                                    }
                                }
                            }
                        }
                        
                        if (removeFlag == 1){
                            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                    if (newConnectivityMap3 [counterY2][counterX2] == largestConnectNo*-1){
                                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && newConnectivityMap3 [counterY2-1][counterX2-1] == 1){
                                            newConnectivityMap2 [counterY2-1][counterX2-1] = 2;
                                            newConnectivityMap3 [counterY2-1][counterX2-1] = 0;
                                        }
                                        if (counterY2-1 >= 0 && newConnectivityMap3 [counterY2-1][counterX2] == 1){
                                            newConnectivityMap2 [counterY2-1][counterX2] = 2;
                                            newConnectivityMap3 [counterY2-1][counterX2] = 0;
                                        }
                                        if (counterY2-1 >= 0 && counterX2+1 < dimension && newConnectivityMap3 [counterY2-1][counterX2+1] == 1){
                                            newConnectivityMap2 [counterY2-1][counterX2+1] = 2;
                                            newConnectivityMap3 [counterY2-1][counterX2+1] = 0;
                                        }
                                        if (counterX2+1 < dimension && newConnectivityMap3 [counterY2][counterX2+1] == 1){
                                            newConnectivityMap2 [counterY2][counterX2+1] = 2;
                                            newConnectivityMap3 [counterY2][counterX2+1] = 0;
                                        }
                                        if (counterY2+1 < dimension && counterX2+1 < dimension && newConnectivityMap3 [counterY2+1][counterX2+1] == 1){
                                            newConnectivityMap2 [counterY2+1][counterX2+1] = 2;
                                            newConnectivityMap3 [counterY2+1][counterX2+1] = 0;
                                        }
                                        if (counterY2+1 < dimension && newConnectivityMap3 [counterY2+1][counterX2] == 1){
                                            newConnectivityMap2 [counterY2+1][counterX2] = 2;
                                            newConnectivityMap3 [counterY2+1][counterX2] = 0;
                                        }
                                        if (counterY2+1 < dimension && counterX2-1 >= 0 && newConnectivityMap3 [counterY2+1][counterX2-1] == 1){
                                            newConnectivityMap2 [counterY2+1][counterX2-1] = 2;
                                            newConnectivityMap3 [counterY2+1][counterX2-1] = 0;
                                        }
                                        if (counterX2-1 >= 0 && newConnectivityMap3 [counterY2][counterX2-1] == 1){
                                            newConnectivityMap2 [counterY2][counterX2-1] = 2;
                                            newConnectivityMap3 [counterY2][counterX2-1] = 0;
                                        }
                                    }
                                }
                            }
                        }
                        
                        if (firstProcess == 0) firstProcess = 1;
                    }
                    
                    delete [] connectedPix;
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3 [counterA][counterB];
                    //    cout<<" previousMap3 "<<counterA<<endl;
                    // }
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (newConnectivityMap2 [counterY2][counterX2] == 1){
                                newConnectivityMap3 [counterY2][counterX2] = 1;
                                xPositionTemp = counterX2;
                                yPositionTemp = counterY2;
                            }
                            else newConnectivityMap3 [counterY2][counterX2] = 0;
                        }
                    }
                    
                    //for (int counterA = 760; counterA < 820; counterA++){
                    //    for (int counterB = 150; counterB < 230; counterB++) cout<<" "<<connectivityOutlineMap [counterA][counterB];
                    //     cout<<" connectivityOutlineMap "<<counterA<<endl;
                    // }
                    
                    // for (int counterA = 0; counterA < dimension; counterA++){
                    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3 [counterA][counterB];
                    //     cout<<" previousMap3 "<<counterA<<endl;
                    // }
                    
                    constructedLineCount = 0;
                    
                    newConnectivityMap3 [yPositionTemp][xPositionTemp] = -1;
                    arrayNewConstructedLinesX [constructedLineCount] = xPositionTemp+horizontalStart;
                    arrayNewConstructedLinesY [constructedLineCount] = yPositionTemp+verticalStart;
                    constructedLineCount++;
                    
                    do{
                        
                        findFlag = 0;
                        terminationFlag = 0;
                        
                        if (xPositionTemp+1 < dimension){
                            if (newConnectivityMap3 [yPositionTemp][xPositionTemp+1] == 1){
                                newConnectivityMap3 [yPositionTemp][xPositionTemp+1] = -1;
                                arrayNewConstructedLinesX [constructedLineCount] = xPositionTemp+1+horizontalStart;
                                arrayNewConstructedLinesY [constructedLineCount] = yPositionTemp+verticalStart;
                                constructedLineCount++;
                                xPositionTemp = xPositionTemp+1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        
                        if (xPositionTemp+1 < dimension && yPositionTemp+1 < dimension && findFlag == 0){
                            if (newConnectivityMap3 [yPositionTemp+1][xPositionTemp+1] == 1){
                                newConnectivityMap3 [yPositionTemp+1][xPositionTemp+1] = -1;
                                arrayNewConstructedLinesX [constructedLineCount] = xPositionTemp+1+horizontalStart;
                                arrayNewConstructedLinesY [constructedLineCount] = yPositionTemp+1+verticalStart;
                                constructedLineCount++;
                                xPositionTemp = xPositionTemp+1, yPositionTemp = yPositionTemp+1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        
                        if (yPositionTemp+1 < dimension && findFlag == 0){
                            if (newConnectivityMap3 [yPositionTemp+1][xPositionTemp] == 1){
                                newConnectivityMap3 [yPositionTemp+1][xPositionTemp] = -1;
                                arrayNewConstructedLinesX [constructedLineCount] = xPositionTemp+horizontalStart;
                                arrayNewConstructedLinesY [constructedLineCount] = yPositionTemp+1+verticalStart;
                                constructedLineCount++;
                                yPositionTemp = yPositionTemp+1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        
                        if (xPositionTemp-1 >= 0 && yPositionTemp+1 < dimension && findFlag == 0){
                            if (newConnectivityMap3 [yPositionTemp+1][xPositionTemp-1] == 1){
                                newConnectivityMap3 [yPositionTemp+1][xPositionTemp-1] = -1;
                                arrayNewConstructedLinesX [constructedLineCount] = xPositionTemp-1+horizontalStart;
                                arrayNewConstructedLinesY [constructedLineCount] = yPositionTemp+1+verticalStart;
                                constructedLineCount++;
                                xPositionTemp = xPositionTemp-1, yPositionTemp = yPositionTemp+1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        
                        if (xPositionTemp-1 >= 0 && findFlag == 0){
                            if (newConnectivityMap3 [yPositionTemp][xPositionTemp-1] == 1){
                                newConnectivityMap3 [yPositionTemp][xPositionTemp-1] = -1;
                                arrayNewConstructedLinesX [constructedLineCount] = xPositionTemp-1+horizontalStart;
                                arrayNewConstructedLinesY [constructedLineCount] = yPositionTemp+verticalStart;
                                constructedLineCount++;
                                xPositionTemp = xPositionTemp-1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        
                        if (xPositionTemp-1 >= 0 && yPositionTemp-1 >= 0 && findFlag == 0){
                            if (newConnectivityMap3 [yPositionTemp-1][xPositionTemp-1] == 1){
                                newConnectivityMap3 [yPositionTemp-1][xPositionTemp-1] = -1;
                                arrayNewConstructedLinesX [constructedLineCount] = xPositionTemp-1+horizontalStart;
                                arrayNewConstructedLinesY [constructedLineCount] = yPositionTemp-1+verticalStart;
                                constructedLineCount++;
                                xPositionTemp = xPositionTemp-1, yPositionTemp = yPositionTemp-1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        
                        if (yPositionTemp-1 >= 0 && findFlag == 0){
                            if (newConnectivityMap3 [yPositionTemp-1][xPositionTemp] == 1){
                                newConnectivityMap3 [yPositionTemp-1][xPositionTemp] = -1;
                                arrayNewConstructedLinesX [constructedLineCount] = xPositionTemp+horizontalStart;
                                arrayNewConstructedLinesY [constructedLineCount] = yPositionTemp-1+verticalStart;
                                constructedLineCount++;
                                yPositionTemp = yPositionTemp-1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        
                        if (xPositionTemp+1 < dimension && yPositionTemp-1 >= 0 && findFlag == 0){
                            if (newConnectivityMap3 [yPositionTemp-1][xPositionTemp+1] == 1){
                                newConnectivityMap3 [yPositionTemp-1][xPositionTemp+1] = -1;
                                arrayNewConstructedLinesX [constructedLineCount] = xPositionTemp+1+horizontalStart;
                                arrayNewConstructedLinesY [constructedLineCount] = yPositionTemp-1+verticalStart;
                                constructedLineCount++;
                                xPositionTemp = xPositionTemp+1, yPositionTemp = yPositionTemp-1, terminationFlag = 1;
                            }
                        }
                        
                    } while (terminationFlag == 1);
                }
            }
            
            if (outlineExistCount+constructedLineCount*3 > outlineExistLimit){
                int *arraySourceTemp = new int [outlineExistCount+50];
                for (int counter2 = 0; counter2 < outlineExistCount; counter2++) arraySourceTemp [counter2] = arrayOutlineExist [counter2];
                
                delete [] arrayOutlineExist;
                arrayOutlineExist = new int [outlineExistLimit+constructedLineCount*3+500];
                outlineExistLimit = outlineExistLimit+constructedLineCount*3+500;
                
                for (int counter2 = 0; counter2 < outlineExistCount; counter2++) arrayOutlineExist [counter2] = arraySourceTemp [counter2];
                delete [] arraySourceTemp;
            }
            
            for (int counter2 = 0; counter2 < constructedLineCount; counter2++){
                arrayOutlineExist [outlineExistCount] = counter1, outlineExistCount++;
                arrayOutlineExist [outlineExistCount] = arrayNewConstructedLinesX [counter2], outlineExistCount++;
                arrayOutlineExist [outlineExistCount] = arrayNewConstructedLinesY [counter2], outlineExistCount++;
            }
            
            if (outlineExistAssCount+10 > outlineExistAssLimit){
                int *arraySourceTemp = new int [outlineExistAssCount+50];
                for (int counter2 = 0; counter2 < outlineExistAssCount; counter2++) arraySourceTemp [counter2] = arrayOutlineExistAss [counter2];
                
                delete [] arrayOutlineExistAss;
                arrayOutlineExistAss = new int [outlineExistAssLimit+500];
                outlineExistAssLimit = outlineExistAssLimit+500;
                
                for (int counter2 = 0; counter2 < outlineExistAssCount; counter2++) arrayOutlineExistAss [counter2] = arraySourceTemp [counter2];
                delete [] arraySourceTemp;
            }
            
            arrayOutlineExistAss [outlineExistAssCount] = counter1, outlineExistAssCount++;
            arrayOutlineExistAss [outlineExistAssCount] = associatedInfo [counter1][0], outlineExistAssCount++;
            arrayOutlineExistAss [outlineExistAssCount] = associatedInfo [counter1][1], outlineExistAssCount++;
            arrayOutlineExistAss [outlineExistAssCount] = associatedInfo [counter1][2], outlineExistAssCount++;
            arrayOutlineExistAss [outlineExistAssCount] = associatedInfo [counter1][3], outlineExistAssCount++;
            arrayOutlineExistAss [outlineExistAssCount] = 0, outlineExistAssCount++;
            
            for (int counter2 = 0; counter2 < dimension+4; counter2++){
                delete [] newConnectivityMap2 [counter2];
                delete [] newConnectivityMap3 [counter2];
            }
            
            delete [] newConnectivityMap2;
            delete [] newConnectivityMap3;
        }
    }
    
    delete [] maxMinXY;
    
    for (int counter1 = 0; counter1 < imageWidth+4; counter1++) delete [] newConnectivityMap [counter1];
    delete [] newConnectivityMap;
    
    for (int counter1 = 0; counter1 < maxVectorNumber+4; counter1++) delete [] associatedInfo [counter1];
    delete [] associatedInfo;
    
    delete [] arrayNewConstructedLinesX;
    delete [] arrayNewConstructedLinesY;
    
    //------Remaining Send to OutlineVector------
    connectivityNumber = 0;
    
    for (int counterY = 0; counterY < imageWidth; counterY++){
        for (int counterX = 0; counterX < imageWidth; counterX++){
            if (arrayImageRemaining [counterY][counterX] == -150){
                connectivityNumber++;
                arrayImageRemaining [counterY][counterX] = connectivityNumber;
                connectAnalysisCount = 0;
                
                if (counterY-1 >= 0 && counterX-1 >= 0 && arrayImageRemaining [counterY-1][counterX-1] == -150){
                    arrayImageRemaining [counterY-1][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterY-1 >= 0 && arrayImageRemaining [counterY-1][counterX] == -150){
                    arrayImageRemaining [counterY-1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterY-1 >= 0 && counterX+1 < imageWidth && arrayImageRemaining [counterY-1][counterX+1] == -150){
                    arrayImageRemaining [counterY-1][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterX+1 < imageWidth && arrayImageRemaining [counterY][counterX+1] == -150){
                    arrayImageRemaining [counterY][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                if (counterY+1 < imageWidth && counterX+1 < imageWidth && arrayImageRemaining [counterY+1][counterX+1] == -150){
                    arrayImageRemaining [counterY+1][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterY+1 < imageWidth && arrayImageRemaining [counterY+1][counterX] == -150){
                    arrayImageRemaining [counterY+1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterY+1 < imageWidth && counterX-1 >= 0 && arrayImageRemaining [counterY+1][counterX-1] == -150){
                    arrayImageRemaining [counterY+1][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterX-1 >= 0 && arrayImageRemaining [counterY][counterX-1] == -150){
                    arrayImageRemaining [counterY][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                
                if (connectAnalysisCount != 0){
                    do{
                        
                        terminationFlag = 1;
                        connectAnalysisTempCount = 0;
                        
                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                            xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                            
                            if (ySource-1 >= 0 && xSource-1 >= 0 && arrayImageRemaining [ySource-1][xSource-1] == -150){
                                arrayImageRemaining [ySource-1][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (ySource-1 >= 0 && arrayImageRemaining [ySource-1][xSource] == -150){
                                arrayImageRemaining [ySource-1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (ySource-1 >= 0 && xSource+1 < imageWidth && arrayImageRemaining [ySource-1][xSource+1] == -150){
                                arrayImageRemaining [ySource-1][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (xSource+1 < imageWidth && arrayImageRemaining [ySource][xSource+1] == -150){
                                arrayImageRemaining [ySource][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                            if (ySource+1 > imageWidth && xSource+1 < imageWidth && arrayImageRemaining [ySource+1][xSource+1] == -150){
                                arrayImageRemaining [ySource+1][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < imageWidth && arrayImageRemaining [ySource+1][xSource] == -150){
                                arrayImageRemaining [ySource+1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < imageWidth && xSource-1 >= 0 && arrayImageRemaining [ySource+1][xSource-1] == -150){
                                arrayImageRemaining [ySource+1][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (xSource-1 >= 0 && arrayImageRemaining [ySource][xSource-1] == -150){
                                arrayImageRemaining [ySource][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                        }
                        
                        connectAnalysisCount = connectAnalysisTempCount;
                        
                        if (connectAnalysisCount == 0) terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                }
            }
        }
    }
    
    //for (int counterA = 1800; counterA < 2000; counterA++){
    //	for (int counterB = 350; counterB < 450; counterB++) cout<<" "<<arrayImageRemaining [counterA][counterB];
    //	cout<<" arrayImageRemaining "<<counterA<<endl;
    //}
    
    int typeSubArray = 5;
    
    outlineVector = [[OutlineVector alloc] init];
    [outlineVector outlineVector:typeSubArray:imageWidth];
    
    int additionalVector = 0;
    
    for (int counter1 = 0; counter1 < outlineVectorSourceCount4/5; counter1++){
        remainingPixelMap [arrayOutlineVectorSource4 [counter1*5+2]+1][arrayOutlineVectorSource4 [counter1*5+1]+1] = arrayOutlineVectorSource4 [counter1*5];
        
        if (additionalVector < arrayOutlineVectorSource4 [counter1*5]) additionalVector = arrayOutlineVectorSource4 [counter1*5];
    }
    
    //for (int counterA = 200; counterA < 500; counterA++){
    //	for (int counterB = 200; counterB < 500; counterB++) cout<<" "<<remainingPixelMap [counterA][counterB];
    //	cout<<" remainingPixelMap "<<counterA<<endl;
    //}
    
    connectivityNumber = -3;
    
    for (int counterY = 0; counterY < imageWidth+2; counterY++){
        for (int counterX = 0; counterX < imageWidth+2; counterX++){
            if (remainingPixelMap [counterY][counterX] == 0){
                connectivityNumber = connectivityNumber+2;
                
                if (connectivityNumber >= 1){
                    if (counterY-1 >= 0 && remainingPixelMap [counterY-1][counterX] != -1 && remainingPixelMap [counterY-1][counterX] != 0){
                        connectivityNumber = remainingPixelMap [counterY-1][counterX], remainingPixelMap [counterY-1][counterX] = connectivityNumber;
                    }
                    if (counterX+1 < imageWidth+2 && remainingPixelMap [counterY][counterX+1] != -1 && remainingPixelMap [counterY][counterX+1] != 0){
                        connectivityNumber = remainingPixelMap [counterY][counterX+1], remainingPixelMap [counterY][counterX+1] = connectivityNumber;
                    }
                    if (counterY+1 < imageWidth+2 && remainingPixelMap [counterY+1][counterX] != -1 && remainingPixelMap [counterY+1][counterX] != 0){
                        connectivityNumber = remainingPixelMap [counterY+1][counterX], remainingPixelMap [counterY+1][counterX] = connectivityNumber;
                    }
                    if (counterX-1 >= 0 && remainingPixelMap [counterY][counterX-1] != -1 && remainingPixelMap [counterY][counterX-1] != 0){
                        connectivityNumber = remainingPixelMap [counterY][counterX-1], remainingPixelMap [counterY][counterX-1] = connectivityNumber;
                    }
                }
                
                connectAnalysisCount = 0;
                
                if (counterY-1 >= 0 && remainingPixelMap [counterY-1][counterX] == 0){
                    remainingPixelMap [counterY-1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterX+1 < imageWidth+2 && remainingPixelMap [counterY][counterX+1] == 0){
                    remainingPixelMap [counterY][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                if (counterY+1 < imageWidth+2 && remainingPixelMap [counterY+1][counterX] == 0){
                    remainingPixelMap [counterY+1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterX-1 >= 0 && remainingPixelMap [counterY][counterX-1] == 0){
                    remainingPixelMap [counterY][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                
                if (connectAnalysisCount != 0){
                    do{
                        
                        terminationFlag = 1;
                        connectAnalysisTempCount = 0;
                        
                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                            xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                            
                            if (ySource-1 >= 0 && remainingPixelMap [ySource-1][xSource] == 0){
                                remainingPixelMap [ySource-1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (xSource+1 < imageWidth+2 && remainingPixelMap [ySource][xSource+1] == 0){
                                remainingPixelMap [ySource][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < imageWidth+2 && remainingPixelMap [ySource+1][xSource] == 0){
                                remainingPixelMap [ySource+1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (xSource-1 >= 0 && remainingPixelMap [ySource][xSource-1] == 0){
                                remainingPixelMap [ySource][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                        }
                        
                        connectAnalysisCount = connectAnalysisTempCount;
                        
                        if (connectAnalysisCount == 0) terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                }
            }
        }
    }
    
    delete [] connectAnalysisX;
    delete [] connectAnalysisY;
    delete [] connectAnalysisTempX;
    delete [] connectAnalysisTempY;
    
    for (int counterY = 0; counterY < imageWidth+2; counterY++){
        for (int counterX = 0; counterX < imageWidth+2; counterX++){
            if (remainingPixelMap [counterY][counterX] == -1) remainingPixelMap [counterY][counterX] = 0;
        }
    }
    
    //for (int counterA = 200; counterA < 500; counterA++){
    //	for (int counterB = 200; counterB < 500; counterB++) cout<<" "<<remainingPixelMap [counterA][counterB];
    //	cout<<" remainingPixelMap "<<counterA<<endl;
    //}
    
    //------Determine number of pixels------
    int *connectedPix2 = new int [additionalVector+50];
    
    for (int counter1 = 0; counter1 < additionalVector+1; counter1++) connectedPix2 [counter1] = 0;
    
    for (int counterY = 1; counterY < imageWidth+1; counterY++){
        for (int counterX = 1; counterX < imageWidth+1; counterX++){
            if (remainingPixelMap [counterY][counterX] != 0) connectedPix2 [remainingPixelMap [counterY][counterX]]++;
        }
    }
    
    //------Map up-date------
    int counterTemp2 = 1;
    int cutLimit = 0;
    
    if (typeSubArray == 4) cutLimit = 50;
    else cutLimit = 10;
    
    for (int counter1 = 1; counter1 <= additionalVector; counter1++){
        if (connectedPix2 [counter1] < cutLimit) connectedPix2 [counter1] = 0;
        else connectedPix2 [counter1] = counterTemp2, counterTemp2++;
    }
    
    for (int counterY = 1; counterY < imageWidth+1; counterY++){
        for (int counterX = 1; counterX < imageWidth+1; counterX++){
            if (connectedPix2 [remainingPixelMap [counterY][counterX]] != 0) remainingPixelMap [counterY][counterX] = connectedPix2 [remainingPixelMap [counterY][counterX]]+maxVectorNumber;
            else remainingPixelMap [counterY][counterX] = 0;
        }
    }
    
    if (outlineVectorSourceCount4 > outlineAdditionLimit){
        delete [] arrayOutlineAddition;
        arrayOutlineAddition = new int [outlineVectorSourceCount4+500], outlineAdditionLimit = outlineVectorSourceCount4+500;
    }
    
    outlineAdditionCount = 0;
    
    for (int counter1 = 0; counter1 < outlineVectorSourceCount4/5; counter1++){
        if (connectedPix2 [arrayOutlineVectorSource4 [counter1*5]] != 0){
            arrayOutlineAddition [outlineAdditionCount] = connectedPix2 [arrayOutlineVectorSource4 [counter1*5]]+maxVectorNumber, outlineAdditionCount++;
            arrayOutlineAddition [outlineAdditionCount] = arrayOutlineVectorSource4 [counter1*5+1], outlineAdditionCount++;
            arrayOutlineAddition [outlineAdditionCount] = arrayOutlineVectorSource4 [counter1*5+2], outlineAdditionCount++;
            arrayOutlineAddition [outlineAdditionCount] = arrayOutlineVectorSource4 [counter1*5+3], outlineAdditionCount++;
            arrayOutlineAddition [outlineAdditionCount] = arrayOutlineVectorSource4 [counter1*5+4], outlineAdditionCount++;
        }
    }
    
    delete [] connectedPix2;
    
    //for (int counterA = 200; counterA < 500; counterA++){
    //	for (int counterB = 200; counterB < 500; counterB++) cout<<" "<<remainingPixelMap [counterA][counterB];
    //	cout<<" remainingPixelMap "<<counterA<<endl;
    //}
    
    //for (int counterA = 870; counterA < 1000; counterA++){
    //    for (int counterB = 870; counterB < 930; counterB++) cout<<" "<<newConnectivityMap4 [counterA][counterB];
    //    cout<<" newConnectivityMap4 "<<counterA<<endl;
    //}
    
    for (int counterY = 1; counterY < imageWidth+1; counterY++){
        for (int counterX = 1; counterX < imageWidth+1; counterX++){
            if (remainingPixelMap [counterY][counterX] != 0){
                if (newConnectivityMap4 [counterY-1][counterX-1] == 0) newConnectivityMap4 [counterY-1][counterX-1] = remainingPixelMap [counterY][counterX];
            }
        }
    }
    
    for (int counterY = 0; counterY < imageWidth; counterY++){
        for (int counterX = 0; counterX < imageWidth; counterX++) arrayImageConnectivity [counterY][counterX] = newConnectivityMap4 [counterY][counterX];
    }
    
    //for (int counterA = 870; counterA < 1000; counterA++){
    //	for (int counterB = 870; counterB < 930; counterB++) cout<<" "<<arrayImageConnectivity [counterA][counterB];
    //	cout<<" arrayImageConnectivity "<<counterA<<endl;
    //}
    
    for (int counterY = 0; counterY < imageWidth; counterY++){
        for (int counterX = 0; counterX < imageWidth; counterX++){
            if (connectivityMap [counterY][counterX] != 0) arrayImage150 [counterY][counterX] = rangeMatrix [counterY][counterX];
            else arrayImage150 [counterY][counterX] = 0;
        }
    }
    
    for (int counter1 = 0; counter1 < imageWidth+4; counter1++){
        delete [] connectivityMap [counter1];
        delete [] rangeMatrix [counter1];
        delete [] newConnectivityMap4 [counter1];
        delete [] remainingPixelMap [counter1];
    }
    
    delete [] connectivityMap;
    delete [] rangeMatrix;
    delete [] newConnectivityMap4;
    delete [] remainingPixelMap;
}

@end
