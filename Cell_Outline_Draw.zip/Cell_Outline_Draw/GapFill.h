//
// GapFill.h
// Cell_Outline_Draw
//
// Created by Masahiko Sato on 20/12/12.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#ifndef GAPFILL_H
#define GAPFILL_H
#import "Controller.h"
#endif

@interface GapFill : NSObject {
}

-(void)gapFilling:(int)originX :(int)originY :(int)destinationX :(int)destinationY;
-(int)gapChaseingMain:(int)midStartXMap2 :(int)midStartYMap2 :(int)midEndXMap2 :(int)midEndYMap2 :(int)dimension :(int)connectivityNumber;
-(void)returnDataUpDate;

@end
