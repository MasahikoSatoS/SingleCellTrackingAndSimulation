//
//  TerminationMonitor.h
//  XY_Map
//
//  Created by Masahiko Sato on 12/12/16.
//
//

#ifndef TERMINATIONMONITOR_H
#define TERMINATIONMONITOR_H
#import "Controller.h"
#endif

@interface TerminationMonitor : NSObject{
    NSTimer *commTimer;
}

-(id)init;
-(void)dealloc;
-(void)processControl;

@end
