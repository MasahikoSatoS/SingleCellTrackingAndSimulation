//
//  SnapHandle.h
//  XY_Map
//
//  Created by Masahiko Sato on 2014-08-23.
//
//

#ifndef SNAPHANDLE_H
#define SNAPHANDLE_H
#import "Controller.h" 
#endif

@interface SnapHandle : NSObject <NSTextFieldDelegate> {
    int stepperLimitXL1; //Stepper limit
    int stepperLimitXH1; //Stepper limit
    int stepperLimitYL1; //Stepper limit
    int stepperLimitYH1; //Stepper limit
    
    IBOutlet NSTextField *snap1;
    IBOutlet NSTextField *snap2;
    IBOutlet NSTextField *xPositionSnap1;
    IBOutlet NSTextField *yPositionSnap1;
    IBOutlet NSTextField *zPositionSnap1;
    IBOutlet NSTextField *xPositionSnap2;
    IBOutlet NSTextField *yPositionSnap2;
    IBOutlet NSTextField *zPositionSnap2;
    IBOutlet NSTextField *xDiff1;
    IBOutlet NSTextField *yDiff1;
    IBOutlet NSTextField *pageNo;
    IBOutlet NSTextField *stepperStartDisplay1;
    
    IBOutlet NSWindow *snapWindow;
    IBOutlet NSStepper *stepperX1;
    IBOutlet NSStepper *stepperY1;
    IBOutlet NSStepper *stepperStart1;
    
    NSTimer *snapTimer;
    NSWindowController *snapDisplayController;
    
    id ascIIconversion;
    id subProcesses;
    id singleTiffSave;
    id tiffFileRead;
}

-(id)init;
-(void)reDisplayWindow;
-(void)fileDeleteUpDate;
-(void)dealloc;

-(IBAction)closeWindow:(id)sender;
-(IBAction)snapSet1:(id)sender;
-(IBAction)snapSet2:(id)sender;
-(IBAction)create1:(id)sender;
-(IBAction)createSnap1:(id)sender;
-(IBAction)createMain1:(id)sender;
-(IBAction)imageLoad:(id)sender;
-(IBAction)stepperActionX1:(id)sender;
-(IBAction)stepperActionY1:(id)sender;
-(IBAction)stepperActionStart1:(id)sender;
-(IBAction)timePointSWMain:(id)sender;
-(IBAction)clearPage:(id)sender;
-(IBAction)pageFW:(id)sender;
-(IBAction)pageBW:(id)sender;
-(IBAction)createTest1:(id)sender;

@end
