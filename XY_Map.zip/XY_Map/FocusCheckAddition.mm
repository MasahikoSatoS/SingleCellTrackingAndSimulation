//
//  FocusCheckAddition.m
//  XY_Map
//
//  Created by Masahiko Sato on 2015-03-03.
//
//

#import "FocusCheckAddition.h"

NSString *notificationToFocusCheckAddition = @"notificationExecuteFocusCheckAddition";

@implementation FocusCheckAddition

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToFocusCheckAddition object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    focusCheckTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(displayData) userInfo:nil repeats:YES];
}

-(void)displayData{
    if (currentPlaneDisplayCall == 1){
        [currentPlaneNumber setIntegerValue: planeNumberDisplay+1];
        
        NSString *treatNSString = [currentPlaneNumber stringValue];
        
        if (treatNSString != NULL){
            string treatString = [treatNSString UTF8String];
            
            if (to_string(planeNumberDisplay+1) == treatString){
                currentPlaneDisplayCall = 0;
            }
        }
    }
    
    if (fileNameHoldCall == 1 || fileNameHoldCall == 2){
        if (fileNameHoldCall == 2) fileNameHoldCall = 1;
        else if (fileNameHoldCall == 1) fileNameHoldCall = 0;
        
        [fileNameDisplay setStringValue:@(fileNameHold.c_str())];
    }
}

-(void)dealloc{
    if (focusCheckTimer2) [focusCheckTimer2 invalidate];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToFocusCheckAddition object:nil];
}

@end
