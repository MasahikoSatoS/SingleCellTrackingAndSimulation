//
//  ASCIIconversion.mm
//  XY_Map
//
//  Created by Masahiko Sato on 29/05/11, 28/05/13 revised.
//  Copyright 2011 Masahiko Sato. All rights reserved.
//

/*Version B: Text conversion data will be saved in an array*/

#import "ASCIIconversion.h"

@implementation ASCIIconversion

-(int)ascIICode{
    int ascIIint = 0;
    int length = (int)ascIIstring.length();
    string writeData;
    
    ascIIintDataCount = 0;
    
    for (int counter1 = 0; counter1 < length; counter1++){
        writeData = ascIIstring.substr((unsigned long)counter1, 1);
        
        if (writeData == "A") ascIIint = 65;
        else if (writeData == "B") ascIIint = 66;
        else if (writeData == "C") ascIIint = 67;
        else if (writeData == "D") ascIIint = 68;
        else if (writeData == "E") ascIIint = 69;
        else if (writeData == "F") ascIIint = 70;
        else if (writeData == "G") ascIIint = 71;
        else if (writeData == "H") ascIIint = 72;
        else if (writeData == "I") ascIIint = 73;
        else if (writeData == "J") ascIIint = 74;
        else if (writeData == "K") ascIIint = 75;
        else if (writeData == "L") ascIIint = 76;
        else if (writeData == "M") ascIIint = 77;
        else if (writeData == "N") ascIIint = 78;
        else if (writeData == "O") ascIIint = 79;
        else if (writeData == "P") ascIIint = 80;
        else if (writeData == "Q") ascIIint = 81;
        else if (writeData == "R") ascIIint = 82;
        else if (writeData == "S") ascIIint = 83;
        else if (writeData == "T") ascIIint = 84;
        else if (writeData == "U") ascIIint = 85;
        else if (writeData == "V") ascIIint = 86;
        else if (writeData == "W") ascIIint = 87;
        else if (writeData == "X") ascIIint = 88;
        else if (writeData == "Y") ascIIint = 89;
        else if (writeData == "Z") ascIIint = 90;
        else if (writeData == "a") ascIIint = 97;
        else if (writeData == "b") ascIIint = 98;
        else if (writeData == "c") ascIIint = 99;
        else if (writeData == "d") ascIIint = 100;
        else if (writeData == "e") ascIIint = 101;
        else if (writeData == "f") ascIIint = 102;
        else if (writeData == "g") ascIIint = 103;
        else if (writeData == "h") ascIIint = 104;
        else if (writeData == "i") ascIIint = 105;
        else if (writeData == "j") ascIIint = 106;
        else if (writeData == "k") ascIIint = 107;
        else if (writeData == "l") ascIIint = 108;
        else if (writeData == "m") ascIIint = 109;
        else if (writeData == "n") ascIIint = 110;
        else if (writeData == "o") ascIIint = 111;
        else if (writeData == "p") ascIIint = 112;
        else if (writeData == "q") ascIIint = 113;
        else if (writeData == "r") ascIIint = 114;
        else if (writeData == "s") ascIIint = 115;
        else if (writeData == "t") ascIIint = 116;
        else if (writeData == "u") ascIIint = 117;
        else if (writeData == "v") ascIIint = 118;
        else if (writeData == "w") ascIIint = 119;
        else if (writeData == "x") ascIIint = 120;
        else if (writeData == "y") ascIIint = 121;
        else if (writeData == "z") ascIIint = 122;
        else if (writeData == "1") ascIIint = 49;
        else if (writeData == "2") ascIIint = 50;
        else if (writeData == "3") ascIIint = 51;
        else if (writeData == "4") ascIIint = 52;
        else if (writeData == "5") ascIIint = 53;
        else if (writeData == "6") ascIIint = 54;
        else if (writeData == "7") ascIIint = 55;
        else if (writeData == "8") ascIIint = 56;
        else if (writeData == "9") ascIIint = 57;
        else if (writeData == "0") ascIIint = 48;
        else if (writeData == ".") ascIIint = 46;
        else if (writeData == "-") ascIIint = 45;
        else if (writeData == "_") ascIIint = 95;
        else if (writeData == "+") ascIIint = 43;
        else if (writeData == "=") ascIIint = 61;
        else if (writeData == " ") ascIIint = 32;
        
        arrayAscIIintData [ascIIintDataCount] = ascIIint, ascIIintDataCount++;
    }
    
    return ascIIintDataCount;
}

-(void)ascIIConversion2:(int)ascIIint{
    if (ascIIint == 65) ascIIstring = "A";
    else if (ascIIint == 66) ascIIstring = "B";
    else if (ascIIint == 67) ascIIstring = "C";
    else if (ascIIint == 68) ascIIstring = "D";
    else if (ascIIint == 69) ascIIstring = "E";
    else if (ascIIint == 70) ascIIstring = "F";
    else if (ascIIint == 71) ascIIstring = "G";
    else if (ascIIint == 72) ascIIstring = "H";
    else if (ascIIint == 73) ascIIstring = "I";
    else if (ascIIint == 74) ascIIstring = "J";
    else if (ascIIint == 75) ascIIstring = "K";
    else if (ascIIint == 76) ascIIstring = "L";
    else if (ascIIint == 77) ascIIstring = "M";
    else if (ascIIint == 78) ascIIstring = "N";
    else if (ascIIint == 79) ascIIstring = "O";
    else if (ascIIint == 80) ascIIstring = "P";
    else if (ascIIint == 81) ascIIstring = "Q";
    else if (ascIIint == 82) ascIIstring = "R";
    else if (ascIIint == 83) ascIIstring = "S";
    else if (ascIIint == 84) ascIIstring = "T";
    else if (ascIIint == 85) ascIIstring = "U";
    else if (ascIIint == 86) ascIIstring = "V";
    else if (ascIIint == 87) ascIIstring = "W";
    else if (ascIIint == 88) ascIIstring = "X";
    else if (ascIIint == 89) ascIIstring = "Y";
    else if (ascIIint == 90) ascIIstring = "Z";
    else if (ascIIint == 97) ascIIstring = "a";
    else if (ascIIint == 98) ascIIstring = "b";
    else if (ascIIint == 99) ascIIstring = "c";
    else if (ascIIint == 100) ascIIstring = "d";
    else if (ascIIint == 101) ascIIstring = "e";
    else if (ascIIint == 102) ascIIstring = "f";
    else if (ascIIint == 103) ascIIstring = "g";
    else if (ascIIint == 104) ascIIstring = "h";
    else if (ascIIint == 105) ascIIstring = "i";
    else if (ascIIint == 106) ascIIstring = "j";
    else if (ascIIint == 107) ascIIstring = "k";
    else if (ascIIint == 108) ascIIstring = "l";
    else if (ascIIint == 109) ascIIstring = "m";
    else if (ascIIint == 110) ascIIstring = "n";
    else if (ascIIint == 111) ascIIstring = "o";
    else if (ascIIint == 112) ascIIstring = "p";
    else if (ascIIint == 113) ascIIstring = "q";
    else if (ascIIint == 114) ascIIstring = "r";
    else if (ascIIint == 115) ascIIstring = "s";
    else if (ascIIint == 116) ascIIstring = "t";
    else if (ascIIint == 117) ascIIstring = "u";
    else if (ascIIint == 118) ascIIstring = "v";
    else if (ascIIint == 119) ascIIstring = "w";
    else if (ascIIint == 120) ascIIstring = "x";
    else if (ascIIint == 121) ascIIstring = "y";
    else if (ascIIint == 122) ascIIstring = "z";
    else if (ascIIint == 49) ascIIstring = "1";
    else if (ascIIint == 50) ascIIstring = "2";
    else if (ascIIint == 51) ascIIstring = "3";
    else if (ascIIint == 52) ascIIstring = "4";
    else if (ascIIint == 53) ascIIstring = "5";
    else if (ascIIint == 54) ascIIstring = "6";
    else if (ascIIint == 55) ascIIstring = "7";
    else if (ascIIint == 56) ascIIstring = "8";
    else if (ascIIint == 57) ascIIstring = "9";
    else if (ascIIint == 48) ascIIstring = "0";
    else if (ascIIint == 46) ascIIstring = ".";
    else if (ascIIint == 45) ascIIstring = "-";
    else if (ascIIint == 95) ascIIstring = "_";
    else if (ascIIint == 43) ascIIstring = "+";
    else if (ascIIint == 61) ascIIstring = "=";
    else if (ascIIint == 44) ascIIstring = ",";
    else if (ascIIint == 34) ascIIstring = "'";
    else if (ascIIint == 32) ascIIstring = " ";
}

@end
