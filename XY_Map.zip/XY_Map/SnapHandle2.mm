//
//  SnapHandle2.m
//  XY_Map
//
//  Created by Masahiko Sato on 2014-08-23.
//
//

#import "SnapHandle2.h"

NSString *notificationToSnapHandle2 = @"notificationExecuteSnapHandle2";

@implementation SnapHandle2

-(id)init{
    self = [super init];
    
    if (self != nil){
        stepperLimitXL2 = 0;
        stepperLimitXH2 = 0;
        stepperLimitYL2 = 0;
        stepperLimitYH2 = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToSnapHandle2 object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    snapDisplayController2 = [[NSWindowController alloc] initWithWindowNibName:@"SnapDisplay2"];
    [snapDisplayController2 showWindow:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [snapWindow2 frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [snapWindow2 setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    if (snapFirstSecondTime2 == 1){
        [snap3 setTextColor:[NSColor redColor]];
        [snap4 setTextColor:[NSColor blackColor]];
        [snap3 setStringValue:@"Time C"];
        [snap4 setStringValue:@"Time D"];
    }
    
    if (snapFirstSecondTime2 == 2){
        [snap3 setTextColor:[NSColor blackColor]];
        [snap4 setTextColor:[NSColor redColor]];
        [snap3 setStringValue:@"Time C"];
        [snap4 setStringValue:@"Time D"];
    }
    
    [xDiff3 setDelegate:self];
    [yDiff3 setDelegate:self];
    
    [xPositionSnap3 setStringValue:@"nil"];
    [yPositionSnap3 setStringValue:@"nil"];
    [xPositionSnap4 setStringValue:@"nil"];
    [yPositionSnap4 setStringValue:@"nil"];
    [zPositionSnap3 setStringValue:@"nil"];
    [zPositionSnap4 setStringValue:@"nil"];
    [xDiff3 setStringValue:@""];
    [yDiff3 setStringValue:@""];
    
    if (snapPage2 == 0){
        [xPositionSnap3 setStringValue:@"nil"];
        [yPositionSnap3 setStringValue:@"nil"];
        [xPositionSnap4 setStringValue:@"nil"];
        [yPositionSnap4 setStringValue:@"nil"];
        [zPositionSnap3 setStringValue:@"nil"];
        [zPositionSnap4 setStringValue:@"nil"];
        [xDiff3 setStringValue:@""];
        [yDiff3 setStringValue:@""];
        [pageNo2 setStringValue:@"nil"];
    }
    else{
        
        [pageNo2 setIntegerValue:snapPage2];
        
        int entryPosition = (snapPage2-1)*16;
        
        arraySnapData2 [0] = arraySnapMainData2 [entryPosition]; //----Snap 1 no----
        arraySnapData2 [1] = arraySnapMainData2 [entryPosition+1]; //----X Corner Snap 1----
        arraySnapData2 [2] = arraySnapMainData2 [entryPosition+2]; //----Y Corner Snap 1----
        arraySnapData2 [3] = arraySnapMainData2 [entryPosition+3]; //----Z Corner Snap 1----
        arraySnapData2 [4] = arraySnapMainData2 [entryPosition+4]; //----X Position set 1----
        arraySnapData2 [5] = arraySnapMainData2 [entryPosition+5]; //----Y Position set 1----
        arraySnapData2 [6] = arraySnapMainData2 [entryPosition+6]; //----Snap 2 no----
        arraySnapData2 [7] = arraySnapMainData2 [entryPosition+7]; //----X Corner Snap 2----
        arraySnapData2 [8] = arraySnapMainData2 [entryPosition+8]; //----Y Corner Snap 2----
        arraySnapData2 [9] = arraySnapMainData2 [entryPosition+9]; //----Z Corner Snap 2----
        arraySnapData2 [10] = arraySnapMainData2 [entryPosition+10]; //----X Position set 2----
        arraySnapData2 [11] = arraySnapMainData2 [entryPosition+11]; //----X Position set 2----
        arraySnapData2 [12] = arraySnapMainData2 [entryPosition+12]; //----Set mark----
        arraySnapData2 [13] = arraySnapMainData2 [entryPosition+13]; //----X Diff----
        arraySnapData2 [14] = arraySnapMainData2 [entryPosition+14]; //----Y Diff----
        arraySnapData2 [15] = arraySnapMainData2 [entryPosition+15]; //----Z Diff----
        
        //for (int counterA = 0; counterA < 1; counterA++){
        //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<arraySnapData2 [counterA*16+counterB];
        //    cout<<" arraySnapData2 "<<counterA<<" "<<endl;
        //}
        
        //for (int counterA = 0; counterA < snapMainDataCount/16; counterA++){
        //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<arraySnapMainData2 [counterA*16+counterB];
        //     cout<<" arraySnapMainData2 "<<counterA<<" "<<endl;
        //}
        
        [pageNo2 setIntegerValue:snapPage2];
        
        if (arraySnapData2 [4] != 0 && arraySnapData2 [5] != 0){
            [xPositionSnap3 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [4]]];
            [yPositionSnap3 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [5]]];
            [zPositionSnap3 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [3]]];
        }
        else{
            
            [xPositionSnap3 setStringValue:@"nil"];
            [yPositionSnap3 setStringValue:@"nil"];
            [zPositionSnap3 setStringValue:@"nil"];
        }
        
        if (arraySnapData2 [10] != 0 && arraySnapData2 [11] != 0){
            [xPositionSnap4 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [10]]];
            [yPositionSnap4 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [11]]];
            [zPositionSnap4 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [9]]];
        }
        else{
            
            [xPositionSnap4 setStringValue:@"nil"];
            [yPositionSnap4 setStringValue:@"nil"];
            [zPositionSnap4 setStringValue:@"nil"];
        }
        
        if (arraySnapData2 [13] != 0 && arraySnapData2 [14] != 0){
            int xDifferenceInt = (int)(round (arraySnapData2 [13]));
            int yDifferenceInt = (int)(round (arraySnapData2 [14]));
            
            [xDiff3 setIntegerValue:xDifferenceInt];
            [yDiff3 setIntegerValue:yDifferenceInt];
            
            [stepperX2 setMinValue:xDifferenceInt-200];
            [stepperX2 setMaxValue:xDifferenceInt+200];
            [stepperY2 setMinValue:yDifferenceInt-200];
            [stepperY2 setMaxValue:yDifferenceInt+200];
            
            stepperLimitXL2 = xDifferenceInt-200;
            stepperLimitXH2 = xDifferenceInt+200;
            stepperLimitYL2 = yDifferenceInt-200;
            stepperLimitYH2 = yDifferenceInt+200;
            
            [stepperX2 setIntValue:xDifferenceInt];
            [stepperY2 setIntValue:yDifferenceInt];
        }
        else{
            
            [xDiff3 setStringValue:@""];
            [yDiff3 setStringValue:@""];
        }
        
        [stepperStartDisplay2 setDelegate:self];
        
        [stepperStart2 setMinValue:1];
        [stepperStart2 setMaxValue:500];
        [stepperStartDisplay2 setIntValue:1];
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage3 object:self];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage4 object:self];
}

-(IBAction)closeWindow:(id)sender{
    [snapWindow2 orderOut:self];
    snapOperation2 = 2;
    snapTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(IBAction)snapSet3:(id)sender{
    if (imageFirstLoadFlagSnap3 == 1){
        if (snapFirstSecondTime2 == 1){
            
            //for (int counterA = 0; counterA < 1; counterA++){
            //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<arraySnapData2 [counterA*16+counterB];
            //    cout<<" arraySnapData2 "<<counterA<<" "<<endl;
            // }
            
            //for (int counterA = 0; counterA < snapMainDataCount/16; //counterA++){
            //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<arraySnapMainData2 [counterA*16+counterB];
            //    cout<<" arraySnapMainData2 "<<counterA<<" "<<endl;
            //}
            
            if (arraySnapData2 [0] != 0){
                if (xClickPositionSnap3 != 0 && yClickPositionSnap3 != 0){
                    if (objectiveSelect == 1){
                        arraySnapData2 [4] = yClickPositionSnap3*1.04101+arraySnapData2 [1];
                        arraySnapData2 [5] = xClickPositionSnap3*1.04101+arraySnapData2 [2];
                        
                        int entryPosition = (snapPage2-1)*16;
                        arraySnapMainData2 [entryPosition+4] = arraySnapData2 [4];
                        arraySnapMainData2 [entryPosition+5] = arraySnapData2 [5];
                    }
                    else if (objectiveSelect == 2){
                        arraySnapData2 [4] = yClickPositionSnap3*0.52084+arraySnapData2 [1];
                        arraySnapData2 [5] = xClickPositionSnap3*0.52084+arraySnapData2 [2];
                        
                        int entryPosition = (snapPage2-1)*16;
                        arraySnapMainData2 [entryPosition+4] = arraySnapData2 [4];
                        arraySnapMainData2 [entryPosition+5] = arraySnapData2 [5];
                    }
                    else{
                        
                        arraySnapData2 [4] = yClickPositionSnap3*0.259589+arraySnapData2 [1];
                        arraySnapData2 [5] = xClickPositionSnap3*0.259589+arraySnapData2 [2];
                        
                        int entryPosition = (snapPage2-1)*16;
                        arraySnapMainData2 [entryPosition+4] = arraySnapData2 [4];
                        arraySnapMainData2 [entryPosition+5] = arraySnapData2 [5];
                    }
                    
                    [xPositionSnap3 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [4]]];
                    [yPositionSnap3 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [5]]];
                    [zPositionSnap3 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [3]]];
                    
                    ofstream oin;
                    
                    oin.open(snapDataPath2.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < snapMainDataCount2; counter1++) oin<<arraySnapMainData2 [counter1]<<endl;
                    
                    oin.close();
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage3 object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"No XY Data Set"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Time C Image Found"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Time C Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)snapSet4:(id)sender{
    if (imageFirstLoadFlagSnap4 == 1){
        if (snapFirstSecondTime2 == 2){
            if (arraySnapData2 [0] != 0 || arraySnapData2 [6] != 0){
                if (arraySnapData2 [4] != 0 || arraySnapData2 [5] != 0){
                    if (xClickPositionSnap4 != 0 || yClickPositionSnap4 != 0){
                        int entryPosition = (snapPage2-1)*16;
                        
                        if (objectiveSelect == 1){
                            arraySnapData2 [10] = yClickPositionSnap4*1.04101+arraySnapData2 [7];
                            arraySnapData2 [11] = xClickPositionSnap4*1.04101+arraySnapData2 [8];
                            
                            arraySnapMainData2 [entryPosition+10] = arraySnapData2 [10];
                            arraySnapMainData2 [entryPosition+11] = arraySnapData2 [11];
                        }
                        else if (objectiveSelect == 2){
                            arraySnapData2 [10] = yClickPositionSnap4*0.52084+arraySnapData2 [7];
                            arraySnapData2 [11] = xClickPositionSnap4*0.52084+arraySnapData2 [8];
                            
                            arraySnapMainData2 [entryPosition+10] = arraySnapData2 [10];
                            arraySnapMainData2 [entryPosition+11] = arraySnapData2 [11];
                        }
                        else{
                            
                            arraySnapData2 [10] = yClickPositionSnap4*0.259589+arraySnapData2 [7];
                            arraySnapData2 [11] = xClickPositionSnap4*0.259589+arraySnapData2 [8];
                            
                            arraySnapMainData2 [entryPosition+10] = arraySnapData2 [10];
                            arraySnapMainData2 [entryPosition+11] = arraySnapData2 [11];
                        }
                        
                        [xPositionSnap4 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [10]]];
                        [yPositionSnap4 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [11]]];
                        [zPositionSnap4 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [9]]];
                        
                        double xDifference = 0;
                        double yDifference = 0;
                        
                        xDifference = arraySnapData2 [4]-arraySnapData2 [10];
                        yDifference = arraySnapData2 [5]-arraySnapData2 [11];
                        
                        arraySnapData2 [12] = 1;
                        arraySnapData2 [13] = xDifference;
                        arraySnapData2 [14] = yDifference;
                        arraySnapData2 [15] = arraySnapData2 [9];
                        
                        arraySnapMainData2 [entryPosition+12] = arraySnapData2 [12];
                        arraySnapMainData2 [entryPosition+13] = arraySnapData2 [13];
                        arraySnapMainData2 [entryPosition+14] = arraySnapData2 [14];
                        arraySnapMainData2 [entryPosition+15] = arraySnapData2 [15];
                        
                        int xDifferenceInt = (int)(round (xDifference));
                        int yDifferenceInt = (int)(round (yDifference));
                        
                        [xDiff3 setIntegerValue:xDifferenceInt];
                        [yDiff3 setIntegerValue:yDifferenceInt];
                        
                        [stepperX2 setMinValue:xDifferenceInt-200];
                        [stepperX2 setMaxValue:xDifferenceInt+200];
                        [stepperY2 setMinValue:yDifferenceInt-200];
                        [stepperY2 setMaxValue:yDifferenceInt+200];
                        
                        stepperLimitXL2 = xDifferenceInt-200;
                        stepperLimitXH2 = xDifferenceInt+200;
                        stepperLimitYL2 = yDifferenceInt-200;
                        stepperLimitYH2 = yDifferenceInt+200;
                        
                        [stepperX2 setIntValue:xDifferenceInt];
                        [stepperY2 setIntValue:yDifferenceInt];
                        
                        ofstream oin;
                        
                        oin.open(snapDataPath2.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < snapMainDataCount2; counter1++) oin<<arraySnapMainData2 [counter1]<<endl;
                        
                        oin.close();
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage4 object:self];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"No XY Data Set"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"No Time C XY Data Set"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Time C/Time D Image Found"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Time D Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)create3:(id)sender{
    if (arraySnapData2 [12] != 0){
        string stgSaveAdjustPath = informationDirectoryPath+"/Adjust_positions.STG"; //===========================================
        
        ofstream oin;
        
        oin.open(stgSaveAdjustPath.c_str(), ios::out | ios::binary);
        
        ascIIconversion = [[ASCIIconversion alloc] init];
        
        if (oin.is_open()){
            arrayAscIIintData = new int [100];
            ascIIintDataCount = 0;
            
            oin.put(34);
            
            ascIIstring = "Stage Memory List";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(34), oin.put(44), oin.put(32);
            
            ascIIstring = "Version 6.0";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(13), oin.put(10), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
            oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44);
            oin.put(32), oin.put(34), oin.put(117), oin.put(109), oin.put(34), oin.put(44), oin.put(32), oin.put(34), oin.put(117), oin.put(109), oin.put(34);
            oin.put(13), oin.put(10), oin.put(48), oin.put(13), oin.put(10);
            
            ascIIstring = "1";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(13), oin.put(10), oin.put(34);
            
            ascIIstring = "well ";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            //----Well number----
            ascIIstring = "1";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            ascIIstring = " position ";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            //----X position----
            ascIIstring = "1";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            //----Y position----
            ascIIstring = "1";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(34), oin.put(44), oin.put(32);
            
            stringstream extension3;
            extension3 << arraySnapData2 [7]-(arraySnapData2 [7]-arraySnapData2 [1])-arraySnapData2 [13]; //----X value----
            ascIIstring = extension3.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            stringstream extension4;
            extension4 << arraySnapData2 [8]+(arraySnapData2 [8]-arraySnapData2 [2])+arraySnapData2 [14]; //----Y value----
            ascIIstring = extension4.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            stringstream extension5;
            extension5 << arraySnapData2 [15]; //----Z value----
            ascIIstring = extension5.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
            
            ascIIstring = "FALSE";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            ascIIstring = "-9999";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            ascIIstring = "TRUE";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            ascIIstring = "TRUE";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(45), oin.put(49), oin.put(44);
            oin.put(32), oin.put(34), oin.put(34), oin.put(44), oin.put(13), oin.put(10);
            
            oin.close();
            
            delete [] arrayAscIIintData;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Saved Position Data In Chamber 1"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)createSnap3:(id)sender{
    if (arraySnapData2 [0] != 0){
        string stgSaveAdjustPath = informationDirectoryPath+"/Adjust_positions.STG"; //===========================================
        
        ofstream oin;
        
        oin.open(stgSaveAdjustPath.c_str(), ios::out | ios::binary);
        
        ascIIconversion = [[ASCIIconversion alloc] init];
        
        if (oin.is_open()){
            arrayAscIIintData = new int [100];
            ascIIintDataCount = 0;
            
            oin.put(34);
            
            ascIIstring = "Stage Memory List";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(34), oin.put(44), oin.put(32);
            
            ascIIstring = "Version 6.0";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(13), oin.put(10), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
            oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44);
            oin.put(32), oin.put(34), oin.put(117), oin.put(109), oin.put(34), oin.put(44), oin.put(32), oin.put(34), oin.put(117), oin.put(109), oin.put(34);
            oin.put(13), oin.put(10), oin.put(48), oin.put(13), oin.put(10);
            
            ascIIstring = "1";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(13), oin.put(10), oin.put(34);
            
            ascIIstring = "well ";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            //----Well number----
            ascIIstring = "1";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            ascIIstring = " position ";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            //----X position----
            ascIIstring = "1";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            //----Y position----
            ascIIstring = "1";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(34), oin.put(44), oin.put(32);
            
            stringstream extension3;
            extension3 << arraySnapData2 [1]; //----X value----
            ascIIstring = extension3.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            stringstream extension4;
            extension4 << arraySnapData2 [2]; //----Y value----
            
            ascIIstring = extension4.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            stringstream extension5;
            extension5 << arraySnapData2 [3]; //----Z value----
            ascIIstring = extension5.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
            
            ascIIstring = "FALSE";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            ascIIstring = "-9999";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            ascIIstring = "TRUE";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            ascIIstring = "TRUE";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(45), oin.put(49), oin.put(44);
            oin.put(32), oin.put(34), oin.put(34), oin.put(44), oin.put(13), oin.put(10);
            
            oin.close();
            
            delete [] arrayAscIIintData;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Saved Position Data In Chamber 1"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)createMain3:(id)sender{
    if (arraySnapData2 [12] != 0){
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"MDA For IF Will Be Created"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            int stringLength = (int)bodyName.length();
            string stringExtract = bodyName.substr((unsigned long)stringLength-2);
            string stgIFSavePath;
            
            if (stringExtract == "IF"){
                stgIFSavePath = informationDirectoryPath+"/"+bodyName+"_positions.STG"; //===========================================
            }
            else stgIFSavePath = informationDirectoryPath+"/"+bodyName+"IF_positions.STG"; //===========================================
            
            string dataString;
            
            ifstream fin;
            
            fin.open(savedDataLastSavePath.c_str(), ios::in);
            
            if (fin.is_open()){
                int mapEnterCount1 = 0;
                int mapEnterCount2 = 0;
                int readingFlag = 0;
                int terminationFlag = 0;
                
                do{
                    
                    terminationFlag = 1;
                    
                    getline(fin, dataString);
                    
                    if (dataString == "SelectedFOV1") readingFlag = 3;
                    else if (readingFlag == 3 && dataString != "SelectedFOV2") mapEnterCount1++;
                    
                    if (dataString == "SelectedFOV2") readingFlag = 4;
                    else if (readingFlag == 4 && dataString != "END") mapEnterCount2++;
                    
                    if (dataString == "END") terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                fin.close();
                
                double *arrayMapTemp1 = new double [mapEnterCount1+50];
                double *arrayMapTemp2 = new double [mapEnterCount2+50];
                
                mapEnterCount1 = 0;
                mapEnterCount2 = 0;
                readingFlag = 0;
                
                fin.open(savedDataLastSavePath.c_str(), ios::in);
                
                if (fin.is_open()){
                    do{
                        
                        terminationFlag = 1;
                        
                        getline(fin, dataString);
                        
                        if (dataString == "SelectedFOV1") readingFlag = 3;
                        else if (readingFlag == 3 && dataString != "SelectedFOV2"){
                            arrayMapTemp1 [mapEnterCount1] = atof(dataString.c_str()), mapEnterCount1++;
                        }
                        
                        if (dataString == "SelectedFOV2") readingFlag = 4;
                        else if (readingFlag == 4 && dataString != "END"){
                            arrayMapTemp2 [mapEnterCount2] = atof(dataString.c_str()), mapEnterCount2++;
                        }
                        
                        if (dataString == "END") terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    fin.close();
                }
                
                if (arraySnapData [12] != 0){
                    double *arrayMapTemp = new double [mapEnterCount1+50];
                    int mapTempCount = 0;
                    
                    for (int counter1 = 1; counter1 <= chamberWellLimit1; counter1++){
                        for (int counter2 = 0; counter2 < mapEnterCount1/6; counter2++){
                            if (arrayMapTemp1 [counter2*6] == counter1){
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+1], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+2], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+3], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+4], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+5], mapTempCount++;
                            }
                        }
                    }
                    
                    mapEnterCount1 = 0;
                    
                    for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp1 [mapEnterCount1] = arrayMapTemp [counter1], mapEnterCount1++;
                    
                    int selectedFOVCount = mapEnterCount1/6;
                    
                    if (selectedFOVCount != 0){
                        double xDiffAdjust = arraySnapData [1]-(arraySnapData [7]-(arraySnapData [7]-arraySnapData [1])-arraySnapData [13]);
                        double yDiffAdjust = arraySnapData [2]-(arraySnapData [8]+(arraySnapData [8]-arraySnapData [2])+arraySnapData [14]);
                        
                        for (int counter1 = 0; counter1 < selectedFOVCount; counter1++){
                            arrayMapTemp1 [counter1*6+3] = arrayMapTemp1 [counter1*6+3]-xDiffAdjust;
                            arrayMapTemp1 [counter1*6+4] = arrayMapTemp1 [counter1*6+4]-yDiffAdjust;
                        }
                    }
                    
                    delete [] arrayMapTemp;
                }
                
                if (arraySnapData2 [12] != 0){
                    double *arrayMapTemp = new double [mapEnterCount2+50];
                    int mapTempCount = 0;
                    
                    for (int counter1 = chamberWellLimit1+1; counter1 <= chamberWellLimit1+chamberWellLimit2; counter1++){
                        for (int counter2 = 0; counter2 < mapEnterCount2/6; counter2++){
                            if (arrayMapTemp2 [counter2*6] == counter1){
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+1], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+2], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+3], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+4], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+5], mapTempCount++;
                            }
                        }
                    }
                    
                    mapEnterCount2 = 0;
                    
                    for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp2 [mapEnterCount2] = arrayMapTemp [counter1], mapEnterCount2++;
                    
                    int selectedFOVCount = mapEnterCount2/6;
                    
                    if (selectedFOVCount != 0){
                        double xDiffAdjust = arraySnapData2 [1]-(arraySnapData2 [7]-(arraySnapData2 [7]-arraySnapData2 [1])-arraySnapData2 [13]);
                        double yDiffAdjust = arraySnapData2 [2]-(arraySnapData2 [8]+(arraySnapData2 [8]-arraySnapData2 [2])+arraySnapData2 [14]);
                        
                        for (int counter1 = 0; counter1 < selectedFOVCount; counter1++){
                            arrayMapTemp2 [counter1*6+3] = arrayMapTemp2 [counter1*6+3]-xDiffAdjust;
                            arrayMapTemp2 [counter1*6+4] = arrayMapTemp2 [counter1*6+4]-yDiffAdjust;
                        }
                    }
                    
                    delete [] arrayMapTemp;
                }
                
                int selectedFOVCount1 = mapEnterCount1/6;
                int selectedFOVCount2 = mapEnterCount2/6;
                
                if (selectedFOVCount1 != 0){
                    double *arrayMapTemp = new double [mapEnterCount1+50];
                    int mapTempCount = 0;
                    
                    for (int counter1 = 1; counter1 <= chamberWellLimit1; counter1++){
                        for (int counter2 = 0; counter2 < selectedFOVCount1; counter2++){
                            if (arrayMapTemp1 [counter2*6] == counter1){
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+1], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+2], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+3], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+4], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+5], mapTempCount++;
                            }
                        }
                    }
                    
                    mapEnterCount1 = 0;
                    
                    for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp1 [mapEnterCount1] = arrayMapTemp [counter1], mapEnterCount1++;
                    delete [] arrayMapTemp;
                }
                
                if (selectedFOVCount2 != 0){
                    double *arrayMapTemp = new double [mapEnterCount2+50];
                    int mapTempCount = 0;
                    
                    for (int counter1 = chamberWellLimit1+1; counter1 <= chamberWellLimit1+chamberWellLimit2; counter1++){
                        for (int counter2 = 0; counter2 < selectedFOVCount2; counter2++){
                            if (arrayMapTemp2 [counter2*6] == counter1){
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+1], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+2], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+3], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+4], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+5], mapTempCount++;
                            }
                        }
                    }
                    
                    mapEnterCount2 = 0;
                    
                    for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp2 [mapEnterCount2] = arrayMapTemp [counter1], mapEnterCount2++;
                    delete [] arrayMapTemp;
                }
                
                if (selectedFOVCount1+selectedFOVCount2 != 0){
                    ofstream oin;
                    
                    oin.open(stgIFSavePath.c_str(), ios::out | ios::binary);
                    
                    ascIIconversion = [[ASCIIconversion alloc] init];
                    
                    if (oin.is_open()){
                        arrayAscIIintData = new int [100];
                        ascIIintDataCount = 0;
                        
                        oin.put(34);
                        
                        ascIIstring = "Stage Memory List";
                        ascIIintDataCount = [ascIIconversion ascIICode];
                        
                        for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
                        
                        oin.put(34), oin.put(44), oin.put(32);
                        
                        ascIIstring = "Version 6.0";
                        ascIIintDataCount = [ascIIconversion ascIICode];
                        
                        for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
                        
                        oin.put(13), oin.put(10), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
                        oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44);
                        oin.put(32), oin.put(34), oin.put(117), oin.put(109), oin.put(34), oin.put(44), oin.put(32), oin.put(34), oin.put(117), oin.put(109), oin.put(34);
                        oin.put(13), oin.put(10), oin.put(48), oin.put(13), oin.put(10);
                        
                        ascIIstring = to_string(selectedFOVCount1+selectedFOVCount2);
                        ascIIintDataCount = [ascIIconversion ascIICode];
                        
                        for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
                        
                        oin.put(13), oin.put(10);
                        
                        if (selectedFOVCount1 != 0){
                            for (int counter1 = 0; counter1 < selectedFOVCount1; counter1++){
                                oin.put(34);
                                
                                ascIIstring = "well ";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                stringstream extension;
                                extension << arrayMapTemp1 [counter1*6]; //----Well number----
                                ascIIstring = extension.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                ascIIstring = " position ";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                stringstream extension1;
                                extension1 << arrayMapTemp1 [counter1*6+1]; //----X position----
                                ascIIstring = extension1.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                stringstream extension2;
                                extension2 << arrayMapTemp1 [counter1*6+2]; //----Y position----
                                ascIIstring = extension2.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(34), oin.put(44), oin.put(32);
                                
                                stringstream extension3;
                                extension3 << arrayMapTemp1 [counter1*6+3]; //----X value----
                                ascIIstring = extension3.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                stringstream extension4;
                                extension4 << arrayMapTemp1 [counter1*6+4]; //----Y value----
                                ascIIstring = extension4.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                stringstream extension5;
                                extension5 << arrayMapTemp1 [counter1*6+5]; //----Z value----
                                ascIIstring = extension5.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
                                
                                ascIIstring = "FALSE";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                ascIIstring = "-9999";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                ascIIstring = "TRUE";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                ascIIstring = "TRUE";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(45), oin.put(49), oin.put(44);
                                oin.put(32), oin.put(34), oin.put(34), oin.put(44), oin.put(13), oin.put(10);
                            }
                        }
                        
                        if (selectedFOVCount2 != 0){
                            for (int counter1 = 0; counter1 < selectedFOVCount2; counter1++){
                                oin.put(34);
                                
                                ascIIstring = "well ";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                stringstream extension;
                                extension << arrayMapTemp2 [counter1*6]; //----Well number----
                                ascIIstring = extension.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                ascIIstring = " position ";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                stringstream extension1;
                                extension1 << arrayMapTemp2 [counter1*6+1]; //----X position----
                                ascIIstring = extension1.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                stringstream extension2;
                                extension2 << arrayMapTemp2 [counter1*6+2]; //----Y position----
                                ascIIstring = extension2.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(34), oin.put(44), oin.put(32);
                                
                                stringstream extension3;
                                extension3 << arrayMapTemp2 [counter1*6+3]; //----X value----
                                ascIIstring = extension3.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                stringstream extension4;
                                extension4 << arrayMapTemp2 [counter1*6+4]; //----Y value----
                                ascIIstring = extension4.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                stringstream extension5;
                                extension5 << arrayMapTemp2 [counter1*6+5]; //----Z value----
                                ascIIstring = extension5.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
                                
                                ascIIstring = "FALSE";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                ascIIstring = "-9999";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                ascIIstring = "TRUE";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                ascIIstring = "TRUE";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(45), oin.put(49), oin.put(44);
                                oin.put(32), oin.put(34), oin.put(34), oin.put(44), oin.put(13), oin.put(10);
                            }
                        }
                        
                        oin.close();
                        
                        delete [] arrayAscIIintData;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                }
                
                delete [] arrayMapTemp1;
                delete [] arrayMapTemp2;
            }
            else{
                
                NSAlert *alert2 = [[NSAlert alloc] init];
                
                [alert2 addButtonWithTitle:@"OK"];
                [alert2 setMessageText:@"No Saved file was found"];
                [alert2 setAlertStyle:NSAlertStyleWarning];
                [alert2 runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Found"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)createTest2:(id)sender{
    if (arraySnapData [12] != 0){
        string stgSaveAdjustPath = informationDirectoryPath+"/ATest_positions.STG";
        string dataString;
        
        ifstream fin;
        
        fin.open(savedDataLastSavePath.c_str(), ios::in);
        
        if (fin.is_open()){
            int mapEnterCount1 = 0;
            int mapEnterCount2 = 0;
            int readingFlag = 0;
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                
                getline(fin, dataString);
                
                if (dataString == "SelectedFOV1") readingFlag = 3;
                else if (readingFlag == 3 && dataString != "SelectedFOV2") mapEnterCount1++;
                
                if (dataString == "SelectedFOV2") readingFlag = 4;
                else if (readingFlag == 4 && dataString != "END") mapEnterCount2++;
                
                if (dataString == "END") terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            fin.close();
            
            double *arrayMapTemp1 = new double [mapEnterCount1+50];
            double *arrayMapTemp2 = new double [mapEnterCount2+50];
            
            mapEnterCount1 = 0;
            mapEnterCount2 = 0;
            readingFlag = 0;
            
            fin.open(savedDataLastSavePath.c_str(), ios::in);
            
            if (fin.is_open()){
                do{
                    
                    terminationFlag = 1;
                    
                    getline(fin, dataString);
                    
                    if (dataString == "SelectedFOV1") readingFlag = 3;
                    else if (readingFlag == 3 && dataString != "SelectedFOV2"){
                        arrayMapTemp1 [mapEnterCount1] = atof(dataString.c_str()), mapEnterCount1++;
                    }
                    
                    if (dataString == "SelectedFOV2") readingFlag = 4;
                    else if (readingFlag == 4 && dataString != "END"){
                        arrayMapTemp2 [mapEnterCount2] = atof(dataString.c_str()), mapEnterCount2++;
                    }
                    
                    if (dataString == "END") terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                fin.close();
            }
            
            if (arraySnapData [12] != 0){
                double *arrayMapTemp = new double [mapEnterCount1+50];
                int mapTempCount = 0;
                
                for (int counter1 = 1; counter1 <= chamberWellLimit1; counter1++){
                    for (int counter2 = 0; counter2 < mapEnterCount1/6; counter2++){
                        if (arrayMapTemp1 [counter2*6] == counter1){
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+1], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+2], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+3], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+4], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+5], mapTempCount++;
                        }
                    }
                }
                
                mapEnterCount1 = 0;
                
                for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp1 [mapEnterCount1] = arrayMapTemp [counter1], mapEnterCount1++;
                
                int selectedFOVCount = mapEnterCount1/6;
                
                if (selectedFOVCount != 0){
                    double xDiffAdjust = arraySnapData [1]-(arraySnapData [7]-(arraySnapData [7]-arraySnapData [1])-arraySnapData [13]);
                    double yDiffAdjust = arraySnapData [2]-(arraySnapData [8]+(arraySnapData [8]-arraySnapData [2])+arraySnapData [14]);
                    
                    for (int counter1 = 0; counter1 < selectedFOVCount; counter1++){
                        arrayMapTemp1 [counter1*6+3] = arrayMapTemp1 [counter1*6+3]-xDiffAdjust;
                        arrayMapTemp1 [counter1*6+4] = arrayMapTemp1 [counter1*6+4]-yDiffAdjust;
                    }
                }
                
                delete [] arrayMapTemp;
            }
            
            if (arraySnapData2 [12] != 0){
                double *arrayMapTemp = new double [mapEnterCount2+50];
                int mapTempCount = 0;
                
                for (int counter1 = chamberWellLimit1+1; counter1 <= chamberWellLimit1+chamberWellLimit2; counter1++){
                    for (int counter2 = 0; counter2 < mapEnterCount2/6; counter2++){
                        if (arrayMapTemp2 [counter2*6] == counter1){
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+1], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+2], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+3], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+4], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+5], mapTempCount++;
                        }
                    }
                }
                
                mapEnterCount2 = 0;
                
                for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp2 [mapEnterCount2] = arrayMapTemp [counter1], mapEnterCount2++;
                
                int selectedFOVCount = mapEnterCount2/6;
                
                if (selectedFOVCount != 0){
                    double xDiffAdjust = arraySnapData2 [1]-(arraySnapData2 [7]-(arraySnapData2 [7]-arraySnapData2 [1])-arraySnapData2 [13]);
                    double yDiffAdjust = arraySnapData2 [2]-(arraySnapData2 [8]+(arraySnapData2 [8]-arraySnapData2 [2])+arraySnapData2 [14]);
                    
                    for (int counter1 = 0; counter1 < selectedFOVCount; counter1++){
                        arrayMapTemp2 [counter1*6+3] = arrayMapTemp2 [counter1*6+3]-xDiffAdjust;
                        arrayMapTemp2 [counter1*6+4] = arrayMapTemp2 [counter1*6+4]-yDiffAdjust;
                    }
                }
                
                delete [] arrayMapTemp;
            }
            
            for (int counter2 = 0; counter2 <= 16; counter2++){
                wellPositionTest [counter2*2] = -1;
                wellPositionTest [counter2*2+1] = -1;
            }
            
            int selectedFOVCount1 = mapEnterCount1/6;
            int selectedFOVCount2 = mapEnterCount2/6;
            
            if (selectedFOVCount1 != 0){
                double *arrayMapTemp = new double [mapEnterCount1+50];
                int mapTempCount = 0;
                int fovPositionCount = 0;
                
                for (int counter2 = 1; counter2 <= 16; counter2++){
                    for (int counter3 = 0; counter3 < selectedFOVCount1; counter3++){
                        if (arrayMapTemp1 [counter3*6] == counter2){
                            fovPositionCount = 1;
                            
                            for (int counter4 = counter3; counter4 < selectedFOVCount1; counter4++){
                                if (fovPositionCount == stepperStartHold1){
                                    arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter4*6], mapTempCount++;
                                    arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter4*6+1], mapTempCount++;
                                    arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter4*6+2], mapTempCount++;
                                    arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter4*6+3], mapTempCount++;
                                    arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter4*6+4], mapTempCount++;
                                    arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter4*6+5], mapTempCount++;
                                    break;
                                }
                                else fovPositionCount++;
                            }
                            
                            break;
                        }
                    }
                }
                
                mapEnterCount1 = 0;
                
                for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp1 [mapEnterCount1] = arrayMapTemp [counter1], mapEnterCount1++;
                
                mapTempCount = 0;
                
                for (int counter1 = 1; counter1 <= chamberWellLimit1; counter1++){
                    for (int counter2 = 0; counter2 < mapEnterCount1/6; counter2++){
                        if (arrayMapTemp1 [counter2*6] == counter1){
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+1], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+2], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+3], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+4], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+5], mapTempCount++;
                        }
                    }
                }
                
                mapEnterCount1 = 0;
                
                for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp1 [mapEnterCount1] = arrayMapTemp [counter1], mapEnterCount1++;
                
                delete [] arrayMapTemp;
                
                for (int counter1 = 0; counter1 < mapEnterCount1/6; counter1++){
                    if (wellPositionTest [(int)arrayMapTemp1 [counter1*6]*2] == -1){
                        wellPositionTest [(int)arrayMapTemp1 [counter1*6]*2] = counter1+1;
                        wellPositionTest [(int)arrayMapTemp1 [counter1*6]*2+1] = counter1+1;
                    }
                    else wellPositionTest [(int)arrayMapTemp1 [counter1*6]*2+1] = counter1+1;
                }
            }
            
            if (selectedFOVCount2 != 0){
                double *arrayMapTemp = new double [mapEnterCount2+50];
                int mapTempCount = 0;
                int fovPositionCount = 0;
                
                for (int counter2 = 1; counter2 <= 16; counter2++){
                    for (int counter3 = 0; counter3 < selectedFOVCount2; counter3++){
                        if (arrayMapTemp2 [counter3*6] == counter2){
                            fovPositionCount = 1;
                            
                            for (int counter4 = counter3; counter4 < selectedFOVCount2; counter4++){
                                if (fovPositionCount == stepperStartHold2){
                                    arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter4*6], mapTempCount++;
                                    arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter4*6+1], mapTempCount++;
                                    arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter4*6+2], mapTempCount++;
                                    arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter4*6+3], mapTempCount++;
                                    arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter4*6+4], mapTempCount++;
                                    arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter4*6+5], mapTempCount++;
                                    break;
                                }
                                else fovPositionCount++;
                            }
                            
                            break;
                        }
                    }
                }
                
                mapEnterCount2 = 0;
                
                for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp2 [mapEnterCount2] = arrayMapTemp [counter1], mapEnterCount2++;
                
                mapTempCount = 0;
                
                for (int counter1 = chamberWellLimit1+1; counter1 <= chamberWellLimit1+chamberWellLimit2; counter1++){
                    for (int counter2 = 0; counter2 < mapEnterCount2/6; counter2++){
                        if (arrayMapTemp2 [counter2*6] == counter1){
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+1], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+2], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+3], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+4], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+5], mapTempCount++;
                        }
                    }
                }
                
                mapEnterCount2 = 0;
                
                for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp2 [mapEnterCount2] = arrayMapTemp [counter1], mapEnterCount2++;
                
                delete [] arrayMapTemp;
                
                for (int counter1 = 0; counter1 < mapEnterCount2/6; counter1++){
                    if (wellPositionTest [(int)arrayMapTemp2 [counter1*6]*2] == -1){
                        wellPositionTest [(int)arrayMapTemp2 [counter1*6]*2] = counter1+1;
                        wellPositionTest [(int)arrayMapTemp2 [counter1*6]*2+1] = counter1+1;
                    }
                    else wellPositionTest [(int)arrayMapTemp2 [counter1*6]*2+1] = counter1+1;
                }
            }
            
            if (mapEnterCount1/6+mapEnterCount2/6 != 0){
                ofstream oin;
                
                oin.open(stgSaveAdjustPath.c_str(), ios::out | ios::binary);
                
                ascIIconversion = [[ASCIIconversion alloc] init];
                
                if (oin.is_open()){
                    arrayAscIIintData = new int [100];
                    ascIIintDataCount = 0;
                    
                    oin.put(34);
                    
                    ascIIstring = "Stage Memory List";
                    ascIIintDataCount = [ascIIconversion ascIICode];
                    
                    for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
                    
                    oin.put(34), oin.put(44), oin.put(32);
                    
                    ascIIstring = "Version 6.0";
                    ascIIintDataCount = [ascIIconversion ascIICode];
                    
                    for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
                    
                    oin.put(13), oin.put(10), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
                    oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44);
                    oin.put(32), oin.put(34), oin.put(117), oin.put(109), oin.put(34), oin.put(44), oin.put(32), oin.put(34), oin.put(117), oin.put(109), oin.put(34);
                    oin.put(13), oin.put(10), oin.put(48), oin.put(13), oin.put(10);
                    
                    ascIIstring = to_string(mapEnterCount1/6+mapEnterCount2/6);
                    ascIIintDataCount = [ascIIconversion ascIICode];
                    
                    for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
                    
                    oin.put(13), oin.put(10);
                    
                    if (mapEnterCount1/6 != 0){
                        for (int counter1 = 0; counter1 < mapEnterCount1/6; counter1++){
                            oin.put(34);
                            
                            ascIIstring = "well ";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            stringstream extension;
                            extension << arrayMapTemp1 [counter1*6]; //----Well number----
                            ascIIstring = extension.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            ascIIstring = " position ";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            stringstream extension1;
                            extension1 << arrayMapTemp1 [counter1*6+1]; //----X position----
                            ascIIstring = extension1.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            stringstream extension2;
                            extension2 << arrayMapTemp1 [counter1*6+2]; //----Y position----
                            ascIIstring = extension2.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(34), oin.put(44), oin.put(32);
                            
                            stringstream extension3;
                            extension3 << arrayMapTemp1 [counter1*6+3]; //----X value----
                            ascIIstring = extension3.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            stringstream extension4;
                            extension4 << arrayMapTemp1 [counter1*6+4]; //----Y value----
                            ascIIstring = extension4.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            stringstream extension5;
                            extension5 << arrayMapTemp1 [counter1*6+5]; //----Z value----
                            ascIIstring = extension5.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
                            
                            ascIIstring = "FALSE";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            ascIIstring = "-9999";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            ascIIstring = "TRUE";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            ascIIstring = "TRUE";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(45), oin.put(49), oin.put(44);
                            oin.put(32), oin.put(34), oin.put(34), oin.put(44), oin.put(13), oin.put(10);
                        }
                    }
                    
                    if (mapEnterCount2/6 != 0){
                        for (int counter1 = 0; counter1 < mapEnterCount2/6; counter1++){
                            oin.put(34);
                            
                            ascIIstring = "well ";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            stringstream extension;
                            extension << arrayMapTemp2 [counter1*6]; //----Well number----
                            ascIIstring = extension.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            ascIIstring = " position ";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            stringstream extension1;
                            extension1 << arrayMapTemp2 [counter1*6+1]; //----X position----
                            ascIIstring = extension1.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            stringstream extension2;
                            extension2 << arrayMapTemp2 [counter1*6+2]; //----Y position----
                            ascIIstring = extension2.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(34), oin.put(44), oin.put(32);
                            
                            stringstream extension3;
                            extension3 << arrayMapTemp2 [counter1*6+3]; //----X value----
                            ascIIstring = extension3.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            stringstream extension4;
                            extension4 << arrayMapTemp2 [counter1*6+4]; //----Y value----
                            ascIIstring = extension4.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            stringstream extension5;
                            extension5 << arrayMapTemp2 [counter1*6+5]; //----Z value----
                            ascIIstring = extension5.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
                            
                            ascIIstring = "FALSE";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            ascIIstring = "-9999";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            ascIIstring = "TRUE";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            ascIIstring = "TRUE";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(45), oin.put(49), oin.put(44);
                            oin.put(32), oin.put(34), oin.put(34), oin.put(44), oin.put(13), oin.put(10);
                        }
                    }
                    
                    oin.close();
                    
                    delete [] arrayAscIIintData;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
            }
            
            delete [] arrayMapTemp1;
            delete [] arrayMapTemp2;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Saved file was found"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Found"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageLoad:(id)sender{
    if (snapPage2 != 100){
        ifstream fin;
        
        fin.open(informationDirectoryPath.c_str(), ios::in);
        
        if (fin.is_open()){
            fin.close();
            
            if (snapFirstSecondTime2 == 1){
                int lastSnapNo = 0;
                
                for (int counter1 = 0; counter1 < snapMainDataCount2/16; counter1++){
                    if (arraySnapMainData2 [counter1*16] != 0) lastSnapNo = (int)arraySnapMainData2 [counter1*16];
                }
                
                string entry;
                
                fileDeleteCount = 0;
                
                DIR *dir;
                struct dirent *dent;
                
                dir = opendir(informationDirectoryPath.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                            arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                        }
                    }
                    
                    closedir(dir);
                    
                    string snapFilePath2;
                    string extension;
                    
                    unsigned long nextAddress = 0;
                    unsigned long stripFirstAddress = 0;
                    unsigned long stripByteCountAddress = 0;
                    unsigned long headPosition = 0;
                    unsigned long stripEntry = 0;
                    long sizeForCopy = 0;
                    
                    double xPosition = 0;
                    double yPosition = 0;
                    double zPosition = 0;
                    
                    int imageWidth = 0;
                    int imageHeight = 0;
                    int imageBit = 0; //Check 8, 16
                    int imageCompression = 0; //Check 1
                    int photoMetric = 0; //Check 0, 1, 2
                    
                    int verticalBmp = 0;
                    int horizontalBmp = 0;
                    int endianType = 0;
                    int samplePerPix = 0;
                    int dataConversion [4];
                    int processType = 0; //----Out put image 8 bit gray
                    int numberOfLayers = 0;
                    int mode = 0;
                    
                    struct stat sizeOfFile;
                    
                    ofstream oin;
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                        entry = arrayFileDelete [counter1];
                        
                        if ((int)entry.find("Snap") != -1){
                            if (lastSnapNo == 0) lastSnapNo = 1;
                            else if (lastSnapNo != 0) lastSnapNo = lastSnapNo+2;
                            
                            extension = to_string(lastSnapNo);
                            
                            if (extension.length() == 1) extension = "00"+extension;
                            else if (extension.length() == 2) extension = "0"+extension;
                            
                            snapFilePath2 = informationDirectoryPath+"/"+entry;
                            fileSavePathHold = cellTrackingSystemDataPath+"/"+"SnapB-"+extension;
                            
                            if (stat(snapFilePath2.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                fileReadArray = new uint8_t [sizeForCopy+4];
                                fin.open(snapFilePath2.c_str(), ios::in | ios::binary);
                                
                                fin.read((char*)fileReadArray, sizeForCopy+1);
                                fin.close();
                                
                                dataConversion [0] = fileReadArray [0];
                                dataConversion [1] = fileReadArray [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = fileReadArray [7];
                                    dataConversion [1] = fileReadArray [6];
                                    dataConversion [2] = fileReadArray [5];
                                    dataConversion [3] = fileReadArray [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = fileReadArray [4];
                                    dataConversion [1] = fileReadArray [5];
                                    dataConversion [2] = fileReadArray [6];
                                    dataConversion [3] = fileReadArray [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                int *arrayExtractedImage3 = new int [100];
                                
                                if (endianType == 1){ //----Big endian----
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers:&zPosition];
                                    
                                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && numberOfLayers == 1 && samplePerPix <= 4 && photoMetric < 3 && imageWidth == cameraDimension && imageHeight == cameraDimension){
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:cameraDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                    }
                                }
                                else if (endianType == 0){
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers:&zPosition];
                                    
                                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && numberOfLayers == 1 && samplePerPix <= 4 && photoMetric < 3 && imageWidth == cameraDimension && imageHeight == cameraDimension){
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:cameraDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                    }
                                }
                                
                                //cout<<imageCompression<<" "<<imageBit<<" "<<" "<<samplePerPix<<" "<<photoMetric<<" "<<zPosition<<" "<<imageWidth<<" "<<cameraDimension<<" "<<numberOfLayers<<" entryinfo"<<endl;
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && numberOfLayers == 1 && samplePerPix <= 4 && photoMetric < 3 && imageWidth == cameraDimension && imageHeight == cameraDimension){
                                    
                                    horizontalBmp = 0;
                                    verticalBmp = 0;
                                    
                                    //----Saved image----
                                    arrayImageFileSave = new int *[cameraDimension+1];
                                    
                                    for (int counter3 = 0; counter3 < cameraDimension+1; counter3++){
                                        arrayImageFileSave [counter3] = new int [cameraDimension+1];
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cameraDimension; counter3++){
                                        for (int counter4 = 0; counter4 < cameraDimension; counter4++){
                                            arrayImageFileSave [counter3][counter4] = 0;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cameraDimension*cameraDimension; counter3++){
                                        if (horizontalBmp < cameraDimension){
                                            arrayImageFileSave [verticalBmp][horizontalBmp] = arrayExtractedImage3 [counter3], horizontalBmp++;
                                        }
                                        
                                        if (horizontalBmp == cameraDimension){
                                            horizontalBmp = 0;
                                            verticalBmp++;
                                        }
                                    }
                                    
                                    photoMetric = 1;
                                    imageBit = 8;
                                    
                                    if (xPosition == -1) xPosition = 100;
                                    if (yPosition == -1) yPosition = 100;
                                    if (zPosition == -1) zPosition = 100;
                                    
                                    singleTiffSave = [[SingleTiffSave alloc] init];
                                    [singleTiffSave singleTiffLayerSave:cameraDimension:cameraDimension:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:(unsigned long)mode:zPosition];
                                    
                                    for (int counter3 = 0; counter3 < cameraDimension+1; counter3++){
                                        delete [] arrayImageFileSave [counter3];
                                    }
                                    
                                    delete [] arrayImageFileSave;
                                    
                                    snapPage2 = (lastSnapNo+1)/2;
                                    
                                    arraySnapMainData2 [snapMainDataCount2] = lastSnapNo, snapMainDataCount2++;
                                    arraySnapMainData2 [snapMainDataCount2] = xPosition, snapMainDataCount2++;
                                    arraySnapMainData2 [snapMainDataCount2] = yPosition, snapMainDataCount2++;
                                    arraySnapMainData2 [snapMainDataCount2] = zPosition, snapMainDataCount2++;
                                    arraySnapMainData2 [snapMainDataCount2] = 0, snapMainDataCount2++;
                                    arraySnapMainData2 [snapMainDataCount2] = 0, snapMainDataCount2++;
                                    arraySnapMainData2 [snapMainDataCount2] = 0, snapMainDataCount2++;
                                    arraySnapMainData2 [snapMainDataCount2] = 0, snapMainDataCount2++;
                                    arraySnapMainData2 [snapMainDataCount2] = 0, snapMainDataCount2++;
                                    arraySnapMainData2 [snapMainDataCount2] = 0, snapMainDataCount2++;
                                    arraySnapMainData2 [snapMainDataCount2] = 0, snapMainDataCount2++;
                                    arraySnapMainData2 [snapMainDataCount2] = 0, snapMainDataCount2++;
                                    arraySnapMainData2 [snapMainDataCount2] = 0, snapMainDataCount2++;
                                    arraySnapMainData2 [snapMainDataCount2] = 0, snapMainDataCount2++;
                                    arraySnapMainData2 [snapMainDataCount2] = 0, snapMainDataCount2++;
                                    arraySnapMainData2 [snapMainDataCount2] = 0, snapMainDataCount2++;
                                    
                                    oin.open(snapDataPath2.c_str(), ios::out);
                                    
                                    for (int counter2 = 0; counter2 < snapMainDataCount2; counter2++) oin<<arraySnapMainData2 [counter2]<<endl;
                                    
                                    oin.close();
                                    
                                    subProcesses = [[SubProcesses alloc] init];
                                    [subProcesses mapDataSave];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                }
                                else{
                                    
                                    remove (fileSavePathHold.c_str());
                                    
                                    if (lastSnapNo == 1) lastSnapNo = 0;
                                    else if (lastSnapNo != 0) lastSnapNo = lastSnapNo-2;
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"File Format Error"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                                
                                delete [] fileReadArray;
                                delete [] arrayExtractedImage3;
                            }
                            else{
                                
                                if (lastSnapNo == 1) lastSnapNo = 0;
                                else if (lastSnapNo != 0) lastSnapNo = lastSnapNo-2;
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                            
                            remove (snapFilePath2.c_str());
                        }
                    }
                }
            }
            else if (snapFirstSecondTime2 == 2){
                string entry;
                
                fileDeleteCount = 0;
                
                DIR *dir;
                struct dirent *dent;
                
                dir = opendir(informationDirectoryPath.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                            arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                        }
                    }
                    
                    closedir(dir);
                    
                    string snapFilePath2;
                    string extension;
                    
                    unsigned long nextAddress = 0;
                    unsigned long stripFirstAddress = 0;
                    unsigned long stripByteCountAddress = 0;
                    unsigned long headPosition = 0;
                    unsigned long stripEntry = 0;
                    long sizeForCopy = 0;
                    
                    double xPosition = 0;
                    double yPosition = 0;
                    double zPosition = 0;
                    
                    int imageWidth = 0;
                    int imageHeight = 0;
                    int imageBit = 0; //Check 8, 16
                    int imageCompression = 0; //Check 1
                    int photoMetric = 0; //Check 0, 1, 2
                    
                    int verticalBmp = 0;
                    int horizontalBmp = 0;
                    int endianType = 0;
                    int samplePerPix = 0;
                    int dataConversion [4];
                    int processType = 1; //----Out put image 8 bit color or gray
                    int numberOfLayers = 0;
                    int mode = 0;
                    int entryPosition = 0;
                    
                    struct stat sizeOfFile;
                    
                    ofstream oin;
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                        entry = arrayFileDelete [counter1];
                        
                        if ((int)entry.find("Snap") != -1){
                            extension = to_string(snapPage2*2);
                            
                            if (extension.length() == 1) extension = "00"+extension;
                            else if (extension.length() == 2) extension = "0"+extension;
                            
                            snapFilePath2 = informationDirectoryPath+"/"+entry;
                            fileSavePathHold = cellTrackingSystemDataPath+"/"+"SnapB-"+extension;
                            
                            if (stat(snapFilePath2.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                fileReadArray = new uint8_t [sizeForCopy+4];
                                fin.open(snapFilePath2.c_str(), ios::in | ios::binary);
                                
                                fin.read((char*)fileReadArray, sizeForCopy+1);
                                fin.close();
                                
                                dataConversion [0] = fileReadArray [0];
                                dataConversion [1] = fileReadArray [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = fileReadArray [7];
                                    dataConversion [1] = fileReadArray [6];
                                    dataConversion [2] = fileReadArray [5];
                                    dataConversion [3] = fileReadArray [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = fileReadArray [4];
                                    dataConversion [1] = fileReadArray [5];
                                    dataConversion [2] = fileReadArray [6];
                                    dataConversion [3] = fileReadArray [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                int *arrayExtractedImage3 = new int [100];
                                
                                if (endianType == 1){ //----Big endian----
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers:&zPosition];
                                    
                                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && numberOfLayers == 1 && samplePerPix <= 4 && photoMetric < 3 && imageWidth == cameraDimension && imageHeight == cameraDimension){
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:cameraDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                    }
                                }
                                else if (endianType == 0){
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers:&zPosition];
                                    
                                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && numberOfLayers == 1 && samplePerPix <= 4 && photoMetric < 3 && imageWidth == cameraDimension && imageHeight == cameraDimension){
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:cameraDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                    }
                                }
                                
                                //cout<<imageCompression<<" "<<imageBit<<" "<<" "<<samplePerPix<<" "<<photoMetric<<" "<<zPosition<<" "<<imageWidth<<" "<<cameraDimension<<" "<<numberOfLayers<<" entryinfo"<<endl;
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && numberOfLayers == 1 && samplePerPix <= 4 && photoMetric < 3 && imageWidth == cameraDimension && imageHeight == cameraDimension){
                                    
                                    horizontalBmp = 0;
                                    verticalBmp = 0;
                                    
                                    //----Saved image----
                                    arrayImageFileSave = new int *[cameraDimension+1];
                                    
                                    for (int counter3 = 0; counter3 < cameraDimension+1; counter3++){
                                        arrayImageFileSave [counter3] = new int [cameraDimension+1];
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cameraDimension; counter3++){
                                        for (int counter4 = 0; counter4 < cameraDimension; counter4++){
                                            arrayImageFileSave [counter3][counter4] = 0;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cameraDimension*cameraDimension; counter3++){
                                        if (horizontalBmp < cameraDimension){
                                            arrayImageFileSave [verticalBmp][horizontalBmp] = arrayExtractedImage3 [counter3], horizontalBmp++;
                                        }
                                        
                                        if (horizontalBmp == cameraDimension){
                                            horizontalBmp = 0;
                                            verticalBmp++;
                                        }
                                    }
                                    
                                    photoMetric = 1;
                                    imageBit = 8;
                                    
                                    if (xPosition == -1) xPosition = 100;
                                    if (yPosition == -1) yPosition = 100;
                                    if (zPosition == -1) zPosition = 100;
                                    
                                    singleTiffSave = [[SingleTiffSave alloc] init];
                                    [singleTiffSave singleTiffLayerSave:cameraDimension:cameraDimension:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:(unsigned long)mode:zPosition];
                                    
                                    for (int counter3 = 0; counter3 < cameraDimension+1; counter3++){
                                        delete [] arrayImageFileSave [counter3];
                                    }
                                    
                                    delete [] arrayImageFileSave;
                                    
                                    entryPosition = (snapPage2-1)*16;
                                    
                                    arraySnapMainData2 [entryPosition+6] = snapPage2*2;
                                    arraySnapMainData2 [entryPosition+7] = xPosition;
                                    arraySnapMainData2 [entryPosition+8] = yPosition;
                                    arraySnapMainData2 [entryPosition+9] = zPosition;
                                    
                                    oin.open(snapDataPath2.c_str(), ios::out);
                                    
                                    for (int counter2 = 0; counter2 < snapMainDataCount2; counter2++) oin<<arraySnapMainData2 [counter2]<<endl;
                                    
                                    oin.close();
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                }
                                else{
                                    
                                    remove (fileSavePathHold.c_str());
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"File Format Error"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                                
                                delete [] fileReadArray;
                                delete [] arrayExtractedImage3;
                            }
                            else{
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                            
                            remove (snapFilePath2.c_str());
                            
                            break;
                        }
                    }
                }
            }
            
            if (snapFirstSecondTime2 == 1){
                [snap3 setTextColor:[NSColor redColor]];
                [snap4 setTextColor:[NSColor blackColor]];
                [snap3 setStringValue:@"Time C"];
                [snap4 setStringValue:@"Time D"];
            }
            
            if (snapFirstSecondTime2 == 2){
                [snap3 setTextColor:[NSColor blackColor]];
                [snap4 setTextColor:[NSColor redColor]];
                [snap3 setStringValue:@"Time C"];
                [snap4 setStringValue:@"Time D"];
            }
            
            if (snapPage2 != 0){
                int entryPosition = (snapPage2-1)*16;
                
                arraySnapData2 [0] = arraySnapMainData2 [entryPosition]; //----Snap 1 no----
                arraySnapData2 [1] = arraySnapMainData2 [entryPosition+1]; //----X Corner Snap 1----
                arraySnapData2 [2] = arraySnapMainData2 [entryPosition+2]; //----Y Corner Snap 1----
                arraySnapData2 [3] = arraySnapMainData2 [entryPosition+3]; //----Z Corner Snap 1----
                arraySnapData2 [4] = arraySnapMainData2 [entryPosition+4]; //----X Position set 1----
                arraySnapData2 [5] = arraySnapMainData2 [entryPosition+5]; //----Y Position set 1----
                arraySnapData2 [6] = arraySnapMainData2 [entryPosition+6]; //----Snap 2 no----
                arraySnapData2 [7] = arraySnapMainData2 [entryPosition+7]; //----X Corner Snap 2----
                arraySnapData2 [8] = arraySnapMainData2 [entryPosition+8]; //----Y Corner Snap 2----
                arraySnapData2 [9] = arraySnapMainData2 [entryPosition+9]; //----Z Corner Snap 2----
                arraySnapData2 [10] = arraySnapMainData2 [entryPosition+10]; //----X Position set 2----
                arraySnapData2 [11] = arraySnapMainData2 [entryPosition+11]; //----X Position set 2----
                arraySnapData2 [12] = arraySnapMainData2 [entryPosition+12]; //----Set mark----
                arraySnapData2 [13] = arraySnapMainData2 [entryPosition+13]; //----X Diff----
                arraySnapData2 [14] = arraySnapMainData2 [entryPosition+14]; //----Y Diff----
                arraySnapData2 [15] = arraySnapMainData2 [entryPosition+15]; //----Z Diff----
                
                [pageNo2 setIntegerValue:snapPage2];
                
                if (arraySnapData2 [4] != 0 && arraySnapData2 [5] != 0){
                    [xPositionSnap3 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [4]]];
                    [yPositionSnap3 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [5]]];
                    [zPositionSnap3 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [3]]];
                }
                else{
                    
                    [xPositionSnap3 setStringValue:@"nil"];
                    [yPositionSnap3 setStringValue:@"nil"];
                    [zPositionSnap3 setStringValue:@"nil"];
                }
                
                if (arraySnapData2 [10] != 0 && arraySnapData2 [11] != 0){
                    [xPositionSnap4 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [10]]];
                    [yPositionSnap4 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [11]]];
                    [zPositionSnap4 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [9]]];
                }
                else{
                    
                    [xPositionSnap4 setStringValue:@"nil"];
                    [yPositionSnap4 setStringValue:@"nil"];
                    [zPositionSnap4 setStringValue:@"nil"];
                }
                
                if (arraySnapData2 [13] != 0 && arraySnapData2 [14] != 0){
                    int xDifferenceInt = (int)(round (arraySnapData2 [13]));
                    int yDifferenceInt = (int)(round (arraySnapData2 [14]));
                    
                    [xDiff3 setIntegerValue:xDifferenceInt];
                    [yDiff3 setIntegerValue:yDifferenceInt];
                    
                    [stepperX2 setMinValue:xDifferenceInt-200];
                    [stepperX2 setMaxValue:xDifferenceInt+200];
                    [stepperY2 setMinValue:yDifferenceInt-200];
                    [stepperY2 setMaxValue:yDifferenceInt+200];
                    
                    stepperLimitXL2 = xDifferenceInt-200, stepperLimitXH2 = xDifferenceInt+200;
                    stepperLimitYL2 = yDifferenceInt-200, stepperLimitYH2 = yDifferenceInt+200;
                    
                    [stepperX2 setIntValue:xDifferenceInt];
                    [stepperY2 setIntValue:yDifferenceInt];
                }
                else{
                    
                    [xDiff3 setStringValue:@""];
                    [yDiff3 setStringValue:@""];
                }
                
                string extension = to_string(snapPage2*2-1);
                
                if (extension.length() == 1) extension = "00"+extension;
                else if (extension.length() == 2) extension = "0"+extension;
                
                string snapSavePath = cellTrackingSystemDataPath+"/"+"SnapB-"+extension;
                string refPath = informationDirectoryPath+"/RefImage.tif";
                
                struct stat sizeOfFile;
                
                long sizeForCopy = 0;
                
                if (stat(snapSavePath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    ifstream infile (snapSavePath.c_str(), ifstream::binary);
                    ofstream outfile (refPath.c_str(), ofstream::binary);
                    
                    char *buffer = new char[sizeForCopy];
                    infile.read (buffer, sizeForCopy);
                    outfile.write (buffer, sizeForCopy);
                    delete [] buffer;
                    
                    outfile.close();
                    infile.close();
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                [xPositionSnap3 setStringValue:@"nil"];
                [yPositionSnap3 setStringValue:@"nil"];
                [xPositionSnap4 setStringValue:@"nil"];
                [yPositionSnap4 setStringValue:@"nil"];
                [zPositionSnap3 setStringValue:@"nil"];
                [zPositionSnap4 setStringValue:@"nil"];
                [xDiff3 setStringValue:@""];
                [yDiff3 setStringValue:@""];
                [pageNo2 setStringValue:@"nil"];
            }
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage3 object:self];
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage4 object:self];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Check The Destination Computer"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Maximum 100 Snaps: Delete Images"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)controlTextDidChange:(NSNotification *)aNotification {
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == xDiff3 && arraySnapData2 [12] != 0){
            if ([xDiff3 intValue] >= stepperLimitXL2 && [xDiff3 intValue] <= stepperLimitXH2){
                [stepperX2 setIntValue:[xDiff3 intValue]];
                arraySnapData2 [13] = [stepperX2 intValue];
                
                int entryPosition = (snapPage2-1)*16;
                arraySnapMainData2 [entryPosition+13] = arraySnapData2 [13];
                
                ofstream oin;
                
                oin.open(snapDataPath2.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < snapMainDataCount2; counter1++) oin<<arraySnapMainData2 [counter1]<<endl;
                
                oin.close();
            }
        }
        
        if ([aNotification object] == yDiff3 && arraySnapData2 [12] != 0){
            if ([yDiff3 intValue] >= stepperLimitYL2 && [yDiff3 intValue] <= stepperLimitYH2){
                [stepperY2 setIntValue:[yDiff3 intValue]];
                arraySnapData2 [14] = [stepperY2 intValue];
                
                int entryPosition = (snapPage2-1)*16;
                arraySnapMainData2 [entryPosition+14] = arraySnapData2 [14];
                
                ofstream oin;
                
                oin.open(snapDataPath2.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < snapMainDataCount2; counter1++) oin<<arraySnapMainData2 [counter1]<<endl;
                
                oin.close();
            }
        }
        
        if ([aNotification object] == stepperStartDisplay2){
            if ([stepperStartDisplay2 intValue] >= 1 && [stepperStartDisplay2 intValue] <= 500){
                [stepperStart2 setIntValue:[stepperStartDisplay2 intValue]];
                stepperStartHold2 = [stepperStartDisplay2 intValue];
            }
        }
    }
}

-(IBAction)stepperActionX3:(id)sender{
    if (arraySnapData2 [12] != 0){
        if ([stepperX2 intValue] >= stepperLimitXL2 && [stepperX2 intValue] <= stepperLimitXH2){
            [xDiff3 setIntValue:[stepperX2 intValue]];
            arraySnapData2 [13] = [stepperX2 intValue];
            
            int entryPosition = (snapPage2-1)*16;
            arraySnapMainData2 [entryPosition+13] = arraySnapData2 [13];
            
            ofstream oin;
            
            oin.open(snapDataPath2.c_str(), ios::out);
            
            for (int counter1 = 0; counter1 < snapMainDataCount2; counter1++) oin<<arraySnapMainData2 [counter1]<<endl;
            
            oin.close();
        }
    }
}

-(IBAction)stepperActionY3:(id)sender{
    if (arraySnapData2 [12] != 0){
        if ([stepperY2 intValue] >= stepperLimitYL2 && [stepperY2 intValue] <= stepperLimitYH2){
            [yDiff3 setIntValue:[stepperY2 intValue]];
            arraySnapData2 [14] = [stepperY2 intValue];
            
            int entryPosition = (snapPage2-1)*16;
            arraySnapMainData2 [entryPosition+14] = arraySnapData2 [14];
            
            ofstream oin;
            
            oin.open(snapDataPath2.c_str(), ios::out);
            
            for (int counter1 = 0; counter1 < snapMainDataCount2; counter1++) oin<<arraySnapMainData2 [counter1]<<endl;
            
            oin.close();
        }
    }
}

-(IBAction)stepperActionStart2:(id)sender{
    if ([stepperStart2 intValue] >= 1 && [stepperStart2 intValue] <= 500){
        [stepperStartDisplay2 setIntValue:[stepperStart2 intValue]];
        stepperStartHold2 = [stepperStart2 intValue];
    }
}

-(IBAction)timePointSWMain:(id)sender{
    if (snapFirstSecondTime2 == 1){
        snapFirstSecondTime2 = 2;
        
        [snap3 setTextColor:[NSColor blackColor]];
        [snap4 setTextColor:[NSColor redColor]];
        [snap3 setStringValue:@"Time C"];
        [snap4 setStringValue:@"Time D"];
        
        subProcesses = [[SubProcesses alloc] init];
        [subProcesses mapDataSave];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else if (snapFirstSecondTime2 == 2){
        snapFirstSecondTime2 = 1;
        
        [snap3 setTextColor:[NSColor redColor]];
        [snap4 setTextColor:[NSColor blackColor]];
        [snap3 setStringValue:@"Time C"];
        [snap4 setStringValue:@"Time D"];
        
        subProcesses = [[SubProcesses alloc] init];
        [subProcesses mapDataSave];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)clearPage:(id)sender{
    if (snapPage2 != 0){
        double *arraySnapMainDataTemp = new double [1700];
        int snapMainDataTempCount = 0;
        
        for (int counter1 = 0; counter1 < snapMainDataCount2/16; counter1++){
            if (counter1 != snapPage2-1){
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData2 [counter1*16], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData2 [counter1*16+1], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData2 [counter1*16+2], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData2 [counter1*16+3], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData2 [counter1*16+4], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData2 [counter1*16+5], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData2 [counter1*16+6], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData2 [counter1*16+7], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData2 [counter1*16+8], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData2 [counter1*16+9], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData2 [counter1*16+10], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData2 [counter1*16+11], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData2 [counter1*16+12], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData2 [counter1*16+13], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData2 [counter1*16+14], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData2 [counter1*16+15], snapMainDataTempCount++;
            }
        }
        
        for (int counter1 = 0; counter1 < 1700; counter1++) arraySnapMainData2 [counter1] = 0;
        
        snapMainDataCount2 = 0;
        for (int counter1 = 0; counter1 < snapMainDataTempCount; counter1++) arraySnapMainData2 [snapMainDataCount2] = arraySnapMainDataTemp [counter1], snapMainDataCount2++;
        delete [] arraySnapMainDataTemp;
        
        string entry;
        string removePath;
        string oldNamePath;
        string newNamePath;
        string stringExtract;
        
        fileDeleteCount = 0;
        
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(cellTrackingSystemDataPath.c_str());
        
        if (dir != NULL){
            while((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
            }
            
            closedir(dir);
            
            string extension;
            string extension2;
            
            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                entry = arrayFileDelete [counter1];
                
                extension = to_string(snapPage2*2);
                
                if (extension.length() == 1) extension = "00"+extension;
                else if (extension.length() == 2) extension = "0"+extension;
                
                extension2 = to_string(snapPage2*2-1);
                
                if (extension2.length() == 1) extension2 = "00"+extension2;
                else if (extension2.length() == 2) extension2 = "0"+extension2;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    if ((int)entry.find("SnapB-"+extension) != -1){
                        removePath = cellTrackingSystemDataPath+"/"+"SnapB-"+extension;
                        remove(removePath.c_str());
                    }
                    else if ((int)entry.find("SnapB-"+extension2) != -1){
                        removePath = cellTrackingSystemDataPath+"/"+"SnapB-"+extension2;
                        remove(removePath.c_str());
                    }
                }
            }
        }
        
        fileDeleteCount = 0;
        
        dir = opendir(cellTrackingSystemDataPath.c_str());
        
        if (dir != NULL){
            while((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                    arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                }
            }
            
            closedir(dir);
            
            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                entry = arrayFileDelete [counter1];
                
                if ((int)entry.find("SnapB-") != -1){
                    stringExtract = entry.substr(6);
                    int snapNo = atoi(stringExtract.c_str());
                    
                    if (snapNo > snapPage2*2){
                        string extension3 = to_string(snapNo-2);
                        
                        if (extension3.length() == 1) extension3 = "00"+extension3;
                        else if (extension3.length() == 2) extension3 = "0"+extension3;
                        
                        oldNamePath = cellTrackingSystemDataPath+"/"+entry;
                        newNamePath = cellTrackingSystemDataPath+"/"+"SnapB-"+extension3;
                        
                        rename (oldNamePath.c_str(), newNamePath.c_str());
                    }
                }
            }
        }
        
        if (snapMainDataCount2 == 0) snapPage2 = 0;
        else if (snapMainDataCount2 != 0){
            if (snapPage2-1 == 0) snapPage2 = 1;
            else snapPage2 = snapPage2-1;
        }
        
        if (snapPage2 != 0){
            int entryPosition = (snapPage2-1)*16;
            
            arraySnapData2 [0] = arraySnapMainData2 [entryPosition]; //----Snap 1 no----
            arraySnapData2 [1] = arraySnapMainData2 [entryPosition+1]; //----X Corner Snap 1----
            arraySnapData2 [2] = arraySnapMainData2 [entryPosition+2]; //----Y Corner Snap 1----
            arraySnapData2 [3] = arraySnapMainData2 [entryPosition+3]; //----Z Corner Snap 1----
            arraySnapData2 [4] = arraySnapMainData2 [entryPosition+4]; //----X Position set 1----
            arraySnapData2 [5] = arraySnapMainData2 [entryPosition+5]; //----Y Position set 1----
            arraySnapData2 [6] = arraySnapMainData2 [entryPosition+6]; //----Snap 2 no----
            arraySnapData2 [7] = arraySnapMainData2 [entryPosition+7]; //----X Corner Snap 2----
            arraySnapData2 [8] = arraySnapMainData2 [entryPosition+8]; //----Y Corner Snap 2----
            arraySnapData2 [9] = arraySnapMainData2 [entryPosition+9]; //----Z Corner Snap 2----
            arraySnapData2 [10] = arraySnapMainData2 [entryPosition+10]; //----X Position set 2----
            arraySnapData2 [11] = arraySnapMainData2 [entryPosition+11]; //----X Position set 2----
            arraySnapData2 [12] = arraySnapMainData2 [entryPosition+12]; //----Set mark----
            arraySnapData2 [13] = arraySnapMainData2 [entryPosition+13]; //----X Diff----
            arraySnapData2 [14] = arraySnapMainData2 [entryPosition+14]; //----Y Diff----
            arraySnapData2 [15] = arraySnapMainData2 [entryPosition+15]; //----Z Diff----
            
            [pageNo2 setIntegerValue:snapPage2];
            
            if (arraySnapData2 [4] != 0 && arraySnapData2 [5] != 0){
                [xPositionSnap3 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [4]]];
                [yPositionSnap3 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [5]]];
                [zPositionSnap3 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [3]]];
            }
            else{
                
                [xPositionSnap3 setStringValue:@"nil"];
                [yPositionSnap3 setStringValue:@"nil"];
                [zPositionSnap3 setStringValue:@"nil"];
            }
            
            if (arraySnapData2 [10] != 0 && arraySnapData2 [11] != 0){
                [xPositionSnap4 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [10]]];
                [yPositionSnap4 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [11]]];
                [zPositionSnap4 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [9]]];
            }
            else{
                
                [xPositionSnap4 setStringValue:@"nil"];
                [yPositionSnap4 setStringValue:@"nil"];
                [zPositionSnap4 setStringValue:@"nil"];
            }
            
            if (arraySnapData2 [13] != 0 && arraySnapData2 [14] != 0){
                int xDifferenceInt = (int)(round (arraySnapData2 [13]));
                int yDifferenceInt = (int)(round (arraySnapData2 [14]));
                
                [xDiff3 setIntegerValue:xDifferenceInt];
                [yDiff3 setIntegerValue:yDifferenceInt];
                
                [stepperX2 setMinValue:xDifferenceInt-200];
                [stepperX2 setMaxValue:xDifferenceInt+200];
                [stepperY2 setMinValue:yDifferenceInt-200];
                [stepperY2 setMaxValue:yDifferenceInt+200];
                
                stepperLimitXL2 = xDifferenceInt-200;
                stepperLimitXH2 = xDifferenceInt+200;
                stepperLimitYL2 = yDifferenceInt-200;
                stepperLimitYH2 = yDifferenceInt+200;
                
                [stepperX2 setIntValue:xDifferenceInt];
                [stepperY2 setIntValue:yDifferenceInt];
            }
            else{
                
                [xDiff3 setStringValue:@""];
                [yDiff3 setStringValue:@""];
            }
            
            string extension = to_string(snapPage2*2-1);
            
            if (extension.length() == 1) extension = "00"+extension;
            else if (extension.length() == 2) extension = "0"+extension;
            
            string snapSavePath = cellTrackingSystemDataPath+"/"+"SnapB-"+extension;
            string refPath = informationDirectoryPath+"/RefImage.tif";
            
            struct stat sizeOfFile;
            
            long sizeForCopy = 0;
            
            if (stat(snapSavePath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                ifstream infile (snapSavePath.c_str(), ifstream::binary);
                ofstream outfile (refPath.c_str(), ofstream::binary);
                
                char *buffer = new char[sizeForCopy];
                infile.read (buffer, sizeForCopy);
                outfile.write (buffer, sizeForCopy);
                delete [] buffer;
                
                outfile.close();
                infile.close();
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            [xPositionSnap3 setStringValue:@"nil"];
            [yPositionSnap3 setStringValue:@"nil"];
            [xPositionSnap4 setStringValue:@"nil"];
            [yPositionSnap4 setStringValue:@"nil"];
            [zPositionSnap3 setStringValue:@"nil"];
            [zPositionSnap4 setStringValue:@"nil"];
            [xDiff3 setStringValue:@""];
            [yDiff3 setStringValue:@""];
            [pageNo2 setStringValue:@"nil"];
        }
        
        ofstream oin;
        
        oin.open(snapDataPath2.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 < snapMainDataCount2; counter1++) oin<<arraySnapMainData2 [counter1]<<endl;
        
        oin.close();
        
        subProcesses = [[SubProcesses alloc] init];
        [subProcesses mapDataSave];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage3 object:self];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage4 object:self];
    }
}

-(IBAction)pageFW:(id)sender{
    if (snapPage2 != 0){
        int findFlag = 0;
        
        if (arraySnapMainData2 [snapPage2*16] != 0) findFlag = 1;
        
        if (findFlag == 1){
            snapPage2++;
            
            [pageNo2 setIntegerValue:snapPage2];
            
            int entryPosition = (snapPage2-1)*16;
            
            arraySnapData2 [0] = arraySnapMainData2 [entryPosition]; //----Snap 1 no----
            arraySnapData2 [1] = arraySnapMainData2 [entryPosition+1]; //----X Corner Snap 1----
            arraySnapData2 [2] = arraySnapMainData2 [entryPosition+2]; //----Y Corner Snap 1----
            arraySnapData2 [3] = arraySnapMainData2 [entryPosition+3]; //----Z Corner Snap 1----
            arraySnapData2 [4] = arraySnapMainData2 [entryPosition+4]; //----X Position set 1----
            arraySnapData2 [5] = arraySnapMainData2 [entryPosition+5]; //----Y Position set 1----
            arraySnapData2 [6] = arraySnapMainData2 [entryPosition+6]; //----Snap 2 no----
            arraySnapData2 [7] = arraySnapMainData2 [entryPosition+7]; //----X Corner Snap 2----
            arraySnapData2 [8] = arraySnapMainData2 [entryPosition+8]; //----Y Corner Snap 2----
            arraySnapData2 [9] = arraySnapMainData2 [entryPosition+9]; //----Z Corner Snap 2----
            arraySnapData2 [10] = arraySnapMainData2 [entryPosition+10]; //----X Position set 2----
            arraySnapData2 [11] = arraySnapMainData2 [entryPosition+11]; //----X Position set 2----
            arraySnapData2 [12] = arraySnapMainData2 [entryPosition+12]; //----Set mark----
            arraySnapData2 [13] = arraySnapMainData2 [entryPosition+13]; //----X Diff----
            arraySnapData2 [14] = arraySnapMainData2 [entryPosition+14]; //----Y Diff----
            arraySnapData2 [15] = arraySnapMainData2 [entryPosition+15]; //----Z Diff----
            
            if (arraySnapData2 [4] != 0 && arraySnapData2 [5] != 0){
                [xPositionSnap3 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [4]]];
                [yPositionSnap3 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [5]]];
                [zPositionSnap3 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [3]]];
            }
            else{
                
                [xPositionSnap3 setStringValue:@"nil"];
                [yPositionSnap3 setStringValue:@"nil"];
                [zPositionSnap3 setStringValue:@"nil"];
            }
            
            if (arraySnapData2 [10] != 0 && arraySnapData2 [11] != 0){
                [xPositionSnap4 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [10]]];
                [yPositionSnap4 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [11]]];
                [zPositionSnap4 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [9]]];
            }
            else{
                
                [xPositionSnap4 setStringValue:@"nil"];
                [yPositionSnap4 setStringValue:@"nil"];
                [zPositionSnap4 setStringValue:@"nil"];
            }
            
            if (arraySnapData2 [13] != 0 && arraySnapData2 [14] != 0){
                int xDifferenceInt = (int)(round (arraySnapData2 [13]));
                int yDifferenceInt = (int)(round (arraySnapData2 [14]));
                
                [xDiff3 setIntegerValue:xDifferenceInt];
                [yDiff3 setIntegerValue:yDifferenceInt];
                
                [stepperX2 setMinValue:xDifferenceInt-200];
                [stepperX2 setMaxValue:xDifferenceInt+200];
                [stepperY2 setMinValue:yDifferenceInt-200];
                [stepperY2 setMaxValue:yDifferenceInt+200];
                
                stepperLimitXL2 = xDifferenceInt-200;
                stepperLimitXH2 = xDifferenceInt+200;
                stepperLimitYL2 = yDifferenceInt-200;
                stepperLimitYH2 = yDifferenceInt+200;
                
                [stepperX2 setIntValue:xDifferenceInt];
                [stepperY2 setIntValue:yDifferenceInt];
            }
            else{
                
                [xDiff3 setStringValue:@""];
                [yDiff3 setStringValue:@""];
            }
            
            string extension = to_string(snapPage2*2-1);
            
            if (extension.length() == 1) extension = "00"+extension;
            else if (extension.length() == 2) extension = "0"+extension;
            
            string snapSavePath = cellTrackingSystemDataPath+"/"+"SnapB-"+extension;
            string refPath = informationDirectoryPath+"/RefImage.tif";
            
            struct stat sizeOfFile;
            
            long sizeForCopy = 0;
            
            if (stat(snapSavePath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                ifstream infile (snapSavePath.c_str(), ifstream::binary);
                ofstream outfile (refPath.c_str(), ofstream::binary);
                
                char *buffer = new char[sizeForCopy];
                infile.read (buffer, sizeForCopy);
                outfile.write (buffer, sizeForCopy);
                delete [] buffer;
                
                outfile.close();
                infile.close();
                
                subProcesses = [[SubProcesses alloc] init];
                [subProcesses mapDataSave];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage3 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage4 object:self];
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)pageBW:(id)sender{
    if (snapPage2 != 0){
        if (snapPage2 > 1){
            snapPage2--;
            
            [pageNo2 setIntegerValue:snapPage2];
            
            int entryPosition = (snapPage2-1)*16;
            
            arraySnapData2 [0] = arraySnapMainData2 [entryPosition]; //----Snap 1 no----
            arraySnapData2 [1] = arraySnapMainData2 [entryPosition+1]; //----X Corner Snap 1----
            arraySnapData2 [2] = arraySnapMainData2 [entryPosition+2]; //----Y Corner Snap 1----
            arraySnapData2 [3] = arraySnapMainData2 [entryPosition+3]; //----Z Corner Snap 1----
            arraySnapData2 [4] = arraySnapMainData2 [entryPosition+4]; //----X Position set 1----
            arraySnapData2 [5] = arraySnapMainData2 [entryPosition+5]; //----Y Position set 1----
            arraySnapData2 [6] = arraySnapMainData2 [entryPosition+6]; //----Snap 2 no----
            arraySnapData2 [7] = arraySnapMainData2 [entryPosition+7]; //----X Corner Snap 2----
            arraySnapData2 [8] = arraySnapMainData2 [entryPosition+8]; //----Y Corner Snap 2----
            arraySnapData2 [9] = arraySnapMainData2 [entryPosition+9]; //----Z Corner Snap 2----
            arraySnapData2 [10] = arraySnapMainData2 [entryPosition+10]; //----X Position set 2----
            arraySnapData2 [11] = arraySnapMainData2 [entryPosition+11]; //----X Position set 2----
            arraySnapData2 [12] = arraySnapMainData2 [entryPosition+12]; //----Set mark----
            arraySnapData2 [13] = arraySnapMainData2 [entryPosition+13]; //----X Diff----
            arraySnapData2 [14] = arraySnapMainData2 [entryPosition+14]; //----Y Diff----
            arraySnapData2 [15] = arraySnapMainData2 [entryPosition+15]; //----Z Diff----
            
            if (arraySnapData2 [4] != 0 && arraySnapData2 [5] != 0){
                [xPositionSnap3 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [4]]];
                [yPositionSnap3 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [5]]];
                [zPositionSnap3 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [3]]];
            }
            else{
                
                [xPositionSnap3 setStringValue:@"nil"];
                [yPositionSnap3 setStringValue:@"nil"];
                [zPositionSnap3 setStringValue:@"nil"];
            }
            
            if (arraySnapData2 [10] != 0 && arraySnapData2 [11] != 0){
                [xPositionSnap4 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [10]]];
                [yPositionSnap4 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [11]]];
                [zPositionSnap4 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData2 [9]]];
            }
            else{
                
                [xPositionSnap4 setStringValue:@"nil"];
                [yPositionSnap4 setStringValue:@"nil"];
                [zPositionSnap4 setStringValue:@"nil"];
            }
            
            if (arraySnapData2 [13] != 0 && arraySnapData2 [14] != 0){
                int xDifferenceInt = (int)(round (arraySnapData2 [13]));
                int yDifferenceInt = (int)(round (arraySnapData2 [14]));
                
                [xDiff3 setIntegerValue:xDifferenceInt];
                [yDiff3 setIntegerValue:yDifferenceInt];
                
                [stepperX2 setMinValue:xDifferenceInt-200];
                [stepperX2 setMaxValue:xDifferenceInt+200];
                [stepperY2 setMinValue:yDifferenceInt-200];
                [stepperY2 setMaxValue:yDifferenceInt+200];
                
                stepperLimitXL2 = xDifferenceInt-200;
                stepperLimitXH2 = xDifferenceInt+200;
                stepperLimitYL2 = yDifferenceInt-200;
                stepperLimitYH2 = yDifferenceInt+200;
                
                [stepperX2 setIntValue:xDifferenceInt];
                [stepperY2 setIntValue:yDifferenceInt];
            }
            else{
                
                [xDiff3 setStringValue:@""];
                [yDiff3 setStringValue:@""];
            }
            
            string extension = to_string(snapPage2*2-1);
            
            if (extension.length() == 1) extension = "00"+extension;
            else if (extension.length() == 2) extension = "0"+extension;
            
            string snapSavePath = cellTrackingSystemDataPath+"/"+"SnapB-"+extension;
            string refPath = informationDirectoryPath+"/RefImage.tif";
            
            struct stat sizeOfFile;
            
            long sizeForCopy = 0;
            
            if (stat(snapSavePath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                ifstream infile (snapSavePath.c_str(), ifstream::binary);
                ofstream outfile (refPath.c_str(), ofstream::binary);
                
                char *buffer = new char[sizeForCopy];
                infile.read (buffer, sizeForCopy);
                outfile.write (buffer, sizeForCopy);
                delete [] buffer;
                
                outfile.close();
                infile.close();
                
                subProcesses = [[SubProcesses alloc] init];
                [subProcesses mapDataSave];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage3 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage4 object:self];
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)reDisplayWindow{
    if (snapOperation2 == 3){
        [snapWindow2 makeKeyAndOrderFront:self];
        snapOperation2 = 1;
        [snapTimer2 invalidate];
    }
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    if (snapTimer2) [snapTimer2 invalidate];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToSnapHandle2 object:nil];
}

@end
