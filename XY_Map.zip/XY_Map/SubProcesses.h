//
//  SubProcesses.h
//  XY_Map
//
//  Created by Masahiko Sato on 2022-02-16.
//

#ifndef SUBPROCESSES_H
#define SUBPROCESSES_H
#import "Controller.h"
#endif

@interface SubProcesses : NSObject{
}

-(void)mapDataSave;

@end
