//
//  FocusCheckImage.h
//  XY_Map
//
//  Created by Masahiko Sato on 2014-10-29.
//
//

#ifndef FOCUSCHECKIMAGE_H
#define FOCUSCHECKIMAGE_H
#import "Controller.h" 
#endif

@interface  FocusCheckImage : NSView {
    int magnificationFocus; //Display control
    
    double xPositionFocus; //Display control
    double yPositionFocus; //Display control
    double xPositionAdjustFocus; //Display control
    double yPositionAdjustFocus; //Display control
    double xPointDownFocus; //Display control
    double yPointDownFocus; //Display control
    double xPointDragFocus; //Display control
    double yPointDragFocus; //Display control
    double xPositionMoveFocus; //Display control
    double yPositionMoveFocus; //Display control
    double windowWidthFocus; //Display control
    double windowHeightFocus; //Display control
    
    IBOutlet NSImage *focusImage1;
}

-(void)mouseDown:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)mouseDraged:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
