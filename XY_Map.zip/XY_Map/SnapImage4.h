//
//  SnapImage4.h
//  XY_Map
//
//  Created by Masahiko Sato on 2014-08-23.
//
//

#ifndef SNAPIMAGE4_H
#define SNAPIMAGE4_H
#import "Controller.h"
#endif

@interface SnapImage4 : NSView {
    int magnificationSnap4; //Display control
    
    int mouseDragFlag; //Display control
    double xPositionSnap4; //Display control
    double yPositionSnap4; //Display control
    double xPositionAdjustSnap4; //Display control
    double yPositionAdjustSnap4; //Display control
    double xPointDownSnap4; //Display control
    double yPointDownSnap4; //Display control
    double xPointDragSnap4; //Display control
    double yPointDragSnap4; //Display control
    double xPositionMoveSnap4; //Display control
    double yPositionMoveSnap4; //Display control
    double windowWidthSnap4; //Display control
    double windowHeightSnap4; //Display control
    
    IBOutlet NSImage *snapWindowImage4;
    
    id tiffFileRead;
}

-(void)mouseDown:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)mouseDraged:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
