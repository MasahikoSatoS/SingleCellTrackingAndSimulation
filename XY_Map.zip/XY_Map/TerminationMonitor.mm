//
//  TerminationMonitor.m
//  XY_Map
//
//  Created by Masahiko Sato on 12/12/16.
//
//

#import "TerminationMonitor.h"

NSString *notificationToTermination = @"notificationExecuteTermination";

@implementation TerminationMonitor

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToTermination object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    commTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(processControl) userInfo:nil repeats:YES];
}

-(void)processControl{
    NSString *activeProcess;
    
    int mainControllerActive = 1;
    
    for (NSRunningApplication *currApp in [[NSWorkspace sharedWorkspace] runningApplications]){
        activeProcess = [currApp localizedName];
        
        if ([activeProcess isEqualToString:@"Imaging_Controller"]) mainControllerActive = 2;
    }
    
    if (mainControllerActive == 1){
        delete [] arrayWellPosition1;
        delete [] arrayWellPosition2;
        delete [] arraySelectedMap1;
        delete [] arraySelectedMap2;
        delete [] arrayTableXYDimension;
        delete [] arrayTableZ;
        delete [] arrayReadingPositionMDA;
        delete [] arrayLabelPosition1;
        delete [] arrayLabelPosition2;
        delete [] arrayTableXYDimensionHold;
        delete [] arrayTableZHold;
        delete [] arraySnapData;
        delete [] arraySnapData2;
        delete [] arraySnapMainData;
        delete [] arraySnapMainData2;
        delete [] arrayDirectoryInfo;
        delete [] arrayFileDelete;
        delete [] wellPositionTest;
        
        if (imageDataHoldZImageStatus == 1){
            for (int counter1 = 0; counter1 < zImageHeight*zImagePlane+2; counter1++) delete [] arrayImageDataHoldZImage [counter1];
            delete [] arrayImageDataHoldZImage;
        }
        
        exit (0);
    }
}

-(void)dealloc{
    if (commTimer) [commTimer invalidate];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToTermination object:nil];
}

@end
