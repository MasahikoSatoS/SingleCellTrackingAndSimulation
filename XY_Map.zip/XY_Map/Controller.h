//
//  Controller.h
//  XY_Map
//
//  Created by Masahiko Sato on 11/04/29, 28/05/13 revised.
//  Copyright 2011 Masahiko Sato All rights reserved.
//

#ifndef CONTROLLER_H
#define CONTROLLER_H
#import <Cocoa/Cocoa.h>
#import "XYMap.h"
#import "XYMap2.h"
#import "WellDataWrite.h"
#import "ASCIIconversion.h"
#import "Communication.h"
#import "SnapHandle.h"
#import "SnapHandle2.h"
#import "FocusCheckControl.h"
#import "FocusCheckImage.h"
#import "FocusCheckAddition.h"
#import "SnapImage.h"
#import "SnapImage2.h"
#import "SnapImage3.h" 
#import "SnapImage4.h" 
#import "TerminationMonitor.h"
#import "SubProcesses.h"
#import "TiffFileRead.h"
#import "SingleTiffSave.h"
#include <iostream>
#include <string>
#include <cstdio>
#include <dirent.h>
#include <sys/stat.h>
#include <fstream>
#include <sstream>
#endif

using namespace std;

extern NSString *notificationToXYMap;
extern NSString *notificationToXYMap2;
extern NSString *notificationToCommunication;
extern NSString *notificationToSnapHandle;
extern NSString *notificationToSnapHandle2;
extern NSString *notificationToSnapImage;
extern NSString *notificationToSnapImage2;
extern NSString *notificationToSnapImage3;
extern NSString *notificationToSnapImage4;
extern NSString *notificationToFocusCheckImage;
extern NSString *notificationToFocusCheckControl;
extern NSString *notificationToFocusCheckAddition;
extern NSString *notificationToTermination;

//----Map operation----
extern double *arrayWellPosition1; //Array for Well Position Map1
extern int wellPositionCount1;
extern double *arrayWellPosition2; //Array for Well Position Map2
extern int wellPositionCount2;
extern double *arrayLabelPosition1; //Label Position1
extern int labelPositionCount1;
extern double *arrayLabelPosition2; //Label Position2
extern int labelPositionCount2;
extern double *arrayReadingPositionMDA; //Array for Memorized position 2
extern int readingPositionMDACount;
extern int readingPositionMDALimit;
extern double *arraySelectedMap1; //Array for Selected FOV Map 1
extern int selectedMapCount1;
extern int selectedMapLimit1;
extern int selectedMapAddition1;
extern double *arraySelectedMap2; //Array for Selected FOV Map 2
extern int selectedMapCount2;
extern int selectedMapLimit2;
extern int selectedMapAddition2;
extern int *arrayTableXYDimension; //Array for XY data and FOV dimension (XY)
extern int tableXYDimensionCount;
extern double *arrayTableZ; //Array for Z data
extern int tableZCount;
extern int *arrayTableXYDimensionHold; //Array for XY data and FOV dimension (XY) Hold
extern int tableXYDimensionHoldCount;
extern double *arrayTableZHold; //Array for Z data Hold
extern int tableZHoldCount;
extern string *arrayFileDelete; //File name that will be deleted hold
extern int fileDeleteCount;
extern int fileDeleteLimit;
extern string instructionMapPath; //Instruction Path
extern string instructionMapPath2; //Instruction Path
extern int cameraDimension; //Camera dimension
extern string fileSavePathHold; //Path for Tiff file save
extern int **arrayImageFileSave; //Image array for tif save
extern uint8_t *fileReadArray; //Array holding image data

extern string pathNameString; //Path name
extern string ascIIstring; //AscII string data
extern string xyLogFilePath; //XY position log file path
extern string positionMDAPath; //Memorize position Windows file path
extern string savedDataPath; //File path for Well XY position, Marker XY position, Selected FOV XY position
extern string bodyName; //Body name hold
extern string computerName; //Computer name hold
extern string analysisDataPath; //Basic info path
extern string xyMapDataPath; //xy Map Info path (Corner 1 XY position, Corner2 XY Position, Objective magnification)
extern string xyDimensionMapPath; //File path for XY data and dimension
extern string zMapPath; //File path for Z data
extern string stgSavePath; //File path for STG data
extern string savedDataLastSavePath; //File path for Well XY position, Marker XY position, Selected FOV XY position, Last save
extern string xyDimensionMapSavePath; //File path for XY data and dimension, Last Save
extern string zMapSavePath; //File path for Z Last Save data
extern string xyBasicDataPath; //xy Data path
extern string dataDirectoryPath; //Data path
extern string informationDirectoryPath; //Information path

extern int drawingPermit1; //Set during the ApplicationDisFinish to allow map drawing
extern int drawingPermit2; //Set during the ApplicationDisFinish to allow map drawing
extern int xFOVTaken; //Array dimension
extern int yFOVTaken; //Array dimension
extern int objectiveSelect; //Selected Objective info
extern int wellDataSaveRequest; //Request data sav
extern int mapReadFlag1; //Flag for Map Read map1
extern int mapReadFlag2; //Flag for Map Read map1
extern int displayCheck1; //Map display timing
extern int displayCheck2; //Map display timing
extern double xClickCurrent; //Click XY position, for Array S press and Set
extern double yClickCurrent; //Click XY position, for Array S press and Set
extern double xPositionCurrent; //XY Current objective position
extern double yPositionCurrent; //XY Current objective position
extern int saveDoneFlag; //Save done
extern int autoCommitStatus; //Status of Auto Commitment
extern int batchCommitStatus; //Status of Batch Commitment
extern int initialCommitStatus; //Status of Initial Commitment
extern int analysisNameDisplayCall; //Status of Initial Commitment
extern int drawingOrientation; //0:BL, 1: BR, 2: TL, 3: TL
extern int stepperStartHoldM; //For Test MDA
extern int stepperEveryHoldM; //For Test MDA

//----Snap operation----
extern int chamberType1; //1: LabTeck II 8, 2: ibidi 2, 3: ibidi 4, 4: ibidi 8
extern int chamberType2; //1: LabTeck II 8, 2: ibidi 2, 3: ibidi 4, 4: ibidi 8
extern int chamberWellLimit1; //Number of wells
extern int chamberWellLimit2; //Number of wells
extern int snapOperation; //Orientation of snap
extern int snapOperation2; //Orientation of snap
extern int snapFirstSecondTime; //Snap select
extern int snapFirstSecondTime2; //Snap select
extern double *arraySnapData; //Local Array for Snap Data 1
extern double *arraySnapMainData; //Array for Snap Data, main data 1
extern int snapMainDataCount; //Array for Snap Data, main data 1
extern double *arraySnapData2; //Local Array for Snap Data 2
extern double *arraySnapMainData2; //Array for Snap Data, main data 2
extern int snapMainDataCount2; //Array for Snap Data, main data 2
extern int snapStart; //Start memorized position 1
extern int snapStart2; //Start memorized position 2
extern int snapPage; //Snap page no
extern int snapPage2; //Snap page no
extern string cellTrackingSystemDataPath; //System data path
extern string snapDataPath1; //Snap data path1
extern string snapDataPath2; //Snap data Path2
extern int imageFirstLoadFlagSnap1; //Snap image first load
extern int xClickPositionSnap1; //X click position
extern int yClickPositionSnap1; //Y click position
extern int imageFirstLoadFlagSnap2; //Snap image first load
extern int xClickPositionSnap2; //X click position
extern int yClickPositionSnap2; //Y click position
extern int imageFirstLoadFlagSnap3; //Snap image first load
extern int xClickPositionSnap3; //X click position
extern int yClickPositionSnap3; //Y click position
extern int imageFirstLoadFlagSnap4; //Snap image first load
extern int xClickPositionSnap4; //X click position
extern int yClickPositionSnap4; //Y click position
extern int stepperStartHold1; //For Test MDA
extern int stepperStartHold2; //For Test MDA
extern int *arrayAscIIintData; //ASCII array
extern int ascIIintDataCount;

//----Focus check----
extern int focusOperation; //Focus operation window control
extern int **arrayImageDataHoldZImage; //Z image array
extern int imageDataHoldZImageStatus;
extern int zImageHeight; //Z image height
extern int zImageWidth; //Z image width
extern int zImagePlane; //Z image data
extern int planeNumberDisplay; //Plane number
extern int currentPlaneDisplayCall; //Plane number display call
extern int imageFirstLoadFlagFocus; //Focus image first load
extern int fileNameHoldCall; //File name hold call
extern double contrastAdjust; //Contrast adjust
extern string userName; //User name
extern string fileNameHold; //File name
extern int focusPhotometric; //Photometric for Focus 

//----Directory temp save----
extern string *arrayDirectoryInfo; //Temp file list
extern int directoryInfoCount;
extern int directoryInfoLimit;

//----Well orientation----
extern int wellOrientation1; //Well orientation
extern int wellOrientation2; //Well orientation
extern int wellOrientation3; //Well orientation

//----Test MDA----
extern int *wellPositionTest; //Well position test

@interface Controller : NSObject <NSTextFieldDelegate, NSTableViewDataSource>{
    int zValueAdjustWell; //Well no for Z value Adjust
    long stgMemorizedSizeHold; //Hold file size of memorized position
    int tableViewCall; //Call Table View
    double xCorner1; //Map 1 corner
    double yCorner1;
    double xCorner2; //Map 2 corner
    double yCorner2;
    double xClickCurrentHold; //Click XY position (Previous), for Array S press and Set
    double yClickCurrentHold; //Click XY position (Previous), for Array S press and Set
    double zValueAdjust; //Hold Z value for adjust
    int zPositionSaveCount; //Count Z position after STG save
    
    IBOutlet NSTableView *tableViewList;
    
    IBOutlet NSTextField *xNumberPointTake;
    IBOutlet NSTextField *yNumberPointTake;
    IBOutlet NSTextField *analysisName;
    IBOutlet NSTextField *totalFOV;
    IBOutlet NSTextField *currentX;
    IBOutlet NSTextField *currentY;
    IBOutlet NSTextField *cornerX1;
    IBOutlet NSTextField *cornerY1;
    IBOutlet NSTextField *cornerX2;
    IBOutlet NSTextField *cornerY2;
    IBOutlet NSTextField *zAdjustWell;
    IBOutlet NSTextField *zAdjustValue;
    IBOutlet NSTextField *magnification;
    IBOutlet NSTextField *chamberDisplay1;
    IBOutlet NSTextField *chamberDisplay2;
    IBOutlet NSTextField *orientationDR;
    IBOutlet NSTextField *orientationWell1;
    IBOutlet NSTextField *orientationWell2;
    IBOutlet NSTextField *orientationWell3;
    IBOutlet NSTextField *stepperStartDisplayM;
    IBOutlet NSTextField *stepperEveryDisplayM;
    IBOutlet NSTextField *cameraDimensionDisplay;
    
    IBOutlet NSStepper *stepperX;
    IBOutlet NSStepper *stepperY;
    IBOutlet NSStepper *stepperWell;
    IBOutlet NSStepper *stepperZ;
    
    IBOutlet NSStepper *stepperStartM;
    IBOutlet NSStepper *stepperEveryM;
    
    IBOutlet NSWindow *controllerWindow;
    IBOutlet NSWindow *mapWindow1;
    IBOutlet NSWindow *mapWindow2;
    
    NSTimer *controllerTimer;
    
    NSWindowController *mapWindowTC1;
    NSWindowController *mapWindowTC2;
    
    id ascIIconversion;
    id wellDataWrite;
    id subProcesses;
}

-(id)init;
-(void)dealloc;
-(void)userPathSet;
-(void)displayData;
-(void)saveCurrentData;
-(void)saveCornerData;
-(void)mapWellLabelSet1;
-(void)mapWellLabelSet2;
-(void)readingPositionMDAUpDate;
-(void)selectedMapUpDate1;
-(void)selectedMapUpDate2;
-(void)saveLastSavedData;
-(void)saveZPositionData;
-(void)refreshPerform;
-(void)fileDeleteUpDate;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;

-(IBAction)chamber1:(id)sender;
-(IBAction)chamber2:(id)sender;
-(IBAction)toolBarRefresh:(id)sender;
-(IBAction)stopProcess:(id)sender;
-(IBAction)toolBarSave:(id)sender;
-(IBAction)toolBarObjective:(id)sender;
-(IBAction)zValueSet:(id)sender;
-(IBAction)stepperActionX:(id)sender;
-(IBAction)stepperActionY:(id)sender;
-(IBAction)stepperActionWell:(id)sender;
-(IBAction)stepperActionZ:(id)sender;
-(IBAction)lastSavedPointLoad:(id)sender;
-(IBAction)stgFileAllClear:(id)sender;
-(IBAction)stgMemorizedClear:(id)sender;
-(IBAction)chamberSelect1:(id)sender;
-(IBAction)chamberSelect2:(id)sender;
-(IBAction)chamberSelect3:(id)sender;
-(IBAction)chamberSelect4:(id)sender;
-(IBAction)chamberSelect5:(id)sender;
-(IBAction)chamberSelect6:(id)sender;
-(IBAction)chamberSelect7:(id)sender;
-(IBAction)chamberSelect8:(id)sender;
-(IBAction)chamberSelect9:(id)sender;
-(IBAction)chamberSelect10:(id)sender;
-(IBAction)memorizePosition:(id)sender;
-(IBAction)memorizePosition2:(id)sender;
-(IBAction)orientationSet:(id)sender;
-(IBAction)focusCheckSet:(id)sender;
-(IBAction)wellOrientationSet1:(id)sender;
-(IBAction)wellOrientationSet2:(id)sender;
-(IBAction)wellOrientationSet3:(id)sender;
-(IBAction)stepperActionStartM:(id)sender;
-(IBAction)stepperActionEveryM:(id)sender;
-(IBAction)createTestM:(id)sender;
-(IBAction)camera512x512:(id)sender;
-(IBAction)camera1024x1024:(id)sender;
-(IBAction)camera1536x1536:(id)sender;
-(IBAction)camera2048x2048:(id)sender;
-(IBAction)reloadPrevZ:(id)sender;
-(IBAction)saveCurrentZ:(id)sender;

@end
