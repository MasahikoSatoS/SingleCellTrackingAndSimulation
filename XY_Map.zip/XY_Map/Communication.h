//
//  Communication.h
//  XY_Map
//
//  Created by Masahiko Sato on 2014-05-14.
//
//

#ifndef Communication_H
#define Communication_H
#import "Controller.h"
#endif

@interface Communication : NSObject{
    int firstCommunication; //Set at the first communication
    
    NSTimer *communicationTimer;
}

-(id)init;
-(void)dealloc;
-(void)processControl;

@end
