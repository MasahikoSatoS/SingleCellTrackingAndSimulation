//
//  SnapImage3.h
//  XY_Map
//
//  Created by Masahiko Sato on 2014-08-23.
//
//

#ifndef SNAPIMAGE3_H
#define SNAPIMAGE3_H
#import "Controller.h"
#endif

@interface SnapImage3 : NSView {
    int magnificationSnap3; //Display control
    
    int mouseDragFlag; //Display control
    double xPositionSnap3; //Display control
    double yPositionSnap3; //Display control
    double xPositionAdjustSnap3; //Display control
    double yPositionAdjustSnap3; //Display control
    double xPointDownSnap3; //Display control
    double yPointDownSnap3; //Display control
    double xPointDragSnap3; //Display control
    double yPointDragSnap3; //Display control
    double xPositionMoveSnap3; //Display control
    double yPositionMoveSnap3; //Display control
    double windowWidthSnap3; //Display control
    double windowHeightSnap3; //Display control
    
    IBOutlet NSImage *snapWindowImage3;
    
    id tiffFileRead;
}

-(void)mouseDown:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)mouseDraged:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
