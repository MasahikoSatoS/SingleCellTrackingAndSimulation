//
//  WellDataWrite.mm
//  XY_Map
//
//  Created by Masahiko Sato on 28/05/13, 28/05/13 revised.
//  Copyright 2013 Masahiko Sato All rights reserved.
//

#import "WellDataWrite.h"

@implementation WellDataWrite

-(int)dataSave{
    int zValueMatchFlag = 0;
    int saveStatus = 0;
    
    if (tableXYDimensionHoldCount != 0){
        for (int counter1 = 0; counter1 < 16; counter1++){
            if (arrayTableZHold [counter1] != arrayTableZ [counter1]) zValueMatchFlag = 1;
        }
    }
    
    int selectedFOVCount1 = selectedMapCount1/6;
    int selectedFOVCount2 = selectedMapCount2/6;
    
    if (selectedFOVCount1 != 0){
        double *arrayMapTemp = new double [selectedMapCount1+50];
        int mapTempCount = 0;
        
        for (int counter1 = 1; counter1 <= chamberWellLimit1; counter1++){
            for (int counter2 = 0; counter2 < selectedFOVCount1; counter2++){
                if (arraySelectedMap1 [counter2*6] == counter1){
                    arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6], mapTempCount++;
                    arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6+1], mapTempCount++;
                    arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6+2], mapTempCount++;
                    arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6+3], mapTempCount++;
                    arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6+4], mapTempCount++;
                    arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6+5], mapTempCount++;
                }
            }
        }
        
        selectedMapCount1 = 0;
        
        for (int counter1 = 0; counter1 < mapTempCount; counter1++) arraySelectedMap1 [selectedMapCount1] = arrayMapTemp [counter1], selectedMapCount1++;
        delete [] arrayMapTemp;
    }
    
    if (selectedFOVCount2 != 0){
        double *arrayMapTemp = new double [selectedMapCount2+50];
        int mapTempCount = 0;
        
        for (int counter1 = chamberWellLimit1+1; counter1 <= chamberWellLimit1+chamberWellLimit2; counter1++){
            for (int counter2 = 0; counter2 < selectedFOVCount2; counter2++){
                if (arraySelectedMap2 [counter2*6] == counter1){
                    arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6], mapTempCount++;
                    arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6+1], mapTempCount++;
                    arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6+2], mapTempCount++;
                    arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6+3], mapTempCount++;
                    arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6+4], mapTempCount++;
                    arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6+5], mapTempCount++;
                }
            }
        }
        
        selectedMapCount2 = 0;
        
        for (int counter1 = 0; counter1 < mapTempCount; counter1++) arraySelectedMap2 [selectedMapCount2] = arrayMapTemp [counter1], selectedMapCount2++;
        delete [] arrayMapTemp;
    }
    
    if (selectedFOVCount1+selectedFOVCount2 != 0){
        if (batchCommitStatus == 0){
            if (autoCommitStatus == 0 || (autoCommitStatus == 1 && zValueMatchFlag == 1)){
                if (initialCommitStatus == 0 || (autoCommitStatus == 1 && zValueMatchFlag == 1)){
                    ofstream oin;
                    
                    oin.open(stgSavePath.c_str(), ios::out | ios::binary);
                    
                    if (oin.is_open()){
                        string bodyNameMessage = bodyName+"_position.STG";
                        NSString *bodyNameType = @(bodyNameMessage.c_str());
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert addButtonWithTitle:@"Cancel"];
                        [alert setMessageText:bodyNameType];
                        [alert setInformativeText:@"Will Be Created"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        
                        if ([alert runModal] == NSAlertFirstButtonReturn){
                            ascIIconversion = [[ASCIIconversion alloc] init];
                            
                            arrayWellData = new int [1000];
                            wellDataCount = 0;
                            wellDataLimit = 1000;
                            arrayAscIIintData = new int [100];
                            ascIIintDataCount = 0;
                            
                            oin.put(34);
                            
                            ascIIstring = "Stage Memory List";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
                            
                            oin.put(34), oin.put(44), oin.put(32);
                            
                            ascIIstring = "Version 6.0";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
                            
                            oin.put(13), oin.put(10), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
                            oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44);
                            oin.put(32), oin.put(34), oin.put(117), oin.put(109), oin.put(34), oin.put(44), oin.put(32), oin.put(34), oin.put(117), oin.put(109), oin.put(34);
                            oin.put(13), oin.put(10), oin.put(48), oin.put(13), oin.put(10);
                            
                            ascIIstring = to_string(selectedFOVCount1+selectedFOVCount2);
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
                            
                            oin.put(13), oin.put(10);
                            
                            delete [] arrayAscIIintData;
                            
                            int arrayNumber = 1;
                            
                            if (selectedMapCount1 != 0){
                                [self wellDataFile:arrayNumber];
                                int ascIIintSize = wellDataCount;
                                for (int counter1 = 0; counter1 < ascIIintSize; counter1++) oin.put((char)arrayWellData [counter1]);
                            }
                            
                            arrayNumber = 2;
                            
                            if (selectedMapCount2 != 0){
                                [self wellDataFile:arrayNumber];
                                int ascIIintSize = wellDataCount;
                                for (int counter1 = 0; counter1 < ascIIintSize; counter1++) oin.put((char)arrayWellData [counter1]);
                            }
                            
                            delete [] arrayWellData;
                            
                            saveStatus = 1;
                        }
                        
                        oin.close();
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Check The Destination Computer"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Init On, Saving Prohibited"];
                    [alert setInformativeText:@" For IF: Save after IF Start."];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Auto. On, Saving Prohibited/Z Has Not Been Changed"];
                [alert setInformativeText:@"After Last Purge: Quit Map and Restart after IF Start/For IF: Quit Map and Restart after IF Start."];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Batch ON, Save Prohibited"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No FOV Found"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    
    return saveStatus;
}

-(void)wellDataFile:(int)arrayNumber{
    int selectedFOVCount1 = selectedMapCount1/6;
    int selectedFOVCount2 = selectedMapCount2/6;
    
    if (arrayNumber == 1 && selectedFOVCount1 != 0){
        wellDataCount = 0;
        
        ascIIconversion = [[ASCIIconversion alloc] init];
        
        for (int counter1 = 0; counter1 < selectedFOVCount1; counter1++){
            arrayAscIIintData = new int [100];
            ascIIintDataCount = 0;
            
            if (wellDataCount+200 > wellDataLimit) [self wellDataMapUpDate];
            
            arrayWellData [wellDataCount] = 34, wellDataCount++;
            
            ascIIstring = "well ";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            stringstream extension;
            extension << arraySelectedMap1 [counter1*6]; //----Well number----
            ascIIstring = extension.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            ascIIstring = " position ";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            stringstream extension1;
            extension1 << arraySelectedMap1 [counter1*6+1]; //----X position----
            ascIIstring = extension1.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            
            stringstream extension2;
            extension2 << arraySelectedMap1 [counter1*6+2]; //----Y position----
            ascIIstring = extension2.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            arrayWellData [wellDataCount] = 34, wellDataCount++;
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            
            stringstream extension3;
            extension3 << arraySelectedMap1 [counter1*6+3]; //----X value----
            ascIIstring = extension3.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            
            stringstream extension4;
            extension4 << arraySelectedMap1 [counter1*6+4]; //----Y value----
            ascIIstring = extension4.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            
            stringstream extension5;
            extension5 << arraySelectedMap1 [counter1*6+5]; //----Z value----
            ascIIstring = extension5.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            arrayWellData [wellDataCount] = 48, wellDataCount++;
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            arrayWellData [wellDataCount] = 48, wellDataCount++;
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            
            ascIIstring = "FALSE";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            
            ascIIstring = "-9999";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            
            ascIIstring = "TRUE";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            
            ascIIstring = "TRUE";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            arrayWellData [wellDataCount] = 48, wellDataCount++;
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            arrayWellData [wellDataCount] = 45, wellDataCount++;
            arrayWellData [wellDataCount] = 49, wellDataCount++;
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            arrayWellData [wellDataCount] = 34, wellDataCount++;
            arrayWellData [wellDataCount] = 34, wellDataCount++;
            arrayWellData [wellDataCount] = 13, wellDataCount++;
            arrayWellData [wellDataCount] = 10, wellDataCount++;
            
            delete [] arrayAscIIintData;
        }
    }
    
    if (arrayNumber == 2 && selectedFOVCount2 != 0){
        wellDataCount = 0;
        
        ascIIconversion = [[ASCIIconversion alloc] init];
        
        for (int counter1 = 0; counter1 < selectedFOVCount2; counter1++){
            arrayAscIIintData = new int [100];
            ascIIintDataCount = 0;
            
            if (wellDataCount+200 > wellDataLimit) [self wellDataMapUpDate];
            
            arrayWellData [wellDataCount] = 34, wellDataCount++;
            
            ascIIstring = "well ";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            stringstream extension;
            extension << arraySelectedMap2 [counter1*6]; //----Well number----
            ascIIstring = extension.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            ascIIstring = " position ";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            stringstream extension1;
            extension1 << arraySelectedMap2 [counter1*6+1]; //----X position----
            ascIIstring = extension1.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            
            stringstream extension2;
            extension2 << arraySelectedMap2 [counter1*6+2 ]; //----Y position----
            ascIIstring = extension2.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            arrayWellData [wellDataCount] = 34, wellDataCount++;
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            
            stringstream extension3;
            extension3 << arraySelectedMap2 [counter1*6+3]; //----X value----
            ascIIstring = extension3.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            
            stringstream extension4;
            extension4 << arraySelectedMap2 [counter1*6+4 ]; //----Y value----
            ascIIstring = extension4.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            
            stringstream extension5;
            extension5 << arraySelectedMap2 [counter1*6+5 ]; //----Z value----
            ascIIstring = extension5.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            arrayWellData [wellDataCount] = 48, wellDataCount++;
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            arrayWellData [wellDataCount] = 48, wellDataCount++;
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            
            ascIIstring = "FALSE";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            
            ascIIstring = "-9999";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            
            ascIIstring = "TRUE";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            
            ascIIstring = "TRUE";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) arrayWellData [wellDataCount] = arrayAscIIintData [counter2], wellDataCount++;
            
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            arrayWellData [wellDataCount] = 48, wellDataCount++;
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            arrayWellData [wellDataCount] = 45, wellDataCount++;
            arrayWellData [wellDataCount] = 49, wellDataCount++;
            arrayWellData [wellDataCount] = 44, wellDataCount++;
            arrayWellData [wellDataCount] = 32, wellDataCount++;
            arrayWellData [wellDataCount] = 34, wellDataCount++;
            arrayWellData [wellDataCount] = 34, wellDataCount++;
            arrayWellData [wellDataCount] = 13, wellDataCount++;
            arrayWellData [wellDataCount] = 10, wellDataCount++;
            
            delete [] arrayAscIIintData;
        }
    }
}

-(void)wellDataMapUpDate{
    int *arrayUpDate = new int [wellDataCount+10];
    
    for (int counter1 = 0; counter1 < wellDataCount; counter1++) arrayUpDate [counter1] = arrayWellData [counter1];
    
    delete [] arrayWellData;
    arrayWellData = new int [wellDataLimit+1000];
    wellDataLimit = wellDataLimit+1000;
    
    for (int counter1 = 0; counter1 < wellDataCount; counter1++) arrayWellData [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

@end
