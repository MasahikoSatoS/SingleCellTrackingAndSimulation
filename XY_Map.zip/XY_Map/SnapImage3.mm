//
//  SnapImage3.m
//  XY_Map
//
//  Created by Masahiko Sato on 2014-08-23.
//
//

#import "SnapImage3.h"

NSString *notificationToSnapImage3 = @"notificationExecuteSnapImage3";

@implementation SnapImage3

- (id)initWithFrame:(NSRect)frame{
    self = [super initWithFrame:frame];
    
    if (self){
        magnificationSnap3 = 10;
        mouseDragFlag = 0;
        snapWindowImage3 = [[NSImage alloc] initWithContentsOfFile:@""];
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToSnapImage3 object:nil];
    }
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    if (snapStart2 == 1){
        string extension = to_string(snapPage2*2-1);
        
        if (extension.length() == 1) extension = "00"+extension;
        else if (extension.length() == 2) extension = "0"+extension;
        
        string snapSavePath = cellTrackingSystemDataPath+"/"+"SnapB-"+extension;
        
        unsigned long nextAddress = 0;
        unsigned long stripFirstAddress = 0;
        unsigned long stripByteCountAddress = 0;
        unsigned long headPosition = 0;
        unsigned long stripEntry = 0;
        long sizeForCopy = 0;
        
        double xPosition = 0;
        double yPosition = 0;
        double zPosition = 0;
        
        int imageWidth = 0;
        int imageHeight = 0;
        int imageBit = 0; //Check 8, 16
        int imageCompression = 0; //Check 1
        int photoMetric = 0; //Check 0, 1, 2
        int imageDimension = 0;
        int verticalBmp = 0;
        int horizontalBmp = 0;
        int endianType = 0;
        int samplePerPix = 0;
        int dataConversion [4];
        int processType = 0; //----Out put image 8 bit gray
        int numberOfLayers = 0;
        
        //----File Read----
        struct stat sizeOfFile;
        
        ifstream fin;
        
        if (stat(snapSavePath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            int **imageDataTemp = new int *[cameraDimension+1];
            for (int counter1 = 0; counter1 < cameraDimension+1; counter1++) imageDataTemp [counter1] = new int [cameraDimension+1];
            
            for (int counter3 = 0; counter3 < cameraDimension+1; counter3++){
                for (int counter4 = 0; counter4 < cameraDimension+1; counter4++){
                    imageDataTemp [counter3][counter4] = 0;
                }
            }
            
            fileReadArray = new uint8_t [sizeForCopy+4];
            fin.open(snapSavePath.c_str(), ios::in | ios::binary);
            
            fin.read((char*)fileReadArray, sizeForCopy+1);
            fin.close();
            
            dataConversion [0] = fileReadArray [0];
            dataConversion [1] = fileReadArray [1];
            
            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
            else endianType = 0;
            
            if (endianType == 1){
                dataConversion [0] = fileReadArray [7];
                dataConversion [1] = fileReadArray [6];
                dataConversion [2] = fileReadArray [5];
                dataConversion [3] = fileReadArray [4];
                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
            }
            else if (endianType == 0){
                dataConversion [0] = fileReadArray [4];
                dataConversion [1] = fileReadArray [5];
                dataConversion [2] = fileReadArray [6];
                dataConversion [3] = fileReadArray [7];
                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
            }
            
            int *arrayExtractedImage3 = new int [100];
            
            if (endianType == 1){ //----Big endian----
                tiffFileRead = [[TiffFileRead alloc] init];
                [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers:&zPosition];
                
                tiffFileRead = [[TiffFileRead alloc] init];
                delete [] arrayExtractedImage3;
                
                imageDimension = imageWidth;
                
                arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
            }
            else if (endianType == 0){
                tiffFileRead = [[TiffFileRead alloc] init];
                [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers:&zPosition];
                
                tiffFileRead = [[TiffFileRead alloc] init];
                delete [] arrayExtractedImage3;
                
                imageDimension = imageWidth;
                
                arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
            }
            
            //cout<<imageCompression<<" "<<imageBit<<" "<<" "<<samplePerPix<<" "<<photoMetric<<" entryinfo"<<endl;
            
            if (imageCompression == 1 && imageBit == 8 && numberOfLayers == 1 && samplePerPix == 1 && imageWidth == cameraDimension){
                for (int counter3 = 0; counter3 < cameraDimension*cameraDimension; counter3++){
                    if (horizontalBmp < cameraDimension){
                        imageDataTemp [verticalBmp][horizontalBmp] = arrayExtractedImage3 [counter3], horizontalBmp++;
                    }
                    
                    if (horizontalBmp == cameraDimension){
                        horizontalBmp = 0;
                        verticalBmp++;
                    }
                }
                
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:cameraDimension pixelsHigh:cameraDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:cameraDimension bitsPerPixel:8];
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                for (int counter1 = 0; counter1 < cameraDimension; counter1++){
                    for (int counter2 = 0; counter2 < cameraDimension; counter2++) *bitmapData++ = (unsigned char)imageDataTemp [counter1][counter2];
                }
                
                snapWindowImage3 = [[NSImage alloc] initWithSize:NSMakeSize(cameraDimension, cameraDimension)];
                [snapWindowImage3 addRepresentation:bitmapReps];
                
                if (imageFirstLoadFlagSnap3 == 0){
                    xPositionSnap3 = 0;
                    yPositionSnap3 = 0;
                    xPositionAdjustSnap3 = 0;
                    yPositionAdjustSnap3 = 0;
                    magnificationSnap3 = 10;
                    imageFirstLoadFlagSnap3 = 1;
                }
                
                //----Window size and Position re-adjust----
                int vertical = 300+78;
                int horizontal = 300;
                
                windowWidthSnap3 = cameraDimension/(double)horizontal;
                windowHeightSnap3 = cameraDimension/(double)(vertical-78);
                
                xPositionAdjustSnap3 = (cameraDimension-cameraDimension/(double)(magnificationSnap3*0.1))/(double)2;
                yPositionAdjustSnap3 = (cameraDimension-cameraDimension/(double)(magnificationSnap3*0.1))/(double)2;
            }
            else snapWindowImage3 = [[NSImage alloc] initWithContentsOfFile:@""];
            
            for (int counter1 = 0; counter1 < cameraDimension+1; counter1++) delete [] imageDataTemp [counter1];
            delete [] imageDataTemp;
            
            delete [] fileReadArray;
            delete [] arrayExtractedImage3;
        }
        else snapWindowImage3 = [[NSImage alloc] initWithContentsOfFile:@""];
        
        [self setNeedsDisplay:YES];
    }
}

-(void)mouseDown:(NSEvent *)event{
    NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
    xPointDownSnap3 = clickPoint.x;
    yPointDownSnap3 = clickPoint.y;
    
    int xPositionTemp = (int)(xPointDownSnap3*(double)windowWidthSnap3/(double)magnificationSnap3/(double)0.1+xPositionAdjustSnap3+xPositionSnap3);
    int yPositionTemp = cameraDimension-(int)((yPointDownSnap3*(double)windowHeightSnap3/(double)magnificationSnap3/(double)0.1+yPositionAdjustSnap3+yPositionSnap3+windowHeightSnap3));
    
    xClickPositionSnap3 = xPositionTemp;
    yClickPositionSnap3 = yPositionTemp;
    
    [self setNeedsDisplay:YES];
}

-(void)mouseUp:(NSEvent *)event{
    xPositionSnap3 = xPositionSnap3+xPositionMoveSnap3;
    yPositionSnap3 = yPositionSnap3+yPositionMoveSnap3;
    xPositionMoveSnap3 = 0;
    yPositionMoveSnap3 = 0;
    mouseDragFlag = 0;
    [self setNeedsDisplay:YES];
}

-(void)mouseDraged:(NSEvent *)event{
    NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
    xPointDragSnap3 = clickPoint.x;
    yPointDragSnap3 = clickPoint.y;
    xPositionMoveSnap3 = (xPointDownSnap3-xPointDragSnap3)*windowWidthSnap3/(double)(magnificationSnap3*0.1);
    yPositionMoveSnap3 = (yPointDownSnap3-yPointDragSnap3)*windowHeightSnap3/(double)(magnificationSnap3*0.1);
    
    mouseDragFlag = 1;
    [self setNeedsDisplay:YES];
}

-(void)keyDown:(NSEvent *)event{
    int keyCode = [event keyCode];
    int proceedFlag = 0;
    
    //----Original size----
    if (keyCode == 6){
        proceedFlag = 1;
        xPositionSnap3 = 0;
        yPositionSnap3 = 0;
        xPositionAdjustSnap3 = 0;
        yPositionAdjustSnap3 = 0;
        magnificationSnap3 = 10;
    }
    
    //----Magnification Magnify----
    if (keyCode == 125){
        if (magnificationSnap3 >= 12 && magnificationSnap3 <= 350){
            proceedFlag = 1;
            if (magnificationSnap3-10 < 12) magnificationSnap3 = 12;
            else magnificationSnap3 = magnificationSnap3-10;
            
            xPositionAdjustSnap3 = -1*(cameraDimension/(double)(magnificationSnap3*0.1)-cameraDimension)/(double)2;
            yPositionAdjustSnap3 = -1*(cameraDimension/(double)(magnificationSnap3*0.1)-cameraDimension)/(double)2;
        }
    }
    
    //----Magnification Reduction----
    if (keyCode == 126){
        if (magnificationSnap3 >= 10 && magnificationSnap3 <= 498){
            proceedFlag = 1;
            
            if (magnificationSnap3+10 > 498) magnificationSnap3 = 498;
            else magnificationSnap3 = magnificationSnap3+10;
            
            xPositionAdjustSnap3 = (cameraDimension-cameraDimension/(double)(magnificationSnap3*0.1))/(double)2;
            yPositionAdjustSnap3 = (cameraDimension-cameraDimension/(double)(magnificationSnap3*0.1))/(double)2;
        }
    }
    
    if (proceedFlag == 1) [self setNeedsDisplay:YES];
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)drawRect:(NSRect)rect{
    NSRect srcRect;
    srcRect.origin.x = xPositionSnap3+xPositionAdjustSnap3+xPositionMoveSnap3;
    srcRect.origin.y = yPositionSnap3+yPositionAdjustSnap3+yPositionMoveSnap3;
    srcRect.size.width = cameraDimension/(double)(magnificationSnap3*0.1);
    srcRect.size.height = cameraDimension/(double)(magnificationSnap3*0.1);
    
    [snapWindowImage3 drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
    
    if (mouseDragFlag == 0){
        if (imageFirstLoadFlagSnap3 == 1){
            double xPositionAdj = xPositionAdjustSnap3+xPositionSnap3;
            double yPositionAdj = yPositionAdjustSnap3+yPositionSnap3;
            double xCalValue = 1/(double)windowWidthSnap3*magnificationSnap3*0.1;
            double yCalValue = 1/(double)windowHeightSnap3*magnificationSnap3*0.1;
            
            [NSBezierPath setDefaultLineWidth:2];
            NSPoint pointA;
            NSPoint pointB;
            
            if (snapFirstSecondTime2 == 1){
                [[NSColor redColor] set];
                pointA.x = (xClickPositionSnap3-8-xPositionAdj)*xCalValue;
                pointA.y = (cameraDimension-yClickPositionSnap3-yPositionAdj)*yCalValue;
                pointB.x = (xClickPositionSnap3+8-xPositionAdj)*xCalValue;
                pointB.y = (cameraDimension-yClickPositionSnap3-yPositionAdj)*yCalValue;
                [NSBezierPath strokeLineFromPoint:pointA toPoint:pointB];
                
                pointA.x = (xClickPositionSnap3-xPositionAdj)*xCalValue;
                pointA.y = (cameraDimension-yClickPositionSnap3-8-yPositionAdj)*yCalValue;
                pointB.x = (xClickPositionSnap3-xPositionAdj)*xCalValue;
                pointB.y = (cameraDimension-yClickPositionSnap3+8-yPositionAdj)*yCalValue;
                [NSBezierPath strokeLineFromPoint:pointA toPoint:pointB];
            }
            
            if (arraySnapData2 [3] != 0 && arraySnapData2 [4] != 0){
                double xSetPosition = 0;
                double ySetPosition = 0;
                
                if (objectiveSelect == 1){
                    ySetPosition = (arraySnapData2 [4]-arraySnapData2 [1])/(double)1.04101;
                    xSetPosition = (arraySnapData2 [5]-arraySnapData2 [2])/(double)1.04101;
                }
                else if (objectiveSelect == 2){
                    ySetPosition = (arraySnapData2 [4]-arraySnapData2 [1])/(double)0.52084;
                    xSetPosition = (arraySnapData2 [5]-arraySnapData2 [2])/(double)0.52084;
                }
                else if (objectiveSelect == 3){
                    ySetPosition = (arraySnapData2 [4]-arraySnapData2 [1])/(double)0.259589;
                    xSetPosition = (arraySnapData2 [5]-arraySnapData2 [2])/(double)0.259589;
                }
                
                [[NSColor greenColor] set];
                pointA.x = (xSetPosition-8-xPositionAdj)*xCalValue;
                pointA.y = (cameraDimension-ySetPosition-yPositionAdj)*yCalValue;
                pointB.x = (xSetPosition+8-xPositionAdj)*xCalValue;
                pointB.y = (cameraDimension-ySetPosition-yPositionAdj)*yCalValue;
                [NSBezierPath strokeLineFromPoint:pointA toPoint:pointB];
                
                pointA.x = (xSetPosition-xPositionAdj)*xCalValue;
                pointA.y = (cameraDimension-ySetPosition-8-yPositionAdj)*yCalValue;
                pointB.x = (xSetPosition-xPositionAdj)*xCalValue;
                pointB.y = (cameraDimension-ySetPosition+8-yPositionAdj)*yCalValue;
                [NSBezierPath strokeLineFromPoint:pointA toPoint:pointB];
            }
        }
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToSnapImage3 object:nil];
}

@end
