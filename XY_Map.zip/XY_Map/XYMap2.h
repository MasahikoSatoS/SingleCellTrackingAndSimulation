//
//  XYMap2.h
//  XY_Map
//
//  Created by Masahiko Sato on 12/05/11, 28/05/13 revised.
//  Copyright 2011 Masahiko Sato. All rights reserved.
//

#ifndef MAP2_H
#define MAP2_H
#import "Controller.h"
#endif

@interface XYMap2 : NSView {
    double xPointDown; //Display control
    double yPointDown; //Display control
    int magnificationWell; //Display control
    int pressSflag; //Flag for press S
    
    IBOutlet NSImage *xyMapImage2;
    IBOutlet NSWindow *mapImageWindow2;
    
    NSTimer *xyMapTimer2;
}

-(void)dealloc;
-(void)keyDown:(NSEvent *)event;
-(void)displayMap;
-(void)selectedMapUpDate2;

@end
