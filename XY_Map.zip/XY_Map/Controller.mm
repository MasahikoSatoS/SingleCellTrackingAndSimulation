//
//  Controller.mm
//  XY_Map
//
//  Created by Masahiko Sato on 11/04/29, 28/05/13 revised.
//  Copyright 2011 Masahiko Sato All rights reserved.
//

#import "Controller.h"

//----Map operation----
double *arrayWellPosition1;
int wellPositionCount1;
double *arrayWellPosition2; 
int wellPositionCount2;
double *arrayLabelPosition1;
int labelPositionCount1;
double *arrayLabelPosition2;
int labelPositionCount2;
double *arrayReadingPositionMDA;
int readingPositionMDACount;
int readingPositionMDALimit;
double *arraySelectedMap1;
int selectedMapCount1;
int selectedMapLimit1;
int selectedMapAddition1;
double *arraySelectedMap2;
int selectedMapCount2;
int selectedMapLimit2;
int selectedMapAddition2;
int *arrayTableXYDimension;
int tableXYDimensionCount;
double *arrayTableZ;
int tableZCount;
int *arrayTableXYDimensionHold;
int tableXYDimensionHoldCount;
double *arrayTableZHold;
int tableZHoldCount;
string *arrayFileDelete;
int fileDeleteCount;
int fileDeleteLimit;
int cameraDimension;

string fileSavePathHold;
int **arrayImageFileSave;
uint8_t *fileReadArray;

string pathNameString;
string ascIIstring;
string xyLogFilePath;
string positionMDAPath;
string savedDataPath;
string bodyName;
string computerName;
string analysisDataPath;
string xyMapDataPath;
string xyDimensionMapPath;
string zMapPath;
string stgSavePath;
string savedDataLastSavePath;
string xyDimensionMapSavePath;
string zMapSavePath;
string xyBasicDataPath;
string dataDirectoryPath;
string informationDirectoryPath;

int drawingPermit1;
int drawingPermit2;
int xFOVTaken;
int yFOVTaken;
int objectiveSelect;
int wellDataSaveRequest;
int mapReadFlag1;
int mapReadFlag2;
int displayCheck1;
int displayCheck2;
double xClickCurrent;
double yClickCurrent;
double xPositionCurrent;
double yPositionCurrent;
int saveDoneFlag;
int autoCommitStatus;
int batchCommitStatus;
int initialCommitStatus;
int analysisNameDisplayCall;
int drawingOrientation;
int stepperStartHoldM;
int stepperEveryHoldM;
string instructionMapPath;
string instructionMapPath2;

//----Snap operation----
int chamberType1;
int chamberType2;
int chamberWellLimit1;
int chamberWellLimit2;
int snapOperation;
int snapOperation2;
int snapFirstSecondTime;
int snapFirstSecondTime2;
double *arraySnapData;
double *arraySnapMainData;
int snapMainDataCount;
double *arraySnapData2;
double *arraySnapMainData2;
int snapMainDataCount2;
int snapStart;
int snapStart2;
int snapPage;
int snapPage2;
string cellTrackingSystemDataPath;
string snapDataPath1;
string snapDataPath2;
int imageFirstLoadFlagSnap1;
int xClickPositionSnap1;
int yClickPositionSnap1;
int imageFirstLoadFlagSnap2;
int xClickPositionSnap2;
int yClickPositionSnap2;
int imageFirstLoadFlagSnap3;
int xClickPositionSnap3;
int yClickPositionSnap3;
int imageFirstLoadFlagSnap4;
int xClickPositionSnap4;
int yClickPositionSnap4;
int stepperStartHold1;
int stepperStartHold2;
int *arrayAscIIintData;
int ascIIintDataCount;

//----Focus check----
int focusOperation;
int **arrayImageDataHoldZImage;
int imageDataHoldZImageStatus;
int zImageHeight;
int zImageWidth;
int zImagePlane; 
int planeNumberDisplay;
int currentPlaneDisplayCall;
int imageFirstLoadFlagFocus;
int fileNameHoldCall;
double contrastAdjust;
string userName;
string fileNameHold;
int focusPhotometric;

//----Directory temp save----
string *arrayDirectoryInfo;
int directoryInfoCount;
int directoryInfoLimit;

//----Well orientation----
int wellOrientation1;
int wellOrientation2;
int wellOrientation3;

//----Test MDA----
int *wellPositionTest;

@implementation Controller

-(id)init{
    self = [super init];
    
    if (self != nil){
        [self userPathSet];
        
        cameraDimension = 512;
        
        bodyName = "nil";
        computerName = "nil";
        
        drawingPermit1 = 0;
        drawingPermit2 = 0;
        objectiveSelect = 1;
        wellDataSaveRequest = 0;
        mapReadFlag1 = 0;
        mapReadFlag2 = 0;
        displayCheck1 = 0;
        displayCheck2 = 0;
        xClickCurrent = 0;
        yClickCurrent = 0;
        xPositionCurrent = 0;
        yPositionCurrent = 0;
        saveDoneFlag = 0;
        autoCommitStatus = 0;
        batchCommitStatus = 0;
        initialCommitStatus = 0;
        analysisNameDisplayCall = 0;
        drawingOrientation = 0;
        stepperStartHoldM = 1;
        stepperEveryHoldM = 5;
        
        chamberType1 = 1;
        chamberType2 = 1;
        chamberWellLimit1 = 8;
        chamberWellLimit2 = 8;
        snapOperation = 0;
        snapOperation2 = 0;
        snapFirstSecondTime = 1;
        snapFirstSecondTime2 = 1;
        imageFirstLoadFlagSnap1 = 0;
        xClickPositionSnap1 = 0;
        yClickPositionSnap1 = 0;
        imageFirstLoadFlagSnap2 = 0;
        xClickPositionSnap2 = 0;
        yClickPositionSnap2 = 0;
        imageFirstLoadFlagSnap3 = 0;
        xClickPositionSnap3 = 0;
        yClickPositionSnap3 = 0;
        imageFirstLoadFlagSnap4 = 0;
        xClickPositionSnap4 = 0;
        yClickPositionSnap4 = 0;
        stepperStartHold1 = 1;
        stepperStartHold2 = 1;
        
        focusOperation = 0;
        planeNumberDisplay = 0;
        currentPlaneDisplayCall = 0;
        fileNameHoldCall = 0;
        contrastAdjust = 1;
        userName = "nil";
        fileNameHold = "nil";
        focusPhotometric = 0;
        
        stgMemorizedSizeHold = 0;
        xCorner1 = 0;
        yCorner1 = 0;
        xCorner2 = 0;
        yCorner2 = 0;
        xClickCurrentHold = 0;
        yClickCurrentHold = 0;
        
        imageFirstLoadFlagFocus = 0;
        
        zPositionSaveCount = 0;
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(controlTextDidChange:) name:NSControlTextDidChangeNotification object:nil];
    }
    
    return self;
}

-(void)userPathSet{
    NSString *currentDirectoryPathNSString = [[NSBundle mainBundle] bundlePath];
    string userPathNameString = [currentDirectoryPathNSString cStringUsingEncoding:NSUTF8StringEncoding];
    
    if (userPathNameString.length() == 0) exit (0);
    else if ((int)userPathNameString.find("/Users/") == -1) exit (0);
    else{
        
        string pathName2 = userPathNameString.substr((unsigned long)userPathNameString.find("/Users/")+7);
        pathNameString = pathName2.substr(0, (unsigned long)pathName2.find("/"));
    }
}

-(void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat xLength = screenRect.size.width;
    CGFloat yLength = screenRect.size.height;
    
    int mainControllerX = 800;
    
    NSRect windowSize = [controllerWindow frame];
    CGFloat windowWidth = windowSize.size.width;
    CGFloat windowHeight = windowSize.size.height;
    
    NSRect windowSize2 = [mapWindow1 frame];
    CGFloat windowWidth2 = windowSize2.size.width;
    CGFloat windowHeight2 = windowSize2.size.height;
    
    NSRect windowSize3 = [mapWindow2 frame];
    CGFloat windowWidth3 = windowSize3.size.width;
    CGFloat windowHeight3 = windowSize3.size.height;
    
    int displayPositionType = 0;
    
    if (80+mainControllerX+5+windowWidth+5+80 > xLength || 80+mainControllerX+5+windowWidth+5+windowWidth2+5+80 > xLength || 80+mainControllerX+5+windowWidth+5+windowWidth3+5+80 > xLength) displayPositionType = 1;
    
    CGFloat displayX = 0;
    
    if (displayPositionType == 1) displayX = 550;
    else displayX = 80+mainControllerX+5+windowWidth+5;
    
    CGFloat displayY = yLength+yOrigin-20-windowHeight3-157;
    
    if (windowHeight3 != 0) [mapWindow2 setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    if (displayPositionType == 1) displayX = 550;
    else displayX = 80+mainControllerX+5+windowWidth+5;
    
    displayY = yLength+yOrigin-20-windowHeight2;
    
    if (windowHeight2 != 0) [mapWindow1 setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    if (displayPositionType == 1) displayX = 550;
    else displayX = 80+mainControllerX+5;
    
    displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [controllerWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [xNumberPointTake setDelegate:self];
    [yNumberPointTake setDelegate:self];
    [zAdjustWell setDelegate:self];
    [zAdjustValue setDelegate:self];
    
    [stepperStartDisplayM setDelegate:self];
    [stepperEveryDisplayM setDelegate:self];
    
    [stepperStartM setMinValue:1];
    [stepperStartM setMaxValue:500];
    [stepperEveryM setMinValue:1];
    [stepperEveryM setMaxValue:100];
    [stepperStartDisplayM setIntValue:1];
    [stepperEveryDisplayM setIntValue:5];
    
    [tableViewList setDataSource:self];
    
    for (NSTableColumn* column in [tableViewList tableColumns]) {
        if ([[column identifier] isEqualToString:@"COL1"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Well No" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL2"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"X" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL3"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Y" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL4"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Z" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL5"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"FOV" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
    }
}

-(void)applicationDidFinishLaunching:(NSNotification*)notification{
    mapWindowTC2 = [[NSWindowController alloc] initWithWindowNibName:@"MapDisplay2"];
    [mapWindowTC2 showWindow:self];
    
    mapWindowTC1 = [[NSWindowController alloc] initWithWindowNibName:@"MapDisplay1"];
    [mapWindowTC1 showWindow:self];
    
    [mapWindow1 orderFront: nil];
    [controllerWindow orderFront: nil];
    
    analysisDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/AnalysisSetting";
    xyBasicDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/MAP_BasicData";
    cellTrackingSystemDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data";
    snapDataPath1 = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"MAP_SnapData1";
    snapDataPath2 = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"MAP_SnapData2";
    instructionMapPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"Map_Instruction1";
    instructionMapPath2 = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"Map_Instruction2";
    
    string getString;
    int totalFOVNoHold = 0;
    
    ifstream fin;
    
    fin.open(analysisDataPath.c_str(), ios::in);
    
    if (fin.is_open()){
        getline(fin, getString), bodyName = getString;
        getline(fin, getString), computerName = getString;
        getline(fin, getString), totalFOVNoHold = atoi(getString.c_str());
        getline(fin, getString), userName = getString;
        fin.close();
    }
    
    if (bodyName != "nil") [analysisName setStringValue:@(bodyName.c_str())];
    else [analysisName setStringValue:@"nil"];
    
    if (totalFOVNoHold != 0) [totalFOV setIntegerValue:totalFOVNoHold];
    else [totalFOV setIntegerValue:0];
    
    string directoryDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/DirectoryData";
    
    dataDirectoryPath = "nil";
    informationDirectoryPath = "nil";
    
    fin.open(directoryDataPath.c_str(), ios::in);
    
    if (fin.is_open()){
        getline(fin, getString), dataDirectoryPath = getString;
        getline(fin, getString), informationDirectoryPath = getString;
        
        fin.close();
    }
    
    if (dataDirectoryPath != "nil" && informationDirectoryPath != "nil"){
        xyLogFilePath = informationDirectoryPath+"/xyposition.LOG"; //=========================================
        
        fin.open(xyBasicDataPath.c_str(), ios::in);
        
        if (fin.is_open()){
            getline(fin, getString), xFOVTaken = atoi(getString.c_str());
            getline(fin, getString), yFOVTaken = atoi(getString.c_str());
            getline(fin, getString), chamberType1 = atoi(getString.c_str());
            getline(fin, getString), chamberType2 = atoi(getString.c_str());
            getline(fin, getString), snapFirstSecondTime = atoi(getString.c_str());
            getline(fin, getString), snapFirstSecondTime2 = atoi(getString.c_str());
            getline(fin, getString), snapPage = atoi(getString.c_str());
            getline(fin, getString), snapPage2 = atoi(getString.c_str());
            getline(fin, getString), wellOrientation1 = atoi(getString.c_str());
            getline(fin, getString), wellOrientation2 = atoi(getString.c_str());
            getline(fin, getString), wellOrientation3 = atoi(getString.c_str());
            getline(fin, getString), cameraDimension = atoi(getString.c_str());
            
            fin.close();
        }
        else{
            
            xFOVTaken = 5;
            yFOVTaken = 5;
            chamberType1 = 1;
            chamberType2 = 1;
            snapFirstSecondTime = 1;
            snapFirstSecondTime2 = 1;
            snapPage = 0;
            snapPage2 = 0;
            wellOrientation1 = 0;
            wellOrientation2 = 0;
            wellOrientation3 = 0;
            cameraDimension = 512;
        }
        
        [currentX setIntegerValue:0]; //----Current XY, default 0----
        [currentY setIntegerValue:0];
        [xNumberPointTake setIntegerValue:xFOVTaken]; //----XY dimension, default 5----
        [yNumberPointTake setIntegerValue:yFOVTaken];
        
        if (cameraDimension == 512)[cameraDimensionDisplay setStringValue:@"512x1512"];
        else if (cameraDimension == 1024)[cameraDimensionDisplay setStringValue:@"1024x1024"];
        else if (cameraDimension == 1536)[cameraDimensionDisplay setStringValue:@"1536x1536"];
        else if (cameraDimension == 2048)[cameraDimensionDisplay setStringValue:@"2048x2048"];
        
        //CHAMBER**********ASSIG. CHAMBER TYPE NO, WELL NO AND DISPLAY NAME**********************************
        if (chamberType1 == 1) chamberWellLimit1 = 8, [chamberDisplay1 setStringValue:@"Lab-TekII 8"];
        else if (chamberType1 == 2) chamberWellLimit1 = 2, [chamberDisplay1 setStringValue:@"ibidi 2"];
        else if (chamberType1 == 3) chamberWellLimit1 = 4, [chamberDisplay1 setStringValue:@"ibidi 4"];
        else if (chamberType1 == 4) chamberWellLimit1 = 8, [chamberDisplay1 setStringValue:@"ibidi 8"];
        else if (chamberType1 == 5) chamberWellLimit1 = 6, [chamberDisplay1 setStringValue:@"ibidi Mu"];
        
        if (chamberType2 == 1) chamberWellLimit2 = 8, [chamberDisplay2 setStringValue:@"Lab-TekII 8"];
        else if (chamberType2 == 2) chamberWellLimit2 = 2, [chamberDisplay2 setStringValue:@"ibidi 2"];
        else if (chamberType2 == 3) chamberWellLimit2 = 4, [chamberDisplay2 setStringValue:@"ibidi 4"];
        else if (chamberType2 == 4) chamberWellLimit2 = 8, [chamberDisplay2 setStringValue:@"ibidi 8"];
        else if (chamberType2 == 5) chamberWellLimit2 = 6, [chamberDisplay2 setStringValue:@"ibidi Mu"];
        
        [stepperX setIntValue:[xNumberPointTake intValue]];
        [stepperY setIntValue:[yNumberPointTake intValue]];
        
        xyMapDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/MAP_XYMapSetting";
        
        fin.open(xyMapDataPath.c_str(), ios::in);
        
        if (fin.is_open()){
            getline(fin, getString), xCorner1 = atof(getString.c_str());
            getline(fin, getString), yCorner1 = atof(getString.c_str());
            getline(fin, getString), xCorner2 = atof(getString.c_str());
            getline(fin, getString), yCorner2 = atof(getString.c_str());
            getline(fin, getString), objectiveSelect = atoi(getString.c_str());
            fin.close();
        }
        
        [cornerX1 setStringValue:[NSString stringWithFormat:@"%.2f", xCorner1]];
        [cornerY1 setStringValue:[NSString stringWithFormat:@"%.2f", yCorner1]];
        [cornerX2 setStringValue:[NSString stringWithFormat:@"%.2f", xCorner2]];
        [cornerY2 setStringValue:[NSString stringWithFormat:@"%.2f", yCorner2]];
        
        if (objectiveSelect == 1) [magnification setStringValue:@"x10"];
        else if (objectiveSelect == 2) [magnification setStringValue:@"x20"];
        else if (objectiveSelect == 3) [magnification setStringValue:@"x40"];
        
        arrayWellPosition1 = new double [50];
        wellPositionCount1 = 0;
        arrayWellPosition2 = new double [50];
        wellPositionCount2 = 0;
        arraySelectedMap1 = new double [120];
        selectedMapCount1 = 0;
        selectedMapLimit1 = 120;
        selectedMapAddition1 = 0;
        arraySelectedMap2 = new double [120];
        selectedMapCount2 = 0;
        selectedMapLimit2 = 120;
        selectedMapAddition2 = 0;
        
        savedDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/MAP_XYPositionData";
        savedDataLastSavePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/MAP_XYPositionDataLastSave";
        
        string dataString;
        
        fin.open(savedDataPath.c_str(), ios::in);
        
        int readingFlag = 0;
        
        if (fin.is_open()){
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                
                getline(fin, dataString);
                
                if (dataString == "WellPosition1") readingFlag = 1;
                else if (readingFlag == 1 && dataString != "WellPosition2") arrayWellPosition1 [wellPositionCount1] = atof(dataString.c_str()), wellPositionCount1++;
                
                if (dataString == "WellPosition2") readingFlag = 2;
                else if (readingFlag == 2 && dataString != "SelectedFOV1") arrayWellPosition2 [wellPositionCount2] = atof(dataString.c_str()), wellPositionCount2++;
                
                if (dataString == "SelectedFOV1") readingFlag = 3;
                else if (readingFlag == 3 && dataString != "SelectedFOV2"){
                    if (selectedMapCount1+5 > selectedMapLimit1) selectedMapAddition1 = 0, [self selectedMapUpDate1];
                    
                    arraySelectedMap1 [selectedMapCount1] = atof(dataString.c_str()), selectedMapCount1++;
                }
                
                if (dataString == "SelectedFOV2") readingFlag = 4;
                else if (readingFlag == 4 && dataString != "END"){
                    if (selectedMapCount2+5 > selectedMapLimit2) selectedMapAddition2 = 0, [self selectedMapUpDate2];
                    
                    arraySelectedMap2 [selectedMapCount2] = atof(dataString.c_str()), selectedMapCount2++;
                }
                
                if (dataString == "END") terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            fin.close();
        }
        else{
            
            wellPositionCount1 = chamberWellLimit1*2+2;
            [self mapWellLabelSet1];
            wellPositionCount2 = chamberWellLimit2*2+2;
            [self mapWellLabelSet2];
        }
        
        //for (int counterA = 0; counterA < wellPositionCount1/2; counterA++){
        //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<arrayWellPosition1 [counterA*2+counterB];
        //    cout<<" arrayWellPosition "<<counterA+1<<" "<<counter1<<endl;
        //}
        
        //for (int counterA = 0; counterA < selectedMapCount1/6; counterA++){
        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arraySelectedMap1 [counterA*6+counterB];
        //    cout<<" arraySelectedMap1 "<<counterA+1<<" "<<endl;
        //}
        
        positionMDAPath = informationDirectoryPath+"/position2_stage_positions.STG"; //===================================
        
        xyDimensionMapPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/MAP_XYDimensionMapData";
        zMapPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/MAP_ZMapData";
        
        xyDimensionMapSavePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/MAP_XYDimensionMapDataLastSave";
        zMapSavePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/MAP_ZMapDataLastSave";
        
        arrayTableXYDimension = new int [100];
        tableXYDimensionCount = 0;
        arrayTableXYDimensionHold = new int [100];
        tableXYDimensionHoldCount = 0;
        arrayTableZ = new double [30];
        tableZCount = 0;
        arrayTableZHold = new double [30];
        tableZHoldCount = 0;
        
        for (int counter1 = 0; counter1 < 16; counter1++){
            arrayTableXYDimension [counter1*3] = 0;
            arrayTableXYDimension [counter1*3+1] = 0;
            arrayTableXYDimension [counter1*3+2] = 0;
            
            arrayTableXYDimensionHold [counter1*3] = 0;
            arrayTableXYDimensionHold [counter1*3+1] = 0;
            arrayTableXYDimensionHold [counter1*3+2] = 0;
        }
        
        for (int counter1 = 0; counter1 < 16; counter1++){
            arrayTableZ [counter1] = 0;
            arrayTableZHold [counter1] = 0;
        }
        
        fin.open(xyDimensionMapPath.c_str(), ios::in);
        
        if (fin.is_open()){
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                getline(fin, dataString);
                
                if (dataString != ""){
                    arrayTableXYDimension [tableXYDimensionCount] = atoi(dataString.c_str()), tableXYDimensionCount++;
                    arrayTableXYDimensionHold [tableXYDimensionCount] = atoi(dataString.c_str()), tableXYDimensionHoldCount++;
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            fin.close();
        }
        else{
            
            tableXYDimensionCount = (chamberWellLimit1+chamberWellLimit2)*3;
            tableXYDimensionHoldCount = (chamberWellLimit1+chamberWellLimit2)*3;
        }
        
        fin.open(zMapPath.c_str(), ios::in);
        
        if (fin.is_open()){
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                
                getline(fin, dataString);
                
                if (dataString != ""){
                    arrayTableZ [tableZCount] = atof(dataString.c_str()), tableZCount++;
                    arrayTableZHold [tableZHoldCount] = atof(dataString.c_str()), tableZHoldCount++;
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            fin.close();
        }
        else{
            
            tableZCount = chamberWellLimit1+chamberWellLimit2;
            tableZHoldCount = chamberWellLimit1+chamberWellLimit2;
        }
        
        //for (int counterA = 0; counterA < 16; counterA++){
        //    cout<<counterA<<" "<<arrayTableXYDimensionHold [counterA*3]<<" "<<arrayTableXYDimension [counterA*3]<<" arrayTableXYDimensionHold"<<endl;
        //}
        
        arrayReadingPositionMDA = new double [500];
        readingPositionMDACount = 0;
        readingPositionMDALimit = 500;
        arrayLabelPosition1 = new double [50];
        labelPositionCount1 = 0;
        arrayLabelPosition2 = new double [50];
        labelPositionCount1 = 0;
        
        arrayDirectoryInfo = new string [500];
        directoryInfoCount = 0;
        directoryInfoLimit = 500;
        
        [zAdjustWell setIntegerValue: 1];
        [stepperWell setIntValue: 1];
        [zAdjustValue setIntegerValue: 0];
        [stepperZ setIntValue: 0];
        
        zValueAdjust = 0;
        zValueAdjustWell = 1;
        tableViewCall = 1;
        
        if (xCorner1 == 0 && yCorner1 == 0) drawingPermit1 = 0;
        else drawingPermit1 = 1;
        
        if (xCorner2 == 0 && yCorner2 == 0) drawingPermit2 = 0;
        else drawingPermit2 = 1;
        
        stgSavePath = informationDirectoryPath+"/"+bodyName+"_positions.STG"; //===========================================
        
        mapReadFlag1 = 1;
        mapReadFlag2 = 1;
        
        arraySnapData = new double [20];
        for (int counter1 = 0; counter1 < 20; counter1++) arraySnapData [counter1] = 0;
        
        arraySnapData2 = new double [20];
        for (int counter1 = 0; counter1 < 20; counter1++) arraySnapData2 [counter1] = 0;
        
        arraySnapMainData = new double [1700];
        snapMainDataCount = 0;
        for (int counter1 = 0; counter1 < 1700; counter1++) arraySnapMainData [counter1] = 0;
        
        arraySnapMainData2 = new double [1700];
        snapMainDataCount2 = 0;
        for (int counter1 = 0; counter1 < 1700; counter1++) arraySnapMainData2 [counter1] = 0;
        
        //********array content********
        //1. Snap No 1--0
        //2. Snap X position--1
        //3. Snap Y position--2
        //4. Snap Z position--3
        //5. Set X position--4
        //6. Set Y position--5
        //7. Snap No 2--6
        //8. Snap X position--7
        //9. Snap Y position--8
        //10. Snap Z position--9
        //11. Set X position--10
        //12. Set Y position--11
        //13. Set Mark--12
        //14. Diff X position--13
        //15. Diff Y position--14
        //16. Diff Y position--15
        
        fin.open(snapDataPath1.c_str(), ios::in);
        
        if (fin.is_open()){
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                
                getline(fin, dataString);
                
                if (dataString != "") arraySnapMainData [snapMainDataCount] = atof(dataString.c_str()), snapMainDataCount++;
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            fin.close();
        }
        
        fin.open(snapDataPath2.c_str(), ios::in);
        
        if (fin.is_open()){
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                
                getline(fin, dataString);
                
                if (dataString != "") arraySnapMainData2 [snapMainDataCount2] = atof(dataString.c_str()), snapMainDataCount2++;
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            fin.close();
        }
        
        [orientationDR setStringValue:@"Bt/Lf"];
        
        if (wellOrientation1 == 0) [orientationWell1 setStringValue:@"<<<"];
        else [orientationWell1 setStringValue:@">>>"];
        
        if (wellOrientation2 == 0) [orientationWell2 setStringValue:@">>>"];
        else [orientationWell2 setStringValue:@"<<<"];
        
        if (wellOrientation3 == 0) [orientationWell3 setStringValue:@"<<<"];
        else [orientationWell3 setStringValue:@">>>"];
        
        arrayFileDelete = new string [100];
        fileDeleteCount = 0;
        fileDeleteLimit = 100;
        
        wellPositionTest = new int [50];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToXYMap object:self];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToXYMap2 object:self];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCommunication object:self];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTermination object:self];
        
        controllerTimer = [NSTimer scheduledTimerWithTimeInterval:0.3 target:self selector:@selector(displayData) userInfo:nil repeats:YES];
    }
    else exit (0);
}

-(void)displayData{
    if (tableViewCall == 1){
        tableViewCall = 0;
        [tableViewList reloadData];
    }
    
    if (analysisNameDisplayCall == 1){
        analysisNameDisplayCall = 0;
        [analysisName setStringValue:@(bodyName.c_str())];
    }
    
    //----XY Current Position Read----
    ifstream fin;
    
    fin.open(xyLogFilePath.c_str(), ios::in);
    
    if (fin.is_open()){
        int bitPosition = 0;
        int bitData = 0;
        string readData = "";
        
        ascIIconversion = [[ASCIIconversion alloc] init];
        
        while ((bitData = fin.get()) != EOF){
            [ascIIconversion ascIIConversion2:bitData];
            readData+= ascIIstring;
            bitPosition++;
        }
        
        fin.close();
        
        string xPositionData = readData.substr(0, readData.find(" "));
        xPositionCurrent = atof(xPositionData.c_str());
        string yPositionData = readData.substr(readData.find(" ")+1);
        yPositionCurrent = atof(yPositionData.c_str());
        
        if (xPositionCurrent != 0 && yPositionCurrent != 0){
            [currentX setStringValue:[NSString stringWithFormat:@"%.2f", xPositionCurrent]];
            [currentY setStringValue:[NSString stringWithFormat:@"%.2f", yPositionCurrent]];
        }
    }
    
    if (xClickCurrentHold != xPositionCurrent || yClickCurrentHold != yPositionCurrent){
        xClickCurrentHold = xPositionCurrent;
        yClickCurrentHold = yPositionCurrent;
        mapReadFlag1 = 1;
        mapReadFlag2 = 1;
    }
    
    //----Memorized position file read----
    //==========Well no, when Memorized position is performed, Well no is increased regardless of actual Well position (MetaMorph MDA).==========
    //==========Upon read the file and enter data into the array, Actual Well No is assigned.==========
    //==========If multiple base FOVs are drawn by the Memorized position, retain the recent one==========
    
    long sizeForCopy = 0;
    
    struct stat sizeOfFile;
    
    if (stat(positionMDAPath.c_str(), &sizeOfFile) == 0){
        sizeForCopy = sizeOfFile.st_size;
    }
    
    if (sizeForCopy != stgMemorizedSizeHold || drawingPermit1 == 2 || drawingPermit2 == 2){
        stgMemorizedSizeHold = sizeForCopy;
        
        if (drawingPermit1 == 2) drawingPermit1 = 1;
        if (drawingPermit2 == 2) drawingPermit2 = 1;
        
        fin.open(positionMDAPath.c_str(),ios::in | ios::binary);
        
        readingPositionMDACount = 0;
        int bitPosition = 0;
        int readFlag = 0;
        int bitData = 0;
        string readData = "";
        
        string extData;
        string wellNumberExtract;
        string horizontalBase;
        string verticalBase;
        string xPositionData;
        int xLimit = 0;
        string yPositionData;
        int yLimit = 0;
        string zPositionData;
        
        int findFlag = 0;
        
        if (fin.is_open()){
            ascIIconversion = [[ASCIIconversion alloc] init];
            
            while ((bitData = fin.get()) != EOF){
                if (readFlag == 1 && bitData == 70){
                    readFlag = 0;
                    
                    if ((int)readData.find("well") != -1){
                        extData = readData.substr(readData.find("well ")+5);
                        wellNumberExtract = extData.substr(0, extData.find(" "));
                        extData = extData.substr(extData.find("position ")+9);
                        horizontalBase = extData.substr(0, extData.find(" ")-1);
                        extData = extData.substr(extData.find(" ")+1);
                        verticalBase = extData.substr(0, extData.find(" ")-2);
                        extData = extData.substr(extData.find(" ")+1);
                        xPositionData = extData.substr(0, extData.find(" "));
                        xLimit = (int)(atof(xPositionData.c_str()));
                        extData = extData.substr(extData.find(" ")+1);
                        yPositionData = extData.substr(0, extData.find(" "));
                        yLimit = (int)(atof(yPositionData.c_str()));
                        extData = extData.substr(extData.find(" ")+1);
                        zPositionData = extData.substr(0, extData.find(" "));
                        
                        if (wellPositionCount1 != 0){
                            if (readingPositionMDACount+8 > readingPositionMDALimit) [self readingPositionMDAUpDate];
                            
                            findFlag = 0;
                            
                            //CHAMBER**********Add MDA display limit +- 500**********************************
                            if (chamberType1 == 1){
                                if (xLimit >= arrayWellPosition1 [0]-500 && xLimit <= arrayWellPosition1 [0]+10500+500 && yLimit >= arrayWellPosition1 [1]-500 && yLimit <= arrayWellPosition1 [1]+8332+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 1, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition1 [2]-500 && xLimit <= arrayWellPosition1 [2]+10500+500 && yLimit >= arrayWellPosition1 [3]-500 && yLimit <= arrayWellPosition1 [3]+8332+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 2, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition1 [4]-500 && xLimit <= arrayWellPosition1 [4]+10500+500 && yLimit >= arrayWellPosition1 [5]-500 && yLimit <= arrayWellPosition1 [5]+8332+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 3, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition1 [6]-500 && xLimit <= arrayWellPosition1 [6]+10500+500 && yLimit >= arrayWellPosition1 [7]-500 && yLimit <= arrayWellPosition1 [7]+8332+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 4, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition1 [8]-500 && xLimit <= arrayWellPosition1 [8]+10500+500 && yLimit >= arrayWellPosition1 [9]-500 && yLimit <= arrayWellPosition1 [9]+8332+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 5, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition1 [10]-500 && xLimit <= arrayWellPosition1 [10]+10500+500 && yLimit >= arrayWellPosition1 [11]-500 && yLimit <= arrayWellPosition1 [11]+8332+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 6, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition1 [12]-500 && xLimit <= arrayWellPosition1 [12]+10500+500 && yLimit >= arrayWellPosition1 [13]-500 && yLimit <= arrayWellPosition1 [13]+8332+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 7, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition1 [14]-500 && xLimit <= arrayWellPosition1 [14]+10500+500 && yLimit >= arrayWellPosition1 [15]-500 && yLimit <= arrayWellPosition1 [15]+8332+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 8, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                            }
                            else if (chamberType1 == 2){
                                if (xLimit >= arrayWellPosition1 [0]-500 && xLimit <= arrayWellPosition1 [0]+22170+500 && yLimit >= arrayWellPosition1 [1]-500 && yLimit <= arrayWellPosition1 [1]+19687+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 1, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition1 [2]-500 && xLimit <= arrayWellPosition1 [2]+22170+500 && yLimit >= arrayWellPosition1 [3]-500 && yLimit <= arrayWellPosition1 [3]+19687+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 2, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                            }
                            else if (chamberType1 == 3){
                                if (xLimit >= arrayWellPosition1 [0]-500 && xLimit <= arrayWellPosition1 [0]+9938+500 && yLimit >= arrayWellPosition1 [1]-500 && yLimit <= arrayWellPosition1 [1]+19687+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 1, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition1 [2]-500 && xLimit <= arrayWellPosition1 [2]+9938+500 && yLimit >= arrayWellPosition1 [3]-500 && yLimit <= arrayWellPosition1 [3]+19687+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 2, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition1 [4]-500 && xLimit <= arrayWellPosition1 [4]+9938+500 && yLimit >= arrayWellPosition1 [5]-500 && yLimit <= arrayWellPosition1 [5]+19687+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 3, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition1 [6]-500 && xLimit <= arrayWellPosition1 [6]+9938+500 && yLimit >= arrayWellPosition1 [7]-500 && yLimit <= arrayWellPosition1 [7]+19687+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 4, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                            }
                            else if (chamberType1 == 4){
                                if (xLimit >= arrayWellPosition1 [0]-500 && xLimit <= arrayWellPosition1 [0]+10700+500 && yLimit >= arrayWellPosition1 [1]-500 && yLimit <= arrayWellPosition1 [1]+9489+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 1, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition1 [2]-500 && xLimit <= arrayWellPosition1 [2]+10700+500 && yLimit >= arrayWellPosition1 [3]-500 && yLimit <= arrayWellPosition1 [3]+9489+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 2, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition1 [4]-500 && xLimit <= arrayWellPosition1 [4]+10700+500 && yLimit >= arrayWellPosition1 [5]-500 && yLimit <= arrayWellPosition1 [5]+9489+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 3, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition1 [6]-500 && xLimit <= arrayWellPosition1 [6]+10700+500 && yLimit >= arrayWellPosition1 [7]-500 && yLimit <= arrayWellPosition1 [7]+9489+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 4, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition1 [8]-500 && xLimit <= arrayWellPosition1 [8]+10700+500 && yLimit >= arrayWellPosition1 [9]-500 && yLimit <= arrayWellPosition1 [9]+9489+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 5, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition1 [10]-500 && xLimit <= arrayWellPosition1 [10]+10700+500 && yLimit >= arrayWellPosition1 [11]-500 && yLimit <= arrayWellPosition1 [11]+9489+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 6, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition1 [12]-500 && xLimit <= arrayWellPosition1 [12]+10700+500 && yLimit >= arrayWellPosition1 [13]-500 && yLimit <= arrayWellPosition1 [13]+9489+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 7, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition1 [14]-500 && xLimit <= arrayWellPosition1 [14]+10700+500 && yLimit >= arrayWellPosition1 [15]-500 && yLimit <= arrayWellPosition1 [15]+9489+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 8, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                            }
                            else if (chamberType1 == 5){
                                if (xLimit >= arrayWellPosition1 [0]-500 && xLimit <= arrayWellPosition1 [0]+3868+500 && yLimit >= arrayWellPosition1 [1]-500 && yLimit <= arrayWellPosition1 [1]+14238+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 1, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition1 [2]-500 && xLimit <= arrayWellPosition1 [2]+3868+500 && yLimit >= arrayWellPosition1 [3]-500 && yLimit <= arrayWellPosition1 [3]+14238+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 2, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition1 [4]-500 && xLimit <= arrayWellPosition1 [4]+3868+500 && yLimit >= arrayWellPosition1 [5]-500 && yLimit <= arrayWellPosition1 [5]+14238+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 3, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition1 [6]-500 && xLimit <= arrayWellPosition1 [6]+3868+500 && yLimit >= arrayWellPosition1 [7]-500 && yLimit <= arrayWellPosition1 [7]+14238+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 4, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition1 [8]-500 && xLimit <= arrayWellPosition1 [8]+3868+500 && yLimit >= arrayWellPosition1 [9]-500 && yLimit <= arrayWellPosition1 [9]+14238+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 5, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition1 [10]-500 && xLimit <= arrayWellPosition1 [10]+3868+500 && yLimit >= arrayWellPosition1 [11]-500 && yLimit <= arrayWellPosition1 [11]+14238+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = 6, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                            }
                            
                            if (findFlag == 1){
                                arrayReadingPositionMDA [readingPositionMDACount] = atof(verticalBase.c_str()), readingPositionMDACount++;
                                arrayReadingPositionMDA [readingPositionMDACount] = atof(horizontalBase.c_str()), readingPositionMDACount++;
                                arrayReadingPositionMDA [readingPositionMDACount] = atof(wellNumberExtract.c_str()), readingPositionMDACount++;
                                arrayReadingPositionMDA [readingPositionMDACount] = atof(xPositionData.c_str()), readingPositionMDACount++;
                                arrayReadingPositionMDA [readingPositionMDACount] = atof(yPositionData.c_str()), readingPositionMDACount++;
                                arrayReadingPositionMDA [readingPositionMDACount] = atof(zPositionData.c_str()), readingPositionMDACount++;
                            }
                        }
                        if (wellPositionCount2 != 0){
                            if (readingPositionMDACount+8 > readingPositionMDALimit) [self readingPositionMDAUpDate];
                            
                            findFlag = 0;
                            
                            //CHAMBER**********Add MDA display limit +- 500**********************************
                            if (chamberType2 == 1){
                                if (xLimit >= arrayWellPosition2 [0]-500 && xLimit <= arrayWellPosition2 [0]+10500+500 && yLimit >= arrayWellPosition2 [1]-500 && yLimit <= arrayWellPosition2 [1]+8332+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+1, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition2 [2]-500 && xLimit <= arrayWellPosition2 [2]+10500+500 && yLimit >= arrayWellPosition2 [3]-500 && yLimit <= arrayWellPosition2 [3]+8332+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+2, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition2 [4]-500 && xLimit <= arrayWellPosition2 [4]+10500+500 && yLimit >= arrayWellPosition2 [5]-500 && yLimit <= arrayWellPosition2 [5]+8332+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+3, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition2 [6]-500 && xLimit <= arrayWellPosition2 [6]+10500+500 && yLimit >= arrayWellPosition2 [7]-500 && yLimit <= arrayWellPosition2 [7]+8332+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+4, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition2 [8]-500 && xLimit <= arrayWellPosition2 [8]+10500+500 && yLimit >= arrayWellPosition2 [9]-500 && yLimit <= arrayWellPosition2 [9]+8332+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+5, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition2 [10]-500 && xLimit <= arrayWellPosition2 [10]+10500+500 && yLimit >= arrayWellPosition2 [11]-500 && yLimit <= arrayWellPosition2 [11]+8332+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+6, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition2 [12]-500 && xLimit <= arrayWellPosition2 [12]+10500+500 && yLimit >= arrayWellPosition2 [13]-500 && yLimit <= arrayWellPosition2 [13]+8332+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+7, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else  if (xLimit >= arrayWellPosition2 [14]-500 && xLimit <= arrayWellPosition2 [14]+10500+500 && yLimit >= arrayWellPosition2 [15]-500 && yLimit <= arrayWellPosition2 [15]+8332+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+8, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                            }
                            else if (chamberType2 == 2){
                                if (xLimit >= arrayWellPosition2 [0]-500 && xLimit <= arrayWellPosition2 [0]+22170+500 && yLimit >= arrayWellPosition2 [1]-500 && yLimit <= arrayWellPosition2 [1]+19687+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+1, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition2 [2]-500 && xLimit <= arrayWellPosition2 [2]+22170+500 && yLimit >= arrayWellPosition2 [3]-500 && yLimit <= arrayWellPosition2 [3]+19687+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+2, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                            }
                            else if (chamberType2 == 3){
                                if (xLimit >= arrayWellPosition2 [0]-500 && xLimit <= arrayWellPosition2 [0]+9938+500 && yLimit >= arrayWellPosition2 [1]-500 && yLimit <= arrayWellPosition2 [1]+19687+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+1, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition2 [2]-500 && xLimit <= arrayWellPosition2 [2]+9938+500 && yLimit >= arrayWellPosition2 [3]-500 && yLimit <= arrayWellPosition2 [3]+19687+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+2, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition2 [4]-500 && xLimit <= arrayWellPosition2 [4]+9938+500 && yLimit >= arrayWellPosition2 [5]-500 && yLimit <= arrayWellPosition2 [5]+19687+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+3, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition2 [6]-500 && xLimit <= arrayWellPosition2 [6]+9938+500 && yLimit >= arrayWellPosition2 [7]-500 && yLimit <= arrayWellPosition2 [7]+19687+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+4, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                            }
                            else if (chamberType1 == 4){
                                if (xLimit >= arrayWellPosition2 [0]-500 && xLimit <= arrayWellPosition2 [0]+10700+500 && yLimit >= arrayWellPosition2 [1]-500 && yLimit <= arrayWellPosition2 [1]+9489+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+1, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition2 [2]-500 && xLimit <= arrayWellPosition2 [2]+10700+500 && yLimit >= arrayWellPosition2 [3]-500 && yLimit <= arrayWellPosition2 [3]+9489+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+2, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition2 [4]-500 && xLimit <= arrayWellPosition2 [4]+10700+500 && yLimit >= arrayWellPosition2 [5]-500 && yLimit <= arrayWellPosition2 [5]+9489+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+3, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition2 [6]-500 && xLimit <= arrayWellPosition2 [6]+10700+500 && yLimit >= arrayWellPosition2 [7]-500 && yLimit <= arrayWellPosition2 [7]+9489+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+4, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition2 [8]-500 && xLimit <= arrayWellPosition2 [8]+10700+500 && yLimit >= arrayWellPosition2 [9]-500 && yLimit <= arrayWellPosition2 [9]+9489+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+5, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition2 [10]-500 && xLimit <= arrayWellPosition2 [10]+10700+500 && yLimit >= arrayWellPosition2 [11]-500 && yLimit <= arrayWellPosition2 [11]+9489+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+6, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition2 [12]-500 && xLimit <= arrayWellPosition2 [12]+10700+500 && yLimit >= arrayWellPosition2 [13]-500 && yLimit <= arrayWellPosition2 [13]+9489+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+7, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition2 [14]-500 && xLimit <= arrayWellPosition2 [14]+10700+500 && yLimit >= arrayWellPosition2 [15]-500 && yLimit <= arrayWellPosition2 [15]+9489+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+8, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                            }
                            else if (chamberType1 == 4){
                                if (xLimit >= arrayWellPosition2 [0]-500 && xLimit <= arrayWellPosition2 [0]+3868+500 && yLimit >= arrayWellPosition2 [1]-500 && yLimit <= arrayWellPosition2 [1]+14238+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+1, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition2 [2]-500 && xLimit <= arrayWellPosition2 [2]+3868+500 && yLimit >= arrayWellPosition2 [3]-500 && yLimit <= arrayWellPosition2 [3]+14238+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+2, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition2 [4]-500 && xLimit <= arrayWellPosition2 [4]+3868+500 && yLimit >= arrayWellPosition2 [5]-500 && yLimit <= arrayWellPosition2 [5]+14238+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+3, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition2 [6]-500 && xLimit <= arrayWellPosition2 [6]+3868+500 && yLimit >= arrayWellPosition2 [7]-500 && yLimit <= arrayWellPosition2 [7]+14238+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+4, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition2 [8]-500 && xLimit <= arrayWellPosition2 [8]+3868+500 && yLimit >= arrayWellPosition2 [9]-500 && yLimit <= arrayWellPosition2 [9]+14238+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+5, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                                else if (xLimit >= arrayWellPosition2 [10]-500 && xLimit <= arrayWellPosition2 [10]+3868+500 && yLimit >= arrayWellPosition2 [11]-500 && yLimit <= arrayWellPosition2 [11]+14238+500){
                                    arrayReadingPositionMDA [readingPositionMDACount] = chamberWellLimit1+6, readingPositionMDACount++;
                                    findFlag = 1;
                                }
                            }
                            
                            if (findFlag == 1){
                                arrayReadingPositionMDA [readingPositionMDACount] = atof(verticalBase.c_str()), readingPositionMDACount++;
                                arrayReadingPositionMDA [readingPositionMDACount] = atof(horizontalBase.c_str()), readingPositionMDACount++;
                                arrayReadingPositionMDA [readingPositionMDACount] = atof(wellNumberExtract.c_str()), readingPositionMDACount++;
                                arrayReadingPositionMDA [readingPositionMDACount] = atof(xPositionData.c_str()), readingPositionMDACount++;
                                arrayReadingPositionMDA [readingPositionMDACount] = atof(yPositionData.c_str()), readingPositionMDACount++;
                                arrayReadingPositionMDA [readingPositionMDACount] = atof(zPositionData.c_str()), readingPositionMDACount++;
                            }
                        }
                    }
                    
                    readData = "";
                }
                
                if (readFlag == 0 && bitData == 119) readFlag = 1;
                if (readFlag == 1 && bitData != 70){
                    [ascIIconversion ascIIConversion2:bitData];
                    readData+= ascIIstring;
                }
                
                bitPosition++;
            }
            
            fin.close();
        }
        
        double *arrayMapTemp = new double [readingPositionMDACount+50];
        
        int firstWellNumber = 0;
        int resetFlag = 0;
        int mapTempCount = 0;
        
        for (int counter1 = 1; counter1 <= 16; counter1++){
            firstWellNumber = 0;
            resetFlag = 0;
            
            for (int counter2 = 0; counter2 < readingPositionMDACount/7; counter2++){
                if (counter1 == arrayReadingPositionMDA [counter2*7]){
                    if (firstWellNumber == 0) firstWellNumber = (int)arrayReadingPositionMDA [counter2*7+3];
                    else if (firstWellNumber != 0 && firstWellNumber != arrayReadingPositionMDA [counter2*7+3]){
                        firstWellNumber = (int)arrayReadingPositionMDA [counter2*7+3];
                        resetFlag = 1;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < readingPositionMDACount/7; counterA++){
            //    for (int counterB = 0; counterB < 7; counterB++) cout<< arrayReadingPositionMDA [counterA*7+counterB]<<endl;
            //    cout<<" arrayReadingPositionMDA"<<endl;
            //}
            
            if (resetFlag == 1){
                mapTempCount = 0;
                
                for (int counter2 = 0; counter2 < readingPositionMDACount/7; counter2++){
                    if (counter1 == arrayReadingPositionMDA [counter2*7]){
                        if (firstWellNumber == arrayReadingPositionMDA [counter2*7+3]){
                            arrayMapTemp [mapTempCount] = arrayReadingPositionMDA [counter2*7], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayReadingPositionMDA [counter2*7+1], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayReadingPositionMDA [counter2*7+2], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayReadingPositionMDA [counter2*7+3], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayReadingPositionMDA [counter2*7+4], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayReadingPositionMDA [counter2*7+5], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayReadingPositionMDA [counter2*7+6], mapTempCount++;
                        }
                    }
                    else{
                        
                        arrayMapTemp [mapTempCount] = arrayReadingPositionMDA [counter2*7], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arrayReadingPositionMDA [counter2*7+1], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arrayReadingPositionMDA [counter2*7+2], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arrayReadingPositionMDA [counter2*7+3], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arrayReadingPositionMDA [counter2*7+4], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arrayReadingPositionMDA [counter2*7+5], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arrayReadingPositionMDA [counter2*7+6], mapTempCount++;
                    }
                }
                
                readingPositionMDACount = 0;
                
                for (int counter2 = 0; counter2 < mapTempCount; counter2++) arrayReadingPositionMDA [readingPositionMDACount] = arrayMapTemp [counter2], readingPositionMDACount++;
                
                //for (int counterA = 0; counterA < readingPositionMDACount/7; counterA++){
                //    for (int counterB = 0; counterB < 7; counterB++) cout<< arrayReadingPositionMDA [counterA*7+counterB]<<endl;
                //    cout<<" arrayReadingPositionMDA"<<endl;
                //}
            }
        }
        
        delete [] arrayMapTemp;
        
        mapReadFlag1 = 1;
        mapReadFlag2 = 1;
    }
    
    if (wellDataSaveRequest == 1){
        wellDataSaveRequest = 0;
        [self saveCurrentData];
        
        if (bodyName.substr(bodyName.length()-2) == "IF"){
            [self saveLastSavedData];
        }
    }
    
    if (zPositionSaveCount == 1){
        zPositionSaveCount++;
    }
    else if (zPositionSaveCount >= 2 && zPositionSaveCount < 24000){
        zPositionSaveCount++;
    }
    else if (zPositionSaveCount == 24000){
        string zMapSavePath2 = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/MAP_ZMapDataLastSave2";
        
        ofstream oin;
        
        oin.open(zMapSavePath2.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 < chamberWellLimit1+chamberWellLimit2; counter1++) oin<<arrayTableZ [counter1]<<endl;
        
        oin.close();
        
        zPositionSaveCount = 0;
    }
}

-(void)controlTextDidChange:(NSNotification *)aNotification{
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == xNumberPointTake){
            if ([xNumberPointTake intValue] >= 1 && [xNumberPointTake intValue] <= 100){
                [stepperX setIntValue:[xNumberPointTake intValue]];
                xFOVTaken = [stepperX intValue];
                
                subProcesses = [[SubProcesses alloc] init];
                [subProcesses mapDataSave];
            }
        }
        
        if ([aNotification object] == yNumberPointTake){
            if ([yNumberPointTake intValue] >= 1 && [yNumberPointTake intValue] <= 100){
                [stepperY setIntValue:[yNumberPointTake intValue]];
                yFOVTaken = [stepperY intValue];
                
                subProcesses = [[SubProcesses alloc] init];
                [subProcesses mapDataSave];
            }
        }
        
        if ([aNotification object] == zAdjustWell){
            if ([zAdjustWell intValue] >= 1 && [zAdjustWell intValue] <= 16){
                [stepperWell setIntValue:[zAdjustWell intValue]];
                zValueAdjustWell = [stepperWell intValue];
            }
        }
        
        if ([aNotification object] == zAdjustValue){
            if ([zAdjustValue intValue] >= -10000 && [zAdjustValue intValue] <= 10000){
                [stepperZ setIntValue:[zAdjustValue intValue]];
                zValueAdjust = [stepperZ intValue];
            }
        }
        
        if ([aNotification object] == stepperStartDisplayM){
            if ([stepperStartDisplayM intValue] >= 1 && [stepperStartDisplayM intValue] <= 500){
                [stepperStartM setIntValue:[stepperStartDisplayM intValue]];
                stepperStartHoldM = [stepperStartDisplayM intValue];
            }
        }
        
        if ([aNotification object] == stepperEveryDisplayM){
            if ([stepperEveryDisplayM intValue] >= 1 && [stepperEveryDisplayM intValue] <= 100){
                [stepperEveryM setIntValue:[stepperEveryDisplayM intValue]];
                stepperEveryHoldM = [stepperEveryDisplayM intValue];
            }
        }
    }
}

-(IBAction)stepperActionX:(id)sender{
    [xNumberPointTake setIntValue: [stepperX intValue]];
    xFOVTaken = [stepperX intValue];
    
    subProcesses = [[SubProcesses alloc] init];
    [subProcesses mapDataSave];
}

-(IBAction)stepperActionY:(id)sender{
    [yNumberPointTake setIntValue: [stepperY intValue]];
    yFOVTaken = [stepperY intValue];
    
    subProcesses = [[SubProcesses alloc] init];
    [subProcesses mapDataSave];
}

-(IBAction)stepperActionWell:(id)sender{
    [zAdjustWell setIntValue: [stepperWell intValue]];
    zValueAdjustWell = [stepperWell intValue];
}

-(IBAction)stepperActionZ:(id)sender{
    [zAdjustValue setIntValue: [stepperZ intValue]];
    zValueAdjust = [stepperZ intValue];
}

-(IBAction)stopProcess:(id)sender{
    if (controllerTimer) [controllerTimer invalidate];
    
    delete [] arrayWellPosition1;
    delete [] arrayWellPosition2;
    delete [] arraySelectedMap1;
    delete [] arraySelectedMap2;
    delete [] arrayTableXYDimension;
    delete [] arrayTableZ;
    delete [] arrayReadingPositionMDA;
    delete [] arrayLabelPosition1;
    delete [] arrayLabelPosition2;
    delete [] arrayTableXYDimensionHold;
    delete [] arrayTableZHold;
    delete [] arraySnapData;
    delete [] arraySnapData2;
    delete [] arraySnapMainData;
    delete [] arraySnapMainData2;
    delete [] arrayDirectoryInfo;
    delete [] arrayFileDelete;
    delete [] wellPositionTest;
    
    if (imageDataHoldZImageStatus == 1){
        for (int counter1 = 0; counter1 < zImageHeight*zImagePlane+2; counter1++) delete [] arrayImageDataHoldZImage [counter1];
        delete [] arrayImageDataHoldZImage;
    }
    
    exit (0);
}

-(IBAction)chamber1:(id)sender{
    if (drawingPermit1 == 0){
        xCorner1 = xPositionCurrent;
        yCorner1 = yPositionCurrent;
        
        [cornerX1 setStringValue:[NSString stringWithFormat:@"%.2f", xCorner1]];
        [cornerY1 setStringValue:[NSString stringWithFormat:@"%.2f", yCorner1]];
        
        [self mapWellLabelSet1];
        [self saveCurrentData];
        [self saveCornerData];
        
        drawingPermit1 = 2;
    }
    
    if (drawingPermit1 == 1){
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Reset Previous Settings?"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            xCorner1 = xPositionCurrent;
            yCorner1 = yPositionCurrent;
            
            [cornerX1 setStringValue:[NSString stringWithFormat:@"%.2f", xCorner1]];
            [cornerY1 setStringValue:[NSString stringWithFormat:@"%.2f", yCorner1]];
            
            selectedMapCount1 = 0;
            
            [self mapWellLabelSet1];
            [self saveCurrentData];
            [self saveCornerData];
            
            drawingPermit1 = 2;
            
            remove(savedDataLastSavePath.c_str());
            remove(xyDimensionMapSavePath.c_str());
            remove(zMapSavePath.c_str());
            
            string zMapSavePath2 = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/MAP_ZMapDataLastSave2";
            remove(zMapSavePath2.c_str());
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
}

//CHAMBER**********Add CHABER DIMENSION INFO**********************************
-(void)mapWellLabelSet1{
    if (chamberType1 == 1){
        if (wellOrientation1 == 0){
            arrayWellPosition1 [0] = xCorner1-2186-10500; //----WA1----
            arrayWellPosition1 [1] = yCorner1-8332;
            arrayWellPosition1 [2] = xCorner1; //----WA2----
            arrayWellPosition1 [3] = yCorner1-8332;
            arrayWellPosition1 [4] = xCorner1+10500+2186; //----WA3----
            arrayWellPosition1 [5] = yCorner1-8332;
            arrayWellPosition1 [6] = xCorner1+10500+2186+10500+2186; //----WA4----
            arrayWellPosition1 [7] = yCorner1-8332;
            arrayWellPosition1 [8] = xCorner1+10500+2186+10500+2186; //----WA5----
            arrayWellPosition1 [9] = yCorner1-8332-2186-8332;
            arrayWellPosition1 [10] = xCorner1+10500+2186; //----WA6----
            arrayWellPosition1 [11] = yCorner1-8332-2186-8332;
            arrayWellPosition1 [12] = xCorner1; //----WA7----
            arrayWellPosition1 [13] = yCorner1-8332-2186-8332;
            arrayWellPosition1 [14] = xCorner1-2186-10500; //----WA8----
            arrayWellPosition1 [15] = yCorner1-8332-2186-8332;
            arrayWellPosition1 [16] = xCorner1-2186-10500-2186; //----BA1----
            arrayWellPosition1 [17] = yCorner1-8332-2186-8332-2186;
        }
        else if (wellOrientation1 == 1){
            arrayWellPosition1 [0] = xCorner1-2186-10500; //----WA1----
            arrayWellPosition1 [1] = yCorner1-8332;
            arrayWellPosition1 [2] = xCorner1; //----WA2----
            arrayWellPosition1 [3] = yCorner1-8332;
            arrayWellPosition1 [4] = xCorner1+10500+2186; //----WA3----
            arrayWellPosition1 [5] = yCorner1-8332;
            arrayWellPosition1 [6] = xCorner1+10500+2186+10500+2186; //----WA4----
            arrayWellPosition1 [7] = yCorner1-8332;
            arrayWellPosition1 [14] = xCorner1+10500+2186+10500+2186; //----WA5----
            arrayWellPosition1 [15] = yCorner1-8332-2186-8332;
            arrayWellPosition1 [12] = xCorner1+10500+2186; //----WA6----
            arrayWellPosition1 [13] = yCorner1-8332-2186-8332;
            arrayWellPosition1 [10] = xCorner1; //----WA7----
            arrayWellPosition1 [11] = yCorner1-8332-2186-8332;
            arrayWellPosition1 [8] = xCorner1-2186-10500; //----WA8----
            arrayWellPosition1 [9] = yCorner1-8332-2186-8332;
            arrayWellPosition1 [16] = xCorner1-2186-10500-2186; //----BA1----
            arrayWellPosition1 [17] = yCorner1-8332-2186-8332-2186;
        }
        
        wellPositionCount1 = 18;
    }
    else if (chamberType1 == 2){
        arrayWellPosition1 [0] = xCorner1-2597-22170; //----WA1----
        arrayWellPosition1 [1] = yCorner1-19687;
        arrayWellPosition1 [2] = xCorner1; //----WA2----
        arrayWellPosition1 [3] = yCorner1-19687;
        arrayWellPosition1 [4] = xCorner1-2597-22170-2186; //----BA2----
        arrayWellPosition1 [5] = yCorner1-19687-2186;
        
        wellPositionCount1 = 5;
    }
    else if (chamberType1 == 3){
        arrayWellPosition1 [0] = xCorner1-2499-9938; //----WA1----
        arrayWellPosition1 [1] = yCorner1-19687;
        arrayWellPosition1 [2] = xCorner1; //----WA2----
        arrayWellPosition1 [3] = yCorner1-19687;
        arrayWellPosition1 [4] = xCorner1+9938+2499; //----WA3----
        arrayWellPosition1 [5] = yCorner1-19687;
        arrayWellPosition1 [6] = xCorner1+9938+2499+9938+2499; //----WA4----
        arrayWellPosition1 [7] = yCorner1-19687;
        arrayWellPosition1 [8] = xCorner1-2499-9938-2186; //----BA1----
        arrayWellPosition1 [9] = yCorner1-19687-2186;
        
        wellPositionCount1 = 9;
    }
    else if (chamberType1 == 4){
        if (wellOrientation1 == 0){
            arrayWellPosition1 [0] = xCorner1-1146-10700; //----WA1----
            arrayWellPosition1 [1] = yCorner1-9489;
            arrayWellPosition1 [2] = xCorner1; //----WA2----
            arrayWellPosition1 [3] = yCorner1-9489;
            arrayWellPosition1 [4] = xCorner1+10700+2673; //----WA3----
            arrayWellPosition1 [5] = yCorner1-9489;
            arrayWellPosition1 [6] = xCorner1+10700+2673+10700+1146; //----WA4----
            arrayWellPosition1 [7] = yCorner1-9489;
            arrayWellPosition1 [8] = xCorner1+10700+2673+10700+1146; //----WA5----
            arrayWellPosition1 [9] = yCorner1-9489-1528-9489;
            arrayWellPosition1 [10] = xCorner1+10700+2673; //----WA6----
            arrayWellPosition1 [11] = yCorner1-9489-1528-9489;
            arrayWellPosition1 [12] = xCorner1; //----WA7----
            arrayWellPosition1 [13] = yCorner1-9489-1528-9489;
            arrayWellPosition1 [14] = xCorner1-1146-10700; //----WA8----
            arrayWellPosition1 [15] = yCorner1-9489-1528-9489;
            arrayWellPosition1 [16] = xCorner1-1146-10700-2186; //----BA1----
            arrayWellPosition1 [17] = yCorner1-9489-1528-9489-2186;
        }
        else if (wellOrientation1 == 1){
            arrayWellPosition1 [0] = xCorner1-1146-10700; //----WA1----
            arrayWellPosition1 [1] = yCorner1-9489;
            arrayWellPosition1 [2] = xCorner1; //----WA2----
            arrayWellPosition1 [3] = yCorner1-9489;
            arrayWellPosition1 [4] = xCorner1+10700+2673; //----WA3----
            arrayWellPosition1 [5] = yCorner1-9489;
            arrayWellPosition1 [6] = xCorner1+10700+2673+10700+1146; //----WA4----
            arrayWellPosition1 [7] = yCorner1-9489;
            arrayWellPosition1 [14] = xCorner1+10700+2673+10700+1146; //----WA5----
            arrayWellPosition1 [15] = yCorner1-9489-1528-9489;
            arrayWellPosition1 [12] = xCorner1+10700+2673; //----WA6----
            arrayWellPosition1 [13] = yCorner1-9489-1528-9489;
            arrayWellPosition1 [10] = xCorner1; //----WA7----
            arrayWellPosition1 [11] = yCorner1-9489-1528-9489;
            arrayWellPosition1 [8] = xCorner1-1146-10700; //----WA8----
            arrayWellPosition1 [9] = yCorner1-9489-1528-9489;
            arrayWellPosition1 [16] = xCorner1-1146-10700-2186; //----BA1----
            arrayWellPosition1 [17] = yCorner1-9489-1528-9489-2186;
        }
        
        wellPositionCount1 = 18;
    }
    else if (chamberType1 == 5){
        arrayWellPosition1 [0] = xCorner1-5152-3868; //----WA1----
        arrayWellPosition1 [1] = yCorner1-14238;
        arrayWellPosition1 [2] = xCorner1; //----WA2----
        arrayWellPosition1 [3] = yCorner1-14238;
        arrayWellPosition1 [4] = xCorner1+3868+5152; //----WA3----
        arrayWellPosition1 [5] = yCorner1-14238;
        arrayWellPosition1 [6] = xCorner1+3868+5152+3868+5152; //----WA4----
        arrayWellPosition1 [7] = yCorner1-14238;
        arrayWellPosition1 [8] = xCorner1+3868+5152+3868+5152+3868+5152; //----WA5----
        arrayWellPosition1 [9] = yCorner1-14238;
        arrayWellPosition1 [10] = xCorner1+3868+5152+3868+5152+3868+5152+3868+5152; //----WA6----
        arrayWellPosition1 [11] = yCorner1-14238;
        arrayWellPosition1 [12] = xCorner1-5152-3868-2186; //----BA1----
        arrayWellPosition1 [13] = yCorner1-14238-2186-2186;
        
        wellPositionCount1 = 14;
    }
}

-(IBAction)chamber2:(id)sender{
    if (drawingPermit2 == 0){
        xCorner2 = xPositionCurrent;
        yCorner2 = yPositionCurrent;
        
        [cornerX2 setStringValue:[NSString stringWithFormat:@"%.2f", xCorner2]];
        [cornerY2 setStringValue:[NSString stringWithFormat:@"%.2f", yCorner2]];
        
        [self mapWellLabelSet2];
        [self saveCurrentData];
        [self saveCornerData];
        
        drawingPermit2 = 2;
    }
    
    if (drawingPermit2 == 1){
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Reset Previous Settings?"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            xCorner2 = xPositionCurrent;
            yCorner2 = yPositionCurrent;
            
            [cornerX2 setStringValue:[NSString stringWithFormat:@"%.2f", xCorner2]];
            [cornerY2 setStringValue:[NSString stringWithFormat:@"%.2f", yCorner2]];
            
            selectedMapCount2 = 0;
            
            [self mapWellLabelSet2];
            [self saveCurrentData];
            [self saveCornerData];
            
            drawingPermit2 = 2;
            
            remove(savedDataLastSavePath.c_str());
            remove(xyDimensionMapSavePath.c_str());
            remove(zMapSavePath.c_str());
            
            string zMapSavePath2 = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/MAP_ZMapDataLastSave2";
            remove(zMapSavePath2.c_str());
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
}

//CHAMBER**********CHAMBER DIMENSION INFO**********************************
-(void)mapWellLabelSet2{
    if (chamberType2 == 1){
        if (wellOrientation2 == 0 && wellOrientation3 == 0){
            arrayWellPosition2 [0] = xCorner2-2186-10500; //----WB1----
            arrayWellPosition2 [1] = yCorner2-8332;
            arrayWellPosition2 [2] = xCorner2; //----WB2----
            arrayWellPosition2 [3] = yCorner2-8332;
            arrayWellPosition2 [4] = xCorner2+10500+2186; //----WB3----
            arrayWellPosition2 [5] = yCorner2-8332;
            arrayWellPosition2 [6] = xCorner2+10500+2186+10500+2186; //----WB4----
            arrayWellPosition2 [7] = yCorner2-8332;
            arrayWellPosition2 [8] = xCorner2+10500+2186+10500+2186; //----WB5----
            arrayWellPosition2 [9] = yCorner2-8332-2186-8332;
            arrayWellPosition2 [10] = xCorner2+10500+2186; //----WB6----
            arrayWellPosition2 [11] = yCorner2-8332-2186-8332;
            arrayWellPosition2 [12] = xCorner2; //----WB7----
            arrayWellPosition2 [13] = yCorner2-8332-2186-8332;
            arrayWellPosition2 [14] = xCorner2-2186-10500; //----WB8----
            arrayWellPosition2 [15] = yCorner2-8332-2186-8332;
            arrayWellPosition2 [16] = xCorner2-2186-10500-2186; //----BB2----
            arrayWellPosition2 [17] = yCorner2-8332-2186-8332-2186;
        }
        else if (wellOrientation2 == 1 && wellOrientation3 == 0){
            arrayWellPosition2 [6] = xCorner2-2186-10500; //----WB1----
            arrayWellPosition2 [7] = yCorner2-8332;
            arrayWellPosition2 [4] = xCorner2; //----WB2----
            arrayWellPosition2 [5] = yCorner2-8332;
            arrayWellPosition2 [2] = xCorner2+10500+2186; //----WB3----
            arrayWellPosition2 [3] = yCorner2-8332;
            arrayWellPosition2 [0] = xCorner2+10500+2186+10500+2186; //----WB4----
            arrayWellPosition2 [1] = yCorner2-8332;
            arrayWellPosition2 [8] = xCorner2+10500+2186+10500+2186; //----WB5----
            arrayWellPosition2 [9] = yCorner2-8332-2186-8332;
            arrayWellPosition2 [10] = xCorner2+10500+2186; //----WB6----
            arrayWellPosition2 [11] = yCorner2-8332-2186-8332;
            arrayWellPosition2 [12] = xCorner2; //----WB7----
            arrayWellPosition2 [13] = yCorner2-8332-2186-8332;
            arrayWellPosition2 [14] = xCorner2-2186-10500; //----WB8----
            arrayWellPosition2 [15] = yCorner2-8332-2186-8332;
            arrayWellPosition2 [16] = xCorner2-2186-10500-2186; //----BB2----
            arrayWellPosition2 [17] = yCorner2-8332-2186-8332-2186;
        }
        else if (wellOrientation2 == 0 && wellOrientation3 == 1){
            arrayWellPosition2 [0] = xCorner2-2186-10500; //----WB1----
            arrayWellPosition2 [1] = yCorner2-8332;
            arrayWellPosition2 [2] = xCorner2; //----WB2----
            arrayWellPosition2 [3] = yCorner2-8332;
            arrayWellPosition2 [4] = xCorner2+10500+2186; //----WB3----
            arrayWellPosition2 [5] = yCorner2-8332;
            arrayWellPosition2 [6] = xCorner2+10500+2186+10500+2186; //----WB4----
            arrayWellPosition2 [7] = yCorner2-8332;
            arrayWellPosition2 [14] = xCorner2+10500+2186+10500+2186; //----WB5----
            arrayWellPosition2 [15] = yCorner2-8332-2186-8332;
            arrayWellPosition2 [12] = xCorner2+10500+2186; //----WB6----
            arrayWellPosition2 [13] = yCorner2-8332-2186-8332;
            arrayWellPosition2 [10] = xCorner2; //----WB7----
            arrayWellPosition2 [11] = yCorner2-8332-2186-8332;
            arrayWellPosition2 [8] = xCorner2-2186-10500; //----WB8----
            arrayWellPosition2 [9] = yCorner2-8332-2186-8332;
            arrayWellPosition2 [16] = xCorner2-2186-10500-2186; //----BB2----
            arrayWellPosition2 [17] = yCorner2-8332-2186-8332-2186;
        }
        else if (wellOrientation2 == 1 && wellOrientation3 == 1){
            arrayWellPosition2 [6] = xCorner2-2186-10500; //----WB1----
            arrayWellPosition2 [7] = yCorner2-8332;
            arrayWellPosition2 [4] = xCorner2; //----WB2----
            arrayWellPosition2 [5] = yCorner2-8332;
            arrayWellPosition2 [2] = xCorner2+10500+2186; //----WB3----
            arrayWellPosition2 [3] = yCorner2-8332;
            arrayWellPosition2 [0] = xCorner2+10500+2186+10500+2186; //----WB4----
            arrayWellPosition2 [1] = yCorner2-8332;
            arrayWellPosition2 [14] = xCorner2+10500+2186+10500+2186; //----WB5----
            arrayWellPosition2 [15] = yCorner2-8332-2186-8332;
            arrayWellPosition2 [12] = xCorner2+10500+2186; //----WB6----
            arrayWellPosition2 [13] = yCorner2-8332-2186-8332;
            arrayWellPosition2 [10] = xCorner2; //----WB7----
            arrayWellPosition2 [11] = yCorner2-8332-2186-8332;
            arrayWellPosition2 [8] = xCorner2-2186-10500; //----WB8----
            arrayWellPosition2 [9] = yCorner2-8332-2186-8332;
            arrayWellPosition2 [16] = xCorner2-2186-10500-2186; //----BB2----
            arrayWellPosition2 [17] = yCorner2-8332-2186-8332-2186;
        }
        
        wellPositionCount2 = 18;
    }
    else if (chamberType2 == 2){
        if (wellOrientation2 == 0){
            arrayWellPosition2 [0] = xCorner2-2597-22170; //----WB1----
            arrayWellPosition2 [1] = yCorner2-19687;
            arrayWellPosition2 [2] = xCorner2; //----WB2----
            arrayWellPosition2 [3] = yCorner2-19687;
            arrayWellPosition2 [4] = xCorner2-2597-22170-2186; //----BB2----
            arrayWellPosition2 [5] = yCorner2-19687-2186;
        }
        else if (wellOrientation2 == 1){
            arrayWellPosition2 [2] = xCorner2-2597-22170; //----WB1----
            arrayWellPosition2 [3] = yCorner2-19687;
            arrayWellPosition2 [0] = xCorner2; //----WB2----
            arrayWellPosition2 [1] = yCorner2-19687;
            arrayWellPosition2 [4] = xCorner2-2597-22170-2186; //----BB2----
            arrayWellPosition2 [5] = yCorner2-19687-2186;
        }
        
        wellPositionCount2 = 5;
    }
    else if (chamberType2 == 3){
        if (wellOrientation2 == 0){
            arrayWellPosition2 [0] = xCorner2-2499-9938; //----WA1----
            arrayWellPosition2 [1] = yCorner2-19687;
            arrayWellPosition2 [2] = xCorner2; //----WA2----
            arrayWellPosition2 [3] = yCorner2-19687;
            arrayWellPosition2 [4] = xCorner2+9938+2499; //----WA3----
            arrayWellPosition2 [5] = yCorner2-19687;
            arrayWellPosition2 [6] = xCorner2+9938+2499+9938+2499; //----WA4----
            arrayWellPosition2 [7] = yCorner2-19687;
            arrayWellPosition2 [8] = xCorner2-2499-9938-2186; //----BA1----
            arrayWellPosition2 [9] = yCorner2-19687-2186;
        }
        else if (wellOrientation2 == 1){
            arrayWellPosition2 [6] = xCorner2-2499-9938; //----WA1----
            arrayWellPosition2 [7] = yCorner2-19687;
            arrayWellPosition2 [4] = xCorner2; //----WA2----
            arrayWellPosition2 [5] = yCorner2-19687;
            arrayWellPosition2 [2] = xCorner2+9938+2499; //----WA3----
            arrayWellPosition2 [3] = yCorner2-19687;
            arrayWellPosition2 [0] = xCorner2+9938+2499+9938+2499; //----WA4----
            arrayWellPosition2 [1] = yCorner2-19687;
            arrayWellPosition2 [8] = xCorner2-2499-9938-2186; //----BA1----
            arrayWellPosition2 [9] = yCorner2-19687-2186;
        }
        
        wellPositionCount2 = 9;
    }
    else if (chamberType2 == 4){
        if (wellOrientation2 == 0 && wellOrientation3 == 0){
            arrayWellPosition2 [0] = xCorner2-1146-10700; //----WA1----
            arrayWellPosition2 [1] = yCorner2-9489;
            arrayWellPosition2 [2] = xCorner2; //----WA2----
            arrayWellPosition2 [3] = yCorner2-9489;
            arrayWellPosition2 [4] = xCorner2+10700+2673; //----WA3----
            arrayWellPosition2 [5] = yCorner2-9489;
            arrayWellPosition2 [6] = xCorner2+10700+2673+10700+1146; //----WA4----
            arrayWellPosition2 [7] = yCorner2-9489;
            arrayWellPosition2 [8] = xCorner2+10700+2673+10700+1146; //----WA5----
            arrayWellPosition2 [9] = yCorner2-9489-1528-9489;
            arrayWellPosition2 [10] = xCorner2+10700+2673; //----WA6----
            arrayWellPosition2 [11] = yCorner2-9489-1528-9489;
            arrayWellPosition2 [12] = xCorner2; //----WA7----
            arrayWellPosition2 [13] = yCorner2-9489-1528-9489;
            arrayWellPosition2 [14] = xCorner2-1146-10700; //----WA8----
            arrayWellPosition2 [15] = yCorner2-9489-1528-9489;
            arrayWellPosition2 [16] = xCorner2-1146-10700-2186; //----BA1----
            arrayWellPosition2 [17] = yCorner2-9489-1528-9489-2186;
        }
        else if (wellOrientation2 == 1 && wellOrientation3 == 0){
            arrayWellPosition2 [6] = xCorner2-1146-10700; //----WA1----
            arrayWellPosition2 [7] = yCorner2-9489;
            arrayWellPosition2 [4] = xCorner2; //----WA2----
            arrayWellPosition2 [5] = yCorner2-9489;
            arrayWellPosition2 [2] = xCorner2+10700+2673; //----WA3----
            arrayWellPosition2 [3] = yCorner2-9489;
            arrayWellPosition2 [0] = xCorner2+10700+2673+10700+1146; //----WA4----
            arrayWellPosition2 [1] = yCorner2-9489;
            arrayWellPosition2 [8] = xCorner2+10700+2673+10700+1146; //----WA5----
            arrayWellPosition2 [9] = yCorner2-9489-1528-9489;
            arrayWellPosition2 [10] = xCorner2+10700+2673; //----WA6----
            arrayWellPosition2 [11] = yCorner2-9489-1528-9489;
            arrayWellPosition2 [12] = xCorner2; //----WA7----
            arrayWellPosition2 [13] = yCorner2-9489-1528-9489;
            arrayWellPosition2 [14] = xCorner2-1146-10700; //----WA8----
            arrayWellPosition2 [15] = yCorner2-9489-1528-9489;
            arrayWellPosition2 [16] = xCorner2-1146-10700-2186; //----BA1----
            arrayWellPosition2 [17] = yCorner2-9489-1528-9489-2186;
        }
        
        if (wellOrientation2 == 0 && wellOrientation3 == 1){
            arrayWellPosition2 [0] = xCorner2-1146-10700; //----WA1----
            arrayWellPosition2 [1] = yCorner2-9489;
            arrayWellPosition2 [2] = xCorner2; //----WA2----
            arrayWellPosition2 [3] = yCorner2-9489;
            arrayWellPosition2 [4] = xCorner2+10700+2673; //----WA3----
            arrayWellPosition2 [5] = yCorner2-9489;
            arrayWellPosition2 [6] = xCorner2+10700+2673+10700+1146; //----WA4----
            arrayWellPosition2 [7] = yCorner2-9489;
            arrayWellPosition2 [14] = xCorner2+10700+2673+10700+1146; //----WA5----
            arrayWellPosition2 [15] = yCorner2-9489-1528-9489;
            arrayWellPosition2 [12] = xCorner2+10700+2673; //----WA6----
            arrayWellPosition2 [13] = yCorner2-9489-1528-9489;
            arrayWellPosition2 [10] = xCorner2; //----WA7----
            arrayWellPosition2 [11] = yCorner2-9489-1528-9489;
            arrayWellPosition2 [8] = xCorner2-1146-10700; //----WA8----
            arrayWellPosition2 [9] = yCorner2-9489-1528-9489;
            arrayWellPosition2 [16] = xCorner2-1146-10700-2186; //----BA1----
            arrayWellPosition2 [17] = yCorner2-9489-1528-9489-2186;
        }
        
        if (wellOrientation2 == 1 && wellOrientation3 == 1){
            arrayWellPosition2 [6] = xCorner2-1146-10700; //----WA1----
            arrayWellPosition2 [7] = yCorner2-9489;
            arrayWellPosition2 [4] = xCorner2; //----WA2----
            arrayWellPosition2 [5] = yCorner2-9489;
            arrayWellPosition2 [2] = xCorner2+10700+2673; //----WA3----
            arrayWellPosition2 [3] = yCorner2-9489;
            arrayWellPosition2 [0] = xCorner2+10700+2673+10700+1146; //----WA4----
            arrayWellPosition2 [1] = yCorner2-9489;
            arrayWellPosition2 [14] = xCorner2+10700+2673+10700+1146; //----WA5----
            arrayWellPosition2 [15] = yCorner2-9489-1528-9489;
            arrayWellPosition2 [12] = xCorner2+10700+2673; //----WA6----
            arrayWellPosition2 [13] = yCorner2-9489-1528-9489;
            arrayWellPosition2 [10] = xCorner2; //----WA7----
            arrayWellPosition2 [11] = yCorner2-9489-1528-9489;
            arrayWellPosition2 [8] = xCorner2-1146-10700; //----WA8----
            arrayWellPosition2 [9] = yCorner2-9489-1528-9489;
            arrayWellPosition2 [16] = xCorner2-1146-10700-2186; //----BA1----
            arrayWellPosition2 [17] = yCorner2-9489-1528-9489-2186;
        }
        
        wellPositionCount2 = 18;
    }
    else if (chamberType2 == 5){
        if (wellOrientation2 == 0){
            arrayWellPosition2 [0] = xCorner2-5152-3868; //----WA1----
            arrayWellPosition2 [1] = yCorner2-14238;
            arrayWellPosition2 [2] = xCorner2; //----WA2----
            arrayWellPosition2 [3] = yCorner2-14238;
            arrayWellPosition2 [4] = xCorner2+3868+5152; //----WA3----
            arrayWellPosition2 [5] = yCorner2-14238;
            arrayWellPosition2 [6] = xCorner2+3868+5152+3868+5152; //----WA4----
            arrayWellPosition2 [7] = yCorner2-14238;
            arrayWellPosition2 [8] = xCorner2+3868+5152+3868+5152+3868+5152; //----WA5----
            arrayWellPosition2 [9] = yCorner2-14238;
            arrayWellPosition2 [10] = xCorner2+3868+5152+3868+5152+3868+5152+3868+5152; //----WA6----
            arrayWellPosition2 [11] = yCorner2-14238;
            arrayWellPosition2 [12] = xCorner2-5152-3868-2186; //----BA1----
            arrayWellPosition2 [13] = yCorner2-14238-2186-2186;
        }
        else if (wellOrientation2 == 1){
            arrayWellPosition2 [10] = xCorner2-5152-3868; //----WA1----
            arrayWellPosition2 [11] = yCorner2-14238;
            arrayWellPosition2 [8] = xCorner2; //----WA2----
            arrayWellPosition2 [9] = yCorner2-14238;
            arrayWellPosition2 [6] = xCorner2+3868+5152; //----WA3----
            arrayWellPosition2 [7] = yCorner2-14238;
            arrayWellPosition2 [4] = xCorner2+3868+5152+3868+5152; //----WA4----
            arrayWellPosition2 [5] = yCorner2-14238;
            arrayWellPosition2 [2] = xCorner2+3868+5152+3868+5152+3868+5152; //----WA5----
            arrayWellPosition2 [3] = yCorner2-14238;
            arrayWellPosition2 [0] = xCorner2+3868+5152+3868+5152+3868+5152+3868+5152; //----WA6----
            arrayWellPosition2 [1] = yCorner2-14238;
            arrayWellPosition2 [12] = xCorner2-5152-3868-2186; //----BA1----
            arrayWellPosition2 [13] = yCorner2-14238-2186-2186;
        }
        
        wellPositionCount2 = 14;
    }
}

-(void)saveCurrentData{
    ofstream oin;
    
    oin.open(savedDataPath.c_str(), ios::out);
    
    oin<<"WellPosition1"<<endl;
    
    if (wellPositionCount1 != 0){
        for (int counter1 = 0; counter1 < wellPositionCount1; counter1++) oin<<arrayWellPosition1 [counter1]<<endl;
    }
    
    oin<<"WellPosition2"<<endl;
    
    if (wellPositionCount2 != 0){
        for (int counter1 = 0; counter1 < wellPositionCount2; counter1++) oin<<arrayWellPosition2 [counter1]<<endl;
    }
    
    oin<<"SelectedFOV1"<<endl;
    
    if (selectedMapCount1 != 0){
        for (int counter1 = 0; counter1 < selectedMapCount1; counter1++) oin<<arraySelectedMap1 [counter1]<<endl;
    }
    
    oin<<"SelectedFOV2"<<endl;
    
    if (selectedMapCount2 != 0){
        for (int counter1 = 0; counter1 < selectedMapCount2; counter1++) oin<<arraySelectedMap2 [counter1]<<endl;
    }
    
    oin<<"END"<<endl;
    
    oin.close();
    
    int totalFOVCount = 0;
    int wellNoCount = 0;
    
    //for (int counterA = 0; counterA < selectedMapCount1/6; counterA++){
    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arraySelectedMap1 [counterA*6+counterB];
    //	cout<<" arraySelectedMap1 "<<counterA+1<<endl;
    //}
    
    int xDimensionMax = 0;
    int yDimensionMax = 0;
    
    double zValueCount = 0;
    
    if (selectedMapCount1/6 != 0){
        for (int counter1 = 0; counter1 < chamberWellLimit1; counter1++){
            arrayTableXYDimension [counter1*3] = 0;
            arrayTableXYDimension [counter1*3+1] = 0;
            arrayTableXYDimension [counter1*3+2] = 0;
            arrayTableZ [counter1] = 0;
        }
        
        zValueCount = 0;
        
        for (int counter1 = 0; counter1 < selectedMapCount1/6; counter1++){
            if (arraySelectedMap1 [counter1*6] != wellNoCount || counter1 == selectedMapCount1/6-1){
                if (wellNoCount != 0){
                    arrayTableXYDimension [(wellNoCount-1)*3] = xDimensionMax;
                    arrayTableXYDimension [(wellNoCount-1)*3+1] = yDimensionMax;
                    arrayTableXYDimension [(wellNoCount-1)*3+2] = xDimensionMax*yDimensionMax;
                    arrayTableZ [(wellNoCount-1)] = zValueCount;
                    
                    totalFOVCount = totalFOVCount+xDimensionMax*yDimensionMax;
                }
                
                wellNoCount = (int)arraySelectedMap1 [counter1*6];
                
                xDimensionMax = 0;
                yDimensionMax = 0;
                zValueCount = arraySelectedMap1 [counter1*6+5];
                
                if (xDimensionMax < arraySelectedMap1 [counter1*6+1]) xDimensionMax = (int)arraySelectedMap1 [counter1*6+1];
                if (yDimensionMax < arraySelectedMap1 [counter1*6+2]) yDimensionMax = (int)arraySelectedMap1 [counter1*6+2];
            }
            else{
                
                if (xDimensionMax < arraySelectedMap1 [counter1*6+1]) xDimensionMax = (int)arraySelectedMap1 [counter1*6+1];
                if (yDimensionMax < arraySelectedMap1 [counter1*6+2]) yDimensionMax = (int)arraySelectedMap1 [counter1*6+2];
            }
        }
    }
    else{
        
        for (int counter1 = 0; counter1 < chamberWellLimit1; counter1++){
            arrayTableXYDimension [counter1*3] = 0;
            arrayTableXYDimension [counter1*3+1] = 0;
            arrayTableXYDimension [counter1*3+2] = 0;
            arrayTableZ [counter1] = 0;
            
            arrayTableXYDimensionHold [counter1*3] = 0;
            arrayTableXYDimensionHold [counter1*3+1] = 0;
            arrayTableXYDimensionHold [counter1*3+2] = 0;
            arrayTableZHold [counter1] = 0;
        }
    }
    
    wellNoCount = 0;
    xDimensionMax = 0;
    yDimensionMax = 0;
    
    if (selectedMapCount2/6 != 0){
        for (int counter1 = chamberWellLimit1; counter1 < chamberWellLimit1+chamberWellLimit2; counter1++){
            arrayTableXYDimension [counter1*3] = 0;
            arrayTableXYDimension [counter1*3+1] = 0;
            arrayTableXYDimension [counter1*3+2] = 0;
            arrayTableZ [counter1] = 0;
        }
        
        zValueCount = 0;
        
        for (int counter1 = 0; counter1 < selectedMapCount2/6; counter1++){
            if (arraySelectedMap2 [counter1*6] != wellNoCount || counter1 == selectedMapCount2/6-1){
                if (wellNoCount != 0){
                    arrayTableXYDimension [(wellNoCount-1)*3] = xDimensionMax;
                    arrayTableXYDimension [(wellNoCount-1)*3+1] = yDimensionMax;
                    arrayTableXYDimension [(wellNoCount-1)*3+2] = xDimensionMax*yDimensionMax;
                    arrayTableZ [(wellNoCount-1)] = zValueCount;
                    
                    totalFOVCount = totalFOVCount+xDimensionMax*yDimensionMax;
                }
                
                wellNoCount = (int)arraySelectedMap2 [counter1*6];
                
                xDimensionMax = 0;
                yDimensionMax = 0;
                zValueCount = arraySelectedMap2 [counter1*6+5];
                
                if (xDimensionMax < arraySelectedMap2 [counter1*6+1]) xDimensionMax = (int)arraySelectedMap2 [counter1*6+1];
                if (yDimensionMax < arraySelectedMap2 [counter1*6+2]) yDimensionMax = (int)arraySelectedMap2 [counter1*6+2];
                
            }
            else{
                
                if (xDimensionMax < arraySelectedMap2 [counter1*6+1]) xDimensionMax = (int)arraySelectedMap2 [counter1*6+1];
                if (yDimensionMax < arraySelectedMap2 [counter1*6+2]) yDimensionMax = (int)arraySelectedMap2 [counter1*6+2];
            }
        }
    }
    else{
        
        for (int counter1 = chamberWellLimit1; counter1 < chamberWellLimit1+chamberWellLimit2; counter1++){
            arrayTableXYDimension [counter1*3] = 0;
            arrayTableXYDimension [counter1*3+1] = 0;
            arrayTableXYDimension [counter1*3+2] = 0;
            arrayTableZ [counter1] = 0;
            
            arrayTableXYDimensionHold [counter1*3] = 0;
            arrayTableXYDimensionHold [counter1*3+1] = 0;
            arrayTableXYDimensionHold [counter1*3+2] = 0;
            arrayTableZHold [counter1] = 0;
        }
    }
    
    [totalFOV setIntegerValue:totalFOVCount];
    
    oin.open(xyDimensionMapPath.c_str(), ios::out);
    
    for (int counter1 = 0; counter1 < (chamberWellLimit1+chamberWellLimit2)*3; counter1++) oin<<arrayTableXYDimension [counter1]<<endl;
    
    oin.close();
    
    oin.open(zMapPath.c_str(), ios::out);
    
    for (int counter1 = 0; counter1 < chamberWellLimit1+chamberWellLimit2; counter1++) oin<<arrayTableZ [counter1]<<endl;
    
    oin.close();
    
    tableViewCall = 1;
    
    //for (int counterA = 0; counterA < selectedMapCount1/6; counterA++){
    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arraySelectedMap1 [counterA*6+counterB];
    //    cout<<" arraySelectedMap1 "<<counterA+1<<" "<<counter1<<endl;
    //}
}

-(void)saveLastSavedData{
    ofstream oin;
    
    oin.open(savedDataLastSavePath.c_str(), ios::out);
    
    oin<<"WellPosition1"<<endl;
    
    if (wellPositionCount1 != 0){
        for (int counter1 = 0; counter1 < wellPositionCount1; counter1++) oin<<arrayWellPosition1 [counter1]<<endl;
    }
    
    oin<<"WellPosition2"<<endl;
    
    if (wellPositionCount2 != 0){
        for (int counter1 = 0; counter1 < wellPositionCount2; counter1++) oin<<arrayWellPosition2 [counter1]<<endl;
    }
    
    oin<<"SelectedFOV1"<<endl;
    
    if (selectedMapCount1 != 0){
        for (int counter1 = 0; counter1 < selectedMapCount1; counter1++) oin<<arraySelectedMap1 [counter1]<<endl;
    }
    
    oin<<"SelectedFOV2"<<endl;
    
    if (selectedMapCount2 != 0){
        for (int counter1 = 0; counter1 < selectedMapCount2; counter1++) oin<<arraySelectedMap2 [counter1]<<endl;
    }
    
    oin<<"END"<<endl;
    
    oin.close();
    
    int totalFOVCount = 0;
    int wellNoCount = 0;
    
    //for (int counterA = 0; counterA < selectedMapCount2/6; counterA++){
    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arraySelectedMap2 [counterA*6+counterB];
    //	cout<<" arraySelectedMap2 "<<counterA+1<<endl;
    //}
    
    int xDimensionMax = 0;
    int yDimensionMax = 0;
    
    double zValueCount = 0;
    
    if (selectedMapCount1/6 != 0){
        for (int counter1 = 0; counter1 < chamberWellLimit1; counter1++){
            arrayTableXYDimension [counter1*3] = 0;
            arrayTableXYDimension [counter1*3+1] = 0;
            arrayTableXYDimension [counter1*3+2] = 0;
            arrayTableZ [counter1] = 0;
            
            arrayTableXYDimensionHold [counter1*3] = 0;
            arrayTableXYDimensionHold [counter1*3+1] = 0;
            arrayTableXYDimensionHold [counter1*3+2] = 0;
            arrayTableZHold [counter1] = 0;
        }
        
        tableXYDimensionHoldCount = (chamberWellLimit1+chamberWellLimit2)*3;
        tableZHoldCount = chamberWellLimit1+chamberWellLimit2;
        
        zValueCount = 0;
        
        for (int counter1 = 0; counter1 < selectedMapCount1/6; counter1++){
            if (arraySelectedMap1 [counter1*6] != wellNoCount || counter1 == selectedMapCount1/6-1){
                if (wellNoCount != 0){
                    arrayTableXYDimension [(wellNoCount-1)*3] = xDimensionMax;
                    arrayTableXYDimension [(wellNoCount-1)*3+1] = yDimensionMax;
                    arrayTableXYDimension [(wellNoCount-1)*3+2] = xDimensionMax*yDimensionMax;
                    arrayTableZ [(wellNoCount-1)] = zValueCount;
                    
                    arrayTableXYDimensionHold [(wellNoCount-1)*3] = xDimensionMax;
                    arrayTableXYDimensionHold [(wellNoCount-1)*3+1] = yDimensionMax;
                    arrayTableXYDimensionHold [(wellNoCount-1)*3+2] = xDimensionMax*yDimensionMax;
                    arrayTableZHold [(wellNoCount-1)] = zValueCount;
                    
                    totalFOVCount = totalFOVCount+xDimensionMax*yDimensionMax;
                }
                
                wellNoCount = (int)arraySelectedMap1 [counter1*6];
                
                xDimensionMax = 0;
                yDimensionMax = 0;
                zValueCount = arraySelectedMap1 [counter1*6+5];
                
                if (xDimensionMax < arraySelectedMap1 [counter1*6+1]) xDimensionMax = (int)arraySelectedMap1 [counter1*6+1];
                if (yDimensionMax < arraySelectedMap1 [counter1*6+2]) yDimensionMax = (int)arraySelectedMap1 [counter1*6+2];
            }
            else{
                
                if (xDimensionMax < arraySelectedMap1 [counter1*6+1]) xDimensionMax = (int)arraySelectedMap1 [counter1*6+1];
                if (yDimensionMax < arraySelectedMap1 [counter1*6+2]) yDimensionMax = (int)arraySelectedMap1 [counter1*6+2];
            }
        }
    }
    else{
        
        tableXYDimensionHoldCount = (chamberWellLimit1+chamberWellLimit2)*3;
        tableZHoldCount = chamberWellLimit1+chamberWellLimit2;
        
        for (int counter1 = 0; counter1 < chamberWellLimit1; counter1++){
            arrayTableXYDimension [counter1*3] = 0;
            arrayTableXYDimension [counter1*3+1] = 0;
            arrayTableXYDimension [counter1*3+2] = 0;
            arrayTableZ [counter1] = 0;
            
            arrayTableXYDimensionHold [counter1*3] = 0;
            arrayTableXYDimensionHold [counter1*3+1] = 0;
            arrayTableXYDimensionHold [counter1*3+2] = 0;
            arrayTableZHold [counter1] = 0;
        }
    }
    
    //for (int counterA = 0; counterA < tableXYDimensionCount/3; counterA++){
    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayTableXYDimension [counterA*3+counterB];
    //    cout<<" arrayTableXYDimension "<<counterA+1<<endl;
    //}
    
    wellNoCount = 0;
    xDimensionMax = 0;
    yDimensionMax = 0;
    
    if (selectedMapCount2/6 != 0){
        for (int counter1 = chamberWellLimit1; counter1 < chamberWellLimit1+chamberWellLimit2; counter1++){
            arrayTableXYDimension [counter1*3] = 0;
            arrayTableXYDimension [counter1*3+1] = 0;
            arrayTableXYDimension [counter1*3+2] = 0;
            arrayTableZ [counter1] = 0;
            
            arrayTableXYDimensionHold [counter1*3] = 0;
            arrayTableXYDimensionHold [counter1*3+1] = 0;
            arrayTableXYDimensionHold [counter1*3+2] = 0;
            arrayTableZHold [counter1] = 0;
        }
        
        tableXYDimensionHoldCount = (chamberWellLimit1+chamberWellLimit2)*3;
        tableZHoldCount = chamberWellLimit1+chamberWellLimit2;
        
        zValueCount = 0;
        
        for (int counter1 = 0; counter1 < selectedMapCount2/6; counter1++){
            if (arraySelectedMap2 [counter1*6] != wellNoCount || counter1 == selectedMapCount2/6-1){
                if (wellNoCount != 0){
                    arrayTableXYDimension [(wellNoCount-1)*3] = xDimensionMax;
                    arrayTableXYDimension [(wellNoCount-1)*3+1] = yDimensionMax;
                    arrayTableXYDimension [(wellNoCount-1)*3+2] = xDimensionMax*yDimensionMax;
                    arrayTableZ [(wellNoCount-1)] = zValueCount;
                    
                    arrayTableXYDimensionHold [(wellNoCount-1)*3] = xDimensionMax;
                    arrayTableXYDimensionHold [(wellNoCount-1)*3+1] = yDimensionMax;
                    arrayTableXYDimensionHold [(wellNoCount-1)*3+2] = xDimensionMax*yDimensionMax;
                    arrayTableZHold [(wellNoCount-1)] = zValueCount;
                    
                    totalFOVCount = totalFOVCount+xDimensionMax*yDimensionMax;
                }
                
                wellNoCount = (int)arraySelectedMap2 [counter1*6];
                
                xDimensionMax = 0;
                yDimensionMax = 0;
                zValueCount = arraySelectedMap2 [counter1*6+5];
                
                if (xDimensionMax < arraySelectedMap2 [counter1*6+1]) xDimensionMax = (int)arraySelectedMap2 [counter1*6+1];
                if (yDimensionMax < arraySelectedMap2 [counter1*6+2]) yDimensionMax = (int)arraySelectedMap2 [counter1*6+2];
            }
            else{
                
                if (xDimensionMax < arraySelectedMap2 [counter1*6+1]) xDimensionMax = (int)arraySelectedMap2 [counter1*6+1];
                if (yDimensionMax < arraySelectedMap2 [counter1*6+2]) yDimensionMax = (int)arraySelectedMap2 [counter1*6+2];
            }
        }
    }
    else{
        
        tableXYDimensionHoldCount = (chamberWellLimit1+chamberWellLimit2)*3;
        tableZHoldCount = chamberWellLimit1+chamberWellLimit2;
        
        for (int counter1 = chamberWellLimit1; counter1 < chamberWellLimit1+chamberWellLimit2; counter1++){
            arrayTableXYDimension [counter1*3] = 0;
            arrayTableXYDimension [counter1*3+1] = 0;
            arrayTableXYDimension [counter1*3+2] = 0;
            arrayTableZ [counter1] = 0;
            
            arrayTableXYDimensionHold [counter1*3] = 0;
            arrayTableXYDimensionHold [counter1*3+1] = 0;
            arrayTableXYDimensionHold [counter1*3+2] = 0;
            arrayTableZHold [counter1] = 0;
        }
    }
    
    [totalFOV setIntegerValue:totalFOVCount];
    
    //for (int counterA = 0; counterA < 16; counterA++){
    //    cout<<counterA<<" "<<arrayTableXYDimensionHold [counterA*3]<<" "<<arrayTableXYDimension [counterA*3]<<" arrayTableXYDimensionHold"<<endl;
    //}
    
    oin.open(xyDimensionMapSavePath.c_str(), ios::out);
    
    for (int counter1 = 0; counter1 < (chamberWellLimit1+chamberWellLimit2)*3; counter1++) oin<<arrayTableXYDimension [counter1]<<endl;
    
    oin.close();
    
    oin.open(zMapSavePath.c_str(), ios::out);
    
    for (int counter1 = 0; counter1 < chamberWellLimit1+chamberWellLimit2; counter1++) oin<<arrayTableZ [counter1]<<endl;
    
    oin.close();
    
    //for (int counterA = 0; counterA < 16; counterA++){
    //    cout<<counterA<<" "<<arrayTableXYDimensionHold [counterA*3]<<" "<<arrayTableXYDimension [counterA*3]<<" arrayTableXYDimensionHold"<<endl;
    //}
}

-(void)saveZPositionData{
    string zMapSavePath2 = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/MAP_ZMapDataLastSave2";
    
    ofstream oin;
    
    oin.open(zMapSavePath2.c_str(), ios::out);
    
    for (int counter1 = 0; counter1 < chamberWellLimit1+chamberWellLimit2; counter1++) oin<<arrayTableZ [counter1]<<endl;
    
    oin.close();
}

-(void)saveCornerData{
    ofstream oin;
    
    oin.open(xyMapDataPath.c_str(), ios::out);
    
    oin<<xCorner1<<endl;
    oin<<yCorner1<<endl;
    oin<<xCorner2<<endl;
    oin<<yCorner2<<endl;
    oin<<objectiveSelect<<endl;
    
    oin.close();
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = chamberWellLimit1+chamberWellLimit2;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    
    if (tableXYDimensionCount != 0){
        int xFOVCount = arrayTableXYDimension [rowIndex*3];
        int yFOVCount = arrayTableXYDimension [rowIndex*3+1];
        int totalFOVInt = arrayTableXYDimension [rowIndex*3+2];
        
        double zValueTable = arrayTableZ [rowIndex];
        string displayData2 = to_string(xFOVCount);
        
        if (displayData2 == "0") displayData2 = "nil";
        
        string displayData3 = to_string(yFOVCount);
        
        if (displayData3 == "0") displayData3 = "nil";
        
        int zValueInt = (int)(zValueTable*100);
        zValueTable = zValueInt/100;
        
        stringstream extension1;
        extension1 << zValueTable;
        string displayData4 = extension1.str();
        
        string displayData5 = to_string(totalFOVInt);
        string displayData1;
        
        if (rowIndex == 0) displayData1 = "Well 1";
        else if (rowIndex == 1) displayData1 = "Well 2";
        else if (rowIndex == 2) displayData1 = "Well 3";
        else if (rowIndex == 3) displayData1 = "Well 4";
        else if (rowIndex == 4) displayData1 = "Well 5";
        else if (rowIndex == 5) displayData1 = "Well 6";
        else if (rowIndex == 6) displayData1 = "Well 7";
        else if (rowIndex == 7) displayData1 = "Well 8";
        else if (rowIndex == 8) displayData1 = "Well 9";
        else if (rowIndex == 9) displayData1 = "Well 10";
        else if (rowIndex == 10) displayData1 = "Well 11";
        else if (rowIndex == 11) displayData1 = "Well 12";
        else if (rowIndex == 12) displayData1 = "Well 13";
        else if (rowIndex == 13) displayData1 = "Well 14";
        else if (rowIndex == 14) displayData1 = "Well 15";
        else if (rowIndex == 15) displayData1 = "Well 16";
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"] && rowIndex <= chamberWellLimit1-1){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && rowIndex <= chamberWellLimit1-1){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && rowIndex <= chamberWellLimit1-1){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData3.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData3.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"] && rowIndex <= chamberWellLimit1-1){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData4.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"]){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData4.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL5"] && rowIndex <= chamberWellLimit1-1){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData5.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL5"]){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData5.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else{
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL5"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    
    return attrStr;
}

-(IBAction)toolBarRefresh:(id)sender{
    NSAlert *alert = [[NSAlert alloc] init];
    
    [alert addButtonWithTitle:@"OK"];
    [alert addButtonWithTitle:@"Cancel"];
    [alert setMessageText:@"Clear All Data"];
    [alert setAlertStyle:NSAlertStyleWarning];
    
    if ([alert runModal] == NSAlertFirstButtonReturn) [self refreshPerform];
}

-(void)refreshPerform{
    string getString;
    
    int totalFOVNoHold = 0;
    
    ifstream fin;
    
    fin.open(analysisDataPath.c_str(), ios::in);
    
    if (fin.is_open()){
        getline(fin, getString), bodyName = getString;
        getline(fin, getString), computerName = getString;
        getline(fin, getString), totalFOVNoHold = atoi(getString.c_str());
        fin.close();
    }
    
    if (bodyName != "nil") [analysisName setStringValue:@(bodyName.c_str())];
    else [analysisName setStringValue:@"nil"];
    
    if (totalFOVNoHold != 0) [totalFOV setIntegerValue:totalFOVNoHold];
    else [totalFOV setIntegerValue:0];
    
    [xNumberPointTake setIntegerValue:5]; //----XY dimension, default 5----
    [yNumberPointTake setIntegerValue:5];
    xFOVTaken = 5;
    yFOVTaken = 5;
    
    [stepperX setIntValue:5];
    [stepperY setIntValue:5];
    
    xCorner1 = 0;
    yCorner1 = 0;
    xCorner2 = 0;
    yCorner2 = 0;
    
    [cornerX1 setStringValue:[NSString stringWithFormat:@"%.2f", xCorner1]];
    [cornerY1 setStringValue:[NSString stringWithFormat:@"%.2f", yCorner1]];
    [cornerX2 setStringValue:[NSString stringWithFormat:@"%.2f", xCorner2]];
    [cornerY2 setStringValue:[NSString stringWithFormat:@"%.2f", yCorner2]];
    
    if (objectiveSelect == 1) [magnification setStringValue:@"x10"];
    else if (objectiveSelect == 2) [magnification setStringValue:@"x20"];
    else if (objectiveSelect == 3) [magnification setStringValue:@"x40"];
    
    selectedMapCount1 = 0;
    selectedMapCount2 = 0;
    
    wellPositionCount1 = 0;
    wellPositionCount2 = 0;
    
    tableZCount = 0;
    tableXYDimensionCount = (chamberWellLimit1+chamberWellLimit2)*3;
    
    for (int counter1 = 0; counter1 < 16; counter1++){
        arrayTableXYDimension [counter1*3] = 0;
        arrayTableXYDimension [counter1*3+1] = 0;
        arrayTableXYDimension [counter1*3+2] = 0;
        
        arrayTableXYDimensionHold [counter1*3] = 0;
        arrayTableXYDimensionHold [counter1*3+1] = 0;
        arrayTableXYDimensionHold [counter1*3+2] = 0;
    }
    
    tableZCount = chamberWellLimit1+chamberWellLimit2;
    
    for (int counter1 = 0; counter1 < 16; counter1++){
        arrayTableZ [counter1] = 0;
        arrayTableZHold [counter1] = 0;
    }
    
    readingPositionMDACount = 0;
    labelPositionCount1 = 0;
    labelPositionCount2 = 0;
    
    [zAdjustWell setIntegerValue: 1];
    [stepperWell setIntValue: 1];
    [zAdjustValue setIntegerValue: 0];
    [stepperZ setIntValue: 0];
    
    zValueAdjust = 0;
    zValueAdjustWell = 1;
    drawingPermit1 = 0;
    drawingPermit2 = 0;
    mapReadFlag1 = 1;
    mapReadFlag2 = 1;
    
    readingPositionMDACount = 0;
    selectedMapCount1 = 0;
    selectedMapCount2 = 0;
    drawingPermit1 = 0;
    drawingPermit2 = 0;
    
    xClickCurrent = 0;
    yClickCurrent = 0;
    xCorner1 = 0;
    yCorner1 = 0;
    xCorner2 = 0;
    yCorner2 = 0;
    
    wellDataSaveRequest = 0;
    stgMemorizedSizeHold = 0;
    xClickCurrentHold = 0;
    yClickCurrentHold = 0;
    displayCheck1 = 0;
    displayCheck2 = 0;
    snapFirstSecondTime = 1;
    snapFirstSecondTime2 = 1;
    snapPage = 0;
    snapPage2 = 0;
    
    subProcesses = [[SubProcesses alloc] init];
    [subProcesses mapDataSave];
    
    remove(xyMapDataPath.c_str());
    remove(xyDimensionMapPath.c_str());
    remove(zMapPath.c_str());
    remove(savedDataPath.c_str());
    remove(savedDataLastSavePath.c_str());
    remove(xyDimensionMapSavePath.c_str());
    remove(zMapSavePath.c_str());
    remove(snapDataPath1.c_str());
    remove(snapDataPath2.c_str());
    
    string zMapSavePath2 = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/MAP_ZMapDataLastSave2";
    remove(zMapSavePath2.c_str());
    
    for (int counter1 = 0; counter1 < 20; counter1++) arraySnapData [counter1] = 0;
    for (int counter1 = 0; counter1 < 20; counter1++) arraySnapData2 [counter1] = 0;
    
    snapMainDataCount = 0;
    for (int counter1 = 0; counter1 < 1700; counter1++) arraySnapMainData [counter1] = 0;
    
    snapMainDataCount2 = 0;
    for (int counter1 = 0; counter1 < 1700; counter1++) arraySnapMainData2 [counter1] = 0;
    
    string entry;
    string removeDataPath;
    
    fileDeleteCount = 0;
    
    DIR *dir;
    struct dirent *dent;
    
    dir = opendir(cellTrackingSystemDataPath.c_str());
    
    if (dir != NULL){
        while ((dent = readdir(dir))){
            entry = dent -> d_name;
            
            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                if ((int)entry.find("Snap") != -1){
                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                    arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                }
            }
        }
        
        closedir(dir);
        
        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
            removeDataPath = cellTrackingSystemDataPath+"/"+arrayFileDelete [counter1];
            remove(removeDataPath.c_str());
        }
    }
    
    tableViewCall = 1;
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToXYMap object:self];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToXYMap2 object:self];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)toolBarSave:(id)sender{
    if (bodyName.substr(bodyName.length()-2) != "IF"){
        int saveStatus = 0;
        
        wellDataWrite = [[WellDataWrite alloc] init];
        saveStatus = [wellDataWrite dataSave];
        
        if (saveStatus == 1){
            [self saveLastSavedData];
            saveDoneFlag = 1;
            zPositionSaveCount = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Save MDA Using Memorize"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)zValueSet:(id)sender{
    if (zValueAdjustWell > 0 && zValueAdjustWell <= 16){
        int selectedFOVCount1 = selectedMapCount1/6;
        int selectedFOVCount2 = selectedMapCount2/6;
        
        //for (int counterA = 0; counterA < selectedMapCount1/6; counterA++){
        //   for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arraySelectedMap1 [counterA*6+counterB];
        //    cout<<" arraySelectedMap1 "<<counterA+1<<endl;
        // }
        
        if (zValueAdjustWell > 0 && zValueAdjustWell <= chamberWellLimit1){
            if (selectedMapCount1 != 0){
                int zLimitSet = 100000;
                
                for (int counter1 = 0; counter1 < selectedFOVCount1; counter1++){
                    if (arraySelectedMap1 [counter1*6] == zValueAdjustWell){
                        zLimitSet = (int)arraySelectedMap1 [counter1*6+5];
                        break;
                    }
                }
                
                if (zLimitSet != 100000){
                    if (zLimitSet < zValueAdjust+500 && zLimitSet > zValueAdjust-500){
                        double *arrayMapTemp = new double [selectedMapCount1+50];
                        int mapTempCount = 0;
                        
                        for (int counter1 = 0; counter1 < selectedFOVCount1; counter1++){
                            if (arraySelectedMap1 [counter1*6] == zValueAdjustWell){
                                arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+1], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+2], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+3], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+4], mapTempCount++;
                                arrayMapTemp [mapTempCount] = zValueAdjust, mapTempCount++;
                            }
                            else{
                                
                                arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+1], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+2], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+3], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+4], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+5], mapTempCount++;
                            }
                        }
                        
                        selectedMapCount1 = 0;
                        
                        for (int counter1 = 0; counter1 < mapTempCount; counter1++) arraySelectedMap1 [selectedMapCount1] = arrayMapTemp [counter1], selectedMapCount1++;
                        
                        delete [] arrayMapTemp;
                        
                        wellDataSaveRequest = 1;
                        
                        //for (int counterA = 0; counterA < selectedMapCount1/6; counterA++){
                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arraySelectedMap1 [counterA*6+counterB];
                        //    cout<<" arraySelectedMap1 "<<counterA+1<<endl;
                        //}
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Exceeded ±500"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Exceed Z Limit"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        if (zValueAdjustWell > chamberWellLimit1 && zValueAdjustWell <= chamberWellLimit2+chamberWellLimit1){
            if (selectedMapCount2 != 0){
                int zLimitSet = 100000;
                
                for (int counter1 = 0; counter1 < selectedFOVCount2; counter1++){
                    if (arraySelectedMap2 [counter1*6] == zValueAdjustWell){
                        zLimitSet = (int)arraySelectedMap2 [counter1*6+5];
                        break;
                    }
                }
                
                if (zLimitSet != 100000){
                    if (zLimitSet < zValueAdjust+500 && zLimitSet > zValueAdjust-500){
                        double *arrayMapTemp = new double [selectedMapCount2+50];
                        int mapTempCount = 0;
                        
                        for (int counter1 = 0; counter1 < selectedFOVCount2; counter1++){
                            if (arraySelectedMap2 [counter1*6] == zValueAdjustWell){
                                arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter1*6], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter1*6+1], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter1*6+2], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter1*6+3], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter1*6+4], mapTempCount++;
                                arrayMapTemp [mapTempCount] = zValueAdjust, mapTempCount++;
                            }
                            else{
                                
                                arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter1*6], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter1*6+1], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter1*6+2], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter1*6+3], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter1*6+4], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter1*6+5], mapTempCount++;
                            }
                        }
                        
                        selectedMapCount2 = 0;
                        
                        for (int counter1 = 0; counter1 < mapTempCount; counter1++) arraySelectedMap2 [selectedMapCount2] = arrayMapTemp [counter1], selectedMapCount2++;
                        
                        delete [] arrayMapTemp;
                        
                        wellDataSaveRequest = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Exceeded ±500"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Exceed Z Limit"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
}

-(IBAction)toolBarObjective:(id)sender{
    if (objectiveSelect == 1){
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Previous Settings Will Be Cleared"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            objectiveSelect = 2;
            [self refreshPerform];
            [magnification setStringValue:@"x20"];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else if (objectiveSelect == 2){
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Previous Settings Will Be Cleared"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            objectiveSelect = 3;
            [self refreshPerform];
            [magnification setStringValue:@"x40"];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else if (objectiveSelect == 3){
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Previous Settings Will Be Cleared"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            objectiveSelect = 1;
            [self refreshPerform];
            [magnification setStringValue:@"x10"];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
}

-(IBAction)lastSavedPointLoad:(id)sender{
    ifstream fin;
    
    fin.open(savedDataLastSavePath.c_str(), ios::in);
    
    if (fin.is_open()){
        string dataString;
        
        wellPositionCount1 = 0;
        wellPositionCount2 = 0;
        selectedMapCount1 = 0;
        selectedMapCount2 = 0;
        int readingFlag = 0;
        
        int terminationFlag = 0;
        
        do{
            
            terminationFlag = 1;
            
            getline(fin, dataString);
            
            if (dataString == "WellPosition1") readingFlag = 1;
            else if (readingFlag == 1 && dataString != "WellPosition2") arrayWellPosition1 [wellPositionCount1] = atof(dataString.c_str()), wellPositionCount1++;
            
            if (dataString == "WellPosition2") readingFlag = 2;
            else if (readingFlag == 2 && dataString != "SelectedFOV1") arrayWellPosition2 [wellPositionCount2] = atof(dataString.c_str()), wellPositionCount2++;
            
            if (dataString == "SelectedFOV1") readingFlag = 3;
            else if (readingFlag == 3 && dataString != "SelectedFOV2"){
                if (selectedMapCount1+5 > selectedMapLimit1) selectedMapAddition1 = 0, [self selectedMapUpDate1];
                
                arraySelectedMap1 [selectedMapCount1] = atof(dataString.c_str()), selectedMapCount1++;
            }
            
            if (dataString == "SelectedFOV2") readingFlag = 4;
            else if (readingFlag == 4 && dataString != "END"){
                if (selectedMapCount2+5 > selectedMapLimit2) selectedMapAddition2 = 0, [self selectedMapUpDate2];
                
                arraySelectedMap2 [selectedMapCount2] = atof(dataString.c_str()), selectedMapCount2++;
            }
            
            if (dataString == "END") terminationFlag = 0;
            
        } while (terminationFlag == 1);
        
        fin.close();
        
        tableXYDimensionCount = 0;
        
        fin.open(xyDimensionMapSavePath.c_str(), ios::in);
        
        if (fin.is_open()){
            do{
                
                terminationFlag = 1;
                getline(fin, dataString);
                
                if (dataString != "") arrayTableXYDimension [tableXYDimensionCount] = atoi(dataString.c_str()), tableXYDimensionCount++;
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            fin.close();
        }
        
        tableZCount = 0;
        
        fin.open(zMapSavePath.c_str(), ios::in);
        
        if (fin.is_open()){
            do{
                
                terminationFlag = 1;
                
                getline(fin, dataString);
                
                if (dataString != "") arrayTableZ [tableZCount] = atof(dataString.c_str()), tableZCount++;
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            fin.close();
        }
        
        wellDataSaveRequest = 1;
        drawingPermit1 = 1;
        tableViewCall = 1;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Saved File Found"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)reloadPrevZ:(id)sender{
    string zMapSavePath2 = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/MAP_ZMapDataLastSave2";
    
    ifstream fin;
    
    fin.open(zMapSavePath2.c_str(), ios::in);
    
    if (fin.is_open()){
        string dataString;
        
        int terminationFlag = 0;
        
        fin.open(zMapSavePath2.c_str(), ios::in);
        
        if (fin.is_open()){
            do{
                
                terminationFlag = 1;
                
                getline(fin, dataString);
                
                if (dataString != "") arrayTableZ [tableZCount] = atof(dataString.c_str()), tableZCount++;
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            fin.close();
            
            tableViewCall = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Saved File Found"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Saved File Found"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)saveCurrentZ:(id)sender{
    if (tableZCount != 0){
        string zMapSavePath2 = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/MAP_ZMapDataLastSave2";
        
        ofstream oin;
        
        oin.open(zMapSavePath2.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 < chamberWellLimit1+chamberWellLimit2; counter1++) oin<<arrayTableZ [counter1]<<endl;
        
        oin.close();
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Z Data Found"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)stgFileAllClear:(id)sender{
    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"OK"];
    [alert addButtonWithTitle:@"Cancel"];
    [alert setMessageText:@"Clear All STG Files?"];
    [alert setAlertStyle:NSAlertStyleWarning];
    
    if ([alert runModal] == NSAlertFirstButtonReturn){
        string entry;
        string removeFilePath;
        
        fileDeleteCount = 0;
        
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(informationDirectoryPath.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    if ((int)entry.find(".STG") != -1){
                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                        arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                    }
                }
            }
            
            closedir(dir);
            
            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                removeFilePath = informationDirectoryPath+"/"+arrayFileDelete [counter1];
                remove(removeFilePath.c_str());
            }
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)stgMemorizedClear:(id)sender{
    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"OK"];
    [alert addButtonWithTitle:@"Cancel"];
    [alert setMessageText:@"Clear Memorized Position STG?"];
    [alert setAlertStyle:NSAlertStyleWarning];
    
    if ([alert runModal] == NSAlertFirstButtonReturn){
        remove (positionMDAPath.c_str());
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

//CHAMBER**********CHAMBER SET METHODS**********************************
-(IBAction)chamberSelect1:(id)sender{
    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"OK"];
    [alert addButtonWithTitle:@"Cancel"];
    [alert setMessageText:@"Previous Settings Will Be Cleared"];
    [alert setAlertStyle:NSAlertStyleWarning];
    
    if ([alert runModal] == NSAlertFirstButtonReturn){
        chamberType1 = 1;
        chamberWellLimit1 = 8;
        
        subProcesses = [[SubProcesses alloc] init];
        [subProcesses mapDataSave];
        
        [self refreshPerform];
        
        [chamberDisplay1 setStringValue:@"Lab-TekII 8"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)chamberSelect2:(id)sender{
    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"OK"];
    [alert addButtonWithTitle:@"Cancel"];
    [alert setMessageText:@"Previous Settings Will Be Cleared"];
    [alert setAlertStyle:NSAlertStyleWarning];
    
    if ([alert runModal] == NSAlertFirstButtonReturn){
        chamberType1 = 2;
        chamberWellLimit1 = 2;
        
        subProcesses = [[SubProcesses alloc] init];
        [subProcesses mapDataSave];
        
        [self refreshPerform];
        
        [chamberDisplay1 setStringValue:@"ibidi 2"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)chamberSelect3:(id)sender{
    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"OK"];
    [alert addButtonWithTitle:@"Cancel"];
    [alert setMessageText:@"Previous Settings Will Be Cleared"];
    [alert setAlertStyle:NSAlertStyleWarning];
    
    if ([alert runModal] == NSAlertFirstButtonReturn){
        chamberType1 = 3;
        chamberWellLimit1 = 4;
        
        subProcesses = [[SubProcesses alloc] init];
        [subProcesses mapDataSave];
        
        [self refreshPerform];
        
        [chamberDisplay1 setStringValue:@"ibidi 4"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)chamberSelect4:(id)sender{
    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"OK"];
    [alert addButtonWithTitle:@"Cancel"];
    [alert setMessageText:@"Previous Settings Will Be Cleared"];
    [alert setAlertStyle:NSAlertStyleWarning];
    
    if ([alert runModal] == NSAlertFirstButtonReturn){
        chamberType1 = 4;
        chamberWellLimit1 = 8;
        
        subProcesses = [[SubProcesses alloc] init];
        [subProcesses mapDataSave];
        
        [self refreshPerform];
        
        [chamberDisplay1 setStringValue:@"ibidi 8"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)chamberSelect5:(id)sender{
    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"OK"];
    [alert addButtonWithTitle:@"Cancel"];
    [alert setMessageText:@"Previous Settings Will Be Cleared"];
    [alert setAlertStyle:NSAlertStyleWarning];
    
    if ([alert runModal] == NSAlertFirstButtonReturn){
        chamberType2 = 1;
        chamberWellLimit2 = 8;
        
        subProcesses = [[SubProcesses alloc] init];
        [subProcesses mapDataSave];
        
        [self refreshPerform];
        
        [chamberDisplay2 setStringValue:@"Lab-TekII 8"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)chamberSelect6:(id)sender{
    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"OK"];
    [alert addButtonWithTitle:@"Cancel"];
    [alert setMessageText:@"Previous Settings Will Be Cleared"];
    [alert setAlertStyle:NSAlertStyleWarning];
    
    if ([alert runModal] == NSAlertFirstButtonReturn){
        chamberType2 = 2;
        chamberWellLimit2 = 2;
        
        subProcesses = [[SubProcesses alloc] init];
        [subProcesses mapDataSave];
        
        [self refreshPerform];
        
        [chamberDisplay2 setStringValue:@"ibidi 2"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)chamberSelect7:(id)sender{
    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"OK"];
    [alert addButtonWithTitle:@"Cancel"];
    [alert setMessageText:@"Previous Settings Will Be Cleared"];
    [alert setAlertStyle:NSAlertStyleWarning];
    
    if ([alert runModal] == NSAlertFirstButtonReturn){
        chamberType2 = 3;
        chamberWellLimit2 = 4;
        
        subProcesses = [[SubProcesses alloc] init];
        [subProcesses mapDataSave];
        
        [self refreshPerform];
        
        [chamberDisplay2 setStringValue:@"ibidi 4"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)chamberSelect8:(id)sender{
    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"OK"];
    [alert addButtonWithTitle:@"Cancel"];
    [alert setMessageText:@"Previous Settings Will Be Cleared"];
    [alert setAlertStyle:NSAlertStyleWarning];
    
    if ([alert runModal] == NSAlertFirstButtonReturn){
        chamberType2 = 4;
        chamberWellLimit2 = 8;
        
        subProcesses = [[SubProcesses alloc] init];
        [subProcesses mapDataSave];
        
        [self refreshPerform];
        
        [chamberDisplay2 setStringValue:@"ibidi 8"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)chamberSelect9:(id)sender{
    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"OK"];
    [alert addButtonWithTitle:@"Cancel"];
    [alert setMessageText:@"Previous Settings Will Be Cleared"];
    [alert setAlertStyle:NSAlertStyleWarning];
    
    if ([alert runModal] == NSAlertFirstButtonReturn){
        chamberType1 = 5;
        chamberWellLimit1 = 6;
        
        subProcesses = [[SubProcesses alloc] init];
        [subProcesses mapDataSave];
        
        [self refreshPerform];
        
        [chamberDisplay1 setStringValue:@"ibidi Mu"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)chamberSelect10:(id)sender{
    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"OK"];
    [alert addButtonWithTitle:@"Cancel"];
    [alert setMessageText:@"Previous Settings Will Be Cleared"];
    [alert setAlertStyle:NSAlertStyleWarning];
    
    if ([alert runModal] == NSAlertFirstButtonReturn){
        chamberType2 = 5;
        chamberWellLimit2 = 6;
        
        subProcesses = [[SubProcesses alloc] init];
        [subProcesses mapDataSave];
        
        [self refreshPerform];
        
        [chamberDisplay2 setStringValue:@"ibidi Mu"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)memorizePosition:(id)sender{
    if (batchCommitStatus == 0){
        if (snapOperation == 0){
            snapOperation = 1;
            snapStart = 1;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapHandle object:self];
        }
        
        if (snapOperation == 2) snapOperation = 3;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Batch Mode Active"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)memorizePosition2:(id)sender{
    if (batchCommitStatus == 0){
        if (snapOperation2 == 0){
            snapOperation2 = 1;
            snapStart2 = 1;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapHandle2 object:self];
        }
        
        if (snapOperation2 == 2) snapOperation2 = 3;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Batch Mode Active"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)focusCheckSet:(id)sender{
    if (focusOperation == 0){
        focusOperation = 1;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFocusCheckControl object:self];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFocusCheckImage object:self];
    }
    if (focusOperation == 2) focusOperation = 3;
}

-(IBAction)orientationSet:(id)sender{
    if (drawingOrientation == 0){
        drawingOrientation = 1;
        [orientationDR setStringValue:@"Bt/Rt"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else if (drawingOrientation == 1){
        drawingOrientation = 2;
        [orientationDR setStringValue:@"Tp/Lt"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else if (drawingOrientation == 2){
        drawingOrientation = 3;
        [orientationDR setStringValue:@"Tp/Rt"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else if (drawingOrientation == 3){
        drawingOrientation = 0;
        [orientationDR setStringValue:@"Bt/Lt"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)wellOrientationSet1:(id)sender{
    if (chamberType1 == 1 || chamberType1 == 4){
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"To Change The Orientation: Save/Upload MDA"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            if (wellOrientation1 == 0){
                wellOrientation1 = 1;
                
                wellDataSaveRequest = 1;
                drawingPermit1 = 2;
                labelPositionCount1 = 0;
                
                subProcesses = [[SubProcesses alloc] init];
                [subProcesses mapDataSave];
                
                [self mapWellLabelSet1];
                
                for (int counter1 = 0; counter1 < selectedMapCount1/6; counter1++){
                    if (arraySelectedMap1 [counter1*6] == 8) arraySelectedMap1 [counter1*6] = 5;
                    else if (arraySelectedMap1 [counter1*6] == 7) arraySelectedMap1 [counter1*6] = 6;
                    else if (arraySelectedMap1 [counter1*6] == 6) arraySelectedMap1 [counter1*6] = 7;
                    else if (arraySelectedMap1 [counter1*6] == 5) arraySelectedMap1 [counter1*6] = 8;
                }
                
                [orientationWell1 setStringValue:@">>>"];
                
                wellDataSaveRequest = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                wellOrientation1 = 0;
                wellDataSaveRequest = 1;
                tableViewCall = 1;
                drawingPermit1 = 2;
                labelPositionCount1 = 0;
                
                subProcesses = [[SubProcesses alloc] init];
                [subProcesses mapDataSave];
                
                [self mapWellLabelSet1];
                
                for (int counter1 = 0; counter1 < selectedMapCount1/6; counter1++){
                    if (arraySelectedMap1 [counter1*6] == 5) arraySelectedMap1 [counter1*6] = 8;
                    else if (arraySelectedMap1 [counter1*6] == 6) arraySelectedMap1 [counter1*6] = 7;
                    else if (arraySelectedMap1 [counter1*6] == 7) arraySelectedMap1 [counter1*6] = 6;
                    else if (arraySelectedMap1 [counter1*6] == 8) arraySelectedMap1 [counter1*6] = 5;
                }
                
                [orientationWell1 setStringValue:@"<<<"];
                
                wellDataSaveRequest = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Second Row In This Chamber"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)wellOrientationSet2:(id)sender{
    NSAlert *alert = [[NSAlert alloc] init];
    
    [alert addButtonWithTitle:@"OK"];
    [alert addButtonWithTitle:@"Cancel"];
    [alert setMessageText:@"To Change The Orientation: Save/Upload MDA"];
    [alert setAlertStyle:NSAlertStyleWarning];
    
    if ([alert runModal] == NSAlertFirstButtonReturn){
        if (wellOrientation2 == 0){
            wellOrientation2 = 1;
            wellDataSaveRequest = 1;
            drawingPermit2 = 2;
            labelPositionCount2 = 0;
            
            subProcesses = [[SubProcesses alloc] init];
            [subProcesses mapDataSave];
            
            [self mapWellLabelSet2];
            
            if (chamberType1 == 1 || chamberType1 == 4){
                for (int counter1 = 0; counter1 < selectedMapCount2/6; counter1++){
                    if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+1) arraySelectedMap2 [counter1*6] = chamberWellLimit1+4;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+2) arraySelectedMap2 [counter1*6] = chamberWellLimit1+3;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+3) arraySelectedMap2 [counter1*6] = chamberWellLimit1+2;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+4) arraySelectedMap2 [counter1*6] = chamberWellLimit1+1;
                }
            }
            else if (chamberType1 == 2){
                for (int counter1 = 0; counter1 < selectedMapCount2/6; counter1++){
                    if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+1) arraySelectedMap2 [counter1*6] = chamberWellLimit1+2;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+2) arraySelectedMap2 [counter1*6] = chamberWellLimit1+1;
                }
            }
            else if (chamberType1 == 3){
                for (int counter1 = 0; counter1 < selectedMapCount2/6; counter1++){
                    if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+1) arraySelectedMap2 [counter1*6] = chamberWellLimit1+4;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+2) arraySelectedMap2 [counter1*6] = chamberWellLimit1+3;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+3) arraySelectedMap2 [counter1*6] = chamberWellLimit1+2;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+4) arraySelectedMap2 [counter1*6] = chamberWellLimit1+1;
                }
            }
            else if (chamberType1 == 5){
                for (int counter1 = 0; counter1 < selectedMapCount2/6; counter1++){
                    if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+1) arraySelectedMap2 [counter1*6] = chamberWellLimit1+6;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+2) arraySelectedMap2 [counter1*6] = chamberWellLimit1+5;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+3) arraySelectedMap2 [counter1*6] = chamberWellLimit1+4;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+4) arraySelectedMap2 [counter1*6] = chamberWellLimit1+3;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+5) arraySelectedMap2 [counter1*6] = chamberWellLimit1+2;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+6) arraySelectedMap2 [counter1*6] = chamberWellLimit1+1;
                }
            }
            
            [orientationWell2 setStringValue:@"<<<"];
            
            wellDataSaveRequest = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            wellOrientation2 = 0;
            wellDataSaveRequest = 1;
            drawingPermit2 = 2;
            labelPositionCount2 = 0;
            
            subProcesses = [[SubProcesses alloc] init];
            [subProcesses mapDataSave];
            
            [self mapWellLabelSet2];
            
            if (chamberType1 == 1 || chamberType1 == 4){
                for (int counter1 = 0; counter1 < selectedMapCount2/6; counter1++){
                    if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+4) arraySelectedMap2 [counter1*6] = chamberWellLimit1+1;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+3) arraySelectedMap2 [counter1*6] = chamberWellLimit1+2;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+2) arraySelectedMap2 [counter1*6] = chamberWellLimit1+3;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+1) arraySelectedMap2 [counter1*6] = chamberWellLimit1+4;
                }
            }
            else if (chamberType1 == 2){
                for (int counter1 = 0; counter1 < selectedMapCount2/6; counter1++){
                    if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+2) arraySelectedMap2 [counter1*6] = chamberWellLimit1+1;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+1) arraySelectedMap2 [counter1*6] = chamberWellLimit1+2;
                }
            }
            else if (chamberType1 == 3){
                for (int counter1 = 0; counter1 < selectedMapCount2/6; counter1++){
                    if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+4) arraySelectedMap2 [counter1*6] = chamberWellLimit1+1;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+3) arraySelectedMap2 [counter1*6] = chamberWellLimit1+2;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+2) arraySelectedMap2 [counter1*6] = chamberWellLimit1+3;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+1) arraySelectedMap2 [counter1*6] = chamberWellLimit1+4;
                }
            }
            else if (chamberType1 == 5){
                for (int counter1 = 0; counter1 < selectedMapCount2/6; counter1++){
                    if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+6) arraySelectedMap2 [counter1*6] = chamberWellLimit1+1;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+5) arraySelectedMap2 [counter1*6] = chamberWellLimit1+2;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+4) arraySelectedMap2 [counter1*6] = chamberWellLimit1+3;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+3) arraySelectedMap2 [counter1*6] = chamberWellLimit1+4;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+2) arraySelectedMap2 [counter1*6] = chamberWellLimit1+5;
                    else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+1) arraySelectedMap2 [counter1*6] = chamberWellLimit1+6;
                }
            }
            
            [orientationWell2 setStringValue:@">>>"];
            
            wellDataSaveRequest = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
}

-(IBAction)wellOrientationSet3:(id)sender{
    if (chamberType2 == 1 || chamberType2 == 4){
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"To Change The Orientation: Save/Upload MDA"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            if (wellOrientation3 == 0){
                wellOrientation3 = 1;
                wellDataSaveRequest = 1;
                drawingPermit2 = 2;
                labelPositionCount2 = 0;
                
                subProcesses = [[SubProcesses alloc] init];
                [subProcesses mapDataSave];
                
                [self mapWellLabelSet2];
                
                if (chamberType1 == 1 || chamberType1 == 4){
                    for (int counter1 = 0; counter1 < selectedMapCount2/6; counter1++){
                        if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+5) arraySelectedMap2 [counter1*6] = chamberWellLimit1+8;
                        else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+6) arraySelectedMap2 [counter1*6] = chamberWellLimit1+7;
                        else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+7) arraySelectedMap2 [counter1*6] = chamberWellLimit1+6;
                        else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+8) arraySelectedMap2 [counter1*6] = chamberWellLimit1+5;
                    }
                }
                
                [orientationWell3 setStringValue:@">>>"];
                
                wellDataSaveRequest = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                wellOrientation3 = 0;
                wellDataSaveRequest = 1;
                drawingPermit2 = 2;
                labelPositionCount2 = 0;
                
                subProcesses = [[SubProcesses alloc] init];
                [subProcesses mapDataSave];
                
                [self mapWellLabelSet2];
                
                if (chamberType1 == 1 || chamberType1 == 4){
                    for (int counter1 = 0; counter1 < selectedMapCount2/6; counter1++){
                        if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+8) arraySelectedMap2 [counter1*6] = chamberWellLimit1+5;
                        else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+7) arraySelectedMap2 [counter1*6] = chamberWellLimit1+6;
                        else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+6) arraySelectedMap2 [counter1*6] = chamberWellLimit1+7;
                        else if (arraySelectedMap2 [counter1*6] == chamberWellLimit1+5) arraySelectedMap2 [counter1*6] = chamberWellLimit1+8;
                    }
                }
                
                [orientationWell3 setStringValue:@"<<<"];
                
                wellDataSaveRequest = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Second Row In This Chamber"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)stepperActionStartM:(id)sender{
    if ([stepperStartM intValue] >= 1 && [stepperStartM intValue] <= 500){
        [stepperStartDisplayM setIntValue:[stepperStartM intValue]];
        stepperStartHoldM = [stepperStartM intValue];
    }
}

-(IBAction)stepperActionEveryM:(id)sender{
    if ([stepperEveryM intValue] >= 1 && [stepperEveryM intValue] <= 100){
        [stepperEveryDisplayM setIntValue:[stepperEveryM intValue]];
        stepperEveryHoldM = [stepperEveryM intValue];
    }
}

-(IBAction)createTestM:(id)sender{
    if (bodyName.substr(bodyName.length()-2) != "IF"){
        int zValueMatchFlag = 0;
        
        if (tableXYDimensionHoldCount != 0){
            for (int counter1 = 0; counter1 < 16; counter1++){
                if (arrayTableZHold [counter1] != arrayTableZ [counter1]) zValueMatchFlag = 1;
            }
        }
        
        string stgSaveAdjustPath = informationDirectoryPath+"/Atest_positions.STG";
        string dataString;
        
        ifstream fin;
        
        for (int counter2 = 0; counter2 <= 16; counter2++){
            wellPositionTest [counter2*2] = -1;
            wellPositionTest [counter2*2+1] = -1;
        }
        
        double *arrayMapTemp1 = new double [selectedMapCount1+50];
        double *arrayMapTemp2 = new double [selectedMapCount2+50];
        
        int selectedFOVCount1 = selectedMapCount1/6;
        int selectedFOVCount2 = selectedMapCount2/6;
        
        int mapEnterCount1 = 0;
        int mapEnterCount2 = 0;
        
        if (selectedFOVCount1 != 0){
            double *arrayMapTemp = new double [selectedMapCount1+50];
            int mapTempCount = 0;
            int fovPositionCount = 0;
            int fovPositionCountTemp = 0;
            int wellNo = 0;
            
            for (int counter2 = 0; counter2 < selectedFOVCount1; counter2++){
                if (arraySelectedMap1 [counter2*6] != wellNo && fovPositionCount == 0){
                    if (stepperStartHoldM == 1){
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6+1], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6+2], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6+3], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6+4], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6+5], mapTempCount++;
                        
                        fovPositionCount = stepperEveryHoldM;
                        wellNo = (int)arraySelectedMap1 [counter2*6];
                        
                        fovPositionCountTemp++;
                    }
                    else{
                        
                        fovPositionCount = stepperStartHoldM-1;
                        wellNo = (int)arraySelectedMap1 [counter2*6];
                        fovPositionCountTemp++;
                    }
                }
                else if (arraySelectedMap1 [counter2*6] == wellNo && fovPositionCount != 0){
                    if (fovPositionCountTemp == fovPositionCount){
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6+1], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6+2], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6+3], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6+4], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6+5], mapTempCount++;
                        
                        fovPositionCount = fovPositionCount+stepperEveryHoldM;
                        
                        fovPositionCountTemp++;
                    }
                    else fovPositionCountTemp++;
                }
                else if (arraySelectedMap1 [counter2*6] != wellNo && fovPositionCount != 0){
                    fovPositionCountTemp = 0;
                    
                    if (stepperStartHoldM == 1){
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6+1], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6+2], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6+3], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6+4], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter2*6+5], mapTempCount++;
                        
                        fovPositionCount = stepperEveryHoldM;
                        wellNo = (int)arraySelectedMap1 [counter2*6];
                        
                        fovPositionCountTemp++;
                    }
                    else{
                        
                        fovPositionCount = stepperStartHoldM-1;
                        wellNo = (int)arraySelectedMap1 [counter2*6];
                    }
                }
            }
            
            mapEnterCount1 = 0;
            
            for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp1 [mapEnterCount1] = arrayMapTemp [counter1], mapEnterCount1++;
            
            mapTempCount = 0;
            
            for (int counter1 = 1; counter1 <= chamberWellLimit1; counter1++){
                for (int counter2 = 0; counter2 < mapEnterCount1/6; counter2++){
                    if (arrayMapTemp1 [counter2*6] == counter1){
                        arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+1], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+2], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+3], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+4], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+5], mapTempCount++;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < 16; counterA++){
            //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<wellPositionTest [counterA*2+counterB];
            //    cout<<" wellPositionTest "<<counterA<<endl;
            //}
            
            mapEnterCount1 = 0;
            
            for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp1 [mapEnterCount1] = arrayMapTemp [counter1], mapEnterCount1++;
            
            delete [] arrayMapTemp;
            
            //for (int counterA = 0; counterA < mapEnterCount1/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayMapTemp1 [counterA*6+counterB];
            //    cout<<" arrayMapTemp1 "<<counterA<<" "<<endl;
            //}
            
            for (int counter1 = 0; counter1 < mapEnterCount1/6; counter1++){
                if (wellPositionTest [(int)arrayMapTemp1 [counter1*6]*2] == -1){
                    wellPositionTest [(int)arrayMapTemp1 [counter1*6]*2] = counter1+1;
                    wellPositionTest [(int)arrayMapTemp1 [counter1*6]*2+1] = counter1+1;
                }
                else{
                    
                    wellPositionTest [(int)arrayMapTemp1 [counter1*6]*2+1] = counter1+1;
                }
            }
            
            //for (int counterA = 0; counterA < 16; counterA++){
            //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<wellPositionTest [counterA*2+counterB];
            //    cout<<" wellPositionTest "<<counterA<<" "<<endl;
            //}
        }
        
        if (selectedFOVCount2 != 0){
            double *arrayMapTemp = new double [selectedMapCount2+50];
            int mapTempCount = 0;
            int fovPositionCount = 0;
            int fovPositionCountTemp = 0;
            int wellNo = 0;
            
            for (int counter2 = 0; counter2 < selectedFOVCount1; counter2++){
                if (arraySelectedMap2 [counter2*6] != wellNo && fovPositionCount == 0){
                    if (stepperStartHoldM == 1){
                        arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6+1], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6+2], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6+3], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6+4], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6+5], mapTempCount++;
                        
                        fovPositionCount = stepperEveryHoldM;
                        wellNo = (int)arraySelectedMap2 [counter2*6];
                        
                        fovPositionCountTemp++;
                    }
                    else{
                        
                        fovPositionCount = stepperStartHoldM-1;
                        wellNo = (int)arraySelectedMap2 [counter2*6];
                        fovPositionCountTemp++;
                    }
                }
                else if (arraySelectedMap2 [counter2*6] == wellNo && fovPositionCount != 0){
                    if (fovPositionCountTemp == fovPositionCount){
                        arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6+1], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6+2], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6+3], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6+4], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6+5], mapTempCount++;
                        
                        fovPositionCount = fovPositionCount+stepperEveryHoldM;
                        
                        fovPositionCountTemp++;
                    }
                    else fovPositionCountTemp++;
                }
                else if (arraySelectedMap2 [counter2*6] != wellNo && fovPositionCount != 0){
                    fovPositionCountTemp = 0;
                    
                    if (stepperStartHoldM == 1){
                        arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6+1], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6+2], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6+3], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6+4], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap2 [counter2*6+5], mapTempCount++;
                        
                        fovPositionCount = stepperEveryHoldM;
                        wellNo = (int)arraySelectedMap2 [counter2*6];
                        
                        fovPositionCountTemp++;
                    }
                    else{
                        
                        fovPositionCount = stepperStartHoldM-1;
                        wellNo = (int)arraySelectedMap2 [counter2*6];
                        fovPositionCountTemp++;
                    }
                }
            }
            
            mapEnterCount2 = 0;
            
            for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp2 [mapEnterCount2] = arrayMapTemp [counter1], mapEnterCount2++;
            
            mapTempCount = 0;
            
            for (int counter1 = chamberWellLimit1+1; counter1 <= chamberWellLimit1+chamberWellLimit2; counter1++){
                for (int counter2 = 0; counter2 < mapEnterCount2/6; counter2++){
                    if (arrayMapTemp2 [counter2*6] == counter1){
                        arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+1], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+2], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+3], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+4], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+5], mapTempCount++;
                    }
                }
            }
            
            mapEnterCount2 = 0;
            
            for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp2 [mapEnterCount2] = arrayMapTemp [counter1], mapEnterCount2++;
            
            delete [] arrayMapTemp;
            
            for (int counter1 = 0; counter1 < mapEnterCount2/6; counter1++){
                if (wellPositionTest [(int)arrayMapTemp2 [counter1*6]*2] == -1){
                    wellPositionTest [(int)arrayMapTemp2 [counter1*6]*2] = counter1+1;
                    wellPositionTest [(int)arrayMapTemp2 [counter1*6]*2+1] = counter1+1;
                }
                else wellPositionTest [(int)arrayMapTemp2 [counter1*6]*2+1] = counter1+1;
            }
        }
        
        //for (int counterA = 0; counterA < mapEnterCount1/6; counterA++){
        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayMapTemp1 [counterA*6+counterB];
        //    cout<<" arrayMapTemp1 "<<counterA<<" "<<endl;
        //}
        
        if (mapEnterCount1/6+mapEnterCount2/6 != 0){
            if (batchCommitStatus == 0){
                if (autoCommitStatus == 0 || (autoCommitStatus == 1 && zValueMatchFlag == 1)){
                    if (initialCommitStatus == 0 || (autoCommitStatus == 1 && zValueMatchFlag == 1)){
                        ofstream oin;
                        
                        oin.open(stgSaveAdjustPath.c_str(), ios::out | ios::binary);
                        
                        ascIIconversion = [[ASCIIconversion alloc] init];
                        
                        if (oin.is_open()){
                            arrayAscIIintData = new int [100];
                            ascIIintDataCount = 0;
                            
                            oin.put(34);
                            
                            ascIIstring = "Stage Memory List";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
                            
                            oin.put(34), oin.put(44), oin.put(32);
                            
                            ascIIstring = "Version 6.0";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
                            
                            oin.put(13), oin.put(10), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
                            oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44);
                            oin.put(32), oin.put(34), oin.put(117), oin.put(109), oin.put(34), oin.put(44), oin.put(32), oin.put(34), oin.put(117), oin.put(109), oin.put(34);
                            oin.put(13), oin.put(10), oin.put(48), oin.put(13), oin.put(10);
                            
                            ascIIstring = to_string(mapEnterCount1/6+mapEnterCount2/6);
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
                            
                            oin.put(13), oin.put(10);
                            
                            if (mapEnterCount1/6 != 0){
                                for (int counter1 = 0; counter1 < mapEnterCount1/6; counter1++){
                                    oin.put(34);
                                    
                                    ascIIstring = "well ";
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    stringstream extension;
                                    extension << arrayMapTemp1 [counter1*6]; //----Well number----
                                    ascIIstring = extension.str();
                                    
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    ascIIstring = " position ";
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    stringstream extension1;
                                    extension1 << arrayMapTemp1 [counter1*6+1]; //----X position----
                                    ascIIstring = extension1.str();
                                    
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    oin.put(44), oin.put(32);
                                    
                                    stringstream extension2;
                                    extension2 << arrayMapTemp1 [counter1*6+2]; //----Y position----
                                    ascIIstring = extension2.str();
                                    
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    oin.put(34), oin.put(44), oin.put(32);
                                    
                                    stringstream extension3;
                                    extension3 << arrayMapTemp1 [counter1*6+3]; //----X value----
                                    ascIIstring = extension3.str();
                                    
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    oin.put(44), oin.put(32);
                                    
                                    stringstream extension4;
                                    extension4 << arrayMapTemp1 [counter1*6+4]; //----Y value----
                                    ascIIstring = extension4.str();
                                    
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    oin.put(44), oin.put(32);
                                    
                                    stringstream extension5;
                                    extension5 << arrayMapTemp1 [counter1*6+5]; //----Z value----
                                    ascIIstring = extension5.str();
                                    
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
                                    
                                    ascIIstring = "FALSE";
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    oin.put(44), oin.put(32);
                                    
                                    ascIIstring = "-9999";
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    oin.put(44), oin.put(32);
                                    
                                    ascIIstring = "TRUE";
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    oin.put(44), oin.put(32);
                                    
                                    ascIIstring = "TRUE";
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(45), oin.put(49), oin.put(44);
                                    oin.put(32), oin.put(34), oin.put(34), oin.put(44), oin.put(13), oin.put(10);
                                }
                            }
                            
                            if (mapEnterCount2/6 != 0){
                                for (int counter1 = 0; counter1 < mapEnterCount2/6; counter1++){
                                    oin.put(34);
                                    
                                    ascIIstring = "well ";
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    stringstream extension;
                                    extension << arrayMapTemp2 [counter1*6]; //----Well number----
                                    ascIIstring = extension.str();
                                    
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    ascIIstring = " position ";
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    stringstream extension1;
                                    extension1 << arrayMapTemp2 [counter1*6+1]; //----X position----
                                    ascIIstring = extension1.str();
                                    
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    oin.put(44), oin.put(32);
                                    
                                    stringstream extension2;
                                    extension2 << arrayMapTemp2 [counter1*6+2]; //----Y position----
                                    ascIIstring = extension2.str();
                                    
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    oin.put(34), oin.put(44), oin.put(32);
                                    
                                    stringstream extension3;
                                    extension3 << arrayMapTemp2 [counter1*6+3]; //----X value----
                                    ascIIstring = extension3.str();
                                    
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    oin.put(44), oin.put(32);
                                    
                                    stringstream extension4;
                                    extension4 << arrayMapTemp2 [counter1*6+4]; //----Y value----
                                    ascIIstring = extension4.str();
                                    
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    oin.put(44), oin.put(32);
                                    
                                    stringstream extension5;
                                    extension5 << arrayMapTemp2 [counter1*6+5]; //----Z value----
                                    ascIIstring = extension5.str();
                                    
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
                                    
                                    ascIIstring = "FALSE";
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    oin.put(44), oin.put(32);
                                    
                                    ascIIstring = "-9999";
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    oin.put(44), oin.put(32);
                                    
                                    ascIIstring = "TRUE";
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    oin.put(44), oin.put(32);
                                    
                                    ascIIstring = "TRUE";
                                    ascIIintDataCount = [ascIIconversion ascIICode];
                                    
                                    for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                    
                                    oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(45), oin.put(49), oin.put(44);
                                    oin.put(32), oin.put(34), oin.put(34), oin.put(44), oin.put(13), oin.put(10);
                                }
                            }
                            
                            oin.close();
                            
                            delete [] arrayAscIIintData;
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Check The Destination Computer"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Init On, Saving Prohibited"];
                        [alert setInformativeText:@" For IF: Save after IF Start."];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Auto. On, Saving Prohibited/Z Has Not Been Changed"];
                    [alert setInformativeText:@"After Last Purge: Quit Map and Restart after IF Start/For IF: Quit Map and Restart after IF Start."];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Batch ON, Saving Prohibited"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No FOV Found"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        
        delete [] arrayMapTemp1;
        delete [] arrayMapTemp2;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Save MDA Using Memorize"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)camera512x512:(id)sender{
    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"OK"];
    [alert addButtonWithTitle:@"Cancel"];
    [alert setMessageText:@"Previous Settings Will Be Cleared"];
    [alert setAlertStyle:NSAlertStyleWarning];
    
    if ([alert runModal] == NSAlertFirstButtonReturn){
        cameraDimension = 512;
        
        subProcesses = [[SubProcesses alloc] init];
        [subProcesses mapDataSave];
        
        [self refreshPerform];
        
        [cameraDimensionDisplay setStringValue:@"512x512"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)camera1024x1024:(id)sender{
    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"OK"];
    [alert addButtonWithTitle:@"Cancel"];
    [alert setMessageText:@"Previous Settings Will Be Cleared"];
    [alert setAlertStyle:NSAlertStyleWarning];
    
    if ([alert runModal] == NSAlertFirstButtonReturn){
        cameraDimension = 1024;
        
        subProcesses = [[SubProcesses alloc] init];
        [subProcesses mapDataSave];
        
        [self refreshPerform];
        
        [cameraDimensionDisplay setStringValue:@"1024x1024"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)camera1536x1536:(id)sender{
    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"OK"];
    [alert addButtonWithTitle:@"Cancel"];
    [alert setMessageText:@"Previous Settings Will Be Cleared"];
    [alert setAlertStyle:NSAlertStyleWarning];
    
    if ([alert runModal] == NSAlertFirstButtonReturn){
        cameraDimension = 1536;
        
        subProcesses = [[SubProcesses alloc] init];
        [subProcesses mapDataSave];
        
        [self refreshPerform];
        
        [cameraDimensionDisplay setStringValue:@"1536x1536"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)camera2048x2048:(id)sender{
    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"OK"];
    [alert addButtonWithTitle:@"Cancel"];
    [alert setMessageText:@"Previous Settings Will Be Cleared"];
    [alert setAlertStyle:NSAlertStyleWarning];
    
    if ([alert runModal] == NSAlertFirstButtonReturn){
        cameraDimension = 2048;
        
        subProcesses = [[SubProcesses alloc] init];
        [subProcesses mapDataSave];
        
        [self refreshPerform];
        
        [cameraDimensionDisplay setStringValue:@"2048x2048"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(void)readingPositionMDAUpDate{
    double *arrayUpDate = new double [readingPositionMDACount+10];
    
    for (int counter1 = 0; counter1 < readingPositionMDACount; counter1++) arrayUpDate [counter1] = arrayReadingPositionMDA [counter1];
    
    delete [] arrayReadingPositionMDA;
    arrayReadingPositionMDA = new double [readingPositionMDALimit+500];
    readingPositionMDALimit = readingPositionMDALimit+500;
    
    for (int counter1 = 0; counter1 < readingPositionMDACount; counter1++) arrayReadingPositionMDA [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)selectedMapUpDate1{
    double *arrayUpDate = new double [selectedMapCount1+10];
    
    for (int counter1 = 0; counter1 < selectedMapCount1; counter1++) arrayUpDate [counter1] = arraySelectedMap1 [counter1];
    
    delete [] arraySelectedMap1;
    arraySelectedMap1 = new double [selectedMapLimit1+selectedMapAddition1+500];
    selectedMapLimit1 = selectedMapLimit1+selectedMapAddition1+500;
    
    for (int counter1 = 0; counter1 < selectedMapCount1; counter1++) arraySelectedMap1 [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)selectedMapUpDate2{
    double *arrayUpDate = new double [selectedMapCount2+10];
    
    for (int counter1 = 0; counter1 < selectedMapCount2; counter1++) arrayUpDate [counter1] = arraySelectedMap2 [counter1];
    
    delete [] arraySelectedMap2;
    arraySelectedMap2 = new double [selectedMapLimit2+selectedMapAddition2+500];
    selectedMapLimit2 = selectedMapLimit2+selectedMapAddition2+500;
    
    for (int counter1 = 0; counter1 < selectedMapCount2; counter1++) arraySelectedMap2 [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    if (controllerTimer) [controllerTimer invalidate];
}

@end
