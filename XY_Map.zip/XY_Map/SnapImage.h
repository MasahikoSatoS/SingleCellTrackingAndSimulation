//
//  SnapImage.h
//  XY_Map
//
//  Created by Masahiko Sato on 2014-08-23.
//
//

#ifndef SNAPIMAGE_H
#define SNAPIMAGE_H
#import "Controller.h"
#endif

@interface SnapImage : NSView {
    int magnificationSnap1; //Display control
    
    int mouseDragFlag; //Display control
    double xPositionSnap1; //Display control
    double yPositionSnap1; //Display control
    double xPositionAdjustSnap1; //Display control
    double yPositionAdjustSnap1; //Display control
    double xPointDownSnap1; //Display control
    double yPointDownSnap1; //Display control
    double xPointDragSnap1; //Display control
    double yPointDragSnap1; //Display control
    double xPositionMoveSnap1; //Display control
    double yPositionMoveSnap1; //Display control
    double windowWidthSnap1; //Display control
    double windowHeightSnap1; //Display control
    
    IBOutlet NSImage *snapWindowImage1;
    
    id tiffFileRead;
}

-(void)mouseDown:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)mouseDraged:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
