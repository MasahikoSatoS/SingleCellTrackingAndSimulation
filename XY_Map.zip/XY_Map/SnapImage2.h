//
//  SnapImage2.h
//  XY_Map
//
//  Created by Masahiko Sato on 2014-08-23.
//
//

#ifndef SNAPIMAGE2_H
#define SNAPIMAGE2_H
#import "Controller.h"
#endif

@interface SnapImage2 : NSView {
    int magnificationSnap2; //Display control
    
    int mouseDragFlag; //Display control
    double xPositionSnap2; //Display control
    double yPositionSnap2; //Display control
    double xPositionAdjustSnap2; //Display control
    double yPositionAdjustSnap2; //Display control
    double xPointDownSnap2; //Display control
    double yPointDownSnap2; //Display control
    double xPointDragSnap2; //Display control
    double yPointDragSnap2; //Display control
    double xPositionMoveSnap2; //Display control
    double yPositionMoveSnap2; //Display control
    double windowWidthSnap2; //Display control
    double windowHeightSnap2; //Display control
    
    IBOutlet NSImage *snapWindowImage2;
    
    id tiffFileRead;
}

-(void)mouseDown:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)mouseDraged:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
