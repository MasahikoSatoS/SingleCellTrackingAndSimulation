//
//  FocusCheckAddition.h
//  XY_Map
//
//  Created by Masahiko Sato on 2015-03-03.
//
//

#ifndef FOCUSCHECKADDITION_H
#define FOCUSCHECKADDITION_H
#import "Controller.h" 
#endif

@interface FocusCheckAddition : NSView {
    IBOutlet NSTextField *currentPlaneNumber;
    IBOutlet NSTextField *fileNameDisplay;
    
    NSTimer *focusCheckTimer2;
}

-(id)init;
-(void)dealloc;
-(void)displayData;

@end
