//
//  FocusCheckImage.m
//  XY_Map
//
//  Created by Masahiko Sato on 2014-10-29.
//
//

#import "FocusCheckImage.h"

NSString *notificationToFocusCheckImage = @"notificationExecuteFocusImage";

@implementation FocusCheckImage

- (id)initWithFrame:(NSRect)frame{
    self = [super initWithFrame:frame];
    
    if (self){
        magnificationFocus = 10;
        
        focusImage1 = [[NSImage alloc] initWithContentsOfFile:@""];
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToFocusCheckImage object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    if (imageDataHoldZImageStatus == 1){
        if (focusPhotometric == 1){
            NSBitmapImageRep *bitmapReps;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:zImageHeight pixelsHigh:zImageHeight bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:zImageHeight bitsPerPixel:8];
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            int dataA = 0;
            
            for (int counter1 = 0; counter1 < zImageHeight; counter1++){
                for (int counter2 = 0; counter2 < zImageHeight; counter2++){
                    dataA = (int)(arrayImageDataHoldZImage [planeNumberDisplay*zImageHeight+counter1][counter2]*contrastAdjust);
                    
                    if (dataA > 255) dataA = 255;
                    
                    *bitmapData++ = (unsigned char)dataA;
                }
            }
            
            focusImage1 = [[NSImage alloc] initWithSize:NSMakeSize(zImageHeight, zImageHeight)];
            [focusImage1 addRepresentation:bitmapReps];
        }
        else if (focusPhotometric == 2){
            NSBitmapImageRep *bitmapReps;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:zImageHeight pixelsHigh:zImageWidth bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:zImageWidth*4 bitsPerPixel:32];
            
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            int dataA = 0;
            
            for (int counter1 = 0; counter1 < zImageHeight; counter1++){
                for (int counter2 = 0; counter2 < zImageHeight; counter2++){
                    dataA = (int)(arrayImageDataHoldZImage [planeNumberDisplay*zImageHeight+counter1][counter2]*contrastAdjust);
                    
                    if (dataA > 255) dataA = 255;
                    
                    *bitmapData++ = (unsigned char)dataA;
                    
                    dataA = (int)(arrayImageDataHoldZImage [planeNumberDisplay*zImageHeight+counter1][counter2+1]*contrastAdjust);
                    
                    if (dataA > 255) dataA = 255;
                    
                    *bitmapData++ = (unsigned char)dataA;
                    
                    dataA = (int)(arrayImageDataHoldZImage [planeNumberDisplay*zImageHeight+counter1][counter2+3]*contrastAdjust);
                    
                    if (dataA > 255) dataA = 255;
                    
                    *bitmapData++ = (unsigned char)dataA;
                }
            }
            
            focusImage1 = [[NSImage alloc] initWithSize:NSMakeSize(zImageHeight, zImageHeight)];
            [focusImage1 addRepresentation:bitmapReps];
        }
        
        currentPlaneDisplayCall = 1;
    }
    
    if (imageFirstLoadFlagFocus == 0){
        xPositionFocus = 0;
        yPositionFocus = 0;
        xPositionAdjustFocus = 0;
        yPositionAdjustFocus = 0;
        magnificationFocus = 10;
        imageFirstLoadFlagFocus = 1;
    }
    
    //----Window size and Position re-adjust----
    int vertical = 450+78;
    int horizontal = 450;
    
    windowWidthFocus = zImageHeight/(double)horizontal;
    windowHeightFocus = zImageHeight/(double)(vertical-78);
    
    xPositionAdjustFocus = (zImageHeight-zImageHeight/(double)(magnificationFocus*0.1))/(double)2;
    yPositionAdjustFocus = (zImageHeight-zImageHeight/(double)(magnificationFocus*0.1))/(double)2;
    
    [self setNeedsDisplay:YES];
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)mouseDown:(NSEvent *)event{
    NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
    xPointDownFocus = clickPoint.x;
    yPointDownFocus = clickPoint.y;
    [self setNeedsDisplay:YES];
}

-(void)mouseUp:(NSEvent *)event{
    xPositionFocus = xPositionFocus+xPositionMoveFocus;
    yPositionFocus = yPositionFocus+yPositionMoveFocus;
    xPositionMoveFocus = 0;
    yPositionMoveFocus = 0;
    [self setNeedsDisplay:YES];
}

- (void)mouseDraged:(NSEvent *)event{
    NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
    xPointDragFocus = clickPoint.x;
    yPointDragFocus = clickPoint.y;
    xPositionMoveFocus = (xPointDownFocus-xPointDragFocus)*windowWidthFocus/(double)(magnificationFocus*0.1);
    yPositionMoveFocus = (yPointDownFocus-yPointDragFocus)*windowHeightFocus/(double)(magnificationFocus*0.1);
    
    [self setNeedsDisplay:YES];
}

-(void)keyDown:(NSEvent *)event{
    int keyCode = [event keyCode];
    int proceedFlag = 0;
    
    if (keyCode == 124){
        proceedFlag = 1;
        planeNumberDisplay++;
        
        if (planeNumberDisplay >= zImagePlane) planeNumberDisplay--;
        
        currentPlaneDisplayCall = 1;
    }
    
    //----Magnification Reduction----
    if (keyCode == 123){
        proceedFlag = 1;
        planeNumberDisplay--;
        
        if (planeNumberDisplay < 0) planeNumberDisplay = 0;
        
        currentPlaneDisplayCall = 1;
    }
    
    //----Magnification Magnify----
    if (keyCode == 125){
        if (magnificationFocus >= 10 && magnificationFocus <= 350){
            proceedFlag = 1;
            
            if (magnificationFocus-10 < 10) magnificationFocus = 10;
            else magnificationFocus = magnificationFocus-10;
            
            xPositionAdjustFocus = -1*(zImageHeight/(double)(magnificationFocus*0.1)-zImageHeight)/(double)2;
            yPositionAdjustFocus = -1*(zImageHeight/(double)(magnificationFocus*0.1)-zImageHeight)/(double)2;
        }
    }
    
    //----Magnification Reduction----
    if (keyCode == 126){
        if (magnificationFocus >= 10 && magnificationFocus <= 498){
            proceedFlag = 1;
            
            if (magnificationFocus+10 > 498) magnificationFocus = 498;
            else magnificationFocus = magnificationFocus+10;
            
            xPositionAdjustFocus = (zImageHeight-zImageHeight/(double)(magnificationFocus*0.1))/(double)2;
            yPositionAdjustFocus = (zImageHeight-zImageHeight/(double)(magnificationFocus*0.1))/(double)2;
        }
    }
    
    if (proceedFlag == 1){
        if (focusPhotometric == 1){
            NSBitmapImageRep *bitmapReps;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:zImageHeight pixelsHigh:zImageHeight bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:zImageHeight bitsPerPixel:8];
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            int dataA = 0;
            
            for (int counter1 = 0; counter1 < zImageHeight; counter1++){
                for (int counter2 = 0; counter2 < zImageHeight; counter2++){
                    dataA = (int)(arrayImageDataHoldZImage [planeNumberDisplay*zImageHeight+counter1][counter2]*contrastAdjust);
                    
                    if (dataA > 255) dataA = 255;
                    
                    *bitmapData++ = (unsigned char)dataA;
                }
            }
            
            focusImage1 = [[NSImage alloc] initWithSize:NSMakeSize(zImageHeight, zImageHeight)];
            [focusImage1 addRepresentation:bitmapReps];
        }
        else if (focusPhotometric == 2){
            NSBitmapImageRep *bitmapReps;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:zImageHeight pixelsHigh:zImageWidth bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:zImageWidth*4 bitsPerPixel:32];
            
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            int dataA = 0;
            
            for (int counter1 = 0; counter1 < zImageHeight; counter1++){
                for (int counter2 = 0; counter2 < zImageHeight; counter2++){
                    dataA = (int)(arrayImageDataHoldZImage [planeNumberDisplay*zImageHeight+counter1][counter2]*contrastAdjust);
                    
                    if (dataA > 255) dataA = 255;
                    
                    *bitmapData++ = (unsigned char)dataA;
                    
                    dataA = (int)(arrayImageDataHoldZImage [planeNumberDisplay*zImageHeight+counter1][counter2+1]*contrastAdjust);
                    
                    if (dataA > 255) dataA = 255;
                    
                    *bitmapData++ = (unsigned char)dataA;
                    
                    dataA = (int)(arrayImageDataHoldZImage [planeNumberDisplay*zImageHeight+counter1][counter2+3]*contrastAdjust);
                    
                    if (dataA > 255) dataA = 255;
                    
                    *bitmapData++ = (unsigned char)dataA;
                }
            }
            
            focusImage1 = [[NSImage alloc] initWithSize:NSMakeSize(zImageHeight, zImageHeight)];
            [focusImage1 addRepresentation:bitmapReps];
        }
        
        [self setNeedsDisplay:YES];
    }
}

-(void)drawRect:(NSRect)rect{
    NSRect srcRect;
    srcRect.origin.x = xPositionFocus+xPositionAdjustFocus+xPositionMoveFocus;
    srcRect.origin.y = yPositionFocus+yPositionAdjustFocus+yPositionMoveFocus;
    srcRect.size.width = zImageHeight/(double)(magnificationFocus*0.1);
    srcRect.size.height = zImageHeight/(double)(magnificationFocus*0.1);
    
    [focusImage1 drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToFocusCheckImage object:nil];
}

@end
