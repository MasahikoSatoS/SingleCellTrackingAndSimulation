//
//  SubProcesses.m
//  XY_Map
//
//  Created by Masahiko Sato on 2022-02-16.
//

#import "SubProcesses.h"

@implementation SubProcesses

-(void)mapDataSave{
    ofstream oin;
    
    oin.open(xyBasicDataPath.c_str(),ios::out);
    oin<<xFOVTaken<<endl;
    oin<<yFOVTaken<<endl;
    oin<<chamberType1<<endl;
    oin<<chamberType2<<endl;
    oin<<snapFirstSecondTime<<endl;
    oin<<snapFirstSecondTime2<<endl;
    oin<<snapPage<<endl;
    oin<<snapPage2<<endl;
    oin<<wellOrientation1<<endl;
    oin<<wellOrientation2<<endl;
    oin<<wellOrientation3<<endl;
    oin<<cameraDimension<<endl;
    oin.close();
}

@end
