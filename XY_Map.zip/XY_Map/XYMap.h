//
//  XYMap.h
//  XY_Map
//
//  Created by Masahiko Sato on 11/04/29, 28/05/13 revised.
//  Copyright 2011 Masahiko Sato All rights reserved.
//

#ifndef MAP_H
#define MAP_H
#import "Controller.h" 
#endif

@interface XYMap : NSView {
    double xPointDown; //Display control
    double yPointDown; //Display control
    int magnificationWell; //Display control
    int pressSflag; //Flag for press S
    
    IBOutlet NSImage *xyMapImage;
    IBOutlet NSWindow *mapImageWindow1;
    
    NSTimer *xyMapTimer;
}

-(void)dealloc;
-(void)keyDown:(NSEvent *)event;
-(void)displayMap;
-(void)selectedMapUpDate1;

@end
