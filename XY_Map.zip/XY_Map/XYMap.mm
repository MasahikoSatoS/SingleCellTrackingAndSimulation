//
//  XYMap.mm
//  XY_Map
//
//  Created by Masahiko Sato on 11/04/29, 28/05/13 revised.
//  Copyright 2011 Masahiko Sato All rights reserved.
//

#import "XYMap.h"

NSString *notificationToXYMap = @"notificationExecuteXYMap";

@implementation XYMap

-(id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    
    if (self){
        xPointDown = 0;
        yPointDown = 0;
        magnificationWell = 0;
        pressSflag = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToXYMap object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    xyMapTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(displayMap) userInfo:nil repeats:YES];
}

-(void)displayMap{
    if (mapReadFlag1 == 1){
        mapReadFlag1 = 0;
        displayCheck1 = 1;
    }
    
    if (displayCheck1 == 1)[self setNeedsDisplay:YES];
    else if (displayCheck1 == 2) displayCheck1 = 0;
}

//----First Responder----
-(BOOL)acceptsFirstResponder{
    return YES;
}

//----Key Down----
-(void)keyDown:(NSEvent *)event{
    if (drawingPermit1 == 1){
        int keyCode = [event keyCode];
        
        //----Save FOVs----
        if (keyCode == 1){
            if (magnificationWell != 0){
                pressSflag = 1;
                [self setNeedsDisplay:YES];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Select A Well"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        //----Reset all FOVs----
        if (keyCode == 3){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert addButtonWithTitle:@"Cancel"];
            [alert setMessageText:@"Clear All FOVs In Map1?"];
            [alert setAlertStyle:NSAlertStyleWarning];
            
            if ([alert runModal] == NSAlertFirstButtonReturn){
                selectedMapCount1 = 0;
                wellDataSaveRequest = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [self setNeedsDisplay:YES];
            }
        }
        
        //----Reset FOV in a well----
        if (keyCode == 15){
            if (magnificationWell != 0){
                double *arrayMapTemp = new double [selectedMapCount1+50];
                int mapTempCount = 0;
                
                for (int counter1 = 0; counter1 < selectedMapCount1/6; counter1++){
                    if (arraySelectedMap1 [counter1*6] != magnificationWell){
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+1], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+2], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+3], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+4], mapTempCount++;
                        arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+5], mapTempCount++;
                    }
                }
                
                selectedMapCount1 = 0;
                
                for (int counter1 = 0; counter1 < mapTempCount; counter1++) arraySelectedMap1 [selectedMapCount1] = arrayMapTemp [counter1], selectedMapCount1++;
                delete [] arrayMapTemp;
                
                wellDataSaveRequest = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [self setNeedsDisplay:YES];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Select A Well"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Set Corner 1"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

//----Mouse Down----
-(void)mouseDown:(NSEvent *)event{
    if (drawingPermit1 == 1){
        NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
        int magnificationSwitchFlag = 0;
        
        xPointDown = clickPoint.x;
        yPointDown = clickPoint.y;
        
        if (pressSflag == 0){
            //CHAMBER**********LABEL CRICK AND GET WELL NO, ADD CHAMBER TYPE NO, ARRANGE BASED ON THE WELL NO**********************************
            if (labelPositionCount1 == chamberWellLimit1*2 && (chamberType1 == 1 || chamberType1 == 4)){
                if (xPointDown >= arrayLabelPosition1 [0] && xPointDown <= arrayLabelPosition1 [0]+40){
                    if (yPointDown >= arrayLabelPosition1 [1] && yPointDown <= arrayLabelPosition1 [1]+15){
                        if (magnificationWell == 0) magnificationWell = 1, magnificationSwitchFlag = 1;
                        else if (magnificationWell == 1) magnificationWell = 0, magnificationSwitchFlag = 1;
                    }
                }
                
                if (xPointDown >= arrayLabelPosition1 [2] && xPointDown <= arrayLabelPosition1 [2]+40){
                    if (yPointDown >= arrayLabelPosition1 [3] && yPointDown <= arrayLabelPosition1 [3]+15){
                        if (magnificationWell == 0) magnificationWell = 2, magnificationSwitchFlag = 1;
                        else if (magnificationWell == 2) magnificationWell = 0, magnificationSwitchFlag = 1;
                    }
                }
                
                if (xPointDown >= arrayLabelPosition1 [4] && xPointDown <= arrayLabelPosition1 [4]+40){
                    if (yPointDown >= arrayLabelPosition1 [5] && yPointDown <= arrayLabelPosition1 [5]+15){
                        if (magnificationWell == 0) magnificationWell = 3, magnificationSwitchFlag = 1;
                        else if (magnificationWell == 3) magnificationWell = 0, magnificationSwitchFlag = 1;
                    }
                }
                
                if (xPointDown >= arrayLabelPosition1 [6] && xPointDown <= arrayLabelPosition1 [6]+40){
                    if (yPointDown >= arrayLabelPosition1 [7] && yPointDown <= arrayLabelPosition1 [7]+15){
                        if (magnificationWell == 0) magnificationWell = 4, magnificationSwitchFlag = 1;
                        else if (magnificationWell == 4) magnificationWell = 0, magnificationSwitchFlag = 1;
                    }
                }
                
                if (xPointDown >= arrayLabelPosition1 [8] && xPointDown <= arrayLabelPosition1 [8]+40){
                    if (yPointDown >= arrayLabelPosition1 [9] && yPointDown <= arrayLabelPosition1 [9]+15){
                        if (magnificationWell == 0) magnificationWell = 5, magnificationSwitchFlag = 1;
                        else if (magnificationWell == 5) magnificationWell = 0, magnificationSwitchFlag = 1;
                    }
                }
                
                if (xPointDown >= arrayLabelPosition1 [10] && xPointDown <= arrayLabelPosition1 [10]+40){
                    if (yPointDown >= arrayLabelPosition1 [11] && yPointDown <= arrayLabelPosition1 [11]+15){
                        if (magnificationWell == 0) magnificationWell = 6, magnificationSwitchFlag = 1;
                        else if (magnificationWell == 6) magnificationWell = 0, magnificationSwitchFlag = 1;
                    }
                }
                
                if (xPointDown >= arrayLabelPosition1 [12] && xPointDown <= arrayLabelPosition1 [12]+40){
                    if (yPointDown >= arrayLabelPosition1 [13] && yPointDown <= arrayLabelPosition1 [13]+15){
                        if (magnificationWell == 0) magnificationWell = 7, magnificationSwitchFlag = 1;
                        else if (magnificationWell == 7) magnificationWell = 0, magnificationSwitchFlag = 1;
                    }
                }
                
                if (xPointDown >= arrayLabelPosition1 [14] && xPointDown <= arrayLabelPosition1 [14]+40){
                    if (yPointDown >= arrayLabelPosition1 [15] && yPointDown <= arrayLabelPosition1 [15]+15){
                        if (magnificationWell == 0) magnificationWell = 8, magnificationSwitchFlag = 1;
                        else if (magnificationWell == 8) magnificationWell = 0, magnificationSwitchFlag = 1;
                    }
                }
                
                if (magnificationSwitchFlag == 1) labelPositionCount1 = 0;
                
                [self setNeedsDisplay:YES];
            }
            else if (labelPositionCount1 == chamberWellLimit1*2 && chamberType1 == 2){
                if (xPointDown >= arrayLabelPosition1 [0] && xPointDown <= arrayLabelPosition1 [0]+40){
                    if (yPointDown >= arrayLabelPosition1 [1] && yPointDown <= arrayLabelPosition1 [1]+15){
                        if (magnificationWell == 0) magnificationWell = 1, magnificationSwitchFlag = 1;
                        else if (magnificationWell == 1) magnificationWell = 0, magnificationSwitchFlag = 1;
                    }
                }
                
                if (xPointDown >= arrayLabelPosition1 [2] && xPointDown <= arrayLabelPosition1 [2]+40){
                    if (yPointDown >= arrayLabelPosition1 [3] && yPointDown <= arrayLabelPosition1 [3]+15){
                        if (magnificationWell == 0) magnificationWell = 2, magnificationSwitchFlag = 1;
                        else if (magnificationWell == 2) magnificationWell = 0, magnificationSwitchFlag = 1;
                    }
                }
                
                if (magnificationSwitchFlag == 1) labelPositionCount1 = 0;
                
                [self setNeedsDisplay:YES];
            }
            else if (labelPositionCount1 == chamberWellLimit1*2 && chamberType1 == 3){
                if (xPointDown >= arrayLabelPosition1 [0] && xPointDown <= arrayLabelPosition1 [0]+40){
                    if (yPointDown >= arrayLabelPosition1 [1] && yPointDown <= arrayLabelPosition1 [1]+15){
                        if (magnificationWell == 0) magnificationWell = 1, magnificationSwitchFlag = 1;
                        else if (magnificationWell == 1) magnificationWell = 0, magnificationSwitchFlag = 1;
                    }
                }
                
                if (xPointDown >= arrayLabelPosition1 [2] && xPointDown <= arrayLabelPosition1 [2]+40){
                    if (yPointDown >= arrayLabelPosition1 [3] && yPointDown <= arrayLabelPosition1 [3]+15){
                        if (magnificationWell == 0) magnificationWell = 2, magnificationSwitchFlag = 1;
                        else if (magnificationWell == 2) magnificationWell = 0, magnificationSwitchFlag = 1;
                    }
                }
                
                if (xPointDown >= arrayLabelPosition1 [4] && xPointDown <= arrayLabelPosition1 [4]+40){
                    if (yPointDown >= arrayLabelPosition1 [5] && yPointDown <= arrayLabelPosition1 [5]+15){
                        if (magnificationWell == 0) magnificationWell = 3, magnificationSwitchFlag = 1;
                        else if (magnificationWell == 3) magnificationWell = 0, magnificationSwitchFlag = 1;
                    }
                }
                
                if (xPointDown >= arrayLabelPosition1 [6] && xPointDown <= arrayLabelPosition1 [6]+40){
                    if (yPointDown >= arrayLabelPosition1 [7] && yPointDown <= arrayLabelPosition1 [7]+15){
                        if (magnificationWell == 0) magnificationWell = 4, magnificationSwitchFlag = 1;
                        else if (magnificationWell == 4) magnificationWell = 0, magnificationSwitchFlag = 1;
                    }
                }
                
                if (magnificationSwitchFlag == 1) labelPositionCount1 = 0;
                
                [self setNeedsDisplay:YES];
            }
            else if (labelPositionCount1 == chamberWellLimit1*2 && chamberType1 == 5){
                if (xPointDown >= arrayLabelPosition1 [0] && xPointDown <= arrayLabelPosition1 [0]+40){
                    if (yPointDown >= arrayLabelPosition1 [1] && yPointDown <= arrayLabelPosition1 [1]+15){
                        if (magnificationWell == 0) magnificationWell = 1, magnificationSwitchFlag = 1;
                        else if (magnificationWell == 1) magnificationWell = 0, magnificationSwitchFlag = 1;
                    }
                }
                
                if (xPointDown >= arrayLabelPosition1 [2] && xPointDown <= arrayLabelPosition1 [2]+40){
                    if (yPointDown >= arrayLabelPosition1 [3] && yPointDown <= arrayLabelPosition1 [3]+15){
                        if (magnificationWell == 0) magnificationWell = 2, magnificationSwitchFlag = 1;
                        else if (magnificationWell == 2) magnificationWell = 0, magnificationSwitchFlag = 1;
                    }
                }
                
                if (xPointDown >= arrayLabelPosition1 [4] && xPointDown <= arrayLabelPosition1 [4]+40){
                    if (yPointDown >= arrayLabelPosition1 [5] && yPointDown <= arrayLabelPosition1 [5]+15){
                        if (magnificationWell == 0) magnificationWell = 3, magnificationSwitchFlag = 1;
                        else if (magnificationWell == 3) magnificationWell = 0, magnificationSwitchFlag = 1;
                    }
                }
                
                if (xPointDown >= arrayLabelPosition1 [6] && xPointDown <= arrayLabelPosition1 [6]+40){
                    if (yPointDown >= arrayLabelPosition1 [7] && yPointDown <= arrayLabelPosition1 [7]+15){
                        if (magnificationWell == 0) magnificationWell = 4, magnificationSwitchFlag = 1;
                        else if (magnificationWell == 4) magnificationWell = 0, magnificationSwitchFlag = 1;
                    }
                }
                
                if (xPointDown >= arrayLabelPosition1 [8] && xPointDown <= arrayLabelPosition1 [8]+40){
                    if (yPointDown >= arrayLabelPosition1 [9] && yPointDown <= arrayLabelPosition1 [9]+15){
                        if (magnificationWell == 0) magnificationWell = 5, magnificationSwitchFlag = 1;
                        else if (magnificationWell == 5) magnificationWell = 0, magnificationSwitchFlag = 1;
                    }
                }
                
                if (xPointDown >= arrayLabelPosition1 [10] && xPointDown <= arrayLabelPosition1 [10]+40){
                    if (yPointDown >= arrayLabelPosition1 [11] && yPointDown <= arrayLabelPosition1 [11]+15){
                        if (magnificationWell == 0) magnificationWell = 6, magnificationSwitchFlag = 1;
                        else if (magnificationWell == 6) magnificationWell = 0, magnificationSwitchFlag = 1;
                    }
                }
                
                if (magnificationSwitchFlag == 1) labelPositionCount1 = 0;
                
                [self setNeedsDisplay:YES];
            }
        }
        
        if (pressSflag == 1){
            xClickCurrent = xPointDown;
            yClickCurrent = yPointDown;
            pressSflag = 0;
            
            [self setNeedsDisplay:YES];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Set Corner 1"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

//----Image Draw----
-(void)drawRect:(NSRect)rect {
    //----Clear background----
    NSBezierPath *path;
    [NSBezierPath setDefaultLineWidth:0];
    
    path = [NSBezierPath bezierPathWithRect: NSMakeRect(5, 5, 1047-10, 537-10)];
    [[NSColor colorWithCalibratedRed:0.2 green:0.7 blue:0.2 alpha:0.3] set];
    [path fill];
    
    //for (int counterA = 0; counterA < readingPositionMDACount/7; counterA++){
    //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayReadingPositionMDA [counterA*7+counterB];
    //    cout<<" arrayReadingPositionMDA "<<counterA<<" "<<endl;
    //}
    
    double objectAdjustment = 0;
    int objectSizeAdjust = 0;
    
    if (objectiveSelect == 1){
        objectAdjustment = 1;
        objectSizeAdjust = 480;
    }
    else if (objectiveSelect == 2){
        objectAdjustment = 0.52084;
        objectSizeAdjust = 240;
    }
    else if (objectiveSelect == 3){
        objectAdjustment = 0.25958;
        objectSizeAdjust = 120;
    }
    
    double cameraAdjustment = 0;
    
    if (cameraDimension == 512){
        cameraAdjustment = 1;
    }
    else if (cameraDimension == 1024){
        cameraAdjustment = 2;
    }
    else if (cameraDimension == 1536){
        cameraAdjustment = 3;
    }
    else if (cameraDimension == 2048){
        cameraAdjustment = 4;
    }
    
    //----Position Setting Mode----
    if (drawingPermit1 == 1){
        
        //CHAMBER**********ADD PROCESSING METHODS, COPY FOLLOWING METHODS (MAP 1)**********************************
        if (chamberType1 == 1){
            double gridIncrement = 5.0;
            
            NSPoint positionA;
            NSPoint positionB;
            
            //----Standard view Limit----
            double xLowest = arrayWellPosition1 [0]-2186;
            double yLowest = arrayWellPosition1 [15]-2186;
            double xHighest = arrayWellPosition1 [6]+10500+2186;
            double yHighest = arrayWellPosition1 [1]+8332+2186;
            
            //----Magnified well Limit----
            if (magnificationWell == 1){
                xLowest = arrayWellPosition1 [0];
                yLowest = arrayWellPosition1 [1];
                xHighest = arrayWellPosition1 [0]+10500;
                yHighest = arrayWellPosition1 [1]+8332;
            }
            
            if (magnificationWell == 2){
                xLowest = arrayWellPosition1 [2];
                yLowest = arrayWellPosition1 [3];
                xHighest = arrayWellPosition1 [2]+10500;
                yHighest = arrayWellPosition1 [3]+8332;
            }
            
            if (magnificationWell == 3){
                xLowest = arrayWellPosition1 [4];
                yLowest = arrayWellPosition1 [5];
                xHighest = arrayWellPosition1 [4]+10500;
                yHighest = arrayWellPosition1 [5]+8332;
            }
            
            if (magnificationWell == 4){
                xLowest = arrayWellPosition1 [6];
                yLowest = arrayWellPosition1 [7];
                xHighest = arrayWellPosition1 [6]+10500;
                yHighest = arrayWellPosition1 [7]+8332;
            }
            
            if (magnificationWell == 5){
                xLowest = arrayWellPosition1 [8];
                yLowest = arrayWellPosition1 [9];
                xHighest = arrayWellPosition1 [8]+10500;
                yHighest = arrayWellPosition1 [9]+8332;
            }
            
            if (magnificationWell == 6){
                xLowest = arrayWellPosition1 [10];
                yLowest = arrayWellPosition1 [11];
                xHighest = arrayWellPosition1 [10]+10500;
                yHighest = arrayWellPosition1 [11]+8332;
            }
            
            if (magnificationWell == 7){
                xLowest = arrayWellPosition1 [12];
                yLowest = arrayWellPosition1 [13];
                xHighest = arrayWellPosition1 [12]+10500;
                yHighest = arrayWellPosition1 [13]+8332;
            }
            
            if (magnificationWell == 8){
                xLowest = arrayWellPosition1 [14];
                yLowest = arrayWellPosition1 [15];
                xHighest = arrayWellPosition1 [14]+10500;
                yHighest = arrayWellPosition1 [15]+8332;
            }
            
            //----Grid set----
            double xLength = xHighest-xLowest;
            double yLength = yHighest-yLowest;
            double gridOriginal = 0;
            double xGrid = 1;
            double yGrid = 1;
            
            double xGridTemp = xLength/512+10;
            double xGridTemp2 = (1047-10)/(double)xGridTemp;
            double yGridTemp = yLength/512+10;
            double yGridTemp2 = (537-10)/(double)yGridTemp;
            
            if (xGridTemp2 > yGridTemp2){
                gridOriginal = yGridTemp2;
                xGrid = (1047-10)/((537-10)/(double)yGridTemp);
                yGrid = yGridTemp;
            }
            
            if (xGridTemp2 <= yGridTemp2){
                gridOriginal = xGridTemp2;
                xGrid = xGridTemp;
                yGrid = (537-10)/((1047-10)/(double)xGridTemp);
            }
            
            if (xGrid == 0 && yGrid == 0){
                xGrid = 1;
                yGrid = 1;
            }
            
            //----Data sheet Drawing Horizontal lines----
            [NSBezierPath setDefaultLineWidth:0.5];
            [[NSColor blackColor] set];
            
            for (int counter1 = 0; counter1 <= yGrid; counter1++){
                positionA.x = 5.0;
                positionA.y = gridIncrement;
                positionB.x = 1047-5;
                positionB.y = gridIncrement;
                [NSBezierPath strokeLineFromPoint:positionA toPoint:positionB];
                gridIncrement = gridIncrement+gridOriginal;
            }
            
            //----Data sheet Drawing Vertical Lines----
            gridIncrement = 5.0;
            
            for (int counter1 = 0; counter1 <= xGrid; counter1++){
                positionA.x = gridIncrement;
                positionA.y = 5.0;
                positionB.x = gridIncrement;
                positionB.y = 537-5;
                [NSBezierPath strokeLineFromPoint:positionA toPoint:positionB];
                gridIncrement = gridIncrement+gridOriginal;
            }
            
            //----Base FOV and side number display----
            int xFirstBlock = 0;
            int yFirstBlock = 0;
            
            double constant1 = 1/(double)512;
            double constant2 = 5+gridOriginal*5;
            
            NSAttributedString *attrStr1;
            NSMutableDictionary *attributes1 = [NSMutableDictionary dictionary];
            [attributes1 setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            
            [NSBezierPath setDefaultLineWidth:2];
            
            int firstFind = 0;
            int horizontalCount = 0;
            int verticalCount = 0;
            double fontSize = 0;
            
            for (int counter1 = 1; counter1 <= 8; counter1++){
                firstFind = 0;
                horizontalCount = 0;
                verticalCount = 0;
                
                for (int counter2 = 0; counter2 < readingPositionMDACount/7; counter2++){
                    if (counter1 == arrayReadingPositionMDA [counter2*7]){
                        if (firstFind == 0){
                            firstFind = 1;
                            xFirstBlock = (int)arrayReadingPositionMDA [counter2*7+4];
                            yFirstBlock = (int)arrayReadingPositionMDA [counter2*7+5];
                        }
                        
                        //----MDA memorized display---
                        path = [NSBezierPath bezierPathWithRect: NSMakeRect((arrayReadingPositionMDA [counter2*7+4]-xLowest)*constant1*gridOriginal+constant2, (arrayReadingPositionMDA [counter2*7+5]-yLowest)*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                        
                        [[NSColor colorWithCalibratedRed:0.5 green:0.5 blue:0.7 alpha:0.5] set];
                        [path stroke];
                        
                        //----Vertical labe----
                        if (xFirstBlock-xLowest >= arrayReadingPositionMDA [counter2*7+4]-xLowest-10 && xFirstBlock-xLowest <= arrayReadingPositionMDA [counter2*7+4]-xLowest+10 && magnificationWell != 0){
                            verticalCount++;
                            
                            if (objectiveSelect == 1) fontSize = 12*cameraAdjustment;
                            else if (objectiveSelect == 2) fontSize = 10*cameraAdjustment;
                            else fontSize = 8*cameraAdjustment;
                            
                            [attributes1 setObject:[NSFont systemFontOfSize:(fontSize)] forKey:NSFontAttributeName];
                            
                            attrStr1 = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat : @"%d", verticalCount] attributes:attributes1];
                            
                            if (objectiveSelect == 1){
                                positionA.x = (xFirstBlock-xLowest)*constant1*gridOriginal+constant2-15;
                                positionA.y = (arrayReadingPositionMDA [counter2*7+5]-yLowest)*constant1*gridOriginal+constant2;
                            }
                            else if (objectiveSelect == 2){
                                positionA.x = (xFirstBlock-xLowest)*constant1*gridOriginal+constant2-10;
                                positionA.y = (arrayReadingPositionMDA [counter2*7+5]-yLowest)*constant1*gridOriginal+constant2;
                            }
                            else{
                                
                                positionA.x = (xFirstBlock-xLowest)*constant1*gridOriginal+constant2-8;
                                positionA.y = (arrayReadingPositionMDA [counter2*7+5]-yLowest)*constant1*gridOriginal+constant2;
                            }
                            
                            [attrStr1 drawAtPoint:positionA];
                        }
                        
                        //----Horizontal labe----
                        if (yFirstBlock-yLowest >= arrayReadingPositionMDA [counter2*7+5]-yLowest-10 && yFirstBlock-yLowest <= arrayReadingPositionMDA [counter2*7+5]-yLowest+10 && magnificationWell != 0){
                            horizontalCount++;
                            
                            if (objectiveSelect == 1) fontSize = 12*cameraAdjustment;
                            else if (objectiveSelect == 2) fontSize = 10*cameraAdjustment;
                            else fontSize = 8*cameraAdjustment;
                            
                            [attributes1 setObject:[NSFont systemFontOfSize:(fontSize)] forKey:NSFontAttributeName];
                            
                            attrStr1 = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat : @"%d", horizontalCount] attributes:attributes1];
                            
                            if (objectiveSelect == 1){
                                positionA.x = (arrayReadingPositionMDA [counter2*7+4]-xLowest)*constant1*gridOriginal+constant2+8;
                                positionA.y = (yFirstBlock-yLowest)*constant1*gridOriginal+constant2-15;
                            }
                            else if (objectiveSelect == 2){
                                positionA.x = (arrayReadingPositionMDA [counter2*7+4]-xLowest)*constant1*gridOriginal+constant2;
                                positionA.y = (yFirstBlock-yLowest)*constant1*gridOriginal+constant2-10;
                            }
                            else{
                                
                                positionA.x = (arrayReadingPositionMDA [counter2*7+4]-xLowest)*constant1*gridOriginal+constant2;
                                positionA.y = (yFirstBlock-yLowest)*constant1*gridOriginal+constant2-8;
                            }
                            
                            [attrStr1 drawAtPoint:positionA];
                        }
                    }
                }
            }
            
            //----XY Position writing----
            double xPositionCurrent2 = xPositionCurrent-xLowest;
            double yPositionCurrent2 = yPositionCurrent-yLowest;
            
            if (xPositionCurrent != 0 && yPositionCurrent != 0){
                [NSBezierPath setDefaultLineWidth:0];
                
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionCurrent2*constant1*gridOriginal+constant2, yPositionCurrent2*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                
                [[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] set];
                [path fill];
            }
            
            //----Label Display----
            double xGridOriginal = gridOriginal*10500/(double)512;
            double yGridOriginal = gridOriginal*8332/(double)512+gridOriginal;
            
            double constant3 = ((8332+1000)/(double)512)*gridOriginal;
            double constant4 = (1400/(double)512)*gridOriginal;
            
            [NSBezierPath setDefaultLineWidth:2];
            
            double xPositionWell = 0;
            double yPositionWell = 0;
            
            for (int counter1 = 1; counter1 <= 8; counter1++){
                xPositionWell = arrayWellPosition1 [(counter1-1)*2]-xLowest;
                yPositionWell = arrayWellPosition1 [(counter1-1)*2+1]-yLowest;
                
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionWell*constant1*gridOriginal+constant2, yPositionWell*constant1*gridOriginal+constant2, xGridOriginal, yGridOriginal)];
                
                if (magnificationWell == counter1) [[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] set];
                else [[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] set];
                
                [path stroke];
                
                [attributes1 setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                [attributes1 setObject:[NSColor blueColor] forKey: NSBackgroundColorAttributeName];
                [attributes1 setObject:[NSFont systemFontOfSize:(14)] forKey:NSFontAttributeName];
                
                if (counter1 == 1) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 1" attributes:attributes1];
                else if (counter1 == 2) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 2" attributes:attributes1];
                else if (counter1 == 3) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 3" attributes:attributes1];
                else if (counter1 == 4) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 4" attributes:attributes1];
                else if (counter1 == 5) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 5" attributes:attributes1];
                else if (counter1 == 6) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 6" attributes:attributes1];
                else if (counter1 == 7) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 7" attributes:attributes1];
                else if (counter1 == 8) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 8" attributes:attributes1];
                
                if (counter1 >= 1 && counter1 <= 4){
                    positionA.x = xPositionWell*constant1*gridOriginal+constant2;
                    positionA.y = yPositionWell*constant1*gridOriginal+constant2+constant3;
                }
                
                if (counter1 >= 5 && counter1 <= 8){
                    positionA.x = xPositionWell*constant1*gridOriginal+constant2;
                    positionA.y = yPositionWell*constant1*gridOriginal+constant2-constant4;
                }
                
                [attrStr1 drawAtPoint:positionA];
                
                if (labelPositionCount1 <= 14){
                    if (counter1 >= 1 && counter1 <= 4){
                        arrayLabelPosition1 [labelPositionCount1] = xPositionWell*constant1*gridOriginal+constant2, labelPositionCount1++;
                        arrayLabelPosition1 [labelPositionCount1] = yPositionWell*constant1*gridOriginal+constant2+constant3, labelPositionCount1++;
                    }
                    
                    if (counter1 >= 5 && counter1 <= 8){
                        arrayLabelPosition1 [labelPositionCount1] = xPositionWell*constant1*gridOriginal+constant2, labelPositionCount1++;
                        arrayLabelPosition1 [labelPositionCount1] = yPositionWell*constant1*gridOriginal+constant2-constant4, labelPositionCount1++;
                    }
                }
            }
            
            //----Outside Frame display----
            xPositionWell = arrayWellPosition1 [16]-xLowest;
            yPositionWell = arrayWellPosition1 [17]-yLowest;
            
            xGridOriginal = gridOriginal*(10500*4+2186*5)/(double)512;
            yGridOriginal = gridOriginal*(8332*2+2186*3)/(double)512+gridOriginal;
            
            [NSBezierPath setDefaultLineWidth:2];
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionWell*constant1*gridOriginal+constant2, yPositionWell*constant1*gridOriginal+constant2, xGridOriginal, yGridOriginal)];
            [[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] set];
            [path stroke];
            
            //----Press S----
            if (pressSflag == 1 && magnificationWell != 0){
                [attributes1 setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                [attributes1 setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
                [attributes1 setObject:[NSFont systemFontOfSize:(14)] forKey:NSFontAttributeName];
                attrStr1 = [[NSAttributedString alloc] initWithString:@"Click First FOV" attributes:attributes1];
                
                positionA.x = 10;
                positionA.y = 10;
                [attrStr1 drawAtPoint:positionA];
            }
            
            //----Select FOV, Press S----
            double xMatchFound = 0;
            double yMatchFound = 0;
            double zMatchFound = 0;
            int matchFindFlag = 0;
            
            if (xClickCurrent != 0 && yClickCurrent != 0 && magnificationWell != 0){
                for (int counter1 = 0; counter1 < readingPositionMDACount/7; counter1++){
                    if (arrayReadingPositionMDA [counter1*7] == magnificationWell){
                        if (xClickCurrent >= (arrayReadingPositionMDA [counter1*7+4]-xLowest)*constant1*gridOriginal+constant2 && (arrayReadingPositionMDA [counter1*7+4]-xLowest)*constant1*gridOriginal+constant2+gridOriginal*objectAdjustment*cameraAdjustment >= xClickCurrent){
                            if (yClickCurrent >= (arrayReadingPositionMDA [counter1*7+5]-yLowest)*constant1*gridOriginal+constant2 && (arrayReadingPositionMDA [counter1*7+5]-yLowest)*constant1*gridOriginal+constant2+gridOriginal*objectAdjustment*cameraAdjustment >= yClickCurrent){
                                xMatchFound = arrayReadingPositionMDA [counter1*7+4];
                                yMatchFound = arrayReadingPositionMDA [counter1*7+5];
                                zMatchFound = arrayReadingPositionMDA [counter1*7+6];
                                matchFindFlag = 1;
                                break;
                            }
                        }
                    }
                }
                
                xClickCurrent = 0;
                yClickCurrent = 0;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            
            //----Save XYZ position into array----
            if (matchFindFlag == 1){
                double *arrayMapTemp = new double [selectedMapCount1+50];
                int mapTempCount = 0;
                
                if (xFOVTaken != 0 && yFOVTaken != 0){
                    for (int counter1 = 0; counter1 < selectedMapCount1/6; counter1++){
                        if (arraySelectedMap1 [counter1*6] != magnificationWell){
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+1], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+2], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+3], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+4], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+5], mapTempCount++;
                        }
                    }
                    
                    selectedMapCount1 = 0;
                    
                    for (int counter1 = 0; counter1 < mapTempCount; counter1++) arraySelectedMap1 [selectedMapCount1] = arrayMapTemp [counter1], selectedMapCount1++;
                    
                    double *arrayMapTemp2 = new double [xFOVTaken*yFOVTaken*7+50];
                    double *arrayMapTemp3 = new double [xFOVTaken*yFOVTaken*7+50];
                    int arrayMapTempCount2 = 0;
                    int arrayMapTempCount3 = 0;
                    
                    for (int counter1 = 1; counter1 <= xFOVTaken; counter1++){
                        for (int counter2 = 1; counter2 <= yFOVTaken; counter2++){
                            arrayMapTemp2 [arrayMapTempCount2] = magnificationWell, arrayMapTempCount2++;
                            
                            if (drawingOrientation == 0){
                                arrayMapTemp2 [arrayMapTempCount2] = counter1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = counter2, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = xMatchFound+(counter1-1)*objectSizeAdjust*cameraAdjustment, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yMatchFound+(counter2-1)*objectSizeAdjust*cameraAdjustment, arrayMapTempCount2++;
                            }
                            else  if (drawingOrientation == 1){
                                arrayMapTemp2 [arrayMapTempCount2] = xFOVTaken-counter1+1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = counter2, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = xMatchFound+(counter1*-1+1)*objectSizeAdjust*cameraAdjustment*cameraAdjustment, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yMatchFound+(counter2-1)*objectSizeAdjust*cameraAdjustment, arrayMapTempCount2++;
                            }
                            else  if (drawingOrientation == 2){
                                arrayMapTemp2 [arrayMapTempCount2] = counter1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yFOVTaken-counter2+1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = xMatchFound+(counter1-1)*objectSizeAdjust*cameraAdjustment, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yMatchFound+(counter2*-1+1)*objectSizeAdjust*cameraAdjustment, arrayMapTempCount2++;
                            }
                            else  if (drawingOrientation == 3){
                                arrayMapTemp2 [arrayMapTempCount2] = xFOVTaken-counter1+1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yFOVTaken-counter2+1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = xMatchFound+(counter1*-1+1)*objectSizeAdjust*cameraAdjustment, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yMatchFound+(counter2*-1+1)*objectSizeAdjust*cameraAdjustment*cameraAdjustment, arrayMapTempCount2++;
                            }
                            
                            arrayMapTemp2 [arrayMapTempCount2] = zMatchFound, arrayMapTempCount2++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < arrayMapTempCount2/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayMapTemp2 [counterA*6+counterB];
                    //    cout<<" arrayMapTemp2 "<<counterA+1<<" "<<endl;
                    //}
                    
                    for (int counter1 = 1; counter1 <= xFOVTaken; counter1++){
                        for (int counter2 = 0; counter2 < arrayMapTempCount2/6; counter2++){
                            if (arrayMapTemp2 [counter2*6+1] == counter1){
                                for (int counter3 = 1; counter3 <= yFOVTaken; counter3++){
                                    for (int counter4 = 0; counter4 < arrayMapTempCount2/6; counter4++){
                                        if (arrayMapTemp2 [counter4*6+1] == counter1 && arrayMapTemp2 [counter4*6+2] == counter3){
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+1], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+2], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+3], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+4], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+5], arrayMapTempCount3++;
                                            break;
                                        }
                                    }
                                }
                                
                                break;
                            }
                        }
                    }
                    
                    if (selectedMapCount1+arrayMapTempCount3 > selectedMapLimit1){
                        selectedMapAddition1 = arrayMapTempCount3;
                        [self selectedMapUpDate1];
                    }
                    
                    for (int counter1 = 0; counter1 < arrayMapTempCount3; counter1++) arraySelectedMap1 [selectedMapCount1] = arrayMapTemp3 [counter1], selectedMapCount1++;
                    
                    delete [] arrayMapTemp2;
                    delete [] arrayMapTemp3;
                    
                    wellDataSaveRequest = 1;
                }
                
                delete [] arrayMapTemp;
            }
            
            //for (int counterA = 0; counterA < selectedMapCount1/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arraySelectedMap1 [counterA*6+counterB];
            //    cout<<" arraySelectedMap1 "<<counterA+1<<" "<<endl;
            //}
            
            //----Draw Selected FOVs----
            [[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] set];
            [NSBezierPath setDefaultLineWidth:0.7];
            
            for (int counter1 = 0; counter1 < selectedMapCount1/6 ; counter1++){
                path = [NSBezierPath bezierPathWithRect: NSMakeRect((arraySelectedMap1 [counter1*6+3]-xLowest)*constant1*gridOriginal+constant2, (arraySelectedMap1 [counter1*6+4]-yLowest)*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                
                [path stroke];
            }
            
            //----Draw Snap Position----
            for (int counter1 = 0; counter1 < snapMainDataCount/16; counter1++){
                
                if (snapPage*2-1 == arraySnapMainData [counter1*16]){
                    [[NSColor orangeColor] set];
                    path = [NSBezierPath bezierPathWithRect: NSMakeRect((arraySnapMainData [counter1*16+1]-xLowest)*constant1*gridOriginal+constant2, (arraySnapMainData [counter1*16+2]-yLowest)*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                }
                else{
                    
                    [[NSColor magentaColor] set];
                    path = [NSBezierPath bezierPathWithRect: NSMakeRect((arraySnapMainData [counter1*16+1]-xLowest)*constant1*gridOriginal+constant2, (arraySnapMainData [counter1*16+2]-yLowest)*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                }
                
                [path fill];
            }
        }
        else if (chamberType1 == 2){
            double gridIncrement = 5.0;
            
            NSPoint positionA;
            NSPoint positionB;
            
            //----Standard view Limit----
            double xLowest = arrayWellPosition1 [0]-2186; //CHAMBER**********RIGHT WELL**********************************
            double yLowest = arrayWellPosition1 [3]-2186; //CHAMBER**********RIGHT BOTTOM WELL**********************************
            double xHighest = arrayWellPosition1 [2]+22170+2186; //CHAMBER**********LEFT WELL, X-LENGTH OF WELL**********************************
            double yHighest = arrayWellPosition1 [1]+19687+2186; //CHAMBER**********LEFT BOTTOM WELL, Y-LENGTH OF WELL**********************************
            
            //----Magnified well Limit----
            //CHAMBER**********WELL INFO, X-LENGTH ANF Y-LENGTH**********************************
            if (magnificationWell == 1){
                xLowest = arrayWellPosition1 [0];
                yLowest = arrayWellPosition1 [1];
                xHighest = arrayWellPosition1 [0]+22170;
                yHighest = arrayWellPosition1 [1]+19687;
            }
            
            if (magnificationWell == 2){
                xLowest = arrayWellPosition1 [2];
                yLowest = arrayWellPosition1 [3];
                xHighest = arrayWellPosition1 [2]+22170;
                yHighest = arrayWellPosition1 [3]+19687;
            }
            
            //----Grid set----
            double xLength = xHighest-xLowest;
            double yLength = yHighest-yLowest;
            double gridOriginal = 0;
            double xGrid = 1;
            double yGrid = 1;
            
            double xGridTemp = xLength/512+10;
            double xGridTemp2 = (1047-10)/(double)xGridTemp;
            double yGridTemp = yLength/512+10;
            double yGridTemp2 = (537-10)/(double)yGridTemp;
            
            if (xGridTemp2 > yGridTemp2){
                gridOriginal = yGridTemp2;
                xGrid = (1047-10)/((537-10)/(double)yGridTemp);
                yGrid = yGridTemp;
            }
            
            if (xGridTemp2 <= yGridTemp2){
                gridOriginal = xGridTemp2;
                xGrid = xGridTemp;
                yGrid = (537-10)/((1047-10)/(double)xGridTemp);
            }
            
            if (xGrid == 0 && yGrid == 0){
                xGrid = 1;
                yGrid = 1;
            }
            
            //----Data sheet Drawing Horizontal lines----
            [NSBezierPath setDefaultLineWidth:0.5];
            [[NSColor blackColor] set];
            
            for (int counter1 = 0; counter1 <= yGrid; counter1++){
                positionA.x = 5.0;
                positionA.y = gridIncrement;
                positionB.x = 1047-5;
                positionB.y = gridIncrement;
                [NSBezierPath strokeLineFromPoint:positionA toPoint:positionB];
                gridIncrement = gridIncrement+gridOriginal;
            }
            
            //----Data sheet Drawing Vertical Lines----
            gridIncrement = 5.0;
            
            for (int counter1 = 0; counter1 <= xGrid; counter1++){
                positionA.x = gridIncrement;
                positionA.y = 5.0;
                positionB.x = gridIncrement;
                positionB.y = 537-5;
                [NSBezierPath strokeLineFromPoint:positionA toPoint:positionB];
                gridIncrement = gridIncrement+gridOriginal;
            }
            
            //----Base FOV and side number display----
            int xFirstBlock = 0;
            int yFirstBlock = 0;
            
            double constant1 = 1/(double)512;
            double constant2 = 5+gridOriginal*5;
            
            NSAttributedString *attrStr1;
            NSMutableDictionary *attributes1 = [NSMutableDictionary dictionary];
            [attributes1 setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            
            [NSBezierPath setDefaultLineWidth:2];
            
            //for (int counterA = 0; counterA < readingPositionMDACount/7; counterA++){
            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayReadingPositionMDA [counterA*7+counterB];
            //	cout<<" arrayReadingPositionMDA "<<counterA<<" "<<endl;
            //}
            
            int firstFind = 0;
            int horizontalCount = 0;
            int verticalCount = 0;
            double fontSize = 0;
            
            for (int counter1 = 1; counter1 <= 2; counter1++){
                firstFind = 0;
                horizontalCount = 0;
                verticalCount = 0;
                
                for (int counter2 = 0; counter2 < readingPositionMDACount/7; counter2++){
                    if (counter1 == arrayReadingPositionMDA [counter2*7]){
                        if (firstFind == 0){
                            firstFind = 1;
                            xFirstBlock = (int)arrayReadingPositionMDA [counter2*7+4];
                            yFirstBlock = (int)arrayReadingPositionMDA [counter2*7+5];
                        }
                        
                        path = [NSBezierPath bezierPathWithRect: NSMakeRect((arrayReadingPositionMDA [counter2*7+4]-xLowest)*constant1*gridOriginal+constant2, (arrayReadingPositionMDA [counter2*7+5]-yLowest)*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                        
                        [[NSColor colorWithCalibratedRed:0.5 green:0.5 blue:0.7 alpha:0.5] set];
                        [path stroke];
                        
                        if (xFirstBlock-xLowest >= arrayReadingPositionMDA [counter2*7+4]-xLowest-10 && xFirstBlock-xLowest <= arrayReadingPositionMDA [counter2*7+4]-xLowest+10 && magnificationWell != 0){
                            verticalCount++;
                            
                            if (objectiveSelect == 1) fontSize = 12*cameraAdjustment;
                            else if (objectiveSelect == 2) fontSize = 10*cameraAdjustment;
                            else fontSize = 8*cameraAdjustment;
                            
                            [attributes1 setObject:[NSFont systemFontOfSize:(fontSize)] forKey:NSFontAttributeName];
                            
                            attrStr1 = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat : @"%d", verticalCount] attributes:attributes1];
                            
                            if (objectiveSelect == 1){
                                positionA.x = (xFirstBlock-xLowest)*constant1*gridOriginal+constant2-15;
                                positionA.y = (arrayReadingPositionMDA [counter2*7+5]-yLowest)*constant1*gridOriginal+constant2;
                            }
                            else if (objectiveSelect == 2){
                                positionA.x = (xFirstBlock-xLowest)*constant1*gridOriginal+constant2-10;
                                positionA.y = (arrayReadingPositionMDA [counter2*7+5]-yLowest)*constant1*gridOriginal+constant2;
                            }
                            else{
                                
                                positionA.x = (xFirstBlock-xLowest)*constant1*gridOriginal+constant2-8;
                                positionA.y = (arrayReadingPositionMDA [counter2*7+5]-yLowest)*constant1*gridOriginal+constant2;
                            }
                            
                            [attrStr1 drawAtPoint:positionA];
                        }
                        if (yFirstBlock-yLowest >= arrayReadingPositionMDA [counter2*7+5]-yLowest-10 && yFirstBlock-yLowest <= arrayReadingPositionMDA [counter2*7+5]-yLowest+10 && magnificationWell != 0){
                            horizontalCount++;
                            
                            if (objectiveSelect == 1) fontSize = 12*cameraAdjustment;
                            else if (objectiveSelect == 2) fontSize = 10*cameraAdjustment;
                            else fontSize = 8*cameraAdjustment;
                            
                            [attributes1 setObject:[NSFont systemFontOfSize:(fontSize)] forKey:NSFontAttributeName];
                            
                            attrStr1 = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat : @"%d", horizontalCount] attributes:attributes1];
                            
                            if (objectiveSelect == 1){
                                positionA.x = (arrayReadingPositionMDA [counter2*7+4]-xLowest)*constant1*gridOriginal+constant2+8;
                                positionA.y = (yFirstBlock-yLowest)*constant1*gridOriginal+constant2-15;
                            }
                            else if (objectiveSelect == 2){
                                positionA.x = (arrayReadingPositionMDA [counter2*7+4]-xLowest)*constant1*gridOriginal+constant2;
                                positionA.y = (yFirstBlock-yLowest)*constant1*gridOriginal+constant2-10;
                            }
                            else{
                                
                                positionA.x = (arrayReadingPositionMDA [counter2*7+4]-xLowest)*constant1*gridOriginal+constant2;
                                positionA.y = (yFirstBlock-yLowest)*constant1*gridOriginal+constant2-8;
                            }
                            
                            [attrStr1 drawAtPoint:positionA];
                        }
                    }
                }
            }
            
            //----XY Position writing----
            double xPositionCurrent2 = xPositionCurrent-xLowest;
            double yPositionCurrent2 = yPositionCurrent-yLowest;
            
            if (xPositionCurrent != 0 && yPositionCurrent != 0){
                [NSBezierPath setDefaultLineWidth:0];
                
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionCurrent2*constant1*gridOriginal+constant2, yPositionCurrent2*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                
                [[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] set];
                [path fill];
            }
            
            //----Label Display----
            //CHAMBER**********X-LENGTH AND Y-LENGTH CHANGE**********************************
            double xGridOriginal = gridOriginal*22170/(double)512;
            double yGridOriginal = gridOriginal*19687/(double)512+gridOriginal;
            
            double constant3 = ((19687+1000)/(double)512)*gridOriginal;
            //double constant4 = (1400/(double)512)*gridOriginal; //CHAMBER**********NEED FOR 8 WELL**********************************
            
            [NSBezierPath setDefaultLineWidth:2];
            
            double xPositionWell = 0;
            double yPositionWell = 0;
            
            for (int counter1 = 1; counter1 <= 2; counter1++){
                xPositionWell = arrayWellPosition1 [(counter1-1)*2]-xLowest;
                yPositionWell = arrayWellPosition1 [(counter1-1)*2+1]-yLowest;
                
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionWell*constant1*gridOriginal+constant2, yPositionWell*constant1*gridOriginal+constant2, xGridOriginal, yGridOriginal)];
                
                if (magnificationWell == counter1) [[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] set];
                else [[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] set];
                
                [path stroke];
                
                [attributes1 setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                [attributes1 setObject:[NSColor blueColor] forKey: NSBackgroundColorAttributeName];
                [attributes1 setObject:[NSFont systemFontOfSize:(14)] forKey:NSFontAttributeName];
                
                if (counter1 == 1) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 1" attributes:attributes1];
                else if (counter1 == 2) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 2" attributes:attributes1];
                if (counter1 >= 1 && counter1 <= 2){ //CHAMBER**********NO OF WELL, CHANGE**********************************
                    positionA.x = xPositionWell*constant1*gridOriginal+constant2;
                    positionA.y = yPositionWell*constant1*gridOriginal+constant2+constant3;
                }
                //if (counter1 >= 5 && counter1 <= 8){ //CHAMBER**********NEED FOR 8 WELL**********************************
                //    positionA.x = xPositionWell*constant1*gridOriginal+constant2;
                //    positionA.y = yPositionWell*constant1*gridOriginal+constant2-constant4;
                //}
                
                [attrStr1 drawAtPoint:positionA];
                
                if (labelPositionCount1 <= 2){ //CHAMBER**********SET WELL NO*2-2**********************************
                    if (counter1 >= 1 && counter1 <= 2){
                        arrayLabelPosition1 [labelPositionCount1] = xPositionWell*constant1*gridOriginal+constant2, labelPositionCount1++;
                        arrayLabelPosition1 [labelPositionCount1] = yPositionWell*constant1*gridOriginal+constant2+constant3, labelPositionCount1++;
                    }
                    //if (counter1 >= 5 && counter1 <= 8){ //CHAMBER**********NEED FOR 8 WELL**********************************
                    //    arrayLabelPosition1 [labelPositionCount1] = xPositionWell*constant1*gridOriginal+constant2, labelPositionCount1++;
                    //    arrayLabelPosition1 [labelPositionCount1] = yPositionWell*constant1*gridOriginal+constant2-constant4, labelPositionCount1++;
                    //}
                }
            }
            
            //----Outside Frame display----
            xPositionWell = arrayWellPosition1 [4]-xLowest;
            yPositionWell = arrayWellPosition1 [5]-yLowest;
            
            xGridOriginal = gridOriginal*(22170*2+2597+2186*2)/(double)512; //CHAMBER**********X-LENGTH: 2186+(WELL X-LENGTH)*NO OF WELL (X)+(WALL LENGTH)*NO OF WALL+2186**********************************
            yGridOriginal = gridOriginal*(19687+2186*2)/(double)512+gridOriginal; //CHAMBER**********Y-LENGTH: 2186+(WELL Y-LENGTH)*NO OF WELL (Y)+(WALL LENGTH)*NO OF WALL+2186**********************************
            
            [NSBezierPath setDefaultLineWidth:2];
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionWell*constant1*gridOriginal+constant2, yPositionWell*constant1*gridOriginal+constant2, xGridOriginal, yGridOriginal)];
            [[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] set];
            [path stroke];
            
            //----Press S----
            if (pressSflag == 1 && magnificationWell != 0){
                [attributes1 setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                [attributes1 setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
                [attributes1 setObject:[NSFont systemFontOfSize:(14)] forKey:NSFontAttributeName];
                attrStr1 = [[NSAttributedString alloc] initWithString:@"Click First FOV" attributes:attributes1];
                positionA.x = 10;
                positionA.y = 10;
                [attrStr1 drawAtPoint:positionA];
            }
            
            //----Select FOV, Press S----
            double xMatchFound = 0;
            double yMatchFound = 0;
            double zMatchFound = 0;
            int matchFindFlag = 0;
            
            if (xClickCurrent != 0 && yClickCurrent != 0 && magnificationWell != 0){
                for (int counter1 = 0; counter1 < readingPositionMDACount/7; counter1++){
                    if (arrayReadingPositionMDA [counter1*7] == magnificationWell){
                        if (xClickCurrent >= (arrayReadingPositionMDA [counter1*7+4]-xLowest)*constant1*gridOriginal+constant2 && (arrayReadingPositionMDA [counter1*7+4]-xLowest)*constant1*gridOriginal+constant2+gridOriginal*objectAdjustment*cameraAdjustment >= xClickCurrent){
                            if (yClickCurrent >= (arrayReadingPositionMDA [counter1*7+5]-yLowest)*constant1*gridOriginal+constant2 && (arrayReadingPositionMDA [counter1*7+5]-yLowest)*constant1*gridOriginal+constant2+gridOriginal*objectAdjustment*cameraAdjustment >= yClickCurrent){
                                xMatchFound = arrayReadingPositionMDA [counter1*7+4];
                                yMatchFound = arrayReadingPositionMDA [counter1*7+5];
                                zMatchFound = arrayReadingPositionMDA [counter1*7+6];
                                matchFindFlag = 1;
                                break;
                            }
                        }
                    }
                }
                
                xClickCurrent = 0;
                yClickCurrent = 0;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            
            //----Save XYZ position into array----
            if (matchFindFlag == 1){
                double *arrayMapTemp = new double [selectedMapCount1+50];
                int mapTempCount = 0;
                
                if (xFOVTaken != 0 && yFOVTaken != 0){
                    for (int counter1 = 0; counter1 < selectedMapCount1/6; counter1++){
                        if (arraySelectedMap1 [counter1*6] != magnificationWell){
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+1], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+2], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+3], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+4], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+5], mapTempCount++;
                        }
                    }
                    
                    selectedMapCount1 = 0;
                    
                    for (int counter1 = 0; counter1 < mapTempCount; counter1++) arraySelectedMap1 [selectedMapCount1] = arrayMapTemp [counter1], selectedMapCount1++;
                    
                    double *arrayMapTemp2 = new double [xFOVTaken*yFOVTaken*7+50];
                    double *arrayMapTemp3 = new double [xFOVTaken*yFOVTaken*7+50];
                    int arrayMapTempCount2 = 0;
                    int arrayMapTempCount3 = 0;
                    
                    for (int counter1 = 1; counter1 <= xFOVTaken; counter1++){
                        for (int counter2 = 1; counter2 <= yFOVTaken; counter2++){
                            arrayMapTemp2 [arrayMapTempCount2] = magnificationWell, arrayMapTempCount2++;
                            
                            if (drawingOrientation == 0){
                                arrayMapTemp2 [arrayMapTempCount2] = counter1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = counter2, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = xMatchFound+(counter1-1)*objectSizeAdjust, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yMatchFound+(counter2-1)*objectSizeAdjust, arrayMapTempCount2++;
                            }
                            else  if (drawingOrientation == 1){
                                arrayMapTemp2 [arrayMapTempCount2] = xFOVTaken-counter1+1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = counter2, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = xMatchFound+(counter1*-1+1)*objectSizeAdjust, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yMatchFound+(counter2-1)*objectSizeAdjust, arrayMapTempCount2++;
                            }
                            else  if (drawingOrientation == 2){
                                arrayMapTemp2 [arrayMapTempCount2] = counter1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yFOVTaken-counter2+1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = xMatchFound+(counter1-1)*objectSizeAdjust, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yMatchFound+(counter2*-1+1)*objectSizeAdjust, arrayMapTempCount2++;
                            }
                            else  if (drawingOrientation == 3){
                                arrayMapTemp2 [arrayMapTempCount2] = xFOVTaken-counter1+1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yFOVTaken-counter2+1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = xMatchFound+(counter1*-1+1)*objectSizeAdjust, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yMatchFound+(counter2*-1+1)*objectSizeAdjust, arrayMapTempCount2++;
                            }
                            
                            arrayMapTemp2 [arrayMapTempCount2] = zMatchFound, arrayMapTempCount2++;
                            
                            // cout<<counter1<<" "<<counter2<<" "<<xMatchFound+(counter1-1)*240<<" "<<yMatchFound+(counter2-1)*240<<" "<<zMatchFound<<" SaveData"<<endl;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < arrayMapTempCount2/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayMapTemp2 [counterA*6+counterB];
                    //    cout<<" arrayMapTemp2 "<<counterA+1<<" "<<endl;
                    //}
                    
                    for (int counter1 = 1; counter1 <= xFOVTaken; counter1++){
                        for (int counter2 = 0; counter2 < arrayMapTempCount2/6; counter2++){
                            if (arrayMapTemp2 [counter2*6+1] == counter1){
                                for (int counter3 = 1; counter3 <= yFOVTaken; counter3++){
                                    for (int counter4 = 0; counter4 < arrayMapTempCount2/6; counter4++){
                                        if (arrayMapTemp2 [counter4*6+1] == counter1 && arrayMapTemp2 [counter4*6+2] == counter3){
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+1], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+2], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+3], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+4], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+5], arrayMapTempCount3++;
                                            break;
                                        }
                                    }
                                }
                                
                                break;
                            }
                        }
                    }
                    
                    if (selectedMapCount1+arrayMapTempCount3 > selectedMapLimit1){
                        selectedMapAddition1 = arrayMapTempCount3;
                        [self selectedMapUpDate1];
                    }
                    
                    for (int counter1 = 0; counter1 < arrayMapTempCount3; counter1++) arraySelectedMap1 [selectedMapCount1] = arrayMapTemp3 [counter1], selectedMapCount1++;
                    
                    delete [] arrayMapTemp2;
                    delete [] arrayMapTemp3;
                    
                    wellDataSaveRequest = 1;
                }
                
                delete [] arrayMapTemp;
            }
            
            //----Draw Selected FOVs----
            [[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] set];
            [NSBezierPath setDefaultLineWidth:0.7];
            
            for (int counter1 = 0; counter1 < selectedMapCount1/6 ; counter1++){
                path = [NSBezierPath bezierPathWithRect: NSMakeRect((arraySelectedMap1 [counter1*6+3]-xLowest)*constant1*gridOriginal+constant2, (arraySelectedMap1 [counter1*6+4]-yLowest)*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                
                [path stroke];
            }
            
            //----Draw Snap Position----
            for (int counter1 = 0; counter1 < snapMainDataCount/16; counter1++){
                if (snapPage*2-1 == arraySnapMainData [counter1*16]){
                    [[NSColor orangeColor] set];
                    path = [NSBezierPath bezierPathWithRect: NSMakeRect((arraySnapMainData [counter1*16+1]-xLowest)*constant1*gridOriginal+constant2, (arraySnapMainData [counter1*16+2]-yLowest)*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                }
                else{
                    
                    [[NSColor magentaColor] set];
                    path = [NSBezierPath bezierPathWithRect: NSMakeRect((arraySnapMainData [counter1*16+1]-xLowest)*constant1*gridOriginal+constant2, (arraySnapMainData [counter1*16+2]-yLowest)*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                }
                
                [path fill];
            }
        }
        else if (chamberType1 == 3){
            double gridIncrement = 5.0;
            
            NSPoint positionA;
            NSPoint positionB;
            
            //----Standard view Limit----
            double xLowest = arrayWellPosition1 [0]-2186;
            double yLowest = arrayWellPosition1 [7]-2186;
            double xHighest = arrayWellPosition1 [6]+9938+2186;
            double yHighest = arrayWellPosition1 [1]+19687+2186;
            
            //----Magnified well Limit----
            if (magnificationWell == 1){
                xLowest = arrayWellPosition1 [0];
                yLowest = arrayWellPosition1 [1];
                xHighest = arrayWellPosition1 [0]+9938;
                yHighest = arrayWellPosition1 [1]+19687;
            }
            
            if (magnificationWell == 2){
                xLowest = arrayWellPosition1 [2];
                yLowest = arrayWellPosition1 [3];
                xHighest = arrayWellPosition1 [2]+9938;
                yHighest = arrayWellPosition1 [3]+19687;
            }
            
            if (magnificationWell == 3){
                xLowest = arrayWellPosition1 [4];
                yLowest = arrayWellPosition1 [5];
                xHighest = arrayWellPosition1 [4]+9938;
                yHighest = arrayWellPosition1 [5]+19687;
            }
            
            if (magnificationWell == 4){
                xLowest = arrayWellPosition1 [6];
                yLowest = arrayWellPosition1 [7];
                xHighest = arrayWellPosition1 [6]+9938;
                yHighest = arrayWellPosition1 [7]+19687;
            }
            
            //----Grid set----
            double xLength = xHighest-xLowest;
            double yLength = yHighest-yLowest;
            double gridOriginal = 0;
            double xGrid = 1;
            double yGrid = 1;
            
            double xGridTemp = xLength/512+10;
            double xGridTemp2 = (1047-10)/(double)xGridTemp;
            double yGridTemp = yLength/512+10;
            double yGridTemp2 = (537-10)/(double)yGridTemp;
            
            if (xGridTemp2 > yGridTemp2){
                gridOriginal = yGridTemp2;
                xGrid = (1047-10)/((537-10)/(double)yGridTemp);
                yGrid = yGridTemp;
            }
            
            if (xGridTemp2 <= yGridTemp2){
                gridOriginal = xGridTemp2;
                xGrid = xGridTemp;
                yGrid = (537-10)/((1047-10)/(double)xGridTemp);
            }
            
            if (xGrid == 0 && yGrid == 0){
                xGrid = 1;
                yGrid = 1;
            }
            
            //----Data sheet Drawing Horizontal lines----
            [NSBezierPath setDefaultLineWidth:0.5];
            [[NSColor blackColor] set];
            
            for (int counter1 = 0; counter1 <= yGrid; counter1++){
                positionA.x = 5.0;
                positionA.y = gridIncrement;
                positionB.x = 1047-5;
                positionB.y = gridIncrement;
                [NSBezierPath strokeLineFromPoint:positionA toPoint:positionB];
                gridIncrement = gridIncrement+gridOriginal;
            }
            
            //----Data sheet Drawing Vertical Lines----
            gridIncrement = 5.0;
            
            for (int counter1 = 0; counter1 <= xGrid; counter1++){
                positionA.x = gridIncrement;
                positionA.y = 5.0;
                positionB.x = gridIncrement;
                positionB.y = 537-5;
                [NSBezierPath strokeLineFromPoint:positionA toPoint:positionB];
                gridIncrement = gridIncrement+gridOriginal;
            }
            
            //----Base FOV and side number display----
            int xFirstBlock = 0;
            int yFirstBlock = 0;
            
            double constant1 = 1/(double)512;
            double constant2 = 5+gridOriginal*5;
            
            NSAttributedString *attrStr1;
            NSMutableDictionary *attributes1 = [NSMutableDictionary dictionary];
            [attributes1 setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            
            [NSBezierPath setDefaultLineWidth:2];
            
            int firstFind = 0;
            int horizontalCount = 0;
            int verticalCount = 0;
            double fontSize = 0;
            
            for (int counter1 = 1; counter1 <= 4; counter1++){
                firstFind = 0;
                horizontalCount = 0;
                verticalCount = 0;
                
                for (int counter2 = 0; counter2 < readingPositionMDACount/7; counter2++){
                    if (counter1 == arrayReadingPositionMDA [counter2*7]){
                        if (firstFind == 0){
                            firstFind = 1;
                            xFirstBlock = (int)arrayReadingPositionMDA [counter2*7+4];
                            yFirstBlock = (int)arrayReadingPositionMDA [counter2*7+5];
                        }
                        
                        path = [NSBezierPath bezierPathWithRect: NSMakeRect((arrayReadingPositionMDA [counter2*7+4]-xLowest)*constant1*gridOriginal+constant2, (arrayReadingPositionMDA [counter2*7+5]-yLowest)*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                        
                        [[NSColor colorWithCalibratedRed:0.5 green:0.5 blue:0.7 alpha:0.5] set];
                        [path stroke];
                        
                        if (xFirstBlock-xLowest >= arrayReadingPositionMDA [counter2*7+4]-xLowest-10 && xFirstBlock-xLowest <= arrayReadingPositionMDA [counter2*7+4]-xLowest+10 && magnificationWell != 0){
                            verticalCount++;
                            
                            if (objectiveSelect == 1) fontSize = 12*cameraAdjustment;
                            else if (objectiveSelect == 2) fontSize = 10*cameraAdjustment;
                            else fontSize = 8*cameraAdjustment;
                            
                            [attributes1 setObject:[NSFont systemFontOfSize:(fontSize)] forKey:NSFontAttributeName];
                            
                            attrStr1 = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat : @"%d", verticalCount] attributes:attributes1];
                            
                            if (objectiveSelect == 1){
                                positionA.x = (xFirstBlock-xLowest)*constant1*gridOriginal+constant2-15;
                                positionA.y = (arrayReadingPositionMDA [counter2*7+5]-yLowest)*constant1*gridOriginal+constant2;
                            }
                            else if (objectiveSelect == 2){
                                positionA.x = (xFirstBlock-xLowest)*constant1*gridOriginal+constant2-10;
                                positionA.y = (arrayReadingPositionMDA [counter2*7+5]-yLowest)*constant1*gridOriginal+constant2;
                            }
                            else{
                                
                                positionA.x = (xFirstBlock-xLowest)*constant1*gridOriginal+constant2-8;
                                positionA.y = (arrayReadingPositionMDA [counter2*7+5]-yLowest)*constant1*gridOriginal+constant2;
                            }
                            
                            [attrStr1 drawAtPoint:positionA];
                        }
                        if (yFirstBlock-yLowest >= arrayReadingPositionMDA [counter2*7+5]-yLowest-10 && yFirstBlock-yLowest <= arrayReadingPositionMDA [counter2*7+5]-yLowest+10 && magnificationWell != 0){
                            horizontalCount++;
                            
                            if (objectiveSelect == 1) fontSize = 12*cameraAdjustment;
                            else if (objectiveSelect == 2) fontSize = 10*cameraAdjustment;
                            else fontSize = 8*cameraAdjustment;
                            
                            [attributes1 setObject:[NSFont systemFontOfSize:(fontSize)] forKey:NSFontAttributeName];
                            
                            attrStr1 = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat : @"%d", horizontalCount] attributes:attributes1];
                            
                            if (objectiveSelect == 1){
                                positionA.x = (arrayReadingPositionMDA [counter2*7+4]-xLowest)*constant1*gridOriginal+constant2+8;
                                positionA.y = (yFirstBlock-yLowest)*constant1*gridOriginal+constant2-15;
                            }
                            else if (objectiveSelect == 2){
                                positionA.x = (arrayReadingPositionMDA [counter2*7+4]-xLowest)*constant1*gridOriginal+constant2;
                                positionA.y = (yFirstBlock-yLowest)*constant1*gridOriginal+constant2-10;
                            }
                            else{
                                
                                positionA.x = (arrayReadingPositionMDA [counter2*7+4]-xLowest)*constant1*gridOriginal+constant2;
                                positionA.y = (yFirstBlock-yLowest)*constant1*gridOriginal+constant2-8;
                            }
                            
                            [attrStr1 drawAtPoint:positionA];
                        }
                    }
                }
            }
            
            //----XY Position writing----
            double xPositionCurrent2 = xPositionCurrent-xLowest;
            double yPositionCurrent2 = yPositionCurrent-yLowest;
            
            if (xPositionCurrent != 0 && yPositionCurrent != 0){
                [NSBezierPath setDefaultLineWidth:0];
                
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionCurrent2*constant1*gridOriginal+constant2, yPositionCurrent2*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                
                [[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] set];
                [path fill];
            }
            
            //----Label Display----
            double xGridOriginal = gridOriginal*9938/(double)512;
            double yGridOriginal = gridOriginal*19687/(double)512+gridOriginal;
            
            double constant3 = ((19687+1000)/(double)512)*gridOriginal;
            
            [NSBezierPath setDefaultLineWidth:2];
            
            double xPositionWell = 0;
            double yPositionWell = 0;
            
            for (int counter1 = 1; counter1 <= 4; counter1++){
                xPositionWell = arrayWellPosition1 [(counter1-1)*2]-xLowest;
                yPositionWell = arrayWellPosition1 [(counter1-1)*2+1]-yLowest;
                
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionWell*constant1*gridOriginal+constant2, yPositionWell*constant1*gridOriginal+constant2, xGridOriginal, yGridOriginal)];
                
                if (magnificationWell == counter1) [[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] set];
                else [[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] set];
                
                [path stroke];
                
                [attributes1 setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                [attributes1 setObject:[NSColor blueColor] forKey: NSBackgroundColorAttributeName];
                [attributes1 setObject:[NSFont systemFontOfSize:(14)] forKey:NSFontAttributeName];
                
                if (counter1 == 1) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 1" attributes:attributes1];
                else if (counter1 == 2) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 2" attributes:attributes1];
                else if (counter1 == 3) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 3" attributes:attributes1];
                else if (counter1 == 4) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 4" attributes:attributes1];
                if (counter1 >= 1 && counter1 <= 4){
                    positionA.x = xPositionWell*constant1*gridOriginal+constant2;
                    positionA.y = yPositionWell*constant1*gridOriginal+constant2+constant3;
                }
                
                [attrStr1 drawAtPoint:positionA];
                
                if (labelPositionCount1 <= 6){
                    if (counter1 >= 1 && counter1 <= 4){
                        arrayLabelPosition1 [labelPositionCount1] = xPositionWell*constant1*gridOriginal+constant2, labelPositionCount1++;
                        arrayLabelPosition1 [labelPositionCount1] = yPositionWell*constant1*gridOriginal+constant2+constant3, labelPositionCount1++;
                    }
                }
            }
            
            //----Outside Frame display----
            xPositionWell = arrayWellPosition1 [8]-xLowest;
            yPositionWell = arrayWellPosition1 [9]-yLowest;
            
            xGridOriginal = gridOriginal*(9938*4+2499*3+2186*2)/(double)512;
            yGridOriginal = gridOriginal*(19687+2186*2)/(double)512+gridOriginal;
            
            [NSBezierPath setDefaultLineWidth:2];
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionWell*constant1*gridOriginal+constant2, yPositionWell*constant1*gridOriginal+constant2, xGridOriginal, yGridOriginal)];
            [[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] set];
            [path stroke];
            
            //----Press S----
            if (pressSflag == 1 && magnificationWell != 0){
                [attributes1 setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                [attributes1 setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
                [attributes1 setObject:[NSFont systemFontOfSize:(14)] forKey:NSFontAttributeName];
                attrStr1 = [[NSAttributedString alloc] initWithString:@"Click First FOV" attributes:attributes1];
                positionA.x = 10;
                positionA.y = 10;
                [attrStr1 drawAtPoint:positionA];
            }
            
            //----Select FOV, Press S----
            double xMatchFound = 0;
            double yMatchFound = 0;
            double zMatchFound = 0;
            int matchFindFlag = 0;
            
            if (xClickCurrent != 0 && yClickCurrent != 0 && magnificationWell != 0){
                for (int counter1 = 0; counter1 < readingPositionMDACount/7; counter1++){
                    if (arrayReadingPositionMDA [counter1*7] == magnificationWell){
                        if (xClickCurrent >= (arrayReadingPositionMDA [counter1*7+4]-xLowest)*constant1*gridOriginal+constant2 && (arrayReadingPositionMDA [counter1*7+4]-xLowest)*constant1*gridOriginal+constant2+gridOriginal*objectAdjustment*cameraAdjustment >= xClickCurrent){
                            if (yClickCurrent >= (arrayReadingPositionMDA [counter1*7+5]-yLowest)*constant1*gridOriginal+constant2 && (arrayReadingPositionMDA [counter1*7+5]-yLowest)*constant1*gridOriginal+constant2+gridOriginal*objectAdjustment*cameraAdjustment >= yClickCurrent){
                                xMatchFound = arrayReadingPositionMDA [counter1*7+4];
                                yMatchFound = arrayReadingPositionMDA [counter1*7+5];
                                zMatchFound = arrayReadingPositionMDA [counter1*7+6];
                                matchFindFlag = 1;
                                break;
                            }
                        }
                    }
                }
                
                xClickCurrent = 0;
                yClickCurrent = 0;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            
            //----Save XYZ position into array----
            if (matchFindFlag == 1){
                double *arrayMapTemp = new double [selectedMapCount1+50];
                int mapTempCount = 0;
                
                if (xFOVTaken != 0 && yFOVTaken != 0){
                    for (int counter1 = 0; counter1 < selectedMapCount1/6; counter1++){
                        if (arraySelectedMap1 [counter1*6] != magnificationWell){
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+1], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+2], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+3], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+4], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+5], mapTempCount++;
                        }
                    }
                    
                    selectedMapCount1 = 0;
                    
                    for (int counter1 = 0; counter1 < mapTempCount; counter1++) arraySelectedMap1 [selectedMapCount1] = arrayMapTemp [counter1], selectedMapCount1++;
                    
                    double *arrayMapTemp2 = new double [xFOVTaken*yFOVTaken*7+50];
                    double *arrayMapTemp3 = new double [xFOVTaken*yFOVTaken*7+50];
                    int arrayMapTempCount2 = 0;
                    int arrayMapTempCount3 = 0;
                    
                    for (int counter1 = 1; counter1 <= xFOVTaken; counter1++){
                        for (int counter2 = 1; counter2 <= yFOVTaken; counter2++){
                            arrayMapTemp2 [arrayMapTempCount2] = magnificationWell, arrayMapTempCount2++;
                            
                            if (drawingOrientation == 0){
                                arrayMapTemp2 [arrayMapTempCount2] = counter1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = counter2, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = xMatchFound+(counter1-1)*objectSizeAdjust, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yMatchFound+(counter2-1)*objectSizeAdjust, arrayMapTempCount2++;
                            }
                            else  if (drawingOrientation == 1){
                                arrayMapTemp2 [arrayMapTempCount2] = xFOVTaken-counter1+1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = counter2, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = xMatchFound+(counter1*-1+1)*objectSizeAdjust, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yMatchFound+(counter2-1)*objectSizeAdjust, arrayMapTempCount2++;
                            }
                            else  if (drawingOrientation == 2){
                                arrayMapTemp2 [arrayMapTempCount2] = counter1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yFOVTaken-counter2+1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = xMatchFound+(counter1-1)*objectSizeAdjust, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yMatchFound+(counter2*-1+1)*objectSizeAdjust, arrayMapTempCount2++;
                            }
                            else  if (drawingOrientation == 3){
                                arrayMapTemp2 [arrayMapTempCount2] = xFOVTaken-counter1+1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yFOVTaken-counter2+1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = xMatchFound+(counter1*-1+1)*objectSizeAdjust, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yMatchFound+(counter2*-1+1)*objectSizeAdjust, arrayMapTempCount2++;
                            }
                            
                            arrayMapTemp2 [arrayMapTempCount2] = zMatchFound, arrayMapTempCount2++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < arrayMapTempCount2/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayMapTemp2 [counterA*6+counterB];
                    //    cout<<" arrayMapTemp2 "<<counterA+1<<" "<<endl;
                    //}
                    
                    for (int counter1 = 1; counter1 <= xFOVTaken; counter1++){
                        for (int counter2 = 0; counter2 < arrayMapTempCount2/6; counter2++){
                            if (arrayMapTemp2 [counter2*6+1] == counter1){
                                for (int counter3 = 1; counter3 <= yFOVTaken; counter3++){
                                    for (int counter4 = 0; counter4 < arrayMapTempCount2/6; counter4++){
                                        if (arrayMapTemp2 [counter4*6+1] == counter1 && arrayMapTemp2 [counter4*6+2] == counter3){
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+1], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+2], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+3], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+4], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+5], arrayMapTempCount3++;
                                            break;
                                        }
                                    }
                                }
                                
                                break;
                            }
                        }
                    }
                    
                    if (selectedMapCount1+arrayMapTempCount3 > selectedMapLimit1){
                        selectedMapAddition1 = arrayMapTempCount3;
                        [self selectedMapUpDate1];
                    }
                    
                    for (int counter1 = 0; counter1 < arrayMapTempCount3; counter1++) arraySelectedMap1 [selectedMapCount1] = arrayMapTemp3 [counter1], selectedMapCount1++;
                    
                    delete [] arrayMapTemp2;
                    delete [] arrayMapTemp3;
                    
                    wellDataSaveRequest = 1;
                }
                
                delete [] arrayMapTemp;
            }
            
            //----Draw Selected FOVs----
            [[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] set];
            [NSBezierPath setDefaultLineWidth:0.7];
            
            for (int counter1 = 0; counter1 < selectedMapCount1/6; counter1++){
                path = [NSBezierPath bezierPathWithRect: NSMakeRect((arraySelectedMap1 [counter1*6+3]-xLowest)*constant1*gridOriginal+constant2, (arraySelectedMap1 [counter1*6+4]-yLowest)*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                
                [path stroke];
            }
            
            //----Draw Snap Position----
            for (int counter1 = 0; counter1 < snapMainDataCount/16; counter1++){
                if (snapPage*2-1 == arraySnapMainData [counter1*16]){
                    [[NSColor orangeColor] set];
                    path = [NSBezierPath bezierPathWithRect: NSMakeRect((arraySnapMainData [counter1*16+1]-xLowest)*constant1*gridOriginal+constant2, (arraySnapMainData [counter1*16+2]-yLowest)*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                }
                else{
                    
                    [[NSColor magentaColor] set];
                    path = [NSBezierPath bezierPathWithRect: NSMakeRect((arraySnapMainData [counter1*16+1]-xLowest)*constant1*gridOriginal+constant2, (arraySnapMainData [counter1*16+2]-yLowest)*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                }
                
                [path fill];
            }
        }
        else if (chamberType1 == 4){
            double gridIncrement = 5.0;
            
            NSPoint positionA, positionB;
            
            //----Standard view Limit----
            double xLowest = arrayWellPosition1 [0]-2186;
            double yLowest = arrayWellPosition1 [15]-2186;
            double xHighest = arrayWellPosition1 [6]+10700+2186;
            double yHighest = arrayWellPosition1 [1]+9489+2186;
            
            //----Magnified well Limit----
            if (magnificationWell == 1){
                xLowest = arrayWellPosition1 [0];
                yLowest = arrayWellPosition1 [1];
                xHighest = arrayWellPosition1 [0]+10700;
                yHighest = arrayWellPosition1 [1]+9489;
            }
            
            if (magnificationWell == 2){
                xLowest = arrayWellPosition1 [2];
                yLowest = arrayWellPosition1 [3];
                xHighest = arrayWellPosition1 [2]+10700;
                yHighest = arrayWellPosition1 [3]+9489;
            }
            
            if (magnificationWell == 3){
                xLowest = arrayWellPosition1 [4];
                yLowest = arrayWellPosition1 [5];
                xHighest = arrayWellPosition1 [4]+10700;
                yHighest = arrayWellPosition1 [5]+9489;
            }
            
            if (magnificationWell == 4){
                xLowest = arrayWellPosition1 [6];
                yLowest = arrayWellPosition1 [7];
                xHighest = arrayWellPosition1 [6]+10700;
                yHighest = arrayWellPosition1 [7]+9489;
            }
            
            if (magnificationWell == 5){
                xLowest = arrayWellPosition1 [8];
                yLowest = arrayWellPosition1 [9];
                xHighest = arrayWellPosition1 [8]+10700;
                yHighest = arrayWellPosition1 [9]+9489;
            }
            
            if (magnificationWell == 6){
                xLowest = arrayWellPosition1 [10];
                yLowest = arrayWellPosition1 [11];
                xHighest = arrayWellPosition1 [10]+10700;
                yHighest = arrayWellPosition1 [11]+9489;
            }
            
            if (magnificationWell == 7){
                xLowest = arrayWellPosition1 [12];
                yLowest = arrayWellPosition1 [13];
                xHighest = arrayWellPosition1 [12]+10700;
                yHighest = arrayWellPosition1 [13]+9489;
            }
            
            if (magnificationWell == 8){
                xLowest = arrayWellPosition1 [14];
                yLowest = arrayWellPosition1 [15];
                xHighest = arrayWellPosition1 [14]+10700;
                yHighest = arrayWellPosition1 [15]+9489;
            }
            
            //----Grid set----
            double xLength = xHighest-xLowest;
            double yLength = yHighest-yLowest;
            double gridOriginal = 0;
            double xGrid = 1;
            double yGrid = 1;
            
            double xGridTemp = xLength/512+10;
            double xGridTemp2 = (1047-10)/(double)xGridTemp;
            double yGridTemp = yLength/512+10;
            double yGridTemp2 = (537-10)/(double)yGridTemp;
            
            if (xGridTemp2 > yGridTemp2){
                gridOriginal = yGridTemp2;
                xGrid = (1047-10)/((537-10)/(double)yGridTemp);
                yGrid = yGridTemp;
            }
            
            if (xGridTemp2 <= yGridTemp2){
                gridOriginal = xGridTemp2;
                xGrid = xGridTemp;
                yGrid = (537-10)/((1047-10)/(double)xGridTemp);
            }
            
            if (xGrid == 0 && yGrid == 0){
                xGrid = 1;
                yGrid = 1;
            }
            
            //----Data sheet Drawing Horizontal lines----
            [NSBezierPath setDefaultLineWidth:0.5];
            [[NSColor blackColor] set];
            
            for (int counter1 = 0; counter1 <= yGrid; counter1++){
                positionA.x = 5.0;
                positionA.y = gridIncrement;
                positionB.x = 1047-5;
                positionB.y = gridIncrement;
                [NSBezierPath strokeLineFromPoint:positionA toPoint:positionB];
                gridIncrement = gridIncrement+gridOriginal;
            }
            
            //----Data sheet Drawing Vertical Lines----
            gridIncrement = 5.0;
            
            for (int counter1 = 0; counter1 <= xGrid; counter1++){
                positionA.x = gridIncrement;
                positionA.y = 5.0;
                positionB.x = gridIncrement;
                positionB.y = 537-5;
                [NSBezierPath strokeLineFromPoint:positionA toPoint:positionB];
                gridIncrement = gridIncrement+gridOriginal;
            }
            
            //----Base FOV and side number display----
            int xFirstBlock = 0;
            int yFirstBlock = 0;
            
            double constant1 = 1/(double)512;
            double constant2 = 5+gridOriginal*5;
            
            NSAttributedString *attrStr1;
            NSMutableDictionary *attributes1 = [NSMutableDictionary dictionary];
            [attributes1 setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            
            [NSBezierPath setDefaultLineWidth:2];
            
            int firstFind = 0;
            int horizontalCount = 0;
            int verticalCount = 0;
            double fontSize = 0;
            
            for (int counter1 = 1; counter1 <= 8; counter1++){
                firstFind = 0;
                horizontalCount = 0;
                verticalCount = 0;
                
                for (int counter2 = 0; counter2 < readingPositionMDACount/7; counter2++){
                    if (counter1 == arrayReadingPositionMDA [counter2*7]){
                        if (firstFind == 0){
                            firstFind = 1;
                            xFirstBlock = (int)arrayReadingPositionMDA [counter2*7+4];
                            yFirstBlock = (int)arrayReadingPositionMDA [counter2*7+5];
                        }
                        
                        path = [NSBezierPath bezierPathWithRect: NSMakeRect((arrayReadingPositionMDA [counter2*7+4]-xLowest)*constant1*gridOriginal+constant2, (arrayReadingPositionMDA [counter2*7+5]-yLowest)*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                        
                        [[NSColor colorWithCalibratedRed:0.5 green:0.5 blue:0.7 alpha:0.5] set];
                        [path stroke];
                        
                        if (xFirstBlock-xLowest >= arrayReadingPositionMDA [counter2*7+4]-xLowest-10 && xFirstBlock-xLowest <= arrayReadingPositionMDA [counter2*7+4]-xLowest+10 && magnificationWell != 0){
                            verticalCount++;
                            
                            if (objectiveSelect == 1) fontSize = 12*cameraAdjustment;
                            else if (objectiveSelect == 2) fontSize = 10*cameraAdjustment;
                            else fontSize = 8*cameraAdjustment;
                            
                            [attributes1 setObject:[NSFont systemFontOfSize:(fontSize)] forKey:NSFontAttributeName];
                            
                            attrStr1 = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat : @"%d", verticalCount] attributes:attributes1];
                            
                            if (objectiveSelect == 1){
                                positionA.x = (xFirstBlock-xLowest)*constant1*gridOriginal+constant2-15;
                                positionA.y = (arrayReadingPositionMDA [counter2*7+5]-yLowest)*constant1*gridOriginal+constant2;
                            }
                            else if (objectiveSelect == 2){
                                positionA.x = (xFirstBlock-xLowest)*constant1*gridOriginal+constant2-10;
                                positionA.y = (arrayReadingPositionMDA [counter2*7+5]-yLowest)*constant1*gridOriginal+constant2;
                            }
                            else{
                                
                                positionA.x = (xFirstBlock-xLowest)*constant1*gridOriginal+constant2-8;
                                positionA.y = (arrayReadingPositionMDA [counter2*7+5]-yLowest)*constant1*gridOriginal+constant2;
                            }
                            
                            [attrStr1 drawAtPoint:positionA];
                        }
                        if (yFirstBlock-yLowest >= arrayReadingPositionMDA [counter2*7+5]-yLowest-10 && yFirstBlock-yLowest <= arrayReadingPositionMDA [counter2*7+5]-yLowest+10 && magnificationWell != 0){
                            horizontalCount++;
                            
                            if (objectiveSelect == 1) fontSize = 12*cameraAdjustment;
                            else if (objectiveSelect == 2) fontSize = 10*cameraAdjustment;
                            else fontSize = 8*cameraAdjustment;
                            
                            [attributes1 setObject:[NSFont systemFontOfSize:(fontSize)] forKey:NSFontAttributeName];
                            
                            attrStr1 = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat : @"%d", horizontalCount] attributes:attributes1];
                            
                            if (objectiveSelect == 1){
                                positionA.x = (arrayReadingPositionMDA [counter2*7+4]-xLowest)*constant1*gridOriginal+constant2+8;
                                positionA.y = (yFirstBlock-yLowest)*constant1*gridOriginal+constant2-15;
                            }
                            else if (objectiveSelect == 2){
                                positionA.x = (arrayReadingPositionMDA [counter2*7+4]-xLowest)*constant1*gridOriginal+constant2;
                                positionA.y = (yFirstBlock-yLowest)*constant1*gridOriginal+constant2-10;
                            }
                            else{
                                
                                positionA.x = (arrayReadingPositionMDA [counter2*7+4]-xLowest)*constant1*gridOriginal+constant2;
                                positionA.y = (yFirstBlock-yLowest)*constant1*gridOriginal+constant2-8;
                            }
                            
                            [attrStr1 drawAtPoint:positionA];
                        }
                    }
                }
            }
            
            //----XY Position writing----
            double xPositionCurrent2 = xPositionCurrent-xLowest;
            double yPositionCurrent2 = yPositionCurrent-yLowest;
            
            if (xPositionCurrent != 0 && yPositionCurrent != 0){
                [NSBezierPath setDefaultLineWidth:0];
                
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionCurrent2*constant1*gridOriginal+constant2, yPositionCurrent2*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                
                [[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] set];
                [path fill];
            }
            
            //----Label Display----
            double xGridOriginal = gridOriginal*10700/(double)512;
            double yGridOriginal = gridOriginal*9489/(double)512+gridOriginal;
            
            double constant3 = ((9489+1000)/(double)512)*gridOriginal;
            double constant4 = (1400/(double)512)*gridOriginal;
            
            [NSBezierPath setDefaultLineWidth:2];
            
            double xPositionWell = 0;
            double yPositionWell = 0;
            
            for (int counter1 = 1; counter1 <= 8; counter1++){
                xPositionWell = arrayWellPosition1 [(counter1-1)*2]-xLowest;
                yPositionWell = arrayWellPosition1 [(counter1-1)*2+1]-yLowest;
                
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionWell*constant1*gridOriginal+constant2, yPositionWell*constant1*gridOriginal+constant2, xGridOriginal, yGridOriginal)];
                
                if (magnificationWell == counter1) [[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] set];
                else [[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] set];
                
                [path stroke];
                
                [attributes1 setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                [attributes1 setObject:[NSColor blueColor] forKey: NSBackgroundColorAttributeName];
                [attributes1 setObject:[NSFont systemFontOfSize:(14)] forKey:NSFontAttributeName];
                
                if (counter1 == 1) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 1" attributes:attributes1];
                else if (counter1 == 2) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 2" attributes:attributes1];
                else if (counter1 == 3) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 3" attributes:attributes1];
                else if (counter1 == 4) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 4" attributes:attributes1];
                else if (counter1 == 5) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 5" attributes:attributes1];
                else if (counter1 == 6) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 6" attributes:attributes1];
                else if (counter1 == 7) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 7" attributes:attributes1];
                else if (counter1 == 8) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 8" attributes:attributes1];
                
                if (counter1 >= 1 && counter1 <= 4){
                    positionA.x = xPositionWell*constant1*gridOriginal+constant2;
                    positionA.y = yPositionWell*constant1*gridOriginal+constant2+constant3;
                }
                
                if (counter1 >= 5 && counter1 <= 8){
                    positionA.x = xPositionWell*constant1*gridOriginal+constant2;
                    positionA.y = yPositionWell*constant1*gridOriginal+constant2-constant4;
                }
                
                [attrStr1 drawAtPoint:positionA];
                
                if (labelPositionCount1 <= 14){
                    if (counter1 >= 1 && counter1 <= 4){
                        arrayLabelPosition1 [labelPositionCount1] = xPositionWell*constant1*gridOriginal+constant2, labelPositionCount1++;
                        arrayLabelPosition1 [labelPositionCount1] = yPositionWell*constant1*gridOriginal+constant2+constant3, labelPositionCount1++;
                    }
                    
                    if (counter1 >= 5 && counter1 <= 8){
                        arrayLabelPosition1 [labelPositionCount1] = xPositionWell*constant1*gridOriginal+constant2, labelPositionCount1++;
                        arrayLabelPosition1 [labelPositionCount1] = yPositionWell*constant1*gridOriginal+constant2-constant4, labelPositionCount1++;
                    }
                }
            }
            
            //----Outside Frame display----
            xPositionWell = arrayWellPosition1 [16]-xLowest;
            yPositionWell = arrayWellPosition1 [17]-yLowest;
            
            xGridOriginal = gridOriginal*(10700*4+1146*2+2673+2186*2)/(double)512;
            yGridOriginal = gridOriginal*(9489*2+1528+2186*2)/(double)512+gridOriginal;
            
            [NSBezierPath setDefaultLineWidth:2];
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionWell*constant1*gridOriginal+constant2, yPositionWell*constant1*gridOriginal+constant2, xGridOriginal, yGridOriginal)];
            [[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] set];
            [path stroke];
            
            //----Press S----
            if (pressSflag == 1 && magnificationWell != 0){
                [attributes1 setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                [attributes1 setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
                [attributes1 setObject:[NSFont systemFontOfSize:(14)] forKey:NSFontAttributeName];
                attrStr1 = [[NSAttributedString alloc] initWithString:@"Click First FOV" attributes:attributes1];
                positionA.x = 10;
                positionA.y = 10;
                [attrStr1 drawAtPoint:positionA];
            }
            
            //----Select FOV, Press S----
            double xMatchFound = 0;
            double yMatchFound = 0;
            double zMatchFound = 0;
            int matchFindFlag = 0;
            
            if (xClickCurrent != 0 && yClickCurrent != 0 && magnificationWell != 0){
                for (int counter1 = 0; counter1 < readingPositionMDACount/7; counter1++){
                    if (arrayReadingPositionMDA [counter1*7] == magnificationWell){
                        if (xClickCurrent >= (arrayReadingPositionMDA [counter1*7+4]-xLowest)*constant1*gridOriginal+constant2 && (arrayReadingPositionMDA [counter1*7+4]-xLowest)*constant1*gridOriginal+constant2+gridOriginal*objectAdjustment*cameraAdjustment >= xClickCurrent){
                            if (yClickCurrent >= (arrayReadingPositionMDA [counter1*7+5]-yLowest)*constant1*gridOriginal+constant2 && (arrayReadingPositionMDA [counter1*7+5]-yLowest)*constant1*gridOriginal+constant2+gridOriginal*objectAdjustment*cameraAdjustment >= yClickCurrent){
                                xMatchFound = arrayReadingPositionMDA [counter1*7+4];
                                yMatchFound = arrayReadingPositionMDA [counter1*7+5];
                                zMatchFound = arrayReadingPositionMDA [counter1*7+6];
                                matchFindFlag = 1;
                                break;
                            }
                        }
                    }
                }
                
                xClickCurrent = 0;
                yClickCurrent = 0;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            
            //----Save XYZ position into array----
            if (matchFindFlag == 1){
                double *arrayMapTemp = new double [selectedMapCount1+50];
                int mapTempCount = 0;
                
                if (xFOVTaken != 0 && yFOVTaken != 0){
                    for (int counter1 = 0; counter1 < selectedMapCount1/6; counter1++){
                        if (arraySelectedMap1 [counter1*6] != magnificationWell){
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+1], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+2], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+3], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+4], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+5], mapTempCount++;
                        }
                    }
                    
                    selectedMapCount1 = 0;
                    
                    for (int counter1 = 0; counter1 < mapTempCount; counter1++) arraySelectedMap1 [selectedMapCount1] = arrayMapTemp [counter1], selectedMapCount1++;
                    
                    double *arrayMapTemp2 = new double [xFOVTaken*yFOVTaken*7+50];
                    double *arrayMapTemp3 = new double [xFOVTaken*yFOVTaken*7+50];
                    int arrayMapTempCount2 = 0;
                    int arrayMapTempCount3 = 0;
                    
                    for (int counter1 = 1; counter1 <= xFOVTaken; counter1++){
                        for (int counter2 = 1; counter2 <= yFOVTaken; counter2++){
                            arrayMapTemp2 [arrayMapTempCount2] = magnificationWell, arrayMapTempCount2++;
                            
                            if (drawingOrientation == 0){
                                arrayMapTemp2 [arrayMapTempCount2] = counter1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = counter2, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = xMatchFound+(counter1-1)*objectSizeAdjust, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yMatchFound+(counter2-1)*objectSizeAdjust, arrayMapTempCount2++;
                            }
                            else  if (drawingOrientation == 1){
                                arrayMapTemp2 [arrayMapTempCount2] = xFOVTaken-counter1+1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = counter2, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = xMatchFound+(counter1*-1+1)*objectSizeAdjust, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yMatchFound+(counter2-1)*objectSizeAdjust, arrayMapTempCount2++;
                            }
                            else  if (drawingOrientation == 2){
                                arrayMapTemp2 [arrayMapTempCount2] = counter1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yFOVTaken-counter2+1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = xMatchFound+(counter1-1)*objectSizeAdjust, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yMatchFound+(counter2*-1+1)*objectSizeAdjust, arrayMapTempCount2++;
                            }
                            else  if (drawingOrientation == 3){
                                arrayMapTemp2 [arrayMapTempCount2] = xFOVTaken-counter1+1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yFOVTaken-counter2+1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = xMatchFound+(counter1*-1+1)*objectSizeAdjust, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yMatchFound+(counter2*-1+1)*objectSizeAdjust, arrayMapTempCount2++;
                            }
                            
                            arrayMapTemp2 [arrayMapTempCount2] = zMatchFound, arrayMapTempCount2++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < arrayMapTempCount2/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayMapTemp2 [counterA*6+counterB];
                    //    cout<<" arrayMapTemp2 "<<counterA+1<<" "<<endl;
                    //}
                    
                    for (int counter1 = 1; counter1 <= xFOVTaken; counter1++){
                        for (int counter2 = 0; counter2 < arrayMapTempCount2/6; counter2++){
                            if (arrayMapTemp2 [counter2*6+1] == counter1){
                                for (int counter3 = 1; counter3 <= yFOVTaken; counter3++){
                                    for (int counter4 = 0; counter4 < arrayMapTempCount2/6; counter4++){
                                        if (arrayMapTemp2 [counter4*6+1] == counter1 && arrayMapTemp2 [counter4*6+2] == counter3){
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+1], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+2], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+3], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+4], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+5], arrayMapTempCount3++;
                                            break;
                                        }
                                    }
                                }
                                
                                break;
                            }
                        }
                    }
                    
                    if (selectedMapCount1+arrayMapTempCount3 > selectedMapLimit1){
                        selectedMapAddition1 = arrayMapTempCount3;
                        [self selectedMapUpDate1];
                    }
                    
                    for (int counter1 = 0; counter1 < arrayMapTempCount3; counter1++) arraySelectedMap1 [selectedMapCount1] = arrayMapTemp3 [counter1], selectedMapCount1++;
                    
                    delete [] arrayMapTemp2;
                    delete [] arrayMapTemp3;
                    
                    wellDataSaveRequest = 1;
                }
                
                delete [] arrayMapTemp;
            }
            
            //----Draw Selected FOVs----
            [[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] set];
            [NSBezierPath setDefaultLineWidth:0.7];
            
            for (int counter1 = 0; counter1 < selectedMapCount1/6 ; counter1++){
                path = [NSBezierPath bezierPathWithRect: NSMakeRect((arraySelectedMap1 [counter1*6+3]-xLowest)*constant1*gridOriginal+constant2, (arraySelectedMap1 [counter1*6+4]-yLowest)*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                
                [path stroke];
            }
            
            //----Draw Snap Position----
            for (int counter1 = 0; counter1 < snapMainDataCount/16; counter1++){
                if (snapPage*2-1 == arraySnapMainData [counter1*16]){
                    [[NSColor orangeColor] set];
                    path = [NSBezierPath bezierPathWithRect: NSMakeRect((arraySnapMainData [counter1*16+1]-xLowest)*constant1*gridOriginal+constant2, (arraySnapMainData [counter1*16+2]-yLowest)*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                }
                else{
                    
                    [[NSColor magentaColor] set];
                    path = [NSBezierPath bezierPathWithRect: NSMakeRect((arraySnapMainData [counter1*16+1]-xLowest)*constant1*gridOriginal+constant2, (arraySnapMainData [counter1*16+2]-yLowest)*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                }
                
                [path fill];
            }
        }
        else if (chamberType1 == 5){
            double gridIncrement = 5.0;
            
            NSPoint positionA, positionB;
            
            //----Standard view Limit----
            double xLowest = arrayWellPosition1 [0]-2186; //CHAMBER**********RIGHT WELL**********************************
            double yLowest = arrayWellPosition1 [1]-2186-2186; //CHAMBER**********RIGHT BOTTOM WELL**********************************
            double xHighest = arrayWellPosition1 [10]+3868+2186; //CHAMBER**********LEFT WELL, X-LENGTH OF WELL**********************************
            double yHighest = arrayWellPosition1 [11]+14238+2186+2186; //CHAMBER**********LEFT BOTTOM WELL, Y-LENGTH OF WELL**********************************
            
            //----Magnified well Limit----
            //CHAMBER**********WELL INFO, X-LENGTH ANF Y-LENGTH**********************************
            if (magnificationWell == 1){
                xLowest = arrayWellPosition1 [0];
                yLowest = arrayWellPosition1 [1];
                xHighest = arrayWellPosition1 [0]+3868;
                yHighest = arrayWellPosition1 [1]+14238;
            }
            
            if (magnificationWell == 2){
                xLowest = arrayWellPosition1 [2];
                yLowest = arrayWellPosition1 [3];
                xHighest = arrayWellPosition1 [2]+3868;
                yHighest = arrayWellPosition1 [3]+14238;
            }
            
            if (magnificationWell == 3){
                xLowest = arrayWellPosition1 [4];
                yLowest = arrayWellPosition1 [5];
                xHighest = arrayWellPosition1 [4]+3868;
                yHighest = arrayWellPosition1 [5]+14238;
            }
            
            if (magnificationWell == 4){
                xLowest = arrayWellPosition1 [6];
                yLowest = arrayWellPosition1 [7];
                xHighest = arrayWellPosition1 [6]+3868;
                yHighest = arrayWellPosition1 [7]+14238;
            }
            
            if (magnificationWell == 5){
                xLowest = arrayWellPosition1 [8];
                yLowest = arrayWellPosition1 [9];
                xHighest = arrayWellPosition1 [8]+3868;
                yHighest = arrayWellPosition1 [9]+14238;
            }
            
            if (magnificationWell == 6){
                xLowest = arrayWellPosition1 [10];
                yLowest = arrayWellPosition1 [11];
                xHighest = arrayWellPosition1 [10]+3868;
                yHighest = arrayWellPosition1 [11]+14238;
            }
            
            //----Grid set----
            double xLength = xHighest-xLowest;
            double yLength = yHighest-yLowest;
            double gridOriginal = 0;
            double xGrid = 1;
            double yGrid = 1;
            
            double xGridTemp = xLength/512+10;
            double xGridTemp2 = (1047-10)/(double)xGridTemp;
            double yGridTemp = yLength/512+10;
            double yGridTemp2 = (537-10)/(double)yGridTemp;
            
            if (xGridTemp2 > yGridTemp2){
                gridOriginal = yGridTemp2;
                xGrid = (1047-10)/((537-10)/(double)yGridTemp);
                yGrid = yGridTemp;
            }
            
            if (xGridTemp2 <= yGridTemp2){
                gridOriginal = xGridTemp2;
                xGrid = xGridTemp;
                yGrid = (537-10)/((1047-10)/(double)xGridTemp);
            }
            
            if (xGrid == 0 && yGrid == 0){
                xGrid = 1;
                yGrid = 1;
            }
            
            //----Data sheet Drawing Horizontal lines----
            [NSBezierPath setDefaultLineWidth:0.5];
            [[NSColor blackColor] set];
            
            for (int counter1 = 0; counter1 <= yGrid; counter1++){
                positionA.x = 5.0;
                positionA.y = gridIncrement;
                positionB.x = 1047-5;
                positionB.y = gridIncrement;
                [NSBezierPath strokeLineFromPoint:positionA toPoint:positionB];
                gridIncrement = gridIncrement+gridOriginal;
            }
            
            //----Data sheet Drawing Vertical Lines----
            gridIncrement = 5.0;
            
            for (int counter1 = 0; counter1 <= xGrid; counter1++){
                positionA.x = gridIncrement;
                positionA.y = 5.0;
                positionB.x = gridIncrement;
                positionB.y = 537-5;
                [NSBezierPath strokeLineFromPoint:positionA toPoint:positionB];
                gridIncrement = gridIncrement+gridOriginal;
            }
            
            //----Base FOV and side number display----
            int xFirstBlock = 0;
            int yFirstBlock = 0;
            
            double constant1 = 1/(double)512;
            double constant2 = 5+gridOriginal*5;
            
            NSAttributedString *attrStr1;
            NSMutableDictionary *attributes1 = [NSMutableDictionary dictionary];
            [attributes1 setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            
            [NSBezierPath setDefaultLineWidth:2];
            
            //for (int counterA = 0; counterA < readingPositionMDACount/7; counterA++){
            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayReadingPositionMDA [counterA*7+counterB];
            //	cout<<" arrayReadingPositionMDA "<<counterA<<" "<<endl;
            //}
            
            int firstFind = 0;
            int horizontalCount = 0;
            int verticalCount = 0;
            double fontSize = 0;
            
            for (int counter1 = 1; counter1 <= 6; counter1++){
                firstFind = 0;
                horizontalCount = 0;
                verticalCount = 0;
                
                for (int counter2 = 0; counter2 < readingPositionMDACount/7; counter2++){
                    if (counter1 == arrayReadingPositionMDA [counter2*7]){
                        if (firstFind == 0){
                            firstFind = 1;
                            xFirstBlock = (int)arrayReadingPositionMDA [counter2*7+4];
                            yFirstBlock = (int)arrayReadingPositionMDA [counter2*7+5];
                        }
                        
                        path = [NSBezierPath bezierPathWithRect: NSMakeRect((arrayReadingPositionMDA [counter2*7+4]-xLowest)*constant1*gridOriginal+constant2, (arrayReadingPositionMDA [counter2*7+5]-yLowest)*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                        
                        [[NSColor colorWithCalibratedRed:0.5 green:0.5 blue:0.7 alpha:0.5] set];
                        [path stroke];
                        
                        if (xFirstBlock-xLowest >= arrayReadingPositionMDA [counter2*7+4]-xLowest-10 && xFirstBlock-xLowest <= arrayReadingPositionMDA [counter2*7+4]-xLowest+10 && magnificationWell != 0){
                            verticalCount++;
                            
                            if (objectiveSelect == 1) fontSize = 12*cameraAdjustment;
                            else if (objectiveSelect == 2) fontSize = 10*cameraAdjustment;
                            else fontSize = 8*cameraAdjustment;
                            
                            [attributes1 setObject:[NSFont systemFontOfSize:(fontSize)] forKey:NSFontAttributeName];
                            
                            attrStr1 = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat : @"%d", verticalCount] attributes:attributes1];
                            
                            if (objectiveSelect == 1){
                                positionA.x = (xFirstBlock-xLowest)*constant1*gridOriginal+constant2-15;
                                positionA.y = (arrayReadingPositionMDA [counter2*7+5]-yLowest)*constant1*gridOriginal+constant2;
                            }
                            else if (objectiveSelect == 2){
                                positionA.x = (xFirstBlock-xLowest)*constant1*gridOriginal+constant2-10;
                                positionA.y = (arrayReadingPositionMDA [counter2*7+5]-yLowest)*constant1*gridOriginal+constant2;
                            }
                            else{
                                positionA.x = (xFirstBlock-xLowest)*constant1*gridOriginal+constant2-8;
                                positionA.y = (arrayReadingPositionMDA [counter2*7+5]-yLowest)*constant1*gridOriginal+constant2;
                            }
                            
                            [attrStr1 drawAtPoint:positionA];
                        }
                        if (yFirstBlock-yLowest >= arrayReadingPositionMDA [counter2*7+5]-yLowest-10 && yFirstBlock-yLowest <= arrayReadingPositionMDA [counter2*7+5]-yLowest+10 && magnificationWell != 0){
                            horizontalCount++;
                            
                            if (objectiveSelect == 1) fontSize = 12*cameraAdjustment;
                            else if (objectiveSelect == 2) fontSize = 10*cameraAdjustment;
                            else fontSize = 8*cameraAdjustment;
                            
                            [attributes1 setObject:[NSFont systemFontOfSize:(fontSize)] forKey:NSFontAttributeName];
                            
                            attrStr1 = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat : @"%d", horizontalCount] attributes:attributes1];
                            
                            if (objectiveSelect == 1){
                                positionA.x = (arrayReadingPositionMDA [counter2*7+4]-xLowest)*constant1*gridOriginal+constant2+8;
                                positionA.y = (yFirstBlock-yLowest)*constant1*gridOriginal+constant2-15;
                            }
                            else if (objectiveSelect == 2){
                                positionA.x = (arrayReadingPositionMDA [counter2*7+4]-xLowest)*constant1*gridOriginal+constant2;
                                positionA.y = (yFirstBlock-yLowest)*constant1*gridOriginal+constant2-10;
                            }
                            else{
                                
                                positionA.x = (arrayReadingPositionMDA [counter2*7+4]-xLowest)*constant1*gridOriginal+constant2;
                                positionA.y = (yFirstBlock-yLowest)*constant1*gridOriginal+constant2-8;
                            }
                            
                            [attrStr1 drawAtPoint:positionA];
                        }
                    }
                }
            }
            
            //----XY Position writing----
            double xPositionCurrent2 = xPositionCurrent-xLowest;
            double yPositionCurrent2 = yPositionCurrent-yLowest;
            
            if (xPositionCurrent != 0 && yPositionCurrent != 0){
                [NSBezierPath setDefaultLineWidth:0];
                
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionCurrent2*constant1*gridOriginal+constant2, yPositionCurrent2*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                
                [[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] set];
                [path fill];
            }
            
            //----Label Display----
            //CHAMBER**********X-LENGTH AND Y-LENGTH CHANGE**********************************
            double xGridOriginal = gridOriginal*3868/(double)512;
            double yGridOriginal = gridOriginal*14238/(double)512+gridOriginal;
            
            double constant3 = ((14238+1000)/(double)512)*gridOriginal;
            //double constant4 = (1400/(double)512)*gridOriginal; //CHAMBER**********NEED FOR 8 WELL**********************************
            
            [NSBezierPath setDefaultLineWidth:2];
            
            double xPositionWell = 0;
            double yPositionWell = 0;
            
            for (int counter1 = 1; counter1 <= 6; counter1++){ //CHAMBER**********Number of WELL**********************************
                xPositionWell = arrayWellPosition1 [(counter1-1)*2]-xLowest;
                yPositionWell = arrayWellPosition1 [(counter1-1)*2+1]-yLowest;
                
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionWell*constant1*gridOriginal+constant2, yPositionWell*constant1*gridOriginal+constant2, xGridOriginal, yGridOriginal)];
                
                if (magnificationWell == counter1) [[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] set];
                else [[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] set];
                
                [path stroke];
                
                [attributes1 setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                [attributes1 setObject:[NSColor blueColor] forKey: NSBackgroundColorAttributeName];
                [attributes1 setObject:[NSFont systemFontOfSize:(14)] forKey:NSFontAttributeName];
                
                if (counter1 == 1) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 1" attributes:attributes1];
                else if (counter1 == 2) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 2" attributes:attributes1];
                else if (counter1 == 3) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 3" attributes:attributes1];
                else if (counter1 == 4) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 4" attributes:attributes1];
                else if (counter1 == 5) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 5" attributes:attributes1];
                else if (counter1 == 6) attrStr1 = [[NSAttributedString alloc] initWithString:@"Well 6" attributes:attributes1];
                
                if (counter1 >= 1 && counter1 <= 6){ //CHAMBER**********NO OF WELL, CHANGE**********************************
                    positionA.x = xPositionWell*constant1*gridOriginal+constant2;
                    positionA.y = yPositionWell*constant1*gridOriginal+constant2+constant3;
                }
                //if (counter1 >= 5 && counter1 <= 8){ //CHAMBER**********NEED FOR 8 WELL**********************************
                //    positionA.x = xPositionWell*constant1*gridOriginal+constant2;
                //    positionA.y = yPositionWell*constant1*gridOriginal+constant2-constant4;
                //}
                
                [attrStr1 drawAtPoint:positionA];
                
                if (labelPositionCount1 <= 10){ //CHAMBER**********SET WELL NO*2-2**********************************
                    if (counter1 >= 1 && counter1 <= 6){
                        arrayLabelPosition1 [labelPositionCount1] = xPositionWell*constant1*gridOriginal+constant2, labelPositionCount1++;
                        arrayLabelPosition1 [labelPositionCount1] = yPositionWell*constant1*gridOriginal+constant2+constant3, labelPositionCount1++;
                    }
                    //if (counter1 >= 5 && counter1 <= 8){ //CHAMBER**********NEED FOR 8 WELL**********************************
                    //    arrayLabelPosition1 [labelPositionCount1] = xPositionWell*constant1*gridOriginal+constant2, labelPositionCount1++;
                    //    arrayLabelPosition1 [labelPositionCount1] = yPositionWell*constant1*gridOriginal+constant2-constant4, labelPositionCount1++;
                    //}
                }
            }
            
            //----Outside Frame display----
            xPositionWell = arrayWellPosition1 [12]-xLowest;
            yPositionWell = arrayWellPosition1 [13]-yLowest;
            
            xGridOriginal = gridOriginal*(3868*6+5152*5+2186*2)/(double)512; //CHAMBER**********X-LENGTH: 2186+(WELL X-LENGTH)*NO OF WELL (X)+(WALL LENGTH)*NO OF WALL+2186**********************************
            yGridOriginal = gridOriginal*(14238+2186*4)/(double)512+gridOriginal; //CHAMBER**********Y-LENGTH: 2186+(WELL Y-LENGTH)*NO OF WELL (Y)+(WALL LENGTH)*NO OF WALL+2186**********************************
            
            [NSBezierPath setDefaultLineWidth:2];
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionWell*constant1*gridOriginal+constant2, yPositionWell*constant1*gridOriginal+constant2, xGridOriginal, yGridOriginal)];
            [[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] set];
            [path stroke];
            
            //----Press S----
            if (pressSflag == 1 && magnificationWell != 0){
                [attributes1 setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                [attributes1 setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
                [attributes1 setObject:[NSFont systemFontOfSize:(14)] forKey:NSFontAttributeName];
                attrStr1 = [[NSAttributedString alloc] initWithString:@"Click First FOV" attributes:attributes1];
                positionA.x = 10;
                positionA.y = 10;
                [attrStr1 drawAtPoint:positionA];
            }
            
            //----Select FOV, Press S----
            double xMatchFound = 0;
            double yMatchFound = 0;
            double zMatchFound = 0;
            int matchFindFlag = 0;
            
            if (xClickCurrent != 0 && yClickCurrent != 0 && magnificationWell != 0){
                for (int counter1 = 0; counter1 < readingPositionMDACount/7; counter1++){
                    if (arrayReadingPositionMDA [counter1*7] == magnificationWell){
                        if (xClickCurrent >= (arrayReadingPositionMDA [counter1*7+4]-xLowest)*constant1*gridOriginal+constant2 && (arrayReadingPositionMDA [counter1*7+4]-xLowest)*constant1*gridOriginal+constant2+gridOriginal*objectAdjustment*cameraAdjustment>= xClickCurrent){
                            if (yClickCurrent >= (arrayReadingPositionMDA [counter1*7+5]-yLowest)*constant1*gridOriginal+constant2 && (arrayReadingPositionMDA [counter1*7+5]-yLowest)*constant1*gridOriginal+constant2+gridOriginal*objectAdjustment*cameraAdjustment >= yClickCurrent){
                                xMatchFound = arrayReadingPositionMDA [counter1*7+4];
                                yMatchFound = arrayReadingPositionMDA [counter1*7+5];
                                zMatchFound = arrayReadingPositionMDA [counter1*7+6];
                                matchFindFlag = 1;
                                break;
                            }
                        }
                    }
                }
                
                xClickCurrent = 0;
                yClickCurrent = 0;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            
            //----Save XYZ position into array----
            if (matchFindFlag == 1){
                double *arrayMapTemp = new double [selectedMapCount1+50];
                int mapTempCount = 0;
                
                if (xFOVTaken != 0 && yFOVTaken != 0){
                    for (int counter1 = 0; counter1 < selectedMapCount1/6; counter1++){
                        if (arraySelectedMap1 [counter1*6] != magnificationWell){
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+1], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+2], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+3], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+4], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arraySelectedMap1 [counter1*6+5], mapTempCount++;
                        }
                    }
                    
                    selectedMapCount1 = 0;
                    
                    for (int counter1 = 0; counter1 < mapTempCount; counter1++) arraySelectedMap1 [selectedMapCount1] = arrayMapTemp [counter1], selectedMapCount1++;
                    
                    double *arrayMapTemp2 = new double [xFOVTaken*yFOVTaken*7+50];
                    double *arrayMapTemp3 = new double [xFOVTaken*yFOVTaken*7+50];
                    int arrayMapTempCount2 = 0, arrayMapTempCount3 = 0;
                    
                    for (int counter1 = 1; counter1 <= xFOVTaken; counter1++){
                        for (int counter2 = 1; counter2 <= yFOVTaken; counter2++){
                            arrayMapTemp2 [arrayMapTempCount2] = magnificationWell, arrayMapTempCount2++;
                            
                            if (drawingOrientation == 0){
                                arrayMapTemp2 [arrayMapTempCount2] = counter1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = counter2, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = xMatchFound+(counter1-1)*objectSizeAdjust, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yMatchFound+(counter2-1)*objectSizeAdjust, arrayMapTempCount2++;
                            }
                            else  if (drawingOrientation == 1){
                                arrayMapTemp2 [arrayMapTempCount2] = xFOVTaken-counter1+1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = counter2, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = xMatchFound+(counter1*-1+1)*objectSizeAdjust, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yMatchFound+(counter2-1)*objectSizeAdjust, arrayMapTempCount2++;
                            }
                            else  if (drawingOrientation == 2){
                                arrayMapTemp2 [arrayMapTempCount2] = counter1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yFOVTaken-counter2+1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = xMatchFound+(counter1-1)*objectSizeAdjust, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yMatchFound+(counter2*-1+1)*objectSizeAdjust, arrayMapTempCount2++;
                            }
                            else  if (drawingOrientation == 3){
                                arrayMapTemp2 [arrayMapTempCount2] = xFOVTaken-counter1+1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yFOVTaken-counter2+1, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = xMatchFound+(counter1*-1+1)*objectSizeAdjust, arrayMapTempCount2++;
                                arrayMapTemp2 [arrayMapTempCount2] = yMatchFound+(counter2*-1+1)*objectSizeAdjust, arrayMapTempCount2++;
                            }
                            
                            arrayMapTemp2 [arrayMapTempCount2] = zMatchFound, arrayMapTempCount2++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < arrayMapTempCount2/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayMapTemp2 [counterA*6+counterB];
                    //    cout<<" arrayMapTemp2 "<<counterA+1<<" "<<endl;
                    //}
                    
                    for (int counter1 = 1; counter1 <= xFOVTaken; counter1++){
                        for (int counter2 = 0; counter2 < arrayMapTempCount2/6; counter2++){
                            if (arrayMapTemp2 [counter2*6+1] == counter1){
                                for (int counter3 = 1; counter3 <= yFOVTaken; counter3++){
                                    for (int counter4 = 0; counter4 < arrayMapTempCount2/6; counter4++){
                                        if (arrayMapTemp2 [counter4*6+1] == counter1 && arrayMapTemp2 [counter4*6+2] == counter3){
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+1], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+2], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+3], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+4], arrayMapTempCount3++;
                                            arrayMapTemp3 [arrayMapTempCount3] = arrayMapTemp2 [counter4*6+5], arrayMapTempCount3++;
                                            break;
                                        }
                                    }
                                }
                                
                                break;
                            }
                        }
                    }
                    
                    if (selectedMapCount1+arrayMapTempCount3 > selectedMapLimit1){
                        selectedMapAddition1 = arrayMapTempCount3;
                        [self selectedMapUpDate1];
                    }
                    
                    for (int counter1 = 0; counter1 < arrayMapTempCount3; counter1++) arraySelectedMap1 [selectedMapCount1] = arrayMapTemp3 [counter1], selectedMapCount1++;
                    
                    delete [] arrayMapTemp2;
                    delete [] arrayMapTemp3;
                    
                    wellDataSaveRequest = 1;
                }
                
                delete [] arrayMapTemp;
            }
            
            //----Draw Selected FOVs----
            [[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] set];
            [NSBezierPath setDefaultLineWidth:0.7];
            
            for (int counter1 = 0; counter1 < selectedMapCount1/6; counter1++){
                path = [NSBezierPath bezierPathWithRect: NSMakeRect((arraySelectedMap1 [counter1*6+3]-xLowest)*constant1*gridOriginal+constant2, (arraySelectedMap1 [counter1*6+4]-yLowest)*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                
                [path stroke];
            }
            
            //----Draw Snap Position----
            for (int counter1 = 0; counter1 < snapMainDataCount/16; counter1++){
                if (snapPage*2-1 == arraySnapMainData [counter1*16]){
                    [[NSColor orangeColor] set];
                    path = [NSBezierPath bezierPathWithRect: NSMakeRect((arraySnapMainData [counter1*16+1]-xLowest)*constant1*gridOriginal+constant2, (arraySnapMainData [counter1*16+2]-yLowest)*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                }
                else{
                    
                    [[NSColor magentaColor] set];
                    path = [NSBezierPath bezierPathWithRect: NSMakeRect((arraySnapMainData [counter1*16+1]-xLowest)*constant1*gridOriginal+constant2, (arraySnapMainData [counter1*16+2]-yLowest)*constant1*gridOriginal+constant2, gridOriginal*objectAdjustment*cameraAdjustment, gridOriginal*objectAdjustment*cameraAdjustment)];
                }
                
                [path fill];
            }
        }
        
        if (displayCheck1 == 1) displayCheck1 = 2;
    }
}

-(void)selectedMapUpDate1{
    double *arrayUpDate = new double [selectedMapCount1+10];
    
    for (int counter1 = 0; counter1 < selectedMapCount1; counter1++) arrayUpDate [counter1] = arraySelectedMap1 [counter1];
    
    delete [] arraySelectedMap1;
    arraySelectedMap1 = new double [selectedMapLimit1+selectedMapAddition1+500];
    selectedMapLimit1 = selectedMapLimit1+selectedMapAddition1+500;
    
    for (int counter1 = 0; counter1 < selectedMapCount1; counter1++) arraySelectedMap1 [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    if (xyMapTimer) [xyMapTimer invalidate];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToXYMap object:nil];
}

@end
