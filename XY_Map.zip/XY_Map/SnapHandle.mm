//
//  SnapHandle.m
//  XY_Map
//
//  Created by Masahiko Sato on 2014-08-23.
//
//

#import "SnapHandle.h"

NSString *notificationToSnapHandle = @"notificationExecuteSnapHandle";

@implementation SnapHandle

-(id)init{
    self = [super init];
    
    if (self != nil){
        stepperLimitXL1 = 0;
        stepperLimitXH1 = 0;
        stepperLimitYL1 = 0;
        stepperLimitYH1 = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToSnapHandle object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    snapDisplayController = [[NSWindowController alloc] initWithWindowNibName:@"SnapDisplay"];
    [snapDisplayController showWindow:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    int yOrigin = (int)screenRect.origin.y;
    int yLength = (int)screenRect.size.height;
    
    NSRect windowSize = [snapWindow frame];
    int windowHeight = (int)windowSize.size.height;
    
    int displayX = 500;
    int displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [snapWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    if (snapFirstSecondTime == 1){
        [snap1 setTextColor:[NSColor redColor]];
        [snap2 setTextColor:[NSColor blackColor]];
        [snap1 setStringValue:@"Time A"];
        [snap2 setStringValue:@"Time B"];
    }
    
    if (snapFirstSecondTime == 2){
        [snap1 setTextColor:[NSColor blackColor]];
        [snap2 setTextColor:[NSColor redColor]];
        [snap1 setStringValue:@"Time A"];
        [snap2 setStringValue:@"Time B"];
    }
    
    [xDiff1 setDelegate:self];
    [yDiff1 setDelegate:self];
    
    if (snapPage == 0){
        [xPositionSnap1 setStringValue:@"nil"];
        [yPositionSnap1 setStringValue:@"nil"];
        [xPositionSnap2 setStringValue:@"nil"];
        [yPositionSnap2 setStringValue:@"nil"];
        [zPositionSnap1 setStringValue:@"nil"];
        [zPositionSnap2 setStringValue:@"nil"];
        [xDiff1 setStringValue:@""];
        [yDiff1 setStringValue:@""];
        [pageNo setStringValue:@"nil"];
    }
    else{
        
        [pageNo setIntegerValue:snapPage];
        
        int entryPosition = (snapPage-1)*16;
        arraySnapData [0] = arraySnapMainData [entryPosition]; //----Snap 1 no----
        arraySnapData [1] = arraySnapMainData [entryPosition+1]; //----X Corner Snap 1----
        arraySnapData [2] = arraySnapMainData [entryPosition+2]; //----Y Corner Snap 1----
        arraySnapData [3] = arraySnapMainData [entryPosition+3]; //----Z Corner Snap 1----
        arraySnapData [4] = arraySnapMainData [entryPosition+4]; //----X Position set 1----
        arraySnapData [5] = arraySnapMainData [entryPosition+5]; //----Y Position set 1----
        arraySnapData [6] = arraySnapMainData [entryPosition+6]; //----Snap 2 no----
        arraySnapData [7] = arraySnapMainData [entryPosition+7]; //----X Corner Snap 2----
        arraySnapData [8] = arraySnapMainData [entryPosition+8]; //----Y Corner Snap 2----
        arraySnapData [9] = arraySnapMainData [entryPosition+9]; //----Z Corner Snap 2----
        arraySnapData [10] = arraySnapMainData [entryPosition+10]; //----X Position set 2----
        arraySnapData [11] = arraySnapMainData [entryPosition+11]; //----X Position set 2----
        arraySnapData [12] = arraySnapMainData [entryPosition+12]; //----Set mark----
        arraySnapData [13] = arraySnapMainData [entryPosition+13]; //----X Diff----
        arraySnapData [14] = arraySnapMainData [entryPosition+14]; //----Y Diff----
        arraySnapData [15] = arraySnapMainData [entryPosition+15]; //----Z Diff----
        
        //for (int counterA = 0; counterA < 1; counterA++){
        //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<arraySnapData [counterA*16+counterB];
        //    cout<<" arraySnapData "<<counterA<<" "<<endl;
        //}
        
        //for (int counterA = 0; counterA < snapMainDataCount/16; counterA++){
        //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<arraySnapMainData [counterA*16+counterB];
        //    cout<<" arraySnapMainData "<<counterA<<" "<<endl;
        //}
        
        if (arraySnapData [4] != 0 && arraySnapData [5] != 0){
            [xPositionSnap1 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [4]]];
            [yPositionSnap1 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [5]]];
            [zPositionSnap1 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [3]]];
        }
        else{
            
            [xPositionSnap1 setStringValue:@"nil"];
            [yPositionSnap1 setStringValue:@"nil"];
            [zPositionSnap1 setStringValue:@"nil"];
        }
        
        if (arraySnapData [10] != 0 && arraySnapData [11] != 0){
            [xPositionSnap2 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [10]]];
            [yPositionSnap2 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [11]]];
            [zPositionSnap2 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [9]]];
        }
        else{
            
            [xPositionSnap2 setStringValue:@"nil"];
            [yPositionSnap2 setStringValue:@"nil"];
            [zPositionSnap2 setStringValue:@"nil"];
        }
        
        if (arraySnapData [13] != 0 && arraySnapData [14] != 0){
            int xDifferenceInt = (int)(round (arraySnapData [13]));
            int yDifferenceInt = (int)(round (arraySnapData [14]));
            
            [xDiff1 setIntegerValue:xDifferenceInt];
            [yDiff1 setIntegerValue:yDifferenceInt];
            
            [stepperX1 setMinValue:xDifferenceInt-200];
            [stepperX1 setMaxValue:xDifferenceInt+200];
            [stepperY1 setMinValue:yDifferenceInt-200];
            [stepperY1 setMaxValue:yDifferenceInt+200];
            
            stepperLimitXL1 = xDifferenceInt-200;
            stepperLimitXH1 = xDifferenceInt+200;
            stepperLimitYL1 = yDifferenceInt-200;
            stepperLimitYH1 = yDifferenceInt+200;
            
            [stepperX1 setIntValue:xDifferenceInt];
            [stepperY1 setIntValue:yDifferenceInt];
        }
        else{
            
            [xDiff1 setStringValue:@""];
            [yDiff1 setStringValue:@""];
        }
        
        [stepperStartDisplay1 setDelegate:self];
        
        [stepperStart1 setMinValue:1];
        [stepperStart1 setMaxValue:500];
        [stepperStartDisplay1 setIntValue:1];
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage object:self];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage2 object:self];
}

-(IBAction)closeWindow:(id)sender{
    [snapWindow orderOut:self];
    snapOperation = 2;
    snapTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(IBAction)snapSet1:(id)sender{
    if (imageFirstLoadFlagSnap1 == 1){
        if (snapFirstSecondTime == 1){
            if (arraySnapData [0] != 0){
                if (xClickPositionSnap1 != 0 && yClickPositionSnap1 != 0){
                    if (objectiveSelect == 1){
                        arraySnapData [4] = yClickPositionSnap1*1.04101+arraySnapData [1];
                        arraySnapData [5] = xClickPositionSnap1*1.04101+arraySnapData [2];
                        
                        int entryPosition = (snapPage-1)*16;
                        arraySnapMainData [entryPosition+4] = arraySnapData [4];
                        arraySnapMainData [entryPosition+5] = arraySnapData [5];
                    }
                    else if (objectiveSelect == 2){
                        arraySnapData [4] = yClickPositionSnap1*0.52084+arraySnapData [1];
                        arraySnapData [5] = xClickPositionSnap1*0.52084+arraySnapData [2];
                        
                        int entryPosition = (snapPage-1)*16;
                        arraySnapMainData [entryPosition+4] = arraySnapData [4];
                        arraySnapMainData [entryPosition+5] = arraySnapData [5];
                    }
                    else{
                        
                        arraySnapData [4] = yClickPositionSnap1*0.259589+arraySnapData [1];
                        arraySnapData [5] = xClickPositionSnap1*0.259589+arraySnapData [2];
                        
                        int entryPosition = (snapPage-1)*16;
                        arraySnapMainData [entryPosition+4] = arraySnapData [4];
                        arraySnapMainData [entryPosition+5] = arraySnapData [5];
                    }
                    
                    //for (int counterA = 0; counterA < 1; counterA++){
                    //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<arraySnapData [counterA*16+counterB];
                    //    cout<<" arraySnapData "<<counterA<<" "<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < snapMainDataCount/16; counterA++){
                    //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<arraySnapMainData [counterA*16+counterB];
                    //    cout<<" arraySnapMainData "<<counterA<<" "<<endl;
                    //}
                    
                    [xPositionSnap1 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [4]]];
                    [yPositionSnap1 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [5]]];
                    [zPositionSnap1 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [3]]];
                    
                    ofstream oin;
                    
                    oin.open(snapDataPath1.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < snapMainDataCount; counter1++) oin<<arraySnapMainData [counter1]<<endl;
                    
                    oin.close();
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"No XY Data Set"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Time A Image Found"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Time A Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)snapSet2:(id)sender{
    if (imageFirstLoadFlagSnap2 == 1){
        if (snapFirstSecondTime == 2){
            if (arraySnapData [0] != 0 || arraySnapData [6] != 0){
                if (arraySnapData [4] != 0 || arraySnapData [5] != 0){
                    if (xClickPositionSnap2 != 0 || yClickPositionSnap2 != 0){
                        int entryPosition = (snapPage-1)*16;
                        
                        if (objectiveSelect == 1){
                            arraySnapData [10] = yClickPositionSnap2*1.04101+arraySnapData [7];
                            arraySnapData [11] = xClickPositionSnap2*1.04101+arraySnapData [8];
                            
                            arraySnapMainData [entryPosition+10] = arraySnapData [10];
                            arraySnapMainData [entryPosition+11] = arraySnapData [11];
                        }
                        else if (objectiveSelect == 2){
                            arraySnapData [10] = yClickPositionSnap2*0.52084+arraySnapData [7];
                            arraySnapData [11] = xClickPositionSnap2*0.52084+arraySnapData [8];
                            
                            arraySnapMainData [entryPosition+10] = arraySnapData [10];
                            arraySnapMainData [entryPosition+11] = arraySnapData [11];
                        }
                        else{
                            
                            arraySnapData [10] = yClickPositionSnap2*0.259589+arraySnapData [7];
                            arraySnapData [11] = xClickPositionSnap2*0.259589+arraySnapData [8];
                            
                            arraySnapMainData [entryPosition+10] = arraySnapData [10];
                            arraySnapMainData [entryPosition+11] = arraySnapData [11];
                        }
                        
                        [xPositionSnap2 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [10]]];
                        [yPositionSnap2 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [11]]];
                        [zPositionSnap2 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [9]]];
                        
                        double xDifference = 0;
                        double yDifference = 0;
                        
                        xDifference = arraySnapData [4]-arraySnapData [10];
                        yDifference = arraySnapData [5]-arraySnapData [11];
                        
                        arraySnapData [12] = 1;
                        arraySnapData [13] = xDifference;
                        arraySnapData [14] = yDifference;
                        arraySnapData [15] = arraySnapData [9];
                        
                        arraySnapMainData [entryPosition+12] = arraySnapData [12];
                        arraySnapMainData [entryPosition+13] = arraySnapData [13];
                        arraySnapMainData [entryPosition+14] = arraySnapData [14];
                        arraySnapMainData [entryPosition+15] = arraySnapData [15];
                        
                        int xDifferenceInt = (int)(round (xDifference));
                        int yDifferenceInt = (int)(round (yDifference));
                        
                        [xDiff1 setIntegerValue:xDifferenceInt];
                        [yDiff1 setIntegerValue:yDifferenceInt];
                        
                        [stepperX1 setMinValue:xDifferenceInt-200];
                        [stepperX1 setMaxValue:xDifferenceInt+200];
                        [stepperY1 setMinValue:yDifferenceInt-200];
                        [stepperY1 setMaxValue:yDifferenceInt+200];
                        
                        stepperLimitXL1 = xDifferenceInt-200;
                        stepperLimitXH1 = xDifferenceInt+200;
                        stepperLimitYL1 = yDifferenceInt-200;
                        stepperLimitYH1 = yDifferenceInt+200;
                        
                        [stepperX1 setIntValue:xDifferenceInt];
                        [stepperY1 setIntValue:yDifferenceInt];
                        
                        //for (int counterA = 0; counterA < 1; counterA++){
                        //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<arraySnapData [counterA*16+counterB];
                        //    cout<<" arraySnapData "<<counterA<<" "<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < snapMainDataCount/16; counterA++){
                        //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<arraySnapMainData [counterA*16+counterB];
                        //    cout<<" arraySnapMainData "<<counterA<<" "<<endl;
                        //}
                        
                        ofstream oin;
                        
                        oin.open(snapDataPath1.c_str(), ios::out);
                        
                        for (int counter3 = 0; counter3 < snapMainDataCount; counter3++) oin<<arraySnapMainData [counter3]<<endl;
                        
                        oin.close();
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage2 object:self];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"No XY Data Set"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"No Time A XY Data Set"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Time A/Time B Image Found"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Time B Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)create1:(id)sender{
    if (arraySnapData [12] != 0){
        string stgSaveAdjustPath = informationDirectoryPath+"/Adjust_positions.STG"; //===========================================
        
        ofstream oin;
        
        oin.open(stgSaveAdjustPath.c_str(), ios::out | ios::binary);
        
        ascIIconversion = [[ASCIIconversion alloc] init];
        
        if (oin.is_open()){
            arrayAscIIintData = new int [100];
            ascIIintDataCount = 0;
            
            oin.put(34);
            
            ascIIstring = "Stage Memory List";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(34), oin.put(44), oin.put(32);
            
            ascIIstring = "Version 6.0";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(13), oin.put(10), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
            oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44);
            oin.put(32), oin.put(34), oin.put(117), oin.put(109), oin.put(34), oin.put(44), oin.put(32), oin.put(34), oin.put(117), oin.put(109), oin.put(34);
            oin.put(13), oin.put(10), oin.put(48), oin.put(13), oin.put(10);
            
            ascIIstring = "1";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(13), oin.put(10), oin.put(34);
            
            ascIIstring = "well ";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            //----Well number----
            ascIIstring = "1";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            ascIIstring = " position ";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            //----X position----
            ascIIstring = "1";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            //----Y position----
            ascIIstring = "1";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(34), oin.put(44), oin.put(32);
            
            stringstream extension3;
            extension3 << arraySnapData [7]-(arraySnapData [7]-arraySnapData [1])-arraySnapData [13]; //----X value----
            ascIIstring = extension3.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            //cout<<arraySnapData [1]<<" "<<arraySnapData [7]<<" "<<arraySnapData [13]<<" "<<arraySnapData [7]-(arraySnapData [7]-arraySnapData [1])-arraySnapData [13]<<" XPosition"<<endl;
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            stringstream extension4;
            extension4 << arraySnapData [8]+(arraySnapData [8]-arraySnapData [2])+arraySnapData [14]; //----Y value----
            ascIIstring = extension4.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            //cout<<arraySnapData [2]<<" "<<arraySnapData [8]<<" "<<arraySnapData [14]<<" "<<arraySnapData [8]+(arraySnapData [8]-arraySnapData [2])+arraySnapData [14]<<" yPosition"<<endl;
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            stringstream extension5;
            
            extension5 << arraySnapData [15]; //----Z value----
            ascIIstring = extension5.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
            
            ascIIstring = "FALSE";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            ascIIstring = "-9999";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            ascIIstring = "TRUE";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            ascIIstring = "TRUE";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(45), oin.put(49), oin.put(44);
            oin.put(32), oin.put(34), oin.put(34), oin.put(44), oin.put(13), oin.put(10);
            
            oin.close();
            
            delete [] arrayAscIIintData;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Saved Position Data In Chamber 1"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)createSnap1:(id)sender{
    if (arraySnapData [0] != 0){
        string stgSaveAdjustPath = informationDirectoryPath+"/Adjust_positions.STG"; //===========================================
        
        ofstream oin;
        
        oin.open(stgSaveAdjustPath.c_str(), ios::out | ios::binary);
        
        ascIIconversion = [[ASCIIconversion alloc] init];
        
        if (oin.is_open()){
            arrayAscIIintData = new int [100];
            ascIIintDataCount = 0;
            
            oin.put(34);
            
            ascIIstring = "Stage Memory List";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(34), oin.put(44), oin.put(32);
            
            ascIIstring = "Version 6.0";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(13), oin.put(10), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
            oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44);
            oin.put(32), oin.put(34), oin.put(117), oin.put(109), oin.put(34), oin.put(44), oin.put(32), oin.put(34), oin.put(117), oin.put(109), oin.put(34);
            oin.put(13), oin.put(10), oin.put(48), oin.put(13), oin.put(10);
            
            ascIIstring = "1";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(13), oin.put(10), oin.put(34);
            
            ascIIstring = "well ";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            //----Well number----
            ascIIstring = "1";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            ascIIstring = " position ";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            //----X position----
            ascIIstring = "1";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            //----Y position----
            ascIIstring = "1";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(34), oin.put(44), oin.put(32);
            
            stringstream extension3;
            extension3 << arraySnapData [1]; //----X value----
            ascIIstring = extension3.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            stringstream extension4;
            extension4 << arraySnapData [2]; //----Y value----
            ascIIstring = extension4.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            stringstream extension5;
            
            extension5 << arraySnapData [3]; //----Z value----
            ascIIstring = extension5.str();
            
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
            
            ascIIstring = "FALSE";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            ascIIstring = "-9999";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            ascIIstring = "TRUE";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32);
            
            ascIIstring = "TRUE";
            ascIIintDataCount = [ascIIconversion ascIICode];
            
            for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
            
            oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(45), oin.put(49), oin.put(44);
            oin.put(32), oin.put(34), oin.put(34), oin.put(44), oin.put(13), oin.put(10);
            
            oin.close();
            
            delete [] arrayAscIIintData;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Saved position data in chamber 1"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)createMain1:(id)sender{
    if (arraySnapData [12] != 0){
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"MDA For IF Will Be Created"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            int stringLength = (int)bodyName.length();
            string stringExtract = bodyName.substr((unsigned long)stringLength-2);
            string stgIFSavePath;
            
            if (stringExtract == "IF"){
                stgIFSavePath = informationDirectoryPath+"/"+bodyName+"_positions.STG"; //===========================================
            }
            else stgIFSavePath = informationDirectoryPath+"/"+bodyName+"IF_positions.STG"; //===========================================
            
            string dataString;
            
            ifstream fin;
            
            fin.open(savedDataLastSavePath.c_str(), ios::in);
            
            if (fin.is_open()){
                int mapEnterCount1 = 0;
                int mapEnterCount2 = 0;
                int readingFlag = 0;
                int terminationFlag = 0;
                
                do{
                    
                    terminationFlag = 1;
                    
                    getline(fin, dataString);
                    
                    if (dataString == "SelectedFOV1") readingFlag = 3;
                    else if (readingFlag == 3 && dataString != "SelectedFOV2") mapEnterCount1++;
                    
                    if (dataString == "SelectedFOV2") readingFlag = 4;
                    else if (readingFlag == 4 && dataString != "END") mapEnterCount2++;
                    
                    if (dataString == "END") terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                fin.close();
                
                double *arrayMapTemp1 = new double [mapEnterCount1+50];
                double *arrayMapTemp2 = new double [mapEnterCount2+50];
                
                mapEnterCount1 = 0;
                mapEnterCount2 = 0;
                readingFlag = 0;
                
                fin.open(savedDataLastSavePath.c_str(), ios::in);
                
                if (fin.is_open()){
                    do{
                        
                        terminationFlag = 1;
                        
                        getline(fin, dataString);
                        
                        if (dataString == "SelectedFOV1") readingFlag = 3;
                        else if (readingFlag == 3 && dataString != "SelectedFOV2"){
                            arrayMapTemp1 [mapEnterCount1] = atof(dataString.c_str()), mapEnterCount1++;
                        }
                        
                        if (dataString == "SelectedFOV2") readingFlag = 4;
                        else if (readingFlag == 4 && dataString != "END"){
                            arrayMapTemp2 [mapEnterCount2] = atof(dataString.c_str()), mapEnterCount2++;
                        }
                        
                        if (dataString == "END") terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    fin.close();
                }
                
                //for (int counterA = 0; counterA < mapEnterCount1/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayMapTemp1 [counterA*6+counterB];
                //    cout<<" arrayMapTemp1 "<<counterA<<endl;
                //}
                
                if (arraySnapData [12] != 0){
                    double *arrayMapTemp = new double [mapEnterCount1+50];
                    int mapTempCount = 0;
                    
                    for (int counter1 = 1; counter1 <= chamberWellLimit1; counter1++){
                        for (int counter2 = 0; counter2 < mapEnterCount1/6; counter2++){
                            if (arrayMapTemp1 [counter2*6] == counter1){
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+1], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+2], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+3], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+4], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+5], mapTempCount++;
                            }
                        }
                    }
                    
                    mapEnterCount1 = 0;
                    
                    for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp1 [mapEnterCount1] = arrayMapTemp [counter1], mapEnterCount1++;
                    
                    //for (int counterA = 0; counterA < mapEnterCount1/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayMapTemp1 [counterA*6+counterB];
                    //    cout<<" arrayMapTemp1 "<<counterA<<endl;
                    //}
                    
                    int selectedFOVCount = mapEnterCount1/6;
                    
                    if (selectedFOVCount != 0){
                        double xDiffAdjust = arraySnapData [1]-(arraySnapData [7]-(arraySnapData [7]-arraySnapData [1])-arraySnapData [13]);
                        double yDiffAdjust = arraySnapData [2]-(arraySnapData [8]+(arraySnapData [8]-arraySnapData [2])+arraySnapData [14]);
                        
                        for (int counter1 = 0; counter1 < selectedFOVCount; counter1++){
                            arrayMapTemp1 [counter1*6+3] = arrayMapTemp1 [counter1*6+3]-xDiffAdjust;
                            arrayMapTemp1 [counter1*6+4] = arrayMapTemp1 [counter1*6+4]-yDiffAdjust;
                        }
                    }
                    
                    delete [] arrayMapTemp;
                }
                
                if (arraySnapData2 [12] != 0){
                    double *arrayMapTemp = new double [mapEnterCount2+50];
                    int mapTempCount = 0;
                    
                    for (int counter1 = chamberWellLimit1+1; counter1 <= chamberWellLimit1+chamberWellLimit2; counter1++){
                        for (int counter2 = 0; counter2 < mapEnterCount2/6; counter2++){
                            if (arrayMapTemp2 [counter2*6] == counter1){
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+1], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+2], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+3], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+4], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+5], mapTempCount++;
                            }
                        }
                    }
                    
                    mapEnterCount2 = 0;
                    
                    for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp2 [mapEnterCount2] = arrayMapTemp [counter1], mapEnterCount2++;
                    
                    int selectedFOVCount = mapEnterCount2/6;
                    
                    if (selectedFOVCount != 0){
                        double xDiffAdjust = arraySnapData2 [1]-(arraySnapData2 [7]-(arraySnapData2 [7]-arraySnapData2 [1])-arraySnapData2 [13]);
                        double yDiffAdjust = arraySnapData2 [2]-(arraySnapData2 [8]+(arraySnapData2 [8]-arraySnapData2 [2])+arraySnapData2 [14]);
                        
                        for (int counter1 = 0; counter1 < selectedFOVCount; counter1++){
                            arrayMapTemp2 [counter1*6+3] = arrayMapTemp2 [counter1*6+3]-xDiffAdjust;
                            arrayMapTemp2 [counter1*6+4] = arrayMapTemp2 [counter1*6+4]-yDiffAdjust;
                        }
                    }
                    
                    delete [] arrayMapTemp;
                }
                
                int selectedFOVCount1 = mapEnterCount1/6;
                int selectedFOVCount2 = mapEnterCount2/6;
                
                if (selectedFOVCount1 != 0){
                    double *arrayMapTemp = new double [mapEnterCount1+50];
                    int mapTempCount = 0;
                    
                    for (int counter1 = 1; counter1 <= chamberWellLimit1; counter1++){
                        for (int counter2 = 0; counter2 < selectedFOVCount1; counter2++){
                            if (arrayMapTemp1 [counter2*6] == counter1){
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+1], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+2], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+3], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+4], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+5], mapTempCount++;
                            }
                        }
                    }
                    
                    mapEnterCount1 = 0;
                    
                    for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp1 [mapEnterCount1] = arrayMapTemp [counter1], mapEnterCount1++;
                    
                    delete [] arrayMapTemp;
                }
                
                if (selectedFOVCount2 != 0){
                    double *arrayMapTemp = new double [mapEnterCount2+50];
                    int mapTempCount = 0;
                    
                    for (int counter1 = chamberWellLimit1+1; counter1 <= chamberWellLimit1+chamberWellLimit2; counter1++){
                        for (int counter2 = 0; counter2 < selectedFOVCount2; counter2++){
                            if (arrayMapTemp2 [counter2*6] == counter1){
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+1], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+2], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+3], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+4], mapTempCount++;
                                arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+5], mapTempCount++;
                            }
                        }
                    }
                    
                    mapEnterCount2 = 0;
                    
                    for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp2 [mapEnterCount2] = arrayMapTemp [counter1], mapEnterCount2++;
                    
                    delete [] arrayMapTemp;
                }
                
                if (selectedFOVCount1+selectedFOVCount2 != 0){
                    ofstream oin;
                    
                    oin.open(stgIFSavePath.c_str(), ios::out | ios::binary);
                    
                    ascIIconversion = [[ASCIIconversion alloc] init];
                    
                    if (oin.is_open()){
                        arrayAscIIintData = new int [100];
                        ascIIintDataCount = 0;
                        
                        oin.put(34);
                        
                        ascIIstring = "Stage Memory List";
                        ascIIintDataCount = [ascIIconversion ascIICode];
                        
                        for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
                        
                        oin.put(34), oin.put(44), oin.put(32);
                        
                        ascIIstring = "Version 6.0";
                        ascIIintDataCount = [ascIIconversion ascIICode];
                        
                        for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
                        
                        oin.put(13), oin.put(10), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
                        oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44);
                        oin.put(32), oin.put(34), oin.put(117), oin.put(109), oin.put(34), oin.put(44), oin.put(32), oin.put(34), oin.put(117), oin.put(109), oin.put(34);
                        oin.put(13), oin.put(10), oin.put(48), oin.put(13), oin.put(10);
                        
                        ascIIstring = to_string(selectedFOVCount1+selectedFOVCount2);
                        ascIIintDataCount = [ascIIconversion ascIICode];
                        
                        for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
                        
                        oin.put(13), oin.put(10);
                        
                        if (selectedFOVCount1 != 0){
                            for (int counter1 = 0; counter1 < selectedFOVCount1; counter1++){
                                oin.put(34);
                                
                                ascIIstring = "well ";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                stringstream extension;
                                extension << arrayMapTemp1 [counter1*6]; //----Well number----
                                ascIIstring = extension.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                ascIIstring = " position ";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                stringstream extension1;
                                extension1 << arrayMapTemp1 [counter1*6+1]; //----X position----
                                ascIIstring = extension1.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                stringstream extension2;
                                extension2 << arrayMapTemp1 [counter1*6+2]; //----Y position----
                                ascIIstring = extension2.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(34), oin.put(44), oin.put(32);
                                
                                stringstream extension3;
                                extension3 << arrayMapTemp1 [counter1*6+3]; //----X value----
                                ascIIstring = extension3.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                stringstream extension4;
                                extension4 << arrayMapTemp1 [counter1*6+4]; //----Y value----
                                ascIIstring = extension4.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                stringstream extension5;
                                extension5 << arrayMapTemp1 [counter1*6+5]; //----Z value----
                                ascIIstring = extension5.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
                                
                                ascIIstring = "FALSE";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                ascIIstring = "-9999";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                ascIIstring = "TRUE";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                ascIIstring = "TRUE";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(45), oin.put(49), oin.put(44);
                                oin.put(32), oin.put(34), oin.put(34), oin.put(44), oin.put(13), oin.put(10);
                            }
                        }
                        
                        if (selectedFOVCount2 != 0){
                            for (int counter1 = 0; counter1 < selectedFOVCount2; counter1++){
                                oin.put(34);
                                
                                ascIIstring = "well ";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                stringstream extension;
                                extension << arrayMapTemp2 [counter1*6]; //----Well number----
                                ascIIstring = extension.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                ascIIstring = " position ";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                stringstream extension1;
                                extension1 << arrayMapTemp2 [counter1*6+1]; //----X position----
                                ascIIstring = extension1.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                stringstream extension2;
                                extension2 << arrayMapTemp2 [counter1*6+2]; //----Y position----
                                ascIIstring = extension2.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(34), oin.put(44), oin.put(32);
                                
                                stringstream extension3;
                                extension3 << arrayMapTemp2 [counter1*6+3]; //----X value----
                                ascIIstring = extension3.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                stringstream extension4;
                                extension4 << arrayMapTemp2 [counter1*6+4]; //----Y value----
                                ascIIstring = extension4.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                stringstream extension5;
                                extension5 << arrayMapTemp2 [counter1*6+5]; //----Z value----
                                ascIIstring = extension5.str();
                                
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
                                
                                ascIIstring = "FALSE";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                ascIIstring = "-9999";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                ascIIstring = "TRUE";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32);
                                
                                ascIIstring = "TRUE";
                                ascIIintDataCount = [ascIIconversion ascIICode];
                                
                                for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                                
                                oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(45), oin.put(49), oin.put(44);
                                oin.put(32), oin.put(34), oin.put(34), oin.put(44), oin.put(13), oin.put(10);
                            }
                        }
                        
                        oin.close();
                        
                        delete [] arrayAscIIintData;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                }
                
                delete [] arrayMapTemp1;
                delete [] arrayMapTemp2;
            }
            else{
                
                NSAlert *alert2 = [[NSAlert alloc] init];
                [alert2 addButtonWithTitle:@"OK"];
                [alert2 setMessageText:@"No Saved file was found"];
                [alert2 setAlertStyle:NSAlertStyleWarning];
                [alert2 runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Found"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)createTest1:(id)sender{
    if (arraySnapData [12] != 0){
        string stgSaveAdjustPath = informationDirectoryPath+"/Atest_positions.STG";
        string dataString;
        
        ifstream fin;
        
        fin.open(savedDataLastSavePath.c_str(), ios::in);
        
        if (fin.is_open()){
            int mapEnterCount1 = 0;
            int mapEnterCount2 = 0;
            int readingFlag = 0;
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                
                getline(fin, dataString);
                
                if (dataString == "SelectedFOV1") readingFlag = 3;
                else if (readingFlag == 3 && dataString != "SelectedFOV2") mapEnterCount1++;
                
                if (dataString == "SelectedFOV2") readingFlag = 4;
                else if (readingFlag == 4 && dataString != "END") mapEnterCount2++;
                
                if (dataString == "END") terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            fin.close();
            
            double *arrayMapTemp1 = new double [mapEnterCount1+50];
            double *arrayMapTemp2 = new double [mapEnterCount2+50];
            
            mapEnterCount1 = 0;
            mapEnterCount2 = 0;
            readingFlag = 0;
            
            fin.open(savedDataLastSavePath.c_str(), ios::in);
            
            if (fin.is_open()){
                do{
                    
                    terminationFlag = 1;
                    
                    getline(fin, dataString);
                    
                    if (dataString == "SelectedFOV1") readingFlag = 3;
                    else if (readingFlag == 3 && dataString != "SelectedFOV2"){
                        arrayMapTemp1 [mapEnterCount1] = atof(dataString.c_str()), mapEnterCount1++;
                    }
                    
                    if (dataString == "SelectedFOV2") readingFlag = 4;
                    else if (readingFlag == 4 && dataString != "END"){
                        arrayMapTemp2 [mapEnterCount2] = atof(dataString.c_str()), mapEnterCount2++;
                    }
                    
                    if (dataString == "END") terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                fin.close();
            }
            
            //for (int counterA = 0; counterA < mapEnterCount1/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayMapTemp1 [counterA*6+counterB];
            //    cout<<" arrayMapTemp1 "<<counterA<<endl;
            //}
            
            if (arraySnapData [12] != 0){
                double *arrayMapTemp = new double [mapEnterCount1+50];
                int mapTempCount = 0;
                
                for (int counter1 = 1; counter1 <= chamberWellLimit1; counter1++){
                    for (int counter2 = 0; counter2 < mapEnterCount1/6; counter2++){
                        if (arrayMapTemp1 [counter2*6] == counter1){
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+1], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+2], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+3], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+4], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+5], mapTempCount++;
                        }
                    }
                }
                
                mapEnterCount1 = 0;
                
                for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp1 [mapEnterCount1] = arrayMapTemp [counter1], mapEnterCount1++;
                
                //for (int counterA = 0; counterA < mapEnterCount1/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayMapTemp1 [counterA*6+counterB];
                //    cout<<" arrayMapTemp1 "<<counterA<<endl;
                //}
                
                int selectedFOVCount = mapEnterCount1/6;
                
                if (selectedFOVCount != 0){
                    double xDiffAdjust = arraySnapData [1]-(arraySnapData [7]-(arraySnapData [7]-arraySnapData [1])-arraySnapData [13]);
                    double yDiffAdjust = arraySnapData [2]-(arraySnapData [8]+(arraySnapData [8]-arraySnapData [2])+arraySnapData [14]);
                    
                    for (int counter1 = 0; counter1 < selectedFOVCount; counter1++){
                        arrayMapTemp1 [counter1*6+3] = arrayMapTemp1 [counter1*6+3]-xDiffAdjust;
                        arrayMapTemp1 [counter1*6+4] = arrayMapTemp1 [counter1*6+4]-yDiffAdjust;
                    }
                }
                
                delete [] arrayMapTemp;
            }
            
            if (arraySnapData2 [12] != 0){
                double *arrayMapTemp = new double [mapEnterCount2+50];
                int mapTempCount = 0;
                
                for (int counter1 = chamberWellLimit1+1; counter1 <= chamberWellLimit1+chamberWellLimit2; counter1++){
                    for (int counter2 = 0; counter2 < mapEnterCount2/6; counter2++){
                        if (arrayMapTemp2 [counter2*6] == counter1){
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+1], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+2], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+3], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+4], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+5], mapTempCount++;
                        }
                    }
                }
                
                mapEnterCount2 = 0;
                
                for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp2 [mapEnterCount2] = arrayMapTemp [counter1], mapEnterCount2++;
                
                int selectedFOVCount = mapEnterCount2/6;
                
                if (selectedFOVCount != 0){
                    double xDiffAdjust = arraySnapData2 [1]-(arraySnapData2 [7]-(arraySnapData2 [7]-arraySnapData2 [1])-arraySnapData2 [13]);
                    double yDiffAdjust = arraySnapData2 [2]-(arraySnapData2 [8]+(arraySnapData2 [8]-arraySnapData2 [2])+arraySnapData2 [14]);
                    
                    for (int counter1 = 0; counter1 < selectedFOVCount; counter1++){
                        arrayMapTemp2 [counter1*6+3] = arrayMapTemp2 [counter1*6+3]-xDiffAdjust;
                        arrayMapTemp2 [counter1*6+4] = arrayMapTemp2 [counter1*6+4]-yDiffAdjust;
                    }
                }
                
                delete [] arrayMapTemp;
            }
            
            for (int counter2 = 0; counter2 <= 16; counter2++){
                wellPositionTest [counter2*2] = -1;
                wellPositionTest [counter2*2+1] = -1;
            }
            
            int selectedFOVCount1 = mapEnterCount1/6;
            int selectedFOVCount2 = mapEnterCount2/6;
            
            if (selectedFOVCount1 != 0){
                double *arrayMapTemp = new double [mapEnterCount1+50];
                int mapTempCount = 0;
                int fovPositionCount = 0;
                
                for (int counter2 = 1; counter2 <= 16; counter2++){
                    for (int counter3 = 0; counter3 < selectedFOVCount1; counter3++){
                        if (arrayMapTemp1 [counter3*6] == counter2){
                            fovPositionCount = 1;
                            
                            for (int counter4 = counter3; counter4 < selectedFOVCount1; counter4++){
                                if (fovPositionCount == stepperStartHold1){
                                    arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter4*6], mapTempCount++;
                                    arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter4*6+1], mapTempCount++;
                                    arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter4*6+2], mapTempCount++;
                                    arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter4*6+3], mapTempCount++;
                                    arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter4*6+4], mapTempCount++;
                                    arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter4*6+5], mapTempCount++;
                                    break;
                                }
                                else fovPositionCount++;
                            }
                            
                            break;
                        }
                    }
                }
                
                mapEnterCount1 = 0;
                
                for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp1 [mapEnterCount1] = arrayMapTemp [counter1], mapEnterCount1++;
                
                mapTempCount = 0;
                
                for (int counter1 = 1; counter1 <= chamberWellLimit1; counter1++){
                    for (int counter2 = 0; counter2 < mapEnterCount1/6; counter2++){
                        if (arrayMapTemp1 [counter2*6] == counter1){
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+1], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+2], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+3], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+4], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp1 [counter2*6+5], mapTempCount++;
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < mapTempCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayMapTemp1 [counterA*6+counterB];
                //    cout<<" arrayMapTemp1 "<<counterA<<endl;
                //}
                
                mapEnterCount1 = 0;
                
                for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp1 [mapEnterCount1] = arrayMapTemp [counter1], mapEnterCount1++;
                
                delete [] arrayMapTemp;
                
                for (int counter1 = 0; counter1 < mapEnterCount1/6; counter1++){
                    if (wellPositionTest [(int)arrayMapTemp1 [counter1*6]*2] == -1){
                        wellPositionTest [(int)arrayMapTemp1 [counter1*6]*2] = counter1+1;
                        wellPositionTest [(int)arrayMapTemp1 [counter1*6]*2+1] = counter1+1;
                    }
                    else wellPositionTest [(int)arrayMapTemp1 [counter1*6]*2+1] = counter1+1;
                }
            }
            
            if (selectedFOVCount2 != 0){
                double *arrayMapTemp = new double [mapEnterCount2+50];
                int mapTempCount = 0;
                int fovPositionCount = 0;
                
                for (int counter2 = 1; counter2 <= 16; counter2++){
                    for (int counter3 = 0; counter3 < selectedFOVCount2; counter3++){
                        if (arrayMapTemp2 [counter3*6] == counter2){
                            fovPositionCount = 1;
                            
                            for (int counter4 = counter3; counter4 < selectedFOVCount2; counter4++){
                                if (fovPositionCount == stepperStartHold2){
                                    arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter4*6], mapTempCount++;
                                    arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter4*6+1], mapTempCount++;
                                    arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter4*6+2], mapTempCount++;
                                    arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter4*6+3], mapTempCount++;
                                    arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter4*6+4], mapTempCount++;
                                    arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter4*6+5], mapTempCount++;
                                    break;
                                }
                                else fovPositionCount++;
                            }
                            
                            break;
                        }
                    }
                }
                
                mapEnterCount2 = 0;
                
                for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp2 [mapEnterCount2] = arrayMapTemp [counter1], mapEnterCount2++;
                
                mapTempCount = 0;
                
                for (int counter1 = chamberWellLimit1+1; counter1 <= chamberWellLimit1+chamberWellLimit2; counter1++){
                    for (int counter2 = 0; counter2 < mapEnterCount2/6; counter2++){
                        if (arrayMapTemp2 [counter2*6] == counter1){
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+1], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+2], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+3], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+4], mapTempCount++;
                            arrayMapTemp [mapTempCount] = arrayMapTemp2 [counter2*6+5], mapTempCount++;
                        }
                    }
                }
                
                mapEnterCount2 = 0;
                
                for (int counter1 = 0; counter1 < mapTempCount; counter1++) arrayMapTemp2 [mapEnterCount2] = arrayMapTemp [counter1], mapEnterCount2++;
                
                delete [] arrayMapTemp;
                
                for (int counter1 = 0; counter1 < mapEnterCount2/6; counter1++){
                    if (wellPositionTest [(int)arrayMapTemp2 [counter1*6]*2] == -1){
                        wellPositionTest [(int)arrayMapTemp2 [counter1*6]*2] = counter1+1;
                        wellPositionTest [(int)arrayMapTemp2 [counter1*6]*2+1] = counter1+1;
                    }
                    else wellPositionTest [(int)arrayMapTemp2 [counter1*6]*2+1] = counter1+1;
                }
            }
            
            if (mapEnterCount1/6+mapEnterCount2/6 != 0){
                ofstream oin;
                
                oin.open(stgSaveAdjustPath.c_str(), ios::out | ios::binary);
                
                ascIIconversion = [[ASCIIconversion alloc] init];
                
                if (oin.is_open()){
                    arrayAscIIintData = new int [100];
                    ascIIintDataCount = 0;
                    
                    oin.put(34);
                    
                    ascIIstring = "Stage Memory List";
                    ascIIintDataCount = [ascIIconversion ascIICode];
                    
                    for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
                    
                    oin.put(34), oin.put(44), oin.put(32);
                    
                    ascIIstring = "Version 6.0";
                    ascIIintDataCount = [ascIIconversion ascIICode];
                    
                    for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
                    
                    oin.put(13), oin.put(10), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
                    oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44);
                    oin.put(32), oin.put(34), oin.put(117), oin.put(109), oin.put(34), oin.put(44), oin.put(32), oin.put(34), oin.put(117), oin.put(109), oin.put(34);
                    oin.put(13), oin.put(10), oin.put(48), oin.put(13), oin.put(10);
                    
                    ascIIstring = to_string(mapEnterCount1/6+mapEnterCount2/6);
                    ascIIintDataCount = [ascIIconversion ascIICode];
                    
                    for (int counter1 = 0; counter1 < ascIIintDataCount; counter1++) oin.put((char)arrayAscIIintData [counter1]);
                    
                    oin.put(13), oin.put(10);
                    
                    if (mapEnterCount1/6 != 0){
                        for (int counter1 = 0; counter1 < mapEnterCount1/6; counter1++){
                            oin.put(34);
                            
                            ascIIstring = "well ";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            stringstream extension;
                            extension << arrayMapTemp1 [counter1*6]; //----Well number----
                            ascIIstring = extension.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            ascIIstring = " position ";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            stringstream extension1;
                            extension1 << arrayMapTemp1 [counter1*6+1]; //----X position----
                            ascIIstring = extension1.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            stringstream extension2;
                            extension2 << arrayMapTemp1 [counter1*6+2]; //----Y position----
                            ascIIstring = extension2.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(34), oin.put(44), oin.put(32);
                            
                            stringstream extension3;
                            extension3 << arrayMapTemp1 [counter1*6+3]; //----X value----
                            ascIIstring = extension3.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            stringstream extension4;
                            extension4 << arrayMapTemp1 [counter1*6+4]; //----Y value----
                            ascIIstring = extension4.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            stringstream extension5;
                            extension5 << arrayMapTemp1 [counter1*6+5]; //----Z value----
                            ascIIstring = extension5.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
                            
                            ascIIstring = "FALSE";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            ascIIstring = "-9999";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            ascIIstring = "TRUE";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            ascIIstring = "TRUE";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(45), oin.put(49), oin.put(44);
                            oin.put(32), oin.put(34), oin.put(34), oin.put(44), oin.put(13), oin.put(10);
                        }
                    }
                    
                    if (mapEnterCount2/6 != 0){
                        for (int counter1 = 0; counter1 < mapEnterCount2/6; counter1++){
                            oin.put(34);
                            
                            ascIIstring = "well ";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            stringstream extension;
                            extension << arrayMapTemp2 [counter1*6]; //----Well number----
                            ascIIstring = extension.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            ascIIstring = " position ";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            stringstream extension1;
                            extension1 << arrayMapTemp2 [counter1*6+1]; //----X position----
                            ascIIstring = extension1.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            stringstream extension2;
                            extension2 << arrayMapTemp2 [counter1*6+2]; //----Y position----
                            ascIIstring = extension2.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(34), oin.put(44), oin.put(32);
                            
                            stringstream extension3;
                            extension3 << arrayMapTemp2 [counter1*6+3]; //----X value----
                            ascIIstring = extension3.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            stringstream extension4;
                            extension4 << arrayMapTemp2 [counter1*6+4]; //----Y value----
                            ascIIstring = extension4.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            stringstream extension5;
                            extension5 << arrayMapTemp2 [counter1*6+5]; //----Z value----
                            ascIIstring = extension5.str();
                            
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32);
                            
                            ascIIstring = "FALSE";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            ascIIstring = "-9999";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            ascIIstring = "TRUE";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32);
                            
                            ascIIstring = "TRUE";
                            ascIIintDataCount = [ascIIconversion ascIICode];
                            
                            for (int counter2 = 0; counter2 < ascIIintDataCount; counter2++) oin.put((char)arrayAscIIintData [counter2]);
                            
                            oin.put(44), oin.put(32), oin.put(48), oin.put(44), oin.put(32), oin.put(45), oin.put(49), oin.put(44);
                            oin.put(32), oin.put(34), oin.put(34), oin.put(44), oin.put(13), oin.put(10);
                        }
                    }
                    
                    oin.close();
                    
                    delete [] arrayAscIIintData;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
            }
            
            delete [] arrayMapTemp1;
            delete [] arrayMapTemp2;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Saved file was found"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Found"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageLoad:(id)sender{
    /*
     Read tif file from imaging computer and then save it to 11_System data folder with SNAP no.
     */
    
    if (snapPage != 100){
        ifstream fin;
        
        fin.open(informationDirectoryPath.c_str(), ios::in);
        
        if (fin.is_open()){
            fin.close();
            
            if (snapFirstSecondTime == 1){
                int lastSnapNo = 0;
                
                for (int counter1 = 0; counter1 < snapMainDataCount/16; counter1++){
                    if (arraySnapMainData [counter1*16] != 0) lastSnapNo = (int)arraySnapMainData [counter1*16];
                }
                
                string entry;
                
                fileDeleteCount = 0;
                
                DIR *dir;
                struct dirent *dent;
                
                dir = opendir(informationDirectoryPath.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                            arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                        }
                    }
                    
                    closedir(dir);
                    
                    string snapFilePath2;
                    string extension;
                    
                    unsigned long nextAddress = 0;
                    unsigned long stripFirstAddress = 0;
                    unsigned long stripByteCountAddress = 0;
                    unsigned long headPosition = 0;
                    unsigned long stripEntry = 0;
                    long sizeForCopy = 0;
                    
                    double xPosition = 0;
                    double yPosition = 0;
                    double zPosition = 0;
                    
                    int imageWidth = 0;
                    int imageHeight = 0;
                    int imageBit = 0; //Check 8, 16
                    int imageCompression = 0; //Check 1
                    int photoMetric = 0; //Check 0, 1, 2
                    int verticalBmp = 0;
                    int horizontalBmp = 0;
                    int endianType = 0;
                    int samplePerPix = 0;
                    int dataConversion [4];
                    int processType = 0; //----Out put image 8 bit gray
                    int numberOfLayers = 0;
                    int mode = 0;
                    
                    struct stat sizeOfFile;
                    
                    ofstream oin;
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                        entry = arrayFileDelete [counter1];
                        
                        if ((int)entry.find("Snap") != -1){
                            if (lastSnapNo == 0) lastSnapNo = 1;
                            else if (lastSnapNo != 0) lastSnapNo = lastSnapNo+2;
                            
                            extension = to_string(lastSnapNo);
                            
                            if (extension.length() == 1) extension = "00"+extension;
                            else if (extension.length() == 2) extension = "0"+extension;
                            
                            snapFilePath2 = informationDirectoryPath+"/"+entry;
                            fileSavePathHold = cellTrackingSystemDataPath+"/"+"SnapA-"+extension;
                            
                            //----File Read----
                            if (stat(snapFilePath2.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                fileReadArray = new uint8_t [sizeForCopy+4];
                                fin.open(snapFilePath2.c_str(), ios::in | ios::binary);
                                
                                fin.read((char*)fileReadArray, sizeForCopy+1);
                                fin.close();
                                
                                dataConversion [0] = fileReadArray [0];
                                dataConversion [1] = fileReadArray [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = fileReadArray [7];
                                    dataConversion [1] = fileReadArray [6];
                                    dataConversion [2] = fileReadArray [5];
                                    dataConversion [3] = fileReadArray [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = fileReadArray [4];
                                    dataConversion [1] = fileReadArray [5];
                                    dataConversion [2] = fileReadArray [6];
                                    dataConversion [3] = fileReadArray [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                int *arrayExtractedImage3 = new int [100];
                                
                                if (endianType == 1){ //----Big endian----
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers:&zPosition];
                                    
                                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && numberOfLayers == 1 && samplePerPix <= 4 && photoMetric < 3 && imageWidth == cameraDimension && imageHeight == cameraDimension){
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:cameraDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                    }
                                }
                                else if (endianType == 0){
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers:&zPosition];
                                    
                                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && numberOfLayers == 1 && samplePerPix <= 4 && photoMetric < 3 && imageWidth == cameraDimension && imageHeight == cameraDimension){
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:cameraDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                    }
                                }
                                
                                //cout<<imageCompression<<" "<<imageBit<<" "<<" "<<samplePerPix<<" "<<photoMetric<<" "<<zPosition<<" "<<imageWidth<<" "<<cameraDimension<<" "<<numberOfLayers<<" entryinfo"<<endl;
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && numberOfLayers == 1 && samplePerPix <= 4 && photoMetric < 3 && imageWidth == cameraDimension && imageHeight == cameraDimension){
                                    horizontalBmp = 0;
                                    verticalBmp = 0;
                                    
                                    //----Saved image----
                                    arrayImageFileSave = new int *[cameraDimension+1];
                                    
                                    for (int counter3 = 0; counter3 < cameraDimension+1; counter3++){
                                        arrayImageFileSave [counter3] = new int [cameraDimension+1];
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cameraDimension; counter3++){
                                        for (int counter4 = 0; counter4 < cameraDimension; counter4++){
                                            arrayImageFileSave [counter3][counter4] = 0;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cameraDimension*cameraDimension; counter3++){
                                        if (horizontalBmp < cameraDimension){
                                            arrayImageFileSave [verticalBmp][horizontalBmp] = arrayExtractedImage3 [counter3], horizontalBmp++;
                                        }
                                        
                                        if (horizontalBmp == cameraDimension){
                                            horizontalBmp = 0;
                                            verticalBmp++;
                                        }
                                    }
                                    
                                    photoMetric = 1;
                                    imageBit = 8;
                                    
                                    if (xPosition == -1) xPosition = 100;
                                    if (yPosition == -1) yPosition = 100;
                                    if (zPosition == -1) zPosition = 100;
                                    
                                    singleTiffSave = [[SingleTiffSave alloc] init];
                                    [singleTiffSave singleTiffLayerSave:cameraDimension:cameraDimension:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:(unsigned long)mode:zPosition];
                                    
                                    for (int counter3 = 0; counter3 < cameraDimension+1; counter3++){
                                        delete [] arrayImageFileSave [counter3];
                                    }
                                    
                                    delete [] arrayImageFileSave;
                                    
                                    snapPage = (lastSnapNo+1)/2;
                                    
                                    arraySnapMainData [snapMainDataCount] = lastSnapNo, snapMainDataCount++;
                                    arraySnapMainData [snapMainDataCount] = xPosition, snapMainDataCount++;
                                    arraySnapMainData [snapMainDataCount] = yPosition, snapMainDataCount++;
                                    arraySnapMainData [snapMainDataCount] = zPosition, snapMainDataCount++;
                                    arraySnapMainData [snapMainDataCount] = 0, snapMainDataCount++;
                                    arraySnapMainData [snapMainDataCount] = 0, snapMainDataCount++;
                                    arraySnapMainData [snapMainDataCount] = 0, snapMainDataCount++;
                                    arraySnapMainData [snapMainDataCount] = 0, snapMainDataCount++;
                                    arraySnapMainData [snapMainDataCount] = 0, snapMainDataCount++;
                                    arraySnapMainData [snapMainDataCount] = 0, snapMainDataCount++;
                                    arraySnapMainData [snapMainDataCount] = 0, snapMainDataCount++;
                                    arraySnapMainData [snapMainDataCount] = 0, snapMainDataCount++;
                                    arraySnapMainData [snapMainDataCount] = 0, snapMainDataCount++;
                                    arraySnapMainData [snapMainDataCount] = 0, snapMainDataCount++;
                                    arraySnapMainData [snapMainDataCount] = 0, snapMainDataCount++;
                                    arraySnapMainData [snapMainDataCount] = 0, snapMainDataCount++;
                                    
                                    //for (int counterA = 0; counterA < snapMainDataCount/16; counterA++){
                                    //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<arraySnapMainData [counterA*16+counterB];
                                    //    cout<<" arraySnapMainData "<<counterA<<" "<<endl;
                                    //}
                                    
                                    oin.open(snapDataPath1.c_str(), ios::out);
                                    
                                    for (int counter2 = 0; counter2 < snapMainDataCount; counter2++) oin<<arraySnapMainData [counter2]<<endl;
                                    
                                    oin.close();
                                    
                                    subProcesses = [[SubProcesses alloc] init];
                                    [subProcesses mapDataSave];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                }
                                else{
                                    
                                    remove (fileSavePathHold.c_str());
                                    
                                    if (lastSnapNo == 1) lastSnapNo = 0;
                                    else if (lastSnapNo != 0) lastSnapNo = lastSnapNo-2;
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"File Format Error"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                                
                                delete [] fileReadArray;
                                delete [] arrayExtractedImage3;
                            }
                            else{
                                
                                if (lastSnapNo == 1) lastSnapNo = 0;
                                else if (lastSnapNo != 0) lastSnapNo = lastSnapNo-2;
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                            
                            remove (snapFilePath2.c_str());
                        }
                    }
                }
            }
            else if (snapFirstSecondTime == 2){
                string entry;
                
                fileDeleteCount = 0;
                
                DIR *dir;
                struct dirent *dent;
                
                dir = opendir(informationDirectoryPath.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                            arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                        }
                    }
                    
                    closedir(dir);
                    
                    string snapFilePath2;
                    string extension;
                    
                    unsigned long nextAddress = 0;
                    unsigned long stripFirstAddress = 0;
                    unsigned long stripByteCountAddress = 0;
                    unsigned long headPosition = 0;
                    unsigned long stripEntry = 0;
                    long sizeForCopy = 0;
                    
                    double xPosition = 0;
                    double yPosition = 0;
                    double zPosition = 0;
                    
                    int imageWidth = 0;
                    int imageHeight = 0;
                    int imageBit = 0; //Check 8, 16
                    int imageCompression = 0; //Check 1
                    int photoMetric = 0; //Check 0, 1, 2
                    
                    int verticalBmp = 0;
                    int horizontalBmp = 0;
                    int endianType = 0;
                    int samplePerPix = 0;
                    int dataConversion [4];
                    int processType = 0; //----Out put image 8 bit gray
                    int numberOfLayers = 0;
                    int mode = 0;
                    int entryPosition = 0;
                    
                    struct stat sizeOfFile;
                    
                    ofstream oin;
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                        entry = arrayFileDelete [counter1];
                        
                        if ((int)entry.find("Snap") != -1){
                            extension = to_string(snapPage*2);
                            
                            if (extension.length() == 1) extension = "00"+extension;
                            else if (extension.length() == 2) extension = "0"+extension;
                            
                            snapFilePath2 = informationDirectoryPath+"/"+entry;
                            fileSavePathHold = cellTrackingSystemDataPath+"/"+"SnapA-"+extension;
                            
                            if (stat(snapFilePath2.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                fileReadArray = new uint8_t [sizeForCopy+4];
                                fin.open(snapFilePath2.c_str(), ios::in | ios::binary);
                                
                                fin.read((char*)fileReadArray, sizeForCopy+1);
                                fin.close();
                                
                                dataConversion [0] = fileReadArray [0];
                                dataConversion [1] = fileReadArray [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = fileReadArray [7];
                                    dataConversion [1] = fileReadArray [6];
                                    dataConversion [2] = fileReadArray [5];
                                    dataConversion [3] = fileReadArray [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = fileReadArray [4];
                                    dataConversion [1] = fileReadArray [5];
                                    dataConversion [2] = fileReadArray [6];
                                    dataConversion [3] = fileReadArray [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                int *arrayExtractedImage3 = new int [100];
                                
                                if (endianType == 1){ //----Big endian----
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers:&zPosition];
                                    
                                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && numberOfLayers == 1 && samplePerPix <= 4 && photoMetric < 3 && imageWidth == cameraDimension && imageHeight == cameraDimension){
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:cameraDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                    }
                                }
                                else if (endianType == 0){
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers:&zPosition];
                                    
                                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && numberOfLayers == 1 && samplePerPix <= 4 && photoMetric < 3 && imageWidth == cameraDimension && imageHeight == cameraDimension){
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:cameraDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                    }
                                }
                                
                                //cout<<imageCompression<<" "<<imageBit<<" "<<" "<<samplePerPix<<" "<<photoMetric<<" "<<zPosition<<" "<<imageWidth<<" "<<cameraDimension<<" "<<numberOfLayers<<" entryinfo"<<endl;
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && numberOfLayers == 1 && samplePerPix <= 4 && photoMetric < 3 && imageWidth == cameraDimension && imageHeight == cameraDimension){
                                    
                                    horizontalBmp = 0;
                                    verticalBmp = 0;
                                    
                                    //----Saved image----
                                    arrayImageFileSave = new int *[cameraDimension+1];
                                    
                                    for (int counter3 = 0; counter3 < cameraDimension+1; counter3++){
                                        arrayImageFileSave [counter3] = new int [cameraDimension+1];
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cameraDimension; counter3++){
                                        for (int counter4 = 0; counter4 < cameraDimension; counter4++){
                                            arrayImageFileSave [counter3][counter4] = 0;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cameraDimension*cameraDimension; counter3++){
                                        if (horizontalBmp < cameraDimension){
                                            arrayImageFileSave [verticalBmp][horizontalBmp] = arrayExtractedImage3 [counter3], horizontalBmp++;
                                        }
                                        
                                        if (horizontalBmp == cameraDimension){
                                            horizontalBmp = 0;
                                            verticalBmp++;
                                        }
                                    }
                                    
                                    photoMetric = 1;
                                    imageBit = 8;
                                    
                                    if (xPosition == -1) xPosition = 100;
                                    if (yPosition == -1) yPosition = 100;
                                    if (zPosition == -1) zPosition = 100;
                                    
                                    singleTiffSave = [[SingleTiffSave alloc] init];
                                    [singleTiffSave singleTiffLayerSave:cameraDimension:cameraDimension:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:(unsigned long)mode:zPosition];
                                    
                                    for (int counter3 = 0; counter3 < cameraDimension+1; counter3++){
                                        delete [] arrayImageFileSave [counter3];
                                    }
                                    
                                    delete [] arrayImageFileSave;
                                    
                                    entryPosition = (snapPage-1)*16;
                                    
                                    arraySnapMainData [entryPosition+6] = snapPage*2;
                                    arraySnapMainData [entryPosition+7] = xPosition;
                                    arraySnapMainData [entryPosition+8] = yPosition;
                                    arraySnapMainData [entryPosition+9] = zPosition;
                                    
                                    oin.open(snapDataPath1.c_str(), ios::out);
                                    
                                    for (int counter2 = 0; counter2 < snapMainDataCount; counter2++) oin<<arraySnapMainData [counter2]<<endl;
                                    
                                    oin.close();
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                }
                                else{
                                    
                                    remove (fileSavePathHold.c_str());
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"File Format Error"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                                
                                delete [] fileReadArray;
                                delete [] arrayExtractedImage3;
                            }
                            else{
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                            
                            remove (snapFilePath2.c_str());
                            
                            break;
                        }
                    }
                }
            }
            
            if (snapFirstSecondTime == 1){
                [snap1 setTextColor:[NSColor redColor]];
                [snap2 setTextColor:[NSColor blackColor]];
                [snap1 setStringValue:@"Time A"];
                [snap2 setStringValue:@"Time B"];
            }
            
            if (snapFirstSecondTime == 2){
                [snap1 setTextColor:[NSColor blackColor]];
                [snap2 setTextColor:[NSColor redColor]];
                [snap1 setStringValue:@"Time A"];
                [snap2 setStringValue:@"Time B"];
            }
            
            if (snapPage != 0){
                int entryPosition = (snapPage-1)*16;
                
                arraySnapData [0] = arraySnapMainData [entryPosition]; //----Snap 1 no----
                arraySnapData [1] = arraySnapMainData [entryPosition+1]; //----X Corner Snap 1----
                arraySnapData [2] = arraySnapMainData [entryPosition+2]; //----Y Corner Snap 1----
                arraySnapData [3] = arraySnapMainData [entryPosition+3]; //----Z Corner Snap 1----
                arraySnapData [4] = arraySnapMainData [entryPosition+4]; //----X Position set 1----
                arraySnapData [5] = arraySnapMainData [entryPosition+5]; //----Y Position set 1----
                arraySnapData [6] = arraySnapMainData [entryPosition+6]; //----Snap 2 no----
                arraySnapData [7] = arraySnapMainData [entryPosition+7]; //----X Corner Snap 2----
                arraySnapData [8] = arraySnapMainData [entryPosition+8]; //----Y Corner Snap 2----
                arraySnapData [9] = arraySnapMainData [entryPosition+9]; //----Z Corner Snap 2----
                arraySnapData [10] = arraySnapMainData [entryPosition+10]; //----X Position set 2----
                arraySnapData [11] = arraySnapMainData [entryPosition+11]; //----X Position set 2----
                arraySnapData [12] = arraySnapMainData [entryPosition+12]; //----Set mark----
                arraySnapData [13] = arraySnapMainData [entryPosition+13]; //----X Diff----
                arraySnapData [14] = arraySnapMainData [entryPosition+14]; //----Y Diff----
                arraySnapData [15] = arraySnapMainData [entryPosition+15]; //----Z Diff----
                
                //for (int counterA = 0; counterA < 1; counterA++){
                //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<arraySnapData [counterA*16+counterB];
                //    cout<<" arraySnapData "<<counterA<<" "<<endl;
                //}
                
                [pageNo setIntegerValue:snapPage];
                
                if (arraySnapData [4] != 0 && arraySnapData [5] != 0){
                    [xPositionSnap1 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [4]]];
                    [yPositionSnap1 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [5]]];
                    [zPositionSnap1 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [3]]];
                }
                else{
                    
                    [xPositionSnap1 setStringValue:@"nil"];
                    [yPositionSnap1 setStringValue:@"nil"];
                    [zPositionSnap1 setStringValue:@"nil"];
                }
                
                if (arraySnapData [10] != 0 && arraySnapData [11] != 0){
                    [xPositionSnap2 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [10]]];
                    [yPositionSnap2 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [11]]];
                    [zPositionSnap2 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [9]]];
                }
                else{
                    
                    [xPositionSnap2 setStringValue:@"nil"];
                    [yPositionSnap2 setStringValue:@"nil"];
                    [zPositionSnap2 setStringValue:@"nil"];
                }
                
                if (arraySnapData [13] != 0 && arraySnapData [14] != 0){
                    int xDifferenceInt = (int)(round (arraySnapData [13]));
                    int yDifferenceInt = (int)(round (arraySnapData [14]));
                    
                    [xDiff1 setIntegerValue:xDifferenceInt];
                    [yDiff1 setIntegerValue:yDifferenceInt];
                    
                    [stepperX1 setMinValue:xDifferenceInt-200];
                    [stepperX1 setMaxValue:xDifferenceInt+200];
                    [stepperY1 setMinValue:yDifferenceInt-200];
                    [stepperY1 setMaxValue:yDifferenceInt+200];
                    
                    stepperLimitXL1 = xDifferenceInt-200;
                    stepperLimitXH1 = xDifferenceInt+200;
                    stepperLimitYL1 = yDifferenceInt-200;
                    stepperLimitYH1 = yDifferenceInt+200;
                    
                    [stepperX1 setIntValue:xDifferenceInt];
                    [stepperY1 setIntValue:yDifferenceInt];
                }
                else{
                    
                    [xDiff1 setStringValue:@""];
                    [yDiff1 setStringValue:@""];
                }
                
                string extension = to_string(snapPage*2-1);
                
                if (extension.length() == 1) extension = "00"+extension;
                else if (extension.length() == 2) extension = "0"+extension;
                
                string snapSavePath = cellTrackingSystemDataPath+"/"+"SnapA-"+extension;
                string refPath = informationDirectoryPath+"/RefImage.tif";
                
                struct stat sizeOfFile;
                
                long sizeForCopy = 0;
                
                if (stat(snapSavePath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    ifstream infile (snapSavePath.c_str(), ifstream::binary);
                    ofstream outfile (refPath.c_str(), ofstream::binary);
                    
                    char *buffer = new char[sizeForCopy];
                    infile.read (buffer, sizeForCopy);
                    outfile.write (buffer, sizeForCopy);
                    delete [] buffer;
                    
                    outfile.close();
                    infile.close();
                }
            }
            else{
                
                [xPositionSnap1 setStringValue:@"nil"];
                [yPositionSnap1 setStringValue:@"nil"];
                [xPositionSnap2 setStringValue:@"nil"];
                [yPositionSnap2 setStringValue:@"nil"];
                [zPositionSnap1 setStringValue:@"nil"];
                [zPositionSnap2 setStringValue:@"nil"];
                [xDiff1 setStringValue:@""];
                [yDiff1 setStringValue:@""];
                [pageNo setStringValue:@"nil"];
            }
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage object:self];
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage2 object:self];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Check The Destination Computer"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Maximum 100 Snaps: Delete Images"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)controlTextDidChange:(NSNotification *)aNotification {
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == xDiff1 && arraySnapData [12] != 0){
            if ([xDiff1 intValue] >= stepperLimitXL1 && [xDiff1 intValue] <= stepperLimitXH1){
                [stepperX1 setIntValue:[xDiff1 intValue]];
                arraySnapData [13] = [stepperX1 intValue];
                
                int entryPosition = (snapPage-1)*16;
                arraySnapMainData [entryPosition+13] = arraySnapData [13];
                
                ofstream oin;
                
                oin.open(snapDataPath1.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < snapMainDataCount; counter1++) oin<<arraySnapMainData [counter1]<<endl;
                
                oin.close();
            }
        }
        
        if ([aNotification object] == yDiff1 && arraySnapData [12] != 0){
            if ([yDiff1 intValue] >= stepperLimitYL1 && [yDiff1 intValue] <= stepperLimitYH1){
                [stepperY1 setIntValue:[yDiff1 intValue]];
                arraySnapData [14] = [stepperY1 intValue];
                
                int entryPosition = (snapPage-1)*16;
                arraySnapMainData [entryPosition+14] = arraySnapData [14];
                
                ofstream oin;
                
                oin.open(snapDataPath1.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < snapMainDataCount; counter1++) oin<<arraySnapMainData [counter1]<<endl;
                
                oin.close();
            }
        }
        
        if ([aNotification object] == stepperStartDisplay1){
            if ([stepperStartDisplay1 intValue] >= 1 && [stepperStartDisplay1 intValue] <= 500){
                [stepperStart1 setIntValue:[stepperStartDisplay1 intValue]];
                stepperStartHold1 = [stepperStartDisplay1 intValue];
            }
        }
    }
}

-(IBAction)stepperActionX1:(id)sender{
    if (arraySnapData [12] != 0){
        if ([stepperX1 intValue] >= stepperLimitXL1 && [stepperX1 intValue] <= stepperLimitXH1){
            [xDiff1 setIntValue:[stepperX1 intValue]];
            arraySnapData [13] = [stepperX1 intValue];
            
            int entryPosition = (snapPage-1)*16;
            arraySnapMainData [entryPosition+13] = arraySnapData [13];
            
            ofstream oin;
            
            oin.open(snapDataPath1.c_str(), ios::out);
            
            for (int counter1 = 0; counter1 < snapMainDataCount; counter1++) oin<<arraySnapMainData [counter1]<<endl;
            
            oin.close();
        }
    }
}

-(IBAction)stepperActionY1:(id)sender{
    if (arraySnapData [12] != 0){
        if ([stepperY1 intValue] >= stepperLimitYL1 && [stepperY1 intValue] <= stepperLimitYH1){
            [yDiff1 setIntValue:[stepperY1 intValue]];
            arraySnapData [14] = [stepperY1 intValue];
            
            int entryPosition = (snapPage-1)*16;
            arraySnapMainData [entryPosition+14] = arraySnapData [14];
            
            ofstream oin;
            
            oin.open(snapDataPath1.c_str(), ios::out);
            
            for (int counter1 = 0; counter1 < snapMainDataCount; counter1++) oin<<arraySnapMainData [counter1]<<endl;
            
            oin.close();
        }
    }
}

-(IBAction)stepperActionStart1:(id)sender{
    if ([stepperStart1 intValue] >= 1 && [stepperStart1 intValue] <= 500){
        [stepperStartDisplay1 setIntValue:[stepperStart1 intValue]];
        stepperStartHold1 = [stepperStart1 intValue];
    }
}

-(IBAction)timePointSWMain:(id)sender{
    if (snapFirstSecondTime == 1){
        snapFirstSecondTime = 2;
        
        [snap1 setTextColor:[NSColor blackColor]];
        [snap2 setTextColor:[NSColor redColor]];
        [snap1 setStringValue:@"Time A"];
        [snap2 setStringValue:@"Time B"];
        
        subProcesses = [[SubProcesses alloc] init];
        [subProcesses mapDataSave];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else if (snapFirstSecondTime == 2){
        snapFirstSecondTime = 1;
        
        [snap1 setTextColor:[NSColor redColor]];
        [snap2 setTextColor:[NSColor blackColor]];
        [snap1 setStringValue:@"Time A"];
        [snap2 setStringValue:@"Time B"];
        
        subProcesses = [[SubProcesses alloc] init];
        [subProcesses mapDataSave];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)clearPage:(id)sender{
    if (snapPage != 0){
        double *arraySnapMainDataTemp = new double [1700];
        int snapMainDataTempCount = 0;
        
        for (int counter1 = 0; counter1 < snapMainDataCount/16; counter1++){
            if (counter1 != snapPage-1){
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData [counter1*16], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData [counter1*16+1], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData [counter1*16+2], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData [counter1*16+3], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData [counter1*16+4], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData [counter1*16+5], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData [counter1*16+6], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData [counter1*16+7], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData [counter1*16+8], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData [counter1*16+9], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData [counter1*16+10], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData [counter1*16+11], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData [counter1*16+12], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData [counter1*16+13], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData [counter1*16+14], snapMainDataTempCount++;
                arraySnapMainDataTemp [snapMainDataTempCount] = arraySnapMainData [counter1*16+15], snapMainDataTempCount++;
            }
        }
        
        for (int counter1 = 0; counter1 < 1700; counter1++) arraySnapMainData [counter1] = 0;
        
        snapMainDataCount = 0;
        for (int counter1 = 0; counter1 < snapMainDataTempCount; counter1++) arraySnapMainData [snapMainDataCount] = arraySnapMainDataTemp [counter1], snapMainDataCount++;
        delete [] arraySnapMainDataTemp;
        
        string entry;
        string removePath;
        string oldNamePath;
        string newNamePath;
        string stringExtract;
        
        fileDeleteCount = 0;
        
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(cellTrackingSystemDataPath.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
            }
            
            closedir(dir);
            
            string extension;
            string extension2;
            
            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                entry = arrayFileDelete [counter1];
                extension = to_string(snapPage*2);
                
                if (extension.length() == 1) extension = "00"+extension;
                else if (extension.length() == 2) extension = "0"+extension;
                
                extension2 = to_string(snapPage*2-1);
                
                if (extension2.length() == 1) extension2 = "00"+extension2;
                else if (extension2.length() == 2) extension2 = "0"+extension2;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    if ((int)entry.find("SnapA-"+extension) != -1){
                        removePath = cellTrackingSystemDataPath+"/"+"SnapA-"+extension;
                        remove(removePath.c_str());
                    }
                    else if ((int)entry.find("SnapA-"+extension2) != -1){
                        removePath = cellTrackingSystemDataPath+"/"+"SnapA-"+extension2;
                        remove(removePath.c_str());
                    }
                }
            }
        }
        
        fileDeleteCount = 0;
        
        dir = opendir(cellTrackingSystemDataPath.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                    arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                }
            }
            
            closedir(dir);
            
            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                entry = arrayFileDelete [counter1];
                
                if ((int)entry.find("SnapA-") != -1){
                    stringExtract = entry.substr(6);
                    
                    if (atoi(stringExtract.c_str()) > snapPage*2){
                        string extension3 = to_string(atoi(stringExtract.c_str())-2);
                        
                        if (extension3.length() == 1) extension3 = "00"+extension3;
                        else if (extension3.length() == 2) extension3 = "0"+extension3;
                        
                        oldNamePath = cellTrackingSystemDataPath+"/"+entry;
                        newNamePath = cellTrackingSystemDataPath+"/"+"SnapA-"+extension3;
                        
                        rename (oldNamePath.c_str(), newNamePath.c_str());
                    }
                }
            }
        }
        
        if (snapMainDataCount == 0) snapPage = 0;
        else if (snapMainDataCount != 0){
            if (snapPage-1 == 0) snapPage = 1;
            else snapPage = snapPage-1;
        }
        
        if (snapPage != 0){
            int entryPosition = (snapPage-1)*16;
            
            arraySnapData [0] = arraySnapMainData [entryPosition]; //----Snap 1 no----
            arraySnapData [1] = arraySnapMainData [entryPosition+1]; //----X Corner Snap 1----
            arraySnapData [2] = arraySnapMainData [entryPosition+2]; //----Y Corner Snap 1----
            arraySnapData [3] = arraySnapMainData [entryPosition+3]; //----Z Corner Snap 1----
            arraySnapData [4] = arraySnapMainData [entryPosition+4]; //----X Position set 1----
            arraySnapData [5] = arraySnapMainData [entryPosition+5]; //----Y Position set 1----
            arraySnapData [6] = arraySnapMainData [entryPosition+6]; //----Snap 2 no----
            arraySnapData [7] = arraySnapMainData [entryPosition+7]; //----X Corner Snap 2----
            arraySnapData [8] = arraySnapMainData [entryPosition+8]; //----Y Corner Snap 2----
            arraySnapData [9] = arraySnapMainData [entryPosition+9]; //----Z Corner Snap 2----
            arraySnapData [10] = arraySnapMainData [entryPosition+10]; //----X Position set 2----
            arraySnapData [11] = arraySnapMainData [entryPosition+11]; //----X Position set 2----
            arraySnapData [12] = arraySnapMainData [entryPosition+12]; //----Set mark----
            arraySnapData [13] = arraySnapMainData [entryPosition+13]; //----X Diff----
            arraySnapData [14] = arraySnapMainData [entryPosition+14]; //----Y Diff----
            arraySnapData [15] = arraySnapMainData [entryPosition+15]; //----Z Diff----
            
            [pageNo setIntegerValue:snapPage];
            
            if (arraySnapData [4] != 0 && arraySnapData [5] != 0){
                [xPositionSnap1 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [4]]];
                [yPositionSnap1 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [5]]];
                [zPositionSnap1 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [3]]];
            }
            else{
                
                [xPositionSnap1 setStringValue:@"nil"];
                [yPositionSnap1 setStringValue:@"nil"];
                [zPositionSnap1 setStringValue:@"nil"];
            }
            
            if (arraySnapData [10] != 0 && arraySnapData [11] != 0){
                [xPositionSnap2 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [10]]];
                [yPositionSnap2 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [11]]];
                [zPositionSnap2 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [9]]];
            }
            else{
                
                [xPositionSnap2 setStringValue:@"nil"];
                [yPositionSnap2 setStringValue:@"nil"];
                [zPositionSnap2 setStringValue:@"nil"];
            }
            
            if (arraySnapData [13] != 0 && arraySnapData [14] != 0){
                int xDifferenceInt = (int)(round (arraySnapData [13]));
                int yDifferenceInt = (int)(round (arraySnapData [14]));
                
                [xDiff1 setIntegerValue:xDifferenceInt];
                [yDiff1 setIntegerValue:yDifferenceInt];
                
                [stepperX1 setMinValue:xDifferenceInt-200];
                [stepperX1 setMaxValue:xDifferenceInt+200];
                [stepperY1 setMinValue:yDifferenceInt-200];
                [stepperY1 setMaxValue:yDifferenceInt+200];
                
                stepperLimitXL1 = xDifferenceInt-200;
                stepperLimitXH1 = xDifferenceInt+200;
                stepperLimitYL1 = yDifferenceInt-200;
                stepperLimitYH1 = yDifferenceInt+200;
                
                [stepperX1 setIntValue:xDifferenceInt];
                [stepperY1 setIntValue:yDifferenceInt];
            }
            else{
                
                [xDiff1 setStringValue:@""];
                [yDiff1 setStringValue:@""];
            }
            
            string extension = to_string(snapPage*2-1);
            
            if (extension.length() == 1) extension = "00"+extension;
            else if (extension.length() == 2) extension = "0"+extension;
            
            string snapSavePath = cellTrackingSystemDataPath+"/"+"SnapA-"+extension;
            string refPath = informationDirectoryPath+"/RefImage.tif";
            
            struct stat sizeOfFile;
            
            long sizeForCopy = 0;
            
            if (stat(snapSavePath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                ifstream infile (snapSavePath.c_str(), ifstream::binary);
                ofstream outfile (refPath.c_str(), ofstream::binary);
                
                char *buffer = new char[sizeForCopy];
                infile.read (buffer, sizeForCopy);
                outfile.write (buffer, sizeForCopy);
                delete [] buffer;
                
                outfile.close();
                infile.close();
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            [xPositionSnap1 setStringValue:@"nil"];
            [yPositionSnap1 setStringValue:@"nil"];
            [xPositionSnap2 setStringValue:@"nil"];
            [yPositionSnap2 setStringValue:@"nil"];
            [zPositionSnap1 setStringValue:@"nil"];
            [zPositionSnap2 setStringValue:@"nil"];
            [xDiff1 setStringValue:@""];
            [yDiff1 setStringValue:@""];
            [pageNo setStringValue:@"nil"];
        }
        
        ofstream oin;
        
        oin.open(snapDataPath1.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 < snapMainDataCount; counter1++) oin<<arraySnapMainData [counter1]<<endl;
        
        oin.close();
        
        subProcesses = [[SubProcesses alloc] init];
        [subProcesses mapDataSave];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage object:self];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage2 object:self];
    }
}

-(IBAction)pageFW:(id)sender{
    if (snapPage != 0){
        int findFlag = 0;
        
        if (arraySnapMainData [snapPage*16] != 0) findFlag = 1;
        
        if (findFlag == 1){
            snapPage++;
            
            [pageNo setIntegerValue:snapPage];
            
            int entryPosition = (snapPage-1)*16;
            
            arraySnapData [0] = arraySnapMainData [entryPosition]; //----Snap 1 no----
            arraySnapData [1] = arraySnapMainData [entryPosition+1]; //----X Corner Snap 1----
            arraySnapData [2] = arraySnapMainData [entryPosition+2]; //----Y Corner Snap 1----
            arraySnapData [3] = arraySnapMainData [entryPosition+3]; //----Z Corner Snap 1----
            arraySnapData [4] = arraySnapMainData [entryPosition+4]; //----X Position set 1----
            arraySnapData [5] = arraySnapMainData [entryPosition+5]; //----Y Position set 1----
            arraySnapData [6] = arraySnapMainData [entryPosition+6]; //----Snap 2 no----
            arraySnapData [7] = arraySnapMainData [entryPosition+7]; //----X Corner Snap 2----
            arraySnapData [8] = arraySnapMainData [entryPosition+8]; //----Y Corner Snap 2----
            arraySnapData [9] = arraySnapMainData [entryPosition+9]; //----Z Corner Snap 2----
            arraySnapData [10] = arraySnapMainData [entryPosition+10]; //----X Position set 2----
            arraySnapData [11] = arraySnapMainData [entryPosition+11]; //----X Position set 2----
            arraySnapData [12] = arraySnapMainData [entryPosition+12]; //----Set mark----
            arraySnapData [13] = arraySnapMainData [entryPosition+13]; //----X Diff----
            arraySnapData [14] = arraySnapMainData [entryPosition+14]; //----Y Diff----
            arraySnapData [15] = arraySnapMainData [entryPosition+15]; //----Z Diff----
            
            if (arraySnapData [4] != 0 && arraySnapData [5] != 0){
                [xPositionSnap1 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [4]]];
                [yPositionSnap1 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [5]]];
                [zPositionSnap1 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [3]]];
            }
            else{
                
                [xPositionSnap1 setStringValue:@"nil"];
                [yPositionSnap1 setStringValue:@"nil"];
                [zPositionSnap1 setStringValue:@"nil"];
            }
            
            if (arraySnapData [10] != 0 && arraySnapData [11] != 0){
                [xPositionSnap2 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [10]]];
                [yPositionSnap2 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [11]]];
                [zPositionSnap2 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [9]]];
            }
            else{
                
                [xPositionSnap2 setStringValue:@"nil"];
                [yPositionSnap2 setStringValue:@"nil"];
                [zPositionSnap2 setStringValue:@"nil"];
            }
            
            if (arraySnapData [13] != 0 && arraySnapData [14] != 0){
                int xDifferenceInt = (int)(round (arraySnapData [13]));
                int yDifferenceInt = (int)(round (arraySnapData [14]));
                
                [xDiff1 setIntegerValue:xDifferenceInt];
                [yDiff1 setIntegerValue:yDifferenceInt];
                
                [stepperX1 setMinValue:xDifferenceInt-200];
                [stepperX1 setMaxValue:xDifferenceInt+200];
                [stepperY1 setMinValue:yDifferenceInt-200];
                [stepperY1 setMaxValue:yDifferenceInt+200];
                
                stepperLimitXL1 = xDifferenceInt-200;
                stepperLimitXH1 = xDifferenceInt+200;
                stepperLimitYL1 = yDifferenceInt-200;
                stepperLimitYH1 = yDifferenceInt+200;
                
                [stepperX1 setIntValue:xDifferenceInt];
                [stepperY1 setIntValue:yDifferenceInt];
            }
            else{
                
                [xDiff1 setStringValue:@""];
                [yDiff1 setStringValue:@""];
            }
            
            string extension = to_string(snapPage*2-1);
            
            if (extension.length() == 1) extension = "00"+extension;
            else if (extension.length() == 2) extension = "0"+extension;
            
            string snapSavePath = cellTrackingSystemDataPath+"/"+"SnapA-"+extension;
            string refPath = informationDirectoryPath+"/RefImage.tif";
            
            struct stat sizeOfFile;
            
            long sizeForCopy = 0;
            
            if (stat(snapSavePath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                ifstream infile (snapSavePath.c_str(), ifstream::binary);
                ofstream outfile (refPath.c_str(), ofstream::binary);
                
                char *buffer = new char[sizeForCopy];
                infile.read (buffer, sizeForCopy);
                outfile.write (buffer, sizeForCopy);
                delete [] buffer;
                
                outfile.close();
                infile.close();
                
                subProcesses = [[SubProcesses alloc] init];
                [subProcesses mapDataSave];
                
                drawingPermit1 = 2;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage2 object:self];
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)pageBW:(id)sender{
    if (snapPage != 0){
        if (snapPage > 1){
            snapPage--;
            
            [pageNo setIntegerValue:snapPage];
            
            int entryPosition = (snapPage-1)*16;
            
            arraySnapData [0] = arraySnapMainData [entryPosition]; //----Snap 1 no----
            arraySnapData [1] = arraySnapMainData [entryPosition+1]; //----X Corner Snap 1----
            arraySnapData [2] = arraySnapMainData [entryPosition+2]; //----Y Corner Snap 1----
            arraySnapData [3] = arraySnapMainData [entryPosition+3]; //----Z Corner Snap 1----
            arraySnapData [4] = arraySnapMainData [entryPosition+4]; //----X Position set 1----
            arraySnapData [5] = arraySnapMainData [entryPosition+5]; //----Y Position set 1----
            arraySnapData [6] = arraySnapMainData [entryPosition+6]; //----Snap 2 no----
            arraySnapData [7] = arraySnapMainData [entryPosition+7]; //----X Corner Snap 2----
            arraySnapData [8] = arraySnapMainData [entryPosition+8]; //----Y Corner Snap 2----
            arraySnapData [9] = arraySnapMainData [entryPosition+9]; //----Z Corner Snap 2----
            arraySnapData [10] = arraySnapMainData [entryPosition+10]; //----X Position set 2----
            arraySnapData [11] = arraySnapMainData [entryPosition+11]; //----X Position set 2----
            arraySnapData [12] = arraySnapMainData [entryPosition+12]; //----Set mark----
            arraySnapData [13] = arraySnapMainData [entryPosition+13]; //----X Diff----
            arraySnapData [14] = arraySnapMainData [entryPosition+14]; //----Y Diff----
            arraySnapData [15] = arraySnapMainData [entryPosition+15]; //----Z Diff----
            
            if (arraySnapData [4] != 0 && arraySnapData [5] != 0){
                [xPositionSnap1 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [4]]];
                [yPositionSnap1 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [5]]];
                [zPositionSnap1 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [3]]];
            }
            else{
                
                [xPositionSnap1 setStringValue:@"nil"];
                [yPositionSnap1 setStringValue:@"nil"];
                [zPositionSnap1 setStringValue:@"nil"];
            }
            
            if (arraySnapData [10] != 0 && arraySnapData [11] != 0){
                [xPositionSnap2 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [10]]];
                [yPositionSnap2 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [11]]];
                [zPositionSnap2 setStringValue:[NSString stringWithFormat:@"%.2f", arraySnapData [9]]];
            }
            else{
                
                [xPositionSnap2 setStringValue:@"nil"];
                [yPositionSnap2 setStringValue:@"nil"];
                [zPositionSnap2 setStringValue:@"nil"];
            }
            
            if (arraySnapData [13] != 0 && arraySnapData [14] != 0){
                int xDifferenceInt = (int)(round (arraySnapData [13]));
                int yDifferenceInt = (int)(round (arraySnapData [14]));
                
                [xDiff1 setIntegerValue:xDifferenceInt];
                [yDiff1 setIntegerValue:yDifferenceInt];
                
                [stepperX1 setMinValue:xDifferenceInt-200];
                [stepperX1 setMaxValue:xDifferenceInt+200];
                [stepperY1 setMinValue:yDifferenceInt-200];
                [stepperY1 setMaxValue:yDifferenceInt+200];
                
                stepperLimitXL1 = xDifferenceInt-200;
                stepperLimitXH1 = xDifferenceInt+200;
                stepperLimitYL1 = yDifferenceInt-200;
                stepperLimitYH1 = yDifferenceInt+200;
                
                [stepperX1 setIntValue:xDifferenceInt];
                [stepperY1 setIntValue:yDifferenceInt];
            }
            else{
                
                [xDiff1 setStringValue:@""];
                [yDiff1 setStringValue:@""];
            }
            
            string extension = to_string(snapPage*2-1);
            
            if (extension.length() == 1) extension = "00"+extension;
            else if (extension.length() == 2) extension = "0"+extension;
            
            string snapSavePath = cellTrackingSystemDataPath+"/"+"SnapA-"+extension;
            string refPath = informationDirectoryPath+"/RefImage.tif";
            
            struct stat sizeOfFile;
            
            long sizeForCopy = 0;
            
            if (stat(snapSavePath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                ifstream infile (snapSavePath.c_str(), ifstream::binary);
                ofstream outfile (refPath.c_str(), ofstream::binary);
                
                char *buffer = new char[sizeForCopy];
                infile.read (buffer, sizeForCopy);
                outfile.write (buffer, sizeForCopy);
                delete [] buffer;
                
                outfile.close();
                infile.close();
                
                subProcesses = [[SubProcesses alloc] init];
                [subProcesses mapDataSave];
                
                drawingPermit1 = 2;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSnapImage2 object:self];
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)reDisplayWindow{
    if (snapOperation == 3){
        [snapWindow makeKeyAndOrderFront:self];
        snapOperation = 1;
        [snapTimer invalidate];
    }
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    if (snapTimer) [snapTimer invalidate];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToSnapHandle object:nil];
}

@end
