//
//  SnapImage2.m
//  XY_Map
//
//  Created by Masahiko Sato on 2014-08-23.
//
//

#import "SnapImage2.h"

NSString *notificationToSnapImage2 = @"notificationExecuteSnapImage2";

@implementation SnapImage2

- (id)initWithFrame:(NSRect)frame{
    self = [super initWithFrame:frame];
    
    if (self){
        magnificationSnap2 = 10;
        mouseDragFlag = 0;
        snapWindowImage2 = [[NSImage alloc] initWithContentsOfFile:@""];
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToSnapImage2 object:nil];
    }
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    if (snapStart == 1){
        string extension = to_string(snapPage*2);
        
        if (extension.length() == 1) extension = "00"+extension;
        else if (extension.length() == 2) extension = "0"+extension;
        
        string snapSavePath = cellTrackingSystemDataPath+"/"+"SnapA-"+extension;
        
        unsigned long nextAddress = 0;
        unsigned long stripFirstAddress = 0;
        unsigned long stripByteCountAddress = 0;
        unsigned long headPosition = 0;
        unsigned long stripEntry = 0;
        long sizeForCopy = 0;
        
        double xPosition = 0;
        double yPosition = 0;
        double zPosition = 0;
        
        int imageWidth = 0;
        int imageHeight = 0;
        int imageBit = 0; //Check 8, 16
        int imageCompression = 0; //Check 1
        int photoMetric = 0; //Check 0, 1, 2
        int imageDimension = 0;
        int verticalBmp = 0;
        int horizontalBmp = 0;
        int endianType = 0;
        int samplePerPix = 0;
        int dataConversion [4];
        int processType = 0; //----Out put image 8 bit gray
        int numberOfLayers = 0;
        
        //----File Read----
        struct stat sizeOfFile;
        
        ifstream fin;
        
        if (stat(snapSavePath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            int **imageDataTemp = new int *[cameraDimension+1];
            for (int counter1 = 0; counter1 < cameraDimension+1; counter1++) imageDataTemp [counter1] = new int [cameraDimension+1];
            
            for (int counter3 = 0; counter3 < cameraDimension+1; counter3++){
                for (int counter4 = 0; counter4 < cameraDimension+1; counter4++){
                    imageDataTemp [counter3][counter4] = 0;
                }
            }
            
            fileReadArray = new uint8_t [sizeForCopy+4];
            fin.open(snapSavePath.c_str(), ios::in | ios::binary);
            
            fin.read((char*)fileReadArray, sizeForCopy+1);
            fin.close();
            
            dataConversion [0] = fileReadArray [0];
            dataConversion [1] = fileReadArray [1];
            
            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
            else endianType = 0;
            
            if (endianType == 1){
                dataConversion [0] = fileReadArray [7];
                dataConversion [1] = fileReadArray [6];
                dataConversion [2] = fileReadArray [5];
                dataConversion [3] = fileReadArray [4];
                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
            }
            else if (endianType == 0){
                dataConversion [0] = fileReadArray [4];
                dataConversion [1] = fileReadArray [5];
                dataConversion [2] = fileReadArray [6];
                dataConversion [3] = fileReadArray [7];
                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
            }
            
            int *arrayExtractedImage3 = new int [100];
            
            if (endianType == 1){ //----Big endian----
                tiffFileRead = [[TiffFileRead alloc] init];
                [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers:&zPosition];
                
                tiffFileRead = [[TiffFileRead alloc] init];
                delete [] arrayExtractedImage3;
                
                imageDimension = imageWidth;
                
                arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
            }
            else if (endianType == 0){
                tiffFileRead = [[TiffFileRead alloc] init];
                [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers:&zPosition];
                
                tiffFileRead = [[TiffFileRead alloc] init];
                delete [] arrayExtractedImage3;
                
                imageDimension = imageWidth;
                
                arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
            }
            
            //cout<<imageCompression<<" "<<imageBit<<" "<<" "<<samplePerPix<<" "<<photoMetric<<" entryinfo"<<endl;
            
            if (imageCompression == 1 && imageBit == 8 && numberOfLayers == 1 && samplePerPix == 1 && imageWidth == cameraDimension){
                for (int counter3 = 0; counter3 < cameraDimension*cameraDimension; counter3++){
                    if (horizontalBmp < cameraDimension){
                        imageDataTemp [verticalBmp][horizontalBmp] = arrayExtractedImage3 [counter3], horizontalBmp++;
                    }
                    
                    if (horizontalBmp == cameraDimension){
                        horizontalBmp = 0;
                        verticalBmp++;
                    }
                }
                
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:cameraDimension pixelsHigh:cameraDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:cameraDimension bitsPerPixel:8];
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                for (int counter1 = 0; counter1 < cameraDimension; counter1++){
                    for (int counter2 = 0; counter2 < cameraDimension; counter2++) *bitmapData++ = (unsigned char)imageDataTemp [counter1][counter2];
                }
                
                snapWindowImage2 = [[NSImage alloc] initWithSize:NSMakeSize(cameraDimension, cameraDimension)];
                [snapWindowImage2 addRepresentation:bitmapReps];
                
                if (imageFirstLoadFlagSnap2 == 0){
                    xPositionSnap2 = 0;
                    yPositionSnap2 = 0;
                    xPositionAdjustSnap2 = 0;
                    yPositionAdjustSnap2 = 0;
                    magnificationSnap2 = 10;
                    imageFirstLoadFlagSnap2 = 1;
                }
                
                //----Window size and Position re-adjust----
                int vertical = 300+78;
                int horizontal = 300;
                
                windowWidthSnap2 = cameraDimension/(double)horizontal;
                windowHeightSnap2 = cameraDimension/(double)(vertical-78);
                
                xPositionAdjustSnap2 = (cameraDimension-cameraDimension/(double)(magnificationSnap2*0.1))/(double)2;
                yPositionAdjustSnap2 = (cameraDimension-cameraDimension/(double)(magnificationSnap2*0.1))/(double)2;
            }
            else snapWindowImage2 = [[NSImage alloc] initWithContentsOfFile:@""];
            
            for (int counter1 = 0; counter1 < cameraDimension+1; counter1++) delete [] imageDataTemp [counter1];
            delete [] imageDataTemp;
            
            delete [] fileReadArray;
            delete [] arrayExtractedImage3;
        }
        else snapWindowImage2 = [[NSImage alloc] initWithContentsOfFile:@""];
        
        [self setNeedsDisplay:YES];
    }
}

-(void)mouseDown:(NSEvent *)event{
    NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
    xPointDownSnap2 = clickPoint.x;
    yPointDownSnap2 = clickPoint.y;
    
    int xPositionTemp = (int)(xPointDownSnap2*(double)windowWidthSnap2/(double)magnificationSnap2/(double)0.1+xPositionAdjustSnap2+xPositionSnap2);
    int yPositionTemp = cameraDimension-(int)((yPointDownSnap2*(double)windowHeightSnap2/(double)magnificationSnap2/(double)0.1+yPositionAdjustSnap2+yPositionSnap2+windowHeightSnap2));
    
    xClickPositionSnap2 = xPositionTemp;
    yClickPositionSnap2 = yPositionTemp;
    
    [self setNeedsDisplay:YES];
}

-(void)mouseUp:(NSEvent *)event{
    xPositionSnap2 = xPositionSnap2+xPositionMoveSnap2;
    yPositionSnap2 = yPositionSnap2+yPositionMoveSnap2;
    xPositionMoveSnap2 = 0;
    yPositionMoveSnap2 = 0;
    mouseDragFlag = 0;
    [self setNeedsDisplay:YES];
}

-(void)mouseDraged:(NSEvent *)event{
    NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
    xPointDragSnap2 = clickPoint.x;
    yPointDragSnap2 = clickPoint.y;
    xPositionMoveSnap2 = (xPointDownSnap2-xPointDragSnap2)*windowWidthSnap2/(double)(magnificationSnap2*0.1);
    yPositionMoveSnap2 = (yPointDownSnap2-yPointDragSnap2)*windowHeightSnap2/(double)(magnificationSnap2*0.1);
    
    mouseDragFlag = 1;
    [self setNeedsDisplay:YES];
}

-(void)keyDown:(NSEvent *)event{
    int keyCode = [event keyCode];
    int proceedFlag = 0;
    
    //----Original size----
    if (keyCode == 6){
        proceedFlag = 1;
        xPositionSnap2 = 0;
        yPositionSnap2 = 0;
        xPositionAdjustSnap2 = 0;
        yPositionAdjustSnap2 = 0;
        magnificationSnap2 = 10;
    }
    
    //----Magnification Magnify----
    if (keyCode == 125){
        if (magnificationSnap2 >= 12 && magnificationSnap2 <= 350){
            proceedFlag = 1;
            if (magnificationSnap2-10 < 12) magnificationSnap2 = 12;
            else magnificationSnap2 = magnificationSnap2-10;
            
            xPositionAdjustSnap2 = -1*(cameraDimension/(double)(magnificationSnap2*0.1)-cameraDimension)/(double)2;
            yPositionAdjustSnap2 = -1*(cameraDimension/(double)(magnificationSnap2*0.1)-cameraDimension)/(double)2;
        }
    }
    
    //----Magnification Reduction----
    if (keyCode == 126){
        if (magnificationSnap2 >= 10 && magnificationSnap2 <= 498){
            proceedFlag = 1;
            
            if (magnificationSnap2+10 > 498) magnificationSnap2 = 498;
            else magnificationSnap2 = magnificationSnap2+10;
            
            xPositionAdjustSnap2 = (cameraDimension-cameraDimension/(double)(magnificationSnap2*0.1))/(double)2;
            yPositionAdjustSnap2 = (cameraDimension-cameraDimension/(double)(magnificationSnap2*0.1))/(double)2;
        }
    }
    
    if (proceedFlag == 1) [self setNeedsDisplay:YES];
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)drawRect:(NSRect)rect{
    NSRect srcRect;
    srcRect.origin.x = xPositionSnap2+xPositionAdjustSnap2+xPositionMoveSnap2;
    srcRect.origin.y = yPositionSnap2+yPositionAdjustSnap2+yPositionMoveSnap2;
    srcRect.size.width = cameraDimension/(double)(magnificationSnap2*0.1);
    srcRect.size.height = cameraDimension/(double)(magnificationSnap2*0.1);
    
    [snapWindowImage2 drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
    
    if (mouseDragFlag == 0){
        if (imageFirstLoadFlagSnap2 == 1){
            double xPositionAdj = xPositionAdjustSnap2+xPositionSnap2;
            double yPositionAdj = yPositionAdjustSnap2+yPositionSnap2;
            double xCalValue = 1/(double)windowWidthSnap2*magnificationSnap2*0.1;
            double yCalValue = 1/(double)windowHeightSnap2*magnificationSnap2*0.1;
            
            [NSBezierPath setDefaultLineWidth:2];
            NSPoint pointA;
            NSPoint pointB;
            
            if (snapFirstSecondTime == 2){
                [[NSColor redColor] set];
                pointA.x = (xClickPositionSnap2-8-xPositionAdj)*xCalValue;
                pointA.y = (cameraDimension-yClickPositionSnap2-yPositionAdj)*yCalValue;
                pointB.x = (xClickPositionSnap2+8-xPositionAdj)*xCalValue;
                pointB.y = (cameraDimension-yClickPositionSnap2-yPositionAdj)*yCalValue;
                [NSBezierPath strokeLineFromPoint:pointA toPoint:pointB];
                
                pointA.x = (xClickPositionSnap2-xPositionAdj)*xCalValue;
                pointA.y = (cameraDimension-yClickPositionSnap2-8-yPositionAdj)*yCalValue;
                pointB.x = (xClickPositionSnap2-xPositionAdj)*xCalValue;
                pointB.y = (cameraDimension-yClickPositionSnap2+8-yPositionAdj)*yCalValue;
                [NSBezierPath strokeLineFromPoint:pointA toPoint:pointB];
            }
            
            if (arraySnapData [10] != 0 && arraySnapData [11] != 0){
                double xSetPosition = 0;
                double ySetPosition = 0;
                
                if (objectiveSelect == 1){
                    ySetPosition = (arraySnapData [10]-arraySnapData [7])/(double)1.04101;
                    xSetPosition = (arraySnapData [11]-arraySnapData [8])/(double)1.04101;
                }
                else if (objectiveSelect == 2){
                    ySetPosition = (arraySnapData [10]-arraySnapData [7])/(double)0.52084;
                    xSetPosition = (arraySnapData [11]-arraySnapData [8])/(double)0.52084;
                }
                else if (objectiveSelect == 3){
                    ySetPosition = (arraySnapData [10]-arraySnapData [7])/(double)0.259589;
                    xSetPosition = (arraySnapData [11]-arraySnapData [8])/(double)0.259589;
                }
                
                [[NSColor greenColor] set];
                pointA.x = (xSetPosition-8-xPositionAdj)*xCalValue;
                pointA.y = (cameraDimension-ySetPosition-yPositionAdj)*yCalValue;
                pointB.x = (xSetPosition+8-xPositionAdj)*xCalValue;
                pointB.y = (cameraDimension-ySetPosition-yPositionAdj)*yCalValue;
                [NSBezierPath strokeLineFromPoint:pointA toPoint:pointB];
                
                pointA.x = (xSetPosition-xPositionAdj)*xCalValue;
                pointA.y = (cameraDimension-ySetPosition-8-yPositionAdj)*yCalValue;
                pointB.x = (xSetPosition-xPositionAdj)*xCalValue;
                pointB.y = (cameraDimension-ySetPosition+8-yPositionAdj)*yCalValue;
                [NSBezierPath strokeLineFromPoint:pointA toPoint:pointB];
            }
        }
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToSnapImage2 object:nil];
}

@end
