//
//  Communication.m
//  XY_Map
//
//  Created by Masahiko Sato on 2014-05-14.
//
//

#import "Communication.h"

NSString *notificationToCommunication = @"notificationExecuteCommunication";

@implementation Communication

-(id)init{
    self = [super init];
    
    if (self != nil){
        firstCommunication = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToCommunication object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    communicationTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(processControl) userInfo:nil repeats:YES];
}

-(void)processControl{
    if (firstCommunication == 0) firstCommunication = 1;
    
    if (firstCommunication == 1){
        string bodyNameReceive;
        string autoStatusXYReceive;
        string batchStatusXYReceive;
        string initialStatusXYReceive;
        string receivedData = "nil";
        
        int instructionMapFlag = 0;
        
        string getString = "nil";
        
        ifstream fin;
        
        fin.open(instructionMapPath.c_str(), ios::in);
        
        if (fin.is_open()){
            instructionMapFlag = 1;
            fin.close();
        }
        
        if (instructionMapFlag != 0){
            fin.open(instructionMapPath.c_str(), ios::in);
            
            getline(fin, getString), bodyNameReceive = getString;
            getline(fin, getString), autoStatusXYReceive = getString;
            getline(fin, getString), batchStatusXYReceive = getString;
            getline(fin, getString), initialStatusXYReceive = getString;
            
            if ((int)bodyNameReceive.find("~~") != -1){
                bodyNameReceive = bodyNameReceive.substr(2);
                receivedData = "1";
                
                remove (instructionMapPath.c_str());
            }
            
            fin.close();
        }
        
        if (receivedData != "nil"){
            if (bodyNameReceive != bodyName){
                bodyName = bodyNameReceive;
                analysisNameDisplayCall = 1;
            }
            
            autoCommitStatus = atoi(autoStatusXYReceive.c_str());
            batchCommitStatus = atoi(batchStatusXYReceive.c_str());
            initialCommitStatus = atoi(initialStatusXYReceive.c_str());
            
            //cout<< bodyName<<" "<<autoCommitStatus<<" "<<batchCommitStatus<<" "<<initialCommitStatus<<" Status"<<endl;
        }
    }
    
    //----Sending data----
    if (firstCommunication == 1 && saveDoneFlag == 1) saveDoneFlag = 2;
    
    if (firstCommunication == 1 && saveDoneFlag == 2){
        string sendString = "~~N";
        string extension;
        
        for (int counter1 = 0; counter1 < 16; counter1++){
            extension = to_string(arrayTableXYDimension [counter1*3+2]);
            sendString = sendString+"/"+extension;
        }
        
        if (objectiveSelect == 1) sendString = sendString+"/1";
        else if (objectiveSelect == 2) sendString = sendString+"/2";
        else if (objectiveSelect == 3) sendString = sendString+"/3";
        
        sendString = sendString+"/";
        
        fstream oin;
        
        for (int counter1 = 0; counter1 < 10; counter1++){
            oin.open(instructionMapPath2.c_str(), ios::out);
            
            if (oin.is_open()){
                oin<<sendString<<endl;
                oin.close();
                saveDoneFlag = 3;
                break;
            }
        }
    }
    
    if (firstCommunication == 1 && saveDoneFlag == 3) saveDoneFlag = 4;
    
    if (firstCommunication == 1 && saveDoneFlag == 4) saveDoneFlag = 0;
}

-(void)dealloc{
    if (communicationTimer) [communicationTimer invalidate];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToCommunication object:nil];
}

@end
