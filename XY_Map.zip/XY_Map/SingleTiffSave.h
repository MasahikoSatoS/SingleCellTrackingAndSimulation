//
//  TiffSave.h
//  XYMAP
//
//  Created by Masahiko Sato on 2021-06-16.
//  Copyright 2021 Masahiko Sato. All rights reserved.
//

/*Version B: With Z, ASCII; Text conversion data will be send together*/

#ifndef SINGLETIFFSAVE_H
#define SINGLETIFFSAVE_H
#import "Controller.h"
#endif

@interface SingleTiffSave : NSObject{
    id ascIIconversion;
}

-(unsigned long)singleTiffLayerSave:(int)imageDimensionX :(int)imageDimensionY :(int)imageBitPerPix :(int)photometric :(int)samplePerPix :(double)xPositionImage :(double)yPositionImage :(int)mode :(unsigned long)ifDPrevious :(double)zPositionImage;

@end
