//
//  FocusCheckControl.m
//  XY_Map
//
//  Created by Masahiko Sato on 2014-10-29.
//
//

#import "FocusCheckControl.h"

NSString *notificationToFocusCheckControl = @"notificationExecuteFocusCheckControl";

@implementation FocusCheckControl

-(id)init{
    self = [super init];
    
    if (self != nil){
        testFullMDAStatus = 0;
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToFocusCheckControl object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    focusCheckController = [[NSWindowController alloc] initWithWindowNibName:@"FocusCheck"];
    [focusCheckController showWindow:self];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFocusCheckImage object:self];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFocusCheckAddition object:self];
}

-(void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [focusCheckWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [focusCheckWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [listBrowser setTarget:self];
    [listBrowser setDoubleAction:@selector(browserDoubleClick:)];
    [listBrowser setAction:@selector(browserCellSelected:)];
    [listBrowser setSendsActionOnArrowKeys:YES];
}

-(int)browser:(NSBrowser *)sender numberOfRowsInColumn:(int)column{
    directoryInfoCount = 0;
    
    if (column == 0){
        string displayData3;
        
        for (int counter1 = 0; counter1 < chamberWellLimit1+chamberWellLimit2; counter1++){
            if (arrayTableXYDimension [counter1*3+2] != 0){
                displayData3 = to_string(counter1+1);
                
                arrayDirectoryInfo [directoryInfoCount] = "Well "+displayData3, directoryInfoCount++;
            }
        }
    }
    if (column == 1){
        NSString *path;
        path = [sender path];
        
        string imageNameTemp = [path UTF8String];
        int findString = (int)imageNameTemp.find("Well");
        string extractNo = imageNameTemp.substr((unsigned long)findString+4);
        
        int wellNo = atoi(extractNo.c_str());
        int startNo = 1;
        int endNo = 0;
        
        if (testFullMDAStatus == 0){
            for (int counter1 = 0; counter1 < chamberWellLimit1+chamberWellLimit2; counter1++){
                if (counter1 == wellNo-1){
                    endNo = startNo+arrayTableXYDimension [counter1*3+2]-1;
                    break;
                }
                else startNo = startNo+arrayTableXYDimension [counter1*3+2];
            }
        }
        else{
            
            if (wellPositionTest [wellNo*2] != -1){
                startNo = wellPositionTest [wellNo*2];
                endNo = wellPositionTest [wellNo*2+1];
            }
        }
        
        string getString;
        string userNameTemp;
        string bodyNameTemp;
        
        ifstream fin;
        
        fin.open(analysisDataPath.c_str(), ios::in);
        
        if (fin.is_open()){
            getline(fin, getString), bodyNameTemp = getString;
            getline(fin, getString);
            getline(fin, getString);
            getline(fin, getString), userNameTemp = getString;
            fin.close();
        }
        
        int maxBodyNo = 0;
        int maxTimePoint = 1;
        int bodyNameLength = (int)bodyName.length();
        int fileNoCount = 0;
        
        string entry;
        
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(dataDirectoryPath.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if ((int)entry.find(bodyName) != -1) fileNoCount++;
            }
            
            closedir(dir);
        }
        
        string *arrayDirectoryInfoTemp = new string [fileNoCount+500];
        int directoryInfoTempCount = 0;
        
        dir = opendir(dataDirectoryPath.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if ((int)entry.find(bodyName) != -1) arrayDirectoryInfoTemp [directoryInfoTempCount] = entry, directoryInfoTempCount++;
            }
            
            closedir(dir);
            
            //----Directory Sort----
            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
            
            for (int counter1 = 0; counter1 < directoryInfoTempCount; counter1++){
                [unsortedArray addObject:@(arrayDirectoryInfoTemp [counter1].c_str())];
            }
            
            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
            
            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                arrayDirectoryInfoTemp [counter1] = [unsortedArray [counter1] UTF8String];
            }
        }
        
        if (directoryInfoTempCount != 0){
            string tempName;
            string bodyNameExtract;
            string lastString;
            string extractStringTemp;
            string extractStringTemp2;
            
            int findString1 = 0;
            int terminationFlag = 0;
            
            for (int counter1 = 0; counter1 < directoryInfoTempCount; counter1++){
                entry = arrayDirectoryInfoTemp [counter1];
                
                findString1 = (int)entry.find(bodyName);
                
                if (findString1 > 0){
                    if (entry.substr((unsigned long)findString1-1, 1) != "_") findString1 = -1;
                }
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && findString1 != -1){
                    tempName = entry.substr((unsigned long)findString1);
                    bodyNameExtract = tempName.substr(0, tempName.find("_"));
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        lastString = bodyNameExtract.substr(bodyNameExtract.length()-1, 1);
                        
                        if (lastString == "0" || lastString == "1" || lastString == "2" || lastString == "3" || lastString == "4" || lastString == "5" || lastString == "6" || lastString == "7" || lastString == "8" || lastString == "9"){
                            bodyNameExtract = bodyNameExtract.substr(0, bodyNameExtract.length()-1);
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    if (bodyNameExtract == bodyName && (int)entry.find("_s") != -1){
                        tempName = entry.substr(entry.find(bodyName));
                        extractStringTemp = tempName.substr((unsigned long)bodyNameLength, tempName.find("_")-(unsigned long)bodyNameLength);
                        
                        if (atoi(extractStringTemp.c_str()) != 0 && atoi(extractStringTemp.c_str()) > maxBodyNo) maxBodyNo = atoi(extractStringTemp.c_str());
                    }
                }
            }
            
            for (int counter1 = 0; counter1 < directoryInfoTempCount; counter1++){
                entry = arrayDirectoryInfoTemp [counter1];
                
                findString1 = (int)entry.find(bodyName);
                
                if (findString1 > 0){
                    if (entry.substr((unsigned long)findString1-1, 1) != "_") findString1 = -1;
                }
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && findString1 != -1){
                    tempName = entry.substr((unsigned long)findString1);
                    bodyNameExtract = tempName.substr(0, tempName.find("_"));
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        lastString = bodyNameExtract.substr(bodyNameExtract.length()-1, 1);
                        
                        if (lastString == "0" || lastString == "1" || lastString == "2" || lastString == "3" || lastString == "4" || lastString == "5" || lastString == "6" || lastString == "7" || lastString == "8" || lastString == "9"){
                            bodyNameExtract = bodyNameExtract.substr(0, bodyNameExtract.length()-1);
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    if (bodyNameExtract == bodyName && (int)entry.find("_s") != -1){
                        tempName = entry.substr(entry.find(bodyName));
                        extractStringTemp = tempName.substr((unsigned long)bodyNameLength, tempName.find("_")-(unsigned long)bodyNameLength);
                        
                        if (maxBodyNo == atoi(extractStringTemp.c_str())){
                            extractStringTemp = entry.substr(entry.find("_t")+2, entry.find(".TIF")-entry.find("_t")-2);
                            
                            if (maxTimePoint < atoi(extractStringTemp.c_str())) maxTimePoint = atoi(extractStringTemp.c_str());
                        }
                    }
                }
            }
            
            for (int counter1 = 0; counter1 < directoryInfoTempCount; counter1++){
                entry = arrayDirectoryInfoTemp [counter1];
                
                findString1 = (int)entry.find(bodyName);
                
                if (findString1 > 0){
                    if (entry.substr((unsigned long)findString1-1, 1) != "_") findString1 = -1;
                }
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && findString1 != -1){
                    tempName = entry.substr((unsigned long)findString1);
                    bodyNameExtract = tempName.substr(0, tempName.find("_"));
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        lastString = bodyNameExtract.substr(bodyNameExtract.length()-1, 1);
                        
                        if (lastString == "0" || lastString == "1" || lastString == "2" || lastString == "3" || lastString == "4" || lastString == "5" || lastString == "6" || lastString == "7" || lastString == "8" || lastString == "9"){
                            bodyNameExtract = bodyNameExtract.substr(0, bodyNameExtract.length()-1);
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    if (bodyNameExtract == bodyName){
                        tempName = entry.substr(entry.find(bodyName));
                        extractStringTemp = tempName.substr((unsigned long)bodyNameLength, tempName.find("_")-(unsigned long)bodyNameLength);
                        int extractStringTempInt = atoi(extractStringTemp.c_str());
                        
                        extractStringTemp = entry.substr(entry.find("_t")+2, entry.find(".TIF")-entry.find("_t")-2);
                        int timeInt = atoi(extractStringTemp.c_str());
                        
                        extractStringTemp2 = entry.substr(entry.find("_s")+2, entry.find("_t")-entry.find("_s")-2);
                        int stagePosition = atoi(extractStringTemp2.c_str());
                        
                        if (extractStringTempInt == maxBodyNo && timeInt == maxTimePoint && stagePosition >= startNo && stagePosition <= endNo){
                            if (directoryInfoCount+10 > directoryInfoLimit) [self directoryInfoDate];
                            
                            arrayDirectoryInfo [directoryInfoCount] = entry, directoryInfoCount++;
                        }
                    }
                }
            }
        }
        
        delete [] arrayDirectoryInfoTemp;
    }
    
    return directoryInfoCount;
}

-(void)browser:(NSBrowser *)sender willDisplayCell:(id)cell atRow:(int)row column:(int)column{
    if (column == 0){
        string folderName = arrayDirectoryInfo [row];
        [cell setStringValue: @(folderName.c_str())];
        [cell setLoaded:YES];
    }
    if (column == 1){
        string folderName = arrayDirectoryInfo [row];
        [cell setStringValue: @(folderName.c_str())];
        [cell setLeaf:YES];
    }
}

-(void)browserCellSelected:(id)sender{
    NSString *nodePath = [listBrowser path];
    string nodePathString = [nodePath UTF8String];
    
    if (nodePathString != ""){
        string fileNameExtraction = nodePathString.substr(nodePathString.find("/")+1);
        fileNameHold = fileNameExtraction.substr(fileNameExtraction.find("/")+1);
        
        fileNameHoldCall = 2;
    }
}

-(IBAction)browserDoubleClick:(id)browser{
    NSString *nodePath = [browser path];
    string nodePathString = [nodePath UTF8String];
    
    if (nodePathString != ""){
        nodePathString = nodePathString.substr(1);
        
        if ((int)nodePathString.find("/") != -1){
            string getString;
            string userNameTemp;
            string bodyNameTemp;
            
            ifstream fin;
            
            fin.open(analysisDataPath.c_str(), ios::in);
            
            if (fin.is_open()){
                getline(fin, getString), bodyNameTemp = getString;
                getline(fin, getString);
                getline(fin, getString);
                getline(fin, getString), userNameTemp = getString;
                fin.close();
            }
            
            string fileNameExtraction = nodePathString.substr(nodePathString.find("/")+1);
            
            int fluorescentAddition = 0;
            
            if ((int)fileNameExtraction.find("_w") != -1 && (int)fileNameExtraction.find("DIC") == -1) fluorescentAddition = 2;
            else if ((int)fileNameExtraction.find("_w") != -1 && (int)fileNameExtraction.find("DIC") != -1) fluorescentAddition = 1;
            
            string imageDisplayPath = dataDirectoryPath+"/"+fileNameHold;
            
            fin.open(imageDisplayPath.c_str(), ios::in);
            
            if (fin.is_open()){
                fin.close();
                
                if (imageDataHoldZImageStatus == 1){
                    for (int counter1 = 0; counter1 < zImageHeight*zImagePlane+2; counter1++) delete [] arrayImageDataHoldZImage [counter1];
                    delete [] arrayImageDataHoldZImage;
                }
                
                zImageHeight = 0;
                zImageWidth = 0;
                zImagePlane = 1;
                
                //----Tiff reading----
                unsigned long stripFirstAddress = 0;
                unsigned long stripByteCountAddress = 0;
                unsigned long nextAddress = 0;
                unsigned long headPosition = 0;
                unsigned long stripEntry = 0;
                unsigned long headPositionHold = 0;
                
                long sizeForCopy = 0;
                
                double xPosition = 0;
                double yPosition = 0;
                double zPosition = 0;
                
                int imageWidth = 0;
                int imageHeight = 0;
                int imageBit = 0; //Check 8, 16
                int imageCompression = 0; //Check 1
                int photoMetric = 0; //Check 0, 1, 2
                int verticalBmp = 0;
                int horizontalBmpEntry = 0;
                int endianType = 0;
                int samplePerPix = 0;
                int dataConversion [4];
                int processType = 1;
                int numberOfLayers = 0;
                int terminationFlag = 0;
                int loopCount = 0;
                int horizontalActual = 0;
                
                ifstream fin2;
                
                //----File Read----
                struct stat sizeOfFile;
                
                if (stat(imageDisplayPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    fileReadArray = new uint8_t [(int)sizeForCopy+4];
                    fin2.open(imageDisplayPath.c_str(), ios::in | ios::binary);
                    fin2.read((char*)fileReadArray, sizeForCopy+1);
                    fin2.close();
                    
                    dataConversion [0] = fileReadArray [0];
                    dataConversion [1] = fileReadArray [1];
                    
                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                    else endianType = 0;
                    
                    if (endianType == 1){
                        dataConversion [0] = fileReadArray [7];
                        dataConversion [1] = fileReadArray [6];
                        dataConversion [2] = fileReadArray [5];
                        dataConversion [3] = fileReadArray [4];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    else if (endianType == 0){
                        dataConversion [0] = fileReadArray [4];
                        dataConversion [1] = fileReadArray [5];
                        dataConversion [2] = fileReadArray [6];
                        dataConversion [3] = fileReadArray [7];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    
                    headPositionHold = headPosition;
                    loopCount = 1;
                    
                    zImageWidth = 0;
                    zImageHeight = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        if (endianType == 1){
                            tiffFileRead = [[TiffFileRead alloc] init];
                            [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers:&zPosition];
                            
                            if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                zImageWidth = imageWidth;
                                zImageHeight = imageHeight;
                            }
                        }
                        else if (endianType == 0){
                            tiffFileRead = [[TiffFileRead alloc] init];
                            [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers:&zPosition];
                            
                            if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                zImageWidth = imageWidth;
                                zImageHeight = imageHeight;
                            }
                        }
                        
                        if (nextAddress != 0){
                            headPosition = nextAddress;
                            loopCount++;
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    zImagePlane = loopCount;
                    
                    int *arrayExtractedImage3 = new int [100];
                    
                    zImagePlane = loopCount;
                    
                    if (zImageWidth == zImageHeight*2 && zImageWidth != 0 && zImageHeight != 0){
                        if (photoMetric < 1) photoMetric = 1;
                        else photoMetric = 2;
                        
                        imageDataHoldZImageStatus = 1;
                        
                        arrayImageDataHoldZImage = new int *[zImageHeight*zImagePlane+2];
                        for (int counter1 = 0; counter1 < zImageHeight*zImagePlane+2; counter1++) arrayImageDataHoldZImage [counter1] = new int [(zImageWidth/2)*3+2];
                        
                        verticalBmp = 0;
                        headPosition = headPositionHold;
                        
                        do{
                            
                            terminationFlag = 1;
                            
                            if (endianType == 1){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers:&zPosition];
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:cameraDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                }
                            }
                            else if (endianType == 0){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers:&zPosition];
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:cameraDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                }
                            }
                            
                            if (imageWidth == imageHeight*2 && cameraDimension == imageHeight){
                                if (fluorescentAddition == 1){
                                    horizontalBmpEntry = 0;
                                    
                                    if (photoMetric == 1){
                                        horizontalActual = 0;
                                        
                                        for (int counter2 = 0; counter2 < imageWidth*imageHeight; counter2++){
                                            if (horizontalBmpEntry >= zImageWidth/2){
                                                arrayImageDataHoldZImage [verticalBmp][horizontalActual] = (int)(arrayExtractedImage3 [counter2]);
                                                
                                                horizontalActual++;
                                                horizontalBmpEntry++;
                                            }
                                            else horizontalBmpEntry++;
                                            
                                            if (horizontalBmpEntry == zImageWidth){
                                                horizontalBmpEntry = 0;
                                                horizontalActual = 0;
                                                verticalBmp++;
                                            }
                                        }
                                        
                                        focusPhotometric = photoMetric;
                                    }
                                    else if (photoMetric == 2){
                                        horizontalActual = 0;
                                        
                                        for (int counter2 = 0; counter2 < imageWidth*imageHeight; counter2++){
                                            if (horizontalBmpEntry >= zImageWidth/2){
                                                arrayImageDataHoldZImage [verticalBmp][horizontalActual] = (int)(arrayExtractedImage3 [counter2*3]);
                                                horizontalBmpEntry++;
                                                horizontalActual++;
                                                arrayImageDataHoldZImage [verticalBmp][horizontalActual] = (int)(arrayExtractedImage3 [counter2*3+1]);
                                                horizontalBmpEntry++;
                                                horizontalActual++;
                                                arrayImageDataHoldZImage [verticalBmp][horizontalActual] = (int)(arrayExtractedImage3 [counter2*3+2]);
                                                horizontalBmpEntry++;
                                                horizontalActual++;
                                            }
                                            else horizontalBmpEntry = horizontalBmpEntry+3;
                                            
                                            if (horizontalBmpEntry == zImageWidth*3){
                                                horizontalBmpEntry = 0;
                                                horizontalActual = 0;
                                                verticalBmp++;
                                            }
                                        }
                                        
                                        focusPhotometric = photoMetric;
                                    }
                                }
                                
                                if (fluorescentAddition == 2){
                                    horizontalBmpEntry = 0;
                                    
                                    if (photoMetric == 1){
                                        for (int counter2 = 0; counter2 < imageWidth*imageHeight; counter2++){
                                            if (horizontalBmpEntry < zImageWidth/2){
                                                arrayImageDataHoldZImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2]);
                                                horizontalBmpEntry++;
                                            }
                                            else horizontalBmpEntry++;
                                            
                                            if (horizontalBmpEntry == imageWidth){
                                                horizontalBmpEntry = 0;
                                                verticalBmp++;
                                            }
                                        }
                                        
                                        focusPhotometric = photoMetric;
                                    }
                                    else if (photoMetric == 2){
                                        for (int counter2 = 0; counter2 < imageWidth*imageHeight; counter2++){
                                            if (horizontalBmpEntry < zImageWidth/2){
                                                arrayImageDataHoldZImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2*3]), horizontalBmpEntry++;
                                                arrayImageDataHoldZImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2*3+1]), horizontalBmpEntry++;
                                                arrayImageDataHoldZImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2*3+2]), horizontalBmpEntry++;
                                            }
                                            else horizontalBmpEntry = horizontalBmpEntry+3;
                                            
                                            if (horizontalBmpEntry == imageWidth*3){
                                                horizontalBmpEntry = 0;
                                                verticalBmp++;
                                            }
                                        }
                                        
                                        focusPhotometric = photoMetric;
                                    }
                                }
                            }
                            
                            if (nextAddress != 0) headPosition = nextAddress;
                            else terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                    else if (zImageWidth == zImageHeight && zImageWidth != 0 && zImageHeight != 0){
                        if (photoMetric < 1) photoMetric = 1;
                        else photoMetric = 2;
                        
                        imageDataHoldZImageStatus = 1;
                        
                        arrayImageDataHoldZImage = new int *[zImageHeight*zImagePlane+2];
                        for (int counter1 = 0; counter1 < zImageHeight*zImagePlane+2; counter1++) arrayImageDataHoldZImage [counter1] = new int [zImageWidth+2];
                        
                        verticalBmp = 0;
                        headPosition = headPositionHold;
                        
                        do{
                            
                            terminationFlag = 1;
                            
                            if (endianType == 1){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers:&zPosition];
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:cameraDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                }
                            }
                            else if (endianType == 0){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers:&zPosition];
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:cameraDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                }
                            }
                            
                            if (imageWidth == imageHeight && cameraDimension == imageWidth){
                                horizontalBmpEntry = 0;
                                
                                if (photoMetric == 1){
                                    for (int counter2 = 0; counter2 < imageWidth*imageHeight; counter2++){
                                        arrayImageDataHoldZImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2]);
                                        horizontalBmpEntry++;
                                        
                                        if (horizontalBmpEntry == imageWidth){
                                            horizontalBmpEntry = 0;
                                            verticalBmp++;
                                        }
                                    }
                                    
                                    focusPhotometric = photoMetric;
                                }
                                else if (photoMetric == 2){
                                    for (int counter2 = 0; counter2 < imageWidth*imageHeight; counter2++){
                                        arrayImageDataHoldZImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2*3]), horizontalBmpEntry++;
                                        arrayImageDataHoldZImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2*3+1]), horizontalBmpEntry++;
                                        arrayImageDataHoldZImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2*3+2]), horizontalBmpEntry++;
                                        
                                        if (horizontalBmpEntry == imageWidth*3){
                                            horizontalBmpEntry = 0;
                                            verticalBmp++;
                                        }
                                    }
                                    
                                    focusPhotometric = photoMetric;
                                }
                            }
                            
                            if (nextAddress != 0) headPosition = nextAddress;
                            else terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                    
                    delete [] fileReadArray;
                    delete []arrayExtractedImage3;
                }
            }
            
            planeNumberDisplay = 0;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFocusCheckImage object:self];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Image Files Found"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Image Files Found"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderAction:(id)sender{
    if (imageFirstLoadFlagFocus == 1){
        contrastAdjust = [sliderContrast doubleValue];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFocusCheckImage object:self];
    }
}

-(IBAction)tableReload:(id)sender{
    [listBrowser reloadColumn:0];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)testFullMDA:(id)sender{
    if (testFullMDAStatus == 0){
        testFullMDAStatus = 1;
        [testFullDisplay setStringValue:@"Test"];
    }
    else{
        
        testFullMDAStatus = 0;
        [testFullDisplay setStringValue:@"Full"];
    }
}

-(IBAction)closeWindow:(id)sender{
    [focusCheckWindow orderOut:self];
    focusOperation = 2;
    focusCheckTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (focusOperation == 3){
        [focusCheckWindow makeKeyAndOrderFront:self];
        focusOperation = 1;
        [focusCheckTimer invalidate];
    }
}

-(void)directoryInfoDate{
    string *arrayUpDate = new string [directoryInfoCount+10];
    
    for (int counter1 = 0; counter1 < directoryInfoCount; counter1++) arrayUpDate [counter1] = arrayDirectoryInfo [counter1];
    
    delete [] arrayDirectoryInfo;
    arrayDirectoryInfo = new string [directoryInfoCount+500];
    selectedMapLimit1 = directoryInfoLimit+500;
    
    for (int counter1 = 0; counter1 < directoryInfoCount; counter1++) arrayDirectoryInfo [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    if (focusCheckTimer) [focusCheckTimer invalidate];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToFocusCheckControl object:nil];
}

@end
