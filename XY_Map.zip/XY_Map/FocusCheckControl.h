//
//  FocusCheckControl.h
//  XY_Map
//
//  Created by Masahiko Sato on 2014-10-29.
//
//

#ifndef FOCUSCHECKCONTROL_H
#define FOCUSCHECKCONTROL_H
#import "Controller.h" 
#endif

@interface FocusCheckControl : NSObject {
    int testFullMDAStatus; //Test or full status
    
    IBOutlet NSTextField *testFullDisplay;
    
    IBOutlet NSWindow *focusCheckWindow;
    IBOutlet NSBrowser *listBrowser;
    IBOutlet NSSlider *sliderContrast;
    
    NSTimer *focusCheckTimer;
    NSWindowController *focusCheckController;
    
    id tiffFileRead;
}

-(id)init;
-(void)reDisplayWindow;
-(void)dealloc;

-(IBAction)closeWindow:(id)sender;
-(IBAction)browserDoubleClick:(id)browser;
-(IBAction)sliderAction:(id)sender;
-(IBAction)tableReload:(id)sender;
-(IBAction)testFullMDA:(id)sender;

@end
