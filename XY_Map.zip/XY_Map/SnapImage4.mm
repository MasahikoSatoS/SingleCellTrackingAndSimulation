//
//  SnapImage4.m
//  XY_Map
//
//  Created by Masahiko Sato on 2014-08-23.
//
//

#import "SnapImage4.h"

NSString *notificationToSnapImage4 = @"notificationExecuteSnapImage4";

@implementation SnapImage4

- (id)initWithFrame:(NSRect)frame{
    self = [super initWithFrame:frame];
    
    if (self){
        magnificationSnap4 = 10;
        mouseDragFlag = 0;
        snapWindowImage4 = [[NSImage alloc] initWithContentsOfFile:@""];
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToSnapImage4 object:nil];
    }
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    if (snapStart2 == 1){
        string extension = to_string(snapPage2*2);
        
        if (extension.length() == 1) extension = "00"+extension;
        else if (extension.length() == 2) extension = "0"+extension;
        
        string snapSavePath = cellTrackingSystemDataPath+"/"+"SnapB-"+extension;
        
        unsigned long nextAddress = 0;
        unsigned long stripFirstAddress = 0;
        unsigned long stripByteCountAddress = 0;
        unsigned long headPosition = 0;
        unsigned long stripEntry = 0;
        long sizeForCopy = 0;
        
        double xPosition = 0;
        double yPosition = 0;
        double zPosition = 0;
        
        int imageWidth = 0;
        int imageHeight = 0;
        int imageBit = 0; //Check 8, 16
        int imageCompression = 0; //Check 1
        int photoMetric = 0; //Check 0, 1, 2
        int imageDimension = 0;
        int verticalBmp = 0;
        int horizontalBmp = 0;
        int endianType = 0;
        int samplePerPix = 0;
        int dataConversion [4];
        int processType = 0; //----Out put image 8 bit gray
        int numberOfLayers = 0;
        
        //----File Read----
        struct stat sizeOfFile;
        
        ifstream fin;
        
        if (stat(snapSavePath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            int **imageDataTemp = new int *[cameraDimension+1];
            for (int counter1 = 0; counter1 < cameraDimension+1; counter1++) imageDataTemp [counter1] = new int [cameraDimension+1];
            
            for (int counter3 = 0; counter3 < cameraDimension+1; counter3++){
                for (int counter4 = 0; counter4 < cameraDimension+1; counter4++){
                    imageDataTemp [counter3][counter4] = 0;
                }
            }
            
            fileReadArray = new uint8_t [sizeForCopy+4];
            fin.open(snapSavePath.c_str(), ios::in | ios::binary);
            
            fin.read((char*)fileReadArray, sizeForCopy+1);
            fin.close();
            
            dataConversion [0] = fileReadArray [0];
            dataConversion [1] = fileReadArray [1];
            
            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
            else endianType = 0;
            
            if (endianType == 1){
                dataConversion [0] = fileReadArray [7];
                dataConversion [1] = fileReadArray [6];
                dataConversion [2] = fileReadArray [5];
                dataConversion [3] = fileReadArray [4];
                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
            }
            else if (endianType == 0){
                dataConversion [0] = fileReadArray [4];
                dataConversion [1] = fileReadArray [5];
                dataConversion [2] = fileReadArray [6];
                dataConversion [3] = fileReadArray [7];
                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
            }
            
            int *arrayExtractedImage3 = new int [100];
            
            if (endianType == 1){ //----Big endian----
                tiffFileRead = [[TiffFileRead alloc] init];
                [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers:&zPosition];
                
                tiffFileRead = [[TiffFileRead alloc] init];
                delete [] arrayExtractedImage3;
                
                imageDimension = imageWidth;
                
                arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
            }
            else if (endianType == 0){
                tiffFileRead = [[TiffFileRead alloc] init];
                [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers:&zPosition];
                
                tiffFileRead = [[TiffFileRead alloc] init];
                delete [] arrayExtractedImage3;
                
                imageDimension = imageWidth;
                
                arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
            }
            
            //cout<<imageCompression<<" "<<imageBit<<" "<<" "<<samplePerPix<<" "<<photoMetric<<" entryinfo"<<endl;
            
            if (imageCompression == 1 && imageBit == 8 && numberOfLayers == 1 && samplePerPix == 1 && imageWidth == cameraDimension){
                for (int counter3 = 0; counter3 < cameraDimension*cameraDimension; counter3++){
                    if (horizontalBmp < cameraDimension){
                        imageDataTemp [verticalBmp][horizontalBmp] = arrayExtractedImage3 [counter3], horizontalBmp++;
                    }
                    
                    if (horizontalBmp == cameraDimension){
                        horizontalBmp = 0;
                        verticalBmp++;
                    }
                }
                
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:cameraDimension pixelsHigh:cameraDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:cameraDimension bitsPerPixel:8];
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                for (int counter1 = 0; counter1 < cameraDimension; counter1++){
                    for (int counter2 = 0; counter2 < cameraDimension; counter2++) *bitmapData++ = (unsigned char)imageDataTemp [counter1][counter2];
                }
                
                snapWindowImage4 = [[NSImage alloc] initWithSize:NSMakeSize(cameraDimension, cameraDimension)];
                [snapWindowImage4 addRepresentation:bitmapReps];
                
                if (imageFirstLoadFlagSnap4 == 0){
                    xPositionSnap4 = 0;
                    yPositionSnap4 = 0;
                    xPositionAdjustSnap4 = 0;
                    yPositionAdjustSnap4 = 0;
                    magnificationSnap4 = 10;
                    imageFirstLoadFlagSnap4 = 1;
                }
                
                //----Window size and Position re-adjust----
                int vertical = 300+78;
                int horizontal = 300;
                
                windowWidthSnap4 = cameraDimension/(double)horizontal;
                windowHeightSnap4 = cameraDimension/(double)(vertical-78);
                
                xPositionAdjustSnap4 = (cameraDimension-cameraDimension/(double)(magnificationSnap4*0.1))/(double)2;
                yPositionAdjustSnap4 = (cameraDimension-cameraDimension/(double)(magnificationSnap4*0.1))/(double)2;
            }
            else snapWindowImage4 = [[NSImage alloc] initWithContentsOfFile:@""];
            
            for (int counter1 = 0; counter1 < cameraDimension+1; counter1++) delete [] imageDataTemp [counter1];
            delete [] imageDataTemp;
            
            delete [] fileReadArray;
            delete [] arrayExtractedImage3;
        }
        else snapWindowImage4 = [[NSImage alloc] initWithContentsOfFile:@""];
        
        [self setNeedsDisplay:YES];
    }
}

-(void)mouseDown:(NSEvent *)event{
    NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
    xPointDownSnap4 = clickPoint.x;
    yPointDownSnap4 = clickPoint.y;
    
    int xPositionTemp = (int)(xPointDownSnap4*(double)windowWidthSnap4/(double)magnificationSnap4/(double)0.1+xPositionAdjustSnap4+xPositionSnap4);
    int yPositionTemp = cameraDimension-(int)((yPointDownSnap4*(double)windowHeightSnap4/(double)magnificationSnap4/(double)0.1+yPositionAdjustSnap4+yPositionSnap4+windowHeightSnap4));
    
    xClickPositionSnap4 = xPositionTemp;
    yClickPositionSnap4 = yPositionTemp;
    
    [self setNeedsDisplay:YES];
}

-(void)mouseUp:(NSEvent *)event{
    xPositionSnap4 = xPositionSnap4+xPositionMoveSnap4;
    yPositionSnap4 = yPositionSnap4+yPositionMoveSnap4;
    xPositionMoveSnap4 = 0;
    yPositionMoveSnap4 = 0;
    mouseDragFlag = 0;
    [self setNeedsDisplay:YES];
}

-(void)mouseDraged:(NSEvent *)event{
    NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
    xPointDragSnap4 = clickPoint.x;
    yPointDragSnap4 = clickPoint.y;
    xPositionMoveSnap4 = (xPointDownSnap4-xPointDragSnap4)*windowWidthSnap4/(double)(magnificationSnap4*0.1);
    yPositionMoveSnap4 = (yPointDownSnap4-yPointDragSnap4)*windowHeightSnap4/(double)(magnificationSnap4*0.1);
    
    mouseDragFlag = 1;
    [self setNeedsDisplay:YES];
}

-(void)keyDown:(NSEvent *)event{
    int keyCode = [event keyCode];
    int proceedFlag = 0;
    
    //----Original size----
    if (keyCode == 6){
        proceedFlag = 1;
        xPositionSnap4 = 0;
        yPositionSnap4 = 0;
        xPositionAdjustSnap4 = 0;
        yPositionAdjustSnap4 = 0;
        magnificationSnap4 = 10;
    }
    
    //----Magnification Magnify----
    if (keyCode == 125){
        if (magnificationSnap4 >= 12 && magnificationSnap4 <= 350){
            proceedFlag = 1;
            if (magnificationSnap4-10 < 12) magnificationSnap4 = 12;
            else magnificationSnap4 = magnificationSnap4-10;
            
            xPositionAdjustSnap4 = -1*(cameraDimension/(double)(magnificationSnap4*0.1)-cameraDimension)/(double)2;
            yPositionAdjustSnap4 = -1*(cameraDimension/(double)(magnificationSnap4*0.1)-cameraDimension)/(double)2;
        }
    }
    
    //----Magnification Reduction----
    if (keyCode == 126){
        if (magnificationSnap4 >= 10 && magnificationSnap4 <= 498){
            proceedFlag = 1;
            
            if (magnificationSnap4+10 > 498) magnificationSnap4 = 498;
            else magnificationSnap4 = magnificationSnap4+10;
            
            xPositionAdjustSnap4 = (cameraDimension-cameraDimension/(double)(magnificationSnap4*0.1))/(double)2;
            yPositionAdjustSnap4 = (cameraDimension-cameraDimension/(double)(magnificationSnap4*0.1))/(double)2;
        }
    }
    
    if (proceedFlag == 1) [self setNeedsDisplay:YES];
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)drawRect:(NSRect)rect{
    NSRect srcRect;
    srcRect.origin.x = xPositionSnap4+xPositionAdjustSnap4+xPositionMoveSnap4;
    srcRect.origin.y = yPositionSnap4+yPositionAdjustSnap4+yPositionMoveSnap4;
    srcRect.size.width = cameraDimension/(double)(magnificationSnap4*0.1);
    srcRect.size.height = cameraDimension/(double)(magnificationSnap4*0.1);
    
    [snapWindowImage4 drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
    
    if (mouseDragFlag == 0){
        if (imageFirstLoadFlagSnap4 == 1){
            double xPositionAdj = xPositionAdjustSnap4+xPositionSnap4;
            double yPositionAdj = yPositionAdjustSnap4+yPositionSnap4;
            double xCalValue = 1/(double)windowWidthSnap4*magnificationSnap4*0.1;
            double yCalValue = 1/(double)windowHeightSnap4*magnificationSnap4*0.1;
            
            [NSBezierPath setDefaultLineWidth:2];
            NSPoint pointA;
            NSPoint pointB;
            
            if (snapFirstSecondTime2 == 2){
                [[NSColor redColor] set];
                pointA.x = (xClickPositionSnap4-8-xPositionAdj)*xCalValue;
                pointA.y = (cameraDimension-yClickPositionSnap4-yPositionAdj)*yCalValue;
                pointB.x = (xClickPositionSnap4+8-xPositionAdj)*xCalValue;
                pointB.y = (cameraDimension-yClickPositionSnap4-yPositionAdj)*yCalValue;
                [NSBezierPath strokeLineFromPoint:pointA toPoint:pointB];
                
                pointA.x = (xClickPositionSnap4-xPositionAdj)*xCalValue;
                pointA.y = (cameraDimension-yClickPositionSnap4-8-yPositionAdj)*yCalValue;
                pointB.x = (xClickPositionSnap4-xPositionAdj)*xCalValue;
                pointB.y = (cameraDimension-yClickPositionSnap4+8-yPositionAdj)*yCalValue;
                [NSBezierPath strokeLineFromPoint:pointA toPoint:pointB];
            }
            
            if (arraySnapData2 [10] != 0 && arraySnapData2 [11] != 0){
                double xSetPosition = 0;
                double ySetPosition = 0;
                
                if (objectiveSelect == 1){
                    ySetPosition = (arraySnapData2 [10]-arraySnapData2 [7])/(double)1.04101;
                    xSetPosition = (arraySnapData2 [11]-arraySnapData2 [8])/(double)1.04101;
                }
                else if (objectiveSelect == 2){
                    ySetPosition = (arraySnapData2 [10]-arraySnapData2 [7])/(double)0.52084;
                    xSetPosition = (arraySnapData2 [11]-arraySnapData2 [8])/(double)0.52084;
                }
                else if (objectiveSelect == 3){
                    ySetPosition = (arraySnapData2 [10]-arraySnapData2 [7])/(double)0.259589;
                    xSetPosition = (arraySnapData2 [11]-arraySnapData2 [8])/(double)0.2595890;
                }
                
                [[NSColor greenColor] set];
                pointA.x = (xSetPosition-8-xPositionAdj)*xCalValue;
                pointA.y = (cameraDimension-ySetPosition-yPositionAdj)*yCalValue;
                pointB.x = (xSetPosition+8-xPositionAdj)*xCalValue;
                pointB.y = (cameraDimension-ySetPosition-yPositionAdj)*yCalValue;
                [NSBezierPath strokeLineFromPoint:pointA toPoint:pointB];
                
                pointA.x = (xSetPosition-xPositionAdj)*xCalValue;
                pointA.y = (cameraDimension-ySetPosition-8-yPositionAdj)*yCalValue;
                pointB.x = (xSetPosition-xPositionAdj)*xCalValue;
                pointB.y = (cameraDimension-ySetPosition+8-yPositionAdj)*yCalValue;
                [NSBezierPath strokeLineFromPoint:pointA toPoint:pointB];
            }
        }
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToSnapImage4 object:nil];
}

@end
