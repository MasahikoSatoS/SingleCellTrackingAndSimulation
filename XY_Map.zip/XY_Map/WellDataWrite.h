//
//  WellDataWrite.h
//  XY_Map
//
//  Created by Masahiko Sato on 28/05/13, 28/05/13 revised.
//  Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef WELLDATAWRITE_H
#define WELLDATAWRITE_H
#import "Controller.h"
#endif

@interface WellDataWrite : NSObject {
    int *arrayWellData; //Well data for STG file
    int wellDataCount;
    int wellDataLimit;
    
    id ascIIconversion;
}

-(int)dataSave;
-(void)wellDataFile:(int)arrayNumber;
-(void)wellDataMapUpDate;

@end
