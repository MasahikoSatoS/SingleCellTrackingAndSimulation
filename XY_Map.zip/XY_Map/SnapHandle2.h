//
//  SnapHandle2.h
//  XY_Map
//
//  Created by Masahiko Sato on 2014-09-20.
//
//

#ifndef SNAPHANDLE2_H
#define SNAPHANDLE2_H
#import "Controller.h" 
#endif

@interface SnapHandle2 : NSObject <NSTextFieldDelegate> {
    int stepperLimitXL2; //Stepper limit
    int stepperLimitXH2; //Stepper limit
    int stepperLimitYL2; //Stepper limit
    int stepperLimitYH2; //Stepper limit
    
    IBOutlet NSTextField *snap3;
    IBOutlet NSTextField *snap4;
    IBOutlet NSTextField *xPositionSnap3;
    IBOutlet NSTextField *yPositionSnap3;
    IBOutlet NSTextField *zPositionSnap3;
    IBOutlet NSTextField *xPositionSnap4;
    IBOutlet NSTextField *yPositionSnap4;
    IBOutlet NSTextField *zPositionSnap4;
    IBOutlet NSTextField *xDiff3;
    IBOutlet NSTextField *yDiff3;
    IBOutlet NSTextField *pageNo2;
    IBOutlet NSTextField *stepperStartDisplay2;
    
    IBOutlet NSWindow *snapWindow2;
    IBOutlet NSStepper *stepperX2;
    IBOutlet NSStepper *stepperY2;
    IBOutlet NSStepper *stepperStart2;
    
    NSTimer *snapTimer2;
    NSWindowController *snapDisplayController2;
    
    id ascIIconversion;
    id subProcesses;
    id singleTiffSave;
    id tiffFileRead;
}

-(id)init;
-(void)reDisplayWindow;
-(void)fileDeleteUpDate;
-(void)dealloc;

-(IBAction)closeWindow:(id)sender;
-(IBAction)snapSet3:(id)sender;
-(IBAction)snapSet4:(id)sender;
-(IBAction)create3:(id)sender;
-(IBAction)createSnap3:(id)sender;
-(IBAction)createMain3:(id)sender;
-(IBAction)imageLoad:(id)sender;
-(IBAction)stepperActionX3:(id)sender;
-(IBAction)stepperActionY3:(id)sender;
-(IBAction)stepperActionStart2:(id)sender;
-(IBAction)timePointSWMain:(id)sender;
-(IBAction)clearPage:(id)sender;
-(IBAction)pageFW:(id)sender;
-(IBAction)pageBW:(id)sender;
-(IBAction)createTest2:(id)sender;

@end
