//
// NewAreaCreation.h
// CellMovieQuant
//
// Created by Masahiko Sato on 01/09/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef NEWAREACREATION_H
#define NEWAREACREATION_H
#import "LineSet.h" 
#endif

@interface NewAreaCreation : NSObject {
}

-(void)newAreaLine;
-(void)positionRevSelectedUpDate;
-(void)gravityCenterRevUpDate;
-(void)timeSelectedUpDate;

@end
