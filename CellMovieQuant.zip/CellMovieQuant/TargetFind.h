//
// TargetFind.h
// CellMovieQuant
//
// Created by Masahiko Sato on 01/09/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef TARGETFIND_H
#define TARGETFIND_H
#import "Controller.h"
#endif

@interface TargetFind : NSObject {
}

-(void)interpretationFirst;

@end
