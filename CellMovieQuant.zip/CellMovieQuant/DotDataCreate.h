//
//  DotDataCreate.h
//  CellMovieQuant
//
//  Created by Masahiko Sato on 2020-01-15.
//

#ifndef DOTDATACREATE_H
#define DOTDATACREATE_H
#import "Controller.h" 
#endif

@interface DotDataCreate : NSObject {
    id subProcesses;
    id tiffFileRead;
}

-(void)arrayDotDataHoldUpDate;

-(IBAction)dotCreateRef1:(id)sender;
-(IBAction)dotCreateRef2:(id)sender;
-(IBAction)removeInside:(id)sender;
-(IBAction)removeOutside:(id)sender;

-(IBAction)dotImport:(id)sender;
-(IBAction)dotExport:(id)sender;
-(IBAction)dotExportRangeSet:(id)sender;

@end
