//
//  Merge.m
//  CellMovieQuant
//
//  Created by Masahiko Sato on 2015-01-12.
//
//

#import "Merge.h"

@implementation Merge

-(void)mergeMain:(int)groupNoMerge :(int)numberOfEntry{
    int *groupNoHold = new int [numberOfEntry+5];
    int groupNoHoldCount = 0;
    
    for (int counter1 = 1; counter1 < groupNumberListCount; counter1++){
        if (groupNumberList [counter1] == groupNoMerge || groupNumberList [counter1] == groupNoMerge*-1) groupNoHold [groupNoHoldCount] = counter1, groupNoHoldCount++;
    }
    
    //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
    //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
    //	cout<<" arrayPositionRevise "<<counterA<<endl;
    //}
    
    int maxPointDimX = 0;
    int maxPointDimY = 0;
    int minPointDimX = 1000000;
    int minPointDimY = 1000000;
    int connectFind = 0;
    
    for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
        connectFind = 0;
        
        for (int counter2 = 0; counter2 < groupNoHoldCount; counter2++){
            if (groupNoHold [counter2] == arrayTimeSelected [counter1*10+8]){
                connectFind = 1;
                break;
            }
        }
        
        if (connectFind == 1){
            for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 < positionReviseCount/7; counter2++){
                if (arrayPositionRevise [counter2*7+3] == arrayTimeSelected [counter1*10+8]){
                    if (maxPointDimX < arrayPositionRevise [counter2*7]) maxPointDimX = arrayPositionRevise [counter2*7];
                    if (minPointDimX > arrayPositionRevise [counter2*7]) minPointDimX = arrayPositionRevise [counter2*7];
                    if (maxPointDimY < arrayPositionRevise [counter2*7+1]) maxPointDimY = arrayPositionRevise [counter2*7+1];
                    if (minPointDimY > arrayPositionRevise [counter2*7+1]) minPointDimY = arrayPositionRevise [counter2*7+1];
                }
                else{
                    
                    break;
                }
            }
        }
    }
    
    int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
    int verticalLength = (maxPointDimY-minPointDimY)/2*2;
    int dimension = 0;
    
    if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
    if (horizontalLength < verticalLength) dimension = verticalLength+30;
    
    dimension = (dimension/2)*2;
    
    int horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
    int verticalStart = minPointDimY-(dimension-verticalLength)/2;
    
    int **connectivityMapTemp = new int *[dimension+1];
    for (int counter1 = 0; counter1 < dimension+1; counter1++) connectivityMapTemp [counter1] = new int [dimension+1];
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = 0;
    }
    
    int startY = 0;
    int endY = 0;
    int startX = 0;
    int endX = 0;
    
    if (minPointDimY-30 >= 0) startY = minPointDimY-30;
    else startY = 0;
    
    if (maxPointDimY+30 < imageXYLength) endY = maxPointDimY+31;
    else endY = imageXYLength;
    
    if (minPointDimX-30 >= 0) startX = minPointDimX-30;
    else startX = 0;
    
    if (maxPointDimX+30 < imageXYLength) endX = maxPointDimX+31;
    else endX = imageXYLength;
    
    for (int counterY = startY; counterY < endY; counterY++){
        for (int counterX = startX; counterX < endX; counterX++){
            connectFind = 0;
            
            for (int counter1 = 0; counter1 < groupNoHoldCount; counter1++){
                if (groupNoHold [counter1] == revisedWorkingMap [counterY][counterX]){
                    connectFind = 1;
                    break;
                }
            }
            
            if (connectFind == 1){
                if (counterY-verticalStart > 0 && counterY-verticalStart < dimension && counterX-horizontalStart > 0 && counterX-horizontalStart < dimension)
                    connectivityMapTemp [counterY-verticalStart][counterX-horizontalStart] = 1;
            }
        }
    }
    
    //for (int counterA = 0; counterA < dimension; counterA++){
    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
    //	cout<<" connectivityMapTemp "<<counterA<<endl;
    //}
    
    //------Connectivity analysis, For Zero------
    int *connectAnalysisX = new int [dimension*4];
    int *connectAnalysisY = new int [dimension*4];
    int *connectAnalysisTempX = new int [dimension*4];
    int *connectAnalysisTempY = new int [dimension*4];
    
    int connectivityNumber = -3;
    int connectAnalysisCount = 0;
    int terminationFlag = 0;
    int connectAnalysisTempCount = 0;
    int xSource = 0;
    int ySource = 0;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (connectivityMapTemp [counterY][counterX] == 0){
                connectivityNumber = connectivityNumber+2;
                connectivityMapTemp [counterY][counterX] = connectivityNumber;
                
                connectAnalysisCount = 0;
                
                if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == 0){
                    connectivityMapTemp [counterY-1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterX+1 < dimension && connectivityMapTemp [counterY][counterX+1] == 0){
                    connectivityMapTemp [counterY][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                if (counterY+1 < dimension && connectivityMapTemp [counterY+1][counterX] == 0){
                    connectivityMapTemp [counterY+1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == 0){
                    connectivityMapTemp [counterY][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                
                if (connectAnalysisCount != 0){
                    do{
                        
                        terminationFlag = 1;
                        connectAnalysisTempCount = 0;
                        
                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                            xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                            
                            if (ySource-1 >= 0 && connectivityMapTemp [ySource-1][xSource] == 0){
                                connectivityMapTemp [ySource-1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (xSource+1 < dimension && connectivityMapTemp [ySource][xSource+1] == 0){
                                connectivityMapTemp [ySource][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < dimension && connectivityMapTemp [ySource+1][xSource] == 0){
                                connectivityMapTemp [ySource+1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (xSource-1 >= 0 && connectivityMapTemp [ySource][xSource-1] == 0){
                                connectivityMapTemp [ySource][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                        }
                        
                        connectAnalysisCount = connectAnalysisTempCount;
                        
                        if (connectAnalysisCount == 0) terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                }
            }
        }
    }
    
    //for (int counterA = 0; counterA < dimension; counterA++){
    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
    //	cout<<" connectivityMapTemp "<<counterA<<endl;
    //}
    
    //------Remove connectivity groups, which attach edge, extract inner part of Linked Line------
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (connectivityMapTemp [counterY][counterX] == -1) connectivityMapTemp [counterY][counterX] = 0;
        }
    }
    
    //for (int counterA = 0; counterA < dimension; counterA++){
    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
    // 	cout<<" connectivityMapTemp "<<counterA<<endl;
    // }
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (connectivityMapTemp [counterY][counterX] != 0){
                if (counterX+1 < dimension && connectivityMapTemp [counterY][counterX+1] == 0) connectivityMapTemp [counterY][counterX] = -1;
                else if (counterY+1 < dimension && connectivityMapTemp [counterY+1][counterX] == 0) connectivityMapTemp [counterY][counterX] = -1;
                else if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == 0) connectivityMapTemp [counterY][counterX] = -1;
                else if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == 0) connectivityMapTemp [counterY][counterX] = -1;
            }
        }
    }
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (connectivityMapTemp [counterY][counterX] > 0) connectivityMapTemp [counterY][counterX] = 0;
            if (connectivityMapTemp [counterY][counterX] < 0) connectivityMapTemp [counterY][counterX] = 1;
        }
    }
    
    connectivityNumber = 0;
    
    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
            if (connectivityMapTemp [counterY2][counterX2] == 0){
                connectivityNumber--;
                connectAnalysisCount = 0;
                
                connectivityMapTemp [counterY2][counterX2] = connectivityNumber;
                
                if (counterY2-1 >= 0 && connectivityMapTemp [counterY2-1][counterX2] == 0){
                    connectivityMapTemp [counterY2-1][counterX2] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                }
                if (counterX2+1 < dimension && connectivityMapTemp [counterY2][counterX2+1] == 0){
                    connectivityMapTemp [counterY2][counterX2+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                }
                if (counterY2+1 < dimension && connectivityMapTemp [counterY2+1][counterX2] == 0){
                    connectivityMapTemp [counterY2+1][counterX2] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                }
                if (counterX2-1 >= 0 && connectivityMapTemp [counterY2][counterX2-1] == 0){
                    connectivityMapTemp [counterY2][counterX2-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                }
                
                if (connectAnalysisCount != 0){
                    do{
                        
                        terminationFlag = 1;
                        connectAnalysisTempCount = 0;
                        
                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                            xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                            
                            if (ySource-1 >= 0 && connectivityMapTemp [ySource-1][xSource] == 0){
                                connectivityMapTemp [ySource-1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (xSource+1 < dimension && connectivityMapTemp [ySource][xSource+1] == 0){
                                connectivityMapTemp [ySource][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < dimension && connectivityMapTemp [ySource+1][xSource] == 0){
                                connectivityMapTemp [ySource+1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (xSource-1 >= 0 && connectivityMapTemp [ySource][xSource-1] == 0){
                                connectivityMapTemp [ySource][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                        }
                        
                        connectAnalysisCount = connectAnalysisTempCount;
                        
                        if (connectAnalysisCount == 0) terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                }
            }
        }
    }
    
    delete [] connectAnalysisX;
    delete [] connectAnalysisY;
    delete [] connectAnalysisTempX;
    delete [] connectAnalysisTempY;
    
    //for (int counterA = 0; counterA < dimension; counterA++){
    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
    //	cout<<" connectivityMapTemp "<<counterA<<endl;
    //}
    
    //------Determine number of pixels------
    connectivityNumber = connectivityNumber*-1;
    
    int *connectedPix = new int [connectivityNumber+50];
    for (int counter1 = 0; counter1 <= connectivityNumber; counter1++) connectedPix [counter1] = 0;
    
    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
            if (connectivityMapTemp [counterY2][counterX2] < -1){
                connectedPix [connectivityMapTemp [counterY2][counterX2]*-1]++;
            }
        }
    }
    
    int **newConnectivityMapTemp = new int *[dimension+4];
    for (int counter1 = 0; counter1 < dimension+4; counter1++) newConnectivityMapTemp [counter1] = new int [dimension+4];
    
    for (int counterY = 0; counterY < dimension+4; counterY++){
        for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
    }
    
    int largestConnect = 0;
    int largestConnectNo = 0;
    
    for (int counter1 = 2; counter1 <= connectivityNumber; counter1++){
        if (connectedPix [counter1] > largestConnect){
            largestConnect = connectedPix [counter1];
            largestConnectNo = counter1;
        }
    }
    
    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
            if (connectivityMapTemp [counterY2][counterX2] == largestConnectNo*-1){
                if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityMapTemp [counterY2-1][counterX2-1] == 1){
                    newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                    connectivityMapTemp [counterY2-1][counterX2-1] = 0;
                }
                if (counterY2-1 >= 0 && connectivityMapTemp [counterY2-1][counterX2] == 1){
                    newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                    connectivityMapTemp [counterY2-1][counterX2] = 0;
                }
                if (counterY2-1 >= 0 && counterX2+1 < dimension && connectivityMapTemp [counterY2-1][counterX2+1] == 1){
                    newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                    connectivityMapTemp [counterY2-1][counterX2+1] = 0;
                }
                if (counterX2+1 < dimension && connectivityMapTemp [counterY2][counterX2+1] == 1){
                    newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                    connectivityMapTemp [counterY2][counterX2+1] = 0;
                }
                if (counterY2+1 < dimension && counterX2+1 < dimension && connectivityMapTemp [counterY2+1][counterX2+1] == 1){
                    newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                    connectivityMapTemp [counterY2+1][counterX2+1] = 0;
                }
                if (counterY2+1 < dimension && connectivityMapTemp [counterY2+1][counterX2] == 1){
                    newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                    connectivityMapTemp [counterY2+1][counterX2] = 0;
                }
                if (counterY2+1 < dimension && counterX2-1 >= 0 && connectivityMapTemp [counterY2+1][counterX2-1] == 1){
                    newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                    connectivityMapTemp [counterY2+1][counterX2-1] = 0;
                }
                if (counterX2-1 >= 0 && connectivityMapTemp [counterY2][counterX2-1] == 1){
                    newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                    connectivityMapTemp [counterY2][counterX2-1] = 0;
                }
            }
        }
    }
    
    delete [] connectedPix;
    
    int xPositionTempStart = 0;
    int yPositionTempStart = 0;
    int lineSize = 0;
    
    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
            if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                connectivityMapTemp [counterY2][counterX2] = 1;
                
                xPositionTempStart = counterX2;
                yPositionTempStart = counterY2;
                lineSize++;
            }
            else connectivityMapTemp [counterY2][counterX2] = 0;
        }
    }
    
    for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] newConnectivityMapTemp [counter1];
    delete [] newConnectivityMapTemp;
    
    int constructedLineCount = 0;
    int findFlag = 0;
    
    int *arrayNewLines = new int [lineSize*2+50];
    
    connectivityMapTemp [yPositionTempStart][xPositionTempStart] = -1;
    arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
    arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
    
    do{
        
        findFlag = 0;
        terminationFlag = 0;
        
        if (xPositionTempStart+1 < dimension){
            if (connectivityMapTemp [yPositionTempStart][xPositionTempStart+1] == 1){
                connectivityMapTemp [yPositionTempStart][xPositionTempStart+1] = -1;
                arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
            }
        }
        
        if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
            if (connectivityMapTemp [yPositionTempStart+1][xPositionTempStart+1] == 1){
                connectivityMapTemp [yPositionTempStart+1][xPositionTempStart+1] = -1;
                arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
            }
        }
        
        if (yPositionTempStart+1 < dimension && findFlag == 0){
            if (connectivityMapTemp [yPositionTempStart+1][xPositionTempStart] == 1){
                connectivityMapTemp [yPositionTempStart+1][xPositionTempStart] = -1;
                arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
            }
        }
        
        if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
            if (connectivityMapTemp [yPositionTempStart+1][xPositionTempStart-1] == 1){
                connectivityMapTemp [yPositionTempStart+1][xPositionTempStart-1] = -1;
                arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
            }
        }
        
        if (xPositionTempStart-1 >= 0 && findFlag == 0){
            if (connectivityMapTemp [yPositionTempStart][xPositionTempStart-1] == 1){
                connectivityMapTemp [yPositionTempStart][xPositionTempStart-1] = -1;
                arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
            }
        }
        
        if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
            if (connectivityMapTemp [yPositionTempStart-1][xPositionTempStart-1] == 1){
                connectivityMapTemp [yPositionTempStart-1][xPositionTempStart-1] = -1;
                arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
            }
        }
        
        if (yPositionTempStart-1 >= 0 && findFlag == 0){
            if (connectivityMapTemp [yPositionTempStart-1][xPositionTempStart] == 1){
                connectivityMapTemp [yPositionTempStart-1][xPositionTempStart] = -1;
                arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
            }
        }
        
        if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
            if (connectivityMapTemp [yPositionTempStart-1][xPositionTempStart+1] == 1){
                connectivityMapTemp [yPositionTempStart-1][xPositionTempStart+1] = -1;
                arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
            }
        }
        
    } while (terminationFlag == 1);
    
    delete [] groupNoHold;
    
    for (int counter1 = 0; counter1 < dimension+1; counter1++) delete [] connectivityMapTemp [counter1];
    delete [] connectivityMapTemp;
    
    referenceLineCount = 0;
    
    for (int counter1 = 0; counter1 < constructedLineCount/2; counter1++){
        if (referenceLineCount+2 > referenceLineLimit) [self referenceLineCountUpDate];
        
        arrayReferenceLine [referenceLineCount] = arrayNewLines [counter1*2], referenceLineCount++;
        arrayReferenceLine [referenceLineCount] = arrayNewLines [counter1*2+1], referenceLineCount++;
    }
    
    delete [] arrayNewLines;
}

-(void)mergeConnect{
    int maxPointDimX = 0;
    int maxPointDimY = 0;
    int minPointDimX = 1000000;
    int minPointDimY = 1000000;
    
    for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
        if (arrayTimeSelected [counter1*10+8] == currentConnectNo){
            for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 < positionReviseCount/7; counter2++){
                if (arrayPositionRevise [counter2*7+3] == currentConnectNo){
                    if (maxPointDimX < arrayPositionRevise [counter2*7]) maxPointDimX = arrayPositionRevise [counter2*7];
                    if (minPointDimX > arrayPositionRevise [counter2*7]) minPointDimX = arrayPositionRevise [counter2*7];
                    if (maxPointDimY < arrayPositionRevise [counter2*7+1]) maxPointDimY = arrayPositionRevise [counter2*7+1];
                    if (minPointDimY > arrayPositionRevise [counter2*7+1]) minPointDimY = arrayPositionRevise [counter2*7+1];
                }
                else{
                    
                    break;
                }
            }
        }
    }
    
    int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
    int verticalLength = (maxPointDimY-minPointDimY)/2*2;
    int dimension = 0;
    
    if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
    if (horizontalLength < verticalLength) dimension = verticalLength+30;
    
    dimension = (dimension/2)*2;
    
    int horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
    int verticalStart = minPointDimY-(dimension-verticalLength)/2;
    
    int startY = 0;
    int endY = 0;
    int startX = 0;
    int endX = 0;
    
    int **rangeMatrix = new int *[dimension+4];
    
    for (int counter1 = 0; counter1 < dimension+4; counter1++){
        rangeMatrix [counter1] = new int [dimension+4];
    }
    
    int *connectAnalysisX = new int [dimension*4];
    int *connectAnalysisY = new int [dimension*4];
    int *connectAnalysisTempX = new int [dimension*4];
    int *connectAnalysisTempY = new int [dimension*4];
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageXYLength && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageXYLength){
                rangeMatrix [counterY][counterX] = -150;
            }
            else rangeMatrix [counterY][counterX] = 0;
        }
    }
    
    int connectivityNumber = 0;
    int connectAnalysisCount = 0;
    int terminationFlag = 0;
    int connectAnalysisTempCount = 0;
    int xSource = 0;
    int ySource = 0;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (rangeMatrix [counterY][counterX] == -150){
                connectivityNumber++;
                rangeMatrix [counterY][counterX] = connectivityNumber;
                connectAnalysisCount = 0;
                
                if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrix [counterY-1][counterX-1] == -150){
                    rangeMatrix [counterY-1][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterY-1 >= 0 && rangeMatrix [counterY-1][counterX] == -150){
                    rangeMatrix [counterY-1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterY-1 >= 0 && counterX+1 < dimension && rangeMatrix [counterY-1][counterX+1] == -150){
                    rangeMatrix [counterY-1][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterX+1 < dimension && rangeMatrix [counterY][counterX+1] == -150){
                    rangeMatrix [counterY][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                if (counterY+1 < dimension && counterX+1 < dimension && rangeMatrix [counterY+1][counterX+1] == -150){
                    rangeMatrix [counterY+1][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterY+1 < dimension && rangeMatrix [counterY+1][counterX] == -150){
                    rangeMatrix [counterY+1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterY+1 < dimension && counterX-1 >= 0 && rangeMatrix [counterY+1][counterX-1] == -150){
                    rangeMatrix [counterY+1][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterX-1 >= 0 && rangeMatrix [counterY][counterX-1] == -150){
                    rangeMatrix [counterY][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                
                if (connectAnalysisCount != 0){
                    do{
                        
                        terminationFlag = 1;
                        connectAnalysisTempCount = 0;
                        
                        for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                            xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                            
                            if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrix [ySource-1][xSource-1] == -150){
                                rangeMatrix [ySource-1][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (ySource-1 >= 0 && rangeMatrix [ySource-1][xSource] == -150){
                                rangeMatrix [ySource-1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (ySource-1 >= 0 && xSource+1 < dimension && rangeMatrix [ySource-1][xSource+1] == -150){
                                rangeMatrix [ySource-1][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (xSource+1 < dimension && rangeMatrix [ySource][xSource+1] == -150){
                                rangeMatrix [ySource][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                            if (ySource+1 > dimension && xSource+1 < dimension && rangeMatrix [ySource+1][xSource+1] == -150){
                                rangeMatrix [ySource+1][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < dimension && rangeMatrix [ySource+1][xSource] == -150){
                                rangeMatrix [ySource+1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < dimension && xSource-1 >= 0 && rangeMatrix [ySource+1][xSource-1] == -150){
                                rangeMatrix [ySource+1][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (xSource-1 >= 0 && rangeMatrix [ySource][xSource-1] == -150){
                                rangeMatrix [ySource][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                            connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                        }
                        
                        connectAnalysisCount = connectAnalysisTempCount;
                        
                        if (connectAnalysisCount == 0) terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                }
            }
        }
    }
    
    //------Determine number of pixels------
    int *connectedPix = new int [connectivityNumber+50];
    for (int counter2 = 0; counter2 <= connectivityNumber; counter2++) connectedPix [counter2] = 0;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (rangeMatrix [counterY][counterX] != 0) connectedPix [rangeMatrix [counterY][counterX]]++;
        }
    }
    
    //------Map up-date------
    int connectTemp = 1;
    
    for (int counter2 = 1; counter2 <= connectivityNumber; counter2++){
        if (connectedPix [counter2] < 10) connectedPix [counter2] = 0;
        else{
            
            connectedPix [counter2] = connectTemp;
            connectTemp++;
        }
    }
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if ((connectTemp = rangeMatrix [counterY][counterX]) != 0) rangeMatrix [counterY][counterX] = connectedPix [connectTemp];
            else rangeMatrix [counterY][counterX] = 0;
        }
    }
    
    delete [] connectedPix;
    
    delete [] connectAnalysisX;
    delete [] connectAnalysisY;
    delete [] connectAnalysisTempX;
    delete [] connectAnalysisTempY;
    
    int maxConnect = 0;
    int maxConnectRevise = 0;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageXYLength && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageXYLength){
                if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] > maxConnectRevise) maxConnectRevise = revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart];
                if (rangeMatrix [counterY][counterX] > maxConnect) maxConnect = rangeMatrix [counterY][counterX];
            }
        }
    }
    
    int *findConnectNo = new int [maxConnect+5];
    for (int counter1 = 0; counter1 < maxConnect+5; counter1++) findConnectNo [counter1] = 0;
    
    int *findReviseConnect = new int [maxConnectRevise+5];
    for (int counter1 = 0; counter1 < maxConnectRevise+5; counter1++) findReviseConnect [counter1] = 0;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageXYLength && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageXYLength){
                if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] == currentConnectNo){
                    if (rangeMatrix [counterY][counterX] != 0) findConnectNo [rangeMatrix [counterY][counterX]]++;
                }
            }
        }
    }
    
    int processConnectNo = 0;
    int processConnectPosition = 0;
    
    for (int counter1 = 1; counter1 < maxConnect+1; counter1++){
        if (findConnectNo [counter1] > processConnectNo){
            processConnectNo = findConnectNo [counter1];
            processConnectPosition = counter1;
        }
    }
    
    referenceLineCount = 0;
    
    if (processConnectPosition != 0){
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageXYLength && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageXYLength){
                    if (rangeMatrix [counterY][counterX] == processConnectPosition && revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] != 0){
                        findReviseConnect [revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart]]++;
                    }
                }
            }
        }
        
        maxPointDimX = 0;
        maxPointDimY = 0;
        minPointDimX = 1000000;
        minPointDimY = 1000000;
        
        int connectFind = 0;
        
        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
            connectFind = 0;
            
            if (maxConnectRevise >= arrayTimeSelected [counter1*10+8] && findReviseConnect [arrayTimeSelected [counter1*10+8]] != 0) connectFind = 1;
            
            if (connectFind == 1){
                for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 < positionReviseCount/7; counter2++){
                    if (arrayPositionRevise [counter2*7+3] == arrayTimeSelected [counter1*10+8]){
                        if (maxPointDimX < arrayPositionRevise [counter2*7]) maxPointDimX = arrayPositionRevise [counter2*7];
                        if (minPointDimX > arrayPositionRevise [counter2*7]) minPointDimX = arrayPositionRevise [counter2*7];
                        if (maxPointDimY < arrayPositionRevise [counter2*7+1]) maxPointDimY = arrayPositionRevise [counter2*7+1];
                        if (minPointDimY > arrayPositionRevise [counter2*7+1]) minPointDimY = arrayPositionRevise [counter2*7+1];
                    }
                    else{
                        
                        break;
                    }
                }
            }
        }
        
        horizontalLength = (maxPointDimX-minPointDimX)/2*2;
        verticalLength = (maxPointDimY-minPointDimY)/2*2;
        int dimension2 = 0;
        
        if (horizontalLength >= verticalLength) dimension2 = horizontalLength+30;
        if (horizontalLength < verticalLength) dimension2 = verticalLength+30;
        
        dimension2 = (dimension2/2)*2;
        
        horizontalStart = minPointDimX-(dimension2-horizontalLength)/2;
        verticalStart = minPointDimY-(dimension2-verticalLength)/2;
        
        int **connectivityMapTemp = new int *[dimension2+1];
        int **connectivityMapTemp2 = new int *[dimension2+1];
        
        for (int counter1 = 0; counter1 < dimension2+1; counter1++){
            connectivityMapTemp [counter1] = new int [dimension2+1];
            connectivityMapTemp2 [counter1] = new int [dimension2+1];
        }
        
        for (int counterY = 0; counterY < dimension2; counterY++){
            for (int counterX = 0; counterX < dimension2; counterX++){
                connectivityMapTemp [counterY][counterX] = 0;
                connectivityMapTemp2 [counterY][counterX] = 0;
            }
        }
        
        if (minPointDimY-30 >= 0) startY = minPointDimY-30;
        else startY = 0;
        
        if (maxPointDimY+30 < imageXYLength) endY = maxPointDimY+31;
        else endY = imageXYLength;
        
        if (minPointDimX-30 >= 0) startX = minPointDimX-30;
        else startX = 0;
        
        if (maxPointDimX+30 < imageXYLength) endX = maxPointDimX+31;
        else endX = imageXYLength;
        
        for (int counterY = startY; counterY < endY; counterY++){
            for (int counterX = startX; counterX < endX; counterX++){
                connectFind = 0;
                
                if (revisedWorkingMap [counterY][counterX] < maxConnectRevise+5 && findReviseConnect [revisedWorkingMap [counterY][counterX]] != 0) connectFind = 1;
                
                if (connectFind == 1){
                    if (counterY-verticalStart > 0 && counterY-verticalStart < dimension2 && counterX-horizontalStart > 0 && counterX-horizontalStart < dimension2) connectivityMapTemp [counterY-verticalStart][counterX-horizontalStart] = 1;
                }
                
                if (connectFind == 1 && revisedWorkingMap [counterY][counterX] == currentConnectNo){
                    if (counterY-verticalStart > 0 && counterY-verticalStart < dimension2 && counterX-horizontalStart > 0 && counterX-horizontalStart < dimension2) connectivityMapTemp2 [counterY-verticalStart][counterX-horizontalStart] = 2;
                }
            }
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
        //	cout<<" connectivityMapTemp "<<counterA<<endl;
        //}
        
        //------Connectivity analysis, For Zero------
        connectAnalysisX = new int [dimension2*4];
        connectAnalysisY = new int [dimension2*4];
        connectAnalysisTempX = new int [dimension2*4];
        connectAnalysisTempY = new int [dimension2*4];
        
        connectivityNumber = -3;
        
        for (int counterY = 0; counterY < dimension2; counterY++){
            for (int counterX = 0; counterX < dimension2; counterX++){
                if (connectivityMapTemp [counterY][counterX] == 0){
                    connectivityNumber = connectivityNumber+2;
                    connectivityMapTemp [counterY][counterX] = connectivityNumber;
                    
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == 0){
                        connectivityMapTemp [counterY-1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension2 && connectivityMapTemp [counterY][counterX+1] == 0){
                        connectivityMapTemp [counterY][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension2 && connectivityMapTemp [counterY+1][counterX] == 0){
                        connectivityMapTemp [counterY+1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == 0){
                        connectivityMapTemp [counterY][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && connectivityMapTemp [ySource-1][xSource] == 0){
                                    connectivityMapTemp [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension2 && connectivityMapTemp [ySource][xSource+1] == 0){
                                    connectivityMapTemp [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension2 && connectivityMapTemp [ySource+1][xSource] == 0){
                                    connectivityMapTemp [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && connectivityMapTemp [ySource][xSource-1] == 0){
                                    connectivityMapTemp [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //------Remove connectivity groups, which attach edge, extract inner part of Linked Line------
        for (int counterY = 0; counterY < dimension2; counterY++){
            for (int counterX = 0; counterX < dimension2; counterX++){
                if (connectivityMapTemp [counterY][counterX] == -1) connectivityMapTemp [counterY][counterX] = 0;
                else connectivityMapTemp [counterY][counterX] = -1;
            }
        }
        
        connectivityNumber = 0;
        
        for (int counterY = 0; counterY < dimension2; counterY++){
            for (int counterX = 0; counterX < dimension2; counterX++){
                if (connectivityMapTemp [counterY][counterX] < 0){
                    connectivityNumber++;
                    connectivityMapTemp [counterY][counterX] = connectivityNumber;
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMapTemp [counterY-1][counterX-1] < 0){
                        connectivityMapTemp [counterY-1][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] < 0){
                        connectivityMapTemp [counterY-1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && counterX+1 < dimension2 && connectivityMapTemp [counterY-1][counterX+1] < 0){
                        connectivityMapTemp [counterY-1][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension2 && connectivityMapTemp [counterY][counterX+1] < 0){
                        connectivityMapTemp [counterY][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension2 && counterX+1 < dimension2 && connectivityMapTemp [counterY+1][counterX+1] < 0){
                        connectivityMapTemp [counterY+1][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension2 && connectivityMapTemp [counterY+1][counterX] < 0){
                        connectivityMapTemp [counterY+1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension2 && counterX-1 >= 0 && connectivityMapTemp [counterY+1][counterX-1] < 0){
                        connectivityMapTemp [counterY+1][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] < 0){
                        connectivityMapTemp [counterY][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && xSource-1 >= 0 && connectivityMapTemp [ySource-1][xSource-1] < 0){
                                    connectivityMapTemp [ySource-1][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && connectivityMapTemp [ySource-1][xSource] < 0){
                                    connectivityMapTemp [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && xSource+1 < dimension2 && connectivityMapTemp [ySource-1][xSource+1] < 0){
                                    connectivityMapTemp [ySource-1][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension2 && connectivityMapTemp [ySource][xSource+1] < 0){
                                    connectivityMapTemp [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 > dimension2 && xSource+1 < dimension2 && connectivityMapTemp [ySource+1][xSource+1] < 0){
                                    connectivityMapTemp [ySource+1][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension2 && connectivityMapTemp [ySource+1][xSource] < 0){
                                    connectivityMapTemp [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension2 && xSource-1 >= 0 && connectivityMapTemp [ySource+1][xSource-1] < 0){
                                    connectivityMapTemp [ySource+1][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && connectivityMapTemp [ySource][xSource-1] < 0){
                                    connectivityMapTemp [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        int *connectNoList = new int [connectivityNumber+2];
        for (int counter1 = 0; counter1 < connectivityNumber+2; counter1++) connectNoList [counter1] = 0;
        
        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
            if (arrayTimeSelected [counter1*10+8] == currentConnectNo){
                for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 < positionReviseCount/7; counter2++){
                    if (arrayPositionRevise [counter2*7+3] == currentConnectNo){
                        if (connectivityMapTemp [arrayPositionRevise [counter2*7+1]-verticalStart][arrayPositionRevise [counter2*7]-horizontalStart] != 0) connectNoList [connectivityMapTemp [arrayPositionRevise [counter2*7+1]-verticalStart][arrayPositionRevise [counter2*7]-horizontalStart]]++;
                    }
                    else{
                        
                        break;
                    }
                }
            }
        }
        
        int largestSelect = 0;
        int largestSelectNo = 0;
        
        for (int counter1 = 1; counter1 <= connectivityNumber; counter1++){
            if (connectNoList [counter1] > largestSelect){
                largestSelect = connectNoList [counter1];
                largestSelectNo = counter1;
            }
        }
        
        for (int counterY = 0; counterY < dimension2; counterY++){
            for (int counterX = 0; counterX < dimension2; counterX++){
                if (connectivityMapTemp [counterY][counterX] != 0){
                    for (int counter1 = 1; counter1 <= connectivityNumber; counter1++){
                        if (connectivityMapTemp [counterY][counterX] != largestSelectNo) connectivityMapTemp [counterY][counterX] = 0;
                    }
                }
            }
        }
        
        delete [] connectNoList;
        
        //-------Zero Fill-------
        int **connectivityUpdate5 = new int *[dimension2+4];
        
        for (int counter1 = 0; counter1 < dimension2+4; counter1++){
            connectivityUpdate5 [counter1] = new int [dimension2+4];
        }
        
        for (int counterX = 0; counterX < dimension2+4; counterX++){
            for (int counterY = 0; counterY < dimension2+4; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
        }
        
        for (int counterY = 0; counterY < dimension2; counterY++){
            for (int counterX = 0; counterX < dimension2; counterX++) connectivityUpdate5 [counterY+1][counterX+1] = connectivityMapTemp [counterY][counterX];
        }
        
        connectivityNumber = 0;
        
        for (int counterY2 = 0; counterY2 < dimension2+2; counterY2++){
            for (int counterX2 = 0; counterX2 < dimension2+2; counterX2++){
                if (connectivityUpdate5 [counterY2][counterX2] == 0){
                    connectivityNumber--;
                    connectAnalysisCount = 0;
                    
                    connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                    
                    if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                        connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                    }
                    if (counterX2+1 < dimension2+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                        connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                    }
                    if (counterY2+1 < dimension2+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                        connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                    }
                    if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                        connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                    connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension2+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                    connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension2+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                    connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                    connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        int connectTemp2 = 0;
        
        if (connectivityNumber < -1){
            int *connectCheckArray = new int [connectivityNumber*-1*2+5];
            
            for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
            
            for (int counterY2 = 0; counterY2 < dimension2+2; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension2+2; counterX2++){
                    connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                    
                    if (connectTemp2 < -1){
                        connectTemp2 = connectTemp2*-1;
                        
                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2-1 >= 0 && counterX2+1 < dimension2+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterX2+1 < dimension2+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2+1 < dimension2+2 && counterX2+1 < dimension2+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2+1 < dimension2+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2+1 < dimension2+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                    }
                }
            }
            
            int zeroFillFlag = 0;
            
            for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
            }
            
            //for (int counterA = 1; counterA <= connectivityNumber*-1; counterA++){
            //    cout<<counterA<<" "<<connectCheckArray [counterA*2]<<" "<<connectCheckArray [counterA*2+1]<<" connectCheckArray"<<endl;
            //}
            
            //for (int counterA = 0; counterA < dimension2+2; counterA++){
            //    for (int counterB = 0; counterB < dimension2+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
            //    cout<<" connectivityUpdate5 "<<counterA<<endl;
            //}
            
            if (zeroFillFlag == 1){
                for (int counterY2 = 0; counterY2 < dimension2+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension2+2; counterX2++){
                        connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                        
                        if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                    }
                }
                
                for (int counterY2 = 0; counterY2 < dimension2+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension2+2; counterX2++){
                        if (connectivityUpdate5 [counterY2][counterX2] > 0){
                            connectivityMapTemp [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                        }
                    }
                }
            }
            
            delete [] connectCheckArray;
        }
        
        for (int counter1 = 0; counter1 < dimension2+4; counter1++) delete [] connectivityUpdate5 [counter1];
        
        delete [] connectivityUpdate5;
        //---------
        
        for (int counterY = 0; counterY < dimension2; counterY++){
            for (int counterX = 0; counterX < dimension2; counterX++){
                if (connectivityMapTemp [counterY][counterX] != 0){
                    if (counterX+1 < dimension2 && connectivityMapTemp [counterY][counterX+1] == 0) connectivityMapTemp [counterY][counterX] = -1;
                    else if (counterY+1 < dimension2 && connectivityMapTemp [counterY+1][counterX] == 0) connectivityMapTemp [counterY][counterX] = -1;
                    else if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == 0) connectivityMapTemp [counterY][counterX] = -1;
                    else if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == 0) connectivityMapTemp [counterY][counterX] = -1;
                }
            }
        }
        
        for (int counterY = 0; counterY < dimension2; counterY++){
            for (int counterX = 0; counterX < dimension2; counterX++){
                if (connectivityMapTemp [counterY][counterX] > 0) connectivityMapTemp [counterY][counterX] = 0;
                if (connectivityMapTemp [counterY][counterX] < 0) connectivityMapTemp [counterY][counterX] = 1;
            }
        }
        
        connectivityNumber = 0;
        
        for (int counterY2 = 0; counterY2 < dimension2; counterY2++){
            for (int counterX2 = 0; counterX2 < dimension2; counterX2++){
                if (connectivityMapTemp [counterY2][counterX2] == 0){
                    connectivityNumber--;
                    connectAnalysisCount = 0;
                    
                    connectivityMapTemp [counterY2][counterX2] = connectivityNumber;
                    
                    if (counterY2-1 >= 0 && connectivityMapTemp [counterY2-1][counterX2] == 0){
                        connectivityMapTemp [counterY2-1][counterX2] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                    }
                    if (counterX2+1 < dimension2 && connectivityMapTemp [counterY2][counterX2+1] == 0){
                        connectivityMapTemp [counterY2][counterX2+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                    }
                    if (counterY2+1 < dimension2 && connectivityMapTemp [counterY2+1][counterX2] == 0){
                        connectivityMapTemp [counterY2+1][counterX2] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                    }
                    if (counterX2-1 >= 0 && connectivityMapTemp [counterY2][counterX2-1] == 0){
                        connectivityMapTemp [counterY2][counterX2-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && connectivityMapTemp [ySource-1][xSource] == 0){
                                    connectivityMapTemp [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension2 && connectivityMapTemp [ySource][xSource+1] == 0){
                                    connectivityMapTemp [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension2 && connectivityMapTemp [ySource+1][xSource] == 0){
                                    connectivityMapTemp [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && connectivityMapTemp [ySource][xSource-1] == 0){
                                    connectivityMapTemp [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        delete [] connectAnalysisX;
        delete [] connectAnalysisY;
        delete [] connectAnalysisTempX;
        delete [] connectAnalysisTempY;
        
        //for (int counterA = 0; counterA < dimension2; counterA++){
        //	for (int counterB = 0; counterB < dimension2; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
        //	cout<<" connectivityMapTemp "<<counterA<<endl;
        //}
        
        //------Determine number of pixels------
        connectivityNumber = connectivityNumber*-1;
        
        connectedPix = new int [connectivityNumber+50];
        for (int counter1 = 0; counter1 <= connectivityNumber; counter1++) connectedPix [counter1] = 0;
        
        for (int counterY2 = 0; counterY2 < dimension2; counterY2++){
            for (int counterX2 = 0; counterX2 < dimension2; counterX2++){
                if (connectivityMapTemp [counterY2][counterX2] < -1 && connectivityMapTemp2 [counterY2][counterX2] != 0){
                    connectedPix [connectivityMapTemp [counterY2][counterX2]*-1]++;
                }
            }
        }
        
        int **newConnectivityMapTemp = new int *[dimension2+4];
        for (int counter1 = 0; counter1 < dimension2+4; counter1++) newConnectivityMapTemp [counter1] = new int [dimension2+4];
        
        for (int counterY = 0; counterY < dimension2+4; counterY++){
            for (int counterX = 0; counterX < dimension2+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
        }
        
        int largestConnect = 0;
        int largestConnectNo = 0;
        
        for (int counter1 = 2; counter1 <= connectivityNumber; counter1++){
            if (connectedPix [counter1] > largestConnect){
                largestConnect = connectedPix [counter1];
                largestConnectNo = counter1;
            }
        }
        
        for (int counterY2 = 0; counterY2 < dimension2; counterY2++){
            for (int counterX2 = 0; counterX2 < dimension2; counterX2++){
                if (connectivityMapTemp [counterY2][counterX2] == largestConnectNo*-1){
                    if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityMapTemp [counterY2-1][counterX2-1] == 1){
                        newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                        connectivityMapTemp [counterY2-1][counterX2-1] = 0;
                    }
                    if (counterY2-1 >= 0 && connectivityMapTemp [counterY2-1][counterX2] == 1){
                        newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                        connectivityMapTemp [counterY2-1][counterX2] = 0;
                    }
                    if (counterY2-1 >= 0 && counterX2+1 < dimension2 && connectivityMapTemp [counterY2-1][counterX2+1] == 1){
                        newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                        connectivityMapTemp [counterY2-1][counterX2+1] = 0;
                    }
                    if (counterX2+1 < dimension2 && connectivityMapTemp [counterY2][counterX2+1] == 1){
                        newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                        connectivityMapTemp [counterY2][counterX2+1] = 0;
                    }
                    if (counterY2+1 < dimension2 && counterX2+1 < dimension2 && connectivityMapTemp [counterY2+1][counterX2+1] == 1){
                        newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                        connectivityMapTemp [counterY2+1][counterX2+1] = 0;
                    }
                    if (counterY2+1 < dimension2 && connectivityMapTemp [counterY2+1][counterX2] == 1){
                        newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                        connectivityMapTemp [counterY2+1][counterX2] = 0;
                    }
                    if (counterY2+1 < dimension2 && counterX2-1 >= 0 && connectivityMapTemp [counterY2+1][counterX2-1] == 1){
                        newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                        connectivityMapTemp [counterY2+1][counterX2-1] = 0;
                    }
                    if (counterX2-1 >= 0 && connectivityMapTemp [counterY2][counterX2-1] == 1){
                        newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                        connectivityMapTemp [counterY2][counterX2-1] = 0;
                    }
                }
            }
        }
        
        delete [] connectedPix;
        
        int xPositionTempStart = 0;
        int yPositionTempStart = 0;
        int lineSize = 0;
        
        for (int counterY2 = 0; counterY2 < dimension2; counterY2++){
            for (int counterX2 = 0; counterX2 < dimension2; counterX2++){
                if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                    connectivityMapTemp [counterY2][counterX2] = 1;
                    xPositionTempStart = counterX2;
                    yPositionTempStart = counterY2;
                    lineSize++;
                }
                else connectivityMapTemp [counterY2][counterX2] = 0;
            }
        }
        
        for (int counter1 = 0; counter1 < dimension2+4; counter1++) delete [] newConnectivityMapTemp [counter1];
        delete [] newConnectivityMapTemp;
        
        int constructedLineCount = 0;
        int findFlag = 0;
        
        int *arrayNewLines = new int [lineSize*2+50];
        
        connectivityMapTemp [yPositionTempStart][xPositionTempStart] = -1;
        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
        
        do{
            
            findFlag = 0;
            terminationFlag = 0;
            
            if (xPositionTempStart+1 < dimension2){
                if (connectivityMapTemp [yPositionTempStart][xPositionTempStart+1] == 1){
                    connectivityMapTemp [yPositionTempStart][xPositionTempStart+1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                }
            }
            if (xPositionTempStart+1 < dimension2 && yPositionTempStart+1 < dimension2 && findFlag == 0){
                if (connectivityMapTemp [yPositionTempStart+1][xPositionTempStart+1] == 1){
                    connectivityMapTemp [yPositionTempStart+1][xPositionTempStart+1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                }
            }
            if (yPositionTempStart+1 < dimension2 && findFlag == 0){
                if (connectivityMapTemp [yPositionTempStart+1][xPositionTempStart] == 1){
                    connectivityMapTemp [yPositionTempStart+1][xPositionTempStart] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                    yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                }
            }
            if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension2 && findFlag == 0){
                if (connectivityMapTemp [yPositionTempStart+1][xPositionTempStart-1] == 1){
                    connectivityMapTemp [yPositionTempStart+1][xPositionTempStart-1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                }
            }
            if (xPositionTempStart-1 >= 0 && findFlag == 0){
                if (connectivityMapTemp [yPositionTempStart][xPositionTempStart-1] == 1){
                    connectivityMapTemp [yPositionTempStart][xPositionTempStart-1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                }
            }
            if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                if (connectivityMapTemp [yPositionTempStart-1][xPositionTempStart-1] == 1){
                    connectivityMapTemp [yPositionTempStart-1][xPositionTempStart-1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                }
            }
            if (yPositionTempStart-1 >= 0 && findFlag == 0){
                if (connectivityMapTemp [yPositionTempStart-1][xPositionTempStart] == 1){
                    connectivityMapTemp [yPositionTempStart-1][xPositionTempStart] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                    yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                }
            }
            if (xPositionTempStart+1 < dimension2 && yPositionTempStart-1 >= 0 && findFlag == 0){
                if (connectivityMapTemp [yPositionTempStart-1][xPositionTempStart+1] == 1){
                    connectivityMapTemp [yPositionTempStart-1][xPositionTempStart+1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                }
            }
            
        } while (terminationFlag == 1);
        
        for (int counter1 = 0; counter1 < dimension2+1; counter1++){
            delete [] connectivityMapTemp [counter1];
            delete [] connectivityMapTemp2 [counter1];
        }
        
        delete [] connectivityMapTemp;
        delete [] connectivityMapTemp2;
        
        for (int counter1 = 0; counter1 < constructedLineCount/2; counter1++){
            if (referenceLineCount+2 > referenceLineLimit) [self referenceLineCountUpDate];
            
            arrayReferenceLine [referenceLineCount] = arrayNewLines [counter1*2], referenceLineCount++;
            arrayReferenceLine [referenceLineCount] = arrayNewLines [counter1*2+1], referenceLineCount++;
        }
        
        delete [] arrayNewLines;
    }
    
    for (int counter2 = 0; counter2 < dimension+4; counter2++){
        delete [] rangeMatrix [counter2];
    }
    
    delete [] rangeMatrix;
    
    delete [] findConnectNo;
    delete [] findReviseConnect;
}

-(int)mergeAttach{
    int mergeResult = 0;
    
    int *connectList = new int [timeSelectedCount/10+10];
    int *connectList2 = new int [timeSelectedCount/10+10];
    int connectListCount2 = 0;
    
    for (int counter1 = 0; counter1 < timeSelectedCount/10+10; counter1++){
        connectList [counter1] = 0;
        connectList2 [counter1] = 0;
    }
    
    int positionX = 0;
    int positionY = 0;
    
    for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
        if (arrayTimeSelected [counter1*10+8] == currentConnectNo){
            for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 < positionReviseCount/7; counter2++){
                if (arrayPositionRevise [counter2*7+3] == currentConnectNo){
                    positionX = arrayPositionRevise [counter2*7];
                    positionY = arrayPositionRevise [counter2*7+1];
                    
                    if (revisedWorkingMap [positionY][positionX] != 0){
                        if (positionY-1 >= 0 && positionX-1 >= 0 && revisedWorkingMap [positionY-1][positionX-1] != 0){
                            connectList [revisedWorkingMap [positionY-1][positionX-1]]++;
                        }
                        if (positionY-1 >= 0 && revisedWorkingMap [positionY-1][positionX] != 0){
                            connectList [revisedWorkingMap [positionY-1][positionX]]++;
                        }
                        if (positionY-1 >= 0 && positionX+1 < imageXYLength && revisedWorkingMap [positionY-1][positionX+1] != 0){
                            connectList [revisedWorkingMap [positionY-1][positionX+1]]++;
                        }
                        if (positionX+1 < imageXYLength && revisedWorkingMap [positionY][positionX+1] != 0) {
                            connectList [revisedWorkingMap [positionY][positionX+1]]++;
                        }
                        if (positionY+1 < imageXYLength && positionX+1 < imageXYLength && revisedWorkingMap [positionY+1][positionX+1] != 0){
                            connectList [revisedWorkingMap [positionY+1][positionX+1]]++;
                        }
                        if (positionY+1 < imageXYLength && revisedWorkingMap [positionY+1][positionX] != 0){
                            connectList [revisedWorkingMap [positionY+1][positionX]]++;
                        }
                        if (positionY+1 < imageXYLength && positionX-1 >= 0 && revisedWorkingMap [positionY+1][positionX-1] != 0){
                            connectList [revisedWorkingMap [positionY+1][positionX-1]]++;
                        }
                        if (positionX-1 >= 0 && revisedWorkingMap [positionY][positionX-1] != 0){
                            connectList [revisedWorkingMap [positionY][positionX-1]]++;
                        }
                    }
                }
                else{
                    
                    break;
                }
            }
        }
    }
    
    connectList [currentConnectNo] = 1;
    
    for (int counter1 = 1; counter1 <= timeSelectedCount/10; counter1++){
        if (connectList [counter1] != 0) connectList2 [connectListCount2] = counter1, connectListCount2++;
    }
    
    if (connectListCount2 > 1){
        int maxPointDimX = 0;
        int maxPointDimY = 0;
        int minPointDimX = 1000000;
        int minPointDimY = 1000000;
        
        int connectFind = 0;
        
        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
            connectFind = 0;
            
            for (int counter2 = 0; counter2 < connectListCount2; counter2++){
                if (connectList2 [counter2] == arrayTimeSelected [counter1*10+8]){
                    connectFind = 1;
                    break;
                }
            }
            
            if (connectFind == 1){
                for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 < positionReviseCount/7; counter2++){
                    if (arrayPositionRevise [counter2*7+3] == arrayTimeSelected [counter1*10+8]){
                        if (maxPointDimX < arrayPositionRevise [counter2*7]) maxPointDimX = arrayPositionRevise [counter2*7];
                        if (minPointDimX > arrayPositionRevise [counter2*7]) minPointDimX = arrayPositionRevise [counter2*7];
                        if (maxPointDimY < arrayPositionRevise [counter2*7+1]) maxPointDimY = arrayPositionRevise [counter2*7+1];
                        if (minPointDimY > arrayPositionRevise [counter2*7+1]) minPointDimY = arrayPositionRevise [counter2*7+1];
                    }
                    else{
                        
                        break;
                    }
                }
            }
        }
        
        int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
        int verticalLength = (maxPointDimY-minPointDimY)/2*2;
        int dimension = 0;
        
        if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
        if (horizontalLength < verticalLength) dimension = verticalLength+30;
        
        dimension = (dimension/2)*2;
        
        int horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
        int verticalStart = minPointDimY-(dimension-verticalLength)/2;
        
        int **connectivityMapTemp = new int *[dimension+1];
        int **connectivityMapTemp2 = new int *[dimension+1];
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++){
            connectivityMapTemp [counter1] = new int [dimension+1];
            connectivityMapTemp2 [counter1] = new int [dimension+1];
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                connectivityMapTemp [counterY][counterX] = 0;
                connectivityMapTemp2 [counterY][counterX] = 0;
            }
        }
        
        int startY = 0;
        int endY = 0;
        int startX = 0;
        int endX = 0;
        
        if (minPointDimY-30 >= 0) startY = minPointDimY-30;
        else startY = 0;
        
        if (maxPointDimY+30 < imageXYLength) endY = maxPointDimY+31;
        else endY = imageXYLength;
        
        if (minPointDimX-30 >= 0) startX = minPointDimX-30;
        else startX = 0;
        
        if (maxPointDimX+30 < imageXYLength) endX = maxPointDimX+31;
        else endX = imageXYLength;
        
        for (int counterY = startY; counterY < endY; counterY++){
            for (int counterX = startX; counterX < endX; counterX++){
                connectFind = 0;
                
                for (int counter1 = 0; counter1 < connectListCount2; counter1++){
                    if (connectList2 [counter1] == revisedWorkingMap [counterY][counterX]){
                        connectFind = 1;
                        break;
                    }
                }
                
                if (connectFind == 1){
                    if (counterY-verticalStart > 0 && counterY-verticalStart < dimension && counterX-horizontalStart > 0 && counterX-horizontalStart < dimension)
                        connectivityMapTemp [counterY-verticalStart][counterX-horizontalStart] = 1;
                }
                
                if (connectFind == 1 && revisedWorkingMap [counterY][counterX] == currentConnectNo){
                    if (counterY-verticalStart > 0 && counterY-verticalStart < dimension && counterX-horizontalStart > 0 && counterX-horizontalStart < dimension) connectivityMapTemp2 [counterY-verticalStart][counterX-horizontalStart] = 2;
                }
            }
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
        //    cout<<" connectivityMapTemp "<<counterA<<endl;
        //}
        
        //------Connectivity analysis, For Zero------
        int *connectAnalysisX = new int [dimension*4];
        int *connectAnalysisY = new int [dimension*4];
        int *connectAnalysisTempX = new int [dimension*4];
        int *connectAnalysisTempY = new int [dimension*4];
        
        int connectivityNumber = -3;
        int connectAnalysisCount = 0;
        int terminationFlag = 0;
        int connectAnalysisTempCount = 0;
        int xSource = 0;
        int ySource = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivityMapTemp [counterY][counterX] == 0){
                    connectivityNumber = connectivityNumber+2;
                    connectivityMapTemp [counterY][counterX] = connectivityNumber;
                    
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == 0){
                        connectivityMapTemp [counterY-1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension && connectivityMapTemp [counterY][counterX+1] == 0){
                        connectivityMapTemp [counterY][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && connectivityMapTemp [counterY+1][counterX] == 0){
                        connectivityMapTemp [counterY+1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == 0){
                        connectivityMapTemp [counterY][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && connectivityMapTemp [ySource-1][xSource] == 0){
                                    connectivityMapTemp [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension && connectivityMapTemp [ySource][xSource+1] == 0){
                                    connectivityMapTemp [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && connectivityMapTemp [ySource+1][xSource] == 0){
                                    connectivityMapTemp [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && connectivityMapTemp [ySource][xSource-1] == 0){
                                    connectivityMapTemp [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //------Remove connectivity groups, which attach edge, extract inner part of Linked Line------
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivityMapTemp [counterY][counterX] == -1) connectivityMapTemp [counterY][counterX] = 0;
            }
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivityMapTemp [counterY][counterX] != 0){
                    if (counterX+1 < dimension && connectivityMapTemp [counterY][counterX+1] == 0) connectivityMapTemp [counterY][counterX] = -1;
                    else if (counterY+1 < dimension && connectivityMapTemp [counterY+1][counterX] == 0) connectivityMapTemp [counterY][counterX] = -1;
                    else if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == 0) connectivityMapTemp [counterY][counterX] = -1;
                    else if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == 0) connectivityMapTemp [counterY][counterX] = -1;
                }
            }
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivityMapTemp [counterY][counterX] > 0) connectivityMapTemp [counterY][counterX] = 0;
                if (connectivityMapTemp [counterY][counterX] < 0) connectivityMapTemp [counterY][counterX] = 1;
            }
        }
        
        connectivityNumber = 0;
        
        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                if (connectivityMapTemp [counterY2][counterX2] == 0){
                    connectivityNumber--;
                    connectAnalysisCount = 0;
                    
                    connectivityMapTemp [counterY2][counterX2] = connectivityNumber;
                    
                    if (counterY2-1 >= 0 && connectivityMapTemp [counterY2-1][counterX2] == 0){
                        connectivityMapTemp [counterY2-1][counterX2] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                    }
                    if (counterX2+1 < dimension && connectivityMapTemp [counterY2][counterX2+1] == 0){
                        connectivityMapTemp [counterY2][counterX2+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                    }
                    if (counterY2+1 < dimension && connectivityMapTemp [counterY2+1][counterX2] == 0){
                        connectivityMapTemp [counterY2+1][counterX2] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                    }
                    if (counterX2-1 >= 0 && connectivityMapTemp [counterY2][counterX2-1] == 0){
                        connectivityMapTemp [counterY2][counterX2-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && connectivityMapTemp [ySource-1][xSource] == 0){
                                    connectivityMapTemp [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension && connectivityMapTemp [ySource][xSource+1] == 0){
                                    connectivityMapTemp [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && connectivityMapTemp [ySource+1][xSource] == 0){
                                    connectivityMapTemp [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && connectivityMapTemp [ySource][xSource-1] == 0){
                                    connectivityMapTemp [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        delete [] connectAnalysisX;
        delete [] connectAnalysisY;
        delete [] connectAnalysisTempX;
        delete [] connectAnalysisTempY;
        
        //------Determine number of pixels------
        connectivityNumber = connectivityNumber*-1;
        
        int *connectedPix = new int [connectivityNumber+50];
        for (int counter1 = 0; counter1 <= connectivityNumber; counter1++) connectedPix [counter1] = 0;
        
        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                if (connectivityMapTemp [counterY2][counterX2] < -1 && connectivityMapTemp2 [counterY2][counterX2] != 0){
                    connectedPix [connectivityMapTemp [counterY2][counterX2]*-1]++;
                }
            }
        }
        
        int **newConnectivityMapTemp = new int *[dimension+4];
        for (int counter1 = 0; counter1 < dimension+4; counter1++) newConnectivityMapTemp [counter1] = new int [dimension+4];
        
        for (int counterY = 0; counterY < dimension+4; counterY++){
            for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
        }
        
        int largestConnect = 0;
        int largestConnectNo = 0;
        
        for (int counter1 = 2; counter1 <= connectivityNumber; counter1++){
            if (connectedPix [counter1] > largestConnect){
                largestConnect = connectedPix [counter1];
                largestConnectNo = counter1;
            }
        }
        
        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                if (connectivityMapTemp [counterY2][counterX2] == largestConnectNo*-1){
                    if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityMapTemp [counterY2-1][counterX2-1] == 1){
                        newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                        connectivityMapTemp [counterY2-1][counterX2-1] = 0;
                    }
                    if (counterY2-1 >= 0 && connectivityMapTemp [counterY2-1][counterX2] == 1){
                        newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                        connectivityMapTemp [counterY2-1][counterX2] = 0;
                    }
                    if (counterY2-1 >= 0 && counterX2+1 < dimension && connectivityMapTemp [counterY2-1][counterX2+1] == 1){
                        newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                        connectivityMapTemp [counterY2-1][counterX2+1] = 0;
                    }
                    if (counterX2+1 < dimension && connectivityMapTemp [counterY2][counterX2+1] == 1){
                        newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                        connectivityMapTemp [counterY2][counterX2+1] = 0;
                    }
                    if (counterY2+1 < dimension && counterX2+1 < dimension && connectivityMapTemp [counterY2+1][counterX2+1] == 1){
                        newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                        connectivityMapTemp [counterY2+1][counterX2+1] = 0;
                    }
                    if (counterY2+1 < dimension && connectivityMapTemp [counterY2+1][counterX2] == 1){
                        newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                        connectivityMapTemp [counterY2+1][counterX2] = 0;
                    }
                    if (counterY2+1 < dimension && counterX2-1 >= 0 && connectivityMapTemp [counterY2+1][counterX2-1] == 1){
                        newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                        connectivityMapTemp [counterY2+1][counterX2-1] = 0;
                    }
                    if (counterX2-1 >= 0 && connectivityMapTemp [counterY2][counterX2-1] == 1){
                        newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                        connectivityMapTemp [counterY2][counterX2-1] = 0;
                    }
                }
            }
        }
        
        delete [] connectedPix;
        
        int xPositionTempStart = 0;
        int yPositionTempStart = 0;
        int lineSize = 0;
        
        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                    connectivityMapTemp [counterY2][counterX2] = 1;
                    xPositionTempStart = counterX2;
                    yPositionTempStart = counterY2;
                    lineSize++;
                }
                else connectivityMapTemp [counterY2][counterX2] = 0;
            }
        }
        
        for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] newConnectivityMapTemp [counter1];
        delete [] newConnectivityMapTemp;
        
        int constructedLineCount = 0;
        int findFlag = 0;
        
        int *arrayNewLines = new int [lineSize*2+50];
        
        connectivityMapTemp [yPositionTempStart][xPositionTempStart] = -1;
        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
        
        do{
            
            findFlag = 0;
            terminationFlag = 0;
            
            if (xPositionTempStart+1 < dimension){
                if (connectivityMapTemp [yPositionTempStart][xPositionTempStart+1] == 1){
                    connectivityMapTemp [yPositionTempStart][xPositionTempStart+1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                }
            }
            if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                if (connectivityMapTemp [yPositionTempStart+1][xPositionTempStart+1] == 1){
                    connectivityMapTemp [yPositionTempStart+1][xPositionTempStart+1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                }
            }
            if (yPositionTempStart+1 < dimension && findFlag == 0){
                if (connectivityMapTemp [yPositionTempStart+1][xPositionTempStart] == 1){
                    connectivityMapTemp [yPositionTempStart+1][xPositionTempStart] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                    yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                }
            }
            if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                if (connectivityMapTemp [yPositionTempStart+1][xPositionTempStart-1] == 1){
                    connectivityMapTemp [yPositionTempStart+1][xPositionTempStart-1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                }
            }
            if (xPositionTempStart-1 >= 0 && findFlag == 0){
                if (connectivityMapTemp [yPositionTempStart][xPositionTempStart-1] == 1){
                    connectivityMapTemp [yPositionTempStart][xPositionTempStart-1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                }
            }
            if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                if (connectivityMapTemp [yPositionTempStart-1][xPositionTempStart-1] == 1){
                    connectivityMapTemp [yPositionTempStart-1][xPositionTempStart-1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                }
            }
            if (yPositionTempStart-1 >= 0 && findFlag == 0){
                if (connectivityMapTemp [yPositionTempStart-1][xPositionTempStart] == 1){
                    connectivityMapTemp [yPositionTempStart-1][xPositionTempStart] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                    yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                }
            }
            if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                if (connectivityMapTemp [yPositionTempStart-1][xPositionTempStart+1] == 1){
                    connectivityMapTemp [yPositionTempStart-1][xPositionTempStart+1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                }
            }
            
        } while (terminationFlag == 1);
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
        //	cout<<" connectivityMapTemp "<<counterA<<endl;
        //}
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++){
            delete [] connectivityMapTemp [counter1];
            delete [] connectivityMapTemp2 [counter1];
        }
        
        delete [] connectivityMapTemp;
        delete [] connectivityMapTemp2;
        
        if (constructedLineCount != 0){
            referenceLineCount = 0;
            
            for (int counter1 = 0; counter1 < constructedLineCount/2; counter1++){
                if (referenceLineCount+2 > referenceLineLimit) [self referenceLineCountUpDate];
                
                arrayReferenceLine [referenceLineCount] = arrayNewLines [counter1*2], referenceLineCount++;
                arrayReferenceLine [referenceLineCount] = arrayNewLines [counter1*2+1], referenceLineCount++;
            }
            
            mergeResult = 1;
        }
        
        delete [] arrayNewLines;
    }
    
    delete [] connectList;
    delete [] connectList2;
    
    return mergeResult;
}

-(void)referenceLineCountUpDate{
    int *arrayUpDate = new int [referenceLineCount+10];
    
    for (int counter1 = 0; counter1 < referenceLineCount; counter1++) arrayUpDate [counter1] = arrayReferenceLine [counter1];
    
    delete [] arrayReferenceLine;
    arrayReferenceLine = new int [referenceLineLimit+5000];
    referenceLineLimit = referenceLineLimit+5000;
    
    for (int counter1 = 0; counter1 < referenceLineCount; counter1++) arrayReferenceLine [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

@end
