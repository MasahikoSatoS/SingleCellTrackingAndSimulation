//
//  SubProcesses.m
//  CellMovieQuant
//
//  Created by Masahiko Sato on 2021-12-26.
//

#import "SubProcesses.h"

@implementation SubProcesses

-(void)areaTotalDataSet{
    double *calDataHold = new double [100];
    
    for (int counter1 = 0; counter1 < 100; counter1++) calDataHold [counter1] = 0;
    
    for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
        if (arrayTimeSelected [counter1*10] == 1){
            for (int counter2 = 0; counter2 < gravityCenterRevCount/6; counter2++){
                if (arrayGravityCenterRev [counter2*6+4] == arrayTimeSelected [counter1*10+8]){
                    calDataHold [0] = calDataHold [0]+arrayGravityCenterRev [counter2*6+2];
                    calDataHold [1] = calDataHold [1]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                    
                    if (arrayTimeSelected [counter1*10+9] == 0){
                        calDataHold [2] = calDataHold [2]+arrayGravityCenterRev [counter2*6+2];
                        calDataHold [3] = calDataHold [3]+arrayTimeSelected [counter1*10+9];
                        calDataHold [4] = calDataHold [4]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                    }
                    else if (arrayTimeSelected [counter1*10+9] == 1 || arrayTimeSelected [counter1*10+9] == 2){
                        calDataHold [5] = calDataHold [5]+arrayGravityCenterRev [counter2*6+2];
                        calDataHold [6] = calDataHold [6]+arrayTimeSelected [counter1*10+9];
                        calDataHold [7] = calDataHold [7]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                    }
                    else if (arrayTimeSelected [counter1*10+9] == 3 || arrayTimeSelected [counter1*10+9] == 4){
                        calDataHold [8] = calDataHold [8]+arrayGravityCenterRev [counter2*6+2];
                        calDataHold [9] = calDataHold [9]+arrayTimeSelected [counter1*10+9];
                        calDataHold [10] = calDataHold [10]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                    }
                    else if (arrayTimeSelected [counter1*10+9] == 5 || arrayTimeSelected [counter1*10+9] == 6){
                        calDataHold [11] = calDataHold [11]+arrayGravityCenterRev [counter2*6+2];
                        calDataHold [12] = calDataHold [12]+arrayTimeSelected [counter1*10+9];
                        calDataHold [13] = calDataHold [13]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                    }
                    else if (arrayTimeSelected [counter1*10+9] == 7 || arrayTimeSelected [counter1*10+9] == 8){
                        calDataHold [14] = calDataHold [14]+arrayGravityCenterRev [counter2*6+2];
                        calDataHold [15] = calDataHold [15]+arrayTimeSelected [counter1*10+9];
                        calDataHold [16] = calDataHold [16]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                    }
                    else if (arrayTimeSelected [counter1*10+9] == 9 || arrayTimeSelected [counter1*10+9] == 10){
                        calDataHold [17] = calDataHold [17]+arrayGravityCenterRev [counter2*6+2];
                        calDataHold [18] = calDataHold [18]+arrayTimeSelected [counter1*10+9];
                        calDataHold [19] = calDataHold [19]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                    }
                    else if (arrayTimeSelected [counter1*10+9] == 11 || arrayTimeSelected [counter1*10+9] == 12){
                        calDataHold [20] = calDataHold [20]+arrayGravityCenterRev [counter2*6+2];
                        calDataHold [21] = calDataHold [21]+arrayTimeSelected [counter1*10+9];
                        calDataHold [22] = calDataHold [22]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                    }
                    else if (arrayTimeSelected [counter1*10+9] == 13 || arrayTimeSelected [counter1*10+9] == 14){
                        calDataHold [23] = calDataHold [23]+arrayGravityCenterRev [counter2*6+2];
                        calDataHold [24] = calDataHold [24]+arrayTimeSelected [counter1*10+9];
                        calDataHold [25] = calDataHold [25]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                    }
                    else if (arrayTimeSelected [counter1*10+9] == 15 || arrayTimeSelected [counter1*10+9] == 16){
                        calDataHold [26] = calDataHold [26]+arrayGravityCenterRev [counter2*6+2];
                        calDataHold [27] = calDataHold [27]+arrayTimeSelected [counter1*10+9];
                        calDataHold [28] = calDataHold [28]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                    }
                    else if (arrayTimeSelected [counter1*10+9] == 17 || arrayTimeSelected [counter1*10+9] == 18){
                        calDataHold [29] = calDataHold [29]+arrayGravityCenterRev [counter2*6+2];
                        calDataHold [30] = calDataHold [30]+arrayTimeSelected [counter1*10+9];
                        calDataHold [31] = calDataHold [31]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                    }
                    else if (arrayTimeSelected [counter1*10+9] == 19 || arrayTimeSelected [counter1*10+9] == 20){
                        calDataHold [32] = calDataHold [32]+arrayGravityCenterRev [counter2*6+2];
                        calDataHold [33] = calDataHold [33]+arrayTimeSelected [counter1*10+9];
                        calDataHold [34] = calDataHold [34]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                    }
                    else if (arrayTimeSelected [counter1*10+9] == 21 || arrayTimeSelected [counter1*10+9] == 22){
                        calDataHold [35] = calDataHold [35]+arrayGravityCenterRev [counter2*6+2];
                        calDataHold [36] = calDataHold [36]+arrayTimeSelected [counter1*10+9];
                        calDataHold [37] = calDataHold [37]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                    }
                    else if (arrayTimeSelected [counter1*10+9] >= 23){
                        calDataHold [38] = calDataHold [38]+arrayGravityCenterRev [counter2*6+2];
                        calDataHold [39] = calDataHold [39]+arrayTimeSelected [counter1*10+9];
                        calDataHold [40] = calDataHold [40]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                    }
                    
                    break;
                }
            }
        }
    }
    
    if (areaTotalTable == 0){
        arrayAreaDataHold [(timePointHold-1)*25+10] = calDataHold [0];
        arrayAreaDataHold [(timePointHold-1)*25+11] = calDataHold [1];
        
        if (calDataHold [2] != 0) arrayAreaDataHold [(timePointHold-1)*25+12] = calDataHold [2];
        else arrayAreaDataHold [(timePointHold-1)*25+12] = 0;
        
        if (calDataHold [6] != 0) arrayAreaDataHold [(timePointHold-1)*25+13] = calDataHold [5]/(double)calDataHold [6];
        else arrayAreaDataHold [(timePointHold-1)*25+13] = 0;
        
        if (calDataHold [9] != 0) arrayAreaDataHold [(timePointHold-1)*25+14] = calDataHold [8]/(double)calDataHold [9];
        else arrayAreaDataHold [(timePointHold-1)*25+14] = 0;
        
        if (calDataHold [12] != 0) arrayAreaDataHold [(timePointHold-1)*25+15] = calDataHold [11]/(double)calDataHold [12];
        else arrayAreaDataHold [(timePointHold-1)*25+15] = 0;
        
        if (calDataHold [15] != 0) arrayAreaDataHold [(timePointHold-1)*25+16] = calDataHold [14]/(double)calDataHold [15];
        else arrayAreaDataHold [(timePointHold-1)*25+16] = 0;
        
        if (calDataHold [18] != 0) arrayAreaDataHold [(timePointHold-1)*25+17] = calDataHold [17]/(double)calDataHold [18];
        else arrayAreaDataHold [(timePointHold-1)*25+17] = 0;
        
        if (calDataHold [21] != 0) arrayAreaDataHold [(timePointHold-1)*25+18] = calDataHold [20]/(double)calDataHold [21];
        else arrayAreaDataHold [(timePointHold-1)*25+18] = 0;
        
        if (calDataHold [24] != 0) arrayAreaDataHold [(timePointHold-1)*25+19] = calDataHold [23]/(double)calDataHold [24];
        else arrayAreaDataHold [(timePointHold-1)*25+19] = 0;
        
        if (calDataHold [27] != 0) arrayAreaDataHold [(timePointHold-1)*25+20] = calDataHold [26]/(double)calDataHold [27];
        else arrayAreaDataHold [(timePointHold-1)*25+20] = 0;
        
        if (calDataHold [30] != 0) arrayAreaDataHold [(timePointHold-1)*25+21] = calDataHold [29]/(double)calDataHold [30];
        else arrayAreaDataHold [(timePointHold-1)*25+21] = 0;
        
        if (calDataHold [33] != 0) arrayAreaDataHold [(timePointHold-1)*25+22] = calDataHold [32]/(double)calDataHold [33];
        else arrayAreaDataHold [(timePointHold-1)*25+22] = 0;
        
        if (calDataHold [36] != 0) arrayAreaDataHold [(timePointHold-1)*25+23] = calDataHold [35]/(double)calDataHold [36];
        else arrayAreaDataHold [(timePointHold-1)*25+23] = 0;
        
        if (calDataHold [39] != 0) arrayAreaDataHold [(timePointHold-1)*25+24] = calDataHold [38]/(double)calDataHold [39];
        else arrayAreaDataHold [(timePointHold-1)*25+24] = 0;
    }
    else if (areaTotalTable == 1){
        arrayAreaDataHold [(timePointHold-1)*25+10] = calDataHold [0];
        arrayAreaDataHold [(timePointHold-1)*25+11] = calDataHold [1];
        
        if (calDataHold [4] != 0) arrayAreaDataHold [(timePointHold-1)*25+12] = calDataHold [4];
        else arrayAreaDataHold [(timePointHold-1)*25+12] = 0;
        
        if (calDataHold [6] != 0) arrayAreaDataHold [(timePointHold-1)*25+13] = calDataHold [7]/(double)calDataHold [6];
        else arrayAreaDataHold [(timePointHold-1)*25+13] = 0;
        
        if (calDataHold [9] != 0) arrayAreaDataHold [(timePointHold-1)*25+14] = calDataHold [10]/(double)calDataHold [9];
        else arrayAreaDataHold [(timePointHold-1)*25+14] = 0;
        
        if (calDataHold [12] != 0) arrayAreaDataHold [(timePointHold-1)*25+15] = calDataHold [13]/(double)calDataHold [12];
        else arrayAreaDataHold [(timePointHold-1)*25+15] = 0;
        
        if (calDataHold [15] != 0) arrayAreaDataHold [(timePointHold-1)*25+16] = calDataHold [16]/(double)calDataHold [15];
        else arrayAreaDataHold [(timePointHold-1)*25+16] = 0;
        
        if (calDataHold [18] != 0) arrayAreaDataHold [(timePointHold-1)*25+17] = calDataHold [19]/(double)calDataHold [18];
        else arrayAreaDataHold [(timePointHold-1)*25+17] = 0;
        
        if (calDataHold [21] != 0) arrayAreaDataHold [(timePointHold-1)*25+18] = calDataHold [22]/(double)calDataHold [21];
        else arrayAreaDataHold [(timePointHold-1)*25+18] = 0;
        
        if (calDataHold [24] != 0) arrayAreaDataHold [(timePointHold-1)*25+19] = calDataHold [25]/(double)calDataHold [24];
        else arrayAreaDataHold [(timePointHold-1)*25+19] = 0;
        
        if (calDataHold [27] != 0) arrayAreaDataHold [(timePointHold-1)*25+20] = calDataHold [28]/(double)calDataHold [27];
        else arrayAreaDataHold [(timePointHold-1)*25+20] = 0;
        
        if (calDataHold [30] != 0) arrayAreaDataHold [(timePointHold-1)*25+21] = calDataHold [31]/(double)calDataHold [30];
        else arrayAreaDataHold [(timePointHold-1)*25+21] = 0;
        
        if (calDataHold [33] != 0) arrayAreaDataHold [(timePointHold-1)*25+22] = calDataHold [34]/(double)calDataHold [33];
        else arrayAreaDataHold [(timePointHold-1)*25+22] = 0;
        
        if (calDataHold [36] != 0) arrayAreaDataHold [(timePointHold-1)*25+23] = calDataHold [37]/(double)calDataHold [36];
        else arrayAreaDataHold [(timePointHold-1)*25+23] = 0;
        
        if (calDataHold [39] != 0) arrayAreaDataHold [(timePointHold-1)*25+24] = calDataHold [40]/(double)calDataHold [39];
        else arrayAreaDataHold [(timePointHold-1)*25+24] = 0;
    }
    
    delete [] calDataHold;
}

@end
