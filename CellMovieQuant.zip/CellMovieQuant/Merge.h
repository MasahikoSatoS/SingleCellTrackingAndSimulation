//
//  Merge.h
//  CellMovieQuant
//
//  Created by Masahiko Sato on 2015-01-12.
//
//

#ifndef MERGE_H
#define MERGE_H
#import "Controller.h"
#endif

@interface Merge : NSObject {
}

-(void)mergeMain:(int)groupNoMerge :(int)numberOfEntry;
-(void)mergeConnect;
-(int)mergeAttach;

-(void)referenceLineCountUpDate;

@end
