//
//  MovieDisplay.m
//  CellMovieQuant
//
//  Created by Masahiko Sato on 2014-09-29.
//
//

#import "MovieDisplay.h"

NSString *notificationToMovieDisplay = @"notificationExecuteMovieDisplay";

@implementation MovieDisplay

-(id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    
    if (self) {
        firstDisplayFlag = 0;
        
        magnificationDisplay = 10;
        mouseDragFlag = 0;
        
        timeOneQuickSet = 0;
        
        xPointLine = 0;
        yPointLine = 0;
        
        movieImage = [[NSImage alloc] initWithContentsOfFile:@""];
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToMovieDisplay object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    if (imageXYLength != 0){
        int areaValue = 0;
        double areaTotal = 0;
        
        NSBitmapImageRep *bitmapRepsCR = nil;
        bitmapRepsCR = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageXYLength pixelsHigh:imageXYLength bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageXYLength*4 bitsPerPixel:32];
        
        unsigned char *bitmapData = [bitmapRepsCR bitmapData];
        
        if (phaseStatus == 0){
            if (grayColorStatus == 0){
                int value0 = 0;
                int value1 = 0;
                int value2 = 0;
                int value3 = 0;
                int value4 = 0;
                int value5 = 0;
                int value6 = 0;
                
                int dataConversion [4];
                int endianType = 0;
                
                double colorHit1 = 0;
                double colorHit2 = 0;
                double colorHit3 = 0;
                double colorHit4 = 0;
                double colorHit5 = 0;
                double colorHit6 = 0;
                
                int hitR = 0;
                int hitG = 0;
                int hitB = 0;
                
                if (statusHold1 != 0 || statusHold2 != 0 || statusHold3 != 0 || statusHold4 != 0 || statusHold5 != 0 || statusHold6 != 0){
                    if (imageBmpTifFlag == 0){
                        double *hitMap = new double [20];
                        
                        if (colorNo1 == "1"){
                            hitMap [0] = 0;
                            hitMap [1] = 0;
                            hitMap [2] = 1;
                        }
                        else if (colorNo1 == "2"){
                            hitMap [0] = 0;
                            hitMap [1] = 1;
                            hitMap [2] = 0;
                        }
                        else if (colorNo1 == "3"){
                            hitMap [0] = 1;
                            hitMap [1] = 1;
                            hitMap [2] = 0;
                        }
                        else if (colorNo1 == "4"){
                            hitMap [0] = 1;
                            hitMap [1] = 0;
                            hitMap [2] = 0;
                        }
                        else if (colorNo1 == "5"){
                            hitMap [0] = 1;
                            hitMap [1] = 0;
                            hitMap [2] = 1;
                        }
                        else if (colorNo1 == "6"){
                            hitMap [0] = 0;
                            hitMap [1] = 1;
                            hitMap [2] = 1;
                        }
                        else if (colorNo1 == "7"){
                            hitMap [0] = 1;
                            hitMap [1] = 0.674;
                            hitMap [2] = 0;
                        }
                        else if (colorNo1 == "8"){
                            hitMap [0] = 0.627;
                            hitMap [1] = 0.125;
                            hitMap [2] = 0.941;
                        }
                        else if (colorNo1 == "9"){
                            hitMap [0] = 0.529;
                            hitMap [1] = 0.808;
                            hitMap [2] = 0.922;
                        }
                        
                        if (colorNo2 == "1"){
                            hitMap [3] = 0;
                            hitMap [4] = 0;
                            hitMap [5] = 1;
                        }
                        else if (colorNo2 == "2"){
                            hitMap [3] = 0;
                            hitMap [4] = 1;
                            hitMap [5] = 0;
                        }
                        else if (colorNo2 == "3"){
                            hitMap [3] = 1;
                            hitMap [4] = 1;
                            hitMap [5] = 0;
                        }
                        else if (colorNo2 == "4"){
                            hitMap [3] = 1;
                            hitMap [4] = 0;
                            hitMap [5] = 0;
                        }
                        else if (colorNo2 == "5"){
                            hitMap [3] = 1;
                            hitMap [4] = 0;
                            hitMap [5] = 1;
                        }
                        else if (colorNo2 == "6"){
                            hitMap [3] = 0;
                            hitMap [4] = 1;
                            hitMap [5] = 1;
                        }
                        else if (colorNo2 == "7"){
                            hitMap [3] = 1;
                            hitMap [4] = 0.674;
                            hitMap [5] = 0;
                        }
                        else if (colorNo2 == "8"){
                            hitMap [3] = 0.627;
                            hitMap [4] = 0.125;
                            hitMap [5] = 0.941;
                        }
                        else if (colorNo2 == "9"){
                            hitMap [3] = 0.529;
                            hitMap [4] = 0.808;
                            hitMap [5] = 0.922;
                        }
                        
                        if (colorNo3 == "1"){
                            hitMap [6] = 0;
                            hitMap [7] = 0;
                            hitMap [8] = 1;
                        }
                        else if (colorNo3 == "2"){
                            hitMap [6] = 0;
                            hitMap [7] = 1;
                            hitMap [8] = 0;
                        }
                        else if (colorNo3 == "3"){
                            hitMap [6] = 1;
                            hitMap [7] = 1;
                            hitMap [8] = 0;
                        }
                        else if (colorNo3 == "4"){
                            hitMap [6] = 1;
                            hitMap [7] = 0;
                            hitMap [8] = 0;
                        }
                        else if (colorNo3 == "5"){
                            hitMap [6] = 1;
                            hitMap [7] = 0;
                            hitMap [8] = 1;
                        }
                        else if (colorNo3 == "6"){
                            hitMap [6] = 0;
                            hitMap [7] = 1;
                            hitMap [8] = 1;
                        }
                        else if (colorNo3 == "7"){
                            hitMap [6] = 1;
                            hitMap [7] = 0.674;
                            hitMap [8] = 0;
                        }
                        else if (colorNo3 == "8"){
                            hitMap [6] = 0.627;
                            hitMap [7] = 0.125;
                            hitMap [8] = 0.941;
                        }
                        else if (colorNo3 == "9"){
                            hitMap [6] = 0.529;
                            hitMap [7] = 0.808;
                            hitMap [8] = 0.922;
                        }
                        
                        if (colorNo4 == "1"){
                            hitMap [9] = 0;
                            hitMap [10] = 0;
                            hitMap [11] = 1;
                        }
                        else if (colorNo4 == "2"){
                            hitMap [9] = 0;
                            hitMap [10] = 1;
                            hitMap [11] = 0;
                        }
                        else if (colorNo4 == "3"){
                            hitMap [9] = 1;
                            hitMap [10] = 1;
                            hitMap [11] = 0;
                        }
                        else if (colorNo4 == "4"){
                            hitMap [9] = 1;
                            hitMap [10] = 0;
                            hitMap [11] = 0;
                        }
                        else if (colorNo4 == "5"){
                            hitMap [9] = 1;
                            hitMap [10] = 0;
                            hitMap [11] = 1;
                        }
                        else if (colorNo4 == "6"){
                            hitMap [9] = 0;
                            hitMap [10] = 1;
                            hitMap [11] = 1;
                        }
                        else if (colorNo4 == "7"){
                            hitMap [9] = 1;
                            hitMap [10] = 0.674;
                            hitMap [11] = 0;
                        }
                        else if (colorNo4 == "8"){
                            hitMap [9] = 0.627;
                            hitMap [10] = 0.125;
                            hitMap [11] = 0.941;
                        }
                        else if (colorNo4 == "9"){
                            hitMap [9] = 0.529;
                            hitMap [10] = 0.808;
                            hitMap [11] = 0.922;
                        }
                        
                        if (colorNo5 == "1"){
                            hitMap [12] = 0;
                            hitMap [13] = 0;
                            hitMap [14] = 1;
                        }
                        else if (colorNo5 == "2"){
                            hitMap [12] = 0;
                            hitMap [13] = 1;
                            hitMap [14] = 0;
                        }
                        else if (colorNo5 == "3"){
                            hitMap [12] = 1;
                            hitMap [13] = 1;
                            hitMap [14] = 0;
                        }
                        else if (colorNo5 == "4"){
                            hitMap [12] = 1;
                            hitMap [13] = 0;
                            hitMap [14] = 0;
                        }
                        else if (colorNo5 == "5"){
                            hitMap [12] = 1;
                            hitMap [13] = 0;
                            hitMap [14] = 1;
                        }
                        else if (colorNo5 == "6"){
                            hitMap [12] = 0;
                            hitMap [13] = 1;
                            hitMap [14] = 1;
                        }
                        else if (colorNo5 == "7"){
                            hitMap [12] = 1;
                            hitMap [13] = 0.674;
                            hitMap [14] = 0;
                        }
                        else if (colorNo5 == "8"){
                            hitMap [12] = 0.627;
                            hitMap [13] = 0.125;
                            hitMap [14] = 0.941;
                        }
                        else if (colorNo5 == "9"){
                            hitMap [12] = 0.529;
                            hitMap [13] = 0.808;
                            hitMap [14] = 0.922;
                        }
                        
                        if (colorNo6 == "1"){
                            hitMap [15] = 0;
                            hitMap [16] = 0;
                            hitMap [17] = 1;
                        }
                        else if (colorNo6 == "2"){
                            hitMap [15] = 0;
                            hitMap [16] = 1;
                            hitMap [17] = 0;
                        }
                        else if (colorNo6 == "3"){
                            hitMap [15] = 1;
                            hitMap [16] = 1;
                            hitMap [17] = 0;
                        }
                        else if (colorNo6 == "4"){
                            hitMap [15] = 1;
                            hitMap [16] = 0;
                            hitMap [17] = 0;
                        }
                        else if (colorNo6 == "5"){
                            hitMap [15] = 1;
                            hitMap [16] = 0;
                            hitMap [17] = 1;
                        }
                        else if (colorNo6 == "6"){
                            hitMap [15] = 0;
                            hitMap [16] = 1;
                            hitMap [17] = 1;
                        }
                        else if (colorNo6 == "7"){
                            hitMap [15] = 1;
                            hitMap [16] = 0.674;
                            hitMap [17] = 0;
                        }
                        else if (colorNo6 == "8"){
                            hitMap [15] = 0.627;
                            hitMap [16] = 0.125;
                            hitMap [17] = 0.941;
                        }
                        else if (colorNo6 == "9"){
                            hitMap [15] = 0.529;
                            hitMap [16] = 0.808;
                            hitMap [17] = 0.922;
                        }
                        
                        unsigned long headPosition = 0;
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                            value1 = 0;
                            value2 = 0;
                            value3 = 0;
                            value4 = 0;
                            value5 = 0;
                            value6 = 0;
                            
                            value0 = uploadTemp [counter1];
                            
                            if (value0 >= 0 && value0 < cutHoldDIC){
                                value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                
                                if (value0 < 0) value0 = 0;
                            }
                            else{
                                
                                value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                
                                if (value0 > 255) value0 = 255;
                            }
                            
                            if (statusHold1 == 1 && colorFlag1 == 1){
                                value1 = uploadTempCl1 [counter1];
                                
                                if (value1 < cutHold1) value1 = 0;
                                else{
                                    
                                    value1 = value1+(int)((value1-cutHold1)*levelHold1);
                                    
                                    if (value1 > 255) value1 = 255;
                                }
                            }
                            
                            if (statusHold2 == 1 && colorFlag2 == 1){
                                value2 = uploadTempCl2 [counter1];
                                
                                if (value2 < cutHold2) value2 = 0;
                                else{
                                    
                                    value2 = value2+(int)((value2-cutHold2)*levelHold2);
                                    
                                    if (value2 > 255) value2 = 255;
                                }
                            }
                            
                            if (statusHold3 == 1 && colorFlag3 == 1){
                                value3 = uploadTempCl3 [counter1];
                                
                                if (value3 < cutHold3) value3 = 0;
                                else{
                                    
                                    value3 = value3+(int)((value3-cutHold3)*levelHold3);
                                    
                                    if (value3 > 255) value3 = 255;
                                }
                            }
                            
                            if (statusHold4 == 1 && colorFlag4 == 1){
                                value4 = uploadTempCl4 [counter1];
                                
                                if (value4 < cutHold4) value4 = 0;
                                else{
                                    
                                    value4 = value4+(int)((value4-cutHold4)*levelHold4);
                                    
                                    if (value4 > 255) value4 = 255;
                                }
                            }
                            
                            if (statusHold5 == 1 && colorFlag5 == 1){
                                value5 = uploadTempCl5 [counter1];
                                
                                if (value5 < cutHold5) value5 = 0;
                                else{
                                    
                                    value5 = value5+(int)((value5-cutHold5)*levelHold5);
                                    
                                    if (value5 > 255) value5 = 255;
                                }
                            }
                            
                            if (statusHold6 == 1 && colorFlag6 == 1){
                                value6 = uploadTempCl6 [counter1];
                                
                                if (value6 < cutHold6) value6 = 0;
                                else{
                                    
                                    value6 = value6+(int)((value6-cutHold6)*levelHold6);
                                    
                                    if (value6 > 255) value6 = 255;
                                }
                            }
                            
                            if (statusHold1 == 0) value1 = 0;
                            if (statusHold2 == 0) value2 = 0;
                            if (statusHold3 == 0) value3 = 0;
                            if (statusHold4 == 0) value4 = 0;
                            if (statusHold5 == 0) value5 = 0;
                            if (statusHold6 == 0) value6 = 0;
                            
                            if (value1 <= 0 && value2 <= 0 && value3 <= 0 && value4 <= 0 && value5 <= 0 && value6 <= 0){
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = 0;
                            }
                            else{
                                
                                if (value1 < 0) value1 = 0;
                                if (value2 < 0) value2 = 0;
                                if (value3 < 0) value3 = 0;
                                if (value4 < 0) value4 = 0;
                                if (value5 < 0) value5 = 0;
                                if (value6 < 0) value6 = 0;
                                
                                hitR = 0;
                                hitG = 0;
                                hitB = 0;
                                
                                if (value1 > 0){
                                    if (hitMap [0] != 0) hitR++;
                                    if (hitMap [1] != 0) hitG++;
                                    if (hitMap [2] != 0) hitB++;
                                }
                                
                                if (value2 > 0){
                                    if (hitMap [3] != 0) hitR++;
                                    if (hitMap [4] != 0) hitG++;
                                    if (hitMap [5] != 0) hitB++;
                                }
                                
                                if (value3 > 0){
                                    if (hitMap [6] != 0) hitR++;
                                    if (hitMap [7] != 0) hitG++;
                                    if (hitMap [8] != 0) hitB++;
                                }
                                
                                if (value4 > 0){
                                    if (hitMap [9] != 0) hitR++;
                                    if (hitMap [10] != 0) hitG++;
                                    if (hitMap [11] != 0) hitB++;
                                }
                                
                                if (value5 > 0){
                                    if (hitMap [12] != 0) hitR++;
                                    if (hitMap [13] != 0) hitG++;
                                    if (hitMap [14] != 0) hitB++;
                                }
                                
                                if (value6 > 0){
                                    if (hitMap [15] != 0) hitR++;
                                    if (hitMap [16] != 0) hitG++;
                                    if (hitMap [17] != 0) hitB++;
                                }
                                
                                colorHit1 = 0;
                                colorHit2 = 0;
                                colorHit3 = 0;
                                colorHit4 = 0;
                                colorHit5 = 0;
                                colorHit6 = 0;
                                
                                if (hitR == 1){
                                    if (hitMap [0] != 0 && value1 > 0) colorHit1 = 1;
                                    if (hitMap [3] != 0 && value2 > 0) colorHit2 = 1;
                                    if (hitMap [6] != 0 && value3 > 0) colorHit3 = 1;
                                    if (hitMap [9] != 0 && value4 > 0) colorHit4 = 1;
                                    if (hitMap [12] != 0 && value5 > 0) colorHit5 = 1;
                                    if (hitMap [15] != 0 && value6 > 0) colorHit6 = 1;
                                }
                                else if (hitR == 2){
                                    if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.5;
                                    if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.5;
                                    if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.5;
                                    if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.5;
                                    if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.5;
                                    if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.5;
                                }
                                else if (hitR == 3){
                                    if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.33;
                                    if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.33;
                                    if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.33;
                                    if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.33;
                                    if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.33;
                                    if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.33;
                                }
                                else if (hitR == 4){
                                    if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.25;
                                    if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.25;
                                    if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.25;
                                    if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.25;
                                    if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.25;
                                    if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.25;
                                }
                                else if (hitR == 5){
                                    if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.2;
                                    if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.2;
                                    if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.2;
                                    if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.2;
                                    if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.2;
                                    if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.2;
                                }
                                else if (hitR == 6){
                                    if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.13;
                                    if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.13;
                                    if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.13;
                                    if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.13;
                                    if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.13;
                                    if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.13;
                                }
                                
                                if (value1 > 0 && colorNo1 == "7") colorHit1 = colorHit1*0.647;
                                else if (value1 > 0 && colorNo1 == "8") colorHit1 = colorHit1*0.627;
                                else if (value1 > 0 && colorNo1 == "9") colorHit1 = colorHit1*0.529;
                                
                                if (value2 > 0 && colorNo2 == "7") colorHit2 = colorHit2*0.647;
                                else if (value2 > 0 && colorNo2 == "8") colorHit2 = colorHit2*0.627;
                                else if (value2 > 0 && colorNo2 == "9") colorHit2 = colorHit2*0.529;
                                
                                if (value3 > 0 && colorNo3 == "7") colorHit3 = colorHit3*0.647;
                                else if (value3 > 0 && colorNo3 == "8") colorHit3 = colorHit3*0.627;
                                else if (value3 > 0 && colorNo3 == "9") colorHit3 = colorHit3*0.529;
                                
                                if (value4 > 0 && colorNo4 == "7") colorHit4 = colorHit4*0.647;
                                else if (value4 > 0 && colorNo4 == "8") colorHit4 = colorHit4*0.627;
                                else if (value4 > 0 && colorNo4 == "9") colorHit4 = colorHit4*0.529;
                                
                                if (value5 > 0 && colorNo5 == "7") colorHit5 = colorHit5*0.647;
                                else if (value5 > 0 && colorNo5 == "8") colorHit5 = colorHit5*0.627;
                                else if (value5 > 0 && colorNo5 == "9") colorHit5 = colorHit5*0.529;
                                
                                if (value6 > 0 && colorNo6 == "7") colorHit6 = colorHit6*0.647;
                                else if (value6 > 0 && colorNo6 == "8") colorHit6 = colorHit6*0.627;
                                else if (value6 > 0 && colorNo6 == "9") colorHit6 = colorHit6*0.529;
                                
                                *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3+value4*(double)colorHit4+value5*(double)colorHit5+value6*(double)colorHit6));
                                
                                colorHit1 = 0;
                                colorHit2 = 0;
                                colorHit3 = 0;
                                colorHit4 = 0;
                                colorHit5 = 0;
                                colorHit6 = 0;
                                
                                if (hitG == 1){
                                    if (hitMap [1] != 0 && value1 > 0) colorHit1 = 1;
                                    if (hitMap [4] != 0 && value2 > 0) colorHit2 = 1;
                                    if (hitMap [7] != 0 && value3 > 0) colorHit3 = 1;
                                    if (hitMap [10] != 0 && value4 > 0) colorHit4 = 1;
                                    if (hitMap [13] != 0 && value5 > 0) colorHit5 = 1;
                                    if (hitMap [16] != 0 && value6 > 0) colorHit6 = 1;
                                }
                                else if (hitG == 2){
                                    if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.5;
                                    if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.5;
                                    if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.5;
                                    if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.5;
                                    if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.5;
                                    if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.5;
                                }
                                else if (hitG == 3){
                                    if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.33;
                                    if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.33;
                                    if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.33;
                                    if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.33;
                                    if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.33;
                                    if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.33;
                                }
                                else if (hitG == 4){
                                    if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.25;
                                    if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.25;
                                    if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.25;
                                    if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.25;
                                    if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.25;
                                    if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.25;
                                }
                                else if (hitG == 5){
                                    if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.2;
                                    if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.2;
                                    if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.2;
                                    if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.2;
                                    if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.2;
                                    if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.2;
                                }
                                else if (hitG == 6){
                                    if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.13;
                                    if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.13;
                                    if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.13;
                                    if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.13;
                                    if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.13;
                                    if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.13;
                                }
                                
                                if (value1 > 0 && colorNo1 == "8") colorHit1 = colorHit1*0.125;
                                else if (value1 > 0 && colorNo1 == "9") colorHit1 = colorHit1*0.808;
                                
                                if (value2 > 0 && colorNo2 == "8") colorHit2 = colorHit2*0.125;
                                else if (value2 > 0 && colorNo2 == "9") colorHit2 = colorHit2*0.808;
                                
                                if (value3 > 0 && colorNo3 == "8") colorHit3 = colorHit3*0.125;
                                else if (value3 > 0 && colorNo3 == "9") colorHit3 = colorHit3*0.808;
                                
                                if (value4 > 0 && colorNo4 == "8") colorHit4 = colorHit4*0.125;
                                else if (value4 > 0 && colorNo4 == "9") colorHit4 = colorHit4*0.808;
                                
                                if (value5 > 0 && colorNo5 == "8") colorHit5 = colorHit5*0.125;
                                else if (value5 > 0 && colorNo5 == "9") colorHit5 = colorHit5*0.808;
                                
                                if (value6 > 0 && colorNo6 == "8") colorHit6 = colorHit6*0.125;
                                else if (value6 > 0 && colorNo6 == "9") colorHit6 = colorHit6*0.808;
                                
                                *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3+value4*(double)colorHit4+value5*(double)colorHit5+value6*(double)colorHit6));
                                
                                colorHit1 = 0;
                                colorHit2 = 0;
                                colorHit3 = 0;
                                colorHit4 = 0;
                                colorHit5 = 0;
                                colorHit6 = 0;
                                
                                if (hitB == 1){
                                    if (hitMap [2] != 0 && value1 > 0) colorHit1 = 1;
                                    if (hitMap [5] != 0 && value2 > 0) colorHit2 = 1;
                                    if (hitMap [8] != 0 && value3 > 0) colorHit3 = 1;
                                    if (hitMap [11] != 0 && value4 > 0) colorHit4 = 1;
                                    if (hitMap [14] != 0 && value5 > 0) colorHit5 = 1;
                                    if (hitMap [17] != 0 && value6 > 0) colorHit6 = 1;
                                }
                                else if (hitB == 2){
                                    if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.5;
                                    if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.5;
                                    if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.5;
                                    if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.5;
                                    if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.5;
                                    if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.5;
                                }
                                else if (hitB == 3){
                                    if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.33;
                                    if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.33;
                                    if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.33;
                                    if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.33;
                                    if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.33;
                                    if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.33;
                                }
                                else if (hitB == 4){
                                    if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.25;
                                    if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.25;
                                    if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.25;
                                    if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.25;
                                    if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.25;
                                    if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.25;
                                }
                                else if (hitB == 5){
                                    if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.2;
                                    if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.2;
                                    if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.2;
                                    if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.2;
                                    if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.2;
                                    if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.2;
                                }
                                else if (hitB == 6){
                                    if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.13;
                                    if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.13;
                                    if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.13;
                                    if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.13;
                                    if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.13;
                                    if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.13;
                                }
                                
                                if (value1 > 0 && colorNo1 == "8") colorHit1 = colorHit1*0.941;
                                else if (value1 > 0 && colorNo1 == "9") colorHit1 = colorHit1*0.922;
                                
                                if (value2 > 0 && colorNo2 == "8") colorHit2 = colorHit2*0.941;
                                else if (value2 > 0 && colorNo2 == "9") colorHit2 = colorHit2*0.922;
                                
                                if (value3 > 0 && colorNo3 == "8") colorHit3 = colorHit3*0.941;
                                else if (value3 > 0 && colorNo3 == "9") colorHit3 = colorHit3*0.922;
                                
                                if (value4 > 0 && colorNo4 == "8") colorHit4 = colorHit4*0.941;
                                else if (value4 > 0 && colorNo4 == "9") colorHit4 = colorHit4*0.922;
                                
                                if (value5 > 0 && colorNo5 == "8") colorHit5 = colorHit5*0.941;
                                else if (value5 > 0 && colorNo5 == "9") colorHit5 = colorHit5*0.922;
                                
                                if (value6 > 0 && colorNo6 == "8") colorHit6 = colorHit6*0.941;
                                else if (value6 > 0 && colorNo6 == "9") colorHit6 = colorHit6*0.922;
                                
                                *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3+value4*(double)colorHit4+value5*(double)colorHit5+value6*(double)colorHit6));
                                *bitmapData++ = 0;
                            }
                        }
                        
                        delete [] hitMap;
                    }
                    else if (imageBmpTifFlag == 1){
                        double *hitMap = new double [20];
                        
                        if (colorNo1 == "1"){
                            hitMap [0] = 0;
                            hitMap [1] = 0;
                            hitMap [2] = 1;
                        }
                        else if (colorNo1 == "2"){
                            hitMap [0] = 0;
                            hitMap [1] = 1;
                            hitMap [2] = 0;
                        }
                        else if (colorNo1 == "3"){
                            hitMap [0] = 1;
                            hitMap [1] = 1;
                            hitMap [2] = 0;
                        }
                        else if (colorNo1 == "4"){
                            hitMap [0] = 1;
                            hitMap [1] = 0;
                            hitMap [2] = 0;
                        }
                        else if (colorNo1 == "5"){
                            hitMap [0] = 1;
                            hitMap [1] = 0;
                            hitMap [2] = 1;
                        }
                        
                        if (colorNo2 == "1"){
                            hitMap [3] = 0;
                            hitMap [4] = 0;
                            hitMap [5] = 1;
                        }
                        else if (colorNo2 == "2"){
                            hitMap [3] = 0;
                            hitMap [4] = 1;
                            hitMap [5] = 0;
                        }
                        else if (colorNo2 == "3"){
                            hitMap [3] = 1;
                            hitMap [4] = 1;
                            hitMap [5] = 0;
                        }
                        else if (colorNo2 == "4"){
                            hitMap [3] = 1;
                            hitMap [4] = 0;
                            hitMap [5] = 0;
                        }
                        else if (colorNo2 == "5"){
                            hitMap [3] = 1;
                            hitMap [4] = 0;
                            hitMap [5] = 1;
                        }
                        
                        if (colorNo3 == "1"){
                            hitMap [6] = 0;
                            hitMap [7] = 0;
                            hitMap [8] = 1;
                        }
                        else if (colorNo3 == "2"){
                            hitMap [6] = 0;
                            hitMap [7] = 1;
                            hitMap [8] = 0;
                        }
                        else if (colorNo3 == "3"){
                            hitMap [6] = 1;
                            hitMap [7] = 1;
                            hitMap [8] = 0;
                        }
                        else if (colorNo3 == "4"){
                            hitMap [6] = 1;
                            hitMap [7] = 0;
                            hitMap [8] = 0;
                        }
                        else if (colorNo3 == "5"){
                            hitMap [6] = 1;
                            hitMap [7] = 0;
                            hitMap [8] = 1;
                        }
                        
                        for (int counter1 = imageXYLength-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                                value0 = uploadTemp [1078+counter1*imageXYLength+counter2];
                                
                                if (value0 >= 0 && value0 < cutHoldDIC){
                                    value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                    
                                    if (value0 < 0) value0 = 0;
                                }
                                else{
                                    
                                    value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                    
                                    if (value0 > 255) value0 = 255;
                                }
                                
                                if (statusHold1 == 1 && colorFlag1 == 1){
                                    value1 = uploadTempCl1 [1078+counter1*imageXYLength+counter2];
                                    
                                    if (value1 < cutHold1) value1 = 0;
                                    else{
                                        
                                        value1 = value1+(int)((value1-cutHold1)*levelHold1);
                                        
                                        if (value1 > 255) value1 = 255;
                                    }
                                }
                                
                                if (statusHold2 == 1 && colorFlag2 == 1){
                                    value2 = uploadTempCl2 [1078+counter1*imageXYLength+counter2];
                                    
                                    if (value2 < cutHold2) value2 = 0;
                                    else{
                                        
                                        value2 = value2+(int)((value2-cutHold2)*levelHold2);
                                        
                                        if (value2 > 255) value2 = 255;
                                    }
                                }
                                
                                if (statusHold3 == 1 && colorFlag3 == 1){
                                    value3 = uploadTempCl3 [1078+counter1*imageXYLength+counter2];
                                    
                                    if (value3 < cutHold3) value3 = 0;
                                    else{
                                        
                                        value3 = value3+(int)((value3-cutHold3)*levelHold3);
                                        
                                        if (value3 > 255) value3 = 255;
                                    }
                                }
                                
                                if (statusHold1 == 0) value1 = 0;
                                if (statusHold2 == 0) value2 = 0;
                                if (statusHold3 == 0) value3 = 0;
                                
                                if (value1 <= 0 && value2 <= 0 && value3 <= 0){
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = 0;
                                }
                                else{
                                    
                                    if (value1 < 0) value1 = 0;
                                    if (value2 < 0) value2 = 0;
                                    if (value3 < 0) value3 = 0;
                                    
                                    hitR = 0;
                                    hitG = 0;
                                    hitB = 0;
                                    
                                    if (value1 > 0 && statusHold1 != 0){
                                        if (hitMap [0] != 0) hitR++;
                                        if (hitMap [1] != 0) hitG++;
                                        if (hitMap [2] != 0) hitB++;
                                    }
                                    
                                    if (value2 > 0 && statusHold2 != 0){
                                        if (hitMap [3] != 0) hitR++;
                                        if (hitMap [4] != 0) hitG++;
                                        if (hitMap [5] != 0) hitB++;
                                    }
                                    
                                    if (value3 > 0 && statusHold3 != 0){
                                        if (hitMap [6] != 0) hitR++;
                                        if (hitMap [7] != 0) hitG++;
                                        if (hitMap [8] != 0) hitB++;
                                    }
                                    
                                    colorHit1 = 0;
                                    colorHit2 = 0;
                                    colorHit3 = 0;
                                    
                                    if (hitR == 1){
                                        if (hitMap [0] != 0 && value1 > 0 ) colorHit1 = 1;
                                        if (hitMap [3] != 0 && value2 > 0 ) colorHit2 = 1;
                                        if (hitMap [6] != 0 && value3 > 0 ) colorHit3 = 1;
                                        
                                    }
                                    else if (hitR == 2){
                                        if (hitMap [0] != 0 && value1 > 0 ) colorHit1 = 0.5;
                                        if (hitMap [3] != 0 && value2 > 0 ) colorHit2 = 0.5;
                                        if (hitMap [6] != 0 && value3 > 0 ) colorHit3 = 0.5;
                                    }
                                    else if (hitR == 3){
                                        if (value1 > 0) colorHit1 = 0.33;
                                        if (value2 > 0) colorHit2 = 0.33;
                                        if (value3 > 0) colorHit3 = 0.33;
                                    }
                                    
                                    *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3));
                                    
                                    colorHit1 = 0;
                                    colorHit2 = 0;
                                    colorHit3 = 0;
                                    
                                    if (hitG == 1){
                                        if (hitMap [1] != 0 && value1 > 0 ) colorHit1 = 1;
                                        if (hitMap [4] != 0 && value2 > 0 ) colorHit2 = 1;
                                        if (hitMap [7] != 0 && value3 > 0 ) colorHit3 = 1;
                                    }
                                    else if (hitG == 2){
                                        if (hitMap [1] != 0 && value1 > 0 ) colorHit1 = 0.5;
                                        if (hitMap [4] != 0 && value2 > 0 ) colorHit2 = 0.5;
                                        if (hitMap [7] != 0 && value3 > 0 ) colorHit3 = 0.5;
                                    }
                                    else if (hitG == 3){
                                        if (hitMap [1] != 0 && value1 > 0 ) colorHit1 = 0.33;
                                        if (hitMap [4] != 0 && value2 > 0 ) colorHit2 = 0.33;
                                        if (hitMap [7] != 0 && value3 > 0 ) colorHit3 = 0.33;
                                    }
                                    
                                    *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3));
                                    
                                    colorHit1 = 0;
                                    colorHit2 = 0;
                                    colorHit3 = 0;
                                    
                                    if (hitB == 1){
                                        if (hitMap [2] != 0 && value1 > 0 ) colorHit1 = 1;
                                        if (hitMap [5] != 0 && value2 > 0 ) colorHit2 = 1;
                                        if (hitMap [8] != 0 && value3 > 0 ) colorHit3 = 1;
                                    }
                                    else if (hitB == 2){
                                        if (hitMap [2] != 0 && value1 > 0 ) colorHit1 = 0.5;
                                        if (hitMap [5] != 0 && value2 > 0 ) colorHit2 = 0.5;
                                        if (hitMap [8] != 0 && value3 > 0 ) colorHit3 = 0.5;
                                    }
                                    else if (hitB == 3){
                                        if (hitMap [2] != 0 && value1 > 0 ) colorHit1 = 0.33;
                                        if (hitMap [5] != 0 && value2 > 0 ) colorHit2 = 0.33;
                                        if (hitMap [8] != 0 && value3 > 0 ) colorHit3 = 0.33;
                                    }
                                    
                                    *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3));
                                    *bitmapData++ = 0;
                                }
                            }
                        }
                        
                        delete [] hitMap;
                    }
                }
                else{
                    
                    if (imageBmpTifFlag == 0){
                        unsigned long headPosition = 0;
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                            value0 = uploadTemp [counter1];
                            
                            if (value0 >= 0 && value0 < cutHoldDIC){
                                value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                
                                if (value0 < 0) value0 = 0;
                            }
                            else{
                                
                                value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                
                                if (value0 > 255) value0 = 255;
                            }
                            
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = 0;
                        }
                    }
                    else if (imageBmpTifFlag == 1){
                        for (int counter1 = imageXYLength-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                                value0 = uploadTemp [1078+counter1*imageXYLength+counter2];
                                
                                if (value0 >= 0 && value0 < cutHoldDIC){
                                    value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                    
                                    if (value0 < 0) value0 = 0;
                                }
                                else{
                                    
                                    value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                    
                                    if (value0 > 255) value0 = 255;
                                }
                                
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = 0;
                            }
                        }
                    }
                }
            }
            else if (grayColorStatus == 1){
                int dataConversion [4];
                int endianType = 0;
                
                unsigned long headPosition = 0;
                
                dataConversion [0] = uploadTemp [0];
                dataConversion [1] = uploadTemp [1];
                
                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                else endianType = 0;
                
                headPosition = 0;
                
                if (endianType == 1){
                    dataConversion [0] = uploadTemp [7];
                    dataConversion [1] = uploadTemp [6];
                    dataConversion [2] = uploadTemp [5];
                    dataConversion [3] = uploadTemp [4];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                else if (endianType == 0){
                    dataConversion [0] = uploadTemp [4];
                    dataConversion [1] = uploadTemp [5];
                    dataConversion [2] = uploadTemp [6];
                    dataConversion [3] = uploadTemp [7];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                
                int value0 = 0;
                int value1 = 0;
                int value2 = 0;
                
                for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                    value0 = uploadTemp [counter1];
                    value0 = (int)(value0*(double)levelHoldR);
                    
                    if (value0 > 255) value0 = 255;
                    
                    value1 = uploadTemp [counter1+1];
                    value1 = (int)(value1*(double)levelHoldG);
                    
                    if (value1 > 255) value1 = 255;
                    
                    value2 = uploadTemp [counter1+2];
                    value2 = (int)(value2*(double)levelHoldB);
                    
                    if (value2 > 255) value2 = 255;
                    
                    *bitmapData++ = (unsigned char)value0;
                    *bitmapData++ = (unsigned char)value1;
                    *bitmapData++ = (unsigned char)value2;
                    *bitmapData++ = 0;
                }
            }
        }
        else{
            
            if (refLoadStatus == 1){
                int dataConversion [4];
                int endianType = 0;
                
                unsigned long headPosition = 0;
                
                dataConversion [0] = uploadTempRef [0];
                dataConversion [1] = uploadTempRef [1];
                
                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                else endianType = 0;
                
                if (endianType == 1){
                    dataConversion [0] = uploadTempRef [7];
                    dataConversion [1] = uploadTempRef [6];
                    dataConversion [2] = uploadTempRef [5];
                    dataConversion [3] = uploadTempRef [4];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                else if (endianType == 0){
                    dataConversion [0] = uploadTempRef [4];
                    dataConversion [1] = uploadTempRef [5];
                    dataConversion [2] = uploadTempRef [6];
                    dataConversion [3] = uploadTempRef [7];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                
                int grayColorStatusColor = 0;
                
                if (headPosition-8 == (unsigned long)(imageXYLength*imageXYLength)) grayColorStatusColor = 0;
                else grayColorStatusColor = 1;
                
                if (grayColorStatusColor == 0){
                    int value0 = 0;
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                        value0 = uploadTempRef [counter1];
                        
                        if (value0 >= 0 && value0 < cutHoldDIC){
                            value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                            
                            if (value0 < 0) value0 = 0;
                        }
                        else{
                            
                            value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                            
                            if (value0 > 255) value0 = 255;
                        }
                        
                        if (value0 >= cutHoldDIC){
                            areaValue++;
                            areaTotal = areaTotal+value0;
                        }
                        
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = 0;
                    }
                }
                else if (grayColorStatusColor == 1){
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                        value0 = uploadTempRef [counter1];
                        value0 = (int)(value0*(double)levelHoldR);
                        
                        if (value0 > 255) value0 = 255;
                        
                        if (value0 >= cutHoldDIC){
                            areaValue++;
                            areaTotal = areaTotal+value0;
                        }
                        
                        value1 = uploadTempRef [counter1+1];
                        value1 = (int)(value1*(double)levelHoldG);
                        
                        if (value1 > 255) value1 = 255;
                        
                        value2 = uploadTempRef [counter1+2];
                        value2 = (int)(value2*(double)levelHoldB);
                        
                        if (value2 > 255) value2 = 255;
                        
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value1;
                        *bitmapData++ = (unsigned char)value2;
                        *bitmapData++ = 0;
                    }
                }
            }
            else if (refLoadStatus == 2){
                int dataConversion [4];
                int endianType = 0;
                
                unsigned long headPosition = 0;
                
                dataConversion [0] = uploadTempRef2 [0];
                dataConversion [1] = uploadTempRef2 [1];
                
                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                else endianType = 0;
                
                if (endianType == 1){
                    dataConversion [0] = uploadTempRef2 [7];
                    dataConversion [1] = uploadTempRef2 [6];
                    dataConversion [2] = uploadTempRef2 [5];
                    dataConversion [3] = uploadTempRef2 [4];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                else if (endianType == 0){
                    dataConversion [0] = uploadTempRef2 [4];
                    dataConversion [1] = uploadTempRef2 [5];
                    dataConversion [2] = uploadTempRef2 [6];
                    dataConversion [3] = uploadTempRef2 [7];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                
                int grayColorStatusRef2 = 0;
                
                if (headPosition-8 == (unsigned long)(imageXYLength*imageXYLength)) grayColorStatusRef2 = 0;
                else grayColorStatusRef2 = 1;
                
                if (grayColorStatusRef2 == 0){
                    int value0 = 0;
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                        value0 = uploadTempRef2 [counter1];
                        
                        if (value0 >= 0 && value0 < cutHoldDIC){
                            value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                            
                            if (value0 < 0) value0 = 0;
                        }
                        else{
                            
                            value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                            
                            if (value0 > 255) value0 = 255;
                        }
                        
                        if (value0 >= cutHoldDIC){
                            areaValue++;
                            areaTotal = areaTotal+value0;
                        }
                        
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = 0;
                    }
                }
                else if (grayColorStatusRef2 == 1){
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                        value0 = uploadTempRef2 [counter1];
                        value0 = (int)(value0*(double)levelHoldR);
                        
                        if (value0 > 255) value0 = 255;
                        
                        if (value0 >= cutHoldDIC){
                            areaValue++;
                            areaTotal = areaTotal+value0;
                        }
                        
                        value1 = uploadTempRef2 [counter1+1];
                        value1 = (int)(value1*(double)levelHoldG);
                        
                        if (value1 > 255) value1 = 255;
                        
                        value2 = uploadTempRef2 [counter1+2];
                        value2 = (int)(value2*(double)levelHoldB);
                        
                        if (value2 > 255) value2 = 255;
                        
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value1;
                        *bitmapData++ = (unsigned char)value2;
                        *bitmapData++ = 0;
                    }
                }
            }
            else if (refLoadStatus == 3){
                int dataConversion [4];
                int endianType = 0;
                
                unsigned long headPosition = 0;
                
                dataConversion [0] = uploadTempRef3 [0];
                dataConversion [1] = uploadTempRef3 [1];
                
                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                else endianType = 0;
                
                if (endianType == 1){
                    dataConversion [0] = uploadTempRef3 [7];
                    dataConversion [1] = uploadTempRef3 [6];
                    dataConversion [2] = uploadTempRef3 [5];
                    dataConversion [3] = uploadTempRef3 [4];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                else if (endianType == 0){
                    dataConversion [0] = uploadTempRef3 [4];
                    dataConversion [1] = uploadTempRef3 [5];
                    dataConversion [2] = uploadTempRef3 [6];
                    dataConversion [3] = uploadTempRef3 [7];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                
                int grayColorStatusRef3 = 0;
                
                if (headPosition-8 == (unsigned long)(imageXYLength*imageXYLength)) grayColorStatusRef3 = 0;
                else grayColorStatusRef3 = 1;
                
                if (grayColorStatusRef3 == 0){
                    int value0 = 0;
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                        value0 = uploadTempRef3 [counter1];
                        
                        if (value0 >= 0 && value0 < cutHoldDIC){
                            value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                            
                            if (value0 < 0) value0 = 0;
                        }
                        else{
                            
                            value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                            
                            if (value0 > 255) value0 = 255;
                        }
                        
                        if (value0 >= cutHoldDIC){
                            areaValue++;
                            areaTotal = areaTotal+value0;
                        }
                        
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = 0;
                    }
                }
                else if (grayColorStatusRef3 == 1){
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                        value0 = uploadTempRef3 [counter1];
                        value0 = (int)(value0*(double)levelHoldR);
                        
                        if (value0 > 255) value0 = 255;
                        
                        if (value0 >= cutHoldDIC){
                            areaValue++;
                            areaTotal = areaTotal+value0;
                        }
                        
                        value1 = uploadTempRef3 [counter1+1];
                        value1 = (int)(value1*(double)levelHoldG);
                        
                        if (value1 > 255) value1 = 255;
                        
                        value2 = uploadTempRef3 [counter1+2];
                        value2 = (int)(value2*(double)levelHoldB);
                        
                        if (value2 > 255) value2 = 255;
                        
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value1;
                        *bitmapData++ = (unsigned char)value2;
                        *bitmapData++ = 0;
                    }
                }
            }
        }
        
        movieImage = [[NSImage alloc] initWithSize:NSMakeSize(imageXYLength, imageXYLength)];
        [movieImage addRepresentation:bitmapRepsCR];
        
        if (timePointHold >= 1){
            if (areaDataHoldLimit < timePointHold*25){
                [self arrayAreaDataHoldUpDate];
                
                for (int counter1 = areaDataHoldCount; counter1 < timePointHold*25; counter1++) arrayAreaDataHold [counter1] = 0;
            }
            
            if (arrayAreaDataHold [(timePointHold-1)*25] == 0 || quantitationStatusHold == 1){
                if ((timePointHold-1)*25+25 < areaDataHoldCount){
                    dotNumberCurrent = (int)arrayAreaDataHold [(timePointHold-1)*25+5];
                }
                else dotNumberCurrent = 0;
                
                arrayAreaDataHold [(timePointHold-1)*25] = timePointHold;
                arrayAreaDataHold [(timePointHold-1)*25+1] = cutHoldDIC;
                arrayAreaDataHold [(timePointHold-1)*25+2] = areaValue;
                arrayAreaDataHold [(timePointHold-1)*25+3] = areaTotal;
                arrayAreaDataHold [(timePointHold-1)*25+4] = areaTotal/(double)areaValue;
                arrayAreaDataHold [(timePointHold-1)*25+5] = dotNumberCurrent;
                
                if (areaDataHoldCount < timePointHold*25+25){
                    if (areaDataHoldLimit < timePointHold*25+25){
                        [self arrayAreaDataHoldUpDate];
                    }
                    
                    areaDataHoldCount = timePointHold*25+25;
                }
                
                ofstream oin;
                
                string dataSaveTreatmentPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"AnalysisData";
                
                oin.open(dataSaveTreatmentPath.c_str(), ios::out | ios::binary);
                
                for (int counter1 = 0; counter1 < areaDataHoldCount; counter1++){
                    oin<<to_string(arrayAreaDataHold [counter1])<<endl;
                }
                
                oin.close();
                
                areaValueCall = 1;
            }
        }
        
        if (firstDisplayFlag == 0){
            xPositionDisplay = 0;
            yPositionDisplay = 0;
            xPositionAdjustDisplay = 0;
            yPositionAdjustDisplay = 0;
            magnificationDisplay = 10;
            firstDisplayFlag = 1;
        }
        
        int vertical = 600+78;
        int horizontal = 600;
        
        windowWidthDisplay = imageXYLength/(double)horizontal;
        windowHeightDisplay = imageXYLength/(double)(vertical-78);
        
        xPositionAdjustDisplay = (imageXYLength-imageXYLength/(double)(magnificationDisplay*0.1))/(double)2;
        yPositionAdjustDisplay = (imageXYLength-imageXYLength/(double)(magnificationDisplay*0.1))/(double)2;
        
        if (initialArraySet == 0) initialArraySet = 1;
        
        [self setNeedsDisplay:YES];
    }
}

//----------First Responder----------
-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)mouseDown:(NSEvent *)event{
    if (imageProgressFlag == 0){
        NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDownDisplay = clickPoint.x;
        yPointDownDisplay = clickPoint.y;
        
        if (lineDraw == 1){
            targetCount = 0;
            xPointLine = (int)xPointDownDisplay;
            yPointLine = (int)yPointDownDisplay;
            lineDraw = 2;
        }
        
        [self setNeedsDisplay:YES];
    }
}

-(void)mouseUp:(NSEvent *)event{
    if (imageProgressFlag == 0){
        NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
        
        xPositionDisplay = xPositionDisplay+xPositionMoveDisplay;
        yPositionDisplay = yPositionDisplay+yPositionMoveDisplay;
        xPositionMoveDisplay = 0;
        yPositionMoveDisplay = 0;
        mouseDragFlag = 0;
        
        if (xPositionMoveDisplay < 5 && yPositionMoveDisplay < 5){
            double xPositionAdj = xPositionAdjustDisplay+xPositionDisplay;
            double yPositionAdj = yPositionAdjustDisplay+yPositionDisplay;
            double xCalValue = 1/(double)windowWidthDisplay*magnificationDisplay*0.1;
            double yCalValue = 1/(double)windowHeightDisplay*magnificationDisplay*0.1;
            
            boxXPositionCurrent = (int)(clickPoint.x/(double)xCalValue+xPositionAdj);
            boxYPositionCurrent = (int)((clickPoint.y/(double)yCalValue+yPositionAdj-imageXYLength)*-1);
            
            if (analysisStatusHold == 1){
                if (dotDataHoldLimit < dotDataHoldCount+50) [self arrayDotDataHoldUpDate];
                
                if (dotSetFirstSecondHold == 0) arrayDotDataHold [dotDataHoldCount] = timePointHold, dotDataHoldCount++;
                else if (dotSetFirstSecondHold == 1) arrayDotDataHold [dotDataHoldCount] = timePointHold*-1, dotDataHoldCount++;
                else if (dotSetFirstSecondHold == 2) arrayDotDataHold [dotDataHoldCount] = timePointHold+100000, dotDataHoldCount++;
                else if (dotSetFirstSecondHold == 3) arrayDotDataHold [dotDataHoldCount] = timePointHold*-1-100000, dotDataHoldCount++;
                
                arrayDotDataHold [dotDataHoldCount] = (int)boxXPositionCurrent, dotDataHoldCount++;
                arrayDotDataHold [dotDataHoldCount] = (int)boxYPositionCurrent, dotDataHoldCount++;
                
                dotNumberCurrent++;
                
                ofstream oin;
                
                string dataSaveTreatmentPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"DotData";
                
                oin.open(dataSaveTreatmentPath.c_str(), ios::out | ios::binary);
                
                for (int counter1 = 0; counter1 < dotDataHoldCount; counter1++) oin<<arrayDotDataHold [counter1]<<endl;
                
                oin.close();
                
                arrayAreaDataHold [(timePointHold-1)*25+5] = dotNumberCurrent;
                
                if (areaModeStatusHold == 1){
                    for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                        arrayTimeSelected [counter1*10+9] = 0;
                    }
                    
                    for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                        for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                            if ((int)arrayDotDataHold [counter1*3+2] >= 0 && (int)arrayDotDataHold [counter1*3+2] < imageSizeLimit && (int)arrayDotDataHold [counter1*3+1] >= 0 && (int)arrayDotDataHold [counter1*3+1] < imageSizeLimit){
                                if (arrayTimeSelected [counter2*10+8] == revisedWorkingMap [(int)arrayDotDataHold [counter1*3+2]][(int)arrayDotDataHold [counter1*3+1]]){
                                    arrayTimeSelected [counter2*10+9]++;
                                    break;
                                }
                            }
                        }
                    }
                    
                    subProcesses = [[SubProcesses alloc] init];
                    [subProcesses areaTotalDataSet];
                }
                
                string dataSaveTreatmentPath2 = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"AnalysisData";
                
                oin.open(dataSaveTreatmentPath2.c_str(), ios::out | ios::binary);
                
                for (int counter1 = 0; counter1 < areaDataHoldCount; counter1++){
                    oin<<to_string(arrayAreaDataHold [counter1])<<endl;
                }
                
                oin.close();
                
                areaValueCall = 1;
            }
            else if (analysisStatusHold == 2){
                int matchFind = -1;
                int timeTemp = 0;
                
                for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                    if (arrayDotDataHold [counter1*3] < -100000) timeTemp = arrayDotDataHold [counter1*3]*-1-100000;
                    else if (arrayDotDataHold [counter1*3] < 0 && arrayDotDataHold [counter1*3] >= -100000) timeTemp = arrayDotDataHold [counter1*3]*-1;
                    else if (arrayDotDataHold [counter1*3] >= 0 && arrayDotDataHold [counter1*3] <= 100000) timeTemp = arrayDotDataHold [counter1*3];
                    else if (arrayDotDataHold [counter1*3] > 100000) timeTemp = arrayDotDataHold [counter1*3]-100000;
                    
                    if (timeTemp == timePointHold){
                        if (arrayDotDataHold [counter1*3+1]-10 < (int)boxXPositionCurrent && arrayDotDataHold [counter1*3+1]+10 > (int)boxXPositionCurrent && arrayDotDataHold [counter1*3+2]-10 < (int)boxYPositionCurrent && arrayDotDataHold [counter1*3+2]+10 > (int)boxYPositionCurrent){
                            matchFind = counter1;
                            break;
                        }
                    }
                }
                
                if (matchFind != -1){
                    int *arrayDotDataHoldTemp = new int [dotDataHoldCount+10];
                    int dotDataHoldCountTemp = 0;
                    
                    for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                        if (counter1 != matchFind){
                            arrayDotDataHoldTemp [dotDataHoldCountTemp] = arrayDotDataHold [counter1*3], dotDataHoldCountTemp++;
                            arrayDotDataHoldTemp [dotDataHoldCountTemp] = arrayDotDataHold [counter1*3+1], dotDataHoldCountTemp++;
                            arrayDotDataHoldTemp [dotDataHoldCountTemp] = arrayDotDataHold [counter1*3+2], dotDataHoldCountTemp++;
                        }
                    }
                    
                    dotDataHoldCount = 0;
                    
                    for (int counter1 = 0; counter1 < dotDataHoldCountTemp; counter1++) arrayDotDataHold [dotDataHoldCount] = arrayDotDataHoldTemp [counter1], dotDataHoldCount++;
                    
                    delete [] arrayDotDataHoldTemp;
                    
                    dotNumberCurrent--;
                    
                    ofstream oin;
                    
                    string dataSaveTreatmentPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"DotData";
                    
                    oin.open(dataSaveTreatmentPath.c_str(), ios::out | ios::binary);
                    
                    for (int counter1 = 0; counter1 < dotDataHoldCount; counter1++) oin<<arrayDotDataHold [counter1]<<endl;
                    
                    oin.close();
                    
                    arrayAreaDataHold [(timePointHold-1)*25+5] = dotNumberCurrent;
                    
                    if (areaModeStatusHold == 1){
                        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                            arrayTimeSelected [counter1*10+9] = 0;
                        }
                        
                        for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                            for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                                if ((int)arrayDotDataHold [counter1*3+2] >= 0 && (int)arrayDotDataHold [counter1*3+2] < imageSizeLimit && (int)arrayDotDataHold [counter1*3+1] >= 0 && (int)arrayDotDataHold [counter1*3+1] < imageSizeLimit){
                                    if (arrayTimeSelected [counter2*10+8] == revisedWorkingMap [(int)arrayDotDataHold [counter1*3+2]][(int)arrayDotDataHold [counter1*3+1]]){
                                        arrayTimeSelected [counter2*10+9]++;
                                        break;
                                    }
                                }
                            }
                        }
                        
                        subProcesses = [[SubProcesses alloc] init];
                        [subProcesses areaTotalDataSet];
                    }
                    
                    string dataSaveTreatmentPath2 = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"AnalysisData";
                    
                    oin.open(dataSaveTreatmentPath2.c_str(), ios::out | ios::binary);
                    
                    for (int counter1 = 0; counter1 < areaDataHoldCount; counter1++){
                        oin<<to_string(arrayAreaDataHold [counter1])<<endl;
                    }
                    
                    oin.close();
                    
                    areaValueCall = 1;
                }
            }
            
            if (areaModeStatusHold == 1){
                int xPointMarkTemp = (int)(clickPoint.x/(double)xCalValue+xPositionAdj);
                int yPointMarkTemp = (int)((clickPoint.y/(double)yCalValue+yPositionAdj-imageXYLength)*-1);
                
                if (yPointMarkTemp >= 0 && yPointMarkTemp < imageXYLength && xPointMarkTemp >= 0 && xPointMarkTemp < imageXYLength){
                    currentConnectNo = revisedWorkingMap [yPointMarkTemp][xPointMarkTemp];
                    
                    if (timeOneQuickSet != 0 && currentConnectNo != 0){
                        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                            if (arrayTimeSelected [counter1*10+8] == currentConnectNo){
                                if (timeOneQuickSet == 2) arrayTimeSelected [counter1*10] = 1;
                                else if (timeOneQuickSet == 3) arrayTimeSelected [counter1*10] = 0;
                                else if (timeOneQuickSet == 4) arrayTimeSelected [counter1*10] = 10;
                                else if (timeOneQuickSet == 5) arrayTimeSelected [counter1*10] = 11;
                                
                                break;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                            if (arrayPositionRevise [counter1*7+3] == currentConnectNo && (arrayPositionRevise [counter1*7+5] == 0 || arrayPositionRevise [counter1*7+5] == 1)){
                                arrayPositionRevise [counter1*7+6] = currentConnectNo;
                                
                                if (timeOneQuickSet == 2) arrayPositionRevise [counter1*7+5] = 1;
                                else if (timeOneQuickSet == 3) arrayPositionRevise [counter1*7+5] = 0;
                                else if (timeOneQuickSet == 4) arrayPositionRevise [counter1*7+5] = 1;
                                else if (timeOneQuickSet == 5) arrayPositionRevise [counter1*7+5] = 1;
                                
                                arrayPositionRevise [counter1*7+4] = 0;
                            }
                        }
                    }
                }
            }
        }
        
        if (lineDraw == 2){
            lineDraw = 1;
            xPointLine = (int)clickPoint.x;
            yPointLine = (int)clickPoint.y;
        }
        
        [self setNeedsDisplay:YES];
    }
}

-(void)mouseDragged:(NSEvent *)event{
    if (imageProgressFlag == 0){
        NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
        
        if (windowLock == 0){
            xPointDragDisplay = clickPoint.x;
            yPointDragDisplay = clickPoint.y;
            xPositionMoveDisplay = (xPointDownDisplay-xPointDragDisplay)*windowWidthDisplay/(double)(magnificationDisplay*0.1);
            yPositionMoveDisplay = (yPointDownDisplay-yPointDragDisplay)*windowHeightDisplay/(double)(magnificationDisplay*0.1);
            mouseDragFlag = 1;
        }
        
        if (lineDraw == 2){
            xPointLine = (int)clickPoint.x;
            yPointLine = (int)clickPoint.y;
        }
        
        [self setNeedsDisplay:YES];
    }
}

-(void)keyDown:(NSEvent *)event{
    int keyCode = [event keyCode];
    int proceedFlag = 0;
    
    if (keyCode == 124 && movieRunningFlag == 0 && areaModeStatusHold == 0 && imageProgressFlag == 0){
        filePosition++;
        
        if (maxImageNo < filePosition) filePosition--;
        
        string timeDisplayTemp = fileList [(filePosition-1)*7];
        timeDisplayTemp = timeDisplayTemp.substr(8, 4);
        
        int currentTime = timePointHold;
        
        timePointHold = atoi(timeDisplayTemp.c_str());
        
        if ((timePointHold-1)*25+25 < areaDataHoldCount){
            boxXLength = (int)(arrayAreaDataHold [(timePointHold-1)*25+6]);
            boxYLength = (int)(arrayAreaDataHold [(timePointHold-1)*25+7]);
            boxXPosition = arrayAreaDataHold [(timePointHold-1)*25+8];
            boxYPosition = arrayAreaDataHold [(timePointHold-1)*25+9];
            
            dotNumberCurrent = (int)arrayAreaDataHold [(timePointHold-1)*25+5];
        }
        else{
            
            boxXLength = 0;
            boxYLength = 0;
            boxXPosition = 0;
            boxYPosition = 0;
            dotNumberCurrent = 0;
        }
        
        if (boxXLength != 0 && boxYLength != 0) boxDisplayCall = 1;
        else boxDisplayCall = 2;
        
        if (areaSetDone == 1){
            areaSetDone = 0;
            trackingDataSave = [[TrackingDataSave alloc] init];
            [trackingDataSave trackingDataSaveTemp:currentTime];
        }
        
        proceedFlag = 1;
        timePointDisplayCall = 1;
    }
    
    if (keyCode == 123 && movieRunningFlag == 0 && areaModeStatusHold == 0 && imageProgressFlag == 0){
        filePosition--;
        
        if (filePosition <= 0) filePosition = 1;
        
        string timeDisplayTemp = fileList [(filePosition-1)*7];
        timeDisplayTemp = timeDisplayTemp.substr(8, 4);
        
        int currentTime = timePointHold;
        
        timePointHold = atoi(timeDisplayTemp.c_str());
        
        if ((timePointHold-1)*25+25 < areaDataHoldCount){
            boxXLength = (int)(arrayAreaDataHold [(timePointHold-1)*25+6]);
            boxYLength = (int)(arrayAreaDataHold [(timePointHold-1)*25+7]);
            boxXPosition = arrayAreaDataHold [(timePointHold-1)*25+8];
            boxYPosition = arrayAreaDataHold [(timePointHold-1)*25+9];
            
            dotNumberCurrent = (int)arrayAreaDataHold [(timePointHold-1)*25+5];
        }
        else{
            
            boxXLength = 0;
            boxYLength = 0;
            boxXPosition = 0;
            boxYPosition = 0;
            
            dotNumberCurrent = 0;
        }
        
        if (boxXLength != 0 && boxYLength != 0) boxDisplayCall = 1;
        else boxDisplayCall = 2;
        
        dotNumberCurrent = 0;
        int timeTemp = 0;
        
        for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
            if (arrayDotDataHold [counter1*3] < -100000) timeTemp = arrayDotDataHold [counter1*3]*-1-100000;
            else if (arrayDotDataHold [counter1*3] < 0 && arrayDotDataHold [counter1*3] >= -100000) timeTemp = arrayDotDataHold [counter1*3]*-1;
            else if (arrayDotDataHold [counter1*3] >= 0 && arrayDotDataHold [counter1*3] <= 100000) timeTemp = arrayDotDataHold [counter1*3];
            else if (arrayDotDataHold [counter1*3] > 100000) timeTemp = arrayDotDataHold [counter1*3]-100000;
            
            if (timeTemp == timePointHold) dotNumberCurrent++;
        }
        
        if (areaSetDone== 1){
            areaSetDone = 0;
            trackingDataSave = [[TrackingDataSave alloc] init];
            [trackingDataSave trackingDataSaveTemp:currentTime];
        }
        
        proceedFlag = 1;
        timePointDisplayCall = 1;
    }
    
    //------Magnification Magnify------
    if (keyCode == 125 && imageProgressFlag == 0){
        if (magnificationDisplay >= 10 && magnificationDisplay <= 350){
            if (magnificationDisplay-10 < 10) magnificationDisplay = 10;
            else magnificationDisplay = magnificationDisplay-10;
            
            xPositionAdjustDisplay = -1*(imageXYLength/(double)(magnificationDisplay*0.1)-imageXYLength)/(double)2;
            yPositionAdjustDisplay = -1*(imageXYLength/(double)(magnificationDisplay*0.1)-imageXYLength)/(double)2;
            
            [self setNeedsDisplay:YES];
        }
    }
    
    //------MagnificationReduction------
    if (keyCode == 126 && imageProgressFlag == 0){
        if (magnificationDisplay >= 10 && magnificationDisplay <= 498){
            if (magnificationDisplay+10 > 498) magnificationDisplay = 498;
            else magnificationDisplay = magnificationDisplay+10;
            
            xPositionAdjustDisplay = (imageXYLength-imageXYLength/(double)(magnificationDisplay*0.1))/(double)2;
            yPositionAdjustDisplay = (imageXYLength-imageXYLength/(double)(magnificationDisplay*0.1))/(double)2;
            
            [self setNeedsDisplay:YES];
        }
    }
    
    //------Magnification space bar------
    if (keyCode == 49 && imageProgressFlag == 0){
        magnificationDisplay = (int)(200/((double)(50/(double)imageXYLength)*600)*10);
        xPositionAdjustDisplay = (imageXYLength-imageXYLength/(double)(magnificationDisplay*0.1))/(double)2;
        yPositionAdjustDisplay = (imageXYLength-imageXYLength/(double)(magnificationDisplay*0.1))/(double)2;
        
        [self setNeedsDisplay:YES];
    }
    
    //------Track Target "S"------
    if (keyCode == 1 && areaModeStatusHold == 1 && imageProgressFlag == 0 && lineFontShowOnOff == 0){
        if (currentConnectNo != 0){
            int connectCheck = arrayTimeSelected[(currentConnectNo-1)*10];
            int startPosition = 0;
            
            if (connectCheck == 0 || connectCheck == 1 || connectCheck == 10 || connectCheck == 11){
                startPosition = 0;
                
                for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                    if (arrayTimeSelected [counter1*10+8] == currentConnectNo){
                        arrayTimeSelected [counter1*10] = 1;
                        startPosition = arrayTimeSelected [counter1*10+2];
                        break;
                    }
                }
                
                for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                    if (arrayPositionRevise [counter1*7+3] == currentConnectNo){
                        arrayPositionRevise [counter1*7+6] = currentConnectNo;
                        arrayPositionRevise [counter1*7+5] = 1;
                        arrayPositionRevise [counter1*7+4] = 0;
                    }
                    else{
                        
                        break;
                    }
                }
                
                timeOneQuickSet = 2;
                
                [self setNeedsDisplay:YES];
            }
        }
    }
    
    //------Exclude "Y"------
    if (keyCode == 16 && areaModeStatusHold == 1 && imageProgressFlag == 0 && lineFontShowOnOff == 0){
        if (currentConnectNo != 0){
            int connectCheck = arrayTimeSelected[(currentConnectNo-1)*10];
            int startPosition = 0;
            
            if (connectCheck == 0 || connectCheck == 1 || connectCheck == 2 || connectCheck == 10 || connectCheck == 11){
                startPosition = 0;
                
                for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                    if (arrayTimeSelected [counter1*10+8] == currentConnectNo){
                        arrayTimeSelected [counter1*10] = 0;
                        startPosition = arrayTimeSelected [counter1*10+2];
                        break;
                    }
                }
                
                for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                    if (arrayPositionRevise [counter1*7+3] == currentConnectNo){
                        arrayPositionRevise [counter1*7+6] = currentConnectNo;
                        arrayPositionRevise [counter1*7+5] = 0;
                        arrayPositionRevise [counter1*7+4] = 0;
                    }
                    else{
                        
                        break;
                    }
                }
                
                timeOneQuickSet = 3;
                
                [self setNeedsDisplay:YES];
            }
        }
    }
    
    //------Track Target "T"------
    if (keyCode == 17 && areaModeStatusHold == 1 && imageProgressFlag == 0 && lineFontShowOnOff == 0){
        if (currentConnectNo != 0){
            int connectCheck = arrayTimeSelected[(currentConnectNo-1)*10];
            int startPosition = 0;
            
            if (connectCheck == 0 || connectCheck == 1 || connectCheck == 2 || connectCheck == 10 || connectCheck == 11){
                startPosition = 0;
                
                for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                    if (arrayTimeSelected [counter1*10+8] == currentConnectNo){
                        arrayTimeSelected [counter1*10] = 10;
                        startPosition = arrayTimeSelected [counter1*10+2];
                        break;
                    }
                }
                
                for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                    if (arrayPositionRevise [counter1*7+3] == currentConnectNo){
                        arrayPositionRevise [counter1*7+6] = currentConnectNo;
                        arrayPositionRevise [counter1*7+5] = 1;
                        arrayPositionRevise [counter1*7+4] = 0;
                    }
                    else{
                        
                        break;
                    }
                }
                
                timeOneQuickSet = 4;
                
                [self setNeedsDisplay:YES];
            }
        }
    }
    
    //------Track Target "Q"------
    if (keyCode == 12 && areaModeStatusHold == 1 && imageProgressFlag == 0 && lineFontShowOnOff == 0){
        if (currentConnectNo != 0){
            int connectCheck = arrayTimeSelected[(currentConnectNo-1)*10];
            int startPosition = 0;
            
            if (connectCheck == 0 || connectCheck == 1 || connectCheck == 2 || connectCheck == 10 || connectCheck == 11){
                startPosition = 0;
                
                for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                    if (arrayTimeSelected [counter1*10+8] == currentConnectNo){
                        arrayTimeSelected [counter1*10] = 11;
                        startPosition = arrayTimeSelected [counter1*10+2];
                        break;
                    }
                }
                
                for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                    if (arrayPositionRevise [counter1*7+3] == currentConnectNo){
                        arrayPositionRevise [counter1*7+6] = currentConnectNo;
                        arrayPositionRevise [counter1*7+5] = 1;
                        arrayPositionRevise [counter1*7+4] = 0;
                    }
                    else{
                        
                        break;
                    }
                }
                
                timeOneQuickSet = 5;
                
                [self setNeedsDisplay:YES];
            }
        }
    }
    
    //------Group Check "G"------
    if (keyCode == 5 && areaModeStatusHold == 1 && imageProgressFlag == 0 && lineFontShowOnOff == 0){
        int typeSet = 2;
        targetFind2 = [[TargetFind2 alloc] init];
        [targetFind2 interpretationFirst:typeSet];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [self setNeedsDisplay:YES];
    }
    
    //------Line/Area Lock release "3"------
    if (keyCode == 20 && areaModeStatusHold == 1 && imageProgressFlag == 0 && lineFontShowOnOff == 0){
        if (lineDraw == 1){
            lineDraw = 0;
            windowLock = 0;
        }
        
        [self setNeedsDisplay:YES];
    }
    
    //------Merge Group Local "M"------
    if (keyCode == 46 && areaModeStatusHold == 1 && imageProgressFlag == 0 && lineFontShowOnOff == 0){
        if (currentConnectNo != 0){
            int connectCheck = arrayTimeSelected[(currentConnectNo-1)*10];
            
            if (connectCheck == 0 || connectCheck == 1 || connectCheck == 2 || connectCheck == 10 || connectCheck == 11){
                int connectFindNumber = 0;
                int groupNoTemp = groupNumberList [currentConnectNo];
                
                for (int counter1 = 1; counter1 < groupNumberListCount; counter1++){
                    if (groupNumberList [counter1] == groupNoTemp || groupNumberList [counter1] == groupNoTemp*-1) connectFindNumber++;
                }
                
                if (connectFindNumber > 1){
                    merge = [[Merge alloc] init];
                    [merge mergeMain:groupNoTemp:connectFindNumber];
                    
                    int lineDrawStatus = 0;
                    
                    if (lineDraw == 0){
                        lineDraw = 1;
                        lineDrawStatus = 1;
                    }
                    
                    mergeOperationStatus = 1;
                    
                    int processType = 2;
                    lineSet = [[LineSet alloc] init];
                    [lineSet lineSetProcess:processType];
                    
                    if (lineDrawStatus == 1) lineDraw = 0;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    [self setNeedsDisplay:YES];
                }
            }
        }
    }
    
    //------Merge Group All "N"------
    if (keyCode == 45 && areaModeStatusHold == 1 && imageProgressFlag == 0 && lineFontShowOnOff == 0){
        imageProgressFlag = 1;
        mergeProcessingFlag = 1;
    }
    
    //------Merge Connect "C"------
    if (keyCode == 8 && areaModeStatusHold == 1 && imageProgressFlag == 0 && lineFontShowOnOff == 0){
        if (currentConnectNo != 0){
            int connectCheck = arrayTimeSelected[(currentConnectNo-1)*10];
            
            if (connectCheck == 0 || connectCheck == 1 || connectCheck == 2 || connectCheck == 10 || connectCheck == 11){
                if (currentConnectNo != 0){
                    int lineDrawStatus = 0;
                    
                    if (lineDraw == 0){
                        lineDraw = 1;
                        lineDrawStatus = 1;
                    }
                    
                    merge = [[Merge alloc] init];
                    [merge mergeConnect];
                    
                    if (referenceLineCount != 0){
                        mergeOperationStatus = 1;
                        int processType = 2;
                        lineSet = [[LineSet alloc] init];
                        [lineSet lineSetProcess:processType];
                    }
                    
                    if (lineDrawStatus == 1) lineDraw = 0;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    [self setNeedsDisplay:YES];
                }
            }
        }
    }
    
    //------Merge Attach "H"------
    if (keyCode == 4 && areaModeStatusHold == 1 && imageProgressFlag == 0 && lineFontShowOnOff == 0){
        if (currentConnectNo != 0){
            int connectCheck = arrayTimeSelected[(currentConnectNo-1)*10];
            
            if (connectCheck == 0 || connectCheck == 1 || connectCheck == 2 || connectCheck == 10 || connectCheck == 11){
                merge = [[Merge alloc] init];
                int mergeResult = [merge mergeAttach];
                
                if (mergeResult != 0){
                    int lineDrawStatus = 0;
                    
                    if (lineDraw == 0){
                        lineDraw = 1;
                        lineDrawStatus = 1;
                    }
                    
                    mergeOperationStatus = 1;
                    int processType = 2;
                    lineSet = [[LineSet alloc] init];
                    [lineSet lineSetProcess:processType];
                    
                    if (lineDrawStatus == 1) lineDraw = 0;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    [self setNeedsDisplay:YES];
                }
            }
        }
    }
    
    //--------Position to the first F--------
    if (keyCode == 3 && areaModeStatusHold == 1 && imageProgressFlag == 0 && lineFontShowOnOff == 0){
        if (currentPositionSet > 0){
            currentPositionSet = 1;
            
            if (arrayTimeSelected [0] == 0 || arrayTimeSelected [0] == 1 || arrayTimeSelected [0] == 2 || arrayTimeSelected [0] == 10 || arrayTimeSelected [0] == 11){
                currentConnectNo = currentPositionSet;
            }
            else currentConnectNo = 0;
            
            for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                if (arrayGravityCenterRev [counter1*6+4] == currentPositionSet){
                    xPositionDisplay = arrayGravityCenterRev [counter1*6]-imageXYLength/2;
                    yPositionDisplay = (imageXYLength-arrayGravityCenterRev [counter1*6+1])-imageXYLength/2;
                    break;
                }
            }
            
            proceedFlag = 1;
        }
    }
    
    //--------Position to the last E--------
    if (keyCode == 14 && areaModeStatusHold == 1 && imageProgressFlag == 0 && lineFontShowOnOff == 0){
        if (currentPositionSet > 0){
            currentPositionSet = timeSelectedCount/10;
            
            if (arrayTimeSelected [(currentPositionSet-1)] == 0 || arrayTimeSelected [(currentPositionSet-1)] == 1 || arrayTimeSelected [(currentPositionSet-1)] == 2 || arrayTimeSelected [(currentPositionSet-1)] == 10 || arrayTimeSelected [(currentPositionSet-1)] == 11){
                currentConnectNo = currentPositionSet;
            }
            else currentConnectNo = 0;
            
            for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                if (arrayGravityCenterRev [counter1*6+4] == currentPositionSet){
                    xPositionDisplay = arrayGravityCenterRev [counter1*6]-imageXYLength/2;
                    yPositionDisplay = (imageXYLength-arrayGravityCenterRev [counter1*6+1])-imageXYLength/2;
                    break;
                }
            }
            
            proceedFlag = 1;
        }
    }
    
    //------Connect Back Time One------
    if (keyCode == 123 && movieRunningFlag == 0 && areaModeStatusHold == 1 && imageProgressFlag == 0){
        if (currentPositionSet > 0){
            int connectFind = 0;
            
            for (int counter1 = timeSelectedCount/10-1; counter1 >= 0; counter1--){
                if (arrayTimeSelected [counter1*10+8] < currentPositionSet){
                    if (arrayTimeSelected [counter1*10] == 0 || arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 2 || arrayTimeSelected [counter1*10] == 10 || arrayTimeSelected [counter1*10] == 11){
                        currentPositionSet = arrayTimeSelected [counter1*10+8];
                        currentConnectNo = currentPositionSet;
                        
                        connectFind = 1;
                        break;
                    }
                    else currentConnectNo = 0;
                }
            }
            
            if (connectFind == 1){
                for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                    if (arrayGravityCenterRev [counter1*6+4] == currentPositionSet){
                        xPositionDisplay = arrayGravityCenterRev [counter1*6]-imageXYLength/2;
                        yPositionDisplay = (imageXYLength-arrayGravityCenterRev [counter1*6+1])-imageXYLength/2;
                        break;
                    }
                }
                
                [self setNeedsDisplay:YES];
            }
        }
    }
    
    //------Connect Forward------
    if (keyCode == 124 && movieRunningFlag == 0 && areaModeStatusHold == 1 && imageProgressFlag == 0){
        if (currentPositionSet > 0){
            int connectFind = 0;
            
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                if (arrayTimeSelected [counter1*10+8] > currentPositionSet){
                    if (arrayTimeSelected [counter1*10] == 0 || arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 2 || arrayTimeSelected [counter1*10] == 10 || arrayTimeSelected [counter1*10] == 11){
                        currentPositionSet = arrayTimeSelected [counter1*10+8];
                        currentConnectNo = currentPositionSet;
                        
                        connectFind = 1;
                        break;
                    }
                    else currentConnectNo = 0;
                }
            }
            
            if (connectFind == 1){
                for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                    if (arrayGravityCenterRev [counter1*6+4] == currentPositionSet){
                        xPositionDisplay = arrayGravityCenterRev [counter1*6]-imageXYLength/2;
                        yPositionDisplay = (imageXYLength-arrayGravityCenterRev [counter1*6+1])-imageXYLength/2;
                        break;
                    }
                }
                
                [self setNeedsDisplay:YES];
            }
        }
    }
    
    //------Line set short cut "1"------
    if (keyCode == 18 && areaModeStatusHold == 1 && imageProgressFlag == 0 && lineFontShowOnOff == 0){
        saveShortCutNumber = 2;
    }
    
    //------Line set short cut "2"------
    if (keyCode == 19 && areaModeStatusHold == 1 && imageProgressFlag == 0 && lineFontShowOnOff == 0){
        saveShortCutNumber = 4;
    }
    
    //------Line set short cut "5"------
    if (keyCode == 23 && quantitationStatusHold == 1 && imageProgressFlag == 0 && lineFontShowOnOff == 0){
        saveShortCutNumber = 5;
    }
    
    //------Line set short cut "6"------
    if (keyCode == 22 && quantitationStatusHold == 1 && imageProgressFlag == 0 && lineFontShowOnOff == 0){
        saveShortCutNumber = 6;
    }
    
    //------Line set short cut "7"------
    if (keyCode == 26 && quantitationStatusHold == 1 && imageProgressFlag == 0 && lineFontShowOnOff == 0){
        saveShortCutNumber = 7;
    }
    
    //------Line set short cut "8"------
    if (keyCode == 28 && quantitationStatusHold == 1 && imageProgressFlag == 0 && lineFontShowOnOff == 0){
        saveShortCutNumber = 9;
    }
    
    //------Line set short cut "9"------
    if (keyCode == 25 && quantitationStatusHold == 1 && imageProgressFlag == 0 && lineFontShowOnOff == 0){
        saveShortCutNumber = 10;
    }
    
    //------Line set short cut "0"------
    if (keyCode == 29 && quantitationStatusHold == 1 && imageProgressFlag == 0 && lineFontShowOnOff == 0){
        saveShortCutNumber = 11;
    }
    
    //------Line set short cut "-"------
    if (keyCode == 27 && quantitationStatusHold == 1 && imageProgressFlag == 0 && lineFontShowOnOff == 0){
        saveShortCutNumber = 12;
    }
    
    //------Line text visible------
    if (keyCode == 9 && areaModeStatusHold == 1 && imageProgressFlag == 0){
        if (lineFontShowOnOff == 0) lineFontShowOnOff = 1;
        else lineFontShowOnOff = 0;
        
        proceedFlag = 1;
    }
    
    //------Jump specific time point------
    if (keyCode == 38 && areaModeStatusHold == 0 && imageProgressFlag == 0 && lineFontShowOnOff == 0){
        saveShortCutNumber = 8;
    }
    else{
        
        if (keyCode == 38 && (areaModeStatusHold == 1 || imageProgressFlag == 1)){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Area Mode On or Coping In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    
    if (proceedFlag == 1){
        int areaValue = 0;
        double areaTotal = 0;
        
        NSBitmapImageRep *bitmapRepsCR = nil;
        bitmapRepsCR = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageXYLength pixelsHigh:imageXYLength bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageXYLength*4 bitsPerPixel:32];
        
        unsigned char *bitmapData = [bitmapRepsCR bitmapData];
        
        if (phaseStatus == 0){
            string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7];
            
            if (statusHoldDIC == 1){
                if (filePosition > lastDICImageTime){
                    imageMoviePath = imageDisplayPath+"/"+fileList [(lastDICImageTime-1)*7];
                }
            }
            
            ifstream fin;
            
            fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                fin.read((char*)uploadTemp, uploadTempFileSize+50);
                fin.close();
            }
            
            if (fileList [(filePosition-1)*7+1] != ""){
                colorFlag1 = 1;
                colorFlag2 = 0;
                colorFlag3 = 0;
                colorFlag4 = 0;
                colorFlag5 = 0;
                colorFlag6 = 0;
                
                unsigned long findString = fileList [(filePosition-1)*7+1].find("tif");
                if ((int)findString == -1) findString = fileList [(filePosition-1)*7+1].find("TIF");
                if ((int)findString == -1) findString = fileList [(filePosition-1)*7+1].find("bmp");
                if ((int)findString == -1) findString = fileList [(filePosition-1)*7+1].find("BMP");
                
                colorNo1 = fileList [(filePosition-1)*7+1].substr(13, 1);
                colorName1 = fileList [(filePosition-1)*7+1].substr(15, findString-16);
                
                imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+1];
                
                if (uploadTempStatusCl1 == 1) delete [] uploadTempCl1;
                
                uploadTempCl1 = new uint8_t [uploadTempFileSize+50];
                uploadTempStatusCl1 = 1;
                
                fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                
                fin.read((char*)uploadTempCl1, (long)uploadTempFileSize+50);
                fin.close();
                
                if (fileList [(filePosition-1)*7+2] != ""){
                    colorFlag2 = 1;
                    
                    findString = fileList [(filePosition-1)*7+2].find("tif");
                    if ((int)findString == -1) findString = fileList [(filePosition-1)*7+2].find("TIF");
                    if ((int)findString == -1) findString = fileList [(filePosition-1)*7+2].find("bmp");
                    if ((int)findString == -1) findString = fileList [(filePosition-1)*7+2].find("BMP");
                    
                    colorNo2 = fileList [(filePosition-1)*7+2].substr(13, 1);
                    colorName2 = fileList [(filePosition-1)*7+2].substr(15, findString-16);
                    
                    imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+2];
                    
                    if (uploadTempStatusCl2 == 1) delete [] uploadTempCl2;
                    
                    uploadTempCl2 = new uint8_t [uploadTempFileSize+50];
                    uploadTempStatusCl2 = 1;
                    
                    fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                    
                    fin.read((char*)uploadTempCl2, (long)uploadTempFileSize+50);
                    fin.close();
                    
                    if (fileList [(filePosition-1)*7+3] != ""){
                        colorFlag3 = 1;
                        
                        findString = fileList [(filePosition-1)*7+3].find("tif");
                        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+3].find("TIF");
                        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+3].find("bmp");
                        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+3].find("BMP");
                        
                        colorNo3 = fileList [(filePosition-1)*7+3].substr(13, 1);
                        colorName3 = fileList [(filePosition-1)*7+3].substr(15, findString-16);
                        
                        imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+3];
                        
                        if (uploadTempStatusCl3 == 1) delete [] uploadTempCl3;
                        
                        uploadTempCl3 = new uint8_t [uploadTempFileSize+50];
                        uploadTempStatusCl3 = 1;
                        
                        fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                        
                        fin.read((char*)uploadTempCl3, (long)uploadTempFileSize+50);
                        fin.close();
                        
                        if (fileList [(filePosition-1)*7+4] != ""){
                            colorFlag4 = 1;
                            
                            findString = fileList [(filePosition-1)*7+4].find("tif");
                            if ((int)findString == -1) findString = fileList [(filePosition-1)*7+4].find("TIF");
                            if ((int)findString == -1) findString = fileList [(filePosition-1)*7+4].find("bmp");
                            if ((int)findString == -1) findString = fileList [(filePosition-1)*7+4].find("BMP");
                            
                            colorNo4 = fileList [(filePosition-1)*7+4].substr(13, 1);
                            colorName4 = fileList [(filePosition-1)*7+4].substr(15, findString-16);
                            
                            imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+4];
                            
                            if (uploadTempStatusCl4 == 1) delete [] uploadTempCl4;
                            
                            uploadTempCl4 = new uint8_t [uploadTempFileSize+50];
                            uploadTempStatusCl4 = 1;
                            
                            fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                            
                            fin.read((char*)uploadTempCl4, (long)uploadTempFileSize+50);
                            fin.close();
                            
                            if (fileList [(filePosition-1)*7+5] != ""){
                                colorFlag5 = 1;
                                
                                findString = fileList [(filePosition-1)*7+5].find("tif");
                                if ((int)findString == -1) findString = fileList [(filePosition-1)*7+5].find("TIF");
                                if ((int)findString == -1) findString = fileList [(filePosition-1)*7+5].find("bmp");
                                if ((int)findString == -1) findString = fileList [(filePosition-1)*7+5].find("BMP");
                                
                                colorNo5 = fileList [(filePosition-1)*7+5].substr(13, 1);
                                colorName5 = fileList [(filePosition-1)*7+5].substr(15, findString-16);
                                
                                imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+5];
                                
                                if (uploadTempStatusCl5 == 1) delete [] uploadTempCl5;
                                
                                uploadTempCl5 = new uint8_t [uploadTempFileSize+50];
                                uploadTempStatusCl5 = 1;
                                
                                fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                                
                                fin.read((char*)uploadTempCl5, (long)uploadTempFileSize+50);
                                fin.close();
                                
                                if (fileList [(filePosition-1)*7+6] != ""){
                                    colorFlag6 = 1;
                                    
                                    findString = fileList [(filePosition-1)*7+6].find("tif");
                                    if ((int)findString == -1) findString = fileList [(filePosition-1)*7+6].find("TIF");
                                    if ((int)findString == -1) findString = fileList [(filePosition-1)*7+6].find("bmp");
                                    if ((int)findString == -1) findString = fileList [(filePosition-1)*7+6].find("BMP");
                                    
                                    colorNo6 = fileList [(filePosition-1)*7+6].substr(13, 1);
                                    colorName6 = fileList [(filePosition-1)*7+6].substr(15, findString-16);
                                    
                                    imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+6];
                                    
                                    if (uploadTempStatusCl6 == 1) delete [] uploadTempCl6;
                                    
                                    uploadTempCl6 = new uint8_t [uploadTempFileSize+50];
                                    uploadTempStatusCl6 = 1;
                                    
                                    fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                                    
                                    fin.read((char*)uploadTempCl6, (long)uploadTempFileSize+50);
                                    fin.close();
                                }
                            }
                        }
                    }
                }
                
                colorInfoDisplayCall = 1;
            }
            else{
                
                if (colorFlag1 != 0){
                    colorFlag1 = 0;
                    colorFlag2 = 0;
                    colorFlag3 = 0;
                    colorFlag4 = 0;
                    colorFlag5 = 0;
                    colorFlag6 = 0;
                    
                    colorInfoDisplayCall = 1;
                }
            }
            
            if (grayColorStatus == 0){
                int value0 = 0;
                int value1 = 0;
                int value2 = 0;
                int value3 = 0;
                int value4 = 0;
                int value5 = 0;
                int value6 = 0;
                
                int dataConversion [4];
                int endianType = 0;
                
                double colorHit1 = 0;
                double colorHit2 = 0;
                double colorHit3 = 0;
                double colorHit4 = 0;
                double colorHit5 = 0;
                double colorHit6 = 0;
                
                int hitR = 0;
                int hitG = 0;
                int hitB = 0;
                
                if (statusHold1 != 0 || statusHold2 != 0 || statusHold3 != 0 || statusHold4 != 0 || statusHold5 != 0 || statusHold6 != 0){
                    if (imageBmpTifFlag == 0){
                        double *hitMap = new double [20];
                        
                        if (colorNo1 == "1"){
                            hitMap [0] = 0;
                            hitMap [1] = 0;
                            hitMap [2] = 1;
                        }
                        else if (colorNo1 == "2"){
                            hitMap [0] = 0;
                            hitMap [1] = 1;
                            hitMap [2] = 0;
                        }
                        else if (colorNo1 == "3"){
                            hitMap [0] = 1;
                            hitMap [1] = 1;
                            hitMap [2] = 0;
                        }
                        else if (colorNo1 == "4"){
                            hitMap [0] = 1;
                            hitMap [1] = 0;
                            hitMap [2] = 0;
                        }
                        else if (colorNo1 == "5"){
                            hitMap [0] = 1;
                            hitMap [1] = 0;
                            hitMap [2] = 1;
                        }
                        else if (colorNo1 == "6"){
                            hitMap [0] = 0;
                            hitMap [1] = 1;
                            hitMap [2] = 1;
                        }
                        else if (colorNo1 == "7"){
                            hitMap [0] = 1;
                            hitMap [1] = 0.674;
                            hitMap [2] = 0;
                        }
                        else if (colorNo1 == "8"){
                            hitMap [0] = 0.627;
                            hitMap [1] = 0.125;
                            hitMap [2] = 0.941;
                        }
                        else if (colorNo1 == "9"){
                            hitMap [0] = 0.529;
                            hitMap [1] = 0.808;
                            hitMap [2] = 0.922;
                        }
                        
                        if (colorNo2 == "1"){
                            hitMap [3] = 0;
                            hitMap [4] = 0;
                            hitMap [5] = 1;
                        }
                        else if (colorNo2 == "2"){
                            hitMap [3] = 0;
                            hitMap [4] = 1;
                            hitMap [5] = 0;
                        }
                        else if (colorNo2 == "3"){
                            hitMap [3] = 1;
                            hitMap [4] = 1;
                            hitMap [5] = 0;
                        }
                        else if (colorNo2 == "4"){
                            hitMap [3] = 1;
                            hitMap [4] = 0;
                            hitMap [5] = 0;
                        }
                        else if (colorNo2 == "5"){
                            hitMap [3] = 1;
                            hitMap [4] = 0;
                            hitMap [5] = 1;
                        }
                        else if (colorNo2 == "6"){
                            hitMap [3] = 0;
                            hitMap [4] = 1;
                            hitMap [5] = 1;
                        }
                        else if (colorNo2 == "7"){
                            hitMap [3] = 1;
                            hitMap [4] = 0.674;
                            hitMap [5] = 0;
                        }
                        else if (colorNo2 == "8"){
                            hitMap [3] = 0.627;
                            hitMap [4] = 0.125;
                            hitMap [5] = 0.941;
                        }
                        else if (colorNo2 == "9"){
                            hitMap [3] = 0.529;
                            hitMap [4] = 0.808;
                            hitMap [5] = 0.922;
                        }
                        
                        if (colorNo3 == "1"){
                            hitMap [6] = 0;
                            hitMap [7] = 0;
                            hitMap [8] = 1;
                        }
                        else if (colorNo3 == "2"){
                            hitMap [6] = 0;
                            hitMap [7] = 1;
                            hitMap [8] = 0;
                        }
                        else if (colorNo3 == "3"){
                            hitMap [6] = 1;
                            hitMap [7] = 1;
                            hitMap [8] = 0;
                        }
                        else if (colorNo3 == "4"){
                            hitMap [6] = 1;
                            hitMap [7] = 0;
                            hitMap [8] = 0;
                        }
                        else if (colorNo3 == "5"){
                            hitMap [6] = 1;
                            hitMap [7] = 0;
                            hitMap [8] = 1;
                        }
                        else if (colorNo3 == "6"){
                            hitMap [6] = 0;
                            hitMap [7] = 1;
                            hitMap [8] = 1;
                        }
                        else if (colorNo3 == "7"){
                            hitMap [6] = 1;
                            hitMap [7] = 0.674;
                            hitMap [8] = 0;
                        }
                        else if (colorNo3 == "8"){
                            hitMap [6] = 0.627;
                            hitMap [7] = 0.125;
                            hitMap [8] = 0.941;
                        }
                        else if (colorNo3 == "9"){
                            hitMap [6] = 0.529;
                            hitMap [7] = 0.808;
                            hitMap [8] = 0.922;
                        }
                        
                        if (colorNo4 == "1"){
                            hitMap [9] = 0;
                            hitMap [10] = 0;
                            hitMap [11] = 1;
                        }
                        else if (colorNo4 == "2"){
                            hitMap [9] = 0;
                            hitMap [10] = 1;
                            hitMap [11] = 0;
                        }
                        else if (colorNo4 == "3"){
                            hitMap [9] = 1;
                            hitMap [10] = 1;
                            hitMap [11] = 0;
                        }
                        else if (colorNo4 == "4"){
                            hitMap [9] = 1;
                            hitMap [10] = 0;
                            hitMap [11] = 0;
                        }
                        else if (colorNo4 == "5"){
                            hitMap [9] = 1;
                            hitMap [10] = 0;
                            hitMap [11] = 1;
                        }
                        else if (colorNo4 == "6"){
                            hitMap [9] = 0;
                            hitMap [10] = 1;
                            hitMap [11] = 1;
                        }
                        else if (colorNo4 == "7"){
                            hitMap [9] = 1;
                            hitMap [10] = 0.674;
                            hitMap [11] = 0;
                        }
                        else if (colorNo4 == "8"){
                            hitMap [9] = 0.627;
                            hitMap [10] = 0.125;
                            hitMap [11] = 0.941;
                        }
                        else if (colorNo4 == "9"){
                            hitMap [9] = 0.529;
                            hitMap [10] = 0.808;
                            hitMap [11] = 0.922;
                        }
                        
                        if (colorNo5 == "1"){
                            hitMap [12] = 0;
                            hitMap [13] = 0;
                            hitMap [14] = 1;
                        }
                        else if (colorNo5 == "2"){
                            hitMap [12] = 0;
                            hitMap [13] = 1;
                            hitMap [14] = 0;
                        }
                        else if (colorNo5 == "3"){
                            hitMap [12] = 1;
                            hitMap [13] = 1;
                            hitMap [14] = 0;
                        }
                        else if (colorNo5 == "4"){
                            hitMap [12] = 1;
                            hitMap [13] = 0;
                            hitMap [14] = 0;
                        }
                        else if (colorNo5 == "5"){
                            hitMap [12] = 1;
                            hitMap [13] = 0;
                            hitMap [14] = 1;
                        }
                        else if (colorNo5 == "6"){
                            hitMap [12] = 0;
                            hitMap [13] = 1;
                            hitMap [14] = 1;
                        }
                        else if (colorNo5 == "7"){
                            hitMap [12] = 1;
                            hitMap [13] = 0.674;
                            hitMap [14] = 0;
                        }
                        else if (colorNo5 == "8"){
                            hitMap [12] = 0.627;
                            hitMap [13] = 0.125;
                            hitMap [14] = 0.941;
                        }
                        else if (colorNo5 == "9"){
                            hitMap [12] = 0.529;
                            hitMap [13] = 0.808;
                            hitMap [14] = 0.922;
                        }
                        
                        if (colorNo6 == "1"){
                            hitMap [15] = 0;
                            hitMap [16] = 0;
                            hitMap [17] = 1;
                        }
                        else if (colorNo6 == "2"){
                            hitMap [15] = 0;
                            hitMap [16] = 1;
                            hitMap [17] = 0;
                        }
                        else if (colorNo6 == "3"){
                            hitMap [15] = 1;
                            hitMap [16] = 1;
                            hitMap [17] = 0;
                        }
                        else if (colorNo6 == "4"){
                            hitMap [15] = 1;
                            hitMap [16] = 0;
                            hitMap [17] = 0;
                        }
                        else if (colorNo6 == "5"){
                            hitMap [15] = 1;
                            hitMap [16] = 0;
                            hitMap [17] = 1;
                        }
                        else if (colorNo6 == "6"){
                            hitMap [15] = 0;
                            hitMap [16] = 1;
                            hitMap [17] = 1;
                        }
                        else if (colorNo6 == "7"){
                            hitMap [15] = 1;
                            hitMap [16] = 0.674;
                            hitMap [17] = 0;
                        }
                        else if (colorNo6 == "8"){
                            hitMap [15] = 0.627;
                            hitMap [16] = 0.125;
                            hitMap [17] = 0.941;
                        }
                        else if (colorNo6 == "9"){
                            hitMap [15] = 0.529;
                            hitMap [16] = 0.808;
                            hitMap [17] = 0.922;
                        }
                        
                        unsigned long headPosition = 0;
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                            value1 = 0;
                            value2 = 0;
                            value3 = 0;
                            value4 = 0;
                            value5 = 0;
                            value6 = 0;
                            
                            value0 = uploadTemp [counter1];
                            
                            if (value0 >= 0 && value0 < cutHoldDIC){
                                value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                
                                if (value0 < 0) value0 = 0;
                            }
                            else{
                                
                                value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                
                                if (value0 > 255) value0 = 255;
                            }
                            
                            if (statusHold1 == 1 && colorFlag1 == 1){
                                value1 = uploadTempCl1 [counter1];
                                
                                if (value1 < cutHold1) value1 = 0;
                                else{
                                    
                                    value1 = value1+(int)((value1-cutHold1)*levelHold1);
                                    
                                    if (value1 > 255) value1 = 255;
                                }
                            }
                            
                            if (statusHold2 == 1 && colorFlag2 == 1){
                                value2 = uploadTempCl2 [counter1];
                                
                                if (value2 < cutHold2) value2 = 0;
                                else{
                                    
                                    value2 = value2+(int)((value2-cutHold2)*levelHold2);
                                    
                                    if (value2 > 255) value2 = 255;
                                }
                            }
                            
                            if (statusHold3 == 1 && colorFlag3 == 1){
                                value3 = uploadTempCl3 [counter1];
                                
                                if (value3 < cutHold3) value3 = 0;
                                else{
                                    
                                    value3 = value3+(int)((value3-cutHold3)*levelHold3);
                                    
                                    if (value3 > 255) value3 = 255;
                                }
                            }
                            
                            if (statusHold4 == 1 && colorFlag4 == 1){
                                value4 = uploadTempCl4 [counter1];
                                
                                if (value4 < cutHold4) value4 = 0;
                                else{
                                    
                                    value4 = value4+(int)((value4-cutHold4)*levelHold4);
                                    
                                    if (value4 > 255) value4 = 255;
                                }
                            }
                            
                            if (statusHold5 == 1 && colorFlag5 == 1){
                                value5 = uploadTempCl5 [counter1];
                                
                                if (value5 < cutHold5) value5 = 0;
                                else{
                                    
                                    value5 = value5+(int)((value5-cutHold5)*levelHold5);
                                    
                                    if (value5 > 255) value5 = 255;
                                }
                            }
                            
                            if (statusHold6 == 1 && colorFlag6 == 1){
                                value6 = uploadTempCl6 [counter1];
                                
                                if (value6 < cutHold6) value6 = 0;
                                else{
                                    
                                    value6 = value6+(int)((value6-cutHold6)*levelHold6);
                                    
                                    if (value6 > 255) value6 = 255;
                                }
                            }
                            
                            if (statusHold1 == 0) value1 = 0;
                            if (statusHold2 == 0) value2 = 0;
                            if (statusHold3 == 0) value3 = 0;
                            if (statusHold4 == 0) value4 = 0;
                            if (statusHold5 == 0) value5 = 0;
                            if (statusHold6 == 0) value6 = 0;
                            
                            if (value1 <= 0 && value2 <= 0 && value3 <= 0 && value4 <= 0 && value5 <= 0 && value6 <= 0){
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = 0;
                            }
                            else{
                                
                                if (value1 < 0) value1 = 0;
                                if (value2 < 0) value2 = 0;
                                if (value3 < 0) value3 = 0;
                                if (value4 < 0) value4 = 0;
                                if (value5 < 0) value5 = 0;
                                if (value6 < 0) value6 = 0;
                                
                                hitR = 0;
                                hitG = 0;
                                hitB = 0;
                                
                                if (value1 > 0){
                                    if (hitMap [0] != 0) hitR++;
                                    if (hitMap [1] != 0) hitG++;
                                    if (hitMap [2] != 0) hitB++;
                                }
                                
                                if (value2 > 0){
                                    if (hitMap [3] != 0) hitR++;
                                    if (hitMap [4] != 0) hitG++;
                                    if (hitMap [5] != 0) hitB++;
                                }
                                
                                if (value3 > 0){
                                    if (hitMap [6] != 0) hitR++;
                                    if (hitMap [7] != 0) hitG++;
                                    if (hitMap [8] != 0) hitB++;
                                }
                                
                                if (value4 > 0){
                                    if (hitMap [9] != 0) hitR++;
                                    if (hitMap [10] != 0) hitG++;
                                    if (hitMap [11] != 0) hitB++;
                                }
                                
                                if (value5 > 0){
                                    if (hitMap [12] != 0) hitR++;
                                    if (hitMap [13] != 0) hitG++;
                                    if (hitMap [14] != 0) hitB++;
                                }
                                
                                if (value6 > 0){
                                    if (hitMap [15] != 0) hitR++;
                                    if (hitMap [16] != 0) hitG++;
                                    if (hitMap [17] != 0) hitB++;
                                }
                                
                                colorHit1 = 0;
                                colorHit2 = 0;
                                colorHit3 = 0;
                                colorHit4 = 0;
                                colorHit5 = 0;
                                colorHit6 = 0;
                                
                                if (hitR == 1){
                                    if (hitMap [0] != 0 && value1 > 0) colorHit1 = 1;
                                    if (hitMap [3] != 0 && value2 > 0) colorHit2 = 1;
                                    if (hitMap [6] != 0 && value3 > 0) colorHit3 = 1;
                                    if (hitMap [9] != 0 && value4 > 0) colorHit4 = 1;
                                    if (hitMap [12] != 0 && value5 > 0) colorHit5 = 1;
                                    if (hitMap [15] != 0 && value6 > 0) colorHit6 = 1;
                                }
                                else if (hitR == 2){
                                    if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.5;
                                    if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.5;
                                    if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.5;
                                    if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.5;
                                    if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.5;
                                    if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.5;
                                }
                                else if (hitR == 3){
                                    if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.33;
                                    if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.33;
                                    if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.33;
                                    if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.33;
                                    if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.33;
                                    if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.33;
                                }
                                else if (hitR == 4){
                                    if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.25;
                                    if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.25;
                                    if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.25;
                                    if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.25;
                                    if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.25;
                                    if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.25;
                                }
                                else if (hitR == 5){
                                    if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.2;
                                    if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.2;
                                    if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.2;
                                    if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.2;
                                    if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.2;
                                    if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.2;
                                }
                                else if (hitR == 6){
                                    if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.13;
                                    if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.13;
                                    if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.13;
                                    if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.13;
                                    if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.13;
                                    if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.13;
                                }
                                
                                if (value1 > 0 && colorNo1 == "7") colorHit1 = colorHit1*0.647;
                                else if (value1 > 0 && colorNo1 == "8") colorHit1 = colorHit1*0.627;
                                else if (value1 > 0 && colorNo1 == "9") colorHit1 = colorHit1*0.529;
                                
                                if (value2 > 0 && colorNo2 == "7") colorHit2 = colorHit2*0.647;
                                else if (value2 > 0 && colorNo2 == "8") colorHit2 = colorHit2*0.627;
                                else if (value2 > 0 && colorNo2 == "9") colorHit2 = colorHit2*0.529;
                                
                                if (value3 > 0 && colorNo3 == "7") colorHit3 = colorHit3*0.647;
                                else if (value3 > 0 && colorNo3 == "8") colorHit3 = colorHit3*0.627;
                                else if (value3 > 0 && colorNo3 == "9") colorHit3 = colorHit3*0.529;
                                
                                if (value4 > 0 && colorNo4 == "7") colorHit4 = colorHit4*0.647;
                                else if (value4 > 0 && colorNo4 == "8") colorHit4 = colorHit4*0.627;
                                else if (value4 > 0 && colorNo4 == "9") colorHit4 = colorHit4*0.529;
                                
                                if (value5 > 0 && colorNo5 == "7") colorHit5 = colorHit5*0.647;
                                else if (value5 > 0 && colorNo5 == "8") colorHit5 = colorHit5*0.627;
                                else if (value5 > 0 && colorNo5 == "9") colorHit5 = colorHit5*0.529;
                                
                                if (value6 > 0 && colorNo6 == "7") colorHit6 = colorHit6*0.647;
                                else if (value6 > 0 && colorNo6 == "8") colorHit6 = colorHit6*0.627;
                                else if (value6 > 0 && colorNo6 == "9") colorHit6 = colorHit6*0.529;
                                
                                *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3+value4*(double)colorHit4+value5*(double)colorHit5+value6*(double)colorHit6));
                                
                                colorHit1 = 0;
                                colorHit2 = 0;
                                colorHit3 = 0;
                                colorHit4 = 0;
                                colorHit5 = 0;
                                colorHit6 = 0;
                                
                                if (hitG == 1){
                                    if (hitMap [1] != 0 && value1 > 0) colorHit1 = 1;
                                    if (hitMap [4] != 0 && value2 > 0) colorHit2 = 1;
                                    if (hitMap [7] != 0 && value3 > 0) colorHit3 = 1;
                                    if (hitMap [10] != 0 && value4 > 0) colorHit4 = 1;
                                    if (hitMap [13] != 0 && value5 > 0) colorHit5 = 1;
                                    if (hitMap [16] != 0 && value6 > 0) colorHit6 = 1;
                                }
                                else if (hitG == 2){
                                    if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.5;
                                    if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.5;
                                    if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.5;
                                    if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.5;
                                    if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.5;
                                    if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.5;
                                }
                                else if (hitG == 3){
                                    if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.33;
                                    if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.33;
                                    if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.33;
                                    if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.33;
                                    if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.33;
                                    if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.33;
                                }
                                else if (hitG == 4){
                                    if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.25;
                                    if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.25;
                                    if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.25;
                                    if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.25;
                                    if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.25;
                                    if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.25;
                                }
                                else if (hitG == 5){
                                    if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.2;
                                    if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.2;
                                    if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.2;
                                    if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.2;
                                    if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.2;
                                    if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.2;
                                }
                                else if (hitG == 6){
                                    if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.13;
                                    if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.13;
                                    if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.13;
                                    if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.13;
                                    if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.13;
                                    if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.13;
                                }
                                
                                if (value1 > 0 && colorNo1 == "8") colorHit1 = colorHit1*0.125;
                                else if (value1 > 0 && colorNo1 == "9") colorHit1 = colorHit1*0.808;
                                
                                if (value2 > 0 && colorNo2 == "8") colorHit2 = colorHit2*0.125;
                                else if (value2 > 0 && colorNo2 == "9") colorHit2 = colorHit2*0.808;
                                
                                if (value3 > 0 && colorNo3 == "8") colorHit3 = colorHit3*0.125;
                                else if (value3 > 0 && colorNo3 == "9") colorHit3 = colorHit3*0.808;
                                
                                if (value4 > 0 && colorNo4 == "8") colorHit4 = colorHit4*0.125;
                                else if (value4 > 0 && colorNo4 == "9") colorHit4 = colorHit4*0.808;
                                
                                if (value5 > 0 && colorNo5 == "8") colorHit5 = colorHit5*0.125;
                                else if (value5 > 0 && colorNo5 == "9") colorHit5 = colorHit5*0.808;
                                
                                if (value6 > 0 && colorNo6 == "8") colorHit6 = colorHit6*0.125;
                                else if (value6 > 0 && colorNo6 == "9") colorHit6 = colorHit6*0.808;
                                
                                *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3+value4*(double)colorHit4+value5*(double)colorHit5+value6*(double)colorHit6));
                                
                                colorHit1 = 0;
                                colorHit2 = 0;
                                colorHit3 = 0;
                                colorHit4 = 0;
                                colorHit5 = 0;
                                colorHit6 = 0;
                                
                                if (hitB == 1){
                                    if (hitMap [2] != 0 && value1 > 0) colorHit1 = 1;
                                    if (hitMap [5] != 0 && value2 > 0) colorHit2 = 1;
                                    if (hitMap [8] != 0 && value3 > 0) colorHit3 = 1;
                                    if (hitMap [11] != 0 && value4 > 0) colorHit4 = 1;
                                    if (hitMap [14] != 0 && value5 > 0) colorHit5 = 1;
                                    if (hitMap [17] != 0 && value6 > 0) colorHit6 = 1;
                                }
                                else if (hitB == 2){
                                    if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.5;
                                    if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.5;
                                    if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.5;
                                    if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.5;
                                    if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.5;
                                    if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.5;
                                }
                                else if (hitB == 3){
                                    if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.33;
                                    if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.33;
                                    if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.33;
                                    if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.33;
                                    if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.33;
                                    if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.33;
                                }
                                else if (hitB == 4){
                                    if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.25;
                                    if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.25;
                                    if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.25;
                                    if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.25;
                                    if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.25;
                                    if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.25;
                                }
                                else if (hitB == 5){
                                    if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.2;
                                    if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.2;
                                    if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.2;
                                    if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.2;
                                    if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.2;
                                    if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.2;
                                }
                                else if (hitB == 6){
                                    if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.13;
                                    if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.13;
                                    if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.13;
                                    if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.13;
                                    if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.13;
                                    if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.13;
                                }
                                
                                if (value1 > 0 && colorNo1 == "8") colorHit1 = colorHit1*0.941;
                                else if (value1 > 0 && colorNo1 == "9") colorHit1 = colorHit1*0.922;
                                
                                if (value2 > 0 && colorNo2 == "8") colorHit2 = colorHit2*0.941;
                                else if (value2 > 0 && colorNo2 == "9") colorHit2 = colorHit2*0.922;
                                
                                if (value3 > 0 && colorNo3 == "8") colorHit3 = colorHit3*0.941;
                                else if (value3 > 0 && colorNo3 == "9") colorHit3 = colorHit3*0.922;
                                
                                if (value4 > 0 && colorNo4 == "8") colorHit4 = colorHit4*0.941;
                                else if (value4 > 0 && colorNo4 == "9") colorHit4 = colorHit4*0.922;
                                
                                if (value5 > 0 && colorNo5 == "8") colorHit5 = colorHit5*0.941;
                                else if (value5 > 0 && colorNo5 == "9") colorHit5 = colorHit5*0.922;
                                
                                if (value6 > 0 && colorNo6 == "8") colorHit6 = colorHit6*0.941;
                                else if (value6 > 0 && colorNo6 == "9") colorHit6 = colorHit6*0.922;
                                
                                *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3+value4*(double)colorHit4+value5*(double)colorHit5+value6*(double)colorHit6));
                                *bitmapData++ = 0;
                            }
                        }
                        
                        delete [] hitMap;
                    }
                    else if (imageBmpTifFlag == 1){
                        double *hitMap = new double [20];
                        
                        if (colorNo1 == "1"){
                            hitMap [0] = 0;
                            hitMap [1] = 0;
                            hitMap [2] = 1;
                        }
                        else if (colorNo1 == "2"){
                            hitMap [0] = 0;
                            hitMap [1] = 1;
                            hitMap [2] = 0;
                        }
                        else if (colorNo1 == "3"){
                            hitMap [0] = 1;
                            hitMap [1] = 1;
                            hitMap [2] = 0;
                        }
                        else if (colorNo1 == "4"){
                            hitMap [0] = 1;
                            hitMap [1] = 0;
                            hitMap [2] = 0;
                        }
                        else if (colorNo1 == "5"){
                            hitMap [0] = 1;
                            hitMap [1] = 0;
                            hitMap [2] = 1;
                        }
                        
                        if (colorNo2 == "1"){
                            hitMap [3] = 0;
                            hitMap [4] = 0;
                            hitMap [5] = 1;
                        }
                        else if (colorNo2 == "2"){
                            hitMap [3] = 0;
                            hitMap [4] = 1;
                            hitMap [5] = 0;
                        }
                        else if (colorNo2 == "3"){
                            hitMap [3] = 1;
                            hitMap [4] = 1;
                            hitMap [5] = 0;
                        }
                        else if (colorNo2 == "4"){
                            hitMap [3] = 1;
                            hitMap [4] = 0;
                            hitMap [5] = 0;
                        }
                        else if (colorNo2 == "5"){
                            hitMap [3] = 1;
                            hitMap [4] = 0;
                            hitMap [5] = 1;
                        }
                        
                        if (colorNo3 == "1"){
                            hitMap [6] = 0;
                            hitMap [7] = 0;
                            hitMap [8] = 1;
                        }
                        else if (colorNo3 == "2"){
                            hitMap [6] = 0;
                            hitMap [7] = 1;
                            hitMap [8] = 0;
                        }
                        else if (colorNo3 == "3"){
                            hitMap [6] = 1;
                            hitMap [7] = 1;
                            hitMap [8] = 0;
                        }
                        else if (colorNo3 == "4"){
                            hitMap [6] = 1;
                            hitMap [7] = 0;
                            hitMap [8] = 0;
                        }
                        else if (colorNo3 == "5"){
                            hitMap [6] = 1;
                            hitMap [7] = 0;
                            hitMap [8] = 1;
                        }
                        
                        for (int counter1 = imageXYLength-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                                value0 = uploadTemp [1078+counter1*imageXYLength+counter2];
                                
                                if (value0 >= 0 && value0 < cutHoldDIC){
                                    value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                    
                                    if (value0 < 0) value0 = 0;
                                }
                                else{
                                    
                                    value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                    
                                    if (value0 > 255) value0 = 255;
                                }
                                
                                if (statusHold1 == 1 && colorFlag1 == 1){
                                    value1 = uploadTempCl1 [1078+counter1*imageXYLength+counter2];
                                    
                                    if (value1 < cutHold1) value1 = 0;
                                    else{
                                        
                                        value1 = value1+(int)((value1-cutHold1)*levelHold1);
                                        
                                        if (value1 > 255) value1 = 255;
                                    }
                                }
                                
                                if (statusHold2 == 1 && colorFlag2 == 1){
                                    value2 = uploadTempCl2 [1078+counter1*imageXYLength+counter2];
                                    
                                    if (value2 < cutHold2) value2 = 0;
                                    else{
                                        
                                        value2 = value2+(int)((value2-cutHold2)*levelHold2);
                                        
                                        if (value2 > 255) value2 = 255;
                                    }
                                }
                                
                                if (statusHold3 == 1 && colorFlag3 == 1){
                                    value3 = uploadTempCl3 [1078+counter1*imageXYLength+counter2];
                                    
                                    if (value3 < cutHold3) value3 = 0;
                                    else{
                                        
                                        value3 = value3+(int)((value3-cutHold3)*levelHold3);
                                        
                                        if (value3 > 255) value3 = 255;
                                    }
                                }
                                
                                if (statusHold1 == 0) value1 = 0;
                                if (statusHold2 == 0) value2 = 0;
                                if (statusHold3 == 0) value3 = 0;
                                
                                if (value1 <= 0 && value2 <= 0 && value3 <= 0){
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = 0;
                                }
                                else{
                                    
                                    if (value1 < 0) value1 = 0;
                                    if (value2 < 0) value2 = 0;
                                    if (value3 < 0) value3 = 0;
                                    
                                    hitR = 0;
                                    hitG = 0;
                                    hitB = 0;
                                    
                                    if (value1 > 0 && statusHold1 != 0){
                                        if (hitMap [0] != 0) hitR++;
                                        if (hitMap [1] != 0) hitG++;
                                        if (hitMap [2] != 0) hitB++;
                                    }
                                    
                                    if (value2 > 0 && statusHold2 != 0){
                                        if (hitMap [3] != 0) hitR++;
                                        if (hitMap [4] != 0) hitG++;
                                        if (hitMap [5] != 0) hitB++;
                                    }
                                    
                                    if (value3 > 0 && statusHold3 != 0){
                                        if (hitMap [6] != 0) hitR++;
                                        if (hitMap [7] != 0) hitG++;
                                        if (hitMap [8] != 0) hitB++;
                                    }
                                    
                                    colorHit1 = 0;
                                    colorHit2 = 0;
                                    colorHit3 = 0;
                                    
                                    if (hitR == 1){
                                        if (hitMap [0] != 0 && value1 > 0 ) colorHit1 = 1;
                                        if (hitMap [3] != 0 && value2 > 0 ) colorHit2 = 1;
                                        if (hitMap [6] != 0 && value3 > 0 ) colorHit3 = 1;
                                        
                                    }
                                    else if (hitR == 2){
                                        if (hitMap [0] != 0 && value1 > 0 ) colorHit1 = 0.5;
                                        if (hitMap [3] != 0 && value2 > 0 ) colorHit2 = 0.5;
                                        if (hitMap [6] != 0 && value3 > 0 ) colorHit3 = 0.5;
                                    }
                                    else if (hitR == 3){
                                        if (value1 > 0) colorHit1 = 0.33;
                                        if (value2 > 0) colorHit2 = 0.33;
                                        if (value3 > 0) colorHit3 = 0.33;
                                    }
                                    
                                    *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3));
                                    
                                    colorHit1 = 0;
                                    colorHit2 = 0;
                                    colorHit3 = 0;
                                    
                                    if (hitG == 1){
                                        if (hitMap [1] != 0 && value1 > 0 ) colorHit1 = 1;
                                        if (hitMap [4] != 0 && value2 > 0 ) colorHit2 = 1;
                                        if (hitMap [7] != 0 && value3 > 0 ) colorHit3 = 1;
                                    }
                                    else if (hitG == 2){
                                        if (hitMap [1] != 0 && value1 > 0 ) colorHit1 = 0.5;
                                        if (hitMap [4] != 0 && value2 > 0 ) colorHit2 = 0.5;
                                        if (hitMap [7] != 0 && value3 > 0 ) colorHit3 = 0.5;
                                    }
                                    else if (hitG == 3){
                                        if (hitMap [1] != 0 && value1 > 0 ) colorHit1 = 0.33;
                                        if (hitMap [4] != 0 && value2 > 0 ) colorHit2 = 0.33;
                                        if (hitMap [7] != 0 && value3 > 0 ) colorHit3 = 0.33;
                                    }
                                    
                                    *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3));
                                    
                                    colorHit1 = 0;
                                    colorHit2 = 0;
                                    colorHit3 = 0;
                                    
                                    if (hitB == 1){
                                        if (hitMap [2] != 0 && value1 > 0 ) colorHit1 = 1;
                                        if (hitMap [5] != 0 && value2 > 0 ) colorHit2 = 1;
                                        if (hitMap [8] != 0 && value3 > 0 ) colorHit3 = 1;
                                    }
                                    else if (hitB == 2){
                                        if (hitMap [2] != 0 && value1 > 0 ) colorHit1 = 0.5;
                                        if (hitMap [5] != 0 && value2 > 0 ) colorHit2 = 0.5;
                                        if (hitMap [8] != 0 && value3 > 0 ) colorHit3 = 0.5;
                                    }
                                    else if (hitB == 3){
                                        if (hitMap [2] != 0 && value1 > 0 ) colorHit1 = 0.33;
                                        if (hitMap [5] != 0 && value2 > 0 ) colorHit2 = 0.33;
                                        if (hitMap [8] != 0 && value3 > 0 ) colorHit3 = 0.33;
                                    }
                                    
                                    *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3));
                                    *bitmapData++ = 0;
                                }
                            }
                        }
                        
                        delete [] hitMap;
                    }
                }
                else{
                    
                    if (imageBmpTifFlag == 0){
                        unsigned long headPosition = 0;
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                            value0 = uploadTemp [counter1];
                            
                            if (value0 >= 0 && value0 < cutHoldDIC){
                                value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                
                                if (value0 < 0) value0 = 0;
                            }
                            else{
                                
                                value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                
                                if (value0 > 255) value0 = 255;
                            }
                            
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = 0;
                        }
                    }
                    else if (imageBmpTifFlag == 1){
                        for (int counter1 = imageXYLength-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                                value0 = uploadTemp [1078+counter1*imageXYLength+counter2];
                                
                                if (value0 >= 0 && value0 < cutHoldDIC){
                                    value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                    
                                    if (value0 < 0) value0 = 0;
                                }
                                else{
                                    
                                    value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                    
                                    if (value0 > 255) value0 = 255;
                                }
                                
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = 0;
                            }
                        }
                    }
                }
            }
            else if (grayColorStatus == 1){
                int dataConversion [4];
                int endianType = 0;
                
                unsigned long headPosition = 0;
                
                dataConversion [0] = uploadTemp [0];
                dataConversion [1] = uploadTemp [1];
                
                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                else endianType = 0;
                
                headPosition = 0;
                
                if (endianType == 1){
                    dataConversion [0] = uploadTemp [7];
                    dataConversion [1] = uploadTemp [6];
                    dataConversion [2] = uploadTemp [5];
                    dataConversion [3] = uploadTemp [4];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                else if (endianType == 0){
                    dataConversion [0] = uploadTemp [4];
                    dataConversion [1] = uploadTemp [5];
                    dataConversion [2] = uploadTemp [6];
                    dataConversion [3] = uploadTemp [7];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                
                int value0 = 0;
                int value1 = 0;
                int value2 = 0;
                
                for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                    value0 = uploadTemp [counter1];
                    value0 = (int)(value0*(double)levelHoldR);
                    
                    if (value0 > 255) value0 = 255;
                    
                    value1 = uploadTemp [counter1+1];
                    value1 = (int)(value1*(double)levelHoldG);
                    
                    if (value1 > 255) value1 = 255;
                    
                    value2 = uploadTemp [counter1+2];
                    value2 = (int)(value2*(double)levelHoldB);
                    
                    if (value2 > 255) value2 = 255;
                    
                    *bitmapData++ = (unsigned char)value0;
                    *bitmapData++ = (unsigned char)value1;
                    *bitmapData++ = (unsigned char)value2;
                    *bitmapData++ = 0;
                }
            }
        }
        else{
            
            if (refLoadStatus == 1){
                int dataConversion [4];
                int endianType = 0;
                
                unsigned long headPosition = 0;
                
                dataConversion [0] = uploadTempRef [0];
                dataConversion [1] = uploadTempRef [1];
                
                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                else endianType = 0;
                
                if (endianType == 1){
                    dataConversion [0] = uploadTempRef [7];
                    dataConversion [1] = uploadTempRef [6];
                    dataConversion [2] = uploadTempRef [5];
                    dataConversion [3] = uploadTempRef [4];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                else if (endianType == 0){
                    dataConversion [0] = uploadTempRef [4];
                    dataConversion [1] = uploadTempRef [5];
                    dataConversion [2] = uploadTempRef [6];
                    dataConversion [3] = uploadTempRef [7];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                
                int grayColorStatusColor = 0;
                
                if (headPosition-8 == (unsigned long)(imageXYLength*imageXYLength)) grayColorStatusColor = 0;
                else grayColorStatusColor = 1;
                
                if (grayColorStatusColor == 0){
                    int value0 = 0;
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                        value0 = uploadTempRef [counter1];
                        
                        if (value0 >= 0 && value0 < cutHoldDIC){
                            value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                            
                            if (value0 < 0) value0 = 0;
                        }
                        else{
                            
                            value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                            
                            if (value0 > 255) value0 = 255;
                        }
                        
                        if (value0 >= cutHoldDIC){
                            areaValue++;
                            areaTotal = areaTotal+value0;
                        }
                        
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = 0;
                    }
                }
                else if (grayColorStatusColor == 1){
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                        value0 = uploadTempRef [counter1];
                        value0 = (int)(value0*(double)levelHoldR);
                        
                        if (value0 > 255) value0 = 255;
                        
                        if (value0 >= cutHoldDIC){
                            areaValue++;
                            areaTotal = areaTotal+value0;
                        }
                        
                        value1 = uploadTempRef [counter1+1];
                        value1 = (int)(value1*(double)levelHoldG);
                        
                        if (value1 > 255) value1 = 255;
                        
                        value2 = uploadTempRef [counter1+2];
                        value2 = (int)(value2*(double)levelHoldB);
                        
                        if (value2 > 255) value2 = 255;
                        
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value1;
                        *bitmapData++ = (unsigned char)value2;
                        *bitmapData++ = 0;
                    }
                }
            }
            else if (refLoadStatus == 2){
                int dataConversion [4];
                int endianType = 0;
                
                unsigned long headPosition = 0;
                
                dataConversion [0] = uploadTempRef2 [0];
                dataConversion [1] = uploadTempRef2 [1];
                
                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                else endianType = 0;
                
                if (endianType == 1){
                    dataConversion [0] = uploadTempRef2 [7];
                    dataConversion [1] = uploadTempRef2 [6];
                    dataConversion [2] = uploadTempRef2 [5];
                    dataConversion [3] = uploadTempRef2 [4];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                else if (endianType == 0){
                    dataConversion [0] = uploadTempRef2 [4];
                    dataConversion [1] = uploadTempRef2 [5];
                    dataConversion [2] = uploadTempRef2 [6];
                    dataConversion [3] = uploadTempRef2 [7];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                
                int grayColorStatusRef2 = 0;
                
                if (headPosition-8 == (unsigned long)(imageXYLength*imageXYLength)) grayColorStatusRef2 = 0;
                else grayColorStatusRef2 = 1;
                
                if (grayColorStatusRef2 == 0){
                    int value0 = 0;
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                        value0 = uploadTempRef2 [counter1];
                        
                        if (value0 >= 0 && value0 < cutHoldDIC){
                            value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                            
                            if (value0 < 0) value0 = 0;
                        }
                        else{
                            
                            value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                            
                            if (value0 > 255) value0 = 255;
                        }
                        
                        if (value0 >= cutHoldDIC){
                            areaValue++;
                            areaTotal = areaTotal+value0;
                        }
                        
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = 0;
                    }
                }
                else if (grayColorStatusRef2 == 1){
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                        value0 = uploadTempRef2 [counter1];
                        value0 = (int)(value0*(double)levelHoldR);
                        
                        if (value0 > 255) value0 = 255;
                        
                        if (value0 >= cutHoldDIC){
                            areaValue++;
                            areaTotal = areaTotal+value0;
                        }
                        
                        value1 = uploadTempRef2 [counter1+1];
                        value1 = (int)(value1*(double)levelHoldG);
                        
                        if (value1 > 255) value1 = 255;
                        
                        value2 = uploadTempRef2 [counter1+2];
                        value2 = (int)(value2*(double)levelHoldB);
                        
                        if (value2 > 255) value2 = 255;
                        
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value1;
                        *bitmapData++ = (unsigned char)value2;
                        *bitmapData++ = 0;
                    }
                }
            }
            else if (refLoadStatus == 3){
                int dataConversion [4];
                int endianType = 0;
                
                unsigned long headPosition = 0;
                
                dataConversion [0] = uploadTempRef3 [0];
                dataConversion [1] = uploadTempRef3 [1];
                
                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                else endianType = 0;
                
                if (endianType == 1){
                    dataConversion [0] = uploadTempRef3 [7];
                    dataConversion [1] = uploadTempRef3 [6];
                    dataConversion [2] = uploadTempRef3 [5];
                    dataConversion [3] = uploadTempRef3 [4];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                else if (endianType == 0){
                    dataConversion [0] = uploadTempRef3 [4];
                    dataConversion [1] = uploadTempRef3 [5];
                    dataConversion [2] = uploadTempRef3 [6];
                    dataConversion [3] = uploadTempRef3 [7];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                
                int grayColorStatusRef3 = 0;
                
                if (headPosition-8 == (unsigned long)(imageXYLength*imageXYLength)) grayColorStatusRef3 = 0;
                else grayColorStatusRef3 = 1;
                
                if (grayColorStatusRef3 == 0){
                    int value0 = 0;
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                        value0 = uploadTempRef3 [counter1];
                        
                        if (value0 >= 0 && value0 < cutHoldDIC){
                            value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                            
                            if (value0 < 0) value0 = 0;
                        }
                        else{
                            
                            value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                            
                            if (value0 > 255) value0 = 255;
                        }
                        
                        if (value0 >= cutHoldDIC){
                            areaValue++;
                            areaTotal = areaTotal+value0;
                        }
                        
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = 0;
                    }
                }
                else if (grayColorStatusRef3 == 1){
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                        value0 = uploadTempRef3 [counter1];
                        value0 = (int)(value0*(double)levelHoldR);
                        
                        if (value0 > 255) value0 = 255;
                        
                        if (value0 >= cutHoldDIC){
                            areaValue++;
                            areaTotal = areaTotal+value0;
                        }
                        
                        value1 = uploadTempRef3 [counter1+1];
                        value1 = (int)(value1*(double)levelHoldG);
                        
                        if (value1 > 255) value1 = 255;
                        
                        value2 = uploadTempRef3 [counter1+2];
                        value2 = (int)(value2*(double)levelHoldB);
                        
                        if (value2 > 255) value2 = 255;
                        
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value1;
                        *bitmapData++ = (unsigned char)value2;
                        *bitmapData++ = 0;
                    }
                }
            }
        }
        
        movieImage = [[NSImage alloc] initWithSize:NSMakeSize(imageXYLength, imageXYLength)];
        [movieImage addRepresentation:bitmapRepsCR];
        
        if (timePointHold >= 1){
            if (areaDataHoldLimit < timePointHold*25){
                [self arrayAreaDataHoldUpDate];
                
                for (int counter1 = areaDataHoldCount; counter1 < timePointHold*25; counter1++){
                    arrayAreaDataHold [counter1] = 0;
                }
            }
            
            if (arrayAreaDataHold [(timePointHold-1)*25] == 0 || quantitationStatusHold == 1){
                arrayAreaDataHold [(timePointHold-1)*25] = timePointHold;
                arrayAreaDataHold [(timePointHold-1)*25+1] = cutHoldDIC;
                arrayAreaDataHold [(timePointHold-1)*25+2] = areaValue;
                arrayAreaDataHold [(timePointHold-1)*25+3] = areaTotal;
                arrayAreaDataHold [(timePointHold-1)*25+4] = areaTotal/(double)areaValue;
                arrayAreaDataHold [(timePointHold-1)*25+5] = dotNumberCurrent;
                
                if (areaDataHoldCount < timePointHold*25+25){
                    if (areaDataHoldLimit < timePointHold*25+25){
                        [self arrayAreaDataHoldUpDate];
                    }
                    
                    areaDataHoldCount = timePointHold*25+25;
                }
                
                ofstream oin;
                
                string dataSaveTreatmentPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"AnalysisData";
                
                oin.open(dataSaveTreatmentPath.c_str(), ios::out | ios::binary);
                
                for (int counter1 = 0; counter1 < areaDataHoldCount; counter1++){
                    oin<<to_string(arrayAreaDataHold [counter1])<<endl;
                }
                
                oin.close();
            }
        }
        
        areaValueCall = 1;
        
        [self setNeedsDisplay:YES];
    }
}

-(void)drawRect:(NSRect)rect {
    NSRect srcRect;
    srcRect.origin.x = xPositionDisplay+xPositionAdjustDisplay+xPositionMoveDisplay;
    srcRect.origin.y = yPositionDisplay+yPositionAdjustDisplay+yPositionMoveDisplay;
    srcRect.size.width = imageXYLength/(double)(magnificationDisplay*0.1);
    srcRect.size.height = imageXYLength/(double)(magnificationDisplay*0.1);
    
    [movieImage drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
    
    double lineDisplayFold = 1;
    
    if (lineSizeHold == 0) lineDisplayFold = 1;
    else if (lineSizeHold == 1) lineDisplayFold = 2;
    else if (lineSizeHold == 2) lineDisplayFold = 3;
    else if (lineSizeHold == 3) lineDisplayFold = 4;
    else if (lineSizeHold == 4) lineDisplayFold = 5;
    else if (lineSizeHold == 5) lineDisplayFold = 0.1;
    else if (lineSizeHold == 6) lineDisplayFold = 0.2;
    else if (lineSizeHold == 7) lineDisplayFold = 0.3;
    else if (lineSizeHold == 8) lineDisplayFold = 0.4;
    else if (lineSizeHold == 9) lineDisplayFold = 0.5;
    
    double xPositionAdj = xPositionAdjustDisplay+xPositionDisplay;
    double yPositionAdj = yPositionAdjustDisplay+yPositionDisplay;
    double xCalValue = 1/(double)windowWidthDisplay*magnificationDisplay*0.1;
    double yCalValue = 1/(double)windowHeightDisplay*magnificationDisplay*0.1;
    double magnificationDisplay2 = magnificationDisplay*0.1;
    double magnificationLine = magnificationDisplay*0.25;
    double magnificationDisplay3 = magnificationDisplay*0.1*0.4*(double)lineDisplayFold;
    double magnificationFont2 = magnificationDisplay*0.08*3.5;
    
    double displayFrequencyTemp = (2-xPositionAdj)*xCalValue-(1-xPositionAdj)*xCalValue;
    int displayFrequency = (int)displayFrequencyTemp;
    
    if (displayFrequencyTemp <= 0.3 && displayFrequencyTemp != 0) displayFrequency = (int)(8/(double)displayFrequencyTemp);
    else if (displayFrequencyTemp <= 0.5 && displayFrequencyTemp > 0.3) displayFrequency = (int)(6/(double)displayFrequencyTemp);
    else if (displayFrequencyTemp <= 1 && displayFrequencyTemp > 0.5) displayFrequency = (int)(4/(double)displayFrequencyTemp);
    else if (displayFrequencyTemp <= 2 && displayFrequencyTemp > 1) displayFrequency = 2;
    else if (displayFrequencyTemp <= 3 && displayFrequencyTemp > 2) displayFrequency = 1;
    else if (displayFrequencyTemp <= 4 && displayFrequencyTemp > 3) displayFrequency = 1;
    else if (displayFrequencyTemp > 4) displayFrequency = 1;
    
    CGFloat sizeCalculation = 512*xCalValue;
    sizeCalculation = (sizeCalculation/(double)500)*0.5;
    
    if (sizeCalculation >= 2) sizeCalculation = 2;
    
    int xPointMarkTemp = 0;
    int yPointMarkTemp = 0;
    int xPointMarkTemp2 = 0;
    int yPointMarkTemp2 = 0;
    
    NSPoint positionAA;
    NSPoint positionBB;
    NSPoint positionCC;
    NSPoint positionDD;
    
    if (dimensionSetModeHold == 1){
        [NSBezierPath setDefaultLineWidth:sizeCalculation*5];
        [[NSColor redColor] set];
        
        xPointMarkTemp = (int)((boxXPositionCurrent-xPositionAdj)*(double)xCalValue);
        yPointMarkTemp = (int)(((imageXYLength-boxYPositionCurrent)-yPositionAdj)*(double)yCalValue);
        
        positionAA.x = xPointMarkTemp-magnificationLine;
        positionAA.y = yPointMarkTemp;
        positionBB.x = xPointMarkTemp+magnificationLine;
        positionBB.y = yPointMarkTemp;
        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
        
        positionCC.x = xPointMarkTemp;
        positionCC.y = yPointMarkTemp-magnificationLine;
        positionDD.x = xPointMarkTemp;
        positionDD.y = yPointMarkTemp+magnificationLine;
        [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
    }
    
    if (boxXLength != 0 && boxYLength != 0){
        [NSBezierPath setDefaultLineWidth:sizeCalculation*10];
        [[NSColor redColor] set];
        
        xPointMarkTemp = (int)(((boxXPosition-(boxXLength/(double)2))-xPositionAdj)*(double)xCalValue);
        xPointMarkTemp2 = (int)(((boxXPosition+(boxXLength/(double)2))-xPositionAdj)*(double)xCalValue);
        yPointMarkTemp = (int)(((imageXYLength-boxYPosition)-yPositionAdj)*(double)yCalValue);
        yPointMarkTemp2 = (int)(((imageXYLength-boxYPosition+boxYLength)-yPositionAdj)*(double)yCalValue);
        
        positionAA.x = xPointMarkTemp;
        positionAA.y = yPointMarkTemp;
        positionBB.x = xPointMarkTemp2;
        positionBB.y = yPointMarkTemp;
        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
        
        positionAA.x = xPointMarkTemp;
        positionAA.y = yPointMarkTemp;
        positionBB.x = xPointMarkTemp;
        positionBB.y = yPointMarkTemp2;
        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
        
        positionAA.x = xPointMarkTemp2;
        positionAA.y = yPointMarkTemp;
        positionBB.x = xPointMarkTemp2;
        positionBB.y = yPointMarkTemp2;
        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
        
        positionAA.x = xPointMarkTemp;
        positionAA.y = yPointMarkTemp2;
        positionBB.x = xPointMarkTemp2;
        positionBB.y = yPointMarkTemp2;
        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
    }
    
    if (gridStatusHold == 1){
        if (gridLinWidth == 0){
            [NSBezierPath setDefaultLineWidth:sizeCalculation*5];
        }
        else if (gridLinWidth == 1){
            [NSBezierPath setDefaultLineWidth:sizeCalculation*5*2];
        }
        else if (gridLinWidth == 2){
            [NSBezierPath setDefaultLineWidth:sizeCalculation*5*4];
        }
        
        if (gridLineColor == 0){
            [[NSColor orangeColor] set];
        }
        else if (gridLineColor == 1){
            [[NSColor greenColor] set];
        }
        else if (gridLineColor == 2){
            [[NSColor yellowColor] set];
        }
        else if (gridLineColor == 3){
            [[NSColor redColor] set];
        }
        else if (gridLineColor == 4){
            [[NSColor blueColor] set];
        }
        else if (gridLineColor == 5){
            [[NSColor blackColor] set];
        }
        else if (gridLineColor == 6){
            [[NSColor whiteColor] set];
        }
        
        int xGridLength = (int)((imageXYLength-xPositionAdj)*(double)xCalValue);
        int yGridLength = (int)(((imageXYLength-imageXYLength)-yPositionAdj)*(double)yCalValue);
        
        xPointMarkTemp = (int)((0-xPositionAdj)*(double)xCalValue);
        yPointMarkTemp = (int)(((imageXYLength-0)-yPositionAdj)*(double)yCalValue);
        
        positionAA.x = xPointMarkTemp;
        positionAA.y = yPointMarkTemp;
        positionBB.x = xGridLength;
        positionBB.y = yPointMarkTemp;
        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
        
        positionAA.x = xPointMarkTemp;
        positionAA.y = yGridLength;
        positionBB.x = xGridLength;
        positionBB.y = yGridLength;
        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
        
        positionAA.x = xPointMarkTemp;
        positionAA.y = yPointMarkTemp;
        positionBB.x = xPointMarkTemp;
        positionBB.y = yGridLength;
        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
        
        positionAA.x = xGridLength;
        positionAA.y = yPointMarkTemp;
        positionBB.x = xGridLength;
        positionBB.y = yGridLength;
        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
        
        if (gridDimHold > 1){
            int xGridPosition = 0;
            int yGridPosition = 0;
            
            double gridNewellDimension = imageXYLength/(double)gridDimHold;
            int positionAccumulate = 0;
            
            for (int counter1 = 0; counter1 < gridDimHold-1; counter1++){
                positionAccumulate = positionAccumulate+(int)gridNewellDimension;
                yGridPosition = (int)(((imageXYLength-positionAccumulate)-yPositionAdj)*(double)yCalValue);
                
                positionAA.x = xPointMarkTemp;
                positionAA.y = yGridPosition;
                positionBB.x = xGridLength;
                positionBB.y = yGridPosition;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            }
            
            positionAccumulate = 0;
            
            for (int counter1 = 0; counter1 < gridDimHold-1; counter1++){
                positionAccumulate = positionAccumulate+(int)gridNewellDimension;
                xGridPosition = (int)((positionAccumulate-xPositionAdj)*(double)xCalValue);
                
                positionAA.x = xGridPosition;
                positionAA.y = yPointMarkTemp;
                positionBB.x = xGridPosition;
                positionBB.y = yGridLength;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            }
        }
    }
    
    NSBezierPath *path3;
    
    if (dotNumberCurrent != 0){
        double magnificationDisplayDot = 0;
        
        if (dotLength == 1) magnificationDisplayDot = magnificationDisplay2*3;
        else if (dotLength == 2) magnificationDisplayDot = (magnificationDisplay2*3)/(double)2;
        else if (dotLength == 3) magnificationDisplayDot = (magnificationDisplay2*3)/(double)4;
        
        for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
            if (arrayDotDataHold [counter1*3] >= 0 && arrayDotDataHold [counter1*3] <= 100000 && arrayDotDataHold [counter1*3] == timePointHold){
                xPointMarkTemp = (int)((arrayDotDataHold [counter1*3+1]-xPositionAdj)*(double)xCalValue);
                yPointMarkTemp = (int)(((imageXYLength-arrayDotDataHold [counter1*3+2])-yPositionAdj)*(double)yCalValue);
                
                [[NSColor cyanColor] set];
                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp-magnificationDisplayDot/2, yPointMarkTemp-magnificationDisplayDot/2, magnificationDisplayDot, magnificationDisplayDot)];
                
                if (dotFillStatus == 0) [path3 fill];
                else if (dotFillStatus == 1) [path3 stroke];
            }
            else if (arrayDotDataHold [counter1*3] < 0 && arrayDotDataHold [counter1*3] >= -100000 & arrayDotDataHold [counter1*3]*-1 == timePointHold){
                xPointMarkTemp = (int)((arrayDotDataHold [counter1*3+1]-xPositionAdj)*(double)xCalValue);
                yPointMarkTemp = (int)(((imageXYLength-arrayDotDataHold [counter1*3+2])-yPositionAdj)*(double)yCalValue);
                
                [[NSColor redColor] set];
                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp-magnificationDisplayDot/2, yPointMarkTemp-magnificationDisplayDot/2, magnificationDisplayDot, magnificationDisplayDot)];
                
                if (dotFillStatus == 0) [path3 fill];
                else if (dotFillStatus == 1) [path3 stroke];
            }
            else if (arrayDotDataHold [counter1*3] > 100000 && arrayDotDataHold [counter1*3]-100000 == timePointHold){
                xPointMarkTemp = (int)((arrayDotDataHold [counter1*3+1]-xPositionAdj)*(double)xCalValue);
                yPointMarkTemp = (int)(((imageXYLength-arrayDotDataHold [counter1*3+2])-yPositionAdj)*(double)yCalValue);
                
                [[NSColor greenColor] set];
                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp-magnificationDisplayDot/2, yPointMarkTemp-magnificationDisplayDot/2, magnificationDisplayDot, magnificationDisplayDot)];
                
                if (dotFillStatus == 0) [path3 fill];
                else if (dotFillStatus == 1) [path3 stroke];
            }
            else if (arrayDotDataHold [counter1*3] < -100000 && arrayDotDataHold [counter1*3]*-1-100000 == timePointHold){
                xPointMarkTemp = (int)((arrayDotDataHold [counter1*3+1]-xPositionAdj)*(double)xCalValue);
                yPointMarkTemp = (int)(((imageXYLength-arrayDotDataHold [counter1*3+2])-yPositionAdj)*(double)yCalValue);
                
                [[NSColor magentaColor] set];
                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp-magnificationDisplayDot/2, yPointMarkTemp-magnificationDisplayDot/2, magnificationDisplayDot, magnificationDisplayDot)];
                
                if (dotFillStatus == 0) [path3 fill];
                else if (dotFillStatus == 1) [path3 stroke];
            }
        }
    }
    
    //------Time One mode------
    if (areaModeStatusHold == 1){
        if (lineFontShowOnOff == 0){
            [NSBezierPath setDefaultLineWidth:sizeCalculation];
            
            int startPoint = 0;
            int removeMark = 0;
            int connectTemp = 0;
            
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                if (arrayTimeSelected [counter1*10] == 0 || arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7 || arrayTimeSelected [counter1*10] == 2 || arrayTimeSelected [counter1*10] == 5 || arrayTimeSelected [counter1*10] == 6 || arrayTimeSelected [counter1*10] == 10 || arrayTimeSelected [counter1*10] == 11){
                    startPoint = arrayTimeSelected [counter1*10+2];
                    removeMark = arrayTimeSelected [counter1*10];
                    
                    connectTemp = 0;
                    
                    for (int counter2 = startPoint; counter2 < positionReviseCount/7; counter2 = counter2+displayFrequency){
                        if (connectTemp == 0){
                            connectTemp = arrayPositionRevise [counter2*7+3];
                            
                            if (removeMark == 0){
                                xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdj)*(double)xCalValue);
                                yPointMarkTemp = (int)(((imageXYLength-arrayPositionRevise [counter2*7+1])-yPositionAdj)*(double)yCalValue);
                                
                                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 600 && yPointMarkTemp >= 0 && yPointMarkTemp <= 600){
                                    [[NSColor yellowColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay3, magnificationDisplay3)];
                                    [path3 fill];
                                }
                            }
                            else if (removeMark == 2){
                                xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdj)*(double)xCalValue);
                                yPointMarkTemp = (int)(((imageXYLength-arrayPositionRevise [counter2*7+1])-yPositionAdj)*(double)yCalValue);
                                
                                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 600 && yPointMarkTemp >= 0 && yPointMarkTemp <= 600){
                                    [[NSColor grayColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay3, magnificationDisplay3)];
                                    [path3 fill];
                                }
                            }
                            else if (removeMark == 10){
                                xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdj)*(double)xCalValue);
                                yPointMarkTemp = (int)(((imageXYLength-arrayPositionRevise [counter2*7+1])-yPositionAdj)*(double)yCalValue);
                                
                                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 600 && yPointMarkTemp >= 0 && yPointMarkTemp <= 600){
                                    [[NSColor blueColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay3, magnificationDisplay3)];
                                    [path3 fill];
                                }
                            }
                            else if (removeMark == 11){
                                xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdj)*(double)xCalValue);
                                yPointMarkTemp = (int)(((imageXYLength-arrayPositionRevise [counter2*7+1])-yPositionAdj)*(double)yCalValue);
                                
                                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 600 && yPointMarkTemp >= 0 && yPointMarkTemp <= 600){
                                    [[NSColor magentaColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay3, magnificationDisplay3)];
                                    [path3 fill];
                                }
                            }
                            else if (removeMark == 1 || removeMark == 7){
                                xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdj)*(double)xCalValue);
                                yPointMarkTemp = (int)(((imageXYLength-arrayPositionRevise [counter2*7+1])-yPositionAdj)*(double)yCalValue);
                                
                                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 600 && yPointMarkTemp >= 0 && yPointMarkTemp <= 600){
                                    [[NSColor greenColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay3, magnificationDisplay3)];
                                    [path3 fill];
                                }
                            }
                        }
                        else if (connectTemp == arrayPositionRevise [counter2*7+3]){
                            if (removeMark == 0){
                                xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdj)*(double)xCalValue);
                                yPointMarkTemp = (int)(((imageXYLength-arrayPositionRevise [counter2*7+1])-yPositionAdj)*(double)yCalValue);
                                
                                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 600 && yPointMarkTemp >= 0 && yPointMarkTemp <= 600){
                                    [[NSColor yellowColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay3, magnificationDisplay3)];
                                    [path3 fill];
                                }
                            }
                            else if (removeMark == 2){
                                xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdj)*(double)xCalValue);
                                yPointMarkTemp = (int)(((imageXYLength-arrayPositionRevise [counter2*7+1])-yPositionAdj)*(double)yCalValue);
                                
                                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 600 && yPointMarkTemp >= 0 && yPointMarkTemp <= 600){
                                    [[NSColor grayColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay3, magnificationDisplay3)];
                                    [path3 fill];
                                }
                            }
                            else if (removeMark == 10){
                                xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdj)*(double)xCalValue);
                                yPointMarkTemp = (int)(((imageXYLength-arrayPositionRevise [counter2*7+1])-yPositionAdj)*(double)yCalValue);
                                
                                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 600 && yPointMarkTemp >= 0 && yPointMarkTemp <= 600){
                                    [[NSColor blueColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay3, magnificationDisplay3)];
                                    [path3 fill];
                                }
                            }
                            else if (removeMark == 11){
                                xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdj)*(double)xCalValue);
                                yPointMarkTemp = (int)(((imageXYLength-arrayPositionRevise [counter2*7+1])-yPositionAdj)*(double)yCalValue);
                                
                                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 600 && yPointMarkTemp >= 0 && yPointMarkTemp <= 600){
                                    [[NSColor magentaColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay3, magnificationDisplay3)];
                                    [path3 fill];
                                }
                            }
                            else if (removeMark == 1 || removeMark == 7){
                                xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdj)*(double)xCalValue);
                                yPointMarkTemp = (int)(((imageXYLength-arrayPositionRevise [counter2*7+1])-yPositionAdj)*(double)yCalValue);
                                
                                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 600 && yPointMarkTemp >= 0 && yPointMarkTemp <= 600){
                                    [[NSColor greenColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay3, magnificationDisplay3)];
                                    [path3 fill];
                                }
                            }
                        }
                        else if (connectTemp != arrayPositionRevise [counter2*7+3]){
                            break;
                        }
                    }
                }
            }
            
            //------Line point display------
            if (lineDraw == 2){ //------Point Data entry to arrayTarget------
                if (targetCount+4 > targetLimit) [self targetUpDate];
                
                arrayTarget [targetCount] = (int)(xPointLine/(double)xCalValue+xPositionAdj), targetCount++;
                arrayTarget [targetCount] = (int)((yPointLine/(double)yCalValue+yPositionAdj-imageXYLength)*-1), targetCount++;
            }
            
            if (lineDraw == 1 || lineDraw == 2){ //------Point display------
                [[NSColor redColor] set];
                
                for (int counter1 = 0; counter1 < targetCount/2; counter1++){
                    xPointMarkTemp = (int)((arrayTarget [counter1*2]-xPositionAdj)*(double)xCalValue);
                    yPointMarkTemp = (int)(((imageXYLength-arrayTarget [counter1*2+1])-yPositionAdj)*(double)yCalValue);
                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay3, magnificationDisplay3)];
                    [path3 fill];
                }
            }
            
            //------GR Center Display------
            positionAA.x = 0;
            positionAA.y = 300;
            positionBB.x = 600;
            positionBB.y = 300;
            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            
            positionCC.x = 300;
            positionCC.y = 0;
            positionDD.x = 300;
            positionDD.y = 600;
            [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
            
            NSPoint pointA;
            NSAttributedString *attrStrA;
            NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
            
            [attributesA setObject:[NSFont systemFontOfSize:magnificationFont2] forKey:NSFontAttributeName];
            
            if (targetMarkWidthType == 0){
                [NSBezierPath setDefaultLineWidth:1];
            }
            else if (targetMarkWidthType == 1){
                [NSBezierPath setDefaultLineWidth:2];
            }
            else if (targetMarkWidthType == 2){
                [NSBezierPath setDefaultLineWidth:4];
            }
            
            [attributesA removeObjectForKey:NSBackgroundColorAttributeName];
            NSString *vectorNumberDisplay;
            
            int selected = 0;
            
            for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                selected = arrayTimeSelected [counter1*10];
                xPointMarkTemp = (int)((arrayGravityCenterRev [counter1*6]-xPositionAdj)*(double)xCalValue);
                yPointMarkTemp = (int)(((imageXYLength-arrayGravityCenterRev [counter1*6+1])-yPositionAdj)*(double)yCalValue);
                
                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 600 && yPointMarkTemp >= 0 && yPointMarkTemp <= 600){
                    if (selected == 0){
                        [[NSColor blackColor] set];
                        [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    }
                    else if (selected == 1 || selected == 10 || selected == 11){
                        if (targetMarkColorType == 0){
                            [attributesA setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                            [[NSColor orangeColor] set];
                        }
                        else if (targetMarkColorType == 1){
                            [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                            [[NSColor greenColor] set];
                        }
                        else if (targetMarkColorType == 2){
                            [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                            [[NSColor yellowColor] set];
                        }
                        else if (targetMarkColorType == 3){
                            [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                            [[NSColor redColor] set];
                        }
                        else if (targetMarkColorType == 4){
                            [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                            [[NSColor blueColor] set];
                        }
                        else if (targetMarkColorType == 5){
                            [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                            [[NSColor blackColor] set];
                        }
                        else if (targetMarkColorType == 6){
                            [attributesA setObject:[NSColor clearColor] forKey: NSForegroundColorAttributeName];
                            [[NSColor clearColor] set];
                        }
                    }
                    
                    if (selected == 0 || selected == 1 || selected == 10 || selected == 11){
                        positionAA.x = xPointMarkTemp-magnificationLine;
                        positionAA.y = yPointMarkTemp;
                        positionBB.x = xPointMarkTemp+magnificationLine;
                        positionBB.y = yPointMarkTemp;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        positionCC.x = xPointMarkTemp;
                        positionCC.y = yPointMarkTemp-magnificationLine;
                        positionDD.x = xPointMarkTemp;
                        positionDD.y = yPointMarkTemp+magnificationLine;
                        [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                        
                        if (charDisplayFlag == 0){
                            vectorNumberDisplay = [NSString stringWithFormat:@"%d", arrayGravityCenterRev [counter1*6+4]];
                            
                            attrStrA = [[NSAttributedString alloc] initWithString:vectorNumberDisplay attributes:attributesA];
                            pointA.x = xPointMarkTemp+magnificationLine*0.3;
                            pointA.y = yPointMarkTemp+magnificationLine*0.3;
                            [attrStrA drawAtPoint:pointA];
                        }
                    }
                }
            }
            
            //------Info Display------
            [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            
            [attributesA setObject:[NSFont systemFontOfSize:12] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
            [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
            
            string infoDisplayString = "Line Draw";
            
            if (lineDraw == 1){
                [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                infoDisplayString = "Line Draw";
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 100;
                pointA.y = 585;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (timeOneQuickSet == 2){
                [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                infoDisplayString = "Select";
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 200;
                pointA.y = 585;
                [attrStrA drawAtPoint:pointA];
            }
            if (timeOneQuickSet == 3){
                [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                infoDisplayString = "Non-Select";
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 200;
                pointA.y = 585;
                [attrStrA drawAtPoint:pointA];
            }
            if (timeOneQuickSet == 4){
                [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                infoDisplayString = "Select2";
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 200;
                pointA.y = 585;
                [attrStrA drawAtPoint:pointA];
            }
            if (timeOneQuickSet == 5){
                [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                infoDisplayString = "Select3";
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 200;
                pointA.y = 585;
                [attrStrA drawAtPoint:pointA];
            }
            if (currentConnectNo != 0){
                [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                infoDisplayString = "Connect: "+to_string(currentConnectNo);
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 300;
                pointA.y = 585;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (currentPositionSet != 0){
                [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                infoDisplayString = "Position: "+to_string(currentPositionSet);
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 400;
                pointA.y = 585;
                [attrStrA drawAtPoint:pointA];
            }
        }
        else{
            
            NSPoint pointA;
            NSAttributedString *attrStrA;
            NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
            
            [attributesA setObject:[NSFont systemFontOfSize:12] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
            [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
            
            string infoDisplayString = "Lines-Invisible";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
            pointA.x = 20;
            pointA.y = 585;
            [attrStrA drawAtPoint:pointA];
        }
    }
    
    movieTiming = 0;
}

-(void)arrayAreaDataHoldUpDate{
    double *arrayUpDate = new double [areaDataHoldCount+10];
    
    for (int counter1 = 0; counter1 < areaDataHoldCount; counter1++) arrayUpDate [counter1] = arrayAreaDataHold [counter1];
    
    delete [] arrayAreaDataHold;
    arrayAreaDataHold = new double [areaDataHoldLimit+timePointHold*25+2500];
    areaDataHoldLimit = areaDataHoldLimit+timePointHold*25+2500;
    
    for (int counter1 = 0; counter1 < areaDataHoldLimit; counter1++){
        arrayAreaDataHold [counter1] = 0;
    }
    
    for (int counter1 = 0; counter1 < areaDataHoldCount; counter1++) arrayAreaDataHold [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)arrayDotDataHoldUpDate{
    int *arrayUpDate = new int [dotDataHoldCount+10];
    
    for (int counter1 = 0; counter1 < dotDataHoldCount; counter1++) arrayUpDate [counter1] = arrayDotDataHold [counter1];
    
    delete [] arrayDotDataHold;
    arrayDotDataHold = new int [dotDataHoldLimit+1000];
    dotDataHoldLimit = dotDataHoldLimit+1000;
    
    for (int counter1 = 0; counter1 < dotDataHoldCount; counter1++) arrayDotDataHold [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)targetUpDate{
    int *arrayTargetUpDate = new int [targetCount+10];
    
    for (int counter1 = 0; counter1 < targetCount; counter1++) arrayTargetUpDate [counter1] = arrayTarget [counter1];
    
    delete [] arrayTarget;
    arrayTarget = new int [targetLimit+1000];
    targetLimit = targetLimit+1000;
    
    for (int counter1 = 0; counter1 < targetCount; counter1++) arrayTarget [counter1] = arrayTargetUpDate [counter1];
    delete [] arrayTargetUpDate;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToMovieDisplay object:nil];
}

@end
