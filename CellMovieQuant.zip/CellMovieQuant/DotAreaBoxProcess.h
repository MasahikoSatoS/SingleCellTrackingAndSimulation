//
//  DotAreaBoxProcess.h
//  CellMovieQuant
//
//  Created by Masahiko Sato on 2021-12-28.
//

#ifndef DOTAREABOXPROCESS_H
#define DOTAREABOXPROCESS_H
#import "Controller.h"
#endif

@interface DotAreaBoxProcess : NSObject{
    IBOutlet NSTextField *quantitationModeDisplay;
    IBOutlet NSTextField *analysisModeDisplay;
    IBOutlet NSTextField *boxXDisplay;
    IBOutlet NSTextField *boxYDisplay;
    IBOutlet NSTextField *boxDimensionDisplay;
    IBOutlet NSTextField *boxDimensionSetDisplay;
    IBOutlet NSTextField *areaTotalTableDisplay;
    
    id lineSet;
    id trackingDataSave;
    id ascIIconversion;
    id subProcesses;
}

-(IBAction)quantitationModeSet:(id)sender;
-(IBAction)areaTotalDisplaySet:(id)sender;
-(IBAction)boxDimensionSet:(id)sender;
-(IBAction)boxDimensionClear:(id)sender;
-(IBAction)boxDrawingSet:(id)sender;
-(IBAction)boxSetMode:(id)sender;
-(IBAction)pointModeSet:(id)sender;
-(IBAction)clearDotTime:(id)sender;
-(IBAction)creatDataFile:(id)sender;

-(IBAction)lineSelect:(id)sender;
-(IBAction)lineSet:(id)sender;

-(IBAction)charDisplaySet:(id)sender;
-(IBAction)reviseLineDone:(id)sender;

-(IBAction)saveAreaData:(id)sender;
-(IBAction)cleaningDataBase:(id)sender;
-(IBAction)removeNonSelectDataBase:(id)sender;

@end
