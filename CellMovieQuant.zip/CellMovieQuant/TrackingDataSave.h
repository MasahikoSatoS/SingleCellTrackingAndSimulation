//
// TrackingDataSave.h
// CellMovieQuant
//
// Created by Masahiko Sato on 13/10/02.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef TRACKINGDATASAVE_H
#define TRACKINGDATASAVE_H
#import "Controller.h" 
#endif

@interface TrackingDataSave : NSObject {
}

-(void)trackingDataSaveTemp: (int)timeSet;

@end
