//
//  ExportController.h
//  CellMovieQuant
//
//  Created by Masahiko Sato on 2019-10-25.
//

#ifndef EXPORTCONTROLLER_H
#define EXPORTCONTROLLER_H
#import "Controller.h" 
#endif

@interface ExportController : NSObject <NSTextFieldDelegate>{
    int currentRangeHold; //Current range
    int refStatusHold1; //Ref status
    int colorListNoHold; //Color list no
    int colorSetStatusHold; //Color status hold
    int areaAdjustStatusHold; //Area Adjust status
    
    IBOutlet NSTextField *outLineWidthDisplay;
    IBOutlet NSTextField *outLineSelectDisplay;
    IBOutlet NSTextField *dotSizeExportDisplay;
    
    IBOutlet NSTextField *targetWidthDisplay;
    IBOutlet NSTextField *targetLengthDisplay;
    IBOutlet NSTextField *targetFontDisplay;
    IBOutlet NSTextField *titleFontDisplay;
    IBOutlet NSTextField *lineWidthDisplay;
    IBOutlet NSTextField *colorMaxAreaDisplay;
    IBOutlet NSTextField *groupDisplay;
    IBOutlet NSTextField *rangeNumberDisplay;
    
    IBOutlet NSTextField *rangeDisplay1;
    IBOutlet NSTextField *rangeDisplay2;
    IBOutlet NSTextField *rangeDisplay3;
    IBOutlet NSTextField *rangeDisplay4;
    IBOutlet NSTextField *rangeDisplay5;
    IBOutlet NSTextField *rangeDisplay6;
    IBOutlet NSTextField *rangeDisplay7;
    IBOutlet NSTextField *rangeDisplay8;
    IBOutlet NSTextField *rangeDisplay9;
    IBOutlet NSTextField *rangeDisplay10;
    IBOutlet NSTextField *colorPasteDisplay;
    IBOutlet NSTextField *pasteDotDisplay;
    IBOutlet NSTextField *fontCrossDisplay;
    IBOutlet NSTextField *colorSdSetDisplay;
    IBOutlet NSTextField *colorSdDisplay;
    IBOutlet NSTextField *colorThSetDisplay;
    IBOutlet NSTextField *colorThDisplay;
    IBOutlet NSTextField *linePrintColorDisplay;
    IBOutlet NSTextField *refStatusDisplay1;
    IBOutlet NSTextField *colorSetStatusDisplay;
    
    IBOutlet NSTextField *dotStyleDisplay;
    IBOutlet NSTextField *dotLengthDisplay;
    IBOutlet NSTextField *areaAdjustDisplay;
    
    IBOutlet NSTextField *dotStatusDisplay;
    IBOutlet NSTextField *dotMinDisplay;
    IBOutlet NSTextField *dotMaxDisplay;
    IBOutlet NSTextField *dotHighestValueDisplay;
    
    IBOutlet NSTextField *densityDiameterDisplay;
    IBOutlet NSTextField *densityMaxDisplay;
    IBOutlet NSTextField *firstSecondDisplay;
    IBOutlet NSTextField *gridDivisionDisplay;
    IBOutlet NSTextField *dotGravityCenterChoiceDiaplay;
    
    IBOutlet NSButton *colorButton1;
    IBOutlet NSButton *colorButton2;
    IBOutlet NSButton *colorButton3;
    IBOutlet NSButton *colorButton4;
    IBOutlet NSButton *colorButton5;
    IBOutlet NSButton *colorButton6;
    IBOutlet NSButton *colorButton7;
    IBOutlet NSButton *colorButton8;
    IBOutlet NSButton *colorButton9;
    IBOutlet NSButton *colorButton10;
    IBOutlet NSButton *colorButton11;
    IBOutlet NSButton *colorButton12;
    
    IBOutlet NSButton *colorList1;
    IBOutlet NSButton *colorList2;
    IBOutlet NSButton *colorList3;
    IBOutlet NSButton *colorList4;
    IBOutlet NSButton *colorList5;
    IBOutlet NSButton *colorList6;
    IBOutlet NSButton *colorList7;
    IBOutlet NSButton *colorList8;
    IBOutlet NSButton *colorList9;
    IBOutlet NSButton *colorList10;
    IBOutlet NSButton *colorList11;
    IBOutlet NSButton *colorList12;
    IBOutlet NSButton *colorList13;
    IBOutlet NSButton *colorList14;
    IBOutlet NSButton *colorList15;
    IBOutlet NSButton *colorList16;
    IBOutlet NSButton *colorList17;
    IBOutlet NSButton *colorList18;
    IBOutlet NSButton *colorList19;
    IBOutlet NSButton *colorList20;
    IBOutlet NSButton *colorList21;
    IBOutlet NSButton *colorList22;
    IBOutlet NSButton *colorList23;
    IBOutlet NSButton *colorList24;
    IBOutlet NSButton *colorList25;
    IBOutlet NSButton *colorList26;
    IBOutlet NSButton *colorList27;
    IBOutlet NSButton *colorList28;
    IBOutlet NSButton *colorList29;
    IBOutlet NSButton *colorList30;
    IBOutlet NSButton *colorList31;
    IBOutlet NSButton *colorList32;
    IBOutlet NSButton *colorList33;
    IBOutlet NSButton *colorList34;
    IBOutlet NSButton *colorList35;
    IBOutlet NSButton *colorList36;
    IBOutlet NSButton *colorList37;
    IBOutlet NSButton *colorList38;
    IBOutlet NSButton *colorList39;
    IBOutlet NSButton *colorList40;
    IBOutlet NSButton *colorList41;
    IBOutlet NSButton *colorList42;
    IBOutlet NSButton *colorList43;
    IBOutlet NSButton *colorList44;
    IBOutlet NSButton *colorList45;
    IBOutlet NSButton *colorList46;
    IBOutlet NSButton *colorList47;
    IBOutlet NSButton *colorList48;
    IBOutlet NSButton *colorList49;
    IBOutlet NSButton *colorList50;
    IBOutlet NSButton *colorList51;
    IBOutlet NSButton *colorList52;
    IBOutlet NSButton *colorList53;
    IBOutlet NSButton *colorList54;
    IBOutlet NSButton *colorList55;
    IBOutlet NSButton *colorList56;
    IBOutlet NSButton *colorList57;
    IBOutlet NSButton *colorList58;
    IBOutlet NSButton *colorList59;
    IBOutlet NSButton *colorList60;
    IBOutlet NSButton *colorList61;
    IBOutlet NSButton *colorList62;
    IBOutlet NSButton *colorList63;
    IBOutlet NSButton *colorList64;
    IBOutlet NSButton *colorList65;
    IBOutlet NSButton *colorList66;
    IBOutlet NSButton *colorList67;
    IBOutlet NSButton *colorList68;
    IBOutlet NSButton *colorList69;
    IBOutlet NSButton *colorList70;
    IBOutlet NSButton *colorList71;
    IBOutlet NSButton *colorList72;
    IBOutlet NSButton *colorList73;
    IBOutlet NSButton *colorList74;
    IBOutlet NSButton *colorList75;
    IBOutlet NSButton *colorList76;
    IBOutlet NSButton *colorList77;
    IBOutlet NSButton *colorList78;
    IBOutlet NSButton *colorList79;
    IBOutlet NSButton *colorList80;
    IBOutlet NSButton *colorList81;
    IBOutlet NSButton *colorList82;
    IBOutlet NSButton *colorList83;
    IBOutlet NSButton *colorList84;
    IBOutlet NSButton *colorList85;
    IBOutlet NSButton *colorList86;
    IBOutlet NSButton *colorList87;
    IBOutlet NSButton *colorList88;
    IBOutlet NSButton *colorList89;
    IBOutlet NSButton *colorList90;
    IBOutlet NSButton *colorList91;
    IBOutlet NSButton *colorList92;
    IBOutlet NSButton *colorList93;
    IBOutlet NSButton *colorList94;
    IBOutlet NSButton *colorList95;
    IBOutlet NSButton *colorList96;
    IBOutlet NSButton *colorList97;
    IBOutlet NSButton *colorList98;
    IBOutlet NSButton *colorList99;
    IBOutlet NSButton *colorList100;
    IBOutlet NSButton *colorList101;
    IBOutlet NSButton *colorList102;
    IBOutlet NSButton *colorList103;
    IBOutlet NSButton *colorList104;
    IBOutlet NSButton *colorList105;
    IBOutlet NSButton *colorList106;
    IBOutlet NSButton *colorList107;
    IBOutlet NSButton *colorList108;
    IBOutlet NSButton *colorList109;
    IBOutlet NSButton *colorList110;
    IBOutlet NSButton *colorList111;
    IBOutlet NSButton *colorList112;
    IBOutlet NSButton *colorList113;
    IBOutlet NSButton *colorList114;
    IBOutlet NSButton *colorList115;
    IBOutlet NSButton *colorList116;
    IBOutlet NSButton *colorList117;
    IBOutlet NSButton *colorList118;
    IBOutlet NSButton *colorList119;
    IBOutlet NSButton *colorList120;
    IBOutlet NSButton *colorList121;
    IBOutlet NSButton *colorList122;
    IBOutlet NSButton *colorList123;
    IBOutlet NSButton *colorList124;
    IBOutlet NSButton *colorList125;
    IBOutlet NSButton *colorList126;
    IBOutlet NSButton *colorList127;
    IBOutlet NSButton *colorList128;
    IBOutlet NSButton *colorList129;
    IBOutlet NSButton *colorList130;
    IBOutlet NSButton *colorList131;
    IBOutlet NSButton *colorList132;
    
    IBOutlet NSButton *colorListSelected;
    
    IBOutlet NSStepper *stepperGroup;
    
    IBOutlet NSWindow *exportMainWindow;
    NSTimer *exportMainTimer;
    NSTimer *exportMainTimer2;
    
    id ascIIconversion;
    
    IBOutlet NSProgressIndicator *backSave;
    
    NSWindowController *exportMainWindowController;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;
-(void)colorDataSave;

-(IBAction)closeWindow:(id)sender;
-(IBAction)outlineWidthSet:(id)sender;
-(IBAction)outlineSet:(id)sender;
-(IBAction)dotSizeExportSet:(id)sender;
-(IBAction)targetWidthSet:(id)sender;
-(IBAction)targetLengthSet:(id)sender;
-(IBAction)targetFontSet:(id)sender;
-(IBAction)refreshSet:(id)sender;
-(IBAction)lineWidthSet:(id)sender;
-(IBAction)phasePixelSet:(id)sender;

-(IBAction)colorSet1:(id)sender;
-(IBAction)colorSet2:(id)sender;
-(IBAction)colorSet3:(id)sender;
-(IBAction)colorSet4:(id)sender;
-(IBAction)colorSet5:(id)sender;
-(IBAction)colorSet6:(id)sender;
-(IBAction)colorSet7:(id)sender;
-(IBAction)colorSet8:(id)sender;
-(IBAction)colorSet9:(id)sender;
-(IBAction)colorSet10:(id)sender;

/*
 Color setting Order:
 If Sd or Th is On, those will have a priority.
 1. Sd On, Th Off: Sd
 2. Sd Off, Th On: Th
 3. Sd On, Th On: Sd
 4. If Sd Off, Th Off, then 1-10 numbers
 */

-(IBAction)colorNumber1:(id)sender;
-(IBAction)colorNumber2:(id)sender;
-(IBAction)colorNumber3:(id)sender;
-(IBAction)colorNumber4:(id)sender;
-(IBAction)colorNumber5:(id)sender;
-(IBAction)colorNumber6:(id)sender;
-(IBAction)colorNumber7:(id)sender;
-(IBAction)colorNumber8:(id)sender;
-(IBAction)colorNumber9:(id)sender;
-(IBAction)colorNumber10:(id)sender;
-(IBAction)colorNumber11:(id)sender;
-(IBAction)colorNumber12:(id)sender;

-(IBAction)colorSdSet:(id)sender;
-(IBAction)colorSdClear:(id)sender;
-(IBAction)colorThSet:(id)sender;
-(IBAction)colorThClear:(id)sender;
-(IBAction)linePrintColorSet:(id)sender;

-(IBAction)clearColorSetting:(id)sender;
-(IBAction)stepperActionGroup:(id)sender;
-(IBAction)colorPasteStatusSet:(id)sender;
-(IBAction)fontCrossSet:(id)sender;
-(IBAction)creatDataFile:(id)sender;
-(IBAction)refImageProcess1:(id)sender;
-(IBAction)colorSetActivate:(id)sender;
-(IBAction)colorDefaultSet:(id)sender;
-(IBAction)dotStyleSet:(id)sender;
-(IBAction)dotLengthSet:(id)sender;

-(IBAction)colorDataFileLoad:(id)sender;
-(IBAction)colorDataFileSave:(id)sender;
-(IBAction)areaAdjustSet:(id)sender;

/*
 Dot Heat map
 
 Time one: create Dot image that is displayed
 Range: Accumulate dot position within the specified range
 Range+Dens: Accumulate dot position within the specified range and create a heat map, diameter and max value have to set. Export density data: export density data as an txt file.
 
 Action will start by pressing S
 */

-(IBAction)dotDisplaySetSet:(id)sender;
-(IBAction)firstSecondSet:(id)sender;
-(IBAction)exportDensityData:(id)sender;
-(IBAction)gridDivisionSet:(id)sender;
-(IBAction)dotGravityCenterChoiceDiaplay:(id)sender;

-(IBAction)colorListSet1:(id)sender;
-(IBAction)colorListSet2:(id)sender;
-(IBAction)colorListSet3:(id)sender;
-(IBAction)colorListSet4:(id)sender;
-(IBAction)colorListSet5:(id)sender;
-(IBAction)colorListSet6:(id)sender;
-(IBAction)colorListSet7:(id)sender;
-(IBAction)colorListSet8:(id)sender;
-(IBAction)colorListSet9:(id)sender;
-(IBAction)colorListSet10:(id)sender;
-(IBAction)colorListSet11:(id)sender;
-(IBAction)colorListSet12:(id)sender;

-(IBAction)colorListSet13:(id)sender;
-(IBAction)colorListSet14:(id)sender;
-(IBAction)colorListSet15:(id)sender;
-(IBAction)colorListSet16:(id)sender;
-(IBAction)colorListSet17:(id)sender;
-(IBAction)colorListSet18:(id)sender;
-(IBAction)colorListSet19:(id)sender;
-(IBAction)colorListSet20:(id)sender;
-(IBAction)colorListSet21:(id)sender;
-(IBAction)colorListSet22:(id)sender;
-(IBAction)colorListSet23:(id)sender;
-(IBAction)colorListSet24:(id)sender;

-(IBAction)colorListSet25:(id)sender;
-(IBAction)colorListSet26:(id)sender;
-(IBAction)colorListSet27:(id)sender;
-(IBAction)colorListSet28:(id)sender;
-(IBAction)colorListSet29:(id)sender;
-(IBAction)colorListSet30:(id)sender;
-(IBAction)colorListSet31:(id)sender;
-(IBAction)colorListSet32:(id)sender;
-(IBAction)colorListSet33:(id)sender;
-(IBAction)colorListSet34:(id)sender;
-(IBAction)colorListSet35:(id)sender;
-(IBAction)colorListSet36:(id)sender;

-(IBAction)colorListSet37:(id)sender;
-(IBAction)colorListSet38:(id)sender;
-(IBAction)colorListSet39:(id)sender;
-(IBAction)colorListSet40:(id)sender;
-(IBAction)colorListSet41:(id)sender;
-(IBAction)colorListSet42:(id)sender;
-(IBAction)colorListSet43:(id)sender;
-(IBAction)colorListSet44:(id)sender;
-(IBAction)colorListSet45:(id)sender;
-(IBAction)colorListSet46:(id)sender;
-(IBAction)colorListSet47:(id)sender;
-(IBAction)colorListSet48:(id)sender;

-(IBAction)colorListSet49:(id)sender;
-(IBAction)colorListSet50:(id)sender;
-(IBAction)colorListSet51:(id)sender;
-(IBAction)colorListSet52:(id)sender;
-(IBAction)colorListSet53:(id)sender;
-(IBAction)colorListSet54:(id)sender;
-(IBAction)colorListSet55:(id)sender;
-(IBAction)colorListSet56:(id)sender;
-(IBAction)colorListSet57:(id)sender;
-(IBAction)colorListSet58:(id)sender;
-(IBAction)colorListSet59:(id)sender;
-(IBAction)colorListSet60:(id)sender;

-(IBAction)colorListSet61:(id)sender;
-(IBAction)colorListSet62:(id)sender;
-(IBAction)colorListSet63:(id)sender;
-(IBAction)colorListSet64:(id)sender;
-(IBAction)colorListSet65:(id)sender;
-(IBAction)colorListSet66:(id)sender;
-(IBAction)colorListSet67:(id)sender;
-(IBAction)colorListSet68:(id)sender;
-(IBAction)colorListSet69:(id)sender;
-(IBAction)colorListSet70:(id)sender;
-(IBAction)colorListSet71:(id)sender;
-(IBAction)colorListSet72:(id)sender;

-(IBAction)colorListSet73:(id)sender;
-(IBAction)colorListSet74:(id)sender;
-(IBAction)colorListSet75:(id)sender;
-(IBAction)colorListSet76:(id)sender;
-(IBAction)colorListSet77:(id)sender;
-(IBAction)colorListSet78:(id)sender;
-(IBAction)colorListSet79:(id)sender;
-(IBAction)colorListSet80:(id)sender;
-(IBAction)colorListSet81:(id)sender;
-(IBAction)colorListSet82:(id)sender;
-(IBAction)colorListSet83:(id)sender;
-(IBAction)colorListSet84:(id)sender;

-(IBAction)colorListSet85:(id)sender;
-(IBAction)colorListSet86:(id)sender;
-(IBAction)colorListSet87:(id)sender;
-(IBAction)colorListSet88:(id)sender;
-(IBAction)colorListSet89:(id)sender;
-(IBAction)colorListSet90:(id)sender;
-(IBAction)colorListSet91:(id)sender;
-(IBAction)colorListSet92:(id)sender;
-(IBAction)colorListSet93:(id)sender;
-(IBAction)colorListSet94:(id)sender;
-(IBAction)colorListSet95:(id)sender;
-(IBAction)colorListSet96:(id)sender;

-(IBAction)colorListSet97:(id)sender;
-(IBAction)colorListSet98:(id)sender;
-(IBAction)colorListSet99:(id)sender;
-(IBAction)colorListSet100:(id)sender;
-(IBAction)colorListSet101:(id)sender;
-(IBAction)colorListSet102:(id)sender;
-(IBAction)colorListSet103:(id)sender;
-(IBAction)colorListSet104:(id)sender;
-(IBAction)colorListSet105:(id)sender;
-(IBAction)colorListSet106:(id)sender;
-(IBAction)colorListSet107:(id)sender;
-(IBAction)colorListSet108:(id)sender;

-(IBAction)colorListSet109:(id)sender;
-(IBAction)colorListSet110:(id)sender;
-(IBAction)colorListSet111:(id)sender;
-(IBAction)colorListSet112:(id)sender;
-(IBAction)colorListSet113:(id)sender;
-(IBAction)colorListSet114:(id)sender;
-(IBAction)colorListSet115:(id)sender;
-(IBAction)colorListSet116:(id)sender;
-(IBAction)colorListSet117:(id)sender;
-(IBAction)colorListSet118:(id)sender;
-(IBAction)colorListSet119:(id)sender;
-(IBAction)colorListSet120:(id)sender;

-(IBAction)colorListSet121:(id)sender;
-(IBAction)colorListSet122:(id)sender;
-(IBAction)colorListSet123:(id)sender;
-(IBAction)colorListSet124:(id)sender;
-(IBAction)colorListSet125:(id)sender;
-(IBAction)colorListSet126:(id)sender;
-(IBAction)colorListSet127:(id)sender;
-(IBAction)colorListSet128:(id)sender;
-(IBAction)colorListSet129:(id)sender;
-(IBAction)colorListSet130:(id)sender;
-(IBAction)colorListSet131:(id)sender;
-(IBAction)colorListSet132:(id)sender;

@end
