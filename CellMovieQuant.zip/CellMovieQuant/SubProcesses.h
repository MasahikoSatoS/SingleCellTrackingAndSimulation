//
//  SubProcesses.h
//  CellMovieQuant
//
//  Created by Masahiko Sato on 2021-12-26.
//

#ifndef SUBPROCESSES_H
#define SUBPROCESSES_H
#import "Controller.h"
#endif

@interface SubProcesses : NSObject{
}

-(void)areaTotalDataSet;

@end
