//
//  LineDotTypeSet.h
//  CellMovieQuant
//
//  Created by Masahiko Sato on 2021-12-29.
//

#ifndef LINEDOTTYPESET_H
#define LINEDOTTYPESET_H
#import "Controller.h"
#endif

@interface LineDotTypeSet : NSObject{
    IBOutlet NSTextField *lineSizeDisplay;
    IBOutlet NSTextField *cutLineDisplay;
}

-(IBAction)lineTargetColorRed:(id)sender;
-(IBAction)lineTargetColorGreen:(id)sender;
-(IBAction)lineTargetColorOrange:(id)sender;
-(IBAction)lineTargetColorYellow:(id)sender;
-(IBAction)lineTargetColorBlue:(id)sender;
-(IBAction)lineTargetColorBlack:(id)sender;
-(IBAction)lineTargetColorClear:(id)sender;

-(IBAction)lineTargetWidth1:(id)sender;
-(IBAction)lineTargetWidth2:(id)sender;
-(IBAction)lineTargetWidth4:(id)sender;

-(IBAction)gridColorRed:(id)sender;
-(IBAction)gridColorGreen:(id)sender;
-(IBAction)gridColorOrange:(id)sender;
-(IBAction)gridColorYellow:(id)sender;
-(IBAction)gridColorBlue:(id)sender;
-(IBAction)gridColorBlack:(id)sender;
-(IBAction)gridColorWhite:(id)sender;

-(IBAction)gridWidth1:(id)sender;
-(IBAction)gridWidth2:(id)sender;
-(IBAction)gridWidth4:(id)sender;

-(IBAction)dotStatusFillSet:(id)sender;
-(IBAction)dotStatusStrokeSet:(id)sender;

-(IBAction)dotLength1:(id)sender;
-(IBAction)dotLength2:(id)sender;
-(IBAction)dotLength3:(id)sender;

-(IBAction)removeDotDataFile:(id)sender;

-(IBAction)lineSizeSet:(id)sender;
-(IBAction)cutLIneSet:(id)sender;

@end
