//
//  ASCIIconversion.h
//  CellMovieQuant
//
//  Created by Masahiko Sato on 29/05/11, 28/05/13 revised.
//  Copyright 2011 Masahiko Sato. All rights reserved.
//

/*Version B: Text conversion data will be saved in an array*/

#ifndef ASCIICONVERSION_H
#define ASCIICONVERSION_H
#import "Controller.h"
#endif

@interface ASCIIconversion : NSObject{
}

-(int)ascIICode:(int*)arrayAscIIintData;
-(void)ascIIConversion2:(int)ascIIint;

@end
