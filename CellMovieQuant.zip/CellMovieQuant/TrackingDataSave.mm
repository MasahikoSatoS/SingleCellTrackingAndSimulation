//
// TrackingDataSave.mm
// CellMovieQuant
//
// Created by Masahiko Sato on 13/10/02.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "TrackingDataSave.h"

@implementation TrackingDataSave

-(void)trackingDataSaveTemp: (int)timeSet{
    string extension = to_string(timeSet);
    
    if (extension.length() == 1) extension = "000"+extension;
    else if (extension.length() == 2) extension = "00"+extension;
    else if (extension.length() == 3) extension = "0"+extension;
    
    string connectDataRevPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_MasterData";
    
    int dataTemp = 0;
    
    if (positionReviseCount != 0){
        int readBit [4];
        long indexCount = 0;
        
        char *writingArray = new char [(positionReviseCount/7+gravityCenterRevCount/6)*17+50];
        
        for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
            dataTemp = arrayPositionRevise [counter1*7];
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            dataTemp = arrayPositionRevise [counter1*7+1];
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            writingArray [indexCount] = (char)arrayPositionRevise [counter1*7+2], indexCount++;
            
            dataTemp = arrayPositionRevise [counter1*7+3];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayPositionRevise [counter1*7+4];
            
            if (dataTemp < 0) dataTemp = dataTemp*-1, writingArray [indexCount] = 1, indexCount++;
            else writingArray [indexCount] = 0, indexCount++;
            
            readBit [0] = dataTemp/16777216;
            dataTemp = dataTemp%16777216;
            readBit [1] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [2] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [3] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            writingArray [indexCount] = (char)readBit [3], indexCount++;
            
            writingArray [indexCount] = (char)arrayPositionRevise [counter1*7+5], indexCount++;
            
            dataTemp = arrayPositionRevise [counter1*7+6];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
        }
        
        for (int counter1 = 0; counter1 < 17; counter1++) writingArray [indexCount] = 0, indexCount++;
        
        for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
            dataTemp = arrayGravityCenterRev [counter1*6];
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            dataTemp = arrayGravityCenterRev [counter1*6+1];
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            dataTemp = arrayGravityCenterRev [counter1*6+2];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = (char)arrayGravityCenterRev [counter1*6+3], indexCount++;
            
            dataTemp = arrayGravityCenterRev [counter1*6+4];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = (char)arrayGravityCenterRev [counter1*6+5], indexCount++;
        }
        
        for (int counter1 = 0; counter1 < 11; counter1++) writingArray [indexCount] = 0, indexCount++;
        
        ofstream outfile (connectDataRevPath.c_str(), ofstream::binary);
        outfile.write ((char*)writingArray, indexCount);
        outfile.close();
        
        delete [] writingArray;
    }
    
    //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
    //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
    //	cout<<" arrayPositionRevise "<<counterA<<endl;
    //}
    
    string connectStatusDataPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_Status";
    
    if (timeSelectedCount != 0){
        char *writingArray = new char [timeSelectedCount/10*19+20];
        
        long indexCount = 0;
        int readBit [3];
        int connectNumberTemp = 0;
        
        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
            writingArray [indexCount] = (char)arrayTimeSelected [counter1*10], indexCount++;
            writingArray [indexCount] = 0, indexCount++;
            writingArray [indexCount] = 0, indexCount++;
            writingArray [indexCount] = 0, indexCount++;
            
            dataTemp = arrayTimeSelected [counter1*10+2];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = 0, indexCount++;
            writingArray [indexCount] = 0, indexCount++;
            
            writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+4], indexCount++;
            writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+5], indexCount++;
            writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+6], indexCount++;
            writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+7], indexCount++;
            
            dataTemp = arrayTimeSelected [counter1*10+8];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            if (arrayTimeSelected [counter1*10] == 3 || arrayTimeSelected [counter1*10] == 4) connectNumberTemp = 0;
            else connectNumberTemp = arrayTimeSelected [counter1*10+9];
            
            dataTemp = connectNumberTemp;
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
        }
        
        for (int counter1 = 0; counter1 < 19; counter1++) writingArray [indexCount] = 0, indexCount++;
        
        ofstream outfile2 (connectStatusDataPath.c_str(), ofstream::binary);
        outfile2.write ((char*) writingArray, indexCount);
        outfile2.close();
        
        delete [] writingArray;
    }
    
    //------Save Revised Map------
    string revisedMapPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_RevisedMap";
    
    if (imageXYLength != 0){
        int totalMapSizeTemp = imageXYLength*imageXYLength*4+1;
        
        char *dataHold = new char [totalMapSizeTemp];
        int indexCount = 0;
        int dataTemp2 = 0;
        int entryCount = 0;
        int readBit [4];
        
        for (int counterX = 0; counterX < imageXYLength; counterX++){
            for (int counterY = 0; counterY < imageXYLength; counterY++){
                dataTemp = revisedWorkingMap [counterX][counterY];
                
                if (counterY == 0) dataTemp2 = dataTemp, entryCount++;
                else if (dataTemp != dataTemp2 || entryCount == 254 || counterY == imageXYLength-1){
                    readBit [0] = dataTemp2/65536;
                    dataTemp2 = dataTemp2%65536;
                    readBit [1] = dataTemp2/256;
                    dataTemp2 = dataTemp2%256;
                    readBit [2] = dataTemp2;
                    
                    if (counterY == imageXYLength-1){
                        if (dataTemp != dataTemp2){
                            dataHold [indexCount] = (char)readBit [0], indexCount++;
                            dataHold [indexCount] = (char)readBit [1], indexCount++;
                            dataHold [indexCount] = (char)readBit [2], indexCount++;
                            dataHold [indexCount] = (char)entryCount, indexCount++;
                            
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            entryCount = 1;
                            
                            dataHold [indexCount] = (char)readBit [0], indexCount++;
                            dataHold [indexCount] = (char)readBit [1], indexCount++;
                            dataHold [indexCount] = (char)readBit [2], indexCount++;
                            dataHold [indexCount] = (char)entryCount, indexCount++;
                        }
                        else{
                            
                            entryCount++;
                            
                            dataHold [indexCount] = (char)readBit [0], indexCount++;
                            dataHold [indexCount] = (char)readBit [1], indexCount++;
                            dataHold [indexCount] = (char)readBit [2], indexCount++;
                            dataHold [indexCount] = (char)entryCount, indexCount++;
                        }
                    }
                    else{
                        
                        dataHold [indexCount] = (char)readBit [0], indexCount++;
                        dataHold [indexCount] = (char)readBit [1], indexCount++;
                        dataHold [indexCount] = (char)readBit [2], indexCount++;
                        dataHold [indexCount] = (char)entryCount, indexCount++;
                    }
                    
                    if (counterY == imageXYLength-1) entryCount = 0;
                    else entryCount = 1, dataTemp2 = dataTemp;
                }
                else entryCount++;
            }
        }
        
        ofstream outfile2 (revisedMapPath.c_str(), ofstream::binary);
        outfile2.write(dataHold, indexCount);
        outfile2.close();
        
        delete [] dataHold;
    }
}

@end
