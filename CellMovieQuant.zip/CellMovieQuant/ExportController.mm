//
//  ExportController.m
//  CellMovieQuant
//
//  Created by Masahiko Sato on 2019-10-25.
//

#import "ExportController.h"

NSString *notificationToExportController = @"notificationExecuteExportController";

@implementation ExportController

-(id)init{
    self = [super init];
    
    if (self != nil){
        currentRangeHold = 0;
        refStatusHold1 = 0;
        colorListNoHold = 0;
        colorSetStatusHold = 0;
        areaAdjustStatusHold = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToExportController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    exportMainWindowController = [[NSWindowController alloc] initWithWindowNibName:@"ExportWindow"];
    [exportMainWindowController showWindow:nil];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToExportDisplay object:nil];
}

-(void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [exportMainWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [exportMainWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [colorMaxAreaDisplay setDelegate:self];
    [colorMaxAreaDisplay setIntegerValue:colorMaxAreaHold];
    
    [dotMinDisplay setDelegate:self];
    [dotMaxDisplay setDelegate:self];
    [densityDiameterDisplay setDelegate:self];
    [densityMaxDisplay setDelegate:self];
    
    string rangeValue;
    
    if (colorHoldArea1 != 0){
        rangeValue = "1: "+to_string(colorHoldArea1);
        [rangeDisplay1 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold1*3] green:arrayColorRange [colorHold1*3+1] blue:arrayColorRange [colorHold1*3+2] alpha:1]];
        [rangeDisplay1 setStringValue:@(rangeValue.c_str())];
        
        if (colorHoldArea2 == 0){
            rangeValue = "2: "+to_string(colorHoldArea1)+"+";
            [rangeDisplay2 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold2*3] green:arrayColorRange [colorHold2*3+1] blue:arrayColorRange [colorHold2*3+2] alpha:1]];
            [rangeDisplay2 setStringValue:@(rangeValue.c_str())];
        }
    }
    
    if (colorHoldArea2 != 0){
        rangeValue = "2: "+to_string(colorHoldArea2);
        [rangeDisplay2 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold2*3] green:arrayColorRange [colorHold2*3+1] blue:arrayColorRange [colorHold2*3+2] alpha:1]];
        [rangeDisplay2 setStringValue:@(rangeValue.c_str())];
        
        if (colorHoldArea3 == 0){
            rangeValue = "3: "+to_string(colorHoldArea2)+"+";
            [rangeDisplay3 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold3*3] green:arrayColorRange [colorHold3*3+1] blue:arrayColorRange [colorHold3*3+2] alpha:1]];
            [rangeDisplay3 setStringValue:@(rangeValue.c_str())];
        }
    }
    
    if (colorHoldArea3 != 0){
        rangeValue = "3: "+to_string(colorHoldArea3);
        [rangeDisplay3 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold3*3] green:arrayColorRange [colorHold3*3+1] blue:arrayColorRange [colorHold3*3+2] alpha:1]];
        [rangeDisplay3 setStringValue:@(rangeValue.c_str())];
        
        if (colorHoldArea4 == 0){
            rangeValue = "4: "+to_string(colorHoldArea3)+"+";
            [rangeDisplay4 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold4*3] green:arrayColorRange [colorHold4*3+1] blue:arrayColorRange [colorHold4*3+2] alpha:1]];
            [rangeDisplay4 setStringValue:@(rangeValue.c_str())];
        }
    }
    
    if (colorHoldArea4 != 0){
        rangeValue = "4: "+to_string(colorHoldArea4);
        [rangeDisplay4 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold4*3] green:arrayColorRange [colorHold4*3+1] blue:arrayColorRange [colorHold4*3+2] alpha:1]];
        [rangeDisplay4 setStringValue:@(rangeValue.c_str())];
        
        if (colorHoldArea5 == 0){
            rangeValue = "5: "+to_string(colorHoldArea4)+"+";
            [rangeDisplay5 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold5*3] green:arrayColorRange [colorHold5*3+1] blue:arrayColorRange [colorHold5*3+2] alpha:1]];
            [rangeDisplay5 setStringValue:@(rangeValue.c_str())];
        }
    }
    
    if (colorHoldArea5 != 0){
        rangeValue = "5: "+to_string(colorHoldArea5);
        [rangeDisplay5 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold5*3] green:arrayColorRange [colorHold5*3+1] blue:arrayColorRange [colorHold5*3+2] alpha:1]];
        [rangeDisplay5 setStringValue:@(rangeValue.c_str())];
        
        if (colorHoldArea6 == 0){
            rangeValue = "6: "+to_string(colorHoldArea5)+"+";
            [rangeDisplay6 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold6*3] green:arrayColorRange [colorHold6*3+1] blue:arrayColorRange [colorHold6*3+2] alpha:1]];
            [rangeDisplay6 setStringValue:@(rangeValue.c_str())];
        }
    }
    
    if (colorHoldArea6 != 0){
        rangeValue = "6: "+to_string(colorHoldArea6);
        [rangeDisplay6 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold6*3] green:arrayColorRange [colorHold6*3+1] blue:arrayColorRange [colorHold6*3+2] alpha:1]];
        [rangeDisplay6 setStringValue:@(rangeValue.c_str())];
        
        if (colorHoldArea7 == 0){
            rangeValue = "7: "+to_string(colorHoldArea6)+"+";
            [rangeDisplay7 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold7*3] green:arrayColorRange [colorHold7*3+1] blue:arrayColorRange [colorHold7*3+2] alpha:1]];
            [rangeDisplay7 setStringValue:@(rangeValue.c_str())];
        }
    }
    
    if (colorHoldArea7 != 0){
        rangeValue = "7: "+to_string(colorHoldArea7);
        [rangeDisplay7 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold7*3] green:arrayColorRange [colorHold7*3+1] blue:arrayColorRange [colorHold7*3+2] alpha:1]];
        [rangeDisplay7 setStringValue:@(rangeValue.c_str())];
        
        if (colorHoldArea8 == 0){
            rangeValue = "8: "+to_string(colorHoldArea7)+"+";
            [rangeDisplay8 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold8*3] green:arrayColorRange [colorHold8*3+1] blue:arrayColorRange [colorHold8*3+2] alpha:1]];
            [rangeDisplay8 setStringValue:@(rangeValue.c_str())];
        }
    }
    
    if (colorHoldArea8 != 0){
        rangeValue = "8: "+to_string(colorHoldArea8);
        [rangeDisplay8 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold8*3] green:arrayColorRange [colorHold8*3+1] blue:arrayColorRange [colorHold8*3+2] alpha:1]];
        [rangeDisplay8 setStringValue:@(rangeValue.c_str())];
        
        if (colorHoldArea9 == 0){
            rangeValue = "9: "+to_string(colorHoldArea8)+"+";
            [rangeDisplay9 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold9*3] green:arrayColorRange [colorHold9*3+1] blue:arrayColorRange [colorHold9*3+2] alpha:1]];
            [rangeDisplay9 setStringValue:@(rangeValue.c_str())];
        }
    }
    
    if (colorHoldArea9 != 0){
        rangeValue = "9: "+to_string(colorHoldArea9);
        [rangeDisplay9 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold9*3] green:arrayColorRange [colorHold9*3+1] blue:arrayColorRange [colorHold9*3+2] alpha:1]];
        [rangeDisplay9 setStringValue:@(rangeValue.c_str())];
        
        rangeValue = "10: "+to_string(colorHoldArea9)+"+";
        [rangeDisplay10 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold10*3] green:arrayColorRange [colorHold10*3+1] blue:arrayColorRange [colorHold10*3+2] alpha:1]];
        [rangeDisplay10 setStringValue:@(rangeValue.c_str())];
    }
    
    if (colorHoldSdStatus != 0){
        rangeValue = "Sd:";
        [colorSdDisplay setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHoldSd*3] green:arrayColorRange [colorHoldSd*3+1] blue:arrayColorRange [colorHoldSd*3+2] alpha:1]];
        [colorSdDisplay setStringValue:@(rangeValue.c_str())];
    }
    
    if (colorHoldSdStatus != 0){
        rangeValue = "Sd:";
        [colorSdDisplay setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHoldSd*3] green:arrayColorRange [colorHoldSd*3+1] blue:arrayColorRange [colorHoldSd*3+2] alpha:1]];
        [colorSdDisplay setStringValue:@(rangeValue.c_str())];
    }
    else{
        
        rangeValue = "Sd:";
        [colorSdDisplay setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:0 alpha:1]];
        [colorSdDisplay setStringValue:@(rangeValue.c_str())];
    }
    
    if (colorHoldThStatus != 0){
        rangeValue = "Th:";
        [colorThDisplay setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHoldTh*3] green:arrayColorRange [colorHoldTh*3+1] blue:arrayColorRange [colorHoldTh*3+2] alpha:1]];
        [colorThDisplay setStringValue:@(rangeValue.c_str())];
    }
    
    if (colorHoldThStatus != 0){
        rangeValue = "Th:";
        [colorThDisplay setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHoldTh*3] green:arrayColorRange [colorHoldTh*3+1] blue:arrayColorRange [colorHoldTh*3+2] alpha:1]];
        [colorThDisplay setStringValue:@(rangeValue.c_str())];
    }
    else{
        
        rangeValue = "Th:";
        [colorThDisplay setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:0 alpha:1]];
        [colorThDisplay setStringValue:@(rangeValue.c_str())];
    }
    
    if (exportOperation == 1){
        [[colorButton1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [3] green:arrayColorRange [4] blue:arrayColorRange [5] alpha:1]];
        [[colorButton2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [6] green:arrayColorRange [7] blue:arrayColorRange [8] alpha:1]];
        [[colorButton3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [9] green:arrayColorRange [10] blue:arrayColorRange [11] alpha:1]];
        [[colorButton4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [12] green:arrayColorRange [13] blue:arrayColorRange [14] alpha:1]];
        [[colorButton5 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [15] green:arrayColorRange [16] blue:arrayColorRange [17] alpha:1]];
        [[colorButton6 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [18] green:arrayColorRange [19] blue:arrayColorRange [20] alpha:1]];
        [[colorButton7 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [21] green:arrayColorRange [22] blue:arrayColorRange [23] alpha:1]];
        [[colorButton8 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [24] green:arrayColorRange [25] blue:arrayColorRange [26] alpha:1]];
        [[colorButton9 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [27] green:arrayColorRange [28] blue:arrayColorRange [29] alpha:1]];
        [[colorButton10 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [30] green:arrayColorRange [31] blue:arrayColorRange [32] alpha:1]];
        [[colorButton11 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [33] green:arrayColorRange [34] blue:arrayColorRange [35] alpha:1]];
        [[colorButton12 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [36] green:arrayColorRange [37] blue:arrayColorRange [38] alpha:1]];
        
        [[colorList1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [0] green:arrayColorRangeSource [1] blue:arrayColorRangeSource [2] alpha:1]];
        [[colorList2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [3] green:arrayColorRangeSource [4] blue:arrayColorRangeSource [5] alpha:1]];
        [[colorList3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [6] green:arrayColorRangeSource [7] blue:arrayColorRangeSource [8] alpha:1]];
        [[colorList4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [9] green:arrayColorRangeSource [10] blue:arrayColorRangeSource [11] alpha:1]];
        [[colorList5 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [12] green:arrayColorRangeSource [13] blue:arrayColorRangeSource [14] alpha:1]];
        [[colorList6 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [15] green:arrayColorRangeSource [16] blue:arrayColorRangeSource [17] alpha:1]];
        [[colorList7 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [18] green:arrayColorRangeSource [19] blue:arrayColorRangeSource [20] alpha:1]];
        [[colorList8 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [21] green:arrayColorRangeSource [22] blue:arrayColorRangeSource [23] alpha:1]];
        [[colorList9 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [24] green:arrayColorRangeSource [25] blue:arrayColorRangeSource [26] alpha:1]];
        [[colorList10 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [27] green:arrayColorRangeSource [28] blue:arrayColorRangeSource [29] alpha:1]];
        [[colorList11 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [30] green:arrayColorRangeSource [31] blue:arrayColorRangeSource [32] alpha:1]];
        [[colorList12 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [33] green:arrayColorRangeSource [34] blue:arrayColorRangeSource [35] alpha:1]];
        
        [[colorList13 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [36] green:arrayColorRangeSource [37] blue:arrayColorRangeSource [38] alpha:1]];
        [[colorList14 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [39] green:arrayColorRangeSource [40] blue:arrayColorRangeSource [41] alpha:1]];
        [[colorList15 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [42] green:arrayColorRangeSource [43] blue:arrayColorRangeSource [44] alpha:1]];
        [[colorList16 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [45] green:arrayColorRangeSource [46] blue:arrayColorRangeSource [47] alpha:1]];
        [[colorList17 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [48] green:arrayColorRangeSource [49] blue:arrayColorRangeSource [50] alpha:1]];
        [[colorList18 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [51] green:arrayColorRangeSource [52] blue:arrayColorRangeSource [53] alpha:1]];
        [[colorList19 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [54] green:arrayColorRangeSource [55] blue:arrayColorRangeSource [56] alpha:1]];
        [[colorList20 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [57] green:arrayColorRangeSource [58] blue:arrayColorRangeSource [59] alpha:1]];
        [[colorList21 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [60] green:arrayColorRangeSource [61] blue:arrayColorRangeSource [62] alpha:1]];
        [[colorList22 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [63] green:arrayColorRangeSource [64] blue:arrayColorRangeSource [65] alpha:1]];
        [[colorList23 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [66] green:arrayColorRangeSource [67] blue:arrayColorRangeSource [68] alpha:1]];
        [[colorList24 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [69] green:arrayColorRangeSource [70] blue:arrayColorRangeSource [71] alpha:1]];
        
        [[colorList25 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [72] green:arrayColorRangeSource [73] blue:arrayColorRangeSource [74] alpha:1]];
        [[colorList26 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [75] green:arrayColorRangeSource [76] blue:arrayColorRangeSource [77] alpha:1]];
        [[colorList27 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [78] green:arrayColorRangeSource [79] blue:arrayColorRangeSource [80] alpha:1]];
        [[colorList28 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [81] green:arrayColorRangeSource [82] blue:arrayColorRangeSource [83] alpha:1]];
        [[colorList29 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [84] green:arrayColorRangeSource [85] blue:arrayColorRangeSource [86] alpha:1]];
        [[colorList30 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [87] green:arrayColorRangeSource [88] blue:arrayColorRangeSource [89] alpha:1]];
        [[colorList31 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [90] green:arrayColorRangeSource [91] blue:arrayColorRangeSource [92] alpha:1]];
        [[colorList32 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [93] green:arrayColorRangeSource [94] blue:arrayColorRangeSource [95] alpha:1]];
        [[colorList33 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [96] green:arrayColorRangeSource [97] blue:arrayColorRangeSource [98] alpha:1]];
        [[colorList34 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [99] green:arrayColorRangeSource [100] blue:arrayColorRangeSource [101] alpha:1]];
        [[colorList35 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [102] green:arrayColorRangeSource [103] blue:arrayColorRangeSource [104] alpha:1]];
        [[colorList36 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [105] green:arrayColorRangeSource [106] blue:arrayColorRangeSource [107] alpha:1]];
        
        [[colorList37 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [108] green:arrayColorRangeSource [109] blue:arrayColorRangeSource [110] alpha:1]];
        [[colorList38 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [111] green:arrayColorRangeSource [112] blue:arrayColorRangeSource [113] alpha:1]];
        [[colorList39 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [114] green:arrayColorRangeSource [115] blue:arrayColorRangeSource [116] alpha:1]];
        [[colorList40 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [117] green:arrayColorRangeSource [118] blue:arrayColorRangeSource [119] alpha:1]];
        [[colorList41 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [120] green:arrayColorRangeSource [121] blue:arrayColorRangeSource [122] alpha:1]];
        [[colorList42 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [123] green:arrayColorRangeSource [124] blue:arrayColorRangeSource [125] alpha:1]];
        [[colorList43 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [126] green:arrayColorRangeSource [127] blue:arrayColorRangeSource [128] alpha:1]];
        [[colorList44 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [129] green:arrayColorRangeSource [130] blue:arrayColorRangeSource [131] alpha:1]];
        [[colorList45 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [132] green:arrayColorRangeSource [133] blue:arrayColorRangeSource [134] alpha:1]];
        [[colorList46 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [135] green:arrayColorRangeSource [136] blue:arrayColorRangeSource [137] alpha:1]];
        [[colorList47 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [138] green:arrayColorRangeSource [139] blue:arrayColorRangeSource [140] alpha:1]];
        [[colorList48 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [141] green:arrayColorRangeSource [142] blue:arrayColorRangeSource [143] alpha:1]];
        
        [[colorList49 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [144] green:arrayColorRangeSource [145] blue:arrayColorRangeSource [146] alpha:1]];
        [[colorList50 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [147] green:arrayColorRangeSource [148] blue:arrayColorRangeSource [149] alpha:1]];
        [[colorList51 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [150] green:arrayColorRangeSource [151] blue:arrayColorRangeSource [152] alpha:1]];
        [[colorList52 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [153] green:arrayColorRangeSource [154] blue:arrayColorRangeSource [155] alpha:1]];
        [[colorList53 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [156] green:arrayColorRangeSource [157] blue:arrayColorRangeSource [158] alpha:1]];
        [[colorList54 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [159] green:arrayColorRangeSource [160] blue:arrayColorRangeSource [161] alpha:1]];
        [[colorList55 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [162] green:arrayColorRangeSource [163] blue:arrayColorRangeSource [164] alpha:1]];
        [[colorList56 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [165] green:arrayColorRangeSource [166] blue:arrayColorRangeSource [167] alpha:1]];
        [[colorList57 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [168] green:arrayColorRangeSource [169] blue:arrayColorRangeSource [170] alpha:1]];
        [[colorList58 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [171] green:arrayColorRangeSource [172] blue:arrayColorRangeSource [173] alpha:1]];
        [[colorList59 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [174] green:arrayColorRangeSource [175] blue:arrayColorRangeSource [176] alpha:1]];
        [[colorList60 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [177] green:arrayColorRangeSource [178] blue:arrayColorRangeSource [179] alpha:1]];
        
        [[colorList61 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [180] green:arrayColorRangeSource [181] blue:arrayColorRangeSource [182] alpha:1]];
        [[colorList62 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [183] green:arrayColorRangeSource [184] blue:arrayColorRangeSource [185] alpha:1]];
        [[colorList63 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [186] green:arrayColorRangeSource [187] blue:arrayColorRangeSource [188] alpha:1]];
        [[colorList64 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [189] green:arrayColorRangeSource [190] blue:arrayColorRangeSource [191] alpha:1]];
        [[colorList65 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [192] green:arrayColorRangeSource [193] blue:arrayColorRangeSource [194] alpha:1]];
        [[colorList66 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [195] green:arrayColorRangeSource [196] blue:arrayColorRangeSource [197] alpha:1]];
        [[colorList67 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [198] green:arrayColorRangeSource [199] blue:arrayColorRangeSource [200] alpha:1]];
        [[colorList68 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [201] green:arrayColorRangeSource [202] blue:arrayColorRangeSource [203] alpha:1]];
        [[colorList69 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [204] green:arrayColorRangeSource [205] blue:arrayColorRangeSource [206] alpha:1]];
        [[colorList70 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [207] green:arrayColorRangeSource [208] blue:arrayColorRangeSource [209] alpha:1]];
        [[colorList71 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [210] green:arrayColorRangeSource [211] blue:arrayColorRangeSource [212] alpha:1]];
        [[colorList72 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [213] green:arrayColorRangeSource [214] blue:arrayColorRangeSource [215] alpha:1]];
        
        [[colorList73 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [216] green:arrayColorRangeSource [217] blue:arrayColorRangeSource [218] alpha:1]];
        [[colorList74 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [219] green:arrayColorRangeSource [220] blue:arrayColorRangeSource [221] alpha:1]];
        [[colorList75 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [222] green:arrayColorRangeSource [223] blue:arrayColorRangeSource [224] alpha:1]];
        [[colorList76 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [225] green:arrayColorRangeSource [226] blue:arrayColorRangeSource [227] alpha:1]];
        [[colorList77 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [228] green:arrayColorRangeSource [229] blue:arrayColorRangeSource [230] alpha:1]];
        [[colorList78 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [231] green:arrayColorRangeSource [232] blue:arrayColorRangeSource [233] alpha:1]];
        [[colorList79 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [234] green:arrayColorRangeSource [235] blue:arrayColorRangeSource [236] alpha:1]];
        [[colorList80 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [237] green:arrayColorRangeSource [238] blue:arrayColorRangeSource [239] alpha:1]];
        [[colorList81 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [240] green:arrayColorRangeSource [241] blue:arrayColorRangeSource [242] alpha:1]];
        [[colorList82 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [243] green:arrayColorRangeSource [244] blue:arrayColorRangeSource [245] alpha:1]];
        [[colorList83 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [246] green:arrayColorRangeSource [247] blue:arrayColorRangeSource [248] alpha:1]];
        [[colorList84 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [249] green:arrayColorRangeSource [250] blue:arrayColorRangeSource [251] alpha:1]];
        
        [[colorList85 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [252] green:arrayColorRangeSource [253] blue:arrayColorRangeSource [254] alpha:1]];
        [[colorList86 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [255] green:arrayColorRangeSource [256] blue:arrayColorRangeSource [257] alpha:1]];
        [[colorList87 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [258] green:arrayColorRangeSource [259] blue:arrayColorRangeSource [260] alpha:1]];
        [[colorList88 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [261] green:arrayColorRangeSource [262] blue:arrayColorRangeSource [263] alpha:1]];
        [[colorList89 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [264] green:arrayColorRangeSource [265] blue:arrayColorRangeSource [266] alpha:1]];
        [[colorList90 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [267] green:arrayColorRangeSource [268] blue:arrayColorRangeSource [269] alpha:1]];
        [[colorList91 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [270] green:arrayColorRangeSource [271] blue:arrayColorRangeSource [272] alpha:1]];
        [[colorList92 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [273] green:arrayColorRangeSource [274] blue:arrayColorRangeSource [275] alpha:1]];
        [[colorList93 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [276] green:arrayColorRangeSource [277] blue:arrayColorRangeSource [278] alpha:1]];
        [[colorList94 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [279] green:arrayColorRangeSource [280] blue:arrayColorRangeSource [281] alpha:1]];
        [[colorList95 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [282] green:arrayColorRangeSource [283] blue:arrayColorRangeSource [284] alpha:1]];
        [[colorList96 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [285] green:arrayColorRangeSource [286] blue:arrayColorRangeSource [287] alpha:1]];
        
        [[colorList97 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [288] green:arrayColorRangeSource [289] blue:arrayColorRangeSource [290] alpha:1]];
        [[colorList98 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [291] green:arrayColorRangeSource [292] blue:arrayColorRangeSource [293] alpha:1]];
        [[colorList99 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [294] green:arrayColorRangeSource [295] blue:arrayColorRangeSource [296] alpha:1]];
        [[colorList100 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [297] green:arrayColorRangeSource [298] blue:arrayColorRangeSource [299] alpha:1]];
        [[colorList101 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [300] green:arrayColorRangeSource [301] blue:arrayColorRangeSource [302] alpha:1]];
        [[colorList102 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [303] green:arrayColorRangeSource [304] blue:arrayColorRangeSource [305] alpha:1]];
        [[colorList103 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [306] green:arrayColorRangeSource [307] blue:arrayColorRangeSource [308] alpha:1]];
        [[colorList104 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [309] green:arrayColorRangeSource [310] blue:arrayColorRangeSource [311] alpha:1]];
        [[colorList105 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [312] green:arrayColorRangeSource [313] blue:arrayColorRangeSource [314] alpha:1]];
        [[colorList106 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [315] green:arrayColorRangeSource [316] blue:arrayColorRangeSource [317] alpha:1]];
        [[colorList107 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [318] green:arrayColorRangeSource [319] blue:arrayColorRangeSource [320] alpha:1]];
        [[colorList108 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [321] green:arrayColorRangeSource [322] blue:arrayColorRangeSource [323] alpha:1]];
        
        [[colorList109 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [324] green:arrayColorRangeSource [325] blue:arrayColorRangeSource [326] alpha:1]];
        [[colorList110 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [327] green:arrayColorRangeSource [328] blue:arrayColorRangeSource [329] alpha:1]];
        [[colorList111 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [330] green:arrayColorRangeSource [331] blue:arrayColorRangeSource [332] alpha:1]];
        [[colorList112 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [333] green:arrayColorRangeSource [334] blue:arrayColorRangeSource [335] alpha:1]];
        [[colorList113 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [336] green:arrayColorRangeSource [337] blue:arrayColorRangeSource [338] alpha:1]];
        [[colorList114 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [339] green:arrayColorRangeSource [340] blue:arrayColorRangeSource [341] alpha:1]];
        [[colorList115 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [342] green:arrayColorRangeSource [343] blue:arrayColorRangeSource [344] alpha:1]];
        [[colorList116 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [345] green:arrayColorRangeSource [346] blue:arrayColorRangeSource [347] alpha:1]];
        [[colorList117 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [348] green:arrayColorRangeSource [349] blue:arrayColorRangeSource [350] alpha:1]];
        [[colorList118 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [351] green:arrayColorRangeSource [352] blue:arrayColorRangeSource [353] alpha:1]];
        [[colorList119 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [354] green:arrayColorRangeSource [355] blue:arrayColorRangeSource [356] alpha:1]];
        [[colorList120 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [357] green:arrayColorRangeSource [358] blue:arrayColorRangeSource [359] alpha:1]];
        
        [[colorList121 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [360] green:arrayColorRangeSource [361] blue:arrayColorRangeSource [362] alpha:1]];
        [[colorList122 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [363] green:arrayColorRangeSource [364] blue:arrayColorRangeSource [365] alpha:1]];
        [[colorList123 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [366] green:arrayColorRangeSource [367] blue:arrayColorRangeSource [368] alpha:1]];
        [[colorList124 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [369] green:arrayColorRangeSource [370] blue:arrayColorRangeSource [371] alpha:1]];
        [[colorList125 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [372] green:arrayColorRangeSource [373] blue:arrayColorRangeSource [374] alpha:1]];
        [[colorList126 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [375] green:arrayColorRangeSource [376] blue:arrayColorRangeSource [377] alpha:1]];
        [[colorList127 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [378] green:arrayColorRangeSource [379] blue:arrayColorRangeSource [380] alpha:1]];
        [[colorList128 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [381] green:arrayColorRangeSource [382] blue:arrayColorRangeSource [383] alpha:1]];
        [[colorList129 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [384] green:arrayColorRangeSource [385] blue:arrayColorRangeSource [386] alpha:1]];
        [[colorList130 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [387] green:arrayColorRangeSource [388] blue:arrayColorRangeSource [389] alpha:1]];
        [[colorList131 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [390] green:arrayColorRangeSource [391] blue:arrayColorRangeSource [392] alpha:1]];
        [[colorList132 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [393] green:arrayColorRangeSource [394] blue:arrayColorRangeSource [395] alpha:1]];
        
        [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [393] green:arrayColorRangeSource [394] blue:arrayColorRangeSource [395] alpha:1]];
        colorListNoHold = 133;
    }
    
    string areaValueTemp = to_string(colorMaxAreaHold);
    
    [colorMaxAreaDisplay setStringValue:@(areaValueTemp.c_str())];
    [stepperGroup setIntegerValue:numberOfGroupHold];
    [groupDisplay setIntegerValue:numberOfGroupHold];
    
    exportMainTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
}

-(void)display{
    if (timingEx == 1){
        [backSave startAnimation:self];
        
        if (backSave) timingEx = 2;
    }
    else if (timingEx == 3){
        [backSave stopAnimation:self];
        
        if (backSave){
            timingEx = 0;
            
            if (dotDisplayMode == 2){
                [dotHighestValueDisplay setIntegerValue:densityValueHighest];
            }
        }
    }
    
    if (timingEx == 10){
        timingEx = 0;
        
        dotDisplayTimeMin = 0;
        dotDisplayTimeMax = 0;
        [dotStatusDisplay setStringValue:@"One Time"];
        [dotMinDisplay setStringValue:@""];
        [dotMaxDisplay setStringValue:@""];
    }
}

-(void)controlTextDidChange:(NSNotification *)aNotification{
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == colorMaxAreaDisplay){
            if ([colorMaxAreaDisplay intValue] > 0){
                colorMaxAreaHold = [colorMaxAreaDisplay intValue];
                
                colorHoldArea1 = 0;
                colorHoldArea2 = 0;
                colorHoldArea3 = 0;
                colorHoldArea4 = 0;
                colorHoldArea5 = 0;
                colorHoldArea6 = 0;
                colorHoldArea7 = 0;
                colorHoldArea8 = 0;
                colorHoldArea9 = 0;
                
                int valueSetTemp = 0;
                
                if (numberOfGroupHold != 0){
                    valueSetTemp = (int)(colorMaxAreaHold/(double)numberOfGroupHold);
                    
                    if (numberOfGroupHold >= 1) colorHoldArea1 = valueSetTemp;
                    if (numberOfGroupHold >= 2) colorHoldArea2 = valueSetTemp*2;
                    if (numberOfGroupHold >= 3) colorHoldArea3 = valueSetTemp*3;
                    if (numberOfGroupHold >= 4) colorHoldArea4 = valueSetTemp*4;
                    if (numberOfGroupHold >= 5) colorHoldArea5 = valueSetTemp*5;
                    if (numberOfGroupHold >= 6) colorHoldArea6 = valueSetTemp*6;
                    if (numberOfGroupHold >= 7) colorHoldArea7 = valueSetTemp*7;
                    if (numberOfGroupHold >= 8) colorHoldArea8 = valueSetTemp*8;
                    if (numberOfGroupHold >= 9) colorHoldArea9 = valueSetTemp*9;
                }
                
                [rangeDisplay1 setStringValue:@"1: nil"];
                [rangeDisplay2 setStringValue:@"2: nil"];
                [rangeDisplay3 setStringValue:@"3: nil"];
                [rangeDisplay4 setStringValue:@"4: nil"];
                [rangeDisplay5 setStringValue:@"5: nil"];
                [rangeDisplay6 setStringValue:@"6: nil"];
                [rangeDisplay7 setStringValue:@"7: nil"];
                [rangeDisplay8 setStringValue:@"8: nil"];
                [rangeDisplay9 setStringValue:@"9: nil"];
                [rangeDisplay10 setStringValue:@"10: nil"];
                
                string rangeValue;
                
                if (colorHoldArea1 != 0){
                    if (numberOfGroupHold == 1){
                        rangeValue = "2: "+to_string(colorHoldArea1)+"+";
                        [rangeDisplay2 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold2*3] green:arrayColorRange [colorHold2*3+1] blue:arrayColorRange [colorHold2*3+2] alpha:1]];
                        [rangeDisplay2 setStringValue:@(rangeValue.c_str())];
                    }
                    
                    if (numberOfGroupHold >= 1){
                        rangeValue = "1: "+to_string(colorHoldArea1);
                        [rangeDisplay1 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold1*3] green:arrayColorRange [colorHold1*3+1] blue:arrayColorRange [colorHold1*3+2] alpha:1]];
                        [rangeDisplay1 setStringValue:@(rangeValue.c_str())];
                    }
                }
                
                if (colorHoldArea2 != 0){
                    if (numberOfGroupHold == 2){
                        rangeValue = "3: "+to_string(colorHoldArea2)+"+";
                        [rangeDisplay3 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold3*3] green:arrayColorRange [colorHold3*3+1] blue:arrayColorRange [colorHold3*3+2] alpha:1]];
                        [rangeDisplay3 setStringValue:@(rangeValue.c_str())];
                    }
                    
                    if (numberOfGroupHold >= 2){
                        rangeValue = "2: "+to_string(colorHoldArea2);
                        [rangeDisplay2 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold2*3] green:arrayColorRange [colorHold2*3+1] blue:arrayColorRange [colorHold2*3+2] alpha:1]];
                        [rangeDisplay2 setStringValue:@(rangeValue.c_str())];
                    }
                }
                
                if (colorHoldArea3 != 0){
                    if (numberOfGroupHold == 3){
                        rangeValue = "4: "+to_string(colorHoldArea3)+"+";
                        [rangeDisplay4 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold4*3] green:arrayColorRange [colorHold4*3+1] blue:arrayColorRange [colorHold4*3+2] alpha:1]];
                        [rangeDisplay4 setStringValue:@(rangeValue.c_str())];
                    }
                    
                    if (numberOfGroupHold >= 3){
                        rangeValue = "3: "+to_string(colorHoldArea3);
                        [rangeDisplay3 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold3*3] green:arrayColorRange [colorHold3*3+1] blue:arrayColorRange [colorHold3*3+2] alpha:1]];
                        [rangeDisplay3 setStringValue:@(rangeValue.c_str())];
                    }
                }
                
                if (colorHoldArea4 != 0){
                    if (numberOfGroupHold == 4){
                        rangeValue = "5: "+to_string(colorHoldArea4)+"+";
                        [rangeDisplay5 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold5*3] green:arrayColorRange [colorHold5*3+1] blue:arrayColorRange [colorHold5*3+2] alpha:1]];
                        [rangeDisplay5 setStringValue:@(rangeValue.c_str())];
                    }
                    
                    if (numberOfGroupHold >= 4){
                        rangeValue = "4: "+to_string(colorHoldArea4);
                        [rangeDisplay4 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold4*3] green:arrayColorRange [colorHold4*3+1] blue:arrayColorRange [colorHold4*3+2] alpha:1]];
                        [rangeDisplay4 setStringValue:@(rangeValue.c_str())];
                    }
                }
                
                if (colorHoldArea5 != 0){
                    if (numberOfGroupHold == 5){
                        rangeValue = "6: "+to_string(colorHoldArea5)+"+";
                        [rangeDisplay6 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold6*3] green:arrayColorRange [colorHold6*3+1] blue:arrayColorRange [colorHold6*3+2] alpha:1]];
                        [rangeDisplay6 setStringValue:@(rangeValue.c_str())];
                    }
                    
                    if (numberOfGroupHold >= 5){
                        rangeValue = "5: "+to_string(colorHoldArea5);
                        [rangeDisplay5 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold5*3] green:arrayColorRange [colorHold5*3+1] blue:arrayColorRange [colorHold5*3+2] alpha:1]];
                        [rangeDisplay5 setStringValue:@(rangeValue.c_str())];
                    }
                }
                
                if (colorHoldArea6 != 0){
                    if (numberOfGroupHold == 6){
                        rangeValue = "7: "+to_string(colorHoldArea6)+"+";
                        [rangeDisplay7 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold7*3] green:arrayColorRange [colorHold7*3+1] blue:arrayColorRange [colorHold7*3+2] alpha:1]];
                        [rangeDisplay7 setStringValue:@(rangeValue.c_str())];
                    }
                    
                    if (numberOfGroupHold >= 6){
                        rangeValue = "6: "+to_string(colorHoldArea6);
                        [rangeDisplay6 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold6*3] green:arrayColorRange [colorHold6*3+1] blue:arrayColorRange [colorHold6*3+2] alpha:1]];
                        [rangeDisplay6 setStringValue:@(rangeValue.c_str())];
                    }
                }
                
                if (colorHoldArea7 != 0){
                    if (numberOfGroupHold == 7){
                        rangeValue = "8: "+to_string(colorHoldArea7)+"+";
                        [rangeDisplay8 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold8*3] green:arrayColorRange [colorHold8*3+1] blue:arrayColorRange [colorHold8*3+2] alpha:1]];
                        [rangeDisplay8 setStringValue:@(rangeValue.c_str())];
                    }
                    
                    if (numberOfGroupHold >= 7){
                        rangeValue = "7: "+to_string(colorHoldArea7);
                        [rangeDisplay7 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold7*3] green:arrayColorRange [colorHold7*3+1] blue:arrayColorRange [colorHold7*3+2] alpha:1]];
                        [rangeDisplay7 setStringValue:@(rangeValue.c_str())];
                    }
                }
                
                if (colorHoldArea8 != 0){
                    if (numberOfGroupHold == 8){
                        rangeValue = "9: "+to_string(colorHoldArea8)+"+";
                        [rangeDisplay9 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold9*3] green:arrayColorRange [colorHold9*3+1] blue:arrayColorRange [colorHold9*3+2] alpha:1]];
                        [rangeDisplay9 setStringValue:@(rangeValue.c_str())];
                    }
                    
                    if (numberOfGroupHold >= 8){
                        rangeValue = "8: "+to_string(colorHoldArea8);
                        [rangeDisplay8 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold8*3] green:arrayColorRange [colorHold8*3+1] blue:arrayColorRange [colorHold8*3+2] alpha:1]];
                        [rangeDisplay8 setStringValue:@(rangeValue.c_str())];
                    }
                }
                
                if (colorHoldArea9 != 0){
                    if (numberOfGroupHold == 9){
                        rangeValue = "10: "+to_string(colorHoldArea9)+"+";
                        [rangeDisplay10 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold10*3] green:arrayColorRange [colorHold10*3+1] blue:arrayColorRange [colorHold10*3+2] alpha:1]];
                        [rangeDisplay10 setStringValue:@(rangeValue.c_str())];
                    }
                    
                    if (numberOfGroupHold >= 9){
                        rangeValue = "9: "+to_string(colorHoldArea9);
                        [rangeDisplay9 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold9*3] green:arrayColorRange [colorHold9*3+1] blue:arrayColorRange [colorHold9*3+2] alpha:1]];
                        [rangeDisplay9 setStringValue:@(rangeValue.c_str())];
                    }
                }
                
                [self colorDataSave];
            }
        }
        
        if ([aNotification object] == dotMinDisplay){
            if ([dotMinDisplay intValue] > 0) dotDisplayTimeMin = [dotMinDisplay intValue];
            else{
                
                dotDisplayTimeMin = 0;
                [dotMinDisplay setStringValue:@""];
            }
        }
        
        if ([aNotification object] == dotMaxDisplay){
            if ([dotMaxDisplay intValue] > 0) dotDisplayTimeMax = [dotMaxDisplay intValue];
            else{
                
                dotDisplayTimeMax = 0;
                [dotMaxDisplay setStringValue:@""];
            }
        }
        
        if ([aNotification object] == densityDiameterDisplay){
            int inputTemp = [[densityDiameterDisplay stringValue] intValue];
            
            if (inputTemp < 5000){
                int oddFind = inputTemp%2;
                
                if (oddFind == 0) densityDiameterHold = inputTemp+1;
                else densityDiameterHold = inputTemp;
            }
            else{
                
                densityDiameterHold = 0;
                [densityDiameterDisplay setStringValue:@""];
            }
        }
        
        if ([aNotification object] == densityMaxDisplay){
            int inputTemp = [[densityMaxDisplay stringValue] intValue];
            
            if (inputTemp < 5000) densityValueMaxHold = inputTemp;
            else{
                
                densityValueMaxHold = 0;
                [densityMaxDisplay setStringValue:@""];
            }
        }
    }
}

-(IBAction)outlineWidthSet:(id)sender{
    if (outlineWidthExport == 1){
        outlineWidthExport = 2;
        [outLineWidthDisplay setStringValue:@"2 pix"];
    }
    else if (outlineWidthExport == 2){
        outlineWidthExport = 3;
        [outLineWidthDisplay setStringValue:@"3 pix"];
    }
    else if (outlineWidthExport == 3){
        outlineWidthExport = 4;
        [outLineWidthDisplay setStringValue:@"4 pix"];
    }
    else if (outlineWidthExport == 4){
        outlineWidthExport = 5;
        [outLineWidthDisplay setStringValue:@"5 pix"];
    }
    else if (outlineWidthExport == 5){
        outlineWidthExport = 6;
        [outLineWidthDisplay setStringValue:@"8 pix"];
    }
    else if (outlineWidthExport == 6){
        outlineWidthExport = 7;
        [outLineWidthDisplay setStringValue:@"10 pix"];
    }
    else if (outlineWidthExport == 7){
        outlineWidthExport = 8;
        [outLineWidthDisplay setStringValue:@"15 pix"];
    }
    else if (outlineWidthExport == 8){
        outlineWidthExport = 9;
        [outLineWidthDisplay setStringValue:@"0 pix"];
    }
    else if (outlineWidthExport == 9){
        outlineWidthExport = 1;
        [outLineWidthDisplay setStringValue:@"1 pix"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)outlineSet:(id)sender{
    if (outLineSelectExport == 0){
        outLineSelectExport = 1;
        [outLineSelectDisplay setStringValue:@"Sel"];
    }
    else if (outLineSelectExport == 1){
        outLineSelectExport = 0;
        [outLineSelectDisplay setStringValue:@"All"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)dotSizeExportSet:(id)sender{
    if (dotSizeExport == 1){
        dotSizeExport = 2;
        [dotSizeExportDisplay setStringValue:@"10 pix"];
    }
    else if (dotSizeExport == 2){
        dotSizeExport = 3;
        [dotSizeExportDisplay setStringValue:@"20 pix"];
    }
    else if (dotSizeExport == 3){
        dotSizeExport = 4;
        [dotSizeExportDisplay setStringValue:@"30 pix"];
    }
    else if (dotSizeExport == 4){
        dotSizeExport = 5;
        [dotSizeExportDisplay setStringValue:@"40 pix"];
    }
    else if (dotSizeExport == 5){
        dotSizeExport = 6;
        [dotSizeExportDisplay setStringValue:@"50 pix"];
    }
    else if (dotSizeExport == 6){
        dotSizeExport = 7;
        [dotSizeExportDisplay setStringValue:@"70 pix"];
    }
    else if (dotSizeExport == 7){
        dotSizeExport = 8;
        [dotSizeExportDisplay setStringValue:@"100 pix"];
    }
    else if (dotSizeExport == 8){
        dotSizeExport = 9;
        [dotSizeExportDisplay setStringValue:@"0 pix"];
    }
    else if (dotSizeExport == 9){
        dotSizeExport = 1;
        [dotSizeExportDisplay setStringValue:@"5 pix"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)targetWidthSet:(id)sender{
    if (targetWidthExport == 1){
        targetWidthExport = 2;
        [targetWidthDisplay setStringValue:@"0.5 pix"];
    }
    else if (targetWidthExport == 2){
        targetWidthExport = 3;
        [targetWidthDisplay setStringValue:@"1.0 pix"];
    }
    else if (targetWidthExport == 3){
        targetWidthExport = 4;
        [targetWidthDisplay setStringValue:@"1.5 pix"];
    }
    else if (targetWidthExport == 4){
        targetWidthExport = 5;
        [targetWidthDisplay setStringValue:@"2.0 pix"];
    }
    else if (targetWidthExport == 5){
        targetWidthExport = 6;
        [targetWidthDisplay setStringValue:@"4.0 pix"];
    }
    else if (targetWidthExport == 6){
        targetWidthExport = 7;
        [targetWidthDisplay setStringValue:@"6.0 pix"];
    }
    else if (targetWidthExport == 7){
        targetWidthExport = 8;
        [targetWidthDisplay setStringValue:@"8.0 pix"];
    }
    else if (targetWidthExport == 8){
        targetWidthExport = 1;
        [targetWidthDisplay setStringValue:@"0 pix"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)targetLengthSet:(id)sender{
    if (targetLengthExport == 1){
        targetLengthExport = 2;
        [targetLengthDisplay setStringValue:@"10 pix"];
    }
    else if (targetLengthExport == 2){
        targetLengthExport = 3;
        [targetLengthDisplay setStringValue:@"20 pix"];
    }
    else if (targetLengthExport == 3){
        targetLengthExport = 4;
        [targetLengthDisplay setStringValue:@"30 pix"];
    }
    else if (targetLengthExport == 4){
        targetLengthExport = 5;
        [targetLengthDisplay setStringValue:@"40 pix"];
    }
    else if (targetLengthExport == 5){
        targetLengthExport = 6;
        [targetLengthDisplay setStringValue:@"50 pix"];
    }
    else if (targetLengthExport == 6){
        targetLengthExport = 7;
        [targetLengthDisplay setStringValue:@"70 pix"];
    }
    else if (targetLengthExport == 7){
        targetLengthExport = 8;
        [targetLengthDisplay setStringValue:@"100 pix"];
    }
    else if (targetLengthExport == 8){
        targetLengthExport = 1;
        [targetLengthDisplay setStringValue:@"0 pix"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)targetFontSet:(id)sender{
    if (targetFontExport == 1){
        targetFontExport = 2;
        [targetFontDisplay setStringValue:@"12 F"];
    }
    else if (targetFontExport == 2){
        targetFontExport = 3;
        [targetFontDisplay setStringValue:@"18 F"];
    }
    else if (targetFontExport == 3){
        targetFontExport = 4;
        [targetFontDisplay setStringValue:@"24 F"];
    }
    else if (targetFontExport == 4){
        targetFontExport = 5;
        [targetFontDisplay setStringValue:@"30 F"];
    }
    else if (targetFontExport == 5){
        targetFontExport = 6;
        [targetFontDisplay setStringValue:@"40 F"];
    }
    else if (targetFontExport == 6){
        targetFontExport = 7;
        [targetFontDisplay setStringValue:@"50 F"];
    }
    else if (targetFontExport == 7){
        targetFontExport = 8;
        [targetFontDisplay setStringValue:@"60 F"];
    }
    else if (targetFontExport == 8){
        targetFontExport = 1;
        [targetFontDisplay setStringValue:@"0 F"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)titleFontSet:(id)sender{
    if (titleFontExport == 1){
        titleFontExport = 2;
        [titleFontDisplay setStringValue:@"18 F"];
    }
    else if (titleFontExport == 2){
        titleFontExport = 3;
        [titleFontDisplay setStringValue:@"24 F"];
    }
    else if (titleFontExport== 3){
        titleFontExport = 4;
        [titleFontDisplay setStringValue:@"30 F"];
    }
    else if (titleFontExport == 4){
        titleFontExport = 5;
        [titleFontDisplay setStringValue:@"40 F"];
    }
    else if (titleFontExport == 5){
        titleFontExport = 6;
        [titleFontDisplay setStringValue:@"50 F"];
    }
    else if (titleFontExport == 6){
        titleFontExport = 7;
        [titleFontDisplay setStringValue:@"60 F"];
    }
    else if (titleFontExport == 7){
        titleFontExport = 8;
        [titleFontDisplay setStringValue:@"0 F"];
    }
    else if (titleFontExport == 8){
        titleFontExport = 1;
        [titleFontDisplay setStringValue:@"12 F"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)refreshSet:(id)sender{
    outlineWidthExport = 1;
    [outLineWidthDisplay setStringValue:@"1 pix"];
    
    outlineWidthExport = 5;
    [outLineSelectDisplay setStringValue:@"2.0 pix"];
    
    dotSizeExport = 2;
    [dotSizeExportDisplay setStringValue:@"10 pix"];
    
    targetWidthExport = 5;
    [targetWidthDisplay setStringValue:@"2.0 pix"];
    
    targetLengthExport = 2;
    [targetLengthDisplay setStringValue:@"10 pix"];
    
    targetFontExport = 2;
    [targetFontDisplay setStringValue:@"12 F"];
    
    titleFontExport = 4;
    [titleFontDisplay setStringValue:@"30 F"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)lineWidthSet:(id)sender{
    if (lineWidthExp == 1){
        lineWidthExp = 2;
        [lineWidthDisplay setStringValue:@"2 pix"];
    }
    else if (lineWidthExp == 2){
        lineWidthExp = 3;
        [lineWidthDisplay setStringValue:@"3 pix"];
    }
    else if (lineWidthExp == 3){
        lineWidthExp = 4;
        [lineWidthDisplay setStringValue:@"4 pix"];
    }
    else if (lineWidthExp == 4){
        lineWidthExp = 5;
        [lineWidthDisplay setStringValue:@"5 pix"];
    }
    else if (lineWidthExp == 5){
        lineWidthExp = 0.1;
        [lineWidthDisplay setStringValue:@"0.1 pix"];
    }
    else if (lineWidthExp == 0.1){
        lineWidthExp = 0.5;
        [lineWidthDisplay setStringValue:@"0.5 pix"];
    }
    else if (lineWidthExp == 0.5){
        lineWidthExp = 1;
        [lineWidthDisplay setStringValue:@"1 pix"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorSet1:(id)sender{
    currentRangeHold = 1;
    
    [rangeNumberDisplay setStringValue:@"1"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorSet2:(id)sender{
    currentRangeHold = 2;
    
    [rangeNumberDisplay setStringValue:@"2"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorSet3:(id)sender{
    currentRangeHold = 3;
    
    [rangeNumberDisplay setStringValue:@"3"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorSet4:(id)sender{
    currentRangeHold = 4;
    
    [rangeNumberDisplay setStringValue:@"4"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorSet5:(id)sender{
    currentRangeHold = 5;
    
    [rangeNumberDisplay setStringValue:@"5"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorSet6:(id)sender{
    currentRangeHold = 6;
    
    [rangeNumberDisplay setStringValue:@"6"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorSet7:(id)sender{
    currentRangeHold = 7;
    
    [rangeNumberDisplay setStringValue:@"7"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorSet8:(id)sender{
    currentRangeHold = 8;
    
    [rangeNumberDisplay setStringValue:@"8"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorSet9:(id)sender{
    currentRangeHold = 9;
    
    [rangeNumberDisplay setStringValue:@"9"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorSet10:(id)sender{
    currentRangeHold = 10;
    
    [rangeNumberDisplay setStringValue:@"10"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorNumber1:(id)sender{
    if(colorSetStatusHold == 0){
        if (colorHoldSdStatus == 0 && colorHoldThStatus == 0){
            if (colorHold1 == 1) colorHold1 = 0;
            else if (colorHold2 == 1) colorHold2 = 0;
            else if (colorHold3 == 1) colorHold3 = 0;
            else if (colorHold4 == 1) colorHold4 = 0;
            else if (colorHold5 == 1) colorHold5 = 0;
            else if (colorHold6 == 1) colorHold6 = 0;
            else if (colorHold7 == 1) colorHold7 = 0;
            else if (colorHold8 == 1) colorHold8 = 0;
            else if (colorHold9 == 1) colorHold9 = 0;
            else if (colorHold10 == 1) colorHold10 = 0;
            
            if (currentRangeHold == 1) colorHold1 = 1;
            else if (currentRangeHold == 2) colorHold2 = 1;
            else if (currentRangeHold == 3) colorHold3 = 1;
            else if (currentRangeHold == 4) colorHold4 = 1;
            else if (currentRangeHold == 5) colorHold5 = 1;
            else if (currentRangeHold == 6) colorHold6 = 1;
            else if (currentRangeHold == 7) colorHold7 = 1;
            else if (currentRangeHold == 8) colorHold8 = 1;
            else if (currentRangeHold == 9) colorHold9 = 1;
            else if (currentRangeHold == 10) colorHold10 = 1;
        }
        else{
            
            if (colorHoldSdStatus == 1) colorHoldSd = 1;
            else if (colorHoldThStatus == 1) colorHoldTh = 1;
        }
        
        [self colorDataSave];
    }
    else{
        
        [[colorButton1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
        
        arrayColorRange [3] = arrayColorRangeSource [(colorListNoHold-1)*3];
        arrayColorRange [4] = arrayColorRangeSource [(colorListNoHold-1)*3+1];
        arrayColorRange [5] = arrayColorRangeSource [(colorListNoHold-1)*3+2];
        
        [self colorDataSave];
        
        string colorListPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ColorListData";
        
        ofstream oin;
        oin.open(colorListPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 <= 38; counter1++){
            oin<<arrayColorRange [counter1]<<endl;
        }
        
        oin.close();
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorNumber2:(id)sender{
    if(colorSetStatusHold == 0){
        if (colorHoldSdStatus == 0 && colorHoldThStatus == 0){
            if (colorHold1 == 2) colorHold1 = 0;
            else if (colorHold2 == 2) colorHold2 = 0;
            else if (colorHold3 == 2) colorHold3 = 0;
            else if (colorHold4 == 2) colorHold4 = 0;
            else if (colorHold5 == 2) colorHold5 = 0;
            else if (colorHold6 == 2) colorHold6 = 0;
            else if (colorHold7 == 2) colorHold7 = 0;
            else if (colorHold8 == 2) colorHold8 = 0;
            else if (colorHold9 == 2) colorHold9 = 0;
            else if (colorHold10 == 2) colorHold10 = 0;
            
            if (currentRangeHold == 1) colorHold1 = 2;
            else if (currentRangeHold == 2) colorHold2 = 2;
            else if (currentRangeHold == 3) colorHold3 = 2;
            else if (currentRangeHold == 4) colorHold4 = 2;
            else if (currentRangeHold == 5) colorHold5 = 2;
            else if (currentRangeHold == 6) colorHold6 = 2;
            else if (currentRangeHold == 7) colorHold7 = 2;
            else if (currentRangeHold == 8) colorHold8 = 2;
            else if (currentRangeHold == 9) colorHold9 = 2;
            else if (currentRangeHold == 10) colorHold10 = 2;
        }
        else{
            
            if (colorHoldSdStatus == 1) colorHoldSd = 2;
            else if (colorHoldThStatus == 1) colorHoldTh = 2;
        }
        
        [self colorDataSave];
    }
    else{
        
        [[colorButton2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
        
        arrayColorRange [6] = arrayColorRangeSource [(colorListNoHold-1)*3];
        arrayColorRange [7] = arrayColorRangeSource [(colorListNoHold-1)*3+1];
        arrayColorRange [8] = arrayColorRangeSource [(colorListNoHold-1)*3+2];
        
        [self colorDataSave];
        
        string colorListPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ColorListData";
        
        ofstream oin;
        oin.open(colorListPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 <= 38; counter1++) oin<<arrayColorRange [counter1]<<endl;
        
        oin.close();
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorNumber3:(id)sender{
    if(colorSetStatusHold == 0){
        if (colorHoldSdStatus == 0 && colorHoldThStatus == 0){
            if (colorHold1 == 3) colorHold1 = 0;
            else if (colorHold2 == 3) colorHold2 = 0;
            else if (colorHold3 == 3) colorHold3 = 0;
            else if (colorHold4 == 3) colorHold4 = 0;
            else if (colorHold5 == 3) colorHold5 = 0;
            else if (colorHold6 == 3) colorHold6 = 0;
            else if (colorHold7 == 3) colorHold7 = 0;
            else if (colorHold8 == 3) colorHold8 = 0;
            else if (colorHold9 == 3) colorHold9 = 0;
            else if (colorHold10 == 3) colorHold10 = 0;
            
            if (currentRangeHold == 1) colorHold1 = 3;
            else if (currentRangeHold == 2) colorHold2 = 3;
            else if (currentRangeHold == 3) colorHold3 = 3;
            else if (currentRangeHold == 4) colorHold4 = 3;
            else if (currentRangeHold == 5) colorHold5 = 3;
            else if (currentRangeHold == 6) colorHold6 = 3;
            else if (currentRangeHold == 7) colorHold7 = 3;
            else if (currentRangeHold == 8) colorHold8 = 3;
            else if (currentRangeHold == 9) colorHold9 = 3;
            else if (currentRangeHold == 10) colorHold10 = 3;
        }
        else{
            
            if (colorHoldSdStatus == 1) colorHoldSd = 3;
            else if (colorHoldThStatus == 1) colorHoldTh = 3;
        }
        
        [self colorDataSave];
    }
    else{
        
        [[colorButton3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
        
        arrayColorRange [9] = arrayColorRangeSource [(colorListNoHold-1)*3];
        arrayColorRange [10] = arrayColorRangeSource [(colorListNoHold-1)*3+1];
        arrayColorRange [11] = arrayColorRangeSource [(colorListNoHold-1)*3+2];
        
        [self colorDataSave];
        
        string colorListPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ColorListData";
        
        ofstream oin;
        oin.open(colorListPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 <= 38; counter1++) oin<<arrayColorRange [counter1]<<endl;
        
        oin.close();
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorNumber4:(id)sender{
    if(colorSetStatusHold == 0){
        if (colorHoldSdStatus == 0 && colorHoldThStatus == 0){
            if (colorHold1 == 4) colorHold1 = 0;
            else if (colorHold2 == 4) colorHold2 = 0;
            else if (colorHold3 == 4) colorHold3 = 0;
            else if (colorHold4 == 4) colorHold4 = 0;
            else if (colorHold5 == 4) colorHold5 = 0;
            else if (colorHold6 == 4) colorHold6 = 0;
            else if (colorHold7 == 4) colorHold7 = 0;
            else if (colorHold8 == 4) colorHold8 = 0;
            else if (colorHold9 == 4) colorHold9 = 0;
            else if (colorHold10 == 4) colorHold10 = 0;
            
            if (currentRangeHold == 1) colorHold1 = 4;
            else if (currentRangeHold == 2) colorHold2 = 4;
            else if (currentRangeHold == 3) colorHold3 = 4;
            else if (currentRangeHold == 4) colorHold4 = 4;
            else if (currentRangeHold == 5) colorHold5 = 4;
            else if (currentRangeHold == 6) colorHold6 = 4;
            else if (currentRangeHold == 7) colorHold7 = 4;
            else if (currentRangeHold == 8) colorHold8 = 4;
            else if (currentRangeHold == 9) colorHold9 = 4;
            else if (currentRangeHold == 10) colorHold10 = 4;
        }
        else{
            
            if (colorHoldSdStatus == 1) colorHoldSd = 4;
            else if (colorHoldThStatus == 1) colorHoldTh = 4;
        }
        
        [self colorDataSave];
    }
    else{
        
        [[colorButton4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
        
        arrayColorRange [12] = arrayColorRangeSource [(colorListNoHold-1)*3];
        arrayColorRange [13] = arrayColorRangeSource [(colorListNoHold-1)*3+1];
        arrayColorRange [14] = arrayColorRangeSource [(colorListNoHold-1)*3+2];
        
        [self colorDataSave];
        
        string colorListPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ColorListData";
        
        ofstream oin;
        oin.open(colorListPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 <= 38; counter1++) oin<<arrayColorRange [counter1]<<endl;
        
        oin.close();
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorNumber5:(id)sender{
    if(colorSetStatusHold == 0){
        if (colorHoldSdStatus == 0 && colorHoldThStatus == 0){
            if (colorHold1 == 5) colorHold1 = 0;
            else if (colorHold2 == 5) colorHold2 = 0;
            else if (colorHold3 == 5) colorHold3 = 0;
            else if (colorHold4 == 5) colorHold4 = 0;
            else if (colorHold5 == 5) colorHold5 = 0;
            else if (colorHold6 == 5) colorHold6 = 0;
            else if (colorHold7 == 5) colorHold7 = 0;
            else if (colorHold8 == 5) colorHold8 = 0;
            else if (colorHold9 == 5) colorHold9 = 0;
            else if (colorHold10 == 5) colorHold10 = 0;
            
            if (currentRangeHold == 1) colorHold1 = 5;
            else if (currentRangeHold == 2) colorHold2 = 5;
            else if (currentRangeHold == 3) colorHold3 = 5;
            else if (currentRangeHold == 4) colorHold4 = 5;
            else if (currentRangeHold == 5) colorHold5 = 5;
            else if (currentRangeHold == 6) colorHold6 = 5;
            else if (currentRangeHold == 7) colorHold7 = 5;
            else if (currentRangeHold == 8) colorHold8 = 5;
            else if (currentRangeHold == 9) colorHold9 = 5;
            else if (currentRangeHold == 10) colorHold10 = 5;
        }
        else{
            
            if (colorHoldSdStatus == 1) colorHoldSd = 5;
            else if (colorHoldThStatus == 1) colorHoldTh = 5;
        }
        
        [self colorDataSave];
    }
    else{
        
        [[colorButton5 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
        
        arrayColorRange [15] = arrayColorRangeSource [(colorListNoHold-1)*3];
        arrayColorRange [16] = arrayColorRangeSource [(colorListNoHold-1)*3+1];
        arrayColorRange [17] = arrayColorRangeSource [(colorListNoHold-1)*3+2];
        
        [self colorDataSave];
        
        string colorListPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ColorListData";
        
        ofstream oin;
        oin.open(colorListPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 <= 38; counter1++) oin<<arrayColorRange [counter1]<<endl;
        
        oin.close();
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorNumber6:(id)sender{
    if(colorSetStatusHold == 0){
        if (colorHoldSdStatus == 0 && colorHoldThStatus == 0){
            if (colorHold1 == 6) colorHold1 = 0;
            else if (colorHold2 == 6) colorHold2 = 0;
            else if (colorHold3 == 6) colorHold3 = 0;
            else if (colorHold4 == 6) colorHold4 = 0;
            else if (colorHold5 == 6) colorHold5 = 0;
            else if (colorHold6 == 6) colorHold6 = 0;
            else if (colorHold7 == 6) colorHold7 = 0;
            else if (colorHold8 == 6) colorHold8 = 0;
            else if (colorHold9 == 6) colorHold9 = 0;
            else if (colorHold10 == 6) colorHold10 = 0;
            
            if (currentRangeHold == 1) colorHold1 = 6;
            else if (currentRangeHold == 2) colorHold2 = 6;
            else if (currentRangeHold == 3) colorHold3 = 6;
            else if (currentRangeHold == 4) colorHold4 = 6;
            else if (currentRangeHold == 5) colorHold5 = 6;
            else if (currentRangeHold == 6) colorHold6 = 6;
            else if (currentRangeHold == 7) colorHold7 = 6;
            else if (currentRangeHold == 8) colorHold8 = 6;
            else if (currentRangeHold == 9) colorHold9 = 6;
            else if (currentRangeHold == 10) colorHold10 = 6;
        }
        else{
            
            if (colorHoldSdStatus == 1) colorHoldSd = 6;
            else if (colorHoldThStatus == 1) colorHoldTh = 6;
        }
        
        [self colorDataSave];
    }
    else{
        
        [[colorButton6 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
        
        arrayColorRange [18] = arrayColorRangeSource [(colorListNoHold-1)*3];
        arrayColorRange [19] = arrayColorRangeSource [(colorListNoHold-1)*3+1];
        arrayColorRange [20] = arrayColorRangeSource [(colorListNoHold-1)*3+2];
        
        [self colorDataSave];
        
        string colorListPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ColorListData";
        
        ofstream oin;
        oin.open(colorListPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 <= 38; counter1++) oin<<arrayColorRange [counter1]<<endl;
        
        oin.close();
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorNumber7:(id)sender{
    if(colorSetStatusHold == 0){
        if (colorHoldSdStatus == 0 && colorHoldThStatus == 0){
            if (colorHold1 == 7) colorHold1 = 0;
            else if (colorHold2 == 7) colorHold2 = 0;
            else if (colorHold3 == 7) colorHold3 = 0;
            else if (colorHold4 == 7) colorHold4 = 0;
            else if (colorHold5 == 7) colorHold5 = 0;
            else if (colorHold6 == 7) colorHold6 = 0;
            else if (colorHold7 == 7) colorHold7 = 0;
            else if (colorHold8 == 7) colorHold8 = 0;
            else if (colorHold9 == 7) colorHold9 = 0;
            else if (colorHold10 == 7) colorHold10 = 0;
            
            if (currentRangeHold == 1) colorHold1 = 7;
            else if (currentRangeHold == 2) colorHold2 = 7;
            else if (currentRangeHold == 3) colorHold3 = 7;
            else if (currentRangeHold == 4) colorHold4 = 7;
            else if (currentRangeHold == 5) colorHold5 = 7;
            else if (currentRangeHold == 6) colorHold6 = 7;
            else if (currentRangeHold == 7) colorHold7 = 7;
            else if (currentRangeHold == 8) colorHold8 = 7;
            else if (currentRangeHold == 9) colorHold9 = 7;
            else if (currentRangeHold == 10) colorHold10 = 7;
        }
        else{
            
            if (colorHoldSdStatus == 1) colorHoldSd = 7;
            else if (colorHoldThStatus == 1) colorHoldTh = 7;
        }
        
        [self colorDataSave];
    }
    else{
        
        [[colorButton7 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
        
        arrayColorRange [21] = arrayColorRangeSource [(colorListNoHold-1)*3];
        arrayColorRange [22] = arrayColorRangeSource [(colorListNoHold-1)*3+1];
        arrayColorRange [23] = arrayColorRangeSource [(colorListNoHold-1)*3+2];
        
        [self colorDataSave];
        
        string colorListPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ColorListData";
        
        ofstream oin;
        oin.open(colorListPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 <= 38; counter1++) oin<<arrayColorRange [counter1]<<endl;
        
        oin.close();
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorNumber8:(id)sender{
    if(colorSetStatusHold == 0){
        if (colorHoldSdStatus == 0 && colorHoldThStatus == 0){
            if (colorHold1 == 8) colorHold1 = 0;
            else if (colorHold2 == 8) colorHold2 = 0;
            else if (colorHold3 == 8) colorHold3 = 0;
            else if (colorHold4 == 8) colorHold4 = 0;
            else if (colorHold5 == 8) colorHold5 = 0;
            else if (colorHold6 == 8) colorHold6 = 0;
            else if (colorHold7 == 8) colorHold7 = 0;
            else if (colorHold8 == 8) colorHold8 = 0;
            else if (colorHold9 == 8) colorHold9 = 0;
            else if (colorHold10 == 8) colorHold10 = 0;
            
            if (currentRangeHold == 1) colorHold1 = 8;
            else if (currentRangeHold == 2) colorHold2 = 8;
            else if (currentRangeHold == 3) colorHold3 = 8;
            else if (currentRangeHold == 4) colorHold4 = 8;
            else if (currentRangeHold == 5) colorHold5 = 8;
            else if (currentRangeHold == 6) colorHold6 = 8;
            else if (currentRangeHold == 7) colorHold7 = 8;
            else if (currentRangeHold == 8) colorHold8 = 8;
            else if (currentRangeHold == 9) colorHold9 = 8;
            else if (currentRangeHold == 10) colorHold10 = 8;
        }
        else{
            
            if (colorHoldSdStatus == 1) colorHoldSd = 8;
            else if (colorHoldThStatus == 1) colorHoldTh = 8;
        }
        
        [self colorDataSave];
    }
    else{
        
        [[colorButton8 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
        
        arrayColorRange [24] = arrayColorRangeSource [(colorListNoHold-1)*3];
        arrayColorRange [25] = arrayColorRangeSource [(colorListNoHold-1)*3+1];
        arrayColorRange [26] = arrayColorRangeSource [(colorListNoHold-1)*3+2];
        
        [self colorDataSave];
        
        string colorListPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ColorListData";
        
        ofstream oin;
        oin.open(colorListPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 <= 38; counter1++) oin<<arrayColorRange [counter1]<<endl;
        
        oin.close();
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorNumber9:(id)sender{
    if(colorSetStatusHold == 0){
        if (colorHoldSdStatus == 0 && colorHoldThStatus == 0){
            if (colorHold1 == 9) colorHold1 = 0;
            else if (colorHold2 == 9) colorHold2 = 0;
            else if (colorHold3 == 9) colorHold3 = 0;
            else if (colorHold4 == 9) colorHold4 = 0;
            else if (colorHold5 == 9) colorHold5 = 0;
            else if (colorHold6 == 9) colorHold6 = 0;
            else if (colorHold7 == 9) colorHold7 = 0;
            else if (colorHold8 == 9) colorHold8 = 0;
            else if (colorHold9 == 9) colorHold9 = 0;
            else if (colorHold10 == 9) colorHold10 = 0;
            
            if (currentRangeHold == 1) colorHold1 = 9;
            else if (currentRangeHold == 2) colorHold2 = 9;
            else if (currentRangeHold == 3) colorHold3 = 9;
            else if (currentRangeHold == 4) colorHold4 = 9;
            else if (currentRangeHold == 5) colorHold5 = 9;
            else if (currentRangeHold == 6) colorHold6 = 9;
            else if (currentRangeHold == 7) colorHold7 = 9;
            else if (currentRangeHold == 8) colorHold8 = 9;
            else if (currentRangeHold == 9) colorHold9 = 9;
            else if (currentRangeHold == 10) colorHold10 = 9;
        }
        else{
            
            if (colorHoldSdStatus == 1) colorHoldSd = 9;
            else if (colorHoldThStatus == 1) colorHoldTh = 9;
        }
        
        [self colorDataSave];
    }
    else{
        
        [[colorButton9 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
        
        arrayColorRange [27] = arrayColorRangeSource [(colorListNoHold-1)*3];
        arrayColorRange [28] = arrayColorRangeSource [(colorListNoHold-1)*3+1];
        arrayColorRange [29] = arrayColorRangeSource [(colorListNoHold-1)*3+2];
        
        [self colorDataSave];
        
        string colorListPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ColorListData";
        
        ofstream oin;
        oin.open(colorListPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 <= 38; counter1++) oin<<arrayColorRange [counter1]<<endl;
        
        oin.close();
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorNumber10:(id)sender{
    if(colorSetStatusHold == 0){
        if (colorHoldSdStatus == 0 && colorHoldThStatus == 0){
            if (colorHold1 == 10) colorHold1 = 0;
            else if (colorHold2 == 10) colorHold2 = 0;
            else if (colorHold3 == 10) colorHold3 = 0;
            else if (colorHold4 == 10) colorHold4 = 0;
            else if (colorHold5 == 10) colorHold5 = 0;
            else if (colorHold6 == 10) colorHold6 = 0;
            else if (colorHold7 == 10) colorHold7 = 0;
            else if (colorHold8 == 10) colorHold8 = 0;
            else if (colorHold9 == 10) colorHold9 = 0;
            else if (colorHold10 == 10) colorHold10 = 0;
            
            if (currentRangeHold == 1) colorHold1 = 10;
            else if (currentRangeHold == 2) colorHold2 = 10;
            else if (currentRangeHold == 3) colorHold3 = 10;
            else if (currentRangeHold == 4) colorHold4 = 10;
            else if (currentRangeHold == 5) colorHold5 = 10;
            else if (currentRangeHold == 6) colorHold6 = 10;
            else if (currentRangeHold == 7) colorHold7 = 10;
            else if (currentRangeHold == 8) colorHold8 = 10;
            else if (currentRangeHold == 9) colorHold9 = 10;
            else if (currentRangeHold == 10) colorHold10 = 10;
        }
        else{
            
            if (colorHoldSdStatus == 1) colorHoldSd = 10;
            else if (colorHoldThStatus == 1) colorHoldTh = 10;
        }
        
        [self colorDataSave];
    }
    else{
        
        [[colorButton10 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
        
        arrayColorRange [30] = arrayColorRangeSource [(colorListNoHold-1)*3];
        arrayColorRange [31] = arrayColorRangeSource [(colorListNoHold-1)*3+1];
        arrayColorRange [32] = arrayColorRangeSource [(colorListNoHold-1)*3+2];
        
        [self colorDataSave];
        
        string colorListPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ColorListData";
        
        ofstream oin;
        oin.open(colorListPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 <= 38; counter1++) oin<<arrayColorRange [counter1]<<endl;
        
        oin.close();
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorNumber11:(id)sender{
    if(colorSetStatusHold == 0){
        if (colorHoldSdStatus == 0 && colorHoldThStatus == 0){
            if (colorHold1 == 11) colorHold1 = 0;
            else if (colorHold2 == 11) colorHold2 = 0;
            else if (colorHold3 == 11) colorHold3 = 0;
            else if (colorHold4 == 11) colorHold4 = 0;
            else if (colorHold5 == 11) colorHold5 = 0;
            else if (colorHold6 == 11) colorHold6 = 0;
            else if (colorHold7 == 11) colorHold7 = 0;
            else if (colorHold8 == 11) colorHold8 = 0;
            else if (colorHold9 == 11) colorHold9 = 0;
            else if (colorHold10 == 11) colorHold10 = 0;
            
            if (currentRangeHold == 1) colorHold1 = 11;
            else if (currentRangeHold == 2) colorHold2 = 11;
            else if (currentRangeHold == 3) colorHold3 = 11;
            else if (currentRangeHold == 4) colorHold4 = 11;
            else if (currentRangeHold == 5) colorHold5 = 11;
            else if (currentRangeHold == 6) colorHold6 = 11;
            else if (currentRangeHold == 7) colorHold7 = 11;
            else if (currentRangeHold == 8) colorHold8 = 11;
            else if (currentRangeHold == 9) colorHold9 = 11;
            else if (currentRangeHold == 10) colorHold10 = 11;
        }
        else{
            
            if (colorHoldSdStatus == 1) colorHoldSd = 11;
            else if (colorHoldThStatus == 1) colorHoldTh = 11;
        }
        
        [self colorDataSave];
    }
    else{
        
        [[colorButton11 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
        
        arrayColorRange [33] = arrayColorRangeSource [(colorListNoHold-1)*3];
        arrayColorRange [34] = arrayColorRangeSource [(colorListNoHold-1)*3+1];
        arrayColorRange [35] = arrayColorRangeSource [(colorListNoHold-1)*3+2];
        
        [self colorDataSave];
        
        string colorListPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ColorListData";
        
        ofstream oin;
        oin.open(colorListPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 <= 38; counter1++) oin<<arrayColorRange [counter1]<<endl;
        
        oin.close();
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorNumber12:(id)sender{
    if(colorSetStatusHold == 0){
        if (colorHoldSdStatus == 0 && colorHoldThStatus == 0){
            if (colorHold1 == 12) colorHold1 = 0;
            else if (colorHold2 == 12) colorHold2 = 0;
            else if (colorHold3 == 12) colorHold3 = 0;
            else if (colorHold4 == 12) colorHold4 = 0;
            else if (colorHold5 == 12) colorHold5 = 0;
            else if (colorHold6 == 12) colorHold6 = 0;
            else if (colorHold7 == 12) colorHold7 = 0;
            else if (colorHold8 == 12) colorHold8 = 0;
            else if (colorHold9 == 12) colorHold9 = 0;
            else if (colorHold10 == 12) colorHold10 = 0;
            
            if (currentRangeHold == 1) colorHold1 = 12;
            else if (currentRangeHold == 2) colorHold2 = 12;
            else if (currentRangeHold == 3) colorHold3 = 12;
            else if (currentRangeHold == 4) colorHold4 = 12;
            else if (currentRangeHold == 5) colorHold5 = 12;
            else if (currentRangeHold == 6) colorHold6 = 12;
            else if (currentRangeHold == 7) colorHold7 = 12;
            else if (currentRangeHold == 8) colorHold8 = 12;
            else if (currentRangeHold == 9) colorHold9 = 12;
            else if (currentRangeHold == 10) colorHold10 = 12;
        }
        else{
            
            if (colorHoldSdStatus == 1) colorHoldSd = 12;
            else if (colorHoldThStatus == 1) colorHoldTh = 12;
        }
        
        [self colorDataSave];
    }
    else{
        
        [[colorButton12 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
        
        arrayColorRange [36] = arrayColorRangeSource [(colorListNoHold-1)*3];
        arrayColorRange [37] = arrayColorRangeSource [(colorListNoHold-1)*3+1];
        arrayColorRange [38] = arrayColorRangeSource [(colorListNoHold-1)*3+2];
        
        [self colorDataSave];
        
        string colorListPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ColorListData";
        
        ofstream oin;
        oin.open(colorListPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 <= 38; counter1++) oin<<arrayColorRange [counter1]<<endl;
        
        oin.close();
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorSdSet:(id)sender{
    if (colorHoldSdStatus == 0){
        colorHoldSdStatus = 1;
        
        [colorSdSetDisplay setStringValue:@"On"];
        
        string rangeValue = "Sd:";
        [colorSdDisplay setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHoldSd*3] green:arrayColorRange [colorHoldSd*3+1] blue:arrayColorRange [colorHoldSd*3+2] alpha:1]];
        [colorSdDisplay setStringValue:@(rangeValue.c_str())];
        
    }
    else if (colorHoldSdStatus == 1){
        colorHoldSdStatus = 0;
        
        [colorSdSetDisplay setStringValue:@"Off"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorSdClear:(id)sender{
    colorHoldSdStatus = 0;
    colorHoldSd = 0;
    
    string rangeValue = "Sd:";
    [colorSdDisplay setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:0 alpha:1]];
    [colorSdDisplay setStringValue:@(rangeValue.c_str())];
    
    [colorSdSetDisplay setStringValue:@"Off"];
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorThSet:(id)sender{
    if (colorHoldThStatus == 0){
        colorHoldThStatus = 1;
        
        [colorThSetDisplay setStringValue:@"On"];
        
        string rangeValue = "Th:";
        [colorThDisplay setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHoldTh*3] green:arrayColorRange [colorHoldTh*3+1] blue:arrayColorRange [colorHoldTh*3+2] alpha:1]];
        [colorThDisplay setStringValue:@(rangeValue.c_str())];
        
    }
    else if (colorHoldThStatus == 1){
        colorHoldThStatus = 0;
        
        [colorThSetDisplay setStringValue:@"Off"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorThClear:(id)sender{
    colorHoldThStatus = 0;
    colorHoldTh = 0;
    
    string rangeValue = "Th:";
    [colorThDisplay setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:0 alpha:1]];
    [colorThDisplay setStringValue:@(rangeValue.c_str())];
    
    [colorThSetDisplay setStringValue:@"Off"];
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)stepperActionGroup:(id)sender{
    if ([stepperGroup intValue] >= 0 && [stepperGroup intValue] <= 9){
        numberOfGroupHold = [stepperGroup intValue];
        
        [groupDisplay setIntegerValue:numberOfGroupHold];
        
        colorHold1 = 0;
        colorHold2 = 0;
        colorHold3 = 0;
        colorHold4 = 0;
        colorHold5 = 0;
        colorHold6 = 0;
        colorHold7 = 0;
        colorHold8 = 0;
        colorHold9 = 0;
        colorHold10 = 0;
        
        colorHoldArea1 = 0;
        colorHoldArea2 = 0;
        colorHoldArea3 = 0;
        colorHoldArea4 = 0;
        colorHoldArea5 = 0;
        colorHoldArea6 = 0;
        colorHoldArea7 = 0;
        colorHoldArea8 = 0;
        colorHoldArea9 = 0;
        
        int valueSetTemp = 0;
        
        valueSetTemp = (int)(colorMaxAreaHold/(double)numberOfGroupHold);
        
        if (numberOfGroupHold >= 1) colorHoldArea1 = valueSetTemp;
        if (numberOfGroupHold >= 2) colorHoldArea2 = valueSetTemp*2;
        if (numberOfGroupHold >= 3) colorHoldArea3 = valueSetTemp*3;
        if (numberOfGroupHold >= 4) colorHoldArea4 = valueSetTemp*4;
        if (numberOfGroupHold >= 5) colorHoldArea5 = valueSetTemp*5;
        if (numberOfGroupHold >= 6) colorHoldArea6 = valueSetTemp*6;
        if (numberOfGroupHold >= 7) colorHoldArea7 = valueSetTemp*7;
        if (numberOfGroupHold >= 8) colorHoldArea8 = valueSetTemp*8;
        if (numberOfGroupHold >= 9) colorHoldArea9 = valueSetTemp*9;
        
        [rangeDisplay1 setStringValue:@"1: nil"];
        [rangeDisplay2 setStringValue:@"2: nil"];
        [rangeDisplay3 setStringValue:@"3: nil"];
        [rangeDisplay4 setStringValue:@"4: nil"];
        [rangeDisplay5 setStringValue:@"5: nil"];
        [rangeDisplay6 setStringValue:@"6: nil"];
        [rangeDisplay7 setStringValue:@"7: nil"];
        [rangeDisplay8 setStringValue:@"8: nil"];
        [rangeDisplay9 setStringValue:@"9: nil"];
        [rangeDisplay10 setStringValue:@"10: nil"];
        
        [self colorDataSave];
    }
}

-(IBAction)colorSetActivate:(id)sender{
    if (colorSetStatusHold == 0){
        colorSetStatusHold = 1;
        [colorSetStatusDisplay setStringValue:@"On"];
    }
    else if (colorSetStatusHold == 1){
        colorSetStatusHold = 0;
        [colorSetStatusDisplay setStringValue:@"Off"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(void)colorDataSave{
    string rangeValue;
    
    if (colorHoldArea1 != 0){
        if (numberOfGroupHold == 1){
            rangeValue = "2: "+to_string(colorHoldArea1)+"+";
            [rangeDisplay2 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold2*3] green:arrayColorRange [colorHold2*3+1] blue:arrayColorRange [colorHold2*3+2] alpha:1]];
            [rangeDisplay2 setStringValue:@(rangeValue.c_str())];
        }
        
        if (numberOfGroupHold >= 1){
            rangeValue = "1: "+to_string(colorHoldArea1);
            [rangeDisplay1 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold1*3] green:arrayColorRange [colorHold1*3+1] blue:arrayColorRange [colorHold1*3+2] alpha:1]];
            [rangeDisplay1 setStringValue:@(rangeValue.c_str())];
        }
    }
    
    if (colorHoldArea2 != 0){
        if (numberOfGroupHold == 2){
            rangeValue = "3: "+to_string(colorHoldArea2)+"+";
            [rangeDisplay3 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold3*3] green:arrayColorRange [colorHold3*3+1] blue:arrayColorRange [colorHold3*3+2] alpha:1]];
            [rangeDisplay3 setStringValue:@(rangeValue.c_str())];
        }
        
        if (numberOfGroupHold >= 2){
            rangeValue = "2: "+to_string(colorHoldArea2);
            [rangeDisplay2 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold2*3] green:arrayColorRange [colorHold2*3+1] blue:arrayColorRange [colorHold2*3+2] alpha:1]];
            [rangeDisplay2 setStringValue:@(rangeValue.c_str())];
        }
    }
    
    if (colorHoldArea3 != 0){
        if (numberOfGroupHold == 3){
            rangeValue = "4: "+to_string(colorHoldArea3)+"+";
            [rangeDisplay4 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold4*3] green:arrayColorRange [colorHold4*3+1] blue:arrayColorRange [colorHold4*3+2] alpha:1]];
            [rangeDisplay4 setStringValue:@(rangeValue.c_str())];
        }
        
        if (numberOfGroupHold >= 3){
            rangeValue = "3: "+to_string(colorHoldArea3);
            [rangeDisplay3 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold3*3] green:arrayColorRange [colorHold3*3+1] blue:arrayColorRange [colorHold3*3+2] alpha:1]];
            [rangeDisplay3 setStringValue:@(rangeValue.c_str())];
        }
    }
    
    if (colorHoldArea4 != 0){
        if (numberOfGroupHold == 4){
            rangeValue = "5: "+to_string(colorHoldArea4)+"+";
            [rangeDisplay5 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold5*3] green:arrayColorRange [colorHold5*3+1] blue:arrayColorRange [colorHold5*3+2] alpha:1]];
            [rangeDisplay5 setStringValue:@(rangeValue.c_str())];
        }
        
        if (numberOfGroupHold >= 4){
            rangeValue = "4: "+to_string(colorHoldArea4);
            [rangeDisplay4 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold4*3] green:arrayColorRange [colorHold4*3+1] blue:arrayColorRange [colorHold4*3+2] alpha:1]];
            [rangeDisplay4 setStringValue:@(rangeValue.c_str())];
        }
    }
    
    if (colorHoldArea5 != 0){
        if (numberOfGroupHold == 5){
            rangeValue = "6: "+to_string(colorHoldArea5)+"+";
            [rangeDisplay6 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold6*3] green:arrayColorRange [colorHold6*3+1] blue:arrayColorRange [colorHold6*3+2] alpha:1]];
            [rangeDisplay6 setStringValue:@(rangeValue.c_str())];
        }
        
        if (numberOfGroupHold >= 5){
            rangeValue = "5: "+to_string(colorHoldArea5);
            [rangeDisplay5 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold5*3] green:arrayColorRange [colorHold5*3+1] blue:arrayColorRange [colorHold5*3+2] alpha:1]];
            [rangeDisplay5 setStringValue:@(rangeValue.c_str())];
        }
    }
    
    if (colorHoldArea6 != 0){
        if (numberOfGroupHold == 6){
            rangeValue = "7: "+to_string(colorHoldArea6)+"+";
            [rangeDisplay7 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold7*3] green:arrayColorRange [colorHold7*3+1] blue:arrayColorRange [colorHold7*3+2] alpha:1]];
            [rangeDisplay7 setStringValue:@(rangeValue.c_str())];
        }
        
        if (numberOfGroupHold >= 6){
            rangeValue = "6: "+to_string(colorHoldArea6);
            [rangeDisplay6 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold6*3] green:arrayColorRange [colorHold6*3+1] blue:arrayColorRange [colorHold6*3+2] alpha:1]];
            [rangeDisplay6 setStringValue:@(rangeValue.c_str())];
        }
    }
    
    if (colorHoldArea7 != 0){
        if (numberOfGroupHold == 7){
            rangeValue = "8: "+to_string(colorHoldArea7)+"+";
            [rangeDisplay8 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold8*3] green:arrayColorRange [colorHold8*3+1] blue:arrayColorRange [colorHold8*3+2] alpha:1]];
            [rangeDisplay8 setStringValue:@(rangeValue.c_str())];
        }
        
        if (numberOfGroupHold >= 7){
            rangeValue = "7: "+to_string(colorHoldArea7);
            [rangeDisplay7 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold7*3] green:arrayColorRange [colorHold7*3+1] blue:arrayColorRange [colorHold7*3+2] alpha:1]];
            [rangeDisplay7 setStringValue:@(rangeValue.c_str())];
        }
    }
    
    if (colorHoldArea8 != 0){
        if (numberOfGroupHold == 8){
            rangeValue = "9: "+to_string(colorHoldArea8)+"+";
            [rangeDisplay9 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold9*3] green:arrayColorRange [colorHold9*3+1] blue:arrayColorRange [colorHold9*3+2] alpha:1]];
            [rangeDisplay9 setStringValue:@(rangeValue.c_str())];
        }
        
        if (numberOfGroupHold >= 8){
            rangeValue = "8: "+to_string(colorHoldArea8);
            [rangeDisplay8 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold8*3] green:arrayColorRange [colorHold8*3+1] blue:arrayColorRange [colorHold8*3+2] alpha:1]];
            [rangeDisplay8 setStringValue:@(rangeValue.c_str())];
        }
    }
    
    if (colorHoldArea9 != 0){
        if (numberOfGroupHold == 9){
            rangeValue = "10: "+to_string(colorHoldArea9)+"+";
            [rangeDisplay10 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold10*3] green:arrayColorRange [colorHold10*3+1] blue:arrayColorRange [colorHold10*3+2] alpha:1]];
            [rangeDisplay10 setStringValue:@(rangeValue.c_str())];
        }
        
        if (numberOfGroupHold >= 9){
            rangeValue = "9: "+to_string(colorHoldArea9);
            [rangeDisplay9 setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHold9*3] green:arrayColorRange [colorHold9*3+1] blue:arrayColorRange [colorHold9*3+2] alpha:1]];
            [rangeDisplay9 setStringValue:@(rangeValue.c_str())];
        }
    }
    
    if (colorHoldSd != 0){
        rangeValue = "Sd:";
        [colorSdDisplay setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHoldSd*3] green:arrayColorRange [colorHoldSd*3+1] blue:arrayColorRange [colorHoldSd*3+2] alpha:1]];
        [colorSdDisplay setStringValue:@(rangeValue.c_str())];
    }
    else{
        
        rangeValue = "Sd:";
        [colorSdDisplay setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:0 alpha:1]];
        [colorSdDisplay setStringValue:@(rangeValue.c_str())];
    }
    
    if (colorHoldTh != 0){
        rangeValue = "Th:";
        [colorThDisplay setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [colorHoldTh*3] green:arrayColorRange [colorHoldTh*3+1] blue:arrayColorRange [colorHoldTh*3+2] alpha:1]];
        [colorThDisplay setStringValue:@(rangeValue.c_str())];
    }
    else{
        
        rangeValue = "Th:";
        [colorThDisplay setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:0 alpha:1]];
        [colorThDisplay setStringValue:@(rangeValue.c_str())];
    }
    
    if (colorSetStatusHold == 0){
        string colorDataHoldPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ExportColorMQ";
        
        ofstream oin;
        oin.open(colorDataHoldPath.c_str(),ios::out);
        
        oin<<colorHoldArea1<<endl;
        oin<<colorHoldArea2<<endl;
        oin<<colorHoldArea3<<endl;
        oin<<colorHoldArea4<<endl;
        oin<<colorHoldArea5<<endl;
        oin<<colorHoldArea6<<endl;
        oin<<colorHoldArea7<<endl;
        oin<<colorHoldArea8<<endl;
        oin<<colorHoldArea9<<endl;
        oin<<colorHold1<<endl;
        oin<<colorHold2<<endl;
        oin<<colorHold3<<endl;
        oin<<colorHold4<<endl;
        oin<<colorHold5<<endl;
        oin<<colorHold6<<endl;
        oin<<colorHold7<<endl;
        oin<<colorHold8<<endl;
        oin<<colorHold9<<endl;
        oin<<colorHold10<<endl;
        oin<<colorMaxAreaHold<<endl;
        oin<<numberOfGroupHold<<endl;
        oin<<colorHoldSd<<endl;
        oin<<colorHoldTh<<endl;
        
        oin.close();
    }
}

-(IBAction)clearColorSetting:(id)sender{
    colorHold1 = 0;
    colorHold2 = 0;
    colorHold3 = 0;
    colorHold4 = 0;
    colorHold5 = 0;
    colorHold6 = 0;
    colorHold7 = 0;
    colorHold8 = 0;
    colorHold9 = 0;
    colorHold10 = 0;
    
    colorHoldSd = 0;
    colorHoldTh = 0;
    
    colorHoldArea1 = 0;
    colorHoldArea2 = 0;
    colorHoldArea3 = 0;
    colorHoldArea4 = 0;
    colorHoldArea5 = 0;
    colorHoldArea6 = 0;
    colorHoldArea7 = 0;
    colorHoldArea8 = 0;
    colorHoldArea9 = 0;
    
    currentRangeHold = 0;
    
    [rangeNumberDisplay setStringValue:@"0"];
    
    [rangeDisplay1 setStringValue:@"1: nil"];
    [rangeDisplay2 setStringValue:@"2: nil"];
    [rangeDisplay3 setStringValue:@"3: nil"];
    [rangeDisplay4 setStringValue:@"4: nil"];
    [rangeDisplay5 setStringValue:@"5: nil"];
    [rangeDisplay6 setStringValue:@"6: nil"];
    [rangeDisplay7 setStringValue:@"7: nil"];
    [rangeDisplay8 setStringValue:@"8: nil"];
    [rangeDisplay9 setStringValue:@"9: nil"];
    [rangeDisplay10 setStringValue:@"10: nil"];
    [colorSdDisplay setStringValue:@"Sd"];
    
    [rangeDisplay1 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:0 alpha:1]];
    [rangeDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:0 alpha:1]];
    [rangeDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:0 alpha:1]];
    [rangeDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:0 alpha:1]];
    [rangeDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:0 alpha:1]];
    [rangeDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:0 alpha:1]];
    [rangeDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:0 alpha:1]];
    [rangeDisplay8 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:0 alpha:1]];
    [rangeDisplay9 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:0 alpha:1]];
    [rangeDisplay10 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:0 alpha:1]];
    [colorSdDisplay setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:0 alpha:1]];
    
    colorMaxAreaHold = 0;
    numberOfGroupHold = 0;
    
    [colorMaxAreaDisplay setStringValue:@"0"];
    [stepperGroup setIntegerValue:numberOfGroupHold];
    [groupDisplay setIntegerValue:numberOfGroupHold];
    
    [self colorDataSave];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorPasteStatusSet:(id)sender{
    if (colorPasteStatus == 0){
        colorPasteStatus = 1;
        [colorPasteDisplay setStringValue:@"On"];
    }
    else if (colorPasteStatus == 1){
        colorPasteStatus = 0;
        [colorPasteDisplay setStringValue:@"Off"];
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToExportDisplay object:nil];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)phasePixelSet:(id)sender{
    if (pasteDotExport == 1){
        pasteDotExport = 2;
        [pasteDotDisplay setStringValue:@"2 Pix"];
    }
    else if (pasteDotExport == 2){
        pasteDotExport = 3;
        [pasteDotDisplay setStringValue:@"3 Pix"];
    }
    else if (pasteDotExport == 3){
        pasteDotExport = 4;
        [pasteDotDisplay setStringValue:@"4 Pix"];
    }
    else if (pasteDotExport == 4){
        pasteDotExport = 5;
        [pasteDotDisplay setStringValue:@"5 Pix"];
    }
    else if (pasteDotExport == 5){
        pasteDotExport = 6;
        [pasteDotDisplay setStringValue:@"6 Pix"];
    }
    else if (pasteDotExport == 6){
        pasteDotExport = 7;
        [pasteDotDisplay setStringValue:@"7 Pix"];
    }
    else if (pasteDotExport == 7){
        pasteDotExport = 8;
        [pasteDotDisplay setStringValue:@"8 Pix"];
    }
    else if (pasteDotExport == 8){
        pasteDotExport = 1;
        [pasteDotDisplay setStringValue:@"1 Pix"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)creatDataFile:(id)sender{
    if (imageProgressFlag == 0){
        string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
        mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Movie_Quant";
        mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        DIR *dir;
        struct dirent *dent;
        
        string entry;
        string extractString;
        int maxEntryNo = 0;
        
        dir = opendir(resultSavePath2.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Movie_Quant") != -1){
                    extractString = entry.substr(entry.find("MQ")+2, entry.find(".txt")-entry.find("MQ")-2);
                    
                    if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                }
            }
            
            closedir(dir);
        }
        
        maxEntryNo++;
        
        string path = resultSavePath2+"/Movie_Quant-MQ"+to_string(maxEntryNo)+".txt";
        
        ofstream oin;
        oin.open(path.c_str(), ios::out | ios::binary);
        
        int *arrayAscIIintData = new int [100];
        int ascIIintDataCount = 0;
        
        ascIIconversion = [[ASCIIconversion alloc] init];
        
        ascIIstring = analysisNameHold;
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = treatNameHold;
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        oin.put(13);
        oin.put(10);
        
        ascIIstring = "No";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "Area-Pixel";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        if (refStatusHold1 == 1){
            ascIIstring = "Area-Pixel-Subtract-Ref1";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            oin.put(9);
        }
        else if (refStatusHold1 == 2){
            ascIIstring = "Area-Pixel-Subtract-Ref2";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            oin.put(9);
        }
        else if (refStatusHold1 == 3){
            ascIIstring = "Min Feret";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = "Max Feret";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            oin.put(9);
        }
        else if (refStatusHold1 == 4){
            ascIIstring = "No of Nuclei";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            oin.put(9);
        }
        else if (refStatusHold1 == 5){
            ascIIstring = "Area-Pixel-Subtract-Ref1";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = "No of Nuclei";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            oin.put(9);
        }
        else if (refStatusHold1 == 6){
            ascIIstring = "Area-Pixel-Subtract-Ref2";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = "No of Nuclei";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            oin.put(9);
        }
        else if (refStatusHold1 == 7){
            ascIIstring = "Min Feret";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = "No of Nuclei";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            oin.put(9);
        }
        
        oin.put(13);
        oin.put(10);
        
        int **revisedWorkingMapExpTemp = new int *[imageXYLength+1];
        
        for (int counter1 = 0; counter1 < imageXYLength+1; counter1++){
            revisedWorkingMapExpTemp [counter1] = new int [imageXYLength+1];
        }
        
        for (int counter1 = 0; counter1 < imageXYLength; counter1++){
            for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                revisedWorkingMapExpTemp [counter1][counter2] = revisedWorkingMapExp [counter1][counter2];
            }
        }
        
        int *calDataHoldRef = new int [(timeSelectedExportCount/10)*4+100];
        double *calDataHoldRefDouble = new double [(timeSelectedExportCount/10)*4+100];
        int calDataHoldRefSet = 0;
        
        for (int counter1 = 0; counter1 < (timeSelectedExportCount/10)*4+100; counter1++){
            calDataHoldRef [counter1] = 0;
            calDataHoldRefDouble [counter1] = 0;
        }
        
        unsigned long headPosition = 0;
        int endianType = 0;
        int dataConversion [4];
        
        //----------Subtraction----------
        if ((refStatusHold1 == 1 || (refStatusHold1 == 5 && dotDataHoldCount != 0)) && uploadTempExpLoadRef2 == 1){
            headPosition = 0;
            
            dataConversion [0] = uploadTempExpRef2 [0];
            dataConversion [1] = uploadTempExpRef2 [1];
            
            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
            else endianType = 0;
            
            if (endianType == 1){
                dataConversion [0] = uploadTempExpRef2 [7];
                dataConversion [1] = uploadTempExpRef2 [6];
                dataConversion [2] = uploadTempExpRef2 [5];
                dataConversion [3] = uploadTempExpRef2 [4];
                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
            }
            else if (endianType == 0){
                dataConversion [0] = uploadTempExpRef2 [4];
                dataConversion [1] = uploadTempExpRef2 [5];
                dataConversion [2] = uploadTempExpRef2 [6];
                dataConversion [3] = uploadTempExpRef2 [7];
                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
            }
            
            int grayColorStatusColor = 0;
            
            if (headPosition-8 == (unsigned long)(imageXYLength*imageXYLength)) grayColorStatusColor = 0;
            else grayColorStatusColor = 1;
            
            int **arrayExtractedImage = new int *[imageXYLength+1];
            
            if (grayColorStatusColor == 0){
                for (int counter3 = 0; counter3 < imageXYLength+1; counter3++){
                    arrayExtractedImage [counter3] = new int [imageXYLength+1];
                }
            }
            else{
                
                for (int counter3 = 0; counter3 < imageXYLength+1; counter3++){
                    arrayExtractedImage [counter3] = new int [imageXYLength*3+1];
                }
            }
            
            int horizontalEntry = 0;
            int verticalEntry = 0;
            
            if (grayColorStatusColor == 0){
                int value0 = 0;
                
                for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                    value0 = uploadTempExpRef2 [counter1];
                    
                    arrayExtractedImage [verticalEntry][horizontalEntry] = value0, horizontalEntry++;
                    
                    if (horizontalEntry == imageXYLength){
                        horizontalEntry = 0;
                        verticalEntry++;
                    }
                }
            }
            else if (grayColorStatusColor == 1){
                int value0 = 0;
                int value1 = 0;
                int value2 = 0;
                
                for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                    value0 = uploadTempExpRef2 [counter1];
                    value1 = uploadTempExpRef2 [counter1+1];
                    value2 = uploadTempExpRef2 [counter1+2];
                    
                    arrayExtractedImage [verticalEntry][horizontalEntry] = value0, horizontalEntry++;
                    arrayExtractedImage [verticalEntry][horizontalEntry] = value1, horizontalEntry++;
                    arrayExtractedImage [verticalEntry][horizontalEntry] = value2, horizontalEntry++;
                    
                    if (horizontalEntry == imageXYLength*3){
                        horizontalEntry = 0;
                        verticalEntry++;
                    }
                }
            }
            
            if (grayColorStatusColor == 0){
                for (int counter1 = 0; counter1 < imageXYLength; counter1++){
                    for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                        if (arrayExtractedImage [counter1][counter2] != 0) revisedWorkingMapExpTemp [counter1][counter2] = 0;
                    }
                }
            }
            else{
                
                for (int counter1 = 0; counter1 < imageXYLength; counter1++){
                    for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                        if (arrayExtractedImage [counter1][counter2*3] != 0) revisedWorkingMapExpTemp [counter1][counter2] = 0;
                        if (arrayExtractedImage [counter1][counter2*3+1] != 0) revisedWorkingMapExpTemp [counter1][counter2] = 0;
                        if (arrayExtractedImage [counter1][counter2*3+2] != 0) revisedWorkingMapExpTemp [counter1][counter2] = 0;
                    }
                }
            }
            
            for (int counter3 = 0; counter3 < imageXYLength+1; counter3++){
                delete [] arrayExtractedImage [counter3];
            }
            
            delete [] arrayExtractedImage;
            
            for (int counter1 = 0; counter1 < imageXYLength; counter1++){
                for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                    if (revisedWorkingMapExpTemp [counter1][counter2] != 0) calDataHoldRef [revisedWorkingMapExpTemp [counter1][counter2]*2]++;
                }
            }
            
            calDataHoldRefSet = 1;
        }
        else if ((refStatusHold1 == 2 || (refStatusHold1 == 6 && dotDataHoldCount != 0)) && uploadTempExpLoadRef3 == 1){
            headPosition = 0;
            
            dataConversion [0] = uploadTempExpRef3 [0];
            dataConversion [1] = uploadTempExpRef3 [1];
            
            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
            else endianType = 0;
            
            if (endianType == 1){
                dataConversion [0] = uploadTempExpRef3 [7];
                dataConversion [1] = uploadTempExpRef3 [6];
                dataConversion [2] = uploadTempExpRef3 [5];
                dataConversion [3] = uploadTempExpRef3 [4];
                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
            }
            else if (endianType == 0){
                dataConversion [0] = uploadTempExpRef3 [4];
                dataConversion [1] = uploadTempExpRef3 [5];
                dataConversion [2] = uploadTempExpRef3 [6];
                dataConversion [3] = uploadTempExpRef3 [7];
                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
            }
            
            int grayColorStatusColor = 0;
            
            if (headPosition-8 == (unsigned long)(imageXYLength*imageXYLength)) grayColorStatusColor = 0;
            else grayColorStatusColor = 1;
            
            int **arrayExtractedImage = new int *[imageXYLength+1];
            
            if (grayColorStatusColor == 0){
                for (int counter3 = 0; counter3 < imageXYLength+1; counter3++){
                    arrayExtractedImage [counter3] = new int [imageXYLength+1];
                }
            }
            else{
                
                for (int counter3 = 0; counter3 < imageXYLength+1; counter3++){
                    arrayExtractedImage [counter3] = new int [imageXYLength*3+1];
                }
            }
            
            int horizontalEntry = 0;
            int verticalEntry = 0;
            
            if (grayColorStatusColor == 0){
                int value0 = 0;
                
                for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                    value0 = uploadTempExpRef3 [counter1];
                    
                    arrayExtractedImage [verticalEntry][horizontalEntry] = value0, horizontalEntry++;
                    
                    if (horizontalEntry == imageXYLength){
                        horizontalEntry = 0;
                        verticalEntry++;
                    }
                }
            }
            else if (grayColorStatusColor == 1){
                int value0 = 0;
                int value1 = 0;
                int value2 = 0;
                
                for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                    value0 = uploadTempExpRef3 [counter1];
                    value1 = uploadTempExpRef3 [counter1+1];
                    value2 = uploadTempExpRef3 [counter1+2];
                    
                    arrayExtractedImage [verticalEntry][horizontalEntry] = value0, horizontalEntry++;
                    arrayExtractedImage [verticalEntry][horizontalEntry] = value1, horizontalEntry++;
                    arrayExtractedImage [verticalEntry][horizontalEntry] = value2, horizontalEntry++;
                    
                    if (horizontalEntry == imageXYLength*3){
                        horizontalEntry = 0;
                        verticalEntry++;
                    }
                }
            }
            
            if (grayColorStatusColor == 0){
                for (int counter1 = 0; counter1 < imageXYLength; counter1++){
                    for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                        if (arrayExtractedImage [counter1][counter2] != 0) revisedWorkingMapExpTemp [counter1][counter2] =  0;
                    }
                }
            }
            else{
                
                for (int counter1 = 0; counter1 < imageXYLength; counter1++){
                    for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                        if (arrayExtractedImage [counter1][counter2*3] != 0) revisedWorkingMapExpTemp [counter1][counter2] =  0;
                        if (arrayExtractedImage [counter1][counter2*3+1] != 0) revisedWorkingMapExpTemp [counter1][counter2] =  0;
                        if (arrayExtractedImage [counter1][counter2*3+2] != 0) revisedWorkingMapExpTemp [counter1][counter2] =  0;
                    }
                }
            }
            
            for (int counter3 = 0; counter3 < imageXYLength+1; counter3++){
                delete [] arrayExtractedImage [counter3];
            }
            
            delete [] arrayExtractedImage;
            
            for (int counter1 = 0; counter1 < imageXYLength; counter1++){
                for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                    if (revisedWorkingMapExpTemp [counter1][counter2] != 0) calDataHoldRef [revisedWorkingMapExpTemp [counter1][counter2]*2]++;
                }
            }
            
            calDataHoldRefSet = 1;
        }
        
        if (refStatusHold1 == 3 || (refStatusHold1 == 7 && dotDataHoldCount != 0)){
            int maxMapConnect = timeSelectedExportCount/10;
            
            int *connectLimit = new int [(maxMapConnect+1)*4+100];
            
            for (int counter3 = 0; counter3 <= maxMapConnect; counter3++){
                connectLimit [counter3*4] = 0;
                connectLimit [counter3*4+1] = 1000000;
                connectLimit [counter3*4+2] = 0;
                connectLimit [counter3*4+3] = 1000000;
            }
            
            for (int counter3 = 0; counter3 < imageXYLength; counter3++){
                for (int counter4 = 0; counter4 < imageXYLength; counter4++){
                    if (revisedWorkingMapExp [counter3][counter4] != 0){
                        if (connectLimit [revisedWorkingMapExp [counter3][counter4]*4] < counter3) connectLimit [revisedWorkingMapExp [counter3][counter4]*4] = counter3;
                        if (connectLimit [revisedWorkingMapExp [counter3][counter4]*4+1] > counter3) connectLimit [revisedWorkingMapExp [counter3][counter4]*4+1] = counter3;
                        if (connectLimit [revisedWorkingMapExp [counter3][counter4]*4+2] < counter4) connectLimit [revisedWorkingMapExp [counter3][counter4]*4+2] = counter4;
                        if (connectLimit [revisedWorkingMapExp [counter3][counter4]*4+3] > counter4) connectLimit [revisedWorkingMapExp [counter3][counter4]*4+3] = counter4;
                    }
                }
            }
            
            int maxPointDimX = 0;
            int maxPointDimY = 0;
            int minPointDimX = 0;
            int minPointDimY = 0;
            int horizontalLength = 0;
            int verticalLength = 0;
            int dimension = 0;
            int horizontalStart = 0;
            int verticalStart = 0;
            int connectivityNumber = 0;
            int connectAnalysisCount = 0;
            int terminationFlag = 0;
            int connectAnalysisTempCount = 0;
            int xSource = 0;
            int ySource = 0;
            int numberOfEdge = 0;
            int edgeCount = 0;
            int dataTempX = 0;
            int dataTempY = 0;
            int dataTempX2 = 0;
            int dataTempY2 = 0;
            int distanceListCount = 0;
            int crossFind = 0;
            int yValueInt = 0;
            
            double yValue = 0;
            double constA = 0;
            double constC = 0;
            double constD = 0;
            double constE = 0;
            double maxFeret = 0;
            double minFeret = 0;
            
            for (int counter2 = 1; counter2 <= maxMapConnect; counter2++){
                maxPointDimX = 0;
                maxPointDimY = 0;
                minPointDimX = 1000000;
                minPointDimY = 1000000;
                
                for (int counter3 = connectLimit [counter2*4+1]; counter3 <= connectLimit [counter2*4]; counter3++){
                    for (int counter4 = connectLimit [counter2*4+3]; counter4 <= connectLimit [counter2*4+2]; counter4++){
                        if (counter2 == revisedWorkingMapExp [counter3][counter4]){
                            if (maxPointDimX < counter4) maxPointDimX = counter4;
                            if (minPointDimX > counter4) minPointDimX = counter4;
                            if (maxPointDimY < counter3) maxPointDimY = counter3;
                            if (minPointDimY > counter3) minPointDimY = counter3;
                        }
                    }
                }
                
                if (minPointDimX != 1000000){
                    //------Determine the dimension of cell------
                    horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                    verticalLength = (maxPointDimY-minPointDimY)/2*2;
                    dimension = 0;
                    
                    if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
                    if (horizontalLength < verticalLength) dimension = verticalLength+30;
                    
                    dimension = (dimension/2)*2;
                    
                    horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
                    verticalStart = minPointDimY-(dimension-verticalLength)/2;
                    
                    int **connectivityMapVerMap = new int *[dimension+1];
                    
                    for (int counter3 = 0; counter3 < dimension+1; counter3++){
                        connectivityMapVerMap [counter3] = new int [dimension+1];
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            connectivityMapVerMap [counterY][counterX] = 0;
                        }
                    }
                    
                    for (int counter3 = connectLimit [counter2*4+1]; counter3 <= connectLimit [counter2*4]; counter3++){
                        for (int counter4 = connectLimit [counter2*4+3]; counter4 <= connectLimit [counter2*4+2]; counter4++){
                            if (counter2 == revisedWorkingMapExp [counter3][counter4]){
                                if (counter3-verticalStart >= 0 && counter3-verticalStart < dimension && counter4-horizontalStart >= 0 && counter4-horizontalStart < dimension){
                                    connectivityMapVerMap [counter3-verticalStart][counter4-horizontalStart] = 1;
                                }
                            }
                        }
                    }
                    
                    //------Fill inside------
                    int *connectAnalysisX = new int [dimension*4];
                    int *connectAnalysisY = new int [dimension*4];
                    int *connectAnalysisTempX = new int [dimension*4];
                    int *connectAnalysisTempY = new int [dimension*4];
                    
                    connectivityNumber = -3;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapVerMap [counterY][counterX] == 0){
                                connectivityNumber = connectivityNumber+2;
                                connectAnalysisCount = 0;
                                
                                if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMapVerMap [counterY][counterX] = connectivityNumber;
                                
                                if (counterY-1 >= 0 && connectivityMapVerMap [counterY-1][counterX] == 0){
                                    connectivityMapVerMap [counterY-1][counterX] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                }
                                if (counterX+1 < dimension && connectivityMapVerMap [counterY][counterX+1] == 0){
                                    connectivityMapVerMap [counterY][counterX+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                if (counterY+1 < dimension && connectivityMapVerMap [counterY+1][counterX] == 0){
                                    connectivityMapVerMap [counterY+1][counterX] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                }
                                if (counterX-1 >= 0 && connectivityMapVerMap [counterY][counterX-1] == 0){
                                    connectivityMapVerMap [counterY][counterX-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                            xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                            
                                            if (ySource-1 >= 0 && connectivityMapVerMap [ySource-1][xSource] == 0){
                                                connectivityMapVerMap [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension && connectivityMapVerMap [ySource][xSource+1] == 0){
                                                connectivityMapVerMap [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension && connectivityMapVerMap [ySource+1][xSource] == 0){
                                                connectivityMapVerMap [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && connectivityMapVerMap [ySource][xSource-1] == 0){
                                                connectivityMapVerMap [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                            connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapVerMap [counterY][counterX] == -1) connectivityMapVerMap [counterY][counterX] = 0;
                            else connectivityMapVerMap [counterY][counterX] = 1;
                        }
                    }
                    
                    delete [] connectAnalysisX;
                    delete [] connectAnalysisY;
                    delete [] connectAnalysisTempX;
                    delete [] connectAnalysisTempY;
                    
                    //------Connectivity analysis, For Zero------
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapVerMap [counterY][counterX] != 0){
                                if (counterX+1 < dimension && connectivityMapVerMap [counterY][counterX+1] == 0) connectivityMapVerMap [counterY][counterX] = -1;
                                else if (counterY+1 < dimension && connectivityMapVerMap [counterY+1][counterX] == 0) connectivityMapVerMap [counterY][counterX] = -1;
                                else if (counterX-1 >= 0 && connectivityMapVerMap [counterY][counterX-1] == 0) connectivityMapVerMap [counterY][counterX] = -1;
                                else if (counterY-1 >= 0 && connectivityMapVerMap [counterY-1][counterX] == 0) connectivityMapVerMap [counterY][counterX] = -1;
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //    for (int counterB = 0; counterB < dimension; counterB++)  cout<<" "<<connectivityMapVerMap [counterA][counterB];//
                    //    cout<<" connectivityMapVerMap"<<counterA<<endl;
                    //}
                    
                    numberOfEdge = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapVerMap [counterY][counterX] == -1){
                                connectivityMapVerMap [counterY][counterX] = 2;
                                numberOfEdge++;
                            }
                        }
                    }
                    
                    int *edgeList = new int [numberOfEdge*2+10];
                    double *distanceList = new double [numberOfEdge*numberOfEdge+10];
                    distanceListCount = 0;
                    
                    for (int counter3 = 0; counter3 < numberOfEdge*2+10; counter3++) edgeList [counter3] = 0;
                    
                    edgeCount = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapVerMap [counterY][counterX] == 2){
                                edgeList [edgeCount] = counterX, edgeCount++;
                                edgeList [edgeCount] = counterY, edgeCount++;
                            }
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < edgeCount/2-1; counter3++){
                        for (int counter4 = counter3+1; counter4 < edgeCount/2; counter4++){
                            dataTempX = edgeList [counter3*2];
                            dataTempY = edgeList [counter3*2+1];
                            
                            dataTempX2 = edgeList [counter4*2];
                            dataTempY2 = edgeList [counter4*2+1];
                            
                            if (dataTempX2-dataTempX != 0 && dataTempY2-dataTempY != 0){
                                constA = (dataTempY2-dataTempY)/(double)(dataTempX2-dataTempX);
                                
                                constC = -1/(double)constA;
                                constD = (double)dataTempY-(double)(constC*dataTempX);
                                constE = (double)dataTempY2-(double)(constC*dataTempX2);
                                
                                crossFind = 0;
                                
                                for (int counter5 = 0; counter5 < dimension; counter5++){
                                    yValue = constC*(double)counter5+constD;
                                    
                                    if (yValue >= 0 && yValue < dimension){
                                        yValueInt = (int)yValue;
                                        
                                        if (connectivityMapVerMap [yValueInt][counter5] == 1) crossFind = 1;
                                    }
                                    
                                    yValue = constC*(double)counter5+constE;
                                    
                                    if (yValue >= 0 && yValue < dimension){
                                        yValueInt = (int)yValue;
                                        
                                        if (connectivityMapVerMap [yValueInt][counter5] == 1) crossFind = 1;
                                    }
                                }
                                
                                if (crossFind == 0) distanceList [distanceListCount] = sqrt((dataTempX2-dataTempX)*(dataTempX2-dataTempX)+(dataTempY2-dataTempY)*(dataTempY2-dataTempY)), distanceListCount++;
                            }
                            else if (dataTempX2-dataTempX == 0 && dataTempY2-dataTempY != 0){
                                crossFind = 0;
                                
                                for (int counter5 = 0; counter5 < dimension; counter5++){
                                    if (connectivityMapVerMap [dataTempY][counter5] == 1) crossFind = 1;
                                    if (connectivityMapVerMap [dataTempY2][counter5] == 1) crossFind = 1;
                                }
                                
                                if (crossFind == 0) distanceList [distanceListCount] = sqrt((dataTempX2-dataTempX)*(dataTempX2-dataTempX)+(dataTempY2-dataTempY)*(dataTempY2-dataTempY)), distanceListCount++;
                            }
                            else if (dataTempX2-dataTempX != 0 && dataTempY2-dataTempY == 0){
                                crossFind = 0;
                                
                                for (int counter5 = 0; counter5 < dimension; counter5++){
                                    if (connectivityMapVerMap [counter5][dataTempX] == 1) crossFind = 1;
                                    if (connectivityMapVerMap [counter5][dataTempX2] == 1) crossFind = 1;
                                }
                                
                                if (crossFind == 0) distanceList [distanceListCount] = sqrt((dataTempX2-dataTempX)*(dataTempX2-dataTempX)+(dataTempY2-dataTempY)*(dataTempY2-dataTempY)), distanceListCount++;
                            }
                        }
                    }
                    
                    maxFeret = 0;
                    minFeret = 10000000;
                    
                    for (int counter3 = 0; counter3 < distanceListCount; counter3++){
                        if (distanceList [counter3] > maxFeret) maxFeret = distanceList [counter3];
                        if (distanceList [counter3] < minFeret) minFeret = distanceList [counter3];
                    }
                    
                    if (refStatusHold1 == 3 && minFeret != 10000000){
                        calDataHoldRefDouble [counter2*2] = minFeret;
                        calDataHoldRefDouble [counter2*2+1] = maxFeret;
                    }
                    else if (refStatusHold1 == 7 && minFeret != 10000000){
                        calDataHoldRefDouble [counter2*2] = minFeret;
                    }
                    
                    for (int counter3 = 0; counter3 < dimension+1; counter3++){
                        delete [] connectivityMapVerMap [counter3];
                    }
                    
                    delete [] connectivityMapVerMap;
                    
                    delete [] edgeList;
                    delete [] distanceList;
                }
            }
            
            delete [] connectLimit;
            
            calDataHoldRefSet = 1;
        }
        
        if ((refStatusHold1 == 4 || refStatusHold1 == 5 || refStatusHold1 == 6 || refStatusHold1 == 7) && dotDataHoldCount != 0){
            int *arrayDotDataTemp = new int [dotDataHoldCount*2+30];
            int dotDataTempCount = 0;
            
            for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                arrayDotDataTemp [dotDataTempCount] = arrayDotDataHold [counter1*3], dotDataTempCount++;
                arrayDotDataTemp [dotDataTempCount] = arrayDotDataHold [counter1*3+1], dotDataTempCount++;
                arrayDotDataTemp [dotDataTempCount] = arrayDotDataHold [counter1*3+2], dotDataTempCount++;
                arrayDotDataTemp [dotDataTempCount] = 0, dotDataTempCount++;
            }
            
            for (int counter1 = 0; counter1 < dotDataTempCount/4; counter1++){
                for (int counter2 = 0; counter2 < timeSelectedExportCount/10; counter2++){
                    if ((int)arrayDotDataTemp [counter1*4+2] >= 0 && (int)arrayDotDataTemp [counter1*4+2] < imageSizeLimit && (int)arrayDotDataTemp [counter1*4+1] >= 0 && (int)arrayDotDataTemp [counter1*4+1] < imageSizeLimit){
                        if (arrayTimeSelectedExport [counter2*10+8] == revisedWorkingMapExp [(int)arrayDotDataTemp [counter1*4+2]][(int)arrayDotDataTemp [counter1*4+1]]){
                            arrayDotDataTemp [counter1*4+3] = revisedWorkingMapExp [(int)arrayDotDataTemp [counter1*4+2]][(int)arrayDotDataTemp [counter1*4+1]];
                            break;
                        }
                    }
                }
            }
            
            for (int counter1 = 0; counter1 < dotDataTempCount/4; counter1++){
                if (arrayDotDataTemp [counter1*4+3] != 0) calDataHoldRef [arrayDotDataTemp [counter1*4+3]*2+1]++;
            }
            
            delete [] arrayDotDataTemp;
            
            calDataHoldRefSet = 1;
        }
        
        for (int counter1 = 0; counter1 < imageXYLength+1; counter1++){
            delete [] revisedWorkingMapExpTemp [counter1];
        }
        
        delete [] revisedWorkingMapExpTemp;
        
        int *calDataHold = new int [(timeSelectedExportCount/10)*3+100];
        
        for (int counter1 = 0; counter1 < (timeSelectedExportCount/10)*3+100; counter1++) calDataHold [counter1] = 0;
        
        int calDataHoldCount = 0;
        
        for (int counter1 = 0; counter1 < timeSelectedExportCount/10; counter1++){
            if (arrayTimeSelectedExport [counter1*10] == 1 || arrayTimeSelectedExport [counter1*10] == 10 || arrayTimeSelectedExport [counter1*10] == 11){
                for (int counter2 = 0; counter2 < gravityCenterExportCount/6; counter2++){
                    if (arrayGravityCenterExport [counter2*6+4] == arrayTimeSelectedExport [counter1*10+8]){
                        calDataHold [calDataHoldCount] = arrayGravityCenterExport [counter2*6+4], calDataHoldCount++;
                        calDataHold [calDataHoldCount] = arrayGravityCenterExport [counter2*6+2], calDataHoldCount++;
                        
                        if (arrayTimeSelectedExport [counter1*10] == 10){
                            calDataHold [calDataHoldCount] = 1, calDataHoldCount++;
                        }
                        else if (arrayTimeSelectedExport [counter1*10] == 11){
                            calDataHold [calDataHoldCount] = 2, calDataHoldCount++;
                        }
                        else calDataHold [calDataHoldCount] = 0, calDataHoldCount++;
                        
                        break;
                    }
                }
            }
        }
        
        //for (int counterA = 0; counterA < calDataHoldCount/3; counterA++){
        //    cout<<calDataHold [counterA*3]<<" "<<calDataHold [counterA*3+1]<<" "<<calDataHold [counterA*3+2]<<" calDataHold"<<endl;
        //}
        
        //for (int counterA = 0; counterA < timeSelectedExportCount/10; counterA++){
        //    cout<<counterA<<" "<<calDataHoldRefDouble [counterA*2]<<" "<<calDataHoldRefDouble [counterA*2+1]<<" calDataHoldRefDouble"<<endl;
        //}
        
        //for (int counterA = 0; counterA < timeSelectedExportCount/10; counterA++){
        //    cout<<counterA<<" "<<calDataHoldRef [counterA*2]<<" "<<calDataHoldRef [counterA*2+1]<<" calDataHoldRef"<<endl;
        //}
        
        double meanFeretDouble = 0;
        int meanFeretInt = 0;
        
        for (int counter2 = 0; counter2 < calDataHoldCount/3; counter2++){
            if (calDataHold [counter2*3+2] == 0){
                ascIIstring = to_string(calDataHold [counter2*3]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(calDataHold [counter2*3+1]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                if (refStatusHold1 == 1 && uploadTempExpLoadRef2 == 1){
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    oin.put(9);
                }
                else if (refStatusHold1 == 2 && uploadTempExpLoadRef3 == 1){
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    oin.put(9);
                }
                else if (refStatusHold1 == 3){
                    meanFeretInt = (int)(calDataHoldRefDouble [calDataHold [counter2*3]*2]*100);
                    meanFeretDouble = meanFeretInt/(double)100;
                    
                    stringstream extension1;
                    extension1 << meanFeretDouble;
                    string shortestString = extension1.str();
                    
                    ascIIstring = shortestString;
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    meanFeretInt = (int)(calDataHoldRefDouble [calDataHold [counter2*3]*2+1]*100);
                    meanFeretDouble = meanFeretInt/(double)100;
                    
                    stringstream extension2;
                    extension2 << meanFeretDouble;
                    shortestString = extension2.str();
                    
                    ascIIstring = shortestString;
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                }
                else if (refStatusHold1 == 4 && dotDataHoldCount != 0){
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2+1]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    oin.put(9);
                }
                else if (refStatusHold1 == 5 && dotDataHoldCount != 0){
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2+1]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                }
                else if (refStatusHold1 == 6 && dotDataHoldCount != 0){
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2+1]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                }
                else if (refStatusHold1 == 7 && dotDataHoldCount != 0){
                    meanFeretInt = (int)(calDataHoldRefDouble [calDataHold [counter2*3]*2]*100);
                    meanFeretDouble = meanFeretInt/(double)100;
                    
                    stringstream extension1;
                    extension1 << meanFeretDouble;
                    string shortestString = extension1.str();
                    
                    ascIIstring = shortestString;
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2+1]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    oin.put(9);
                }
                else{
                    
                    oin.put(9);
                    oin.put(9);
                }
                
                oin.put(13);
                oin.put(10);
            }
        }
        
        oin.put(13);
        oin.put(10);
        
        ascIIstring = "Other1";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        for (int counter2 = 0; counter2 < calDataHoldCount/3; counter2++){
            if (calDataHold [counter2*3+2] == 1){
                ascIIstring = to_string(calDataHold [counter2*3]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(calDataHold [counter2*3+1]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                if (refStatusHold1 == 1 && uploadTempExpLoadRef2 == 1){
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    oin.put(9);
                }
                else if (refStatusHold1 == 2 && uploadTempExpLoadRef3 == 1){
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    oin.put(9);
                }
                else if (refStatusHold1 == 3){
                    meanFeretInt = (int)(calDataHoldRefDouble [calDataHold [counter2*3]*2]*100);
                    meanFeretDouble = meanFeretInt/(double)100;
                    
                    stringstream extension1;
                    extension1 << meanFeretDouble;
                    string shortestString = extension1.str();
                    
                    ascIIstring = shortestString;
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    meanFeretInt = (int)(calDataHoldRefDouble [calDataHold [counter2*3]*2+1]*100);
                    meanFeretDouble = meanFeretInt/(double)100;
                    
                    stringstream extension2;
                    extension2 << meanFeretDouble;
                    shortestString = extension2.str();
                    
                    ascIIstring = shortestString;
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                }
                else if (refStatusHold1 == 4 && dotDataHoldCount != 0){
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2+1]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    oin.put(9);
                }
                else if (refStatusHold1 == 5 && dotDataHoldCount != 0){
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2+1]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                }
                else if (refStatusHold1 == 6 && dotDataHoldCount != 0){
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2+1]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                }
                else if (refStatusHold1 == 7 && dotDataHoldCount != 0){
                    meanFeretInt = (int)(calDataHoldRefDouble [calDataHold [counter2*3]*2]*100);
                    meanFeretDouble = meanFeretInt/(double)100;
                    
                    stringstream extension1;
                    extension1 << meanFeretDouble;
                    string shortestString = extension1.str();
                    
                    ascIIstring = shortestString;
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2+1]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    oin.put(9);
                }
                else{
                    
                    oin.put(9);
                    oin.put(9);
                }
                
                oin.put(13);
                oin.put(10);
            }
        }
        
        oin.put(13);
        oin.put(10);
        
        ascIIstring = "Other2";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        for (int counter2 = 0; counter2 < calDataHoldCount/3; counter2++){
            if (calDataHold [counter2*3+2] == 2){
                ascIIstring = to_string(calDataHold [counter2*3]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(calDataHold [counter2*3+1]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                if (refStatusHold1 == 1 && uploadTempExpLoadRef2 == 1){
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    oin.put(9);
                }
                else if (refStatusHold1 == 2 && uploadTempExpLoadRef3 == 1){
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    oin.put(9);
                }
                else if (refStatusHold1 == 3){
                    meanFeretInt = (int)(calDataHoldRefDouble [calDataHold [counter2*3]*2]*100);
                    meanFeretDouble = meanFeretInt/(double)100;
                    
                    stringstream extension1;
                    extension1 << meanFeretDouble;
                    string shortestString = extension1.str();
                    
                    ascIIstring = shortestString;
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    meanFeretInt = (int)(calDataHoldRefDouble [calDataHold [counter2*3]*2+1]*100);
                    meanFeretDouble = meanFeretInt/(double)100;
                    
                    stringstream extension2;
                    extension2 << meanFeretDouble;
                    shortestString = extension2.str();
                    
                    ascIIstring = shortestString;
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                }
                else if (refStatusHold1 == 4 && dotDataHoldCount != 0){
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2+1]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    oin.put(9);
                }
                else if (refStatusHold1 == 5 && dotDataHoldCount != 0){
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2+1]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                }
                else if (refStatusHold1 == 6 && dotDataHoldCount != 0){
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2+1]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                }
                else if (refStatusHold1 == 7 && dotDataHoldCount != 0){
                    meanFeretInt = (int)(calDataHoldRefDouble [calDataHold [counter2*3]*2]*100);
                    meanFeretDouble = meanFeretInt/(double)100;
                    
                    stringstream extension1;
                    extension1 << meanFeretDouble;
                    string shortestString = extension1.str();
                    
                    ascIIstring = shortestString;
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(calDataHoldRef [calDataHold [counter2*3]*2+1]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    oin.put(9);
                }
                else{
                    
                    oin.put(9);
                    oin.put(9);
                }
                
                oin.put(13);
                oin.put(10);
            }
        }
        
        oin.put(13);
        oin.put(10);
        
        delete [] calDataHold;
        
        int *histoTemp = new int [50];
        int *histoTempRef = new int [50];
        int *histoTempRef2 = new int [50];
        
        for (int counter2 = 0; counter2 < 50; counter2++){
            histoTemp [counter2] = 0;
            histoTempRef [counter2] = 0;
            histoTempRef2 [counter2] = 0;
        }
        
        for (int counter1 = 0; counter1 < timeSelectedExportCount/10; counter1++){
            if (arrayTimeSelectedExport [counter1*10] == 1){
                for (int counter2 = 0; counter2 < gravityCenterExportCount/6; counter2++){
                    if (arrayGravityCenterExport [counter2*6+4] == arrayTimeSelectedExport [counter1*10+8]){
                        if (colorHoldArea1 != 0 && arrayGravityCenterExport [counter2*6+2] <= colorHoldArea1){
                            histoTemp [0]++;
                            histoTemp [1] = histoTemp [1]+arrayGravityCenterExport [counter2*6+2];
                            
                            if (refStatusHold1 == 4 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [20]++;
                        }
                        else if (colorHoldArea1 != 0 && colorHoldArea2 == 0 && arrayGravityCenterExport [counter2*6+2] > colorHoldArea1){
                            histoTemp [2]++;
                            histoTemp [3] = histoTemp [3]+arrayGravityCenterExport [counter2*6+2];
                            
                            if (refStatusHold1 == 4 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [22]++;
                        }
                        else if (colorHoldArea1 != 0 && colorHoldArea2 != 0 && arrayGravityCenterExport [counter2*6+2] > colorHoldArea1 && arrayGravityCenterExport [counter2*6+2] <= colorHoldArea2){
                            histoTemp [2]++;
                            histoTemp [3] = histoTemp [3]+arrayGravityCenterExport [counter2*6+2];
                            
                            if (refStatusHold1 == 4 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [22]++;
                        }
                        else if (colorHoldArea2 != 0 && colorHoldArea3 == 0 && arrayGravityCenterExport [counter2*6+2] > colorHoldArea2){
                            histoTemp [4]++;
                            histoTemp [5] = histoTemp [5]+arrayGravityCenterExport [counter2*6+2];
                            
                            if (refStatusHold1 == 4 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [24]++;
                        }
                        else if (colorHoldArea2 != 0 && colorHoldArea3 != 0 && arrayGravityCenterExport [counter2*6+2] > colorHoldArea2 && arrayGravityCenterExport [counter2*6+2] <= colorHoldArea3){
                            histoTemp [4]++;
                            histoTemp [5] = histoTemp [5]+arrayGravityCenterExport [counter2*6+2];
                            
                            if (refStatusHold1 == 4 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [24]++;
                        }
                        else if (colorHoldArea3 != 0 && colorHoldArea4 == 0 && arrayGravityCenterExport [counter2*6+2] > colorHoldArea3){
                            histoTemp [6]++;
                            histoTemp [7] = histoTemp [7]+arrayGravityCenterExport [counter2*6+2];
                            
                            if (refStatusHold1 == 4 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [26]++;
                        }
                        else if (colorHoldArea3 != 0 && colorHoldArea4 != 0 && arrayGravityCenterExport [counter2*6+2] > colorHoldArea3 && arrayGravityCenterExport [counter2*6+2] <= colorHoldArea4){
                            histoTemp [6]++;
                            histoTemp [7] = histoTemp [7]+arrayGravityCenterExport [counter2*6+2];
                            
                            if (refStatusHold1 == 4 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [26]++;
                        }
                        else if (colorHoldArea4 != 0 && colorHoldArea5 == 0 && arrayGravityCenterExport [counter2*6+2] > colorHoldArea4){
                            histoTemp [8]++;
                            histoTemp [9] = histoTemp [9]+arrayGravityCenterExport [counter2*6+2];
                            
                            if (refStatusHold1 == 4 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [28]++;
                        }
                        else if (colorHoldArea4 != 0 && colorHoldArea5 != 0 && arrayGravityCenterExport [counter2*6+2] > colorHoldArea4 && arrayGravityCenterExport [counter2*6+2] <= colorHoldArea5){
                            histoTemp [8]++;
                            histoTemp [9] = histoTemp [9]+arrayGravityCenterExport [counter2*6+2];
                            
                            if (refStatusHold1 == 4 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [28]++;
                        }
                        else if (colorHoldArea5 != 0 && colorHoldArea6 == 0 && arrayGravityCenterExport [counter2*6+2] > colorHoldArea5){
                            histoTemp [10]++;
                            histoTemp [11] = histoTemp [11]+arrayGravityCenterExport [counter2*6+2];
                            
                            if (refStatusHold1 == 4 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [30]++;
                        }
                        else if (colorHoldArea5 != 0 && colorHoldArea6 != 0 && arrayGravityCenterExport [counter2*6+2] > colorHoldArea5 && arrayGravityCenterExport [counter2*6+2] <= colorHoldArea6){
                            histoTemp [10]++;
                            histoTemp [11] = histoTemp [11]+arrayGravityCenterExport [counter2*6+2];
                            
                            if (refStatusHold1 == 4 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [30]++;
                        }
                        else if (colorHoldArea6 != 0 && colorHoldArea7 == 0 && arrayGravityCenterExport [counter2*6+2] > colorHoldArea6){
                            histoTemp [12]++;
                            histoTemp [13] = histoTemp [13]+arrayGravityCenterExport [counter2*6+2];
                            
                            if (refStatusHold1 == 4 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [32]++;
                        }
                        else if (colorHoldArea6 != 0 && colorHoldArea7 != 0 && arrayGravityCenterExport [counter2*6+2] > colorHoldArea6 && arrayGravityCenterExport [counter2*6+2] <= colorHoldArea7){
                            histoTemp [12]++;
                            histoTemp [13] = histoTemp [13]+arrayGravityCenterExport [counter2*6+2];
                            
                            if (refStatusHold1 == 4 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [32]++;
                        }
                        else if (colorHoldArea7 != 0 && colorHoldArea8 == 0 && arrayGravityCenterExport [counter2*6+2] > colorHoldArea7 && arrayGravityCenterExport [counter2*6+2] <= colorHoldArea8){
                            histoTemp [14]++;
                            histoTemp [15] = histoTemp [15]+arrayGravityCenterExport [counter2*6+2];
                            
                            if (refStatusHold1 == 4 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [34]++;
                        }
                        else if (colorHoldArea7 != 0 && colorHoldArea8 != 0 && arrayGravityCenterExport [counter2*6+2] > colorHoldArea7 && arrayGravityCenterExport [counter2*6+2] <= colorHoldArea8){
                            histoTemp [14]++;
                            histoTemp [15] = histoTemp [15]+arrayGravityCenterExport [counter2*6+2];
                            
                            if (refStatusHold1 == 4 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [34]++;
                        }
                        else if (colorHoldArea8 != 0 && colorHoldArea9 == 0 && arrayGravityCenterExport [counter2*6+2] > colorHoldArea8){
                            histoTemp [16]++;
                            histoTemp [17] = histoTemp [17]+arrayGravityCenterExport [counter2*6+2];
                            
                            if (refStatusHold1 == 4 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [36]++;
                        }
                        else if (colorHoldArea8 != 0 && colorHoldArea9 != 0 && arrayGravityCenterExport [counter2*6+2] > colorHoldArea8 && arrayGravityCenterExport [counter2*6+2] <= colorHoldArea9){
                            histoTemp [16]++;
                            histoTemp [17] = histoTemp [17]+arrayGravityCenterExport [counter2*6+2];
                            
                            if (refStatusHold1 == 4 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [36]++;
                        }
                        else if (colorHoldArea9 != 0 && arrayGravityCenterExport [counter2*6+2] > colorHoldArea9){
                            histoTemp [18]++;
                            histoTemp [19] = histoTemp [19]+arrayGravityCenterExport [counter2*6+2];
                            
                            if (refStatusHold1 == 4 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [38]++;
                        }
                        
                        break;
                    }
                }
            }
        }
        
        if ((refStatusHold1 == 1 || refStatusHold1 == 2 || refStatusHold1 == 5 || refStatusHold1 == 6) && calDataHoldRefSet == 1){
            for (int counter1 = 0; counter1 < timeSelectedExportCount/10; counter1++){
                if (arrayTimeSelectedExport [counter1*10] == 1){
                    if (colorHoldArea1 != 0 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] <= colorHoldArea1){
                        histoTempRef [0]++;
                        histoTempRef [1] = histoTempRef [1]+calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2];
                        
                        if ((refStatusHold1 == 5 || refStatusHold1 == 6) && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [20]++;
                    }
                    else if (colorHoldArea1 != 0 && colorHoldArea2 == 0 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea1){
                        histoTempRef [2]++;
                        histoTempRef [3] = histoTempRef [3]+calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2];
                        
                        if ((refStatusHold1 == 5 || refStatusHold1 == 6) && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [22]++;
                    }
                    else if (colorHoldArea1 != 0 && colorHoldArea2 != 0 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea1 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] <= colorHoldArea2){
                        histoTempRef [2]++;
                        histoTempRef [3] = histoTempRef [3]+calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2];
                        
                        if ((refStatusHold1 == 5 || refStatusHold1 == 6) && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [22]++;
                    }
                    else if (colorHoldArea2 != 0 && colorHoldArea3 == 0 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea2){
                        histoTempRef [4]++;
                        histoTempRef [5] = histoTempRef [5]+calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2];
                        
                        if ((refStatusHold1 == 5 || refStatusHold1 == 6) && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [24]++;
                    }
                    else if (colorHoldArea2 != 0 && colorHoldArea3 != 0 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea2 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] <= colorHoldArea3){
                        histoTempRef [4]++;
                        histoTempRef [5] = histoTempRef [5]+calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2];
                        
                        if ((refStatusHold1 == 5 || refStatusHold1 == 6) && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [24]++;
                    }
                    else if (colorHoldArea3 != 0 && colorHoldArea4 == 0 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea3){
                        histoTempRef [6]++;
                        histoTempRef [7] = histoTempRef [7]+calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2];
                        
                        if ((refStatusHold1 == 5 || refStatusHold1 == 6) && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [26]++;
                    }
                    else if (colorHoldArea3 != 0 && colorHoldArea4 != 0 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea3 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] <= colorHoldArea4){
                        histoTempRef [6]++;
                        histoTempRef [7] = histoTempRef [7]+calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2];
                        
                        if ((refStatusHold1 == 5 || refStatusHold1 == 6) && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [26]++;
                    }
                    else if (colorHoldArea4 != 0 && colorHoldArea5 == 0 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea4){
                        histoTempRef [8]++;
                        histoTempRef [9] = histoTempRef [9]+calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2];
                        
                        if ((refStatusHold1 == 5 || refStatusHold1 == 6) && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [28]++;
                    }
                    else if (colorHoldArea4 != 0 && colorHoldArea5 != 0 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea4 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] <= colorHoldArea5){
                        histoTempRef [8]++;
                        histoTempRef [9] = histoTempRef [9]+calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2];
                        
                        if ((refStatusHold1 == 5 || refStatusHold1 == 6) && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [28]++;
                    }
                    else if (colorHoldArea5 != 0 && colorHoldArea6 == 0 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea5){
                        histoTempRef [10]++;
                        histoTempRef [11] = histoTempRef [11]+calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2];
                        
                        if ((refStatusHold1 == 5 || refStatusHold1 == 6) && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [30]++;
                    }
                    else if (colorHoldArea5 != 0 && colorHoldArea6 != 0 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea5 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] <= colorHoldArea6){
                        histoTempRef [10]++;
                        histoTempRef [11] = histoTempRef [11]+calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2];
                        
                        if ((refStatusHold1 == 5 || refStatusHold1 == 6) && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [30]++;
                    }
                    else if (colorHoldArea6 != 0 && colorHoldArea7 == 0 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea6){
                        histoTempRef [12]++;
                        histoTempRef [13] = histoTempRef [13]+calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2];
                        
                        if ((refStatusHold1 == 5 || refStatusHold1 == 6) && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [32]++;
                    }
                    else if (colorHoldArea6 != 0 && colorHoldArea7 != 0 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea6 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] <= colorHoldArea7){
                        histoTempRef [12]++;
                        histoTempRef [13] = histoTempRef [13]+calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2];
                        
                        if ((refStatusHold1 == 5 || refStatusHold1 == 6) && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [32]++;
                    }
                    else if (colorHoldArea7 != 0 && colorHoldArea8 == 0 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea7 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] <= colorHoldArea8){
                        histoTempRef [14]++;
                        histoTempRef [15] = histoTempRef [15]+calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2];
                        
                        if ((refStatusHold1 == 5 || refStatusHold1 == 6) && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [34]++;
                    }
                    else if (colorHoldArea7 != 0 && colorHoldArea8 != 0 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea7 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] <= colorHoldArea8){
                        histoTempRef [14]++;
                        histoTempRef [15] = histoTempRef [15]+calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2];
                        
                        if ((refStatusHold1 == 5 || refStatusHold1 == 6) && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [34]++;
                    }
                    else if (colorHoldArea8 != 0 && colorHoldArea9 == 0 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea8){
                        histoTempRef [16]++;
                        histoTempRef [17] = histoTempRef [17]+calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2];
                        
                        if ((refStatusHold1 == 5 || refStatusHold1 == 6) && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [36]++;
                    }
                    else if (colorHoldArea8 != 0 && colorHoldArea9 != 0 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea8 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] <= colorHoldArea9){
                        histoTempRef [16]++;
                        histoTempRef [17] = histoTempRef [17]+calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2];
                        
                        if ((refStatusHold1 == 5 || refStatusHold1 == 6) && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [36]++;
                    }
                    else if (colorHoldArea9 != 0 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea9){
                        histoTempRef [18]++;
                        histoTempRef [19] = histoTempRef [19]+calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2];
                        
                        if ((refStatusHold1 == 5 || refStatusHold1 == 6) && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [38]++;
                    }
                }
            }
        }
        else if ((refStatusHold1 == 3 || refStatusHold1 == 7) && calDataHoldRefSet == 1){
            for (int counter1 = 0; counter1 < timeSelectedExportCount/10; counter1++){
                if (arrayTimeSelectedExport [counter1*10] == 1){
                    if (colorHoldArea1 != 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] <= colorHoldArea1){
                        histoTempRef [0]++;
                        
                        if (refStatusHold1 == 7 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [20]++;
                    }
                    else if (colorHoldArea1 != 0 && colorHoldArea2 == 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea1){
                        histoTempRef [2]++;
                        
                        if (refStatusHold1 == 7 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [22]++;
                    }
                    else if (colorHoldArea1 != 0 && colorHoldArea2 != 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea1 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] <= colorHoldArea2){
                        histoTempRef [2]++;
                        
                        if (refStatusHold1 == 7 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [22]++;
                    }
                    else if (colorHoldArea2 != 0 && colorHoldArea3 == 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea2){
                        histoTempRef [4]++;
                        
                        if (refStatusHold1 == 7 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [24]++;
                    }
                    else if (colorHoldArea2 != 0 && colorHoldArea3 != 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea2 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] <= colorHoldArea3){
                        histoTempRef [4]++;
                        
                        if (refStatusHold1 == 7 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [24]++;
                    }
                    else if (colorHoldArea3 != 0 && colorHoldArea4 == 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea3){
                        histoTempRef [6]++;
                        
                        if (refStatusHold1 == 7 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [26]++;
                    }
                    else if (colorHoldArea3 != 0 && colorHoldArea4 != 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea3 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] <= colorHoldArea4){
                        histoTempRef [6]++;
                        
                        if (refStatusHold1 == 7 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [26]++;
                    }
                    else if (colorHoldArea4 != 0 && colorHoldArea5 == 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea4){
                        histoTempRef [8]++;
                        
                        if (refStatusHold1 == 7 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [28]++;
                    }
                    else if (colorHoldArea4 != 0 && colorHoldArea5 != 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea4 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] <= colorHoldArea5){
                        histoTempRef [8]++;
                        
                        if (refStatusHold1 == 7 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [28]++;
                    }
                    else if (colorHoldArea5 != 0 && colorHoldArea6 == 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea5){
                        histoTempRef [10]++;
                        
                        if (refStatusHold1 == 7 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [30]++;
                    }
                    else if (colorHoldArea5 != 0 && colorHoldArea6 != 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea5 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] <= colorHoldArea6){
                        histoTempRef [10]++;
                        
                        if (refStatusHold1 == 7 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [30]++;
                    }
                    else if (colorHoldArea6 != 0 && colorHoldArea7 == 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea6){
                        histoTempRef [12]++;
                        
                        if (refStatusHold1 == 7 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [32]++;
                    }
                    else if (colorHoldArea6 != 0 && colorHoldArea7 != 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea6 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] <= colorHoldArea7){
                        histoTempRef [12]++;
                        
                        if (refStatusHold1 == 7 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [32]++;
                    }
                    else if (colorHoldArea7 != 0 && colorHoldArea8 == 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea7 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] <= colorHoldArea8){
                        histoTempRef [14]++;
                        
                        if (refStatusHold1 == 7 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [34]++;
                    }
                    else if (colorHoldArea7 != 0 && colorHoldArea8 != 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea7 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] <= colorHoldArea8){
                        histoTempRef [14]++;
                        
                        if (refStatusHold1 == 7 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [34]++;
                    }
                    else if (colorHoldArea8 != 0 && colorHoldArea9 == 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea8){
                        histoTempRef [16]++;
                        
                        if (refStatusHold1 == 7 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [36]++;
                    }
                    else if (colorHoldArea8 != 0 && colorHoldArea9 != 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea8 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] <= colorHoldArea9){
                        histoTempRef [16]++;
                        
                        if (refStatusHold1 == 7 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [36]++;
                    }
                    else if (colorHoldArea9 != 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2] > colorHoldArea9){
                        histoTempRef [18]++;
                        
                        if (refStatusHold1 == 7 && calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]*2+1] != 0) histoTemp [38]++;
                    }
                    
                    if (colorHoldArea1 != 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] <= colorHoldArea1){
                        histoTempRef [1]++;
                    }
                    else if (colorHoldArea1 != 0 && colorHoldArea2 == 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] > colorHoldArea1){
                        histoTempRef [3]++;
                    }
                    else if (colorHoldArea1 != 0 && colorHoldArea2 != 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] > colorHoldArea1 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] <= colorHoldArea2){
                        histoTempRef [3]++;
                    }
                    else if (colorHoldArea2 != 0 && colorHoldArea3 == 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] > colorHoldArea2){
                        histoTempRef [5]++;
                    }
                    else if (colorHoldArea2 != 0 && colorHoldArea3 != 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] > colorHoldArea2 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] <= colorHoldArea3){
                        histoTempRef [5]++;
                    }
                    else if (colorHoldArea3 != 0 && colorHoldArea4 == 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] > colorHoldArea3){
                        histoTempRef [7]++;
                    }
                    else if (colorHoldArea3 != 0 && colorHoldArea4 != 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] > colorHoldArea3 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] <= colorHoldArea4){
                        histoTempRef [7]++;
                    }
                    else if (colorHoldArea4 != 0 && colorHoldArea5 == 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] > colorHoldArea4){
                        histoTempRef [9]++;
                    }
                    else if (colorHoldArea4 != 0 && colorHoldArea5 != 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] > colorHoldArea4 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] <= colorHoldArea5){
                        histoTempRef [9]++;
                    }
                    else if (colorHoldArea5 != 0 && colorHoldArea6 == 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] > colorHoldArea5){
                        histoTempRef [11]++;
                    }
                    else if (colorHoldArea5 != 0 && colorHoldArea6 != 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] > colorHoldArea5 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] <= colorHoldArea6){
                        histoTempRef [11]++;
                    }
                    else if (colorHoldArea6 != 0 && colorHoldArea7 == 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] > colorHoldArea6){
                        histoTempRef [13]++;
                    }
                    else if (colorHoldArea6 != 0 && colorHoldArea7 != 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] > colorHoldArea6 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] <= colorHoldArea7){
                        histoTempRef [13]++;
                    }
                    else if (colorHoldArea7 != 0 && colorHoldArea8 == 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] > colorHoldArea7 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] <= colorHoldArea8){
                        histoTempRef [15]++;
                    }
                    else if (colorHoldArea7 != 0 && colorHoldArea8 != 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] > colorHoldArea7 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] <= colorHoldArea8){
                        histoTempRef [15]++;
                    }
                    else if (colorHoldArea8 != 0 && colorHoldArea9 == 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] > colorHoldArea8){
                        histoTempRef [17]++;
                    }
                    else if (colorHoldArea8 != 0 && colorHoldArea9 != 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] > colorHoldArea8 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] <= colorHoldArea9){
                        histoTempRef [17]++;
                    }
                    else if (colorHoldArea9 != 0 && calDataHoldRefDouble [arrayTimeSelectedExport [counter1*10+8]*2+1] > colorHoldArea9){
                        histoTempRef [19]++;
                    }
                }
            }
        }
        
        if ((refStatusHold1 == 4 || refStatusHold1 == 5 || refStatusHold1 == 6 || refStatusHold1 == 7) && calDataHoldRefSet == 1){
            for (int counter1 = 0; counter1 < timeSelectedExportCount/10; counter1++){
                if (arrayTimeSelectedExport [counter1*10] == 1){
                    if (calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]] == 0) histoTempRef2 [0]++;
                    else if (calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]] == 1) histoTempRef2 [1]++;
                    else if (calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]] == 2) histoTempRef2 [2]++;
                    else if (calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]] == 3) histoTempRef2 [3]++;
                    else if (calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]] == 4) histoTempRef2 [4]++;
                    else if (calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]] == 5) histoTempRef2 [5]++;
                    else if (calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]] == 6) histoTempRef2 [6]++;
                    else if (calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]] == 7) histoTempRef2 [7]++;
                    else if (calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]] == 8) histoTempRef2 [8]++;
                    else if (calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]] == 9) histoTempRef2 [9]++;
                    else if (calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]] == 10) histoTempRef2 [10]++;
                    else if (calDataHoldRef [arrayTimeSelectedExport [counter1*10+8]] > 10) histoTempRef2 [11]++;
                }
            }
        }
        
        oin.put(13);
        oin.put(10);
        
        if (refStatusHold1 == 0 || ((refStatusHold1 == 1 || refStatusHold1 == 2 || refStatusHold1 == 3) && calDataHoldRefSet == 1)){
            ascIIstring = "Range";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = "Number";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = "Total area";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            if (refStatusHold1 == 1 && uploadTempExpLoadRef2 == 1){
                ascIIstring = "Number-Subtract";
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = "Total area-Subtract";
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
            }
            else if (refStatusHold1 == 2 && uploadTempExpLoadRef3 == 1){
                ascIIstring = "Number-Subtract";
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = "Total area-Subtract";
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
            }
            else if (refStatusHold1 == 3){
                ascIIstring = "Min Feret";
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = "Max Feret";
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
            }
            
            oin.put(13);
            oin.put(10);
            
            for (int counter2 = 0; counter2 < 10; counter2++){
                ascIIstring = to_string(counter2+1);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(histoTemp [counter2*2]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(histoTemp [counter2*2+1]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                if (refStatusHold1 == 1 && uploadTempExpLoadRef2 == 1){
                    ascIIstring = to_string(histoTempRef [counter2*2]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(histoTempRef [counter2*2+1]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                }
                else if (refStatusHold1 == 2 && uploadTempExpLoadRef3 == 1){
                    ascIIstring = to_string(histoTempRef [counter2*2]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(histoTempRef [counter2*2+1]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                }
                else if (refStatusHold1 == 3){
                    ascIIstring = to_string(histoTempRef [counter2*2]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(histoTempRef [counter2*2+1]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                }
                
                oin.put(13);
                oin.put(10);
            }
        }
        else if (refStatusHold1 == 4){
            ascIIstring = "Nuclei/Fibre";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = "Number-Fibres";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
            
            for (int counter2 = 0; counter2 <= 12; counter2++){
                ascIIstring = to_string(counter2);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(histoTempRef2 [counter2]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                oin.put(13);
                oin.put(10);
            }
            
            oin.put(13);
            oin.put(10);
            
            ascIIstring = "Range";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = "Number";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = "Total area";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = "Number-Fibre-With-Nuclei";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
            
            for (int counter2 = 0; counter2 < 10; counter2++){
                ascIIstring = to_string(counter2+1);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(histoTemp [counter2*2]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(histoTemp [counter2*2+1]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(histoTemp [counter2*2+20]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                oin.put(13);
                oin.put(10);
            }
        }
        else if ((refStatusHold1 == 5 || refStatusHold1 == 6) && calDataHoldRefSet == 1){
            ascIIstring = "Nuclei/Fibre";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = "Number-Fibres";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
            
            for (int counter2 = 0; counter2 <= 12; counter2++){
                ascIIstring = to_string(counter2);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(histoTempRef2 [counter2]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                oin.put(13);
                oin.put(10);
            }
            
            oin.put(13);
            oin.put(10);
            
            ascIIstring = "Range";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = "Number";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = "Total area";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = "Number-Subtract";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = "Total area-Subtract";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = "Number-Fibre-With-Nuclei";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
            
            for (int counter2 = 0; counter2 < 10; counter2++){
                ascIIstring = to_string(counter2+1);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(histoTemp [counter2*2]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(histoTemp [counter2*2+1]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                if (refStatusHold1 == 5 && uploadTempExpLoadRef2 == 1){
                    ascIIstring = to_string(histoTempRef [counter2*2]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(histoTempRef [counter2*2+1]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(histoTemp [counter2*2+20]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                }
                else if (refStatusHold1 == 6 && uploadTempExpLoadRef3 == 1){
                    ascIIstring = to_string(histoTempRef [counter2*2]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(histoTempRef [counter2*2+1]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(histoTemp [counter2*2+20]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                }
                
                oin.put(13);
                oin.put(10);
            }
        }
        else if (refStatusHold1 == 7 && calDataHoldRefSet == 1){
            ascIIstring = "Nuclei/Fibre";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = "Number-Fibres";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
            
            for (int counter2 = 0; counter2 <= 12; counter2++){
                ascIIstring = to_string(counter2);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(histoTempRef2 [counter2]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                oin.put(13);
                oin.put(10);
            }
            
            oin.put(13);
            oin.put(10);
            
            ascIIstring = "Range";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = "Number";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = "Total area";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = "Min Feret";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = "Number-Fibre-With-Nuclei";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
            
            for (int counter2 = 0; counter2 < 10; counter2++){
                ascIIstring = to_string(counter2+1);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(histoTemp [counter2*2]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(histoTemp [counter2*2+1]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(histoTempRef [counter2*2]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(histoTemp [counter2*2+20]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                oin.put(13);
                oin.put(10);
            }
        }
        
        delete [] histoTemp;
        delete [] histoTempRef;
        delete [] histoTempRef2;
        delete [] calDataHoldRef;
        delete [] calDataHoldRefDouble;
        
        oin.close();
        
        delete [] arrayAscIIintData;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Data Missing or Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)fontCrossSet:(id)sender{
    if (fontCrossExport == 0){
        fontCrossExport = 1;
        [fontCrossDisplay setStringValue:@"Off"];
    }
    else if (fontCrossExport == 1){
        fontCrossExport = 0;
        [fontCrossDisplay setStringValue:@"On"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)linePrintColorSet:(id)sender{
    if (printLineColor == 0){
        printLineColor = 1;
        [linePrintColorDisplay setStringValue:@"WH"];
    }
    else if (printLineColor == 1){
        printLineColor = 2;
        [linePrintColorDisplay setStringValue:@"YL"];
    }
    else if (printLineColor == 2){
        printLineColor = 3;
        [linePrintColorDisplay setStringValue:@"BU"];
    }
    else if (printLineColor == 3){
        printLineColor = 4;
        [linePrintColorDisplay setStringValue:@"BL"];
    }
    else if (printLineColor == 4){
        printLineColor = 0;
        [linePrintColorDisplay setStringValue:@"GR"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)refImageProcess1:(id)sender{
    /*
     uploadTempExpLoadRef2 = 0, uploadTempExpLoadRef3 = 0
     Min/Max Feret, No. of Objects, Min Feret-No. of Objects, None
     
     uploadTempExpLoadRef2 = 1, uploadTempExpLoadRef3 = 0
     Subtract Ref1, Min/Max Feret, No. of Objects, Subtract Ref1-No. of Objects, Min Feret-No. of Objects, None
     
     uploadTempExpLoadRef2 = 0, uploadTempExpLoadRef3 = 1
     Subtract Ref2, Min/Max Feret, No. of Objects, Subtract Ref2-No. of Objects, Min Feret-No. of Objects, None
     
     uploadTempExpLoadRef2 = 1, uploadTempExpLoadRef3 = 1
     Subtract Ref1, Subtract Ref2, Min/Max Feret, No. of Objects, Subtract Ref1-No. of Objects, Subtract Ref2-No. of Objects, Min Feret-No. of Objects, None
     */
    
    if (refStatusHold1 == 0){
        if (uploadTempExpLoadRef2 == 1){
            refStatusHold1 = 1;
            [refStatusDisplay1 setStringValue:@"Subtract Ref1"];
        }
        else if (uploadTempExpLoadRef3 == 1){
            refStatusHold1 = 2;
            [refStatusDisplay1 setStringValue:@"Subtract Ref2"];
        }
        else{
            
            refStatusHold1 = 3;
            [refStatusDisplay1 setStringValue:@"Min/Max Feret"];
        }
    }
    else if (refStatusHold1 == 1){
        if (uploadTempExpLoadRef3 == 1){
            refStatusHold1 = 2;
            [refStatusDisplay1 setStringValue:@"Subtract Ref2"];
        }
        else{
            
            refStatusHold1 = 3;
            [refStatusDisplay1 setStringValue:@"Min/Max Feret"];
        }
    }
    else if (refStatusHold1 == 2){
        refStatusHold1 = 3;
        [refStatusDisplay1 setStringValue:@"Min/Max Feret"];
    }
    else if (refStatusHold1 == 3){
        refStatusHold1 = 4;
        [refStatusDisplay1 setStringValue:@"No. of Objects"];
    }
    else if (refStatusHold1 == 4){
        if (uploadTempExpLoadRef2 == 1){
            refStatusHold1 = 5;
            [refStatusDisplay1 setStringValue:@"Subtract Ref1-No. of Objects"];
        }
        else if (uploadTempExpLoadRef3 == 1){
            refStatusHold1 = 6;
            [refStatusDisplay1 setStringValue:@"Subtract Ref2-No. of Objects"];
        }
        else{
            
            refStatusHold1 = 7;
            [refStatusDisplay1 setStringValue:@"Min Feret-No. of Objects"];
        }
    }
    else if (refStatusHold1 == 5){
        if (uploadTempExpLoadRef3 == 1){
            refStatusHold1 = 6;
            [refStatusDisplay1 setStringValue:@"Subtract Ref2-No. of Objects"];
        }
        else{
            
            refStatusHold1 = 7;
            [refStatusDisplay1 setStringValue:@"Min Feret-No. of Objects"];
        }
    }
    else if (refStatusHold1 == 6){
        refStatusHold1 = 7;
        [refStatusDisplay1 setStringValue:@"Min Feret-No. of Objects"];
    }
    else if (refStatusHold1 == 7){
        refStatusHold1 = 0;
        [refStatusDisplay1 setStringValue:@"None"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorDefaultSet:(id)sender{
    if (colorSetStatusHold == 1){
        arrayColorRange = new CGFloat [100];
        arrayColorRange [0] = 0/(double)255, arrayColorRange [1] = 0/(double)255, arrayColorRange [2] = 0/(double)255; //Black
        arrayColorRange [3] = 0/(double)255, arrayColorRange [4] = 0/(double)255, arrayColorRange [5] = 255/(double)255; //Blue
        arrayColorRange [6] = 153/(double)255, arrayColorRange [7] = 102/(double)255, arrayColorRange [8] = 51/(double)255; //Brown
        arrayColorRange [9] = 0/(double)255, arrayColorRange [10] = 255/(double)255, arrayColorRange [11] = 255/(double)255; //Cyan
        arrayColorRange [12] = 0/(double)255, arrayColorRange [13] = 255/(double)255, arrayColorRange [14] = 0/(double)255; //Green
        arrayColorRange [15] = 255/(double)255, arrayColorRange [16] = 0/(double)255, arrayColorRange [17] = 255/(double)255; //Magenta
        arrayColorRange [18] = 255/(double)255, arrayColorRange [19] = 153/(double)255, arrayColorRange [20] = 0/(double)255;//Orange
        arrayColorRange [21] = 170/(double)255, arrayColorRange [22] = 0/(double)255, arrayColorRange [23] = 170/(double)255; //Purple
        arrayColorRange [24] = 255/(double)255, arrayColorRange [25] = 0/(double)255, arrayColorRange [26] = 0/(double)255; //Red
        arrayColorRange [27] = 255/(double)255, arrayColorRange [28] = 255/(double)255, arrayColorRange [29] = 0/(double)255; //Yellow
        arrayColorRange [30] = 0/(double)255, arrayColorRange [31] = 0/(double)255, arrayColorRange [32] = 0/(double)255;
        arrayColorRange [33] = 34/(double)255, arrayColorRange [34] = 78/(double)255, arrayColorRange [35] = 29/(double)255;
        arrayColorRange [36] = 149/(double)255, arrayColorRange [37] = 32/(double)255, arrayColorRange [38] = 67/(double)255;
        
        [[colorButton1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [3] green:arrayColorRange [4] blue:arrayColorRange [5] alpha:1]];
        [[colorButton2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [6] green:arrayColorRange [7] blue:arrayColorRange [8] alpha:1]];
        [[colorButton3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [9] green:arrayColorRange [10] blue:arrayColorRange [11] alpha:1]];
        [[colorButton4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [12] green:arrayColorRange [13] blue:arrayColorRange [14] alpha:1]];
        [[colorButton5 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [15] green:arrayColorRange [16] blue:arrayColorRange [17] alpha:1]];
        [[colorButton6 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [18] green:arrayColorRange [19] blue:arrayColorRange [20] alpha:1]];
        [[colorButton7 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [21] green:arrayColorRange [22] blue:arrayColorRange [23] alpha:1]];
        [[colorButton8 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [24] green:arrayColorRange [25] blue:arrayColorRange [26] alpha:1]];
        [[colorButton9 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [27] green:arrayColorRange [28] blue:arrayColorRange [29] alpha:1]];
        [[colorButton10 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [30] green:arrayColorRange [31] blue:arrayColorRange [32] alpha:1]];
        [[colorButton11 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [33] green:arrayColorRange [34] blue:arrayColorRange [35] alpha:1]];
        [[colorButton12 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [36] green:arrayColorRange [37] blue:arrayColorRange [38] alpha:1]];
        
        [self colorDataSave];
        
        string colorListPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ColorListData";
        
        ofstream oin;
        oin.open(colorListPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 <= 38; counter1++){
            oin<<arrayColorRange [counter1]<<endl;
        }
        
        oin.close();
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Color Set Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dotStyleSet:(id)sender{
    if (dotStyleExport == 0){
        dotStyleExport = 1;
        [dotStyleDisplay setStringValue:@"Stroke"];
    }
    else if (dotStyleExport == 1){
        dotStyleExport = 0;
        [dotStyleDisplay setStringValue:@"Fill"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)dotLengthSet:(id)sender{
    if (dotLengthExport == 1){
        dotLengthExport = 2;
        [dotLengthDisplay setStringValue:@"1/2"];
    }
    else if (dotLengthExport == 2){
        dotLengthExport = 3;
        [dotLengthDisplay setStringValue:@"1/4"];
    }
    else if (dotLengthExport == 3){
        dotLengthExport = 4;
        [dotLengthDisplay setStringValue:@"0"];
    }
    else if (dotLengthExport == 4){
        dotLengthExport = 1;
        [dotLengthDisplay setStringValue:@"1"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)dotDisplaySetSet:(id)sender{
    if (dotDisplayMode == 0){
        dotDisplayMode = 1;
        [dotStatusDisplay setStringValue:@"Range"];
    }
    else if (dotDisplayMode == 1){
        dotDisplayMode = 2;
        [dotStatusDisplay setStringValue:@"Range+Dens"];
    }
    else if (dotDisplayMode == 2){
        dotDisplayMode = 0;
        dotDisplayTimeMin = 0;
        dotDisplayTimeMax = 0;
        [dotStatusDisplay setStringValue:@"One Time"];
        [dotMinDisplay setStringValue:@""];
        [dotMaxDisplay setStringValue:@""];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorDataFileLoad:(id)sender{
    if (colorSetStatusHold == 1){
        NSOpenPanel *openDlg = [NSOpenPanel openPanel];
        [openDlg setCanChooseFiles:YES];
        [openDlg setCanChooseDirectories:NO];
        
        if ([openDlg runModal] == NSModalResponseOK){
            NSArray *files = [openDlg URLs];
            NSString *fileName = [[files objectAtIndex:0] absoluteString];
            
            string directoryPathImport = [fileName UTF8String];
            
            int findString1 = (int)directoryPathImport.find("/Users/");
            if (findString1 == -1) findString1 = (int)directoryPathImport.find("/Volumes/");
            
            unsigned long directoryLength = directoryPathImport.length();
            directoryPathImport = directoryPathImport.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1);
            string extractedID;
            string extractedID2;
            
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                
                findString1 = (int)directoryPathImport.find("%20");
                if (findString1 != -1){
                    extractedID2 = directoryPathImport.substr(0, (unsigned long)findString1);
                    directoryPathImport = directoryPathImport.substr((unsigned long)findString1+3);
                    directoryPathImport = extractedID2+" "+directoryPathImport;
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            extractedID = directoryPathImport;
            string stringExtract;
            
            do{
                
                terminationFlag = 1;
                findString1 = (int)extractedID.find("/");
                
                if (findString1 != -1){
                    stringExtract = extractedID.substr(0, (unsigned long)findString1);
                    extractedID = extractedID.substr((unsigned long)findString1+1);
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            if ((int)extractedID.find("ColorListData") != -1){
                string getString;
                
                ifstream fin;
                
                fin.open(directoryPathImport.c_str(),ios::in);
                
                if (fin.is_open()){
                    for (int counter1 = 0; counter1 <= 38; counter1++){
                        getline(fin, getString), arrayColorRange [counter1] = atof(getString.c_str());
                    }
                    
                    fin.close();
                    
                    [[colorButton1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [3] green:arrayColorRange [4] blue:arrayColorRange [5] alpha:1]];
                    [[colorButton2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [6] green:arrayColorRange [7] blue:arrayColorRange [8] alpha:1]];
                    [[colorButton3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [9] green:arrayColorRange [10] blue:arrayColorRange [11] alpha:1]];
                    [[colorButton4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [12] green:arrayColorRange [13] blue:arrayColorRange [14] alpha:1]];
                    [[colorButton5 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [15] green:arrayColorRange [16] blue:arrayColorRange [17] alpha:1]];
                    [[colorButton6 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [18] green:arrayColorRange [19] blue:arrayColorRange [20] alpha:1]];
                    [[colorButton7 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [21] green:arrayColorRange [22] blue:arrayColorRange [23] alpha:1]];
                    [[colorButton8 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [24] green:arrayColorRange [25] blue:arrayColorRange [26] alpha:1]];
                    [[colorButton9 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [27] green:arrayColorRange [28] blue:arrayColorRange [29] alpha:1]];
                    [[colorButton10 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [30] green:arrayColorRange [31] blue:arrayColorRange [32] alpha:1]];
                    [[colorButton11 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [33] green:arrayColorRange [34] blue:arrayColorRange [35] alpha:1]];
                    [[colorButton12 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange [36] green:arrayColorRange [37] blue:arrayColorRange [38] alpha:1]];
                    
                    [self colorDataSave];
                    
                    string colorListPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ColorListData";
                    
                    ofstream oin;
                    oin.open(colorListPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 <= 38; counter1++){
                        oin<<arrayColorRange [counter1]<<endl;
                    }
                    
                    oin.close();
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Color List File Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Color Set Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)colorDataFileSave:(id)sender{
    if (colorSetStatusHold == 1){
        NSOpenPanel *openDlg = [NSOpenPanel openPanel];
        [openDlg setCanChooseFiles:NO];
        [openDlg setCanChooseDirectories:YES];
        
        if ([openDlg runModal] == NSModalResponseOK){
            NSArray *files = [openDlg URLs];
            NSString *fileName = [[files objectAtIndex:0] absoluteString];
            
            string directoryPathImport = [fileName UTF8String];
            
            int findString1 = (int)directoryPathImport.find("/Users/");
            if (findString1 == -1) findString1 = (int)directoryPathImport.find("/Volumes/");
            
            unsigned long directoryLength = directoryPathImport.length();
            directoryPathImport = directoryPathImport.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
            string extractedID;
            string extractedID2;
            
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                
                findString1 = (int)directoryPathImport.find("%20");
                if (findString1 != -1){
                    extractedID2 = directoryPathImport.substr(0, (unsigned long)findString1);
                    directoryPathImport = directoryPathImport.substr((unsigned long)findString1+3);
                    directoryPathImport = extractedID2+" "+directoryPathImport;
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            DIR *dir;
            struct dirent *dent;
            
            string entry;
            string extractString;
            int maxEntryNo = 0;
            
            dir = opendir(directoryPathImport.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("ColorListData") != -1){
                        extractString = entry.substr(entry.find("-")+1);
                        
                        if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                    }
                }
                
                closedir(dir);
            }
            
            maxEntryNo++;
            
            string resultSavePath2 = directoryPathImport+"/ColorListData-"+to_string(maxEntryNo);
            
            ofstream oin;
            oin.open(resultSavePath2.c_str(),ios::out);
            
            for (int counter1 = 0; counter1 <= 38; counter1++){
                oin<<arrayColorRange [counter1]<<endl;
            }
            
            oin.close();
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Color Set Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)areaAdjustSet:(id)sender{
    if (imageProgressFlag == 0){
        if (areaAdjustStatusHold == 0){
            if (phaseStatus == 1){
                int **revisedWorkingMapExpTemp = new int *[imageXYLength+1];
                
                for (int counter1 = 0; counter1 < imageXYLength+1; counter1++){
                    revisedWorkingMapExpTemp [counter1] = new int [imageXYLength+1];
                }
                
                for (int counter1 = 0; counter1 < imageXYLength; counter1++){
                    for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                        revisedWorkingMapExpTemp [counter1][counter2] = revisedWorkingMapExp [counter1][counter2];
                    }
                }
                
                int *calDataHoldRef = new int [(timeSelectedExportCount/10)*4+100];
                
                for (int counter1 = 0; counter1 < (timeSelectedExportCount/10)*4+100; counter1++){
                    calDataHoldRef [counter1] = 0;
                }
                
                //----------Subtraction----------
                if (uploadTempExpLoadRef2 == 1){
                    unsigned long headPosition = 0;
                    int endianType = 0;
                    int dataConversion [4];
                    
                    dataConversion [0] = uploadTempExpRef2 [0];
                    dataConversion [1] = uploadTempExpRef2 [1];
                    
                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                    else endianType = 0;
                    
                    headPosition = 0;
                    
                    if (endianType == 1){
                        dataConversion [0] = uploadTempExpRef2 [7];
                        dataConversion [1] = uploadTempExpRef2 [6];
                        dataConversion [2] = uploadTempExpRef2 [5];
                        dataConversion [3] = uploadTempExpRef2 [4];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    else if (endianType == 0){
                        dataConversion [0] = uploadTempExpRef2 [4];
                        dataConversion [1] = uploadTempExpRef2 [5];
                        dataConversion [2] = uploadTempExpRef2 [6];
                        dataConversion [3] = uploadTempExpRef2 [7];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    
                    int grayColorStatusColor = 0;
                    
                    if (headPosition-8 == (unsigned long)(imageXYLength*imageXYLength)) grayColorStatusColor = 0;
                    else grayColorStatusColor = 1;
                    
                    int **arrayExtractedImage = new int *[imageXYLength+1];
                    
                    if (grayColorStatusColor == 0){
                        for (int counter3 = 0; counter3 < imageXYLength+1; counter3++){
                            arrayExtractedImage [counter3] = new int [imageXYLength+1];
                        }
                    }
                    else{
                        
                        for (int counter3 = 0; counter3 < imageXYLength+1; counter3++){
                            arrayExtractedImage [counter3] = new int [imageXYLength*3+1];
                        }
                    }
                    
                    int horizontalEntry = 0;
                    int verticalEntry = 0;
                    
                    if (grayColorStatusColor == 0){
                        int value0 = 0;
                        
                        for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                            value0 = uploadTempExpRef2 [counter1];
                            
                            arrayExtractedImage [verticalEntry][horizontalEntry] = value0, horizontalEntry++;
                            
                            if (horizontalEntry == imageXYLength){
                                horizontalEntry = 0;
                                verticalEntry++;
                            }
                        }
                    }
                    else if (grayColorStatusColor == 1){
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        
                        for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                            value0 = uploadTempExpRef2 [counter1];
                            value1 = uploadTempExpRef2 [counter1+1];
                            value2 = uploadTempExpRef2 [counter1+2];
                            
                            arrayExtractedImage [verticalEntry][horizontalEntry] = value0, horizontalEntry++;
                            arrayExtractedImage [verticalEntry][horizontalEntry] = value1, horizontalEntry++;
                            arrayExtractedImage [verticalEntry][horizontalEntry] = value2, horizontalEntry++;
                            
                            if (horizontalEntry == imageXYLength*3){
                                horizontalEntry = 0;
                                verticalEntry++;
                            }
                        }
                    }
                    
                    if (grayColorStatusColor == 0){
                        for (int counter1 = 0; counter1 < imageXYLength; counter1++){
                            for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                                if (arrayExtractedImage [counter1][counter2] != 0) revisedWorkingMapExpTemp [counter1][counter2] = 0;
                            }
                        }
                    }
                    else{
                        
                        for (int counter1 = 0; counter1 < imageXYLength; counter1++){
                            for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                                if (arrayExtractedImage [counter1][counter2*3] != 0) revisedWorkingMapExpTemp [counter1][counter2] = 0;
                                if (arrayExtractedImage [counter1][counter2*3+1] != 0) revisedWorkingMapExpTemp [counter1][counter2] = 0;
                                if (arrayExtractedImage [counter1][counter2*3+2] != 0) revisedWorkingMapExpTemp [counter1][counter2] = 0;
                            }
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < imageXYLength+1; counter3++){
                        delete [] arrayExtractedImage [counter3];
                    }
                    
                    delete [] arrayExtractedImage;
                    
                    for (int counter1 = 0; counter1 < imageXYLength; counter1++){
                        for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                            if (revisedWorkingMapExpTemp [counter1][counter2] != 0) calDataHoldRef [revisedWorkingMapExpTemp [counter1][counter2]*2]++;
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < timeSelectedExportCount/10; counter2++){
                        arrayGravityCenterExport [counter2*6+2] = calDataHoldRef [counter2*2];
                    }
                    
                    areaAdjustStatusHold = 1;
                    
                    [areaAdjustDisplay setStringValue:@"On"];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Ref1 Missing"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                
                for (int counter1 = 0; counter1 < imageXYLength+1; counter1++){
                    delete [] revisedWorkingMapExpTemp [counter1];
                }
                
                delete [] revisedWorkingMapExpTemp;
                
                delete [] calDataHoldRef;
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else if (areaAdjustStatusHold == 1){
            for (int counter2 = 0; counter2 < timeSelectedExportCount/10; counter2++){
                arrayGravityCenterExport [counter2*6+2] = arrayGravityCenterExportHold [counter2*6+2];
            }
            
            areaAdjustStatusHold = 0;
            
            [areaAdjustDisplay setStringValue:@"Off"];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Data Missing or Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)firstSecondSet:(id)sender{
    if (firstSecondSelectHold == 0){
        firstSecondSelectHold = 1;
        [firstSecondDisplay setStringValue:@"Second"];
    }
    else if (firstSecondSelectHold == 1){
        firstSecondSelectHold = 2;
        [firstSecondDisplay setStringValue:@"Third"];
    }
    else if (firstSecondSelectHold == 2){
        firstSecondSelectHold = 3;
        [firstSecondDisplay setStringValue:@"Fourth"];
    }
    else if (firstSecondSelectHold == 3){
        firstSecondSelectHold = 0;
        [firstSecondDisplay setStringValue:@"First"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)exportDensityData:(id)sender{
    if (dotDisplayMode == 2){
        string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
        mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Movie_Quant";
        mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        DIR *dir;
        struct dirent *dent;
        
        string entry;
        string extractString;
        int maxEntryNo = 0;
        
        dir = opendir(resultSavePath2.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Movie_Quant") != -1){
                    extractString = entry.substr(entry.find("MQ")+2, entry.find(".txt")-entry.find("MQ")-2);
                    
                    if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                }
            }
            
            closedir(dir);
        }
        
        maxEntryNo++;
        
        string path = resultSavePath2+"/Movie_Quant-MQ"+to_string(maxEntryNo)+".txt";
        
        int xImageStart = 0;
        int yImageStart = 0;
        int xImageSizeEX = imageXYLength;
        int yImageSizeEX = imageXYLength;
        int xPointMarkTemp = 0;
        int yPointMarkTemp = 0;
        
        int displayTimeRangeMin = dotDisplayTimeMin;
        int displayTimeRangeMax = 0;
        
        if (dotDisplayTimeMax > maxImageNo) displayTimeRangeMax = maxImageNo;
        else displayTimeRangeMax = dotDisplayTimeMax;
        
        if (displayTimeRangeMax < displayTimeRangeMin){
            displayTimeRangeMin = 0;
            displayTimeRangeMax = 0;
        }
        
        if (displayTimeRangeMin != 0 && displayTimeRangeMax != 0 && densityDiameterHold != 0 && densityValueMaxHold != 0){
            if (circleAreaHoldStatus == 1){
                for (int counter1 = 0; counter1 < densityDiameterPrev+2; counter1++) delete [] circleAreaHold [counter1];
                delete [] circleAreaHold;
            }
            
            densityDiameterPrev = densityDiameterHold;
            
            circleAreaHold = new int *[densityDiameterHold+2];
            
            for (int counter1 = 0; counter1 < densityDiameterHold+2; counter1++){
                circleAreaHold [counter1] = new int [densityDiameterHold+2];
            }
            
            circleAreaHoldStatus = 1;
            
            for (int counter1 = 0; counter1 < densityDiameterHold+2; counter1++){
                for (int counter2 = 0; counter2 <densityDiameterHold+2; counter2++){
                    circleAreaHold [counter1][counter2] = 0;
                }
            }
            
            int center2 = (densityDiameterHold/2)+1;
            double radius = densityDiameterHold/(double)2;
            double diameterCal = 0;
            
            for (int counter1 = 0; counter1 < densityDiameterHold+2; counter1++){
                for (int counter2 = 0; counter2 <densityDiameterHold+2; counter2++){
                    diameterCal = (counter1-center2)*(counter1-center2)+(counter2-center2)*(counter2-center2);
                    
                    if (sqrt(diameterCal) <= radius) circleAreaHold [counter1][counter2] = 1;
                }
            }
            
            int center = (densityDiameterHold/2)+1;
            int **densityMapHold = new int *[yImageSizeEX+1];
            
            for (int counter1 = 0; counter1 < yImageSizeEX+1; counter1++){
                densityMapHold [counter1] = new int [xImageSizeEX+1];
            }
            
            for (int counter1 = 0; counter1 < yImageSizeEX+1; counter1++){
                for (int counter2 = 0; counter2 < xImageSizeEX+1; counter2++){
                    densityMapHold [counter1][counter2] = 0;
                }
            }
            
            for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                if (firstSecondSelectHold == 0){
                    if (arrayDotDataHold [counter1*3] >= 0 && arrayDotDataHold [counter1*3] <= 100000 && arrayDotDataHold [counter1*3] >= displayTimeRangeMin && arrayDotDataHold [counter1*3] <= displayTimeRangeMax){
                        xPointMarkTemp = arrayDotDataHold [counter1*3+1]-xImageStart;
                        yPointMarkTemp = imageXYLength-(arrayDotDataHold [counter1*3+2]+yImageStart);
                        
                        for (int counter3 = 1; counter3 <= densityDiameterHold; counter3++){
                            for (int counter4 = 1; counter4 <= densityDiameterHold; counter4++){
                                if (xPointMarkTemp-center+counter4 >= 0 && xPointMarkTemp-center+counter4 < xImageSizeEX && yPointMarkTemp-center+counter3 >= 0 && yPointMarkTemp-center+counter3 < yImageSizeEX && circleAreaHold [counter3][counter4] == 1){
                                    densityMapHold [yPointMarkTemp-center+counter3][xPointMarkTemp-center+counter4]++;
                                }
                            }
                        }
                    }
                }
                else if (firstSecondSelectHold == 1){
                    if (arrayDotDataHold [counter1*3] < 0 && arrayDotDataHold [counter1*3] >= -100000 && arrayDotDataHold [counter1*3]*-1 >= displayTimeRangeMin && arrayDotDataHold [counter1*3]*-1 <= displayTimeRangeMax){
                        xPointMarkTemp = arrayDotDataHold [counter1*3+1]-xImageStart;
                        yPointMarkTemp = imageXYLength-(arrayDotDataHold [counter1*3+2]+yImageStart);
                        
                        for (int counter3 = 1; counter3 <= densityDiameterHold; counter3++){
                            for (int counter4 = 1; counter4 <= densityDiameterHold; counter4++){
                                if (xPointMarkTemp-center+counter4 >= 0 && xPointMarkTemp-center+counter4 < xImageSizeEX && yPointMarkTemp-center+counter3 >= 0 && yPointMarkTemp-center+counter3 < yImageSizeEX && circleAreaHold [counter3][counter4] == 1){
                                    densityMapHold [yPointMarkTemp-center+counter3][xPointMarkTemp-center+counter4]++;
                                }
                            }
                        }
                    }
                }
                else if (firstSecondSelectHold == 2){
                    if (arrayDotDataHold [counter1*3] > 100000 && arrayDotDataHold [counter1*3]-100000 >= displayTimeRangeMin && arrayDotDataHold [counter1*3]-100000 <= displayTimeRangeMax){
                        xPointMarkTemp = arrayDotDataHold [counter1*3+1]-xImageStart;
                        yPointMarkTemp = imageXYLength-(arrayDotDataHold [counter1*3+2]+yImageStart);
                        
                        for (int counter3 = 1; counter3 <= densityDiameterHold; counter3++){
                            for (int counter4 = 1; counter4 <= densityDiameterHold; counter4++){
                                if (xPointMarkTemp-center+counter4 >= 0 && xPointMarkTemp-center+counter4 < xImageSizeEX && yPointMarkTemp-center+counter3 >= 0 && yPointMarkTemp-center+counter3 < yImageSizeEX && circleAreaHold [counter3][counter4] == 1){
                                    densityMapHold [yPointMarkTemp-center+counter3][xPointMarkTemp-center+counter4]++;
                                }
                            }
                        }
                    }
                }
                else if (firstSecondSelectHold == 3){
                    if (arrayDotDataHold [counter1*3] < -100000 && arrayDotDataHold [counter1*3]*-1-100000 >= displayTimeRangeMin && arrayDotDataHold [counter1*3]*-1-100000 <= displayTimeRangeMax){
                        xPointMarkTemp = arrayDotDataHold [counter1*3+1]-xImageStart;
                        yPointMarkTemp = imageXYLength-(arrayDotDataHold [counter1*3+2]+yImageStart);
                        
                        for (int counter3 = 1; counter3 <= densityDiameterHold; counter3++){
                            for (int counter4 = 1; counter4 <= densityDiameterHold; counter4++){
                                if (xPointMarkTemp-center+counter4 >= 0 && xPointMarkTemp-center+counter4 < xImageSizeEX && yPointMarkTemp-center+counter3 >= 0 && yPointMarkTemp-center+counter3 < yImageSizeEX && circleAreaHold [counter3][counter4] == 1){
                                    densityMapHold [yPointMarkTemp-center+counter3][xPointMarkTemp-center+counter4]++;
                                }
                            }
                        }
                    }
                }
            }
            
            int *dotListExp = new int [dotDataHoldCount+dotDataHoldCount/3+10];
            int dotListCountExp = 0;
            
            int pointCount = 0;
            
            for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                if (firstSecondSelectHold == 0){
                    if (arrayDotDataHold [counter1*3] >= 0 && arrayDotDataHold [counter1*3] <= 100000 && arrayDotDataHold [counter1*3] >= displayTimeRangeMin && arrayDotDataHold [counter1*3] <= displayTimeRangeMax){
                        dotListExp [dotListCountExp] = arrayDotDataHold [counter1*3+1], dotListCountExp++;
                        dotListExp [dotListCountExp] = arrayDotDataHold [counter1*3+2], dotListCountExp++;
                        dotListExp [dotListCountExp] = 0, dotListCountExp++;
                        dotListExp [dotListCountExp] = 0, dotListCountExp++;
                        
                        xPointMarkTemp = arrayDotDataHold [counter1*3+1]-xImageStart;
                        yPointMarkTemp = imageXYLength-(arrayDotDataHold [counter1*3+2]+yImageStart);
                        
                        pointCount = 0;
                        
                        for (int counter3 = 1; counter3 <= densityDiameterHold; counter3++){
                            for (int counter4 = 1; counter4 <= densityDiameterHold; counter4++){
                                if (xPointMarkTemp-center+counter4 >= 0 && xPointMarkTemp-center+counter4 < xImageSizeEX && yPointMarkTemp-center+counter3 >= 0 && yPointMarkTemp-center+counter3 < yImageSizeEX && circleAreaHold [counter3][counter4] == 1){
                                    dotListExp [dotListCountExp-2] = dotListExp [dotListCountExp-2]+densityMapHold [yPointMarkTemp-center+counter3][xPointMarkTemp-center+counter4];
                                    pointCount++;
                                }
                            }
                        }
                        
                        dotListExp [dotListCountExp-1] = pointCount;
                    }
                }
                else if (firstSecondSelectHold == 1){
                    if (arrayDotDataHold [counter1*3] < 0 && arrayDotDataHold [counter1*3] >= -100000 && arrayDotDataHold [counter1*3]*-1 >= displayTimeRangeMin && arrayDotDataHold [counter1*3]*-1 <= displayTimeRangeMax){
                        dotListExp [dotListCountExp] = arrayDotDataHold [counter1*3+1], dotListCountExp++;
                        dotListExp [dotListCountExp] = arrayDotDataHold [counter1*3+2], dotListCountExp++;
                        dotListExp [dotListCountExp] = 0, dotListCountExp++;
                        dotListExp [dotListCountExp] = 0, dotListCountExp++;
                        
                        xPointMarkTemp = arrayDotDataHold [counter1*3+1]-xImageStart;
                        yPointMarkTemp = imageXYLength-(arrayDotDataHold [counter1*3+2]+yImageStart);
                        
                        pointCount = 0;
                        
                        for (int counter3 = 1; counter3 <= densityDiameterHold; counter3++){
                            for (int counter4 = 1; counter4 <= densityDiameterHold; counter4++){
                                if (xPointMarkTemp-center+counter4 >= 0 && xPointMarkTemp-center+counter4 < xImageSizeEX && yPointMarkTemp-center+counter3 >= 0 && yPointMarkTemp-center+counter3 < yImageSizeEX && circleAreaHold [counter3][counter4] == 1){
                                    dotListExp [dotListCountExp-2] = dotListExp [dotListCountExp-2]+densityMapHold [yPointMarkTemp-center+counter3][xPointMarkTemp-center+counter4];
                                    pointCount++;
                                }
                            }
                        }
                        
                        dotListExp [dotListCountExp-1] = pointCount;
                    }
                }
                else if (firstSecondSelectHold == 2){
                    if (arrayDotDataHold [counter1*3] > 100000 && arrayDotDataHold [counter1*3]-100000 >= displayTimeRangeMin && arrayDotDataHold [counter1*3]-100000 <= displayTimeRangeMax){
                        dotListExp [dotListCountExp] = arrayDotDataHold [counter1*3+1], dotListCountExp++;
                        dotListExp [dotListCountExp] = arrayDotDataHold [counter1*3+2], dotListCountExp++;
                        dotListExp [dotListCountExp] = 0, dotListCountExp++;
                        dotListExp [dotListCountExp] = 0, dotListCountExp++;
                        
                        xPointMarkTemp = arrayDotDataHold [counter1*3+1]-xImageStart;
                        yPointMarkTemp = imageXYLength-(arrayDotDataHold [counter1*3+2]+yImageStart);
                        
                        pointCount = 0;
                        
                        for (int counter3 = 1; counter3 <= densityDiameterHold; counter3++){
                            for (int counter4 = 1; counter4 <= densityDiameterHold; counter4++){
                                if (xPointMarkTemp-center+counter4 >= 0 && xPointMarkTemp-center+counter4 < xImageSizeEX && yPointMarkTemp-center+counter3 >= 0 && yPointMarkTemp-center+counter3 < yImageSizeEX && circleAreaHold [counter3][counter4] == 1){
                                    dotListExp [dotListCountExp-2] = dotListExp [dotListCountExp-2]+densityMapHold [yPointMarkTemp-center+counter3][xPointMarkTemp-center+counter4];
                                    pointCount++;
                                }
                            }
                        }
                        
                        dotListExp [dotListCountExp-1] = pointCount;
                    }
                }
                else if (firstSecondSelectHold == 3){
                    if (arrayDotDataHold [counter1*3] < -100000 && arrayDotDataHold [counter1*3]*-1-100000 >= displayTimeRangeMin && arrayDotDataHold [counter1*3]*-1-100000 <= displayTimeRangeMax){
                        dotListExp [dotListCountExp] = arrayDotDataHold [counter1*3+1], dotListCountExp++;
                        dotListExp [dotListCountExp] = arrayDotDataHold [counter1*3+2], dotListCountExp++;
                        dotListExp [dotListCountExp] = 0, dotListCountExp++;
                        dotListExp [dotListCountExp] = 0, dotListCountExp++;
                        
                        xPointMarkTemp = arrayDotDataHold [counter1*3+1]-xImageStart;
                        yPointMarkTemp = imageXYLength-(arrayDotDataHold [counter1*3+2]+yImageStart);
                        
                        pointCount = 0;
                        
                        for (int counter3 = 1; counter3 <= densityDiameterHold; counter3++){
                            for (int counter4 = 1; counter4 <= densityDiameterHold; counter4++){
                                if (xPointMarkTemp-center+counter4 >= 0 && xPointMarkTemp-center+counter4 < xImageSizeEX && yPointMarkTemp-center+counter3 >= 0 && yPointMarkTemp-center+counter3 < yImageSizeEX && circleAreaHold [counter3][counter4] == 1){
                                    dotListExp [dotListCountExp-2] = dotListExp [dotListCountExp-2]+densityMapHold [yPointMarkTemp-center+counter3][xPointMarkTemp-center+counter4];
                                    pointCount++;
                                }
                            }
                        }
                        
                        dotListExp [dotListCountExp-1] = pointCount;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < lineageListCountExp/4; counterA++){
            //    cout<<lineageListExp [counterA*4]<<" "<<lineageListExp [counterA*4+1]<<" "<<lineageListExp [counterA*4+2]<<" "<<lineageListExp [counterA*4+3]<<" Ling"<<endl;
            //}
            
            ofstream oin;
            oin.open(path.c_str(), ios::out);
            
            int *arrayAscIIintData = new int [100];
            int ascIIintDataCount = 0;
            
            ascIIconversion = [[ASCIIconversion alloc] init];
            
            ascIIstring = "Xposition";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = "Yposition";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = "Density";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
            
            for (int counter1 = 0; counter1 < dotListCountExp/4; counter1++){
                ascIIstring = to_string(dotListExp [counter1*4]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(dotListExp [counter1*4+1]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(dotListExp [counter1*4+2]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(dotListExp [counter1*4+3]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                oin.put(13);
                oin.put(10);
            }
            
            int divisionNo = 0;
            
            if (gridDivisionHold == 0) divisionNo = 3;
            else if (gridDivisionHold == 1) divisionNo = 4;
            else if (gridDivisionHold == 2) divisionNo = 5;
            
            int xDivStart = (int)(xImageSizeEX*(double)0.1);
            int xDivLength = (xImageSizeEX-(int)(xImageSizeEX*(double)0.1))-(int)(xImageSizeEX*(double)0.1);
            int xPixLength = (int)(xDivLength/(double)divisionNo);
            int yDivStart = (int)(yImageSizeEX*(double)0.1);
            int yDivLength = (yImageSizeEX-(int)(yImageSizeEX*(double)0.1))-(int)(yImageSizeEX*(double)0.1);
            int yPixLength = (int)(yDivLength/(double)divisionNo);
            
            int *dimensionData = new int [30];
            int dimensionEntry = 0;
            
            for (int counter3 = 0; counter3 < 30; counter3++) dimensionData [counter3] = 0;
            
            for (int counter3 = 0; counter3 < divisionNo; counter3++){
                for (int counter4 = 0; counter4 < divisionNo; counter4++){
                    for (int counter5 = yDivStart+yPixLength*counter3; counter5 < yDivStart+yPixLength*counter3+yPixLength; counter5++){
                        for (int counter6 = xDivStart+xPixLength*counter4; counter6 < xDivStart+xPixLength*counter4+xPixLength; counter6++){
                            dimensionData [dimensionEntry] = dimensionData [dimensionEntry]+densityMapHold [counter5][counter6];
                        }
                    }
                    
                    dimensionEntry++;
                }
            }
            
            oin.put(13);
            oin.put(10);
            
            ascIIconversion = [[ASCIIconversion alloc] init];
            
            ascIIstring = "Density in a Block";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(13);
            oin.put(10);
            
            ascIIstring = "Pix";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            int areaPix = xPixLength*yPixLength;
            
            ascIIstring = to_string(areaPix);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
            
            oin.put(13);
            oin.put(10);
            
            for (int counter1 = 0; counter1 < divisionNo*divisionNo; counter1++){
                ascIIstring = to_string(counter1+1);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(dimensionData [counter1]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                oin.put(13);
                oin.put(10);
            }
            
            for (int counter3 = 0; counter3 < 30; counter3++) dimensionData [counter3] = 0;
            
            dimensionEntry = 0;
            
            for (int counter3 = 0; counter3 < divisionNo; counter3++){
                for (int counter4 = 0; counter4 < divisionNo; counter4++){
                    for (int counter5 = 0; counter5 < dotDataHoldCount/3; counter5++){
                        if (firstSecondSelectHold == 0){
                            if (arrayDotDataHold [counter5*3] >= 0 && arrayDotDataHold [counter5*3] <= 100000 && arrayDotDataHold [counter5*3] >= displayTimeRangeMin && arrayDotDataHold [counter5*3] <= displayTimeRangeMax){
                                xPointMarkTemp = arrayDotDataHold [counter5*3+1]-xImageStart;
                                yPointMarkTemp = imageXYLength-(arrayDotDataHold [counter5*3+2]+yImageStart);
                                
                                if (yPointMarkTemp > yDivStart+yPixLength*counter3 && yDivStart+yPixLength*counter3+yPixLength >= yPointMarkTemp && xPointMarkTemp > xDivStart+xPixLength*counter4 && xDivStart+xPixLength*counter4+xPixLength >= xPointMarkTemp){
                                    dimensionData [dimensionEntry]++;
                                }
                            }
                        }
                        else if (firstSecondSelectHold == 1){
                            if (arrayDotDataHold [counter5*3] < 0 && arrayDotDataHold [counter5*3] >= -100000 && arrayDotDataHold [counter5*3]*-1 >= displayTimeRangeMin && arrayDotDataHold [counter5*3]*-1 <= displayTimeRangeMax){
                                xPointMarkTemp = arrayDotDataHold [counter5*3+1]-xImageStart;
                                yPointMarkTemp = imageXYLength-(arrayDotDataHold [counter5*3+2]+yImageStart);
                                
                                if (yPointMarkTemp > yDivStart+yPixLength*counter3 && yDivStart+yPixLength*counter3+yPixLength >= yPointMarkTemp && xPointMarkTemp > xDivStart+xPixLength*counter4 && xDivStart+xPixLength*counter4+xPixLength >= xPointMarkTemp){
                                    dimensionData [dimensionEntry]++;
                                }
                            }
                        }
                        else if (firstSecondSelectHold == 2){
                            if (arrayDotDataHold [counter5*3] > 100000 && arrayDotDataHold [counter5*3]-100000 >= displayTimeRangeMin && arrayDotDataHold [counter5*3]-100000 <= displayTimeRangeMax){
                                xPointMarkTemp = arrayDotDataHold [counter5*3+1]-xImageStart;
                                yPointMarkTemp = imageXYLength-(arrayDotDataHold [counter5*3+2]+yImageStart);
                                
                                if (yPointMarkTemp > yDivStart+yPixLength*counter3 && yDivStart+yPixLength*counter3+yPixLength >= yPointMarkTemp && xPointMarkTemp > xDivStart+xPixLength*counter4 && xDivStart+xPixLength*counter4+xPixLength >= xPointMarkTemp){
                                    dimensionData [dimensionEntry]++;
                                }
                            }
                        }
                        else if (firstSecondSelectHold == 3){
                            if (arrayDotDataHold [counter5*3] < -100000 && arrayDotDataHold [counter5*3]*-1-100000 >= displayTimeRangeMin && arrayDotDataHold [counter5*3]*-1-100000 <= displayTimeRangeMax){
                                xPointMarkTemp = arrayDotDataHold [counter5*3+1]-xImageStart;
                                yPointMarkTemp = imageXYLength-(arrayDotDataHold [counter5*3+2]+yImageStart);
                                
                                if (yPointMarkTemp > yDivStart+yPixLength*counter3 && yDivStart+yPixLength*counter3+yPixLength >= yPointMarkTemp && xPointMarkTemp > xDivStart+xPixLength*counter4 && xDivStart+xPixLength*counter4+xPixLength >= xPointMarkTemp){
                                    dimensionData [dimensionEntry]++;
                                }
                            }
                        }
                    }
                    
                    dimensionEntry++;
                    
                }
            }
            
            oin.put(13);
            oin.put(10);
            
            ascIIconversion = [[ASCIIconversion alloc] init];
            
            ascIIstring = "No of cells in a Block";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(13);
            oin.put(10);
            
            oin.put(13);
            oin.put(10);
            
            for (int counter1 = 0; counter1 < divisionNo*divisionNo; counter1++){
                ascIIstring = to_string(counter1+1);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(dimensionData [counter1]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                oin.put(13);
                oin.put(10);
            }
            
            oin.close();
            
            for (int counter1 = 0; counter1 < yImageSizeEX+1; counter1++){
                delete [] densityMapHold [counter1];
            }
            
            delete [] densityMapHold;
            
            delete [] arrayAscIIintData;
            delete [] dotListExp;
            delete [] dimensionData;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Range Error/Dot Data Missing/Diameter-Value Error"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Range+Density Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)gridDivisionSet:(id)sender{
    if (gridDivisionHold == 0){
        gridDivisionHold = 1;
        
        [gridDivisionDisplay setStringValue:@"4"];
    }
    else if (gridDivisionHold == 1){
        gridDivisionHold = 2;
        
        [gridDivisionDisplay setStringValue:@"5"];
    }
    else if (gridDivisionHold == 2){
        gridDivisionHold = 0;
        
        [gridDivisionDisplay setStringValue:@"3"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)dotGravityCenterChoiceDiaplay:(id)sender{
    if (dotGCenterChoice == 0){
        dotGCenterChoice = 1;
        
        [dotGravityCenterChoiceDiaplay setStringValue:@"GR"];
    }
    else if (dotGCenterChoice == 1){
        dotGCenterChoice = 0;
        
        [dotGravityCenterChoiceDiaplay setStringValue:@"Dot"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet1:(id)sender{
    colorListNoHold = 1;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet2:(id)sender{
    colorListNoHold = 2;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet3:(id)sender{
    colorListNoHold = 3;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet4:(id)sender{
    colorListNoHold = 4;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet5:(id)sender{
    colorListNoHold = 5;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet6:(id)sender{
    colorListNoHold = 6;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet7:(id)sender{
    colorListNoHold = 7;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet8:(id)sender{
    colorListNoHold = 8;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet9:(id)sender{
    colorListNoHold = 9;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet10:(id)sender{
    colorListNoHold = 10;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet11:(id)sender{
    colorListNoHold = 11;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet12:(id)sender{
    colorListNoHold = 12;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet13:(id)sender{
    colorListNoHold = 13;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet14:(id)sender{
    colorListNoHold = 14;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet15:(id)sender{
    colorListNoHold = 15;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet16:(id)sender{
    colorListNoHold = 16;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet17:(id)sender{
    colorListNoHold = 17;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet18:(id)sender{
    colorListNoHold = 18;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet19:(id)sender{
    colorListNoHold = 19;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet20:(id)sender{
    colorListNoHold = 20;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet21:(id)sender{
    colorListNoHold = 21;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet22:(id)sender{
    colorListNoHold = 22;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet23:(id)sender{
    colorListNoHold = 23;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet24:(id)sender{
    colorListNoHold = 24;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet25:(id)sender{
    colorListNoHold = 25;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet26:(id)sender{
    colorListNoHold = 26;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet27:(id)sender{
    colorListNoHold = 27;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet28:(id)sender{
    colorListNoHold = 28;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet29:(id)sender{
    colorListNoHold = 29;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet30:(id)sender{
    colorListNoHold = 30;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet31:(id)sender{
    colorListNoHold = 31;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet32:(id)sender{
    colorListNoHold = 32;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet33:(id)sender{
    colorListNoHold = 33;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet34:(id)sender{
    colorListNoHold = 34;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet35:(id)sender{
    colorListNoHold = 35;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet36:(id)sender{
    colorListNoHold = 36;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet37:(id)sender{
    colorListNoHold = 37;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet38:(id)sender{
    colorListNoHold = 38;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet39:(id)sender{
    colorListNoHold = 39;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet40:(id)sender{
    colorListNoHold = 40;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet41:(id)sender{
    colorListNoHold = 41;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet42:(id)sender{
    colorListNoHold = 42;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet43:(id)sender{
    colorListNoHold = 43;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet44:(id)sender{
    colorListNoHold = 44;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet45:(id)sender{
    colorListNoHold = 45;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet46:(id)sender{
    colorListNoHold = 46;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet47:(id)sender{
    colorListNoHold = 47;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet48:(id)sender{
    colorListNoHold = 48;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet49:(id)sender{
    colorListNoHold = 49;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet50:(id)sender{
    colorListNoHold = 50;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet51:(id)sender{
    colorListNoHold = 51;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet52:(id)sender{
    colorListNoHold = 52;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet53:(id)sender{
    colorListNoHold = 53;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet54:(id)sender{
    colorListNoHold = 54;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet55:(id)sender{
    colorListNoHold = 55;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet56:(id)sender{
    colorListNoHold = 56;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet57:(id)sender{
    colorListNoHold = 57;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet58:(id)sender{
    colorListNoHold = 58;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet59:(id)sender{
    colorListNoHold = 59;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet60:(id)sender{
    colorListNoHold = 60;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet61:(id)sender{
    colorListNoHold = 61;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet62:(id)sender{
    colorListNoHold = 62;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet63:(id)sender{
    colorListNoHold = 63;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet64:(id)sender{
    colorListNoHold = 64;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet65:(id)sender{
    colorListNoHold = 65;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet66:(id)sender{
    colorListNoHold = 66;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet67:(id)sender{
    colorListNoHold = 67;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet68:(id)sender{
    colorListNoHold = 68;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet69:(id)sender{
    colorListNoHold = 69;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet70:(id)sender{
    colorListNoHold = 70;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet71:(id)sender{
    colorListNoHold = 71;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet72:(id)sender{
    colorListNoHold = 72;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet73:(id)sender{
    colorListNoHold = 73;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet74:(id)sender{
    colorListNoHold = 74;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet75:(id)sender{
    colorListNoHold = 75;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet76:(id)sender{
    colorListNoHold = 76;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet77:(id)sender{
    colorListNoHold = 77;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet78:(id)sender{
    colorListNoHold = 78;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet79:(id)sender{
    colorListNoHold = 79;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet80:(id)sender{
    colorListNoHold = 80;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet81:(id)sender{
    colorListNoHold = 81;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet82:(id)sender{
    colorListNoHold = 82;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet83:(id)sender{
    colorListNoHold = 83;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet84:(id)sender{
    colorListNoHold = 84;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet85:(id)sender{
    colorListNoHold = 85;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet86:(id)sender{
    colorListNoHold = 86;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet87:(id)sender{
    colorListNoHold = 87;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet88:(id)sender{
    colorListNoHold = 88;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet89:(id)sender{
    colorListNoHold = 89;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet90:(id)sender{
    colorListNoHold = 90;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet91:(id)sender{
    colorListNoHold = 91;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet92:(id)sender{
    colorListNoHold = 92;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet93:(id)sender{
    colorListNoHold = 93;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet94:(id)sender{
    colorListNoHold = 94;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet95:(id)sender{
    colorListNoHold = 95;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet96:(id)sender{
    colorListNoHold = 96;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet97:(id)sender{
    colorListNoHold = 97;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet98:(id)sender{
    colorListNoHold = 98;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet99:(id)sender{
    colorListNoHold = 99;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet100:(id)sender{
    colorListNoHold = 100;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet101:(id)sender{
    colorListNoHold = 101;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet102:(id)sender{
    colorListNoHold = 102;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet103:(id)sender{
    colorListNoHold = 103;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet104:(id)sender{
    colorListNoHold = 104;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet105:(id)sender{
    colorListNoHold = 105;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet106:(id)sender{
    colorListNoHold = 106;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet107:(id)sender{
    colorListNoHold = 107;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet108:(id)sender{
    colorListNoHold = 108;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet109:(id)sender{
    colorListNoHold = 109;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet110:(id)sender{
    colorListNoHold = 110;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet111:(id)sender{
    colorListNoHold = 111;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet112:(id)sender{
    colorListNoHold = 112;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet113:(id)sender{
    colorListNoHold = 113;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet114:(id)sender{
    colorListNoHold = 114;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet115:(id)sender{
    colorListNoHold = 115;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet116:(id)sender{
    colorListNoHold = 116;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet117:(id)sender{
    colorListNoHold = 117;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet118:(id)sender{
    colorListNoHold = 118;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet119:(id)sender{
    colorListNoHold = 119;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet120:(id)sender{
    colorListNoHold = 120;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet121:(id)sender{
    colorListNoHold = 121;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet122:(id)sender{
    colorListNoHold = 122;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet123:(id)sender{
    colorListNoHold = 123;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet124:(id)sender{
    colorListNoHold = 124;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet125:(id)sender{
    colorListNoHold = 125;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet126:(id)sender{
    colorListNoHold = 126;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet127:(id)sender{
    colorListNoHold = 127;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet128:(id)sender{
    colorListNoHold = 128;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet129:(id)sender{
    colorListNoHold = 129;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet130:(id)sender{
    colorListNoHold = 130;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet131:(id)sender{
    colorListNoHold = 131;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorListSet132:(id)sender{
    colorListNoHold = 132;
    [[colorListSelected cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRangeSource [(colorListNoHold-1)*3] green:arrayColorRangeSource [(colorListNoHold-1)*3+1] blue:arrayColorRangeSource [(colorListNoHold-1)*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(void)reDisplayWindow{
    if (exportOperation == 3){
        [exportMainWindow makeKeyAndOrderFront:nil];
        exportOperation = 1;
        [exportMainTimer invalidate];
    }
}

-(IBAction)closeWindow:(id)sender{
    [exportMainWindow orderOut:nil];
    exportOperation = 2;
    exportMainTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToExportController object:nil];
}

@end
