//
// GapFill.h
// CellMovieQuant
//
// Created by Masahiko Sato on 20/12/12.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#ifndef GAPFILL_H
#define GAPFILL_H
#import "LineSet.h" 
#endif

@interface GapFill : NSObject {
}

-(void)gapFilling:(int)originX :(int)originY :(int)destinationX :(int)destinationY;
-(void)gapDataUpdate;

@end
