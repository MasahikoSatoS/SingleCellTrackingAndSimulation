//
//  TargetFind2.h
//  CellMovieQuant
//
//  Created by Masahiko Sato on 2015-01-11.
//
//

#ifndef TARGETFIND2_H
#define TARGETFIND2_H
#import "Controller.h" 
#endif

@interface TargetFind2 : NSObject {
}

-(void)interpretationFirst :(int) processType;

@end
