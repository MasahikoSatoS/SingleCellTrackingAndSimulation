//
//  Controller.m
//  CellMovieQuant
//
//  Created by Masahiko Sato on 2014-09-29.
//
//

#import "Controller.h"

//-------Basic info------
string pathNameString;
string analysisNameHold;
string treatNameHold;
string imageDataPath;
string imageDisplayPath;
int grayColorStatus;

//-----Arrays--------
string *fileList;
int fileListCount;
int fileListStatus;
uint8_t *fileReadArray;

//-------Basic operation------
int maxImageNo;
int timePointHold;
int movieRunningFlag;
int filePosition;
int timePointDisplayCall;
int movieTiming;
int imageXYLength;
int imageBmpTifFlag;

//------Image data--------
uint8_t *uploadTemp;
int uploadTempStatus;
uint8_t *uploadTempCl1;
int uploadTempStatusCl1;
uint8_t *uploadTempCl2;
int uploadTempStatusCl2;
uint8_t *uploadTempCl3;
int uploadTempStatusCl3;
uint8_t *uploadTempCl4;
int uploadTempStatusCl4;
uint8_t *uploadTempCl5;
int uploadTempStatusCl5;
uint8_t *uploadTempCl6;
int uploadTempStatusCl6;
long uploadTempFileSize;

int colorFlag1;
int colorFlag2;
int colorFlag3;
int colorFlag4;
int colorFlag5;
int colorFlag6;
string colorNo1;
string colorNo2;
string colorNo3;
string colorNo4;
string colorNo5;
string colorNo6;
string colorName1;
string colorName2;
string colorName3;
string colorName4;
string colorName5;
string colorName6;
double levelHold1;
double levelHold2;
double levelHold3;
double levelHold4;
double levelHold5;
double levelHold6;
double levelHoldDIC;
double levelHoldR;
double levelHoldG;
double levelHoldB;
double cutHold1;
double cutHold2;
double cutHold3;
double cutHold4;
double cutHold5;
double cutHold6;
double cutHoldDIC;
int statusHold1;
int statusHold2;
int statusHold3;
int statusHold4;
int statusHold5;
int statusHold6;
int statusHoldDIC;
int lastDICImageTime;
int lastTIFRoundNo;
int colorInfoDisplayCall;

//-------Basic info------
int initialArraySet;
string dataSavePath;
int quantitationStatusHold;
int analysisStatusHold;
int areaModeStatusHold;
int saveShortCutNumber;
int areaTotalTable;
string ascIIstring;
int imageProgressFlag;
int mergeProcessingFlag;
int phaseStatus;
string *fileList2;
int fileListCount2;
int warningSet;
string directoryPathExtract;

//-------Box data------
int boxXLength;
int boxYLength;
double boxXPosition;
double boxYPosition;
double boxXPositionCurrent;
double boxYPositionCurrent;
int dimensionSetModeHold;
int boxDisplayCall;

//-------Dot data------
int dotNumberCurrent;
int dotSetFirstSecondHold;
int dotExportLimitTimeTo;
int dotExportLimitTimeFrom;

//------Image data--------
uint8_t *uploadTempRef;
int uploadTempCountRef;
int uploadTempStatusRef;
uint8_t *uploadTempRef2;
int uploadTempCountRef2;
int uploadTempStatusRef2;
int uploadTempLoadRef2;
uint8_t *uploadTempRef3;
int uploadTempCountRef3;
int uploadTempStatusRef3;
int uploadTempLoadRef3;
int refLoadStatus;

long uploadTempRefFileSize1;
long uploadTempRefFileSize2;
long uploadTempRefFileSize3;

//-------Area processing------
double *arrayAreaDataHold;
int areaDataHoldCount;
int areaDataHoldLimit;
int *arrayDotDataHold;
int dotDataHoldCount;
int dotDataHoldLimit;
int areaValueCall;
int currentConnectNo;
int *groupNumberList;
int groupNumberListCount;
int lineDraw;
int windowLock;
int currentPositionSet;
int areaSetDone;
int mergeOperationStatus;

//------Area processing arrays-----
int *arrayPositionRevise;
int positionReviseCount;
int positionReviseLimit;
int positionReviseAddition;

int *arrayGravityCenterRev;
int gravityCenterRevCount;
int gravityCenterRevLimit;

int *arrayTimeSelected;
int timeSelectedCount;
int timeSelectedLimit;

int **sourceImage;
int **revisedMap;
int **revisedWorkingMap;
int **connectMap200;
int **connectMap220;
int **connectMap240;
int **connectMapA;
int **connectMapB;
int **connectMapC;
int **connectMapD;
int imageSizeLimit;

int *arrayTarget;
int targetCount;
int targetLimit;

int *arrayGapData;
int gapDataCount;
int gapDataLimit;

int *arrayReferenceLine;
int referenceLineCount;
int referenceLineLimit;

int *arrayLineDataProcessing;
int lineDataProcessingCount;

int *arrayTargetHold;
int targetHoldCount;
int targetHoldLimit;
int targetHoldAddition;
int targetHoldStatus;

int *arrayTargetHoldInfo;
int targetHoldInfoCount;
int targetHoldInfoLimit;

//-------Line Dot display type-----
int targetMarkColorType;
int targetMarkWidthType;
int dotFillStatus;
int dotLength;

int lineSizeHold;
int lineWidthFlag;

int lineFontShowOnOff;
int charDisplayFlag;

//-------Grid data-----
int gridDimHold;
int gridLinWidth;
int gridLineColor;
int gridStatusHold;

//=======Image export=======
//-------Basic info------
int exportOperation;
string displayImageSavePath;
int filePositionExp;
int timePointHoldExp;
string fileSavePathHold;
int **arrayImageFileSave;
int timingEx;

//------Image data--------
uint8_t *uploadTempExp;
int uploadTempExpStatus;
uint8_t *uploadTempExpCl1;
int uploadTempExpStatusCl1;
uint8_t *uploadTempExpCl2;
int uploadTempExpStatusCl2;
uint8_t *uploadTempExpCl3;
int uploadTempExpStatusCl3;
uint8_t *uploadTempExpCl4;
int uploadTempExpStatusCl4;
uint8_t *uploadTempExpCl5;
int uploadTempExpStatusCl5;
uint8_t *uploadTempExpCl6;
int uploadTempExpStatusCl6;

uint8_t *uploadTempExpRef;
int uploadTempExpStatusRef;
uint8_t *uploadTempExpRef2;
int uploadTempExpStatusRef2;
int uploadTempExpLoadRef2;
uint8_t *uploadTempExpRef3;
int uploadTempExpStatusRef3;
int uploadTempExpLoadRef3;

int colorFlagExp1;
int colorFlagExp2;
int colorFlagExp3;
int colorFlagExp4;
int colorFlagExp5;
int colorFlagExp6;

//------Area processing arrays-----
int *arrayPositionExport;
int positionExportCount;
int positionExportStatus;

int *arrayGravityCenterExport;
int gravityCenterExportCount;
int gravityCenterExportStatus;

int *arrayGravityCenterExportHold;
int gravityCenterExportCorrectCount;
int gravityCenterExportCorrectStatus;

int *arrayTimeSelectedExport;
int timeSelectedExportCount;
int timeSelectedExportStatus;

int **revisedWorkingMapExp;
int revisedWorkingMapExpStatus;

//-------Line Dot type for Print-----
int outlineWidthExport;
int outLineSelectExport;
int printLineColor;
int dotSizeExport;
int targetWidthExport;
int targetLengthExport;
int targetFontExport;
int titleFontExport;

//-------Line Dot type for Display-----
double lineWidthExp;
int pasteDotExport;
int dotStyleExport;
int dotLengthExport;
int fontCrossExport;

int boxXLengthExp;
int boxYLengthExp;
double boxXPositionExp;
double boxYPositionExp;

int dotNumberCurrentExp;

//------Color past setting--------
int colorHold1;
int colorHold2;
int colorHold3;
int colorHold4;
int colorHold5;
int colorHold6;
int colorHold7;
int colorHold8;
int colorHold9;
int colorHold10;
int colorHoldSd;
int colorHoldTh;

int colorHoldArea1;
int colorHoldArea2;
int colorHoldArea3;
int colorHoldArea4;
int colorHoldArea5;
int colorHoldArea6;
int colorHoldArea7;
int colorHoldArea8;
int colorHoldArea9;

int colorMaxAreaHold;
int numberOfGroupHold;

int colorPasteStatus;
int colorHoldSdStatus;
int colorHoldThStatus;

CGFloat *arrayColorRange;
CGFloat *arrayColorRange2;
CGFloat *arrayColorRangeSource;

//------Dot Heat Map commands--------
int firstSecondSelectHold;
int dotDisplayMode;
int dotDisplayTimeMin;
int dotDisplayTimeMax;
int densityDiameterHold;
int densityDiameterPrev;
int densityValueMaxHold;
int densityValueHighest;
int gridDivisionHold;
int **circleAreaHold;
int circleAreaHoldStatus;
int dotGCenterChoice;

@implementation Controller

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSString *currentDirectoryPathNSString = [[NSBundle mainBundle] bundlePath];
        string userPathNameString = [currentDirectoryPathNSString cStringUsingEncoding:NSUTF8StringEncoding];
        
        if (userPathNameString.length() == 0) exit (0);
        else if ((int)userPathNameString.find("/Users/") == -1) exit (0);
        else{
            
            string pathName2 = userPathNameString.substr((unsigned long)userPathNameString.find("/Users/")+7);
            pathNameString = pathName2.substr(0, (unsigned long)pathName2.find("/"));
        }
        
        analysisNameHold = "";
        treatNameHold = "";
        grayColorStatus = 0;
        
        fileListStatus = 0;
        
        maxImageNo = 0;
        timePointHold = 0;
        movieRunningFlag = 0;
        timePointDisplayCall = 0;
        movieTiming = 0;
        imageXYLength = 0;
        imageBmpTifFlag = 0;
        
        uploadTempStatus = 0;
        uploadTempStatusCl1 = 0;
        uploadTempStatusCl2 = 0;
        uploadTempStatusCl3 = 0;
        uploadTempStatusCl4 = 0;
        uploadTempStatusCl5 = 0;
        uploadTempStatusCl6 = 0;
        
        colorFlag1 = 0;
        colorFlag2 = 0;
        colorFlag3 = 0;
        colorFlag4 = 0;
        colorFlag5 = 0;
        colorFlag6 = 0;
        levelHold1 = 1;
        levelHold2 = 1;
        levelHold3 = 1;
        levelHold4 = 1;
        levelHold5 = 1;
        levelHold6 = 1;
        levelHoldDIC = 0;
        levelHoldR = 1;
        levelHoldG = 1;
        levelHoldB = 1;
        cutHold1 = 50;
        cutHold2 = 50;
        cutHold3 = 50;
        cutHold4 = 50;
        cutHold5 = 50;
        cutHold6 = 50;
        cutHoldDIC = 0;
        statusHold1 = 0;
        statusHold2 = 0;
        statusHold3 = 0;
        statusHold4 = 0;
        statusHold5 = 0;
        statusHold6 = 0;
        statusHoldDIC = 0;
        colorInfoDisplayCall = 0;
        
        initialArraySet = 0;
        quantitationStatusHold = 0;
        analysisStatusHold = 0;
        areaModeStatusHold = 0;
        saveShortCutNumber = 0;
        areaTotalTable = 0;
        imageProgressFlag = 0;
        mergeProcessingFlag = 0;
        phaseStatus = 0;
        warningSet = 0;
        
        boxXPositionCurrent = 0;
        boxYPositionCurrent = 0;
        dimensionSetModeHold = 0;
        boxDisplayCall = 0;
        
        dotNumberCurrent = 0;
        dotSetFirstSecondHold = 0;
        dotExportLimitTimeTo = 0;
        dotExportLimitTimeFrom = 0;
        
        uploadTempStatusRef = 0;
        uploadTempStatusRef2 = 0;
        uploadTempStatusRef3 = 0;
        refLoadStatus = 0;
        
        areaValueCall = 0;
        currentConnectNo = 0;
        lineDraw = 0;
        windowLock = 0;
        currentPositionSet = 1;
        areaSetDone = 0;
        mergeOperationStatus = 0;
        
        targetMarkColorType = 0;
        targetMarkWidthType = 0;
        dotFillStatus = 0;
        dotLength = 1;
        
        lineSizeHold = 0;
        lineWidthFlag = 0;
        
        lineFontShowOnOff = 0;
        charDisplayFlag = 0;
        
        gridDimHold = 1;
        gridLinWidth = 0;
        gridLineColor = 0;
        gridStatusHold = 0;
        
        exportOperation = 0;
        filePositionExp = 0;
        timingEx = 0;
        
        uploadTempExpStatus = 0;
        uploadTempExpStatusCl1 = 0;
        uploadTempExpStatusCl2 = 0;
        uploadTempExpStatusCl3 = 0;
        uploadTempExpStatusCl4 = 0;
        uploadTempExpStatusCl5 = 0;
        uploadTempExpStatusCl6 = 0;
        
        uploadTempExpStatusRef = 0;
        uploadTempExpStatusRef2 = 0;
        uploadTempExpStatusRef3 = 0;
        
        revisedWorkingMapExpStatus = 0;
        
        outlineWidthExport = 1;
        outLineSelectExport = 0;
        printLineColor = 0;
        
        positionExportStatus = 0;
        gravityCenterExportStatus = 0;
        timeSelectedExportStatus = 0;
        dotSizeExport = 2;
        targetWidthExport = 5;
        targetLengthExport = 2;
        targetFontExport = 2;
        titleFontExport = 4;
        
        lineWidthExp = 1;
        pasteDotExport = 1;
        dotStyleExport = 0;
        dotLengthExport = 1;
        fontCrossExport = 0;
        
        colorHoldSdStatus = 0;
        colorHoldThStatus = 0;
        
        firstSecondSelectHold = 0;
        dotDisplayMode = 0;
        dotDisplayTimeMin = 0;
        dotDisplayTimeMax = 0;
        densityDiameterHold = 0;
        densityDiameterPrev = 0;
        densityValueMaxHold = 0;
        densityValueHighest = 0;
        gridDivisionHold = 0;
        circleAreaHoldStatus = 0;
        dotGCenterChoice = 0;
        
        //-----Controller static-----
        currentImageNo = 0;
        speedHold = 10;
        orientationHold = 0;
        
        sliderFluorescentCHMax1 = 20;
        sliderFluorescentCHMin1 = 0.01;
        sliderFluorescentCHDiff1 = 19.99;
        sliderCutCHMax1 = 255;
        sliderCutCHMin1 = 0;
        sliderCutCHDiff1 = 255;
        
        sliderFluorescentCHMax2 = 20;
        sliderFluorescentCHMin2 = 0.01;
        sliderFluorescentCHDiff2 = 19.99;
        sliderCutCHMax2 = 255;
        sliderCutCHMin2 = 0;
        sliderCutCHDiff2 = 255;
        
        sliderFluorescentCHMax3 = 20;
        sliderFluorescentCHMin3 = 0.01;
        sliderFluorescentCHDiff3 = 19.99;
        sliderCutCHMax3 = 255;
        sliderCutCHMin3 = 0;
        sliderCutCHDiff3 = 255;
        
        sliderFluorescentCHMax4 = 20;
        sliderFluorescentCHMin4 = 0.01;
        sliderFluorescentCHDiff4 = 19.99;
        sliderCutCHMax4 = 255;
        sliderCutCHMin4 = 0;
        sliderCutCHDiff4 = 255;
        
        sliderFluorescentCHMax5 = 20;
        sliderFluorescentCHMin5 = 0.01;
        sliderFluorescentCHDiff5 = 19.99;
        sliderCutCHMax5 = 255;
        sliderCutCHMin5 = 0;
        sliderCutCHDiff5 = 255;
        
        sliderFluorescentCHMax6 = 20;
        sliderFluorescentCHMin6 = 0.01;
        sliderFluorescentCHDiff6 = 19.99;
        sliderCutCHMax6 = 255;
        sliderCutCHMin6 = 0;
        sliderCutCHDiff6 = 255;
        
        sliderDICMax = 20;
        sliderDICMin = 0.01;
        sliderDICDiff = 19.99;
        sliderCutDICMax = 255;
        sliderCutDICMin = 0;
        sliderCutDICDiff = 255;
        
        sliderRMax = 20;
        sliderRMin = 0.01;
        sliderRDiff = 19.99;
        
        sliderGMax = 20;
        sliderGMin = 0.01;
        sliderGDiff = 19.99;
        
        sliderBMax = 20;
        sliderBMin = 0.01;
        sliderBDiff = 19.99;
        
        sliderStart = 0;
        sliderEnd = 0;
        warningSetB = 0;
        progressTimingB = 0;
    }
    
    return self;
}

-(void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat xLength = screenRect.size.width;
    CGFloat yLength = screenRect.size.height;
    
    int mainControllerX = 800;
    
    NSRect windowSize = [controllerWindow frame];
    CGFloat windowWidth = windowSize.size.width;
    CGFloat windowHeight = windowSize.size.height;
    
    int displayPositionType = 0;
    
    if (80+mainControllerX+5+windowWidth+5+80 > xLength) displayPositionType = 1;
    
    CGFloat displayX;
    
    if (displayPositionType == 1) displayX = 550;
    else displayX = 80+mainControllerX+5;
    
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [controllerWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    imageDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images";
    dataSavePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"07_Cell_Tracking_Data/MovieQuant_InfoMovie";
    
    [speed setDelegate:self];
    
    [listBrowser setTarget:self];
    [listBrowser setDoubleAction:@selector(browserDoubleClick:)];
    
    [areaSummaryTable setDataSource:self];
    [dotExportToDisplay setDelegate:self];
    [dotExportFromDisplay setDelegate:self];
    
    for (NSTableColumn* column in [areaSummaryTable tableColumns]) {
        if ([[column identifier] isEqualToString:@"COL1"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Category" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL2"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Value" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
    }
}

-(void)applicationDidFinishLaunching:(NSNotification*)notification{
    string movieSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CMBasic";
    string getString;
    
    ifstream fin;
    fin.open(movieSettingPath.c_str(),ios::in);
    
    if (fin.is_open()){
        getline(fin, getString), speedHold = atoi(getString.c_str());
        getline(fin, getString), orientationHold = atoi(getString.c_str());
        fin.close();
    }
    else{
        
        ofstream oin;
        oin.open(movieSettingPath.c_str(),ios::out);
        oin<<speedHold<<endl;
        oin<<orientationHold<<endl;
        oin.close();
    }
    
    [speed setIntegerValue:speedHold];
    [stepper setIntValue:speedHold];
    [stepper setMinValue:10];
    [stepper setMaxValue:1000];
    
    if (orientationHold == 0) [direction setStringValue:@"FW"];
    else [direction setStringValue:@"RW"];
    
    [timePoint setStringValue:@"nil"];
    [analysisName setStringValue:@"nil"];
    [treatment setStringValue:@"nil"];
    
    [movieStatus setStringValue:@"Off"];
    [movieText setStringValue:@"Movie"];
    
    [chLabel1 setStringValue:@"CH1"];
    [chLabel2 setStringValue:@"CH2"];
    [chLabel3 setStringValue:@"CH3"];
    [chLabel4 setStringValue:@"CH4"];
    [chLabel5 setStringValue:@"CH5"];
    [chLabel6 setStringValue:@"CH6"];
    [chName1 setStringValue:@"nil"];
    [chName2 setStringValue:@"nil"];
    [chName3 setStringValue:@"nil"];
    [chName4 setStringValue:@"nil"];
    [chName5 setStringValue:@"nil"];
    [chName6 setStringValue:@"nil"];
    [chLevel1 setStringValue:@"nil"];
    [chLevel2 setStringValue:@"nil"];
    [chLevel3 setStringValue:@"nil"];
    [chLevel4 setStringValue:@"nil"];
    [chLevel5 setStringValue:@"nil"];
    [chLevel6 setStringValue:@"nil"];
    [chCut1 setStringValue:@"nil"];
    [chCut2 setStringValue:@"nil"];
    [chCut3 setStringValue:@"nil"];
    [chCut4 setStringValue:@"nil"];
    [chCut5 setStringValue:@"nil"];
    [chCut6 setStringValue:@"nil"];
    [chCutDIC setStringValue:@"nil"];
    [chStatus1 setStringValue:@"Off"];
    [chStatus2 setStringValue:@"Off"];
    [chStatus3 setStringValue:@"Off"];
    [chStatus4 setStringValue:@"Off"];
    [chStatus5 setStringValue:@"Off"];
    [chStatus6 setStringValue:@"Off"];
    [chLevelDIC setStringValue:@"nil"];
    [chDICImage setStringValue:@"IF Image"];
    
    arrayDirectoryInfo = new string [100];
    directoryInfoCount = 0;
    directoryInfoLimit = 100;
    
    arrayAreaDataHold = new double [2500];
    areaDataHoldCount = 0;
    areaDataHoldLimit = 2500;
    
    for (int counter1 = 0; counter1 < areaDataHoldCount; counter1++) arrayAreaDataHold [counter1] = 0;
    
    arrayDotDataHold = new int [1000];
    dotDataHoldCount = 0;
    dotDataHoldLimit = 1000;
    
    arrayPositionRevise = new int [10000];
    positionReviseCount = 0;
    positionReviseLimit = 10000;
    
    arrayGravityCenterRev = new int [10000];
    gravityCenterRevCount = 0;
    gravityCenterRevLimit = 10000;
    
    arrayTimeSelected = new int [10000];
    timeSelectedCount = 0;
    timeSelectedLimit = 10000;
    
    imageSizeLimit = 1000;
    
    sourceImage = new int *[imageSizeLimit+1];
    revisedMap = new int *[imageSizeLimit+1];
    revisedWorkingMap = new int *[imageSizeLimit+1];
    connectMap200 = new int *[imageSizeLimit+1];
    connectMap220 = new int *[imageSizeLimit+1];
    connectMap240 = new int *[imageSizeLimit+1];
    connectMapA = new int *[imageSizeLimit+1];
    connectMapB = new int *[imageSizeLimit+1];
    connectMapC = new int *[imageSizeLimit+1];
    connectMapD = new int *[imageSizeLimit+1];
    
    for (int counter1 = 0; counter1 < imageSizeLimit+1; counter1++){
        sourceImage [counter1] = new int [imageSizeLimit+1];
        revisedMap [counter1] = new int [imageSizeLimit+1];
        revisedWorkingMap [counter1] = new int [imageSizeLimit+1];
        connectMap200 [counter1] = new int [imageSizeLimit+1];
        connectMap220 [counter1] = new int [imageSizeLimit+1];
        connectMap240 [counter1] = new int [imageSizeLimit+1];
        connectMapA [counter1] = new int [imageSizeLimit+1];
        connectMapB [counter1] = new int [imageSizeLimit+1];
        connectMapC [counter1] = new int [imageSizeLimit+1];
        connectMapD [counter1] = new int [imageSizeLimit+1];
    }
    
    groupNumberList = new int [10];
    groupNumberListCount = 0;
    
    arrayReferenceLine = new int [5000];
    referenceLineCount = 0;
    referenceLineLimit = 5000;
    
    string colorListPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ColorListData";
    
    arrayColorRange = new CGFloat [100];
    arrayColorRange [0] = 0/(double)255, arrayColorRange [1] = 0/(double)255, arrayColorRange [2] = 0/(double)255;
    arrayColorRange [3] = 0/(double)255, arrayColorRange [4] = 0/(double)255, arrayColorRange [5] = 255/(double)255;
    arrayColorRange [6] = 153/(double)255, arrayColorRange [7] = 102/(double)255, arrayColorRange [8] = 51/(double)255;
    arrayColorRange [9] = 0/(double)255, arrayColorRange [10] = 255/(double)255, arrayColorRange [11] = 255/(double)255;
    arrayColorRange [12] = 0/(double)255, arrayColorRange [13] = 255/(double)255, arrayColorRange [14] = 0/(double)255;
    arrayColorRange [15] = 255/(double)255, arrayColorRange [16] = 0/(double)255, arrayColorRange [17] = 255/(double)255;
    arrayColorRange [18] = 255/(double)255, arrayColorRange [19] = 153/(double)255, arrayColorRange [20] = 0/(double)255;
    arrayColorRange [21] = 170/(double)255, arrayColorRange [22] = 0/(double)255, arrayColorRange [23] = 170/(double)255;
    arrayColorRange [24] = 255/(double)255, arrayColorRange [25] = 0/(double)255, arrayColorRange [26] = 0/(double)255;
    arrayColorRange [27] = 255/(double)255, arrayColorRange [28] = 255/(double)255, arrayColorRange [29] = 0/(double)255;
    arrayColorRange [30] = 0/(double)255, arrayColorRange [31] = 0/(double)255, arrayColorRange [32] = 0/(double)255;
    arrayColorRange [33] = 34/(double)255, arrayColorRange [34] = 78/(double)255, arrayColorRange [35] = 29/(double)255;
    arrayColorRange [36] = 149/(double)255, arrayColorRange [37] = 32/(double)255, arrayColorRange [38] = 67/(double)255;
    
    fin.open(colorListPath.c_str(),ios::in);
    
    if (fin.is_open()){
        for (int counter1 = 0; counter1 <= 38; counter1++){
            getline(fin, getString), arrayColorRange [counter1] = atof(getString.c_str());
        }
        
        fin.close();
    }
    
    arrayColorRangeSource = new CGFloat [400];
    arrayColorRangeSource [0] = 255/(double)255, arrayColorRangeSource [1] = 226/(double)255, arrayColorRangeSource [2] = 222/(double)255;
    arrayColorRangeSource [3] = 238/(double)255, arrayColorRangeSource [4] = 221/(double)255, arrayColorRangeSource [5] = 240/(double)255;
    arrayColorRangeSource [6] = 245/(double)255, arrayColorRangeSource [7] = 214/(double)255, arrayColorRangeSource [8] = 239/(double)255;
    arrayColorRangeSource [9] = 230/(double)255, arrayColorRangeSource [10] = 231/(double)255, arrayColorRangeSource [11] = 249/(double)255;
    arrayColorRangeSource [12] = 220/(double)255, arrayColorRangeSource [13] = 255/(double)255, arrayColorRangeSource [14] = 255/(double)255;
    arrayColorRangeSource [15] = 230/(double)255, arrayColorRangeSource [16] = 249/(double)255, arrayColorRangeSource [17] = 229/(double)255;
    arrayColorRangeSource [18] = 254/(double)255, arrayColorRangeSource [19] = 237/(double)255, arrayColorRangeSource [20] = 241/(double)255;
    arrayColorRangeSource [21] = 255/(double)255, arrayColorRangeSource [22] = 242/(double)255, arrayColorRangeSource [23] = 242/(double)255;
    arrayColorRangeSource [24] = 252/(double)255, arrayColorRangeSource [25] = 252/(double)255, arrayColorRangeSource [26] = 216/(double)255;
    arrayColorRangeSource [27] = 252/(double)255, arrayColorRangeSource [28] = 254/(double)255, arrayColorRangeSource [29] = 215/(double)255;
    arrayColorRangeSource [30] = 255/(double)255, arrayColorRangeSource [31] = 254/(double)255, arrayColorRangeSource [32] = 171/(double)255;
    arrayColorRangeSource [33] = 206/(double)255, arrayColorRangeSource [34] = 247/(double)255, arrayColorRangeSource [35] = 161/(double)255;
    
    arrayColorRangeSource [36] = 252/(double)255, arrayColorRangeSource [37] = 210/(double)255, arrayColorRangeSource [38] = 207/(double)255;
    arrayColorRangeSource [39] = 250/(double)255, arrayColorRangeSource [40] = 209/(double)255, arrayColorRangeSource [41] = 252/(double)255;
    arrayColorRangeSource [42] = 206/(double)255, arrayColorRangeSource [43] = 206/(double)255, arrayColorRangeSource [44] = 255/(double)255;
    arrayColorRangeSource [45] = 212/(double)255, arrayColorRangeSource [46] = 213/(double)255, arrayColorRangeSource [47] = 255/(double)255;
    arrayColorRangeSource [48] = 160/(double)255, arrayColorRangeSource [49] = 252/(double)255, arrayColorRangeSource [50] = 249/(double)255;
    arrayColorRangeSource [51] = 213/(double)255, arrayColorRangeSource [52] = 248/(double)255, arrayColorRangeSource [53] = 216/(double)255;
    arrayColorRangeSource [54] = 248/(double)255, arrayColorRangeSource [55] = 204/(double)255, arrayColorRangeSource [56] = 205/(double)255;
    arrayColorRangeSource [57] = 248/(double)255, arrayColorRangeSource [58] = 207/(double)255, arrayColorRangeSource [59] = 203/(double)255;
    arrayColorRangeSource [60] = 253/(double)255, arrayColorRangeSource [61] = 253/(double)255, arrayColorRangeSource [62] = 217/(double)255;
    arrayColorRangeSource [63] = 255/(double)255, arrayColorRangeSource [64] = 208/(double)255, arrayColorRangeSource [65] = 139/(double)255;
    arrayColorRangeSource [66] = 252/(double)255, arrayColorRangeSource [67] = 250/(double)255, arrayColorRangeSource [68] = 147/(double)255;
    arrayColorRangeSource [69] = 159/(double)255, arrayColorRangeSource [70] = 251/(double)255, arrayColorRangeSource [71] = 113/(double)255;
    
    arrayColorRangeSource [72] = 255/(double)255, arrayColorRangeSource [73] = 159/(double)255, arrayColorRangeSource [74] = 210/(double)255;
    arrayColorRangeSource [75] = 247/(double)255, arrayColorRangeSource [76] = 162/(double)255, arrayColorRangeSource [77] = 243/(double)255;
    arrayColorRangeSource [78] = 210/(double)255, arrayColorRangeSource [79] = 173/(double)255, arrayColorRangeSource [80] = 252/(double)255;
    arrayColorRangeSource [81] = 170/(double)255, arrayColorRangeSource [82] = 169/(double)255, arrayColorRangeSource [83] = 251/(double)255;
    arrayColorRangeSource [84] = 111/(double)255, arrayColorRangeSource [85] = 255/(double)255, arrayColorRangeSource [86] = 247/(double)255;
    arrayColorRangeSource [87] = 158/(double)255, arrayColorRangeSource [88] = 255/(double)255, arrayColorRangeSource [89] = 153/(double)255;
    arrayColorRangeSource [90] = 239/(double)255, arrayColorRangeSource [91] = 153/(double)255, arrayColorRangeSource [92] = 154/(double)255;
    arrayColorRangeSource [93] = 249/(double)255, arrayColorRangeSource [94] = 163/(double)255, arrayColorRangeSource [95] = 174/(double)255;
    arrayColorRangeSource [96] = 254/(double)255, arrayColorRangeSource [97] = 209/(double)255, arrayColorRangeSource [98] = 164/(double)255;
    arrayColorRangeSource [99] = 255/(double)255, arrayColorRangeSource [100] = 214/(double)255, arrayColorRangeSource [101] = 120/(double)255;
    arrayColorRangeSource [102] = 255/(double)255, arrayColorRangeSource [103] = 252/(double)255, arrayColorRangeSource [104] = 85/(double)255;
    arrayColorRangeSource [105] = 152/(double)255, arrayColorRangeSource [106] = 249/(double)255, arrayColorRangeSource [107] = 93/(double)255;
    
    arrayColorRangeSource [108] = 232/(double)255, arrayColorRangeSource [109] = 107/(double)255, arrayColorRangeSource [110] = 154/(double)255;
    arrayColorRangeSource [111] = 247/(double)255, arrayColorRangeSource [112] = 129/(double)255, arrayColorRangeSource [113] = 253/(double)255;
    arrayColorRangeSource [114] = 202/(double)255, arrayColorRangeSource [115] = 132/(double)255, arrayColorRangeSource [116] = 255/(double)255;
    arrayColorRangeSource [117] = 122/(double)255, arrayColorRangeSource [118] = 118/(double)255, arrayColorRangeSource [119] = 255/(double)255;
    arrayColorRangeSource [120] = 129/(double)255, arrayColorRangeSource [121] = 254/(double)255, arrayColorRangeSource [122] = 253/(double)255;
    arrayColorRangeSource [123] = 128/(double)255, arrayColorRangeSource [124] = 251/(double)255, arrayColorRangeSource [125] = 107/(double)255;
    arrayColorRangeSource [126] = 248/(double)255, arrayColorRangeSource [127] = 110/(double)255, arrayColorRangeSource [128] = 101/(double)255;
    arrayColorRangeSource [129] = 245/(double)255, arrayColorRangeSource [130] = 163/(double)255, arrayColorRangeSource [131] = 114/(double)255;
    arrayColorRangeSource [132] = 253/(double)255, arrayColorRangeSource [133] = 160/(double)255, arrayColorRangeSource [134] = 136/(double)255;
    arrayColorRangeSource [135] = 255/(double)255, arrayColorRangeSource [136] = 214/(double)255, arrayColorRangeSource [137] = 120/(double)255;
    arrayColorRangeSource [138] = 254/(double)255, arrayColorRangeSource [139] = 250/(double)255, arrayColorRangeSource [140] = 49/(double)255;
    arrayColorRangeSource [141] = 122/(double)255, arrayColorRangeSource [142] = 200/(double)255, arrayColorRangeSource [143] = 52/(double)255;
    
    arrayColorRangeSource [144] = 241/(double)255, arrayColorRangeSource [145] = 73/(double)255, arrayColorRangeSource [146] = 168/(double)255;
    arrayColorRangeSource [147] = 238/(double)255, arrayColorRangeSource [148] = 80/(double)255, arrayColorRangeSource [149] = 239/(double)255;
    arrayColorRangeSource [150] = 187/(double)255, arrayColorRangeSource [151] = 33/(double)255, arrayColorRangeSource [152] = 249/(double)255;
    arrayColorRangeSource [153] = 76/(double)255, arrayColorRangeSource [154] = 67/(double)255, arrayColorRangeSource [155] = 255/(double)255;
    arrayColorRangeSource [156] = 79/(double)255, arrayColorRangeSource [157] = 249/(double)255, arrayColorRangeSource [158] = 255/(double)255;
    arrayColorRangeSource [159] = 99/(double)255, arrayColorRangeSource [160] = 237/(double)255, arrayColorRangeSource [161] = 106/(double)255;
    arrayColorRangeSource [162] = 249/(double)255, arrayColorRangeSource [163] = 64/(double)255, arrayColorRangeSource [164] = 68/(double)255;
    arrayColorRangeSource [165] = 249/(double)255, arrayColorRangeSource [166] = 131/(double)255, arrayColorRangeSource [167] = 75/(double)255;
    arrayColorRangeSource [168] = 255/(double)255, arrayColorRangeSource [169] = 158/(double)255, arrayColorRangeSource [170] = 109/(double)255;
    arrayColorRangeSource [171] = 248/(double)255, arrayColorRangeSource [172] = 217/(double)255, arrayColorRangeSource [173] = 41/(double)255;
    arrayColorRangeSource [174] = 211/(double)255, arrayColorRangeSource [175] = 215/(double)255, arrayColorRangeSource [176] = 69/(double)255;
    arrayColorRangeSource [177] = 125/(double)255, arrayColorRangeSource [178] = 213/(double)255, arrayColorRangeSource [179] = 20/(double)255;
    
    arrayColorRangeSource [180] = 253/(double)255, arrayColorRangeSource [181] = 26/(double)255, arrayColorRangeSource [182] = 185/(double)255;
    arrayColorRangeSource [183] = 239/(double)255, arrayColorRangeSource [184] = 44/(double)255, arrayColorRangeSource [185] = 234/(double)255;
    arrayColorRangeSource [186] = 169/(double)255, arrayColorRangeSource [187] = 37/(double)255, arrayColorRangeSource [188] = 217/(double)255;
    arrayColorRangeSource [189] = 33/(double)255, arrayColorRangeSource [190] = 31/(double)255, arrayColorRangeSource [191] = 253/(double)255;
    arrayColorRangeSource [192] = 50/(double)255, arrayColorRangeSource [193] = 247/(double)255, arrayColorRangeSource [194] = 255/(double)255;
    arrayColorRangeSource [195] = 53/(double)255, arrayColorRangeSource [196] = 245/(double)255, arrayColorRangeSource [197] = 56/(double)255;
    arrayColorRangeSource [198] = 242/(double)255, arrayColorRangeSource [199] = 16/(double)255, arrayColorRangeSource [200] = 24/(double)255;
    arrayColorRangeSource [201] = 249/(double)255, arrayColorRangeSource [202] = 127/(double)255, arrayColorRangeSource [203] = 45/(double)255;
    arrayColorRangeSource [204] = 255/(double)255, arrayColorRangeSource [205] = 169/(double)255, arrayColorRangeSource [206] = 80/(double)255;
    arrayColorRangeSource [207] = 206/(double)255, arrayColorRangeSource [208] = 170/(double)255, arrayColorRangeSource [209] = 66/(double)255;
    arrayColorRangeSource [210] = 178/(double)255, arrayColorRangeSource [211] = 183/(double)255, arrayColorRangeSource [212] = 67/(double)255;
    arrayColorRangeSource [213] = 107/(double)255, arrayColorRangeSource [214] = 148/(double)255, arrayColorRangeSource [215] = 18/(double)255;
    
    arrayColorRangeSource [216] = 222/(double)255, arrayColorRangeSource [217] = 32/(double)255, arrayColorRangeSource [218] = 120/(double)255;
    arrayColorRangeSource [219] = 218/(double)255, arrayColorRangeSource [220] = 78/(double)255, arrayColorRangeSource [221] = 212/(double)255;
    arrayColorRangeSource [222] = 116/(double)255, arrayColorRangeSource [223] = 61/(double)255, arrayColorRangeSource [224] = 152/(double)255;
    arrayColorRangeSource [225] = 36/(double)255, arrayColorRangeSource [226] = 34/(double)255, arrayColorRangeSource [227] = 218/(double)255;
    arrayColorRangeSource [228] = 38/(double)255, arrayColorRangeSource [229] = 197/(double)255, arrayColorRangeSource [230] = 202/(double)255;
    arrayColorRangeSource [231] = 73/(double)255, arrayColorRangeSource [232] = 223/(double)255, arrayColorRangeSource [233] = 65/(double)255;
    arrayColorRangeSource [234] = 212/(double)255, arrayColorRangeSource [235] = 22/(double)255, arrayColorRangeSource [236] = 27/(double)255;
    arrayColorRangeSource [237] = 253/(double)255, arrayColorRangeSource [238] = 103/(double)255, arrayColorRangeSource [239] = 42/(double)255;
    arrayColorRangeSource [240] = 251/(double)255, arrayColorRangeSource [241] = 185/(double)255, arrayColorRangeSource [242] = 110/(double)255;
    arrayColorRangeSource [243] = 254/(double)255, arrayColorRangeSource [244] = 208/(double)255, arrayColorRangeSource [245] = 7/(double)255;
    arrayColorRangeSource [246] = 217/(double)255, arrayColorRangeSource [247] = 206/(double)255, arrayColorRangeSource [248] = 26/(double)255;
    arrayColorRangeSource [249] = 60/(double)255, arrayColorRangeSource [250] = 163/(double)255, arrayColorRangeSource [251] = 11/(double)255;
    
    arrayColorRangeSource [252] = 132/(double)255, arrayColorRangeSource [253] = 46/(double)255, arrayColorRangeSource [254] = 117/(double)255;
    arrayColorRangeSource [255] = 164/(double)255, arrayColorRangeSource [256] = 115/(double)255, arrayColorRangeSource [257] = 162/(double)255;
    arrayColorRangeSource [258] = 123/(double)255, arrayColorRangeSource [259] = 36/(double)255, arrayColorRangeSource [260] = 111/(double)255;
    arrayColorRangeSource [261] = 67/(double)255, arrayColorRangeSource [262] = 66/(double)255, arrayColorRangeSource [263] = 181/(double)255;
    arrayColorRangeSource [264] = 47/(double)255, arrayColorRangeSource [265] = 182/(double)255, arrayColorRangeSource [266] = 178/(double)255;
    arrayColorRangeSource [267] = 72/(double)255, arrayColorRangeSource [268] = 180/(double)255, arrayColorRangeSource [269] = 66/(double)255;
    arrayColorRangeSource [270] = 182/(double)255, arrayColorRangeSource [271] = 44/(double)255, arrayColorRangeSource [272] = 58/(double)255;
    arrayColorRangeSource [273] = 201/(double)255, arrayColorRangeSource [274] = 118/(double)255, arrayColorRangeSource [275] = 36/(double)255;
    arrayColorRangeSource [276] = 243/(double)255, arrayColorRangeSource [277] = 179/(double)255, arrayColorRangeSource [278] = 71/(double)255;
    arrayColorRangeSource [279] = 206/(double)255, arrayColorRangeSource [280] = 157/(double)255, arrayColorRangeSource [281] = 20/(double)255;
    arrayColorRangeSource [282] = 167/(double)255, arrayColorRangeSource [283] = 166/(double)255, arrayColorRangeSource [284] = 48/(double)255;
    arrayColorRangeSource [285] = 65/(double)255, arrayColorRangeSource [286] = 113/(double)255, arrayColorRangeSource [287] = 13/(double)255;
    
    arrayColorRangeSource [288] = 149/(double)255, arrayColorRangeSource [289] = 32/(double)255, arrayColorRangeSource [290] = 67/(double)255;
    arrayColorRangeSource [291] = 178/(double)255, arrayColorRangeSource [292] = 73/(double)255, arrayColorRangeSource [293] = 184/(double)255;
    arrayColorRangeSource [294] = 72/(double)255, arrayColorRangeSource [295] = 33/(double)255, arrayColorRangeSource [296] = 106/(double)255;
    arrayColorRangeSource [297] = 36/(double)255, arrayColorRangeSource [298] = 37/(double)255, arrayColorRangeSource [299] = 104/(double)255;
    arrayColorRangeSource [300] = 36/(double)255, arrayColorRangeSource [301] = 117/(double)255, arrayColorRangeSource [302] = 123/(double)255;
    arrayColorRangeSource [303] = 72/(double)255, arrayColorRangeSource [304] = 138/(double)255, arrayColorRangeSource [305] = 62/(double)255;
    arrayColorRangeSource [306] = 105/(double)255, arrayColorRangeSource [307] = 13/(double)255, arrayColorRangeSource [308] = 16/(double)255;
    arrayColorRangeSource [309] = 209/(double)255, arrayColorRangeSource [310] = 71/(double)255, arrayColorRangeSource [311] = 33/(double)255;
    arrayColorRangeSource [312] = 213/(double)255, arrayColorRangeSource [313] = 119/(double)255, arrayColorRangeSource [314] = 72/(double)255;
    arrayColorRangeSource [315] = 209/(double)255, arrayColorRangeSource [316] = 166/(double)255, arrayColorRangeSource [317] = 115/(double)255;
    arrayColorRangeSource [318] = 120/(double)255, arrayColorRangeSource [319] = 123/(double)255, arrayColorRangeSource [320] = 32/(double)255;
    arrayColorRangeSource [321] = 63/(double)255, arrayColorRangeSource [322] = 63/(double)255, arrayColorRangeSource [323] = 14/(double)255;
    
    arrayColorRangeSource [324] = 112/(double)255, arrayColorRangeSource [325] = 33/(double)255, arrayColorRangeSource [326] = 73/(double)255;
    arrayColorRangeSource [327] = 111/(double)255, arrayColorRangeSource [328] = 75/(double)255, arrayColorRangeSource [329] = 114/(double)255;
    arrayColorRangeSource [330] = 69/(double)255, arrayColorRangeSource [331] = 38/(double)255, arrayColorRangeSource [332] = 70/(double)255;
    arrayColorRangeSource [333] = 32/(double)255, arrayColorRangeSource [334] = 34/(double)255, arrayColorRangeSource [335] = 83/(double)255;
    arrayColorRangeSource [336] = 30/(double)255, arrayColorRangeSource [337] = 76/(double)255, arrayColorRangeSource [338] = 75/(double)255;
    arrayColorRangeSource [339] = 28/(double)255, arrayColorRangeSource [340] = 106/(double)255, arrayColorRangeSource [341] = 28/(double)255;
    arrayColorRangeSource [342] = 65/(double)255, arrayColorRangeSource [343] = 13/(double)255, arrayColorRangeSource [344] = 18/(double)255;
    arrayColorRangeSource [345] = 151/(double)255, arrayColorRangeSource [346] = 78/(double)255, arrayColorRangeSource [347] = 35/(double)255;
    arrayColorRangeSource [348] = 169/(double)255, arrayColorRangeSource [349] = 119/(double)255, arrayColorRangeSource [350] = 81/(double)255;
    arrayColorRangeSource [351] = 211/(double)255, arrayColorRangeSource [352] = 159/(double)255, arrayColorRangeSource [353] = 72/(double)255;
    arrayColorRangeSource [354] = 81/(double)255, arrayColorRangeSource [355] = 78/(double)255, arrayColorRangeSource [356] = 36/(double)255;
    arrayColorRangeSource [357] = 34/(double)255, arrayColorRangeSource [358] = 78/(double)255, arrayColorRangeSource [359] = 29/(double)255;
    
    arrayColorRangeSource [360] = 0/(double)255, arrayColorRangeSource [361] = 0/(double)255, arrayColorRangeSource [362] = 255/(double)255;
    arrayColorRangeSource [363] = 0/(double)255, arrayColorRangeSource [364] = 255/(double)255, arrayColorRangeSource [365] = 0/(double)255;
    arrayColorRangeSource [366] = 255/(double)255, arrayColorRangeSource [367] = 0/(double)255, arrayColorRangeSource [368] = 0/(double)255;
    arrayColorRangeSource [369] = 0/(double)255, arrayColorRangeSource [370] = 255/(double)255, arrayColorRangeSource [371] = 255/(double)255;
    arrayColorRangeSource [372] = 255/(double)255, arrayColorRangeSource [373] = 0/(double)255, arrayColorRangeSource [374] = 255/(double)255;
    arrayColorRangeSource [375] = 255/(double)255, arrayColorRangeSource [376] = 255/(double)255, arrayColorRangeSource [377] = 0/(double)255;
    arrayColorRangeSource [378] = 255/(double)255, arrayColorRangeSource [379] = 153/(double)255, arrayColorRangeSource [380] = 0/(double)255;
    arrayColorRangeSource [381] = 170/(double)255, arrayColorRangeSource [382] = 0/(double)255, arrayColorRangeSource [383] = 170/(double)255;
    arrayColorRangeSource [384] = 153/(double)255, arrayColorRangeSource [385] = 102/(double)255, arrayColorRangeSource [386] = 51/(double)255;
    arrayColorRangeSource [387] = 1/(double)255, arrayColorRangeSource [388] = 1/(double)255, arrayColorRangeSource [389] = 1/(double)255;
    arrayColorRangeSource [390] = 120/(double)255, arrayColorRangeSource [391] = 120/(double)255, arrayColorRangeSource [392] = 120/(double)255;
    arrayColorRangeSource [393] = 255/(double)255, arrayColorRangeSource [394] = 255/(double)255, arrayColorRangeSource [395] = 255/(double)255;
    
    arrayColorRange2 = new CGFloat [150];
    arrayColorRange2 [0] = 16/(double)255, arrayColorRange2 [1] = 22/(double)255, arrayColorRange2 [2] = 255/(double)255;
    arrayColorRange2 [3] = 31/(double)255, arrayColorRange2 [4] = 49/(double)255, arrayColorRange2 [5] = 237/(double)255;
    arrayColorRange2 [6] = 54/(double)255, arrayColorRange2 [7] = 88/(double)255, arrayColorRange2 [8] = 255/(double)255;
    arrayColorRange2 [9] = 43/(double)255, arrayColorRange2 [10] = 136/(double)255, arrayColorRange2 [11] = 255/(double)255;
    arrayColorRange2 [12] = 65/(double)255, arrayColorRange2 [13] = 178/(double)255, arrayColorRange2 [14] = 236/(double)255;
    arrayColorRange2 [15] = 77/(double)255, arrayColorRange2 [16] = 228/(double)255, arrayColorRange2 [17] = 249/(double)255;
    arrayColorRange2 [18] = 109/(double)255, arrayColorRange2 [19] = 250/(double)255, arrayColorRange2 [20] = 234/(double)255;
    arrayColorRange2 [21] = 104/(double)255, arrayColorRange2 [22] = 250/(double)255, arrayColorRange2 [23] = 203/(double)255;
    arrayColorRange2 [24] = 105/(double)255, arrayColorRange2 [25] = 247/(double)255, arrayColorRange2 [26] = 175/(double)255;
    arrayColorRange2 [27] = 104/(double)255, arrayColorRange2 [28] = 242/(double)255, arrayColorRange2 [29] = 119/(double)255;
    arrayColorRange2 [30] = 102/(double)255, arrayColorRange2 [31] = 242/(double)255, arrayColorRange2 [32] = 93/(double)255;
    arrayColorRange2 [33] = 108/(double)255, arrayColorRange2 [34] = 244/(double)255, arrayColorRange2 [35] = 58/(double)255;
    arrayColorRange2 [36] = 120/(double)255, arrayColorRange2 [37] = 242/(double)255, arrayColorRange2 [38] = 33/(double)255;
    arrayColorRange2 [39] = 110/(double)255, arrayColorRange2 [40] = 250/(double)255, arrayColorRange2 [41] = 53/(double)255;
    arrayColorRange2 [42] = 132/(double)255, arrayColorRange2 [43] = 255/(double)255, arrayColorRange2 [44] = 43/(double)255;
    arrayColorRange2 [45] = 166/(double)255, arrayColorRange2 [46] = 254/(double)255, arrayColorRange2 [47] = 46/(double)255;
    arrayColorRange2 [48] = 199/(double)255, arrayColorRange2 [49] = 255/(double)255, arrayColorRange2 [50] = 72/(double)255;
    arrayColorRange2 [51] = 244/(double)255, arrayColorRange2 [52] = 251/(double)255, arrayColorRange2 [53] = 51/(double)255;
    arrayColorRange2 [54] = 234/(double)255, arrayColorRange2 [55] = 225/(double)255, arrayColorRange2 [56] = 58/(double)255;
    arrayColorRange2 [57] = 234/(double)255, arrayColorRange2 [58] = 185/(double)255, arrayColorRange2 [59] = 44/(double)255;
    arrayColorRange2 [60] = 240/(double)255, arrayColorRange2 [61] = 136/(double)255, arrayColorRange2 [62] = 39/(double)255;
    arrayColorRange2 [63] = 229/(double)255, arrayColorRange2 [64] = 93/(double)255, arrayColorRange2 [65] = 41/(double)255;
    arrayColorRange2 [66] = 222/(double)255, arrayColorRange2 [67] = 64/(double)255, arrayColorRange2 [68] = 25/(double)255;
    arrayColorRange2 [69] = 246/(double)255, arrayColorRange2 [70] = 20/(double)255, arrayColorRange2 [71] = 40/(double)255;
    arrayColorRange2 [72] = 255/(double)255, arrayColorRange2 [73] = 0/(double)255, arrayColorRange2 [74] = 0/(double)255;
    
    [listBrowser reloadColumn:0];
    
    timerCD = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
}

-(void)display{
    if (timePointDisplayCall == 1){
        [timePoint setIntegerValue:timePointHold];
        
        NSString *treatNSString = [timePoint stringValue];
        
        if (treatNSString != NULL){
            string treatString = [treatNSString UTF8String];
            
            if (to_string(timePointHold) == treatString) timePointDisplayCall = 0;
        }
    }
    
    if (movieRunningFlag == 1){
        if (orientationHold == 0 && movieTiming == 0){
            movieTiming = 1;
            filePosition++;
            
            if (maxImageNo < filePosition){
                filePosition--;
                movieRunningFlag = 0;
                
                [movieStatus setTextColor:[NSColor blackColor]];
                [movieStatus setStringValue:@"Off"];
                [movieText setTextColor:[NSColor blackColor]];
                [movieText setStringValue:@"Movie"];
            }
            else{
                
                [self dataSetAndDisplay];
                
                string timeDisplayTemp = fileList [(filePosition-1)*7];
                timeDisplayTemp = timeDisplayTemp.substr(8, 4);
                
                timePointHold = atoi(timeDisplayTemp.c_str());
                [timePoint setIntegerValue:timePointHold];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
            }
        }
        else if (orientationHold == 1 && movieTiming == 0){
            movieTiming = 1;
            filePosition--;
            
            if (filePosition <= 0){
                filePosition = 1;
                movieRunningFlag = 0;
                
                [movieStatus setTextColor:[NSColor blackColor]];
                [movieStatus setStringValue:@"Off"];
                [movieText setTextColor:[NSColor blackColor]];
                [movieText setStringValue:@"Movie"];
            }
            else{
                
                [self dataSetAndDisplay];
                
                string timeDisplayTemp = fileList [(filePosition-1)*7];
                timeDisplayTemp = timeDisplayTemp.substr(8, 4);
                
                timePointHold = atoi(timeDisplayTemp.c_str());
                [timePoint setIntegerValue:timePointHold];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
            }
        }
    }
    
    if (colorInfoDisplayCall == 1){
        colorInfoDisplayCall = 2;
        
        int mode = 1;
        
        if (colorFlag1 == 1){
            [self setCH1:mode];
            
            if (colorFlag2 == 1){
                [self setCH2:mode];
                
                if (colorFlag3 == 1){
                    [self setCH3:mode];
                    
                    if (colorFlag4 == 1){
                        [self setCH4:mode];
                        
                        if (colorFlag5 == 1){
                            [self setCH5:mode];
                            
                            if (colorFlag6 == 1) [self setCH6:mode];
                            else [self resetSubCH6];
                        }
                        else [self resetSubCH5];
                    }
                    else [self resetSubCH4];
                }
                else [self resetSubCH3];
            }
            else [self resetSubCH2];
        }
        else{
            
            if (colorFlag1 == 0) [self resetSubCH1];
        }
        
        colorInfoDisplayCall = 0;
    }
    
    if (sliderStart == 1 && sliderEnd == 0){
        sliderEnd = 1;
        sliderStart = 0;
    }
    
    if (sliderEnd == 1){
        if (sliderStart == 1) sliderStart = 0;
        else{
            
            sliderStart = 0;
            sliderEnd = 0;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
    }
    
    if (areaValueCall == 1){
        areaValueCall = 0;
        [areaSummaryTable reloadData];
    }
    
    if (boxDisplayCall == 1 || boxDisplayCall == 2){
        if (boxDisplayCall == 1){
            string dimensionXY = to_string(boxXLength)+" x "+to_string(boxYLength);
            [boxDimensionDisplay setStringValue:@(dimensionXY.c_str())];
        }
        else if (boxDisplayCall == 2){
            [boxDimensionDisplay setStringValue:@"nil x nil"];
        }
        
        boxDisplayCall = 0;
    }
    
    if (saveShortCutNumber == 2){
        saveShortCutNumber = 20;
        int processType = 1;
        lineSet = [[LineSet alloc] init];
        [lineSet lineSetProcess:processType];
    }
    
    if (saveShortCutNumber == 4){
        saveShortCutNumber = 0;
        
        if (lineDraw == 0){
            lineDraw = 1;
            windowLock = 1;
        }
        else if (lineDraw == 1){
            lineDraw = 0;
            windowLock = 0;
        }
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
    
    if (saveShortCutNumber == 5){
        saveShortCutNumber = 0;
        
        analysisStatusHold = 0;
        [analysisModeDisplay setStringValue:@"Off"];
    }
    
    if (saveShortCutNumber == 6){
        saveShortCutNumber = 0;
        
        analysisStatusHold = 1;
        [analysisModeDisplay setStringValue:@"Dot Set"];
    }
    
    if (saveShortCutNumber == 7){
        saveShortCutNumber = 0;
        
        analysisStatusHold = 2;
        [analysisModeDisplay setStringValue:@"Dot Clear"];
    }
    
    if (saveShortCutNumber == 8){
        saveShortCutNumber = 0;
        
        if (imageXYLength != 0 && movieRunningFlag == 0 && phaseStatus == 0 && imageProgressFlag == 0){
            int jumpPositionNumber = (int)[jumpPosition integerValue];
            
            if (maxImageNo >= jumpPositionNumber && jumpPositionNumber > 0){
                filePosition = jumpPositionNumber;
                
                [self dataSetAndDisplay];
                
                string timeDisplayTemp = fileList [(filePosition-1)*7];
                timeDisplayTemp = timeDisplayTemp.substr(8, 4);
                
                int currentTime = timePointHold;
                
                timePointHold = atoi(timeDisplayTemp.c_str());
                
                if ((timePointHold-1)*25+25 < areaDataHoldCount){
                    boxXLength = (int)(arrayAreaDataHold [(timePointHold-1)*25+6]);
                    boxYLength = (int)(arrayAreaDataHold [(timePointHold-1)*25+7]);
                    boxXPosition = arrayAreaDataHold [(timePointHold-1)*25+8];
                    boxYPosition = arrayAreaDataHold [(timePointHold-1)*25+9];
                    
                    dotNumberCurrent = (int)arrayAreaDataHold [(timePointHold-1)*25+5];
                }
                else{
                    
                    boxXLength = 0;
                    boxYLength = 0;
                    boxXPosition = 0;
                    boxYPosition = 0;
                    dotNumberCurrent = 0;
                }
                
                if (boxXLength != 0 && boxYLength != 0) boxDisplayCall = 1;
                else boxDisplayCall = 2;
                
                if (areaSetDone == 1){
                    areaSetDone = 0;
                    trackingDataSave = [[TrackingDataSave alloc] init];
                    [trackingDataSave trackingDataSaveTemp:currentTime];
                }
                
                timePointDisplayCall = 1;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Value Out of Range"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    
    if (saveShortCutNumber == 9){
        saveShortCutNumber = 0;
        
        dotSetFirstSecondHold = 0;
        [firstSecondDisplay setStringValue:@"P"];
    }
    
    if (saveShortCutNumber == 10){
        saveShortCutNumber = 0;
        
        dotSetFirstSecondHold = 1;
        [firstSecondDisplay setStringValue:@"D"];
    }
    
    if (saveShortCutNumber == 11){
        saveShortCutNumber = 0;
        
        dotSetFirstSecondHold = 2;
        [firstSecondDisplay setStringValue:@"T"];
    }
    
    if (saveShortCutNumber == 12){
        saveShortCutNumber = 0;
        
        dotSetFirstSecondHold = 3;
        [firstSecondDisplay setStringValue:@"Q"];
    }
    
    if (mergeProcessingFlag == 1){
        mergeProcessingFlag = 2;
        imageProgressFlag = 1;
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
            self->progressTimingB = 6;
            
            do usleep(10);
            while (self->progressTimingB == 6);
            
            int lineDrawStatus = 0;
            
            if (lineDraw == 0){
                lineDraw = 1;
                lineDrawStatus = 1;
            }
            
            int connectFindNumber = 0;
            int groupNoTemp = 0;
            int processType = 0;
            
            for (int counter1 = 1; counter1 < groupNumberListCount; counter1++){
                if (groupNumberList [counter1] > 0){
                    connectFindNumber = 0;
                    groupNoTemp = groupNumberList [counter1];
                    
                    for (int counter2 = 1; counter2 < groupNumberListCount; counter2++){
                        if (groupNumberList [counter2] == groupNoTemp || groupNumberList [counter2] == groupNoTemp*-1) connectFindNumber++;
                    }
                    
                    if (connectFindNumber > 1){
                        self->merge = [[Merge alloc] init];
                        [self->merge mergeMain:groupNoTemp:connectFindNumber];
                        
                        mergeOperationStatus = 1;
                        processType = 2;
                        self->lineSet = [[LineSet alloc] init];
                        [self->lineSet lineSetProcess:processType];
                    }
                }
            }
            
            if (lineDrawStatus == 1) lineDraw = 0;
            
            imageProgressFlag = 0;
            mergeProcessingFlag = 3;
            self->progressTimingB = 0;
        });
    }
    else if (mergeProcessingFlag == 3){
        mergeProcessingFlag = 0;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
    
    if (warningSet == 1){
        warningSet = 0;
        areaModeStatusHold = 0;
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Outline Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    else if (warningSet == 2){
        warningSet = 0;
        
        [areaModeDisplay setStringValue:@"On"];
    }
    else if (warningSet == 3){
        warningSet = 0;
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else if (warningSet == 4){
        warningSet = 0;
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"File Number or Size Mismatch"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    else if (warningSet == 5){
        warningSet = 0;
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Incorrect Image Size or No. of Images"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    else if (warningSet == 6){
        warningSet = 0;
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Data Loading Error"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    
    if (warningSetB == 10){
        warningSetB = 0;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
    
    if (progressTimingB == 6){
        [backSave startAnimation:self];
        
        if (backSave) progressTimingB = 7;
    }
    else if (progressTimingB == 8){
        [backSave stopAnimation:self];
        
        if (backSave) progressTimingB = 0;
    }
    
    if (progressTimingB == 0){
        if (backSave) [backSave stopAnimation:self];
    }
}

-(int)browser:(NSBrowser *)sender numberOfRowsInColumn:(int)column{
    directoryInfoCount = 0;
    
    DIR *dir;
    struct dirent *dent;
    
    if (column == 0 && directoryInfoLimit >= 100){
        dir = opendir(imageDataPath.c_str());
        
        if (dir != NULL){
            string entry;
            
            while((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    if ((int)entry.find("_Image") != -1){
                        if (directoryInfoCount+2 > directoryInfoLimit) [self directoryInfoUpDate];
                        
                        entry = entry.substr(0, entry.find("_Image"));
                        arrayDirectoryInfo [directoryInfoCount] = entry, directoryInfoCount++;
                    }
                }
            }
            
            closedir(dir);
            
            //-------Directory Sort------
            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
            
            for (int counter1 = 0; counter1 < directoryInfoCount; counter1++){
                [unsortedArray addObject:@(arrayDirectoryInfo [counter1].c_str())];
            }
            
            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
            
            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                arrayDirectoryInfo [counter1] = [unsortedArray [counter1] UTF8String];
            }
        }
    }
    
    if (column == 1){
        NSString *path;
        path = [sender path];
        
        string imageFolderPath = imageDataPath+[path UTF8String]+"_Image";
        string imageFolderPath2 = "";
        string imageNameTemp = [path UTF8String];
        
        if (imageNameTemp != ""){
            imageNameTemp = imageNameTemp.substr(1);
            
            dir = opendir(imageFolderPath.c_str());
            
            if (dir != NULL){
                string entry;
                
                while((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if ((int)entry.find("_Stitch") != -1){
                            if (directoryInfoCount+2 > directoryInfoLimit) [self directoryInfoUpDate];
                            
                            entry = entry.substr(0, entry.find("_Stitch"));
                            
                            arrayDirectoryInfo [directoryInfoCount] = entry, directoryInfoCount++;
                        }
                    }
                }
                
                closedir(dir);
                
                //-------Directory Sort------
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < directoryInfoCount; counter1++){
                    [unsortedArray addObject:@(arrayDirectoryInfo [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arrayDirectoryInfo [counter1] = [unsortedArray [counter1] UTF8String];
                }
            }
        }
    }
    
    return directoryInfoCount;
}

-(void)browser:(NSBrowser *)sender willDisplayCell:(id)cell atRow:(int)row column:(int)column{
    if (column == 0){
        string folderName = arrayDirectoryInfo [row];
        [cell setStringValue: @(folderName.c_str())];
        [cell setLoaded:YES];
    }
    if (column == 1){
        string folderName = arrayDirectoryInfo [row];
        [cell setStringValue: @(folderName.c_str())];
        [cell setLeaf:YES];
    }
}

-(IBAction)browserDoubleClick:(id)browser{
    NSString *nodePath = [browser path];
    string nodePathString = [nodePath UTF8String];
    
    if (nodePathString != "" && movieRunningFlag == 0 && imageProgressFlag == 0){
        nodePathString = nodePathString.substr(1);
        
        if ((int)nodePathString.find("/") != -1){
            analysisNameHold = nodePathString.substr(0, nodePathString.find("/"));
            treatNameHold = nodePathString.substr(nodePathString.find("/")+1);
            
            imageDisplayPath = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Stitch";
            
            string imageNo;
            string imageNoTemp;
            string firstImageName = "";
            int maxNoTemp = 0;
            
            lastDICImageTime = 0;
            lastTIFRoundNo = 0;
            
            DIR *dir;
            struct dirent *dent;
            
            dir = opendir(imageDisplayPath.c_str());
            
            if (dir != NULL){
                string entry;
                
                while((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if ((int)entry.find("STimage") != -1){
                            imageNoTemp = entry.substr(8, 4);
                            
                            if (atoi(imageNoTemp.c_str()) > maxNoTemp) maxNoTemp = atoi(imageNoTemp.c_str());
                            
                            if ((int)entry.find("tif") != -1 || (int)entry.find("TIF") != -1){
                                if ((int)entry.find("TIF") == -1 && lastDICImageTime < atoi(imageNoTemp.c_str())){
                                    lastDICImageTime = atoi(imageNoTemp.c_str());
                                }
                                if ((int)entry.find("TIF") != -1 && lastTIFRoundNo < atoi(entry.substr(entry.find("TIF")+3).c_str())){
                                    lastTIFRoundNo = atoi(entry.substr(entry.find("TIF")+3).c_str());
                                }
                            }
                            else if ((int)entry.find("bmp") != -1 || (int)entry.find("BMP") != -1){
                                if ((int)entry.find("BMP") == -1 && lastDICImageTime < atoi(imageNoTemp.c_str())){
                                    lastDICImageTime = atoi(imageNoTemp.c_str());
                                }
                                if ((int)entry.find("BMP") != -1 && lastTIFRoundNo < atoi(entry.substr(entry.find("BMP")+3).c_str())){
                                    lastTIFRoundNo = atoi(entry.substr(entry.find("BMP")+3).c_str());
                                }
                            }
                            
                            if (firstImageName == "") firstImageName = entry;
                        }
                    }
                }
                
                closedir(dir);
            }
            
            if (maxNoTemp > 0 && lastDICImageTime != 0){
                maxImageNo = maxNoTemp;
                currentImageNo = 1;
                
                string movieSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CMBasic";
                
                ofstream oin;
                oin.open(movieSettingPath.c_str(),ios::out);
                oin<<speedHold<<endl;
                oin<<orientationHold<<endl;
                oin.close();
                
                if (fileListStatus == 1){
                    delete [] fileList;
                    delete [] fileList2;
                }
                
                fileList = new string [maxNoTemp*7+4];
                fileListCount = 0;
                
                fileList2 = new string [maxNoTemp*7+4];
                fileListCount2 = 0;
                
                string *fileListTemp = new string [maxNoTemp*7+4];
                int fileListTempCount = 0;
                
                dir = opendir(imageDisplayPath.c_str());
                
                if (dir != NULL){
                    string entry;
                    
                    while((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find("STimage") != -1){
                                fileListTemp [fileListTempCount] = entry, fileListTempCount++;
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                
                //-------Directory Sort------
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < fileListTempCount; counter1++){
                    [unsortedArray addObject:@(fileListTemp [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    fileListTemp [counter1] = [unsortedArray [counter1] UTF8String];
                }
                
                for (int counter1 = 0; counter1 < fileListTempCount; counter1++){
                    if ((int)fileListTemp [counter1].find("_") == -1){
                        fileList [fileListCount] = fileListTemp [counter1], fileListCount++;
                        fileList [fileListCount] = "", fileListCount++;
                        fileList [fileListCount] = "", fileListCount++;
                        fileList [fileListCount] = "", fileListCount++;
                        fileList [fileListCount] = "", fileListCount++;
                        fileList [fileListCount] = "", fileListCount++;
                        fileList [fileListCount] = "", fileListCount++;
                    }
                }
                
                int  timePosition = 0;
                
                for (int counter1 = 0; counter1 < fileListTempCount; counter1++){
                    if ((int)fileListTemp [counter1].find("_1_") != -1 || (int)fileListTemp [counter1].find("_2_") != -1 || (int)fileListTemp [counter1].find("_3_") != -1 || (int)fileListTemp [counter1].find("_4_") != -1 || (int)fileListTemp [counter1].find("_5_") != -1 || (int)fileListTemp [counter1].find("_6_") != -1 || (int)fileListTemp [counter1].find("_7_") != -1 || (int)fileListTemp [counter1].find("_8_") != -1 || (int)fileListTemp [counter1].find("_9_") != -1){
                        timePosition = atoi(fileListTemp [counter1].substr(fileListTemp [counter1].find("STimage ")+8, 4).c_str())-1;
                        
                        if (fileList [timePosition*7+1] == "") fileList [timePosition*7+1] = fileListTemp [counter1];
                        else if (fileList [timePosition*7+2] == "") fileList [timePosition*7+2] = fileListTemp [counter1];
                        else if (fileList [timePosition*7+3] == "") fileList [timePosition*7+3] = fileListTemp [counter1];
                        else if (fileList [timePosition*7+4] == "") fileList [timePosition*7+4] = fileListTemp [counter1];
                        else if (fileList [timePosition*7+5] == "") fileList [timePosition*7+5] = fileListTemp [counter1];
                        else if (fileList [timePosition*7+6] == "") fileList [timePosition*7+6] = fileListTemp [counter1];
                    }
                }
                
                delete [] fileListTemp;
                
                timePointHold = 1;
                
                firstImageName = fileList [0];
                
                string firstImagePath = imageDisplayPath+"/"+firstImageName;
                
                imageXYLength = 0;
                
                ifstream fin;
                
                if ((int)firstImageName.find("tif") != -1 || (int)firstImageName.find("TIF") != -1){
                    imageBmpTifFlag = 0;
                    
                    //------Tiff reading------
                    unsigned long stripFirstAddress = 0;
                    unsigned long stripByteCountAddress = 0;
                    unsigned long nextAddress = 0;
                    unsigned long headPosition = 0;
                    unsigned long stripEntry = 0;
                    long sizeForCopy = 0;
                    
                    double xPosition = 0;
                    double yPosition = 0;
                    
                    int imageWidth = 0;
                    int imageHeight = 0;
                    int imageBit = 0; // Check 8, 16
                    int imageCompression = 0; // Check 1
                    int photoMetric = 0;//check 0, 1, 2
                    int endianType = 0;
                    int samplePerPix = 0;
                    int dataConversion [4];
                    int numberOfLayers = 0;
                    
                    struct stat sizeOfFile;
                    
                    if (stat(firstImagePath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        fileReadArray = new uint8_t [sizeForCopy+50];
                        fin.open(firstImagePath.c_str(), ios::in | ios::binary);
                        
                        fin.read((char*)fileReadArray, sizeForCopy+50);
                        fin.close();
                        
                        dataConversion [0] = fileReadArray [0];
                        dataConversion [1] = fileReadArray [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = fileReadArray [7];
                            dataConversion [1] = fileReadArray [6];
                            dataConversion [2] = fileReadArray [5];
                            dataConversion [3] = fileReadArray [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = fileReadArray [4];
                            dataConversion [1] = fileReadArray [5];
                            dataConversion [2] = fileReadArray [6];
                            dataConversion [3] = fileReadArray [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        if (endianType == 1){
                            tiffFileRead = [[TiffFileRead alloc] init];
                            [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                        }
                        else if (endianType == 0){
                            tiffFileRead = [[TiffFileRead alloc] init];
                            [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                        }
                        
                        if (photoMetric <= 1){
                            grayColorStatus = 0;
                            [chColor setTextColor:[NSColor whiteColor]];
                            [chColor setStringValue:@"Color"];
                        }
                        else if (photoMetric == 2){
                            grayColorStatus = 1;
                            [chColor setTextColor:[NSColor redColor]];
                            [chColor setStringValue:@"Color"];
                        }
                        
                        imageXYLength = imageWidth;
                        
                        delete [] fileReadArray;
                    }
                }
                else if ((int)firstImageName.find("bmp") != -1 || (int)firstImageName.find("BMP") != -1){
                    imageBmpTifFlag = 1;
                    
                    int bitPosition = 0;
                    int bitData = 0;
                    int verticalBit [4];
                    
                    fin.open(firstImagePath.c_str(),ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        while((bitData = fin.get()) != EOF){
                            if (bitPosition == 22) verticalBit [0] = bitData;
                            if (bitPosition == 23) verticalBit [1] = bitData;
                            if (bitPosition == 24) verticalBit [2] = bitData;
                            if (bitPosition == 25){
                                verticalBit [3] = bitData;
                                imageXYLength = verticalBit [3]*16777216+verticalBit [2]*65536+verticalBit [1]*256+verticalBit [0];
                                break;
                            }
                            
                            bitPosition++;
                        }
                        
                        fin.close();
                    }
                    
                    grayColorStatus = 0;
                    [chColor setTextColor:[NSColor whiteColor]];
                    [chColor setStringValue:@"Color"];
                }
                
                if (imageXYLength != 0){
                    phaseStatus = 0;
                    areaModeStatusHold = 0;
                    
                    [areaModeDisplay setStringValue:@"Off"];
                    [colorRefStatusDisplay setStringValue:@"Off"];
                    
                    fileListStatus = 1;
                    filePosition = 1;
                    
                    struct stat sizeOfFile;
                    
                    uploadTempFileSize = 0;
                    
                    if (stat(firstImagePath.c_str(), &sizeOfFile) == 0){
                        uploadTempFileSize = sizeOfFile.st_size;
                    }
                    
                    if (uploadTempStatus == 1) delete [] uploadTemp;
                    
                    uploadTemp = new uint8_t [uploadTempFileSize+50];
                    
                    uploadTempStatus = 1;
                    
                    fin.open(firstImagePath.c_str(), ios::in | ios::binary);
                    
                    fin.read((char*)uploadTemp, (long)uploadTempFileSize+50);
                    fin.close();
                    
                    int mode = 0;
                    
                    if (fileList [(filePosition-1)*7+1] != ""){
                        [self setCH1:mode];
                        
                        if (fileList [(filePosition-1)*7+2] != ""){
                            [self setCH2:mode];
                            
                            if (fileList [(filePosition-1)*7+3] != ""){
                                [self  setCH3:mode];
                                
                                if (fileList [(filePosition-1)*7+4] != ""){
                                    [self setCH4:mode];
                                    
                                    if (fileList [(filePosition-1)*7+5] != ""){
                                        [self setCH5:mode];
                                        
                                        if (fileList [(filePosition-1)*7+6] != "") [self setCH6:mode];
                                        else{
                                            
                                            if (uploadTempStatusCl6 == 1){
                                                delete [] uploadTempCl6;
                                                uploadTempStatusCl6 = 0;
                                            }
                                        }
                                    }
                                    else{
                                        
                                        if (uploadTempStatusCl5 == 1){
                                            delete [] uploadTempCl5;
                                            uploadTempStatusCl5 = 0;
                                        }
                                        
                                        if (uploadTempStatusCl6 == 1){
                                            delete [] uploadTempCl6;
                                            uploadTempStatusCl6 = 0;
                                        }
                                    }
                                }
                                else{
                                    
                                    if (uploadTempStatusCl4 == 1){
                                        delete [] uploadTempCl4;
                                        uploadTempStatusCl4 = 0;
                                    }
                                    
                                    if (uploadTempStatusCl5 == 1){
                                        delete [] uploadTempCl5;
                                        uploadTempStatusCl5 = 0;
                                    }
                                    
                                    if (uploadTempStatusCl6 == 1){
                                        delete [] uploadTempCl6;
                                        uploadTempStatusCl6 = 0;
                                    }
                                }
                            }
                            else{
                                
                                if (uploadTempStatusCl3 == 1){
                                    delete [] uploadTempCl3;
                                    uploadTempStatusCl3 = 0;
                                }
                                
                                if (uploadTempStatusCl4 == 1){
                                    delete [] uploadTempCl4;
                                    uploadTempStatusCl4 = 0;
                                }
                                
                                if (uploadTempStatusCl5 == 1){
                                    delete [] uploadTempCl5;
                                    uploadTempStatusCl5 = 0;
                                }
                                
                                if (uploadTempStatusCl6 == 1){
                                    delete [] uploadTempCl6;
                                    uploadTempStatusCl6 = 0;
                                }
                            }
                        }
                        else{
                            
                            if (uploadTempStatusCl2 == 1){
                                delete [] uploadTempCl2;
                                uploadTempStatusCl2 = 0;
                            }
                            
                            if (uploadTempStatusCl3 == 1){
                                delete [] uploadTempCl3;
                                uploadTempStatusCl3 = 0;
                            }
                            
                            if (uploadTempStatusCl4 == 1){
                                delete [] uploadTempCl4;
                                uploadTempStatusCl4 = 0;
                            }
                            
                            if (uploadTempStatusCl5 == 1){
                                delete [] uploadTempCl5;
                                uploadTempStatusCl5 = 0;
                            }
                            
                            if (uploadTempStatusCl6 == 1){
                                delete [] uploadTempCl6;
                                uploadTempStatusCl6 = 0;
                            }
                        }
                    }
                    else{
                        
                        if (uploadTempStatusCl1 == 1){
                            delete [] uploadTempCl1;
                            uploadTempStatusCl1 = 0;
                        }
                        
                        if (uploadTempStatusCl2 == 1){
                            delete [] uploadTempCl2;
                            uploadTempStatusCl2 = 0;
                        }
                        
                        if (uploadTempStatusCl3 == 1){
                            delete [] uploadTempCl3;
                            uploadTempStatusCl3 = 0;
                        }
                        
                        if (uploadTempStatusCl4 == 1){
                            delete [] uploadTempCl4;
                            uploadTempStatusCl4 = 0;
                        }
                        
                        if (uploadTempStatusCl5 == 1){
                            delete [] uploadTempCl5;
                            uploadTempStatusCl5 = 0;
                        }
                        
                        if (uploadTempStatusCl6 == 1){
                            delete [] uploadTempCl6;
                            uploadTempStatusCl6 = 0;
                        }
                        
                        if (colorFlag1 != 0){
                            [self resetSubCH1];
                        }
                    }
                    
                    [analysisName setStringValue:@(analysisNameHold.c_str())];
                    [treatment setStringValue:@(treatNameHold.c_str())];
                    [timePoint setIntegerValue:currentImageNo];
                    
                    string dataSaveTreatmentPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold";
                    
                    fin.open(dataSavePath.c_str(),ios::in);
                    
                    if (fin.is_open()){
                        fin.close();
                        
                        fin.open(dataSaveTreatmentPath.c_str(),ios::in);
                        
                        if (fin.is_open()){
                            fin.close();
                            string getString;
                            
                            string dataSaveTreatmentPath3 = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"AnalysisData";
                            
                            int terminationFlag = 0;
                            areaDataHoldCount = 0;
                            
                            fin.open(dataSaveTreatmentPath3.c_str(),ios::in);
                            
                            if (fin.is_open()){
                                do{
                                    
                                    terminationFlag = 1;
                                    
                                    getline(fin, getString);
                                    
                                    if (getString != ""){
                                        if (areaDataHoldLimit < areaDataHoldCount+50) [self arrayAreaDataHoldUpDate];
                                        
                                        arrayAreaDataHold [areaDataHoldCount] = atof(getString.c_str()), areaDataHoldCount++;
                                    }
                                    else terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                                
                                fin.close();
                            }
                            
                            string dataSaveTreatmentPath4 = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"DotData";
                            
                            dotDataHoldCount = 0;
                            
                            fin.open(dataSaveTreatmentPath4.c_str(),ios::in);
                            
                            if (fin.is_open()){
                                do{
                                    
                                    terminationFlag = 1;
                                    
                                    getline(fin, getString);
                                    
                                    if (getString != ""){
                                        if (dotDataHoldLimit < dotDataHoldCount+50) [self arrayDotDataHoldUpDate];
                                        
                                        arrayDotDataHold [dotDataHoldCount] = atoi(getString.c_str()), dotDataHoldCount++;
                                    }
                                    else terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                                
                                fin.close();
                            }
                            
                            boxXLength = (int)(arrayAreaDataHold [6]);
                            boxYLength = (int)(arrayAreaDataHold [7]);
                            boxXPosition = arrayAreaDataHold [8];
                            boxYPosition = arrayAreaDataHold [9];
                            
                            dotNumberCurrent = 0;
                            
                            int timeTemp = 0;
                            
                            for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                                if (arrayDotDataHold [counter1*3] < -100000) timeTemp = arrayDotDataHold [counter1*3]*-1-100000;
                                else if (arrayDotDataHold [counter1*3] < 0 && arrayDotDataHold [counter1*3] >= -100000) timeTemp = arrayDotDataHold [counter1*3]*-1;
                                else if (arrayDotDataHold [counter1*3] >= 0 && arrayDotDataHold [counter1*3] <= 100000) timeTemp = arrayDotDataHold [counter1*3];
                                else if (arrayDotDataHold [counter1*3] > 100000) timeTemp = arrayDotDataHold [counter1*3]-100000;
                                
                                if (timeTemp == timePointHold) dotNumberCurrent++;
                            }
                            
                            if (boxXLength != 0 && boxYLength != 0){
                                string dimensionXY = to_string(boxXLength)+" x "+to_string(boxYLength);
                                [boxDimensionDisplay setStringValue:@(dimensionXY.c_str())];
                            }
                            else [boxDimensionDisplay setStringValue:@"nil x nil"];
                            
                            if (areaModeStatusHold == 1){
                                areaSetDone = 0;
                                
                                string extension = to_string(timePointHold);
                                
                                if (extension.length() == 1) extension = "000"+extension;
                                else if (extension.length() == 2) extension = "00"+extension;
                                else if (extension.length() == 3) extension = "0"+extension;
                                
                                string connectDataPath = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Processed/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_MasterData";
                                string connectDataRevPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_MasterData";
                                
                                long sizeForCopy = 0;
                                long sizeForCopy2 = 0;
                                long size1 = 0;
                                long size2 = 0;
                                int checkFlag = 0;
                                
                                for (int counter1 = 0; counter1 < 6; counter1++){
                                    sizeForCopy = 0;
                                    
                                    if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                    }
                                    else if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                    }
                                    
                                    if (sizeForCopy != 0){
                                        if (counter1 == 0) size1 = sizeForCopy;
                                        else if (counter1 == 1) size2 = sizeForCopy;
                                        else if (counter1 == 2){
                                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                checkFlag = 1;
                                                break;
                                            }
                                            else{
                                                
                                                size1 = 0;
                                                size2 = 0;
                                                usleep (50000);
                                            }
                                        }
                                        else if (counter1 == 3) size1 = sizeForCopy;
                                        else if (counter1 == 4) size2 = sizeForCopy;
                                        else if (counter1 == 5){
                                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                checkFlag = 1;
                                            }
                                        }
                                    }
                                }
                                
                                if (checkFlag == 1){
                                    int errorFlag = 0;
                                    
                                    delete [] arrayPositionRevise;
                                    arrayPositionRevise = new int [sizeForCopy+50];
                                    positionReviseCount = 0;
                                    positionReviseLimit = (int)sizeForCopy+50;
                                    
                                    sizeForCopy2 = (long)(sizeForCopy*(double)0.1+50);
                                    delete [] arrayGravityCenterRev;
                                    arrayGravityCenterRev = new int [sizeForCopy2+50];
                                    gravityCenterRevCount = 0;
                                    gravityCenterRevLimit = (int)sizeForCopy2+50;
                                    
                                    fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        int finData [17];
                                        
                                        uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                        fin.read((char*)uploadTempA, sizeForCopy+50);
                                        
                                        if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 || (finData [0] = uploadTempA [sizeForCopy-12]) != 0){
                                            usleep(50000);
                                            fin.read((char*)uploadTempA, sizeForCopy+50);
                                            
                                            if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 || (finData [0] = uploadTempA [sizeForCopy-12]) != 0){
                                                usleep(50000);
                                                fin.read((char*)uploadTempA, sizeForCopy+50);
                                                
                                                if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 || (finData [0] = uploadTempA [sizeForCopy-12]) != 0){
                                                    errorFlag = 1;
                                                }
                                            }
                                        }
                                        
                                        fin.close();
                                        
                                        
                                        if (errorFlag == 0){
                                            unsigned long readPosition = 0;
                                            int stepCount = 0;
                                            
                                            do{
                                                
                                                if (stepCount == 0){
                                                    finData [0] = uploadTempA [readPosition], readPosition++;
                                                    finData [1] = uploadTempA [readPosition], readPosition++; //--1
                                                    finData [2] = uploadTempA [readPosition], readPosition++;
                                                    finData [3] = uploadTempA [readPosition], readPosition++; //--2
                                                    finData [4] = uploadTempA [readPosition], readPosition++; //--3
                                                    finData [5] = uploadTempA [readPosition], readPosition++;
                                                    finData [6] = uploadTempA [readPosition], readPosition++;
                                                    finData [7] = uploadTempA [readPosition], readPosition++; //--4
                                                    finData [8] = uploadTempA [readPosition], readPosition++; //--+/- flag
                                                    finData [9] = uploadTempA [readPosition], readPosition++;
                                                    finData [10] = uploadTempA [readPosition], readPosition++;
                                                    finData [11] = uploadTempA [readPosition], readPosition++;
                                                    finData [12] = uploadTempA [readPosition], readPosition++; //--5
                                                    finData [13] = uploadTempA [readPosition], readPosition++; //--6
                                                    finData [14] = uploadTempA [readPosition], readPosition++;
                                                    finData [15] = uploadTempA [readPosition], readPosition++;
                                                    finData [16] = uploadTempA [readPosition], readPosition++; //--7
                                                    
                                                    finData [1] = finData [0]*256+finData [1];
                                                    finData [3] = finData [2]*256+finData [3];
                                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                    
                                                    if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                                    else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                                    
                                                    finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                                    
                                                    if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                                    else{
                                                        
                                                        arrayPositionRevise [positionReviseCount] = finData [1], positionReviseCount++;
                                                        arrayPositionRevise [positionReviseCount] = finData [3], positionReviseCount++;
                                                        arrayPositionRevise [positionReviseCount] = finData [4], positionReviseCount++;
                                                        arrayPositionRevise [positionReviseCount] = finData [7], positionReviseCount++;
                                                        arrayPositionRevise [positionReviseCount] = finData [12], positionReviseCount++;
                                                        arrayPositionRevise [positionReviseCount] = finData [13], positionReviseCount++;
                                                        arrayPositionRevise [positionReviseCount] = finData [16], positionReviseCount++;
                                                    }
                                                }
                                                else if (stepCount == 1){
                                                    finData [0] = uploadTempA [readPosition], readPosition++;
                                                    finData [1] = uploadTempA [readPosition], readPosition++; //--1
                                                    finData [2] = uploadTempA [readPosition], readPosition++;
                                                    finData [3] = uploadTempA [readPosition], readPosition++; //--2
                                                    finData [4] = uploadTempA [readPosition], readPosition++;
                                                    finData [5] = uploadTempA [readPosition], readPosition++;
                                                    finData [6] = uploadTempA [readPosition], readPosition++; //--3
                                                    finData [7] = uploadTempA [readPosition], readPosition++; //--4
                                                    finData [8] = uploadTempA [readPosition], readPosition++;
                                                    finData [9] = uploadTempA [readPosition], readPosition++;
                                                    finData [10] = uploadTempA [readPosition], readPosition++; //--5
                                                    finData [11] = uploadTempA [readPosition], readPosition++; //--6
                                                    
                                                    finData [1] = finData [0]*256+finData [1];
                                                    finData [3] = finData [2]*256+finData [3];
                                                    finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                                    finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                                    
                                                    if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                                    else{
                                                        
                                                        if (gravityCenterRevCount+1 > gravityCenterRevLimit) [self gravityCenterRevUpDate];
                                                        
                                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [1], gravityCenterRevCount++;
                                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [3], gravityCenterRevCount++;
                                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [6], gravityCenterRevCount++;
                                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [7], gravityCenterRevCount++;
                                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [10], gravityCenterRevCount++;
                                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [11], gravityCenterRevCount++;
                                                    }
                                                }
                                                
                                            } while (stepCount != 3);
                                        }
                                        
                                        delete [] uploadTempA;
                                    }
                                    else{
                                        
                                        fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            int finData [11];
                                            
                                            uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                            fin.read((char*)uploadTempA, sizeForCopy+50);
                                            
                                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                                                usleep(50000);
                                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                                
                                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                                                    usleep(50000);
                                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                                    
                                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 ){
                                                        errorFlag = 1;
                                                    }
                                                }
                                            }
                                            
                                            fin.close();
                                            
                                            if (errorFlag == 0){
                                                unsigned long readPosition = 0;
                                                int stepCount = 0;
                                                
                                                do{
                                                    
                                                    if (stepCount == 0){
                                                        finData [0] = uploadTempA [readPosition], readPosition++;
                                                        finData [1] = uploadTempA [readPosition], readPosition++; //--2
                                                        finData [2] = uploadTempA [readPosition], readPosition++;
                                                        finData [3] = uploadTempA [readPosition], readPosition++; //--2
                                                        finData [4] = uploadTempA [readPosition], readPosition++; //--1
                                                        finData [5] = uploadTempA [readPosition], readPosition++;
                                                        finData [6] = uploadTempA [readPosition], readPosition++;
                                                        finData [7] = uploadTempA [readPosition], readPosition++; //--3
                                                        finData [8] = uploadTempA [readPosition], readPosition++; //--1
                                                        finData [9] = uploadTempA [readPosition], readPosition++;
                                                        
                                                        finData [1] = finData [0]*256+finData [1];
                                                        finData [3] = finData [2]*256+finData [3];
                                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                        
                                                        if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                                        else{
                                                            
                                                            arrayPositionRevise [positionReviseCount] = finData [1], positionReviseCount++; //------X position------
                                                            arrayPositionRevise [positionReviseCount] = finData [3], positionReviseCount++; //------Y position------
                                                            arrayPositionRevise [positionReviseCount] = finData [4], positionReviseCount++; //------Value------
                                                            arrayPositionRevise [positionReviseCount] = finData [7], positionReviseCount++; //------Connect No------
                                                            arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //------Cell No------
                                                            arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //------Status------
                                                            arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //------Lineage no------
                                                        }
                                                    }
                                                    else if (stepCount == 1){
                                                        finData [0] = uploadTempA [readPosition], readPosition++;
                                                        finData [1] = uploadTempA [readPosition], readPosition++;
                                                        finData [2] = uploadTempA [readPosition], readPosition++; //--1
                                                        finData [3] = uploadTempA [readPosition], readPosition++; //--2
                                                        finData [4] = uploadTempA [readPosition], readPosition++; //--3
                                                        finData [5] = uploadTempA [readPosition], readPosition++;
                                                        finData [6] = uploadTempA [readPosition], readPosition++;
                                                        finData [7] = uploadTempA [readPosition], readPosition++; //--4
                                                        finData [8] = uploadTempA [readPosition], readPosition++;
                                                        finData [9] = uploadTempA [readPosition], readPosition++; //--5
                                                        finData [10] = uploadTempA [readPosition], readPosition++; //--6
                                                        
                                                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                        finData [9] = finData [8]*256+finData [9];
                                                        
                                                        if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                                    }
                                                    else if (stepCount == 2){
                                                        finData [0] = uploadTempA [readPosition], readPosition++;
                                                        finData [1] = uploadTempA [readPosition], readPosition++; //--1
                                                        finData [2] = uploadTempA [readPosition], readPosition++;
                                                        finData [3] = uploadTempA [readPosition], readPosition++; //--2
                                                        finData [4] = uploadTempA [readPosition], readPosition++;
                                                        finData [5] = uploadTempA [readPosition], readPosition++;
                                                        finData [6] = uploadTempA [readPosition], readPosition++; //--3
                                                        finData [7] = uploadTempA [readPosition], readPosition++; //--4
                                                        finData [8] = uploadTempA [readPosition], readPosition++;
                                                        finData [9] = uploadTempA [readPosition], readPosition++;
                                                        finData [10] = uploadTempA [readPosition], readPosition++; //--5
                                                        
                                                        finData [1] = finData [0]*256+finData [1];
                                                        finData [3] = finData [2]*256+finData [3];
                                                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                                        finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                                        
                                                        if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                                        else{
                                                            
                                                            if (gravityCenterRevCount+1 > gravityCenterRevLimit) [self gravityCenterRevUpDate];
                                                            
                                                            arrayGravityCenterRev [gravityCenterRevCount] = finData [1], gravityCenterRevCount++;
                                                            arrayGravityCenterRev [gravityCenterRevCount] = finData [3], gravityCenterRevCount++;
                                                            arrayGravityCenterRev [gravityCenterRevCount] = finData [6], gravityCenterRevCount++;
                                                            arrayGravityCenterRev [gravityCenterRevCount] = finData [7], gravityCenterRevCount++;
                                                            arrayGravityCenterRev [gravityCenterRevCount] = finData [10], gravityCenterRevCount++;
                                                            arrayGravityCenterRev [gravityCenterRevCount] = 0, gravityCenterRevCount++;
                                                        }
                                                    }
                                                    
                                                } while (stepCount != 3);
                                            }
                                            
                                            delete [] uploadTempA;
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
                                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
                                    //    cout<<" arrayGravityCenterRev "<<counterA<<endl;
                                    //}
                                    
                                    if (errorFlag == 0){
                                        //------Master Data Status UpLoad------
                                        string connectStatusDataPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_Status";
                                        
                                        sizeForCopy = 0;
                                        
                                        if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                                            sizeForCopy = sizeOfFile.st_size;
                                        }
                                        
                                        if (sizeForCopy < gravityCenterRevCount*2) sizeForCopy = gravityCenterRevCount*2;
                                        
                                        delete [] arrayTimeSelected;
                                        arrayTimeSelected = new int [sizeForCopy+50];
                                        timeSelectedCount = 0;
                                        timeSelectedLimit = (int)sizeForCopy+50;
                                        
                                        int firstRead = 0;
                                        errorFlag = 0;
                                        
                                        fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            int finData [19];
                                            
                                            uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                            fin.read((char*)uploadTempA, sizeForCopy+50);
                                            
                                            if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 || (finData [0] = uploadTempA [sizeForCopy-12]) != 0 || (finData [0] = uploadTempA [sizeForCopy-13]) != 0 || (finData [0] = uploadTempA [sizeForCopy-14]) != 0 || (finData [0] = uploadTempA [sizeForCopy-15]) != 0 || (finData [0] = uploadTempA [sizeForCopy-16]) != 0 || (finData [0] = uploadTempA [sizeForCopy-17]) != 0 || (finData [0] = uploadTempA [sizeForCopy-18]) != 0 || (finData [0] = uploadTempA [sizeForCopy-19]) != 0){
                                                usleep(50000);
                                                fin.read((char*)uploadTempA, sizeForCopy+50);
                                                
                                                if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 || (finData [0] = uploadTempA [sizeForCopy-12]) != 0 || (finData [0] = uploadTempA [sizeForCopy-13]) != 0 || (finData [0] = uploadTempA [sizeForCopy-14]) != 0 || (finData [0] = uploadTempA [sizeForCopy-15]) != 0 || (finData [0] = uploadTempA [sizeForCopy-16]) != 0 || (finData [0] = uploadTempA [sizeForCopy-17]) != 0 || (finData [0] = uploadTempA [sizeForCopy-18]) != 0 || (finData [0] = uploadTempA [sizeForCopy-19]) != 0){
                                                    errorFlag = 1;
                                                }
                                            }
                                            
                                            fin.close();
                                            
                                            if (errorFlag == 0){
                                                unsigned long readPosition = 0;
                                                int stepCount = 0;
                                                
                                                do{
                                                    
                                                    if (stepCount == 0){
                                                        finData [0] = uploadTempA [readPosition], readPosition++; //--1 Status
                                                        finData [1] = uploadTempA [readPosition], readPosition++;
                                                        finData [2] = uploadTempA [readPosition], readPosition++;
                                                        finData [3] = uploadTempA [readPosition], readPosition++; //--3 Prev connect
                                                        finData [4] = uploadTempA [readPosition], readPosition++;
                                                        finData [5] = uploadTempA [readPosition], readPosition++;
                                                        finData [6] = uploadTempA [readPosition], readPosition++; //--4 Start position
                                                        finData [7] = uploadTempA [readPosition], readPosition++;
                                                        finData [8] = uploadTempA [readPosition], readPosition++; //--5 Cut no
                                                        finData [9] = uploadTempA [readPosition], readPosition++; //--6 Ch2
                                                        finData [10] = uploadTempA [readPosition], readPosition++; //--7 Ch3
                                                        finData [11] = uploadTempA [readPosition], readPosition++; //--8 Ch4
                                                        finData [12] = uploadTempA [readPosition], readPosition++; //--9 Ch5
                                                        finData [13] = uploadTempA [readPosition], readPosition++;
                                                        finData [14] = uploadTempA [readPosition], readPosition++;
                                                        finData [15] = uploadTempA [readPosition], readPosition++; //--10 Connect no.
                                                        finData [16] = uploadTempA [readPosition], readPosition++;
                                                        finData [17] = uploadTempA [readPosition], readPosition++;
                                                        finData [18] = uploadTempA [readPosition], readPosition++; //--11 Ling no.
                                                        
                                                        finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                                                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                                        finData [8] = finData [7]*256+finData [8];
                                                        finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                                                        finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                                                        
                                                        if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                                                        else{
                                                            
                                                            arrayTimeSelected [timeSelectedCount] = finData [0], timeSelectedCount++; //------Selected, removed, eliminated status------
                                                            arrayTimeSelected [timeSelectedCount] = finData [3], timeSelectedCount++; //------When new line is created, enter line number which creates------
                                                            arrayTimeSelected [timeSelectedCount] = finData [6], timeSelectedCount++; //------PositionRevise Start------
                                                            arrayTimeSelected [timeSelectedCount] = finData [8], timeSelectedCount++; //------Cut line number------
                                                            arrayTimeSelected [timeSelectedCount] = finData [9], timeSelectedCount++; //------X Start------
                                                            arrayTimeSelected [timeSelectedCount] = finData [10], timeSelectedCount++; //------X End------
                                                            arrayTimeSelected [timeSelectedCount] = finData [11], timeSelectedCount++; //------Y Start------
                                                            arrayTimeSelected [timeSelectedCount] = finData [12], timeSelectedCount++; //------Y End------
                                                            arrayTimeSelected [timeSelectedCount] = finData [15], timeSelectedCount++; //------Connect------
                                                            arrayTimeSelected [timeSelectedCount] = finData [18], timeSelectedCount++; //------Lineage------
                                                        }
                                                    }
                                                    
                                                } while (stepCount != 3);
                                            }
                                            
                                            delete [] uploadTempA;
                                        }
                                        else{
                                            
                                            firstRead = 1;
                                            
                                            for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){ //------Counter number corresponds to connect No------
                                                arrayTimeSelected [timeSelectedCount] = 1, timeSelectedCount++; //------Selected, removed, eliminated status------
                                                arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------When new line is created, enter line number which creates------
                                                arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------PositionRevise Start------
                                                arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------Cut line number------
                                                arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------X Start------
                                                arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------X End------
                                                arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------Y Start------
                                                arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------Y End------
                                                arrayTimeSelected [timeSelectedCount] = counter1+1, timeSelectedCount++; //------Connect------
                                                arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------Lineage------
                                            }
                                            
                                            int valueTemp = 0;
                                            
                                            for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                                                if (arrayPositionRevise [counter1*7+3] != valueTemp){
                                                    valueTemp = arrayPositionRevise [counter1*7+3];
                                                    arrayTimeSelected [(valueTemp-1)*10+2] = counter1;
                                                    
                                                    if (arrayPositionRevise [counter1*7+5] == 0){
                                                        arrayTimeSelected [(valueTemp-1)*10] = 0;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                                        //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                                        //    cout<<" arrayTimeSelected "<<counterA<<endl;
                                        //}
                                        
                                        if (errorFlag == 0){
                                            string sourceImagePath = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+extension+".bmp";
                                            string mapPath = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Processed/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_Map";
                                            string revisedMapPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_RevisedMap";
                                            
                                            for (int counter1 = 0; counter1 < imageSizeLimit+1; counter1++){
                                                delete [] sourceImage [counter1];
                                                delete [] revisedMap [counter1];
                                                delete [] revisedWorkingMap [counter1];
                                                delete [] connectMap200 [counter1];
                                                delete [] connectMap220 [counter1];
                                                delete [] connectMap240 [counter1];
                                                delete [] connectMapA [counter1];
                                                delete [] connectMapB [counter1];
                                                delete [] connectMapC [counter1];
                                                delete [] connectMapD [counter1];
                                            }
                                            
                                            delete [] sourceImage;
                                            delete [] revisedMap;
                                            delete [] revisedWorkingMap;
                                            delete [] connectMap200;
                                            delete [] connectMap220;
                                            delete [] connectMap240;
                                            delete [] connectMapA;
                                            delete [] connectMapB;
                                            delete [] connectMapC;
                                            delete [] connectMapD;
                                            
                                            imageSizeLimit = imageXYLength;
                                            
                                            sourceImage = new int *[imageSizeLimit+1];
                                            revisedMap = new int *[imageSizeLimit+1];
                                            revisedWorkingMap = new int *[imageSizeLimit+1];
                                            connectMap200 = new int *[imageSizeLimit+1];
                                            connectMap220 = new int *[imageSizeLimit+1];
                                            connectMap240 = new int *[imageSizeLimit+1];
                                            connectMapA = new int *[imageSizeLimit+1];
                                            connectMapB = new int *[imageSizeLimit+1];
                                            connectMapC = new int *[imageSizeLimit+1];
                                            connectMapD = new int *[imageSizeLimit+1];
                                            
                                            for (int counter1 = 0; counter1 < imageSizeLimit+1; counter1++){
                                                sourceImage [counter1] = new int [imageSizeLimit+1];
                                                revisedMap [counter1] = new int [imageSizeLimit+1];
                                                revisedWorkingMap [counter1] = new int [imageSizeLimit+1];
                                                connectMap200 [counter1] = new int [imageSizeLimit+1];
                                                connectMap220 [counter1] = new int [imageSizeLimit+1];
                                                connectMap240 [counter1] = new int [imageSizeLimit+1];
                                                connectMapA [counter1] = new int [imageSizeLimit+1];
                                                connectMapB [counter1] = new int [imageSizeLimit+1];
                                                connectMapC [counter1] = new int [imageSizeLimit+1];
                                                connectMapD [counter1] = new int [imageSizeLimit+1];
                                            }
                                            
                                            if (stat(sourceImagePath.c_str(), &sizeOfFile) == 0){
                                                sizeForCopy = sizeOfFile.st_size;
                                                
                                                uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                                fin.open(sourceImagePath.c_str(), ios::in | ios::binary);
                                                
                                                if (fin.is_open()){
                                                    fin.read((char*)uploadTempA, sizeForCopy+50);
                                                    fin.close();
                                                    
                                                    int imageDimensionReadCount = 0;
                                                    
                                                    for (int counter1 = imageSizeLimit-1; counter1 >= 0; counter1--){
                                                        for (int counter2 = 0; counter2 < imageSizeLimit; counter2++){
                                                            sourceImage [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageSizeLimit+counter2];
                                                        }
                                                        
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                                
                                                delete [] uploadTempA;
                                            }
                                            
                                            //--------Map Data set-------
                                            int *connectAnalysisX = new int [imageSizeLimit*4];
                                            int *connectAnalysisY = new int [imageSizeLimit*4];
                                            int *connectAnalysisTempX = new int [imageSizeLimit*4];
                                            int *connectAnalysisTempY = new int [imageSizeLimit*4];
                                            
                                            int connectivityNumber = 0;
                                            int connectAnalysisCount = 0;
                                            int connectAnalysisTempCount = 0;
                                            int xSource = 0;
                                            int ySource = 0;
                                            int connectTemp = 0;
                                            int cutOffSet = 0;
                                            int cutOff1 = 240;
                                            int cutOff2 = 230;
                                            int cutOff3 = 220;
                                            int cutOff4 = 190;
                                            int cutOff5 = 160;
                                            int cutOff6 = 130;
                                            int cutOff7 = 90;
                                            
                                            for (int counter1 = 1; counter1 <= 7; counter1++){
                                                if (counter1 == 1) cutOffSet = cutOff1;
                                                else if (counter1 == 2) cutOffSet = cutOff2;
                                                else if (counter1 == 3) cutOffSet = cutOff3;
                                                else if (counter1 == 4) cutOffSet = cutOff4;
                                                else if (counter1 == 5) cutOffSet = cutOff5;
                                                else if (counter1 == 6) cutOffSet = cutOff6;
                                                else if (counter1 == 7) cutOffSet = cutOff7;
                                                
                                                for (int counterY = 0; counterY < imageSizeLimit; counterY++){ //------RevisedMap, temporally used--------
                                                    for (int counterX = 0; counterX < imageSizeLimit; counterX++){
                                                        if (sourceImage [counterY][counterX] == 100) revisedMap [counterY][counterX] = 0;
                                                        else if (sourceImage [counterY][counterX] < cutOffSet) revisedMap [counterY][counterX] = 0;
                                                        else revisedMap [counterY][counterX] = -150;
                                                    }
                                                }
                                                
                                                connectivityNumber = 0;
                                                
                                                for (int counterY = 0; counterY < imageSizeLimit; counterY++){
                                                    for (int counterX = 0; counterX < imageSizeLimit; counterX++){
                                                        if (revisedMap [counterY][counterX] == -150){
                                                            connectivityNumber++;
                                                            revisedMap [counterY][counterX] = connectivityNumber;
                                                            connectAnalysisCount = 0;
                                                            
                                                            if (counterY-1 >= 0 && counterX-1 >= 0 && revisedMap [counterY-1][counterX-1] == -150){
                                                                revisedMap [counterY-1][counterX-1] = connectivityNumber;
                                                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                            }
                                                            if (counterY-1 >= 0 && revisedMap [counterY-1][counterX] == -150){
                                                                revisedMap [counterY-1][counterX] = connectivityNumber;
                                                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                            }
                                                            if (counterY-1 >= 0 && counterX+1 < imageSizeLimit && revisedMap [counterY-1][counterX+1] == -150){
                                                                revisedMap [counterY-1][counterX+1] = connectivityNumber;
                                                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                            }
                                                            if (counterX+1 < imageSizeLimit && revisedMap [counterY][counterX+1] == -150){
                                                                revisedMap [counterY][counterX+1] = connectivityNumber;
                                                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                            }
                                                            if (counterY+1 < imageSizeLimit && counterX+1 < imageSizeLimit && revisedMap [counterY+1][counterX+1] == -150){
                                                                revisedMap [counterY+1][counterX+1] = connectivityNumber;
                                                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                            }
                                                            if (counterY+1 < imageSizeLimit && revisedMap [counterY+1][counterX] == -150){
                                                                revisedMap [counterY+1][counterX] = connectivityNumber;
                                                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                            }
                                                            if (counterY+1 < imageSizeLimit && counterX-1 >= 0 && revisedMap [counterY+1][counterX-1] == -150){
                                                                revisedMap [counterY+1][counterX-1] = connectivityNumber;
                                                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                            }
                                                            if (counterX-1 >= 0 && revisedMap [counterY][counterX-1] == -150){
                                                                revisedMap [counterY][counterX-1] = connectivityNumber;
                                                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                            }
                                                            
                                                            if (connectAnalysisCount != 0){
                                                                do{
                                                                    
                                                                    terminationFlag = 1;
                                                                    connectAnalysisTempCount = 0;
                                                                    
                                                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                                        xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                                        
                                                                        if (ySource-1 >= 0 && xSource-1 >= 0 && revisedMap [ySource-1][xSource-1] == -150){
                                                                            revisedMap [ySource-1][xSource-1] = connectivityNumber;
                                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                        }
                                                                        if (ySource-1 >= 0 && revisedMap [ySource-1][xSource] == -150){
                                                                            revisedMap [ySource-1][xSource] = connectivityNumber;
                                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                        }
                                                                        if (ySource-1 >= 0 && xSource+1 < imageSizeLimit && revisedMap [ySource-1][xSource+1] == -150){
                                                                            revisedMap [ySource-1][xSource+1] = connectivityNumber;
                                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                        }
                                                                        if (xSource+1 < imageSizeLimit && revisedMap [ySource][xSource+1] == -150){
                                                                            revisedMap [ySource][xSource+1] = connectivityNumber;
                                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                        }
                                                                        if (ySource+1 > imageSizeLimit && xSource+1 < imageSizeLimit && revisedMap [ySource+1][xSource+1] == -150){
                                                                            revisedMap [ySource+1][xSource+1] = connectivityNumber;
                                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                        }
                                                                        if (ySource+1 < imageSizeLimit && revisedMap [ySource+1][xSource] == -150){
                                                                            revisedMap [ySource+1][xSource] = connectivityNumber;
                                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                        }
                                                                        if (ySource+1 < imageSizeLimit && xSource-1 >= 0 && revisedMap [ySource+1][xSource-1] == -150){
                                                                            revisedMap [ySource+1][xSource-1] = connectivityNumber;
                                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                        }
                                                                        if (xSource-1 >= 0 && revisedMap [ySource][xSource-1] == -150){
                                                                            revisedMap [ySource][xSource-1] = connectivityNumber;
                                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                        }
                                                                    }
                                                                    
                                                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                                        connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                                                    }
                                                                    
                                                                    connectAnalysisCount = connectAnalysisTempCount;
                                                                    
                                                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                                                    
                                                                } while (terminationFlag == 1);
                                                            }
                                                        }
                                                    }
                                                }
                                                
                                                //------Determine number of pixels------
                                                int *connectedPix = new int [connectivityNumber+50];
                                                
                                                for (int counter2 = 0; counter2 <= connectivityNumber; counter2++) connectedPix [counter2] = 0;
                                                
                                                for (int counterY = 0; counterY < imageSizeLimit; counterY++){
                                                    for (int counterX = 0; counterX < imageSizeLimit; counterX++){
                                                        if (revisedMap [counterY][counterX] != 0) connectedPix [revisedMap [counterY][counterX]]++;
                                                    }
                                                }
                                                
                                                //------Map up-date------
                                                connectTemp = 1;
                                                
                                                for (int counter2 = 1; counter2 <= connectivityNumber; counter2++){
                                                    if (connectedPix [counter2] < 10) connectedPix [counter2] = 0;
                                                    else{
                                                        
                                                        connectedPix [counter2] = connectTemp;
                                                        connectTemp++;
                                                    }
                                                }
                                                
                                                for (int counterY = 0; counterY < imageSizeLimit; counterY++){
                                                    for (int counterX = 0; counterX < imageSizeLimit; counterX++){
                                                        if ((connectTemp = revisedMap [counterY][counterX]) != 0) revisedMap [counterY][counterX] = connectedPix [connectTemp];
                                                        else revisedMap [counterY][counterX] = 0;
                                                        
                                                        if (counter1 == 1){
                                                            connectMap240 [counterY][counterX] = revisedMap [counterY][counterX];
                                                        }
                                                        else if (counter1 == 2){
                                                            connectMap220 [counterY][counterX] = revisedMap [counterY][counterX];
                                                        }
                                                        else if (counter1 == 3){
                                                            connectMap200 [counterY][counterX] = revisedMap [counterY][counterX];
                                                        }
                                                        else if (counter1 == 4){
                                                            connectMapA [counterY][counterX] = revisedMap [counterY][counterX];
                                                        }
                                                        else if (counter1 == 5){
                                                            connectMapB [counterY][counterX] = revisedMap [counterY][counterX];
                                                        }
                                                        else if (counter1 == 6){
                                                            connectMapC [counterY][counterX] = revisedMap [counterY][counterX];
                                                        }
                                                        else if (counter1 == 7){
                                                            connectMapD [counterY][counterX] = revisedMap [counterY][counterX];
                                                        }
                                                    }
                                                }
                                                
                                                delete [] connectedPix;
                                            }
                                            
                                            delete [] connectAnalysisX;
                                            delete [] connectAnalysisY;
                                            delete [] connectAnalysisTempX;
                                            delete [] connectAnalysisTempY;
                                            
                                            int yDimensionCount;
                                            int xDimensionCount;
                                            int readBit [4];
                                            int pixData;
                                            
                                            int totalSize = imageSizeLimit*imageSizeLimit*4;
                                            
                                            fin.open(revisedMapPath.c_str(), ios::in | ios::binary);
                                            
                                            if (fin.is_open()){
                                                uint8_t *upload2 = new uint8_t [totalSize+50];
                                                
                                                fin.read((char*)upload2, totalSize+50);
                                                fin.close();
                                                
                                                yDimensionCount = 0;
                                                xDimensionCount = 0;
                                                
                                                for (int counter1 = 0; counter1 < totalSize; counter1 = counter1+4){
                                                    readBit [0] = upload2[counter1];
                                                    readBit [1] = upload2[counter1+1];
                                                    readBit [2] = upload2[counter1+2];
                                                    readBit [3] = upload2[counter1+3];
                                                    
                                                    pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                                                    
                                                    for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                                                        revisedMap [yDimensionCount][xDimensionCount] = pixData;
                                                        revisedWorkingMap [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                                                    }
                                                    
                                                    if (xDimensionCount == imageSizeLimit){
                                                        xDimensionCount = 0;
                                                        yDimensionCount++;
                                                        
                                                        if (yDimensionCount == imageSizeLimit){
                                                            break;
                                                        }
                                                    }
                                                }
                                                
                                                delete [] upload2;
                                            }
                                            else{
                                                
                                                fin.open(mapPath.c_str(), ios::in | ios::binary);
                                                
                                                if (fin.is_open()){
                                                    uint8_t *upload2 = new uint8_t [totalSize+50];
                                                    
                                                    fin.read((char*)upload2, totalSize+50);
                                                    fin.close();
                                                    
                                                    yDimensionCount = 0;
                                                    xDimensionCount = 0;
                                                    
                                                    for (int counter1 = 0; counter1 < totalSize; counter1 = counter1+4){
                                                        readBit [0] = upload2[counter1];
                                                        readBit [1] = upload2[counter1+1];
                                                        readBit [2] = upload2[counter1+2];
                                                        readBit [3] = upload2[counter1+3];
                                                        
                                                        pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                                                        
                                                        for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                                                            revisedMap [yDimensionCount][xDimensionCount] = pixData;
                                                            revisedWorkingMap [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                                                        }
                                                        
                                                        if (xDimensionCount == imageSizeLimit){
                                                            xDimensionCount = 0;
                                                            yDimensionCount++;
                                                            
                                                            if (yDimensionCount == imageSizeLimit){
                                                                break;
                                                            }
                                                        }
                                                    }
                                                    
                                                    delete [] upload2;
                                                }
                                            }
                                            
                                            if (firstRead == 1){
                                                targetFind = [[TargetFind alloc] init];
                                                [targetFind interpretationFirst];
                                                
                                                int valueTemp = 0;
                                                
                                                for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                                                    if (arrayPositionRevise [counter1*7+3] != valueTemp){
                                                        valueTemp = arrayPositionRevise [counter1*7+3];
                                                        arrayTimeSelected [(valueTemp-1)*10+2] = counter1;
                                                        
                                                        if (arrayPositionRevise [counter1*7+5] == 0){
                                                            arrayTimeSelected [(valueTemp-1)*10] = 0;
                                                        }
                                                    }
                                                }
                                            }
                                            else{
                                                
                                                int typeSet = 1;
                                                
                                                targetFind2 = [[TargetFind2 alloc] init];
                                                [targetFind2 interpretationFirst:typeSet];
                                            }
                                            
                                            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                                                if (arrayTimeSelected [counter1*10] == 1){
                                                    currentConnectNo = arrayTimeSelected [counter1*10+8];
                                                    break;
                                                }
                                            }
                                        }
                                        else{
                                            
                                            NSAlert *alert = [[NSAlert alloc] init];
                                            [alert addButtonWithTitle:@"OK"];
                                            [alert setMessageText:@"Data reading error"];
                                            [alert setAlertStyle:NSAlertStyleWarning];
                                            [alert runModal];
                                            
                                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                                            [sound play];
                                        }
                                    }
                                    else{
                                        
                                        NSAlert *alert = [[NSAlert alloc] init];
                                        [alert addButtonWithTitle:@"OK"];
                                        [alert setMessageText:@"Data reading error"];
                                        [alert setAlertStyle:NSAlertStyleWarning];
                                        [alert runModal];
                                        
                                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                                        [sound play];
                                    }
                                }
                                else{
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"Outline Data Missing"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                            }
                        }
                        else{
                            
                            mkdir(dataSaveTreatmentPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                            
                            delete [] arrayAreaDataHold;
                            arrayAreaDataHold = new double [2500];
                            areaDataHoldCount = 2500;
                            areaDataHoldLimit = 2500;
                            
                            for (int counter1 = 0; counter1 < areaDataHoldCount; counter1++){
                                arrayAreaDataHold [counter1] = 0;
                            }
                            
                            delete [] arrayDotDataHold;
                            arrayDotDataHold = new int [1000];
                            dotDataHoldCount = 0;
                            dotDataHoldLimit = 1000;
                            
                            boxXLength = 0;
                            boxYLength = 0;
                            boxXPosition = 0;
                            boxYPosition = 0;
                            dotNumberCurrent = 0;
                            
                            string dataSaveTreatmentPath2 = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"MovieData";
                            
                            oin.open(dataSaveTreatmentPath2.c_str(),ios::out);
                            oin<<imageXYLength*imageXYLength<<endl;
                            oin.close();
                            
                            string dataSaveTreatmentPath3 = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"AnalysisData";
                            
                            oin.open(dataSaveTreatmentPath3.c_str(), ios::out | ios::binary);
                            
                            for (int counter1 = 0; counter1 < areaDataHoldCount; counter1++){
                                oin<<to_string(arrayAreaDataHold [counter1])<<endl;
                            }
                            
                            oin.close();
                        }
                    }
                    else{
                        
                        mkdir(dataSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                        mkdir(dataSaveTreatmentPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                        
                        delete [] arrayAreaDataHold;
                        arrayAreaDataHold = new double [2500];
                        areaDataHoldCount = 2500;
                        areaDataHoldLimit = 2500;
                        
                        for (int counter1 = 0; counter1 < areaDataHoldCount; counter1++) arrayAreaDataHold [counter1] = 0;
                        
                        delete [] arrayDotDataHold;
                        arrayDotDataHold = new int [1000];
                        dotDataHoldCount = 0;
                        dotDataHoldLimit = 1000;
                        
                        boxXLength = 0;
                        boxYLength = 0;
                        boxXPosition = 0;
                        boxYPosition = 0;
                        dotNumberCurrent = 0;
                        
                        string dataSaveTreatmentPath2 = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"MovieData";
                        
                        oin.open(dataSaveTreatmentPath2.c_str(),ios::out);
                        oin<<imageXYLength*imageXYLength<<endl;
                        oin.close();
                        
                        string dataSaveTreatmentPath3 = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"AnalysisData";
                        
                        oin.open(dataSaveTreatmentPath3.c_str(), ios::out | ios::binary);
                        
                        for (int counter1 = 0; counter1 < areaDataHoldCount; counter1++){
                            oin<<to_string(arrayAreaDataHold [counter1])<<endl;
                        }
                        
                        oin.close();
                    }
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
                    
                    if (exportOperation != 0){
                        int errorFind = [self reloadImageExp];
                        
                        if (errorFind == 0){
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                            
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToExportDisplay object:self];
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Data Loading Error"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Image Size Retrieval Failed"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Image Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Image Folder Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)quitProcess:(id)sender{
    if (imageProgressFlag == 0){
        if (areaSetDone== 1){
            areaSetDone = 0;
            trackingDataSave = [[TrackingDataSave alloc] init];
            [trackingDataSave trackingDataSaveTemp:timePointHold];
        }
        
        delete [] arrayDirectoryInfo;
        
        delete [] arrayAreaDataHold;
        delete [] arrayDotDataHold;
        delete [] arrayPositionRevise;
        delete [] arrayGravityCenterRev;
        delete [] arrayTimeSelected;
        delete [] groupNumberList;
        delete [] arrayReferenceLine;
        
        if (positionExportStatus == 1) delete [] arrayPositionExport;
        if (gravityCenterExportStatus == 1) delete [] arrayGravityCenterExport;
        if (gravityCenterExportCorrectStatus == 1) delete [] arrayGravityCenterExportHold;
        if (timeSelectedExportStatus == 1) delete [] arrayTimeSelectedExport;
        
        for (int counter1 = 0; counter1 < imageSizeLimit+1; counter1++){
            delete [] sourceImage [counter1];
            delete [] revisedMap [counter1];
            delete [] revisedWorkingMap [counter1];
            delete [] connectMap200 [counter1];
            delete [] connectMap220 [counter1];
            delete [] connectMap240 [counter1];
            delete [] connectMapA [counter1];
            delete [] connectMapB [counter1];
            delete [] connectMapC [counter1];
            delete [] connectMapD [counter1];
        }
        
        delete [] sourceImage;
        delete [] revisedMap;
        delete [] revisedWorkingMap;
        delete [] connectMap200;
        delete [] connectMap220;
        delete [] connectMap240;
        delete [] connectMapA;
        delete [] connectMapB;
        delete [] connectMapC;
        delete [] connectMapD;
        
        if (fileListStatus == 1){
            delete [] fileList;
            delete [] fileList2;
        }
        
        if (uploadTempStatus == 1) delete [] uploadTemp;
        if (uploadTempStatusCl1 == 1) delete [] uploadTempCl1;
        if (uploadTempStatusCl2 == 1) delete [] uploadTempCl2;
        if (uploadTempStatusCl3 == 1) delete [] uploadTempCl3;
        if (uploadTempStatusCl4 == 1) delete [] uploadTempCl4;
        if (uploadTempStatusCl5 == 1) delete [] uploadTempCl5;
        if (uploadTempStatusCl6 == 1) delete [] uploadTempCl6;
        
        if (uploadTempStatusRef == 1) delete [] uploadTempRef;
        if (uploadTempStatusRef2 == 1) delete [] uploadTempRef2;
        if (uploadTempStatusRef3 == 1) delete [] uploadTempRef3;
        
        if (uploadTempExpStatus == 1) delete [] uploadTempExp;
        if (uploadTempExpStatusCl1 == 1) delete [] uploadTempExpCl1;
        if (uploadTempExpStatusCl2 == 1) delete [] uploadTempExpCl2;
        if (uploadTempExpStatusCl3 == 1) delete [] uploadTempExpCl3;
        if (uploadTempExpStatusRef == 1) delete [] uploadTempExpRef;
        if (uploadTempExpStatusRef2 == 1) delete [] uploadTempExpRef2;
        if (uploadTempExpStatusRef3 == 1) delete [] uploadTempExpRef3;
        
        delete [] arrayColorRange;
        delete [] arrayColorRangeSource;
        delete [] arrayColorRange2;
        
        if (revisedWorkingMapExpStatus == 1){
            for (int counter1 = 0; counter1 < imageXYLength+1; counter1++){
                delete [] revisedWorkingMapExp [counter1];
            }
            
            delete [] revisedWorkingMapExp;
        }
        
        if (circleAreaHoldStatus == 1){
            for (int counter1 = 0; counter1 < densityDiameterPrev+2; counter1++) delete [] circleAreaHold [counter1];
            delete [] circleAreaHold;
        }
        
        exit (0);
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)startProcess:(id)sender{
    if (phaseStatus == 0 && imageProgressFlag == 0){
        if (imageXYLength != 0){
            if (movieRunningFlag == 0){
                movieRunningFlag = 1;
                movieTiming = 0;
                
                [movieStatus setTextColor:[NSColor redColor]];
                [movieStatus setStringValue:@"On"];
                [movieText setTextColor:[NSColor redColor]];
                [movieText setStringValue:@"Movie"];
            }
            else if (movieRunningFlag == 1){
                movieRunningFlag = 0;
                
                [movieStatus setTextColor:[NSColor blackColor]];
                [movieStatus setStringValue:@"Off"];
                [movieText setTextColor:[NSColor blackColor]];
                [movieText setStringValue:@"Movie"];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Area Mode On or Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)directionSet:(id)sender{
    if (orientationHold == 0 && movieRunningFlag == 0){
        orientationHold = 1;
        
        string movieSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CMBasic";
        
        ofstream oin;
        oin.open(movieSettingPath.c_str(),ios::out);
        oin<<speedHold<<endl;
        oin<<orientationHold<<endl;
        oin.close();
        [direction setStringValue:@"RW"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else if (orientationHold == 1 && movieRunningFlag == 0){
        orientationHold = 0;
        
        string movieSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CMBasic";
        
        ofstream oin;
        oin.open(movieSettingPath.c_str(),ios::out);
        oin<<speedHold<<endl;
        oin<<orientationHold<<endl;
        oin.close();
        
        [direction setStringValue:@"FW"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(void)controlTextDidChange:(NSNotification *)aNotification {
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]) {
        if ([aNotification object] == speed && movieRunningFlag == 0){
            if ([speed intValue] >= 10 && [speed intValue] <= 1000){
                [stepper setIntValue:[speed intValue]];
                speedHold = [speed intValue];
                
                string movieSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CMBasic";
                
                ofstream oin;
                oin.open(movieSettingPath.c_str(),ios::out);
                oin<<speedHold<<endl;
                oin<<orientationHold<<endl;
                oin.close();
            }
        }
        
        if ([aNotification object] == dotExportToDisplay){
            if ([dotExportToDisplay intValue] > 0) dotExportLimitTimeTo = [dotExportToDisplay intValue];
            else{
                
                dotExportLimitTimeTo = 0;
                [dotExportToDisplay setStringValue:@""];
            }
        }
        
        if ([aNotification object] == dotExportFromDisplay){
            if ([dotExportFromDisplay intValue] > 0) dotExportLimitTimeFrom = [dotExportFromDisplay intValue];
            else{
                
                dotExportLimitTimeFrom = 0;
                [dotExportFromDisplay setStringValue:@""];
            }
        }
    }
}

-(IBAction)stepperAction:(id)sender{
    if (movieRunningFlag == 0){
        if ([stepper intValue] >= 10 && [stepper intValue] <= 1000){
            [speed setIntValue:[stepper intValue]];
            speedHold = [stepper intValue];
            
            string movieSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CMBasic";
            
            ofstream oin;
            oin.open(movieSettingPath.c_str(),ios::out);
            oin<<speedHold<<endl;
            oin<<orientationHold<<endl;
            oin.close();
        }
        else{
            
            [speed setStringValue:@""];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)tableReload:(id)sender{
    [listBrowser reloadColumn:0];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)tenFW:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0 && phaseStatus == 0 && imageProgressFlag == 0){
        filePosition = filePosition+10;
        
        if (maxImageNo < filePosition) filePosition = maxImageNo;
        
        [self dataSetAndDisplay];
        
        string timeDisplayTemp = fileList [(filePosition-1)*7];
        timeDisplayTemp = timeDisplayTemp.substr(8, 4);
        
        int currentTime = timePointHold;
        
        timePointHold = atoi(timeDisplayTemp.c_str());
        
        if ((timePointHold-1)*25+25 < areaDataHoldCount){
            boxXLength = (int)(arrayAreaDataHold [(timePointHold-1)*25+6]);
            boxYLength = (int)(arrayAreaDataHold [(timePointHold-1)*25+7]);
            boxXPosition = arrayAreaDataHold [(timePointHold-1)*25+8];
            boxYPosition = arrayAreaDataHold [(timePointHold-1)*25+9];
            
            dotNumberCurrent = (int)arrayAreaDataHold [(timePointHold-1)*25+5];
        }
        else{
            
            boxXLength = 0;
            boxYLength = 0;
            boxXPosition = 0;
            boxYPosition = 0;
            dotNumberCurrent = 0;
        }
        
        if (boxXLength != 0 && boxYLength != 0) boxDisplayCall = 1;
        else boxDisplayCall = 2;
        
        if (areaSetDone == 1){
            areaSetDone = 0;
            trackingDataSave = [[TrackingDataSave alloc] init];
            [trackingDataSave trackingDataSaveTemp:currentTime];
        }
        
        timePointDisplayCall = 1;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)tenBW:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0 && phaseStatus == 0 && imageProgressFlag == 0){
        filePosition = filePosition-10;
        
        if (filePosition <= 0) filePosition = 1;
        
        [self dataSetAndDisplay];
        
        string timeDisplayTemp = fileList [(filePosition-1)*7];
        timeDisplayTemp = timeDisplayTemp.substr(8, 4);
        
        int currentTime = timePointHold;
        
        timePointHold = atoi(timeDisplayTemp.c_str());
        
        if ((timePointHold-1)*25+25 < areaDataHoldCount){
            boxXLength = (int)(arrayAreaDataHold [(timePointHold-1)*25+6]);
            boxYLength = (int)(arrayAreaDataHold [(timePointHold-1)*25+7]);
            boxXPosition = arrayAreaDataHold [(timePointHold-1)*25+8];
            boxYPosition = arrayAreaDataHold [(timePointHold-1)*25+9];
            
            dotNumberCurrent = (int)arrayAreaDataHold [(timePointHold-1)*25+5];
        }
        else{
            
            boxXLength = 0;
            boxYLength = 0;
            boxXPosition = 0;
            boxYPosition = 0;
            dotNumberCurrent = 0;
        }
        
        if (boxXLength != 0 && boxYLength != 0) boxDisplayCall = 1;
        else boxDisplayCall = 2;
        
        if (areaSetDone == 1){
            areaSetDone = 0;
            trackingDataSave = [[TrackingDataSave alloc] init];
            [trackingDataSave trackingDataSaveTemp:currentTime];
        }
        
        timePointDisplayCall = 1;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)hundredFW:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0 && phaseStatus == 0 && imageProgressFlag == 0){
        filePosition = filePosition+100;
        
        if (maxImageNo < filePosition) filePosition = maxImageNo;
        
        [self dataSetAndDisplay];
        
        string timeDisplayTemp = fileList [(filePosition-1)*7];
        timeDisplayTemp = timeDisplayTemp.substr(8, 4);
        
        int currentTime = timePointHold;
        
        timePointHold = atoi(timeDisplayTemp.c_str());
        
        if ((timePointHold-1)*25+25 < areaDataHoldCount){
            boxXLength = (int)(arrayAreaDataHold [(timePointHold-1)*25+6]);
            boxYLength = (int)(arrayAreaDataHold [(timePointHold-1)*25+7]);
            boxXPosition = arrayAreaDataHold [(timePointHold-1)*25+8];
            boxYPosition = arrayAreaDataHold [(timePointHold-1)*25+9];
            
            dotNumberCurrent = (int)arrayAreaDataHold [(timePointHold-1)*25+5];
        }
        else{
            
            boxXLength = 0;
            boxYLength = 0;
            boxXPosition = 0;
            boxYPosition = 0;
            dotNumberCurrent = 0;
        }
        
        if (boxXLength != 0 && boxYLength != 0) boxDisplayCall = 1;
        else boxDisplayCall = 2;
        
        if (areaSetDone == 1){
            areaSetDone = 0;
            trackingDataSave = [[TrackingDataSave alloc] init];
            [trackingDataSave trackingDataSaveTemp:currentTime];
        }
        
        timePointDisplayCall = 1;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)hundredBW:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0 && phaseStatus == 0 && imageProgressFlag == 0){
        filePosition = filePosition-100;
        
        if (filePosition <= 0) filePosition = 1;
        
        [self dataSetAndDisplay];
        
        string timeDisplayTemp = fileList [(filePosition-1)*7];
        timeDisplayTemp = timeDisplayTemp.substr(8, 4);
        
        int currentTime = timePointHold;
        
        timePointHold = atoi(timeDisplayTemp.c_str());
        
        if ((timePointHold-1)*25+25 < areaDataHoldCount){
            boxXLength = (int)(arrayAreaDataHold [(timePointHold-1)*25+6]);
            boxYLength = (int)(arrayAreaDataHold [(timePointHold-1)*25+7]);
            boxXPosition = arrayAreaDataHold [(timePointHold-1)*25+8];
            boxYPosition = arrayAreaDataHold [(timePointHold-1)*25+9];
            
            dotNumberCurrent = (int)arrayAreaDataHold [(timePointHold-1)*25+5];
        }
        else{
            
            boxXLength = 0;
            boxYLength = 0;
            boxXPosition = 0;
            boxYPosition = 0;
            dotNumberCurrent = 0;
        }
        
        if (boxXLength != 0 && boxYLength != 0) boxDisplayCall = 1;
        else boxDisplayCall = 2;
        
        if (areaSetDone == 1){
            areaSetDone = 0;
            trackingDataSave = [[TrackingDataSave alloc] init];
            [trackingDataSave trackingDataSaveTemp:currentTime];
        }
        
        timePointDisplayCall = 1;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(void)dataSetAndDisplay{
    string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7];
    
    if (statusHoldDIC == 1){
        if (filePosition > lastDICImageTime) imageMoviePath = imageDisplayPath+"/"+fileList [(lastDICImageTime-1)*7];
    }
    
    ifstream fin;
    fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
    
    fin.read((char*)uploadTemp, (long)uploadTempFileSize+50);
    fin.close();
    
    int mode = 0;
    
    if (fileList [(filePosition-1)*7+1] != ""){
        [self setCH1:mode];
        
        if (fileList [(filePosition-1)*7+2] != ""){
            [self setCH2:mode];
            
            if (fileList [(filePosition-1)*7+3] != ""){
                [self setCH3:mode];
                
                if (fileList [(filePosition-1)*7+4] != ""){
                    [self setCH4:mode];
                    
                    if (fileList [(filePosition-1)*7+5] != ""){
                        [self setCH5:mode];
                        
                        if (fileList [(filePosition-1)*7+6] != "") [self setCH6:mode];
                        else [self resetSubCH6];
                    }
                    else [self resetSubCH5];
                }
                else [self resetSubCH4];
            }
            else [self resetSubCH3];
        }
        else [self resetSubCH2];
    }
    else{
        
        if (colorFlag1 != 0) [self resetSubCH1];
    }
}

-(void)resetSubCH1{
    colorFlag1 = 0;
    colorFlag2 = 0;
    colorFlag3 = 0;
    colorFlag4 = 0;
    colorFlag5 = 0;
    colorFlag6 = 0;
    
    [chLabel1 setTextColor:[NSColor whiteColor]];
    [chLabel1 setStringValue:@"CH1:"];
    [chName1 setTextColor:[NSColor whiteColor]];
    [chName1 setStringValue:@"nil"];
    
    [chLabel2 setTextColor:[NSColor whiteColor]];
    [chLabel2 setStringValue:@"CH2:"];
    [chName2 setTextColor:[NSColor whiteColor]];
    [chName2 setStringValue:@"nil"];
    
    [chLabel3 setTextColor:[NSColor whiteColor]];
    [chLabel3 setStringValue:@"CH3:"];
    [chName3 setTextColor:[NSColor whiteColor]];
    [chName3 setStringValue:@"nil"];
    
    [chLabel4 setTextColor:[NSColor whiteColor]];
    [chLabel4 setStringValue:@"CH4:"];
    [chName4 setTextColor:[NSColor whiteColor]];
    [chName4 setStringValue:@"nil"];
    
    [chLabel5 setTextColor:[NSColor whiteColor]];
    [chLabel5 setStringValue:@"CH5:"];
    [chName5 setTextColor:[NSColor whiteColor]];
    [chName5 setStringValue:@"nil"];
    
    [chLabel6 setTextColor:[NSColor whiteColor]];
    [chLabel6 setStringValue:@"CH6:"];
    [chName6 setTextColor:[NSColor whiteColor]];
    [chName6 setStringValue:@"nil"];
    
    [chLevel1 setStringValue:@"nil"];
    [chLevel2 setStringValue:@"nil"];
    [chLevel3 setStringValue:@"nil"];
    [chLevel4 setStringValue:@"nil"];
    [chLevel5 setStringValue:@"nil"];
    [chLevel6 setStringValue:@"nil"];
    [chCut1 setStringValue:@"nil"];
    [chCut2 setStringValue:@"nil"];
    [chCut3 setStringValue:@"nil"];
    [chCut4 setStringValue:@"nil"];
    [chCut5 setStringValue:@"nil"];
    [chCut6 setStringValue:@"nil"];
    [chStatus1 setStringValue:@"Off"];
    [chStatus2 setStringValue:@"Off"];
    [chStatus3 setStringValue:@"Off"];
    [chStatus4 setStringValue:@"Off"];
    [chStatus5 setStringValue:@"Off"];
    [chStatus6 setStringValue:@"Off"];
    
    [sliderKnobLevel1 setIntegerValue:1];
    [sliderKnobCut1 setIntegerValue:50];
    [sliderKnobLevel2 setIntegerValue:1];
    [sliderKnobCut2 setIntegerValue:50];
    [sliderKnobLevel3 setIntegerValue:1];
    [sliderKnobCut3 setIntegerValue:50];
    [sliderKnobLevel4 setIntegerValue:1];
    [sliderKnobCut4 setIntegerValue:50];
    [sliderKnobLevel5 setIntegerValue:1];
    [sliderKnobCut5 setIntegerValue:50];
    [sliderKnobLevel6 setIntegerValue:1];
    [sliderKnobCut6 setIntegerValue:50];
}

-(void)resetSubCH2{
    colorFlag2 = 0;
    colorFlag3 = 0;
    colorFlag4 = 0;
    colorFlag5 = 0;
    colorFlag6 = 0;
    
    [chLabel2 setTextColor:[NSColor whiteColor]];
    [chLabel2 setStringValue:@"CH2:"];
    [chName2 setTextColor:[NSColor whiteColor]];
    [chName2 setStringValue:@"nil"];
    
    [chLabel3 setTextColor:[NSColor whiteColor]];
    [chLabel3 setStringValue:@"CH3:"];
    [chName3 setTextColor:[NSColor whiteColor]];
    [chName3 setStringValue:@"nil"];
    
    [chLabel4 setTextColor:[NSColor whiteColor]];
    [chLabel4 setStringValue:@"CH4:"];
    [chName4 setTextColor:[NSColor whiteColor]];
    [chName4 setStringValue:@"nil"];
    
    [chLabel5 setTextColor:[NSColor whiteColor]];
    [chLabel5 setStringValue:@"CH5:"];
    [chName5 setTextColor:[NSColor whiteColor]];
    [chName5 setStringValue:@"nil"];
    
    [chLabel6 setTextColor:[NSColor whiteColor]];
    [chLabel6 setStringValue:@"CH6:"];
    [chName6 setTextColor:[NSColor whiteColor]];
    [chName6 setStringValue:@"nil"];
    
    [chLevel2 setStringValue:@"nil"];
    [chLevel3 setStringValue:@"nil"];
    [chLevel4 setStringValue:@"nil"];
    [chLevel5 setStringValue:@"nil"];
    [chLevel6 setStringValue:@"nil"];
    [chCut2 setStringValue:@"nil"];
    [chCut3 setStringValue:@"nil"];
    [chCut4 setStringValue:@"nil"];
    [chCut5 setStringValue:@"nil"];
    [chCut6 setStringValue:@"nil"];
    [chStatus2 setStringValue:@"Off"];
    [chStatus3 setStringValue:@"Off"];
    [chStatus4 setStringValue:@"Off"];
    [chStatus5 setStringValue:@"Off"];
    [chStatus6 setStringValue:@"Off"];
    
    [sliderKnobLevel2 setIntegerValue:1];
    [sliderKnobCut2 setIntegerValue:50];
    [sliderKnobLevel3 setIntegerValue:1];
    [sliderKnobCut3 setIntegerValue:50];
    [sliderKnobLevel4 setIntegerValue:1];
    [sliderKnobCut4 setIntegerValue:50];
    [sliderKnobLevel5 setIntegerValue:1];
    [sliderKnobCut5 setIntegerValue:50];
    [sliderKnobLevel6 setIntegerValue:1];
    [sliderKnobCut6 setIntegerValue:50];
}

-(void)resetSubCH3{
    colorFlag3 = 0;
    colorFlag4 = 0;
    colorFlag5 = 0;
    colorFlag6 = 0;
    
    [chLabel3 setTextColor:[NSColor whiteColor]];
    [chLabel3 setStringValue:@"CH3:"];
    [chName3 setTextColor:[NSColor whiteColor]];
    [chName3 setStringValue:@"nil"];
    
    [chLabel4 setTextColor:[NSColor whiteColor]];
    [chLabel4 setStringValue:@"CH4:"];
    [chName4 setTextColor:[NSColor whiteColor]];
    [chName4 setStringValue:@"nil"];
    
    [chLabel5 setTextColor:[NSColor whiteColor]];
    [chLabel5 setStringValue:@"CH5:"];
    [chName5 setTextColor:[NSColor whiteColor]];
    [chName5 setStringValue:@"nil"];
    
    [chLabel6 setTextColor:[NSColor whiteColor]];
    [chLabel6 setStringValue:@"CH6:"];
    [chName6 setTextColor:[NSColor whiteColor]];
    [chName6 setStringValue:@"nil"];
    
    [chLevel3 setStringValue:@"nil"];
    [chLevel4 setStringValue:@"nil"];
    [chLevel5 setStringValue:@"nil"];
    [chLevel6 setStringValue:@"nil"];
    [chCut3 setStringValue:@"nil"];
    [chCut4 setStringValue:@"nil"];
    [chCut5 setStringValue:@"nil"];
    [chCut6 setStringValue:@"nil"];
    [chStatus3 setStringValue:@"Off"];
    [chStatus4 setStringValue:@"Off"];
    [chStatus5 setStringValue:@"Off"];
    [chStatus6 setStringValue:@"Off"];
    
    [sliderKnobLevel3 setIntegerValue:1];
    [sliderKnobCut3 setIntegerValue:50];
    [sliderKnobLevel4 setIntegerValue:1];
    [sliderKnobCut4 setIntegerValue:50];
    [sliderKnobLevel5 setIntegerValue:1];
    [sliderKnobCut5 setIntegerValue:50];
    [sliderKnobLevel6 setIntegerValue:1];
    [sliderKnobCut6 setIntegerValue:50];
}

-(void)resetSubCH4{
    colorFlag4 = 0;
    colorFlag5 = 0;
    colorFlag6 = 0;
    
    [chLabel4 setTextColor:[NSColor whiteColor]];
    [chLabel4 setStringValue:@"CH4:"];
    [chName4 setTextColor:[NSColor whiteColor]];
    [chName4 setStringValue:@"nil"];
    
    [chLabel5 setTextColor:[NSColor whiteColor]];
    [chLabel5 setStringValue:@"CH5:"];
    [chName5 setTextColor:[NSColor whiteColor]];
    [chName5 setStringValue:@"nil"];
    
    [chLabel6 setTextColor:[NSColor whiteColor]];
    [chLabel6 setStringValue:@"CH6:"];
    [chName6 setTextColor:[NSColor whiteColor]];
    [chName6 setStringValue:@"nil"];
    
    [chLevel4 setStringValue:@"nil"];
    [chLevel5 setStringValue:@"nil"];
    [chLevel6 setStringValue:@"nil"];
    [chCut4 setStringValue:@"nil"];
    [chCut5 setStringValue:@"nil"];
    [chCut6 setStringValue:@"nil"];
    [chStatus4 setStringValue:@"Off"];
    [chStatus5 setStringValue:@"Off"];
    [chStatus6 setStringValue:@"Off"];
    
    [sliderKnobLevel4 setIntegerValue:1];
    [sliderKnobCut4 setIntegerValue:50];
    [sliderKnobLevel5 setIntegerValue:1];
    [sliderKnobCut5 setIntegerValue:50];
    [sliderKnobLevel6 setIntegerValue:1];
    [sliderKnobCut6 setIntegerValue:50];
}

-(void)resetSubCH5{
    colorFlag5 = 0;
    colorFlag6 = 0;
    
    [chLabel5 setTextColor:[NSColor whiteColor]];
    [chLabel5 setStringValue:@"CH5:"];
    [chName5 setTextColor:[NSColor whiteColor]];
    [chName5 setStringValue:@"nil"];
    
    [chLabel6 setTextColor:[NSColor whiteColor]];
    [chLabel6 setStringValue:@"CH6:"];
    [chName6 setTextColor:[NSColor whiteColor]];
    [chName6 setStringValue:@"nil"];
    
    [chLevel5 setStringValue:@"nil"];
    [chLevel6 setStringValue:@"nil"];
    [chCut5 setStringValue:@"nil"];
    [chCut6 setStringValue:@"nil"];
    [chStatus5 setStringValue:@"Off"];
    [chStatus6 setStringValue:@"Off"];
    
    [sliderKnobLevel5 setIntegerValue:1];
    [sliderKnobCut5 setIntegerValue:50];
    [sliderKnobLevel6 setIntegerValue:1];
    [sliderKnobCut6 setIntegerValue:50];
}

-(void)resetSubCH6{
    colorFlag6 = 0;
    
    [chName5 setTextColor:[NSColor whiteColor]];
    [chName5 setStringValue:@"nil"];
    
    [chName6 setTextColor:[NSColor whiteColor]];
    [chName6 setStringValue:@"nil"];
    
    [chLevel6 setStringValue:@"nil"];
    [chCut6 setStringValue:@"nil"];
    [chStatus6 setStringValue:@"Off"];
    
    [sliderKnobLevel6 setIntegerValue:1];
    [sliderKnobCut6 setIntegerValue:50];
}

-(void)setCH1:(int)mode{
    if (mode == 0){
        colorFlag1 = 1;
        
        unsigned long findString = fileList [(filePosition-1)*7+1].find("tif");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+1].find("TIF");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+1].find("bmp");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+1].find("BMP");
        
        colorNo1 = fileList [(filePosition-1)*7+1].substr(13, 1);
        colorName1 = fileList [(filePosition-1)*7+1].substr(15, findString-16);
        
        string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+1];
        
        if (uploadTempStatusCl1 == 1) delete [] uploadTempCl1;
        
        uploadTempCl1 = new uint8_t [uploadTempFileSize+50];
        uploadTempStatusCl1 = 1;
        
        ifstream fin;
        
        fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
        
        fin.read((char*)uploadTempCl1, (long)uploadTempFileSize+50);
        fin.close();
    }
    
    if (colorNo1 == "1"){
        [chLabel1 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chLabel1 setStringValue:@"CH1:"];
        [chName1 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chName1 setStringValue:@(colorName1.c_str())];
    }
    else if (colorNo1 == "2"){
        [chLabel1 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chLabel1 setStringValue:@"CH1:"];
        [chName1 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chName1 setStringValue:@(colorName1.c_str())];
    }
    else if (colorNo1 == "3"){
        [chLabel1 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chLabel1 setStringValue:@"CH1:"];
        [chName1 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chName1 setStringValue:@(colorName1.c_str())];
    }
    else if (colorNo1 == "4"){
        [chLabel1 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chLabel1 setStringValue:@"CH1:"];
        [chName1 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chName1 setStringValue:@(colorName1.c_str())];
    }
    else if (colorNo1 == "5"){
        [chLabel1 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chLabel1 setStringValue:@"CH1:"];
        [chName1 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chName1 setStringValue:@(colorName1.c_str())];
    }
    else if (colorNo1 == "6"){
        [chLabel1 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chLabel1 setStringValue:@"CH1:"];
        [chName1 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chName1 setStringValue:@(colorName1.c_str())];
    }
    else if (colorNo1 == "7"){
        [chLabel1 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chLabel1 setStringValue:@"CH1:"];
        [chName1 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chName1 setStringValue:@(colorName1.c_str())];
    }
    else if (colorNo1 == "8"){
        [chLabel1 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chLabel1 setStringValue:@"CH1:"];
        [chName1 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chName1 setStringValue:@(colorName1.c_str())];
    }
    else if (colorNo1 == "9"){
        [chLabel1 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chLabel1 setStringValue:@"CH1:"];
        [chName1 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chName1 setStringValue:@(colorName1.c_str())];
    }
    
    int holdTemp = (int)(levelHold1*1000);
    double holdTempDouble = holdTemp/(double)1000;
    
    [chLevel1 setDoubleValue:holdTempDouble];
    
    holdTemp = (int)(cutHold1*1000);
    holdTempDouble = holdTemp/(double)1000;
    
    [chCut1 setDoubleValue:holdTempDouble];
    
    if (statusHold1 == 0){
        [chStatus1 setStringValue:@"Off"];
    }
    else [chStatus1 setStringValue:@"On"];
    
    [sliderKnobLevel1 setIntegerValue:(long)levelHold1];
    [sliderKnobCut1 setDoubleValue:cutHold1];
}

-(void)setCH2:(int)mode{
    if (mode == 0){
        colorFlag2 = 1;
        
        unsigned long findString = fileList [(filePosition-1)*7+2].find("tif");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+2].find("TIF");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+2].find("bmp");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+2].find("BMP");
        
        colorNo2 = fileList [(filePosition-1)*7+2].substr(13, 1);
        colorName2 = fileList [(filePosition-1)*7+2].substr(15, findString-16);
        
        string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+2];
        
        if (uploadTempStatusCl2 == 1) delete [] uploadTempCl2;
        
        uploadTempCl2 = new uint8_t [uploadTempFileSize+50];
        uploadTempStatusCl2 = 1;
        
        ifstream fin;
        
        fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
        
        fin.read((char*)uploadTempCl2, (long)uploadTempFileSize+50);
        fin.close();
    }
    
    if (colorNo2 == "1"){
        [chLabel2 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chLabel2 setStringValue:@"CH2:"];
        [chName2 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chName2 setStringValue:@(colorName2.c_str())];
    }
    else if (colorNo2 == "2"){
        [chLabel2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chLabel2 setStringValue:@"CH2:jj"];
        [chName2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chName2 setStringValue:@(colorName2.c_str())];
    }
    else if (colorNo2 == "3"){
        [chLabel2 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chLabel2 setStringValue:@"CH2:"];
        [chName2 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chName2 setStringValue:@(colorName2.c_str())];
    }
    else if (colorNo2 == "4"){
        [chLabel2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chLabel2 setStringValue:@"CH2:"];
        [chName2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chName2 setStringValue:@(colorName2.c_str())];
    }
    else if (colorNo2 == "5"){
        [chLabel2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chLabel2 setStringValue:@"CH2:"];
        [chName2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chName2 setStringValue:@(colorName2.c_str())];
    }
    else if (colorNo2 == "6"){
        [chLabel2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chLabel2 setStringValue:@"CH2:"];
        [chName2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chName2 setStringValue:@(colorName2.c_str())];
    }
    else if (colorNo2 == "7"){
        [chLabel2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chLabel2 setStringValue:@"CH2:"];
        [chName2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chName2 setStringValue:@(colorName2.c_str())];
    }
    else if (colorNo2 == "8"){
        [chLabel2 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chLabel2 setStringValue:@"CH2:"];
        [chName2 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chName2 setStringValue:@(colorName2.c_str())];
    }
    else if (colorNo2 == "9"){
        [chLabel2 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chLabel2 setStringValue:@"CH2:"];
        [chName2 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chName2 setStringValue:@(colorName2.c_str())];
    }
    
    int holdTemp = (int)(levelHold2*1000);
    double holdTempDouble = holdTemp/(double)1000;
    
    [chLevel2 setDoubleValue:holdTempDouble];
    
    holdTemp = (int)(cutHold2*1000);
    holdTempDouble = holdTemp/(double)1000;
    
    [chCut2 setDoubleValue:holdTempDouble];
    
    if (statusHold2 == 0){
        [chStatus2 setStringValue:@"Off"];
    }
    else [chStatus2 setStringValue:@"On"];
    
    [sliderKnobLevel2 setIntegerValue:(long)levelHold2];
    [sliderKnobCut2 setDoubleValue:cutHold2];
}

-(void)setCH3:(int)mode{
    if (mode == 0){
        colorFlag3 = 1;
        
        unsigned long findString = fileList [(filePosition-1)*7+3].find("tif");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+3].find("TIF");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+3].find("bmp");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+3].find("BMP");
        
        colorNo3 = fileList [(filePosition-1)*7+3].substr(13, 1);
        colorName3 = fileList [(filePosition-1)*7+3].substr(15, findString-16);
        
        string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+3];
        
        if (uploadTempStatusCl3 == 1) delete [] uploadTempCl3;
        
        uploadTempCl3 = new uint8_t [uploadTempFileSize+50];
        uploadTempStatusCl3 = 1;
        
        ifstream fin;
        
        fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
        
        fin.read((char*)uploadTempCl3, (long)uploadTempFileSize+50);
        fin.close();
    }
    
    if (colorNo3 == "1"){
        [chLabel3 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chLabel3 setStringValue:@"CH3:"];
        [chName3 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chName3 setStringValue:@(colorName3.c_str())];
    }
    else if (colorNo3 == "2"){
        [chLabel3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chLabel3 setStringValue:@"CH3:"];
        [chName3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chName3 setStringValue:@(colorName3.c_str())];
    }
    else if (colorNo3 == "3"){
        [chLabel3 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chLabel3 setStringValue:@"CH3:"];
        [chName3 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chName3 setStringValue:@(colorName3.c_str())];
    }
    else if (colorNo3 == "4"){
        [chLabel3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chLabel3 setStringValue:@"CH3:"];
        [chName3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chName3 setStringValue:@(colorName3.c_str())];
    }
    else if (colorNo3 == "5"){
        [chLabel3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chLabel3 setStringValue:@"CH3:"];
        [chName3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chName3 setStringValue:@(colorName3.c_str())];
    }
    else if (colorNo3 == "6"){
        [chLabel3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chLabel3 setStringValue:@"CH3:"];
        [chName3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chName3 setStringValue:@(colorName3.c_str())];
    }
    else if (colorNo3 == "7"){
        [chLabel3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chLabel3 setStringValue:@"CH3:"];
        [chName3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chName3 setStringValue:@(colorName3.c_str())];
    }
    else if (colorNo3 == "8"){
        [chLabel3 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chLabel3 setStringValue:@"CH3:"];
        [chName3 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chName3 setStringValue:@(colorName3.c_str())];
    }
    else if (colorNo3 == "9"){
        [chLabel3 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chLabel3 setStringValue:@"CH3:"];
        [chName3 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chName3 setStringValue:@(colorName3.c_str())];
    }
    
    int holdTemp = (int)(levelHold3*1000);
    double holdTempDouble = holdTemp/(double)1000;
    
    [chLevel3 setDoubleValue:holdTempDouble];
    
    holdTemp = (int)(cutHold3*1000);
    holdTempDouble = holdTemp/(double)1000;
    
    [chCut3 setDoubleValue:holdTempDouble];
    
    if (statusHold3 == 0){
        [chStatus3 setStringValue:@"Off"];
    }
    else [chStatus3 setStringValue:@"On"];
    
    [sliderKnobLevel3 setIntegerValue:(long)levelHold3];
    [sliderKnobCut3 setDoubleValue:cutHold3];
}

-(void)setCH4:(int)mode{
    if (mode == 0){
        colorFlag4 = 1;
        
        unsigned long findString = fileList [(filePosition-1)*7+4].find("tif");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+4].find("TIF");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+4].find("bmp");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+4].find("BMP");
        
        colorNo4 = fileList [(filePosition-1)*7+4].substr(13, 1);
        colorName4 = fileList [(filePosition-1)*7+4].substr(15, findString-16);
        
        string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+4];
        
        if (uploadTempStatusCl4 == 1) delete [] uploadTempCl4;
        
        uploadTempCl4 = new uint8_t [uploadTempFileSize+50];
        uploadTempStatusCl4 = 1;
        
        ifstream fin;
        
        fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
        
        fin.read((char*)uploadTempCl4, (long)uploadTempFileSize+50);
        fin.close();
    }
    
    if (colorNo4 == "1"){
        [chLabel4 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chLabel4 setStringValue:@"CH4:"];
        [chName4 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chName4 setStringValue:@(colorName4.c_str())];
    }
    else if (colorNo4 == "2"){
        [chLabel4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chLabel4 setStringValue:@"CH4:"];
        [chName4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chName4 setStringValue:@(colorName4.c_str())];
    }
    else if (colorNo4 == "3"){
        [chLabel4 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chLabel4 setStringValue:@"CH4:"];
        [chName4 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chName4 setStringValue:@(colorName4.c_str())];
    }
    else if (colorNo4 == "4"){
        [chLabel4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chLabel4 setStringValue:@"CH4:"];
        [chName4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chName4 setStringValue:@(colorName4.c_str())];
    }
    else if (colorNo4 == "5"){
        [chLabel4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chLabel4 setStringValue:@"CH4:"];
        [chName4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chName4 setStringValue:@(colorName4.c_str())];
    }
    else if (colorNo4 == "6"){
        [chLabel4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chLabel4 setStringValue:@"CH4:"];
        [chName4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chName4 setStringValue:@(colorName4.c_str())];
    }
    else if (colorNo4 == "7"){
        [chLabel4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chLabel4 setStringValue:@"CH4:"];
        [chName4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chName4 setStringValue:@(colorName4.c_str())];
    }
    else if (colorNo4 == "8"){
        [chLabel4 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chLabel4 setStringValue:@"CH4:"];
        [chName4 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chName4 setStringValue:@(colorName4.c_str())];
    }
    else if (colorNo4 == "9"){
        [chLabel4 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chLabel4 setStringValue:@"CH4:"];
        [chName4 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chName4 setStringValue:@(colorName4.c_str())];
    }
    
    int holdTemp = (int)(levelHold4*1000);
    double holdTempDouble = holdTemp/(double)1000;
    
    [chLevel4 setDoubleValue:holdTempDouble];
    
    holdTemp = (int)(cutHold4*1000);
    holdTempDouble = holdTemp/(double)1000;
    
    [chCut4 setDoubleValue:holdTempDouble];
    
    if (statusHold4 == 0){
        [chStatus4 setStringValue:@"Off"];
    }
    else [chStatus4 setStringValue:@"On"];
    
    [sliderKnobLevel4 setIntegerValue:(long)levelHold4];
    [sliderKnobCut4 setDoubleValue:cutHold4];
}

-(void)setCH5:(int)mode{
    if (mode == 0){
        colorFlag5 = 1;
        
        unsigned long findString = fileList [(filePosition-1)*7+5].find("tif");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+5].find("TIF");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+5].find("bmp");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+5].find("BMP");
        
        colorNo5 = fileList [(filePosition-1)*7+5].substr(13, 1);
        colorName5 = fileList [(filePosition-1)*7+5].substr(15, findString-16);
        
        string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+5];
        
        if (uploadTempStatusCl5 == 1) delete [] uploadTempCl5;
        
        uploadTempCl5 = new uint8_t [uploadTempFileSize+50];
        uploadTempStatusCl5 = 1;
        
        ifstream fin;
        
        fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
        
        fin.read((char*)uploadTempCl5, (long)uploadTempFileSize+50);
        fin.close();
    }
    
    if (colorNo5 == "1"){
        [chLabel5 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chLabel5 setStringValue:@"CH5:"];
        [chName5 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chName5 setStringValue:@(colorName5.c_str())];
    }
    else if (colorNo5 == "2"){
        [chLabel5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chLabel5 setStringValue:@"CH5:"];
        [chName5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chName5 setStringValue:@(colorName5.c_str())];
    }
    else if (colorNo5 == "3"){
        [chLabel5 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chLabel5 setStringValue:@"CH5:"];
        [chName5 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chName5 setStringValue:@(colorName5.c_str())];
    }
    else if (colorNo5 == "4"){
        [chLabel5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chLabel5 setStringValue:@"CH5:"];
        [chName5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chName5 setStringValue:@(colorName5.c_str())];
    }
    else if (colorNo5 == "5"){
        [chLabel5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chLabel5 setStringValue:@"CH5:"];
        [chName5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chName5 setStringValue:@(colorName5.c_str())];
    }
    else if (colorNo5 == "6"){
        [chLabel5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chLabel5 setStringValue:@"CH5:"];
        [chName5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chName5 setStringValue:@(colorName5.c_str())];
    }
    else if (colorNo5 == "7"){
        [chLabel5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chLabel5 setStringValue:@"CH5:"];
        [chName5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chName5 setStringValue:@(colorName5.c_str())];
    }
    else if (colorNo5 == "8"){
        [chLabel5 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chLabel5 setStringValue:@"CH5:"];
        [chName5 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chName5 setStringValue:@(colorName5.c_str())];
    }
    else if (colorNo5 == "9"){
        [chLabel5 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chLabel5 setStringValue:@"CH5:"];
        [chName5 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chName5 setStringValue:@(colorName5.c_str())];
    }
    
    int holdTemp = (int)(levelHold5*1000);
    double holdTempDouble = holdTemp/(double)1000;
    
    [chLevel5 setDoubleValue:holdTempDouble];
    
    holdTemp = (int)(cutHold5*1000);
    holdTempDouble = holdTemp/(double)1000;
    
    [chCut5 setDoubleValue:holdTempDouble];
    
    if (statusHold5 == 0){
        [chStatus5 setStringValue:@"Off"];
    }
    else [chStatus5 setStringValue:@"On"];
    
    [sliderKnobLevel5 setIntegerValue:(long)levelHold5];
    [sliderKnobCut5 setDoubleValue:cutHold5];
}

-(void)setCH6:(int)mode{
    if (mode == 0){
        colorFlag6 = 1;
        
        unsigned long findString = fileList [(filePosition-1)*7+6].find("tif");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+6].find("TIF");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+6].find("bmp");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+6].find("BMP");
        
        colorNo6 = fileList [(filePosition-1)*7+6].substr(13, 1);
        colorName6 = fileList [(filePosition-1)*7+6].substr(15, findString-16);
        
        string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+6];
        
        if (uploadTempStatusCl6 == 1) delete [] uploadTempCl6;
        
        uploadTempCl6 = new uint8_t [uploadTempFileSize+50];
        uploadTempStatusCl6 = 1;
        
        ifstream fin;
        
        fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
        
        fin.read((char*)uploadTempCl6, (long)uploadTempFileSize+50);
        fin.close();
    }
    
    if (colorNo6 == "1"){
        [chLabel6 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chLabel6 setStringValue:@"CH6:"];
        [chName6 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chName6 setStringValue:@(colorName6.c_str())];
    }
    else if (colorNo6 == "2"){
        [chLabel6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chLabel6 setStringValue:@"CH6:"];
        [chName6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chName6 setStringValue:@(colorName6.c_str())];
    }
    else if (colorNo6 == "3"){
        [chLabel6 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chLabel6 setStringValue:@"CH6:"];
        [chName6 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chName6 setStringValue:@(colorName6.c_str())];
    }
    else if (colorNo6 == "4"){
        [chLabel6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chLabel6 setStringValue:@"CH6:"];
        [chName6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chName6 setStringValue:@(colorName6.c_str())];
    }
    else if (colorNo6 == "5"){
        [chLabel6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chLabel6 setStringValue:@"CH6:"];
        [chName6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chName6 setStringValue:@(colorName6.c_str())];
    }
    else if (colorNo6 == "6"){
        [chLabel6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chLabel6 setStringValue:@"CH6:"];
        [chName6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chName6 setStringValue:@(colorName6.c_str())];
    }
    else if (colorNo6 == "7"){
        [chLabel6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chLabel6 setStringValue:@"CH6:"];
        [chName6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chName6 setStringValue:@(colorName6.c_str())];
    }
    else if (colorNo6 == "8"){
        [chLabel6 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chLabel6 setStringValue:@"CH6:"];
        [chName6 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chName6 setStringValue:@(colorName6.c_str())];
    }
    else if (colorNo6 == "9"){
        [chLabel6 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chLabel6 setStringValue:@"CH6:"];
        [chName6 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chName6 setStringValue:@(colorName6.c_str())];
    }
    
    int holdTemp = (int)(levelHold6*1000);
    double holdTempDouble = holdTemp/(double)1000;
    
    [chLevel6 setDoubleValue:holdTempDouble];
    
    holdTemp = (int)(cutHold6*1000);
    holdTempDouble = holdTemp/(double)1000;
    
    [chCut6 setDoubleValue:holdTempDouble];
    
    if (statusHold6 == 0){
        [chStatus6 setStringValue:@"Off"];
    }
    else [chStatus6 setStringValue:@"On"];
    
    [sliderKnobLevel6 setIntegerValue:(long)levelHold6];
    [sliderKnobCut6 setDoubleValue:cutHold6];
}

-(IBAction)chSet1:(id)sender{
    if (colorFlag1 == 1){
        if (statusHold1 == 0){
            statusHold1 = 1;
            [chStatus1 setStringValue:@"On"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        else if (statusHold1 == 1){
            statusHold1 = 0;
            [chStatus1 setStringValue:@"Off"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)chSet2:(id)sender{
    if (colorFlag2 == 1){
        if (statusHold2 == 0){
            statusHold2 = 1;
            [chStatus2 setStringValue:@"On"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        else if (statusHold2 == 1){
            statusHold2 = 0;
            [chStatus2 setStringValue:@"Off"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)chSet3:(id)sender{
    if (colorFlag3 == 1){
        if (statusHold3 == 0){
            statusHold3 = 1;
            [chStatus3 setStringValue:@"On"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        else if (statusHold3 == 1){
            statusHold3 = 0;
            [chStatus3 setStringValue:@"Off"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)chSet4:(id)sender{
    if (colorFlag4 == 1){
        if (statusHold4 == 0){
            statusHold4 = 1;
            [chStatus4 setStringValue:@"On"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        else if (statusHold4 == 1){
            statusHold4 = 0;
            [chStatus4 setStringValue:@"Off"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)chSet5:(id)sender{
    if (colorFlag5 == 1){
        if (statusHold5 == 0){
            statusHold5 = 1;
            [chStatus5 setStringValue:@"On"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        else if (statusHold5 == 1){
            statusHold5 = 0;
            [chStatus5 setStringValue:@"Off"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)chSet6:(id)sender{
    if (colorFlag6 == 1){
        if (statusHold6 == 0){
            statusHold6 = 1;
            [chStatus6 setStringValue:@"On"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        else if (statusHold6 == 1){
            statusHold6 = 0;
            [chStatus6 setStringValue:@"Off"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderLevelCH1:(id)sender{
    if (colorFlag1 == 1 && imageProgressFlag == 0){
        levelHold1 = [sliderLevel1 doubleValue];
        
        int holdTemp = (int)(levelHold1*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chLevel1 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderLevelCH2:(id)sender{
    if (colorFlag2 == 1 && imageProgressFlag == 0){
        levelHold2 = [sliderLevel2 doubleValue];
        
        int holdTemp = (int)(levelHold2*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chLevel2 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderLevelCH3:(id)sender{
    if (colorFlag3 == 1 && imageProgressFlag == 0){
        levelHold3 = [sliderLevel3 doubleValue];
        
        int holdTemp = (int)(levelHold3*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chLevel3 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderLevelCH4:(id)sender{
    if (colorFlag4 == 1 && imageProgressFlag == 0){
        levelHold4 = [sliderLevel4 doubleValue];
        
        int holdTemp = (int)(levelHold4*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chLevel4 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderLevelCH5:(id)sender{
    if (colorFlag5 == 1 && imageProgressFlag == 0){
        levelHold5 = [sliderLevel5 doubleValue];
        
        int holdTemp = (int)(levelHold5*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chLevel5 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderLevelCH6:(id)sender{
    if (colorFlag6 == 1 && imageProgressFlag == 0){
        levelHold6 = [sliderLevel6 doubleValue];
        
        int holdTemp = (int)(levelHold6*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chLevel6 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderCutCH1:(id)sender{
    if (colorFlag1 == 1 && imageProgressFlag == 0){
        cutHold1 = [sliderCut1 doubleValue];
        
        int holdTemp = (int)(cutHold1*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chCut1 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderCutCH2:(id)sender{
    if (colorFlag2 == 1 && imageProgressFlag == 0){
        cutHold2 = [sliderCut2 doubleValue];
        
        int holdTemp = (int)(cutHold2*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chCut2 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderCutCH3:(id)sender{
    if (colorFlag3 == 1 && imageProgressFlag == 0){
        cutHold3 = [sliderCut3 doubleValue];
        
        int holdTemp = (int)(cutHold3*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chCut3 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderCutCH4:(id)sender{
    if (colorFlag4 == 1 && imageProgressFlag == 0){
        cutHold4 = [sliderCut4 doubleValue];
        
        int holdTemp = (int)(cutHold4*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chCut4 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderCutCH5:(id)sender{
    if (colorFlag5 == 1 && imageProgressFlag == 0){
        cutHold5 = [sliderCut5 doubleValue];
        
        int holdTemp = (int)(cutHold5*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chCut5 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderCutCH6:(id)sender{
    if (colorFlag6 == 1 && imageProgressFlag == 0){
        cutHold6 = [sliderCut6 doubleValue];
        
        int holdTemp = (int)(cutHold6*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chCut6 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderLevelDIC:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0 && imageProgressFlag == 0){
        levelHoldDIC = [sliderLevelDIC doubleValue];
        
        int holdTemp = (int)(levelHoldDIC*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chLevelDIC setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderCutDIC:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0 && imageProgressFlag == 0){
        cutHoldDIC = [sliderCutDIC doubleValue];
        
        int holdTemp = (int)(cutHoldDIC*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chCutDIC setDoubleValue:holdTempDouble];
        
        if (areaModeStatusHold == 1){
            double *newGravityCenterData = new double [(gravityCenterRevCount/6)*2+50];
            
            for (int counter1 = 0; counter1 < (gravityCenterRevCount/6)*2+50; counter1++) newGravityCenterData [counter1] = 0;
            
            for (int counterY = 0; counterY < imageSizeLimit; counterY++){
                for (int counterX = 0; counterX < imageSizeLimit; counterX++){
                    if (revisedMap [counterY][counterX] != 0 && sourceImage [counterY][counterX] > cutHoldDIC){
                        newGravityCenterData [revisedMap [counterY][counterX]*2]++;
                        newGravityCenterData [revisedMap [counterY][counterX]*2+1] = newGravityCenterData [revisedMap [counterY][counterX]*2+1]+sourceImage [counterY][counterX];
                    }
                }
            }
            
            for (int counter2 = 0; counter2 < gravityCenterRevCount/6; counter2++){
                arrayGravityCenterRev [counter2*6+2] = (int)newGravityCenterData [(counter2+1)*2];
                
                if (newGravityCenterData [(counter2+1)*2] != 0){
                    arrayGravityCenterRev [counter2*6+3] = (int)(newGravityCenterData [(counter2+1)*2+1]/(double)newGravityCenterData [(counter2+1)*2]);
                }
                else arrayGravityCenterRev [counter2*6+3] = 0;
            }
            
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                arrayTimeSelected [counter1*10+9] = 0;
            }
            
            for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                    if ((int)arrayDotDataHold [counter1*3+2] >= 0 && (int)arrayDotDataHold [counter1*3+2] < imageSizeLimit && (int)arrayDotDataHold [counter1*3+1] >= 0 && (int)arrayDotDataHold [counter1*3+1] < imageSizeLimit){
                        if (arrayTimeSelected [counter2*10+8] == revisedWorkingMap [(int)arrayDotDataHold [counter1*3+2]][(int)arrayDotDataHold [counter1*3+1]]){
                            arrayTimeSelected [counter2*10+9]++;
                            break;
                        }
                    }
                }
            }
            
            subProcesses = [[SubProcesses alloc] init];
            [subProcesses areaTotalDataSet];
            
            delete [] newGravityCenterData;
        }
        
        sliderStart = 1;
    }
}

-(IBAction)sliderLevelR:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0 && imageProgressFlag == 0){
        levelHoldR = [sliderLevelR doubleValue];
        
        int holdTemp = (int)(levelHoldR*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chLevelR setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderLevelG:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0 && imageProgressFlag == 0){
        levelHoldG = [sliderLevelG doubleValue];
        
        int holdTemp = (int)(levelHoldG*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chLevelG setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderLevelB:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0 && imageProgressFlag == 0){
        levelHoldB = [sliderLevelB doubleValue];
        
        int holdTemp = (int)(levelHoldB*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chLevelB setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)dicImageSelect:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0 && phaseStatus == 0 && imageProgressFlag == 0){
        if (statusHoldDIC == 0){
            statusHoldDIC = 1;
            
            string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7];
            
            if (statusHoldDIC == 1){
                if (filePosition > lastDICImageTime) imageMoviePath = imageDisplayPath+"/"+fileList [(lastDICImageTime-1)*7];
            }
            
            ifstream fin;
            fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
            
            fin.read((char*)uploadTemp, uploadTempFileSize+50);
            fin.close();
            
            [chDICImage setStringValue:@"Last Live"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        else if (statusHoldDIC == 1){
            statusHoldDIC = 0;
            
            string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7];
            
            if (statusHoldDIC == 1){
                if (filePosition > lastDICImageTime) imageMoviePath = imageDisplayPath+"/"+fileList [(lastDICImageTime-1)*7];
            }
            
            ifstream fin;
            fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
            
            fin.read((char*)uploadTemp, uploadTempFileSize+50);
            fin.close();
            
            [chDICImage setStringValue:@"IF Image"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)sliderLevelCHCircle1:(id)sender{
    if (colorFlag1 == 1){
        double sliderCircleValue = sliderFluorescentCHMax1*[sliderLevelCircle1 doubleValue];
        double sliderCircleValue2 = sliderFluorescentCHMin1/[sliderLevelCircle1 doubleValue];
        double sliderValue = [sliderLevel1 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderFluorescentCHDiff1;
        
        sliderCircleValue = sliderValue+(sliderFluorescentCHMax1-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderFluorescentCHMin1)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderLevel1 setMaxValue:sliderCircleValue];
        [sliderLevel1 setMinValue:sliderCircleValue2];
        
        int fluorescentEnhanceInt = (int)([sliderLevel1 doubleValue]*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chLevel1 setDoubleValue:fluorescentEnhanceDouble];
    }
}

-(IBAction)sliderLevelCHCircle2:(id)sender{
    if (colorFlag2 == 1){
        double sliderCircleValue = sliderFluorescentCHMax2*[sliderLevelCircle2 doubleValue];
        double sliderCircleValue2 = sliderFluorescentCHMin2/[sliderLevelCircle2 doubleValue];
        double sliderValue = [sliderLevel2 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderFluorescentCHDiff2;
        
        sliderCircleValue = sliderValue+(sliderFluorescentCHMax2-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderFluorescentCHMin2)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderLevel2 setMaxValue:sliderCircleValue];
        [sliderLevel2 setMinValue:sliderCircleValue2];
        
        int fluorescentEnhanceInt = (int)([sliderLevel2 doubleValue]*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chLevel2 setDoubleValue:fluorescentEnhanceDouble];
    }
}

-(IBAction)sliderLevelCHCircle3:(id)sender{
    if (colorFlag3 == 1){
        double sliderCircleValue = sliderFluorescentCHMax3*[sliderLevelCircle3 doubleValue];
        double sliderCircleValue2 = sliderFluorescentCHMin3/[sliderLevelCircle3 doubleValue];
        double sliderValue = [sliderLevel3 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderFluorescentCHDiff3;
        
        sliderCircleValue = sliderValue+(sliderFluorescentCHMax3-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderFluorescentCHMin3)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderLevel3 setMaxValue:sliderCircleValue];
        [sliderLevel3 setMinValue:sliderCircleValue2];
        
        int fluorescentEnhanceInt = (int)([sliderLevel3 doubleValue]*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chLevel3 setDoubleValue:fluorescentEnhanceDouble];
    }
}

-(IBAction)sliderLevelCHCircle4:(id)sender{
    if (colorFlag4 == 1){
        double sliderCircleValue = sliderFluorescentCHMax4*[sliderLevelCircle4 doubleValue];
        double sliderCircleValue2 = sliderFluorescentCHMin4/[sliderLevelCircle4 doubleValue];
        double sliderValue = [sliderLevel4 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderFluorescentCHDiff4;
        
        sliderCircleValue = sliderValue+(sliderFluorescentCHMax4-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderFluorescentCHMin4)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderLevel4 setMaxValue:sliderCircleValue];
        [sliderLevel4 setMinValue:sliderCircleValue2];
        
        int fluorescentEnhanceInt = (int)([sliderLevel4 doubleValue]*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chLevel4 setDoubleValue:fluorescentEnhanceDouble];
    }
}

-(IBAction)sliderLevelCHCircle5:(id)sender{
    if (colorFlag5 == 1){
        double sliderCircleValue = sliderFluorescentCHMax5*[sliderLevelCircle5 doubleValue];
        double sliderCircleValue2 = sliderFluorescentCHMin5/[sliderLevelCircle5 doubleValue];
        double sliderValue = [sliderLevel5 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderFluorescentCHDiff5;
        
        sliderCircleValue = sliderValue+(sliderFluorescentCHMax5-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderFluorescentCHMin5)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderLevel5 setMaxValue:sliderCircleValue];
        [sliderLevel5 setMinValue:sliderCircleValue2];
        
        int fluorescentEnhanceInt = (int)([sliderLevel5 doubleValue]*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chLevel5 setDoubleValue:fluorescentEnhanceDouble];
    }
}

-(IBAction)sliderLevelCHCircle6:(id)sender{
    if (colorFlag6 == 1){
        double sliderCircleValue = sliderFluorescentCHMax6*[sliderLevelCircle6 doubleValue];
        double sliderCircleValue2 = sliderFluorescentCHMin6/[sliderLevelCircle6 doubleValue];
        double sliderValue = [sliderLevel6 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderFluorescentCHDiff6;
        
        sliderCircleValue = sliderValue+(sliderFluorescentCHMax6-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderFluorescentCHMin6)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderLevel6 setMaxValue:sliderCircleValue];
        [sliderLevel6 setMinValue:sliderCircleValue2];
        
        int fluorescentEnhanceInt = (int)([sliderLevel6 doubleValue]*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chLevel6 setDoubleValue:fluorescentEnhanceDouble];
    }
}

-(IBAction)sliderCutCHCircle1:(id)sender{
    if (colorFlag1 == 1){
        double sliderCircleValue = sliderCutCHMax1*[sliderCutCircle1 doubleValue];
        double sliderCircleValue2 = sliderCutCHMin1/[sliderCutCircle1 doubleValue];
        double sliderValue = [sliderCut1 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderCutCHDiff1;
        
        sliderCircleValue = sliderValue+(sliderCutCHMax1-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderCutCHMin1)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderCut1 setMaxValue:sliderCircleValue];
        [sliderCut1 setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderCut1 doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [chCut1 setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)sliderCutCHCircle2:(id)sender{
    if (colorFlag2 == 1){
        double sliderCircleValue = sliderCutCHMax2*[sliderCutCircle2 doubleValue];
        double sliderCircleValue2 = sliderCutCHMin2/[sliderCutCircle2 doubleValue];
        double sliderValue = [sliderCut2 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderCutCHDiff2;
        
        sliderCircleValue = sliderValue+(sliderCutCHMax2-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderCutCHMin2)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderCut2 setMaxValue:sliderCircleValue];
        [sliderCut2 setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderCut2 doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [chCut2 setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)sliderCutCHCircle3:(id)sender{
    if (colorFlag3 == 1){
        double sliderCircleValue = sliderCutCHMax3*[sliderCutCircle3 doubleValue];
        double sliderCircleValue2 = sliderCutCHMin3/[sliderCutCircle3 doubleValue];
        double sliderValue = [sliderCut3 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderCutCHDiff3;
        
        sliderCircleValue = sliderValue+(sliderCutCHMax3-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderCutCHMin3)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderCut3 setMaxValue:sliderCircleValue];
        [sliderCut3 setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderCut3 doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [chCut3 setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)sliderCutCHCircle4:(id)sender{
    if (colorFlag4 == 1){
        double sliderCircleValue = sliderCutCHMax4*[sliderCutCircle4 doubleValue];
        double sliderCircleValue2 = sliderCutCHMin4/[sliderCutCircle4 doubleValue];
        double sliderValue = [sliderCut4 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderCutCHDiff4;
        
        sliderCircleValue = sliderValue+(sliderCutCHMax4-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderCutCHMin4)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderCut4 setMaxValue:sliderCircleValue];
        [sliderCut4 setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderCut4 doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [chCut4 setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)sliderCutCHCircle5:(id)sender{
    if (colorFlag5 == 1){
        double sliderCircleValue = sliderCutCHMax5*[sliderCutCircle5 doubleValue];
        double sliderCircleValue2 = sliderCutCHMin5/[sliderCutCircle5 doubleValue];
        double sliderValue = [sliderCut5 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderCutCHDiff5;
        
        sliderCircleValue = sliderValue+(sliderCutCHMax5-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderCutCHMin5)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderCut5 setMaxValue:sliderCircleValue];
        [sliderCut5 setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderCut5 doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [chCut5 setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)sliderCutCHCircle6:(id)sender{
    if (colorFlag6 == 1){
        double sliderCircleValue = sliderCutCHMax6*[sliderCutCircle6 doubleValue];
        double sliderCircleValue2 = sliderCutCHMin6/[sliderCutCircle6 doubleValue];
        double sliderValue = [sliderCut6 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderCutCHDiff6;
        
        sliderCircleValue = sliderValue+(sliderCutCHMax6-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderCutCHMin6)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderCut6 setMaxValue:sliderCircleValue];
        [sliderCut6 setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderCut6 doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [chCut6 setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)sliderLevelDICCircle:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0){
        double sliderCircleValue = sliderDICMax*[sliderLevelCircleDIC doubleValue];
        double sliderCircleValue2 = sliderDICMin/[sliderLevelCircleDIC doubleValue];
        double sliderValue = [sliderLevelDIC doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderDICDiff;
        
        sliderCircleValue = sliderValue+(sliderDICMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderDICMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderLevelDIC setMaxValue:sliderCircleValue];
        [sliderLevelDIC setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderLevelDIC doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [chLevelDIC setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)sliderCutDICCircle:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0){
        double sliderCircleValue = sliderCutDICMax*[sliderCutCircleDIC doubleValue];
        double sliderCircleValue2 = sliderCutDICMin/[sliderCutCircleDIC doubleValue];
        double sliderValue = [sliderCutDIC doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderCutDICDiff;
        
        sliderCircleValue = sliderValue+(sliderCutDICMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderCutDICMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderCutDIC setMaxValue:sliderCircleValue];
        [sliderCutDIC setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderCutDIC doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [chCutDIC setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)sliderLevelRCircle:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0){
        double sliderCircleValue = sliderRMax*[sliderLevelCircleR doubleValue];
        double sliderCircleValue2 = sliderRMin/[sliderLevelCircleR doubleValue];
        double sliderValue = [sliderLevelR doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderRDiff;
        
        sliderCircleValue = sliderValue+(sliderRMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderRMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderLevelR setMaxValue:sliderCircleValue];
        [sliderLevelR setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderLevelR doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [chLevelR setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)sliderLevelGCircle:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0){
        double sliderCircleValue = sliderGMax*[sliderLevelCircleG doubleValue];
        double sliderCircleValue2 = sliderGMin/[sliderLevelCircleG doubleValue];
        double sliderValue = [sliderLevelG doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderGDiff;
        
        sliderCircleValue = sliderValue+(sliderGMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderGMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderLevelG setMaxValue:sliderCircleValue];
        [sliderLevelG setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderLevelG doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [chLevelG setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)sliderLevelBCircle:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0){
        double sliderCircleValue = sliderBMax*[sliderLevelCircleB doubleValue];
        double sliderCircleValue2 = sliderBMin/[sliderLevelCircleB doubleValue];
        double sliderValue = [sliderLevelB doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderBDiff;
        
        sliderCircleValue = sliderValue+(sliderBMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderBMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderLevelB setMaxValue:sliderCircleValue];
        [sliderLevelB setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderLevelB doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [chLevelB setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)resetCH1:(id)sender{
    if (colorFlag1 == 1 && imageProgressFlag == 0){
        cutHold1 = 50;
        levelHold1 = 1;
        
        int baseCutInt = (int)(cutHold1*1000);
        double baseCutDouble = baseCutInt/(double)1000;
        int fluorescentEnhanceInt = (int)(levelHold1*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chCut1 setDoubleValue:baseCutDouble];
        [chLevel1 setDoubleValue:fluorescentEnhanceDouble];
        
        [sliderLevel1 setDoubleValue:1];
        [sliderCut1 setDoubleValue:50];
        [sliderLevelCircle1 setDoubleValue:1];
        [sliderCutCircle1 setDoubleValue:1];
        
        [sliderLevel1 setMaxValue:sliderFluorescentCHMax1];
        [sliderLevel1 setMinValue:sliderFluorescentCHMin1];
        
        [sliderCut1 setMaxValue:sliderCutCHMax1];
        [sliderCut1 setMinValue:sliderCutCHMin1];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)resetCH2:(id)sender{
    if (colorFlag2 == 1 && imageProgressFlag == 0){
        cutHold2 = 50;
        levelHold2 = 1;
        
        int baseCutInt = (int)(cutHold2*1000);
        double baseCutDouble = baseCutInt/(double)1000;
        int fluorescentEnhanceInt = (int)(levelHold2*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chCut2 setDoubleValue:baseCutDouble];
        [chLevel2 setDoubleValue:fluorescentEnhanceDouble];
        
        [sliderLevel2 setDoubleValue:1];
        [sliderCut2 setDoubleValue:50];
        [sliderLevelCircle2 setDoubleValue:1];
        [sliderCutCircle2 setDoubleValue:1];
        
        [sliderLevel2 setMaxValue:sliderFluorescentCHMax2];
        [sliderLevel2 setMinValue:sliderFluorescentCHMin2];
        
        [sliderCut2 setMaxValue:sliderCutCHMax2];
        [sliderCut2 setMinValue:sliderCutCHMin2];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)resetCH3:(id)sender{
    if (colorFlag3 == 1 && imageProgressFlag == 0){
        cutHold3 = 50;
        levelHold3 = 1;
        
        int baseCutInt = (int)(cutHold3*1000);
        double baseCutDouble = baseCutInt/(double)1000;
        int fluorescentEnhanceInt = (int)(levelHold3*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chCut3 setDoubleValue:baseCutDouble];
        [chLevel3 setDoubleValue:fluorescentEnhanceDouble];
        
        [sliderLevel3 setDoubleValue:1];
        [sliderCut3 setDoubleValue:50];
        [sliderLevelCircle3 setDoubleValue:1];
        [sliderCutCircle3 setDoubleValue:1];
        
        [sliderLevel3 setMaxValue:sliderFluorescentCHMax3];
        [sliderLevel3 setMinValue:sliderFluorescentCHMin3];
        
        [sliderCut3 setMaxValue:sliderCutCHMax3];
        [sliderCut3 setMinValue:sliderCutCHMin3];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)resetCH4:(id)sender{
    if (colorFlag4 == 1 && imageProgressFlag == 0){
        cutHold4 = 50;
        levelHold4 = 1;
        
        int baseCutInt = (int)(cutHold4*1000);
        double baseCutDouble = baseCutInt/(double)1000;
        int fluorescentEnhanceInt = (int)(levelHold4*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chCut4 setDoubleValue:baseCutDouble];
        [chLevel4 setDoubleValue:fluorescentEnhanceDouble];
        
        [sliderLevel4 setDoubleValue:1];
        [sliderCut4 setDoubleValue:50];
        [sliderLevelCircle4 setDoubleValue:1];
        [sliderCutCircle4 setDoubleValue:1];
        
        [sliderLevel4 setMaxValue:sliderFluorescentCHMax4];
        [sliderLevel4 setMinValue:sliderFluorescentCHMin4];
        
        [sliderCut4 setMaxValue:sliderCutCHMax4];
        [sliderCut4 setMinValue:sliderCutCHMin4];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)resetCH5:(id)sender{
    if (colorFlag5 == 1 && imageProgressFlag == 0){
        cutHold5 = 50;
        levelHold5 = 1;
        
        int baseCutInt = (int)(cutHold5*1000);
        double baseCutDouble = baseCutInt/(double)1000;
        int fluorescentEnhanceInt = (int)(levelHold5*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chCut5 setDoubleValue:baseCutDouble];
        [chLevel5 setDoubleValue:fluorescentEnhanceDouble];
        
        [sliderLevel5 setDoubleValue:1];
        [sliderCut5 setDoubleValue:50];
        [sliderLevelCircle5 setDoubleValue:1];
        [sliderCutCircle5 setDoubleValue:1];
        
        [sliderLevel5 setMaxValue:sliderFluorescentCHMax5];
        [sliderLevel5 setMinValue:sliderFluorescentCHMin5];
        
        [sliderCut5 setMaxValue:sliderCutCHMax5];
        [sliderCut5 setMinValue:sliderCutCHMin5];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)resetCH6:(id)sender{
    if (colorFlag6 == 1 && imageProgressFlag == 0){
        cutHold6 = 50;
        levelHold6 = 1;
        
        int baseCutInt = (int)(cutHold6*1000);
        double baseCutDouble = baseCutInt/(double)1000;
        int fluorescentEnhanceInt = (int)(levelHold6*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chCut6 setDoubleValue:baseCutDouble];
        [chLevel6 setDoubleValue:fluorescentEnhanceDouble];
        
        [sliderLevel6 setDoubleValue:1];
        [sliderCut6 setDoubleValue:50];
        [sliderLevelCircle6 setDoubleValue:1];
        [sliderCutCircle6 setDoubleValue:1];
        
        [sliderLevel6 setMaxValue:sliderFluorescentCHMax6];
        [sliderLevel6 setMinValue:sliderFluorescentCHMin6];
        
        [sliderCut6 setMaxValue:sliderCutCHMax6];
        [sliderCut6 setMinValue:sliderCutCHMin6];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)resetDIC:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0 && imageProgressFlag == 0){
        cutHoldDIC = 0;
        levelHoldDIC = 1;
        
        int baseCutInt = (int)(cutHoldDIC*1000);
        double baseCutDouble = baseCutInt/(double)1000;
        int fluorescentEnhanceInt = (int)(levelHoldDIC*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chCutDIC setDoubleValue:baseCutDouble];
        [chLevelDIC setDoubleValue:fluorescentEnhanceDouble];
        
        [sliderLevelDIC setDoubleValue:1];
        [sliderCutDIC setDoubleValue:50];
        [sliderLevelCircleDIC setDoubleValue:1];
        [sliderCutCircleDIC setDoubleValue:1];
        
        [sliderLevelDIC setMaxValue:sliderDICMax];
        [sliderLevelDIC setMinValue:sliderDICMin];
        
        [sliderCutDIC setMaxValue:sliderCutDICMax];
        [sliderCutDIC setMinValue:sliderCutDICMin];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)resetR:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0 && imageProgressFlag == 0){
        levelHoldR = 1;
        
        int fluorescentEnhanceInt = (int)(levelHoldR*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chLevelR setDoubleValue:fluorescentEnhanceDouble];
        
        [sliderLevelR setDoubleValue:1];
        [sliderLevelCircleR setDoubleValue:1];
        
        [sliderLevelR setMaxValue:sliderRMax];
        [sliderLevelR setMinValue:sliderRMin];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)resetG:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0 && imageProgressFlag == 0){
        levelHoldG = 1;
        
        int fluorescentEnhanceInt = (int)(levelHoldG*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chLevelG setDoubleValue:fluorescentEnhanceDouble];
        
        [sliderLevelG setDoubleValue:1];
        [sliderLevelCircleG setDoubleValue:1];
        
        [sliderLevelG setMaxValue:sliderGMax];
        [sliderLevelG setMinValue:sliderGMin];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)resetB:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0 && imageProgressFlag == 0){
        levelHoldB = 1;
        
        int fluorescentEnhanceInt = (int)(levelHoldB*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chLevelB setDoubleValue:fluorescentEnhanceDouble];
        
        [sliderLevelB setDoubleValue:1];
        [sliderLevelCircleB setDoubleValue:1];
        
        [sliderLevelB setMaxValue:sliderBMax];
        [sliderLevelB setMinValue:sliderBMin];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = 20;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    
    if (initialArraySet == 1 && timePointHold >= 1){
        string displayData1;
        
        if (rowIndex == 0) displayData1 = "Image Area";
        else if (rowIndex == 1) displayData1 = "Image Total";
        else if (rowIndex == 2) displayData1 = "Average";
        else if (rowIndex == 3) displayData1 = "Dot Count";
        else if (rowIndex == 4) displayData1 = "Selected area";
        else if (rowIndex == 5) displayData1 = "Area";
        else if (rowIndex == 6) displayData1 = "Total";
        
        else if (rowIndex == 7) displayData1 = "N0";
        else if (rowIndex == 8) displayData1 = "N1-2";
        else if (rowIndex == 9) displayData1 = "N3-4";
        else if (rowIndex == 10) displayData1 = "N5-6";
        else if (rowIndex == 11) displayData1 = "N7-8";
        else if (rowIndex == 12) displayData1 = "N9-10";
        else if (rowIndex == 13) displayData1 = "N11-12";
        else if (rowIndex == 14) displayData1 = "N13-14";
        else if (rowIndex == 15) displayData1 = "N15-16";
        else if (rowIndex == 16) displayData1 = "N17-18";
        else if (rowIndex == 17) displayData1 = "N19-20";
        else if (rowIndex == 18) displayData1 = "N21-22";
        else if (rowIndex == 19) displayData1 = "N>=23";
        
        string displayData2;
        
        if (rowIndex >= 0 && rowIndex <= 3){
            displayData2 = to_string(arrayAreaDataHold [(timePointHold-1)*25+rowIndex+2]);
        }
        else if (rowIndex >= 5){
            displayData2 = to_string(arrayAreaDataHold [(timePointHold-1)*25+rowIndex+5]);
        }
        
        if (rowIndex == 0 && (int)displayData2.find(".") != -1){
            displayData2 = displayData2.substr(0, displayData2.find("."));
        }
        else if (rowIndex == 1 && (int)displayData2.find(".") != -1){
            displayData2 = displayData2.substr(0, displayData2.find("."));
        }
        else if (rowIndex == 2 && (int)displayData2.find(".") != -1){
            displayData2 = displayData2.substr(0, displayData2.find(".")+2);
        }
        else if (rowIndex == 3 && (int)displayData2.find(".") != -1){
            displayData2 = displayData2.substr(0, displayData2.find("."));
        }
        else if (rowIndex == 4){
            if (areaTotalTable == 0) displayData2 = "Area";
            else if (areaTotalTable == 1) displayData2 = "Total";
        }
        else if (rowIndex >= 5 && (int)displayData2.find(".") != -1){
            displayData2 = displayData2.substr(0, displayData2.find("."));
        }
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else{
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    
    return attrStr;
}

-(IBAction)areaModeSet:(id)sender{
    if (initialArraySet == 1 && timePointHold >= 1 && imageProgressFlag == 0){
        if (areaModeStatusHold == 0){
            areaSetDone = 0;
            areaModeStatusHold = 1;
            imageProgressFlag = 1;
            
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
                self->progressTimingB = 6;
                
                do usleep(10);
                while (self->progressTimingB == 6);
                
                ifstream fin;
                
                string extension = to_string(timePointHold);
                
                if (extension.length() == 1) extension = "000"+extension;
                else if (extension.length() == 2) extension = "00"+extension;
                else if (extension.length() == 3) extension = "0"+extension;
                
                string connectDataPath = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Processed/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_MasterData";
                string connectDataRevPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_MasterData";
                
                struct stat sizeOfFile;
                
                long sizeForCopy = 0;
                long sizeForCopy2 = 0;
                long size1 = 0;
                long size2 = 0;
                int checkFlag = 0;
                
                for (int counter1 = 0; counter1 < 6; counter1++){
                    sizeForCopy = 0;
                    
                    if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    else if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        if (counter1 == 0) size1 = sizeForCopy;
                        else if (counter1 == 1) size2 = sizeForCopy;
                        else if (counter1 == 2){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                                break;
                            }
                            else{
                                
                                size1 = 0;
                                size2 = 0;
                                usleep (50000);
                            }
                        }
                        else if (counter1 == 3) size1 = sizeForCopy;
                        else if (counter1 == 4) size2 = sizeForCopy;
                        else if (counter1 == 5){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                            }
                        }
                    }
                }
                
                if (checkFlag == 1){
                    int errorFlag = 0;
                    
                    delete [] arrayPositionRevise;
                    arrayPositionRevise = new int [sizeForCopy+50];
                    positionReviseCount = 0;
                    positionReviseLimit = (int)sizeForCopy+50;
                    
                    sizeForCopy2 = (long)(sizeForCopy*(double)0.1+50);
                    delete [] arrayGravityCenterRev;
                    arrayGravityCenterRev = new int [sizeForCopy2+50];
                    gravityCenterRevCount = 0;
                    gravityCenterRevLimit = (int)sizeForCopy2+50;
                    
                    fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        int finData [17];
                        
                        uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTempA, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 || (finData [0] = uploadTempA [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTempA, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 || (finData [0] = uploadTempA [sizeForCopy-12]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTempA, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 || (finData [0] = uploadTempA [sizeForCopy-12]) != 0){
                                    errorFlag = 1;
                                }
                            }
                        }
                        
                        fin.close();
                        
                        if (errorFlag == 0){
                            unsigned long readPosition = 0;
                            int stepCount = 0;
                            
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTempA [readPosition], readPosition++;
                                    finData [1] = uploadTempA [readPosition], readPosition++; //--1
                                    finData [2] = uploadTempA [readPosition], readPosition++;
                                    finData [3] = uploadTempA [readPosition], readPosition++; //--2
                                    finData [4] = uploadTempA [readPosition], readPosition++; //--3
                                    finData [5] = uploadTempA [readPosition], readPosition++;
                                    finData [6] = uploadTempA [readPosition], readPosition++;
                                    finData [7] = uploadTempA [readPosition], readPosition++; //--4
                                    finData [8] = uploadTempA [readPosition], readPosition++; //--+/- flag
                                    finData [9] = uploadTempA [readPosition], readPosition++;
                                    finData [10] = uploadTempA [readPosition], readPosition++;
                                    finData [11] = uploadTempA [readPosition], readPosition++;
                                    finData [12] = uploadTempA [readPosition], readPosition++; //--5
                                    finData [13] = uploadTempA [readPosition], readPosition++; //--6
                                    finData [14] = uploadTempA [readPosition], readPosition++;
                                    finData [15] = uploadTempA [readPosition], readPosition++;
                                    finData [16] = uploadTempA [readPosition], readPosition++; //--7
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                    
                                    if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                    else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                    
                                    finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                    else{
                                        
                                        arrayPositionRevise [positionReviseCount] = finData [1], positionReviseCount++;
                                        arrayPositionRevise [positionReviseCount] = finData [3], positionReviseCount++;
                                        arrayPositionRevise [positionReviseCount] = finData [4], positionReviseCount++;
                                        arrayPositionRevise [positionReviseCount] = finData [7], positionReviseCount++;
                                        arrayPositionRevise [positionReviseCount] = finData [12], positionReviseCount++;
                                        arrayPositionRevise [positionReviseCount] = finData [13], positionReviseCount++;
                                        arrayPositionRevise [positionReviseCount] = finData [16], positionReviseCount++;
                                    }
                                }
                                else if (stepCount == 1){
                                    finData [0] = uploadTempA [readPosition], readPosition++;
                                    finData [1] = uploadTempA [readPosition], readPosition++; //--1
                                    finData [2] = uploadTempA [readPosition], readPosition++;
                                    finData [3] = uploadTempA [readPosition], readPosition++; //--2
                                    finData [4] = uploadTempA [readPosition], readPosition++;
                                    finData [5] = uploadTempA [readPosition], readPosition++;
                                    finData [6] = uploadTempA [readPosition], readPosition++; //--3
                                    finData [7] = uploadTempA [readPosition], readPosition++; //--4
                                    finData [8] = uploadTempA [readPosition], readPosition++;
                                    finData [9] = uploadTempA [readPosition], readPosition++;
                                    finData [10] = uploadTempA [readPosition], readPosition++; //--5
                                    finData [11] = uploadTempA [readPosition], readPosition++; //--6
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                    finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                    else{
                                        
                                        if (gravityCenterRevCount+1 > gravityCenterRevLimit) [self gravityCenterRevUpDate];
                                        
                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [1], gravityCenterRevCount++;
                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [3], gravityCenterRevCount++;
                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [6], gravityCenterRevCount++;
                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [7], gravityCenterRevCount++;
                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [10], gravityCenterRevCount++;
                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [11], gravityCenterRevCount++;
                                    }
                                }
                                
                            } while (stepCount != 3);
                        }
                        
                        delete [] uploadTempA;
                    }
                    else{
                        
                        fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            int finData [11];
                            
                            uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                            fin.read((char*)uploadTempA, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 ){
                                        errorFlag = 1;
                                    }
                                }
                            }
                            
                            fin.close();
                            
                            if (errorFlag == 0){
                                unsigned long readPosition = 0;
                                int stepCount = 0;
                                
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTempA [readPosition], readPosition++;
                                        finData [1] = uploadTempA [readPosition], readPosition++; //--2
                                        finData [2] = uploadTempA [readPosition], readPosition++;
                                        finData [3] = uploadTempA [readPosition], readPosition++; //--2
                                        finData [4] = uploadTempA [readPosition], readPosition++; //--1
                                        finData [5] = uploadTempA [readPosition], readPosition++;
                                        finData [6] = uploadTempA [readPosition], readPosition++;
                                        finData [7] = uploadTempA [readPosition], readPosition++; //--3
                                        finData [8] = uploadTempA [readPosition], readPosition++; //--1
                                        finData [9] = uploadTempA [readPosition], readPosition++;
                                        
                                        finData [1] = finData [0]*256+finData [1];
                                        finData [3] = finData [2]*256+finData [3];
                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                        
                                        if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                        else{
                                            
                                            arrayPositionRevise [positionReviseCount] = finData [1], positionReviseCount++; //------X position------
                                            arrayPositionRevise [positionReviseCount] = finData [3], positionReviseCount++; //------Y position------
                                            arrayPositionRevise [positionReviseCount] = finData [4], positionReviseCount++; //------Value------
                                            arrayPositionRevise [positionReviseCount] = finData [7], positionReviseCount++; //------Connect No------
                                            arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //------Cell No------
                                            arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //------Status------
                                            arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //------Lineage no------
                                        }
                                    }
                                    else if (stepCount == 1){
                                        finData [0] = uploadTempA [readPosition], readPosition++;
                                        finData [1] = uploadTempA [readPosition], readPosition++;
                                        finData [2] = uploadTempA [readPosition], readPosition++; //--1
                                        finData [3] = uploadTempA [readPosition], readPosition++; //--2
                                        finData [4] = uploadTempA [readPosition], readPosition++; //--3
                                        finData [5] = uploadTempA [readPosition], readPosition++;
                                        finData [6] = uploadTempA [readPosition], readPosition++;
                                        finData [7] = uploadTempA [readPosition], readPosition++; //--4
                                        finData [8] = uploadTempA [readPosition], readPosition++;
                                        finData [9] = uploadTempA [readPosition], readPosition++; //--5
                                        finData [10] = uploadTempA [readPosition], readPosition++; //--6
                                        
                                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                        finData [9] = finData [8]*256+finData [9];
                                        
                                        if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                    }
                                    else if (stepCount == 2){
                                        finData [0] = uploadTempA [readPosition], readPosition++;
                                        finData [1] = uploadTempA [readPosition], readPosition++; //--1
                                        finData [2] = uploadTempA [readPosition], readPosition++;
                                        finData [3] = uploadTempA [readPosition], readPosition++; //--2
                                        finData [4] = uploadTempA [readPosition], readPosition++;
                                        finData [5] = uploadTempA [readPosition], readPosition++;
                                        finData [6] = uploadTempA [readPosition], readPosition++; //--3
                                        finData [7] = uploadTempA [readPosition], readPosition++; //--4
                                        finData [8] = uploadTempA [readPosition], readPosition++;
                                        finData [9] = uploadTempA [readPosition], readPosition++;
                                        finData [10] = uploadTempA [readPosition], readPosition++; //--5
                                        
                                        finData [1] = finData [0]*256+finData [1];
                                        finData [3] = finData [2]*256+finData [3];
                                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                        finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                        
                                        if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                        else{
                                            
                                            if (gravityCenterRevCount+1 > gravityCenterRevLimit) [self gravityCenterRevUpDate];
                                            
                                            arrayGravityCenterRev [gravityCenterRevCount] = finData [1], gravityCenterRevCount++;
                                            arrayGravityCenterRev [gravityCenterRevCount] = finData [3], gravityCenterRevCount++;
                                            arrayGravityCenterRev [gravityCenterRevCount] = finData [6], gravityCenterRevCount++;
                                            arrayGravityCenterRev [gravityCenterRevCount] = finData [7], gravityCenterRevCount++;
                                            arrayGravityCenterRev [gravityCenterRevCount] = finData [10], gravityCenterRevCount++;
                                            arrayGravityCenterRev [gravityCenterRevCount] = 0, gravityCenterRevCount++;
                                        }
                                    }
                                    
                                } while (stepCount != 3);
                            }
                            
                            delete [] uploadTempA;
                        }
                    }
                    
                    if (errorFlag == 0){
                        //------Master Data Status UpLoad------
                        string connectStatusDataPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_Status";
                        
                        sizeForCopy = 0;
                        
                        if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy < gravityCenterRevCount*2) sizeForCopy = gravityCenterRevCount*2;
                        
                        delete [] arrayTimeSelected;
                        arrayTimeSelected = new int [sizeForCopy+500];
                        timeSelectedCount = 0;
                        timeSelectedLimit = (int)sizeForCopy+500;
                        
                        int firstRead = 0;
                        errorFlag = 0;
                        
                        fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            int finData [19];
                            
                            uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                            fin.read((char*)uploadTempA, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 || (finData [0] = uploadTempA [sizeForCopy-12]) != 0 || (finData [0] = uploadTempA [sizeForCopy-13]) != 0 || (finData [0] = uploadTempA [sizeForCopy-14]) != 0 || (finData [0] = uploadTempA [sizeForCopy-15]) != 0 || (finData [0] = uploadTempA [sizeForCopy-16]) != 0 || (finData [0] = uploadTempA [sizeForCopy-17]) != 0 || (finData [0] = uploadTempA [sizeForCopy-18]) != 0 || (finData [0] = uploadTempA [sizeForCopy-19]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTempA, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 || (finData [0] = uploadTempA [sizeForCopy-12]) != 0 || (finData [0] = uploadTempA [sizeForCopy-13]) != 0 || (finData [0] = uploadTempA [sizeForCopy-14]) != 0 || (finData [0] = uploadTempA [sizeForCopy-15]) != 0 || (finData [0] = uploadTempA [sizeForCopy-16]) != 0 || (finData [0] = uploadTempA [sizeForCopy-17]) != 0 || (finData [0] = uploadTempA [sizeForCopy-18]) != 0 || (finData [0] = uploadTempA [sizeForCopy-19]) != 0){
                                    errorFlag = 1;
                                }
                            }
                            
                            fin.close();
                            
                            if (errorFlag == 0){
                                unsigned long readPosition = 0;
                                int stepCount = 0;
                                
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTempA [readPosition], readPosition++; //--1 Status
                                        finData [1] = uploadTempA [readPosition], readPosition++;
                                        finData [2] = uploadTempA [readPosition], readPosition++;
                                        finData [3] = uploadTempA [readPosition], readPosition++; //--3 Prev connect
                                        finData [4] = uploadTempA [readPosition], readPosition++;
                                        finData [5] = uploadTempA [readPosition], readPosition++;
                                        finData [6] = uploadTempA [readPosition], readPosition++; //--4 Start position
                                        finData [7] = uploadTempA [readPosition], readPosition++;
                                        finData [8] = uploadTempA [readPosition], readPosition++; //--5 Cut no
                                        finData [9] = uploadTempA [readPosition], readPosition++; //--6 Ch2
                                        finData [10] = uploadTempA [readPosition], readPosition++; //--7 Ch3
                                        finData [11] = uploadTempA [readPosition], readPosition++; //--8 Ch4
                                        finData [12] = uploadTempA [readPosition], readPosition++; //--9 Ch5
                                        finData [13] = uploadTempA [readPosition], readPosition++;
                                        finData [14] = uploadTempA [readPosition], readPosition++;
                                        finData [15] = uploadTempA [readPosition], readPosition++; //--10 Connect no.
                                        finData [16] = uploadTempA [readPosition], readPosition++;
                                        finData [17] = uploadTempA [readPosition], readPosition++;
                                        finData [18] = uploadTempA [readPosition], readPosition++; //--11 Ling no.
                                        
                                        finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                        finData [8] = finData [7]*256+finData [8];
                                        finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                                        finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                                        
                                        if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                                        else{
                                            
                                            arrayTimeSelected [timeSelectedCount] = finData [0], timeSelectedCount++; //------Selected, removed, eliminated status------
                                            arrayTimeSelected [timeSelectedCount] = finData [3], timeSelectedCount++; //------When new line is created, enter line number which creates------
                                            arrayTimeSelected [timeSelectedCount] = finData [6], timeSelectedCount++; //------PositionRevise Start------
                                            arrayTimeSelected [timeSelectedCount] = finData [8], timeSelectedCount++; //------Cut line number------
                                            arrayTimeSelected [timeSelectedCount] = finData [9], timeSelectedCount++; //------X Start------
                                            arrayTimeSelected [timeSelectedCount] = finData [10], timeSelectedCount++; //------X End------
                                            arrayTimeSelected [timeSelectedCount] = finData [11], timeSelectedCount++; //------Y Start------
                                            arrayTimeSelected [timeSelectedCount] = finData [12], timeSelectedCount++; //------Y End------
                                            arrayTimeSelected [timeSelectedCount] = finData [15], timeSelectedCount++; //------Connect------
                                            arrayTimeSelected [timeSelectedCount] = finData [18], timeSelectedCount++; //------Lineage------
                                        }
                                    }
                                    
                                } while (stepCount != 3);
                            }
                            
                            delete [] uploadTempA;
                        }
                        else{
                            
                            firstRead = 1;
                            
                            for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){ //------Counter number corresponds to connect No------
                                arrayTimeSelected [timeSelectedCount] = 1, timeSelectedCount++; //------Selected, removed, eliminated status------
                                arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------When new line is created, enter line number which creates------
                                arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------PositionRevise Start------
                                arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------Cut line number------
                                arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------X Start------
                                arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------X End------
                                arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------Y Start------
                                arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------Y End------
                                arrayTimeSelected [timeSelectedCount] = counter1+1, timeSelectedCount++; //------Connect------
                                arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------Lineage------
                            }
                            
                            int valueTemp = 0;
                            
                            for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                                if (arrayPositionRevise [counter1*7+3] != valueTemp){
                                    valueTemp = arrayPositionRevise [counter1*7+3];
                                    arrayTimeSelected [(valueTemp-1)*10+2] = counter1;
                                    
                                    if (arrayPositionRevise [counter1*7+5] == 0){
                                        arrayTimeSelected [(valueTemp-1)*10] = 0;
                                    }
                                }
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                            if (arrayTimeSelected [counter1*10] == 2) arrayTimeSelected [counter1*10] = 0;
                            else if (arrayTimeSelected [counter1*10] == 7) arrayTimeSelected [counter1*10] = 1;
                        }
                        
                        if (errorFlag == 0){
                            string sourceImagePath = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+extension+".bmp";
                            string mapPath = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Processed/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_Map";
                            string revisedMapPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_RevisedMap";
                            
                            for (int counter1 = 0; counter1 < imageSizeLimit+1; counter1++){
                                delete [] sourceImage [counter1];
                                delete [] revisedMap [counter1];
                                delete [] revisedWorkingMap [counter1];
                                delete [] connectMap200 [counter1];
                                delete [] connectMap220 [counter1];
                                delete [] connectMap240 [counter1];
                                delete [] connectMapA [counter1];
                                delete [] connectMapB [counter1];
                                delete [] connectMapC [counter1];
                                delete [] connectMapD [counter1];
                            }
                            
                            delete [] sourceImage;
                            delete [] revisedMap;
                            delete [] revisedWorkingMap;
                            delete [] connectMap200;
                            delete [] connectMap220;
                            delete [] connectMap240;
                            delete [] connectMapA;
                            delete [] connectMapB;
                            delete [] connectMapC;
                            delete [] connectMapD;
                            
                            imageSizeLimit = imageXYLength;
                            
                            sourceImage = new int *[imageSizeLimit+1];
                            revisedMap = new int *[imageSizeLimit+1];
                            revisedWorkingMap = new int *[imageSizeLimit+1];
                            connectMap200 = new int *[imageSizeLimit+1];
                            connectMap220 = new int *[imageSizeLimit+1];
                            connectMap240 = new int *[imageSizeLimit+1];
                            connectMapA = new int *[imageSizeLimit+1];
                            connectMapB = new int *[imageSizeLimit+1];
                            connectMapC = new int *[imageSizeLimit+1];
                            connectMapD = new int *[imageSizeLimit+1];
                            
                            for (int counter1 = 0; counter1 < imageSizeLimit+1; counter1++){
                                sourceImage [counter1] = new int [imageSizeLimit+1];
                                revisedMap [counter1] = new int [imageSizeLimit+1];
                                revisedWorkingMap [counter1] = new int [imageSizeLimit+1];
                                connectMap200 [counter1] = new int [imageSizeLimit+1];
                                connectMap220 [counter1] = new int [imageSizeLimit+1];
                                connectMap240 [counter1] = new int [imageSizeLimit+1];
                                connectMapA [counter1] = new int [imageSizeLimit+1];
                                connectMapB [counter1] = new int [imageSizeLimit+1];
                                connectMapC [counter1] = new int [imageSizeLimit+1];
                                connectMapD [counter1] = new int [imageSizeLimit+1];
                            }
                            
                            if (stat(sourceImagePath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                fin.open(sourceImagePath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.read((char*)uploadTempA, sizeForCopy+50);
                                    fin.close();
                                    
                                    int imageDimensionReadCount = 0;
                                    
                                    for (int counter1 = imageSizeLimit-1; counter1 >= 0; counter1--){
                                        for (int counter2 = 0; counter2 < imageSizeLimit; counter2++){
                                            sourceImage [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageSizeLimit+counter2];
                                        }
                                        
                                        imageDimensionReadCount++;
                                    }
                                }
                                
                                delete [] uploadTempA;
                            }
                            
                            //--------Map Data set-------
                            int *connectAnalysisX = new int [imageSizeLimit*4];
                            int *connectAnalysisY = new int [imageSizeLimit*4];
                            int *connectAnalysisTempX = new int [imageSizeLimit*4];
                            int *connectAnalysisTempY = new int [imageSizeLimit*4];
                            
                            int connectivityNumber = 0;
                            int connectAnalysisCount = 0;
                            int connectAnalysisTempCount = 0;
                            int xSource = 0;
                            int ySource = 0;
                            int connectTemp = 0;
                            int cutOffSet = 0;
                            int cutOff1 = 240;
                            int cutOff2 = 230;
                            int cutOff3 = 220;
                            int cutOff4 = 190;
                            int cutOff5 = 160;
                            int cutOff6 = 130;
                            int cutOff7 = 90;
                            int terminationFlag = 0;
                            
                            for (int counter1 = 1; counter1 <= 7; counter1++){
                                if (counter1 == 1) cutOffSet = cutOff1;
                                else if (counter1 == 2) cutOffSet = cutOff2;
                                else if (counter1 == 3) cutOffSet = cutOff3;
                                else if (counter1 == 4) cutOffSet = cutOff4;
                                else if (counter1 == 5) cutOffSet = cutOff5;
                                else if (counter1 == 6) cutOffSet = cutOff6;
                                else if (counter1 == 7) cutOffSet = cutOff7;
                                
                                for (int counterY = 0; counterY < imageSizeLimit; counterY++){ //------RevisedMap, temporally used--------
                                    for (int counterX = 0; counterX < imageSizeLimit; counterX++){
                                        if (sourceImage [counterY][counterX] == 100) revisedMap [counterY][counterX] = 0;
                                        else if (sourceImage [counterY][counterX] < cutOffSet) revisedMap [counterY][counterX] = 0;
                                        else revisedMap [counterY][counterX] = -150;
                                    }
                                }
                                
                                connectivityNumber = 0;
                                
                                for (int counterY = 0; counterY < imageSizeLimit; counterY++){
                                    for (int counterX = 0; counterX < imageSizeLimit; counterX++){
                                        if (revisedMap [counterY][counterX] == -150){
                                            connectivityNumber++;
                                            revisedMap [counterY][counterX] = connectivityNumber;
                                            connectAnalysisCount = 0;
                                            
                                            if (counterY-1 >= 0 && counterX-1 >= 0 && revisedMap [counterY-1][counterX-1] == -150){
                                                revisedMap [counterY-1][counterX-1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                            }
                                            if (counterY-1 >= 0 && revisedMap [counterY-1][counterX] == -150){
                                                revisedMap [counterY-1][counterX] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                            }
                                            if (counterY-1 >= 0 && counterX+1 < imageSizeLimit && revisedMap [counterY-1][counterX+1] == -150){
                                                revisedMap [counterY-1][counterX+1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                            }
                                            if (counterX+1 < imageSizeLimit && revisedMap [counterY][counterX+1] == -150){
                                                revisedMap [counterY][counterX+1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                            }
                                            if (counterY+1 < imageSizeLimit && counterX+1 < imageSizeLimit && revisedMap [counterY+1][counterX+1] == -150){
                                                revisedMap [counterY+1][counterX+1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                            }
                                            if (counterY+1 < imageSizeLimit && revisedMap [counterY+1][counterX] == -150){
                                                revisedMap [counterY+1][counterX] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                            }
                                            if (counterY+1 < imageSizeLimit && counterX-1 >= 0 && revisedMap [counterY+1][counterX-1] == -150){
                                                revisedMap [counterY+1][counterX-1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                            }
                                            if (counterX-1 >= 0 && revisedMap [counterY][counterX-1] == -150){
                                                revisedMap [counterY][counterX-1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                            }
                                            
                                            if (connectAnalysisCount != 0){
                                                do{
                                                    
                                                    terminationFlag = 1;
                                                    connectAnalysisTempCount = 0;
                                                    
                                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                        xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                        
                                                        if (ySource-1 >= 0 && xSource-1 >= 0 && revisedMap [ySource-1][xSource-1] == -150){
                                                            revisedMap [ySource-1][xSource-1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                        }
                                                        if (ySource-1 >= 0 && revisedMap [ySource-1][xSource] == -150){
                                                            revisedMap [ySource-1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                        }
                                                        if (ySource-1 >= 0 && xSource+1 < imageSizeLimit && revisedMap [ySource-1][xSource+1] == -150){
                                                            revisedMap [ySource-1][xSource+1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource+1 < imageSizeLimit && revisedMap [ySource][xSource+1] == -150){
                                                            revisedMap [ySource][xSource+1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                        if (ySource+1 > imageSizeLimit && xSource+1 < imageSizeLimit && revisedMap [ySource+1][xSource+1] == -150){
                                                            revisedMap [ySource+1][xSource+1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                        }
                                                        if (ySource+1 < imageSizeLimit && revisedMap [ySource+1][xSource] == -150){
                                                            revisedMap [ySource+1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                        }
                                                        if (ySource+1 < imageSizeLimit && xSource-1 >= 0 && revisedMap [ySource+1][xSource-1] == -150){
                                                            revisedMap [ySource+1][xSource-1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource-1 >= 0 && revisedMap [ySource][xSource-1] == -150){
                                                            revisedMap [ySource][xSource-1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                    }
                                                    
                                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                        connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                                    }
                                                    
                                                    connectAnalysisCount = connectAnalysisTempCount;
                                                    
                                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                                    
                                                } while (terminationFlag == 1);
                                            }
                                        }
                                    }
                                }
                                
                                //------Determine number of pixels------
                                int *connectedPix = new int [connectivityNumber+50];
                                
                                for (int counter2 = 0; counter2 <= connectivityNumber; counter2++) connectedPix [counter2] = 0;
                                
                                for (int counterY = 0; counterY < imageSizeLimit; counterY++){
                                    for (int counterX = 0; counterX < imageSizeLimit; counterX++){
                                        if (revisedMap [counterY][counterX] != 0) connectedPix [revisedMap [counterY][counterX]]++;
                                    }
                                }
                                
                                //------Map up-date------
                                connectTemp = 1;
                                
                                for (int counter2 = 1; counter2 <= connectivityNumber; counter2++){
                                    if (connectedPix [counter2] < 10) connectedPix [counter2] = 0;
                                    else{
                                        
                                        connectedPix [counter2] = connectTemp;
                                        connectTemp++;
                                    }
                                }
                                
                                for (int counterY = 0; counterY < imageSizeLimit; counterY++){
                                    for (int counterX = 0; counterX < imageSizeLimit; counterX++){
                                        if ((connectTemp = revisedMap [counterY][counterX]) != 0) revisedMap [counterY][counterX] = connectedPix [connectTemp];
                                        else revisedMap [counterY][counterX] = 0;
                                        
                                        if (counter1 == 1){
                                            connectMap240 [counterY][counterX] = revisedMap [counterY][counterX];
                                        }
                                        else if (counter1 == 2){
                                            connectMap220 [counterY][counterX] = revisedMap [counterY][counterX];
                                        }
                                        else if (counter1 == 3){
                                            connectMap200 [counterY][counterX] = revisedMap [counterY][counterX];
                                        }
                                        else if (counter1 == 4){
                                            connectMapA [counterY][counterX] = revisedMap [counterY][counterX];
                                        }
                                        else if (counter1 == 5){
                                            connectMapB [counterY][counterX] = revisedMap [counterY][counterX];
                                        }
                                        else if (counter1 == 6){
                                            connectMapC [counterY][counterX] = revisedMap [counterY][counterX];
                                        }
                                        else if (counter1 == 7){
                                            connectMapD [counterY][counterX] = revisedMap [counterY][counterX];
                                        }
                                    }
                                }
                                
                                delete [] connectedPix;
                            }
                            
                            delete [] connectAnalysisX;
                            delete [] connectAnalysisY;
                            delete [] connectAnalysisTempX;
                            delete [] connectAnalysisTempY;
                            
                            int yDimensionCount;
                            int xDimensionCount;
                            int readBit [4];
                            int pixData;
                            
                            int totalSize = imageSizeLimit*imageSizeLimit*4;
                            
                            fin.open(revisedMapPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                uint8_t *upload2 = new uint8_t [totalSize+50];
                                
                                fin.read((char*)upload2, totalSize+1);
                                fin.close();
                                
                                yDimensionCount = 0;
                                xDimensionCount = 0;
                                
                                for (int counter1 = 0; counter1 < totalSize; counter1 = counter1+4){
                                    readBit [0] = upload2[counter1];
                                    readBit [1] = upload2[counter1+1];
                                    readBit [2] = upload2[counter1+2];
                                    readBit [3] = upload2[counter1+3];
                                    
                                    pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                                    
                                    for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                                        revisedMap [yDimensionCount][xDimensionCount] = pixData;
                                        revisedWorkingMap [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                                    }
                                    
                                    if (xDimensionCount == imageSizeLimit){
                                        xDimensionCount = 0;
                                        yDimensionCount++;
                                        
                                        if (yDimensionCount == imageSizeLimit){
                                            break;
                                        }
                                    }
                                }
                                
                                delete [] upload2;
                            }
                            else{
                                
                                fin.open(mapPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    uint8_t *upload2 = new uint8_t [totalSize+50];
                                    
                                    fin.read((char*)upload2, totalSize+1);
                                    fin.close();
                                    
                                    yDimensionCount = 0;
                                    xDimensionCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < totalSize; counter1 = counter1+4){
                                        readBit [0] = upload2[counter1];
                                        readBit [1] = upload2[counter1+1];
                                        readBit [2] = upload2[counter1+2];
                                        readBit [3] = upload2[counter1+3];
                                        
                                        pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                                        
                                        for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                                            revisedMap [yDimensionCount][xDimensionCount] = pixData;
                                            revisedWorkingMap [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                                        }
                                        
                                        if (xDimensionCount == imageSizeLimit){
                                            xDimensionCount = 0;
                                            yDimensionCount++;
                                            
                                            if (yDimensionCount == imageSizeLimit){
                                                break;
                                            }
                                        }
                                    }
                                    
                                    delete [] upload2;
                                }
                            }
                            
                            if (firstRead == 1){
                                self->targetFind = [[TargetFind alloc] init];
                                [self->targetFind interpretationFirst];
                                
                                int valueTemp = 0;
                                
                                for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                                    if (arrayPositionRevise [counter1*7+3] != valueTemp){
                                        valueTemp = arrayPositionRevise [counter1*7+3];
                                        arrayTimeSelected [(valueTemp-1)*10+2] = counter1;
                                        
                                        if (arrayPositionRevise [counter1*7+5] == 0){
                                            arrayTimeSelected [(valueTemp-1)*10] = 0;
                                        }
                                    }
                                }
                            }
                            else{
                                
                                int typeSet = 1;
                                
                                self->targetFind2 = [[TargetFind2 alloc] init];
                                [self->targetFind2 interpretationFirst:typeSet];
                            }
                            
                            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                                if (arrayTimeSelected [counter1*10] == 1){
                                    currentConnectNo = arrayTimeSelected [counter1*10+8];
                                    break;
                                }
                            }
                            
                            warningSet = 2;
                        }
                        else{
                            
                            areaModeStatusHold = 0;
                            warningSet = 6;
                        }
                    }
                    else{
                        
                        areaModeStatusHold = 0;
                        warningSet = 6;
                    }
                }
                else{
                    
                    areaModeStatusHold = 0;
                    warningSet = 1;
                }
                
                self->progressTimingB = 0;
                imageProgressFlag = 0;
                self->warningSetB = 10;
            });
        }
        else if (areaModeStatusHold == 1){
            areaModeStatusHold = 0;
            
            if (areaSetDone == 1){
                lineDraw = 0;
                windowLock = 0;
                areaSetDone = 0;
                trackingDataSave = [[TrackingDataSave alloc] init];
                [trackingDataSave trackingDataSaveTemp:timePointHold];
            }
            
            [areaModeDisplay setStringValue:@"Off"];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing or Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)gridStatusSet:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0 && phaseStatus == 0){
        if (gridStatusHold == 0){
            [gridStatusDisplay setStringValue:@"On"];
            gridStatusHold = 1;
        }
        else if (gridStatusHold == 1){
            [gridStatusDisplay setStringValue:@"Off"];
            gridStatusHold = 0;
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing or Movie On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)stepperGridSet:(id)sender{
    if (movieRunningFlag == 0){
        if ([stepperGrid intValue] >= 1 && [stepperGrid intValue] <= 50){
            [gridDimDisplay setIntValue:[stepperGrid intValue]];
            gridDimHold = [stepperGrid intValue];
        }
    }
}

-(IBAction)firstSecondSet:(id)sender{
    if (analysisStatusHold != 0){
        if (dotSetFirstSecondHold == 0){
            dotSetFirstSecondHold = 1;
            [firstSecondDisplay setStringValue:@"D"];
        }
        else if (dotSetFirstSecondHold == 1){
            dotSetFirstSecondHold = 2;
            [firstSecondDisplay setStringValue:@"T"];
        }
        else if (dotSetFirstSecondHold == 2){
            dotSetFirstSecondHold = 3;
            [firstSecondDisplay setStringValue:@"Q"];
        }
        else if (dotSetFirstSecondHold == 3){
            dotSetFirstSecondHold = 0;
            [firstSecondDisplay setStringValue:@"P"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Dot Set Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cutOffAreaSet:(id)sender{
    if (areaModeStatusHold == 1 && imageProgressFlag == 0){
        long int inputNumber2 = [cutOffAreaDisplay integerValue];
        [cutOffAreaDisplay setStringValue:@""];
        
        if (inputNumber2 >= 0 && inputNumber2 <= 20000){
            [cutOffAreaDisplay setIntegerValue:inputNumber2];
            
            int removeConnectNo = 0;
            
            for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                removeConnectNo = 0;
                
                if (arrayGravityCenterRev [counter1*6+2] <= inputNumber2){
                    removeConnectNo = arrayGravityCenterRev [counter1*6+4];
                }
                
                if (arrayTimeSelected [counter1*10] != 3 && arrayTimeSelected [counter1*10] != 4){
                    if (removeConnectNo != 0) arrayTimeSelected [counter1*10] = 0;
                    else arrayTimeSelected [counter1*10] = 1;
                }
            }
            
            int status = 0;
            
            for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                status = arrayTimeSelected [(arrayPositionRevise [counter1*7+3]-1)*10];
                
                if (status != arrayPositionRevise [counter1*7+5]){
                    arrayPositionRevise [counter1*7+5] = status;
                }
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Area Mode On or Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)colorImageLoad:(id)sender{
    if (areaModeStatusHold == 1 && imageProgressFlag == 0){
        NSOpenPanel *openDlg = [NSOpenPanel openPanel];
        [openDlg setCanChooseFiles:NO];
        [openDlg setCanChooseDirectories:YES];
        [openDlg setCanCreateDirectories:YES];
        
        if ([openDlg runModal] == NSModalResponseOK){
            NSArray *files = [openDlg URLs];
            NSString *fileName = [[files objectAtIndex:0] absoluteString];
            
            directoryPathExtract = [fileName UTF8String];
            
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
                imageProgressFlag = 1;
                
                unsigned long directoryLength = directoryPathExtract.length();
                string extractedID;
                
                if ((int)directoryPathExtract.find("Volumes") != -1) extractedID = directoryPathExtract.substr(directoryPathExtract.find("/Volumes/"), directoryLength-directoryPathExtract.find("/Volumes/")-1);
                else extractedID = directoryPathExtract.substr(directoryPathExtract.find("/Users/"), directoryLength-directoryPathExtract.find("/Users/")-1);
                
                string extractedID2;
                
                int terminationFlag = 0;
                
                do{
                    
                    terminationFlag = 1;
                    
                    if ((int)extractedID.find("%20") != -1){
                        extractedID2 = extractedID.substr(0, extractedID.find("%20"));
                        extractedID = extractedID.substr(extractedID.find("%20")+3);
                        extractedID = extractedID2+" "+extractedID;
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                DIR *dir;
                struct dirent *dent;
                
                string entry;
                string cellFolderPath;
                
                string *arrayFileDelete2 = new string [3000];
                int fileDeleteCount2 = 0;
                int fileDeleteLimit2 = 30000;
                
                dir = opendir(extractedID.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" && ((int)entry.find(".TIFF") != -1 || (int)entry.find(".Tiff") != -1 || (int)entry.find(".tiff") != -1 || (int)entry.find(".TIF") != -1 || (int)entry.find(".Tif") != -1 || (int)entry.find(".tif") != -1)){
                            
                            if (fileDeleteCount2+5 > fileDeleteLimit2){
                                string *arrayUpDate = new string [fileDeleteCount2+10];
                                
                                for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++) arrayUpDate [counter1] = arrayFileDelete2 [counter1];
                                
                                delete [] arrayFileDelete2;
                                arrayFileDelete2 = new string [fileDeleteLimit2+500];
                                fileDeleteLimit2 = fileDeleteLimit2+500;
                                
                                for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++) arrayFileDelete2 [counter1] = arrayUpDate [counter1];
                                delete [] arrayUpDate;
                                
                            }
                            
                            arrayFileDelete2 [fileDeleteCount2] = entry, fileDeleteCount2++;
                        }
                    }
                    
                    closedir(dir);
                    
                    //-------Directory Sort------
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++){
                        [unsortedArray addObject:@(arrayFileDelete2 [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        arrayFileDelete2 [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                }
                
                int *imageSizeListTemp = new int [fileListCount+10];
                
                for (int counter1 = 0; counter1 < fileListCount+10; counter1++) imageSizeListTemp [counter1] = 0;
                
                unsigned long stripFirstAddress = 0;
                unsigned long stripByteCountAddress = 0;
                unsigned long nextAddress = 0;
                unsigned long headPosition = 0;
                unsigned long stripEntry = 0;
                long sizeForCopy = 0;
                
                double xPosition = 0;
                double yPosition = 0;
                
                int imageWidth = 0;
                int imageHeight = 0;
                int imageBit = 0; // Check 8, 16
                int imageCompression = 0; // Check 1
                int photoMetric = 0;//check 0, 1, 2
                int endianType = 0;
                int samplePerPix = 0;
                int dataConversion [4];
                int numberOfLayers = 0;
                
                string tiffExtensionHold = "";
                string sourceFileName;
                
                struct stat sizeOfFile;
                
                ifstream fin;
                
                for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++){
                    if ((int)arrayFileDelete2 [counter1].find(".TIFF") != -1 || (int)arrayFileDelete2 [counter1].find(".Tiff") != -1 || (int)arrayFileDelete2 [counter1].find(".tiff") != -1 || (int)arrayFileDelete2 [counter1].find(".TIF") != -1 || (int)arrayFileDelete2 [counter1].find(".Tif") != -1 || (int)arrayFileDelete2 [counter1].find(".tif") != -1){
                        tiffExtensionHold = "";
                        
                        if ((int)arrayFileDelete2 [counter1].find(".TIFF") != -1) tiffExtensionHold = ".TIFF";
                        else if ((int)arrayFileDelete2 [counter1].find(".Tiff") != -1) tiffExtensionHold = ".Tiff";
                        else if ((int)arrayFileDelete2 [counter1].find(".tiff") != -1) tiffExtensionHold = ".tiff";
                        else if ((int)arrayFileDelete2 [counter1].find(".TIF") != -1 ) tiffExtensionHold = ".TIF";
                        else if ((int)arrayFileDelete2 [counter1].find(".Tif") != -1) tiffExtensionHold = ".Tif";
                        else if ((int)arrayFileDelete2 [counter1].find(".tif") != -1) tiffExtensionHold = ".tif";
                        
                        sourceFileName = extractedID+"/"+arrayFileDelete2 [counter1];
                        
                        //----------File Read----------
                        if (stat(sourceFileName.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            fileReadArray = new uint8_t [sizeForCopy+4];
                            fin.open(sourceFileName.c_str(), ios::in | ios::binary);
                            
                            fin.read((char*)fileReadArray, sizeForCopy+4);
                            fin.close();
                            
                            dataConversion [0] = fileReadArray [0];
                            dataConversion [1] = fileReadArray [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = fileReadArray [7];
                                dataConversion [1] = fileReadArray [6];
                                dataConversion [2] = fileReadArray [5];
                                dataConversion [3] = fileReadArray [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = fileReadArray [4];
                                dataConversion [1] = fileReadArray [5];
                                dataConversion [2] = fileReadArray [6];
                                dataConversion [3] = fileReadArray [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            if (endianType == 1){
                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            }
                            else if (endianType == 0){
                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            }
                            
                            if (imageWidth != 0 && imageHeight != 0 && imageWidth == imageHeight && imageCompression == 1 && imageBit == 8 && nextAddress == 0 && photoMetric < 3){
                                imageSizeListTemp [counter1] = imageWidth;
                            }
                            
                            delete [] fileReadArray;
                        }
                    }
                }
                
                int sizeCheck = 0;
                
                for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++){
                    if (imageSizeListTemp [counter1] == 0) sizeCheck = 1;
                }
                
                if (sizeCheck == 0 && fileDeleteCount2 == fileListCount/7){
                    for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++){
                        if (imageSizeListTemp [counter1] != imageXYLength) sizeCheck = 1;
                    }
                    
                    
                    if (sizeCheck == 0){
                        string productPath2 = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Phase";
                        
                        mkdir(productPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                        
                        string savedDataPath;
                        string sourceDataPath;
                        string extension;
                        string extension2;
                        
                        for (int counter2 = 0; counter2 < fileDeleteCount2; counter2++){
                            sourceDataPath = extractedID+"/"+arrayFileDelete2 [counter2];
                            
                            extension = to_string(counter2+1);
                            
                            if (extension.length() == 1) extension = "000"+extension;
                            else if (extension.length() == 2) extension = "00"+extension;
                            else if (extension.length() == 3) extension = "0"+extension;
                            
                            if ((int)arrayFileDelete2 [counter2].find(".TIFF") != -1 || (int)arrayFileDelete2 [counter2].find(".Tiff") != -1 || (int)arrayFileDelete2 [counter2].find(".tiff") != -1 || (int)arrayFileDelete2 [counter2].find(".TIF") != -1 || (int)arrayFileDelete2 [counter2].find(".Tif") != -1 || (int)arrayFileDelete2 [counter2].find(".tif") != -1){
                                extension2 = ".tif";
                            }
                            
                            savedDataPath = productPath2+"/"+treatNameHold+"-"+extension+extension2;
                            
                            if (stat(sourceDataPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                ifstream infile (sourceDataPath.c_str(), ifstream::binary);
                                ofstream outfile (savedDataPath.c_str(), ofstream::binary);
                                
                                char* buffer = new char[sizeForCopy];
                                infile.read (buffer, sizeForCopy);
                                outfile.write (buffer, sizeForCopy);
                                delete[] buffer;
                                
                                outfile.close();
                                infile.close();
                                
                                fileList2 [counter2] = treatNameHold+"-"+extension+extension2;
                            }
                        }
                        
                        warningSet = 3;
                    }
                    else warningSet = 4;
                }
                else warningSet = 5;
                
                delete [] imageSizeListTemp;
                delete [] arrayFileDelete2;
                
                imageProgressFlag = 0;
            });
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Area Mode On or Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)refImageLoad1:(id)sender{
    if (areaModeStatusHold == 1 && imageProgressFlag == 0){
        NSOpenPanel *openDlg = [NSOpenPanel openPanel];
        [openDlg setCanChooseFiles:NO];
        [openDlg setCanChooseDirectories:YES];
        [openDlg setCanCreateDirectories:YES];
        
        if ([openDlg runModal] == NSModalResponseOK){
            NSArray *files = [openDlg URLs];
            NSString *fileName = [[files objectAtIndex:0] absoluteString];
            
            directoryPathExtract = [fileName UTF8String];
            
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
                imageProgressFlag = 1;
                
                unsigned long directoryLength = directoryPathExtract.length();
                string extractedID;
                
                if ((int)directoryPathExtract.find("Volumes") != -1) extractedID = directoryPathExtract.substr(directoryPathExtract.find("/Volumes/"), directoryLength-directoryPathExtract.find("/Volumes/")-1);
                else extractedID = directoryPathExtract.substr(directoryPathExtract.find("/Users/"), directoryLength-directoryPathExtract.find("/Users/")-1);
                
                string extractedID2;
                
                int terminationFlag = 0;
                
                do{
                    
                    terminationFlag = 1;
                    
                    if ((int)extractedID.find("%20") != -1){
                        extractedID2 = extractedID.substr(0, extractedID.find("%20"));
                        extractedID = extractedID.substr(extractedID.find("%20")+3);
                        extractedID = extractedID2+" "+extractedID;
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                DIR *dir;
                struct dirent *dent;
                
                string entry;
                string cellFolderPath;
                
                string *arrayFileDelete2 = new string [3000];
                int fileDeleteCount2 = 0;
                int fileDeleteLimit2 = 30000;
                
                dir = opendir(extractedID.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" && ((int)entry.find(".TIFF") != -1 || (int)entry.find(".Tiff") != -1 || (int)entry.find(".tiff") != -1 || (int)entry.find(".TIF") != -1 || (int)entry.find(".Tif") != -1 || (int)entry.find(".tif") != -1)){
                            
                            if (fileDeleteCount2+5 > fileDeleteLimit2){
                                string *arrayUpDate = new string [fileDeleteCount2+10];
                                
                                for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++) arrayUpDate [counter1] = arrayFileDelete2 [counter1];
                                
                                delete [] arrayFileDelete2;
                                arrayFileDelete2 = new string [fileDeleteLimit2+500];
                                fileDeleteLimit2 = fileDeleteLimit2+500;
                                
                                for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++) arrayFileDelete2 [counter1] = arrayUpDate [counter1];
                                delete [] arrayUpDate;
                                
                            }
                            
                            arrayFileDelete2 [fileDeleteCount2] = entry, fileDeleteCount2++;
                        }
                    }
                    
                    closedir(dir);
                    
                    //-------Directory Sort------
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++){
                        [unsortedArray addObject:@(arrayFileDelete2 [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        arrayFileDelete2 [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                }
                
                int *imageSizeListTemp = new int [fileListCount+10];
                
                for (int counter1 = 0; counter1 < fileListCount+10; counter1++) imageSizeListTemp [counter1] = 0;
                
                unsigned long stripFirstAddress = 0;
                unsigned long stripByteCountAddress = 0;
                unsigned long nextAddress = 0;
                unsigned long headPosition = 0;
                unsigned long stripEntry = 0;
                long sizeForCopy = 0;
                
                double xPosition = 0;
                double yPosition = 0;
                
                int imageWidth = 0;
                int imageHeight = 0;
                int imageBit = 0; // Check 8, 16
                int imageCompression = 0; // Check 1
                int photoMetric = 0;//check 0, 1, 2
                int endianType = 0;
                int samplePerPix = 0;
                int dataConversion [4];
                int numberOfLayers = 0;
                
                string tiffExtensionHold = "";
                string sourceFileName;
                
                struct stat sizeOfFile;
                
                ifstream fin;
                
                for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++){
                    if ((int)arrayFileDelete2 [counter1].find(".TIFF") != -1 || (int)arrayFileDelete2 [counter1].find(".Tiff") != -1 || (int)arrayFileDelete2 [counter1].find(".tiff") != -1 || (int)arrayFileDelete2 [counter1].find(".TIF") != -1 || (int)arrayFileDelete2 [counter1].find(".Tif") != -1 || (int)arrayFileDelete2 [counter1].find(".tif") != -1){
                        tiffExtensionHold = "";
                        
                        if ((int)arrayFileDelete2 [counter1].find(".TIFF") != -1) tiffExtensionHold = ".TIFF";
                        else if ((int)arrayFileDelete2 [counter1].find(".Tiff") != -1) tiffExtensionHold = ".Tiff";
                        else if ((int)arrayFileDelete2 [counter1].find(".tiff") != -1) tiffExtensionHold = ".tiff";
                        else if ((int)arrayFileDelete2 [counter1].find(".TIF") != -1 ) tiffExtensionHold = ".TIF";
                        else if ((int)arrayFileDelete2 [counter1].find(".Tif") != -1) tiffExtensionHold = ".Tif";
                        else if ((int)arrayFileDelete2 [counter1].find(".tif") != -1) tiffExtensionHold = ".tif";
                        
                        sourceFileName = extractedID+"/"+arrayFileDelete2 [counter1];
                        
                        //----------File Read----------
                        if (stat(sourceFileName.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            fileReadArray = new uint8_t [sizeForCopy+4];
                            fin.open(sourceFileName.c_str(), ios::in | ios::binary);
                            
                            fin.read((char*)fileReadArray, sizeForCopy+4);
                            fin.close();
                            
                            dataConversion [0] = fileReadArray [0];
                            dataConversion [1] = fileReadArray [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = fileReadArray [7];
                                dataConversion [1] = fileReadArray [6];
                                dataConversion [2] = fileReadArray [5];
                                dataConversion [3] = fileReadArray [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = fileReadArray [4];
                                dataConversion [1] = fileReadArray [5];
                                dataConversion [2] = fileReadArray [6];
                                dataConversion [3] = fileReadArray [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            if (endianType == 1){
                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            }
                            else if (endianType == 0){
                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            }
                            
                            if (imageWidth != 0 && imageHeight != 0 && imageWidth == imageHeight && imageCompression == 1 && imageBit == 8 && nextAddress == 0 && photoMetric < 3){
                                imageSizeListTemp [counter1] = imageWidth;
                            }
                            
                            delete [] fileReadArray;
                        }
                    }
                }
                
                int sizeCheck = 0;
                
                for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++){
                    if (imageSizeListTemp [counter1] == 0) sizeCheck = 1;
                }
                
                if (sizeCheck == 0 && fileDeleteCount2 == fileListCount/7){
                    for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++){
                        if (imageSizeListTemp [counter1] != imageXYLength) sizeCheck = 1;
                    }
                    
                    if (sizeCheck == 0){
                        string productPath2 = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Ref1";
                        
                        mkdir(productPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                        
                        string savedDataPath;
                        string sourceDataPath;
                        string extension;
                        string extension2;
                        
                        for (int counter2 = 0; counter2 < fileDeleteCount2; counter2++){
                            sourceDataPath = extractedID+"/"+arrayFileDelete2 [counter2];
                            
                            extension = to_string(counter2+1);
                            
                            if (extension.length() == 1) extension = "000"+extension;
                            else if (extension.length() == 2) extension = "00"+extension;
                            else if (extension.length() == 3) extension = "0"+extension;
                            
                            if ((int)arrayFileDelete2 [counter2].find(".TIFF") != -1 || (int)arrayFileDelete2 [counter2].find(".Tiff") != -1 || (int)arrayFileDelete2 [counter2].find(".tiff") != -1 || (int)arrayFileDelete2 [counter2].find(".TIF") != -1 || (int)arrayFileDelete2 [counter2].find(".Tif") != -1 || (int)arrayFileDelete2 [counter2].find(".tif") != -1){
                                extension2 = ".tif";
                            }
                            
                            savedDataPath = productPath2+"/"+treatNameHold+"-"+extension+extension2;
                            
                            if (stat(sourceDataPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                ifstream infile (sourceDataPath.c_str(), ifstream::binary);
                                ofstream outfile (savedDataPath.c_str(), ofstream::binary);
                                
                                char* buffer = new char[sizeForCopy];
                                infile.read (buffer, sizeForCopy);
                                outfile.write (buffer, sizeForCopy);
                                delete[] buffer;
                                
                                outfile.close();
                                infile.close();
                            }
                        }
                        
                        warningSet = 3;
                    }
                    else warningSet = 4;
                }
                else warningSet = 5;
                
                delete [] imageSizeListTemp;
                delete [] arrayFileDelete2;
                
                imageProgressFlag = 0;
            });
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Area Mode On or Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)refImageLoad2:(id)sender{
    if (areaModeStatusHold == 1 && imageProgressFlag == 0){
        NSOpenPanel *openDlg = [NSOpenPanel openPanel];
        [openDlg setCanChooseFiles:NO];
        [openDlg setCanChooseDirectories:YES];
        [openDlg setCanCreateDirectories:YES];
        
        if ([openDlg runModal] == NSModalResponseOK){
            NSArray *files = [openDlg URLs];
            NSString *fileName = [[files objectAtIndex:0] absoluteString];
            
            directoryPathExtract = [fileName UTF8String];
            
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
                imageProgressFlag = 1;
                
                unsigned long directoryLength = directoryPathExtract.length();
                string extractedID;
                
                if ((int)directoryPathExtract.find("Volumes") != -1) extractedID = directoryPathExtract.substr(directoryPathExtract.find("/Volumes/"), directoryLength-directoryPathExtract.find("/Volumes/")-1);
                else extractedID = directoryPathExtract.substr(directoryPathExtract.find("/Users/"), directoryLength-directoryPathExtract.find("/Users/")-1);
                
                string extractedID2;
                
                int terminationFlag = 0;
                
                do{
                    
                    terminationFlag = 1;
                    
                    if ((int)extractedID.find("%20") != -1){
                        extractedID2 = extractedID.substr(0, extractedID.find("%20"));
                        extractedID = extractedID.substr(extractedID.find("%20")+3);
                        extractedID = extractedID2+" "+extractedID;
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                DIR *dir;
                struct dirent *dent;
                
                string entry;
                string cellFolderPath;
                
                string *arrayFileDelete2 = new string [3000];
                int fileDeleteCount2 = 0;
                int fileDeleteLimit2 = 30000;
                
                dir = opendir(extractedID.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" && ((int)entry.find(".TIFF") != -1 || (int)entry.find(".Tiff") != -1 || (int)entry.find(".tiff") != -1 || (int)entry.find(".TIF") != -1 || (int)entry.find(".Tif") != -1 || (int)entry.find(".tif") != -1)){
                            
                            if (fileDeleteCount2+5 > fileDeleteLimit2){
                                string *arrayUpDate = new string [fileDeleteCount2+10];
                                
                                for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++) arrayUpDate [counter1] = arrayFileDelete2 [counter1];
                                
                                delete [] arrayFileDelete2;
                                arrayFileDelete2 = new string [fileDeleteLimit2+500];
                                fileDeleteLimit2 = fileDeleteLimit2+500;
                                
                                for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++) arrayFileDelete2 [counter1] = arrayUpDate [counter1];
                                delete [] arrayUpDate;
                                
                            }
                            
                            arrayFileDelete2 [fileDeleteCount2] = entry, fileDeleteCount2++;
                        }
                    }
                    
                    closedir(dir);
                    
                    //-------Directory Sort------
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++){
                        [unsortedArray addObject:@(arrayFileDelete2 [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        arrayFileDelete2 [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                }
                
                int *imageSizeListTemp = new int [fileListCount+10];
                
                for (int counter1 = 0; counter1 < fileListCount+10; counter1++) imageSizeListTemp [counter1] = 0;
                
                unsigned long stripFirstAddress = 0;
                unsigned long stripByteCountAddress = 0;
                unsigned long nextAddress = 0;
                unsigned long headPosition = 0;
                unsigned long stripEntry = 0;
                long sizeForCopy = 0;
                
                double xPosition = 0;
                double yPosition = 0;
                
                int imageWidth = 0;
                int imageHeight = 0;
                int imageBit = 0; // Check 8, 16
                int imageCompression = 0; // Check 1
                int photoMetric = 0;//check 0, 1, 2
                int endianType = 0;
                int samplePerPix = 0;
                int dataConversion [4];
                int numberOfLayers = 0;
                
                string tiffExtensionHold = "";
                string sourceFileName;
                
                struct stat sizeOfFile;
                
                ifstream fin;
                
                for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++){
                    if ((int)arrayFileDelete2 [counter1].find(".TIFF") != -1 || (int)arrayFileDelete2 [counter1].find(".Tiff") != -1 || (int)arrayFileDelete2 [counter1].find(".tiff") != -1 || (int)arrayFileDelete2 [counter1].find(".TIF") != -1 || (int)arrayFileDelete2 [counter1].find(".Tif") != -1 || (int)arrayFileDelete2 [counter1].find(".tif") != -1){
                        tiffExtensionHold = "";
                        
                        if ((int)arrayFileDelete2 [counter1].find(".TIFF") != -1) tiffExtensionHold = ".TIFF";
                        else if ((int)arrayFileDelete2 [counter1].find(".Tiff") != -1) tiffExtensionHold = ".Tiff";
                        else if ((int)arrayFileDelete2 [counter1].find(".tiff") != -1) tiffExtensionHold = ".tiff";
                        else if ((int)arrayFileDelete2 [counter1].find(".TIF") != -1 ) tiffExtensionHold = ".TIF";
                        else if ((int)arrayFileDelete2 [counter1].find(".Tif") != -1) tiffExtensionHold = ".Tif";
                        else if ((int)arrayFileDelete2 [counter1].find(".tif") != -1) tiffExtensionHold = ".tif";
                        
                        sourceFileName = extractedID+"/"+arrayFileDelete2 [counter1];
                        
                        //----------File Read----------
                        if (stat(sourceFileName.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            fileReadArray = new uint8_t [sizeForCopy+4];
                            fin.open(sourceFileName.c_str(), ios::in | ios::binary);
                            
                            fin.read((char*)fileReadArray, sizeForCopy+4);
                            fin.close();
                            
                            dataConversion [0] = fileReadArray [0];
                            dataConversion [1] = fileReadArray [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = fileReadArray [7];
                                dataConversion [1] = fileReadArray [6];
                                dataConversion [2] = fileReadArray [5];
                                dataConversion [3] = fileReadArray [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = fileReadArray [4];
                                dataConversion [1] = fileReadArray [5];
                                dataConversion [2] = fileReadArray [6];
                                dataConversion [3] = fileReadArray [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            if (endianType == 1){
                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            }
                            else if (endianType == 0){
                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            }
                            
                            
                            if (imageWidth != 0 && imageHeight != 0 && imageWidth == imageHeight && imageCompression == 1 && imageBit == 8 && nextAddress == 0 && photoMetric < 3){
                                imageSizeListTemp [counter1] = imageWidth;
                            }
                            
                            delete [] fileReadArray;
                        }
                    }
                }
                
                int sizeCheck = 0;
                
                for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++){
                    if (imageSizeListTemp [counter1] == 0){
                        sizeCheck = 1;
                    }
                }
                
                if (sizeCheck == 0 && fileDeleteCount2 == fileListCount/7){
                    for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++){
                        if (imageSizeListTemp [counter1] != imageXYLength) sizeCheck = 1;
                    }
                    
                    if (sizeCheck == 0){
                        string productPath2 = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Ref2";
                        
                        mkdir(productPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                        
                        string savedDataPath;
                        string sourceDataPath;
                        string extension;
                        string extension2;
                        
                        for (int counter2 = 0; counter2 < fileDeleteCount2; counter2++){
                            sourceDataPath = extractedID+"/"+arrayFileDelete2 [counter2];
                            
                            extension = to_string(counter2+1);
                            
                            if (extension.length() == 1) extension = "000"+extension;
                            else if (extension.length() == 2) extension = "00"+extension;
                            else if (extension.length() == 3) extension = "0"+extension;
                            
                            if ((int)arrayFileDelete2 [counter2].find(".TIFF") != -1 || (int)arrayFileDelete2 [counter2].find(".Tiff") != -1 || (int)arrayFileDelete2 [counter2].find(".tiff") != -1 || (int)arrayFileDelete2 [counter2].find(".TIF") != -1 || (int)arrayFileDelete2 [counter2].find(".Tif") != -1 || (int)arrayFileDelete2 [counter2].find(".tif") != -1){
                                extension2 = ".tif";
                            }
                            
                            savedDataPath = productPath2+"/"+treatNameHold+"-"+extension+extension2;
                            
                            if (stat(sourceDataPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                ifstream infile (sourceDataPath.c_str(), ifstream::binary);
                                ofstream outfile (savedDataPath.c_str(), ofstream::binary);
                                
                                char* buffer = new char[sizeForCopy];
                                infile.read (buffer, sizeForCopy);
                                outfile.write (buffer, sizeForCopy);
                                delete[] buffer;
                                
                                outfile.close();
                                infile.close();
                            }
                        }
                        
                        warningSet = 3;
                    }
                    else warningSet = 4;
                }
                else warningSet = 5;
                
                delete [] imageSizeListTemp;
                delete [] arrayFileDelete2;
                
                imageProgressFlag = 0;
            });
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Area Mode On or Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)colorImageSet:(id)sender{
    if (phaseStatus == 0 && imageProgressFlag == 0){
        phaseStatus = 1;
        refLoadStatus = 1;
        
        int imagefileCheck = 0;
        
        if (fileListCount2 == 0){
            string imageMoviePath3 = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Phase";
            DIR *dir;
            struct dirent *dent;
            
            string entry;
            string cellFolderPath;
            
            
            dir = opendir(imageMoviePath3.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(".tif") != -1){
                        fileList2 [fileListCount2] = entry, fileListCount2++;
                    }
                }
                
                closedir (dir);
            }
            else imagefileCheck = 1;
        }
        
        if (imagefileCheck == 0){
            string imageMoviePath = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Phase"+"/"+fileList2 [filePosition-1];
            string imageMoviePath2 = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Ref1"+"/"+fileList2 [filePosition-1];
            string imageMoviePath3 = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Ref2"+"/"+fileList2 [filePosition-1];
            
            struct stat sizeOfFile;
            
            if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                uploadTempRefFileSize1 = sizeOfFile.st_size;
            }
            else uploadTempRefFileSize1 = 0;
            
            if (stat(imageMoviePath2.c_str(), &sizeOfFile) == 0){
                uploadTempRefFileSize2 = sizeOfFile.st_size;
            }
            else uploadTempRefFileSize2 = 0;
            
            if (stat(imageMoviePath3.c_str(), &sizeOfFile) == 0){
                uploadTempRefFileSize3 = sizeOfFile.st_size;
            }
            else uploadTempRefFileSize3 = 0;
            
            int reloadingStatus = 0;
            
            if (uploadTempRefFileSize1 != 0){
                if (uploadTempStatusRef == 0){
                    uploadTempRef = new uint8_t [uploadTempRefFileSize1+50];
                    uploadTempStatusRef = 1;
                    uploadTempRef2 = new uint8_t [uploadTempRefFileSize2+50];
                    uploadTempStatusRef2 = 1;
                    uploadTempRef3 = new uint8_t [uploadTempRefFileSize3+50];
                    uploadTempStatusRef3 = 1;
                    
                    uploadTempLoadRef2 = 0;
                    uploadTempLoadRef3 = 0;
                }
                else{
                    
                    delete [] uploadTempRef;
                    uploadTempRef = new uint8_t [uploadTempRefFileSize1+50];
                    
                    delete [] uploadTempRef2;
                    uploadTempRef2 = new uint8_t [uploadTempRefFileSize2+50];
                    
                    delete [] uploadTempRef3;
                    uploadTempRef3 = new uint8_t [uploadTempRefFileSize3+50];
                    
                    uploadTempLoadRef2 = 0;
                    uploadTempLoadRef3 = 0;
                }
                
                ifstream fin;
                
                fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                
                fin.read((char*)uploadTempRef, uploadTempRefFileSize1+50);
                fin.close();
                
                [colorRefStatusDisplay setStringValue:@"On"];
                [refImageStatusDisplay setStringValue:@"Color"];
                
                if (uploadTempRefFileSize2 != 0){
                    fin.open(imageMoviePath2.c_str(), ios::in | ios::binary);
                    
                    fin.read((char*)uploadTempRef2, uploadTempRefFileSize2+50);
                    fin.close();
                    
                    uploadTempLoadRef2 = 1;
                    
                    [colorRefStatusDisplay1 setStringValue:@"On"];
                }
                
                if (uploadTempRefFileSize3 != 0){
                    fin.open(imageMoviePath3.c_str(), ios::in | ios::binary);
                    
                    fin.read((char*)uploadTempRef3, uploadTempRefFileSize3+50);
                    fin.close();
                    
                    uploadTempLoadRef3 = 1;
                    
                    [colorRefStatusDisplay2 setStringValue:@"On"];
                }
                
                if (exportOperation == 0){
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
                }
                else if (exportOperation == 1){
                    int errorFound = [self reloadImageExp];
                    
                    if (errorFound == 0){
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
                    }
                    else reloadingStatus = 1;
                }
            }
            
            if (reloadingStatus == 0){
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Data Loading Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            phaseStatus = 0;
            refLoadStatus = 0;
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Image Missing or Other Processes In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        phaseStatus = 0;
        
        if (uploadTempStatusRef == 1){
            delete [] uploadTempRef;
            uploadTempStatusRef = 0;
            delete [] uploadTempRef2;
            uploadTempStatusRef2 = 0;
            delete [] uploadTempRef3;
            uploadTempStatusRef3 = 0;
            
            uploadTempLoadRef2 = 0;
            uploadTempLoadRef3 = 0;
        }
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        
        [colorRefStatusDisplay setStringValue:@"Off"];
        [colorRefStatusDisplay1 setStringValue:@"Off"];
        [colorRefStatusDisplay2 setStringValue:@"Off"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)refImageSelection:(id)sender{
    if (phaseStatus == 1){
        if (refLoadStatus == 1){
            string imageMoviePath2 = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Ref1"+"/"+fileList2 [filePosition-1];
            
            struct stat sizeOfFile;
            
            long sizeForCopy = 0;
            
            if (stat(imageMoviePath2.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                refLoadStatus = 2;
                [refImageStatusDisplay setStringValue:@"Ref1"];
                
                ifstream fin;
                
                fin.open(imageMoviePath2.c_str(), ios::in | ios::binary);
                
                fin.read((char*)uploadTempRef2, sizeForCopy+50);
                fin.close();
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
            }
            else{
                
                imageMoviePath2 = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Ref2"+"/"+fileList2 [filePosition-1];
                
                if (stat(imageMoviePath2.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    refLoadStatus = 3;
                    [refImageStatusDisplay setStringValue:@"Ref2"];
                    
                    ifstream fin;
                    
                    fin.open(imageMoviePath2.c_str(), ios::in | ios::binary);
                    
                    fin.read((char*)uploadTempRef3, sizeForCopy+50);
                    fin.close();
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else if (refLoadStatus == 2){
            string imageMoviePath2 = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Ref2"+"/"+fileList2 [filePosition-1];
            
            struct stat sizeOfFile;
            
            long sizeForCopy = 0;
            
            if (stat(imageMoviePath2.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                refLoadStatus = 3;
                [refImageStatusDisplay setStringValue:@"Ref2"];
                
                ifstream fin;
                
                fin.open(imageMoviePath2.c_str(), ios::in | ios::binary);
                
                fin.read((char*)uploadTempRef3, sizeForCopy+50);
                fin.close();
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
            }
            else{
                
                imageMoviePath2 = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Phase"+"/"+fileList2 [filePosition-1];
                
                if (stat(imageMoviePath2.c_str(), &sizeOfFile) == 0){
                    refLoadStatus = 1;
                    [refImageStatusDisplay setStringValue:@"Color"];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
                }
            }
        }
        else if (refLoadStatus == 3){
            refLoadStatus = 1;
            [refImageStatusDisplay setStringValue:@"Color"];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Ref Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageExportStart:(id)sender{
    if (imageXYLength != 0 && imageProgressFlag == 0){
        if (exportOperation == 0){
            int errorFind = [self reloadImageExp];
            
            if (errorFind == 0){
                colorHold1 = 0;
                colorHold2 = 0;
                colorHold3 = 0;
                colorHold4 = 0;
                colorHold5 = 0;
                colorHold6 = 0;
                colorHold7 = 0;
                colorHold8 = 0;
                colorHold9 = 0;
                colorHold10 = 0;
                colorHoldSd = 0;
                colorHoldTh = 0;
                
                colorHoldArea1 = 0;
                colorHoldArea2 = 0;
                colorHoldArea3 = 0;
                colorHoldArea4 = 0;
                colorHoldArea5 = 0;
                colorHoldArea6 = 0;
                colorHoldArea7 = 0;
                colorHoldArea8 = 0;
                colorHoldArea9 = 0;
                
                colorMaxAreaHold = 0;
                numberOfGroupHold = 0;
                
                string colorDataHoldPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ExportColorMQ";
                
                string getString;
                
                ifstream fin;
                fin.open(colorDataHoldPath.c_str(),ios::in);
                
                if (fin.is_open()){
                    getline(fin, getString), colorHoldArea1 = atoi(getString.c_str());
                    getline(fin, getString), colorHoldArea2 = atoi(getString.c_str());
                    getline(fin, getString), colorHoldArea3 = atoi(getString.c_str());
                    getline(fin, getString), colorHoldArea4 = atoi(getString.c_str());
                    getline(fin, getString), colorHoldArea5 = atoi(getString.c_str());
                    getline(fin, getString), colorHoldArea6 = atoi(getString.c_str());
                    getline(fin, getString), colorHoldArea7 = atoi(getString.c_str());
                    getline(fin, getString), colorHoldArea8 = atoi(getString.c_str());
                    getline(fin, getString), colorHoldArea9 = atoi(getString.c_str());
                    getline(fin, getString), colorHold1 = atoi(getString.c_str());
                    getline(fin, getString), colorHold2 = atoi(getString.c_str());
                    getline(fin, getString), colorHold3 = atoi(getString.c_str());
                    getline(fin, getString), colorHold4 = atoi(getString.c_str());
                    getline(fin, getString), colorHold5 = atoi(getString.c_str());
                    getline(fin, getString), colorHold6 = atoi(getString.c_str());
                    getline(fin, getString), colorHold7 = atoi(getString.c_str());
                    getline(fin, getString), colorHold8 = atoi(getString.c_str());
                    getline(fin, getString), colorHold9 = atoi(getString.c_str());
                    getline(fin, getString), colorHold10 = atoi(getString.c_str());
                    getline(fin, getString), colorMaxAreaHold = atoi(getString.c_str());
                    getline(fin, getString), numberOfGroupHold = atoi(getString.c_str());
                    getline(fin, getString), colorHoldSd = atoi(getString.c_str());
                    getline(fin, getString), colorHoldTh = atoi(getString.c_str());
                    fin.close();
                }
                
                colorPasteStatus = 0;
                exportOperation = 1;
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToExportController object:self];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Data Loading Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        if (exportOperation == 2) exportOperation = 3;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing or Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(int)reloadImageExp{
    if (uploadTempStatus == 1){
        if (uploadTempExpStatus == 0){
            uploadTempExp = new uint8_t [uploadTempFileSize+50];
            uploadTempExpStatus = 1;
        }
        else{
            
            delete [] uploadTempExp;
            uploadTempExp = new uint8_t [uploadTempFileSize+50];
        }
        
        for (int counter1 = 0; counter1 < uploadTempFileSize+50; counter1++) uploadTempExp [counter1] = uploadTemp [counter1];
    }
    
    if (uploadTempStatusCl1 == 1){
        if (uploadTempExpStatusCl1 == 0){
            uploadTempExpCl1 = new uint8_t [uploadTempFileSize+50];
            uploadTempExpStatusCl1 = 1;
        }
        else{
            
            delete [] uploadTempExpCl1;
            uploadTempExpCl1 = new uint8_t [uploadTempFileSize+50];
        }
        
        for (int counter1 = 0; counter1 < uploadTempFileSize+50; counter1++) uploadTempExpCl1 [counter1] = uploadTempCl1 [counter1];
    }
    
    if (uploadTempStatusCl2 == 1){
        if (uploadTempExpStatusCl2 == 0){
            uploadTempExpCl2 = new uint8_t [uploadTempFileSize+50];
            uploadTempExpStatusCl2 = 1;
        }
        else{
            
            delete [] uploadTempExpCl2;
            uploadTempExpCl2 = new uint8_t [uploadTempFileSize+50];
            
        }
        
        for (int counter1 = 0; counter1 < uploadTempFileSize+50; counter1++) uploadTempExpCl2 [counter1] = uploadTempCl2 [counter1];
    }
    
    if (uploadTempStatusCl3 == 1){
        if (uploadTempExpStatusCl3 == 0){
            uploadTempExpCl3 = new uint8_t [uploadTempFileSize+50];
            uploadTempExpStatusCl3 = 1;
        }
        else{
            
            delete [] uploadTempExpCl3;
            uploadTempExpCl3 = new uint8_t [uploadTempFileSize+50];
        }
        
        for (int counter1 = 0; counter1 < uploadTempFileSize+50; counter1++) uploadTempExpCl3 [counter1] = uploadTempCl3 [counter1];
    }
    
    if (uploadTempStatusCl4 == 1){
        if (uploadTempExpStatusCl4 == 0){
            uploadTempExpCl4 = new uint8_t [uploadTempFileSize+50];
            uploadTempExpStatusCl4 = 1;
        }
        else{
            
            delete [] uploadTempExpCl4;
            uploadTempExpCl4 = new uint8_t [uploadTempFileSize+50];
        }
        
        for (int counter1 = 0; counter1 < uploadTempFileSize+50; counter1++) uploadTempExpCl4 [counter1] = uploadTempCl4 [counter1];
    }
    
    if (uploadTempStatusCl5 == 1){
        if (uploadTempExpStatusCl5 == 0){
            uploadTempExpCl5 = new uint8_t [uploadTempFileSize+50];
            uploadTempExpStatusCl5 = 1;
        }
        else{
            
            delete [] uploadTempExpCl5;
            uploadTempExpCl5 = new uint8_t [uploadTempFileSize+50];
        }
        
        for (int counter1 = 0; counter1 < uploadTempFileSize+50; counter1++) uploadTempExpCl5 [counter1] = uploadTempCl5 [counter1];
    }
    
    if (uploadTempStatusCl6 == 1){
        if (uploadTempExpStatusCl6 == 0){
            uploadTempExpCl6 = new uint8_t [uploadTempFileSize+50];
            uploadTempExpStatusCl6 = 1;
        }
        else{
            
            delete [] uploadTempExpCl6;
            uploadTempExpCl6 = new uint8_t [uploadTempFileSize+50];
        }
        
        for (int counter1 = 0; counter1 < uploadTempFileSize+50; counter1++) uploadTempExpCl6 [counter1] = uploadTempCl6 [counter1];
    }
    
    if (uploadTempStatusRef == 1){
        if (uploadTempExpStatusRef == 0){
            uploadTempExpRef = new uint8_t [uploadTempRefFileSize1+50];
            uploadTempExpStatusRef = 1;
            uploadTempExpRef2 = new uint8_t [uploadTempRefFileSize2+50];
            uploadTempExpStatusRef2 = 1;
            uploadTempExpRef3 = new uint8_t [uploadTempRefFileSize3+50];
            uploadTempExpStatusRef3 = 1;
            
            uploadTempExpLoadRef2 = 0;
            uploadTempExpLoadRef3 = 0;
        }
        else{
            
            delete [] uploadTempExpRef;
            uploadTempExpRef = new uint8_t [uploadTempRefFileSize1+50];
            delete [] uploadTempExpRef2;
            uploadTempExpRef2 = new uint8_t [uploadTempRefFileSize2+50];
            delete [] uploadTempExpRef3;
            uploadTempExpRef3 = new uint8_t [uploadTempRefFileSize3+50];
            
            uploadTempExpLoadRef2 = 0;
            uploadTempExpLoadRef3 = 0;
        }
        
        for (int counter1 = 0; counter1 < uploadTempRefFileSize1+50; counter1++) uploadTempExpRef [counter1] = uploadTempRef [counter1];
        for (int counter1 = 0; counter1 < uploadTempRefFileSize2+50; counter1++) uploadTempExpRef2 [counter1] = uploadTempRef2 [counter1];
        for (int counter1 = 0; counter1 < uploadTempRefFileSize3+50; counter1++) uploadTempExpRef3 [counter1] = uploadTempRef3 [counter1];
        
        uploadTempExpLoadRef2 = uploadTempLoadRef2;
        uploadTempExpLoadRef3 = uploadTempLoadRef3;
    }
    
    filePositionExp = filePosition;
    
    boxXLengthExp = boxXLength;
    boxYLengthExp = boxYLength;
    boxXPositionExp = boxXPosition;
    boxYPositionExp = boxYPosition;
    timePointHoldExp = timePointHold;
    dotNumberCurrentExp = dotNumberCurrent;
    colorFlagExp1 = colorFlag1;
    colorFlagExp2 = colorFlag2;
    colorFlagExp3 = colorFlag3;
    colorFlagExp1 = colorFlag4;
    colorFlagExp2 = colorFlag5;
    colorFlagExp3 = colorFlag6;
    
    ifstream fin;
    
    string extension = to_string(filePositionExp);
    
    if (extension.length() == 1) extension = "000"+extension;
    else if (extension.length() == 2) extension = "00"+extension;
    else if (extension.length() == 3) extension = "0"+extension;
    
    string connectDataPath = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Processed/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_MasterData";
    string connectDataRevPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_MasterData";
    
    struct stat sizeOfFile;
    
    long sizeForCopy = 0;
    long size1 = 0;
    long size2 = 0;
    int checkFlag = 0;
    
    for (int counter1 = 0; counter1 < 6; counter1++){
        sizeForCopy = 0;
        
        if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        else if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        if (sizeForCopy != 0){
            if (counter1 == 0) size1 = sizeForCopy;
            else if (counter1 == 1) size2 = sizeForCopy;
            else if (counter1 == 2){
                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                    checkFlag = 1;
                    break;
                }
                else{
                    
                    size1 = 0;
                    size2 = 0;
                    usleep (50000);
                }
            }
            else if (counter1 == 3) size1 = sizeForCopy;
            else if (counter1 == 4) size2 = sizeForCopy;
            else if (counter1 == 5){
                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                    checkFlag = 1;
                }
            }
        }
    }
    
    int errorFlag = 0;
    
    if (checkFlag == 1){
        if (positionExportStatus == 1) delete [] arrayPositionExport;
        arrayPositionExport = new int [sizeForCopy+50];
        positionExportCount = 0;
        positionExportStatus = 1;
        
        if (gravityCenterExportStatus == 1) delete [] arrayGravityCenterExport;
        arrayGravityCenterExport = new int [sizeForCopy+50];
        gravityCenterExportCount = 0;
        gravityCenterExportStatus = 1;
        
        if (gravityCenterExportCorrectStatus == 1) delete [] arrayGravityCenterExportHold;
        arrayGravityCenterExportHold = new int [sizeForCopy+50];
        gravityCenterExportCorrectCount = 0;
        gravityCenterExportCorrectStatus = 1;
        
        fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
        
        if (fin.is_open()){
            int finData [17];
            
            uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
            fin.read((char*)uploadTempA, sizeForCopy+50);
            
            if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 || (finData [0] = uploadTempA [sizeForCopy-12]) != 0){
                usleep(50000);
                fin.read((char*)uploadTempA, sizeForCopy+50);
                
                if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 || (finData [0] = uploadTempA [sizeForCopy-12]) != 0){
                    usleep(50000);
                    fin.read((char*)uploadTempA, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 || (finData [0] = uploadTempA [sizeForCopy-12]) != 0){
                        errorFlag = 1;
                    }
                }
            }
            
            fin.close();
            
            if (errorFlag == 0){
                unsigned long readPosition = 0;
                int stepCount = 0;
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTempA [readPosition], readPosition++;
                        finData [1] = uploadTempA [readPosition], readPosition++; //--1
                        finData [2] = uploadTempA [readPosition], readPosition++;
                        finData [3] = uploadTempA [readPosition], readPosition++; //--2
                        finData [4] = uploadTempA [readPosition], readPosition++; //--3
                        finData [5] = uploadTempA [readPosition], readPosition++;
                        finData [6] = uploadTempA [readPosition], readPosition++;
                        finData [7] = uploadTempA [readPosition], readPosition++; //--4
                        finData [8] = uploadTempA [readPosition], readPosition++; //--+/- flag
                        finData [9] = uploadTempA [readPosition], readPosition++;
                        finData [10] = uploadTempA [readPosition], readPosition++;
                        finData [11] = uploadTempA [readPosition], readPosition++;
                        finData [12] = uploadTempA [readPosition], readPosition++; //--5
                        finData [13] = uploadTempA [readPosition], readPosition++; //--6
                        finData [14] = uploadTempA [readPosition], readPosition++;
                        finData [15] = uploadTempA [readPosition], readPosition++;
                        finData [16] = uploadTempA [readPosition], readPosition++; //--7
                        
                        finData [1] = finData [0]*256+finData [1];
                        finData [3] = finData [2]*256+finData [3];
                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                        
                        if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                        else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                        
                        finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                        
                        if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                        else{
                            
                            arrayPositionExport [positionExportCount] = finData [1], positionExportCount++;
                            arrayPositionExport [positionExportCount] = finData [3], positionExportCount++;
                            arrayPositionExport [positionExportCount] = finData [4], positionExportCount++;
                            arrayPositionExport [positionExportCount] = finData [7], positionExportCount++;
                            arrayPositionExport [positionExportCount] = finData [12], positionExportCount++;
                            arrayPositionExport [positionExportCount] = finData [13], positionExportCount++;
                            arrayPositionExport [positionExportCount] = finData [16], positionExportCount++;
                        }
                    }
                    else if (stepCount == 1){
                        finData [0] = uploadTempA [readPosition], readPosition++;
                        finData [1] = uploadTempA [readPosition], readPosition++; //--1
                        finData [2] = uploadTempA [readPosition], readPosition++;
                        finData [3] = uploadTempA [readPosition], readPosition++; //--2
                        finData [4] = uploadTempA [readPosition], readPosition++;
                        finData [5] = uploadTempA [readPosition], readPosition++;
                        finData [6] = uploadTempA [readPosition], readPosition++; //--3
                        finData [7] = uploadTempA [readPosition], readPosition++; //--4
                        finData [8] = uploadTempA [readPosition], readPosition++;
                        finData [9] = uploadTempA [readPosition], readPosition++;
                        finData [10] = uploadTempA [readPosition], readPosition++; //--5
                        finData [11] = uploadTempA [readPosition], readPosition++; //--6
                        
                        finData [1] = finData [0]*256+finData [1];
                        finData [3] = finData [2]*256+finData [3];
                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                        finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                        
                        if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                        else{
                            
                            arrayGravityCenterExport [gravityCenterExportCount] = finData [1], gravityCenterExportCount++;
                            arrayGravityCenterExport [gravityCenterExportCount] = finData [3], gravityCenterExportCount++;
                            arrayGravityCenterExport [gravityCenterExportCount] = finData [6], gravityCenterExportCount++;
                            arrayGravityCenterExport [gravityCenterExportCount] = finData [7], gravityCenterExportCount++;
                            arrayGravityCenterExport [gravityCenterExportCount] = finData [10], gravityCenterExportCount++;
                            arrayGravityCenterExport [gravityCenterExportCount] = finData [11], gravityCenterExportCount++;
                            
                            arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = finData [1], gravityCenterExportCorrectCount++;
                            arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = finData [3], gravityCenterExportCorrectCount++;
                            arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = finData [6], gravityCenterExportCorrectCount++;
                            arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = finData [7], gravityCenterExportCorrectCount++;
                            arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = finData [10], gravityCenterExportCorrectCount++;
                            arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = finData [11], gravityCenterExportCorrectCount++;
                        }
                    }
                    
                } while (stepCount != 3);
            }
            
            delete [] uploadTempA;
        }
        else{
            
            fin.open(connectDataPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                int finData [11];
                
                uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTempA, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                    usleep(50000);
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 ){
                            errorFlag = 1;
                        }
                    }
                }
                
                fin.close();
                
                if (errorFlag == 0){
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTempA [readPosition], readPosition++;
                            finData [1] = uploadTempA [readPosition], readPosition++; //--2
                            finData [2] = uploadTempA [readPosition], readPosition++;
                            finData [3] = uploadTempA [readPosition], readPosition++; //--2
                            finData [4] = uploadTempA [readPosition], readPosition++; //--1
                            finData [5] = uploadTempA [readPosition], readPosition++;
                            finData [6] = uploadTempA [readPosition], readPosition++;
                            finData [7] = uploadTempA [readPosition], readPosition++; //--3
                            finData [8] = uploadTempA [readPosition], readPosition++; //--1
                            finData [9] = uploadTempA [readPosition], readPosition++;
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            
                            if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                            else{
                                
                                arrayPositionExport [positionExportCount] = finData [1], positionExportCount++; //------X position------
                                arrayPositionExport [positionExportCount] = finData [3], positionExportCount++; //------Y position------
                                arrayPositionExport [positionExportCount] = finData [4], positionExportCount++; //------Value------
                                arrayPositionExport [positionExportCount] = finData [7], positionExportCount++; //------Connect No------
                                arrayPositionExport [positionExportCount] = 0, positionExportCount++; //------Cell No------
                                arrayPositionExport [positionExportCount] = 0, positionExportCount++; //------Status------
                                arrayPositionExport [positionExportCount] = 0, positionExportCount++; //------Lineage no------
                            }
                        }
                        else if (stepCount == 1){
                            finData [0] = uploadTempA [readPosition], readPosition++;
                            finData [1] = uploadTempA [readPosition], readPosition++;
                            finData [2] = uploadTempA [readPosition], readPosition++; //--1
                            finData [3] = uploadTempA [readPosition], readPosition++; //--2
                            finData [4] = uploadTempA [readPosition], readPosition++; //--3
                            finData [5] = uploadTempA [readPosition], readPosition++;
                            finData [6] = uploadTempA [readPosition], readPosition++;
                            finData [7] = uploadTempA [readPosition], readPosition++; //--4
                            finData [8] = uploadTempA [readPosition], readPosition++;
                            finData [9] = uploadTempA [readPosition], readPosition++; //--5
                            finData [10] = uploadTempA [readPosition], readPosition++; //--6
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            finData [9] = finData [8]*256+finData [9];
                            
                            if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                        }
                        else if (stepCount == 2){
                            finData [0] = uploadTempA [readPosition], readPosition++;
                            finData [1] = uploadTempA [readPosition], readPosition++; //--1
                            finData [2] = uploadTempA [readPosition], readPosition++;
                            finData [3] = uploadTempA [readPosition], readPosition++; //--2
                            finData [4] = uploadTempA [readPosition], readPosition++;
                            finData [5] = uploadTempA [readPosition], readPosition++;
                            finData [6] = uploadTempA [readPosition], readPosition++; //--3
                            finData [7] = uploadTempA [readPosition], readPosition++; //--4
                            finData [8] = uploadTempA [readPosition], readPosition++;
                            finData [9] = uploadTempA [readPosition], readPosition++;
                            finData [10] = uploadTempA [readPosition], readPosition++; //--5
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                            finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                            
                            if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                            else{
                                
                                arrayGravityCenterExport [gravityCenterExportCount] = finData [1], gravityCenterExportCount++;
                                arrayGravityCenterExport [gravityCenterExportCount] = finData [3], gravityCenterExportCount++;
                                arrayGravityCenterExport [gravityCenterExportCount] = finData [6], gravityCenterExportCount++;
                                arrayGravityCenterExport [gravityCenterExportCount] = finData [7], gravityCenterExportCount++;
                                arrayGravityCenterExport [gravityCenterExportCount] = finData [10], gravityCenterExportCount++;
                                arrayGravityCenterExport [gravityCenterExportCount] = 0, gravityCenterExportCount++;
                                
                                arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = finData [1], gravityCenterExportCorrectCount++;
                                arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = finData [3], gravityCenterExportCorrectCount++;
                                arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = finData [6], gravityCenterExportCorrectCount++;
                                arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = finData [7], gravityCenterExportCorrectCount++;
                                arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = finData [10], gravityCenterExportCorrectCount++;
                                arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = 0, gravityCenterExportCorrectCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                }
                
                delete [] uploadTempA;
            }
        }
        
        if (errorFlag == 0){
            //------Master Data Status UpLoad------
            string connectStatusDataPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_Status";
            
            sizeForCopy = 0;
            
            if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (sizeForCopy < gravityCenterExportCount*2) sizeForCopy = gravityCenterExportCount*2;
            
            if (timeSelectedExportStatus == 1) delete [] arrayTimeSelectedExport;
            arrayTimeSelectedExport = new int [sizeForCopy+500];
            timeSelectedExportCount = 0;
            timeSelectedExportStatus = 1;
            
            fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                int finData [19];
                
                uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTempA, sizeForCopy+50);
                
                if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 || (finData [0] = uploadTempA [sizeForCopy-12]) != 0 || (finData [0] = uploadTempA [sizeForCopy-13]) != 0 || (finData [0] = uploadTempA [sizeForCopy-14]) != 0 || (finData [0] = uploadTempA [sizeForCopy-15]) != 0 || (finData [0] = uploadTempA [sizeForCopy-16]) != 0 || (finData [0] = uploadTempA [sizeForCopy-17]) != 0 || (finData [0] = uploadTempA [sizeForCopy-18]) != 0 || (finData [0] = uploadTempA [sizeForCopy-19]) != 0){
                    usleep(50000);
                    fin.read((char*)uploadTempA, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 || (finData [0] = uploadTempA [sizeForCopy-12]) != 0 || (finData [0] = uploadTempA [sizeForCopy-13]) != 0 || (finData [0] = uploadTempA [sizeForCopy-14]) != 0 || (finData [0] = uploadTempA [sizeForCopy-15]) != 0 || (finData [0] = uploadTempA [sizeForCopy-16]) != 0 || (finData [0] = uploadTempA [sizeForCopy-17]) != 0 || (finData [0] = uploadTempA [sizeForCopy-18]) != 0 || (finData [0] = uploadTempA [sizeForCopy-19]) != 0){
                        errorFlag = 1;
                    }
                }
                
                fin.close();
                
                if (errorFlag == 0){
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTempA [readPosition], readPosition++; //--1 Status
                            finData [1] = uploadTempA [readPosition], readPosition++;
                            finData [2] = uploadTempA [readPosition], readPosition++;
                            finData [3] = uploadTempA [readPosition], readPosition++; //--3 Prev connect
                            finData [4] = uploadTempA [readPosition], readPosition++;
                            finData [5] = uploadTempA [readPosition], readPosition++;
                            finData [6] = uploadTempA [readPosition], readPosition++; //--4 Start position
                            finData [7] = uploadTempA [readPosition], readPosition++;
                            finData [8] = uploadTempA [readPosition], readPosition++; //--5 Cut no
                            finData [9] = uploadTempA [readPosition], readPosition++; //--6 Ch2
                            finData [10] = uploadTempA [readPosition], readPosition++; //--7 Ch3
                            finData [11] = uploadTempA [readPosition], readPosition++; //--8 Ch4
                            finData [12] = uploadTempA [readPosition], readPosition++; //--9 Ch5
                            finData [13] = uploadTempA [readPosition], readPosition++;
                            finData [14] = uploadTempA [readPosition], readPosition++;
                            finData [15] = uploadTempA [readPosition], readPosition++; //--10 Connect no.
                            finData [16] = uploadTempA [readPosition], readPosition++;
                            finData [17] = uploadTempA [readPosition], readPosition++;
                            finData [18] = uploadTempA [readPosition], readPosition++; //--11 Ling no.
                            
                            finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                            finData [8] = finData [7]*256+finData [8];
                            finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                            finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                            
                            if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                            else{
                                
                                arrayTimeSelectedExport [timeSelectedExportCount] = finData [0], timeSelectedExportCount++; //------Selected, removed, eliminated status------
                                arrayTimeSelectedExport [timeSelectedExportCount] = finData [3], timeSelectedExportCount++; //------When new line is created, enter line number which creates------
                                arrayTimeSelectedExport [timeSelectedExportCount] = finData [6], timeSelectedExportCount++; //------PositionRevise Start------
                                arrayTimeSelectedExport [timeSelectedExportCount] = finData [8], timeSelectedExportCount++; //------Cut line number------
                                arrayTimeSelectedExport [timeSelectedExportCount] = finData [9], timeSelectedExportCount++; //------X Start------
                                arrayTimeSelectedExport [timeSelectedExportCount] = finData [10], timeSelectedExportCount++; //------X End------
                                arrayTimeSelectedExport [timeSelectedExportCount] = finData [11], timeSelectedExportCount++; //------Y Start------
                                arrayTimeSelectedExport [timeSelectedExportCount] = finData [12], timeSelectedExportCount++; //------Y End------
                                arrayTimeSelectedExport [timeSelectedExportCount] = finData [15], timeSelectedExportCount++; //------Connect------
                                arrayTimeSelectedExport [timeSelectedExportCount] = finData [18], timeSelectedExportCount++; //------Lineage------
                            }
                        }
                        
                    } while (stepCount != 3);
                }
                
                delete [] uploadTempA;
            }
            else{
                
                for (int counter1 = 0; counter1 < gravityCenterExportCount/6; counter1++){ //------Counter number corresponds to connect No------
                    arrayTimeSelectedExport [timeSelectedExportCount] = 1, timeSelectedExportCount++; //------Selected, removed, eliminated status------
                    arrayTimeSelectedExport [timeSelectedExportCount] = 0, timeSelectedExportCount++; //------When new line is created, enter line number which creates------
                    arrayTimeSelectedExport [timeSelectedExportCount] = 0, timeSelectedExportCount++; //------PositionRevise Start------
                    arrayTimeSelectedExport [timeSelectedExportCount] = 0, timeSelectedExportCount++; //------Cut line number------
                    arrayTimeSelectedExport [timeSelectedExportCount] = 0, timeSelectedExportCount++; //------X Start------
                    arrayTimeSelectedExport [timeSelectedExportCount] = 0, timeSelectedExportCount++; //------X End------
                    arrayTimeSelectedExport [timeSelectedExportCount] = 0, timeSelectedExportCount++; //------Y Start------
                    arrayTimeSelectedExport [timeSelectedExportCount] = 0, timeSelectedExportCount++; //------Y End------
                    arrayTimeSelectedExport [timeSelectedExportCount] = counter1+1, timeSelectedExportCount++; //------Connect------
                    arrayTimeSelectedExport [timeSelectedExportCount] = 0, timeSelectedExportCount++; //------Lineage------
                }
                
                int valueTemp = 0;
                
                for (int counter1 = 0; counter1 < positionExportCount/7; counter1++){
                    if (arrayPositionExport [counter1*7+3] != valueTemp){
                        valueTemp = arrayPositionExport [counter1*7+3];
                        arrayTimeSelectedExport [(valueTemp-1)*10+2] = counter1;
                        
                        if (arrayPositionExport [counter1*7+5] == 0){
                            arrayTimeSelectedExport [(valueTemp-1)*10] = 0;
                        }
                    }
                }
            }
            
            for (int counter1 = 0; counter1 < timeSelectedExportCount/10; counter1++){
                if (arrayTimeSelectedExport [counter1*10] == 2) arrayTimeSelectedExport [counter1*10] = 0;
                else if (arrayTimeSelectedExport [counter1*10] == 7) arrayTimeSelectedExport [counter1*10] = 1;
            }
            
            //for (int counterA = 0; counterA < timeSelectedExportCount/10; counterA++){
            //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelectedExport [counterA*10+counterB];
            //    cout<<" arrayTimeSelectedExport "<<counterA<<endl;
            //}
            
            if (errorFlag == 0){
                
                string mapPath = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Processed/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_Map";
                string revisedMapPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_RevisedMap";
                
                revisedWorkingMapExp = new int *[imageXYLength+1];
                
                for (int counter1 = 0; counter1 < imageXYLength+1; counter1++){
                    revisedWorkingMapExp [counter1] = new int [imageXYLength+1];
                }
                
                int yDimensionCount;
                int xDimensionCount;
                int readBit [4];
                int pixData;
                
                int totalSize = imageXYLength*imageXYLength*4;
                
                fin.open(revisedMapPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *upload2 = new uint8_t [totalSize+50];
                    
                    fin.read((char*)upload2, totalSize+1);
                    fin.close();
                    
                    yDimensionCount = 0;
                    xDimensionCount = 0;
                    
                    for (int counter1 = 0; counter1 < totalSize; counter1 = counter1+4){
                        readBit [0] = upload2[counter1];
                        readBit [1] = upload2[counter1+1];
                        readBit [2] = upload2[counter1+2];
                        readBit [3] = upload2[counter1+3];
                        
                        pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                        
                        for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                            revisedWorkingMapExp [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                        }
                        
                        if (xDimensionCount == imageXYLength){
                            xDimensionCount = 0;
                            yDimensionCount++;
                            
                            if (yDimensionCount == imageXYLength){
                                break;
                            }
                        }
                    }
                    
                    delete [] upload2;
                }
                else{
                    
                    fin.open(mapPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        uint8_t *upload2 = new uint8_t [totalSize+50];
                        
                        fin.read((char*)upload2, totalSize+1);
                        fin.close();
                        
                        yDimensionCount = 0;
                        xDimensionCount = 0;
                        
                        for (int counter1 = 0; counter1 < totalSize; counter1 = counter1+4){
                            readBit [0] = upload2[counter1];
                            readBit [1] = upload2[counter1+1];
                            readBit [2] = upload2[counter1+2];
                            readBit [3] = upload2[counter1+3];
                            
                            pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                            
                            for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                                revisedWorkingMapExp [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                            }
                            
                            if (xDimensionCount == imageXYLength){
                                xDimensionCount = 0;
                                yDimensionCount++;
                                
                                if (yDimensionCount == imageXYLength){
                                    break;
                                }
                            }
                        }
                        
                        delete [] upload2;
                    }
                }
                
                revisedWorkingMapExpStatus = 1;
            }
        }
    }
    
    return errorFlag;
}

-(void)arrayAreaDataHoldUpDate{
    double *arrayUpDate = new double [areaDataHoldCount+10];
    
    for (int counter1 = 0; counter1 < areaDataHoldCount; counter1++) arrayUpDate [counter1] = arrayAreaDataHold [counter1];
    
    delete [] arrayAreaDataHold;
    arrayAreaDataHold = new double [areaDataHoldLimit+2500];
    areaDataHoldLimit = areaDataHoldLimit+2500;
    
    for (int counter1 = 0; counter1 < areaDataHoldLimit; counter1++){
        arrayAreaDataHold [counter1] = 0;
    }
    
    for (int counter1 = 0; counter1 < areaDataHoldCount; counter1++) arrayAreaDataHold [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)arrayDotDataHoldUpDate{
    int *arrayUpDate = new int [dotDataHoldCount+10];
    
    for (int counter1 = 0; counter1 < dotDataHoldCount; counter1++) arrayUpDate [counter1] = arrayDotDataHold [counter1];
    
    delete [] arrayDotDataHold;
    arrayDotDataHold = new int [dotDataHoldLimit+1000];
    dotDataHoldLimit = dotDataHoldLimit+1000;
    
    for (int counter1 = 0; counter1 < dotDataHoldCount; counter1++) arrayDotDataHold [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)directoryInfoUpDate{
    string *arrayUpDate = new string [directoryInfoCount+10];
    
    for (int counter1 = 0; counter1 < directoryInfoCount; counter1++) arrayUpDate [counter1] = arrayDirectoryInfo [counter1];
    
    delete [] arrayDirectoryInfo;
    arrayDirectoryInfo = new string [directoryInfoLimit+500];
    directoryInfoLimit = directoryInfoLimit+500;
    
    for (int counter1 = 0; counter1 < directoryInfoCount; counter1++) arrayDirectoryInfo [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)gravityCenterRevUpDate{
    int *arrayUpDate = new int [gravityCenterRevCount+10];
    
    for (int counter1 = 0; counter1 < gravityCenterRevCount; counter1++) arrayUpDate [counter1] = arrayGravityCenterRev [counter1];
    
    delete [] arrayGravityCenterRev;
    arrayGravityCenterRev = new int [gravityCenterRevLimit+2000];
    gravityCenterRevLimit = gravityCenterRevLimit+2000;
    
    for (int counter1 = 0; counter1 < gravityCenterRevCount; counter1++) arrayGravityCenterRev [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    if (timerCD) [timerCD invalidate];
}

@end
