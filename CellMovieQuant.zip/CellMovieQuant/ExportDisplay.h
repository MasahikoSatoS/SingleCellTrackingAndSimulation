//
//  ExportDisplay.h
//  CellMovieQuant
//
//  Created by Masahiko Sato on 2019-10-25.
//

#ifndef EXPORTDIAPLAY_H
#define EXPORTDIAPLAY_H
#import "Controller.h" 
#endif

@interface ExportDisplay : NSView{
    double xPositionAdjustExport; //Display operation
    double yPositionAdjustExport; //Display operation
    double xPointDownExport; //Display operation
    double yPointDownExport; //Display operation
    double xPointDragExport; //Display operation
    double yPointDragExport; //Display operation
    double xPositionMoveExport; //Display operation
    double yPositionMoveExport; //Display operation
    double xPositionExport; //Display operation
    double yPositionExport; //Display operation
    double windowWidthExport; //Display operation
    double windowHeightExport; //Display operation
    int mouseDragFlag; //Display operation
    int magnificationExport; //Display operation
    
    int displayModeSelect; //Display mode select
    int timingEx2; //Timing count
    
    NSImage *exportImage;
    NSImage *exportImage2;
    
    NSTimer *exportMainTimer2;
}

-(void)display;

@end
