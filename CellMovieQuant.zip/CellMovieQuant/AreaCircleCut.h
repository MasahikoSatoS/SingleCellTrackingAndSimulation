//
// AreaCircleCut.h
// CellMovieQuant
//
// Created by Masahiko Sato on 02/09/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef AREACIRCLECUT_H
#define AREACIRCLECUT_H
#import "LineSet.h" 
#endif

@interface AreaCircleCut : NSObject{
    int **connectivityMap; //Connect map
    int **targetMap; //Target map
    int **internalZeroMap; //Internal zero map
}

-(int)circleCut:(int) processSet;
-(int)areaProcess:(int)type :(int)dimension :(int)valueTemp :(int)horizontalStart :(int)verticalStart :(int)processSet;
-(void)positionRevSelectedUpDate;
-(void)gravityCenterRevUpDate;
-(void)timeSelectedUpDate;

@end
