//
// LineSet.h
// CellMovieQuant
//
// Created by Masahiko Sato on 06/10/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef LINESET_H
#define LINESET_H
#import "Controller.h"
#import "NewAreaCreation.h"
#import "AreaCircleCut.h"
#import "GapFill.h" 
#endif

@interface LineSet : NSObject {
    int *targetGapFill; //Array for gap fill
    int targetGapFillCount;
    int targetGapFillAddition;
    int targetGapFillLimit;
    
    id newAreaCreation;
    id areaCircleCut;
    id subProcesses;
}

-(void)lineSetProcess:(int)processType;
-(void)gapFillUpdate;
-(void)targetHoldUpDate;
-(void)targetHoldStatusUpDate;

@end
