//
//  DotAreaBoxProcess.m
//  CellMovieQuant
//
//  Created by Masahiko Sato on 2021-12-28.
//

#import "DotAreaBoxProcess.h"

@implementation DotAreaBoxProcess

-(IBAction)quantitationModeSet:(id)sender{
    if (initialArraySet == 1 && timePointHold >= 1){
        if (quantitationStatusHold == 0){
            [quantitationModeDisplay setStringValue:@"On"];
            quantitationStatusHold = 1;
        }
        else if (quantitationStatusHold == 1){
            [quantitationModeDisplay setStringValue:@"Off"];
            quantitationStatusHold = 0;
            
            analysisStatusHold = 0;
            [analysisModeDisplay setStringValue:@"Off"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)areaTotalDisplaySet:(id)sender{
    if (areaModeStatusHold == 1 && imageProgressFlag == 0){
        if (areaTotalTable == 0){
            areaTotalTable = 1;
            [areaTotalTableDisplay setStringValue:@"Total"];
        }
        else if (areaTotalTable == 1){
            areaTotalTable = 0;
            [areaTotalTableDisplay setStringValue:@"Area"];
        }
        
        if (areaModeStatusHold == 1){
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                arrayTimeSelected [counter1*10+9] = 0;
            }
            
            for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                    if ((int)arrayDotDataHold [counter1*3+2] >= 0 && (int)arrayDotDataHold [counter1*3+2] < imageSizeLimit && (int)arrayDotDataHold [counter1*3+1] >= 0 && (int)arrayDotDataHold [counter1*3+1] < imageSizeLimit){
                        if (arrayTimeSelected [counter2*10+8] == revisedWorkingMap [(int)arrayDotDataHold [counter1*3+2]][(int)arrayDotDataHold [counter1*3+1]]){
                            arrayTimeSelected [counter2*10+9]++;
                            break;
                        }
                    }
                }
            }
            
            subProcesses = [[SubProcesses alloc] init];
            [subProcesses areaTotalDataSet];
        }
        
        areaValueCall = 1;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Area Mode Off or Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)boxDimensionSet:(id)sender{
    if (initialArraySet == 1 && timePointHold >= 1 && imageProgressFlag == 0){
        int xLengthValue = (int)([boxXDisplay integerValue]);
        int yLengthValue = (int)([boxYDisplay integerValue]);
        
        if (xLengthValue > 10 && xLengthValue < imageXYLength && yLengthValue > 10 && yLengthValue < imageXYLength){
            boxXLength = xLengthValue;
            boxYLength = yLengthValue;
            
            string dimensionXY = to_string(xLengthValue)+" x "+to_string(yLengthValue);
            [boxDimensionDisplay setStringValue:@(dimensionXY.c_str())];
            
            arrayAreaDataHold [(timePointHold-1)*25+6] = boxXLength;
            arrayAreaDataHold [(timePointHold-1)*25+7] = boxYLength;
            arrayAreaDataHold [(timePointHold-1)*25+8] = 0;
            arrayAreaDataHold [(timePointHold-1)*25+9] = 0;
            
            ofstream oin;
            
            string dataSaveTreatmentPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"AnalysisData";
            
            oin.open(dataSaveTreatmentPath.c_str(), ios::out | ios::binary);
            
            for (int counter1 = 0; counter1 < areaDataHoldCount; counter1++){
                oin<<to_string(arrayAreaDataHold [counter1])<<endl;
            }
            
            oin.close();
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Dimension: Too Small or Too Large"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)boxSetMode:(id)sender{
    if (initialArraySet == 1 && timePointHold >= 1){
        if (boxXLength != 0 && boxYLength != 0){
            if (dimensionSetModeHold == 0){
                dimensionSetModeHold = 1;
                [boxDimensionSetDisplay setStringValue:@"On"];
            }
            else{
                
                [boxDimensionSetDisplay setStringValue:@"Off"];
                dimensionSetModeHold = 0;
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Dimension Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)boxDimensionClear:(id)sender{
    if (initialArraySet == 1 && timePointHold >= 1 && imageProgressFlag == 0){
        boxXLength = 0;
        boxYLength = 0;
        
        dimensionSetModeHold = 0;
        
        arrayAreaDataHold [(timePointHold-1)*25+6] = 0;
        arrayAreaDataHold [(timePointHold-1)*25+7] = 0;
        arrayAreaDataHold [(timePointHold-1)*25+8] = 0;
        arrayAreaDataHold [(timePointHold-1)*25+9] = 0;
        
        [boxXDisplay setStringValue:@""];
        [boxYDisplay setStringValue:@""];
        [boxDimensionDisplay setStringValue:@"nil x nil"];
        
        [boxDimensionSetDisplay setStringValue:@"Off"];
        
        ofstream oin;
        
        string dataSaveTreatmentPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"AnalysisData";
        
        oin.open(dataSaveTreatmentPath.c_str(), ios::out | ios::binary);
        
        for (int counter1 = 0; counter1 < areaDataHoldCount; counter1++){
            oin<<to_string(arrayAreaDataHold [counter1])<<endl;
        }
        
        oin.close();
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)boxDrawingSet:(id)sender{
    if (initialArraySet == 1 && timePointHold >= 1 && imageProgressFlag == 0){
        dimensionSetModeHold = 0;
        
        boxXPosition = boxXPositionCurrent;
        boxYPosition = boxYPositionCurrent;
        
        arrayAreaDataHold [(timePointHold-1)*25+8] = boxXPosition;
        arrayAreaDataHold [(timePointHold-1)*25+9] = boxYPosition;
        
        [boxDimensionSetDisplay setStringValue:@"Off"];
        
        ofstream oin;
        
        string dataSaveTreatmentPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"AnalysisData";
        
        oin.open(dataSaveTreatmentPath.c_str(), ios::out | ios::binary);
        
        for (int counter1 = 0; counter1 < areaDataHoldCount; counter1++){
            oin<<to_string(arrayAreaDataHold [counter1])<<endl;
        }
        
        oin.close();
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)pointModeSet:(id)sender{
    if (initialArraySet == 1 && timePointHold >= 1){
        if (quantitationStatusHold == 1){
            if (analysisStatusHold == 0){
                analysisStatusHold = 1;
                [analysisModeDisplay setStringValue:@"Dot Set"];
            }
            else if (analysisStatusHold == 1){
                analysisStatusHold = 2;
                [analysisModeDisplay setStringValue:@"Dot Clear"];
            }
            else if (analysisStatusHold == 2){
                analysisStatusHold = 0;
                [analysisModeDisplay setStringValue:@"Off"];
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Quantitation Mode: Set On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clearDotTime:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0 && phaseStatus == 0 && imageProgressFlag == 0 && quantitationStatusHold == 1){
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"All Dot Data (This Time Point) Will Be Removed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            int matchFind = -1;
            int timeTemp = 0;
            
            for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                if (arrayDotDataHold [counter1*3] < -100000) timeTemp = arrayDotDataHold [counter1*3]*-1-100000;
                else if (arrayDotDataHold [counter1*3] < 0 && arrayDotDataHold [counter1*3] >= -100000) timeTemp = arrayDotDataHold [counter1*3]*-1;
                else if (arrayDotDataHold [counter1*3] >= 0 && arrayDotDataHold [counter1*3] <= 100000) timeTemp = arrayDotDataHold [counter1*3];
                else if (arrayDotDataHold [counter1*3] > 100000) timeTemp = arrayDotDataHold [counter1*3]-100000;
                
                if (timeTemp == timePointHold){
                    matchFind = counter1;
                    break;
                }
            }
            
            if (matchFind != -1){
                int *arrayDotDataHoldTemp = new int [dotDataHoldCount+10];
                int dotDataHoldCountTemp = 0;
                
                for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                    if (arrayDotDataHold [counter1*3] < -100000) timeTemp = arrayDotDataHold [counter1*3]*-1-100000;
                    else if (arrayDotDataHold [counter1*3] < 0 && arrayDotDataHold [counter1*3] >= -100000) timeTemp = arrayDotDataHold [counter1*3]*-1;
                    else if (arrayDotDataHold [counter1*3] >= 0 && arrayDotDataHold [counter1*3] <= 100000) timeTemp = arrayDotDataHold [counter1*3];
                    else if (arrayDotDataHold [counter1*3] > 100000) timeTemp = arrayDotDataHold [counter1*3]-100000;
                    
                    if (timeTemp != timePointHold){
                        arrayDotDataHoldTemp [dotDataHoldCountTemp] = arrayDotDataHold [counter1*3], dotDataHoldCountTemp++;
                        arrayDotDataHoldTemp [dotDataHoldCountTemp] = arrayDotDataHold [counter1*3+1], dotDataHoldCountTemp++;
                        arrayDotDataHoldTemp [dotDataHoldCountTemp] = arrayDotDataHold [counter1*3+2], dotDataHoldCountTemp++;
                    }
                    else if (timeTemp == timePointHold){
                        dotNumberCurrent--;
                    }
                }
                
                dotDataHoldCount = 0;
                
                for (int counter1 = 0; counter1 < dotDataHoldCountTemp; counter1++) arrayDotDataHold [dotDataHoldCount] = arrayDotDataHoldTemp [counter1], dotDataHoldCount++;
                
                delete [] arrayDotDataHoldTemp;
                
                ofstream oin;
                
                string dataSaveTreatmentPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"DotData";
                
                oin.open(dataSaveTreatmentPath.c_str(), ios::out | ios::binary);
                
                for (int counter1 = 0; counter1 < dotDataHoldCount; counter1++) oin<<arrayDotDataHold [counter1]<<endl;
                
                oin.close();
                
                arrayAreaDataHold [(timePointHold-1)*25+5] = dotNumberCurrent;
                
                if (areaModeStatusHold == 1){
                    for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                        arrayTimeSelected [counter1*10+9] = 0;
                    }
                    
                    for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                        for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                            if ((int)arrayDotDataHold [counter1*3+2] >= 0 && (int)arrayDotDataHold [counter1*3+2] < imageSizeLimit && (int)arrayDotDataHold [counter1*3+1] >= 0 && (int)arrayDotDataHold [counter1*3+1] < imageSizeLimit){
                                if (arrayTimeSelected [counter2*10+8] == revisedWorkingMap [(int)arrayDotDataHold [counter1*3+2]][(int)arrayDotDataHold [counter1*3+1]]){
                                    arrayTimeSelected [counter2*10+9]++;
                                    break;
                                }
                            }
                        }
                    }
                    
                    subProcesses = [[SubProcesses alloc] init];
                    [subProcesses areaTotalDataSet];
                }
                
                string dataSaveTreatmentPath2 = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"AnalysisData";
                
                oin.open(dataSaveTreatmentPath2.c_str(), ios::out | ios::binary);
                
                for (int counter1 = 0; counter1 < areaDataHoldCount; counter1++){
                    oin<<to_string(arrayAreaDataHold [counter1])<<endl;
                }
                
                oin.close();
                
                areaValueCall = 1;
            }
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Mising/Movie On/Coping In Progress/Quantitation Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)creatDataFile:(id)sender{
    if (areaDataHoldCount != 0 && imageProgressFlag == 0){
        string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
        mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Movie_Quant";
        mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        DIR *dir;
        struct dirent *dent;
        
        string entry;
        string extractString;
        int maxEntryNo = 0;
        
        dir = opendir(resultSavePath2.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Movie_Quant") != -1){
                    extractString = entry.substr(entry.find("MQ")+2, entry.find(".txt")-entry.find("MQ")-2);
                    
                    if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                }
            }
            
            closedir(dir);
        }
        
        maxEntryNo++;
        
        string path = resultSavePath2+"/Movie_Quant-MQ"+to_string(maxEntryNo)+".txt";
        
        string *baseData = new string [100];
        
        string displayData2;
        
        baseData [0] = "Time";
        displayData2 = to_string(arrayAreaDataHold [(timePointHold-1)*25]);
        baseData [1] = displayData2.substr(0, displayData2.find("."));
        
        baseData [2] = "Threshold";
        displayData2 = to_string(arrayAreaDataHold [(timePointHold-1)*25+1]);
        baseData [3] = displayData2.substr(0, displayData2.find("."));
        
        baseData [4] = "Image Area";
        displayData2 = to_string(arrayAreaDataHold [(timePointHold-1)*25+2]);
        baseData [5] = displayData2.substr(0, displayData2.find("."));
        
        baseData [6] = "Image Total";
        displayData2 = to_string(arrayAreaDataHold [(timePointHold-1)*25+3]);
        baseData [7] = displayData2.substr(0, displayData2.find("."));
        
        baseData [8] = "Average";
        displayData2 = to_string(arrayAreaDataHold [(timePointHold-1)*25+4]);
        baseData [9] = displayData2.substr(0, displayData2.find("."));
        
        baseData [10] = "Dot Count";
        displayData2 = to_string(arrayAreaDataHold [(timePointHold-1)*25+5]);
        baseData [11] = displayData2.substr(0, displayData2.find("."));
        
        baseData [12] = "Box X length";
        displayData2 = to_string(arrayAreaDataHold [(timePointHold-1)*25+6]);
        baseData [13] = displayData2.substr(0, displayData2.find("."));
        
        baseData [14] = "Box Y length";
        displayData2 = to_string(arrayAreaDataHold [(timePointHold-1)*25+7]);
        baseData [15] = displayData2.substr(0, displayData2.find("."));
        
        baseData [16] = "Box X origin";
        displayData2 = to_string(arrayAreaDataHold [(timePointHold-1)*25+8]);
        baseData [17] = displayData2.substr(0, displayData2.find("."));
        
        baseData [18] = "Box Y origin";
        displayData2 = to_string(arrayAreaDataHold [(timePointHold-1)*25+9]);
        baseData [19] = displayData2.substr(0, displayData2.find("."));
        
        ofstream oin;
        oin.open(path.c_str(), ios::out | ios::binary);
        
        int *arrayAscIIintData = new int [100];
        int ascIIintDataCount = 0;
        
        ascIIconversion = [[ASCIIconversion alloc] init];
        
        for (int counter2 = 0; counter2 < 10; counter2++){
            ascIIstring = baseData [counter2*2];
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = baseData [counter2*2+1];
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
        }
        
        oin.put(13);
        oin.put(10);
        
        ascIIstring = "Area per nucleus";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(13);
        oin.put(10);
        
        double *calDataHold = new double [100];
        
        for (int counter1 = 0; counter1 < 100; counter1++) calDataHold [counter1] = 0;
        
        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
            if (arrayTimeSelected [counter1*10] == 1){
                for (int counter2 = 0; counter2 < gravityCenterRevCount/6; counter2++){
                    if (arrayGravityCenterRev [counter2*6+4] == arrayTimeSelected [counter1*10+8]){
                        calDataHold [0] = calDataHold [0]+arrayGravityCenterRev [counter2*6+2];
                        calDataHold [1] = calDataHold [1]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                        
                        if (arrayTimeSelected [counter1*10+9] == 0){
                            calDataHold [2] = calDataHold [2]+arrayGravityCenterRev [counter2*6+2];
                            calDataHold [3] = calDataHold [3]+arrayTimeSelected [counter1*10+9];
                            calDataHold [4] = calDataHold [4]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                        }
                        else if (arrayTimeSelected [counter1*10+9] == 1 || arrayTimeSelected [counter1*10+9] == 2){
                            calDataHold [5] = calDataHold [5]+arrayGravityCenterRev [counter2*6+2];
                            calDataHold [6] = calDataHold [6]+arrayTimeSelected [counter1*10+9];
                            calDataHold [7] = calDataHold [7]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                        }
                        else if (arrayTimeSelected [counter1*10+9] == 3 || arrayTimeSelected [counter1*10+9] == 4){
                            calDataHold [8] = calDataHold [8]+arrayGravityCenterRev [counter2*6+2];
                            calDataHold [9] = calDataHold [9]+arrayTimeSelected [counter1*10+9];
                            calDataHold [10] = calDataHold [10]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                        }
                        else if (arrayTimeSelected [counter1*10+9] == 5 || arrayTimeSelected [counter1*10+9] == 6){
                            calDataHold [11] = calDataHold [11]+arrayGravityCenterRev [counter2*6+2];
                            calDataHold [12] = calDataHold [12]+arrayTimeSelected [counter1*10+9];
                            calDataHold [13] = calDataHold [13]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                        }
                        else if (arrayTimeSelected [counter1*10+9] == 7 || arrayTimeSelected [counter1*10+9] == 8){
                            calDataHold [14] = calDataHold [14]+arrayGravityCenterRev [counter2*6+2];
                            calDataHold [15] = calDataHold [15]+arrayTimeSelected [counter1*10+9];
                            calDataHold [16] = calDataHold [16]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                        }
                        else if (arrayTimeSelected [counter1*10+9] == 9 || arrayTimeSelected [counter1*10+9] == 10){
                            calDataHold [17] = calDataHold [17]+arrayGravityCenterRev [counter2*6+2];
                            calDataHold [18] = calDataHold [18]+arrayTimeSelected [counter1*10+9];
                            calDataHold [19] = calDataHold [19]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                        }
                        else if (arrayTimeSelected [counter1*10+9] == 11 || arrayTimeSelected [counter1*10+9] == 12){
                            calDataHold [20] = calDataHold [20]+arrayGravityCenterRev [counter2*6+2];
                            calDataHold [21] = calDataHold [21]+arrayTimeSelected [counter1*10+9];
                            calDataHold [22] = calDataHold [22]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                        }
                        else if (arrayTimeSelected [counter1*10+9] == 13 || arrayTimeSelected [counter1*10+9] == 14){
                            calDataHold [23] = calDataHold [23]+arrayGravityCenterRev [counter2*6+2];
                            calDataHold [24] = calDataHold [24]+arrayTimeSelected [counter1*10+9];
                            calDataHold [25] = calDataHold [25]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                        }
                        else if (arrayTimeSelected [counter1*10+9] == 15 || arrayTimeSelected [counter1*10+9] == 16){
                            calDataHold [26] = calDataHold [26]+arrayGravityCenterRev [counter2*6+2];
                            calDataHold [27] = calDataHold [27]+arrayTimeSelected [counter1*10+9];
                            calDataHold [28] = calDataHold [28]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                        }
                        else if (arrayTimeSelected [counter1*10+9] == 17 || arrayTimeSelected [counter1*10+9] == 18){
                            calDataHold [29] = calDataHold [29]+arrayGravityCenterRev [counter2*6+2];
                            calDataHold [30] = calDataHold [30]+arrayTimeSelected [counter1*10+9];
                            calDataHold [31] = calDataHold [31]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                        }
                        else if (arrayTimeSelected [counter1*10+9] == 19 || arrayTimeSelected [counter1*10+9] == 20){
                            calDataHold [32] = calDataHold [32]+arrayGravityCenterRev [counter2*6+2];
                            calDataHold [33] = calDataHold [33]+arrayTimeSelected [counter1*10+9];
                            calDataHold [34] = calDataHold [34]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                        }
                        else if (arrayTimeSelected [counter1*10+9] == 21 || arrayTimeSelected [counter1*10+9] == 22){
                            calDataHold [35] = calDataHold [35]+arrayGravityCenterRev [counter2*6+2];
                            calDataHold [36] = calDataHold [36]+arrayTimeSelected [counter1*10+9];
                            calDataHold [37] = calDataHold [37]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                        }
                        else if (arrayTimeSelected [counter1*10+9] >= 23){
                            calDataHold [38] = calDataHold [38]+arrayGravityCenterRev [counter2*6+2];
                            calDataHold [39] = calDataHold [39]+arrayTimeSelected [counter1*10+9];
                            calDataHold [40] = calDataHold [40]+arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                        }
                        
                        break;
                    }
                }
            }
        }
        
        ascIIstring = "Area";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        displayData2 = to_string(calDataHold [0]);
        displayData2 = displayData2.substr(0, displayData2.find("."));
        
        ascIIstring = displayData2;
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        double calcTemp = 0;
        
        baseData [0] = "N0";
        
        if (calDataHold [2] != 0) calcTemp = calDataHold [2];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [1] = displayData2.substr(0, displayData2.find("."));
        
        baseData [2] = "N1-2";
        
        if (calDataHold [6] != 0) calcTemp = calDataHold [5]/(double)calDataHold [6];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [3] = displayData2.substr(0, displayData2.find("."));
        
        baseData [4] = "N3-4";
        
        if (calDataHold [9] != 0) calcTemp = calDataHold [8]/(double)calDataHold [9];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [5] = displayData2.substr(0, displayData2.find("."));
        
        baseData [6] = "N5-6";
        
        if (calDataHold [12] != 0) calcTemp = calDataHold [11]/(double)calDataHold [12];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [7] = displayData2.substr(0, displayData2.find("."));
        
        baseData [8] = "N7-8";
        
        if (calDataHold [15] != 0) calcTemp = calDataHold [14]/(double)calDataHold [15];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [9] = displayData2.substr(0, displayData2.find("."));
        
        baseData [10] = "N9-10";
        
        if (calDataHold [18] != 0) calcTemp = calDataHold [17]/(double)calDataHold [18];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [11] = displayData2.substr(0, displayData2.find("."));
        
        baseData [12] = "N11-12";
        
        if (calDataHold [21] != 0) calcTemp = calDataHold [20]/(double)calDataHold [21];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [13] = displayData2.substr(0, displayData2.find("."));
        
        baseData [14] = "N13-14";
        
        if (calDataHold [24] != 0) calcTemp = calDataHold [23]/(double)calDataHold [24];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [15] = displayData2.substr(0, displayData2.find("."));
        
        baseData [16] = "N15-16";
        
        if (calDataHold [27] != 0) calcTemp = calDataHold [26]/(double)calDataHold [27];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [17] = displayData2.substr(0, displayData2.find("."));
        
        baseData [18] = "N17-18";
        
        if (calDataHold [30] != 0) calcTemp = calDataHold [29]/(double)calDataHold [30];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [19] = displayData2.substr(0, displayData2.find("."));
        
        baseData [20] = "N19-20";
        
        if (calDataHold [33] != 0) calcTemp = calDataHold [32]/(double)calDataHold [33];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [21] = displayData2.substr(0, displayData2.find("."));
        
        baseData [22] = "N21-22";
        
        if (calDataHold [36] != 0) calcTemp = calDataHold [35]/(double)calDataHold [36];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [23] = displayData2.substr(0, displayData2.find("."));
        
        baseData [24] = "N>=23";
        
        if (calDataHold [39] != 0) calcTemp = calDataHold [38]/(double)calDataHold [39];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [25] = displayData2.substr(0, displayData2.find("."));
        
        for (int counter2 = 0; counter2 < 13; counter2++){
            ascIIstring = baseData [counter2*2];
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = baseData [counter2*2+1];
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
        }
        
        oin.put(13);
        oin.put(10);
        
        ascIIstring = "Total per nucleus";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(13);
        oin.put(10);
        
        ascIIstring = "Total";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        displayData2 = to_string(calDataHold [1]);
        displayData2 = displayData2.substr(0, displayData2.find("."));
        
        ascIIstring = displayData2;
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        baseData [0] = "N0";
        
        if (calDataHold [4] != 0) calcTemp = calDataHold [4];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [1] = displayData2.substr(0, displayData2.find("."));
        
        baseData [2] = "N1-2";
        
        if (calDataHold [6] != 0) calcTemp = calDataHold [7]/(double)calDataHold [6];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [3] = displayData2.substr(0, displayData2.find("."));
        
        baseData [4] = "N3-4";
        
        if (calDataHold [9] != 0) calcTemp = calDataHold [10]/(double)calDataHold [9];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [5] = displayData2.substr(0, displayData2.find("."));
        
        baseData [6] = "N5-6";
        
        if (calDataHold [12] != 0) calcTemp = calDataHold [13]/(double)calDataHold [12];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [7] = displayData2.substr(0, displayData2.find("."));
        
        baseData [8] = "N7-8";
        
        if (calDataHold [15] != 0) calcTemp = calDataHold [16]/(double)calDataHold [15];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [9] = displayData2.substr(0, displayData2.find("."));
        
        baseData [10] = "N9-10";
        
        if (calDataHold [18] != 0) calcTemp = calDataHold [19]/(double)calDataHold [18];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [11] = displayData2.substr(0, displayData2.find("."));
        
        baseData [12] = "N11-12";
        
        if (calDataHold [21] != 0) calcTemp = calDataHold [22]/(double)calDataHold [21];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [13] = displayData2.substr(0, displayData2.find("."));
        
        baseData [14] = "N13-14";
        
        if (calDataHold [24] != 0) calcTemp = calDataHold [25]/(double)calDataHold [24];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [15] = displayData2.substr(0, displayData2.find("."));
        
        baseData [16] = "N15-16";
        
        if (calDataHold [27] != 0) calcTemp = calDataHold [28]/(double)calDataHold [27];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [17] = displayData2.substr(0, displayData2.find("."));
        
        baseData [18] = "N17-18";
        
        if (calDataHold [30] != 0) calcTemp = calDataHold [31]/(double)calDataHold [30];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [19] = displayData2.substr(0, displayData2.find("."));
        
        baseData [20] = "N19-20";
        
        if (calDataHold [33] != 0) calcTemp = calDataHold [34]/(double)calDataHold [33];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [21] = displayData2.substr(0, displayData2.find("."));
        
        baseData [22] = "N21-22";
        
        if (calDataHold [36] != 0) calcTemp = calDataHold [37]/(double)calDataHold [36];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [23] = displayData2.substr(0, displayData2.find("."));
        
        baseData [24] = "N>=23";
        
        if (calDataHold [39] != 0) calcTemp = calDataHold [40]/(double)calDataHold [39];
        else calcTemp = 0;
        
        displayData2 = to_string(calcTemp);
        baseData [25] = displayData2.substr(0, displayData2.find("."));
        
        for (int counter2 = 0; counter2 < 13; counter2++){
            ascIIstring = baseData [counter2*2];
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = baseData [counter2*2+1];
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
        }
        
        oin.put(13);
        oin.put(10);
        
        ascIIstring = "Individual data";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        ascIIstring = "Connect No";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "Area";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "Total";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "Average";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "No of nuclei";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
            if (arrayTimeSelected [counter1*10] == 1){
                for (int counter2 = 0; counter2 < gravityCenterRevCount/6; counter2++){
                    if (arrayGravityCenterRev [counter2*6+4] == arrayTimeSelected [counter1*10+8]){
                        displayData2 = to_string(arrayTimeSelected [counter1*10+8]);
                        ascIIstring = displayData2.substr(0, displayData2.find("."));
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        displayData2 = to_string(arrayGravityCenterRev [counter2*6+2]);
                        ascIIstring = displayData2.substr(0, displayData2.find("."));
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        calcTemp = arrayGravityCenterRev [counter2*6+2]*arrayGravityCenterRev [counter2*6+3];
                        
                        displayData2 = to_string(calcTemp);
                        ascIIstring = displayData2.substr(0, displayData2.find("."));
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        displayData2 = to_string(arrayGravityCenterRev [counter2*6+3]);
                        ascIIstring = displayData2.substr(0, displayData2.find("."));
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        ascIIstring = to_string(arrayTimeSelected [counter1*10+9]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        oin.put(13);
                        oin.put(10);
                        
                        break;
                    }
                }
            }
        }
        
        delete [] calDataHold;
        delete [] baseData;
        
        int *dotDataTemp = new int [dotDataHoldCount*2+10];
        int dotDataTempCount = 0;
        int *dotDataTemp2 = new int [dotDataHoldCount*2+10];
        int dotDataTempCount2 = 0;
        
        int terminationFlag = 0;
        int dotTimeHold = 0;
        int dotTimePosition = 0;
        
        for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
            dotDataTemp [dotDataTempCount] = arrayDotDataHold [counter1*3], dotDataTempCount++;
            dotDataTemp [dotDataTempCount] = arrayDotDataHold [counter1*3+1], dotDataTempCount++;
            dotDataTemp [dotDataTempCount] = arrayDotDataHold [counter1*3+2], dotDataTempCount++;
            
            if (arrayDotDataHold [counter1*3] < -100000) dotDataTemp [dotDataTempCount] = arrayDotDataHold [counter1*3]*-1-100000, dotDataTempCount++;
            else if (arrayDotDataHold [counter1*3] >= -100000 && arrayDotDataHold [counter1*3] < 0) dotDataTemp [dotDataTempCount] = arrayDotDataHold [counter1*3]*-1, dotDataTempCount++;
            else if (arrayDotDataHold [counter1*3] >= 0 && arrayDotDataHold [counter1*3] <= 100000) dotDataTemp [dotDataTempCount] = arrayDotDataHold [counter1*3], dotDataTempCount++;
            else if (arrayDotDataHold [counter1*3] > 100000) dotDataTemp [dotDataTempCount] = arrayDotDataHold [counter1*3]-100000, dotDataTempCount++;
        }
        
        do{
            
            terminationFlag = 1;
            dotTimePosition = -1;
            dotTimeHold = 10000000;
            
            for (int counter1 = 0; counter1 < dotDataTempCount/4; counter1++){
                if (dotDataTemp [counter1*4+3] < dotTimeHold && dotDataTemp [counter1*4+3] != 0){
                    dotTimeHold = dotDataTemp [counter1*4+3];
                    dotTimePosition = counter1;
                }
            }
            
            if (dotTimePosition != -1){
                dotDataTemp2 [dotDataTempCount2] = dotDataTemp [dotTimePosition*4], dotDataTempCount2++;
                dotDataTemp2 [dotDataTempCount2] = dotDataTemp [dotTimePosition*4+1], dotDataTempCount2++;
                dotDataTemp2 [dotDataTempCount2] = dotDataTemp [dotTimePosition*4+2], dotDataTempCount2++;
                dotDataTemp2 [dotDataTempCount2] = dotDataTemp [dotTimePosition*4+3], dotDataTempCount2++;
                
                dotDataTemp [dotTimePosition*4+3] = 0;
            }
            else terminationFlag = 0;
            
        } while (terminationFlag == 1);
        
        delete [] dotDataTemp;
        
        int *dotDataTemp3 = new int [dotDataTempCount2*2+10];
        int dotDataTempCount3 = 0;
        
        int matchPoint = 0;
        
        for (int counter1 = 0; counter1 < dotDataTempCount2/4; counter1++){
            matchPoint = -1;
            
            for (int counter2 = 0; counter2 < dotDataTempCount3/3; counter2++){
                if (dotDataTemp3 [counter2*3] == dotDataTemp2 [counter1*4+3]){
                    matchPoint = counter2;
                    break;
                }
            }
            
            if (matchPoint != -1){
                if (dotDataTemp2 [counter1*4] < 0) dotDataTemp3 [matchPoint*3+2]++;
                else if (dotDataTemp2 [counter1*4] > 0) dotDataTemp3 [matchPoint*3+1]++;
            }
            else{
                
                dotDataTemp3 [dotDataTempCount3] = dotDataTemp2 [counter1*4+3], dotDataTempCount3++;
                dotDataTemp3 [dotDataTempCount3] = 0, dotDataTempCount3++;
                dotDataTemp3 [dotDataTempCount3] = 0, dotDataTempCount3++;
                
                if (dotDataTemp2 [counter1*4] < 0) dotDataTemp3 [dotDataTempCount3-1]++;
                else if (dotDataTemp2 [counter1*4] > 0) dotDataTemp3 [dotDataTempCount3-2]++;
            }
        }
        
        oin.put(13);
        oin.put(10);
        
        ascIIstring = "DotData each time point";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(13);
        oin.put(10);
        
        ascIIstring = "Time point";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "No First";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "No Second";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        for (int counter1 = 0; counter1 < dotDataTempCount3/3; counter1++){
            ascIIstring = to_string(dotDataTemp3 [counter1*3]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = to_string(dotDataTemp3 [counter1*3+1]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = to_string(dotDataTemp3 [counter1*3+2]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
        }
        
        oin.put(13);
        oin.put(10);
        
        ascIIstring = "DotData Total";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(13);
        oin.put(10);
        
        ascIIstring = "No First";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "No Second";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        int firstTotal = 0;
        int secondTotal = 0;
        
        for (int counter1 = 0; counter1 < dotDataTempCount3/3; counter1++){
            firstTotal = firstTotal+dotDataTemp3 [counter1*3+1];
            secondTotal = secondTotal+dotDataTemp3 [counter1*3+2];
        }
        
        oin.put(13);
        oin.put(10);
        
        ascIIstring = to_string(firstTotal);
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = to_string(secondTotal);
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        delete [] dotDataTemp3;
        
        if (gridStatusHold == 1){
            int dimension = (int)(imageXYLength/(double)gridDimHold);
            
            int **dimensionDataHold = new int *[gridDimHold+1];
            int dimensionDataHoldCount = 0;
            
            for (int counter1 = 0; counter1 < gridDimHold+1; counter1++){
                dimensionDataHold [counter1] = new int [(dotDataTempCount2/4)*3+1];
            }
            
            for (int counter2 = 0; counter2 < gridDimHold+1; counter2++){
                for (int counter3 = 0; counter3 < (dotDataTempCount2/4)*3+1; counter3++){
                    dimensionDataHold [counter2][counter3] = 0;
                }
            }
            
            for (int counter1 = 0; counter1 < dotDataTempCount2/4; counter1++){
                matchPoint = -1;
                
                for (int counter2 = 0; counter2 < dimensionDataHoldCount/3; counter2++){
                    if (dimensionDataHold [0][counter2*3] == dotDataTemp2 [counter1*4+3]){
                        matchPoint = counter1;
                        break;
                    }
                }
                
                if (matchPoint == -1){
                    dimensionDataHold [0][dimensionDataHoldCount] = dotDataTemp2 [counter1*4+3], dimensionDataHoldCount++;
                    dimensionDataHold [0][dimensionDataHoldCount] = 0, dimensionDataHoldCount++;
                    dimensionDataHold [0][dimensionDataHoldCount] = 0, dimensionDataHoldCount++;
                }
            }
            
            int *totalHold = new int [gridDimHold*2+1];
            
            for (int counter2 = 1; counter2 < gridDimHold; counter2++){
                for (int counter3 = 0; counter3 < dimensionDataHoldCount/3; counter3++){
                    dimensionDataHold [counter2][counter3*3] = dimensionDataHold [0][counter3*3];
                }
            }
            
            oin.put(13);
            oin.put(10);
            
            ascIIstring = "DotData Dimension";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
            
            oin.put(13);
            oin.put(10);
            
            int rangeXLow = 0;
            int rangeXHigh = dimension;
            int rangeYLow = 0;
            int rangeYHigh = dimension;
            
            for (int counter1 = 0; counter1 < gridDimHold; counter1++){
                for (int counter2 = 0; counter2 < gridDimHold; counter2++){
                    for (int counter3 = 0; counter3 < dimensionDataHoldCount/3; counter3++){
                        dimensionDataHold [counter2][counter3*3+1] = 0;
                        dimensionDataHold [counter2][counter3*3+2] = 0;
                    }
                }
                
                for (int counter2 = 0; counter2 < gridDimHold*2; counter2++) totalHold [counter2] = 0;
                
                for (int counter2 = 0; counter2 < gridDimHold; counter2++){
                    for (int counter3 = 0; counter3 < dotDataTempCount2/4; counter3++){
                        if (dotDataTemp2 [counter3*4+1] >= rangeXLow && dotDataTemp2 [counter3*4+1] < rangeXHigh && dotDataTemp2 [counter3*4+2] >= rangeYLow && dotDataTemp2 [counter3*4+2] < rangeYHigh){
                            for (int counter4 = 0; counter4 < dimensionDataHoldCount/3; counter4++){
                                if (dimensionDataHold [counter2][counter4*3] == dotDataTemp2 [counter3*4+3]){
                                    if (dotDataTemp2 [counter3*4] < 0) dimensionDataHold [counter2][counter4*3+2]++;
                                    else if (dotDataTemp2 [counter3*4] > 0) dimensionDataHold [counter2][counter4*3+1]++;
                                    
                                    break;
                                }
                            }
                        }
                    }
                    
                    rangeXLow = rangeXLow+dimension;
                    rangeXHigh = rangeXHigh+dimension;
                    
                    if (counter2 == gridDimHold-1){
                        rangeXHigh = imageXYLength+1;
                    }
                }
                
                for (int counter2 = 0; counter2 < gridDimHold; counter2++){
                    for (int counter3 = 0; counter3 < dimensionDataHoldCount/3; counter3++){
                        totalHold [counter2*2] = totalHold [counter2*2]+dimensionDataHold [counter2][counter3*3+1];
                        totalHold [counter2*2+1] = totalHold [counter2*2+1]+dimensionDataHold [counter2][counter3*3+2];
                    }
                }
                
                ascIIstring = "Row"+to_string(counter1+1);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(13);
                oin.put(10);
                
                ascIIstring = "Time point";
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                for (int counter2 = 0; counter2 < gridDimHold; counter2++){
                    ascIIstring = "CL"+to_string(counter2+1)+"-No First";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = "CL"+to_string(counter2+1)+"-No Second";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                }
                
                oin.put(13);
                oin.put(10);
                
                for (int counter2 = 0; counter2 < dimensionDataHoldCount/3; counter2++){
                    for (int counter3 = 0; counter3 < gridDimHold; counter3++){
                        if (counter3 == 0){
                            ascIIstring = to_string(dimensionDataHold [counter3][counter2*3]);
                            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                            
                            oin.put(9);
                        }
                        
                        ascIIstring = to_string(dimensionDataHold [counter3][counter2*3+1]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                        
                        ascIIstring = to_string(dimensionDataHold [counter3][counter2*3+2]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                }
                
                ascIIstring = "Total";
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                for (int counter2 = 0; counter2 < gridDimHold; counter2++){
                    ascIIstring = to_string(totalHold [counter2*2]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(totalHold [counter2*2+1]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                    
                    oin.put(9);
                }
                
                oin.put(13);
                oin.put(10);
                
                rangeYLow = rangeYLow+dimension;
                rangeYHigh = rangeYHigh+dimension;
                
                rangeXLow = 0;
                rangeXHigh = dimension;
                
                if (counter1 == gridDimHold-1){
                    rangeYHigh = imageXYLength+1;
                }
                
                oin.put(13);
                oin.put(10);
            }
            
            for (int counter1 = 0; counter1 < gridDimHold; counter1++){
                delete [] dimensionDataHold [counter1];
            }
            
            delete [] dimensionDataHold;
            
            delete [] totalHold;
        }
        
        oin.put(13);
        oin.put(10);
        
        ascIIstring = "DotData XY position";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(13);
        oin.put(10);
        
        ascIIstring = "Time";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "Xposition";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "Yposition";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(13);
        oin.put(10);
        
        ascIIstring = "First";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
            if (arrayDotDataHold [counter1*3] >= 0 && arrayDotDataHold [counter1*3] <= 100000){
                ascIIstring = to_string(arrayDotDataHold [counter1*3]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                ascIIstring = to_string(arrayDotDataHold [counter1*3+1]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                ascIIstring = to_string(arrayDotDataHold [counter1*3+2]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                oin.put(13);
                oin.put(10);
            }
        }
        
        oin.put(13);
        oin.put(10);
        
        ascIIstring = "Second";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
            if (arrayDotDataHold [counter1*3] < 0 && arrayDotDataHold [counter1*3] >= -100000){
                ascIIstring = to_string(arrayDotDataHold [counter1*3]*-1);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                ascIIstring = to_string(arrayDotDataHold [counter1*3+1]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                ascIIstring = to_string(arrayDotDataHold [counter1*3+2]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                oin.put(13);
                oin.put(10);
            }
        }
        
        ascIIstring = "Third";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
            if (arrayDotDataHold [counter1*3] > 100000){
                ascIIstring = to_string(arrayDotDataHold [counter1*3]-100000);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                ascIIstring = to_string(arrayDotDataHold [counter1*3+1]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                ascIIstring = to_string(arrayDotDataHold [counter1*3+2]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                oin.put(13);
                oin.put(10);
            }
        }
        
        ascIIstring = "Fourth";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
            if (arrayDotDataHold [counter1*3] < -100000){
                ascIIstring = to_string(arrayDotDataHold [counter1*3]*-1-100000);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                ascIIstring = to_string(arrayDotDataHold [counter1*3+1]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                ascIIstring = to_string(arrayDotDataHold [counter1*3+2]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                oin.put(13);
                oin.put(10);
            }
        }
        
        delete [] dotDataTemp2;
        delete [] arrayAscIIintData;
        
        oin.close();
        
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Data Missing or Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lineSelect:(id)sender{
    if (initialArraySet == 1 && timePointHold >= 1 && imageProgressFlag == 0){
        if (areaModeStatusHold == 1){
            if (lineDraw == 0){
                lineDraw = 1;
                windowLock = 1;
            }
            else if (lineDraw == 1){
                lineDraw = 0;
                windowLock = 0;
            }
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Area Mode Off"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing or Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lineSet:(id)sender{
    if (initialArraySet == 1 && timePointHold >= 1 && imageProgressFlag == 0){
        int processType = 1;
        lineSet = [[LineSet alloc] init];
        [lineSet lineSetProcess:processType];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing or Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)charDisplaySet:(id)sender{
    if (areaModeStatusHold == 1){
        if (charDisplayFlag == 0){
            charDisplayFlag = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (charDisplayFlag == 1){
            charDisplayFlag = 0;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Area mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)reviseLineDone:(id)sender{
    if (initialArraySet == 1 && timePointHold >= 1 && imageProgressFlag == 0){
        if (lineDraw == 1){
            lineDraw = 0;
            windowLock = 0;
        }
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing or Other processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)saveAreaData:(id)sender{
    if (initialArraySet == 1 && timePointHold >= 1 && imageProgressFlag == 0 &&  areaModeStatusHold == 1){
        trackingDataSave = [[TrackingDataSave alloc] init];
        [trackingDataSave trackingDataSaveTemp:timePointHold];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing or Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cleaningDataBase:(id)sender{
    if (areaModeStatusHold == 1 && imageProgressFlag == 0){
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
            imageProgressFlag = 1;
            int maxConnectNo = gravityCenterRevCount/6;
            
            int *lineageNoRef = new int [maxConnectNo*4+10];
            
            for (int counter2 = 0; counter2 <= maxConnectNo; counter2++){
                lineageNoRef [counter2*4] = counter2;
                lineageNoRef [counter2*4+1] = 0;
                lineageNoRef [counter2*4+2] = 0;
                lineageNoRef [counter2*4+3] = 0;
            }
            
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                if (arrayTimeSelected [counter1*10] == 0 || arrayTimeSelected [counter1*10] == 2){
                    lineageNoRef [(counter1+1)*4+1] = 1;
                }
                else if (arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7){
                    lineageNoRef [(counter1+1)*4+1] = 2;
                }
                else if (arrayTimeSelected [counter1*10] == 10){
                    lineageNoRef [(counter1+1)*4+1] = 3;
                }
                else if (arrayTimeSelected [counter1*10] == 11){
                    lineageNoRef [(counter1+1)*4+1] = 4;
                }
            }
            
            for (int counterY = 0; counterY < imageXYLength; counterY++){
                for (int counterX = 0; counterX < imageXYLength; counterX++){
                    if (revisedWorkingMap [counterY][counterX] != 0){
                        lineageNoRef [revisedWorkingMap [counterY][counterX]*4+3] = 1;
                    }
                }
            }
            
            for (int counter2 = 1; counter2 <= maxConnectNo; counter2++){
                if (lineageNoRef [counter2*4+1] != 0 && lineageNoRef [counter2*4+3] == 0){
                    lineageNoRef [counter2*4+1] = 0;
                    lineageNoRef [counter2*4+3] = 2;
                }
            }
            
            //for (int counterA = 1; counterA <= maxConnectNo; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<lineageNoRef [counterA*4+counterB];
            //    cout<<" lineageNoRef "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                if (lineageNoRef [arrayPositionRevise [counter1*7+3]*4+3] == 2){
                    arrayPositionRevise [counter1*7+5] = 3;
                }
            }
            
            int newConnectNo = 1;
            
            for (int counter2 = 1; counter2 <= maxConnectNo; counter2++){
                if (lineageNoRef [counter2*4+1] != 0){
                    lineageNoRef [counter2*4+2] = newConnectNo;
                    newConnectNo++;
                }
            }
            
            //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
            //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
            //    cout<<" arrayTimeSelected "<<counterA<<endl;
            //}
            
            int *arrayTimeSelectedTemp = new int [timeSelectedCount+10];
            int timeSelectedTempCount = 0;
            
            for (int counter1 = 1; counter1 <= maxConnectNo; counter1++){
                if (lineageNoRef [counter1*4+1] != 0){
                    for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                        if (lineageNoRef [counter1*4] == arrayTimeSelected [counter2*10+8]){
                            arrayTimeSelectedTemp [timeSelectedTempCount] = arrayTimeSelected [counter2*10], timeSelectedTempCount++; //------Selected, removed, eliminated status------
                            arrayTimeSelectedTemp [timeSelectedTempCount] = arrayTimeSelected [counter2*10+1], timeSelectedTempCount++; //------When new line is created, enter line number which creates------
                            arrayTimeSelectedTemp [timeSelectedTempCount] = 0, timeSelectedTempCount++; //------PositionRevise Start------
                            arrayTimeSelectedTemp [timeSelectedTempCount] = arrayTimeSelected [counter2*10+3], timeSelectedTempCount++; //------Cut line number------
                            arrayTimeSelectedTemp [timeSelectedTempCount] = arrayTimeSelected [counter2*10+4], timeSelectedTempCount++; //------X Start------
                            arrayTimeSelectedTemp [timeSelectedTempCount] = arrayTimeSelected [counter2*10+5], timeSelectedTempCount++; //------X End------
                            arrayTimeSelectedTemp [timeSelectedTempCount] = arrayTimeSelected [counter2*10+6], timeSelectedTempCount++; //------Y Start------
                            arrayTimeSelectedTemp [timeSelectedTempCount] = arrayTimeSelected [counter2*10+7], timeSelectedTempCount++; //------Y End------
                            arrayTimeSelectedTemp [timeSelectedTempCount] = lineageNoRef [counter1*4+2], timeSelectedTempCount++; //------Connect------
                            arrayTimeSelectedTemp [timeSelectedTempCount] = arrayTimeSelected [counter2*10+9], timeSelectedTempCount++; //------Lineage------
                            break;
                        }
                    }
                }
            }
            
            timeSelectedCount = 0;
            
            for (int counter1 = 0; counter1 < timeSelectedTempCount; counter1++) arrayTimeSelected [timeSelectedCount] = arrayTimeSelectedTemp [counter1], timeSelectedCount++;
            
            //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
            //    cout<<" arrayGravityCenterRev "<<counterA<<endl;
            //}
            
            int *arrayGravityCenterTemp = new int [gravityCenterRevCount+10];
            int gravityCenterTempCount = 0;
            
            for (int counter1 = 1; counter1 <= maxConnectNo; counter1++){
                if (lineageNoRef [counter1*4+1] != 0){
                    for (int counter2 = 0; counter2 < gravityCenterRevCount/6; counter2++){
                        if (lineageNoRef [counter1*4] == arrayGravityCenterRev [counter2*6+4]){
                            arrayGravityCenterTemp [gravityCenterTempCount] = arrayGravityCenterRev [counter2*6], gravityCenterTempCount++;
                            arrayGravityCenterTemp [gravityCenterTempCount] = arrayGravityCenterRev [counter2*6+1], gravityCenterTempCount++;
                            arrayGravityCenterTemp [gravityCenterTempCount] = arrayGravityCenterRev [counter2*6+2], gravityCenterTempCount++;
                            arrayGravityCenterTemp [gravityCenterTempCount] = arrayGravityCenterRev [counter2*6+3], gravityCenterTempCount++;
                            arrayGravityCenterTemp [gravityCenterTempCount] = lineageNoRef [counter1*4+2], gravityCenterTempCount++;
                            arrayGravityCenterTemp [gravityCenterTempCount] = arrayGravityCenterRev [counter2*6+5], gravityCenterTempCount++;
                            break;
                        }
                    }
                }
            }
            
            gravityCenterRevCount = 0;
            
            for (int counter1 = 0; counter1 < gravityCenterTempCount; counter1++) arrayGravityCenterRev [gravityCenterRevCount] = arrayGravityCenterTemp [counter1], gravityCenterRevCount++;
            
            int *arrayPositionReviseCountTemp = new int [positionReviseCount+10];
            int positionReviseTempCount = 0;
            
            //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
            //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
            //    cout<<" arrayPositionRevise "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                if (arrayPositionRevise [counter1*7+5] == 0 || arrayPositionRevise [counter1*7+5] == 1){
                    arrayPositionReviseCountTemp [positionReviseTempCount] = arrayPositionRevise [counter1*7], positionReviseTempCount++;
                    arrayPositionReviseCountTemp [positionReviseTempCount] = arrayPositionRevise [counter1*7+1], positionReviseTempCount++;
                    arrayPositionReviseCountTemp [positionReviseTempCount] = arrayPositionRevise [counter1*7+2], positionReviseTempCount++;
                    arrayPositionReviseCountTemp [positionReviseTempCount] = lineageNoRef [arrayPositionRevise [counter1*7+3]*4+2], positionReviseTempCount++;
                    arrayPositionReviseCountTemp [positionReviseTempCount] = arrayPositionRevise [counter1*7+4], positionReviseTempCount++;
                    
                    if (lineageNoRef [arrayPositionRevise [counter1*7+3]*4+1] == 1){
                        arrayPositionReviseCountTemp [positionReviseTempCount] = 0, positionReviseTempCount++;
                    }
                    else if (lineageNoRef [arrayPositionRevise [counter1*7+3]*4+1] == 2){
                        arrayPositionReviseCountTemp [positionReviseTempCount] = 1, positionReviseTempCount++;
                    }
                    else if (lineageNoRef [arrayPositionRevise [counter1*7+3]*4+1] == 3){
                        arrayPositionReviseCountTemp [positionReviseTempCount] = 1, positionReviseTempCount++;
                    }
                    else if (lineageNoRef [arrayPositionRevise [counter1*7+3]*4+1] == 4){
                        arrayPositionReviseCountTemp [positionReviseTempCount] = 1, positionReviseTempCount++;
                    }
                    else if (lineageNoRef [arrayPositionRevise [counter1*7+3]*4+1] == 0){
                        arrayPositionReviseCountTemp [positionReviseTempCount] = 3, positionReviseTempCount++;
                    }
                    
                    arrayPositionReviseCountTemp [positionReviseTempCount] = arrayPositionRevise [counter1*7+6], positionReviseTempCount++;
                }
            }
            
            positionReviseCount = 0;
            
            for (int counter1 = 0; counter1 < positionReviseTempCount; counter1++) arrayPositionRevise [positionReviseCount] = arrayPositionReviseCountTemp [counter1], positionReviseCount++;
            
            int valueTemp = 0;
            
            for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                if (arrayPositionRevise [counter1*7+3] != valueTemp){
                    valueTemp = arrayPositionRevise [counter1*7+3];
                    arrayTimeSelected [(valueTemp-1)*10+2] = counter1;
                    
                    if (arrayPositionRevise [counter1*7+5] == 0){
                        arrayTimeSelected [(valueTemp-1)*10] = 0;
                    }
                }
            }
            
            for (int counterY = 0; counterY < imageXYLength; counterY++){
                for (int counterX = 0; counterX < imageXYLength; counterX++){
                    if (revisedWorkingMap [counterY][counterX] != 0){
                        revisedWorkingMap [counterY][counterX] = lineageNoRef [revisedWorkingMap [counterY][counterX]*4+2];
                    }
                }
            }
            
            delete [] lineageNoRef;
            delete [] arrayTimeSelectedTemp;
            delete [] arrayGravityCenterTemp;
            delete [] arrayPositionReviseCountTemp;
            
            string extension = to_string(timePointHold);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            string connectDataRevPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_MasterData";
            
            int dataTemp = 0;
            
            if (positionReviseCount != 0){
                int readBit [4];
                long indexCount = 0;
                
                char *writingArray = new char [(positionReviseCount/7+gravityCenterRevCount/6)*17+50];
                
                for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                    dataTemp = arrayPositionRevise [counter1*7];
                    readBit [0] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [1] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    
                    dataTemp = arrayPositionRevise [counter1*7+1];
                    readBit [0] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [1] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    
                    writingArray [indexCount] = (char)arrayPositionRevise [counter1*7+2], indexCount++;
                    
                    dataTemp = arrayPositionRevise [counter1*7+3];
                    readBit [0] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [1] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [2] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                    
                    dataTemp = arrayPositionRevise [counter1*7+4];
                    
                    if (dataTemp < 0) dataTemp = dataTemp*-1, writingArray [indexCount] = 1, indexCount++;
                    else writingArray [indexCount] = 0, indexCount++;
                    
                    readBit [0] = dataTemp/16777216;
                    dataTemp = dataTemp%16777216;
                    readBit [1] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [2] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [3] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                    writingArray [indexCount] = (char)readBit [3], indexCount++;
                    
                    writingArray [indexCount] = (char)arrayPositionRevise [counter1*7+5], indexCount++;
                    
                    dataTemp = arrayPositionRevise [counter1*7+6];
                    readBit [0] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [1] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [2] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                }
                
                for (int counter1 = 0; counter1 < 17; counter1++) writingArray [indexCount] = 0, indexCount++;
                
                for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                    dataTemp = arrayGravityCenterRev [counter1*6];
                    readBit [0] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [1] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    
                    dataTemp = arrayGravityCenterRev [counter1*6+1];
                    readBit [0] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [1] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    
                    dataTemp = arrayGravityCenterRev [counter1*6+2];
                    readBit [0] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [1] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [2] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                    
                    writingArray [indexCount] = (char)arrayGravityCenterRev [counter1*6+3], indexCount++;
                    
                    dataTemp = arrayGravityCenterRev [counter1*6+4];
                    readBit [0] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [1] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [2] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                    
                    writingArray [indexCount] = (char)arrayGravityCenterRev [counter1*6+5], indexCount++;
                }
                
                for (int counter1 = 0; counter1 < 11; counter1++) writingArray [indexCount] = 0, indexCount++;
                
                ofstream outfile (connectDataRevPath.c_str(), ofstream::binary);
                outfile.write ((char*)writingArray, indexCount);
                outfile.close();
                
                delete [] writingArray;
            }
            
            string connectStatusDataPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_Status";
            
            if (timeSelectedCount != 0){
                char *writingArray = new char [timeSelectedCount/10*19+20];
                
                long indexCount = 0;
                int readBit [3];
                int connectNumberTemp = 0;
                
                for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                    writingArray [indexCount] = (char)arrayTimeSelected [counter1*10], indexCount++;
                    writingArray [indexCount] = 0, indexCount++;
                    writingArray [indexCount] = 0, indexCount++;
                    writingArray [indexCount] = 0, indexCount++;
                    
                    dataTemp = arrayTimeSelected [counter1*10+2];
                    readBit [0] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [1] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [2] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                    
                    writingArray [indexCount] = 0, indexCount++;
                    writingArray [indexCount] = 0, indexCount++;
                    
                    writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+4], indexCount++;
                    writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+5], indexCount++;
                    writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+6], indexCount++;
                    writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+7], indexCount++;
                    
                    dataTemp = arrayTimeSelected [counter1*10+8];
                    readBit [0] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [1] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [2] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                    
                    if (arrayTimeSelected [counter1*10] == 3 || arrayTimeSelected [counter1*10] == 4) connectNumberTemp = 0;
                    else connectNumberTemp = arrayTimeSelected [counter1*10+9];
                    
                    dataTemp = connectNumberTemp;
                    readBit [0] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [1] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [2] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                }
                
                for (int counter1 = 0; counter1 < 19; counter1++) writingArray [indexCount] = 0, indexCount++;
                
                ofstream outfile2 (connectStatusDataPath.c_str(), ofstream::binary);
                outfile2.write ((char*) writingArray, indexCount);
                outfile2.close();
                
                delete [] writingArray;
            }
            
            string revisedMapPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_RevisedMap";
            
            if (imageXYLength != 0){
                int totalMapSizeTemp = imageXYLength*imageXYLength*4+1;
                
                char *dataHold = new char [totalMapSizeTemp];
                int indexCount = 0;
                int dataTemp2 = 0;
                int entryCount = 0;
                int readBit [4];
                
                for (int counterX = 0; counterX < imageXYLength; counterX++){
                    for (int counterY = 0; counterY < imageXYLength; counterY++){
                        dataTemp = revisedWorkingMap [counterX][counterY];
                        
                        if (counterY == 0) dataTemp2 = dataTemp, entryCount++;
                        else if (dataTemp != dataTemp2 || entryCount == 254 || counterY == imageXYLength-1){
                            readBit [0] = dataTemp2/65536;
                            dataTemp2 = dataTemp2%65536;
                            readBit [1] = dataTemp2/256;
                            dataTemp2 = dataTemp2%256;
                            readBit [2] = dataTemp2;
                            
                            if (counterY == imageXYLength-1){
                                if (dataTemp != dataTemp2){
                                    dataHold [indexCount] = (char)readBit [0], indexCount++;
                                    dataHold [indexCount] = (char)readBit [1], indexCount++;
                                    dataHold [indexCount] = (char)readBit [2], indexCount++;
                                    dataHold [indexCount] = (char)entryCount, indexCount++;
                                    
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    entryCount = 1;
                                    
                                    dataHold [indexCount] = (char)readBit [0], indexCount++;
                                    dataHold [indexCount] = (char)readBit [1], indexCount++;
                                    dataHold [indexCount] = (char)readBit [2], indexCount++;
                                    dataHold [indexCount] = (char)entryCount, indexCount++;
                                }
                                else{
                                    
                                    entryCount++;
                                    
                                    dataHold [indexCount] = (char)readBit [0], indexCount++;
                                    dataHold [indexCount] = (char)readBit [1], indexCount++;
                                    dataHold [indexCount] = (char)readBit [2], indexCount++;
                                    dataHold [indexCount] = (char)entryCount, indexCount++;
                                }
                            }
                            else{
                                
                                dataHold [indexCount] = (char)readBit [0], indexCount++;
                                dataHold [indexCount] = (char)readBit [1], indexCount++;
                                dataHold [indexCount] = (char)readBit [2], indexCount++;
                                dataHold [indexCount] = (char)entryCount, indexCount++;
                            }
                            
                            if (counterY == imageXYLength-1) entryCount = 0;
                            else entryCount = 1, dataTemp2 = dataTemp;
                        }
                        else entryCount++;
                    }
                }
                
                ofstream outfile2 (revisedMapPath.c_str(), ofstream::binary);
                outfile2.write(dataHold, indexCount);
                outfile2.close();
                
                delete [] dataHold;
            }
            
            imageProgressFlag = 0;
            warningSet = 3;
        });
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Area Mode Off or Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)removeNonSelectDataBase:(id)sender{
    if (areaModeStatusHold == 1 && imageProgressFlag == 0){
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
            imageProgressFlag = 1;
            int maxConnectNo = gravityCenterRevCount/6;
            
            int *lineageNoRef = new int [maxConnectNo*4+10];
            
            for (int counter2 = 0; counter2 <= maxConnectNo; counter2++){
                lineageNoRef [counter2*4] = counter2;
                lineageNoRef [counter2*4+1] = 0;
                lineageNoRef [counter2*4+2] = 0;
                lineageNoRef [counter2*4+3] = 0;
            }
            
            //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
            //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
            //    cout<<" arrayTimeSelected "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                if (arrayTimeSelected [counter1*10] == 0 || arrayTimeSelected [counter1*10] == 2){
                    lineageNoRef [(counter1+1)*4+1] = 1;
                }
                else if (arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7){
                    lineageNoRef [(counter1+1)*4+1] = 2;
                }
                else if (arrayTimeSelected [counter1*10] == 10){
                    lineageNoRef [(counter1+1)*4+1] = 3;
                }
                else if (arrayTimeSelected [counter1*10] == 11){
                    lineageNoRef [(counter1+1)*4+1] = 4;
                }
            }
            
            for (int counterY = 0; counterY < imageXYLength; counterY++){
                for (int counterX = 0; counterX < imageXYLength; counterX++){
                    if (revisedWorkingMap [counterY][counterX] != 0){
                        lineageNoRef [revisedWorkingMap [counterY][counterX]*4+3] = 1;
                    }
                }
            }
            
            for (int counter2 = 1; counter2 <= maxConnectNo; counter2++){
                if (lineageNoRef [counter2*4+1] != 0 && lineageNoRef [counter2*4+3] == 0){
                    lineageNoRef [counter2*4+1] = 0;
                    lineageNoRef [counter2*4+3] = 2;
                }
                
                if (lineageNoRef [counter2*4+1] == 1){
                    lineageNoRef [counter2*4+1] = 0;
                    lineageNoRef [counter2*4+3] = 2;
                }
            }
            
            for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                if (lineageNoRef [arrayPositionRevise [counter1*7+3]*4+3] == 2){
                    arrayPositionRevise [counter1*7+5] = 3;
                }
            }
            
            int newConnectNo = 1;
            
            for (int counter2 = 1; counter2 <= maxConnectNo; counter2++){
                if (lineageNoRef [counter2*4+1] != 0){
                    lineageNoRef [counter2*4+2] = newConnectNo;
                    newConnectNo++;
                }
            }
            
            //for (int counterA = 1; counterA <= maxConnectNo; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<lineageNoRef [counterA*4+counterB];
            //    cout<<" lineageNoRef "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
            //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
            //    cout<<" arrayTimeSelected "<<counterA<<endl;
            //}
            
            int *arrayTimeSelectedTemp = new int [timeSelectedCount+10];
            int timeSelectedTempCount = 0;
            
            for (int counter1 = 1; counter1 <= maxConnectNo; counter1++){
                if (lineageNoRef [counter1*4+1] != 0){
                    for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                        if (lineageNoRef [counter1*4] == arrayTimeSelected [counter2*10+8]){
                            arrayTimeSelectedTemp [timeSelectedTempCount] = arrayTimeSelected [counter2*10], timeSelectedTempCount++; //------Selected, removed, eliminated status------
                            arrayTimeSelectedTemp [timeSelectedTempCount] = arrayTimeSelected [counter2*10+1], timeSelectedTempCount++; //------When new line is created, enter line number which creates------
                            arrayTimeSelectedTemp [timeSelectedTempCount] = 0, timeSelectedTempCount++; //------PositionRevise Start------
                            arrayTimeSelectedTemp [timeSelectedTempCount] = arrayTimeSelected [counter2*10+3], timeSelectedTempCount++; //------Cut line number------
                            arrayTimeSelectedTemp [timeSelectedTempCount] = arrayTimeSelected [counter2*10+4], timeSelectedTempCount++; //------X Start------
                            arrayTimeSelectedTemp [timeSelectedTempCount] = arrayTimeSelected [counter2*10+5], timeSelectedTempCount++; //------X End------
                            arrayTimeSelectedTemp [timeSelectedTempCount] = arrayTimeSelected [counter2*10+6], timeSelectedTempCount++; //------Y Start------
                            arrayTimeSelectedTemp [timeSelectedTempCount] = arrayTimeSelected [counter2*10+7], timeSelectedTempCount++; //------Y End------
                            arrayTimeSelectedTemp [timeSelectedTempCount] = lineageNoRef [counter1*4+2], timeSelectedTempCount++; //------Connect------
                            arrayTimeSelectedTemp [timeSelectedTempCount] = arrayTimeSelected [counter2*10+9], timeSelectedTempCount++; //------Lineage------
                            break;
                        }
                    }
                }
            }
            
            timeSelectedCount = 0;
            
            for (int counter1 = 0; counter1 < timeSelectedTempCount; counter1++) arrayTimeSelected [timeSelectedCount] = arrayTimeSelectedTemp [counter1], timeSelectedCount++;
            
            int *arrayGravityCenterTemp = new int [gravityCenterRevCount+10];
            int gravityCenterTempCount = 0;
            
            for (int counter1 = 1; counter1 <= maxConnectNo; counter1++){
                if (lineageNoRef [counter1*4+1] != 0){
                    for (int counter2 = 0; counter2 < gravityCenterRevCount/6; counter2++){
                        if (lineageNoRef [counter1*4] == arrayGravityCenterRev [counter2*6+4]){
                            arrayGravityCenterTemp [gravityCenterTempCount] = arrayGravityCenterRev [counter2*6], gravityCenterTempCount++;
                            arrayGravityCenterTemp [gravityCenterTempCount] = arrayGravityCenterRev [counter2*6+1], gravityCenterTempCount++;
                            arrayGravityCenterTemp [gravityCenterTempCount] = arrayGravityCenterRev [counter2*6+2], gravityCenterTempCount++;
                            arrayGravityCenterTemp [gravityCenterTempCount] = arrayGravityCenterRev [counter2*6+3], gravityCenterTempCount++;
                            arrayGravityCenterTemp [gravityCenterTempCount] = lineageNoRef [counter1*4+2], gravityCenterTempCount++;
                            arrayGravityCenterTemp [gravityCenterTempCount] = arrayGravityCenterRev [counter2*6+5], gravityCenterTempCount++;
                        }
                    }
                }
            }
            
            gravityCenterRevCount = 0;
            
            for (int counter1 = 0; counter1 < gravityCenterTempCount; counter1++) arrayGravityCenterRev [gravityCenterRevCount] = arrayGravityCenterTemp [counter1], gravityCenterRevCount++;
            
            int *arrayPositionReviseCountTemp = new int [positionReviseCount+10];
            int positionReviseTempCount = 0;
            
            for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                if (lineageNoRef [arrayPositionRevise [counter1*7+3]*4+1] == 2 || lineageNoRef [arrayPositionRevise [counter1*7+3]*4+1] == 3 || lineageNoRef [arrayPositionRevise [counter1*7+3]*4+1] == 4){
                    arrayPositionReviseCountTemp [positionReviseTempCount] = arrayPositionRevise [counter1*7], positionReviseTempCount++;
                    arrayPositionReviseCountTemp [positionReviseTempCount] = arrayPositionRevise [counter1*7+1], positionReviseTempCount++;
                    arrayPositionReviseCountTemp [positionReviseTempCount] = arrayPositionRevise [counter1*7+2], positionReviseTempCount++;
                    arrayPositionReviseCountTemp [positionReviseTempCount] = lineageNoRef [arrayPositionRevise [counter1*7+3]*4+2], positionReviseTempCount++;
                    arrayPositionReviseCountTemp [positionReviseTempCount] = arrayPositionRevise [counter1*7+4], positionReviseTempCount++;
                    arrayPositionReviseCountTemp [positionReviseTempCount] = 1, positionReviseTempCount++;
                    arrayPositionReviseCountTemp [positionReviseTempCount] = arrayPositionRevise [counter1*7+6], positionReviseTempCount++;
                }
            }
            
            positionReviseCount = 0;
            
            for (int counter1 = 0; counter1 < positionReviseTempCount; counter1++) arrayPositionRevise [positionReviseCount] = arrayPositionReviseCountTemp [counter1], positionReviseCount++;
            
            //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
            //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
            //    cout<<" arrayPositionRevise "<<counterA<<endl;
            //}
            
            int valueTemp = 0;
            
            for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                if (arrayPositionRevise [counter1*7+3] != valueTemp){
                    valueTemp = arrayPositionRevise [counter1*7+3];
                    arrayTimeSelected [(valueTemp-1)*10+2] = counter1;
                    
                    if (arrayPositionRevise [counter1*7+5] == 0){
                        arrayTimeSelected [(valueTemp-1)*10] = 0;
                    }
                }
            }
            
            for (int counterY = 0; counterY < imageXYLength; counterY++){
                for (int counterX = 0; counterX < imageXYLength; counterX++){
                    if (revisedWorkingMap [counterY][counterX] != 0){
                        revisedWorkingMap [counterY][counterX] = lineageNoRef [revisedWorkingMap [counterY][counterX]*4+2];
                    }
                }
            }
            
            delete [] lineageNoRef;
            delete [] arrayTimeSelectedTemp;
            delete [] arrayGravityCenterTemp;
            delete [] arrayPositionReviseCountTemp;
            
            string extension = to_string(timePointHold);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            string connectDataRevPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_MasterData";
            
            int dataTemp = 0;
            
            if (positionReviseCount != 0){
                int readBit [4];
                long indexCount = 0;
                
                char *writingArray = new char [(positionReviseCount/7+gravityCenterRevCount/6)*17+50];
                
                for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                    dataTemp = arrayPositionRevise [counter1*7];
                    readBit [0] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [1] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    
                    dataTemp = arrayPositionRevise [counter1*7+1];
                    readBit [0] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [1] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    
                    writingArray [indexCount] = (char)arrayPositionRevise [counter1*7+2], indexCount++;
                    
                    dataTemp = arrayPositionRevise [counter1*7+3];
                    readBit [0] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [1] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [2] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                    
                    dataTemp = arrayPositionRevise [counter1*7+4];
                    
                    if (dataTemp < 0) dataTemp = dataTemp*-1, writingArray [indexCount] = 1, indexCount++;
                    else writingArray [indexCount] = 0, indexCount++;
                    
                    readBit [0] = dataTemp/16777216;
                    dataTemp = dataTemp%16777216;
                    readBit [1] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [2] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [3] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                    writingArray [indexCount] = (char)readBit [3], indexCount++;
                    
                    writingArray [indexCount] = (char)arrayPositionRevise [counter1*7+5], indexCount++;
                    
                    dataTemp = arrayPositionRevise [counter1*7+6];
                    readBit [0] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [1] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [2] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                }
                
                for (int counter1 = 0; counter1 < 17; counter1++) writingArray [indexCount] = 0, indexCount++;
                
                for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                    dataTemp = arrayGravityCenterRev [counter1*6];
                    readBit [0] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [1] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    
                    dataTemp = arrayGravityCenterRev [counter1*6+1];
                    readBit [0] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [1] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    
                    dataTemp = arrayGravityCenterRev [counter1*6+2];
                    readBit [0] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [1] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [2] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                    
                    writingArray [indexCount] = (char)arrayGravityCenterRev [counter1*6+3], indexCount++;
                    
                    dataTemp = arrayGravityCenterRev [counter1*6+4];
                    readBit [0] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [1] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [2] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                    
                    writingArray [indexCount] = (char)arrayGravityCenterRev [counter1*6+5], indexCount++;
                }
                
                for (int counter1 = 0; counter1 < 11; counter1++) writingArray [indexCount] = 0, indexCount++;
                
                ofstream outfile (connectDataRevPath.c_str(), ofstream::binary);
                outfile.write ((char*)writingArray, indexCount);
                outfile.close();
                
                delete [] writingArray;
            }
            
            string connectStatusDataPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_Status";
            
            if (timeSelectedCount != 0){
                char *writingArray = new char [timeSelectedCount/10*19+20];
                
                long indexCount = 0;
                int readBit [3];
                int connectNumberTemp = 0;
                
                for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                    writingArray [indexCount] = (char)arrayTimeSelected [counter1*10], indexCount++;
                    writingArray [indexCount] = 0, indexCount++;
                    writingArray [indexCount] = 0, indexCount++;
                    writingArray [indexCount] = 0, indexCount++;
                    
                    dataTemp = arrayTimeSelected [counter1*10+2];
                    readBit [0] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [1] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [2] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                    
                    writingArray [indexCount] = 0, indexCount++;
                    writingArray [indexCount] = 0, indexCount++;
                    
                    writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+4], indexCount++;
                    writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+5], indexCount++;
                    writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+6], indexCount++;
                    writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+7], indexCount++;
                    
                    dataTemp = arrayTimeSelected [counter1*10+8];
                    readBit [0] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [1] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [2] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                    
                    if (arrayTimeSelected [counter1*10] == 3 || arrayTimeSelected [counter1*10] == 4) connectNumberTemp = 0;
                    else connectNumberTemp = arrayTimeSelected [counter1*10+9];
                    
                    dataTemp = connectNumberTemp;
                    readBit [0] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [1] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [2] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                }
                
                for (int counter1 = 0; counter1 < 19; counter1++) writingArray [indexCount] = 0, indexCount++;
                
                ofstream outfile2 (connectStatusDataPath.c_str(), ofstream::binary);
                outfile2.write ((char*) writingArray, indexCount);
                outfile2.close();
                
                delete [] writingArray;
            }
            
            string revisedMapPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_RevisedMap";
            
            if (imageXYLength != 0){
                int totalMapSizeTemp = imageXYLength*imageXYLength*4+1;
                
                char *dataHold = new char [totalMapSizeTemp];
                int indexCount = 0;
                int dataTemp2 = 0;
                int entryCount = 0;
                int readBit [4];
                
                for (int counterX = 0; counterX < imageXYLength; counterX++){
                    for (int counterY = 0; counterY < imageXYLength; counterY++){
                        dataTemp = revisedWorkingMap [counterX][counterY];
                        
                        if (counterY == 0) dataTemp2 = dataTemp, entryCount++;
                        else if (dataTemp != dataTemp2 || entryCount == 254 || counterY == imageXYLength-1){
                            readBit [0] = dataTemp2/65536;
                            dataTemp2 = dataTemp2%65536;
                            readBit [1] = dataTemp2/256;
                            dataTemp2 = dataTemp2%256;
                            readBit [2] = dataTemp2;
                            
                            if (counterY == imageXYLength-1){
                                if (dataTemp != dataTemp2){
                                    dataHold [indexCount] = (char)readBit [0], indexCount++;
                                    dataHold [indexCount] = (char)readBit [1], indexCount++;
                                    dataHold [indexCount] = (char)readBit [2], indexCount++;
                                    dataHold [indexCount] = (char)entryCount, indexCount++;
                                    
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    entryCount = 1;
                                    
                                    dataHold [indexCount] = (char)readBit [0], indexCount++;
                                    dataHold [indexCount] = (char)readBit [1], indexCount++;
                                    dataHold [indexCount] = (char)readBit [2], indexCount++;
                                    dataHold [indexCount] = (char)entryCount, indexCount++;
                                }
                                else{
                                    
                                    entryCount++;
                                    
                                    dataHold [indexCount] = (char)readBit [0], indexCount++;
                                    dataHold [indexCount] = (char)readBit [1], indexCount++;
                                    dataHold [indexCount] = (char)readBit [2], indexCount++;
                                    dataHold [indexCount] = (char)entryCount, indexCount++;
                                }
                            }
                            else{
                                
                                dataHold [indexCount] = (char)readBit [0], indexCount++;
                                dataHold [indexCount] = (char)readBit [1], indexCount++;
                                dataHold [indexCount] = (char)readBit [2], indexCount++;
                                dataHold [indexCount] = (char)entryCount, indexCount++;
                            }
                            
                            if (counterY == imageXYLength-1) entryCount = 0;
                            else entryCount = 1, dataTemp2 = dataTemp;
                        }
                        else entryCount++;
                    }
                }
                
                ofstream outfile2 (revisedMapPath.c_str(), ofstream::binary);
                outfile2.write(dataHold, indexCount);
                outfile2.close();
                
                delete [] dataHold;
            }
            
            imageProgressFlag = 0;
            warningSet = 3;
        });
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Area Mode Off or Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

@end
