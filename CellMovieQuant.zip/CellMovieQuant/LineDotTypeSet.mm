//
//  LineDotTypeSet.m
//  CellMovieQuant
//
//  Created by Masahiko Sato on 2021-12-29.
//

#import "LineDotTypeSet.h"

@implementation LineDotTypeSet

-(IBAction)lineTargetColorOrange:(id)sender{
    targetMarkColorType = 0;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)lineTargetColorGreen:(id)sender{
    targetMarkColorType = 1;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)lineTargetColorYellow:(id)sender{
    targetMarkColorType = 2;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)lineTargetColorRed:(id)sender{
    targetMarkColorType = 3;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)lineTargetColorBlue:(id)sender{
    targetMarkColorType = 4;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)lineTargetColorBlack:(id)sender{
    targetMarkColorType = 5;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)lineTargetColorClear:(id)sender{
    targetMarkColorType = 6;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)lineTargetWidth1:(id)sender{
    targetMarkWidthType = 0;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)lineTargetWidth2:(id)sender{
    targetMarkWidthType = 1;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)lineTargetWidth4:(id)sender{
    targetMarkWidthType = 2;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)gridColorOrange:(id)sender{
    gridLineColor = 0;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)gridColorGreen:(id)sender{
    gridLineColor = 1;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)gridColorYellow:(id)sender{
    gridLineColor = 2;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)gridColorRed:(id)sender{
    gridLineColor = 3;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)gridColorBlue:(id)sender{
    gridLineColor = 4;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)gridColorBlack:(id)sender{
    gridLineColor = 5;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)gridColorWhite:(id)sender{
    gridLineColor = 6;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)gridWidth1:(id)sender{
    gridLinWidth = 0;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)gridWidth2:(id)sender{
    gridLinWidth = 1;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)gridWidth4:(id)sender{
    gridLinWidth = 2;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)dotStatusFillSet:(id)sender{
    dotFillStatus = 0;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)dotStatusStrokeSet:(id)sender{
    dotFillStatus = 1;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)dotLength1:(id)sender{
    dotLength = 1;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)dotLength2:(id)sender{
    dotLength = 2;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)dotLength3:(id)sender{
    dotLength = 3;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)removeDotDataFile:(id)sender{
    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"OK"];
    [alert addButtonWithTitle:@"Cancel"];
    [alert setMessageText:@"Current Dot File Will Be Removed"];
    [alert setAlertStyle:NSAlertStyleWarning];
    
    if ([alert runModal] == NSAlertFirstButtonReturn){
        string dataSaveTreatmentPath4 = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"DotData";
        
        dotDataHoldCount = 0;
        
        remove (dataSaveTreatmentPath4.c_str());
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)lineSizeSet:(id)sender{
    if (lineSizeHold == 0){
        lineSizeHold = 1;
        [lineSizeDisplay setStringValue:@"x2"];
    }
    else if (lineSizeHold == 1){
        lineSizeHold = 2;
        [lineSizeDisplay setStringValue:@"x3"];
    }
    else if (lineSizeHold== 2){
        lineSizeHold = 3;
        [lineSizeDisplay setStringValue:@"x4"];
    }
    else if (lineSizeHold == 3){
        lineSizeHold = 4;
        [lineSizeDisplay setStringValue:@"x5"];
    }
    else if (lineSizeHold == 4){
        lineSizeHold = 5;
        [lineSizeDisplay setStringValue:@"x0.1"];
    }
    else if (lineSizeHold == 5){
        lineSizeHold = 6;
        [lineSizeDisplay setStringValue:@"x0.2"];
    }
    else if (lineSizeHold == 6){
        lineSizeHold = 7;
        [lineSizeDisplay setStringValue:@"x0.3"];
    }
    else if (lineSizeHold == 7){
        lineSizeHold = 8;
        [lineSizeDisplay setStringValue:@"x0.4"];
    }
    else if (lineSizeHold == 8){
        lineSizeHold = 9;
        [lineSizeDisplay setStringValue:@"x0.5"];
    }
    else if (lineSizeHold == 9){
        lineSizeHold = 0;
        [lineSizeDisplay setStringValue:@"x1"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)cutLIneSet:(id)sender{
    if (areaModeStatusHold == 1){
        if (lineWidthFlag == 0){
            lineWidthFlag = 1;
            [cutLineDisplay setStringValue:@"Double"];
        }
        else if (lineWidthFlag == 1){
            lineWidthFlag = 0;
            [cutLineDisplay setStringValue:@"Single"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Area Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

@end
