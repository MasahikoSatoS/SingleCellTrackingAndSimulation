//
//  MovieDisplay.h
//  CellMovieQuant
//
//  Created by Masahiko Sato on 2014-09-29.
//
//

#ifndef MOVIEDISPLAY_H
#define MOVIEDISPLAY_H
#import "Controller.h"
#endif

@interface MovieDisplay : NSView {
    int firstDisplayFlag; //Set the movie is called the first time
    
    int magnificationDisplay; //Movie operation
    int mouseDragFlag; //Movie operation
    double xPositionDisplay; //Movie operation
    double yPositionDisplay; //Movie operation
    double xPositionAdjustDisplay; //Movie operation
    double yPositionAdjustDisplay; //Movie operation
    double xPointDownDisplay; //Movie operation
    double yPointDownDisplay; //Movie operation
    double xPositionMoveDisplay; //Movie operation
    double yPositionMoveDisplay; //Movie operation
    double xPointDragDisplay; //Movie operation
    double yPointDragDisplay; //Movie operation
    double windowWidthDisplay; //Movie operation
    double windowHeightDisplay; //Movie operation
    
    int timeOneQuickSet; //Status of connect hold for display
    
    int xPointLine; //Target line draw position hold
    int yPointLine; //Target line draw position hold
    
    IBOutlet NSImage *movieImage;
    
    id targetFind2;
    id lineSet;
    id merge;
    id trackingDataSave;
    id subProcesses;
}

-(void)mouseDown:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)mouseDragged:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;
-(void)arrayAreaDataHoldUpDate;
-(void)arrayDotDataHoldUpDate;
-(void)targetUpDate;

@end
