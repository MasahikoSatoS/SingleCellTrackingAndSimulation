//
//  ExportDisplay.m
//  CellMovieQuant
//
//  Created by Masahiko Sato on 2019-10-25.
//

#import "ExportDisplay.h"

NSString *notificationToExportDisplay = @"notificationExecuteExportDisplay";

@implementation ExportDisplay

-(id)initWithFrame:(NSRect)frame{
    self = [super initWithFrame:frame];
    
    if (self != nil){
        mouseDragFlag = 0;
        magnificationExport = 10;
        displayModeSelect = 0;
        timingEx2 = 0;
        
        exportImage = [[NSImage alloc] initWithContentsOfFile:@""];
        exportImage2 = [[NSImage alloc] initWithContentsOfFile:@""];
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToExportDisplay object:nil];
    }
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    if (imageXYLength != 0){
        NSBitmapImageRep *bitmapRepsCR = nil;
        bitmapRepsCR = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageXYLength pixelsHigh:imageXYLength bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageXYLength*4 bitsPerPixel:32];
        
        unsigned char *bitmapData = [bitmapRepsCR bitmapData];
        
        if (phaseStatus == 0){
            if (grayColorStatus == 0){
                int value0 = 0;
                int value1 = 0;
                int value2 = 0;
                int value3 = 0;
                int value4 = 0;
                int value5 = 0;
                int value6 = 0;
                
                int dataConversion [4];
                int endianType = 0;
                
                double colorHit1 = 0;
                double colorHit2 = 0;
                double colorHit3 = 0;
                double colorHit4 = 0;
                double colorHit5 = 0;
                double colorHit6 = 0;
                
                int hitR = 0;
                int hitG = 0;
                int hitB = 0;
                
                if (statusHold1 != 0 || statusHold2 != 0 || statusHold3 != 0 || statusHold4 != 0 || statusHold5 != 0 || statusHold6 != 0){
                    if (imageBmpTifFlag == 0){
                        double *hitMap = new double [20];
                        
                        if (colorNo1 == "1"){
                            hitMap [0] = 0;
                            hitMap [1] = 0;
                            hitMap [2] = 1;
                        }
                        else if (colorNo1 == "2"){
                            hitMap [0] = 0;
                            hitMap [1] = 1;
                            hitMap [2] = 0;
                        }
                        else if (colorNo1 == "3"){
                            hitMap [0] = 1;
                            hitMap [1] = 1;
                            hitMap [2] = 0;
                        }
                        else if (colorNo1 == "4"){
                            hitMap [0] = 1;
                            hitMap [1] = 0;
                            hitMap [2] = 0;
                        }
                        else if (colorNo1 == "5"){
                            hitMap [0] = 1;
                            hitMap [1] = 0;
                            hitMap [2] = 1;
                        }
                        else if (colorNo1 == "6"){
                            hitMap [0] = 0;
                            hitMap [1] = 1;
                            hitMap [2] = 1;
                        }
                        else if (colorNo1 == "7"){
                            hitMap [0] = 1;
                            hitMap [1] = 0.674;
                            hitMap [2] = 0;
                        }
                        else if (colorNo1 == "8"){
                            hitMap [0] = 0.627;
                            hitMap [1] = 0.125;
                            hitMap [2] = 0.941;
                        }
                        else if (colorNo1 == "9"){
                            hitMap [0] = 0.529;
                            hitMap [1] = 0.808;
                            hitMap [2] = 0.922;
                        }
                        
                        if (colorNo2 == "1"){
                            hitMap [3] = 0;
                            hitMap [4] = 0;
                            hitMap [5] = 1;
                        }
                        else if (colorNo2 == "2"){
                            hitMap [3] = 0;
                            hitMap [4] = 1;
                            hitMap [5] = 0;
                        }
                        else if (colorNo2 == "3"){
                            hitMap [3] = 1;
                            hitMap [4] = 1;
                            hitMap [5] = 0;
                        }
                        else if (colorNo2 == "4"){
                            hitMap [3] = 1;
                            hitMap [4] = 0;
                            hitMap [5] = 0;
                        }
                        else if (colorNo2 == "5"){
                            hitMap [3] = 1;
                            hitMap [4] = 0;
                            hitMap [5] = 1;
                        }
                        else if (colorNo2 == "6"){
                            hitMap [3] = 0;
                            hitMap [4] = 1;
                            hitMap [5] = 1;
                        }
                        else if (colorNo2 == "7"){
                            hitMap [3] = 1;
                            hitMap [4] = 0.674;
                            hitMap [5] = 0;
                        }
                        else if (colorNo2 == "8"){
                            hitMap [3] = 0.627;
                            hitMap [4] = 0.125;
                            hitMap [5] = 0.941;
                        }
                        else if (colorNo2 == "9"){
                            hitMap [3] = 0.529;
                            hitMap [4] = 0.808;
                            hitMap [5] = 0.922;
                        }
                        
                        if (colorNo3 == "1"){
                            hitMap [6] = 0;
                            hitMap [7] = 0;
                            hitMap [8] = 1;
                        }
                        else if (colorNo3 == "2"){
                            hitMap [6] = 0;
                            hitMap [7] = 1;
                            hitMap [8] = 0;
                        }
                        else if (colorNo3 == "3"){
                            hitMap [6] = 1;
                            hitMap [7] = 1;
                            hitMap [8] = 0;
                        }
                        else if (colorNo3 == "4"){
                            hitMap [6] = 1;
                            hitMap [7] = 0;
                            hitMap [8] = 0;
                        }
                        else if (colorNo3 == "5"){
                            hitMap [6] = 1;
                            hitMap [7] = 0;
                            hitMap [8] = 1;
                        }
                        else if (colorNo3 == "6"){
                            hitMap [6] = 0;
                            hitMap [7] = 1;
                            hitMap [8] = 1;
                        }
                        else if (colorNo3 == "7"){
                            hitMap [6] = 1;
                            hitMap [7] = 0.674;
                            hitMap [8] = 0;
                        }
                        else if (colorNo3 == "8"){
                            hitMap [6] = 0.627;
                            hitMap [7] = 0.125;
                            hitMap [8] = 0.941;
                        }
                        else if (colorNo3 == "9"){
                            hitMap [6] = 0.529;
                            hitMap [7] = 0.808;
                            hitMap [8] = 0.922;
                        }
                        
                        if (colorNo4 == "1"){
                            hitMap [9] = 0;
                            hitMap [10] = 0;
                            hitMap [11] = 1;
                        }
                        else if (colorNo4 == "2"){
                            hitMap [9] = 0;
                            hitMap [10] = 1;
                            hitMap [11] = 0;
                        }
                        else if (colorNo4 == "3"){
                            hitMap [9] = 1;
                            hitMap [10] = 1;
                            hitMap [11] = 0;
                        }
                        else if (colorNo4 == "4"){
                            hitMap [9] = 1;
                            hitMap [10] = 0;
                            hitMap [11] = 0;
                        }
                        else if (colorNo4 == "5"){
                            hitMap [9] = 1;
                            hitMap [10] = 0;
                            hitMap [11] = 1;
                        }
                        else if (colorNo4 == "6"){
                            hitMap [9] = 0;
                            hitMap [10] = 1;
                            hitMap [11] = 1;
                        }
                        else if (colorNo4 == "7"){
                            hitMap [9] = 1;
                            hitMap [10] = 0.674;
                            hitMap [11] = 0;
                        }
                        else if (colorNo4 == "8"){
                            hitMap [9] = 0.627;
                            hitMap [10] = 0.125;
                            hitMap [11] = 0.941;
                        }
                        else if (colorNo4 == "9"){
                            hitMap [9] = 0.529;
                            hitMap [10] = 0.808;
                            hitMap [11] = 0.922;
                        }
                        
                        if (colorNo5 == "1"){
                            hitMap [12] = 0;
                            hitMap [13] = 0;
                            hitMap [14] = 1;
                        }
                        else if (colorNo5 == "2"){
                            hitMap [12] = 0;
                            hitMap [13] = 1;
                            hitMap [14] = 0;
                        }
                        else if (colorNo5 == "3"){
                            hitMap [12] = 1;
                            hitMap [13] = 1;
                            hitMap [14] = 0;
                        }
                        else if (colorNo5 == "4"){
                            hitMap [12] = 1;
                            hitMap [13] = 0;
                            hitMap [14] = 0;
                        }
                        else if (colorNo5 == "5"){
                            hitMap [12] = 1;
                            hitMap [13] = 0;
                            hitMap [14] = 1;
                        }
                        else if (colorNo5 == "6"){
                            hitMap [12] = 0;
                            hitMap [13] = 1;
                            hitMap [14] = 1;
                        }
                        else if (colorNo5 == "7"){
                            hitMap [12] = 1;
                            hitMap [13] = 0.674;
                            hitMap [14] = 0;
                        }
                        else if (colorNo5 == "8"){
                            hitMap [12] = 0.627;
                            hitMap [13] = 0.125;
                            hitMap [14] = 0.941;
                        }
                        else if (colorNo5 == "9"){
                            hitMap [12] = 0.529;
                            hitMap [13] = 0.808;
                            hitMap [14] = 0.922;
                        }
                        
                        if (colorNo6 == "1"){
                            hitMap [15] = 0;
                            hitMap [16] = 0;
                            hitMap [17] = 1;
                        }
                        else if (colorNo6 == "2"){
                            hitMap [15] = 0;
                            hitMap [16] = 1;
                            hitMap [17] = 0;
                        }
                        else if (colorNo6 == "3"){
                            hitMap [15] = 1;
                            hitMap [16] = 1;
                            hitMap [17] = 0;
                        }
                        else if (colorNo6 == "4"){
                            hitMap [15] = 1;
                            hitMap [16] = 0;
                            hitMap [17] = 0;
                        }
                        else if (colorNo6 == "5"){
                            hitMap [15] = 1;
                            hitMap [16] = 0;
                            hitMap [17] = 1;
                        }
                        else if (colorNo6 == "6"){
                            hitMap [15] = 0;
                            hitMap [16] = 1;
                            hitMap [17] = 1;
                        }
                        else if (colorNo6 == "7"){
                            hitMap [15] = 1;
                            hitMap [16] = 0.674;
                            hitMap [17] = 0;
                        }
                        else if (colorNo6 == "8"){
                            hitMap [15] = 0.627;
                            hitMap [16] = 0.125;
                            hitMap [17] = 0.941;
                        }
                        else if (colorNo6 == "9"){
                            hitMap [15] = 0.529;
                            hitMap [16] = 0.808;
                            hitMap [17] = 0.922;
                        }
                        
                        unsigned long headPosition = 0;
                        
                        dataConversion [0] = uploadTempExp [0];
                        dataConversion [1] = uploadTempExp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTempExp [7];
                            dataConversion [1] = uploadTempExp [6];
                            dataConversion [2] = uploadTempExp [5];
                            dataConversion [3] = uploadTempExp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTempExp [4];
                            dataConversion [1] = uploadTempExp [5];
                            dataConversion [2] = uploadTempExp [6];
                            dataConversion [3] = uploadTempExp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                            value1 = 0;
                            value2 = 0;
                            value3 = 0;
                            value4 = 0;
                            value5 = 0;
                            value6 = 0;
                            
                            value0 = uploadTempExp [counter1];
                            
                            if (value0 >= 0 && value0 < cutHoldDIC){
                                value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                
                                if (value0 < 0) value0 = 0;
                            }
                            else{
                                
                                value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                
                                if (value0 > 255) value0 = 255;
                            }
                            
                            if (statusHold1 == 1 && colorFlag1 == 1){
                                value1 = uploadTempExpCl1 [counter1];
                                
                                if (value1 < cutHold1) value1 = 0;
                                else{
                                    
                                    value1 = value1+(int)((value1-cutHold1)*levelHold1);
                                    
                                    if (value1 > 255) value1 = 255;
                                }
                            }
                            
                            if (statusHold2 == 1 && colorFlag2 == 1){
                                value2 = uploadTempExpCl2 [counter1];
                                
                                if (value2 < cutHold2) value2 = 0;
                                else{
                                    
                                    value2 = value2+(int)((value2-cutHold2)*levelHold2);
                                    
                                    if (value2 > 255) value2 = 255;
                                }
                            }
                            
                            if (statusHold3 == 1 && colorFlag3 == 1){
                                value3 = uploadTempExpCl3 [counter1];
                                
                                if (value3 < cutHold3) value3 = 0;
                                else{
                                    
                                    value3 = value3+(int)((value3-cutHold3)*levelHold3);
                                    
                                    if (value3 > 255) value3 = 255;
                                }
                            }
                            
                            if (statusHold4 == 1 && colorFlag4 == 1){
                                value4 = uploadTempExpCl4 [counter1];
                                
                                if (value4 < cutHold4) value4 = 0;
                                else{
                                    
                                    value4 = value4+(int)((value4-cutHold4)*levelHold4);
                                    
                                    if (value4 > 255) value4 = 255;
                                }
                            }
                            
                            if (statusHold5 == 1 && colorFlag5 == 1){
                                value5 = uploadTempExpCl5 [counter1];
                                
                                if (value5 < cutHold5) value5 = 0;
                                else{
                                    
                                    value5 = value5+(int)((value5-cutHold5)*levelHold5);
                                    
                                    if (value5 > 255) value5 = 255;
                                }
                            }
                            
                            if (statusHold6 == 1 && colorFlag6 == 1){
                                value6 = uploadTempExpCl6 [counter1];
                                
                                if (value6 < cutHold6) value6 = 0;
                                else{
                                    
                                    value6 = value6+(int)((value6-cutHold6)*levelHold6);
                                    
                                    if (value6 > 255) value6 = 255;
                                }
                            }
                            
                            if (statusHold1 == 0) value1 = 0;
                            if (statusHold2 == 0) value2 = 0;
                            if (statusHold3 == 0) value3 = 0;
                            if (statusHold4 == 0) value4 = 0;
                            if (statusHold5 == 0) value5 = 0;
                            if (statusHold6 == 0) value6 = 0;
                            
                            if (value1 <= 0 && value2 <= 0 && value3 <= 0 && value4 <= 0 && value5 <= 0 && value6 <= 0){
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = 0;
                            }
                            else{
                                
                                if (value1 < 0) value1 = 0;
                                if (value2 < 0) value2 = 0;
                                if (value3 < 0) value3 = 0;
                                if (value4 < 0) value4 = 0;
                                if (value5 < 0) value5 = 0;
                                if (value6 < 0) value6 = 0;
                                
                                hitR = 0;
                                hitG = 0;
                                hitB = 0;
                                
                                if (value1 > 0){
                                    if (hitMap [0] != 0) hitR++;
                                    if (hitMap [1] != 0) hitG++;
                                    if (hitMap [2] != 0) hitB++;
                                }
                                
                                if (value2 > 0){
                                    if (hitMap [3] != 0) hitR++;
                                    if (hitMap [4] != 0) hitG++;
                                    if (hitMap [5] != 0) hitB++;
                                }
                                
                                if (value3 > 0){
                                    if (hitMap [6] != 0) hitR++;
                                    if (hitMap [7] != 0) hitG++;
                                    if (hitMap [8] != 0) hitB++;
                                }
                                
                                if (value4 > 0){
                                    if (hitMap [9] != 0) hitR++;
                                    if (hitMap [10] != 0) hitG++;
                                    if (hitMap [11] != 0) hitB++;
                                }
                                
                                if (value5 > 0){
                                    if (hitMap [12] != 0) hitR++;
                                    if (hitMap [13] != 0) hitG++;
                                    if (hitMap [14] != 0) hitB++;
                                }
                                
                                if (value6 > 0){
                                    if (hitMap [15] != 0) hitR++;
                                    if (hitMap [16] != 0) hitG++;
                                    if (hitMap [17] != 0) hitB++;
                                }
                                
                                colorHit1 = 0;
                                colorHit2 = 0;
                                colorHit3 = 0;
                                colorHit4 = 0;
                                colorHit5 = 0;
                                colorHit6 = 0;
                                
                                if (hitR == 1){
                                    if (hitMap [0] != 0 && value1 > 0) colorHit1 = 1;
                                    if (hitMap [3] != 0 && value2 > 0) colorHit2 = 1;
                                    if (hitMap [6] != 0 && value3 > 0) colorHit3 = 1;
                                    if (hitMap [9] != 0 && value4 > 0) colorHit4 = 1;
                                    if (hitMap [12] != 0 && value5 > 0) colorHit5 = 1;
                                    if (hitMap [15] != 0 && value6 > 0) colorHit6 = 1;
                                }
                                else if (hitR == 2){
                                    if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.5;
                                    if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.5;
                                    if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.5;
                                    if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.5;
                                    if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.5;
                                    if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.5;
                                }
                                else if (hitR == 3){
                                    if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.33;
                                    if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.33;
                                    if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.33;
                                    if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.33;
                                    if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.33;
                                    if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.33;
                                }
                                else if (hitR == 4){
                                    if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.25;
                                    if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.25;
                                    if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.25;
                                    if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.25;
                                    if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.25;
                                    if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.25;
                                }
                                else if (hitR == 5){
                                    if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.2;
                                    if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.2;
                                    if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.2;
                                    if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.2;
                                    if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.2;
                                    if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.2;
                                }
                                else if (hitR == 6){
                                    if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.13;
                                    if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.13;
                                    if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.13;
                                    if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.13;
                                    if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.13;
                                    if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.13;
                                }
                                
                                if (value1 > 0 && colorNo1 == "7") colorHit1 = colorHit1*0.647;
                                else if (value1 > 0 && colorNo1 == "8") colorHit1 = colorHit1*0.627;
                                else if (value1 > 0 && colorNo1 == "9") colorHit1 = colorHit1*0.529;
                                
                                if (value2 > 0 && colorNo2 == "7") colorHit2 = colorHit2*0.647;
                                else if (value2 > 0 && colorNo2 == "8") colorHit2 = colorHit2*0.627;
                                else if (value2 > 0 && colorNo2 == "9") colorHit2 = colorHit2*0.529;
                                
                                if (value3 > 0 && colorNo3 == "7") colorHit3 = colorHit3*0.647;
                                else if (value3 > 0 && colorNo3 == "8") colorHit3 = colorHit3*0.627;
                                else if (value3 > 0 && colorNo3 == "9") colorHit3 = colorHit3*0.529;
                                
                                if (value4 > 0 && colorNo4 == "7") colorHit4 = colorHit4*0.647;
                                else if (value4 > 0 && colorNo4 == "8") colorHit4 = colorHit4*0.627;
                                else if (value4 > 0 && colorNo4 == "9") colorHit4 = colorHit4*0.529;
                                
                                if (value5 > 0 && colorNo5 == "7") colorHit5 = colorHit5*0.647;
                                else if (value5 > 0 && colorNo5 == "8") colorHit5 = colorHit5*0.627;
                                else if (value5 > 0 && colorNo5 == "9") colorHit5 = colorHit5*0.529;
                                
                                if (value6 > 0 && colorNo6 == "7") colorHit6 = colorHit6*0.647;
                                else if (value6 > 0 && colorNo6 == "8") colorHit6 = colorHit6*0.627;
                                else if (value6 > 0 && colorNo6 == "9") colorHit6 = colorHit6*0.529;
                                
                                *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3+value4*(double)colorHit4+value5*(double)colorHit5+value6*(double)colorHit6));
                                
                                colorHit1 = 0;
                                colorHit2 = 0;
                                colorHit3 = 0;
                                colorHit4 = 0;
                                colorHit5 = 0;
                                colorHit6 = 0;
                                
                                if (hitG == 1){
                                    if (hitMap [1] != 0 && value1 > 0) colorHit1 = 1;
                                    if (hitMap [4] != 0 && value2 > 0) colorHit2 = 1;
                                    if (hitMap [7] != 0 && value3 > 0) colorHit3 = 1;
                                    if (hitMap [10] != 0 && value4 > 0) colorHit4 = 1;
                                    if (hitMap [13] != 0 && value5 > 0) colorHit5 = 1;
                                    if (hitMap [16] != 0 && value6 > 0) colorHit6 = 1;
                                }
                                else if (hitG == 2){
                                    if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.5;
                                    if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.5;
                                    if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.5;
                                    if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.5;
                                    if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.5;
                                    if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.5;
                                }
                                else if (hitG == 3){
                                    if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.33;
                                    if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.33;
                                    if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.33;
                                    if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.33;
                                    if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.33;
                                    if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.33;
                                }
                                else if (hitG == 4){
                                    if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.25;
                                    if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.25;
                                    if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.25;
                                    if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.25;
                                    if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.25;
                                    if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.25;
                                }
                                else if (hitG == 5){
                                    if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.2;
                                    if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.2;
                                    if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.2;
                                    if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.2;
                                    if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.2;
                                    if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.2;
                                }
                                else if (hitG == 6){
                                    if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.13;
                                    if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.13;
                                    if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.13;
                                    if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.13;
                                    if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.13;
                                    if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.13;
                                }
                                
                                if (value1 > 0 && colorNo1 == "8") colorHit1 = colorHit1*0.125;
                                else if (value1 > 0 && colorNo1 == "9") colorHit1 = colorHit1*0.808;
                                
                                if (value2 > 0 && colorNo2 == "8") colorHit2 = colorHit2*0.125;
                                else if (value2 > 0 && colorNo2 == "9") colorHit2 = colorHit2*0.808;
                                
                                if (value3 > 0 && colorNo3 == "8") colorHit3 = colorHit3*0.125;
                                else if (value3 > 0 && colorNo3 == "9") colorHit3 = colorHit3*0.808;
                                
                                if (value4 > 0 && colorNo4 == "8") colorHit4 = colorHit4*0.125;
                                else if (value4 > 0 && colorNo4 == "9") colorHit4 = colorHit4*0.808;
                                
                                if (value5 > 0 && colorNo5 == "8") colorHit5 = colorHit5*0.125;
                                else if (value5 > 0 && colorNo5 == "9") colorHit5 = colorHit5*0.808;
                                
                                if (value6 > 0 && colorNo6 == "8") colorHit6 = colorHit6*0.125;
                                else if (value6 > 0 && colorNo6 == "9") colorHit6 = colorHit6*0.808;
                                
                                *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3+value4*(double)colorHit4+value5*(double)colorHit5+value6*(double)colorHit6));
                                
                                colorHit1 = 0;
                                colorHit2 = 0;
                                colorHit3 = 0;
                                colorHit4 = 0;
                                colorHit5 = 0;
                                colorHit6 = 0;
                                
                                if (hitB == 1){
                                    if (hitMap [2] != 0 && value1 > 0) colorHit1 = 1;
                                    if (hitMap [5] != 0 && value2 > 0) colorHit2 = 1;
                                    if (hitMap [8] != 0 && value3 > 0) colorHit3 = 1;
                                    if (hitMap [11] != 0 && value4 > 0) colorHit4 = 1;
                                    if (hitMap [14] != 0 && value5 > 0) colorHit5 = 1;
                                    if (hitMap [17] != 0 && value6 > 0) colorHit6 = 1;
                                }
                                else if (hitB == 2){
                                    if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.5;
                                    if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.5;
                                    if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.5;
                                    if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.5;
                                    if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.5;
                                    if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.5;
                                }
                                else if (hitB == 3){
                                    if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.33;
                                    if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.33;
                                    if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.33;
                                    if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.33;
                                    if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.33;
                                    if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.33;
                                }
                                else if (hitB == 4){
                                    if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.25;
                                    if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.25;
                                    if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.25;
                                    if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.25;
                                    if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.25;
                                    if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.25;
                                }
                                else if (hitB == 5){
                                    if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.2;
                                    if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.2;
                                    if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.2;
                                    if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.2;
                                    if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.2;
                                    if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.2;
                                }
                                else if (hitB == 6){
                                    if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.13;
                                    if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.13;
                                    if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.13;
                                    if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.13;
                                    if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.13;
                                    if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.13;
                                }
                                
                                if (value1 > 0 && colorNo1 == "8") colorHit1 = colorHit1*0.941;
                                else if (value1 > 0 && colorNo1 == "9") colorHit1 = colorHit1*0.922;
                                
                                if (value2 > 0 && colorNo2 == "8") colorHit2 = colorHit2*0.941;
                                else if (value2 > 0 && colorNo2 == "9") colorHit2 = colorHit2*0.922;
                                
                                if (value3 > 0 && colorNo3 == "8") colorHit3 = colorHit3*0.941;
                                else if (value3 > 0 && colorNo3 == "9") colorHit3 = colorHit3*0.922;
                                
                                if (value4 > 0 && colorNo4 == "8") colorHit4 = colorHit4*0.941;
                                else if (value4 > 0 && colorNo4 == "9") colorHit4 = colorHit4*0.922;
                                
                                if (value5 > 0 && colorNo5 == "8") colorHit5 = colorHit5*0.941;
                                else if (value5 > 0 && colorNo5 == "9") colorHit5 = colorHit5*0.922;
                                
                                if (value6 > 0 && colorNo6 == "8") colorHit6 = colorHit6*0.941;
                                else if (value6 > 0 && colorNo6 == "9") colorHit6 = colorHit6*0.922;
                                
                                *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3+value4*(double)colorHit4+value5*(double)colorHit5+value6*(double)colorHit6));
                                *bitmapData++ = 0;
                            }
                        }
                        
                        delete [] hitMap;
                    }
                    else if (imageBmpTifFlag == 1){
                        double *hitMap = new double [20];
                        
                        if (colorNo1 == "1"){
                            hitMap [0] = 0;
                            hitMap [1] = 0;
                            hitMap [2] = 1;
                        }
                        else if (colorNo1 == "2"){
                            hitMap [0] = 0;
                            hitMap [1] = 1;
                            hitMap [2] = 0;
                        }
                        else if (colorNo1 == "3"){
                            hitMap [0] = 1;
                            hitMap [1] = 1;
                            hitMap [2] = 0;
                        }
                        else if (colorNo1 == "4"){
                            hitMap [0] = 1;
                            hitMap [1] = 0;
                            hitMap [2] = 0;
                        }
                        else if (colorNo1 == "5"){
                            hitMap [0] = 1;
                            hitMap [1] = 0;
                            hitMap [2] = 1;
                        }
                        
                        if (colorNo2 == "1"){
                            hitMap [3] = 0;
                            hitMap [4] = 0;
                            hitMap [5] = 1;
                        }
                        else if (colorNo2 == "2"){
                            hitMap [3] = 0;
                            hitMap [4] = 1;
                            hitMap [5] = 0;
                        }
                        else if (colorNo2 == "3"){
                            hitMap [3] = 1;
                            hitMap [4] = 1;
                            hitMap [5] = 0;
                        }
                        else if (colorNo2 == "4"){
                            hitMap [3] = 1;
                            hitMap [4] = 0;
                            hitMap [5] = 0;
                        }
                        else if (colorNo2 == "5"){
                            hitMap [3] = 1;
                            hitMap [4] = 0;
                            hitMap [5] = 1;
                        }
                        
                        if (colorNo3 == "1"){
                            hitMap [6] = 0;
                            hitMap [7] = 0;
                            hitMap [8] = 1;
                        }
                        else if (colorNo3 == "2"){
                            hitMap [6] = 0;
                            hitMap [7] = 1;
                            hitMap [8] = 0;
                        }
                        else if (colorNo3 == "3"){
                            hitMap [6] = 1;
                            hitMap [7] = 1;
                            hitMap [8] = 0;
                        }
                        else if (colorNo3 == "4"){
                            hitMap [6] = 1;
                            hitMap [7] = 0;
                            hitMap [8] = 0;
                        }
                        else if (colorNo3 == "5"){
                            hitMap [6] = 1;
                            hitMap [7] = 0;
                            hitMap [8] = 1;
                        }
                        
                        for (int counter1 = imageXYLength-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                                value0 = uploadTempExp [1078+counter1*imageXYLength+counter2];
                                
                                if (value0 >= 0 && value0 < cutHoldDIC){
                                    value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                    
                                    if (value0 < 0) value0 = 0;
                                }
                                else{
                                    
                                    value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                    
                                    if (value0 > 255) value0 = 255;
                                }
                                
                                value1 = uploadTempExpCl1 [1078+counter1*imageXYLength+counter2];
                                
                                if (value1 < cutHold1) value1 = 0;
                                else{
                                    
                                    value1 = value1+(int)((value1-cutHold1)*levelHold1);
                                    
                                    if (value1 > 255) value1 = 255;
                                }
                                
                                value2 = uploadTempExpCl2 [1078+counter1*imageXYLength+counter2];
                                
                                if (value2 < cutHold2) value2 = 0;
                                else{
                                    
                                    value2 = value2+(int)((value2-cutHold2)*levelHold2);
                                    
                                    if (value2 > 255) value2 = 255;
                                }
                                
                                value3 = uploadTempExpCl3 [1078+counter1*imageXYLength+counter2];
                                
                                if (value3 < cutHold3) value3 = 0;
                                else{
                                    
                                    value3 = value3+(int)((value3-cutHold3)*levelHold3);
                                    
                                    if (value3 > 255) value3 = 255;
                                }
                                
                                if (statusHold1 == 0) value1 = 0;
                                if (statusHold2 == 0) value2 = 0;
                                if (statusHold3 == 0) value3 = 0;
                                
                                if (value1 <= 0 && value2 <= 0 && value3 <= 0){
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = 0;
                                }
                                else{
                                    
                                    if (value1 < 0) value1 = 0;
                                    if (value2 < 0) value2 = 0;
                                    if (value3 < 0) value3 = 0;
                                    
                                    hitR = 0;
                                    hitG = 0;
                                    hitB = 0;
                                    
                                    if (value1 > 0 && statusHold1 != 0){
                                        if (hitMap [0] != 0) hitR++;
                                        if (hitMap [1] != 0) hitG++;
                                        if (hitMap [2] != 0) hitB++;
                                    }
                                    
                                    if (value2 > 0 && statusHold2 != 0){
                                        if (hitMap [3] != 0) hitR++;
                                        if (hitMap [4] != 0) hitG++;
                                        if (hitMap [5] != 0) hitB++;
                                    }
                                    
                                    if (value3 > 0 && statusHold3 != 0){
                                        if (hitMap [6] != 0) hitR++;
                                        if (hitMap [7] != 0) hitG++;
                                        if (hitMap [8] != 0) hitB++;
                                    }
                                    
                                    colorHit1 = 0;
                                    colorHit2 = 0;
                                    colorHit3 = 0;
                                    
                                    if (hitR == 1){
                                        if (hitMap [0] != 0 && value1 > 0 ) colorHit1 = 1;
                                        if (hitMap [3] != 0 && value2 > 0 ) colorHit2 = 1;
                                        if (hitMap [6] != 0 && value3 > 0 ) colorHit3 = 1;
                                        
                                    }
                                    else if (hitR == 2){
                                        if (hitMap [0] != 0 && value1 > 0 ) colorHit1 = 0.5;
                                        if (hitMap [3] != 0 && value2 > 0 ) colorHit2 = 0.5;
                                        if (hitMap [6] != 0 && value3 > 0 ) colorHit3 = 0.5;
                                    }
                                    else if (hitR == 3){
                                        if (value1 > 0) colorHit1 = 0.33;
                                        if (value2 > 0) colorHit2 = 0.33;
                                        if (value3 > 0) colorHit3 = 0.33;
                                    }
                                    
                                    *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3));
                                    
                                    colorHit1 = 0;
                                    colorHit2 = 0;
                                    colorHit3 = 0;
                                    
                                    if (hitG == 1){
                                        if (hitMap [1] != 0 && value1 > 0 ) colorHit1 = 1;
                                        if (hitMap [4] != 0 && value2 > 0 ) colorHit2 = 1;
                                        if (hitMap [7] != 0 && value3 > 0 ) colorHit3 = 1;
                                    }
                                    else if (hitG == 2){
                                        if (hitMap [1] != 0 && value1 > 0 ) colorHit1 = 0.5;
                                        if (hitMap [4] != 0 && value2 > 0 ) colorHit2 = 0.5;
                                        if (hitMap [7] != 0 && value3 > 0 ) colorHit3 = 0.5;
                                    }
                                    else if (hitG == 3){
                                        if (hitMap [1] != 0 && value1 > 0 ) colorHit1 = 0.33;
                                        if (hitMap [4] != 0 && value2 > 0 ) colorHit2 = 0.33;
                                        if (hitMap [7] != 0 && value3 > 0 ) colorHit3 = 0.33;
                                    }
                                    
                                    *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3));
                                    
                                    colorHit1 = 0;
                                    colorHit2 = 0;
                                    colorHit3 = 0;
                                    
                                    if (hitB == 1){
                                        if (hitMap [2] != 0 && value1 > 0 ) colorHit1 = 1;
                                        if (hitMap [5] != 0 && value2 > 0 ) colorHit2 = 1;
                                        if (hitMap [8] != 0 && value3 > 0 ) colorHit3 = 1;
                                    }
                                    else if (hitB == 2){
                                        if (hitMap [2] != 0 && value1 > 0 ) colorHit1 = 0.5;
                                        if (hitMap [5] != 0 && value2 > 0 ) colorHit2 = 0.5;
                                        if (hitMap [8] != 0 && value3 > 0 ) colorHit3 = 0.5;
                                    }
                                    else if (hitB == 3){
                                        if (hitMap [2] != 0 && value1 > 0 ) colorHit1 = 0.33;
                                        if (hitMap [5] != 0 && value2 > 0 ) colorHit2 = 0.33;
                                        if (hitMap [8] != 0 && value3 > 0 ) colorHit3 = 0.33;
                                    }
                                    
                                    *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3));
                                    *bitmapData++ = 0;
                                }
                            }
                        }
                        
                        delete [] hitMap;
                    }
                }
                else{
                    
                    if (imageBmpTifFlag == 0){
                        unsigned long headPosition = 0;
                        
                        dataConversion [0] = uploadTempExp [0];
                        dataConversion [1] = uploadTempExp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTempExp [7];
                            dataConversion [1] = uploadTempExp [6];
                            dataConversion [2] = uploadTempExp [5];
                            dataConversion [3] = uploadTempExp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTempExp [4];
                            dataConversion [1] = uploadTempExp [5];
                            dataConversion [2] = uploadTempExp [6];
                            dataConversion [3] = uploadTempExp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                            value0 = uploadTempExp [counter1];
                            
                            if (value0 >= 0 && value0 < cutHoldDIC){
                                value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                
                                if (value0 < 0) value0 = 0;
                            }
                            else{
                                
                                value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                
                                if (value0 > 255) value0 = 255;
                            }
                            
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = 0;
                        }
                    }
                    else if (imageBmpTifFlag == 1){
                        for (int counter1 = imageXYLength-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                                value0 = uploadTempExp [1078+counter1*imageXYLength+counter2];
                                
                                if (value0 >= 0 && value0 < cutHoldDIC){
                                    value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                    
                                    if (value0 < 0) value0 = 0;
                                }
                                else{
                                    
                                    value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                    
                                    if (value0 > 255) value0 = 255;
                                }
                                
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = 0;
                            }
                        }
                    }
                }
            }
            else if (grayColorStatus == 1){
                int dataConversion [4];
                int endianType = 0;
                
                unsigned long headPosition = 0;
                
                dataConversion [0] = uploadTempExp [0];
                dataConversion [1] = uploadTempExp [1];
                
                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                else endianType = 0;
                
                headPosition = 0;
                
                if (endianType == 1){
                    dataConversion [0] = uploadTempExp [7];
                    dataConversion [1] = uploadTempExp [6];
                    dataConversion [2] = uploadTempExp [5];
                    dataConversion [3] = uploadTempExp [4];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                else if (endianType == 0){
                    dataConversion [0] = uploadTempExp [4];
                    dataConversion [1] = uploadTempExp [5];
                    dataConversion [2] = uploadTempExp [6];
                    dataConversion [3] = uploadTempExp [7];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                
                int value0 = 0;
                int value1 = 0;
                int value2 = 0;
                
                for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                    value0 = uploadTempExp [counter1];
                    value0 = (int)(value0*(double)levelHoldR);
                    
                    if (value0 > 255) value0 = 255;
                    
                    value1 = uploadTempExp [counter1+1];
                    value1 = (int)(value1*(double)levelHoldG);
                    
                    if (value1 > 255) value1 = 255;
                    
                    value2 = uploadTempExp [counter1+2];
                    value2 = (int)(value2*(double)levelHoldB);
                    
                    if (value2 > 255) value2 = 255;
                    
                    *bitmapData++ = (unsigned char)value0;
                    *bitmapData++ = (unsigned char)value1;
                    *bitmapData++ = (unsigned char)value2;
                    *bitmapData++ = 0;
                }
            }
        }
        else{
            
            if (refLoadStatus == 1){
                int dataConversion [4];
                int endianType = 0;
                
                unsigned long headPosition = 0;
                
                dataConversion [0] = uploadTempExpRef [0];
                dataConversion [1] = uploadTempExpRef [1];
                
                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                else endianType = 0;
                
                if (endianType == 1){
                    dataConversion [0] = uploadTempExpRef [7];
                    dataConversion [1] = uploadTempExpRef [6];
                    dataConversion [2] = uploadTempExpRef [5];
                    dataConversion [3] = uploadTempExpRef [4];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                else if (endianType == 0){
                    dataConversion [0] = uploadTempExpRef [4];
                    dataConversion [1] = uploadTempExpRef [5];
                    dataConversion [2] = uploadTempExpRef [6];
                    dataConversion [3] = uploadTempExpRef [7];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                
                int grayColorStatusColor = 0;
                
                if (headPosition-8 == (unsigned long)(imageXYLength*imageXYLength)) grayColorStatusColor = 0;
                else grayColorStatusColor = 1;
                
                if (grayColorStatusColor == 0){
                    int value0 = 0;
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                        value0 = uploadTempExpRef [counter1];
                        
                        if (value0 >= 0 && value0 < cutHoldDIC){
                            value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                            
                            if (value0 < 0) value0 = 0;
                        }
                        else{
                            
                            value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                            
                            if (value0 > 255) value0 = 255;
                        }
                        
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = 0;
                    }
                }
                else if (grayColorStatusColor == 1){
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                        value0 = uploadTempExpRef [counter1];
                        value0 = (int)(value0*(double)levelHoldR);
                        
                        if (value0 > 255) value0 = 255;
                        
                        value1 = uploadTempExpRef [counter1+1];
                        value1 = (int)(value1*(double)levelHoldG);
                        
                        if (value1 > 255) value1 = 255;
                        
                        value2 = uploadTempExpRef [counter1+2];
                        value2 = (int)(value2*(double)levelHoldB);
                        
                        if (value2 > 255) value2 = 255;
                        
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value1;
                        *bitmapData++ = (unsigned char)value2;
                        *bitmapData++ = 0;
                    }
                }
            }
            else if (refLoadStatus == 2){
                int dataConversion [4];
                int endianType = 0;
                
                unsigned long headPosition = 0;
                
                dataConversion [0] = uploadTempExpRef2 [0];
                dataConversion [1] = uploadTempExpRef2 [1];
                
                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                else endianType = 0;
                
                if (endianType == 1){
                    dataConversion [0] = uploadTempExpRef2 [7];
                    dataConversion [1] = uploadTempExpRef2 [6];
                    dataConversion [2] = uploadTempExpRef2 [5];
                    dataConversion [3] = uploadTempExpRef2 [4];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                else if (endianType == 0){
                    dataConversion [0] = uploadTempExpRef2 [4];
                    dataConversion [1] = uploadTempExpRef2 [5];
                    dataConversion [2] = uploadTempExpRef2 [6];
                    dataConversion [3] = uploadTempExpRef2 [7];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                
                int grayColorStatusRef2 = 0;
                
                if (headPosition-8 == (unsigned long)(imageXYLength*imageXYLength)) grayColorStatusRef2 = 0;
                else grayColorStatusRef2 = 1;
                
                if (grayColorStatusRef2 == 0){
                    int value0 = 0;
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                        value0 = uploadTempExpRef2 [counter1];
                        
                        if (value0 >= 0 && value0 < cutHoldDIC){
                            value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                            
                            if (value0 < 0) value0 = 0;
                        }
                        else{
                            
                            value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                            
                            if (value0 > 255) value0 = 255;
                        }
                        
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = 0;
                    }
                }
                else if (grayColorStatusRef2 == 1){
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                        value0 = uploadTempExpRef2 [counter1];
                        value0 = (int)(value0*(double)levelHoldR);
                        
                        if (value0 > 255) value0 = 255;
                        
                        value1 = uploadTempExpRef2 [counter1+1];
                        value1 = (int)(value1*(double)levelHoldG);
                        
                        if (value1 > 255) value1 = 255;
                        
                        value2 = uploadTempExpRef2 [counter1+2];
                        value2 = (int)(value2*(double)levelHoldB);
                        
                        if (value2 > 255) value2 = 255;
                        
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value1;
                        *bitmapData++ = (unsigned char)value2;
                        *bitmapData++ = 0;
                    }
                }
            }
            else if (refLoadStatus == 3){
                int dataConversion [4];
                int endianType = 0;
                
                unsigned long headPosition = 0;
                
                dataConversion [0] = uploadTempExpRef3 [0];
                dataConversion [1] = uploadTempExpRef3 [1];
                
                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                else endianType = 0;
                
                if (endianType == 1){
                    dataConversion [0] = uploadTempExpRef3 [7];
                    dataConversion [1] = uploadTempExpRef3 [6];
                    dataConversion [2] = uploadTempExpRef3 [5];
                    dataConversion [3] = uploadTempExpRef3 [4];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                else if (endianType == 0){
                    dataConversion [0] = uploadTempExpRef3 [4];
                    dataConversion [1] = uploadTempExpRef3 [5];
                    dataConversion [2] = uploadTempExpRef3 [6];
                    dataConversion [3] = uploadTempExpRef3 [7];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                
                int grayColorStatusRef3 = 0;
                
                if (headPosition-8 == (unsigned long)(imageXYLength*imageXYLength)) grayColorStatusRef3 = 0;
                else grayColorStatusRef3 = 1;
                
                if (grayColorStatusRef3 == 0){
                    int value0 = 0;
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                        value0 = uploadTempExpRef3 [counter1];
                        
                        if (value0 >= 0 && value0 < cutHoldDIC){
                            value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                            
                            if (value0 < 0) value0 = 0;
                        }
                        else{
                            
                            value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                            
                            if (value0 > 255) value0 = 255;
                        }
                        
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = 0;
                    }
                }
                else if (grayColorStatusRef3 == 1){
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                        value0 = uploadTempExpRef3 [counter1];
                        value0 = (int)(value0*(double)levelHoldR);
                        
                        if (value0 > 255) value0 = 255;
                        
                        value1 = uploadTempExpRef3 [counter1+1];
                        value1 = (int)(value1*(double)levelHoldG);
                        
                        if (value1 > 255) value1 = 255;
                        
                        value2 = uploadTempExpRef3 [counter1+2];
                        value2 = (int)(value2*(double)levelHoldB);
                        
                        if (value2 > 255) value2 = 255;
                        
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value1;
                        *bitmapData++ = (unsigned char)value2;
                        *bitmapData++ = 0;
                    }
                }
            }
        }
        
        exportImage = [[NSImage alloc] initWithSize:NSMakeSize(imageXYLength, imageXYLength)];
        [exportImage addRepresentation:bitmapRepsCR];
        
        xPositionExport = 0;
        yPositionExport = 0;
        
        //------Window size and Position re-adjust------
        int vertical = 700+78;
        int horizontal = 700;
        
        windowWidthExport = imageXYLength/(double)horizontal;
        windowHeightExport = imageXYLength/(double)(vertical-78);
        
        timingEx2 = 1;
    }
    
    exportMainTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
}

-(void)display{
    if (timingEx2 == 1) timingEx2 = 2;
    else if (timingEx2 < 2) timingEx2++;
    else if (timingEx2 == 2){
        [self setNeedsDisplay:YES];
        
        if (timingEx2 == 6) timingEx2 = 0;
    }
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)mouseDown:(NSEvent *)event{
    if (imageProgressFlag == 0){
        NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDownExport = clickPoint.x;
        yPointDownExport = clickPoint.y;
    }
}

-(void)mouseUp:(NSEvent *)event{
    if (imageProgressFlag == 0){
        xPositionExport = xPositionExport+xPositionMoveExport;
        yPositionExport = yPositionExport+yPositionMoveExport;
        xPositionMoveExport = 0;
        yPositionMoveExport = 0;
        mouseDragFlag = 0;
        [self setNeedsDisplay:YES];
    }
}

- (void)mouseDragged:(NSEvent *)event{
    if (imageProgressFlag == 0){
        NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDragExport = clickPoint.x;
        yPointDragExport = clickPoint.y;
        xPositionMoveExport = (xPointDownExport-xPointDragExport)*windowWidthExport/(double)(magnificationExport*0.1);
        yPositionMoveExport = (yPointDownExport-yPointDragExport)*windowHeightExport/(double)(magnificationExport*0.1);
        mouseDragFlag = 1;
        [self setNeedsDisplay:YES];
    }
}

-(void)keyDown:(NSEvent *)event{
    if (imageProgressFlag == 0){
        int keyCode = [event keyCode];
        int proceedFlag = 0;
        
        //------Snap------
        if (keyCode == 1){
            timingEx = 1;
            
            string extension = to_string(filePositionExp);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
            mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Movie_Quant";
            mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string nameString = "Export_Images-MQ";
            
            DIR *dir;
            struct dirent *dent;
            
            string entry;
            string extractString;
            int maxEntryNo = 0;
            
            dir = opendir(resultSavePath2.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(nameString) != -1){
                        extractString = entry.substr(entry.find("MQ")+2);
                        
                        if ((int)extractString.find(".tif") == -1) extractString = extractString.substr(0, entry.find(".tif"));
                        
                        if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                    }
                }
                
                closedir(dir);
            }
            
            maxEntryNo++;
            
            if (dotDisplayMode == 2 && densityDiameterHold > 0){
                if (circleAreaHoldStatus == 1){
                    for (int counter1 = 0; counter1 < densityDiameterPrev+2; counter1++) delete [] circleAreaHold [counter1];
                    delete [] circleAreaHold;
                }
                
                densityDiameterPrev = densityDiameterHold;
                
                circleAreaHold = new int *[densityDiameterHold+2];
                
                for (int counter1 = 0; counter1 < densityDiameterHold+2; counter1++){
                    circleAreaHold [counter1] = new int [densityDiameterHold+2];
                }
                
                circleAreaHoldStatus = 1;
                
                for (int counter1 = 0; counter1 < densityDiameterHold+2; counter1++){
                    for (int counter2 = 0; counter2 <densityDiameterHold+2; counter2++){
                        circleAreaHold [counter1][counter2] = 0;
                    }
                }
                
                int center2 = (densityDiameterHold/2)+1;
                double radius = densityDiameterHold/(double)2;
                double diameterCal = 0;
                
                for (int counter1 = 0; counter1 < densityDiameterHold+2; counter1++){
                    for (int counter2 = 0; counter2 <densityDiameterHold+2; counter2++){
                        diameterCal = (counter1-center2)*(counter1-center2)+(counter2-center2)*(counter2-center2);
                        
                        if (sqrt(diameterCal) <= radius) circleAreaHold [counter1][counter2] = 1;
                    }
                }
                
                //for (int counterA = 0; counterA < densityDiameterHold+2; counterA++){
                //    for (int counterB = 0; counterB < densityDiameterHold+2; counterB++) cout<<" "<<circleAreaHold [counterA][counterB];
                //    cout<<" circleAreaHold "<<counterA<<endl;
                //}
            }
            
            displayModeSelect = 1;
            
            displayImageSavePath = resultSavePath2+"/"+nameString+to_string(maxEntryNo)+".tif";
            
            proceedFlag = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        
        //------Original size------
        if (keyCode == 6){
            proceedFlag = 1;
            xPositionExport = 0;
            yPositionExport = 0;
            xPositionAdjustExport = 0;
            yPositionAdjustExport = 0;
            magnificationExport = 10;
        }
        
        //------Magnification Magnify------
        if (keyCode == 125){
            if (magnificationExport >= 12 && magnificationExport <= 500){
                if (magnificationExport-10 < 12) magnificationExport = 10;
                else magnificationExport = magnificationExport-10;
                
                xPositionAdjustExport = -1*(imageXYLength/(double)(magnificationExport*0.1)-imageXYLength)/(double)2;
                yPositionAdjustExport = -1*(imageXYLength/(double)(magnificationExport*0.1)-imageXYLength)/(double)2;
                
                proceedFlag = 1;
            }
        }
        
        //------MagnificationReduction------
        if (keyCode == 126){
            if (magnificationExport >= 10 && magnificationExport <= 498){
                if (magnificationExport+10 > 498) magnificationExport = 498;
                else magnificationExport = magnificationExport+10;
                
                xPositionAdjustExport = (imageXYLength-imageXYLength/(double)(magnificationExport*0.1))/(double)2;
                yPositionAdjustExport = (imageXYLength-imageXYLength/(double)(magnificationExport*0.1))/(double)2;
                
                proceedFlag = 1;
            }
        }
        
        //------Magnification space bar------
        if (keyCode == 49){
            magnificationExport = (int)(200/((double)(50/(double)imageXYLength)*700)*10);
            xPositionAdjustExport = (imageXYLength-imageXYLength/(double)(magnificationExport*0.1))/(double)2;
            yPositionAdjustExport = (imageXYLength-imageXYLength/(double)(magnificationExport*0.1))/(double)2;
            
            proceedFlag = 1;
        }
        
        //------Image Back------
        if (keyCode == 124){
            filePositionExp++;
            
            if (maxImageNo < filePositionExp) filePositionExp--;
            
            string timeDisplayTemp = fileList [(filePositionExp-1)*7];
            timeDisplayTemp = timeDisplayTemp.substr(8, 4);
            
            timePointHoldExp = atoi(timeDisplayTemp.c_str());
            
            if ((timePointHoldExp-1)*25+25 < areaDataHoldCount){
                boxXLengthExp = (int)(arrayAreaDataHold [(timePointHoldExp-1)*25+6]);
                boxYLengthExp = (int)(arrayAreaDataHold [(timePointHoldExp-1)*25+7]);
                boxXPositionExp = arrayAreaDataHold [(timePointHoldExp-1)*25+8];
                boxYPositionExp = arrayAreaDataHold [(timePointHoldExp-1)*25+9];
                
                dotNumberCurrentExp = (int)arrayAreaDataHold [(timePointHoldExp-1)*25+5];
            }
            else{
                
                boxXLengthExp = 0;
                boxYLengthExp = 0;
                boxXPositionExp = 0;
                boxYPositionExp = 0;
                dotNumberCurrentExp = 0;
            }
            
            proceedFlag = 1;
        }
        
        //------Image Forward------
        if (keyCode == 123){
            filePositionExp--;
            
            if (filePositionExp <= 0) filePositionExp = 1;
            
            string timeDisplayTemp = fileList [(filePositionExp-1)*7];
            timeDisplayTemp = timeDisplayTemp.substr(8, 4);
            
            timePointHoldExp = atoi(timeDisplayTemp.c_str());
            
            if ((timePointHoldExp-1)*25+25 < areaDataHoldCount){
                boxXLengthExp = (int)(arrayAreaDataHold [(timePointHoldExp-1)*25+6]);
                boxYLengthExp = (int)(arrayAreaDataHold [(timePointHoldExp-1)*25+7]);
                boxXPositionExp = arrayAreaDataHold [(timePointHoldExp-1)*25+8];
                boxYPositionExp = arrayAreaDataHold [(timePointHoldExp-1)*25+9];
                
                dotNumberCurrentExp = (int)arrayAreaDataHold [(timePointHoldExp-1)*25+5];
            }
            else{
                
                boxXLengthExp = 0;
                boxYLengthExp = 0;
                boxXPositionExp = 0;
                boxYPositionExp = 0;
                dotNumberCurrentExp = 0;
            }
            
            proceedFlag = 1;
        }
        
        //-----Reload-------
        if (keyCode == 15){
            string timeDisplayTemp = fileList [(filePositionExp-1)*7];
            timeDisplayTemp = timeDisplayTemp.substr(8, 4);
            
            timePointHoldExp = atoi(timeDisplayTemp.c_str());
            
            if ((timePointHoldExp-1)*25+25 < areaDataHoldCount){
                boxXLengthExp = (int)(arrayAreaDataHold [(timePointHoldExp-1)*25+6]);
                boxYLengthExp = (int)(arrayAreaDataHold [(timePointHoldExp-1)*25+7]);
                boxXPositionExp = arrayAreaDataHold [(timePointHoldExp-1)*25+8];
                boxYPositionExp = arrayAreaDataHold [(timePointHoldExp-1)*25+9];
                
                dotNumberCurrentExp = (int)arrayAreaDataHold [(timePointHoldExp-1)*25+5];
            }
            else{
                
                boxXLengthExp = 0;
                boxYLengthExp = 0;
                boxXPositionExp = 0;
                boxYPositionExp = 0;
                dotNumberCurrentExp = 0;
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        
        //-----Synchronize-------
        if (keyCode == 8){
            filePositionExp = filePosition;
            
            string timeDisplayTemp = fileList [(filePositionExp-1)*7];
            timeDisplayTemp = timeDisplayTemp.substr(8, 4);
            
            timePointHoldExp = atoi(timeDisplayTemp.c_str());
            
            if ((timePointHoldExp-1)*25+25 < areaDataHoldCount){
                boxXLengthExp = (int)(arrayAreaDataHold [(timePointHoldExp-1)*25+6]);
                boxYLengthExp = (int)(arrayAreaDataHold [(timePointHoldExp-1)*25+7]);
                boxXPositionExp = arrayAreaDataHold [(timePointHoldExp-1)*25+8];
                boxYPositionExp = arrayAreaDataHold [(timePointHoldExp-1)*25+9];
                
                dotNumberCurrentExp = (int)arrayAreaDataHold [(timePointHoldExp-1)*25+5];
            }
            else{
                
                boxXLengthExp = 0;
                boxYLengthExp = 0;
                boxXPositionExp = 0;
                boxYPositionExp = 0;
                dotNumberCurrentExp = 0;
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        
        if (keyCode == 123 || keyCode == 124 || keyCode == 15 || keyCode == 8){
            timingEx = 1;
            
            proceedFlag = 1;
            
            string imageMoviePath1 = imageDisplayPath+"/"+fileList [(filePositionExp-1)*7];
            
            ifstream fin;
            
            if (uploadTempExpStatus == 0){
                uploadTempExp = new uint8_t [uploadTempFileSize+50];
                uploadTempExpStatus = 1;
            }
            else{
                
                delete [] uploadTempExp;
                uploadTempExp = new uint8_t [uploadTempFileSize+50];
            }
            
            fin.open(imageMoviePath1.c_str(), ios::in | ios::binary);
            
            fin.read((char*)uploadTempExp, uploadTempFileSize+50);
            fin.close();
            
            if (fileList [(filePositionExp-1)*7+1] != ""){
                imageMoviePath1 = imageDisplayPath+"/"+fileList [(filePositionExp-1)*7+1];
                
                if (uploadTempExpStatusCl1 == 0){
                    uploadTempExpCl1 = new uint8_t [uploadTempFileSize+50];
                    uploadTempExpStatusCl1 = 1;
                }
                else{
                    
                    delete [] uploadTempExpCl1;
                    uploadTempExpCl1 = new uint8_t [uploadTempFileSize+50];
                }
                
                colorFlagExp1 = 1;
                
                fin.open(imageMoviePath1.c_str(), ios::in | ios::binary);
                
                fin.read((char*)uploadTempExpCl1, uploadTempFileSize+50);
                fin.close();
                
                if (fileList [(filePositionExp-1)*7+2] != ""){
                    imageMoviePath1 = imageDisplayPath+"/"+fileList [(filePositionExp-1)*7+2];
                    
                    if (uploadTempExpStatusCl2 == 0){
                        uploadTempExpCl2 = new uint8_t [uploadTempFileSize+50];
                        uploadTempExpStatusCl2 = 1;
                    }
                    else{
                        
                        delete [] uploadTempExpCl2;
                        uploadTempExpCl2 = new uint8_t [uploadTempFileSize+50];
                    }
                    
                    colorFlagExp2 = 1;
                    
                    fin.open(imageMoviePath1.c_str(), ios::in | ios::binary);
                    
                    fin.read((char*)uploadTempExpCl2, uploadTempFileSize+50);
                    fin.close();
                    
                    if (fileList [(filePositionExp-1)*7+3] != ""){
                        imageMoviePath1 = imageDisplayPath+"/"+fileList [(filePositionExp-1)*7+3];
                        
                        if (uploadTempExpStatusCl3 == 0){
                            uploadTempExpCl3 = new uint8_t [uploadTempFileSize+50];
                            uploadTempExpStatusCl3 = 1;
                        }
                        else{
                            
                            delete [] uploadTempExpCl3;
                            uploadTempExpCl3 = new uint8_t [uploadTempFileSize+50];
                        }
                        
                        colorFlagExp3 = 1;
                        
                        fin.open(imageMoviePath1.c_str(), ios::in | ios::binary);
                        
                        fin.read((char*)uploadTempExpCl3, uploadTempFileSize+50);
                        fin.close();
                        
                        if (fileList [(filePositionExp-1)*7+4] != ""){
                            imageMoviePath1 = imageDisplayPath+"/"+fileList [(filePositionExp-1)*7+4];
                            
                            if (uploadTempExpStatusCl4 == 0){
                                uploadTempExpCl4 = new uint8_t [uploadTempFileSize+50];
                                uploadTempExpStatusCl4 = 1;
                            }
                            else{
                                
                                delete [] uploadTempExpCl4;
                                uploadTempExpCl4 = new uint8_t [uploadTempFileSize+50];
                            }
                            
                            colorFlagExp4 = 1;
                            
                            fin.open(imageMoviePath1.c_str(), ios::in | ios::binary);
                            
                            fin.read((char*)uploadTempExpCl4, uploadTempFileSize+50);
                            fin.close();
                            
                            if (fileList [(filePositionExp-1)*7+5] != ""){
                                imageMoviePath1 = imageDisplayPath+"/"+fileList [(filePositionExp-1)*7+5];
                                
                                if (uploadTempExpStatusCl5 == 0){
                                    uploadTempExpCl5 = new uint8_t [uploadTempFileSize+50];
                                    uploadTempExpStatusCl5 = 1;
                                }
                                else{
                                    
                                    delete [] uploadTempExpCl5;
                                    uploadTempExpCl5 = new uint8_t [uploadTempFileSize+50];
                                }
                                
                                colorFlagExp5 = 1;
                                
                                fin.open(imageMoviePath1.c_str(), ios::in | ios::binary);
                                
                                fin.read((char*)uploadTempExpCl5, uploadTempFileSize+50);
                                fin.close();
                                
                                if (fileList [(filePositionExp-1)*7+6] != ""){
                                    imageMoviePath1 = imageDisplayPath+"/"+fileList [(filePositionExp-1)*7+6];
                                    
                                    if (uploadTempExpStatusCl6 == 0){
                                        uploadTempExpCl6 = new uint8_t [uploadTempFileSize+50];
                                        uploadTempExpStatusCl6 = 1;
                                    }
                                    else{
                                        
                                        delete [] uploadTempExpCl6;
                                        uploadTempExpCl6 = new uint8_t [uploadTempFileSize+50];
                                    }
                                    
                                    colorFlagExp6 = 1;
                                    
                                    fin.open(imageMoviePath1.c_str(), ios::in | ios::binary);
                                    
                                    fin.read((char*)uploadTempExpCl6, uploadTempFileSize+50);
                                    fin.close();
                                }
                                else colorFlagExp6 = 0;
                            }
                            else{
                                
                                colorFlagExp5 = 0;
                                colorFlagExp6 = 0;
                            }
                        }
                        else{
                            
                            colorFlagExp4 = 0;
                            colorFlagExp5 = 0;
                            colorFlagExp6 = 0;
                        }
                    }
                    else{
                        
                        colorFlagExp3 = 0;
                        colorFlagExp4 = 0;
                        colorFlagExp5 = 0;
                        colorFlagExp6 = 0;
                    }
                }
                else{
                    
                    colorFlagExp2 = 0;
                    colorFlagExp3 = 0;
                    colorFlagExp4 = 0;
                    colorFlagExp5 = 0;
                    colorFlagExp6 = 0;
                }
            }
            else{
                
                colorFlagExp1 = 0;
                colorFlagExp2 = 0;
                colorFlagExp3 = 0;
                colorFlagExp4 = 0;
                colorFlagExp5 = 0;
                colorFlagExp6 = 0;
            }
            
            imageMoviePath1 = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Phase"+"/"+fileList2 [filePositionExp-1];
            
            struct stat sizeOfFile;
            
            if (stat(imageMoviePath1.c_str(), &sizeOfFile) == 0){
                if (uploadTempExpStatusRef == 0){
                    uploadTempExpRef = new uint8_t [uploadTempRefFileSize1+50];
                    uploadTempExpStatusRef2 = 1;
                    uploadTempExpRef2 = new uint8_t [uploadTempRefFileSize2+50];
                    uploadTempExpStatusRef2 = 1;
                    uploadTempExpRef3 = new uint8_t [uploadTempRefFileSize3+50];
                    uploadTempExpStatusRef3 = 1;
                    
                    uploadTempExpLoadRef2 = 0;
                    uploadTempExpLoadRef3 = 0;
                }
                else{
                    
                    delete [] uploadTempExpRef;
                    uploadTempExpRef = new uint8_t [uploadTempRefFileSize1+50];
                    delete [] uploadTempExpRef2;
                    uploadTempExpRef2 = new uint8_t [uploadTempRefFileSize2+50];
                    delete [] uploadTempExpRef3;
                    uploadTempExpRef3 = new uint8_t [uploadTempRefFileSize3+50];
                    
                    uploadTempExpLoadRef2 = 0;
                    uploadTempExpLoadRef3 = 0;
                }
                
                fin.open(imageMoviePath1.c_str(), ios::in | ios::binary);
                
                fin.read((char*)uploadTempExpRef, uploadTempRefFileSize1+50);
                fin.close();
                
                imageMoviePath1 = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Ref1"+"/"+fileList2 [filePositionExp-1];
                
                if (stat(imageMoviePath1.c_str(), &sizeOfFile) == 0){
                    fin.open(imageMoviePath1.c_str(), ios::in | ios::binary);
                    
                    fin.read((char*)uploadTempExpRef2, uploadTempRefFileSize2+50);
                    fin.close();
                    
                    uploadTempExpLoadRef2 = 1;
                }
                
                imageMoviePath1 = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Ref2"+"/"+fileList2 [filePositionExp-1];
                
                if (stat(imageMoviePath1.c_str(), &sizeOfFile) == 0){
                    fin.open(imageMoviePath1.c_str(), ios::in | ios::binary);
                    
                    fin.read((char*)uploadTempExpRef3, uploadTempRefFileSize3+50);
                    fin.close();
                    
                    uploadTempExpLoadRef3 = 1;
                }
                
                string extension = to_string(filePositionExp);
                
                if (extension.length() == 1) extension = "000"+extension;
                else if (extension.length() == 2) extension = "00"+extension;
                else if (extension.length() == 3) extension = "0"+extension;
                
                string connectDataPath = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Processed/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_MasterData";
                string connectDataRevPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_MasterData";
                
                long sizeForCopy = 0;
                long size1 = 0;
                long size2 = 0;
                int checkFlag = 0;
                
                for (int counter1 = 0; counter1 < 6; counter1++){
                    sizeForCopy = 0;
                    
                    if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    else if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        if (counter1 == 0) size1 = sizeForCopy;
                        else if (counter1 == 1) size2 = sizeForCopy;
                        else if (counter1 == 2){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                                break;
                            }
                            else{
                                
                                size1 = 0;
                                size2 = 0;
                                usleep (50000);
                            }
                        }
                        else if (counter1 == 3) size1 = sizeForCopy;
                        else if (counter1 == 4) size2 = sizeForCopy;
                        else if (counter1 == 5){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                            }
                        }
                    }
                }
                
                if (checkFlag == 1){
                    int errorFlag = 0;
                    
                    if (positionExportStatus == 1) delete [] arrayPositionExport;
                    arrayPositionExport = new int [sizeForCopy+50];
                    positionExportCount = 0;
                    positionExportStatus = 1;
                    
                    if (gravityCenterExportStatus == 1) delete [] arrayGravityCenterExport;
                    arrayGravityCenterExport = new int [sizeForCopy+50];
                    gravityCenterExportCount = 0;
                    gravityCenterExportStatus = 1;
                    
                    fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        int finData [17];
                        
                        uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTempA, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 || (finData [0] = uploadTempA [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTempA, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 || (finData [0] = uploadTempA [sizeForCopy-12]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTempA, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 || (finData [0] = uploadTempA [sizeForCopy-12]) != 0){
                                    errorFlag = 1;
                                }
                            }
                        }
                        
                        fin.close();
                        
                        if (errorFlag == 0){
                            unsigned long readPosition = 0;
                            int stepCount = 0;
                            
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTempA [readPosition], readPosition++;
                                    finData [1] = uploadTempA [readPosition], readPosition++; //--1
                                    finData [2] = uploadTempA [readPosition], readPosition++;
                                    finData [3] = uploadTempA [readPosition], readPosition++; //--2
                                    finData [4] = uploadTempA [readPosition], readPosition++; //--3
                                    finData [5] = uploadTempA [readPosition], readPosition++;
                                    finData [6] = uploadTempA [readPosition], readPosition++;
                                    finData [7] = uploadTempA [readPosition], readPosition++; //--4
                                    finData [8] = uploadTempA [readPosition], readPosition++; //--+/- flag
                                    finData [9] = uploadTempA [readPosition], readPosition++;
                                    finData [10] = uploadTempA [readPosition], readPosition++;
                                    finData [11] = uploadTempA [readPosition], readPosition++;
                                    finData [12] = uploadTempA [readPosition], readPosition++; //--5
                                    finData [13] = uploadTempA [readPosition], readPosition++; //--6
                                    finData [14] = uploadTempA [readPosition], readPosition++;
                                    finData [15] = uploadTempA [readPosition], readPosition++;
                                    finData [16] = uploadTempA [readPosition], readPosition++; //--7
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                    
                                    if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                    else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                    
                                    finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                    else{
                                        
                                        arrayPositionExport [positionExportCount] = finData [1], positionExportCount++;
                                        arrayPositionExport [positionExportCount] = finData [3], positionExportCount++;
                                        arrayPositionExport [positionExportCount] = finData [4], positionExportCount++;
                                        arrayPositionExport [positionExportCount] = finData [7], positionExportCount++;
                                        arrayPositionExport [positionExportCount] = finData [12], positionExportCount++;
                                        arrayPositionExport [positionExportCount] = finData [13], positionExportCount++;
                                        arrayPositionExport [positionExportCount] = finData [16], positionExportCount++;
                                    }
                                }
                                else if (stepCount == 1){
                                    finData [0] = uploadTempA [readPosition], readPosition++;
                                    finData [1] = uploadTempA [readPosition], readPosition++; //--1
                                    finData [2] = uploadTempA [readPosition], readPosition++;
                                    finData [3] = uploadTempA [readPosition], readPosition++; //--2
                                    finData [4] = uploadTempA [readPosition], readPosition++;
                                    finData [5] = uploadTempA [readPosition], readPosition++;
                                    finData [6] = uploadTempA [readPosition], readPosition++; //--3
                                    finData [7] = uploadTempA [readPosition], readPosition++; //--4
                                    finData [8] = uploadTempA [readPosition], readPosition++;
                                    finData [9] = uploadTempA [readPosition], readPosition++;
                                    finData [10] = uploadTempA [readPosition], readPosition++; //--5
                                    finData [11] = uploadTempA [readPosition], readPosition++; //--6
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                    finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                    else{
                                        
                                        arrayGravityCenterExport [gravityCenterExportCount] = finData [1], gravityCenterExportCount++;
                                        arrayGravityCenterExport [gravityCenterExportCount] = finData [3], gravityCenterExportCount++;
                                        arrayGravityCenterExport [gravityCenterExportCount] = finData [6], gravityCenterExportCount++;
                                        arrayGravityCenterExport [gravityCenterExportCount] = finData [7], gravityCenterExportCount++;
                                        arrayGravityCenterExport [gravityCenterExportCount] = finData [10], gravityCenterExportCount++;
                                        arrayGravityCenterExport [gravityCenterExportCount] = finData [11], gravityCenterExportCount++;
                                        
                                        arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = finData [1], gravityCenterExportCorrectCount++;
                                        arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = finData [3], gravityCenterExportCorrectCount++;
                                        arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = finData [6], gravityCenterExportCorrectCount++;
                                        arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = finData [7], gravityCenterExportCorrectCount++;
                                        arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = finData [10], gravityCenterExportCorrectCount++;
                                        arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = finData [11], gravityCenterExportCorrectCount++;
                                    }
                                }
                                
                            } while (stepCount != 3);
                        }
                        
                        delete [] uploadTempA;
                    }
                    else{
                        
                        fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            int finData [11];
                            
                            uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                            fin.read((char*)uploadTempA, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 ){
                                        errorFlag = 1;
                                    }
                                }
                            }
                            
                            fin.close();
                            
                            if (errorFlag == 0){
                                unsigned long readPosition = 0;
                                int stepCount = 0;
                                
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTempA [readPosition], readPosition++;
                                        finData [1] = uploadTempA [readPosition], readPosition++; //--2
                                        finData [2] = uploadTempA [readPosition], readPosition++;
                                        finData [3] = uploadTempA [readPosition], readPosition++; //--2
                                        finData [4] = uploadTempA [readPosition], readPosition++; //--1
                                        finData [5] = uploadTempA [readPosition], readPosition++;
                                        finData [6] = uploadTempA [readPosition], readPosition++;
                                        finData [7] = uploadTempA [readPosition], readPosition++; //--3
                                        finData [8] = uploadTempA [readPosition], readPosition++; //--1
                                        finData [9] = uploadTempA [readPosition], readPosition++;
                                        
                                        finData [1] = finData [0]*256+finData [1];
                                        finData [3] = finData [2]*256+finData [3];
                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                        
                                        if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                        else{
                                            
                                            arrayPositionExport [positionExportCount] = finData [1], positionExportCount++; //------X position------
                                            arrayPositionExport [positionExportCount] = finData [3], positionExportCount++; //------Y position------
                                            arrayPositionExport [positionExportCount] = finData [4], positionExportCount++; //------Value------
                                            arrayPositionExport [positionExportCount] = finData [7], positionExportCount++; //------Connect No------
                                            arrayPositionExport [positionExportCount] = 0, positionExportCount++; //------Cell No------
                                            arrayPositionExport [positionExportCount] = 0, positionExportCount++; //------Status------
                                            arrayPositionExport [positionExportCount] = 0, positionExportCount++; //------Lineage no------
                                        }
                                    }
                                    else if (stepCount == 1){
                                        finData [0] = uploadTempA [readPosition], readPosition++;
                                        finData [1] = uploadTempA [readPosition], readPosition++;
                                        finData [2] = uploadTempA [readPosition], readPosition++; //--1
                                        finData [3] = uploadTempA [readPosition], readPosition++; //--2
                                        finData [4] = uploadTempA [readPosition], readPosition++; //--3
                                        finData [5] = uploadTempA [readPosition], readPosition++;
                                        finData [6] = uploadTempA [readPosition], readPosition++;
                                        finData [7] = uploadTempA [readPosition], readPosition++; //--4
                                        finData [8] = uploadTempA [readPosition], readPosition++;
                                        finData [9] = uploadTempA [readPosition], readPosition++; //--5
                                        finData [10] = uploadTempA [readPosition], readPosition++; //--6
                                        
                                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                        finData [9] = finData [8]*256+finData [9];
                                        
                                        if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                    }
                                    else if (stepCount == 2){
                                        finData [0] = uploadTempA [readPosition], readPosition++;
                                        finData [1] = uploadTempA [readPosition], readPosition++; //--1
                                        finData [2] = uploadTempA [readPosition], readPosition++;
                                        finData [3] = uploadTempA [readPosition], readPosition++; //--2
                                        finData [4] = uploadTempA [readPosition], readPosition++;
                                        finData [5] = uploadTempA [readPosition], readPosition++;
                                        finData [6] = uploadTempA [readPosition], readPosition++; //--3
                                        finData [7] = uploadTempA [readPosition], readPosition++; //--4
                                        finData [8] = uploadTempA [readPosition], readPosition++;
                                        finData [9] = uploadTempA [readPosition], readPosition++;
                                        finData [10] = uploadTempA [readPosition], readPosition++; //--5
                                        
                                        finData [1] = finData [0]*256+finData [1];
                                        finData [3] = finData [2]*256+finData [3];
                                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                        finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                        
                                        if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                        else{
                                            
                                            arrayGravityCenterExport [gravityCenterExportCount] = finData [1], gravityCenterExportCount++;
                                            arrayGravityCenterExport [gravityCenterExportCount] = finData [3], gravityCenterExportCount++;
                                            arrayGravityCenterExport [gravityCenterExportCount] = finData [6], gravityCenterExportCount++;
                                            arrayGravityCenterExport [gravityCenterExportCount] = finData [7], gravityCenterExportCount++;
                                            arrayGravityCenterExport [gravityCenterExportCount] = finData [10], gravityCenterExportCount++;
                                            arrayGravityCenterExport [gravityCenterExportCount] = 0, gravityCenterExportCount++;
                                            
                                            arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = finData [1], gravityCenterExportCorrectCount++;
                                            arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = finData [3], gravityCenterExportCorrectCount++;
                                            arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = finData [6], gravityCenterExportCorrectCount++;
                                            arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = finData [7], gravityCenterExportCorrectCount++;
                                            arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = finData [10], gravityCenterExportCorrectCount++;
                                            arrayGravityCenterExportHold [gravityCenterExportCorrectCount] = 0, gravityCenterExportCorrectCount++;
                                        }
                                    }
                                    
                                } while (stepCount != 3);
                            }
                            
                            delete [] uploadTempA;
                        }
                    }
                    
                    //------Master Data Status UpLoad------
                    if (errorFlag == 0){
                        string connectStatusDataPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_Status";
                        
                        sizeForCopy = 0;
                        
                        if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (timeSelectedExportStatus == 1) delete [] arrayTimeSelectedExport;
                        
                        if (sizeForCopy != 0){
                            arrayTimeSelectedExport = new int [sizeForCopy+500];
                        }
                        else arrayTimeSelectedExport = new int [(gravityCenterExportCount/6)*10+500];
                        
                        timeSelectedExportCount = 0;
                        timeSelectedExportStatus = 1;
                        
                        fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            int finData [19];
                            
                            uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                            fin.read((char*)uploadTempA, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 || (finData [0] = uploadTempA [sizeForCopy-12]) != 0 || (finData [0] = uploadTempA [sizeForCopy-13]) != 0 || (finData [0] = uploadTempA [sizeForCopy-14]) != 0 || (finData [0] = uploadTempA [sizeForCopy-15]) != 0 || (finData [0] = uploadTempA [sizeForCopy-16]) != 0 || (finData [0] = uploadTempA [sizeForCopy-17]) != 0 || (finData [0] = uploadTempA [sizeForCopy-18]) != 0 || (finData [0] = uploadTempA [sizeForCopy-19]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTempA, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 || (finData [0] = uploadTempA [sizeForCopy-12]) != 0 || (finData [0] = uploadTempA [sizeForCopy-13]) != 0 || (finData [0] = uploadTempA [sizeForCopy-14]) != 0 || (finData [0] = uploadTempA [sizeForCopy-15]) != 0 || (finData [0] = uploadTempA [sizeForCopy-16]) != 0 || (finData [0] = uploadTempA [sizeForCopy-17]) != 0 || (finData [0] = uploadTempA [sizeForCopy-18]) != 0 || (finData [0] = uploadTempA [sizeForCopy-19]) != 0){
                                    errorFlag = 1;
                                }
                            }
                            
                            fin.close();
                            
                            if (errorFlag == 0){
                                unsigned long readPosition = 0;
                                int stepCount = 0;
                                
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTempA [readPosition], readPosition++; //--1 Status
                                        finData [1] = uploadTempA [readPosition], readPosition++;
                                        finData [2] = uploadTempA [readPosition], readPosition++;
                                        finData [3] = uploadTempA [readPosition], readPosition++; //--3 Prev connect
                                        finData [4] = uploadTempA [readPosition], readPosition++;
                                        finData [5] = uploadTempA [readPosition], readPosition++;
                                        finData [6] = uploadTempA [readPosition], readPosition++; //--4 Start position
                                        finData [7] = uploadTempA [readPosition], readPosition++;
                                        finData [8] = uploadTempA [readPosition], readPosition++; //--5 Cut no
                                        finData [9] = uploadTempA [readPosition], readPosition++; //--6 Ch2
                                        finData [10] = uploadTempA [readPosition], readPosition++; //--7 Ch3
                                        finData [11] = uploadTempA [readPosition], readPosition++; //--8 Ch4
                                        finData [12] = uploadTempA [readPosition], readPosition++; //--9 Ch5
                                        finData [13] = uploadTempA [readPosition], readPosition++;
                                        finData [14] = uploadTempA [readPosition], readPosition++;
                                        finData [15] = uploadTempA [readPosition], readPosition++; //--10 Connect no.
                                        finData [16] = uploadTempA [readPosition], readPosition++;
                                        finData [17] = uploadTempA [readPosition], readPosition++;
                                        finData [18] = uploadTempA [readPosition], readPosition++; //--11 Ling no.
                                        
                                        finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                        finData [8] = finData [7]*256+finData [8];
                                        finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                                        finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                                        
                                        if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                                        else{
                                            
                                            arrayTimeSelectedExport [timeSelectedExportCount] = finData [0], timeSelectedExportCount++; //------Selected, removed, eliminated status------
                                            arrayTimeSelectedExport [timeSelectedExportCount] = finData [3], timeSelectedExportCount++; //------When new line is created, enter line number which creates------
                                            arrayTimeSelectedExport [timeSelectedExportCount] = finData [6], timeSelectedExportCount++; //------PositionRevise Start------
                                            arrayTimeSelectedExport [timeSelectedExportCount] = finData [8], timeSelectedExportCount++; //------Cut line number------
                                            arrayTimeSelectedExport [timeSelectedExportCount] = finData [9], timeSelectedExportCount++; //------X Start------
                                            arrayTimeSelectedExport [timeSelectedExportCount] = finData [10], timeSelectedExportCount++; //------X End------
                                            arrayTimeSelectedExport [timeSelectedExportCount] = finData [11], timeSelectedExportCount++; //------Y Start------
                                            arrayTimeSelectedExport [timeSelectedExportCount] = finData [12], timeSelectedExportCount++; //------Y End------
                                            arrayTimeSelectedExport [timeSelectedExportCount] = finData [15], timeSelectedExportCount++; //------Connect------
                                            arrayTimeSelectedExport [timeSelectedExportCount] = finData [18], timeSelectedExportCount++; //------Lineage------
                                        }
                                    }
                                    
                                } while (stepCount != 3);
                            }
                            
                            delete [] uploadTempA;
                        }
                        else{
                            
                            for (int counter1 = 0; counter1 < gravityCenterExportCount/6; counter1++){ //------Counter number corresponds to connect No------
                                arrayTimeSelectedExport [timeSelectedExportCount] = 1, timeSelectedExportCount++; //------Selected, removed, eliminated status------
                                arrayTimeSelectedExport [timeSelectedExportCount] = 0, timeSelectedExportCount++; //------When new line is created, enter line number which creates------
                                arrayTimeSelectedExport [timeSelectedExportCount] = 0, timeSelectedExportCount++; //------PositionRevise Start------
                                arrayTimeSelectedExport [timeSelectedExportCount] = 0, timeSelectedExportCount++; //------Cut line number------
                                arrayTimeSelectedExport [timeSelectedExportCount] = 0, timeSelectedExportCount++; //------X Start------
                                arrayTimeSelectedExport [timeSelectedExportCount] = 0, timeSelectedExportCount++; //------X End------
                                arrayTimeSelectedExport [timeSelectedExportCount] = 0, timeSelectedExportCount++; //------Y Start------
                                arrayTimeSelectedExport [timeSelectedExportCount] = 0, timeSelectedExportCount++; //------Y End------
                                arrayTimeSelectedExport [timeSelectedExportCount] = counter1+1, timeSelectedExportCount++; //------Connect------
                                arrayTimeSelectedExport [timeSelectedExportCount] = 0, timeSelectedExportCount++; //------Lineage------
                            }
                            
                            int valueTemp = 0;
                            
                            for (int counter1 = 0; counter1 < positionExportCount/7; counter1++){
                                if (arrayPositionExport [counter1*7+3] != valueTemp){
                                    valueTemp = arrayPositionExport [counter1*7+3];
                                    arrayTimeSelectedExport [(valueTemp-1)*10+2] = counter1;
                                    
                                    if (arrayPositionExport [counter1*7+5] == 0){
                                        arrayTimeSelectedExport [(valueTemp-1)*10] = 0;
                                    }
                                }
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < timeSelectedExportCount/10; counter1++){
                            if (arrayTimeSelectedExport [counter1*10] == 2) arrayTimeSelectedExport [counter1*10] = 0;
                            else if (arrayTimeSelectedExport [counter1*10] == 7) arrayTimeSelectedExport [counter1*10] = 1;
                        }
                        
                        if (errorFlag == 0){
                            string mapPath = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Processed/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_Map";
                            string revisedMapPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+extension+"_"+analysisNameHold+"_"+treatNameHold+"_RevisedMap";
                            
                            if (revisedWorkingMapExpStatus == 1){
                                for (int counter1 = 0; counter1 < imageXYLength+1; counter1++){
                                    delete [] revisedWorkingMapExp [counter1];
                                }
                                
                                delete [] revisedWorkingMapExp;
                            }
                            
                            revisedWorkingMapExp = new int *[imageXYLength+1];
                            
                            for (int counter1 = 0; counter1 < imageXYLength+1; counter1++){
                                revisedWorkingMapExp [counter1] = new int [imageXYLength+1];
                            }
                            
                            int yDimensionCount;
                            int xDimensionCount;
                            int readBit [4];
                            int pixData;
                            int totalSize = imageXYLength*imageXYLength*4;
                            
                            fin.open(revisedMapPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                uint8_t *upload2 = new uint8_t [totalSize+50];
                                
                                fin.read((char*)upload2, totalSize+1);
                                fin.close();
                                
                                yDimensionCount = 0;
                                xDimensionCount = 0;
                                
                                for (int counter1 = 0; counter1 < totalSize; counter1 = counter1+4){
                                    readBit [0] = upload2[counter1];
                                    readBit [1] = upload2[counter1+1];
                                    readBit [2] = upload2[counter1+2];
                                    readBit [3] = upload2[counter1+3];
                                    
                                    pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                                    
                                    for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                                        revisedWorkingMapExp [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                                    }
                                    
                                    if (xDimensionCount == imageXYLength){
                                        xDimensionCount = 0;
                                        yDimensionCount++;
                                        
                                        if (yDimensionCount == imageXYLength){
                                            break;
                                        }
                                    }
                                }
                                
                                delete [] upload2;
                            }
                            else{
                                
                                fin.open(mapPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    uint8_t *upload2 = new uint8_t [totalSize+50];
                                    
                                    fin.read((char*)upload2, totalSize+1);
                                    fin.close();
                                    
                                    yDimensionCount = 0;
                                    xDimensionCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < totalSize; counter1 = counter1+4){
                                        readBit [0] = upload2[counter1];
                                        readBit [1] = upload2[counter1+1];
                                        readBit [2] = upload2[counter1+2];
                                        readBit [3] = upload2[counter1+3];
                                        
                                        pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                                        
                                        for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                                            revisedWorkingMapExp [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                                        }
                                        
                                        if (xDimensionCount == imageXYLength){
                                            xDimensionCount = 0;
                                            yDimensionCount++;
                                            
                                            if (yDimensionCount == imageXYLength){
                                                break;
                                            }
                                        }
                                    }
                                    
                                    delete [] upload2;
                                }
                            }
                            
                            NSBitmapImageRep *bitmapRepsCR = nil;
                            bitmapRepsCR = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageXYLength pixelsHigh:imageXYLength bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageXYLength*4 bitsPerPixel:32];
                            
                            unsigned char *bitmapData = [bitmapRepsCR bitmapData];
                            
                            if (phaseStatus == 0){
                                if (grayColorStatus == 0){
                                    int value0 = 0;
                                    int value1 = 0;
                                    int value2 = 0;
                                    int value3 = 0;
                                    int value4 = 0;
                                    int value5 = 0;
                                    int value6 = 0;
                                    
                                    int dataConversion [4];
                                    int endianType = 0;
                                    
                                    double colorHit1 = 0;
                                    double colorHit2 = 0;
                                    double colorHit3 = 0;
                                    double colorHit4 = 0;
                                    double colorHit5 = 0;
                                    double colorHit6 = 0;
                                    
                                    int hitR = 0;
                                    int hitG = 0;
                                    int hitB = 0;
                                    
                                    if (statusHold1 != 0 || statusHold2 != 0 || statusHold3 != 0 || statusHold4 != 0 || statusHold5 != 0 || statusHold6 != 0){
                                        if (imageBmpTifFlag == 0){
                                            double *hitMap = new double [20];
                                            
                                            if (colorNo1 == "1"){
                                                hitMap [0] = 0;
                                                hitMap [1] = 0;
                                                hitMap [2] = 1;
                                            }
                                            else if (colorNo1 == "2"){
                                                hitMap [0] = 0;
                                                hitMap [1] = 1;
                                                hitMap [2] = 0;
                                            }
                                            else if (colorNo1 == "3"){
                                                hitMap [0] = 1;
                                                hitMap [1] = 1;
                                                hitMap [2] = 0;
                                            }
                                            else if (colorNo1 == "4"){
                                                hitMap [0] = 1;
                                                hitMap [1] = 0;
                                                hitMap [2] = 0;
                                            }
                                            else if (colorNo1 == "5"){
                                                hitMap [0] = 1;
                                                hitMap [1] = 0;
                                                hitMap [2] = 1;
                                            }
                                            else if (colorNo1 == "6"){
                                                hitMap [0] = 0;
                                                hitMap [1] = 1;
                                                hitMap [2] = 1;
                                            }
                                            else if (colorNo1 == "7"){
                                                hitMap [0] = 1;
                                                hitMap [1] = 0.674;
                                                hitMap [2] = 0;
                                            }
                                            else if (colorNo1 == "8"){
                                                hitMap [0] = 0.627;
                                                hitMap [1] = 0.125;
                                                hitMap [2] = 0.941;
                                            }
                                            else if (colorNo1 == "9"){
                                                hitMap [0] = 0.529;
                                                hitMap [1] = 0.808;
                                                hitMap [2] = 0.922;
                                            }
                                            
                                            if (colorNo2 == "1"){
                                                hitMap [3] = 0;
                                                hitMap [4] = 0;
                                                hitMap [5] = 1;
                                            }
                                            else if (colorNo2 == "2"){
                                                hitMap [3] = 0;
                                                hitMap [4] = 1;
                                                hitMap [5] = 0;
                                            }
                                            else if (colorNo2 == "3"){
                                                hitMap [3] = 1;
                                                hitMap [4] = 1;
                                                hitMap [5] = 0;
                                            }
                                            else if (colorNo2 == "4"){
                                                hitMap [3] = 1;
                                                hitMap [4] = 0;
                                                hitMap [5] = 0;
                                            }
                                            else if (colorNo2 == "5"){
                                                hitMap [3] = 1;
                                                hitMap [4] = 0;
                                                hitMap [5] = 1;
                                            }
                                            else if (colorNo2 == "6"){
                                                hitMap [3] = 0;
                                                hitMap [4] = 1;
                                                hitMap [5] = 1;
                                            }
                                            else if (colorNo2 == "7"){
                                                hitMap [3] = 1;
                                                hitMap [4] = 0.674;
                                                hitMap [5] = 0;
                                            }
                                            else if (colorNo2 == "8"){
                                                hitMap [3] = 0.627;
                                                hitMap [4] = 0.125;
                                                hitMap [5] = 0.941;
                                            }
                                            else if (colorNo2 == "9"){
                                                hitMap [3] = 0.529;
                                                hitMap [4] = 0.808;
                                                hitMap [5] = 0.922;
                                            }
                                            
                                            if (colorNo3 == "1"){
                                                hitMap [6] = 0;
                                                hitMap [7] = 0;
                                                hitMap [8] = 1;
                                            }
                                            else if (colorNo3 == "2"){
                                                hitMap [6] = 0;
                                                hitMap [7] = 1;
                                                hitMap [8] = 0;
                                            }
                                            else if (colorNo3 == "3"){
                                                hitMap [6] = 1;
                                                hitMap [7] = 1;
                                                hitMap [8] = 0;
                                            }
                                            else if (colorNo3 == "4"){
                                                hitMap [6] = 1;
                                                hitMap [7] = 0;
                                                hitMap [8] = 0;
                                            }
                                            else if (colorNo3 == "5"){
                                                hitMap [6] = 1;
                                                hitMap [7] = 0;
                                                hitMap [8] = 1;
                                            }
                                            else if (colorNo3 == "6"){
                                                hitMap [6] = 0;
                                                hitMap [7] = 1;
                                                hitMap [8] = 1;
                                            }
                                            else if (colorNo3 == "7"){
                                                hitMap [6] = 1;
                                                hitMap [7] = 0.674;
                                                hitMap [8] = 0;
                                            }
                                            else if (colorNo3 == "8"){
                                                hitMap [6] = 0.627;
                                                hitMap [7] = 0.125;
                                                hitMap [8] = 0.941;
                                            }
                                            else if (colorNo3 == "9"){
                                                hitMap [6] = 0.529;
                                                hitMap [7] = 0.808;
                                                hitMap [8] = 0.922;
                                            }
                                            
                                            if (colorNo4 == "1"){
                                                hitMap [9] = 0;
                                                hitMap [10] = 0;
                                                hitMap [11] = 1;
                                            }
                                            else if (colorNo4 == "2"){
                                                hitMap [9] = 0;
                                                hitMap [10] = 1;
                                                hitMap [11] = 0;
                                            }
                                            else if (colorNo4 == "3"){
                                                hitMap [9] = 1;
                                                hitMap [10] = 1;
                                                hitMap [11] = 0;
                                            }
                                            else if (colorNo4 == "4"){
                                                hitMap [9] = 1;
                                                hitMap [10] = 0;
                                                hitMap [11] = 0;
                                            }
                                            else if (colorNo4 == "5"){
                                                hitMap [9] = 1;
                                                hitMap [10] = 0;
                                                hitMap [11] = 1;
                                            }
                                            else if (colorNo4 == "6"){
                                                hitMap [9] = 0;
                                                hitMap [10] = 1;
                                                hitMap [11] = 1;
                                            }
                                            else if (colorNo4 == "7"){
                                                hitMap [9] = 1;
                                                hitMap [10] = 0.674;
                                                hitMap [11] = 0;
                                            }
                                            else if (colorNo4 == "8"){
                                                hitMap [9] = 0.627;
                                                hitMap [10] = 0.125;
                                                hitMap [11] = 0.941;
                                            }
                                            else if (colorNo4 == "9"){
                                                hitMap [9] = 0.529;
                                                hitMap [10] = 0.808;
                                                hitMap [11] = 0.922;
                                            }
                                            
                                            if (colorNo5 == "1"){
                                                hitMap [12] = 0;
                                                hitMap [13] = 0;
                                                hitMap [14] = 1;
                                            }
                                            else if (colorNo5 == "2"){
                                                hitMap [12] = 0;
                                                hitMap [13] = 1;
                                                hitMap [14] = 0;
                                            }
                                            else if (colorNo5 == "3"){
                                                hitMap [12] = 1;
                                                hitMap [13] = 1;
                                                hitMap [14] = 0;
                                            }
                                            else if (colorNo5 == "4"){
                                                hitMap [12] = 1;
                                                hitMap [13] = 0;
                                                hitMap [14] = 0;
                                            }
                                            else if (colorNo5 == "5"){
                                                hitMap [12] = 1;
                                                hitMap [13] = 0;
                                                hitMap [14] = 1;
                                            }
                                            else if (colorNo5 == "6"){
                                                hitMap [12] = 0;
                                                hitMap [13] = 1;
                                                hitMap [14] = 1;
                                            }
                                            else if (colorNo5 == "7"){
                                                hitMap [12] = 1;
                                                hitMap [13] = 0.674;
                                                hitMap [14] = 0;
                                            }
                                            else if (colorNo5 == "8"){
                                                hitMap [12] = 0.627;
                                                hitMap [13] = 0.125;
                                                hitMap [14] = 0.941;
                                            }
                                            else if (colorNo5 == "9"){
                                                hitMap [12] = 0.529;
                                                hitMap [13] = 0.808;
                                                hitMap [14] = 0.922;
                                            }
                                            
                                            if (colorNo6 == "1"){
                                                hitMap [15] = 0;
                                                hitMap [16] = 0;
                                                hitMap [17] = 1;
                                            }
                                            else if (colorNo6 == "2"){
                                                hitMap [15] = 0;
                                                hitMap [16] = 1;
                                                hitMap [17] = 0;
                                            }
                                            else if (colorNo6 == "3"){
                                                hitMap [15] = 1;
                                                hitMap [16] = 1;
                                                hitMap [17] = 0;
                                            }
                                            else if (colorNo6 == "4"){
                                                hitMap [15] = 1;
                                                hitMap [16] = 0;
                                                hitMap [17] = 0;
                                            }
                                            else if (colorNo6 == "5"){
                                                hitMap [15] = 1;
                                                hitMap [16] = 0;
                                                hitMap [17] = 1;
                                            }
                                            else if (colorNo6 == "6"){
                                                hitMap [15] = 0;
                                                hitMap [16] = 1;
                                                hitMap [17] = 1;
                                            }
                                            else if (colorNo6 == "7"){
                                                hitMap [15] = 1;
                                                hitMap [16] = 0.674;
                                                hitMap [17] = 0;
                                            }
                                            else if (colorNo6 == "8"){
                                                hitMap [15] = 0.627;
                                                hitMap [16] = 0.125;
                                                hitMap [17] = 0.941;
                                            }
                                            else if (colorNo6 == "9"){
                                                hitMap [15] = 0.529;
                                                hitMap [16] = 0.808;
                                                hitMap [17] = 0.922;
                                            }
                                            
                                            unsigned long headPosition = 0;
                                            
                                            dataConversion [0] = uploadTempExp [0];
                                            dataConversion [1] = uploadTempExp [1];
                                            
                                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                            else endianType = 0;
                                            
                                            headPosition = 0;
                                            
                                            if (endianType == 1){
                                                dataConversion [0] = uploadTempExp [7];
                                                dataConversion [1] = uploadTempExp [6];
                                                dataConversion [2] = uploadTempExp [5];
                                                dataConversion [3] = uploadTempExp [4];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            else if (endianType == 0){
                                                dataConversion [0] = uploadTempExp [4];
                                                dataConversion [1] = uploadTempExp [5];
                                                dataConversion [2] = uploadTempExp [6];
                                                dataConversion [3] = uploadTempExp [7];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            
                                            for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                                value1 = 0;
                                                value2 = 0;
                                                value3 = 0;
                                                value4 = 0;
                                                value5 = 0;
                                                value6 = 0;
                                                
                                                value0 = uploadTempExp [counter1];
                                                
                                                if (value0 >= 0 && value0 < cutHoldDIC){
                                                    value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                                    
                                                    if (value0 < 0) value0 = 0;
                                                }
                                                else{
                                                    
                                                    value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                                    
                                                    if (value0 > 255) value0 = 255;
                                                }
                                                
                                                if (statusHold1 == 1 && colorFlag1 == 1){
                                                    value1 = uploadTempExpCl1 [counter1];
                                                    
                                                    if (value1 < cutHold1) value1 = 0;
                                                    else{
                                                        
                                                        value1 = value1+(int)((value1-cutHold1)*levelHold1);
                                                        
                                                        if (value1 > 255) value1 = 255;
                                                    }
                                                }
                                                
                                                if (statusHold2 == 1 && colorFlag2 == 1){
                                                    value2 = uploadTempExpCl2 [counter1];
                                                    
                                                    if (value2 < cutHold2) value2 = 0;
                                                    else{
                                                        
                                                        value2 = value2+(int)((value2-cutHold2)*levelHold2);
                                                        
                                                        if (value2 > 255) value2 = 255;
                                                    }
                                                }
                                                
                                                if (statusHold3 == 1 && colorFlag3 == 1){
                                                    value3 = uploadTempExpCl3 [counter1];
                                                    
                                                    if (value3 < cutHold3) value3 = 0;
                                                    else{
                                                        
                                                        value3 = value3+(int)((value3-cutHold3)*levelHold3);
                                                        
                                                        if (value3 > 255) value3 = 255;
                                                    }
                                                }
                                                
                                                if (statusHold4 == 1 && colorFlag4 == 1){
                                                    value4 = uploadTempExpCl4 [counter1];
                                                    
                                                    if (value4 < cutHold4) value4 = 0;
                                                    else{
                                                        
                                                        value4 = value4+(int)((value4-cutHold4)*levelHold4);
                                                        
                                                        if (value4 > 255) value4 = 255;
                                                    }
                                                }
                                                
                                                if (statusHold5 == 1 && colorFlag5 == 1){
                                                    value5 = uploadTempExpCl5 [counter1];
                                                    
                                                    if (value5 < cutHold5) value5 = 0;
                                                    else{
                                                        
                                                        value5 = value5+(int)((value5-cutHold5)*levelHold5);
                                                        
                                                        if (value5 > 255) value5 = 255;
                                                    }
                                                }
                                                
                                                if (statusHold6 == 1 && colorFlag6 == 1){
                                                    value6 = uploadTempExpCl6 [counter1];
                                                    
                                                    if (value6 < cutHold6) value6 = 0;
                                                    else{
                                                        
                                                        value6 = value6+(int)((value6-cutHold6)*levelHold6);
                                                        
                                                        if (value6 > 255) value6 = 255;
                                                    }
                                                }
                                                
                                                if (statusHold1 == 0) value1 = 0;
                                                if (statusHold2 == 0) value2 = 0;
                                                if (statusHold3 == 0) value3 = 0;
                                                if (statusHold4 == 0) value4 = 0;
                                                if (statusHold5 == 0) value5 = 0;
                                                if (statusHold6 == 0) value6 = 0;
                                                
                                                if (value1 <= 0 && value2 <= 0 && value3 <= 0 && value4 <= 0 && value5 <= 0 && value6 <= 0){
                                                    *bitmapData++ = (unsigned char)value0;
                                                    *bitmapData++ = (unsigned char)value0;
                                                    *bitmapData++ = (unsigned char)value0;
                                                    *bitmapData++ = 0;
                                                }
                                                else{
                                                    
                                                    if (value1 < 0) value1 = 0;
                                                    if (value2 < 0) value2 = 0;
                                                    if (value3 < 0) value3 = 0;
                                                    if (value4 < 0) value4 = 0;
                                                    if (value5 < 0) value5 = 0;
                                                    if (value6 < 0) value6 = 0;
                                                    
                                                    hitR = 0;
                                                    hitG = 0;
                                                    hitB = 0;
                                                    
                                                    if (value1 > 0){
                                                        if (hitMap [0] != 0) hitR++;
                                                        if (hitMap [1] != 0) hitG++;
                                                        if (hitMap [2] != 0) hitB++;
                                                    }
                                                    
                                                    if (value2 > 0){
                                                        if (hitMap [3] != 0) hitR++;
                                                        if (hitMap [4] != 0) hitG++;
                                                        if (hitMap [5] != 0) hitB++;
                                                    }
                                                    
                                                    if (value3 > 0){
                                                        if (hitMap [6] != 0) hitR++;
                                                        if (hitMap [7] != 0) hitG++;
                                                        if (hitMap [8] != 0) hitB++;
                                                    }
                                                    
                                                    if (value4 > 0){
                                                        if (hitMap [9] != 0) hitR++;
                                                        if (hitMap [10] != 0) hitG++;
                                                        if (hitMap [11] != 0) hitB++;
                                                    }
                                                    
                                                    if (value5 > 0){
                                                        if (hitMap [12] != 0) hitR++;
                                                        if (hitMap [13] != 0) hitG++;
                                                        if (hitMap [14] != 0) hitB++;
                                                    }
                                                    
                                                    if (value6 > 0){
                                                        if (hitMap [15] != 0) hitR++;
                                                        if (hitMap [16] != 0) hitG++;
                                                        if (hitMap [17] != 0) hitB++;
                                                    }
                                                    
                                                    colorHit1 = 0;
                                                    colorHit2 = 0;
                                                    colorHit3 = 0;
                                                    colorHit4 = 0;
                                                    colorHit5 = 0;
                                                    colorHit6 = 0;
                                                    
                                                    if (hitR == 1){
                                                        if (hitMap [0] != 0 && value1 > 0) colorHit1 = 1;
                                                        if (hitMap [3] != 0 && value2 > 0) colorHit2 = 1;
                                                        if (hitMap [6] != 0 && value3 > 0) colorHit3 = 1;
                                                        if (hitMap [9] != 0 && value4 > 0) colorHit4 = 1;
                                                        if (hitMap [12] != 0 && value5 > 0) colorHit5 = 1;
                                                        if (hitMap [15] != 0 && value6 > 0) colorHit6 = 1;
                                                    }
                                                    else if (hitR == 2){
                                                        if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.5;
                                                        if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.5;
                                                        if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.5;
                                                        if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.5;
                                                        if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.5;
                                                        if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.5;
                                                    }
                                                    else if (hitR == 3){
                                                        if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.33;
                                                        if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.33;
                                                        if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.33;
                                                        if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.33;
                                                        if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.33;
                                                        if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.33;
                                                    }
                                                    else if (hitR == 4){
                                                        if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.25;
                                                        if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.25;
                                                        if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.25;
                                                        if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.25;
                                                        if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.25;
                                                        if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.25;
                                                    }
                                                    else if (hitR == 5){
                                                        if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.2;
                                                        if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.2;
                                                        if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.2;
                                                        if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.2;
                                                        if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.2;
                                                        if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.2;
                                                    }
                                                    else if (hitR == 6){
                                                        if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.13;
                                                        if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.13;
                                                        if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.13;
                                                        if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.13;
                                                        if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.13;
                                                        if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.13;
                                                    }
                                                    
                                                    if (value1 > 0 && colorNo1 == "7") colorHit1 = colorHit1*0.647;
                                                    else if (value1 > 0 && colorNo1 == "8") colorHit1 = colorHit1*0.627;
                                                    else if (value1 > 0 && colorNo1 == "9") colorHit1 = colorHit1*0.529;
                                                    
                                                    if (value2 > 0 && colorNo2 == "7") colorHit2 = colorHit2*0.647;
                                                    else if (value2 > 0 && colorNo2 == "8") colorHit2 = colorHit2*0.627;
                                                    else if (value2 > 0 && colorNo2 == "9") colorHit2 = colorHit2*0.529;
                                                    
                                                    if (value3 > 0 && colorNo3 == "7") colorHit3 = colorHit3*0.647;
                                                    else if (value3 > 0 && colorNo3 == "8") colorHit3 = colorHit3*0.627;
                                                    else if (value3 > 0 && colorNo3 == "9") colorHit3 = colorHit3*0.529;
                                                    
                                                    if (value4 > 0 && colorNo4 == "7") colorHit4 = colorHit4*0.647;
                                                    else if (value4 > 0 && colorNo4 == "8") colorHit4 = colorHit4*0.627;
                                                    else if (value4 > 0 && colorNo4 == "9") colorHit4 = colorHit4*0.529;
                                                    
                                                    if (value5 > 0 && colorNo5 == "7") colorHit5 = colorHit5*0.647;
                                                    else if (value5 > 0 && colorNo5 == "8") colorHit5 = colorHit5*0.627;
                                                    else if (value5 > 0 && colorNo5 == "9") colorHit5 = colorHit5*0.529;
                                                    
                                                    if (value6 > 0 && colorNo6 == "7") colorHit6 = colorHit6*0.647;
                                                    else if (value6 > 0 && colorNo6 == "8") colorHit6 = colorHit6*0.627;
                                                    else if (value6 > 0 && colorNo6 == "9") colorHit6 = colorHit6*0.529;
                                                    
                                                    *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3+value4*(double)colorHit4+value5*(double)colorHit5+value6*(double)colorHit6));
                                                    
                                                    colorHit1 = 0;
                                                    colorHit2 = 0;
                                                    colorHit3 = 0;
                                                    colorHit4 = 0;
                                                    colorHit5 = 0;
                                                    colorHit6 = 0;
                                                    
                                                    if (hitG == 1){
                                                        if (hitMap [1] != 0 && value1 > 0) colorHit1 = 1;
                                                        if (hitMap [4] != 0 && value2 > 0) colorHit2 = 1;
                                                        if (hitMap [7] != 0 && value3 > 0) colorHit3 = 1;
                                                        if (hitMap [10] != 0 && value4 > 0) colorHit4 = 1;
                                                        if (hitMap [13] != 0 && value5 > 0) colorHit5 = 1;
                                                        if (hitMap [16] != 0 && value6 > 0) colorHit6 = 1;
                                                    }
                                                    else if (hitG == 2){
                                                        if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.5;
                                                        if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.5;
                                                        if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.5;
                                                        if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.5;
                                                        if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.5;
                                                        if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.5;
                                                    }
                                                    else if (hitG == 3){
                                                        if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.33;
                                                        if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.33;
                                                        if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.33;
                                                        if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.33;
                                                        if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.33;
                                                        if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.33;
                                                    }
                                                    else if (hitG == 4){
                                                        if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.25;
                                                        if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.25;
                                                        if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.25;
                                                        if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.25;
                                                        if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.25;
                                                        if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.25;
                                                    }
                                                    else if (hitG == 5){
                                                        if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.2;
                                                        if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.2;
                                                        if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.2;
                                                        if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.2;
                                                        if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.2;
                                                        if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.2;
                                                    }
                                                    else if (hitG == 6){
                                                        if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.13;
                                                        if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.13;
                                                        if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.13;
                                                        if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.13;
                                                        if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.13;
                                                        if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.13;
                                                    }
                                                    
                                                    if (value1 > 0 && colorNo1 == "8") colorHit1 = colorHit1*0.125;
                                                    else if (value1 > 0 && colorNo1 == "9") colorHit1 = colorHit1*0.808;
                                                    
                                                    if (value2 > 0 && colorNo2 == "8") colorHit2 = colorHit2*0.125;
                                                    else if (value2 > 0 && colorNo2 == "9") colorHit2 = colorHit2*0.808;
                                                    
                                                    if (value3 > 0 && colorNo3 == "8") colorHit3 = colorHit3*0.125;
                                                    else if (value3 > 0 && colorNo3 == "9") colorHit3 = colorHit3*0.808;
                                                    
                                                    if (value4 > 0 && colorNo4 == "8") colorHit4 = colorHit4*0.125;
                                                    else if (value4 > 0 && colorNo4 == "9") colorHit4 = colorHit4*0.808;
                                                    
                                                    if (value5 > 0 && colorNo5 == "8") colorHit5 = colorHit5*0.125;
                                                    else if (value5 > 0 && colorNo5 == "9") colorHit5 = colorHit5*0.808;
                                                    
                                                    if (value6 > 0 && colorNo6 == "8") colorHit6 = colorHit6*0.125;
                                                    else if (value6 > 0 && colorNo6 == "9") colorHit6 = colorHit6*0.808;
                                                    
                                                    *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3+value4*(double)colorHit4+value5*(double)colorHit5+value6*(double)colorHit6));
                                                    
                                                    colorHit1 = 0;
                                                    colorHit2 = 0;
                                                    colorHit3 = 0;
                                                    colorHit4 = 0;
                                                    colorHit5 = 0;
                                                    colorHit6 = 0;
                                                    
                                                    if (hitB == 1){
                                                        if (hitMap [2] != 0 && value1 > 0) colorHit1 = 1;
                                                        if (hitMap [5] != 0 && value2 > 0) colorHit2 = 1;
                                                        if (hitMap [8] != 0 && value3 > 0) colorHit3 = 1;
                                                        if (hitMap [11] != 0 && value4 > 0) colorHit4 = 1;
                                                        if (hitMap [14] != 0 && value5 > 0) colorHit5 = 1;
                                                        if (hitMap [17] != 0 && value6 > 0) colorHit6 = 1;
                                                    }
                                                    else if (hitB == 2){
                                                        if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.5;
                                                        if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.5;
                                                        if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.5;
                                                        if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.5;
                                                        if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.5;
                                                        if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.5;
                                                    }
                                                    else if (hitB == 3){
                                                        if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.33;
                                                        if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.33;
                                                        if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.33;
                                                        if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.33;
                                                        if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.33;
                                                        if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.33;
                                                    }
                                                    else if (hitB == 4){
                                                        if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.25;
                                                        if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.25;
                                                        if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.25;
                                                        if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.25;
                                                        if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.25;
                                                        if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.25;
                                                    }
                                                    else if (hitB == 5){
                                                        if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.2;
                                                        if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.2;
                                                        if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.2;
                                                        if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.2;
                                                        if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.2;
                                                        if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.2;
                                                    }
                                                    else if (hitB == 6){
                                                        if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.13;
                                                        if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.13;
                                                        if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.13;
                                                        if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.13;
                                                        if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.13;
                                                        if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.13;
                                                    }
                                                    
                                                    if (value1 > 0 && colorNo1 == "8") colorHit1 = colorHit1*0.941;
                                                    else if (value1 > 0 && colorNo1 == "9") colorHit1 = colorHit1*0.922;
                                                    
                                                    if (value2 > 0 && colorNo2 == "8") colorHit2 = colorHit2*0.941;
                                                    else if (value2 > 0 && colorNo2 == "9") colorHit2 = colorHit2*0.922;
                                                    
                                                    if (value3 > 0 && colorNo3 == "8") colorHit3 = colorHit3*0.941;
                                                    else if (value3 > 0 && colorNo3 == "9") colorHit3 = colorHit3*0.922;
                                                    
                                                    if (value4 > 0 && colorNo4 == "8") colorHit4 = colorHit4*0.941;
                                                    else if (value4 > 0 && colorNo4 == "9") colorHit4 = colorHit4*0.922;
                                                    
                                                    if (value5 > 0 && colorNo5 == "8") colorHit5 = colorHit5*0.941;
                                                    else if (value5 > 0 && colorNo5 == "9") colorHit5 = colorHit5*0.922;
                                                    
                                                    if (value6 > 0 && colorNo6 == "8") colorHit6 = colorHit6*0.941;
                                                    else if (value6 > 0 && colorNo6 == "9") colorHit6 = colorHit6*0.922;
                                                    
                                                    *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3+value4*(double)colorHit4+value5*(double)colorHit5+value6*(double)colorHit6));
                                                    *bitmapData++ = 0;
                                                }
                                            }
                                            
                                            delete [] hitMap;
                                        }
                                        else if (imageBmpTifFlag == 1){
                                            double *hitMap = new double [20];
                                            
                                            if (colorNo1 == "1"){
                                                hitMap [0] = 0;
                                                hitMap [1] = 0;
                                                hitMap [2] = 1;
                                            }
                                            else if (colorNo1 == "2"){
                                                hitMap [0] = 0;
                                                hitMap [1] = 1;
                                                hitMap [2] = 0;
                                            }
                                            else if (colorNo1 == "3"){
                                                hitMap [0] = 1;
                                                hitMap [1] = 1;
                                                hitMap [2] = 0;
                                            }
                                            else if (colorNo1 == "4"){
                                                hitMap [0] = 1;
                                                hitMap [1] = 0;
                                                hitMap [2] = 0;
                                            }
                                            else if (colorNo1 == "5"){
                                                hitMap [0] = 1;
                                                hitMap [1] = 0;
                                                hitMap [2] = 1;
                                            }
                                            
                                            if (colorNo2 == "1"){
                                                hitMap [3] = 0;
                                                hitMap [4] = 0;
                                                hitMap [5] = 1;
                                            }
                                            else if (colorNo2 == "2"){
                                                hitMap [3] = 0;
                                                hitMap [4] = 1;
                                                hitMap [5] = 0;
                                            }
                                            else if (colorNo2 == "3"){
                                                hitMap [3] = 1;
                                                hitMap [4] = 1;
                                                hitMap [5] = 0;
                                            }
                                            else if (colorNo2 == "4"){
                                                hitMap [3] = 1;
                                                hitMap [4] = 0;
                                                hitMap [5] = 0;
                                            }
                                            else if (colorNo2 == "5"){
                                                hitMap [3] = 1;
                                                hitMap [4] = 0;
                                                hitMap [5] = 1;
                                            }
                                            
                                            if (colorNo3 == "1"){
                                                hitMap [6] = 0;
                                                hitMap [7] = 0;
                                                hitMap [8] = 1;
                                            }
                                            else if (colorNo3 == "2"){
                                                hitMap [6] = 0;
                                                hitMap [7] = 1;
                                                hitMap [8] = 0;
                                            }
                                            else if (colorNo3 == "3"){
                                                hitMap [6] = 1;
                                                hitMap [7] = 1;
                                                hitMap [8] = 0;
                                            }
                                            else if (colorNo3 == "4"){
                                                hitMap [6] = 1;
                                                hitMap [7] = 0;
                                                hitMap [8] = 0;
                                            }
                                            else if (colorNo3 == "5"){
                                                hitMap [6] = 1;
                                                hitMap [7] = 0;
                                                hitMap [8] = 1;
                                            }
                                            
                                            for (int counter1 = imageXYLength-1; counter1 >= 0; counter1--){
                                                for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                                                    value0 = uploadTempExp [1078+counter1*imageXYLength+counter2];
                                                    
                                                    if (value0 >= 0 && value0 < cutHoldDIC){
                                                        value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                                        
                                                        if (value0 < 0) value0 = 0;
                                                    }
                                                    else{
                                                        
                                                        value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                                        
                                                        if (value0 > 255) value0 = 255;
                                                    }
                                                    
                                                    value1 = uploadTempExpCl1 [1078+counter1*imageXYLength+counter2];
                                                    
                                                    if (value1 < cutHold1) value1 = 0;
                                                    else{
                                                        
                                                        value1 = value1+(int)((value1-cutHold1)*levelHold1);
                                                        
                                                        if (value1 > 255) value1 = 255;
                                                    }
                                                    
                                                    value2 = uploadTempExpCl2 [1078+counter1*imageXYLength+counter2];
                                                    
                                                    if (value2 < cutHold2) value2 = 0;
                                                    else{
                                                        
                                                        value2 = value2+(int)((value2-cutHold2)*levelHold2);
                                                        
                                                        if (value2 > 255) value2 = 255;
                                                    }
                                                    
                                                    value3 = uploadTempExpCl3 [1078+counter1*imageXYLength+counter2];
                                                    
                                                    if (value3 < cutHold3) value3 = 0;
                                                    else{
                                                        
                                                        value3 = value3+(int)((value3-cutHold3)*levelHold3);
                                                        
                                                        if (value3 > 255) value3 = 255;
                                                    }
                                                    
                                                    if (statusHold1 == 0) value1 = 0;
                                                    if (statusHold2 == 0) value2 = 0;
                                                    if (statusHold3 == 0) value3 = 0;
                                                    
                                                    if (value1 <= 0 && value2 <= 0 && value3 <= 0){
                                                        *bitmapData++ = (unsigned char)value0;
                                                        *bitmapData++ = (unsigned char)value0;
                                                        *bitmapData++ = (unsigned char)value0;
                                                        *bitmapData++ = 0;
                                                    }
                                                    else{
                                                        
                                                        if (value1 < 0) value1 = 0;
                                                        if (value2 < 0) value2 = 0;
                                                        if (value3 < 0) value3 = 0;
                                                        
                                                        hitR = 0;
                                                        hitG = 0;
                                                        hitB = 0;
                                                        
                                                        if (value1 > 0 && statusHold1 != 0){
                                                            if (hitMap [0] != 0) hitR++;
                                                            if (hitMap [1] != 0) hitG++;
                                                            if (hitMap [2] != 0) hitB++;
                                                        }
                                                        
                                                        if (value2 > 0 && statusHold2 != 0){
                                                            if (hitMap [3] != 0) hitR++;
                                                            if (hitMap [4] != 0) hitG++;
                                                            if (hitMap [5] != 0) hitB++;
                                                        }
                                                        
                                                        if (value3 > 0 && statusHold3 != 0){
                                                            if (hitMap [6] != 0) hitR++;
                                                            if (hitMap [7] != 0) hitG++;
                                                            if (hitMap [8] != 0) hitB++;
                                                        }
                                                        
                                                        colorHit1 = 0;
                                                        colorHit2 = 0;
                                                        colorHit3 = 0;
                                                        
                                                        if (hitR == 1){
                                                            if (hitMap [0] != 0 && value1 > 0 ) colorHit1 = 1;
                                                            if (hitMap [3] != 0 && value2 > 0 ) colorHit2 = 1;
                                                            if (hitMap [6] != 0 && value3 > 0 ) colorHit3 = 1;
                                                            
                                                        }
                                                        else if (hitR == 2){
                                                            if (hitMap [0] != 0 && value1 > 0 ) colorHit1 = 0.5;
                                                            if (hitMap [3] != 0 && value2 > 0 ) colorHit2 = 0.5;
                                                            if (hitMap [6] != 0 && value3 > 0 ) colorHit3 = 0.5;
                                                        }
                                                        else if (hitR == 3){
                                                            if (value1 > 0) colorHit1 = 0.33;
                                                            if (value2 > 0) colorHit2 = 0.33;
                                                            if (value3 > 0) colorHit3 = 0.33;
                                                        }
                                                        
                                                        *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3));
                                                        
                                                        colorHit1 = 0;
                                                        colorHit2 = 0;
                                                        colorHit3 = 0;
                                                        
                                                        if (hitG == 1){
                                                            if (hitMap [1] != 0 && value1 > 0 ) colorHit1 = 1;
                                                            if (hitMap [4] != 0 && value2 > 0 ) colorHit2 = 1;
                                                            if (hitMap [7] != 0 && value3 > 0 ) colorHit3 = 1;
                                                        }
                                                        else if (hitG == 2){
                                                            if (hitMap [1] != 0 && value1 > 0 ) colorHit1 = 0.5;
                                                            if (hitMap [4] != 0 && value2 > 0 ) colorHit2 = 0.5;
                                                            if (hitMap [7] != 0 && value3 > 0 ) colorHit3 = 0.5;
                                                        }
                                                        else if (hitG == 3){
                                                            if (hitMap [1] != 0 && value1 > 0 ) colorHit1 = 0.33;
                                                            if (hitMap [4] != 0 && value2 > 0 ) colorHit2 = 0.33;
                                                            if (hitMap [7] != 0 && value3 > 0 ) colorHit3 = 0.33;
                                                        }
                                                        
                                                        *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3));
                                                        
                                                        colorHit1 = 0;
                                                        colorHit2 = 0;
                                                        colorHit3 = 0;
                                                        
                                                        if (hitB == 1){
                                                            if (hitMap [2] != 0 && value1 > 0 ) colorHit1 = 1;
                                                            if (hitMap [5] != 0 && value2 > 0 ) colorHit2 = 1;
                                                            if (hitMap [8] != 0 && value3 > 0 ) colorHit3 = 1;
                                                        }
                                                        else if (hitB == 2){
                                                            if (hitMap [2] != 0 && value1 > 0 ) colorHit1 = 0.5;
                                                            if (hitMap [5] != 0 && value2 > 0 ) colorHit2 = 0.5;
                                                            if (hitMap [8] != 0 && value3 > 0 ) colorHit3 = 0.5;
                                                        }
                                                        else if (hitB == 3){
                                                            if (hitMap [2] != 0 && value1 > 0 ) colorHit1 = 0.33;
                                                            if (hitMap [5] != 0 && value2 > 0 ) colorHit2 = 0.33;
                                                            if (hitMap [8] != 0 && value3 > 0 ) colorHit3 = 0.33;
                                                        }
                                                        
                                                        *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3));
                                                        *bitmapData++ = 0;
                                                    }
                                                }
                                            }
                                            
                                            delete [] hitMap;
                                        }
                                    }
                                    else{
                                        
                                        if (imageBmpTifFlag == 0){
                                            unsigned long headPosition = 0;
                                            
                                            dataConversion [0] = uploadTempExp [0];
                                            dataConversion [1] = uploadTempExp [1];
                                            
                                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                            else endianType = 0;
                                            
                                            headPosition = 0;
                                            
                                            if (endianType == 1){
                                                dataConversion [0] = uploadTempExp [7];
                                                dataConversion [1] = uploadTempExp [6];
                                                dataConversion [2] = uploadTempExp [5];
                                                dataConversion [3] = uploadTempExp [4];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            else if (endianType == 0){
                                                dataConversion [0] = uploadTempExp [4];
                                                dataConversion [1] = uploadTempExp [5];
                                                dataConversion [2] = uploadTempExp [6];
                                                dataConversion [3] = uploadTempExp [7];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            
                                            for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                                value0 = uploadTempExp [counter1];
                                                
                                                if (value0 >= 0 && value0 < cutHoldDIC){
                                                    value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                                    
                                                    if (value0 < 0) value0 = 0;
                                                }
                                                else{
                                                    
                                                    value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                                    
                                                    if (value0 > 255) value0 = 255;
                                                }
                                                
                                                *bitmapData++ = (unsigned char)value0;
                                                *bitmapData++ = (unsigned char)value0;
                                                *bitmapData++ = (unsigned char)value0;
                                                *bitmapData++ = 0;
                                            }
                                        }
                                        else if (imageBmpTifFlag == 1){
                                            for (int counter1 = imageXYLength-1; counter1 >= 0; counter1--){
                                                for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                                                    value0 = uploadTempExp [1078+counter1*imageXYLength+counter2];
                                                    
                                                    if (value0 >= 0 && value0 < cutHoldDIC){
                                                        value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                                        
                                                        if (value0 < 0) value0 = 0;
                                                    }
                                                    else{
                                                        
                                                        value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                                        
                                                        if (value0 > 255) value0 = 255;
                                                    }
                                                    
                                                    *bitmapData++ = (unsigned char)value0;
                                                    *bitmapData++ = (unsigned char)value0;
                                                    *bitmapData++ = (unsigned char)value0;
                                                    *bitmapData++ = 0;
                                                }
                                            }
                                        }
                                    }
                                }
                                else if (grayColorStatus == 1){
                                    int dataConversion [4];
                                    int endianType = 0;
                                    
                                    unsigned long headPosition = 0;
                                    
                                    dataConversion [0] = uploadTempExp [0];
                                    dataConversion [1] = uploadTempExp [1];
                                    
                                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                    else endianType = 0;
                                    
                                    headPosition = 0;
                                    
                                    if (endianType == 1){
                                        dataConversion [0] = uploadTempExp [7];
                                        dataConversion [1] = uploadTempExp [6];
                                        dataConversion [2] = uploadTempExp [5];
                                        dataConversion [3] = uploadTempExp [4];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    else if (endianType == 0){
                                        dataConversion [0] = uploadTempExp [4];
                                        dataConversion [1] = uploadTempExp [5];
                                        dataConversion [2] = uploadTempExp [6];
                                        dataConversion [3] = uploadTempExp [7];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    
                                    int value0 = 0;
                                    int value1 = 0;
                                    int value2 = 0;
                                    
                                    for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                        value0 = uploadTempExp [counter1];
                                        value0 = (int)(value0*(double)levelHoldR);
                                        
                                        if (value0 > 255) value0 = 255;
                                        
                                        value1 = uploadTempExp [counter1+1];
                                        value1 = (int)(value1*(double)levelHoldG);
                                        
                                        if (value1 > 255) value1 = 255;
                                        
                                        value2 = uploadTempExp [counter1+2];
                                        value2 = (int)(value2*(double)levelHoldB);
                                        
                                        if (value2 > 255) value2 = 255;
                                        
                                        *bitmapData++ = (unsigned char)value0;
                                        *bitmapData++ = (unsigned char)value1;
                                        *bitmapData++ = (unsigned char)value2;
                                        *bitmapData++ = 0;
                                    }
                                }
                            }
                            else{
                                
                                if (refLoadStatus == 1){
                                    int dataConversion [4];
                                    int endianType = 0;
                                    
                                    unsigned long headPosition = 0;
                                    
                                    dataConversion [0] = uploadTempExpRef [0];
                                    dataConversion [1] = uploadTempExpRef [1];
                                    
                                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                    else endianType = 0;
                                    
                                    if (endianType == 1){
                                        dataConversion [0] = uploadTempExpRef [7];
                                        dataConversion [1] = uploadTempExpRef [6];
                                        dataConversion [2] = uploadTempExpRef [5];
                                        dataConversion [3] = uploadTempExpRef [4];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    else if (endianType == 0){
                                        dataConversion [0] = uploadTempExpRef [4];
                                        dataConversion [1] = uploadTempExpRef [5];
                                        dataConversion [2] = uploadTempExpRef [6];
                                        dataConversion [3] = uploadTempExpRef [7];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    
                                    int grayColorStatusColor = 0;
                                    
                                    if (headPosition-8 == (unsigned long)(imageXYLength*imageXYLength)) grayColorStatusColor = 0;
                                    else grayColorStatusColor = 1;
                                    
                                    if (grayColorStatusColor == 0){
                                        int value0 = 0;
                                        
                                        for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                            value0 = uploadTempExpRef [counter1];
                                            
                                            if (value0 >= 0 && value0 < cutHoldDIC){
                                                value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                                
                                                if (value0 < 0) value0 = 0;
                                            }
                                            else{
                                                
                                                value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                                
                                                if (value0 > 255) value0 = 255;
                                            }
                                            
                                            *bitmapData++ = (unsigned char)value0;
                                            *bitmapData++ = (unsigned char)value0;
                                            *bitmapData++ = (unsigned char)value0;
                                            *bitmapData++ = 0;
                                        }
                                    }
                                    else if (grayColorStatusColor == 1){
                                        int value0 = 0;
                                        int value1 = 0;
                                        int value2 = 0;
                                        
                                        for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                            value0 = uploadTempExpRef [counter1];
                                            value0 = (int)(value0*(double)levelHoldR);
                                            
                                            if (value0 > 255) value0 = 255;
                                            
                                            value1 = uploadTempExpRef [counter1+1];
                                            value1 = (int)(value1*(double)levelHoldG);
                                            
                                            if (value1 > 255) value1 = 255;
                                            
                                            value2 = uploadTempExpRef [counter1+2];
                                            value2 = (int)(value2*(double)levelHoldB);
                                            
                                            if (value2 > 255) value2 = 255;
                                            
                                            *bitmapData++ = (unsigned char)value0;
                                            *bitmapData++ = (unsigned char)value1;
                                            *bitmapData++ = (unsigned char)value2;
                                            *bitmapData++ = 0;
                                        }
                                    }
                                }
                                else if (refLoadStatus == 2){
                                    int dataConversion [4];
                                    int endianType = 0;
                                    
                                    unsigned long headPosition = 0;
                                    
                                    dataConversion [0] = uploadTempExpRef2 [0];
                                    dataConversion [1] = uploadTempExpRef2 [1];
                                    
                                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                    else endianType = 0;
                                    
                                    if (endianType == 1){
                                        dataConversion [0] = uploadTempExpRef2 [7];
                                        dataConversion [1] = uploadTempExpRef2 [6];
                                        dataConversion [2] = uploadTempExpRef2 [5];
                                        dataConversion [3] = uploadTempExpRef2 [4];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    else if (endianType == 0){
                                        dataConversion [0] = uploadTempExpRef2 [4];
                                        dataConversion [1] = uploadTempExpRef2 [5];
                                        dataConversion [2] = uploadTempExpRef2 [6];
                                        dataConversion [3] = uploadTempExpRef2 [7];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    
                                    int grayColorStatusRef2 = 0;
                                    
                                    if (headPosition-8 == (unsigned long)(imageXYLength*imageXYLength)) grayColorStatusRef2 = 0;
                                    else grayColorStatusRef2 = 1;
                                    
                                    if (grayColorStatusRef2 == 0){
                                        int value0 = 0;
                                        
                                        for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                            value0 = uploadTempExpRef2 [counter1];
                                            
                                            if (value0 >= 0 && value0 < cutHoldDIC){
                                                value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                                
                                                if (value0 < 0) value0 = 0;
                                            }
                                            else{
                                                
                                                value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                                
                                                if (value0 > 255) value0 = 255;
                                            }
                                            
                                            *bitmapData++ = (unsigned char)value0;
                                            *bitmapData++ = (unsigned char)value0;
                                            *bitmapData++ = (unsigned char)value0;
                                            *bitmapData++ = 0;
                                        }
                                    }
                                    else if (grayColorStatusRef2 == 1){
                                        int value0 = 0;
                                        int value1 = 0;
                                        int value2 = 0;
                                        
                                        for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                            value0 = uploadTempExpRef2 [counter1];
                                            value0 = (int)(value0*(double)levelHoldR);
                                            
                                            if (value0 > 255) value0 = 255;
                                            
                                            value1 = uploadTempExpRef2 [counter1+1];
                                            value1 = (int)(value1*(double)levelHoldG);
                                            
                                            if (value1 > 255) value1 = 255;
                                            
                                            value2 = uploadTempExpRef2 [counter1+2];
                                            value2 = (int)(value2*(double)levelHoldB);
                                            
                                            if (value2 > 255) value2 = 255;
                                            
                                            *bitmapData++ = (unsigned char)value0;
                                            *bitmapData++ = (unsigned char)value1;
                                            *bitmapData++ = (unsigned char)value2;
                                            *bitmapData++ = 0;
                                        }
                                    }
                                }
                                else if (refLoadStatus == 3){
                                    int dataConversion [4];
                                    int endianType = 0;
                                    
                                    unsigned long headPosition = 0;
                                    
                                    dataConversion [0] = uploadTempExpRef3 [0];
                                    dataConversion [1] = uploadTempExpRef3 [1];
                                    
                                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                    else endianType = 0;
                                    
                                    if (endianType == 1){
                                        dataConversion [0] = uploadTempExpRef3 [7];
                                        dataConversion [1] = uploadTempExpRef3 [6];
                                        dataConversion [2] = uploadTempExpRef3 [5];
                                        dataConversion [3] = uploadTempExpRef3 [4];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    else if (endianType == 0){
                                        dataConversion [0] = uploadTempExpRef3 [4];
                                        dataConversion [1] = uploadTempExpRef3 [5];
                                        dataConversion [2] = uploadTempExpRef3 [6];
                                        dataConversion [3] = uploadTempExpRef3 [7];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    
                                    int grayColorStatusRef3 = 0;
                                    
                                    if (headPosition-8 == (unsigned long)(imageXYLength*imageXYLength)) grayColorStatusRef3 = 0;
                                    else grayColorStatusRef3 = 1;
                                    
                                    if (grayColorStatusRef3 == 0){
                                        int value0 = 0;
                                        
                                        for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                            value0 = uploadTempExpRef3 [counter1];
                                            
                                            if (value0 >= 0 && value0 < cutHoldDIC){
                                                value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                                
                                                if (value0 < 0) value0 = 0;
                                            }
                                            else{
                                                
                                                value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                                
                                                if (value0 > 255) value0 = 255;
                                            }
                                            
                                            *bitmapData++ = (unsigned char)value0;
                                            *bitmapData++ = (unsigned char)value0;
                                            *bitmapData++ = (unsigned char)value0;
                                            *bitmapData++ = 0;
                                        }
                                    }
                                    else if (grayColorStatusRef3 == 1){
                                        int value0 = 0;
                                        int value1 = 0;
                                        int value2 = 0;
                                        
                                        for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                            value0 = uploadTempExpRef3 [counter1];
                                            value0 = (int)(value0*(double)levelHoldR);
                                            
                                            if (value0 > 255) value0 = 255;
                                            
                                            value1 = uploadTempExpRef3 [counter1+1];
                                            value1 = (int)(value1*(double)levelHoldG);
                                            
                                            if (value1 > 255) value1 = 255;
                                            
                                            value2 = uploadTempExpRef3 [counter1+2];
                                            value2 = (int)(value2*(double)levelHoldB);
                                            
                                            if (value2 > 255) value2 = 255;
                                            
                                            *bitmapData++ = (unsigned char)value0;
                                            *bitmapData++ = (unsigned char)value1;
                                            *bitmapData++ = (unsigned char)value2;
                                            *bitmapData++ = 0;
                                        }
                                    }
                                }
                            }
                            
                            exportImage = [[NSImage alloc] initWithSize:NSMakeSize(imageXYLength, imageXYLength)];
                            [exportImage addRepresentation:bitmapRepsCR];
                            
                            dotDisplayMode = 0;
                            timingEx = 10;
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Data Loading Error"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Data Loading Error"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Data Loading Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Data Loading Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        if (proceedFlag == 1) timingEx2 = 1;
    }
}

-(void)drawRect:(NSRect)rect{
    timingEx2 = 6;
    [[NSColor blackColor] set];
    
    NSBezierPath *path;
    path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 700, 700)];
    [path fill];
    
    NSRect srcRect;
    srcRect.origin.x = xPositionExport+xPositionAdjustExport+xPositionMoveExport;
    srcRect.origin.y = yPositionExport+yPositionAdjustExport+yPositionMoveExport;
    srcRect.size.width = imageXYLength/(double)(magnificationExport*0.1);
    srcRect.size.height = imageXYLength/(double)(magnificationExport*0.1);
    
    [exportImage drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
    
    if (imageProgressFlag == 0){
        double xPositionAdj = xPositionAdjustExport+xPositionExport;
        double yPositionAdj = yPositionAdjustExport+yPositionExport;
        double xCalValue = 1/(double)windowWidthExport*magnificationExport*0.1;
        double yCalValue = 1/(double)windowHeightExport*magnificationExport*0.1;
        double magnificationDisplay3 = magnificationExport*0.1*0.4*lineWidthExp;//==3
        double magnificationLine = magnificationExport*0.25;
        double magnificationFont2 = magnificationExport*0.08*3.5; //==2
        double magnificationDisplay2 = magnificationExport*0.1;
        
        double displayFrequencyTemp = (2-xPositionAdj)*xCalValue-(1-xPositionAdj)*xCalValue;
        int displayFrequency = (int)displayFrequencyTemp;
        
        if (displayFrequencyTemp <= 0.3 && displayFrequencyTemp != 0) displayFrequency = (int)(8/(double)displayFrequencyTemp);
        else if (displayFrequencyTemp <= 0.5 && displayFrequencyTemp > 0.3) displayFrequency = (int)(6/(double)displayFrequencyTemp);
        else if (displayFrequencyTemp <= 1 && displayFrequencyTemp > 0.5) displayFrequency = (int)(4/(double)displayFrequencyTemp);
        else if (displayFrequencyTemp <= 2 && displayFrequencyTemp > 1) displayFrequency = 2;
        else if (displayFrequencyTemp <= 3 && displayFrequencyTemp > 2) displayFrequency = 1;
        else if (displayFrequencyTemp <= 4 && displayFrequencyTemp > 3) displayFrequency = 1;
        
        CGFloat sizeCalculation = 512*xCalValue;
        sizeCalculation = (sizeCalculation/(double)700)*0.5;
        
        if (sizeCalculation >= 3) sizeCalculation = 3;
        
        NSPoint positionAA;
        NSPoint positionBB;
        NSPoint positionCC;
        NSPoint positionDD;
        
        //------Whole line data, TrackingOn = 1, or TrackingOn = 3, outside of range------
        int xPointMarkTemp = 0;
        int yPointMarkTemp = 0;
        int xPointMarkTemp2 = 0;
        int yPointMarkTemp2 = 0;
        
        if (boxXLengthExp != 0 && boxYLengthExp != 0){
            [NSBezierPath setDefaultLineWidth:sizeCalculation*10];
            [[NSColor redColor] set];
            
            xPointMarkTemp = (int)(((boxXPositionExp-(boxXLengthExp/(double)2))-xPositionAdj)*(double)xCalValue);
            xPointMarkTemp2 = (int)(((boxXPositionExp+(boxXLengthExp/(double)2))-xPositionAdj)*(double)xCalValue);
            yPointMarkTemp = (int)(((imageXYLength-boxYPositionExp)-yPositionAdj)*(double)yCalValue);
            yPointMarkTemp2 = (int)(((imageXYLength-boxYPositionExp+boxYLengthExp)-yPositionAdj)*(double)yCalValue);
            
            positionAA.x = xPointMarkTemp;
            positionAA.y = yPointMarkTemp;
            positionBB.x = xPointMarkTemp2;
            positionBB.y = yPointMarkTemp;
            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            
            positionAA.x = xPointMarkTemp;
            positionAA.y = yPointMarkTemp;
            positionBB.x = xPointMarkTemp;
            positionBB.y = yPointMarkTemp2;
            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            
            positionAA.x = xPointMarkTemp2;
            positionAA.y = yPointMarkTemp;
            positionBB.x = xPointMarkTemp2;
            positionBB.y = yPointMarkTemp2;
            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            
            positionAA.x = xPointMarkTemp;
            positionAA.y = yPointMarkTemp2;
            positionBB.x = xPointMarkTemp2;
            positionBB.y = yPointMarkTemp2;
            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
        }
        
        NSBezierPath *path3;
        
        if (dotNumberCurrentExp != 0){
            double magnificationDisplayDot = 0;
            
            if (dotLengthExport == 1) magnificationDisplayDot = magnificationDisplay2*3;
            else if (dotLengthExport == 2) magnificationDisplayDot = (magnificationDisplay2*3)/(double)2;
            else if (dotLengthExport == 3) magnificationDisplayDot = (magnificationDisplay2*3)/(double)4;
            else if (dotLengthExport == 4) magnificationDisplayDot = 0;
            
            for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                if (arrayDotDataHold [counter1*3] >= 0 && arrayDotDataHold [counter1*3] <= 100000 && arrayDotDataHold [counter1*3] == timePointHoldExp){
                    xPointMarkTemp = (int)((arrayDotDataHold [counter1*3+1]-xPositionAdj)*(double)xCalValue);
                    yPointMarkTemp = (int)(((imageXYLength-arrayDotDataHold [counter1*3+2])-yPositionAdj)*(double)yCalValue);
                    
                    [[NSColor cyanColor] set];
                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp-magnificationDisplayDot/2, yPointMarkTemp-magnificationDisplayDot/2, magnificationDisplayDot, magnificationDisplayDot)];
                    
                    if (dotStyleExport == 0) [path3 fill];
                    else if (dotStyleExport == 1) [path3 stroke];
                }
                else if (arrayDotDataHold [counter1*3] < 0 && arrayDotDataHold [counter1*3] >= -100000 && arrayDotDataHold [counter1*3]*-1 == timePointHoldExp){
                    xPointMarkTemp = (int)((arrayDotDataHold [counter1*3+1]-xPositionAdj)*(double)xCalValue);
                    yPointMarkTemp = (int)(((imageXYLength-arrayDotDataHold [counter1*3+2])-yPositionAdj)*(double)yCalValue);
                    
                    [[NSColor redColor] set];
                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp-magnificationDisplayDot/2, yPointMarkTemp-magnificationDisplayDot/2, magnificationDisplayDot, magnificationDisplayDot)];
                    
                    if (dotStyleExport == 0) [path3 fill];
                    else if (dotStyleExport == 1) [path3 stroke];
                }
                else if (arrayDotDataHold [counter1*3] > 100000 && arrayDotDataHold [counter1*3]-100000 == timePointHoldExp){
                    xPointMarkTemp = (int)((arrayDotDataHold [counter1*3+1]-xPositionAdj)*(double)xCalValue);
                    yPointMarkTemp = (int)(((imageXYLength-arrayDotDataHold [counter1*3+2])-yPositionAdj)*(double)yCalValue);
                    
                    [[NSColor greenColor] set];
                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp-magnificationDisplayDot/2, yPointMarkTemp-magnificationDisplayDot/2, magnificationDisplayDot, magnificationDisplayDot)];
                    
                    if (dotStyleExport == 0) [path3 fill];
                    else if (dotStyleExport == 1) [path3 stroke];
                }
                else if (arrayDotDataHold [counter1*3] < -100000 && arrayDotDataHold [counter1*3]*-1-100000 == timePointHoldExp){
                    xPointMarkTemp = (int)((arrayDotDataHold [counter1*3+1]-xPositionAdj)*(double)xCalValue);
                    yPointMarkTemp = (int)(((imageXYLength-arrayDotDataHold [counter1*3+2])-yPositionAdj)*(double)yCalValue);
                    
                    [[NSColor magentaColor] set];
                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp-magnificationDisplayDot/2, yPointMarkTemp-magnificationDisplayDot/2, magnificationDisplayDot, magnificationDisplayDot)];
                    
                    if (dotStyleExport == 0) [path3 fill];
                    else if (dotStyleExport == 1) [path3 stroke];
                }
            }
        }
        
        if (gridStatusHold == 1){
            if (gridLinWidth == 0){
                [NSBezierPath setDefaultLineWidth:sizeCalculation*5];
            }
            else if (gridLinWidth == 1){
                [NSBezierPath setDefaultLineWidth:sizeCalculation*5*2];
            }
            else if (gridLinWidth == 2){
                [NSBezierPath setDefaultLineWidth:sizeCalculation*5*4];
            }
            
            if (gridLineColor == 0){
                [[NSColor orangeColor] set];
            }
            else if (gridLineColor == 1){
                [[NSColor greenColor] set];
            }
            else if (gridLineColor == 2){
                [[NSColor yellowColor] set];
            }
            else if (gridLineColor == 3){
                [[NSColor redColor] set];
            }
            else if (gridLineColor == 4){
                [[NSColor blueColor] set];
            }
            else if (gridLineColor == 5){
                [[NSColor blackColor] set];
            }
            else if (gridLineColor == 6){
                [[NSColor whiteColor] set];
            }
            
            int xGridLength = (int)((imageXYLength-xPositionAdj)*(double)xCalValue);
            int yGridLength = (int)(((imageXYLength-imageXYLength)-yPositionAdj)*(double)yCalValue);
            
            xPointMarkTemp = (int)((0-xPositionAdj)*(double)xCalValue);
            yPointMarkTemp = (int)(((imageXYLength-0)-yPositionAdj)*(double)yCalValue);
            
            positionAA.x = xPointMarkTemp;
            positionAA.y = yPointMarkTemp;
            positionBB.x = xGridLength;
            positionBB.y = yPointMarkTemp;
            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            
            positionAA.x = xPointMarkTemp;
            positionAA.y = yGridLength;
            positionBB.x = xGridLength;
            positionBB.y = yGridLength;
            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            
            positionAA.x = xPointMarkTemp;
            positionAA.y = yPointMarkTemp;
            positionBB.x = xPointMarkTemp;
            positionBB.y = yGridLength;
            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            
            positionAA.x = xGridLength;
            positionAA.y = yPointMarkTemp;
            positionBB.x = xGridLength;
            positionBB.y = yGridLength;
            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            
            if (gridDimHold > 1){
                int xGridPosition = 0;
                int yGridPosition = 0;
                
                double gridNewellDimension = imageXYLength/(double)gridDimHold;
                int positionAccumulate = 0;
                
                for (int counter1 = 0; counter1 < gridDimHold-1; counter1++){
                    positionAccumulate = positionAccumulate+(int)gridNewellDimension;
                    yGridPosition = (int)(((imageXYLength-positionAccumulate)-yPositionAdj)*(double)yCalValue);
                    
                    positionAA.x = xPointMarkTemp;
                    positionAA.y = yGridPosition;
                    positionBB.x = xGridLength;
                    positionBB.y = yGridPosition;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
                
                positionAccumulate = 0;
                
                for (int counter1 = 0; counter1 < gridDimHold-1; counter1++){
                    positionAccumulate = positionAccumulate+(int)gridNewellDimension;
                    xGridPosition = (int)((positionAccumulate-xPositionAdj)*(double)xCalValue);
                    
                    positionAA.x = xGridPosition;
                    positionAA.y = yPointMarkTemp;
                    positionBB.x = xGridPosition;
                    positionBB.y = yGridLength;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
            }
        }
        
        //------Time One mode------
        NSPoint pointA;
        NSAttributedString *attrStrA;
        NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
        
        if (areaModeStatusHold == 1){
            if (colorPasteStatus == 1){
                for (int counterY = 0; counterY < imageXYLength; counterY = counterY+displayFrequency){
                    for (int counterX = 0; counterX < imageXYLength; counterX = counterX+displayFrequency){
                        xPointMarkTemp = (int)((counterX-xPositionAdj)*(double)xCalValue);
                        yPointMarkTemp = (int)(((imageXYLength-counterY)-yPositionAdj)*(double)yCalValue);
                        
                        if (revisedWorkingMapExp [counterY][counterX] != 0 && xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                            if (outLineSelectExport == 0 || (outLineSelectExport == 1 && (arrayTimeSelectedExport [(revisedWorkingMapExp [counterY][counterX]-1)*10] == 1 || arrayTimeSelectedExport [(revisedWorkingMapExp [counterY][counterX]-1)*10] == 10 || arrayTimeSelectedExport [(revisedWorkingMapExp [counterY][counterX]-1)*10] == 11))){
                                if (colorHoldArea1 == 0){
                                    [[NSColor colorWithCalibratedRed:153 green:153 blue:153 alpha:1] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                    [path3 fill];
                                }
                                else{
                                    
                                    if (arrayTimeSelectedExport [(revisedWorkingMapExp [counterY][counterX]-1)*10] == 1){
                                        if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] <= colorHoldArea1){
                                            [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold1*3] green:arrayColorRange [colorHold1*3+1] blue:arrayColorRange [colorHold1*3+2] alpha:1] set];
                                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                            [path3 fill];
                                        }
                                        else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] > colorHoldArea1 && colorHoldArea2 == 0){
                                            [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold2*3] green:arrayColorRange [colorHold2*3+1] blue:arrayColorRange [colorHold2*3+2] alpha:1] set];
                                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                            [path3 fill];
                                        }
                                        else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] <= colorHoldArea2){
                                            [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold2*3] green:arrayColorRange [colorHold2*3+1] blue:arrayColorRange [colorHold2*3+2] alpha:1] set];
                                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                            [path3 fill];
                                            
                                        }
                                        else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] > colorHoldArea2 && colorHoldArea3 == 0){
                                            [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold3*3] green:arrayColorRange [colorHold3*3+1] blue:arrayColorRange [colorHold3*3+2] alpha:1] set];
                                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                            [path3 fill];
                                        }
                                        else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] <= colorHoldArea3){
                                            [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold3*3] green:arrayColorRange [colorHold3*3+1] blue:arrayColorRange [colorHold3*3+2] alpha:1] set];
                                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                            [path3 fill];
                                        }
                                        else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] > colorHoldArea3 && colorHoldArea4 == 0){
                                            [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold4*3] green:arrayColorRange [colorHold4*3+1] blue:arrayColorRange [colorHold4*3+2] alpha:1] set];
                                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                            [path3 fill];
                                        }
                                        else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] <= colorHoldArea4){
                                            [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold4*3] green:arrayColorRange [colorHold4*3+1] blue:arrayColorRange [colorHold4*3+2] alpha:1] set];
                                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                            [path3 fill];
                                        }
                                        else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] > colorHoldArea4 && colorHoldArea5 == 0){
                                            [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold5*3] green:arrayColorRange [colorHold5*3+1] blue:arrayColorRange [colorHold5*3+2] alpha:1] set];
                                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                            [path3 fill];
                                        }
                                        else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] <= colorHoldArea5){
                                            [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold5*3] green:arrayColorRange [colorHold5*3+1] blue:arrayColorRange [colorHold5*3+2] alpha:1] set];
                                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                            [path3 fill];
                                        }
                                        else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] > colorHoldArea5 && colorHoldArea6 == 0){
                                            [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold6*3] green:arrayColorRange [colorHold6*3+1] blue:arrayColorRange [colorHold6*3+2] alpha:1] set];
                                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                            [path3 fill];
                                        }
                                        else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] <= colorHoldArea6){
                                            [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold6*3] green:arrayColorRange [colorHold6*3+1] blue:arrayColorRange [colorHold6*3+2] alpha:1] set];
                                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                            [path3 fill];
                                        }
                                        else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] > colorHoldArea6 && colorHoldArea7 == 0){
                                            [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold7*3] green:arrayColorRange [colorHold7*3+1] blue:arrayColorRange [colorHold7*3+2] alpha:1] set];
                                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                            [path3 fill];
                                        }
                                        else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] <= colorHoldArea7){
                                            [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold7*3] green:arrayColorRange [colorHold7*3+1] blue:arrayColorRange [colorHold7*3+2] alpha:1] set];
                                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                            [path3 fill];
                                        }
                                        else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] > colorHoldArea7 && colorHoldArea8 == 0){
                                            [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold8*3] green:arrayColorRange [colorHold8*3+1] blue:arrayColorRange [colorHold8*3+2] alpha:1] set];
                                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                            [path3 fill];
                                        }
                                        else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] <= colorHoldArea8){
                                            [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold8*3] green:arrayColorRange [colorHold8*3+1] blue:arrayColorRange [colorHold8*3+2] alpha:1] set];
                                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                            [path3 fill];
                                        }
                                        else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] > colorHoldArea8 && colorHoldArea9 == 0){
                                            [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold9*3] green:arrayColorRange [colorHold9*3+1] blue:arrayColorRange [colorHold9*3+2] alpha:1] set];
                                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                            [path3 fill];
                                        }
                                        else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] <= colorHoldArea9){
                                            [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold9*3] green:arrayColorRange [colorHold9*3+1] blue:arrayColorRange [colorHold9*3+2] alpha:1] set];
                                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                            [path3 fill];
                                        }
                                        else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] > colorHoldArea9){
                                            [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold10*3] green:arrayColorRange [colorHold10*3+1] blue:arrayColorRange [colorHold10*3+2] alpha:1] set];
                                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                            [path3 fill];
                                        }
                                    }
                                    else{
                                        
                                        if (colorHoldSdStatus == 1 && arrayTimeSelectedExport [(revisedWorkingMapExp [counterY][counterX]-1)*10] == 10){
                                            [[NSColor colorWithCalibratedRed:arrayColorRange [colorHoldSd*3] green:arrayColorRange [colorHoldSd*3+1] blue:arrayColorRange [colorHoldSd*3+2] alpha:1] set];
                                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                            [path3 fill];
                                        }
                                        else if (colorHoldThStatus == 1 && arrayTimeSelectedExport [(revisedWorkingMapExp [counterY][counterX]-1)*10] == 11){
                                            [[NSColor colorWithCalibratedRed:arrayColorRange [colorHoldTh*3] green:arrayColorRange [colorHoldTh*3+1] blue:arrayColorRange [colorHoldTh*3+2] alpha:1] set];
                                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                            [path3 fill];
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            if (fontCrossExport == 0){
                [NSBezierPath setDefaultLineWidth:sizeCalculation];
                
                int startPoint = 0;
                int removeMark = 0;
                int connectTemp = 0;
                
                for (int counter1 = 0; counter1 < timeSelectedExportCount/10; counter1++){
                    if (arrayTimeSelectedExport [counter1*10] == 0 || arrayTimeSelectedExport [counter1*10] == 1 || arrayTimeSelectedExport [counter1*10] == 10 || arrayTimeSelectedExport [counter1*10] == 11){
                        startPoint = arrayTimeSelectedExport [counter1*10+2];
                        removeMark = arrayTimeSelectedExport [counter1*10];
                        
                        connectTemp = 0;
                        
                        for (int counter2 = startPoint; counter2 < positionExportCount/7; counter2 = counter2+displayFrequency){
                            if (connectTemp == 0){
                                connectTemp = arrayPositionExport [counter2*7+3];
                                
                                if (removeMark == 0){
                                    xPointMarkTemp = (int)((arrayPositionExport [counter2*7]-xPositionAdj)*(double)xCalValue);
                                    yPointMarkTemp = (int)(((imageXYLength-arrayPositionExport [counter2*7+1])-yPositionAdj)*(double)yCalValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor yellowColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay3, magnificationDisplay3)];
                                        [path3 fill];
                                    }
                                }
                                else if (removeMark == 1){
                                    xPointMarkTemp = (int)((arrayPositionExport [counter2*7]-xPositionAdj)*(double)xCalValue);
                                    yPointMarkTemp = (int)(((imageXYLength-arrayPositionExport [counter2*7+1])-yPositionAdj)*(double)yCalValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor greenColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay3, magnificationDisplay3)];
                                        [path3 fill];
                                    }
                                }
                                else if (removeMark == 10){
                                    xPointMarkTemp = (int)((arrayPositionExport [counter2*7]-xPositionAdj)*(double)xCalValue);
                                    yPointMarkTemp = (int)(((imageXYLength-arrayPositionExport [counter2*7+1])-yPositionAdj)*(double)yCalValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor blueColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay3, magnificationDisplay3)];
                                        [path3 fill];
                                    }
                                }
                                else if (removeMark == 11){
                                    xPointMarkTemp = (int)((arrayPositionExport [counter2*7]-xPositionAdj)*(double)xCalValue);
                                    yPointMarkTemp = (int)(((imageXYLength-arrayPositionExport [counter2*7+1])-yPositionAdj)*(double)yCalValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor magentaColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay3, magnificationDisplay3)];
                                        [path3 fill];
                                    }
                                }
                            }
                            else if (connectTemp == arrayPositionExport [counter2*7+3]){
                                if (removeMark == 0){
                                    xPointMarkTemp = (int)((arrayPositionExport [counter2*7]-xPositionAdj)*(double)xCalValue);
                                    yPointMarkTemp = (int)(((imageXYLength-arrayPositionExport [counter2*7+1])-yPositionAdj)*(double)yCalValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor yellowColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay3, magnificationDisplay3)];
                                        [path3 fill];
                                    }
                                }
                                else if (removeMark == 1){
                                    xPointMarkTemp = (int)((arrayPositionExport [counter2*7]-xPositionAdj)*(double)xCalValue);
                                    yPointMarkTemp = (int)(((imageXYLength-arrayPositionExport [counter2*7+1])-yPositionAdj)*(double)yCalValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor greenColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay3, magnificationDisplay3)];
                                        [path3 fill];
                                    }
                                }
                                else if (removeMark == 10){
                                    xPointMarkTemp = (int)((arrayPositionExport [counter2*7]-xPositionAdj)*(double)xCalValue);
                                    yPointMarkTemp = (int)(((imageXYLength-arrayPositionExport [counter2*7+1])-yPositionAdj)*(double)yCalValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor blueColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay3, magnificationDisplay3)];
                                        [path3 fill];
                                    }
                                }
                                else if (removeMark == 11){
                                    xPointMarkTemp = (int)((arrayPositionExport [counter2*7]-xPositionAdj)*(double)xCalValue);
                                    yPointMarkTemp = (int)(((imageXYLength-arrayPositionExport [counter2*7+1])-yPositionAdj)*(double)yCalValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor magentaColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay3, magnificationDisplay3)];
                                        [path3 fill];
                                    }
                                }
                            }
                            else if (connectTemp != arrayPositionExport [counter2*7+3]){
                                break;
                            }
                        }
                    }
                }
                
                //------GR Center Display------
                positionAA.x = 0;
                positionAA.y = 350;
                positionBB.x = 700;
                positionBB.y = 350;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                positionCC.x = 350;
                positionCC.y = 0;
                positionDD.x = 350;
                positionDD.y = 700;
                [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                
                [attributesA setObject:[NSFont systemFontOfSize:magnificationFont2] forKey:NSFontAttributeName];
                [attributesA setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                [attributesA removeObjectForKey:NSBackgroundColorAttributeName];
                NSString *vectorNumberDisplay;
                
                int selected = 0;
                
                for (int counter1 = 0; counter1 < gravityCenterExportCount/6; counter1++){
                    selected = arrayTimeSelectedExport [counter1*10];
                    xPointMarkTemp = (int)((arrayGravityCenterExport [counter1*6]-xPositionAdj)*(double)xCalValue);
                    yPointMarkTemp = (int)(((imageXYLength-arrayGravityCenterExport [counter1*6+1])-yPositionAdj)*(double)yCalValue);
                    
                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                        if (selected == 0){
                            [[NSColor blackColor] set];
                            [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                        }
                        else if (selected == 1){
                            [[NSColor redColor] set];
                            [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                        }
                        else if (selected == 10){
                            [[NSColor blueColor] set];
                            [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                        }
                        else if (selected == 11){
                            [[NSColor magentaColor] set];
                            [attributesA setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
                        }
                        
                        positionAA.x = xPointMarkTemp-magnificationLine;
                        positionAA.y = yPointMarkTemp;
                        positionBB.x = xPointMarkTemp+magnificationLine;
                        positionBB.y = yPointMarkTemp;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        positionCC.x = xPointMarkTemp;
                        positionCC.y = yPointMarkTemp-magnificationLine;
                        positionDD.x = xPointMarkTemp;
                        positionDD.y = yPointMarkTemp+magnificationLine;
                        [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                        
                        if (charDisplayFlag == 0){
                            vectorNumberDisplay = [NSString stringWithFormat:@"%d", arrayGravityCenterExport [counter1*6+4]];
                            
                            attrStrA = [[NSAttributedString alloc] initWithString:vectorNumberDisplay attributes:attributesA];
                            pointA.x = xPointMarkTemp+magnificationLine*0.3;
                            pointA.y = yPointMarkTemp+magnificationLine*0.3;
                            [attrStrA drawAtPoint:pointA];
                        }
                    }
                }
            }
        }
        
        //------Info writing------
        [attributesA setObject:[NSFont boldSystemFontOfSize:12] forKey:NSFontAttributeName];
        [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
        
        string ifString;
        string infoDisplayString = "Time: "+to_string(filePositionExp);
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 10;
        pointA.y = 685;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = "Treatment: "+treatNameHold;
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 80;
        pointA.y = 685;
        [attrStrA drawAtPoint:pointA];
        
        if (displayModeSelect != 0){
            NSBitmapImageRep *bitmapRepsCR = nil;
            bitmapRepsCR = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageXYLength pixelsHigh:imageXYLength bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageXYLength*4 bitsPerPixel:32];
            
            unsigned char *bitmapData = [bitmapRepsCR bitmapData];
            
            if (phaseStatus == 0){
                if (grayColorStatus == 0){
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    int value3 = 0;
                    int value4 = 0;
                    int value5 = 0;
                    int value6 = 0;
                    
                    int dataConversion [4];
                    int endianType = 0;
                    
                    double colorHit1 = 0;
                    double colorHit2 = 0;
                    double colorHit3 = 0;
                    double colorHit4 = 0;
                    double colorHit5 = 0;
                    double colorHit6 = 0;
                    
                    int hitR = 0;
                    int hitG = 0;
                    int hitB = 0;
                    
                    if (statusHold1 != 0 || statusHold2 != 0 || statusHold3 != 0 || statusHold4 != 0 || statusHold5 != 0 || statusHold6 != 0){
                        if (imageBmpTifFlag == 0){
                            double *hitMap = new double [20];
                            
                            if (colorNo1 == "1"){
                                hitMap [0] = 0;
                                hitMap [1] = 0;
                                hitMap [2] = 1;
                            }
                            else if (colorNo1 == "2"){
                                hitMap [0] = 0;
                                hitMap [1] = 1;
                                hitMap [2] = 0;
                            }
                            else if (colorNo1 == "3"){
                                hitMap [0] = 1;
                                hitMap [1] = 1;
                                hitMap [2] = 0;
                            }
                            else if (colorNo1 == "4"){
                                hitMap [0] = 1;
                                hitMap [1] = 0;
                                hitMap [2] = 0;
                            }
                            else if (colorNo1 == "5"){
                                hitMap [0] = 1;
                                hitMap [1] = 0;
                                hitMap [2] = 1;
                            }
                            else if (colorNo1 == "6"){
                                hitMap [0] = 0;
                                hitMap [1] = 1;
                                hitMap [2] = 1;
                            }
                            else if (colorNo1 == "7"){
                                hitMap [0] = 1;
                                hitMap [1] = 0.674;
                                hitMap [2] = 0;
                            }
                            else if (colorNo1 == "8"){
                                hitMap [0] = 0.627;
                                hitMap [1] = 0.125;
                                hitMap [2] = 0.941;
                            }
                            else if (colorNo1 == "9"){
                                hitMap [0] = 0.529;
                                hitMap [1] = 0.808;
                                hitMap [2] = 0.922;
                            }
                            
                            if (colorNo2 == "1"){
                                hitMap [3] = 0;
                                hitMap [4] = 0;
                                hitMap [5] = 1;
                            }
                            else if (colorNo2 == "2"){
                                hitMap [3] = 0;
                                hitMap [4] = 1;
                                hitMap [5] = 0;
                            }
                            else if (colorNo2 == "3"){
                                hitMap [3] = 1;
                                hitMap [4] = 1;
                                hitMap [5] = 0;
                            }
                            else if (colorNo2 == "4"){
                                hitMap [3] = 1;
                                hitMap [4] = 0;
                                hitMap [5] = 0;
                            }
                            else if (colorNo2 == "5"){
                                hitMap [3] = 1;
                                hitMap [4] = 0;
                                hitMap [5] = 1;
                            }
                            else if (colorNo2 == "6"){
                                hitMap [3] = 0;
                                hitMap [4] = 1;
                                hitMap [5] = 1;
                            }
                            else if (colorNo2 == "7"){
                                hitMap [3] = 1;
                                hitMap [4] = 0.674;
                                hitMap [5] = 0;
                            }
                            else if (colorNo2 == "8"){
                                hitMap [3] = 0.627;
                                hitMap [4] = 0.125;
                                hitMap [5] = 0.941;
                            }
                            else if (colorNo2 == "9"){
                                hitMap [3] = 0.529;
                                hitMap [4] = 0.808;
                                hitMap [5] = 0.922;
                            }
                            
                            if (colorNo3 == "1"){
                                hitMap [6] = 0;
                                hitMap [7] = 0;
                                hitMap [8] = 1;
                            }
                            else if (colorNo3 == "2"){
                                hitMap [6] = 0;
                                hitMap [7] = 1;
                                hitMap [8] = 0;
                            }
                            else if (colorNo3 == "3"){
                                hitMap [6] = 1;
                                hitMap [7] = 1;
                                hitMap [8] = 0;
                            }
                            else if (colorNo3 == "4"){
                                hitMap [6] = 1;
                                hitMap [7] = 0;
                                hitMap [8] = 0;
                            }
                            else if (colorNo3 == "5"){
                                hitMap [6] = 1;
                                hitMap [7] = 0;
                                hitMap [8] = 1;
                            }
                            else if (colorNo3 == "6"){
                                hitMap [6] = 0;
                                hitMap [7] = 1;
                                hitMap [8] = 1;
                            }
                            else if (colorNo3 == "7"){
                                hitMap [6] = 1;
                                hitMap [7] = 0.674;
                                hitMap [8] = 0;
                            }
                            else if (colorNo3 == "8"){
                                hitMap [6] = 0.627;
                                hitMap [7] = 0.125;
                                hitMap [8] = 0.941;
                            }
                            else if (colorNo3 == "9"){
                                hitMap [6] = 0.529;
                                hitMap [7] = 0.808;
                                hitMap [8] = 0.922;
                            }
                            
                            if (colorNo4 == "1"){
                                hitMap [9] = 0;
                                hitMap [10] = 0;
                                hitMap [11] = 1;
                            }
                            else if (colorNo4 == "2"){
                                hitMap [9] = 0;
                                hitMap [10] = 1;
                                hitMap [11] = 0;
                            }
                            else if (colorNo4 == "3"){
                                hitMap [9] = 1;
                                hitMap [10] = 1;
                                hitMap [11] = 0;
                            }
                            else if (colorNo4 == "4"){
                                hitMap [9] = 1;
                                hitMap [10] = 0;
                                hitMap [11] = 0;
                            }
                            else if (colorNo4 == "5"){
                                hitMap [9] = 1;
                                hitMap [10] = 0;
                                hitMap [11] = 1;
                            }
                            else if (colorNo4 == "6"){
                                hitMap [9] = 0;
                                hitMap [10] = 1;
                                hitMap [11] = 1;
                            }
                            else if (colorNo4 == "7"){
                                hitMap [9] = 1;
                                hitMap [10] = 0.674;
                                hitMap [11] = 0;
                            }
                            else if (colorNo4 == "8"){
                                hitMap [9] = 0.627;
                                hitMap [10] = 0.125;
                                hitMap [11] = 0.941;
                            }
                            else if (colorNo4 == "9"){
                                hitMap [9] = 0.529;
                                hitMap [10] = 0.808;
                                hitMap [11] = 0.922;
                            }
                            
                            if (colorNo5 == "1"){
                                hitMap [12] = 0;
                                hitMap [13] = 0;
                                hitMap [14] = 1;
                            }
                            else if (colorNo5 == "2"){
                                hitMap [12] = 0;
                                hitMap [13] = 1;
                                hitMap [14] = 0;
                            }
                            else if (colorNo5 == "3"){
                                hitMap [12] = 1;
                                hitMap [13] = 1;
                                hitMap [14] = 0;
                            }
                            else if (colorNo5 == "4"){
                                hitMap [12] = 1;
                                hitMap [13] = 0;
                                hitMap [14] = 0;
                            }
                            else if (colorNo5 == "5"){
                                hitMap [12] = 1;
                                hitMap [13] = 0;
                                hitMap [14] = 1;
                            }
                            else if (colorNo5 == "6"){
                                hitMap [12] = 0;
                                hitMap [13] = 1;
                                hitMap [14] = 1;
                            }
                            else if (colorNo5 == "7"){
                                hitMap [12] = 1;
                                hitMap [13] = 0.674;
                                hitMap [14] = 0;
                            }
                            else if (colorNo5 == "8"){
                                hitMap [12] = 0.627;
                                hitMap [13] = 0.125;
                                hitMap [14] = 0.941;
                            }
                            else if (colorNo5 == "9"){
                                hitMap [12] = 0.529;
                                hitMap [13] = 0.808;
                                hitMap [14] = 0.922;
                            }
                            
                            if (colorNo6 == "1"){
                                hitMap [15] = 0;
                                hitMap [16] = 0;
                                hitMap [17] = 1;
                            }
                            else if (colorNo6 == "2"){
                                hitMap [15] = 0;
                                hitMap [16] = 1;
                                hitMap [17] = 0;
                            }
                            else if (colorNo6 == "3"){
                                hitMap [15] = 1;
                                hitMap [16] = 1;
                                hitMap [17] = 0;
                            }
                            else if (colorNo6 == "4"){
                                hitMap [15] = 1;
                                hitMap [16] = 0;
                                hitMap [17] = 0;
                            }
                            else if (colorNo6 == "5"){
                                hitMap [15] = 1;
                                hitMap [16] = 0;
                                hitMap [17] = 1;
                            }
                            else if (colorNo6 == "6"){
                                hitMap [15] = 0;
                                hitMap [16] = 1;
                                hitMap [17] = 1;
                            }
                            else if (colorNo6 == "7"){
                                hitMap [15] = 1;
                                hitMap [16] = 0.674;
                                hitMap [17] = 0;
                            }
                            else if (colorNo6 == "8"){
                                hitMap [15] = 0.627;
                                hitMap [16] = 0.125;
                                hitMap [17] = 0.941;
                            }
                            else if (colorNo6 == "9"){
                                hitMap [15] = 0.529;
                                hitMap [16] = 0.808;
                                hitMap [17] = 0.922;
                            }
                            
                            unsigned long headPosition = 0;
                            
                            dataConversion [0] = uploadTempExp [0];
                            dataConversion [1] = uploadTempExp [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = uploadTempExp [7];
                                dataConversion [1] = uploadTempExp [6];
                                dataConversion [2] = uploadTempExp [5];
                                dataConversion [3] = uploadTempExp [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = uploadTempExp [4];
                                dataConversion [1] = uploadTempExp [5];
                                dataConversion [2] = uploadTempExp [6];
                                dataConversion [3] = uploadTempExp [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                value1 = 0;
                                value2 = 0;
                                value3 = 0;
                                value4 = 0;
                                value5 = 0;
                                value6 = 0;
                                
                                value0 = uploadTempExp [counter1];
                                
                                if (value0 >= 0 && value0 < cutHoldDIC){
                                    value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                    
                                    if (value0 < 0) value0 = 0;
                                }
                                else{
                                    
                                    value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                    
                                    if (value0 > 255) value0 = 255;
                                }
                                
                                if (statusHold1 == 1 && colorFlag1 == 1){
                                    value1 = uploadTempExpCl1 [counter1];
                                    
                                    if (value1 < cutHold1) value1 = 0;
                                    else{
                                        
                                        value1 = value1+(int)((value1-cutHold1)*levelHold1);
                                        
                                        if (value1 > 255) value1 = 255;
                                    }
                                }
                                
                                if (statusHold2 == 1 && colorFlag2 == 1){
                                    value2 = uploadTempExpCl2 [counter1];
                                    
                                    if (value2 < cutHold2) value2 = 0;
                                    else{
                                        
                                        value2 = value2+(int)((value2-cutHold2)*levelHold2);
                                        
                                        if (value2 > 255) value2 = 255;
                                    }
                                }
                                
                                if (statusHold3 == 1 && colorFlag3 == 1){
                                    value3 = uploadTempExpCl3 [counter1];
                                    
                                    if (value3 < cutHold3) value3 = 0;
                                    else{
                                        
                                        value3 = value3+(int)((value3-cutHold3)*levelHold3);
                                        
                                        if (value3 > 255) value3 = 255;
                                    }
                                }
                                
                                if (statusHold4 == 1 && colorFlag4 == 1){
                                    value4 = uploadTempExpCl4 [counter1];
                                    
                                    if (value4 < cutHold4) value4 = 0;
                                    else{
                                        
                                        value4 = value4+(int)((value4-cutHold4)*levelHold4);
                                        
                                        if (value4 > 255) value4 = 255;
                                    }
                                }
                                
                                if (statusHold5 == 1 && colorFlag5 == 1){
                                    value5 = uploadTempExpCl5 [counter1];
                                    
                                    if (value5 < cutHold5) value5 = 0;
                                    else{
                                        
                                        value5 = value5+(int)((value5-cutHold5)*levelHold5);
                                        
                                        if (value5 > 255) value5 = 255;
                                    }
                                }
                                
                                if (statusHold6 == 1 && colorFlag6 == 1){
                                    value6 = uploadTempExpCl6 [counter1];
                                    
                                    if (value6 < cutHold6) value6 = 0;
                                    else{
                                        
                                        value6 = value6+(int)((value6-cutHold6)*levelHold6);
                                        
                                        if (value6 > 255) value6 = 255;
                                    }
                                }
                                
                                if (statusHold1 == 0) value1 = 0;
                                if (statusHold2 == 0) value2 = 0;
                                if (statusHold3 == 0) value3 = 0;
                                if (statusHold4 == 0) value4 = 0;
                                if (statusHold5 == 0) value5 = 0;
                                if (statusHold6 == 0) value6 = 0;
                                
                                if (value1 <= 0 && value2 <= 0 && value3 <= 0 && value4 <= 0 && value5 <= 0 && value6 <= 0){
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = 0;
                                }
                                else{
                                    
                                    if (value1 < 0) value1 = 0;
                                    if (value2 < 0) value2 = 0;
                                    if (value3 < 0) value3 = 0;
                                    if (value4 < 0) value4 = 0;
                                    if (value5 < 0) value5 = 0;
                                    if (value6 < 0) value6 = 0;
                                    
                                    hitR = 0;
                                    hitG = 0;
                                    hitB = 0;
                                    
                                    if (value1 > 0){
                                        if (hitMap [0] != 0) hitR++;
                                        if (hitMap [1] != 0) hitG++;
                                        if (hitMap [2] != 0) hitB++;
                                    }
                                    
                                    if (value2 > 0){
                                        if (hitMap [3] != 0) hitR++;
                                        if (hitMap [4] != 0) hitG++;
                                        if (hitMap [5] != 0) hitB++;
                                    }
                                    
                                    if (value3 > 0){
                                        if (hitMap [6] != 0) hitR++;
                                        if (hitMap [7] != 0) hitG++;
                                        if (hitMap [8] != 0) hitB++;
                                    }
                                    
                                    if (value4 > 0){
                                        if (hitMap [9] != 0) hitR++;
                                        if (hitMap [10] != 0) hitG++;
                                        if (hitMap [11] != 0) hitB++;
                                    }
                                    
                                    if (value5 > 0){
                                        if (hitMap [12] != 0) hitR++;
                                        if (hitMap [13] != 0) hitG++;
                                        if (hitMap [14] != 0) hitB++;
                                    }
                                    
                                    if (value6 > 0){
                                        if (hitMap [15] != 0) hitR++;
                                        if (hitMap [16] != 0) hitG++;
                                        if (hitMap [17] != 0) hitB++;
                                    }
                                    
                                    colorHit1 = 0;
                                    colorHit2 = 0;
                                    colorHit3 = 0;
                                    colorHit4 = 0;
                                    colorHit5 = 0;
                                    colorHit6 = 0;
                                    
                                    if (hitR == 1){
                                        if (hitMap [0] != 0 && value1 > 0) colorHit1 = 1;
                                        if (hitMap [3] != 0 && value2 > 0) colorHit2 = 1;
                                        if (hitMap [6] != 0 && value3 > 0) colorHit3 = 1;
                                        if (hitMap [9] != 0 && value4 > 0) colorHit4 = 1;
                                        if (hitMap [12] != 0 && value5 > 0) colorHit5 = 1;
                                        if (hitMap [15] != 0 && value6 > 0) colorHit6 = 1;
                                    }
                                    else if (hitR == 2){
                                        if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.5;
                                        if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.5;
                                        if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.5;
                                        if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.5;
                                        if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.5;
                                        if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.5;
                                    }
                                    else if (hitR == 3){
                                        if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.33;
                                        if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.33;
                                        if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.33;
                                        if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.33;
                                        if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.33;
                                        if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.33;
                                    }
                                    else if (hitR == 4){
                                        if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.25;
                                        if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.25;
                                        if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.25;
                                        if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.25;
                                        if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.25;
                                        if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.25;
                                    }
                                    else if (hitR == 5){
                                        if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.2;
                                        if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.2;
                                        if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.2;
                                        if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.2;
                                        if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.2;
                                        if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.2;
                                    }
                                    else if (hitR == 6){
                                        if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.13;
                                        if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.13;
                                        if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.13;
                                        if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.13;
                                        if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.13;
                                        if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.13;
                                    }
                                    
                                    if (value1 > 0 && colorNo1 == "7") colorHit1 = colorHit1*0.647;
                                    else if (value1 > 0 && colorNo1 == "8") colorHit1 = colorHit1*0.627;
                                    else if (value1 > 0 && colorNo1 == "9") colorHit1 = colorHit1*0.529;
                                    
                                    if (value2 > 0 && colorNo2 == "7") colorHit2 = colorHit2*0.647;
                                    else if (value2 > 0 && colorNo2 == "8") colorHit2 = colorHit2*0.627;
                                    else if (value2 > 0 && colorNo2 == "9") colorHit2 = colorHit2*0.529;
                                    
                                    if (value3 > 0 && colorNo3 == "7") colorHit3 = colorHit3*0.647;
                                    else if (value3 > 0 && colorNo3 == "8") colorHit3 = colorHit3*0.627;
                                    else if (value3 > 0 && colorNo3 == "9") colorHit3 = colorHit3*0.529;
                                    
                                    if (value4 > 0 && colorNo4 == "7") colorHit4 = colorHit4*0.647;
                                    else if (value4 > 0 && colorNo4 == "8") colorHit4 = colorHit4*0.627;
                                    else if (value4 > 0 && colorNo4 == "9") colorHit4 = colorHit4*0.529;
                                    
                                    if (value5 > 0 && colorNo5 == "7") colorHit5 = colorHit5*0.647;
                                    else if (value5 > 0 && colorNo5 == "8") colorHit5 = colorHit5*0.627;
                                    else if (value5 > 0 && colorNo5 == "9") colorHit5 = colorHit5*0.529;
                                    
                                    if (value6 > 0 && colorNo6 == "7") colorHit6 = colorHit6*0.647;
                                    else if (value6 > 0 && colorNo6 == "8") colorHit6 = colorHit6*0.627;
                                    else if (value6 > 0 && colorNo6 == "9") colorHit6 = colorHit6*0.529;
                                    
                                    *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3+value4*(double)colorHit4+value5*(double)colorHit5+value6*(double)colorHit6));
                                    
                                    colorHit1 = 0;
                                    colorHit2 = 0;
                                    colorHit3 = 0;
                                    colorHit4 = 0;
                                    colorHit5 = 0;
                                    colorHit6 = 0;
                                    
                                    if (hitG == 1){
                                        if (hitMap [1] != 0 && value1 > 0) colorHit1 = 1;
                                        if (hitMap [4] != 0 && value2 > 0) colorHit2 = 1;
                                        if (hitMap [7] != 0 && value3 > 0) colorHit3 = 1;
                                        if (hitMap [10] != 0 && value4 > 0) colorHit4 = 1;
                                        if (hitMap [13] != 0 && value5 > 0) colorHit5 = 1;
                                        if (hitMap [16] != 0 && value6 > 0) colorHit6 = 1;
                                    }
                                    else if (hitG == 2){
                                        if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.5;
                                        if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.5;
                                        if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.5;
                                        if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.5;
                                        if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.5;
                                        if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.5;
                                    }
                                    else if (hitG == 3){
                                        if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.33;
                                        if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.33;
                                        if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.33;
                                        if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.33;
                                        if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.33;
                                        if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.33;
                                    }
                                    else if (hitG == 4){
                                        if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.25;
                                        if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.25;
                                        if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.25;
                                        if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.25;
                                        if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.25;
                                        if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.25;
                                    }
                                    else if (hitG == 5){
                                        if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.2;
                                        if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.2;
                                        if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.2;
                                        if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.2;
                                        if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.2;
                                        if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.2;
                                    }
                                    else if (hitG == 6){
                                        if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.13;
                                        if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.13;
                                        if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.13;
                                        if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.13;
                                        if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.13;
                                        if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.13;
                                    }
                                    
                                    if (value1 > 0 && colorNo1 == "8") colorHit1 = colorHit1*0.125;
                                    else if (value1 > 0 && colorNo1 == "9") colorHit1 = colorHit1*0.808;
                                    
                                    if (value2 > 0 && colorNo2 == "8") colorHit2 = colorHit2*0.125;
                                    else if (value2 > 0 && colorNo2 == "9") colorHit2 = colorHit2*0.808;
                                    
                                    if (value3 > 0 && colorNo3 == "8") colorHit3 = colorHit3*0.125;
                                    else if (value3 > 0 && colorNo3 == "9") colorHit3 = colorHit3*0.808;
                                    
                                    if (value4 > 0 && colorNo4 == "8") colorHit4 = colorHit4*0.125;
                                    else if (value4 > 0 && colorNo4 == "9") colorHit4 = colorHit4*0.808;
                                    
                                    if (value5 > 0 && colorNo5 == "8") colorHit5 = colorHit5*0.125;
                                    else if (value5 > 0 && colorNo5 == "9") colorHit5 = colorHit5*0.808;
                                    
                                    if (value6 > 0 && colorNo6 == "8") colorHit6 = colorHit6*0.125;
                                    else if (value6 > 0 && colorNo6 == "9") colorHit6 = colorHit6*0.808;
                                    
                                    *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3+value4*(double)colorHit4+value5*(double)colorHit5+value6*(double)colorHit6));
                                    
                                    colorHit1 = 0;
                                    colorHit2 = 0;
                                    colorHit3 = 0;
                                    colorHit4 = 0;
                                    colorHit5 = 0;
                                    colorHit6 = 0;
                                    
                                    if (hitB == 1){
                                        if (hitMap [2] != 0 && value1 > 0) colorHit1 = 1;
                                        if (hitMap [5] != 0 && value2 > 0) colorHit2 = 1;
                                        if (hitMap [8] != 0 && value3 > 0) colorHit3 = 1;
                                        if (hitMap [11] != 0 && value4 > 0) colorHit4 = 1;
                                        if (hitMap [14] != 0 && value5 > 0) colorHit5 = 1;
                                        if (hitMap [17] != 0 && value6 > 0) colorHit6 = 1;
                                    }
                                    else if (hitB == 2){
                                        if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.5;
                                        if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.5;
                                        if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.5;
                                        if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.5;
                                        if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.5;
                                        if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.5;
                                    }
                                    else if (hitB == 3){
                                        if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.33;
                                        if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.33;
                                        if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.33;
                                        if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.33;
                                        if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.33;
                                        if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.33;
                                    }
                                    else if (hitB == 4){
                                        if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.25;
                                        if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.25;
                                        if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.25;
                                        if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.25;
                                        if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.25;
                                        if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.25;
                                    }
                                    else if (hitB == 5){
                                        if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.2;
                                        if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.2;
                                        if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.2;
                                        if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.2;
                                        if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.2;
                                        if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.2;
                                    }
                                    else if (hitB == 6){
                                        if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.13;
                                        if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.13;
                                        if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.13;
                                        if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.13;
                                        if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.13;
                                        if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.13;
                                    }
                                    
                                    if (value1 > 0 && colorNo1 == "8") colorHit1 = colorHit1*0.941;
                                    else if (value1 > 0 && colorNo1 == "9") colorHit1 = colorHit1*0.922;
                                    
                                    if (value2 > 0 && colorNo2 == "8") colorHit2 = colorHit2*0.941;
                                    else if (value2 > 0 && colorNo2 == "9") colorHit2 = colorHit2*0.922;
                                    
                                    if (value3 > 0 && colorNo3 == "8") colorHit3 = colorHit3*0.941;
                                    else if (value3 > 0 && colorNo3 == "9") colorHit3 = colorHit3*0.922;
                                    
                                    if (value4 > 0 && colorNo4 == "8") colorHit4 = colorHit4*0.941;
                                    else if (value4 > 0 && colorNo4 == "9") colorHit4 = colorHit4*0.922;
                                    
                                    if (value5 > 0 && colorNo5 == "8") colorHit5 = colorHit5*0.941;
                                    else if (value5 > 0 && colorNo5 == "9") colorHit5 = colorHit5*0.922;
                                    
                                    if (value6 > 0 && colorNo6 == "8") colorHit6 = colorHit6*0.941;
                                    else if (value6 > 0 && colorNo6 == "9") colorHit6 = colorHit6*0.922;
                                    
                                    *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3+value4*(double)colorHit4+value5*(double)colorHit5+value6*(double)colorHit6));
                                    *bitmapData++ = 0;
                                }
                            }
                            
                            delete [] hitMap;
                        }
                        else if (imageBmpTifFlag == 1){
                            double *hitMap = new double [20];
                            
                            if (colorNo1 == "1"){
                                hitMap [0] = 0;
                                hitMap [1] = 0;
                                hitMap [2] = 1;
                            }
                            else if (colorNo1 == "2"){
                                hitMap [0] = 0;
                                hitMap [1] = 1;
                                hitMap [2] = 0;
                            }
                            else if (colorNo1 == "3"){
                                hitMap [0] = 1;
                                hitMap [1] = 1;
                                hitMap [2] = 0;
                            }
                            else if (colorNo1 == "4"){
                                hitMap [0] = 1;
                                hitMap [1] = 0;
                                hitMap [2] = 0;
                            }
                            else if (colorNo1 == "5"){
                                hitMap [0] = 1;
                                hitMap [1] = 0;
                                hitMap [2] = 1;
                            }
                            
                            if (colorNo2 == "1"){
                                hitMap [3] = 0;
                                hitMap [4] = 0;
                                hitMap [5] = 1;
                            }
                            else if (colorNo2 == "2"){
                                hitMap [3] = 0;
                                hitMap [4] = 1;
                                hitMap [5] = 0;
                            }
                            else if (colorNo2 == "3"){
                                hitMap [3] = 1;
                                hitMap [4] = 1;
                                hitMap [5] = 0;
                            }
                            else if (colorNo2 == "4"){
                                hitMap [3] = 1;
                                hitMap [4] = 0;
                                hitMap [5] = 0;
                            }
                            else if (colorNo2 == "5"){
                                hitMap [3] = 1;
                                hitMap [4] = 0;
                                hitMap [5] = 1;
                            }
                            
                            if (colorNo3 == "1"){
                                hitMap [6] = 0;
                                hitMap [7] = 0;
                                hitMap [8] = 1;
                            }
                            else if (colorNo3 == "2"){
                                hitMap [6] = 0;
                                hitMap [7] = 1;
                                hitMap [8] = 0;
                            }
                            else if (colorNo3 == "3"){
                                hitMap [6] = 1;
                                hitMap [7] = 1;
                                hitMap [8] = 0;
                            }
                            else if (colorNo3 == "4"){
                                hitMap [6] = 1;
                                hitMap [7] = 0;
                                hitMap [8] = 0;
                            }
                            else if (colorNo3 == "5"){
                                hitMap [6] = 1;
                                hitMap [7] = 0;
                                hitMap [8] = 1;
                            }
                            
                            for (int counter1 = imageXYLength-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                                    value0 = uploadTempExp [1078+counter1*imageXYLength+counter2];
                                    
                                    if (value0 >= 0 && value0 < cutHoldDIC){
                                        value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                        
                                        if (value0 < 0) value0 = 0;
                                    }
                                    else{
                                        
                                        value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                        
                                        if (value0 > 255) value0 = 255;
                                    }
                                    
                                    value1 = uploadTempExpCl1 [1078+counter1*imageXYLength+counter2];
                                    
                                    if (value1 < cutHold1) value1 = 0;
                                    else{
                                        
                                        value1 = value1+(int)((value1-cutHold1)*levelHold1);
                                        
                                        if (value1 > 255) value1 = 255;
                                    }
                                    
                                    value2 = uploadTempExpCl2 [1078+counter1*imageXYLength+counter2];
                                    
                                    if (value2 < cutHold2) value2 = 0;
                                    else{
                                        
                                        value2 = value2+(int)((value2-cutHold2)*levelHold2);
                                        
                                        if (value2 > 255) value2 = 255;
                                    }
                                    
                                    value3 = uploadTempExpCl3 [1078+counter1*imageXYLength+counter2];
                                    
                                    if (value3 < cutHold3) value3 = 0;
                                    else{
                                        
                                        value3 = value3+(int)((value3-cutHold3)*levelHold3);
                                        
                                        if (value3 > 255) value3 = 255;
                                    }
                                    
                                    if (statusHold1 == 0) value1 = 0;
                                    if (statusHold2 == 0) value2 = 0;
                                    if (statusHold3 == 0) value3 = 0;
                                    
                                    if (value1 <= 0 && value2 <= 0 && value3 <= 0){
                                        *bitmapData++ = (unsigned char)value0;
                                        *bitmapData++ = (unsigned char)value0;
                                        *bitmapData++ = (unsigned char)value0;
                                        *bitmapData++ = 0;
                                    }
                                    else{
                                        
                                        if (value1 < 0) value1 = 0;
                                        if (value2 < 0) value2 = 0;
                                        if (value3 < 0) value3 = 0;
                                        
                                        hitR = 0;
                                        hitG = 0;
                                        hitB = 0;
                                        
                                        if (value1 > 0 && statusHold1 != 0){
                                            if (hitMap [0] != 0) hitR++;
                                            if (hitMap [1] != 0) hitG++;
                                            if (hitMap [2] != 0) hitB++;
                                        }
                                        
                                        if (value2 > 0 && statusHold2 != 0){
                                            if (hitMap [3] != 0) hitR++;
                                            if (hitMap [4] != 0) hitG++;
                                            if (hitMap [5] != 0) hitB++;
                                        }
                                        
                                        if (value3 > 0 && statusHold3 != 0){
                                            if (hitMap [6] != 0) hitR++;
                                            if (hitMap [7] != 0) hitG++;
                                            if (hitMap [8] != 0) hitB++;
                                        }
                                        
                                        colorHit1 = 0;
                                        colorHit2 = 0;
                                        colorHit3 = 0;
                                        
                                        if (hitR == 1){
                                            if (hitMap [0] != 0 && value1 > 0 ) colorHit1 = 1;
                                            if (hitMap [3] != 0 && value2 > 0 ) colorHit2 = 1;
                                            if (hitMap [6] != 0 && value3 > 0 ) colorHit3 = 1;
                                            
                                        }
                                        else if (hitR == 2){
                                            if (hitMap [0] != 0 && value1 > 0 ) colorHit1 = 0.5;
                                            if (hitMap [3] != 0 && value2 > 0 ) colorHit2 = 0.5;
                                            if (hitMap [6] != 0 && value3 > 0 ) colorHit3 = 0.5;
                                        }
                                        else if (hitR == 3){
                                            if (value1 > 0) colorHit1 = 0.33;
                                            if (value2 > 0) colorHit2 = 0.33;
                                            if (value3 > 0) colorHit3 = 0.33;
                                        }
                                        
                                        *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3));
                                        
                                        colorHit1 = 0;
                                        colorHit2 = 0;
                                        colorHit3 = 0;
                                        
                                        if (hitG == 1){
                                            if (hitMap [1] != 0 && value1 > 0 ) colorHit1 = 1;
                                            if (hitMap [4] != 0 && value2 > 0 ) colorHit2 = 1;
                                            if (hitMap [7] != 0 && value3 > 0 ) colorHit3 = 1;
                                        }
                                        else if (hitG == 2){
                                            if (hitMap [1] != 0 && value1 > 0 ) colorHit1 = 0.5;
                                            if (hitMap [4] != 0 && value2 > 0 ) colorHit2 = 0.5;
                                            if (hitMap [7] != 0 && value3 > 0 ) colorHit3 = 0.5;
                                        }
                                        else if (hitG == 3){
                                            if (hitMap [1] != 0 && value1 > 0 ) colorHit1 = 0.33;
                                            if (hitMap [4] != 0 && value2 > 0 ) colorHit2 = 0.33;
                                            if (hitMap [7] != 0 && value3 > 0 ) colorHit3 = 0.33;
                                        }
                                        
                                        *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3));
                                        
                                        colorHit1 = 0;
                                        colorHit2 = 0;
                                        colorHit3 = 0;
                                        
                                        if (hitB == 1){
                                            if (hitMap [2] != 0 && value1 > 0 ) colorHit1 = 1;
                                            if (hitMap [5] != 0 && value2 > 0 ) colorHit2 = 1;
                                            if (hitMap [8] != 0 && value3 > 0 ) colorHit3 = 1;
                                        }
                                        else if (hitB == 2){
                                            if (hitMap [2] != 0 && value1 > 0 ) colorHit1 = 0.5;
                                            if (hitMap [5] != 0 && value2 > 0 ) colorHit2 = 0.5;
                                            if (hitMap [8] != 0 && value3 > 0 ) colorHit3 = 0.5;
                                        }
                                        else if (hitB == 3){
                                            if (hitMap [2] != 0 && value1 > 0 ) colorHit1 = 0.33;
                                            if (hitMap [5] != 0 && value2 > 0 ) colorHit2 = 0.33;
                                            if (hitMap [8] != 0 && value3 > 0 ) colorHit3 = 0.33;
                                        }
                                        
                                        *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3));
                                        *bitmapData++ = 0;
                                    }
                                }
                            }
                            
                            delete [] hitMap;
                        }
                    }
                    else{
                        
                        if (imageBmpTifFlag == 0){
                            unsigned long headPosition = 0;
                            
                            dataConversion [0] = uploadTempExp [0];
                            dataConversion [1] = uploadTempExp [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = uploadTempExp [7];
                                dataConversion [1] = uploadTempExp [6];
                                dataConversion [2] = uploadTempExp [5];
                                dataConversion [3] = uploadTempExp [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = uploadTempExp [4];
                                dataConversion [1] = uploadTempExp [5];
                                dataConversion [2] = uploadTempExp [6];
                                dataConversion [3] = uploadTempExp [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                value0 = uploadTempExp [counter1];
                                
                                if (value0 >= 0 && value0 < cutHoldDIC){
                                    value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                    
                                    if (value0 < 0) value0 = 0;
                                }
                                else{
                                    
                                    value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                    
                                    if (value0 > 255) value0 = 255;
                                }
                                
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = 0;
                            }
                        }
                        else if (imageBmpTifFlag == 1){
                            for (int counter1 = imageXYLength-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                                    value0 = uploadTempExp [1078+counter1*imageXYLength+counter2];
                                    
                                    if (value0 >= 0 && value0 < cutHoldDIC){
                                        value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                        
                                        if (value0 < 0) value0 = 0;
                                    }
                                    else{
                                        
                                        value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                        
                                        if (value0 > 255) value0 = 255;
                                    }
                                    
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = 0;
                                }
                            }
                        }
                    }
                }
                else if (grayColorStatus == 1){
                    int dataConversion [4];
                    int endianType = 0;
                    
                    unsigned long headPosition = 0;
                    
                    dataConversion [0] = uploadTempExp [0];
                    dataConversion [1] = uploadTempExp [1];
                    
                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                    else endianType = 0;
                    
                    headPosition = 0;
                    
                    if (endianType == 1){
                        dataConversion [0] = uploadTempExp [7];
                        dataConversion [1] = uploadTempExp [6];
                        dataConversion [2] = uploadTempExp [5];
                        dataConversion [3] = uploadTempExp [4];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    else if (endianType == 0){
                        dataConversion [0] = uploadTempExp [4];
                        dataConversion [1] = uploadTempExp [5];
                        dataConversion [2] = uploadTempExp [6];
                        dataConversion [3] = uploadTempExp [7];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                        value0 = uploadTempExp [counter1];
                        value0 = (int)(value0*(double)levelHoldR);
                        
                        if (value0 > 255) value0 = 255;
                        
                        value1 = uploadTempExp [counter1+1];
                        value1 = (int)(value1*(double)levelHoldG);
                        
                        if (value1 > 255) value1 = 255;
                        
                        value2 = uploadTempExp [counter1+2];
                        value2 = (int)(value2*(double)levelHoldB);
                        
                        if (value2 > 255) value2 = 255;
                        
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value1;
                        *bitmapData++ = (unsigned char)value2;
                        *bitmapData++ = 0;
                    }
                }
            }
            else{
                
                if (refLoadStatus == 1){
                    int dataConversion [4];
                    int endianType = 0;
                    
                    unsigned long headPosition = 0;
                    
                    dataConversion [0] = uploadTempExpRef [0];
                    dataConversion [1] = uploadTempExpRef [1];
                    
                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                    else endianType = 0;
                    
                    if (endianType == 1){
                        dataConversion [0] = uploadTempExpRef [7];
                        dataConversion [1] = uploadTempExpRef [6];
                        dataConversion [2] = uploadTempExpRef [5];
                        dataConversion [3] = uploadTempExpRef [4];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    else if (endianType == 0){
                        dataConversion [0] = uploadTempExpRef [4];
                        dataConversion [1] = uploadTempExpRef [5];
                        dataConversion [2] = uploadTempExpRef [6];
                        dataConversion [3] = uploadTempExpRef [7];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    
                    int grayColorStatusColor = 0;
                    
                    if (headPosition-8 == (unsigned long)(imageXYLength*imageXYLength)) grayColorStatusColor = 0;
                    else grayColorStatusColor = 1;
                    
                    if (grayColorStatusColor == 0){
                        int value0 = 0;
                        
                        for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                            value0 = uploadTempExpRef [counter1];
                            
                            if (value0 >= 0 && value0 < cutHoldDIC){
                                value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                
                                if (value0 < 0) value0 = 0;
                            }
                            else{
                                
                                value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                
                                if (value0 > 255) value0 = 255;
                            }
                            
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = 0;
                        }
                    }
                    else if (grayColorStatusColor == 1){
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        
                        for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                            value0 = uploadTempExpRef [counter1];
                            value0 = (int)(value0*(double)levelHoldR);
                            
                            if (value0 > 255) value0 = 255;
                            
                            value1 = uploadTempRef [counter1+1];
                            value1 = (int)(value1*(double)levelHoldG);
                            
                            if (value1 > 255) value1 = 255;
                            
                            value2 = uploadTempRef [counter1+2];
                            value2 = (int)(value2*(double)levelHoldB);
                            
                            if (value2 > 255) value2 = 255;
                            
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value1;
                            *bitmapData++ = (unsigned char)value2;
                            *bitmapData++ = 0;
                        }
                    }
                }
                else if (refLoadStatus == 2){
                    int dataConversion [4];
                    int endianType = 0;
                    
                    unsigned long headPosition = 0;
                    
                    dataConversion [0] = uploadTempExpRef2 [0];
                    dataConversion [1] = uploadTempExpRef2 [1];
                    
                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                    else endianType = 0;
                    
                    if (endianType == 1){
                        dataConversion [0] = uploadTempExpRef2 [7];
                        dataConversion [1] = uploadTempExpRef2 [6];
                        dataConversion [2] = uploadTempExpRef2 [5];
                        dataConversion [3] = uploadTempExpRef2 [4];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    else if (endianType == 0){
                        dataConversion [0] = uploadTempExpRef2 [4];
                        dataConversion [1] = uploadTempExpRef2 [5];
                        dataConversion [2] = uploadTempExpRef2 [6];
                        dataConversion [3] = uploadTempExpRef2 [7];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    
                    int grayColorStatusRef2 = 0;
                    
                    if (headPosition-8 == (unsigned long)(imageXYLength*imageXYLength)) grayColorStatusRef2 = 0;
                    else grayColorStatusRef2 = 1;
                    
                    if (grayColorStatusRef2 == 0){
                        int value0 = 0;
                        
                        for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                            value0 = uploadTempExpRef2 [counter1];
                            
                            if (value0 >= 0 && value0 < cutHoldDIC){
                                value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                
                                if (value0 < 0) value0 = 0;
                            }
                            else{
                                
                                value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                
                                if (value0 > 255) value0 = 255;
                            }
                            
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = 0;
                        }
                    }
                    else if (grayColorStatusRef2 == 1){
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        
                        for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                            value0 = uploadTempExpRef2 [counter1];
                            value0 = (int)(value0*(double)levelHoldR);
                            
                            if (value0 > 255) value0 = 255;
                            
                            value1 = uploadTempExpRef2 [counter1+1];
                            value1 = (int)(value1*(double)levelHoldG);
                            
                            if (value1 > 255) value1 = 255;
                            
                            value2 = uploadTempExpRef2 [counter1+2];
                            value2 = (int)(value2*(double)levelHoldB);
                            
                            if (value2 > 255) value2 = 255;
                            
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value1;
                            *bitmapData++ = (unsigned char)value2;
                            *bitmapData++ = 0;
                        }
                    }
                }
                else if (refLoadStatus == 3){
                    int dataConversion [4];
                    int endianType = 0;
                    
                    unsigned long headPosition = 0;
                    
                    dataConversion [0] = uploadTempExpRef3 [0];
                    dataConversion [1] = uploadTempExpRef3 [1];
                    
                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                    else endianType = 0;
                    
                    if (endianType == 1){
                        dataConversion [0] = uploadTempExpRef3 [7];
                        dataConversion [1] = uploadTempExpRef3 [6];
                        dataConversion [2] = uploadTempExpRef3 [5];
                        dataConversion [3] = uploadTempExpRef3 [4];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    else if (endianType == 0){
                        dataConversion [0] = uploadTempExpRef3 [4];
                        dataConversion [1] = uploadTempExpRef3 [5];
                        dataConversion [2] = uploadTempExpRef3 [6];
                        dataConversion [3] = uploadTempExpRef3 [7];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    
                    int grayColorStatusRef3 = 0;
                    
                    if (headPosition-8 == (unsigned long)(imageXYLength*imageXYLength)) grayColorStatusRef3 = 0;
                    else grayColorStatusRef3 = 1;
                    
                    if (grayColorStatusRef3 == 0){
                        int value0 = 0;
                        
                        for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                            value0 = uploadTempExpRef3 [counter1];
                            
                            if (value0 >= 0 && value0 < cutHoldDIC){
                                value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                
                                if (value0 < 0) value0 = 0;
                            }
                            else{
                                
                                value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                
                                if (value0 > 255) value0 = 255;
                            }
                            
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = 0;
                        }
                    }
                    else if (grayColorStatusRef3 == 1){
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        
                        for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                            value0 = uploadTempExpRef3 [counter1];
                            value0 = (int)(value0*(double)levelHoldR);
                            
                            if (value0 > 255) value0 = 255;
                            
                            value1 = uploadTempExpRef3 [counter1+1];
                            value1 = (int)(value1*(double)levelHoldG);
                            
                            if (value1 > 255) value1 = 255;
                            
                            value2 = uploadTempExpRef3 [counter1+2];
                            value2 = (int)(value2*(double)levelHoldB);
                            
                            if (value2 > 255) value2 = 255;
                            
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value1;
                            *bitmapData++ = (unsigned char)value2;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            
            exportImage2 = [[NSImage alloc] initWithSize:NSMakeSize(imageXYLength, imageXYLength)];
            [exportImage2 addRepresentation:bitmapRepsCR];
            
            //==========Graphics Context Start==========
            [NSGraphicsContext saveGraphicsState];
            [NSGraphicsContext setCurrentContext:[NSGraphicsContext graphicsContextWithBitmapImageRep:bitmapRepsCR]];
            
            double outlineWidth = 0;
            
            if (outlineWidthExport == 1) outlineWidth = 1;
            else if (outlineWidthExport == 2) outlineWidth = 2;
            else if (outlineWidthExport == 3) outlineWidth = 3;
            else if (outlineWidthExport == 4) outlineWidth = 4;
            else if (outlineWidthExport == 5) outlineWidth = 6;
            else if (outlineWidthExport == 6) outlineWidth = 8;
            else if (outlineWidthExport == 7) outlineWidth = 10;
            else if (outlineWidthExport == 8) outlineWidth = 15;
            else if (outlineWidthExport == 9) outlineWidth = 0;
            
            if (boxXLengthExp != 0 && boxYLengthExp != 0){
                [NSBezierPath setDefaultLineWidth:outlineWidth];
                [[NSColor redColor] set];
                
                xPointMarkTemp = (int)(boxXPositionExp-(boxXLengthExp/(double)2));
                xPointMarkTemp2 = (int)(boxXPositionExp+(boxXLengthExp/(double)2));
                yPointMarkTemp = imageXYLength-(int)boxYPositionExp;
                yPointMarkTemp2 = imageXYLength-(int)boxYPositionExp+boxYLengthExp;
                
                positionAA.x = xPointMarkTemp;
                positionAA.y = yPointMarkTemp;
                positionBB.x = xPointMarkTemp2;
                positionBB.y = yPointMarkTemp;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                positionAA.x = xPointMarkTemp;
                positionAA.y = yPointMarkTemp;
                positionBB.x = xPointMarkTemp;
                positionBB.y = yPointMarkTemp2;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                positionAA.x = xPointMarkTemp2;
                positionAA.y = yPointMarkTemp;
                positionBB.x = xPointMarkTemp2;
                positionBB.y = yPointMarkTemp2;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                positionAA.x = xPointMarkTemp;
                positionAA.y = yPointMarkTemp2;
                positionBB.x = xPointMarkTemp2;
                positionBB.y = yPointMarkTemp2;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            }
            
            double dotSize = 0;
            
            if (dotSizeExport== 1) dotSize = 5;
            else if (dotSizeExport == 2) dotSize = 10;
            else if (dotSizeExport == 3) dotSize = 20;
            else if (dotSizeExport == 4) dotSize = 30;
            else if (dotSizeExport == 5) dotSize = 40;
            else if (dotSizeExport == 6) dotSize = 50;
            else if (dotSizeExport == 7) dotSize = 70;
            else if (dotSizeExport == 8) dotSize = 100;
            else if (dotSizeExport == 9) dotSize = 0;
            
            if (dotNumberCurrentExp != 0 || (dotNumberCurrentExp == 0 && (dotDisplayMode == 1 || dotDisplayMode == 2))){
                int displayTimeRangeMin = dotDisplayTimeMin;
                int displayTimeRangeMax = 0;
                
                if (dotDisplayTimeMax > maxImageNo) displayTimeRangeMax = maxImageNo;
                else displayTimeRangeMax = dotDisplayTimeMax;
                
                if (displayTimeRangeMax < displayTimeRangeMin){
                    displayTimeRangeMin = 0;
                    displayTimeRangeMax = 0;
                }
                
                //cout<<dotNumberCurrentExp << " "<<displayTimeRangeMin<<" "<<displayTimeRangeMax<<" range"<<endl;
                
                if (dotDisplayMode == 0 || ((dotDisplayMode == 1 || dotDisplayMode == 2) && displayTimeRangeMin == 0 && displayTimeRangeMax == 0 && dotNumberCurrentExp != 0)){
                    for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                        if (arrayDotDataHold [counter1*3] >= 0 && arrayDotDataHold [counter1*3] <= 100000 && arrayDotDataHold [counter1*3] == timePointHoldExp){
                            xPointMarkTemp = arrayDotDataHold [counter1*3+1];
                            yPointMarkTemp = imageXYLength-arrayDotDataHold [counter1*3+2];
                            
                            [[NSColor cyanColor] set];
                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, dotSize, dotSize)];
                            [path3 fill];
                        }
                        else if (arrayDotDataHold [counter1*3] < 0 && arrayDotDataHold [counter1*3] >= -100000 && arrayDotDataHold [counter1*3]*-1 == timePointHoldExp){
                            xPointMarkTemp = arrayDotDataHold [counter1*3+1];
                            yPointMarkTemp = imageXYLength-arrayDotDataHold [counter1*3+2];
                            
                            [[NSColor redColor] set];
                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, dotSize, dotSize)];
                            [path3 fill];
                        }
                        else if (arrayDotDataHold [counter1*3] > 100000 && arrayDotDataHold [counter1*3]-100000 == timePointHoldExp){
                            xPointMarkTemp = arrayDotDataHold [counter1*3+1];
                            yPointMarkTemp = imageXYLength-arrayDotDataHold [counter1*3+2];
                            
                            [[NSColor greenColor] set];
                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, dotSize, dotSize)];
                            [path3 fill];
                        }
                        else if (arrayDotDataHold [counter1*3] < -100000 && arrayDotDataHold [counter1*3]*-1-100000 == timePointHoldExp){
                            xPointMarkTemp = arrayDotDataHold [counter1*3+1];
                            yPointMarkTemp = imageXYLength-arrayDotDataHold [counter1*3+2];
                            
                            [[NSColor magentaColor] set];
                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, dotSize, dotSize)];
                            [path3 fill];
                        }
                    }
                }
                else if (dotDisplayMode == 1){
                    for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                        if (arrayDotDataHold [counter1*3] >= 0 && arrayDotDataHold [counter1*3] <= 100000 && arrayDotDataHold [counter1*3] >= displayTimeRangeMin && arrayDotDataHold [counter1*3] <= displayTimeRangeMax){
                            xPointMarkTemp = arrayDotDataHold [counter1*3+1];
                            yPointMarkTemp = imageXYLength-arrayDotDataHold [counter1*3+2];
                            
                            [[NSColor cyanColor] set];
                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, dotSize, dotSize)];
                            [path3 fill];
                        }
                        else if (arrayDotDataHold [counter1*3] < 0 && arrayDotDataHold [counter1*3] >= -100000 && arrayDotDataHold [counter1*3]*-1 >= displayTimeRangeMin && arrayDotDataHold [counter1*3]*-1 <= displayTimeRangeMax){
                            xPointMarkTemp = arrayDotDataHold [counter1*3+1];
                            yPointMarkTemp = imageXYLength-arrayDotDataHold [counter1*3+2];
                            
                            [[NSColor redColor] set];
                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, dotSize, dotSize)];
                            [path3 fill];
                        }
                        else if (arrayDotDataHold [counter1*3] > 100000 && arrayDotDataHold [counter1*3]-100000 >= displayTimeRangeMin && arrayDotDataHold [counter1*3]-100000 <= displayTimeRangeMax){
                            xPointMarkTemp = arrayDotDataHold [counter1*3+1];
                            yPointMarkTemp = imageXYLength-arrayDotDataHold [counter1*3+2];
                            
                            [[NSColor greenColor] set];
                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, dotSize, dotSize)];
                            [path3 fill];
                        }
                        else if (arrayDotDataHold [counter1*3] < -100000 && arrayDotDataHold [counter1*3]*-1-100000 >= displayTimeRangeMin && arrayDotDataHold [counter1*3]*-1-100000 <= displayTimeRangeMax){
                            xPointMarkTemp = arrayDotDataHold [counter1*3+1];
                            yPointMarkTemp = imageXYLength-arrayDotDataHold [counter1*3+2];
                            
                            [[NSColor magentaColor] set];
                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, dotSize, dotSize)];
                            [path3 fill];
                        }
                    }
                }
                else if (dotDisplayMode == 2 && densityDiameterHold != 0 && densityValueMaxHold != 0){
                    int xImageStart = 0;
                    int yImageStart = 0;
                    int xImageSizeEX = imageXYLength;
                    int yImageSizeEX = imageXYLength;
                    
                    int center = (densityDiameterHold/2)+1;
                    int **densityMapHold = new int *[yImageSizeEX+1];
                    
                    for (int counter1 = 0; counter1 < yImageSizeEX+1; counter1++){
                        densityMapHold [counter1] = new int [xImageSizeEX+1];
                    }
                    
                    for (int counter1 = 0; counter1 < yImageSizeEX+1; counter1++){
                        for (int counter2 = 0; counter2 < xImageSizeEX+1; counter2++){
                            densityMapHold [counter1][counter2] = 0;
                        }
                    }
                    
                    
                    if (dotGCenterChoice == 0){
                        
                        for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                            if (firstSecondSelectHold == 0){
                                if (arrayDotDataHold [counter1*3] > 0 && arrayDotDataHold [counter1*3] <= 100000 && arrayDotDataHold [counter1*3] >= displayTimeRangeMin && arrayDotDataHold [counter1*3] <= displayTimeRangeMax){
                                    xPointMarkTemp = arrayDotDataHold [counter1*3+1]-xImageStart;
                                    yPointMarkTemp = imageXYLength-(arrayDotDataHold [counter1*3+2]+yImageStart);
                                    
                                    for (int counter3 = 1; counter3 <= densityDiameterHold; counter3++){
                                        for (int counter4 = 1; counter4 <= densityDiameterHold; counter4++){
                                            if (xPointMarkTemp-center+counter4 >= 0 && xPointMarkTemp-center+counter4 < xImageSizeEX && yPointMarkTemp-center+counter3 >= 0 && yPointMarkTemp-center+counter3 < yImageSizeEX && circleAreaHold [counter3][counter4] == 1){
                                                densityMapHold [yPointMarkTemp-center+counter3][xPointMarkTemp-center+counter4]++;
                                            }
                                        }
                                    }
                                }
                            }
                            else if (firstSecondSelectHold == 1){
                                if (arrayDotDataHold [counter1*3] < 0 && arrayDotDataHold [counter1*3] >= -100000 && arrayDotDataHold [counter1*3]*-1 >= displayTimeRangeMin && arrayDotDataHold [counter1*3]*-1 <= displayTimeRangeMax){
                                    xPointMarkTemp = arrayDotDataHold [counter1*3+1]-xImageStart;
                                    yPointMarkTemp = imageXYLength-(arrayDotDataHold [counter1*3+2]+yImageStart);
                                    
                                    for (int counter3 = 1; counter3 <= densityDiameterHold; counter3++){
                                        for (int counter4 = 1; counter4 <= densityDiameterHold; counter4++){
                                            if (xPointMarkTemp-center+counter4 >= 0 && xPointMarkTemp-center+counter4 < xImageSizeEX && yPointMarkTemp-center+counter3 >= 0 && yPointMarkTemp-center+counter3 < yImageSizeEX && circleAreaHold [counter3][counter4] == 1){
                                                densityMapHold [yPointMarkTemp-center+counter3][xPointMarkTemp-center+counter4]++;
                                            }
                                        }
                                    }
                                }
                            }
                            else if (firstSecondSelectHold == 2){
                                if (arrayDotDataHold [counter1*3] > 100000 && arrayDotDataHold [counter1*3]-100000 >= displayTimeRangeMin && arrayDotDataHold [counter1*3]-100000 <= displayTimeRangeMax){
                                    xPointMarkTemp = arrayDotDataHold [counter1*3+1]-xImageStart;
                                    yPointMarkTemp = imageXYLength-(arrayDotDataHold [counter1*3+2]+yImageStart);
                                    
                                    for (int counter3 = 1; counter3 <= densityDiameterHold; counter3++){
                                        for (int counter4 = 1; counter4 <= densityDiameterHold; counter4++){
                                            if (xPointMarkTemp-center+counter4 >= 0 && xPointMarkTemp-center+counter4 < xImageSizeEX && yPointMarkTemp-center+counter3 >= 0 && yPointMarkTemp-center+counter3 < yImageSizeEX && circleAreaHold [counter3][counter4] == 1){
                                                densityMapHold [yPointMarkTemp-center+counter3][xPointMarkTemp-center+counter4]++;
                                            }
                                        }
                                    }
                                }
                            }
                            else if (firstSecondSelectHold == 3){
                                if (arrayDotDataHold [counter1*3] < -100000 && arrayDotDataHold [counter1*3]*-1-100000 >= displayTimeRangeMin && arrayDotDataHold [counter1*3]*-1-100000 <= displayTimeRangeMax){
                                    xPointMarkTemp = arrayDotDataHold [counter1*3+1]-xImageStart;
                                    yPointMarkTemp = imageXYLength-(arrayDotDataHold [counter1*3+2]+yImageStart);
                                    
                                    for (int counter3 = 1; counter3 <= densityDiameterHold; counter3++){
                                        for (int counter4 = 1; counter4 <= densityDiameterHold; counter4++){
                                            if (xPointMarkTemp-center+counter4 >= 0 && xPointMarkTemp-center+counter4 < xImageSizeEX && yPointMarkTemp-center+counter3 >= 0 && yPointMarkTemp-center+counter3 < yImageSizeEX && circleAreaHold [counter3][counter4] == 1){
                                                densityMapHold [yPointMarkTemp-center+counter3][xPointMarkTemp-center+counter4]++;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else{
                        
                        for (int counter1 = 0; counter1 < timeSelectedExportCount/10; counter1++){
                            //if (arrayTimeSelectedExport [counter1*10] == 1 || arrayTimeSelectedExport [counter1*10] == 10 || arrayTimeSelectedExport [counter1*10] == 11){
                            for (int counter2 = 0; counter2 < gravityCenterExportCount/6; counter2++){
                                if (arrayGravityCenterExport [counter2*6+4] == arrayTimeSelectedExport [counter1*10+8]){
                                    
                                    xPointMarkTemp = arrayGravityCenterExport [counter2*6]-xImageStart;
                                    yPointMarkTemp = imageXYLength-(arrayGravityCenterExport [counter2*6+1]+yImageStart);
                                    
                                    for (int counter3 = 1; counter3 <= densityDiameterHold; counter3++){
                                        for (int counter4 = 1; counter4 <= densityDiameterHold; counter4++){
                                            if (xPointMarkTemp-center+counter4 >= 0 && xPointMarkTemp-center+counter4 < xImageSizeEX && yPointMarkTemp-center+counter3 >= 0 && yPointMarkTemp-center+counter3 < yImageSizeEX && circleAreaHold [counter3][counter4] == 1){
                                                densityMapHold [yPointMarkTemp-center+counter3][xPointMarkTemp-center+counter4]++;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    double valueRange = densityValueMaxHold/(double)25;
                    int eachRange = 0;
                    
                    densityValueHighest = 0;
                    
                    for (int counter1 = 0; counter1 < yImageSizeEX+1; counter1++){
                        for (int counter2 = 0; counter2 < xImageSizeEX+1; counter2++){
                            eachRange = (int)(densityMapHold [counter1][counter2]/(double)valueRange);
                            
                            if (densityValueHighest < densityMapHold [counter1][counter2]) densityValueHighest = densityMapHold [counter1][counter2];
                            
                            if (eachRange >= 24){
                                [[NSColor colorWithCalibratedRed:arrayColorRange2 [24*3] green:arrayColorRange2 [24*3+1] blue:arrayColorRange2 [24*3+2] alpha:1] set];
                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(counter2, counter1, 10, 10)];
                                [path3 fill];
                            }
                            else{
                                
                                [[NSColor colorWithCalibratedRed:arrayColorRange2 [eachRange*3] green:arrayColorRange2 [eachRange*3+1] blue:arrayColorRange2 [eachRange*3+2] alpha:1] set];
                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(counter2, counter1, 10, 10)];
                                [path3 fill];
                            }
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < yImageSizeEX+1; counter1++){
                        delete [] densityMapHold [counter1];
                    }
                    
                    delete [] densityMapHold;
                    
                    if (dotGCenterChoice == 0){
                        for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                            if (firstSecondSelectHold == 0 && arrayDotDataHold [counter1*3] >= 0 && arrayDotDataHold [counter1*3] <= 100000 && arrayDotDataHold [counter1*3] >= displayTimeRangeMin && arrayDotDataHold [counter1*3] <= displayTimeRangeMax){
                                xPointMarkTemp = arrayDotDataHold [counter1*3+1];
                                yPointMarkTemp = imageXYLength-arrayDotDataHold [counter1*3+2];
                                
                                [[NSColor blackColor] set];
                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, dotSize, dotSize)];
                                [path3 fill];
                            }
                            else if (firstSecondSelectHold == 1 && arrayDotDataHold [counter1*3] < 0 && arrayDotDataHold [counter1*3] >= -100000 && arrayDotDataHold [counter1*3]*-1 >= displayTimeRangeMin && arrayDotDataHold [counter1*3]*-1 <= displayTimeRangeMax){
                                xPointMarkTemp = arrayDotDataHold [counter1*3+1];
                                yPointMarkTemp = imageXYLength-arrayDotDataHold [counter1*3+2];
                                
                                [[NSColor blackColor] set];
                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, dotSize, dotSize)];
                                [path3 fill];
                            }
                            else if (firstSecondSelectHold == 2 && arrayDotDataHold [counter1*3] > 100000 && arrayDotDataHold [counter1*3]-100000 >= displayTimeRangeMin && arrayDotDataHold [counter1*3]-100000 <= displayTimeRangeMax){
                                xPointMarkTemp = arrayDotDataHold [counter1*3+1];
                                yPointMarkTemp = imageXYLength-arrayDotDataHold [counter1*3+2];
                                
                                [[NSColor blackColor] set];
                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, dotSize, dotSize)];
                                [path3 fill];
                            }
                            else if (firstSecondSelectHold == 3 && arrayDotDataHold [counter1*3] < -100000 && arrayDotDataHold [counter1*3]*-1-100000 >= displayTimeRangeMin && arrayDotDataHold [counter1*3]*-1-100000 <= displayTimeRangeMax){
                                xPointMarkTemp = arrayDotDataHold [counter1*3+1];
                                yPointMarkTemp = imageXYLength-arrayDotDataHold [counter1*3+2];
                                
                                [[NSColor blackColor] set];
                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, dotSize, dotSize)];
                                [path3 fill];
                            }
                        }
                    }
                }
            }
            
            if (gridStatusHold == 1){
                if (gridLinWidth == 0){
                    [NSBezierPath setDefaultLineWidth:sizeCalculation*5];
                }
                else if (gridLinWidth == 1){
                    [NSBezierPath setDefaultLineWidth:sizeCalculation*5*2];
                }
                else if (gridLinWidth == 2){
                    [NSBezierPath setDefaultLineWidth:sizeCalculation*5*4];
                }
                
                if (gridLineColor == 0){
                    [[NSColor orangeColor] set];
                }
                else if (gridLineColor == 1){
                    [[NSColor greenColor] set];
                }
                else if (gridLineColor == 2){
                    [[NSColor yellowColor] set];
                }
                else if (gridLineColor == 3){
                    [[NSColor redColor] set];
                }
                else if (gridLineColor == 4){
                    [[NSColor blueColor] set];
                }
                else if (gridLineColor == 5){
                    [[NSColor blackColor] set];
                }
                else if (gridLineColor == 6){
                    [[NSColor whiteColor] set];
                }
                
                int xGridLength = imageXYLength;
                int yGridLength = imageXYLength;
                
                xPointMarkTemp = 0;
                yPointMarkTemp = 0;
                
                positionAA.x = xPointMarkTemp;
                positionAA.y = yPointMarkTemp;
                positionBB.x = xGridLength;
                positionBB.y = yPointMarkTemp;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                positionAA.x = xPointMarkTemp;
                positionAA.y = yGridLength;
                positionBB.x = xGridLength;
                positionBB.y = yGridLength;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                positionAA.x = xPointMarkTemp;
                positionAA.y = yPointMarkTemp;
                positionBB.x = xPointMarkTemp;
                positionBB.y = yGridLength;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                positionAA.x = xGridLength;
                positionAA.y = yPointMarkTemp;
                positionBB.x = xGridLength;
                positionBB.y = yGridLength;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                if (gridDimHold > 1){
                    int xGridPosition = 0;
                    int yGridPosition = 0;
                    
                    double gridNewellDimension = imageXYLength/(double)gridDimHold;
                    int positionAccumulate = 0;
                    
                    for (int counter1 = 0; counter1 < gridDimHold-1; counter1++){
                        positionAccumulate = positionAccumulate+(int)gridNewellDimension;
                        yGridPosition = imageXYLength-positionAccumulate;
                        
                        positionAA.x = xPointMarkTemp;
                        positionAA.y = yGridPosition;
                        positionBB.x = xGridLength;
                        positionBB.y = yGridPosition;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    }
                    
                    positionAccumulate = 0;
                    
                    for (int counter1 = 0; counter1 < gridDimHold-1; counter1++){
                        positionAccumulate = positionAccumulate+(int)gridNewellDimension;
                        xGridPosition = positionAccumulate;
                        
                        positionAA.x = xGridPosition;
                        positionAA.y = yPointMarkTemp;
                        positionBB.x = xGridPosition;
                        positionBB.y = yGridLength;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    }
                }
            }
            
            //------Time One mode------
            if (areaModeStatusHold == 1){
                if (colorPasteStatus == 1){
                    for (int counterY = 0; counterY < imageXYLength; counterY++){
                        for (int counterX = 0; counterX < imageXYLength; counterX++){
                            if (revisedWorkingMapExp [counterY][counterX] != 0){
                                xPointMarkTemp = counterX;
                                yPointMarkTemp = imageXYLength-counterY;
                                
                                if (outLineSelectExport == 0 || (outLineSelectExport == 1 && (arrayTimeSelectedExport [(revisedWorkingMapExp [counterY][counterX]-1)*10] == 1 || arrayTimeSelectedExport [(revisedWorkingMapExp [counterY][counterX]-1)*10] == 10 || arrayTimeSelectedExport [(revisedWorkingMapExp [counterY][counterX]-1)*10] == 11))){
                                    if (colorHoldArea1 == 0){
                                        [[NSColor colorWithCalibratedRed:153 green:153 blue:153 alpha:1] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                        [path3 fill];
                                    }
                                    else{
                                        
                                        if (arrayTimeSelectedExport [(revisedWorkingMapExp [counterY][counterX]-1)*10] == 1){
                                            if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] <= colorHoldArea1){
                                                [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold1*3] green:arrayColorRange [colorHold1*3+1] blue:arrayColorRange [colorHold1*3+2] alpha:1] set];
                                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                                [path3 fill];
                                            }
                                            else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] > colorHoldArea1 && colorHoldArea2 == 0){
                                                [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold2*3] green:arrayColorRange [colorHold2*3+1] blue:arrayColorRange [colorHold2*3+2] alpha:1] set];
                                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                                [path3 fill];
                                            }
                                            else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] <= colorHoldArea2){
                                                [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold2*3] green:arrayColorRange [colorHold2*3+1] blue:arrayColorRange [colorHold2*3+2] alpha:1] set];
                                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                                [path3 fill];
                                            }
                                            else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] > colorHoldArea2 && colorHoldArea3 == 0){
                                                [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold3*3] green:arrayColorRange [colorHold3*3+1] blue:arrayColorRange [colorHold3*3+2] alpha:1] set];
                                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                                [path3 fill];
                                            }
                                            else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] <= colorHoldArea3){
                                                [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold3*3] green:arrayColorRange [colorHold3*3+1] blue:arrayColorRange [colorHold3*3+2] alpha:1] set];
                                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                                [path3 fill];
                                            }
                                            else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] > colorHoldArea3 && colorHoldArea4 == 0){
                                                [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold4*3] green:arrayColorRange [colorHold4*3+1] blue:arrayColorRange [colorHold4*3+2] alpha:1] set];
                                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                                [path3 fill];
                                            }
                                            else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] <= colorHoldArea4){
                                                [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold4*3] green:arrayColorRange [colorHold4*3+1] blue:arrayColorRange [colorHold4*3+2] alpha:1] set];
                                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                                [path3 fill];
                                            }
                                            else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] > colorHoldArea4 && colorHoldArea5 == 0){
                                                [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold5*3] green:arrayColorRange [colorHold5*3+1] blue:arrayColorRange [colorHold5*3+2] alpha:1] set];
                                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                                [path3 fill];
                                            }
                                            else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] <= colorHoldArea5){
                                                [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold5*3] green:arrayColorRange [colorHold5*3+1] blue:arrayColorRange [colorHold5*3+2] alpha:1] set];
                                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                                [path3 fill];
                                            }
                                            else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] > colorHoldArea5 && colorHoldArea6 == 0){
                                                [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold6*3] green:arrayColorRange [colorHold6*3+1] blue:arrayColorRange [colorHold6*3+2] alpha:1] set];
                                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                                [path3 fill];
                                            }
                                            else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] <= colorHoldArea6){
                                                [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold6*3] green:arrayColorRange [colorHold6*3+1] blue:arrayColorRange [colorHold6*3+2] alpha:1] set];
                                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                                [path3 fill];
                                            }
                                            else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] > colorHoldArea6 && colorHoldArea7 == 0){
                                                [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold7*3] green:arrayColorRange [colorHold7*3+1] blue:arrayColorRange [colorHold7*3+2] alpha:1] set];
                                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                                [path3 fill];
                                            }
                                            else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] <= colorHoldArea7){
                                                [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold7*3] green:arrayColorRange [colorHold7*3+1] blue:arrayColorRange [colorHold7*3+2] alpha:1] set];
                                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                                [path3 fill];
                                            }
                                            else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] > colorHoldArea7 && colorHoldArea8 == 0){
                                                [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold8*3] green:arrayColorRange [colorHold8*3+1] blue:arrayColorRange [colorHold8*3+2] alpha:1] set];
                                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                                [path3 fill];
                                            }
                                            else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] <= colorHoldArea8){
                                                [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold8*3] green:arrayColorRange [colorHold8*3+1] blue:arrayColorRange [colorHold8*3+2] alpha:1] set];
                                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                                [path3 fill];
                                            }
                                            else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] > colorHoldArea8 && colorHoldArea9 == 0){
                                                [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold9*3] green:arrayColorRange [colorHold9*3+1] blue:arrayColorRange [colorHold9*3+2] alpha:1] set];
                                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                                [path3 fill];
                                            }
                                            else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] <= colorHoldArea9){
                                                [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold9*3] green:arrayColorRange [colorHold9*3+1] blue:arrayColorRange [colorHold9*3+2] alpha:1] set];
                                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                                [path3 fill];
                                            }
                                            else if (arrayGravityCenterExport [(revisedWorkingMapExp [counterY][counterX]-1)*6+2] > colorHoldArea9){
                                                [[NSColor colorWithCalibratedRed:arrayColorRange [colorHold10*3] green:arrayColorRange [colorHold10*3+1] blue:arrayColorRange [colorHold10*3+2] alpha:1] set];
                                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                                [path3 fill];
                                            }
                                        }
                                        else{
                                            
                                            if (colorHoldSdStatus == 1 && arrayTimeSelectedExport [(revisedWorkingMapExp [counterY][counterX]-1)*10] == 10){
                                                [[NSColor colorWithCalibratedRed:arrayColorRange [colorHoldSd*3] green:arrayColorRange [colorHoldSd*3+1] blue:arrayColorRange [colorHoldSd*3+2] alpha:1] set];
                                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                                [path3 fill];
                                            }
                                            else if (colorHoldThStatus == 1 && arrayTimeSelectedExport [(revisedWorkingMapExp [counterY][counterX]-1)*10] == 11){
                                                [[NSColor colorWithCalibratedRed:arrayColorRange [colorHoldTh*3] green:arrayColorRange [colorHoldTh*3+1] blue:arrayColorRange [colorHoldTh*3+2] alpha:1] set];
                                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, pasteDotExport, pasteDotExport)];
                                                [path3 fill];
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
                [NSBezierPath setDefaultLineWidth:sizeCalculation];
                
                int startPoint = 0;
                int removeMark = 0;
                int connectTemp = 0;
                
                for (int counter1 = 0; counter1 < timeSelectedExportCount/10; counter1++){
                    if (arrayTimeSelectedExport [counter1*10] == 0 || arrayTimeSelectedExport [counter1*10] == 1 || arrayTimeSelectedExport [counter1*10] == 10 || arrayTimeSelectedExport [counter1*10] == 11){
                        startPoint = arrayTimeSelectedExport [counter1*10+2];
                        removeMark = arrayTimeSelectedExport [counter1*10];
                        
                        connectTemp = 0;
                        
                        for (int counter2 = startPoint; counter2 < positionExportCount/7; counter2++){
                            if (connectTemp == 0){
                                connectTemp = arrayPositionExport [counter2*7+3];
                                
                                if (removeMark == 0 && outLineSelectExport == 0){
                                    xPointMarkTemp = arrayPositionExport [counter2*7];
                                    yPointMarkTemp = imageXYLength-arrayPositionExport [counter2*7+1];
                                    
                                    [[NSColor yellowColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, outlineWidth, outlineWidth)];
                                    [path3 fill];
                                }
                                else if (removeMark == 1){
                                    xPointMarkTemp = arrayPositionExport [counter2*7];
                                    yPointMarkTemp = imageXYLength-arrayPositionExport [counter2*7+1];
                                    
                                    if (printLineColor == 0)[[NSColor greenColor] set];
                                    else if (printLineColor == 1)[[NSColor whiteColor] set];
                                    else if (printLineColor == 2)[[NSColor yellowColor] set];
                                    else if (printLineColor == 3)[[NSColor blueColor] set];
                                    else if (printLineColor == 4)[[NSColor blackColor] set];
                                    
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, outlineWidth, outlineWidth)];
                                    [path3 fill];
                                }
                                else if (removeMark == 10){
                                    xPointMarkTemp = arrayPositionExport [counter2*7];
                                    yPointMarkTemp = imageXYLength-arrayPositionExport [counter2*7+1];
                                    
                                    [[NSColor blueColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, outlineWidth, outlineWidth)];
                                    [path3 fill];
                                }
                                else if (removeMark == 11){
                                    xPointMarkTemp = arrayPositionExport [counter2*7];
                                    yPointMarkTemp = imageXYLength-arrayPositionExport [counter2*7+1];
                                    
                                    [[NSColor magentaColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, outlineWidth, outlineWidth)];
                                    [path3 fill];
                                }
                            }
                            else if (connectTemp == arrayPositionExport [counter2*7+3]){
                                if (removeMark == 0 && outLineSelectExport == 0){
                                    xPointMarkTemp = arrayPositionExport [counter2*7];
                                    yPointMarkTemp = imageXYLength-arrayPositionExport [counter2*7+1];
                                    
                                    [[NSColor yellowColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, outlineWidth, outlineWidth)];
                                    [path3 fill];
                                }
                                else if (removeMark == 1){
                                    xPointMarkTemp = arrayPositionExport [counter2*7];
                                    yPointMarkTemp = imageXYLength-arrayPositionExport [counter2*7+1];
                                    
                                    if (printLineColor == 0)[[NSColor greenColor] set];
                                    else if (printLineColor == 1)[[NSColor whiteColor] set];
                                    else if (printLineColor == 2)[[NSColor yellowColor] set];
                                    else if (printLineColor == 3)[[NSColor blueColor] set];
                                    else if (printLineColor == 4)[[NSColor blackColor] set];
                                    
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, outlineWidth, outlineWidth)];
                                    [path3 fill];
                                }
                                else if (removeMark == 10){
                                    xPointMarkTemp = arrayPositionExport [counter2*7];
                                    yPointMarkTemp = imageXYLength-arrayPositionExport [counter2*7+1];
                                    
                                    [[NSColor blueColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, outlineWidth, outlineWidth)];
                                    [path3 fill];
                                }
                                else if (removeMark == 11){
                                    xPointMarkTemp = arrayPositionExport [counter2*7];
                                    yPointMarkTemp = imageXYLength-arrayPositionExport [counter2*7+1];
                                    
                                    [[NSColor magentaColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, outlineWidth, outlineWidth)];
                                    [path3 fill];
                                }
                            }
                            else if (connectTemp != arrayPositionExport [counter2*7+3]){
                                break;
                            }
                        }
                    }
                }
                
                double targetWidth = 0;
                
                if (targetWidthExport == 1) targetWidth = 0;
                else if (targetWidthExport == 2) targetWidth = 0.5;
                else if (targetWidthExport == 3) targetWidth = 1;
                else if (targetWidthExport == 4) targetWidth = 1.5;
                else if (targetWidthExport == 5) targetWidth = 2.0;
                else if (targetWidthExport == 6) targetWidth = 4.0;
                else if (targetWidthExport == 7) targetWidth = 6.0;
                else if (targetWidthExport == 8) targetWidth = 8.0;
                
                double targetLength = 0;
                
                if (targetLengthExport == 1) targetLength = 0;
                else if (targetLengthExport == 2) targetLength = 10;
                else if (targetLengthExport == 3) targetLength = 20;
                else if (targetLengthExport == 4) targetLength = 30;
                else if (targetLengthExport == 5) targetLength = 40;
                else if (targetLengthExport == 6) targetLength = 50;
                else if (targetLengthExport == 7) targetLength = 70;
                else if (targetLengthExport == 8) targetLength = 100;
                
                double targetFont = 0;
                
                if (targetFontExport == 1) targetFont = 0;
                else if (targetFontExport == 2) targetFont = 12;
                else if (targetFontExport == 3) targetFont = 18;
                else if (targetFontExport == 4) targetFont = 24;
                else if (targetFontExport == 5) targetFont = 30;
                else if (targetFontExport == 6) targetFont = 40;
                else if (targetFontExport == 7) targetFont = 50;
                else if (targetFontExport == 8) targetFont = 60;
                
                [NSBezierPath setDefaultLineWidth:targetWidth];
                [attributesA setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                [attributesA setObject:[NSFont systemFontOfSize:targetFont] forKey:NSFontAttributeName];
                [attributesA removeObjectForKey:NSBackgroundColorAttributeName];
                
                NSString *vectorNumberDisplay;
                
                int selected = 0;
                
                for (int counter1 = 0; counter1 < gravityCenterExportCount/6; counter1++){
                    selected = arrayTimeSelectedExport [counter1*10];
                    xPointMarkTemp = arrayGravityCenterExport [counter1*6];
                    yPointMarkTemp = imageXYLength-arrayGravityCenterExport [counter1*6+1];
                    
                    if (selected == 0){
                        [[NSColor blackColor] set];
                        [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    }
                    else if (selected == 1){
                        [[NSColor redColor] set];
                        [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                    }
                    else if (selected == 10){
                        [[NSColor blueColor] set];
                        [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                    }
                    else if (selected == 11){
                        [[NSColor magentaColor] set];
                        [attributesA setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
                    }
                    
                    if (selected == 0 || selected == 1 || selected == 10 || selected == 11){
                        positionAA.x = xPointMarkTemp-targetLength;
                        positionAA.y = yPointMarkTemp;
                        positionBB.x = xPointMarkTemp+targetLength;
                        positionBB.y = yPointMarkTemp;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        positionCC.x = xPointMarkTemp;
                        positionCC.y = yPointMarkTemp-targetLength;
                        positionDD.x = xPointMarkTemp;
                        positionDD.y = yPointMarkTemp+targetLength;
                        [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                        
                        if (targetFont != 0){
                            vectorNumberDisplay = [NSString stringWithFormat:@"%d", arrayGravityCenterExport [counter1*6+4]];
                            
                            attrStrA = [[NSAttributedString alloc] initWithString:vectorNumberDisplay attributes:attributesA];
                            pointA.x = xPointMarkTemp;
                            pointA.y = yPointMarkTemp;
                            [attrStrA drawAtPoint:pointA];
                        }
                    }
                }
            }
            
            //------Info writing------
            double titleFont = 0;
            
            if (titleFontExport == 1) titleFont = 12;
            else if (titleFontExport == 2) titleFont = 18;
            else if (titleFontExport == 3) titleFont = 24;
            else if (titleFontExport == 4) titleFont = 30;
            else if (titleFontExport == 5) titleFont = 40;
            else if (titleFontExport == 6) titleFont = 50;
            else if (titleFontExport == 7) titleFont = 60;
            else if (titleFontExport == 8) titleFont = 0;
            
            //------Info writing------
            if (titleFont != 0){
                [attributesA setObject:[NSFont boldSystemFontOfSize:titleFont] forKey:NSFontAttributeName];
                [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
                
                infoDisplayString = "Time: "+to_string(filePositionExp);
                string infoCountString = "Time: 0000";
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 10;
                pointA.y = imageXYLength-100;
                [attrStrA drawAtPoint:pointA];
                
                NSFont *font = [NSFont boldSystemFontOfSize:titleFont];
                
                NSString *timeNSstring2 = @(infoCountString.c_str());
                NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributes2];
                CGFloat size2 = [attrStrS2 size].width;
                
                infoDisplayString = "Treatment: "+treatNameHold;
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 10+size2+size2*0.5;
                pointA.y = imageXYLength-100;
                [attrStrA drawAtPoint:pointA];
            }
            
            [NSGraphicsContext restoreGraphicsState];
            //==========Graphics Context End==========
            
            NSData *imageExportData;
            imageExportData = [bitmapRepsCR TIFFRepresentation];
            
            [imageExportData writeToFile:@(displayImageSavePath.c_str()) atomically:YES];
            
            if (displayModeSelect == 1) displayModeSelect = 0;
            else if (displayModeSelect == 7) displayModeSelect = 8;
        }
    }
    
    timingEx = 3;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToExportDisplay object:nil];
}

@end
