//
//  Controller.h
//  CellMovieQuant
//
//  Created by Masahiko Sato on 2014-09-29.
//
//

#ifndef CONTROLLER_H
#define CONTROLLER_H
#import <Cocoa/Cocoa.h>
#import "MovieDisplay.h"
#import "DotAreaBoxProcess.h"
#import "LineDotTypeSet.h"
#import "TargetFind.h"
#import "TargetFind2.h"
#import "LineSet.h"
#import "Merge.h"
#import "TrackingDataSave.h"
#import "ASCIIconversion.h"
#import "ExportController.h"
#import "ExportDisplay.h"
#import "DotDataCreate.h"
#import "TiffFileRead.h"
#import "SubProcesses.h"
#include <iostream>
#include <dirent.h>
#include <sys/stat.h>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <ctime>
#endif

using namespace std;

extern NSString *notificationToMovieDisplay;
extern NSString *notificationToExportController;
extern NSString *notificationToExportDisplay;

//-------Basic info------
extern string pathNameString; //Path name
extern string analysisNameHold; //Analysis name
extern string treatNameHold; //Treat name
extern string imageDataPath; //Image data path
extern string imageDisplayPath; //Image display path
extern int grayColorStatus; //Hold gray color image status

//======Movie======
//-----Arrays--------
extern string *fileList; //Hold name of files
extern int fileListCount;
extern int fileListStatus;
extern uint8_t *fileReadArray;//Array holding image data

//-------Basic operation------
extern int maxImageNo; //Largest image no
extern int timePointHold;//Current time point
extern int movieRunningFlag;//Set when movie is on
extern int filePosition;//Image position
extern int timePointDisplayCall;//Call to display time
extern int movieTiming;//Movie timing
extern int imageXYLength;//Image width
extern int imageBmpTifFlag; //Hold image format: 0 tif, 1 bmp

//------Image data--------
extern uint8_t *uploadTemp; //Hold DIC image
extern int uploadTempStatus;
extern uint8_t *uploadTempCl1;//Hold fluorescent image
extern int uploadTempStatusCl1;
extern uint8_t *uploadTempCl2;//Hold fluorescent image
extern int uploadTempStatusCl2;
extern uint8_t *uploadTempCl3;//Hold fluorescent image
extern int uploadTempStatusCl3;
extern uint8_t *uploadTempCl4;//Hold fluorescent image
extern int uploadTempStatusCl4;
extern uint8_t *uploadTempCl5;//Hold fluorescent image
extern int uploadTempStatusCl5;
extern uint8_t *uploadTempCl6;//Hold fluorescent image
extern int uploadTempStatusCl6;
extern long uploadTempFileSize; //File size of uploadTemps

extern int colorFlag1; //Fluorescent set flag
extern int colorFlag2; //Fluorescent set flag
extern int colorFlag3; //Fluorescent set flag
extern int colorFlag4; //Fluorescent set flag
extern int colorFlag5; //Fluorescent set flag
extern int colorFlag6; //Fluorescent set flag
extern string colorNo1; //Hold color no
extern string colorNo2; //Hold color no
extern string colorNo3; //Hold color no
extern string colorNo4; //Hold color no
extern string colorNo5; //Hold color no
extern string colorNo6; //Hold color no
extern string colorName1; //Hold color name
extern string colorName2; //Hold color name
extern string colorName3; //Hold color name
extern string colorName4; //Hold color name
extern string colorName5; //Hold color name
extern string colorName6; //Hold color name
extern double levelHold1; //Level hold
extern double levelHold2; //Level hold
extern double levelHold3; //Level hold
extern double levelHold4; //Level hold
extern double levelHold5; //Level hold
extern double levelHold6; //Level hold
extern double levelHoldDIC; //Level hold
extern double levelHoldR; //Level hold
extern double levelHoldG; //Level hold
extern double levelHoldB; //Level hold
extern double cutHold1; //Cut level hold
extern double cutHold2; //Cut level hold
extern double cutHold3; //Cut level hold
extern double cutHold4; //Cut level hold
extern double cutHold5; //Cut level hold
extern double cutHold6; //Cut level hold
extern double cutHoldDIC; //Cut level hold
extern int statusHold1; //Status hold
extern int statusHold2; //Status hold
extern int statusHold3; //Status hold
extern int statusHold4; //Status hold
extern int statusHold5; //Status hold
extern int statusHold6; //Status hold
extern int statusHoldDIC; //Status hold
extern int lastDICImageTime; //Last DIC image
extern int lastTIFRoundNo; //Last TIF image
extern int colorInfoDisplayCall; //Color info call

//======Dot/Box set/Area/Quantitation======
//-------Basic info------
extern int initialArraySet; //Set when dot data is set to an Array
extern string dataSavePath; //Movie data save path
extern int quantitationStatusHold; //Quantitation status
extern int analysisStatusHold; //Analysis status, Off, Dot, Clear dot
extern int areaModeStatusHold; //Area mode on off hold
extern int saveShortCutNumber; //Shortcut number hold
extern int areaTotalTable; //Area Total display status hold
extern string ascIIstring; //AscII conversion
extern int imageProgressFlag; //Set when image uploading/processing is On
extern int mergeProcessingFlag; //Set when merging processing is On
extern int phaseStatus; //Set when color image is set
extern string *fileList2; //Hold file name, created with fileList, hold Color, Ref images
extern int fileListCount2;
extern int warningSet; //Warning set
extern string directoryPathExtract; //Color image directory path

//-------Box data------
extern int boxXLength; //Box size
extern int boxYLength; //Box size
extern double boxXPosition; //Box position hold
extern double boxYPosition; //Box position hold
extern double boxXPositionCurrent; //Box position Current hold
extern double boxYPositionCurrent; //Box position Current hold
extern int dimensionSetModeHold; //Box dimension set
extern int boxDisplayCall; //Box size display call

//-------Dot data------
extern int dotNumberCurrent; //Dot count
extern int dotSetFirstSecondHold; //Dot first/second select
extern int dotExportLimitTimeTo; //Dot data export time to
extern int dotExportLimitTimeFrom; //Dot data export time from

//------Image data--------
extern uint8_t *uploadTempRef; //Ref image1
extern int uploadTempStatusRef;
extern uint8_t *uploadTempRef2; //Ref image2
extern int uploadTempStatusRef2;
extern int uploadTempLoadRef2;
extern uint8_t *uploadTempRef3; //Ref image3
extern int uploadTempStatusRef3;
extern int uploadTempLoadRef3;
extern int refLoadStatus; //Ref image loading status

extern long uploadTempRefFileSize1; //File size of Ref
extern long uploadTempRefFileSize2; //File size of Ref2
extern long uploadTempRefFileSize3; //File size of Ref3

//-------Area processing------
extern double *arrayAreaDataHold; //Area data array
extern int areaDataHoldCount;
extern int areaDataHoldLimit;
extern int *arrayDotDataHold; //Dot data array
extern int dotDataHoldCount;
extern int dotDataHoldLimit;
extern int areaValueCall; //Area data display call
extern int currentConnectNo; //Hold current connect no
extern int *groupNumberList; //Group list info hold
extern int groupNumberListCount;
extern int lineDraw; //Line draw status, 1: allow to LineSet
extern int windowLock; //Window lock status
extern int currentPositionSet;//Current connect position hold
extern int areaSetDone; //Area set status hold
extern int mergeOperationStatus; //Set when performing merge operation

//------Area processing arrays-----
extern int *arrayPositionRevise; //Hold area outline data
extern int positionReviseCount;
extern int positionReviseLimit;
extern int positionReviseAddition;

extern int *arrayGravityCenterRev; //Gravity center data
extern int gravityCenterRevCount;
extern int gravityCenterRevLimit;

extern int *arrayTimeSelected; //Time related data
extern int timeSelectedCount;
extern int timeSelectedLimit;

extern int **sourceImage; //Image processing arrays
extern int **revisedMap; //Image processing arrays
extern int **revisedWorkingMap; //Image processing arrays
extern int **connectMap200; //Image processing arrays
extern int **connectMap220; //Image processing arrays
extern int **connectMap240; //Image processing arrays
extern int **connectMapA; //Image processing arrays
extern int **connectMapB; //Image processing arrays
extern int **connectMapC; //Image processing arrays
extern int **connectMapD; //Image processing arrays
extern int imageSizeLimit; //Hold size of arrays

extern int *arrayTarget;//Outline data for target connect hold
extern int targetCount;
extern int targetLimit;

extern int *arrayGapData; //LineSet to GapFill, hold gap filled data
extern int gapDataCount;
extern int gapDataLimit;

extern int *arrayReferenceLine; //Reference line conned data hold
extern int referenceLineCount;
extern int referenceLineLimit;

extern int *arrayLineDataProcessing; //Line data for area creation hold
extern int lineDataProcessingCount;

extern int *arrayTargetHold; //Cut line data hold
extern int targetHoldCount;
extern int targetHoldLimit;
extern int targetHoldAddition;
extern int targetHoldStatus;

extern int *arrayTargetHoldInfo; //Cut line information hold
extern int targetHoldInfoCount;
extern int targetHoldInfoLimit;

//-------Line Dot display type-----
extern int targetMarkColorType; //Target mark color
extern int targetMarkWidthType; //Target mark width
extern int dotFillStatus; //Dot fill or stroke
extern int dotLength; //Dot xy length

extern int lineSizeHold; //Outline line size
extern int lineWidthFlag; //Hold cut line type, single or double

extern int lineFontShowOnOff; //Outline display on off (press V)
extern int charDisplayFlag; //Character display status

//-------Grid data-----
extern int gridDimHold; //Grid dimension
extern int gridLinWidth; //Grid width
extern int gridLineColor; //Grid color
extern int gridStatusHold; //Grid set status hold

//=======Image export=======
//-------Basic info------
extern int exportOperation; //Image export Window operation
extern string displayImageSavePath; //Image save path
extern int filePositionExp; //File position for export
extern int timePointHoldExp; //Time point for export
extern string fileSavePathHold; //Path for Tiff file save
extern int **arrayImageFileSave;//Image array for tif save
extern int timingEx; //Display timing

//------Image data--------
extern uint8_t *uploadTempExp; //Hold DIC image for export
extern int uploadTempExpStatus;
extern uint8_t *uploadTempExpCl1; //Hold fluorescent image for export
extern int uploadTempExpStatusCl1;
extern uint8_t *uploadTempExpCl2; //Hold fluorescent image for export
extern int uploadTempExpStatusCl2;
extern uint8_t *uploadTempExpCl3; //Hold fluorescent image for export
extern int uploadTempExpStatusCl3;
extern uint8_t *uploadTempExpCl4; //Hold fluorescent image for export
extern int uploadTempExpStatusCl4;
extern uint8_t *uploadTempExpCl5; //Hold fluorescent image for export
extern int uploadTempExpStatusCl5;
extern uint8_t *uploadTempExpCl6; //Hold fluorescent image for export
extern int uploadTempExpStatusCl6;

extern uint8_t *uploadTempExpRef; //Ref image1 for export
extern int uploadTempExpStatusRef;
extern uint8_t *uploadTempExpRef2; //Ref image1 for export
extern int uploadTempExpStatusRef2;
extern int uploadTempExpLoadRef2;
extern uint8_t *uploadTempExpRef3; //Ref image1 for export
extern int uploadTempExpStatusRef3;
extern int uploadTempExpLoadRef3;

extern int colorFlagExp1; //Fluorescent set flag for export
extern int colorFlagExp2; //Fluorescent set flag for export
extern int colorFlagExp3; //Fluorescent set flag for export
extern int colorFlagExp4; //Fluorescent set flag for export
extern int colorFlagExp5; //Fluorescent set flag for export
extern int colorFlagExp6; //Fluorescent set flag for export

//------Area processing arrays-----
extern int *arrayPositionExport; //Hold area outline data
extern int positionExportCount;
extern int positionExportStatus;

extern int *arrayGravityCenterExport; //Gravity center data
extern int gravityCenterExportCount;
extern int gravityCenterExportStatus;

extern int *arrayGravityCenterExportHold; //Gravity center data hold
extern int gravityCenterExportCorrectCount;
extern int gravityCenterExportCorrectStatus;

extern int *arrayTimeSelectedExport; //Time related data
extern int timeSelectedExportCount;
extern int timeSelectedExportStatus;

extern int **revisedWorkingMapExp; //Map for Export
extern int revisedWorkingMapExpStatus;

//-------Line Dot type for Print-----
extern int outlineWidthExport; //Outline width for export
extern int outLineSelectExport; //Outline display, Selected or all
extern int printLineColor; //Outline color
extern int dotSizeExport; //Dot size
extern int targetWidthExport; //Target line width
extern int targetLengthExport; //Target line length
extern int targetFontExport; //Target font size
extern int titleFontExport; //Title font size

//-------Line Dot type for Display-----
extern double lineWidthExp; //Line width
extern int pasteDotExport; //Paste size
extern int dotStyleExport; //Dot type, fill or stroke
extern int dotLengthExport; //Dot length
extern int fontCrossExport; //Gravity center font and cross display

extern int boxXLengthExp; //Box x length
extern int boxYLengthExp; //Box y length
extern double boxXPositionExp; //Box x position
extern double boxYPositionExp; //Box y position

extern int dotNumberCurrentExp; //No of dot for export

//------Color past setting--------
extern int colorHold1; //paste color selection
extern int colorHold2; //paste color selection
extern int colorHold3; //paste color selection
extern int colorHold4; //paste color selection
extern int colorHold5; //paste color selection
extern int colorHold6; //paste color selection
extern int colorHold7; //paste color selection
extern int colorHold8; //paste color selection
extern int colorHold9; //paste color selection
extern int colorHold10; //paste color selection
extern int colorHoldSd; //paste color selection for the second area
extern int colorHoldTh; //paste color selection for the third area

extern int colorHoldArea1; //Area cut off size for past
extern int colorHoldArea2; //Area cut off size for past
extern int colorHoldArea3; //Area cut off size for past
extern int colorHoldArea4; //Area cut off size for past
extern int colorHoldArea5; //Area cut off size for past
extern int colorHoldArea6; //Area cut off size for past
extern int colorHoldArea7; //Area cut off size for past
extern int colorHoldArea8; //Area cut off size for past
extern int colorHoldArea9; //Area cut off size for past

extern int colorMaxAreaHold; //Hold Max size of area
extern int numberOfGroupHold; //Number of groups

extern int colorHoldSdStatus; //Color second status
extern int colorHoldThStatus; //Color third status
extern int colorPasteStatus; //Color Past display on/off

extern CGFloat *arrayColorRange; //Color data array, for selected color to display
extern CGFloat *arrayColorRange2; //Color data array, For heat map
extern CGFloat *arrayColorRangeSource; //Color data array, Source color data

//------Dot Heat Map commands--------
extern int firstSecondSelectHold; //First dot Second dot select
extern int dotDisplayMode; //Dot Display mode hold
extern int dotDisplayTimeMin; //Time range minimal
extern int dotDisplayTimeMax; //Time range max
extern int densityDiameterHold; //Dot diameter
extern int densityDiameterPrev; //Dot diameter-previous value hold
extern int densityValueMaxHold; //Dot value Max
extern int densityValueHighest; //Hold the max overlap value of density map
extern int gridDivisionHold; // Grid division for dot data export
extern int **circleAreaHold; //Heat map drawing array (Draw circle around a dot)
extern int circleAreaHoldStatus; //Circle Area status
extern int dotGCenterChoice; //Choice of Dot GR center

@interface Controller : NSObject <NSTextFieldDelegate, NSTableViewDataSource>{
    int currentImageNo; //Current no of image
    int speedHold; //Speed
    int orientationHold; //Movie orientation
    
    double sliderFluorescentCHMax1; //Slider
    double sliderFluorescentCHMin1; //Slider
    double sliderFluorescentCHDiff1; //Slider
    double sliderCutCHMax1; //Slider
    double sliderCutCHMin1; //Slider
    double sliderCutCHDiff1; //Slider
    
    double sliderFluorescentCHMax2; //Slider
    double sliderFluorescentCHMin2; //Slider
    double sliderFluorescentCHDiff2; //Slider
    double sliderCutCHMax2; //Slider
    double sliderCutCHMin2; //Slider
    double sliderCutCHDiff2; //Slider
    
    double sliderFluorescentCHMax3; //Slider
    double sliderFluorescentCHMin3; //Slider
    double sliderFluorescentCHDiff3; //Slider
    double sliderCutCHMax3; //Slider
    double sliderCutCHMin3; //Slider
    double sliderCutCHDiff3; //Slider
    
    double sliderFluorescentCHMax4; //Slider
    double sliderFluorescentCHMin4; //Slider
    double sliderFluorescentCHDiff4; //Slider
    double sliderCutCHMax4; //Slider
    double sliderCutCHMin4; //Slider
    double sliderCutCHDiff4; //Slider
    
    double sliderFluorescentCHMax5; //Slider
    double sliderFluorescentCHMin5; //Slider
    double sliderFluorescentCHDiff5; //Slider
    double sliderCutCHMax5; //Slider
    double sliderCutCHMin5; //Slider
    double sliderCutCHDiff5; //Slider
    
    double sliderFluorescentCHMax6; //Slider
    double sliderFluorescentCHMin6; //Slider
    double sliderFluorescentCHDiff6; //Slider
    double sliderCutCHMax6; //Slider
    double sliderCutCHMin6; //Slider
    double sliderCutCHDiff6; //Slider
    
    double sliderDICMax; //Slider
    double sliderDICMin; //Slider
    double sliderDICDiff; //Slider
    double sliderCutDICMax; //Slider
    double sliderCutDICMin; //Slider
    double sliderCutDICDiff; //Slider
    
    double sliderRMax; //Slider
    double sliderRMin; //Slider
    double sliderRDiff; //Slider
    
    double sliderGMax; //Slider
    double sliderGMin; //Slider
    double sliderGDiff; //Slider
    
    double sliderBMax; //Slider
    double sliderBMin; //Slider
    double sliderBDiff; //Slider
    
    string *arrayDirectoryInfo; //For file sorting
    int directoryInfoCount;
    int directoryInfoLimit;
    
    int sliderStart; //Slider start
    int sliderEnd; //Slider end
    int warningSetB; //Warning set
    int progressTimingB; //Progress timing
    
    IBOutlet NSTextField *analysisName;
    IBOutlet NSTextField *treatment;
    IBOutlet NSTextField *timePoint;
    IBOutlet NSTextField *direction;
    IBOutlet NSTextField *speed;
    IBOutlet NSTextField *movieStatus;
    IBOutlet NSTextField *movieText;
    
    IBOutlet NSTextField *chLabel1;
    IBOutlet NSTextField *chLabel2;
    IBOutlet NSTextField *chLabel3;
    IBOutlet NSTextField *chLabel4;
    IBOutlet NSTextField *chLabel5;
    IBOutlet NSTextField *chLabel6;
    
    IBOutlet NSTextField *chName1;
    IBOutlet NSTextField *chName2;
    IBOutlet NSTextField *chName3;
    IBOutlet NSTextField *chName4;
    IBOutlet NSTextField *chName5;
    IBOutlet NSTextField *chName6;
    
    IBOutlet NSTextField *chLevel1;
    IBOutlet NSTextField *chLevel2;
    IBOutlet NSTextField *chLevel3;
    IBOutlet NSTextField *chLevel4;
    IBOutlet NSTextField *chLevel5;
    IBOutlet NSTextField *chLevel6;
    IBOutlet NSTextField *chLevelDIC;
    IBOutlet NSTextField *chLevelR;
    IBOutlet NSTextField *chLevelG;
    IBOutlet NSTextField *chLevelB;
    
    IBOutlet NSTextField *chCut1;
    IBOutlet NSTextField *chCut2;
    IBOutlet NSTextField *chCut3;
    IBOutlet NSTextField *chCut4;
    IBOutlet NSTextField *chCut5;
    IBOutlet NSTextField *chCut6;
    IBOutlet NSTextField *chCutDIC;
    
    IBOutlet NSTextField *chStatus1;
    IBOutlet NSTextField *chStatus2;
    IBOutlet NSTextField *chStatus3;
    IBOutlet NSTextField *chStatus4;
    IBOutlet NSTextField *chStatus5;
    IBOutlet NSTextField *chStatus6;
    
    IBOutlet NSTextField *chDICImage;
    IBOutlet NSTextField *chColor;
    
    IBOutlet NSSlider *sliderLevel1;
    IBOutlet NSSlider *sliderLevel2;
    IBOutlet NSSlider *sliderLevel3;
    IBOutlet NSSlider *sliderLevel4;
    IBOutlet NSSlider *sliderLevel5;
    IBOutlet NSSlider *sliderLevel6;
    IBOutlet NSSlider *sliderLevelDIC;
    IBOutlet NSSlider *sliderLevelR;
    IBOutlet NSSlider *sliderLevelG;
    IBOutlet NSSlider *sliderLevelB;
    
    IBOutlet NSSlider *sliderCut1;
    IBOutlet NSSlider *sliderCut2;
    IBOutlet NSSlider *sliderCut3;
    IBOutlet NSSlider *sliderCut4;
    IBOutlet NSSlider *sliderCut5;
    IBOutlet NSSlider *sliderCut6;
    IBOutlet NSSlider *sliderCutDIC;
    
    IBOutlet NSSlider *sliderLevelCircle1;
    IBOutlet NSSlider *sliderLevelCircle2;
    IBOutlet NSSlider *sliderLevelCircle3;
    IBOutlet NSSlider *sliderLevelCircle4;
    IBOutlet NSSlider *sliderLevelCircle5;
    IBOutlet NSSlider *sliderLevelCircle6;
    IBOutlet NSSlider *sliderLevelCircleDIC;
    IBOutlet NSSlider *sliderLevelCircleR;
    IBOutlet NSSlider *sliderLevelCircleG;
    IBOutlet NSSlider *sliderLevelCircleB;
    
    IBOutlet NSSlider *sliderCutCircle1;
    IBOutlet NSSlider *sliderCutCircle2;
    IBOutlet NSSlider *sliderCutCircle3;
    IBOutlet NSSlider *sliderCutCircle4;
    IBOutlet NSSlider *sliderCutCircle5;
    IBOutlet NSSlider *sliderCutCircle6;
    IBOutlet NSSlider *sliderCutCircleDIC;
    
    IBOutlet NSCell *sliderKnobLevel1;
    IBOutlet NSCell *sliderKnobLevel2;
    IBOutlet NSCell *sliderKnobLevel3;
    IBOutlet NSCell *sliderKnobLevel4;
    IBOutlet NSCell *sliderKnobLevel5;
    IBOutlet NSCell *sliderKnobLevel6;
    
    IBOutlet NSCell *sliderKnobCut1;
    IBOutlet NSCell *sliderKnobCut2;
    IBOutlet NSCell *sliderKnobCut3;
    IBOutlet NSCell *sliderKnobCut4;
    IBOutlet NSCell *sliderKnobCut5;
    IBOutlet NSCell *sliderKnobCut6;
    
    //======Dot/Box set/Area/Quantitation======
    IBOutlet NSTextField *quantitationModeDisplay;
    IBOutlet NSTextField *analysisModeDisplay;
    IBOutlet NSTextField *boxDimensionDisplay;
    IBOutlet NSTextField *boxDimensionSetDisplay;
    IBOutlet NSTextField *areaModeDisplay;
    IBOutlet NSTextField *colorRefStatusDisplay;
    IBOutlet NSTextField *colorRefStatusDisplay1;
    IBOutlet NSTextField *colorRefStatusDisplay2;
    IBOutlet NSTextField *jumpPosition;
    IBOutlet NSTextField *gridDimDisplay;
    IBOutlet NSTextField *gridStatusDisplay;
    IBOutlet NSTextField *cutOffAreaDisplay;
    IBOutlet NSTextField *refImageStatusDisplay;
    IBOutlet NSTextField *firstSecondDisplay;
    IBOutlet NSTextField *dotExportToDisplay;
    IBOutlet NSTextField *dotExportFromDisplay;
    
    IBOutlet NSStepper *stepper;
    IBOutlet NSStepper *stepperGrid;
    
    IBOutlet NSProgressIndicator *backSave;
    
    IBOutlet NSWindow *controllerWindow;
    IBOutlet NSBrowser *listBrowser;
    
    IBOutlet NSTableView *areaSummaryTable;
    
    id targetFind;
    id targetFind2;
    id lineSet;
    id trackingDataSave;
    id merge;
    id tiffFileRead;
    id subProcesses;
    
    NSTimer *timerCD;
}

/*
 arrayAreaDataHold: Time 1 (25), Time 2 (25)....Time end (25). Array will be reserved, No of Time point x 25
 
 0: Time pint
 1: Threshold
 2: Image Area (entier)
 3: Image Total (total pix alue of image)(entier)
 4: Average intensity
 5: Dot count
 6: Box X length
 7: Box Y length
 8: Box X origin
 9: Box Y origin
 10: Selected area
 11: Selected area, total intensity
 12: Selected area or total intensity, N0
 13: Selected area or total intensity, N1-2
 14: Selected area or total intensity, N3-4
 15: Selected area or total intensity, N5-6
 16: Selected area or total intensity, N7-8
 17: Selected area or total intensity, N9-10
 18: Selected area or total intensity, N11-12
 19: Selected area or total intensity, N13-14
 20: Selected area or total intensity, N15-16
 21: Selected area or total intensity, N17-18
 22: Selected area or total intensity, N19-20
 23: Selected area or total intensity, N21-22
 24: Selected area or total intensity, N>=23
 */

-(id)init;
-(void)dealloc;
-(void)display;
-(void)directoryInfoUpDate;
-(void)dataSetAndDisplay;

-(IBAction)quitProcess:(id)sender;
-(IBAction)startProcess:(id)sender;
-(IBAction)directionSet:(id)sender;
-(IBAction)stepperAction:(id)sender;
-(IBAction)tableReload:(id)sender;
-(IBAction)tenFW:(id)sender;
-(IBAction)tenBW:(id)sender;
-(IBAction)hundredFW:(id)sender;
-(IBAction)hundredBW:(id)sender;
-(IBAction)browserDoubleClick:(id)browser;

-(IBAction)chSet1:(id)sender;
-(IBAction)chSet2:(id)sender;
-(IBAction)chSet3:(id)sender;
-(IBAction)chSet4:(id)sender;
-(IBAction)chSet5:(id)sender;
-(IBAction)chSet6:(id)sender;
-(IBAction)sliderLevelCH1:(id)sender;
-(IBAction)sliderLevelCH2:(id)sender;
-(IBAction)sliderLevelCH3:(id)sender;
-(IBAction)sliderLevelCH4:(id)sender;
-(IBAction)sliderLevelCH5:(id)sender;
-(IBAction)sliderLevelCH6:(id)sender;
-(IBAction)sliderLevelDIC:(id)sender;
-(IBAction)sliderLevelR:(id)sender;
-(IBAction)sliderLevelG:(id)sender;
-(IBAction)sliderLevelB:(id)sender;
-(IBAction)sliderCutCH1:(id)sender;
-(IBAction)sliderCutCH2:(id)sender;
-(IBAction)sliderCutCH3:(id)sender;
-(IBAction)sliderCutCH4:(id)sender;
-(IBAction)sliderCutCH5:(id)sender;
-(IBAction)sliderCutCH6:(id)sender;
-(IBAction)sliderCutDIC:(id)sender;
-(IBAction)sliderLevelCHCircle1:(id)sender;
-(IBAction)sliderLevelCHCircle2:(id)sender;
-(IBAction)sliderLevelCHCircle3:(id)sender;
-(IBAction)sliderLevelCHCircle4:(id)sender;
-(IBAction)sliderLevelCHCircle5:(id)sender;
-(IBAction)sliderLevelCHCircle6:(id)sender;
-(IBAction)sliderLevelDICCircle:(id)sender;
-(IBAction)sliderLevelRCircle:(id)sender;
-(IBAction)sliderLevelGCircle:(id)sender;
-(IBAction)sliderLevelBCircle:(id)sender;
-(IBAction)sliderCutCHCircle1:(id)sender;
-(IBAction)sliderCutCHCircle2:(id)sender;
-(IBAction)sliderCutCHCircle3:(id)sender;
-(IBAction)sliderCutCHCircle4:(id)sender;
-(IBAction)sliderCutCHCircle5:(id)sender;
-(IBAction)sliderCutCHCircle6:(id)sender;
-(IBAction)sliderCutDICCircle:(id)sender;
-(IBAction)resetCH1:(id)sender;
-(IBAction)resetCH2:(id)sender;
-(IBAction)resetCH3:(id)sender;
-(IBAction)resetCH4:(id)sender;
-(IBAction)resetCH5:(id)sender;
-(IBAction)resetCH6:(id)sender;
-(IBAction)resetDIC:(id)sender;
-(IBAction)resetR:(id)sender;
-(IBAction)resetG:(id)sender;
-(IBAction)resetB:(id)sender;
-(IBAction)dicImageSelect:(id)sender;
-(void)setCH1:(int)mode;
-(void)setCH2:(int)mode;
-(void)setCH3:(int)mode;
-(void)setCH4:(int)mode;
-(void)setCH5:(int)mode;
-(void)setCH6:(int)mode;

//======Dot/Box set/Area/Quantitation======
-(void)arrayAreaDataHoldUpDate;
-(void)arrayDotDataHoldUpDate;
-(void)gravityCenterRevUpDate;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;

-(IBAction)areaModeSet:(id)sender;
-(IBAction)gridStatusSet:(id)sender;
-(IBAction)stepperGridSet:(id)sender;
-(IBAction)firstSecondSet:(id)sender;
-(IBAction)cutOffAreaSet:(id)sender;

-(IBAction)colorImageLoad:(id)sender;
-(IBAction)colorImageSet:(id)sender;
-(IBAction)refImageLoad1:(id)sender;
-(IBAction)refImageLoad2:(id)sender;
-(IBAction)refImageSelection:(id)sender;

-(IBAction)imageExportStart:(id)sender;
-(int)reloadImageExp;

@end
