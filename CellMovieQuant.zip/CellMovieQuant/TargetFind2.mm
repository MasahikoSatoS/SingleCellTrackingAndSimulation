//
//  TargetFind2.m
//  CellMovieQuant
//
//  Created by Masahiko Sato on 2015-01-11.
//
//

#import "TargetFind2.h"

@implementation TargetFind2

-(void)interpretationFirst :(int)processType{
    //------Data set to Maps, maxConnect holds largest connect number, maxCount holds the number of connect entry------
    int maxConnect = 0;
    
    for (int counterY = 0; counterY < imageXYLength; counterY++){
        for (int counterX = 0; counterX < imageXYLength; counterX++){
            if (revisedWorkingMap [counterY][counterX] > maxConnect) maxConnect = revisedWorkingMap [counterY][counterX];
            if (connectMap200 [counterY][counterX] > maxConnect) maxConnect = connectMap200 [counterY][counterX];
            if (connectMap220 [counterY][counterX] > maxConnect) maxConnect = connectMap220 [counterY][counterX];
            if (connectMap240 [counterY][counterX] > maxConnect) maxConnect = connectMap240 [counterY][counterX];
            if (connectMapA [counterY][counterX] > maxConnect) maxConnect = connectMapA [counterY][counterX];
            if (connectMapB [counterY][counterX] > maxConnect) maxConnect = connectMapB [counterY][counterX];
            if (connectMapC [counterY][counterX] > maxConnect) maxConnect = connectMapC [counterY][counterX];
            if (connectMapD [counterY][counterX] > maxConnect) maxConnect = connectMapD [counterY][counterX];
        }
    }
    
    //cout<<maxConnect<<" maxConnect"<<endl;
    
    //for (int counterA = 0; counterA < imageXYLength; counterA++){
    //	for (int counterB = 255; counterB < imageXYLength; counterB++) cout<<" "<<connectMapB [counterA][counterB];
    //	cout<<" connectMapB "<<counterA<<endl;
    //}
    
    //for (int counterA = 0; counterA < imageXYLength; counterA++){
    //	for (int counterB = 255; counterB < imageXYLength; counterB++) cout<<" "<<connectMapA [counterA][counterB];
    //	cout<<" connectMapA "<<counterA<<endl;
    //}
    
    int maxCount = 0;
    
    if (gravityCenterRevCount != 0) maxCount = arrayGravityCenterRev [(gravityCenterRevCount/6-1)*6+4];
    
    //cout<<maxCount<<" maxCount"<<endl;
    
    //------Overlapped Connect Histogram Preparation: find Overlap groups with Map data------
    int *intensityHistogram = new int [maxCount];
    int intensityHistogramCount = 0;
    int intensityHistogramLimit = maxCount;
    int *intensityHistogram2 = new int [maxCount];
    int intensityHistogramCount2 = 0;
    int intensityHistogramLimit2 = maxCount;
    int *intensityHistogram3 = new int [maxCount];
    int intensityHistogramCount3 = 0;
    int intensityHistogramLimit3 = maxCount;
    int *intensityHistogram4 = new int [maxCount*2];
    int intensityHistogramCount4 = 0;
    int intensityHistogramLimit4 = maxCount*2;
    int *intensityHistogram5 = new int [maxCount*2];
    int intensityHistogramCount5 = 0;
    int intensityHistogramLimit5 = maxCount*2;
    int *intensityHistogram6 = new int [maxCount*4];
    int intensityHistogramCount6 = 0;
    int intensityHistogramLimit6 = maxCount*4;
    int *intensityHistogram7 = new int [maxCount*4];
    int intensityHistogramCount7 = 0;
    int intensityHistogramLimit7 = maxCount*4;
    
    int connect4 = 0;
    int map4 = 0;
    int position4 = 0;
    int connect5 = 0;
    int map5 = 0;
    int position5 = 0;
    int connect6 = 0;
    int map6 = 0;
    int position6 = 0;
    int connect7 = 0;
    int map7 = 0;
    int position7 = 0;
    int findFlag = 0;
    int connectTemp = 0;
    
    for (int counterY = 0; counterY < imageXYLength; counterY++){
        for (int counterX = 0; counterX < imageXYLength; counterX++){
            if (revisedWorkingMap [counterY][counterX] != 0){
                connectTemp = revisedWorkingMap [counterY][counterX];
                
                if (intensityHistogramLimit-10 < intensityHistogramCount){
                    int *arrayUpDate = new int [intensityHistogramCount+10];
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount; counter1++) arrayUpDate [counter1] = intensityHistogram [counter1];
                    
                    delete [] intensityHistogram;
                    intensityHistogram = new int [intensityHistogramLimit+5000];
                    intensityHistogramLimit = intensityHistogramLimit+5000;
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount; counter1++) intensityHistogram [counter1] = arrayUpDate [counter1];
                    delete [] arrayUpDate;
                }
                
                if (intensityHistogramLimit2-10 < intensityHistogramCount2){
                    int *arrayUpDate = new int [intensityHistogramCount2+10];
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount2; counter1++) arrayUpDate [counter1] = intensityHistogram2 [counter1];
                    
                    delete [] intensityHistogram2;
                    intensityHistogram2 = new int [intensityHistogramLimit2+5000];
                    intensityHistogramLimit2 = intensityHistogramLimit2+5000;
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount2; counter1++) intensityHistogram2 [counter1] = arrayUpDate [counter1];
                    delete [] arrayUpDate;
                }
                
                if (intensityHistogramLimit3-10 < intensityHistogramCount3){
                    int *arrayUpDate = new int [intensityHistogramCount3+10];
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount3; counter1++) arrayUpDate [counter1] = intensityHistogram3 [counter1];
                    
                    delete [] intensityHistogram3;
                    intensityHistogram3 = new int [intensityHistogramLimit3+5000];
                    intensityHistogramLimit3 = intensityHistogramLimit3+5000;
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount3; counter1++) intensityHistogram3 [counter1] = arrayUpDate [counter1];
                    delete [] arrayUpDate;
                }
                
                if (intensityHistogramLimit4-10 < intensityHistogramCount4){
                    int *arrayUpDate = new int [intensityHistogramCount4+10];
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount4; counter1++) arrayUpDate [counter1] = intensityHistogram4 [counter1];
                    
                    delete [] intensityHistogram4;
                    intensityHistogram4 = new int [intensityHistogramLimit4+5000];
                    intensityHistogramLimit4 = intensityHistogramLimit4+5000;
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount4; counter1++) intensityHistogram4 [counter1] = arrayUpDate [counter1];
                    delete [] arrayUpDate;
                }
                
                if (intensityHistogramLimit5-10 < intensityHistogramCount5){
                    int *arrayUpDate = new int [intensityHistogramCount5+10];
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount5; counter1++) arrayUpDate [counter1] = intensityHistogram5 [counter1];
                    
                    delete [] intensityHistogram5;
                    intensityHistogram5 = new int [intensityHistogramLimit5+5000];
                    intensityHistogramLimit5 = intensityHistogramLimit5+5000;
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount5; counter1++) intensityHistogram5 [counter1] = arrayUpDate [counter1];
                    delete [] arrayUpDate;
                }
                
                if (intensityHistogramLimit6-10 < intensityHistogramCount6){
                    int *arrayUpDate = new int [intensityHistogramCount6+10];
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount6; counter1++) arrayUpDate [counter1] = intensityHistogram6 [counter1];
                    
                    delete [] intensityHistogram6;
                    intensityHistogram6 = new int [intensityHistogramLimit6+5000];
                    intensityHistogramLimit6 = intensityHistogramLimit6+5000;
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount6; counter1++) intensityHistogram6 [counter1] = arrayUpDate [counter1];
                    delete [] arrayUpDate;
                }
                
                if (intensityHistogramLimit7-10 < intensityHistogramCount7){
                    int *arrayUpDate = new int [intensityHistogramCount7+10];
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount7; counter1++) arrayUpDate [counter1] = intensityHistogram7 [counter1];
                    
                    delete [] intensityHistogram7;
                    intensityHistogram7 = new int [intensityHistogramLimit7+5000];
                    intensityHistogramLimit7 = intensityHistogramLimit7+5000;
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount7; counter1++) intensityHistogram7 [counter1] = arrayUpDate [counter1];
                    delete [] arrayUpDate;
                }
                
                if (connectMap240 [counterY][counterX] != 0){
                    findFlag = 0;
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount/3; counter1++){
                        if (intensityHistogram [counter1*3] == connectTemp && intensityHistogram [counter1*3+1] == connectMap240 [counterY][counterX]){
                            intensityHistogram [counter1*3+2]++;
                            findFlag = 1;
                            break;
                        }
                    }
                    
                    if (findFlag == 0){
                        intensityHistogram [intensityHistogramCount] = connectTemp, intensityHistogramCount++;
                        intensityHistogram [intensityHistogramCount] = connectMap240 [counterY][counterX], intensityHistogramCount++;
                        intensityHistogram [intensityHistogramCount] = 1, intensityHistogramCount++;
                    }
                }
                
                if (connectMap220 [counterY][counterX] != 0){
                    findFlag = 0;
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount2/3; counter1++){
                        if (intensityHistogram2 [counter1*3] == connectTemp && intensityHistogram2 [counter1*3+1] == connectMap220 [counterY][counterX]){
                            intensityHistogram2 [counter1*3+2]++;
                            findFlag = 1;
                            break;
                        }
                    }
                    
                    if (findFlag == 0){
                        intensityHistogram2 [intensityHistogramCount2] = connectTemp, intensityHistogramCount2++;
                        intensityHistogram2 [intensityHistogramCount2] = connectMap220 [counterY][counterX], intensityHistogramCount2++;
                        intensityHistogram2 [intensityHistogramCount2] = 1, intensityHistogramCount2++;
                    }
                }
                
                if (connectMap200 [counterY][counterX] != 0){
                    findFlag = 0;
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount3/3; counter1++){
                        if (intensityHistogram3 [counter1*3] == connectTemp && intensityHistogram3 [counter1*3+1] == connectMap200 [counterY][counterX]){
                            intensityHistogram3 [counter1*3+2]++;
                            findFlag = 1;
                            break;
                        }
                    }
                    
                    if (findFlag == 0){
                        intensityHistogram3 [intensityHistogramCount3] = connectTemp, intensityHistogramCount3++;
                        intensityHistogram3 [intensityHistogramCount3] = connectMap200 [counterY][counterX], intensityHistogramCount3++;
                        intensityHistogram3 [intensityHistogramCount3] = 1, intensityHistogramCount3++;
                    }
                }
                
                if (connectMapA [counterY][counterX] != 0){
                    findFlag = 0;
                    
                    if (connect4 != connectTemp || map4 != connectMapA [counterY][counterX]){
                        for (int counter1 = 0; counter1 < intensityHistogramCount4/3; counter1++){
                            if (intensityHistogram4 [counter1*3] == connectTemp && intensityHistogram4 [counter1*3+1] == connectMapA [counterY][counterX]){
                                intensityHistogram4 [counter1*3+2]++;
                                findFlag = 1;
                                connect4 = connectTemp, map4 = connectMapA [counterY][counterX], position4 = counter1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0){
                            intensityHistogram4 [intensityHistogramCount4] = connectTemp, intensityHistogramCount4++;
                            intensityHistogram4 [intensityHistogramCount4] = connectMapA [counterY][counterX], intensityHistogramCount4++;
                            intensityHistogram4 [intensityHistogramCount4] = 1, intensityHistogramCount4++;
                            connect4 = connectTemp, map4 = connectMapA [counterY][counterX], position4 = intensityHistogramCount4/3;
                        }
                    }
                    else intensityHistogram4 [position4*3+2]++;
                }
                
                if (connectMapB [counterY][counterX] != 0){
                    findFlag = 0;
                    
                    if (connect5 != connectTemp || map5 != connectMapB [counterY][counterX]){
                        for (int counter1 = 0; counter1 < intensityHistogramCount5/3; counter1++){
                            if (intensityHistogram5 [counter1*3] == connectTemp && intensityHistogram5 [counter1*3+1] == connectMapB [counterY][counterX]){
                                intensityHistogram5 [counter1*3+2]++;
                                findFlag = 1;
                                connect5 = connectTemp, map5 = connectMapB [counterY][counterX], position5 = counter1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0){
                            intensityHistogram5 [intensityHistogramCount5] = connectTemp, intensityHistogramCount5++;
                            intensityHistogram5 [intensityHistogramCount5] = connectMapB [counterY][counterX], intensityHistogramCount5++;
                            intensityHistogram5 [intensityHistogramCount5] = 1, intensityHistogramCount5++;
                            connect5 = connectTemp, map5 = connectMapB [counterY][counterX], position5 = intensityHistogramCount5/3;
                        }
                    }
                    else intensityHistogram5 [position5*3+2]++;
                }
                
                if (connectMapC [counterY][counterX] != 0){
                    findFlag = 0;
                    
                    if (connect6 != connectTemp || map6 != connectMapC [counterY][counterX]){
                        for (int counter1 = 0; counter1 < intensityHistogramCount6/3; counter1++){
                            if (intensityHistogram6 [counter1*3] == connectTemp && intensityHistogram6 [counter1*3+1] == connectMapC [counterY][counterX]){
                                intensityHistogram6 [counter1*3+2]++;
                                findFlag = 1;
                                connect6 = connectTemp, map6 = connectMapC [counterY][counterX], position6 = counter1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0){
                            intensityHistogram6 [intensityHistogramCount6] = connectTemp, intensityHistogramCount6++;
                            intensityHistogram6 [intensityHistogramCount6] = connectMapC [counterY][counterX], intensityHistogramCount6++;
                            intensityHistogram6 [intensityHistogramCount6] = 1, intensityHistogramCount6++;
                            connect6 = connectTemp, map6 = connectMapC [counterY][counterX], position6 = intensityHistogramCount6/3;
                        }
                    }
                    else intensityHistogram6 [position6*3+2]++;
                }
                
                if (connectMapD [counterY][counterX] != 0){
                    findFlag = 0;
                    
                    if (connect7 != connectTemp || map7 != connectMapD [counterY][counterX]){
                        for (int counter1 = 0; counter1 < intensityHistogramCount7/3; counter1++){
                            if (intensityHistogram7 [counter1*3] == connectTemp && intensityHistogram7 [counter1*3+1] == connectMapD [counterY][counterX]){
                                intensityHistogram7 [counter1*3+2]++;
                                findFlag = 1;
                                connect7 = connectTemp, map7 = connectMapD [counterY][counterX], position7 = counter1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0){
                            intensityHistogram7 [intensityHistogramCount7] = connectTemp, intensityHistogramCount7++;
                            intensityHistogram7 [intensityHistogramCount7] = connectMapD [counterY][counterX], intensityHistogramCount7++;
                            intensityHistogram7 [intensityHistogramCount7] = 1, intensityHistogramCount7++;
                            connect7 = connectTemp, map7 = connectMapD [counterY][counterX], position7 = intensityHistogramCount7/3;
                        }
                    }
                    else intensityHistogram7 [position7*3+2]++;
                }
            }
        }
    }
    
    //cout<<time2-time1<<" "<<maxCount*4<<" "<<intensityHistogramCount4<<" "<<intensityHistogramCount5<<" "<<intensityHistogramCount6<<" HistInfo"<<endl;
    
    //for (int counterA = 0; counterA < intensityHistogramCount/3; counterA++){
    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<intensityHistogram [counterA*3+counterB];
    //	cout<<" intensityHistogram "<<counterA+1<<" "<<endl;
    //}
    
    //for (int counterA = 0; counterA < intensityHistogramCount2/3; counterA++){
    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<intensityHistogram2 [counterA*3+counterB];
    //	cout<<" intensityHistogram2 "<<counterA+1<<" "<<endl;
    //}
    
    //for (int counterA = 0; counterA < intensityHistogramCount2/3; counterA++){
    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<intensityHistogram6 [counterA*3+counterB];
    //	cout<<" intensityHistogram6 "<<counterA+1<<" "<<endl;
    //}
    
    //------Select Largest Connect Group >> int intensityHistogramList [][]------
    int *intensityHistogramList = new int [(maxCount+1)*7+5];
    
    for (int counter1 = 0; counter1 < (maxCount+1)*7+5; counter1++) intensityHistogramList [counter1] = 0;
    
    int countPreviousTemp = 0;
    
    for (int counter1 = 0; counter1 < intensityHistogramCount/3; counter1++){
        countPreviousTemp = 0;
        
        if (intensityHistogramList [intensityHistogram [counter1*3]*7] != 0){
            for (int counter2 = 0; counter2 < intensityHistogramCount/3; counter2++){
                if (intensityHistogram [counter2*3] == intensityHistogram [counter1*3] && intensityHistogram [counter2*3+1] == intensityHistogramList [intensityHistogram [counter1*3]*7]){
                    countPreviousTemp = intensityHistogram [counter2*3+2];
                    break;
                }
            }
            
            if (countPreviousTemp > intensityHistogram [counter1*3+2]) intensityHistogramList [intensityHistogram [counter1*3]*7] = intensityHistogram [counter1*3+1];
        }
        else intensityHistogramList [intensityHistogram [counter1*3]*7] = intensityHistogram [counter1*3+1];
    }
    
    for (int counter1 = 0; counter1 < intensityHistogramCount2/3; counter1++){
        countPreviousTemp = 0;
        
        if (intensityHistogramList [intensityHistogram2 [counter1*3]*7+1] != 0){
            for (int counter2 = 0; counter2 < intensityHistogramCount2/3; counter2++){
                if (intensityHistogram2 [counter2*3] == intensityHistogram2 [counter1*3] && intensityHistogram2 [counter2*3+1] == intensityHistogramList [intensityHistogram2 [counter1*3]*7+1]){
                    countPreviousTemp = intensityHistogram2 [counter2*3+2];
                    break;
                }
            }
            
            if (countPreviousTemp > intensityHistogram2 [counter1*3+2]) intensityHistogramList [intensityHistogram2 [counter1*3]*7+1] = intensityHistogram2 [counter1*3+1];
        }
        else intensityHistogramList [intensityHistogram2 [counter1*3]*7+1] = intensityHistogram2 [counter1*3+1];
    }
    
    for (int counter1 = 0; counter1 < intensityHistogramCount3/3; counter1++){
        countPreviousTemp = 0;
        
        if (intensityHistogramList [intensityHistogram3 [counter1*3]*7+2] != 0){
            for (int counter2 = 0; counter2 < intensityHistogramCount3/3; counter2++){
                if (intensityHistogram3 [counter2*3] == intensityHistogram3 [counter1*3] && intensityHistogram3 [counter2*3+1] == intensityHistogramList [intensityHistogram3 [counter1*3]*7+2]){
                    countPreviousTemp = intensityHistogram3 [counter2*3+2];
                    break;
                }
            }
            
            if (countPreviousTemp > intensityHistogram3 [counter1*3+2]) intensityHistogramList [intensityHistogram3 [counter1*3]*7+2] = intensityHistogram3 [counter1*3+1];
        }
        else intensityHistogramList [intensityHistogram3 [counter1*3]*7+2] = intensityHistogram3 [counter1*3+1];
    }
    
    for (int counter1 = 0; counter1 < intensityHistogramCount4/3; counter1++){
        countPreviousTemp = 0;
        
        if (intensityHistogramList [intensityHistogram4 [counter1*3]*7+3] != 0){
            for (int counter2 = 0; counter2 < intensityHistogramCount4/3; counter2++){
                if (intensityHistogram4 [counter2*3] == intensityHistogram4 [counter1*3] && intensityHistogram4 [counter2*3+1] == intensityHistogramList [intensityHistogram4 [counter1*3]*7+3]){
                    countPreviousTemp = intensityHistogram4 [counter2*3+2];
                    break;
                }
            }
            
            if (countPreviousTemp > intensityHistogram4 [counter1*3+2]) intensityHistogramList [intensityHistogram4 [counter1*3]*7+3] = intensityHistogram4 [counter1*3+1];
        }
        else intensityHistogramList [intensityHistogram4 [counter1*3]*7+3] = intensityHistogram4 [counter1*3+1];
    }
    
    for (int counter1 = 0; counter1 < intensityHistogramCount5/3; counter1++){
        countPreviousTemp = 0;
        
        if (intensityHistogramList [intensityHistogram5 [counter1*3]*7+4] != 0){
            for (int counter2 = 0; counter2 < intensityHistogramCount5/3; counter2++){
                if (intensityHistogram5 [counter2*3] == intensityHistogram5 [counter1*3] && intensityHistogram5 [counter2*3+1] == intensityHistogramList [intensityHistogram5 [counter1*3]*7+4]){
                    countPreviousTemp = intensityHistogram5 [counter2*3+2];
                    break;
                }
            }
            
            if (countPreviousTemp > intensityHistogram5 [counter1*3+2]) intensityHistogramList [intensityHistogram5 [counter1*3]*7+4] = intensityHistogram5 [counter1*3+1];
        }
        else intensityHistogramList [intensityHistogram5 [counter1*3]*7+4] = intensityHistogram5 [counter1*3+1];
    }
    
    for (int counter1 = 0; counter1 < intensityHistogramCount6/3; counter1++){
        countPreviousTemp = 0;
        
        if (intensityHistogramList [intensityHistogram6 [counter1*3]*7+5] != 0){
            for (int counter2 = 0; counter2 < intensityHistogramCount6/3; counter2++){
                if (intensityHistogram6 [counter2*3] == intensityHistogram6 [counter1*3] && intensityHistogram6 [counter2*3+1] == intensityHistogramList [intensityHistogram6 [counter1*3]*7+5]){
                    countPreviousTemp = intensityHistogram6 [counter2*3+2];
                    break;
                }
            }
            
            if (countPreviousTemp > intensityHistogram6 [counter1*3+2]) intensityHistogramList [intensityHistogram6 [counter1*3]*7+5] = intensityHistogram6 [counter1*3+1];
        }
        else intensityHistogramList [intensityHistogram6 [counter1*3]*7+5] = intensityHistogram6 [counter1*3+1];
    }
    
    for (int counter1 = 0; counter1 < intensityHistogramCount7/3; counter1++){
        countPreviousTemp = 0;
        
        if (intensityHistogramList [intensityHistogram7 [counter1*3]*7+6] != 0){
            for (int counter2 = 0; counter2 < intensityHistogramCount7/3; counter2++){
                if (intensityHistogram7 [counter2*3] == intensityHistogram7 [counter1*3] && intensityHistogram7 [counter2*3+1] == intensityHistogramList [intensityHistogram7 [counter1*3]*7+6]){
                    countPreviousTemp = intensityHistogram7 [counter2*3+2];
                    break;
                }
            }
            
            if (countPreviousTemp > intensityHistogram7 [counter1*3+2]) intensityHistogramList [intensityHistogram7 [counter1*3]*7+6] = intensityHistogram7 [counter1*3+1];
        }
        else intensityHistogramList [intensityHistogram7 [counter1*3]*7+6] = intensityHistogram7 [counter1*3+1];
    }
    
    //for (int counterA = 1; counterA < maxCount+1; counterA++){
    //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<intensityHistogramList [counterA*7+counterB];
    //	cout<<" intensityHistogramList "<<counterA<<" "<<endl;
    //}
    
    delete [] intensityHistogram;
    delete [] intensityHistogram2;
    delete [] intensityHistogram3;
    delete [] intensityHistogram4;
    delete [] intensityHistogram5;
    delete [] intensityHistogram6;
    delete [] intensityHistogram7;
    
    //------Area and Intensity Information------
    int *areaIntensityList = new int [(maxCount+1)*2+5];
    
    for (int counter1 = 1; counter1 < (maxCount+1)*2+5; counter1++) areaIntensityList [counter1] = 0;
    
    for (int counter1 = 1; counter1 < maxCount+1; counter1++){
        areaIntensityList [arrayGravityCenterRev [(counter1-1)*6+4]*2] = arrayGravityCenterRev [(counter1-1)*6+2];
        areaIntensityList [arrayGravityCenterRev [(counter1-1)*6+4]*2+1] = arrayGravityCenterRev [(counter1-1)*6+3];
    }
    
    //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
    //	cout<<" arrayGravityCenterRev "<<counterA<<endl;
    //}
    
    //for (int counterA = 1; counterA < maxCount+1; counterA++){
    //	cout<<counterA<<" "<<areaIntensityList [counterA*2]<<" "<<areaIntensityList [counterA*2+1]<<" areaIntensityList"<<endl;
    //}
    
    //------Attached Number List >> attachedNumberList [][]------
    //1. connect No, 2. attached connect No, 3. attach Length, 4. Connect No line length, 5, attached connect No line length
    
    int *attachedNumberList = new int [maxCount+2];
    int attachedNumberListCount = 0;
    int attachedNumberListLimit = 0;
    
    for (int counter1 = 0; counter1 < maxCount+2; counter1++) attachedNumberList [counter1] = 0;
    
    int attachFindA = 0;
    int attachFindA2 = 0;
    int attachFindA3 = 0;
    int attachFindB = 0;
    int attachFindB2 = 0;
    int attachFindB3 = 0;
    int attachFindC = 0;
    int attachFindC2 = 0;
    int attachFindC3 = 0;
    int attachFindD = 0;
    int attachFindD2 = 0;
    int attachFindD3 = 0;
    int attachFindE = 0;
    int attachFindE2 = 0;
    int attachFindE3 = 0;
    int attachFindF = 0;
    int attachFindF2 = 0;
    int attachFindF3 = 0;
    int attachFindG = 0;
    int attachFindG2 = 0;
    int attachFindG3 = 0;
    int attachFindH = 0;
    int attachFindH2 = 0;
    int attachFindH3 = 0;
    
    int attachPointCount = 0;
    
    for (int counterY = 0; counterY < imageXYLength; counterY++){
        for (int counterX = 0; counterX < imageXYLength; counterX++){
            if (revisedWorkingMap [counterY][counterX] != 0){
                if (attachedNumberListLimit-10 < attachedNumberListCount){
                    int *arrayUpDate = new int [attachedNumberListCount+10];
                    
                    for (int counter1 = 0; counter1 < attachedNumberListCount; counter1++) arrayUpDate [counter1] = attachedNumberList [counter1];
                    
                    delete [] attachedNumberList;
                    attachedNumberList = new int [attachedNumberListLimit+5000];
                    attachedNumberListLimit = attachedNumberListLimit+5000;
                    
                    for (int counter1 = 0; counter1 < attachedNumberListCount; counter1++) attachedNumberList [counter1] = arrayUpDate [counter1];
                    delete [] arrayUpDate;
                }
                
                attachPointCount = 0;
                
                if (counterY-1 >= 0 && counterX-1 >= 0 && revisedWorkingMap [counterY-1][counterX-1] != 0 && revisedWorkingMap [counterY-1][counterX-1] != revisedWorkingMap [counterY][counterX]){
                    if (attachFindA != revisedWorkingMap [counterY][counterX] || attachFindA2 != revisedWorkingMap [counterY-1][counterX-1]){
                        findFlag = 0;
                        
                        for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                            if (attachedNumberList [counter1*5] == revisedWorkingMap [counterY][counterX] && attachedNumberList [counter1*5+1] == revisedWorkingMap [counterY-1][counterX-1]){
                                if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                findFlag = 1, attachFindA = revisedWorkingMap [counterY][counterX], attachFindA2 = revisedWorkingMap [counterY-1][counterX-1], attachFindA3 = counter1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0){
                            attachedNumberList [attachedNumberListCount] = revisedWorkingMap [counterY][counterX], attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = revisedWorkingMap [counterY-1][counterX-1], attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                            attachFindA = revisedWorkingMap [counterY][counterX], attachFindA2 = revisedWorkingMap [counterY-1][counterX-1], attachFindA3 = attachedNumberListCount/5;
                            attachPointCount++;
                        }
                    }
                    else if (attachPointCount == 0) attachedNumberList [attachFindA3*5+2]++, attachPointCount++;
                }
                
                if (counterY-1 >= 0 && revisedWorkingMap [counterY-1][counterX] != 0 && revisedWorkingMap [counterY-1][counterX] != revisedWorkingMap [counterY][counterX]){
                    if (attachFindB != revisedWorkingMap [counterY][counterX] || attachFindB2 != revisedWorkingMap [counterY-1][counterX]){
                        findFlag = 0;
                        
                        for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                            if (attachedNumberList [counter1*5] == revisedWorkingMap [counterY][counterX] && attachedNumberList [counter1*5+1] == revisedWorkingMap [counterY-1][counterX]){
                                if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                findFlag = 1, attachFindB = revisedWorkingMap [counterY][counterX], attachFindB2 = revisedWorkingMap [counterY-1][counterX], attachFindB3 = counter1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0){
                            attachedNumberList [attachedNumberListCount] = revisedWorkingMap [counterY][counterX], attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = revisedWorkingMap [counterY-1][counterX], attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                            attachFindB = revisedWorkingMap [counterY][counterX], attachFindB2 = revisedWorkingMap [counterY-1][counterX], attachFindB3 = attachedNumberListCount/5;
                            attachPointCount++;
                        }
                    }
                    else if (attachPointCount == 0) attachedNumberList [attachFindB3*5+2]++, attachPointCount++;
                }
                
                if (counterY-1 >= 0 && counterX+1 < imageXYLength && revisedWorkingMap [counterY-1][counterX+1] != 0 && revisedWorkingMap [counterY-1][counterX+1] != revisedWorkingMap [counterY][counterX]){
                    if (attachFindC != revisedWorkingMap [counterY][counterX] || attachFindC2 != revisedWorkingMap [counterY-1][counterX+1]){
                        findFlag = 0;
                        
                        for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                            if (attachedNumberList [counter1*5] == revisedWorkingMap [counterY][counterX] && attachedNumberList [counter1*5+1] == revisedWorkingMap [counterY-1][counterX+1]){
                                if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                findFlag = 1, attachFindC = revisedWorkingMap [counterY][counterX], attachFindC2 = revisedWorkingMap [counterY-1][counterX+1], attachFindC3 = counter1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0){
                            attachedNumberList [attachedNumberListCount] = revisedWorkingMap [counterY][counterX], attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = revisedWorkingMap [counterY-1][counterX+1], attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                            attachFindC = revisedWorkingMap [counterY][counterX], attachFindC2 = revisedWorkingMap [counterY-1][counterX+1], attachFindC3 = attachedNumberListCount/5;
                            attachPointCount++;
                        }
                    }
                    else if (attachPointCount == 0) attachedNumberList [attachFindC3*5+2]++, attachPointCount++;
                }
                
                if (counterX+1 < imageXYLength && revisedWorkingMap [counterY][counterX+1] != 0 && revisedWorkingMap [counterY][counterX+1] != revisedWorkingMap [counterY][counterX]){
                    if (attachFindD != revisedWorkingMap [counterY][counterX] || attachFindD2 != revisedWorkingMap [counterY][counterX+1]){
                        findFlag = 0;
                        
                        for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                            if (attachedNumberList [counter1*5] == revisedWorkingMap [counterY][counterX] && attachedNumberList [counter1*5+1] == revisedWorkingMap [counterY][counterX+1]){
                                if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                findFlag = 1, attachFindD = revisedWorkingMap [counterY][counterX], attachFindD2 = revisedWorkingMap [counterY][counterX+1], attachFindD3 = counter1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0){
                            attachedNumberList [attachedNumberListCount] = revisedWorkingMap [counterY][counterX], attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = revisedWorkingMap [counterY][counterX+1], attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                            attachFindD = revisedWorkingMap [counterY][counterX], attachFindD2 = revisedWorkingMap [counterY][counterX+1], attachFindD3 = attachedNumberListCount/5;
                            attachPointCount++;
                        }
                    }
                    else if (attachPointCount == 0) attachedNumberList [attachFindD3*5+2]++, attachPointCount++;
                }
                
                if (counterY+1 < imageXYLength && counterX+1 < imageXYLength && revisedWorkingMap [counterY+1][counterX+1] != 0 && revisedWorkingMap [counterY+1][counterX+1] != revisedWorkingMap [counterY][counterX]){
                    if (attachFindE != revisedWorkingMap [counterY][counterX] || attachFindE2 != revisedWorkingMap [counterY+1][counterX+1]){
                        findFlag = 0;
                        
                        for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                            if (attachedNumberList [counter1*5] == revisedWorkingMap [counterY][counterX] && attachedNumberList [counter1*5+1] == revisedWorkingMap [counterY+1][counterX+1]){
                                if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                findFlag = 1, attachFindE = revisedWorkingMap [counterY][counterX], attachFindE2 = revisedWorkingMap [counterY+1][counterX+1], attachFindE3 = counter1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0){
                            attachedNumberList [attachedNumberListCount] = revisedWorkingMap [counterY][counterX], attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = revisedWorkingMap [counterY+1][counterX+1], attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                            attachFindE = revisedWorkingMap [counterY][counterX], attachFindE2 = revisedWorkingMap [counterY+1][counterX+1], attachFindE3 = attachedNumberListCount/5;
                            attachPointCount++;
                        }
                    }
                    else if (attachPointCount == 0) attachedNumberList [attachFindE3*5+2]++, attachPointCount++;
                }
                
                if (counterY+1 < imageXYLength && revisedWorkingMap [counterY+1][counterX] != 0 && revisedWorkingMap [counterY+1][counterX] != revisedWorkingMap [counterY][counterX]){
                    if (attachFindF != revisedWorkingMap [counterY][counterX] || attachFindF2 != revisedWorkingMap [counterY+1][counterX]){
                        findFlag = 0;
                        
                        for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                            if (attachedNumberList [counter1*5] == revisedWorkingMap [counterY][counterX] && attachedNumberList [counter1*5+1] == revisedWorkingMap [counterY+1][counterX]){
                                if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                findFlag = 1, attachFindF = revisedWorkingMap [counterY][counterX], attachFindF2 = revisedWorkingMap [counterY+1][counterX], attachFindF3 = counter1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0){
                            attachedNumberList [attachedNumberListCount] = revisedWorkingMap [counterY][counterX], attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = revisedWorkingMap [counterY+1][counterX], attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                            attachFindF = revisedWorkingMap [counterY][counterX], attachFindF2 = revisedWorkingMap [counterY+1][counterX], attachFindF3 = attachedNumberListCount/5;
                            attachPointCount++;
                        }
                    }
                    else if (attachPointCount == 0) attachedNumberList [attachFindF3*5+2]++, attachPointCount++;
                }
                
                if (counterY+1 < imageXYLength && counterX-1 >= 0 && revisedWorkingMap [counterY+1][counterX-1] != 0 && revisedWorkingMap [counterY+1][counterX-1] != revisedWorkingMap [counterY][counterX]){
                    if (attachFindG != revisedWorkingMap [counterY][counterX] || attachFindG2 != revisedWorkingMap [counterY+1][counterX-1]){
                        findFlag = 0;
                        
                        for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                            if (attachedNumberList [counter1*5] == revisedWorkingMap [counterY][counterX] && attachedNumberList [counter1*5+1] == revisedWorkingMap [counterY+1][counterX-1]){
                                if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                findFlag = 1, attachFindG = revisedWorkingMap [counterY][counterX], attachFindG2 = revisedWorkingMap [counterY+1][counterX-1], attachFindB3 = counter1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0){
                            attachedNumberList [attachedNumberListCount] = revisedWorkingMap [counterY][counterX], attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = revisedWorkingMap [counterY+1][counterX-1], attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                            attachFindG = revisedWorkingMap [counterY][counterX], attachFindG2 = revisedWorkingMap [counterY+1][counterX-1], attachFindG3 = attachedNumberListCount/5;
                            attachPointCount++;
                        }
                    }
                    else if (attachPointCount == 0) attachedNumberList [attachFindG3*5+2]++, attachPointCount++;
                }
                
                if (counterX-1 >= 0 && revisedWorkingMap [counterY][counterX-1] != 0 && revisedWorkingMap [counterY][counterX-1] != revisedWorkingMap [counterY][counterX]){
                    if (attachFindH != revisedWorkingMap [counterY][counterX] || attachFindH2 != revisedWorkingMap [counterY][counterX-1]){
                        findFlag = 0;
                        
                        for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                            if (attachedNumberList [counter1*5] == revisedWorkingMap [counterY][counterX] && attachedNumberList [counter1*5+1] == revisedWorkingMap [counterY][counterX-1]){
                                if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                findFlag = 1, attachFindH = revisedWorkingMap [counterY][counterX], attachFindH2 = revisedWorkingMap [counterY][counterX-1], attachFindH3 = counter1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0){
                            attachedNumberList [attachedNumberListCount] = revisedWorkingMap [counterY][counterX], attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = revisedWorkingMap [counterY][counterX-1], attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                            attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                            attachFindH = revisedWorkingMap [counterY][counterX], attachFindH2 = revisedWorkingMap [counterY][counterX-1], attachFindH3 = attachedNumberListCount/5;
                            attachPointCount++;
                        }
                    }
                    else if (attachPointCount == 0) attachedNumberList [attachFindH3*5+2]++, attachPointCount++;
                }
            }
        }
    }
    
    int *lineLength = new int [maxCount+5];
    
    for (int counter1 = 1; counter1 < maxCount+1; counter1++) lineLength [counter1] = 0;
    
    for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
        if (arrayPositionRevise [counter1*7+5] == 0 || arrayPositionRevise [counter1*7+5] == 1){
            lineLength [arrayPositionRevise [counter1*7+3]]++;
        }
    }
    
    for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
        attachedNumberList [counter1*5+3] = lineLength [attachedNumberList [counter1*5]];
        attachedNumberList [counter1*5+4] = lineLength [attachedNumberList [counter1*5+1]];
    }
    
    delete [] lineLength;
    
    //for (int counterA = 0; counterA < attachedNumberListCount/5; counterA++){
    //    for (int counterB = 0; counterB < 5; counterB++) cout<<attachedNumberList [counterA*5+counterB];
    //    cout<<" "<<counterA<<" attachedNumberList"<<endl;
    //}
    
    //------Group List Initialize------
    int *groupList = new int [maxCount+2];
    int *groupRound = new int [maxCount+2];
    
    delete [] groupNumberList;
    groupNumberList = new int [maxCount+2];
    groupNumberListCount = maxCount+2;
    
    for (int counter1 = 1; counter1 < maxCount+1; counter1++){
        groupList [counter1] = 0;
        groupNumberList [counter1] = 0;
        groupRound [counter1] = 0;
    }
    
    //------Main Process------
    int groupEntryCount = 1;
    int existFindFlag = 0;
    int terminationFlag = 0;
    int entryConnectNumber = 0;
    int numberOfEntry = 0;
    int collectCount = 0;
    int terminationFlag1 = 0;
    int tempGroupNumber = 0;
    int largestConnect = 0;
    int largestConnectCount = 0;
    int attachEntry = 0;
    int numberOfAssociates = 0;
    double ratio1 = 0;
    double ratio2 = 0;
    
    for (int counter1 = 0; counter1 < 7; counter1++){ //------Process from 240, 220, 200, MapA, MapB, MapC, MapD------
        do {
            
            terminationFlag = 1;
            entryConnectNumber = 0;
            
            //------Scan Connect No, if it is not 0, set to "entryConnectNumber"--------
            for (int counter2 = 1; counter2 < maxCount+1; counter2++){ //------Do until e.g. 240 entry become Zero------
                if (intensityHistogramList [counter2*7+counter1] != 0){ //------Find Entry------
                    entryConnectNumber = intensityHistogramList [counter2*7+counter1];
                    break;
                }
            }
            
            //cout<<entryConnectNumber <<" entry-if 0 go next round"<<endl;
            
            if (entryConnectNumber == 0) terminationFlag = 0;
            else{
                
                numberOfEntry = 0;
                
                for (int counter2 = 1; counter2 < maxCount+1; counter2++){
                    if (intensityHistogramList [counter2*7+counter1] == entryConnectNumber) numberOfEntry++; //------EntryNumber related to the Connect group------
                }
                
                //cout<<groupEntryCount<<" GroupNumber "<<numberOfEntry<<" EntryNumber"<<endl;
                
                if (numberOfEntry == 0 && existFindFlag == 0){
                    groupList [entryConnectNumber] = groupEntryCount;
                    groupRound [entryConnectNumber] = counter1;
                    
                    //cout<<entryConnectNumber<<" EntryConnNo"<<endl;
                    
                    groupEntryCount++; //------Only one entry, set group number------
                }
                else if (numberOfEntry > 0){
                    collectCount = 0;
                    int *collectConnect = new int [numberOfEntry+10]; //------All connect data overlapped with connect------
                    
                    for (int counter2 = 0; counter2 < numberOfEntry; counter2++) collectConnect [counter2] = 0;
                    
                    //---------Select connect with same no: when multiple lines are on the same connect, pick all line nos------
                    //---------Then put 0 to the Histogram list----------
                    for (int counter2 = 1; counter2 < maxCount+1; counter2++){ //------All entry number Data Set into >> collectConnect []------
                        if (intensityHistogramList [counter2*7+counter1] == entryConnectNumber){
                            collectConnect [collectCount] = counter2; //------Save position on Histogram list--------
                            intensityHistogramList [counter2*7+counter1] = 0;
                            collectCount++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < numberOfEntry; counterA++) cout<<counterA<<" "<<collectConnect [counterA]<<" collect Get All Connect overlap Data"<<endl;
                    
                    do{ //------do until all entry numbers are processed------
                        
                        terminationFlag1 = 1;
                        existFindFlag = 0;
                        int *groupListAttach = new int [maxCount+1];
                        
                        for (int counter2 = 0; counter2 < maxCount+1; counter2++) groupListAttach [counter2] = 0;
                        
                        tempGroupNumber = groupEntryCount; //------Hold group number for attached group------
                        largestConnect = 0;
                        largestConnectCount = 0; //------Largest Area connect number------
                        
                        //cout<<tempGroupNumber<<" tempGroupNo "<<endl;
                        
                        //---------Identify largest connect among selected connects----------
                        for (int counter2 = 0; counter2 < numberOfEntry; counter2++){ //------Largest connect group number------
                            if (collectConnect [counter2] != 0){
                                if (areaIntensityList [collectConnect [counter2]*2] > largestConnect){
                                    largestConnect = areaIntensityList [collectConnect [counter2]*2];
                                    largestConnectCount = collectConnect [counter2];
                                }
                            }
                        }
                        
                        //cout<<largestConnect<<" "<<largestConnectCount<<" Largest connect"<<endl;
                        
                        if (groupList [largestConnectCount] != 0) existFindFlag = 1; //------If already processed, set the flag------
                        
                        //----------Largest connect, set 0 to the corresponding collectConnect []--------
                        for (int counter2 = 0; counter2 < numberOfEntry; counter2++){ //------Remove the largest from collectConnect []------
                            if (collectConnect [counter2] == largestConnectCount){
                                collectConnect [counter2] = 0;
                                break;
                            }
                        }
                        
                        //----------Assignee new group no to the connect if no no was assigned before----------
                        if (largestConnectCount != 0 && existFindFlag == 0){
                            groupList [largestConnectCount] = groupEntryCount; //------Set largest to groupList []------
                            groupRound [largestConnectCount] = counter1;
                            groupEntryCount++;
                        }
                        
                        //cout<<largestConnectCount<<" LargestCONNECTNO "<<endl;
                        
                        //for (int counterA = 0; counterA < numberOfEntry; counterA++) cout<<counterA<<" "<<collectConnect [counterA]<<" CollectConnect"<<endl;
                        
                        if (largestConnectCount == 0) terminationFlag1 = 0;
                        else{
                            
                            attachEntry = 0;
                            int *attachSelect = new int [numberOfEntry*5+2];
                            
                            for (int counter2 = 0; counter2 < numberOfEntry*5+2; counter2++) attachSelect [counter2] = 0;
                            
                            //--------check attached groups and set data to attachSelect []----------
                            for (int counter2 = 0; counter2 < attachedNumberListCount/5; counter2++){ //------Enter connect number attached with Largest Connect, remove from collectConnect []------
                                if (attachedNumberList [counter2*5+1] == largestConnectCount){
                                    for (int counter3 = 0; counter3 < numberOfEntry; counter3++){
                                        if (collectConnect [counter3] == attachedNumberList [counter2*5]){
                                            attachSelect [attachEntry] = attachedNumberList [counter2*5], attachEntry++;
                                            attachSelect [attachEntry] = attachedNumberList [counter2*5+1], attachEntry++;
                                            attachSelect [attachEntry] = attachedNumberList [counter2*5+2], attachEntry++;
                                            attachSelect [attachEntry] = attachedNumberList [counter2*5+3], attachEntry++;
                                            attachSelect [attachEntry] = attachedNumberList [counter2*5+4], attachEntry++;
                                            collectConnect [counter3] = 0;
                                            break;
                                        }
                                    }
                                }
                            }
                            
                            for (int counter2 = 0; counter2 < numberOfEntry; counter2++){
                                if (attachSelect [counter2*5] != 0 && groupList [attachSelect [counter2*5]] != 0 && existFindFlag == 0){
                                    attachSelect [counter2*5] = 0;
                                    attachEntry = attachEntry-5;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < numberOfEntry; counterA++) cout<<counterA<<" "<<attachSelect [counterA*5]<<" ATTACH TO LARGEST"<<endl;
                            
                            if (attachEntry != 0){
                                if (existFindFlag == 1){
                                    //--------If group no was already assigned, go Exist final--------
                                    
                                    //cout<<"EXIST FIANL"<<endl;
                                    
                                    for (int counter2 = 0; counter2 < numberOfEntry; counter2++){
                                        if (attachSelect [counter2*5] != 0 && groupList [attachSelect [counter2*5]] != 0){
                                            ratio1 = attachSelect [counter2*5+2]/(double)attachSelect [counter2*5+3];
                                            ratio2 = attachSelect [counter2*5+2]/(double)attachSelect [counter2*5+4];
                                            
                                            if ((ratio1 > 0.2 && ratio1 < 0.6 && ratio2 > 0.2 && ratio2 < 0.6) || (ratio1 > 0.2 && ratio1 < 0.6 && ratio2 < 0.2) || (ratio1 < 0.2 && ratio2 > 0.2 && ratio2 < 0.6) || ratio1 >= 0.6 || ratio2 >= 0.6){
                                                numberOfAssociates = 0;
                                                
                                                if (groupList [attachSelect [counter2*5]] == groupList [largestConnectCount] || groupList [attachSelect [counter2*5]] == groupList [largestConnectCount]*-1) groupListAttach [attachSelect [counter2*5]] = groupList [attachSelect [counter2*5]];
                                                else{
                                                    
                                                    for (int counter3 = 1; counter3 < maxCount+1; counter3++){
                                                        if (groupList [counter3] == groupList [attachSelect [counter2*5]] || groupList [counter3] == groupList [attachSelect [counter2*5]]*-1) numberOfAssociates++;
                                                    }
                                                    
                                                    if (numberOfAssociates < 3){
                                                        for (int counter3 = 1; counter3 < maxCount+1; counter3++){
                                                            if (groupList [counter3] == groupList [attachSelect [counter2*5]] || groupList [counter3] == groupList [attachSelect [counter2*5]]*-1){
                                                                if (groupList [largestConnectCount] > 0) groupListAttach [counter3] = groupList [largestConnectCount]*-1;
                                                                else groupListAttach [counter3] = groupList [largestConnectCount];
                                                            }
                                                        }
                                                    }
                                                    else groupListAttach [attachSelect [counter2*5]] = groupList [attachSelect [counter2*5]];
                                                }
                                            }
                                            else groupListAttach [attachSelect [counter2*5]] = groupList [attachSelect [counter2*5]];
                                        }
                                        else if (attachSelect [counter2*5] != 0 && groupList [attachSelect [counter2*5]] == 0){
                                            if (groupList [largestConnectCount] > 0) groupListAttach [attachSelect [counter2*5]] = groupList [largestConnectCount]*-1;
                                            else groupListAttach [attachSelect [counter2*5]] = groupList [largestConnectCount];
                                        }
                                    }
                                }
                                else{
                                    
                                    //cout<<" NON EXIST FINAL"<<endl;
                                    
                                    for (int counter2 = 0; counter2 < numberOfEntry; counter2++){ //------Enter process result of attached connect with largest enter >> newGroups []------
                                        if (attachSelect [counter2*5] != 0){ //============
                                            if (groupList [attachSelect [counter2*5]] == 0) groupListAttach [attachSelect [counter2*5]] = tempGroupNumber*-1;
                                            else{
                                                
                                                for (int counter3 = 1; counter3 < maxCount+1; counter3++){
                                                    if (groupList [counter3] == groupList [attachSelect [counter2*5]] || groupList [counter3] == groupList [attachSelect [counter2*5]]*-1) groupListAttach [attachSelect [counter2*5]] = tempGroupNumber*-1;
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < numberOfEntry; counterA++) cout<<counterA<<" "<<collectConnect [counterA]<<" CollectConnect "<<endl;
                                
                                //for (int counterA = 0; counterA < maxCount+1; counterA++) cout<<counterA<<" "<<groupListAttach [counterA]<<" groupListAttach"<<endl;
                                
                                //for (int counterA = 1; counterA < maxCount+1; counterA++) cout<<counterA<<" "<<groupList [counterA]<<" groupList"<<endl;
                                
                                for (int counter2 = 1; counter2 < maxCount+1; counter2++){
                                    if (groupListAttach [counter2] != 0){
                                        groupList [counter2] = groupListAttach [counter2];
                                        groupRound [counter2] = counter1;
                                    }
                                }
                                
                                //cout<<groupEntryCount<<" groupEntryCountFinal"<<endl;
                            }
                            
                            delete [] attachSelect;
                        }
                        
                        delete [] groupListAttach;
                        
                    } while (terminationFlag1 == 1);
                    
                    delete [] collectConnect;
                }
            }
            
            //for (int counterA = 1; counterA < maxCount+1; counterA++) cout<<counterA<<" "<<groupList [counterA]<<" GroupList_End_Connect"<<endl;
            
        } while (terminationFlag == 1);
        
        //for (int counterA = 1; counterA < maxCount+1; counterA++) cout<<" Round "<<counter1<<" "<<counterA<<" "<<groupList [counterA]<<" GroupList_End_Round"<<endl;
    }
    
    delete [] groupRound;
    delete [] intensityHistogramList;
    
    //for (int counterA = 1; counterA < maxCount+1; counterA++) cout<<" Round "<<" "<<counterA<<" "<<groupList [counterA]<<" Group"<<endl;
    
    //-------Change Main connect group: check area, intensity, then if main is (-), switch (-) and (+)--------
    
    int withinIntensityLargest = 0;
    int withinIntensityCount = 0;
    
    for (int counter1 = 1; counter1 < maxCount+1; counter1++){
        if (groupList [counter1] > 0){
            withinIntensityLargest = 0;
            withinIntensityCount = 0;
            
            //cout<<groupList [counter1]<<" "<<withinGroupNumber<<" "<<withinArea<<" "<<withinIntensity<<" Area_Int_within"<<endl;
            
            for (int counter2 = 1; counter2 < maxCount+1; counter2++){
                if (groupList [counter2] == groupList [counter1]*-1){
                    if (areaIntensityList [counter2*2] > areaIntensityList [counter1*2]*0.8 && areaIntensityList [counter2*2+1] > areaIntensityList [counter1*2+1] && areaIntensityList [counter2*2+1] < 220 && areaIntensityList [counter2*2+1]-areaIntensityList [counter1*2+1] > 30){
                        if (withinIntensityLargest < areaIntensityList [counter2*2]){
                            withinIntensityLargest = areaIntensityList [counter2*2];
                            withinIntensityCount = counter2;
                        }
                        
                        //cout<<withinIntensityLargest<<" "<<withinIntensityCount<<" Area_Int_within2"<<endl;
                    }
                }
            }
            
            for (int counter2 = 1; counter2 < maxCount+1; counter2++){
                if (groupList [counter2] == groupList [counter1] || groupList [counter2] == groupList [counter1]*-1) groupNumberList [counter2] = groupList [counter2];
            }
            
            if (withinIntensityLargest != 0){
                groupNumberList [counter1] = groupNumberList [counter1]*-1;
                groupNumberList [withinIntensityCount] = groupNumberList [withinIntensityCount]*-1;
            }
        }
    }
    
    //for (int counterA = 1; counterA < maxCount+1; counterA++) cout<<" "<<counterA<<" "<<groupNumberList [counterA]<<" groupNumberList"<<endl;
    
    //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
    //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
    //	cout<<" arrayTimeSelected "<<counterA<<endl;
    //}
    
    for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
        if (arrayTimeSelected [counter1*10] == 2){
            if (groupNumberList [arrayTimeSelected [counter1*10+8]] < 0) groupNumberList [arrayTimeSelected [counter1*10+8]] = 0;
            else{
                
                groupNumberList [arrayTimeSelected [counter1*10+8]] = 0;
                
                for (int counter2 = 1; counter2 < maxCount+1; counter2++){
                    if (groupList [counter2] == groupNumberList [arrayTimeSelected [counter1*10+8]]*-1){
                        groupList [counter2] = groupList [counter2]*-1;
                        break;
                    }
                }
                
                for (int counter2 = 1; counter2 < maxCount+1; counter2++){
                    if (groupList [counter2] > 0){
                        withinIntensityLargest = 0;
                        withinIntensityCount = 0;
                        
                        //cout<<groupList [counter2]<<" "<<withinGroupNumber<<" "<<withinArea<<" "<<withinIntensity<<" Area_Int_within"<<endl;
                        
                        for (int counter3 = 1; counter3 < maxCount+1; counter3++){
                            if (groupList [counter3] == groupList [counter2]*-1){
                                if (areaIntensityList [counter3*2] > areaIntensityList [counter2*2]*0.8 && areaIntensityList [counter3*2+1] > areaIntensityList [counter2*2+1] && areaIntensityList [counter3*2+1] < 220 && areaIntensityList [counter3*2+1]-areaIntensityList [counter2*2+1] > 30){
                                    if (withinIntensityLargest < areaIntensityList [counter3*2]) withinIntensityLargest = areaIntensityList [counter3*2], withinIntensityCount = counter3;
                                }
                            }
                        }
                        
                        if (withinIntensityLargest != 0){
                            groupNumberList [counter2] = groupNumberList [counter2]*-1;
                            groupNumberList [withinIntensityCount] = groupNumberList [withinIntensityCount]*-1;
                        }
                    }
                }
            }
        }
        else if (arrayTimeSelected [counter1*10] == 0 && processType == 2){
            if (groupNumberList [arrayTimeSelected [counter1*10+8]] < 0) arrayTimeSelected [counter1*10] = 0;
            else arrayTimeSelected [counter1*10] = 1;
        }
        else if (arrayTimeSelected [counter1*10] == 5 && processType == 2){
            if (groupNumberList [arrayTimeSelected [counter1*10+8]] < 0) arrayTimeSelected [counter1*10] = 0;
            else arrayTimeSelected [counter1*10] = 1;
        }
        else if (arrayTimeSelected [counter1*10] == 6 && processType == 2){
            if (groupNumberList [arrayTimeSelected [counter1*10+8]] < 0) arrayTimeSelected [counter1*10] = 0;
            else arrayTimeSelected [counter1*10] = 7;
        }
    }
    
    //for (int counterA = 1; counterA < maxCount+1; counterA++) cout<<" "<<counterA<<" "<<groupNumberList [counterA]<<" groupNumberList"<<endl;
    
    //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
    //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
    //	cout<<" arrayTimeSelected "<<counterA<<endl;
    //}
    
    //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
    //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
    //	cout<<" arrayPositionRevise "<<counterA<<endl;
    //}
    
    if (processType == 2){
        int *arraySelectedTemp = new int [positionReviseCount+50];
        int selectedTempCount = 0;
        
        for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
            if (arrayTimeSelected [(arrayPositionRevise [counter1*7+3]-1)*10] == 0 || arrayTimeSelected [(arrayPositionRevise [counter1*7+3]-1)*10] == 2){
                arraySelectedTemp [selectedTempCount] = arrayPositionRevise [counter1*7], selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = arrayPositionRevise [counter1*7+1], selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = arrayPositionRevise [counter1*7+2], selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = arrayPositionRevise [counter1*7+3], selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = arrayPositionRevise [counter1*7+4], selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = 0, selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = 0, selectedTempCount++;
            }
            else if (arrayTimeSelected [(arrayPositionRevise [counter1*7+3]-1)*10] == 1 || arrayTimeSelected [(arrayPositionRevise [counter1*7+3]-1)*10] == 7 || arrayTimeSelected [(arrayPositionRevise [counter1*7+3]-1)*10] == 10 || arrayTimeSelected [(arrayPositionRevise [counter1*7+3]-1)*10] == 11){
                arraySelectedTemp [selectedTempCount] = arrayPositionRevise [counter1*7], selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = arrayPositionRevise [counter1*7+1], selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = arrayPositionRevise [counter1*7+2], selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = arrayPositionRevise [counter1*7+3], selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = arrayPositionRevise [counter1*7+4], selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = 1, selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = arrayTimeSelected [(arrayPositionRevise [counter1*7+3]-1)*10+9], selectedTempCount++;
            }
            else if (arrayTimeSelected [(arrayPositionRevise [counter1*7+3]-1)*10] == 3 || arrayTimeSelected [(arrayPositionRevise [counter1*7+3]-1)*10] == 5){
                arraySelectedTemp [selectedTempCount] = arrayPositionRevise [counter1*7], selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = arrayPositionRevise [counter1*7+1], selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = arrayPositionRevise [counter1*7+2], selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = arrayPositionRevise [counter1*7+3], selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = arrayPositionRevise [counter1*7+4], selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = 2, selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = 0, selectedTempCount++;
            }
            else if (arrayTimeSelected [(arrayPositionRevise [counter1*7+3]-1)*10] == 4 || arrayTimeSelected [(arrayPositionRevise [counter1*7+3]-1)*10] == 6){
                arraySelectedTemp [selectedTempCount] = arrayPositionRevise [counter1*7], selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = arrayPositionRevise [counter1*7+1], selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = arrayPositionRevise [counter1*7+2], selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = arrayPositionRevise [counter1*7+3], selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = arrayPositionRevise [counter1*7+4], selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = 3, selectedTempCount++;
                arraySelectedTemp [selectedTempCount] = 0, selectedTempCount++;
            }
        }
        
        positionReviseCount = 0;
        for (int counter1 = 0; counter1 < selectedTempCount; counter1++) arrayPositionRevise [counter1] = arraySelectedTemp [counter1], positionReviseCount++;
        
        delete [] arraySelectedTemp;
    }
    
    delete [] groupList;
    delete [] areaIntensityList;
    delete [] attachedNumberList;
    
    //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
    //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
    //	cout<<" arrayPositionRevise "<<counterA<<endl;
    //}
}

@end
