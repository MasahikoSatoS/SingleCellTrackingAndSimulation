//
// LineSet.mm
// CellMovieQuant
//
// Created by Masahiko Sato on 06/10/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "LineSet.h"

@implementation LineSet

-(void)lineSetProcess:(int)processType{
    if (lineDraw == 1){
        int counterMax = 0;
        
        if (processType == 1) counterMax = targetCount/2;
        else if (processType == 2) counterMax = referenceLineCount/2;
        
        //------Duplicate remove------
        int *duplicateFind = new int [counterMax+1];
        int *arrayTargetTemp1 = new int [counterMax*2+1];
        
        for (int counter1 = 0; counter1 < counterMax; counter1++) duplicateFind [counter1] = 0;
        
        int targetTempCount1 = 0;
        int neighbourCount = 0;
        
        if (processType == 1){
            int xPosition;
            int yPosition;
            
            for (int counter1 = 0; counter1 < counterMax-1; counter1++){
                if (duplicateFind [counter1] == 0){
                    xPosition = arrayTarget [counter1*2];
                    yPosition = arrayTarget [counter1*2+1];
                }
                
                for (int counter2 = counter1+1; counter2 < counterMax; counter2++){
                    if (xPosition == arrayTarget [counter2*2] && yPosition == arrayTarget [counter2*2+1]) duplicateFind [counter2] = 1;
                }
            }
            
            targetTempCount1 = 0;
            
            for (int counter1 = 0; counter1 < counterMax; counter1++){
                if (duplicateFind [counter1] == 0){
                    arrayTargetTemp1 [targetTempCount1] = arrayTarget [counter1*2], targetTempCount1++;
                    arrayTargetTemp1 [targetTempCount1] = arrayTarget [counter1*2+1], targetTempCount1++;
                }
            }
        }
        else if (processType == 2){
            targetTempCount1 = 0;
            
            for (int counter1 = 0; counter1 < counterMax; counter1++){
                arrayTargetTemp1 [targetTempCount1] = arrayReferenceLine [counter1*2], targetTempCount1++;
                arrayTargetTemp1 [targetTempCount1] = arrayReferenceLine [counter1*2+1], targetTempCount1++;
            }
        }
        
        delete [] duplicateFind;
        
        //for (int counterA = 0; counterA < targetTempCount1/2; counterA++){
        //	cout<<arrayTargetTemp1 [counterA*2]<<" "<<arrayTargetTemp1 [counterA*2+1]<<" DuplicateRemove"<<endl;
        //}
        
        if (targetTempCount1/2 > 5){ //------Remove less than 5 points------
            int firstSet = 0;
            
            targetGapFill = new int [targetTempCount1*2+1];
            targetGapFillCount = 0;
            targetGapFillLimit = targetTempCount1*2+1;
            
            //------Gap Fill------
            int xPosition = 0;
            int yPosition = 0;
            int xPositionNext = 0;
            int yPositionNext = 0;
            
            for (int counter1 = 0; counter1 < targetTempCount1/2-1; counter1++){
                if (firstSet == 0 && arrayTargetTemp1 [counter1*2] >= 0 && arrayTargetTemp1 [counter1*2] < imageXYLength && arrayTargetTemp1 [counter1*2+1] >= 0 && arrayTargetTemp1 [counter1*2+1] < imageXYLength){
                    targetGapFill [targetGapFillCount] = arrayTargetTemp1 [counter1*2], targetGapFillCount++;
                    targetGapFill [targetGapFillCount] = arrayTargetTemp1 [counter1*2+1], targetGapFillCount++;
                    firstSet = 1;
                }
                
                if (firstSet == 1){
                    xPosition = arrayTargetTemp1 [counter1*2];
                    yPosition = arrayTargetTemp1 [counter1*2+1];
                    xPositionNext = arrayTargetTemp1 [(counter1+1)*2];
                    yPositionNext = arrayTargetTemp1 [(counter1+1)*2+1];
                    
                    if (xPositionNext < 0 || xPositionNext >= imageXYLength || yPositionNext < 0 || yPositionNext >= imageXYLength){
                        break;
                    }
                    
                    neighbourCount = 0;
                    
                    if (xPosition-1 == xPositionNext && yPosition-1 == yPositionNext) neighbourCount++;
                    else if (xPosition == xPositionNext && yPosition-1 == yPositionNext) neighbourCount++;
                    else if (xPosition+1 == xPositionNext && yPosition-1 == yPositionNext) neighbourCount++;
                    else if (xPosition+1 == xPositionNext && yPosition == yPositionNext) neighbourCount++;
                    else if (xPosition+1 == xPositionNext && yPosition+1 == yPositionNext) neighbourCount++;
                    else if (xPosition == xPositionNext && yPosition+1 == yPositionNext) neighbourCount++;
                    else if (xPosition-1 == xPositionNext && yPosition+1 == yPositionNext) neighbourCount++;
                    else if (xPosition-1 == xPositionNext && yPosition == yPositionNext) neighbourCount++;
                    
                    if (neighbourCount == 0){
                        arrayGapData = new int [500];
                        gapDataCount = 0;
                        gapDataLimit = 0;
                        
                        id gapFill = [[GapFill alloc] init];
                        [gapFill gapFilling:xPosition:yPosition:xPositionNext:yPositionNext];
                        
                        if (targetGapFillCount+gapDataCount+2 > targetGapFillLimit) targetGapFillAddition = gapDataCount+2, [self gapFillUpdate];
                        
                        for (int counter2 = 0; counter2 < gapDataCount/2; counter2++){
                            targetGapFill [targetGapFillCount] = arrayGapData [counter2*2], targetGapFillCount++;
                            targetGapFill [targetGapFillCount] = arrayGapData [counter2*2+1], targetGapFillCount++;
                        }
                        
                        delete [] arrayGapData;
                        
                        targetGapFill [targetGapFillCount] = xPositionNext, targetGapFillCount++;
                        targetGapFill [targetGapFillCount] = yPositionNext, targetGapFillCount++;
                    }
                    else{
                        
                        if (targetGapFillCount+2 > targetGapFillLimit){
                            targetGapFillAddition = 2;
                            [self gapFillUpdate];
                        }
                        
                        targetGapFill [targetGapFillCount] = xPositionNext, targetGapFillCount++;
                        targetGapFill [targetGapFillCount] = yPositionNext, targetGapFillCount++;
                    }
                }
            }
            
            int targetTempCount2 = 0;
            int *arrayTargetTemp2 = new int [targetGapFillCount+1];
            
            //for (int counterA = 0; counterA < counterMax; counterA++){
            //	cout<<targetGapFill [counterA*2]<<" "<<targetGapFill [counterA*2+1]<<" GapFilled"<<endl;
            //}
            
            //------Cross point find, at least 15 apart------
            if (targetGapFillCount/2 > 15){
                neighbourCount = 0;
                int positionCountStart = 0;
                int positionCountEnd = 0;
                
                for (int counter1 = 0; counter1 < targetGapFillCount/2-10; counter1++){
                    xPosition = targetGapFill [counter1*2];
                    yPosition = targetGapFill [counter1*2+1];
                    
                    for (int counter2 = counter1+10; counter2 < targetGapFillCount/2; counter2++){
                        xPositionNext = targetGapFill [counter2*2];
                        yPositionNext = targetGapFill [counter2*2+1];
                        
                        if (xPosition-1 == xPositionNext && yPosition-1 == yPositionNext) neighbourCount++;
                        else if (xPosition == xPositionNext && yPosition-1 == yPositionNext) neighbourCount++;
                        else if (xPosition+1 == xPositionNext && yPosition-1 == yPositionNext) neighbourCount++;
                        else if (xPosition+1 == xPositionNext && yPosition == yPositionNext) neighbourCount++;
                        else if (xPosition+1 == xPositionNext && yPosition+1 == yPositionNext) neighbourCount++;
                        else if (xPosition == xPositionNext && yPosition+1 == yPositionNext) neighbourCount++;
                        else if (xPosition-1 == xPositionNext && yPosition+1 == yPositionNext) neighbourCount++;
                        else if (xPosition-1 == xPositionNext && yPosition == yPositionNext) neighbourCount++;
                        
                        if (neighbourCount > 0){
                            positionCountStart = counter1;
                            positionCountEnd = counter2;
                            break;
                        }
                    }
                    
                    if (neighbourCount > 0){
                        break;
                    }
                }
                
                if (neighbourCount > 0){
                    if (targetGapFillCount+(positionCountEnd-positionCountStart)*2+2 > targetGapFillLimit){
                        targetGapFillAddition = (positionCountEnd-positionCountStart)*2+2+2;
                        [self gapFillUpdate];
                    }
                    
                    for (int counter1 = positionCountStart; counter1 <= positionCountEnd; counter1++){
                        arrayTargetTemp2 [targetTempCount2] = targetGapFill [counter1*2], targetTempCount2++;
                        arrayTargetTemp2 [targetTempCount2] = targetGapFill [counter1*2+1], targetTempCount2++;
                    }
                }
                else{
                    
                    if (targetGapFillCount+targetGapFillCount+2 > targetGapFillLimit){
                        targetGapFillAddition = targetGapFillCount+2;
                        [self gapFillUpdate];
                    }
                    
                    for (int counter1 = 0; counter1 < targetGapFillCount/2; counter1++){
                        arrayTargetTemp2 [targetTempCount2] = targetGapFill [counter1*2], targetTempCount2++;
                        arrayTargetTemp2 [targetTempCount2] = targetGapFill [counter1*2+1], targetTempCount2++;
                    }
                }
                
                //for (int counterA = 0; counterA < targetTempCount2/2; counterA++){
                //	cout<<arrayTargetTemp2 [counterA*2]<<" "<<arrayTargetTemp2 [counterA*2+1]<<" arrayTargetTemp2"<<endl;
                //}
                
                int linePointCount = targetTempCount2/2;
                arrayLineDataProcessing = new int [targetTempCount2+50];
                lineDataProcessingCount = 0;
                
                //------Circle------
                if (neighbourCount != 0 && linePointCount > 11){
                    int *lineTrimmingValue = new int [linePointCount+10];
                    int *lineTrimmingXY = new int [linePointCount*2+10];
                    
                    for (int counter1 = 0; counter1 < linePointCount; counter1++){
                        lineTrimmingValue [counter1] = 0;
                        lineTrimmingXY [counter1*2] = arrayTargetTemp2 [counter1*2];
                        lineTrimmingXY [counter1*2+1] = arrayTargetTemp2 [counter1*2+1];
                    }
                    
                    int lineTrimmingX = 0;
                    int lineTrimmingY = 0;
                    int attachPoint = 0;
                    int countSave = 0;
                    int lineTrimmingX2 = 0;
                    int lineTrimmingY2 = 0;
                    
                    for (int counter1 = 0; counter1 < linePointCount-4; counter1++){
                        lineTrimmingX = lineTrimmingXY [counter1*2];
                        lineTrimmingY = lineTrimmingXY [counter1*2+1];
                        lineTrimmingXY [counter1*2] = -1;
                        lineTrimmingXY [counter1*2+1] = -1;
                        
                        if (lineTrimmingX != -1){
                            attachPoint = 0;
                            countSave = 0;
                            
                            for (int counter2 = counter1+1; counter2 < linePointCount-3; counter2++){
                                lineTrimmingX2 = lineTrimmingXY [counter2*2];
                                lineTrimmingY2 = lineTrimmingXY [counter2*2+1];
                                
                                for (int counterY = lineTrimmingY-1; counterY <= lineTrimmingY+1; counterY++){
                                    for (int counterX = lineTrimmingX-1; counterX <= lineTrimmingX+1; counterX++){
                                        if (counterX == lineTrimmingX2 && counterY == lineTrimmingY2){
                                            attachPoint++;
                                            
                                            if (attachPoint == 1) countSave = counter2;
                                            if (attachPoint > 1){
                                                for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                    lineTrimmingXY [counter3*2] = -1;
                                                    lineTrimmingXY [counter3*2+1] = -1;
                                                    lineTrimmingValue [counter3] = -1;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < linePointCount; counter1++){
                        if (lineTrimmingValue [counter1] != -1){
                            arrayLineDataProcessing [lineDataProcessingCount] = arrayTargetTemp2 [counter1*2], lineDataProcessingCount++;
                            arrayLineDataProcessing [lineDataProcessingCount] = arrayTargetTemp2 [counter1*2+1], lineDataProcessingCount++;
                        }
                    }
                    
                    if (lineDataProcessingCount/2 > 11){
                        //------Line Reorder------
                        targetTempCount2 = 0;
                        
                        linePointCount = lineDataProcessingCount/2;
                        
                        for (int counter1 = linePointCount/2; counter1 < linePointCount; counter1++){
                            arrayTargetTemp2 [targetTempCount2] = arrayLineDataProcessing [counter1*2], targetTempCount2++;
                            arrayTargetTemp2 [targetTempCount2] = arrayLineDataProcessing [counter1*2+1], targetTempCount2++;
                        }
                        
                        for (int counter1 = 0; counter1 < linePointCount/2; counter1++){
                            arrayTargetTemp2 [targetTempCount2] = arrayLineDataProcessing [counter1*2], targetTempCount2++;
                            arrayTargetTemp2 [targetTempCount2] = arrayLineDataProcessing [counter1*2+1], targetTempCount2++;
                        }
                        
                        //for (int counterA = 0; counterA < targetTempCount2/2; counterA++){
                        //	cout<<counterA<<" "<<arrayTargetTemp2 [counterA*2]<<" "<<arrayTargetTemp2 [counterA*2+1]<<" arrayTargetTemp2"<<endl;
                        //}
                        
                        //------Second line cleaning------
                        for (int counter1 = 0; counter1 < linePointCount; counter1++){
                            lineTrimmingValue [counter1] = 0;
                            lineTrimmingXY [counter1*2] = arrayTargetTemp2 [counter1*2];
                            lineTrimmingXY [counter1*2+1] = arrayTargetTemp2 [counter1*2+1];
                        }
                        
                        for (int counter1 = 0; counter1 < linePointCount-4; counter1++){
                            lineTrimmingX = lineTrimmingXY [counter1*2];
                            lineTrimmingY = lineTrimmingXY [counter1*2+1];
                            lineTrimmingXY [counter1*2] = -1;
                            lineTrimmingXY [counter1*2+1] = -1;
                            
                            if (lineTrimmingX != -1){
                                attachPoint = 0;
                                countSave = 0;
                                
                                for (int counter2 = counter1+1; counter2 < linePointCount-3; counter2++){
                                    lineTrimmingX2 = lineTrimmingXY [counter2*2];
                                    lineTrimmingY2 = lineTrimmingXY [counter2*2+1];
                                    
                                    for (int counterY = lineTrimmingY-1; counterY <= lineTrimmingY+1; counterY++){
                                        for (int counterX = lineTrimmingX-1; counterX <= lineTrimmingX+1; counterX++){
                                            if (counterX == lineTrimmingX2 && counterY == lineTrimmingY2){
                                                attachPoint++;
                                                
                                                if (attachPoint == 1) countSave = counter2;
                                                if (attachPoint > 1){
                                                    for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                        lineTrimmingXY [counter3*2] = -1;
                                                        lineTrimmingXY [counter3*2+1] = -1;
                                                        lineTrimmingValue [counter3] = -1;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        
                        lineDataProcessingCount = 0;
                        
                        for (int counter1 = 0; counter1 < linePointCount; counter1++){
                            if (lineTrimmingValue [counter1] != -1){
                                arrayLineDataProcessing [lineDataProcessingCount] = arrayTargetTemp2 [counter1*2], lineDataProcessingCount++;
                                arrayLineDataProcessing [lineDataProcessingCount] = arrayTargetTemp2 [counter1*2+1], lineDataProcessingCount++;
                            }
                        }
                    }
                    else{
                        
                        lineDataProcessingCount = 0;
                        targetCount = 0;
                    }
                    
                    delete [] lineTrimmingValue;
                    delete [] lineTrimmingXY;
                }
                else targetCount = 0;
                
                //------Linear------
                if (neighbourCount == 0 && linePointCount > 5){
                    int *lineTrimmingValue = new int [linePointCount+10];
                    int *lineTrimmingXY = new int [linePointCount*2+10];
                    
                    for (int counter1 = 0; counter1 < linePointCount; counter1++){
                        lineTrimmingValue [counter1] = 0;
                        lineTrimmingXY [counter1*2] = arrayTargetTemp2 [counter1*2];
                        lineTrimmingXY [counter1*2+1] = arrayTargetTemp2 [counter1*2+1];
                    }
                    
                    int lineTrimmingX = 0;
                    int lineTrimmingY = 0;
                    int attachPoint = 0;
                    int countSave = 0;
                    int lineTrimmingX2 = 0;
                    int lineTrimmingY2 = 0;
                    
                    for (int counter1 = 0; counter1 < linePointCount-1; counter1++){
                        lineTrimmingX = lineTrimmingXY [counter1*2];
                        lineTrimmingY = lineTrimmingXY [counter1*2+1];
                        lineTrimmingXY [counter1*2] = -1;
                        lineTrimmingXY [counter1*2+1] = -1;
                        
                        if (lineTrimmingX != -1){
                            attachPoint = 0;
                            countSave = 0;
                            
                            for (int counter2 = counter1+1; counter2 < linePointCount; counter2++){
                                lineTrimmingX2 = lineTrimmingXY [counter2*2];
                                lineTrimmingY2 = lineTrimmingXY [counter2*2+1];
                                
                                for (int counterY = lineTrimmingY-1; counterY <= lineTrimmingY+1; counterY++){
                                    for (int counterX = lineTrimmingX-1; counterX <= lineTrimmingX+1; counterX++){
                                        if (counterX == lineTrimmingX2 && counterY == lineTrimmingY2){
                                            attachPoint++;
                                            
                                            if (attachPoint == 1) countSave = counter2;
                                            if (attachPoint > 1){
                                                for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                    lineTrimmingXY [counter3*2] = -1;
                                                    lineTrimmingXY [counter3*2+1] = -1;
                                                    lineTrimmingValue [counter3] = -1;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    lineDataProcessingCount = 0;
                    
                    for (int counter1 = 0; counter1 < linePointCount; counter1++){
                        if (lineTrimmingValue [counter1] != -1){
                            arrayLineDataProcessing [lineDataProcessingCount] = arrayTargetTemp2 [counter1*2], lineDataProcessingCount++;
                            arrayLineDataProcessing [lineDataProcessingCount] = arrayTargetTemp2 [counter1*2+1], lineDataProcessingCount++;
                        }
                    }
                    
                    delete [] lineTrimmingValue;
                    delete [] lineTrimmingXY;
                    
                    //for (int counterA = 0; counterA < lineDataProcessingCount/2; counterA++){
                    //	cout<<counterA<<" "<<arrayLineDataProcessing [counterA*2]<<" "<<arrayLineDataProcessing [counterA*2+1]<<" LineData"<<endl;
                    //}
                    
                    int *arrayLineDataProcessingTemp = new int [lineDataProcessingCount*2+50];
                    int lineDataProcessingTempCount = 0;
                    
                    arrayLineDataProcessingTemp [lineDataProcessingTempCount] = arrayLineDataProcessing [0], lineDataProcessingTempCount++;
                    arrayLineDataProcessingTemp [lineDataProcessingTempCount] = arrayLineDataProcessing [1], lineDataProcessingTempCount++;
                    
                    for (int counter1 = 0; counter1 < lineDataProcessingCount/2-1; counter1++){
                        lineTrimmingX = arrayLineDataProcessing [counter1*2];
                        lineTrimmingY = arrayLineDataProcessing [counter1*2+1];
                        lineTrimmingX2 = arrayLineDataProcessing [(counter1+1)*2];
                        lineTrimmingY2 = arrayLineDataProcessing [(counter1+1)*2+1];
                        
                        if (lineTrimmingX-1 == lineTrimmingX2 && lineTrimmingY-1 == lineTrimmingY2){
                            arrayLineDataProcessingTemp[lineDataProcessingTempCount] = lineTrimmingX, lineDataProcessingTempCount++;
                            arrayLineDataProcessingTemp[lineDataProcessingTempCount] = lineTrimmingY-1, lineDataProcessingTempCount++;
                            arrayLineDataProcessingTemp[lineDataProcessingTempCount] = lineTrimmingX2, lineDataProcessingTempCount++;
                            arrayLineDataProcessingTemp[lineDataProcessingTempCount] = lineTrimmingY2, lineDataProcessingTempCount++;
                        }
                        else if (lineTrimmingX+1 == lineTrimmingX2 && lineTrimmingY-1 == lineTrimmingY2){
                            arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingX+1, lineDataProcessingTempCount++;
                            arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingY, lineDataProcessingTempCount++;
                            arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingX2, lineDataProcessingTempCount++;
                            arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingY2, lineDataProcessingTempCount++;
                        }
                        else if (lineTrimmingX+1 == lineTrimmingX2 && lineTrimmingY+1 == lineTrimmingY2){
                            arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingX, lineDataProcessingTempCount++;
                            arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingY+1, lineDataProcessingTempCount++;
                            arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingX2, lineDataProcessingTempCount++;
                            arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingY2, lineDataProcessingTempCount++;
                        }
                        else if (lineTrimmingX-1 == lineTrimmingX2 && lineTrimmingY+1 == lineTrimmingY2){
                            arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingX-1, lineDataProcessingTempCount++;
                            arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingY, lineDataProcessingTempCount++;
                            arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingX2, lineDataProcessingTempCount++;
                            arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingY2, lineDataProcessingTempCount++;
                        }
                        else{
                            
                            arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingX2, lineDataProcessingTempCount++;
                            arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingY2, lineDataProcessingTempCount++;
                        }
                    }
                    
                    delete [] arrayLineDataProcessing;
                    lineDataProcessingCount = 0;
                    arrayLineDataProcessing = new int [lineDataProcessingTempCount+50];
                    
                    for (int counter1 = 0; counter1 < lineDataProcessingTempCount; counter1++) arrayLineDataProcessing [lineDataProcessingCount] = arrayLineDataProcessingTemp [counter1], lineDataProcessingCount++;
                    
                    delete [] arrayLineDataProcessingTemp;
                    
                    //for (int counterA = 0; counterA < lineDataProcessingCount/2; counterA++){
                    //	cout<<counterA<<" "<<arrayLineDataProcessing [counterA*2]<<" "<<arrayLineDataProcessing [counterA*2+1]<<" LineData"<<endl;
                    //}
                }
                else targetCount = 0;
                
                //------Entry to Target Hold------
                
                if ((neighbourCount == 0 && lineDataProcessingCount/2 > 5) || (neighbourCount == 1 && lineDataProcessingCount/2 > 11)){
                    int results = 0;
                    
                    if (neighbourCount == 0){
                        newAreaCreation = [[NewAreaCreation alloc] init];
                        [newAreaCreation newAreaLine];
                    }
                    
                    if (neighbourCount == 1){
                        areaCircleCut = [[AreaCircleCut alloc] init];
                        results = [areaCircleCut circleCut:processType];
                    }
                    
                    if (neighbourCount == 1 && results == 0){
                        targetCount = 0;
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    else{
                        
                        areaSetDone = 1;
                        int lineEntryNumber = 0;
                        
                        if (targetHoldCount != 0) lineEntryNumber = arrayTargetHold [(targetHoldCount/3-1)*3+2];
                        else lineEntryNumber = 0;
                        
                        lineEntryNumber++;
                        
                        if (targetHoldCount+lineDataProcessingCount/2*3 > targetHoldLimit){
                            targetHoldAddition = lineDataProcessingCount/2*3;
                            [self targetHoldUpDate];
                        }
                        
                        for (int counter1 = 0; counter1 < lineDataProcessingCount/2; counter1++){
                            arrayTargetHold [targetHoldCount] = arrayLineDataProcessing [counter1*2], targetHoldCount++; //------X position------
                            arrayTargetHold [targetHoldCount] = arrayLineDataProcessing [counter1*2+1], targetHoldCount++; //------Y position------
                            arrayTargetHold [targetHoldCount] = lineEntryNumber, targetHoldCount++; //------Line Number------
                            
                            if (counter1 == 0){
                                if (targetHoldInfoCount+4 > targetHoldInfoLimit) [self targetHoldStatusUpDate];
                                
                                arrayTargetHoldInfo [targetHoldInfoCount] = arrayLineDataProcessing [counter1*2], targetHoldInfoCount++; //------X position First------
                                arrayTargetHoldInfo [targetHoldInfoCount] = arrayLineDataProcessing [counter1*2+1], targetHoldInfoCount++; //------Y position First------
                                
                                if (neighbourCount > 0) arrayTargetHoldInfo [targetHoldInfoCount] = 1, targetHoldInfoCount++; //------Linear, Circle status: cut------
                                else arrayTargetHoldInfo [targetHoldInfoCount] = 0, targetHoldInfoCount++; //------Linear, Circle status: Line------
                                
                                arrayTargetHoldInfo [targetHoldInfoCount] = lineEntryNumber, targetHoldInfoCount++; //------Line Number------
                            }
                        }
                        
                        targetCount = 0;
                    }
                }
                else targetCount = 0;
                
                delete [] arrayLineDataProcessing;
            }
            else targetCount = 0;
            
            delete [] targetGapFill;
            delete [] arrayTargetTemp2;
        }
        else targetCount = 0;
        
        delete [] arrayTargetTemp1;
        
        if (areaModeStatusHold == 1){
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                arrayTimeSelected [counter1*10+9] = 0;
            }
            
            for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                    if ((int)arrayDotDataHold [counter1*3+2] >= 0 && (int)arrayDotDataHold [counter1*3+2] < imageSizeLimit && (int)arrayDotDataHold [counter1*3+1] >= 0 && (int)arrayDotDataHold [counter1*3+1] < imageSizeLimit){
                        if (arrayTimeSelected [counter2*10+8] == revisedWorkingMap [(int)arrayDotDataHold [counter1*3+2]][(int)arrayDotDataHold [counter1*3+1]]){
                            arrayTimeSelected [counter2*10+9]++;
                            break;
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
            //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
            //    cout<<" arrayTimeSelected "<<counterA<<endl;
            //}
            
            subProcesses = [[SubProcesses alloc] init];
            [subProcesses areaTotalDataSet];
            
            ofstream oin;
            
            string dataSaveTreatmentPath2 = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"AnalysisData";
            
            oin.open(dataSaveTreatmentPath2.c_str(), ios::out | ios::binary);
            
            for (int counter1 = 0; counter1 < areaDataHoldCount; counter1++){
                oin<<to_string(arrayAreaDataHold [counter1])<<endl;
            }
            
            oin.close();
            
            areaValueCall = 1;
        }
        
        if (mergeOperationStatus == 0 || saveShortCutNumber == 20){
            saveShortCutNumber = 0;
            targetHoldCount = 0;
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Line Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)gapFillUpdate{
    int *arrayGapUpDate = new int [targetGapFillCount+10];
    
    for (int counter1 = 0; counter1 < targetGapFillCount; counter1++) arrayGapUpDate [counter1] = targetGapFill [counter1];
    
    delete [] targetGapFill;
    targetGapFill = new int [targetGapFillLimit+targetGapFillAddition+500];
    targetGapFillLimit = targetGapFillLimit+targetGapFillAddition+500;
    
    for (int counter1 = 0; counter1 < targetGapFillCount; counter1++) targetGapFill [counter1] = arrayGapUpDate [counter1];
    delete [] arrayGapUpDate;
}

-(void)targetHoldUpDate{
    int *arrayUpDate = new int [targetHoldCount+10];
    
    for (int counter1 = 0; counter1 < targetHoldCount; counter1++) arrayUpDate [counter1] = arrayTargetHold [counter1];
    
    delete [] arrayTargetHold;
    arrayTargetHold = new int [targetHoldLimit+targetHoldAddition+5000];
    targetHoldLimit = targetHoldLimit+targetHoldAddition+5000;
    
    for (int counter1 = 0; counter1 < targetHoldCount; counter1++) arrayTargetHold [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)targetHoldStatusUpDate{
    int *arrayUpDate = new int [targetHoldInfoCount+10];
    
    for (int counter1 = 0; counter1 < targetHoldInfoCount; counter1++) arrayUpDate [counter1] = arrayTargetHoldInfo [counter1];
    
    delete [] arrayTargetHoldInfo;
    arrayTargetHoldInfo = new int [targetHoldInfoLimit+5000];
    targetHoldInfoLimit = targetHoldInfoLimit+5000;
    
    for (int counter1 = 0; counter1 < targetHoldInfoCount; counter1++) arrayTargetHoldInfo [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

@end
