//
//  DotDataCreate.m
//  CellMovieQuant
//
//  Created by Masahiko Sato on 2020-01-15.
//

#import "DotDataCreate.h"

@implementation DotDataCreate

-(IBAction)dotCreateRef1:(id)sender{
    if (phaseStatus == 1){
        int **arrayExtractedImage4 = new int *[imageXYLength+1];
        
        for (int counter3 = 0; counter3 < imageXYLength+1; counter3++){
            arrayExtractedImage4 [counter3] = new int [imageXYLength+1];
        }
        
        for (int counter1 = 0; counter1 < imageXYLength; counter1++){
            for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                arrayExtractedImage4 [counter1][counter2] = 0;
            }
        }
        
        int dataConversion [4];
        int endianType = 0;
        
        unsigned long headPosition = 0;
        
        dataConversion [0] = uploadTempRef2 [0];
        dataConversion [1] = uploadTempRef2 [1];
        
        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
        else endianType = 0;
        
        if (endianType == 1){
            dataConversion [0] = uploadTempRef2 [7];
            dataConversion [1] = uploadTempRef2 [6];
            dataConversion [2] = uploadTempRef2 [5];
            dataConversion [3] = uploadTempRef2 [4];
            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
        }
        else if (endianType == 0){
            dataConversion [0] = uploadTempRef2 [4];
            dataConversion [1] = uploadTempRef2 [5];
            dataConversion [2] = uploadTempRef2 [6];
            dataConversion [3] = uploadTempRef2 [7];
            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
        }
        
        int grayColorStatusRef2 = 0;
        
        if (headPosition-8 == (unsigned long)(imageXYLength*imageXYLength)) grayColorStatusRef2 = 0;
        else grayColorStatusRef2 = 1;
        
        int horizontalBmp = 0;
        int verticalBmp = 0;
        
        if (grayColorStatusRef2 == 0){
            int value0 = 0;
            
            for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                value0 = uploadTempRef2 [counter1];
                
                if (horizontalBmp < imageXYLength){
                    if (value0 >= 50) arrayExtractedImage4 [verticalBmp][horizontalBmp] = -150, horizontalBmp++;
                    else arrayExtractedImage4 [verticalBmp][horizontalBmp] = 0, horizontalBmp++;
                }
                
                if (horizontalBmp == imageXYLength){
                    horizontalBmp = 0;
                    verticalBmp++;
                }
            }
        }
        else if (grayColorStatusRef2 == 1){
            int value0 = 0;
            int value1 = 0;
            int value2 = 0;
            
            for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                value0 = uploadTempRef2 [counter1];
                value1 = uploadTempRef2 [counter1+1];
                value2 = uploadTempRef2 [counter1+2];
                
                if (horizontalBmp < imageXYLength){
                    if ((int)((value0+value1+value2)/(double)3) >= 50) arrayExtractedImage4 [verticalBmp][horizontalBmp] = -150, horizontalBmp++;
                    else  arrayExtractedImage4 [verticalBmp][horizontalBmp] = 0, horizontalBmp++;
                }
                
                if (horizontalBmp == imageXYLength){
                    horizontalBmp = 0;
                    verticalBmp++;
                }
            }
        }
        
        int *connectAnalysisX = new int [imageXYLength*4];
        int *connectAnalysisY = new int [imageXYLength*4];
        int *connectAnalysisTempX = new int [imageXYLength*4];
        int *connectAnalysisTempY = new int [imageXYLength*4];
        
        int connectivityNumber = 0;
        int connectAnalysisCount = 0;
        int terminationFlag = 0;
        int connectAnalysisTempCount = 0;
        int xSource = 0;
        int ySource = 0;
        
        for (int counterY = 0; counterY < imageXYLength; counterY++){
            for (int counterX = 0; counterX < imageXYLength; counterX++){
                if (arrayExtractedImage4 [counterY][counterX] == -150){
                    connectivityNumber++;
                    arrayExtractedImage4 [counterY][counterX] = connectivityNumber;
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && counterX-1 >= 0 && arrayExtractedImage4 [counterY-1][counterX-1] == -150){
                        arrayExtractedImage4 [counterY-1][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && arrayExtractedImage4 [counterY-1][counterX] == -150){
                        arrayExtractedImage4 [counterY-1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && counterX+1 < imageXYLength && arrayExtractedImage4 [counterY-1][counterX+1] == -150){
                        arrayExtractedImage4 [counterY-1][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < imageXYLength && arrayExtractedImage4 [counterY][counterX+1] == -150){
                        arrayExtractedImage4 [counterY][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < imageXYLength && counterX+1 < imageXYLength && arrayExtractedImage4 [counterY+1][counterX+1] == -150){
                        arrayExtractedImage4 [counterY+1][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < imageXYLength && arrayExtractedImage4 [counterY+1][counterX] == -150){
                        arrayExtractedImage4 [counterY+1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < imageXYLength && counterX-1 >= 0 && arrayExtractedImage4 [counterY+1][counterX-1] == -150){
                        arrayExtractedImage4 [counterY+1][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && arrayExtractedImage4 [counterY][counterX-1] == -150){
                        arrayExtractedImage4 [counterY][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && xSource-1 >= 0 && arrayExtractedImage4 [ySource-1][xSource-1] == -150){
                                    arrayExtractedImage4 [ySource-1][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && arrayExtractedImage4 [ySource-1][xSource] == -150){
                                    arrayExtractedImage4 [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && xSource+1 < imageXYLength && arrayExtractedImage4 [ySource-1][xSource+1] == -150){
                                    arrayExtractedImage4 [ySource-1][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < imageXYLength && arrayExtractedImage4 [ySource][xSource+1] == -150){
                                    arrayExtractedImage4 [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 > imageXYLength && xSource+1 < imageXYLength && arrayExtractedImage4 [ySource+1][xSource+1] == -150){
                                    arrayExtractedImage4 [ySource+1][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < imageXYLength && arrayExtractedImage4 [ySource+1][xSource] == -150){
                                    arrayExtractedImage4 [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < imageXYLength && xSource-1 >= 0 && arrayExtractedImage4 [ySource+1][xSource-1] == -150){
                                    arrayExtractedImage4 [ySource+1][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && arrayExtractedImage4 [ySource][xSource-1] == -150){
                                    arrayExtractedImage4 [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        delete [] connectAnalysisX;
        delete [] connectAnalysisY;
        delete [] connectAnalysisTempX;
        delete [] connectAnalysisTempY;
        
        //------Determine number of pixels------
        int *connectedPix = new int [connectivityNumber+50];
        
        for (int counter1 = 0; counter1 <= connectivityNumber; counter1++) connectedPix [counter1] = 0;
        
        for (int counterY = 0; counterY < imageXYLength; counterY++){
            for (int counterX = 0; counterX < imageXYLength; counterX++){
                if (arrayExtractedImage4 [counterY][counterX] != 0) connectedPix [arrayExtractedImage4 [counterY][counterX]]++;
            }
        }
        
        //------Map up-date------
        int connectTemp = 1;
        
        for (int counter1 = 1; counter1 <= connectivityNumber; counter1++){
            if (connectedPix [counter1] < 10) connectedPix [counter1] = 0;
            else{
                
                connectedPix [counter1] = connectTemp;
                connectTemp++;
            }
        }
        
        for (int counterY = 0; counterY < imageXYLength; counterY++){
            for (int counterX = 0; counterX < imageXYLength; counterX++){
                if ((connectTemp = arrayExtractedImage4 [counterY][counterX]) != 0) arrayExtractedImage4 [counterY][counterX] = connectedPix [connectTemp];
            }
        }
        
        delete [] connectedPix;
        
        int maxConnectNoMap = 0;
        
        for (int counter3 = 0; counter3 < imageXYLength; counter3++){
            for (int counter4 = 0; counter4 < imageXYLength; counter4++){
                if (arrayExtractedImage4 [counter3][counter4] > maxConnectNoMap) maxConnectNoMap = arrayExtractedImage4 [counter3][counter4];
            }
        }
        
        double *mapGCCalculations = new double [maxConnectNoMap*2+20];
        int *mapGRPointNo = new int [maxConnectNoMap+10];
        
        for (int counter3 = 0; counter3 <= maxConnectNoMap; counter3++){
            mapGCCalculations [counter3*2] = 0;
            mapGCCalculations [counter3*2+1] = 0;
            mapGRPointNo [counter3] = 0;
        }
        
        for (int counter3 = 0; counter3 < imageXYLength; counter3++){
            for (int counter4 = 0; counter4 < imageXYLength; counter4++){
                if (arrayExtractedImage4 [counter3][counter4] > 0){
                    mapGCCalculations [arrayExtractedImage4 [counter3][counter4]*2] = mapGCCalculations [arrayExtractedImage4 [counter3][counter4]*2]+counter4;
                    mapGCCalculations [arrayExtractedImage4 [counter3][counter4]*2+1] = mapGCCalculations [arrayExtractedImage4 [counter3][counter4]*2+1]+counter3;
                    mapGRPointNo [arrayExtractedImage4 [counter3][counter4]]++;
                }
            }
        }
        
        dotDataHoldCount = 0;
        dotNumberCurrent = 0;
        
        for (int counter3 = 0; counter3 <= maxConnectNoMap; counter3++){
            if (dotDataHoldLimit < dotDataHoldCount+50) [self arrayDotDataHoldUpDate];
            
            if (dotSetFirstSecondHold == 0) arrayDotDataHold [dotDataHoldCount] = timePointHold, dotDataHoldCount++;
            else if (dotSetFirstSecondHold == 1) arrayDotDataHold [dotDataHoldCount] = timePointHold*-1, dotDataHoldCount++;
            else if (dotSetFirstSecondHold == 2) arrayDotDataHold [dotDataHoldCount] = timePointHold+100000, dotDataHoldCount++;
            else if (dotSetFirstSecondHold == 3) arrayDotDataHold [dotDataHoldCount] = timePointHold*-1-100000, dotDataHoldCount++;
            
            arrayDotDataHold [dotDataHoldCount] = (int)(mapGCCalculations [counter3*2]/(double)mapGRPointNo [counter3]), dotDataHoldCount++;
            arrayDotDataHold [dotDataHoldCount] = (int)(mapGCCalculations [counter3*2+1]/(double)mapGRPointNo [counter3]), dotDataHoldCount++;
            
            dotNumberCurrent++;
        }
        
        ofstream oin;
        
        string dataSaveTreatmentPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"DotData";
        
        oin.open(dataSaveTreatmentPath.c_str(), ios::out | ios::binary);
        
        for (int counter1 = 0; counter1 < dotDataHoldCount; counter1++) oin<<arrayDotDataHold [counter1]<<endl;
        
        oin.close();
        
        arrayAreaDataHold [(timePointHold-1)*25+5] = dotNumberCurrent;
        
        if (areaModeStatusHold == 1){
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                arrayTimeSelected [counter1*10+9] = 0;
            }
            
            for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                    if ((int)arrayDotDataHold [counter1*3+2] >= 0 && (int)arrayDotDataHold [counter1*3+2] < imageSizeLimit && (int)arrayDotDataHold [counter1*3+1] >= 0 && (int)arrayDotDataHold [counter1*3+1] < imageSizeLimit){
                        if (arrayTimeSelected [counter2*10+8] == revisedWorkingMap [(int)arrayDotDataHold [counter1*3+2]][(int)arrayDotDataHold [counter1*3+1]]){
                            arrayTimeSelected [counter2*10+9]++;
                            break;
                        }
                    }
                }
            }
            
            subProcesses = [[SubProcesses alloc] init];
            [subProcesses areaTotalDataSet];
        }
        
        string dataSaveTreatmentPath2 = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"AnalysisData";
        
        oin.open(dataSaveTreatmentPath2.c_str(), ios::out | ios::binary);
        
        for (int counter1 = 0; counter1 < areaDataHoldCount; counter1++){
            oin<<to_string(arrayAreaDataHold [counter1])<<endl;
        }
        
        oin.close();
        
        areaValueCall = 1;
        
        for (int counter3 = 0; counter3 < imageXYLength+1; counter3++){
            delete [] arrayExtractedImage4 [counter3];
        }
        
        delete [] arrayExtractedImage4;
        
        delete [] mapGCCalculations;
        delete [] mapGRPointNo;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Ref Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dotCreateRef2:(id)sender{
    if (phaseStatus == 1){
        int **arrayExtractedImage4 = new int *[imageXYLength+1];
        
        for (int counter3 = 0; counter3 < imageXYLength+1; counter3++){
            arrayExtractedImage4 [counter3] = new int [imageXYLength+1];
        }
        
        for (int counter1 = 0; counter1 < imageXYLength; counter1++){
            for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                arrayExtractedImage4 [counter1][counter2] = 0;
            }
        }
        
        int dataConversion [4];
        int endianType = 0;
        
        unsigned long headPosition = 0;
        
        dataConversion [0] = uploadTempRef3 [0];
        dataConversion [1] = uploadTempRef3 [1];
        
        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
        else endianType = 0;
        
        if (endianType == 1){
            dataConversion [0] = uploadTempRef3 [7];
            dataConversion [1] = uploadTempRef3 [6];
            dataConversion [2] = uploadTempRef3 [5];
            dataConversion [3] = uploadTempRef3 [4];
            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
        }
        else if (endianType == 0){
            dataConversion [0] = uploadTempRef3 [4];
            dataConversion [1] = uploadTempRef3 [5];
            dataConversion [2] = uploadTempRef3 [6];
            dataConversion [3] = uploadTempRef3 [7];
            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
        }
        
        int grayColorStatusRef3 = 0;
        
        if (headPosition-8 == (unsigned long)(imageXYLength*imageXYLength)) grayColorStatusRef3 = 0;
        else grayColorStatusRef3 = 1;
        
        int horizontalBmp = 0;
        int verticalBmp = 0;
        
        if (grayColorStatusRef3 == 0){
            int value0 = 0;
            
            for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                value0 = uploadTempRef3 [counter1];
                
                if (horizontalBmp < imageXYLength){
                    if (value0 >= 50) arrayExtractedImage4 [verticalBmp][horizontalBmp] = -150, horizontalBmp++;
                    else arrayExtractedImage4 [verticalBmp][horizontalBmp] = 0, horizontalBmp++;
                }
                
                if (horizontalBmp == imageXYLength){
                    horizontalBmp = 0;
                    verticalBmp++;
                }
            }
        }
        else if (grayColorStatusRef3 == 1){
            int value0 = 0;
            int value1 = 0;
            int value2 = 0;
            
            for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                value0 = uploadTempRef3 [counter1];
                value1 = uploadTempRef3 [counter1+1];
                value2 = uploadTempRef3 [counter1+2];
                
                if (horizontalBmp < imageXYLength){
                    if ((int)((value0+value1+value2)/(double)3) >= 50) arrayExtractedImage4 [verticalBmp][horizontalBmp] = -150, horizontalBmp++;
                    else  arrayExtractedImage4 [verticalBmp][horizontalBmp] = 0, horizontalBmp++;
                }
                
                if (horizontalBmp == imageXYLength){
                    horizontalBmp = 0;
                    verticalBmp++;
                }
            }
        }
        
        int *connectAnalysisX = new int [imageXYLength*4];
        int *connectAnalysisY = new int [imageXYLength*4];
        int *connectAnalysisTempX = new int [imageXYLength*4];
        int *connectAnalysisTempY = new int [imageXYLength*4];
        
        int connectivityNumber = 0;
        int connectAnalysisCount = 0;
        int terminationFlag = 0;
        int connectAnalysisTempCount = 0;
        int xSource = 0;
        int ySource = 0;
        
        for (int counterY = 0; counterY < imageXYLength; counterY++){
            for (int counterX = 0; counterX < imageXYLength; counterX++){
                if (arrayExtractedImage4 [counterY][counterX] == -150){
                    connectivityNumber++;
                    arrayExtractedImage4 [counterY][counterX] = connectivityNumber;
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && counterX-1 >= 0 && arrayExtractedImage4 [counterY-1][counterX-1] == -150){
                        arrayExtractedImage4 [counterY-1][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && arrayExtractedImage4 [counterY-1][counterX] == -150){
                        arrayExtractedImage4 [counterY-1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && counterX+1 < imageXYLength && arrayExtractedImage4 [counterY-1][counterX+1] == -150){
                        arrayExtractedImage4 [counterY-1][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < imageXYLength && arrayExtractedImage4 [counterY][counterX+1] == -150){
                        arrayExtractedImage4 [counterY][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < imageXYLength && counterX+1 < imageXYLength && arrayExtractedImage4 [counterY+1][counterX+1] == -150){
                        arrayExtractedImage4 [counterY+1][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < imageXYLength && arrayExtractedImage4 [counterY+1][counterX] == -150){
                        arrayExtractedImage4 [counterY+1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < imageXYLength && counterX-1 >= 0 && arrayExtractedImage4 [counterY+1][counterX-1] == -150){
                        arrayExtractedImage4 [counterY+1][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && arrayExtractedImage4 [counterY][counterX-1] == -150){
                        arrayExtractedImage4 [counterY][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && xSource-1 >= 0 && arrayExtractedImage4 [ySource-1][xSource-1] == -150){
                                    arrayExtractedImage4 [ySource-1][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && arrayExtractedImage4 [ySource-1][xSource] == -150){
                                    arrayExtractedImage4 [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && xSource+1 < imageXYLength && arrayExtractedImage4 [ySource-1][xSource+1] == -150){
                                    arrayExtractedImage4 [ySource-1][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < imageXYLength && arrayExtractedImage4 [ySource][xSource+1] == -150){
                                    arrayExtractedImage4 [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 > imageXYLength && xSource+1 < imageXYLength && arrayExtractedImage4 [ySource+1][xSource+1] == -150){
                                    arrayExtractedImage4 [ySource+1][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < imageXYLength && arrayExtractedImage4 [ySource+1][xSource] == -150){
                                    arrayExtractedImage4 [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < imageXYLength && xSource-1 >= 0 && arrayExtractedImage4 [ySource+1][xSource-1] == -150){
                                    arrayExtractedImage4 [ySource+1][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && arrayExtractedImage4 [ySource][xSource-1] == -150){
                                    arrayExtractedImage4 [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        delete [] connectAnalysisX;
        delete [] connectAnalysisY;
        delete [] connectAnalysisTempX;
        delete [] connectAnalysisTempY;
        
        //------Determine number of pixels------
        int *connectedPix = new int [connectivityNumber+50];
        
        for (int counter1 = 0; counter1 <= connectivityNumber; counter1++) connectedPix [counter1] = 0;
        
        for (int counterY = 0; counterY < imageXYLength; counterY++){
            for (int counterX = 0; counterX < imageXYLength; counterX++){
                if (arrayExtractedImage4 [counterY][counterX] != 0) connectedPix [arrayExtractedImage4 [counterY][counterX]]++;
            }
        }
        
        //------Map up-date------
        int connectTemp = 1;
        
        for (int counter1 = 1; counter1 <= connectivityNumber; counter1++){
            if (connectedPix [counter1] < 10) connectedPix [counter1] = 0;
            else{
                
                connectedPix [counter1] = connectTemp;
                connectTemp++;
            }
        }
        
        for (int counterY = 0; counterY < imageXYLength; counterY++){
            for (int counterX = 0; counterX < imageXYLength; counterX++){
                if ((connectTemp = arrayExtractedImage4 [counterY][counterX]) != 0) arrayExtractedImage4 [counterY][counterX] = connectedPix [connectTemp];
            }
        }
        
        delete [] connectedPix;
        
        int maxConnectNoMap = 0;
        
        for (int counter3 = 0; counter3 < imageXYLength; counter3++){
            for (int counter4 = 0; counter4 < imageXYLength; counter4++){
                if (arrayExtractedImage4 [counter3][counter4] > maxConnectNoMap) maxConnectNoMap = arrayExtractedImage4 [counter3][counter4];
            }
        }
        
        double *mapGCCalculations = new double [maxConnectNoMap*2+20];
        int *mapGRPointNo = new int [maxConnectNoMap+10];
        
        for (int counter3 = 0; counter3 <= maxConnectNoMap; counter3++){
            mapGCCalculations [counter3*2] = 0;
            mapGCCalculations [counter3*2+1] = 0;
            mapGRPointNo [counter3] = 0;
        }
        
        for (int counter3 = 0; counter3 < imageXYLength; counter3++){
            for (int counter4 = 0; counter4 < imageXYLength; counter4++){
                if (arrayExtractedImage4 [counter3][counter4] > 0){
                    mapGCCalculations [arrayExtractedImage4 [counter3][counter4]*2] = mapGCCalculations [arrayExtractedImage4 [counter3][counter4]*2]+counter4;
                    mapGCCalculations [arrayExtractedImage4 [counter3][counter4]*2+1] = mapGCCalculations [arrayExtractedImage4 [counter3][counter4]*2+1]+counter3;
                    mapGRPointNo [arrayExtractedImage4 [counter3][counter4]]++;
                }
            }
        }
        
        dotDataHoldCount = 0;
        dotNumberCurrent = 0;
        
        for (int counter3 = 1; counter3 <= maxConnectNoMap; counter3++){
            if (dotDataHoldLimit < dotDataHoldCount+50) [self arrayDotDataHoldUpDate];
            
            if (dotSetFirstSecondHold == 0) arrayDotDataHold [dotDataHoldCount] = timePointHold, dotDataHoldCount++;
            else if (dotSetFirstSecondHold == 1) arrayDotDataHold [dotDataHoldCount] = timePointHold*-1, dotDataHoldCount++;
            else if (dotSetFirstSecondHold == 2) arrayDotDataHold [dotDataHoldCount] = timePointHold+100000, dotDataHoldCount++;
            else if (dotSetFirstSecondHold == 3) arrayDotDataHold [dotDataHoldCount] = timePointHold*-1-100000, dotDataHoldCount++;
            
            arrayDotDataHold [dotDataHoldCount] = (int)(mapGCCalculations [counter3*2]/(double)mapGRPointNo [counter3]), dotDataHoldCount++;
            arrayDotDataHold [dotDataHoldCount] = (int)(mapGCCalculations [counter3*2+1]/(double)mapGRPointNo [counter3]), dotDataHoldCount++;
            
            dotNumberCurrent++;
        }
        
        ofstream oin;
        
        string dataSaveTreatmentPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"DotData";
        
        oin.open(dataSaveTreatmentPath.c_str(), ios::out | ios::binary);
        
        for (int counter1 = 0; counter1 < dotDataHoldCount; counter1++) oin<<arrayDotDataHold [counter1]<<endl;
        
        oin.close();
        
        arrayAreaDataHold [(timePointHold-1)*25+5] = dotNumberCurrent;
        
        if (areaModeStatusHold == 1){
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                arrayTimeSelected [counter1*10+9] = 0;
            }
            
            for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                    if ((int)arrayDotDataHold [counter1*3+2] >= 0 && (int)arrayDotDataHold [counter1*3+2] < imageSizeLimit && (int)arrayDotDataHold [counter1*3+1] >= 0 && (int)arrayDotDataHold [counter1*3+1] < imageSizeLimit){
                        if (arrayTimeSelected [counter2*10+8] == revisedWorkingMap [(int)arrayDotDataHold [counter1*3+2]][(int)arrayDotDataHold [counter1*3+1]]){
                            arrayTimeSelected [counter2*10+9]++;
                            break;
                        }
                    }
                }
            }
            
            subProcesses = [[SubProcesses alloc] init];
            [subProcesses areaTotalDataSet];
        }
        
        string dataSaveTreatmentPath2 = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"AnalysisData";
        
        oin.open(dataSaveTreatmentPath2.c_str(), ios::out | ios::binary);
        
        for (int counter1 = 0; counter1 < areaDataHoldCount; counter1++){
            oin<<to_string(arrayAreaDataHold [counter1])<<endl;
        }
        
        oin.close();
        
        areaValueCall = 1;
        
        for (int counter3 = 0; counter3 < imageXYLength+1; counter3++){
            delete [] arrayExtractedImage4 [counter3];
        }
        
        delete [] arrayExtractedImage4;
        
        delete [] mapGCCalculations;
        delete [] mapGRPointNo;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Ref Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)removeInside:(id)sender{
    if (dotNumberCurrent != 0){
        int *arrayDotDataTemp = new int [dotDataHoldCount+30];
        int dotDataTempCount = 0;
        
        for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
            arrayDotDataTemp [dotDataTempCount] = arrayDotDataHold [counter1*3], dotDataTempCount++;
            arrayDotDataTemp [dotDataTempCount] = arrayDotDataHold [counter1*3+1], dotDataTempCount++;
            arrayDotDataTemp [dotDataTempCount] = arrayDotDataHold [counter1*3+2], dotDataTempCount++;
            arrayDotDataTemp [dotDataTempCount] = 0, dotDataTempCount++;
        }
        
        for (int counter1 = 0; counter1 < dotDataTempCount/4; counter1++){
            for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                if ((int)arrayDotDataTemp [counter1*4+2] >= 0 && (int)arrayDotDataTemp [counter1*4+2] < imageSizeLimit && (int)arrayDotDataTemp [counter1*4+1] >= 0 && (int)arrayDotDataTemp [counter1*4+1] < imageSizeLimit){
                    if (arrayTimeSelected [counter2*10+8] == revisedWorkingMap [(int)arrayDotDataTemp [counter1*4+2]][(int)arrayDotDataTemp [counter1*4+1]]){
                        arrayDotDataTemp [counter1*4+3] = 1;
                        break;
                    }
                }
            }
        }
        
        dotDataHoldCount = 0;
        dotNumberCurrent = 0;
        
        for (int counter3 = 0; counter3 < dotDataTempCount/4; counter3++){
            if (dotDataHoldLimit < dotDataHoldCount+50) [self arrayDotDataHoldUpDate];
            
            if (arrayDotDataTemp [counter3*4+3] == 0){
                if (dotSetFirstSecondHold == 0) arrayDotDataHold [dotDataHoldCount] = timePointHold, dotDataHoldCount++;
                else if (dotSetFirstSecondHold == 1) arrayDotDataHold [dotDataHoldCount] = timePointHold*-1, dotDataHoldCount++;
                else if (dotSetFirstSecondHold == 2) arrayDotDataHold [dotDataHoldCount] = timePointHold+100000, dotDataHoldCount++;
                else if (dotSetFirstSecondHold == 3) arrayDotDataHold [dotDataHoldCount] = timePointHold*-1-100000, dotDataHoldCount++;
                
                arrayDotDataHold [dotDataHoldCount] = arrayDotDataTemp [counter3*4+1], dotDataHoldCount++;
                arrayDotDataHold [dotDataHoldCount] = arrayDotDataTemp [counter3*4+2], dotDataHoldCount++;
                
                dotNumberCurrent++;
            }
        }
        
        delete [] arrayDotDataTemp;
        
        ofstream oin;
        
        string dataSaveTreatmentPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"DotData";
        
        oin.open(dataSaveTreatmentPath.c_str(), ios::out | ios::binary);
        
        for (int counter1 = 0; counter1 < dotDataHoldCount; counter1++) oin<<arrayDotDataHold [counter1]<<endl;
        
        oin.close();
        
        arrayAreaDataHold [(timePointHold-1)*25+5] = dotNumberCurrent;
        
        if (areaModeStatusHold == 1){
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                arrayTimeSelected [counter1*10+9] = 0;
            }
            
            for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                    if ((int)arrayDotDataHold [counter1*3+2] >= 0 && (int)arrayDotDataHold [counter1*3+2] < imageSizeLimit && (int)arrayDotDataHold [counter1*3+1] >= 0 && (int)arrayDotDataHold [counter1*3+1] < imageSizeLimit){
                        if (arrayTimeSelected [counter2*10+8] == revisedWorkingMap [(int)arrayDotDataHold [counter1*3+2]][(int)arrayDotDataHold [counter1*3+1]]){
                            arrayTimeSelected [counter2*10+9]++;
                            break;
                        }
                    }
                }
            }
            
            subProcesses = [[SubProcesses alloc] init];
            [subProcesses areaTotalDataSet];
        }
        
        string dataSaveTreatmentPath2 = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"AnalysisData";
        
        oin.open(dataSaveTreatmentPath2.c_str(), ios::out | ios::binary);
        
        for (int counter1 = 0; counter1 < areaDataHoldCount; counter1++){
            oin<<to_string(arrayAreaDataHold [counter1])<<endl;
        }
        
        oin.close();
        
        areaValueCall = 1;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Dot Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)removeOutside:(id)sender{
    if (dotNumberCurrent != 0){
        if (dotNumberCurrent != 0){
            int *arrayDotDataTemp = new int [dotDataHoldCount+30];
            int dotDataTempCount = 0;
            
            for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                arrayDotDataTemp [dotDataTempCount] = arrayDotDataHold [counter1*3], dotDataTempCount++;
                arrayDotDataTemp [dotDataTempCount] = arrayDotDataHold [counter1*3+1], dotDataTempCount++;
                arrayDotDataTemp [dotDataTempCount] = arrayDotDataHold [counter1*3+2], dotDataTempCount++;
                arrayDotDataTemp [dotDataTempCount] = 0, dotDataTempCount++;
            }
            
            for (int counter1 = 0; counter1 < dotDataTempCount/4; counter1++){
                for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                    if ((int)arrayDotDataTemp [counter1*4+2] >= 0 && (int)arrayDotDataTemp [counter1*4+2] < imageSizeLimit && (int)arrayDotDataTemp [counter1*4+1] >= 0 && (int)arrayDotDataTemp [counter1*4+1] < imageSizeLimit){
                        if (arrayTimeSelected [counter2*10+8] == revisedWorkingMap [(int)arrayDotDataTemp [counter1*4+2]][(int)arrayDotDataTemp [counter1*4+1]]){
                            arrayDotDataTemp [counter1*4+3] = 1;
                            break;
                        }
                    }
                }
            }
            
            dotDataHoldCount = 0;
            dotNumberCurrent = 0;
            
            for (int counter3 = 0; counter3 < dotDataTempCount/4; counter3++){
                if (dotDataHoldLimit < dotDataHoldCount+50) [self arrayDotDataHoldUpDate];
                
                if (arrayDotDataTemp [counter3*4+3] == 1){
                    if (dotSetFirstSecondHold == 0) arrayDotDataHold [dotDataHoldCount] = timePointHold, dotDataHoldCount++;
                    else if (dotSetFirstSecondHold == 1) arrayDotDataHold [dotDataHoldCount] = timePointHold*-1, dotDataHoldCount++;
                    else if (dotSetFirstSecondHold == 2) arrayDotDataHold [dotDataHoldCount] = timePointHold+100000, dotDataHoldCount++;
                    else if (dotSetFirstSecondHold == 3) arrayDotDataHold [dotDataHoldCount] = timePointHold*-1-100000, dotDataHoldCount++;
                    
                    arrayDotDataHold [dotDataHoldCount] = arrayDotDataTemp [counter3*4+1], dotDataHoldCount++;
                    arrayDotDataHold [dotDataHoldCount] = arrayDotDataTemp [counter3*4+2], dotDataHoldCount++;
                    
                    dotNumberCurrent++;
                }
            }
            
            delete [] arrayDotDataTemp;
            
            ofstream oin;
            
            string dataSaveTreatmentPath = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"DotData";
            
            oin.open(dataSaveTreatmentPath.c_str(), ios::out | ios::binary);
            
            for (int counter1 = 0; counter1 < dotDataHoldCount; counter1++) oin<<arrayDotDataHold [counter1]<<endl;
            
            oin.close();
            
            arrayAreaDataHold [(timePointHold-1)*25+5] = dotNumberCurrent;
            
            if (areaModeStatusHold == 1){
                for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                    arrayTimeSelected [counter1*10+9] = 0;
                }
                
                for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                    for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                        if ((int)arrayDotDataHold [counter1*3+2] >= 0 && (int)arrayDotDataHold [counter1*3+2] < imageSizeLimit && (int)arrayDotDataHold [counter1*3+1] >= 0 && (int)arrayDotDataHold [counter1*3+1] < imageSizeLimit){
                            if (arrayTimeSelected [counter2*10+8] == revisedWorkingMap [(int)arrayDotDataHold [counter1*3+2]][(int)arrayDotDataHold [counter1*3+1]]){
                                arrayTimeSelected [counter2*10+9]++;
                                break;
                            }
                        }
                    }
                }
                
                subProcesses = [[SubProcesses alloc] init];
                [subProcesses areaTotalDataSet];
            }
            
            string dataSaveTreatmentPath2 = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold/"+"AnalysisData";
            
            oin.open(dataSaveTreatmentPath2.c_str(), ios::out | ios::binary);
            
            for (int counter1 = 0; counter1 < areaDataHoldCount; counter1++){
                oin<<to_string(arrayAreaDataHold [counter1])<<endl;
            }
            
            oin.close();
            
            areaValueCall = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Dot Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Dot Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dotImport:(id)sender{
    if (analysisNameHold != "" && treatNameHold != ""){
        NSOpenPanel *openDlg = [NSOpenPanel openPanel];
        [openDlg setCanChooseFiles:NO];
        [openDlg setCanChooseDirectories:YES];
        
        if ([openDlg runModal] == NSModalResponseOK){
            NSArray *files = [openDlg URLs];
            NSString *fileName = [[files objectAtIndex:0] absoluteString];
            
            string directoryPathImport = [fileName UTF8String];
            
            int findString1 = (int)directoryPathImport.find("/Users/");
            if (findString1 == -1) findString1 = (int)directoryPathImport.find("/Volumes/");
            
            unsigned long directoryLength = directoryPathImport.length();
            directoryPathImport = directoryPathImport.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
            string extractedID;
            string extractedID2;
            
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                
                findString1 = (int)directoryPathImport.find("%20");
                if (findString1 != -1){
                    extractedID2 = directoryPathImport.substr(0, (unsigned long)findString1);
                    directoryPathImport = directoryPathImport.substr((unsigned long)findString1+3);
                    directoryPathImport = extractedID2+" "+directoryPathImport;
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            extractedID = directoryPathImport;
            string stringExtract;
            
            do{
                
                terminationFlag = 1;
                findString1 = (int)extractedID.find("/");
                
                if (findString1 != -1){
                    stringExtract = extractedID.substr(0, (unsigned long)findString1);
                    extractedID = extractedID.substr((unsigned long)findString1+1);
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            extractedID2 = extractedID.substr(0, extractedID.find("-InfoHold"));
            
            string entry;
            
            DIR *dir;
            struct dirent *dent;
            
            dir = opendir(dataSavePath.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if ((int)entry.find(extractedID2) != -1){
                        break;
                    }
                }
                
                closedir(dir);
            }
            
            if ((int)extractedID.find("InfoHold") != -1){
                long sizeForCopy = 0;
                struct stat sizeOfFile;
                
                mkdir(dataSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                string directoryPathSave = dataSavePath+"/"+extractedID2+"-InfoHold";
                mkdir(directoryPathSave.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                dir = opendir(directoryPathImport.c_str());
                
                if (dir != NULL){
                    string pathName2;
                    string pathNameB2;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            pathName2 = directoryPathImport+"/"+entry;
                            pathNameB2 = directoryPathSave+"/"+entry;
                            
                            if (stat(pathName2.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                ifstream infile (pathName2.c_str(), ifstream::binary);
                                ofstream outfile (pathNameB2.c_str(), ofstream::binary);
                                
                                char *buffer = new char[sizeForCopy];
                                infile.read (buffer, sizeForCopy);
                                outfile.write (buffer, sizeForCopy);
                                delete [] buffer;
                                
                                outfile.close();
                                infile.close();
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"InfoHold Directory Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dotExport:(id)sender{
    if (analysisNameHold != "" && treatNameHold != ""){
        NSOpenPanel *openDlg = [NSOpenPanel openPanel];
        [openDlg setCanChooseFiles:NO];
        [openDlg setCanChooseDirectories:YES];
        
        if ([openDlg runModal] == NSModalResponseOK){
            NSArray *files = [openDlg URLs];
            NSString *fileName = [[files objectAtIndex:0] absoluteString];
            
            string directoryPathImport = [fileName UTF8String];
            
            int findString1 = (int)directoryPathImport.find("/Users/");
            if (findString1 == -1) findString1 = (int)directoryPathImport.find("/Volumes/");
            
            unsigned long directoryLength = directoryPathImport.length();
            directoryPathImport = directoryPathImport.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
            string extractedID;
            string extractedID2;
            
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                
                findString1 = (int)directoryPathImport.find("%20");
                if (findString1 != -1){
                    extractedID2 = directoryPathImport.substr(0, (unsigned long)findString1);
                    directoryPathImport = directoryPathImport.substr((unsigned long)findString1+3);
                    directoryPathImport = extractedID2+" "+directoryPathImport;
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            mkdir(directoryPathImport.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            DIR *dir;
            struct dirent *dent;
            
            string entry;
            string extractString;
            int maxEntryNo = 0;
            
            dir = opendir(directoryPathImport.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(analysisNameHold+"_"+treatNameHold) != -1){
                        extractString = entry.substr(entry.find("InfoHold-")+9);
                        
                        if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                    }
                }
                
                closedir(dir);
            }
            
            maxEntryNo++;
            
            string resultSavePath2 = directoryPathImport+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold-"+to_string(maxEntryNo);
            mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            long sizeForCopy = 0;
            struct stat sizeOfFile;
            
            string pathName2 = dataSavePath+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold";
            
            dir = opendir(pathName2.c_str());
            
            if (dir != NULL){
                string pathNameA2;
                string pathNameB2;
                
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        pathNameA2 = pathName2+"/"+entry;
                        pathNameB2 = resultSavePath2+"/"+entry;
                        
                        if (stat(pathNameA2.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            ifstream infile (pathNameA2.c_str(), ifstream::binary);
                            ofstream outfile (pathNameB2.c_str(), ofstream::binary);
                            
                            char *buffer = new char[sizeForCopy];
                            infile.read (buffer, sizeForCopy);
                            outfile.write (buffer, sizeForCopy);
                            delete [] buffer;
                            
                            outfile.close();
                            infile.close();
                        }
                    }
                }
                
                closedir(dir);
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dotExportRangeSet:(id)sender{
    if (analysisNameHold != "" && treatNameHold != ""){
        int displayTimeRangeMin = dotExportLimitTimeFrom;
        int displayTimeRangeMax = 0;
        
        if (dotExportLimitTimeTo > maxImageNo) displayTimeRangeMax = maxImageNo;
        else displayTimeRangeMax = dotExportLimitTimeTo;
        
        if (displayTimeRangeMax == displayTimeRangeMin || displayTimeRangeMax < displayTimeRangeMin){
            displayTimeRangeMin = 0;
            displayTimeRangeMax = 0;
        }
        
        if (displayTimeRangeMin > 0 && displayTimeRangeMax > 0){
            NSOpenPanel *openDlg = [NSOpenPanel openPanel];
            [openDlg setCanChooseFiles:NO];
            [openDlg setCanChooseDirectories:YES];
            
            if ([openDlg runModal] == NSModalResponseOK){
                NSArray *files = [openDlg URLs];
                NSString *fileName = [[files objectAtIndex:0] absoluteString];
                
                string directoryPathImport = [fileName UTF8String];
                
                int findString1 = (int)directoryPathImport.find("/Users/");
                if (findString1 == -1) findString1 = (int)directoryPathImport.find("/Volumes/");
                
                unsigned long directoryLength = directoryPathImport.length();
                directoryPathImport = directoryPathImport.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
                string extractedID;
                string extractedID2;
                
                int terminationFlag = 0;
                
                do{
                    
                    terminationFlag = 1;
                    
                    findString1 = (int)directoryPathImport.find("%20");
                    if (findString1 != -1){
                        extractedID2 = directoryPathImport.substr(0, (unsigned long)findString1);
                        directoryPathImport = directoryPathImport.substr((unsigned long)findString1+3);
                        directoryPathImport = extractedID2+" "+directoryPathImport;
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                mkdir(directoryPathImport.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                DIR *dir;
                struct dirent *dent;
                
                string entry;
                string extractString;
                int maxEntryNo = 0;
                
                dir = opendir(directoryPathImport.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(analysisNameHold+"_"+treatNameHold) != -1){
                            extractString = entry.substr(entry.find("InfoHold-")+9);
                            
                            if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                        }
                    }
                    
                    closedir(dir);
                }
                
                maxEntryNo++;
                
                string resultSavePath2 = directoryPathImport+"/"+analysisNameHold+"_"+treatNameHold+"-InfoHold-"+to_string(maxEntryNo);
                mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                string dataSaveTreatmentPath2 = resultSavePath2+"/MovieData";
                
                ofstream oin;
                
                oin.open(dataSaveTreatmentPath2.c_str(),ios::out);
                oin<<imageXYLength*imageXYLength<<endl;
                oin.close();
                
                string dataSaveTreatmentPath3 = resultSavePath2+"/AnalysisData";
                
                oin.open(dataSaveTreatmentPath3.c_str(), ios::out | ios::binary);
                
                for (int counter1 = 0; counter1 < areaDataHoldCount; counter1++){
                    oin<<to_string(arrayAreaDataHold [counter1])<<endl;
                }
                
                oin.close();
                
                string dataSaveTreatmentPath = resultSavePath2+"/DotData";
                
                oin.open(dataSaveTreatmentPath.c_str(), ios::out | ios::binary);
                
                for (int counter1 = 0; counter1 < dotDataHoldCount/3; counter1++){
                    if (arrayDotDataHold [counter1*3] >= 0 && arrayDotDataHold [counter1*3] <= 100000){
                        if (arrayDotDataHold [counter1*3] >= dotExportLimitTimeFrom && arrayDotDataHold [counter1*3] <= dotExportLimitTimeTo){
                            oin<<arrayDotDataHold [counter1*3]<<endl;
                            oin<<arrayDotDataHold [counter1*3+1]<<endl;
                            oin<<arrayDotDataHold [counter1*3+2]<<endl;
                        }
                    }
                    else if (arrayDotDataHold [counter1*3] < 0 && arrayDotDataHold [counter1*3] >= -100000){
                        if (arrayDotDataHold [counter1*3]*-1 >= dotExportLimitTimeFrom && arrayDotDataHold [counter1*3]*-1 <= dotExportLimitTimeTo){
                            oin<<arrayDotDataHold [counter1*3]<<endl;
                            oin<<arrayDotDataHold [counter1*3+1]<<endl;
                            oin<<arrayDotDataHold [counter1*3+2]<<endl;
                        }
                    }
                    else if (arrayDotDataHold [counter1*3] >= 100000){
                        if (arrayDotDataHold [counter1*3]-100000 >= dotExportLimitTimeFrom && arrayDotDataHold [counter1*3]-100000 <= dotExportLimitTimeTo){
                            oin<<arrayDotDataHold [counter1*3]<<endl;
                            oin<<arrayDotDataHold [counter1*3+1]<<endl;
                            oin<<arrayDotDataHold [counter1*3+2]<<endl;
                        }
                    }
                    else if (arrayDotDataHold [counter1*3] <= -100000){
                        if (arrayDotDataHold [counter1*3]*-1-100000 >= dotExportLimitTimeFrom && arrayDotDataHold [counter1*3]*-1-100000 <= dotExportLimitTimeTo){
                            oin<<arrayDotDataHold [counter1*3]<<endl;
                            oin<<arrayDotDataHold [counter1*3+1]<<endl;
                            oin<<arrayDotDataHold [counter1*3+2]<<endl;
                        }
                    }
                }
                
                oin.close();
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Range Setting Incorrect"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)arrayDotDataHoldUpDate{
    int *arrayUpDate = new int [dotDataHoldCount+10];
    
    for (int counter1 = 0; counter1 < dotDataHoldCount; counter1++) arrayUpDate [counter1] = arrayDotDataHold [counter1];
    
    delete [] arrayDotDataHold;
    arrayDotDataHold = new int [dotDataHoldLimit+1000];
    dotDataHoldLimit = dotDataHoldLimit+1000;
    
    for (int counter1 = 0; counter1 < dotDataHoldCount; counter1++) arrayDotDataHold [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

@end
