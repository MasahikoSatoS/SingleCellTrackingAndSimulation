//
//  NewLineSet.m
//  Cell_Carving
//
//  Created by Masahiko Sato on 2015-04-22.
//
//

#import "NewLineSet.h"

@implementation NewLineSet

-(void)newLineSetMain{
    try{
        
        errorNoHold = 0;
        subCompletionFlag = 1;
        
        int maxPointDimX = 0;
        int maxPointDimY = 0;
        int minPointDimX = 1000000;
        int minPointDimY = 1000000;
        int horizontalLength = 0;
        int verticalLength = 0;
        int dimension = 0;
        int horizontalStart2 = 0;
        int verticalStart2 = 0;
        
        if (retryFlag != -10){
            for (int counter1 = 0; counter1 < referenceLineCount/2; counter1++){
                if (maxPointDimX < arrayReferenceLine [counter1*2]) maxPointDimX = arrayReferenceLine [counter1*2];
                if (minPointDimX > arrayReferenceLine [counter1*2]) minPointDimX = arrayReferenceLine [counter1*2];
                if (maxPointDimY < arrayReferenceLine [counter1*2+1]) maxPointDimY = arrayReferenceLine [counter1*2+1];
                if (minPointDimY > arrayReferenceLine [counter1*2+1]) minPointDimY = arrayReferenceLine [counter1*2+1];
            }
            
            horizontalLength = (maxPointDimX-minPointDimX)/2*2;
            verticalLength = (maxPointDimY-minPointDimY)/2*2;
            
            if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
            if (horizontalLength < verticalLength) dimension = verticalLength+30;
            
            dimension = (dimension/2)*2;
            
            horizontalStart2 = minPointDimX-(dimension-horizontalLength)/2;
            verticalStart2 = minPointDimY-(dimension-verticalLength)/2;
        }
        
        if (retryFlag == -10){
            for (int counter1 = 0; counter1 < cellTrackingCurrentCount/6; counter1++){
                if (maxPointDimX < arrayCellTrackingCurrent [counter1*6]) maxPointDimX = arrayCellTrackingCurrent [counter1*6];
                if (minPointDimX > arrayCellTrackingCurrent [counter1*6]) minPointDimX = arrayCellTrackingCurrent [counter1*6];
                if (maxPointDimY < arrayCellTrackingCurrent [counter1*6+1]) maxPointDimY = arrayCellTrackingCurrent [counter1*6+1];
                if (minPointDimY > arrayCellTrackingCurrent [counter1*6+1]) minPointDimY = arrayCellTrackingCurrent [counter1*6+1];
            }
            
            horizontalLength = (maxPointDimX-minPointDimX)/2*2;
            verticalLength = (maxPointDimY-minPointDimY)/2*2;
            
            if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
            if (horizontalLength < verticalLength) dimension = verticalLength+30;
            
            dimension = (dimension/2)*2;
            
            horizontalStart2 = minPointDimX-(dimension-horizontalLength)/2;
            verticalStart2 = minPointDimY-(dimension-verticalLength)/2;
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3A [counterA][counterB];
        //	cout<<" previousMap3A "<<counterA<<endl;
        //}
        
        if (dimension != 0){
            errorNoHold = 1;
            int **previousMap3A = new int *[dimension+4];
            for (int counter1 = 0; counter1 < dimension+4; counter1++){
                errorNoHold = 2;
                previousMap3A [counter1] = new int [dimension+4];
            }
            
            for (int counterY = 0; counterY < dimension+4; counterY++){
                for (int counterX = 0; counterX < dimension+4; counterX++) previousMap3A [counterY][counterX] = 0;
            }
            
            if (retryFlag != -10){
                for (int counter1 = 0; counter1 < referenceLineCount/2; counter1++){
                    previousMap3A [arrayReferenceLine [counter1*2+1]-verticalStart2][arrayReferenceLine [counter1*2]-horizontalStart2] = 1;
                }
                
                delete [] arrayReferenceLine;
            }
            
            if (retryFlag == -10){
                for (int counter1 = 0; counter1 < partnerInfoCount; counter1++){
                    for (int counter2 = 0; counter2 < cellTrackingCurrentCount/6; counter2++){
                        if (arrayCellTrackingCurrent [counter2*6+3] == arrayPartnerInfo [counter1]){
                            if (arrayCellTrackingCurrent [counter2*6]-horizontalStart2 >= 0 && arrayCellTrackingCurrent [counter2*6]-horizontalStart2 < dimension && arrayCellTrackingCurrent [counter2*6+1]-verticalStart2 >= 0 && arrayCellTrackingCurrent [counter2*6+1]-verticalStart2 < dimension){
                                previousMap3A [arrayCellTrackingCurrent [counter2*6+1]-verticalStart2][arrayCellTrackingCurrent [counter2*6]-horizontalStart2] = 1;
                            }
                        }
                    }
                }
            }
            
            //------Connectivity analysis, For Zero------
            errorNoHold = 3;
            int *connectAnalysisX = new int [(dimension+2)*4];
            errorNoHold = 4;
            int *connectAnalysisY = new int [(dimension+2)*4];
            errorNoHold = 5;
            int *connectAnalysisTempX = new int [(dimension+2)*4];
            errorNoHold = 6;
            int *connectAnalysisTempY = new int [(dimension+2)*4];
            
            int connectivityNumber = -3;
            int connectAnalysisCount = 0;
            int terminationFlag = 0;
            int connectAnalysisTempCount = 0;
            int xSource = 0;
            int ySource = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (previousMap3A [counterY][counterX] == 0){
                        connectivityNumber = connectivityNumber+2;
                        previousMap3A [counterY][counterX] = connectivityNumber;
                        
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && previousMap3A [counterY-1][counterX] == 0){
                            previousMap3A [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension && previousMap3A [counterY][counterX+1] == 0){
                            previousMap3A [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && previousMap3A [counterY+1][counterX] == 0){
                            previousMap3A [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && previousMap3A [counterY][counterX-1] == 0){
                            previousMap3A [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && previousMap3A [ySource-1][xSource] == 0){
                                        previousMap3A [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && previousMap3A [ySource][xSource+1] == 0){
                                        previousMap3A [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && previousMap3A [ySource+1][xSource] == 0){
                                        previousMap3A [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && previousMap3A [ySource][xSource-1] == 0){
                                        previousMap3A [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //------Remove connectivity groups, which attach edge, extract inner part of Linked Line------
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (previousMap3A [counterY][counterX] == -1) previousMap3A [counterY][counterX] = 0;
                    else previousMap3A [counterY][counterX] = 1;
                }
            }
            
            errorNoHold = 7;
            int **connectivityUpdate5 = new int *[dimension+4];
            
            for (int counter1 = 0; counter1 < dimension+4; counter1++){
                errorNoHold = 8;
                connectivityUpdate5 [counter1] = new int [dimension+4];
            }
            
            //-------Zero Fill-------
            for (int counterX = 0; counterX < dimension+4; counterX++){
                for (int counterY = 0; counterY < dimension+4; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++) connectivityUpdate5 [counterY+1][counterX+1] = previousMap3A [counterY][counterX];
            }
            
            connectivityNumber = 0;
            
            for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                    if (connectivityUpdate5 [counterY2][counterX2] == 0){
                        connectivityNumber--;
                        connectAnalysisCount = 0;
                        
                        connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                        
                        if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                            connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                        }
                        if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                            connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                            connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                        }
                        if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                            connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                        connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                        connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                        connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                        connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension+2; counterA++){
            //	for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
            //	cout<<" connectivityUpdate5 "<<counterA<<endl;
            //}
            
            int connectTemp2 = 0;
            
            if (connectivityNumber < -1){
                errorNoHold = 9;
                int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                
                for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
                
                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                        connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                        
                        if (connectTemp2 < -1){
                            connectTemp2 = connectTemp2*-1;
                            
                            if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2-1 >= 0 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2+1 < dimension+2 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2+1 < dimension+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                        }
                    }
                }
                
                int zeroFillFlag = 0;
                
                for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                    if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
                }
                
                if (zeroFillFlag == 1){
                    for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                            connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                            
                            if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                        }
                    }
                    
                    for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                            if (connectivityUpdate5 [counterY2][counterX2] > 0) previousMap3A [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                        }
                    }
                }
                
                delete [] connectCheckArray;
            }
            
            for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] connectivityUpdate5 [counter1];
            
            delete [] connectivityUpdate5;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (previousMap3A [counterY][counterX] != 0){
                        if (counterX+1 < dimension && previousMap3A [counterY][counterX+1] == 0) previousMap3A [counterY][counterX] = -1;
                        else if (counterY+1 < dimension && previousMap3A [counterY+1][counterX] == 0) previousMap3A [counterY][counterX] = -1;
                        else if (counterX-1 >= 0 && previousMap3A [counterY][counterX-1] == 0) previousMap3A [counterY][counterX] = -1;
                        else if (counterY-1 >= 0 && previousMap3A [counterY-1][counterX] == 0) previousMap3A [counterY][counterX] = -1;
                    }
                }
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (previousMap3A [counterY][counterX] > 0) previousMap3A [counterY][counterX] = 0;
                    if (previousMap3A [counterY][counterX] < 0) previousMap3A [counterY][counterX] = 1;
                }
            }
            
            connectivityNumber = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (previousMap3A [counterY2][counterX2] == 0){
                        connectivityNumber--;
                        connectAnalysisCount = 0;
                        
                        previousMap3A [counterY2][counterX2] = connectivityNumber;
                        
                        if (counterY2-1 >= 0 && previousMap3A [counterY2-1][counterX2] == 0){
                            previousMap3A [counterY2-1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                        }
                        if (counterX2+1 < dimension && previousMap3A [counterY2][counterX2+1] == 0){
                            previousMap3A [counterY2][counterX2+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        if (counterY2+1 < dimension && previousMap3A [counterY2+1][counterX2] == 0){
                            previousMap3A [counterY2+1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                        }
                        if (counterX2-1 >= 0 && previousMap3A [counterY2][counterX2-1] == 0){
                            previousMap3A [counterY2][counterX2-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && previousMap3A [ySource-1][xSource] == 0){
                                        previousMap3A [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && previousMap3A [ySource][xSource+1] == 0){
                                        previousMap3A [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && previousMap3A [ySource+1][xSource] == 0){
                                        previousMap3A [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && previousMap3A [ySource][xSource-1] == 0){
                                        previousMap3A [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            delete [] connectAnalysisX;
            delete [] connectAnalysisY;
            delete [] connectAnalysisTempX;
            delete [] connectAnalysisTempY;
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<< previousMap3A [counterA][counterB];
            //    cout<<"  previousMap3A "<<counterA<<endl;
            //}
            
            //------Determine number of pixels------
            connectivityNumber = connectivityNumber*-1;
            
            errorNoHold = 10;
            int *connectedPixels = new int [connectivityNumber+50];
            
            for (int counter1 = 0; counter1 < connectivityNumber+50; counter1++) connectedPixels [counter1] = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (previousMap3A [counterY2][counterX2] < -1) connectedPixels [previousMap3A [counterY2][counterX2]*-1]++;
                }
            }
            
            errorNoHold = 11;
            int **newConnectivityMapTemp = new int *[dimension+4];
            for (int counter1 = 0; counter1 < dimension+4; counter1++){
                errorNoHold = 12;
                newConnectivityMapTemp [counter1] = new int [dimension+4];
            }
            
            for (int counterY = 0; counterY < dimension+4; counterY++){
                for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
            }
            
            int largestConnect = 0;
            int largestConnectNo = 0;
            
            for (int counter1 = 2; counter1 <= connectivityNumber; counter1++){
                if (connectedPixels [counter1] > largestConnect){
                    largestConnect = connectedPixels [counter1];
                    largestConnectNo = counter1;
                }
            }
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (previousMap3A [counterY2][counterX2] == largestConnectNo*-1){
                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && previousMap3A [counterY2-1][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                            previousMap3A [counterY2-1][counterX2-1] = 0;
                        }
                        if (counterY2-1 >= 0 && previousMap3A [counterY2-1][counterX2] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                            previousMap3A [counterY2-1][counterX2] = 0;
                        }
                        if (counterY2-1 >= 0 && counterX2+1 < dimension && previousMap3A [counterY2-1][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                            previousMap3A [counterY2-1][counterX2+1] = 0;
                        }
                        if (counterX2+1 < dimension && previousMap3A [counterY2][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                            previousMap3A [counterY2][counterX2+1] = 0;
                        }
                        if (counterY2+1 < dimension && counterX2+1 < dimension && previousMap3A [counterY2+1][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                            previousMap3A [counterY2+1][counterX2+1] = 0;
                        }
                        if (counterY2+1 < dimension && previousMap3A [counterY2+1][counterX2] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                            previousMap3A [counterY2+1][counterX2] = 0;
                        }
                        if (counterY2+1 < dimension && counterX2-1 >= 0 && previousMap3A [counterY2+1][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                            previousMap3A [counterY2+1][counterX2-1] = 0;
                        }
                        if (counterX2-1 >= 0 && previousMap3A [counterY2][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                            previousMap3A [counterY2][counterX2-1] = 0;
                        }
                    }
                }
            }
            
            delete [] connectedPixels;
            
            int xPositionTempStart = 0;
            int yPositionTempStart = 0;
            int lineSize = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                        previousMap3A [counterY2][counterX2] = 1;
                        xPositionTempStart = counterX2;
                        yPositionTempStart = counterY2;
                        lineSize++;
                    }
                    else previousMap3A [counterY2][counterX2] = 0;
                }
            }
            
            for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] newConnectivityMapTemp [counter1];
            delete [] newConnectivityMapTemp;
            
            int constructedLineCount = 0;
            int findFlag = 0;
            
            errorNoHold = 13;
            int *arrayNewLines = new int [lineSize*2+50];
            
            previousMap3A [yPositionTempStart][xPositionTempStart] = -1;
            arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart2, constructedLineCount++;
            arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart2, constructedLineCount++;
            
            do{
                
                findFlag = 0;
                terminationFlag = 0;
                
                if (xPositionTempStart+1 < dimension){
                    if (previousMap3A [yPositionTempStart][xPositionTempStart+1] == 1){
                        previousMap3A [yPositionTempStart][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart2, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart2, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                    if (previousMap3A [yPositionTempStart+1][xPositionTempStart+1] == 1){
                        previousMap3A [yPositionTempStart+1][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart2, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart2, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (yPositionTempStart+1 < dimension && findFlag == 0){
                    if (previousMap3A [yPositionTempStart+1][xPositionTempStart] == 1){
                        previousMap3A [yPositionTempStart+1][xPositionTempStart] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart2, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart2, constructedLineCount++;
                        yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                    if (previousMap3A [yPositionTempStart+1][xPositionTempStart-1] == 1){
                        previousMap3A [yPositionTempStart+1][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart2, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart2, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart-1 >= 0 && findFlag == 0){
                    if (previousMap3A [yPositionTempStart][xPositionTempStart-1] == 1){
                        previousMap3A [yPositionTempStart][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart2, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart2, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (previousMap3A [yPositionTempStart-1][xPositionTempStart-1] == 1){
                        previousMap3A [yPositionTempStart-1][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart2, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart2, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (previousMap3A [yPositionTempStart-1][xPositionTempStart] == 1){
                        previousMap3A [yPositionTempStart-1][xPositionTempStart] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart2, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart2, constructedLineCount++;
                        yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (previousMap3A [yPositionTempStart-1][xPositionTempStart+1] == 1){
                        previousMap3A [yPositionTempStart-1][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart2, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart2, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                    }
                }
                
            } while (terminationFlag == 1);
            
            //===========
            //int aa = arrayNewLines [0];
            //int bb = arrayNewLines [1];
            
            //int cc = arrayNewLines [(constructedLineCount/2-1)*2];
            //int dd = arrayNewLines [(constructedLineCount/2-1)*2+1];
            
            //int findLink = 0;
            
            //if (cc-1 == aa && dd-1 == bb) findLink = 1;
            //else  if (cc == aa && dd-1 == bb) findLink = 1;
            //else  if (cc+1 == aa && dd-1 == bb) findLink = 1;
            //else  if (cc+1 == aa && dd == bb) findLink = 1;
            //else  if (cc+1 == aa && dd+1 == bb) findLink = 1;
            //else  if (cc == aa && dd+1 == bb) findLink = 1;
            //else  if (cc-1 == aa && dd+1 == bb) findLink = 1;
            //else  if (cc-1 == aa && dd == bb) findLink = 1;
            
            //if (findLink == 0){
            //     for (int counterA = 0; counterA < dimension; counterA++){
            //         for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3A [counterA][counterB];
            //         cout<<" previousMap3A "<<counterA<<endl;
            //     }
            // }
            
            //==========
            
            for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] previousMap3A [counter1];
            delete [] previousMap3A;
            
            if (retryFlag != -10) delete [] arrayReferenceLine;
            
            errorNoHold = 14;
            arrayReferenceLine = new int [constructedLineCount+50];
            referenceLineCount = 0;
            referenceLineLimit = constructedLineCount+50;
            
            for (int counter1 = 0; counter1 < constructedLineCount/2; counter1++){
                arrayReferenceLine [referenceLineCount] = arrayNewLines [counter1*2], referenceLineCount++;
                arrayReferenceLine [referenceLineCount] = arrayNewLines [counter1*2+1], referenceLineCount++;
            }
            
            delete [] arrayNewLines;
        }
        else{
            
            trackHoldFlag = 3000;
        }
        
        errorNoHold = 0;
        subCompletionFlag = 0;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingNewLineSet "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"NewLineSet"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        if (errorNoHold == 0) errorNoHold = 1000;
        
        subCompletionFlag = 0;
    }
}

@end
